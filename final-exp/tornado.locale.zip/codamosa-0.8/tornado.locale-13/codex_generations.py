

# Generated at 2022-06-12 13:31:23.484754
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    _ = Locale("en").translate
    assert _("%(weekday)s, %(month_name)s %(day)s") % {
        "month_name": "June",
        "weekday": "Tuesday",
        "day": "11",
    } == "Tuesday, June 11"
    assert _("%(month_name)s %(day)s") % {
        "month_name": "June",
        "day": "11",
    } == "June 11"



# Generated at 2022-06-12 13:31:25.532292
# Unit test for constructor of class Locale
def test_Locale():
    assert(isinstance(Locale('en_US'), Locale))


# Generated at 2022-06-12 13:31:36.424985
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime, timedelta
    now = datetime.now()
    one_hour_ago = now - timedelta(hours=1)
    one_day_ago = now - timedelta(days=1)
    one_week_ago = now - timedelta(days=7)
    one_month_ago = now - timedelta(days=30)
    one_year_ago = now - timedelta(days=365)
    assert trans(Locale.get('en')).format_date(now) == 'just now'
    assert trans(Locale.get('en')).format_date(one_hour_ago) == '1 hour ago'
    assert trans(Locale.get('en')).format_date(one_day_ago) == 'yesterday'
    assert trans(Locale.get('en')).format

# Generated at 2022-06-12 13:31:37.725246
# Unit test for function load_translations
def test_load_translations():
    load_translations('tornado/locale')

# Generated at 2022-06-12 13:31:39.420724
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    return None

# Generated at 2022-06-12 13:31:47.563319
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en").list(["A"]) == "A"
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    assert Locale.get("en").list(["A", "B", "C", "D"]) == "A, B, C and D"
    assert Locale.get("fa").list(["A", "B", "C", "D"]) == "A \u0648 B \u0648 C \u0648 D"



# Generated at 2022-06-12 13:31:56.963287
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    '''
    Unit test for method format_date of class Locale
    '''
    locale = Locale.get("zh_CN")

# Generated at 2022-06-12 13:32:08.531787
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    #A is not found in translations, so the message returned is original message
    assert CSVLocale("en", {}).translate("A") == "A"
    assert CSVLocale("en", {"singular": {}, "plural": {}}).translate("A") == "A"
    assert CSVLocale("en", {"unknown": {}, "singular": {}, "plural": {}}).translate("A") == "A"
    #B is found in translations, so the returned message will be the translated version of B
    assert CSVLocale("en", {"singular": {"B": "B translated"}}).translate("B") == "B translated"
    assert CSVLocale("en", {"singular": {"B": "B translated"}, "plural": {}}).translate("B") == "B translated"

# Generated at 2022-06-12 13:32:19.354689
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    result = Locale('en').friendly_number(100)
    assert result == '100'
    result = Locale('en').friendly_number(10000)
    assert result == '10,000'
    result = Locale('en').friendly_number(100000)
    assert result == '100,000'
    result = Locale('en').friendly_number(1000000)
    assert result == '1,000,000'
    result = Locale('en').friendly_number(10000000)
    assert result == '10,000,000'
    result = Locale('en').friendly_number(100000000)
    assert result == '100,000,000'
    result = Locale('en').friendly_number(1000000000)
    assert result == '1,000,000,000'
    result = Locale('en').friendly_

# Generated at 2022-06-12 13:32:21.039030
# Unit test for function load_translations
def test_load_translations():
    from tornado import web
    from tornado.testing import AsyncHTTPTestCase, ExpectLog



# Generated at 2022-06-12 13:32:49.692896
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    """Function test_Locale_pgettext returns None or exits with
    an error."""
    gen_log = logging.getLogger("Generator")

# Generated at 2022-06-12 13:32:57.881400
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale.get('en_US')
    assert(locale.format_date(datetime.datetime.utcnow() + datetime.timedelta(seconds=10)) == '1 second ago')
    assert(locale.format_date(datetime.datetime.utcnow() + datetime.timedelta(minutes=10)) == '10 minutes ago')
    assert(locale.format_date(datetime.datetime.utcnow() + datetime.timedelta(hours=10)) == '10 hours ago')
    assert(locale.format_date(datetime.datetime.utcnow() + datetime.timedelta(days=1)) == 'yesterday')

# Generated at 2022-06-12 13:33:08.066150
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    now = datetime.datetime.utcnow()
    now_seconds = int(time.mktime(now.timetuple()))
    print("Test case 1")
    print("Evaluate: Locale.get().format_date(%d)" % now_seconds)
    print("Expect: 'a few seconds ago'")
    print("=>", Locale.get().format_date(now_seconds))
    print("==================================================")
    print("Test case 2")
    print("Evaluate: Locale.get().format_date(%d, relative=False)" % now_seconds)

# Generated at 2022-06-12 13:33:18.876932
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(12) == "12"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(123456) == "123,456"
    assert Locale.get("en").friendly_number(1234567) == "1,234,567"
    assert Locale.get("en").friendly_number(12345678) == "12,345,678"

# Generated at 2022-06-12 13:33:20.165330
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("locale", "mydomain")



# Generated at 2022-06-12 13:33:25.585790
# Unit test for function load_translations
def test_load_translations():
    import sys
    import os
    import locale
    translation_file_path = r"./locale/es_GT.csv" #os.path.join(os.path.dirname(sys.argv[0]), "locale")
    load_translations(r"./locale")
    user_locale = get("es_GT")
    print(user_locale.translate("Sign out"))



# Generated at 2022-06-12 13:33:30.757610
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale("en_US")
    result = locale.friendly_number(123)
    assert result == "123"
    result = locale.friendly_number(1000)
    assert result == "1,000"
    result = locale.friendly_number(12345678)
    assert result == "12,345,678"



# Generated at 2022-06-12 13:33:32.193253
# Unit test for function load_translations
def test_load_translations():
    load_translations('locale')
    print(_translations)

# Generated at 2022-06-12 13:33:36.713094
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('./i18n', 'message')
    print(get('zh_CN').translate('Welcome'))
    # gettext还支持多语言同时输出：
    # print(get('zh_CN', 'zh_CN', 'en').translate('Welcome'))


# Generated at 2022-06-12 13:33:37.251690
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    pass


# Generated at 2022-06-12 13:33:58.493242
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert (Locale('en').friendly_number(100) == "100")
    assert (Locale('en').friendly_number(1234) == "1,234")
    assert (Locale('en').friendly_number(123456) == "123,456")
    assert (Locale('en').friendly_number(1234567) == "1,234,567")
    assert (Locale('en').friendly_number(12345678) == "12,345,678")
    assert (Locale('en').friendly_number(123456789) == "123,456,789")



# Generated at 2022-06-12 13:33:59.764065
# Unit test for function load_translations
def test_load_translations():
    assert load_translations('.')


# Generated at 2022-06-12 13:34:05.473827
# Unit test for method list of class Locale
def test_Locale_list():
    locale = Locale.get("fa")
    assert locale.list([]) == ""
    assert locale.list(["A"]) == "A"
    assert locale.list(["A", "B"]) == "A \u0648 B"
    assert locale.list(["A", "B", "C"]) == "A, B \u0648 C"
    assert locale.list(["A", "B", "C", "D"]) == "A, B, C \u0648 D"



# Generated at 2022-06-12 13:34:07.073873
# Unit test for function load_translations
def test_load_translations():
    def result()->int:
        # TODO: test here
        return 0
    return result


# Generated at 2022-06-12 13:34:08.923874
# Unit test for function load_translations
def test_load_translations():
    load_translations('d:/test/test_data/')
test_load_translations()



# Generated at 2022-06-12 13:34:11.936615
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
     code = "en_US"
     translation = {"unknown": {"message": "singular"},
                    "plural": {"plural_message": "plural"}}
     loc = CSVLocale(code, translation)
     assert loc.translate("message") == "singular"
     assert loc.translate("plural_message", "plural_message", 2) == "plural"

# Generated at 2022-06-12 13:34:13.501822
# Unit test for function load_translations
def test_load_translations():
    # TODO write unit test code
    load_translations('databases/translations')
    assert True



# Generated at 2022-06-12 13:34:15.551722
# Unit test for function load_translations
def test_load_translations():
    DIR = "./trans/"
    load_translations(DIR)
    for key, item in _translations.items():
        print(key, item)



# Generated at 2022-06-12 13:34:19.689728
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    if(os.path.exists(os.path.dirname(__file__)+'/locale')):
        load_gettext_translations(os.path.dirname(__file__)+'/locale','tornado')
    else:
        load_gettext_translations('tornado/locale','tornado')
    gen_log.debug(str(_translations))



# Generated at 2022-06-12 13:34:22.628246
# Unit test for function load_translations
def test_load_translations():
    temp_translations = {}
    temp_supported_locales = frozenset()
    load_translations("path_to_location")
    assert len(temp_translations) == len(_translations)
    assert len(temp_supported_locales) == len(_supported_locales)


# Generated at 2022-06-12 13:34:49.317086
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    temp_translations = {
        'singular': {'Hello World!': 'Saluton Mondon!'},
        'plural': {'Hello Worlds!': 'Saluton Mondoj!'}
    }
    locale = CSVLocale('eo', temp_translations)
    assert locale.translate('Hello World!') == 'Saluton Mondon!'
    assert locale.translate('Hello Worlds!') == 'Saluton Mondoj!'
    assert locale.translate('Hello Worlds!', count=2) == 'Saluton Mondoj!'
    assert locale.translate('Hello World!', 'Hello Worlds!', count=2) == 'Saluton Mondoj!'
    assert locale.translate('Hello World!', 'Hello Worlds!', count=1) == 'Saluton Mondon!'

# Generated at 2022-06-12 13:34:52.723366
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    dt = datetime.datetime(2019, 8, 1)
    locale = Locale("zh_CN")
    result = locale.format_day(dt)
    assert result == "2019\u5e748\u67081\u65e5\u5468\u4e00"



# Generated at 2022-06-12 13:35:00.858670
# Unit test for function load_translations
def test_load_translations():
    load_translations('test_translate')
    string = get('zh_CN').translate('I love you')
    assert string == '我爱你'
    string = get('zh_CN').translate('%(name)s liked this', name='我')
    assert string == '我喜欢这'
    
    string = get('en_US').translate('I love you')
    assert string == 'I love you'
    string = get('en_US').translate('%(name)s liked this', name='我')
    assert string == 'I liked this'



# Generated at 2022-06-12 13:35:11.713741
# Unit test for function load_translations
def test_load_translations():
    import shutil
    import tempfile
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 13:35:18.372985
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1000) == str(1000)
    assert Locale.get("en").friendly_number(1000000) == str(1000000)
    assert Locale.get("en").friendly_number(1000000) != str(1000)
    assert Locale.get("en").friendly_number(1000000) != str(1000000000)
    assert Locale.get("en").friendly_number(1000000000) == str(1000000000)



# Generated at 2022-06-12 13:35:24.806707
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # test when relative is True
    locale = Locale.get('en_US')
    time_now = datetime.datetime.utcnow()
    time_before = time_now - datetime.timedelta(seconds=5)
    time_before_day = time_now - datetime.timedelta(days=1)
    time_before_week = time_now - datetime.timedelta(days=7)
    time_before_year = time_now - datetime.timedelta(days=365)
    time_after = time_now + datetime.timedelta(seconds=5)
    print(locale.format_date(time_now))
    print(locale.format_date(time_before))
    print(locale.format_date(time_before_day))

# Generated at 2022-06-12 13:35:36.333935
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    locale = GettextLocale("en_UA", gettext.translation("tornado", localedir="locale"))
    result = locale.pgettext("law", "right")
    assert result == "право"
    result = locale.pgettext("good", "right")
    assert result == "правильно"
    result = locale.pgettext("organization", "club", "clubs", len([]))
    assert result == "клуб"
    result = locale.pgettext("organization", "club", "clubs", len([1]))
    assert result == "клуби"
    result = locale.pgettext("stick", "club", "clubs", len([]))
    assert result == "копитка"


# Generated at 2022-06-12 13:35:44.384709
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tornado.gen
    import tornado.testing
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop


    class GettextTest(tornado.testing.AsyncTestCase):
        def tearDown(self):
            load_gettext_translations("/not/a/real/directory", "notadomain")
            super(GettextTest, self).tearDown()

        def test_load(self):
            # Create a temporary directory with fake locale files
            locale_dir = self.get_temp_dir()
            os.makedirs(os.path.join(locale_dir, "pt_BR", "LC_MESSAGES"))


# Generated at 2022-06-12 13:35:50.384361
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    Locale.get_closest = MagicMock(return_value = Locale.get("en_US"))
    locale = Locale.get("en_US")
    assert locale.format_day(datetime.datetime(2001, 1, 22)) == "Monday, January 22"
    assert locale.format_day(datetime.datetime(2001, 1, 22), dow = False) == "January 22"



# Generated at 2022-06-12 13:35:57.618455
# Unit test for function load_translations
def test_load_translations():
    from pathlib import Path
    from os import mkdir
    from os.path import exists
    from tempfile import mkdtemp
    resources = Path(__file__)
    tempdir = mkdtemp()
    csv_dir = resources / 'tests' / 'test_locale_data'
    locales = csv_dir.glob('*.csv')
    for resource_locale in locales:
        locale = str(resource_locale).split('_', 1)[1]
        with open(tempdir + '/' + locale, 'w') as filehandle:
            filehandle.write(resource_locale)
    load_translations(tempdir)
    assert _translations



# Generated at 2022-06-12 13:36:24.371311
# Unit test for function load_translations
def test_load_translations():
    directory=r'C:\Users\Administrator\tornado\examples\demos\Zol\translations'
    load_translations(directory)
    print(_translations)



# Generated at 2022-06-12 13:36:31.356435
# Unit test for constructor of class Locale
def test_Locale():
    print("Locale: test constructor")
    code = 'zh_CN'
    locale = Locale.get(code)
    for i in range(len(_translations)):
        assert len(_translations) >= 1
    for i in range(len(_supported_locales)):
        assert len(_supported_locales) >= 1
    assert isinstance(locale.code, str)
    assert isinstance(locale.name, str)
    assert locale.code == 'zh_CN'
    assert locale.name == 'zh'
    assert locale.rtl == False

# Generated at 2022-06-12 13:36:42.243038
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime

    cases = [
        {"dow": True, "date": datetime(2018, 5, 1), "expected": "Tuesday, May 1"},
        {"dow": True, "date": datetime(2018, 5, 2), "expected": "Wed May 2"},
        {"dow": False, "date": datetime(2018, 5, 1), "expected": "May 1"},
        {"dow": False, "date": datetime(2018, 5, 2), "expected": "May 2"},
    ]

    # Load the translation
    import os

    directory = os.path.join(os.path.dirname(__file__), "translations")
    load_csv_translations(directory)

    # Run the tests
    for case in cases:
        locale = Locale.get("en")

# Generated at 2022-06-12 13:36:48.298326
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert "Monday, January 2"   == Locale.get("en_US").format_day(datetime.date(2017, 1, 2))
    assert "Monday, January 22"  == Locale.get("en_US").format_day(datetime.date(2017, 1, 22))
    assert "Monday, January 2"   == Locale.get("en_US").format_day(datetime.date(2017, 1, 2), dow=True)
    assert "January 2"           == Locale.get("en_US").format_day(datetime.date(2017, 1, 2), dow=False)
    assert "Monday, January 22"  == Locale.get("en_US").format_day(datetime.date(2017, 1, 22), dow=True)

# Generated at 2022-06-12 13:36:59.262246
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    from datetime import datetime, timezone, timedelta
    from collections import namedtuple
    from typing import Dict, Tuple, List, Optional

    def sec_until_midnight(date: datetime = datetime.now()) -> int:
        """Return the number of seconds until midnight"""
        tomorrow = date.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
        return (tomorrow - date).seconds


# Generated at 2022-06-12 13:37:01.917570
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Make sure it doesn't throw an exception
    import tornado
    tornado.locale.load_gettext_translations('tornado/locale', 'tornado')



# Generated at 2022-06-12 13:37:10.073877
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import json
    test_dir = os.path.dirname(__file__)+'/test_data'
    load_gettext_translations(test_dir,'test_locale')
    assert(
        _supported_locales 
        == 
        {'es_MX', 'en_US'}
    )
    assert(
        _translations 
        == 
        {
            'es_MX': gettext.translation('test_locale', test_dir, languages=['es_MX']), 
            'en_US': gettext.translation('test_locale', test_dir, languages=['en_US'])
        }
    )
    assert(_use_gettext == True)

# Generated at 2022-06-12 13:37:21.203659
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    def test(code, date, result, relative=True, gmt_offset=0, **kwargs):
        locale = Locale.get(code)
        if not isinstance(date, datetime.datetime):
            date = datetime.datetime.utcfromtimestamp(date)
        assert locale.format_date(date, gmt_offset=gmt_offset, relative=relative, **kwargs) == result

    from_now = datetime.datetime.utcnow()

    test("en_US", from_now, "just now", relative=True)
    test("en_US", from_now - datetime.timedelta(seconds=1), "just now", relative=True)
    test("en_US", from_now - datetime.timedelta(seconds=50), "50 seconds ago", relative=True)

# Generated at 2022-06-12 13:37:30.802041
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(1980, 7, 10)) == "Wednesday, July 10"
    assert Locale.get("en").format_day(datetime.datetime(1980, 7, 10), dow=False) == "July 10"
    assert Locale.get("fa").format_day(datetime.datetime(1980, 7, 10)) == "چهارشنبه، ژوئن 10"
    assert Locale.get("fa").format_day(datetime.datetime(1980, 7, 10), dow=False) == "ژوئن 10"
    assert Locale.get("en").format_day(datetime.datetime(1980, 7, 10), gmt_offset=-300) == "Tuesday, July 9"

#

# Generated at 2022-06-12 13:37:34.513181
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale("en").friendly_number(12345) == "12,345"
    assert Locale("en").friendly_number(123456789) == "123,456,789"
    assert Locale("en").friendly_number(123) == "123"



# Generated at 2022-06-12 13:38:34.776354
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_locale_abbr = 'en_US'
    test_value = 123456789
    test_result = '123,456,789'
    test_locale_obj = Locale(test_locale_abbr)
    test_output = test_locale_obj.friendly_number(test_value)
    # assert test_output.strip(' ') == test_result.strip(' ')
    assert test_output == test_result,\
        "Expected {}, and got {}".format(test_result, test_output)



# Generated at 2022-06-12 13:38:44.484945
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """
        Unit test for format_day of class Locale
        author: Suvash Sedhain
    """
    assert Locale.get('en').format_day(datetime.date(2006,1,1), dow = True) == "Sunday, January 1"
    assert Locale.get('en').format_day(datetime.date(2006,1,1), dow = False) == "January 1"
    assert Locale.get('fa').format_day(datetime.date(2006,1,1), dow = True) == "یکشنبه، ژانویه 1"
    assert Locale.get('fa').format_day(datetime.date(2006,1,1), dow = False) == "ژانویه 1"


# Generated at 2022-06-12 13:38:55.251349
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert "1,000" == Locale.get("en").friendly_number(1000)
    assert "οκτώ" == Locale.get("el").friendly_number(8)
    assert u"\u0661" == Locale.get("ar").friendly_number(1)
    assert u"\u066b" == Locale.get("ar").friendly_number(11)
    assert u"\u0661\u066b" == Locale.get("ar").friendly_number(11)
    assert "11" == Locale.get("en").friendly_number(11)
    assert "111" == Locale.get("en").friendly_number(111)
    assert "1,111" == Locale.get("en").friendly_number(1111)

# Generated at 2022-06-12 13:39:02.251530
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('./locale','test')
    assert 'zh_CN' in _supported_locales
    assert 'ko_KR' in _supported_locales

_re_plural_conditional = re.compile(r"""
    \{
        \s*(\w+)  # variable name
        \s*\,\s*
        (\w(?:[\w\s\|]*\w)?)  # variable values (or ranges)
        \s*
    \}
""", re.VERBOSE | re.IGNORECASE)



# Generated at 2022-06-12 13:39:07.271129
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    _translations = {}
    _translations["en_US"] = {"lalala": {"" : "Lalala"}}
    _translations["pt_BR"] = {"lalala": {"" : "Lalala BR"}}
    translations = _translations["en_US"]
    locale = Locale("en_US", translations)

    assert locale.pgettext("lalala", "") == "Lalala"
    assert locale.pgettext("lalala", "", "") == "Lalala"

    if __name__ == "__main__":
        import doctest

        doctest.testmod()

# Generated at 2022-06-12 13:39:16.290421
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """
    The method format_date in class Locale used to render
    each date into a different format. Now, we try to
    test this method by feeding it with four different dates.


    @param date: is a date that we want to convert it in to a string
    @param gmt_offset: is time zone
    @param relative: is a boolean that represent if we have to return
    a relative time
    @param shorter: is a boolean that represent if we have to return a
    shorter format of the string
    @param full_format: is a boolean that represent if we have to return a
    full format of string
    @return: a string that represent the date in the desired format
    """
    import datetime
    now = datetime.datetime.today()
    date1 = now - datetime.timedelta(minutes=3)

# Generated at 2022-06-12 13:39:20.386304
# Unit test for function load_translations
def test_load_translations():
    # Given
    directory = "..\\test"
    # When
    load_translations(directory)
    # Then
    assert _translations == {}
    assert _supported_locales == frozenset(['en_US'])
    assert gen_log.error.call_count == 3


# Generated at 2022-06-12 13:39:29.181185
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    locale = GettextLocale("en", gettext.NullTranslations())
    test_dict = {
        "good": "good",
        "law": "law",
        "clubs": "clubs",
    }
    for key in test_dict:
        assert locale.pgettext("good", key) == test_dict[key]
        assert locale.pgettext("law", key) == test_dict[key]
    assert locale.pgettext("good", "club", "clubs", 1) == "club"
    assert locale.pgettext("good", "club", "clubs", 5) == "clubs"
    assert locale.pgettext("law", "club", "clubs", 1) == "club"

# Generated at 2022-06-12 13:39:29.657644
# Unit test for function load_translations
def test_load_translations():
    pass



# Generated at 2022-06-12 13:39:34.645424
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    day = 8
    month_name = "September"
    year = 2018
    weekday = "Thursday"
    en = Locale("en")
    actual = en.format_day(datetime.datetime(year, 9, day), 0)
    print(actual)
    expected = weekday+", "+month_name+" "+str(day)
    assert actual == expected
    en = Locale("en")
    actual = en.format_day(datetime.datetime(year, 9, day), 0, False)
    print(actual)
    expected = month_name+" "+str(day)
    assert actual == expected
