

# Generated at 2022-06-12 13:31:39.121039
# Unit test for method list of class Locale
def test_Locale_list():
    _ = lambda x: x

    for l in ["en", "en_US", "ru_RU", "fa_IR"]:
        loc = Locale.get(l)
        for i in range(4):
            a = loc.list([str(j) for j in range(i)])
            b = ", ".join(str(j) for j in range(i))
            assert a == b



# Generated at 2022-06-12 13:31:46.433173
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    #### check weekday, month, day

    # check whether the number is correct or not
    date = datetime.datetime.utcnow()
    check_1 = date.strftime("%A") + ", " + date.strftime("%B") + " " + date.strftime("%d")

    if check_1 != Locale.format_day(date):
        raise Exception("test_Locale_format_day function in Locale failed.")
    else:
        print("test_Locale_format_day function in Locale passed.")



# Generated at 2022-06-12 13:31:53.148660
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import re

    class TestDate(datetime.datetime):
        @classmethod
        def utcnow(cls):
            return cls(2018, 4, 16, hour=14, minute=32, second=52)

    def test_format(local_date, expected_format, gmt_offset=0, shorter=False):
        expected = re.sub(" *\n *", " ", expected_format)
        result = Locale("en").format_date(
            local_date, gmt_offset=gmt_offset, shorter=shorter
        )
        assert expected == result

    def test_format_full(local_date, expected):
        test_format(local_date, expected, full_format=True)

    def test_format_utc(local_date, expected, shorter=False):
        test_format

# Generated at 2022-06-12 13:31:58.202879
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    import sys
    import os
    import gettext
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_helpers import patch
    from zerver.lib.locale_test import load_test_locale_config
    GettextLocale._cache = dict()
    realm = get_realm('zulip')
    realm.default_language = 'ru'
    realm.save()
    FOLDER_PATH = settings.DEPLOY_ROOT + \
        '/templates/zerver/translations/ru/LC_MESSAGES'
    if not os.path.exists(FOLDER_PATH):
        os.makedirs(FOLDER_PATH)

# Generated at 2022-06-12 13:32:05.343428
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    from .base import config

    config["default_locale"] = "en_US"
    config["locales.supported_locales"] = "en_US"
    set_locale("en_US")
    assert get_locale().friendly_number(12) == "12"
    assert get_locale().friendly_number(123) == "123"
    assert get_locale().friendly_number(1234) == "1,234"
    assert get_locale().friendly_number(12345) == "12,345"



# Generated at 2022-06-12 13:32:08.226417
# Unit test for function load_translations
def test_load_translations():
    load_translations("C:\\Users\\kamal\\Desktop\\My_Code\\tornado_prac\\translations")
    print(_translations)

# Generated at 2022-06-12 13:32:10.551760
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    assert _supported_locales == frozenset(['pt_BR'])
    assert _use_gettext == True



# Generated at 2022-06-12 13:32:20.857233
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    CSVLocale('en', {}).translate('a', None, 1)
    CSVLocale('en', {'unknown': {}}).translate('a', None, 1)
    CSVLocale('en', {'unknown': {'a': 'b'}}).translate('a', None, 1)
    CSVLocale('en', {'unknown': {'a': 'b'}}).translate('c', None, 1)
    CSVLocale('en', {'plural': {'a': 'b'}}).translate('a', None, 1)
    CSVLocale('en', {'plural': {'a': 'b'}}).translate('a', 'b', 1)



# Generated at 2022-06-12 13:32:28.423167
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    loc_en = Locale.get('en')
    loc_en_us = Locale.get('en_US')
    loc_fa = Locale.get('fa')
    loc_fa_ir = Locale.get('fa_IR')
    assert loc_en.friendly_number(1) == '1'
    assert loc_en_us.friendly_number(1) == '1'
    assert loc_fa.friendly_number(1) == '1'
    assert loc_fa_ir.friendly_number(1) == '1'
    assert loc_en.friendly_number(12) == '12'
    assert loc_en_us.friendly_number(12) == '12'
    assert loc_fa.friendly_number(12) == '12'
    assert loc_fa_ir.friendly_number(12)

# Generated at 2022-06-12 13:32:37.048717
# Unit test for function load_translations
def test_load_translations():
    print('testing load_translations()')
    directory='test'
    encoding='utf8'
    if not os.path.exists(directory):
        os.makedirs(directory)
    expected_translations={'a': {'plural': {'key': 'a'}}}
    with open(os.path.join(directory,'a.csv'),'w',encoding=encoding) as f:
        f.write('"key", "a","plural"\n')
    load_translations(directory,encoding)
    assert _translations['a'] == expected_translations['a']
    print('passed')


# Generated at 2022-06-12 13:32:51.048212
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """should format a date depending on relative, full_format and shorter"""
    # @todo waiting for a solution to test with pytest
    pass

# Generated at 2022-06-12 13:32:56.779292
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en_US")
    assert locale.friendly_number(100) == "100"
    assert locale.friendly_number(1000) == "1,000"
    assert locale.friendly_number(10000) == "10,000"
    assert locale.friendly_number(100000) == "100,000"
    assert locale.friendly_number(1000000) == "1,000,000"
    assert locale.friendly_number(1000000000) == "1,000,000,000"



# Generated at 2022-06-12 13:33:07.516084
# Unit test for function load_translations
def test_load_translations():
    from tornado import locale
    import tempfile
    import os
    code_string = '''"I love you","Te amo"
        "%(name)s liked this","A %(name)s les gustó esto","plural"
        "%(name)s liked this","A %(name)s le gustó esto","singular"'''
    tmp = tempfile.mkdtemp()
    fd, path = tempfile.mkstemp(dir=tmp)
    with os.fdopen(fd, "wb") as f:
        f.write(code_string.encode())
    locale.load_translations(tmp)
    os.remove(path)
    os.rmdir(tmp)
    assert locale._translations['en_US'] is not None, "Load translations failed."



# Generated at 2022-06-12 13:33:18.225993
# Unit test for method format_date of class Locale

# Generated at 2022-06-12 13:33:28.537658
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    '''
    Returns a comma-separated list for the given list of parts.

    The format is, e.g., "A, B and C", "A and B" or just "A" for lists
    of size 1.
    '''
    # the day of month
    test_day = "02"
    # the week day
    test_weekday = "Sunday"
    # the month name
    test_month = "October"

    _ = test_instance.translate
    if len(parts) == 0:
        return ""
    if len(parts) == 1:
        return parts[0]
    comma = u" \u0648 " if self.code.startswith("fa") else u", "

# Generated at 2022-06-12 13:33:38.165196
# Unit test for function load_translations
def test_load_translations():
    import tempfile
    import shutil
    import csv
    csv_str1 = '''"Hello","Bonjour"
"%(name)s liked this","A %(name)s les gustó esto","plural"
"%(name)s liked this","A %(name)s le gustó esto","singular"'''
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 13:33:40.830713
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    Locale.get_closest("ja_JP")
    date = datetime.datetime.now()
    print(Locale.get_closest("ja_JP").format_day(date, 0))



# Generated at 2022-06-12 13:33:51.908012
# Unit test for constructor of class Locale
def test_Locale():
    _translations = {}
    _translations["en_US"] = {}
    _translations["en_US"].setdefault("unknown", {})["hello"] = "hello"
    _translations["en_US"].setdefault("unknown", {})["world"] = "world"
    _translations["en_US"].setdefault("unknown", {})["yesterday"] = "yesterday"
    _translations["en_US"].setdefault("unknown", {})["today"] = "today"
    _translations["en_US"].setdefault("unknown", {})["tomorrow"] = "tomorrow"
    _translations["en_US"].setdefault("unknown", {})["hour ago"] = "%(hours)d hours ago"

# Generated at 2022-06-12 13:33:58.183083
# Unit test for method list of class Locale
def test_Locale_list():
    Locale.load_translations('locale')
    locale = Locale.get_closest("en", "fi")
    print(locale.list([1,2,"mix",u"\uef43",[5],[5,6]]))
    print(locale.list([]))

    locale = Locale.get_closest("zh", "fi")
    print(locale.list([1,2,"mix",u"\uef43",[5],[5,6]]))
    print(locale.list([]))

    locale = Locale.get_closest("ru", "fi")
    print(locale.list([1,2,"mix",u"\uef43",[5],[5,6]]))
    print(locale.list([]))

    locale = Locale.get_cl

# Generated at 2022-06-12 13:34:04.483811
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l = Locale.get("en")
    assert l.friendly_number(1) == "1"
    assert l.friendly_number(12) == "12"
    assert l.friendly_number(123) == "123"
    assert l.friendly_number(1234) == "1,234"
    assert l.friendly_number(12345) == "12,345"
    assert l.friendly_number(123456) == "123,456"
    assert l.friendly_number(1234567) == "1,234,567"
    assert l.friendly_number(12345678) == "12,345,678"



# Generated at 2022-06-12 13:34:42.722369
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    loc = Locale("en")
    assert loc.friendly_number(4) == "4"
    assert loc.friendly_number(40) == "40"
    assert loc.friendly_number(400) == "400"
    assert loc.friendly_number(4000) == "4,000"
    assert loc.friendly_number(40000) == "40,000"
    assert loc.friendly_number(400000) == "400,000"
    assert loc.friendly_number(4000000) == "4,000,000"
    assert loc.friendly_number(40000000) == "40,000,000"
    assert loc.friendly_number(400000000) == "400,000,000"
    assert loc.friendly_number(4000000000) == "4,000,000,000"



# Generated at 2022-06-12 13:34:52.974798
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class MockGettextLocale(GettextLocale):
        def __init__(self):
            self.ngettext = self.mock_ngettext
            self.gettext = self.mock_gettext
            super().__init__("mock", gettext.NullTranslations())

        def mock_gettext(self, message):
            return message + "_mock_gettext"

        def mock_ngettext(self, message, plural_message, count):
            return plural_message + "_mock_ngettext"

    gt_locale = MockGettextLocale()
    assert gt_locale.pgettext("law", "right") == "right_mock_gettext"
    assert gt_locale.pgettext("good", "right") == "good_mock_gettext"


# Generated at 2022-06-12 13:34:54.791403
# Unit test for function load_translations
def test_load_translations():
    global _translations
    _translations = {}
    load_translations("../tornado/locale")



# Generated at 2022-06-12 13:35:04.763629
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    if len(sys.argv) == 2 and sys.argv[1] == '-test':
        from collections import namedtuple
        # test data
        TestCase = namedtuple("TestCase", "input expected")
        test_case_list = []
        test_case_list.append(
            TestCase(input=10000,
                     expected="10,000"))
        test_case_list.append(
            TestCase(input=1000000,
                     expected="1,000,000"))
        # test method
        for test_case in test_case_list:
            code = "en"
            test_subject = Locale(code)
            result = test_subject.friendly_number(value=test_case.input)
            print(result)
            assert result == test_case.expected

# Generated at 2022-06-12 13:35:06.890309
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/luozhaohui/tornado_app/app/locale", "messages")


# Generated at 2022-06-12 13:35:13.806582
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale("en_US")
    assert locale.friendly_number(1000) == "1,000"
    assert locale.friendly_number(1000000) == "1,000,000"
    assert locale.friendly_number(1234567) == "1,234,567"
    assert locale.friendly_number(123) == "123"
    assert locale.friendly_number(12) == "12"
    assert locale.friendly_number(1) == "1"



# Generated at 2022-06-12 13:35:20.283425
# Unit test for function load_translations
def test_load_translations():
    test_string = """ "I love you","Te amo"
    "%(name)s liked this","A %(name)s les gustó esto","plural"
    "%(name)s liked this","A %(name)s le gustó esto","singular" """
    with open("test.csv", "w") as f:
        f.write(test_string)
    load_translations(".")
    assert _translations != {}
    os.remove("test.csv")



# Generated at 2022-06-12 13:35:21.116837
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # TODO
    pass


# Generated at 2022-06-12 13:35:29.514009
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale("en").friendly_number(1) == "1"
    assert Locale("en").friendly_number(123) == "123"
    assert Locale("en").friendly_number(1234) == "1,234"
    assert Locale("en").friendly_number(12345) == "12,345"
    assert Locale("en").friendly_number(1234567) == "1,234,567"
    assert Locale("en").friendly_number(12345678) == "12,345,678"
test_Locale_friendly_number()



# Generated at 2022-06-12 13:35:40.215586
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    from orator.support.pdate import pdate
    from orator.support.pdate import now

    # Test for relative times in the past
    now().add_second(10)
    locale = Locale.get_closest("en_US")
    assert locale.format_date(pdate().sub_second()) == "1 second ago"
    assert locale.format_date(pdate().sub_second().sub_second()) == "2 seconds ago"
    assert locale.format_date(
        pdate().sub_second().sub_second().sub_second().sub_second().sub_second()) == "5 seconds ago"

# Generated at 2022-06-12 13:36:04.773076
# Unit test for function load_translations
def test_load_translations():
    from tempfile import TemporaryDirectory
    from contextlib import contextmanager
    from io import StringIO
    from contextlib import redirect_stdout
    import tempfile
    import os
    import random

    test_data = """
        "I love you","Te amo"
        "%(name)s liked this","A %(name)s les gustó esto","plural"
        "%(name)s liked this","A %(name)s le gustó esto","singular"
    """


# Generated at 2022-06-12 13:36:08.169775
# Unit test for function load_translations
def test_load_translations():
    dir = "C:/Users/yalei/PycharmProjects/tornado-autumn/tornado-autumn/locale/"
    load_translations(dir)
    print(_translations)



# Generated at 2022-06-12 13:36:17.022121
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    expected = ["Monday, January 21","Monday, January 22"]

    with freeze_time("2019-01-21"):
        locale = Locale.get("en")
        day_1 = locale.format_day(datetime.datetime.now(), gmt_offset=0)
        #print(day_1)
        assert day_1 == "Monday, January 21"

    with freeze_time("2019-01-22"):
        locale = Locale.get("en")
        day_2 = locale.format_day(datetime.datetime.now(), gmt_offset=0)
        #print(day_2)
        assert day_2 == "Monday, January 22"

    assert day_1 != day_2


# Generated at 2022-06-12 13:36:23.475815
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale.get('en_US')
    # Test relative date
    date = datetime.datetime.utcnow()
    relative = locale.format_date(date)
    assert relative == 'just now'
    # Test absolute date
    absolute = locale.format_date(date, relative=False)
    assert absolute == 'Today at ' + '{:%I:%M%p}'.format(date)
    # Test Shortest format date
    shortest = locale.format_date(date, full_format=True, shorter=True)
    assert shortest.__eq__('Today')
    # Test full format date
    full = locale.format_date(date, full_format=True)
    assert full.__eq__('Today at ' + '{:%I:%M%p}'.format(date))


#

# Generated at 2022-06-12 13:36:34.668710
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l = Locale.get("fa_IR")
    assert l.friendly_number(100) == "100"
    assert l.friendly_number(123456789) == "123456789"
    l = Locale.get("en_US")
    assert l.friendly_number(100) == "100"
    assert l.friendly_number(123456789) == "123,456,789"

    l = Locale.get("en_US")
    assert l.list(["a", "b", "c"]) == "a, b and c"

    l = Locale.get("fa_IR")
    assert l.list(["a", "b", "c"]) == u"a \u0648 b \u0648 c"

    l = Locale.get("en")
    assert l.format_

# Generated at 2022-06-12 13:36:35.821669
# Unit test for function load_translations
def test_load_translations():
    """Test load_translations."""

# Generated at 2022-06-12 13:36:38.419755
# Unit test for function load_translations
def test_load_translations():
    test_path = os.path.join(os.path.dirname(__file__), 'test_locale')
    load_translations(test_path, 'utf-8')



# Generated at 2022-06-12 13:36:46.358077
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    def _test(code, date, gmt_offset, dow, expected):
        """
        Args:
            code: language code
            date: datetime.datetime object
            gmt_offet: offset from GMT
            dow: use day of week flag
            expected: expected string returned from locale.format_day
        """
        locale = Locale(code)
        result = locale.format_day(date, gmt_offset, dow)
        assert result == expected
    _test("en_US", datetime.datetime(2015, 1, 1), 0, True, "Thursday, January 1")
    _test("en_US", datetime.datetime(2015, 1, 1), 0, False, "January 1")

# Generated at 2022-06-12 13:36:51.797059
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    '''
    Method to test if format_day of class Locale works.
    '''
    assert Locale.get("pt_BR").format_day(
        datetime.datetime(2019, 3, 4, 15, 0, 20), 0) == "Segunda, Março 4"


# Generated at 2022-06-12 13:37:02.386667
# Unit test for function load_translations
def test_load_translations():
    # load file for test
    import os
    import os.path
    import tempfile
    # create a test file
    with tempfile.TemporaryDirectory() as folder:
        file = os.path.join(folder, "translate.csv")
        fd = open(file, "w")
        fd.write("en_US,en_US,en\n")
        fd.write("de_DE,de_DE,de\n")
        fd.write("fr_FR,fr_FR,fr\n")
        fd.write("it_IT,it_IT,it\n")
        fd.write("es_ES,es_ES,es\n")
        fd.write("zh_CN,zh_CN,zh\n")
        fd.close()
        # testing

# Generated at 2022-06-12 13:37:44.420009
# Unit test for method list of class Locale
def test_Locale_list():
    # Locale.list test
    assert Locale.get_closest('en_US').list(['A', 'B', 'C']) == 'A, B and C'
    assert Locale.get_closest('es_ES').list(['A', 'B', 'C']) == 'A y B, C'
    assert Locale.get_closest('en_US').list(['A', 'B']) == 'A and B'
    assert Locale.get_closest('en_US').list(['A']) == 'A'
    assert Locale.get_closest('en_US').list([]) == ''
    assert Locale.get_closest('fa_IR').list(['A', 'B', 'C']) == 'A \u0648 B, C'

# Generated at 2022-06-12 13:37:47.872139
# Unit test for function load_translations
def test_load_translations():
    file = r"I:\开发工具\PyCharm\自学\tornado-5.1.1\tornado\test\test_locale.csv"
    load_translations(file)
    print(_translations)



# Generated at 2022-06-12 13:37:49.707847
# Unit test for function load_translations
def test_load_translations():
    pass
    #load_translations('.', encoding = "utf-8")


# Generated at 2022-06-12 13:37:57.147993
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get('fa')
    from datetime import datetime

    input_date = datetime.strptime('Mon, 29 Aug 2016', '%a, %d %b %Y')

    output_date = locale.format_day(input_date)
    assert output_date == 'یک‌شنبه, اوت 2016'

    output_date = locale.format_day(input_date, dow=False)
    assert output_date == 'اوت 2016'



# Generated at 2022-06-12 13:37:58.982289
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("ar").list(["A", "B", "C"]) == "A، B، و C"

# Generated at 2022-06-12 13:38:00.279582
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_Locale = Locale.get("es")
    assert test_Locale.friendly_number(1) == "1"


# Generated at 2022-06-12 13:38:03.034710
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert(Locale.get("en").friendly_number(10) == "10")
    assert(Locale.get("en").friendly_number(10000) == "10,000")



# Generated at 2022-06-12 13:38:11.375229
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l = Locale.get("en")
    assert l.friendly_number(0) == "0"
    assert l.friendly_number(1) == "1"
    assert l.friendly_number(12) == "12"
    assert l.friendly_number(123) == "123"
    assert l.friendly_number(1234) == "1,234"
    assert l.friendly_number(12345) == "12,345"
    assert l.friendly_number(123456) == "123,456"
    assert l.friendly_number(1234567) == "1,234,567"
    assert l.friendly_number(12345678) == "12,345,678"
    assert l.friendly_number(123456789) == "123,456,789"

# Generated at 2022-06-12 13:38:20.936853
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    date = datetime.datetime(2020,9,23,12,22)

    def test_format_date_with_args(format_args, expected_result):
        result = Locale('en_US').format_date(date, **format_args)
        assert result == expected_result

    test_format_date_with_args({}, "Yesterday at 12:22 PM")
    test_format_date_with_args({"gmt_offset": 1}, "Yesterday at 12:22 PM")
    test_format_date_with_args({"relative": False}, "September 23, 2020 at 12:22 PM")
    test_format_date_with_args({"full_format": True}, "September 23, 2020 at 12:22 PM")

# Generated at 2022-06-12 13:38:29.340286
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    def run_test(test_case, expected_result, error_test_name=None):
        if expected_result != str(test_case):
            msg = "Unexpected result for test case format_date in Locale for input {0}.".format(
                test_case)
            if error_test_name is not None:
                msg = "{0} {1}".format(msg, error_test_name)
            raise Exception(msg)

    # Test for English
    # First, we set the global variable language to en_US so that we can use en_US
    # to retrieve the correct Locale
    language = "en_US"
    # Setup
    locale = Locale.get(language)
    # Test cases
    # One second ago
    input_date = datetime.datetime.utcnow() - datetime

# Generated at 2022-06-12 13:39:01.588048
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(17000) == '17,000'
    assert Locale.get("en_US").friendly_number(17000) == '17,000'
    assert Locale.get("it").friendly_number(17000) == '17000'



# Generated at 2022-06-12 13:39:07.780801
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from tornado.util import bytes_type
    from tornado.util import unicode_type
    locale = Locale.get("en_US")

    import datetime
    import time

    # Check relative dates
    now = datetime.datetime.utcnow()
    assert locale.format_date(now, relative=True) == "1 second ago"
    assert locale.format_date(now - datetime.timedelta(seconds=2), relative=True) == "2 seconds ago"
    assert locale.format_date(now - datetime.timedelta(seconds=30), relative=True) == "30 seconds ago"
    assert locale.format_date(now - datetime.timedelta(minutes=1), relative=True) == "1 minute ago"

# Generated at 2022-06-12 13:39:16.640233
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import unittest
    from unittest import mock
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import gen_test
    from tornado.web import Application
    import os
    import json
    import locale
    import datetime
    import logging
    import tornado.ioloop
    import tornado.httpserver
    import tornado.web
    import tornado.escape
    import base64
    try:
        import mock  # type: ignore
    except ImportError:
        from unittest import mock  # type: ignore
    import gen.locale

    # reset class Locale to default value
    Locale._cache = {}
    _translations = {}
    _supported_locales = {}
    _use_gettext = {}
    _default_locale = {}


# Generated at 2022-06-12 13:39:25.077459
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    """
    This method tests friendly_number method of Locale class
    """
    #First test case: input number is 123
    #Expected output: 123

    translated_number1 = Locale.get("ru").friendly_number(123)
    assert translated_number1 == "123", "The number did not translate correctly"
    #Second test case: input number is 1234567890
    #Expected output: 1,234,567,890

    translated_number2 = Locale.get("en").friendly_number(1234567890)
    assert translated_number2 == "1,234,567,890", "The number did not translate correctly"



# Generated at 2022-06-12 13:39:34.352392
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    def my_test(locale_code, today, expected_result):
        result = Locale.get(locale_code).format_day(today)
        assert result == expected_result, (
            "Expected %s, got %s" % (expected_result, result))
    for locale_code in LOCALE_NAMES.keys():
        if locale_code == 'zh_TW': locale_code = 'zh_Hant_TW'
        if locale_code == 'zh_CN': locale_code = 'zh_Hans_CN'
        today = datetime.datetime(year=2013, month=2, day=1)
        expected_result = "February 1"
        my_test(locale_code, today, expected_result)

# Generated at 2022-06-12 13:39:36.214380
# Unit test for function load_translations
def test_load_translations():
    load_translations('./test_locale_data')
    print(_translations)


# Generated at 2022-06-12 13:39:43.824120
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    for _ in ["en", "en_US", "es", "fr"]:
        print(_)
        _ = Locale.get(_)
        # Locale.pgettext(self, context, message, plural_message, count)
        #       -> str
        print(_.pgettext())
        print(_.pgettext(context=None))
        print(_.pgettext(context=""))
        print(_.pgettext(context="foo"))
        print(_.pgettext(context="foo", message=None))
        print(_.pgettext(context="foo", message=""))
        print(_.pgettext(context="foo", message="foo"))
        print(_.pgettext(context="foo", message="foo", plural_message=None))

# Generated at 2022-06-12 13:39:52.582352
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/lingyuan/Desktop/cs239/tornado-master/tornado/locale")
    print(_translations)
if __name__ == '__main__':
    test_load_translations()

# precompile some regexes
_variable_re = re.compile(r"%\(([^\)]*)\)s")
_plural_re = re.compile(r"%\(([^\)]*)\)s")
_punctuation_re = re.compile(r"(?:^|\s)([\.,;:])(?:\s|$)")
_punctuation_str = ",;:."



# Generated at 2022-06-12 13:39:59.874569
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    global _translations
    global _supported_locales
    global _default_locale
    global _use_gettext
    # Set up
    code = 'en_US'
    context = 'racing'
    message = 'done'
    plural_message = 'done'
    count = 1
    expected = 'done'
    _default_locale = 'en_US'
    _use_gettext = False
    _translations = {'en_US': {'unknown': {'done': 'done'}}}
    _supported_locales = frozenset(list(_translations.keys()) + [_default_locale])
    gen_log.debug('Supported locales: %s', sorted(_supported_locales))
    assert isinstance(_translations, dict)
    assert code in _supported_locales

# Generated at 2022-06-12 13:40:09.835310
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    fr = Locale.get("fr")
    en = Locale.get("en_US")
    assert fr.friendly_number(1000000) == "1000000"
    assert en.friendly_number(1000000) == "1,000,000"
    assert fr.friendly_number(10000) == "10000"
    assert en.friendly_number(10000) == "10,000"
    assert fr.friendly_number(1200) == "1200"
    assert en.friendly_number(1200) == "1,200"
    assert fr.friendly_number(12) == "12"
    assert en.friendly_number(12) == "12"
    assert fr.friendly_number(1) == "1"
    assert en.friendly_number(1) == "1"
    assert fr.friendly_number(1000) == "1000"