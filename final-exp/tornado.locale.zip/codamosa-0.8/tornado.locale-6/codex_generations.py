

# Generated at 2022-06-12 13:31:32.913694
# Unit test for constructor of class Locale
def test_Locale():
    base = 'russian'
    locale = Locale(base)
    assert locale.code == base


# Generated at 2022-06-12 13:31:35.943740
# Unit test for function load_translations
def test_load_translations():
    """Unit test for function load_translations
    """
    load_translations('static/translations')
    assert _translations!={}
    assert _supported_locales!=frozenset()


# Generated at 2022-06-12 13:31:47.049287
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    load_translations(os.path.join(os.path.dirname(__file__), "translations/"))
    from datetime import datetime

    def test_Locale_format_date_now():
        '''Test for Locale format_date with current time'''

        # FIXME(willkg): Test case for "at" not printed
        now = datetime.utcnow()
        for language in ["en", "zh_CN"]:
            locale = Locale.get(language)
            output = locale.format_date(now)
            assert output.startswith(
                "today"
            ), "Locale format_date: output should start with today"

    def test_Locale_format_date_yesterday():
        '''Test for Locale format_date with yesterday's time'''

        yesterday = datetime

# Generated at 2022-06-12 13:31:52.639004
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Valid test case
    date = datetime.datetime.strptime("2019-06-28", '%Y-%m-%d')
    locale = Locale.get(str(argv[1]))
    locale.format_day(date, 0, True)
    
    # Invalid test case
    date = datetime.datetime.strptime("2019-06-28", '%Y-%m-%d')
    locale = Locale.get(str(argv[2]))
    assert locale.format_day(date, 0, True) == 'Monday, June 28'


# Generated at 2022-06-12 13:31:57.143003
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    load_translations("test/locale_translations.csv")
    locale = Locale.get("ja")
    date = datetime.datetime(2016, 4, 1)
    assert locale.format_day(date, dow = True) == "木曜日, 4月 1日"
    assert locale.format_day(date, dow = False) == "4月 1日"

# Generated at 2022-06-12 13:32:05.239629
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # init the method TestCase class
    test_case = TestCase()
    # get the Locale
    en_US = Locale.get("en_US")
    # test date
    date = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
    # get the result and assert it
    result = en_US.format_date(date)
    test_case.assertEqual("1 second ago", result)
    # get the result and assert it
    date = datetime.datetime.utcnow() - datetime.timedelta(minutes=1)
    result = en_US.format_date(date)
    test_case.assertEqual("1 minute ago", result)
    # get the result and assert it

# Generated at 2022-06-12 13:32:07.573322
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert hasattr(load_gettext_translations, "__call__")
    load_gettext_translations('./', "gettext")



# Generated at 2022-06-12 13:32:15.295793
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    now_time = datetime.datetime.now(tz=pytz.utc)
    now_time_seconde = (now_time - datetime.timedelta(seconds=2)).timestamp()
    now_time_minute = (now_time - datetime.timedelta(minutes=2)).timestamp()
    now_time_hour = (now_time - datetime.timedelta(hours=2)).timestamp()
    now_time_day = (now_time - datetime.timedelta(days=2)).timestamp()
    now_time_month = (now_time - datetime.timedelta(days=62)).timestamp()
    now_time_year = (now_time - datetime.timedelta(days=366)).timestamp()

    assert Locale.get("zh_CN").format_

# Generated at 2022-06-12 13:32:19.015075
# Unit test for function load_translations
def test_load_translations():
    directory = "test_directory"
    csv_file = "test_file"
    open(csv_file, 'w').close()
    open(directory, 'w').close()
    load_translations(directory)



# Generated at 2022-06-12 13:32:24.777188
# Unit test for function load_translations
def test_load_translations():
    """
    .. versionchanged:: 4.0
    """
    target_path = os.path.join(os.path.dirname(__file__), 'test_locale')
    load_translations(target_path)
    assert 'en_US' in _translations
    assert _translations['en_US']['unknown']['Hello'] == 'Hello'
    assert _translations['en_US']['plural']['1 bottle'] == '%(num)s bottles'



# Generated at 2022-06-12 13:32:51.365642
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    def test_Locale_format_date():
        """Tests the format_date method of the Locale class."""
        import time
        # Test with the current local time
        local_time = time.time()
        local_time_struct = time.localtime(local_time)
        local_time_string = time.strftime("%Y-%m-%d %H:%M:%S", local_time_struct)
        gen_log.info("Testing format_date with local time: %s", local_time_string)
        for code in _supported_locales:
            gen_log.info("Formatting time for locale '%s'", code)
            locale = Locale.get(code)
            formatted_time = locale.format_date(local_time)

# Generated at 2022-06-12 13:32:52.471435
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("test/test_locale_data", "test_domain")

# Generated at 2022-06-12 13:32:59.281783
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    load_translations(pkg_resources.resource_filename(__name__, "test-translations"))
    fa = Locale.get("fa")
    assert fa.pgettext("test", "One") == "Ichi"
    assert fa.pgettext("test", "One", "Many", 1) == "Ichi"
    assert fa.pgettext("test", "One", "Many", 2) == "Ni"

# Generated at 2022-06-12 13:33:08.661799
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = r"D:\MyProjects\t1\tornado\locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    print(_translations)

translate = gettext.gettext
utranslate = gettext.ngettext
ugettext = gettext.gettext

# alias
get_closest = get

# These are the loose locales. These are locales that match
# the first part of the locale (e.g., "es" for "es_DO").
_loose_locales = {}  # type: Dict[str, str]
for locale in _translations:
    if locale.find("_") != -1:
        short_locale = locale.split("_")[0]

# Generated at 2022-06-12 13:33:19.365716
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """Unit test for method format_day of class Locale."""
    import os, sys
    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')))
    from zulip_bots.zulip_bots import Locale
    from datetime import datetime

    date = datetime(2019, 3, 23)

    expected = "Saturday, March 23"
    actual = Locale.get("en_US").format_day(date)
    assert actual == expected

    expected = "Sabato, marzo 23"
    actual = Locale.get("it").format_day(date)
    assert actual == expected

    expected = "23 de marzo de 2019"
    actual = Locale.get("es").format_day(date)

# Generated at 2022-06-12 13:33:29.978849
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    mon, tue, wed, thu, fri, sat, sun = 0, 1, 2, 3, 4, 5, 6

# Generated at 2022-06-12 13:33:39.055892
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    from . import i18n
    i18n.load_translations('/Users/xingwangcui/Documents/XD/code/platypus/platypus/translations/localization.csv', 'csv')
    assert i18n.Locale.get_closest('zh_CN').pgettext('context', 'keyword') == 'value'
    assert i18n.Locale.get_closest('zh_CN').pgettext('context', 'keyword', None, 1) == 'value1'
    assert i18n.Locale.get_closest('zh_CN').pgettext('context', 'keyword', None, 0) == 'value0'

# Generated at 2022-06-12 13:33:45.646213
# Unit test for method list of class Locale
def test_Locale_list():
    # test arabic
    ar_locale = Locale.get("ar")
    assert ar_locale.list(["A"]) == "A"
    assert ar_locale.list(["A", "B"]) == "A \u0648 B"
    assert ar_locale.list(["A", "B", "C"]) == "A, B \u0648 C"
    # test fa
    fa_locale = Locale.get("fa")
    assert fa_locale.list(["A"]) == "A"
    assert fa_locale.list(["A", "B"]) == "A \u0648 B"
    assert fa_locale.list(["A", "B", "C"]) == "A, B \u0648 C"
    # test en
    en_loc

# Generated at 2022-06-12 13:33:50.734578
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    l = Locale('en_US')
    d = datetime.datetime(2016, 12, 24)
    assert l.format_day(d, dow=False) == 'December 24'
    assert l.format_day(d, dow=True) == 'Saturday, December 24'


# Unit Test for method list of class Locale

# Generated at 2022-06-12 13:33:53.394063
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory = "../data")
    print(_translations)

# Generated at 2022-06-12 13:34:14.916838
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from dateutil.parser import parse
    from dateutil.tz import tzutc

    # define two dates for comparison
    date1 = parse('1996-01-09T16:00:00.000+00:00')
    date2 = parse('1996-01-10T16:00:00.000+00:00')
    date1 = date1.replace(tzinfo=tzutc())
    date2 = date2.replace(tzinfo=tzutc())

    # define a few locales to test with
    locales = [Locale('en_US'), Locale('ko_KR')]

    # get the result of format_date
    result1 = locales[0].format_day(date1, dow=True)
    result2 = locales[0].format_day(date2, dow=True)
    result

# Generated at 2022-06-12 13:34:18.136049
# Unit test for function load_translations
def test_load_translations():
    """
    Tests for load_translations:
        - working of the function.
        - whether the function raised an Exception or not.
    """
    try:
        load_translations("locale", "utf-8")
        assert True
    except:
        assert False



# Generated at 2022-06-12 13:34:24.852954
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Must run the following first:
    #   load_translations('testdata/locale/csv/')
    #   load_translations('testdata/locale/gettext/')
    import pytz
    tz = pytz.timezone("Asia/Seoul")
    now = datetime.datetime.now(tz)
    yesterday = now - datetime.timedelta(hours=24)
    last_year = now - datetime.timedelta(days=365)
    _ = Locale("ko_KR").translate

    assert _("%(time)s") % {"time": "11:59"} == "11:59"
    assert _("%(time)s") % {"time": "00:00"} == "00:00"


# Generated at 2022-06-12 13:34:34.837500
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # The default locale as English
    locale = Locale("en")
    # The default format is "at"
    assert locale.format_date(datetime.datetime(2018,12,18,23,34,56,27)) == "Dec 18, 2018 at 11:34 PM"
    # No matter if the date is earlier or later than the present time,
    # the format is the same except for the "at"
    assert locale.format_date(datetime.datetime(2018,12,18,23,34,56,27),full_format=True) == "Dec 18, 2018"
    assert locale.format_date(datetime.datetime(2019,12,18,23,34,56,27),full_format=True) == "Dec 18, 2019"
    # the relative formatting

# Generated at 2022-06-12 13:34:44.994316
# Unit test for function load_translations
def test_load_translations():
    import tempfile
    try:
        dirpath = tempfile.mkdtemp()
        encoding = "utf8"
        filename = "es_ES.csv"
        path = os.path.join(dirpath, filename)
        with open(path, "wb") as f:
            f.write(b'\xef\xbb\xbf"I love you","Te amo"')
        load_translations(dirpath)
        assert len(_translations) == 1
        assert _translations["es_ES"]["unknown"]["I love you"] == "Te amo"
    finally:
        import shutil
        shutil.rmtree(dirpath)



# Generated at 2022-06-12 13:34:53.719177
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # set short time format to be used for english
    #   to ensure consistent results
    import locale

    locale.setlocale(locale.LC_TIME, "en_US")
    # set gmt_offset to 0 to ensure consistent results
    gmt_offset = 0
    # test Locale.format_date() method
    #   by comparing the method results to expected results
    locale_code = 'en'
    locale = Locale(locale_code)
    # expected results for unix timestamps

# Generated at 2022-06-12 13:34:56.112545
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    string = "dog"
    string = "gato"
    context = "cat"
    print(pgettext(context, string ))
    

# Generated at 2022-06-12 13:35:03.965114
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale("de_DE")
    assert locale.format_day(datetime.datetime(2018, 11, 25)) == 'Sonntag, 25. November'
    assert locale.format_day(datetime.datetime(2018, 11, 25), dow=False) == '25. November'
    locale = Locale("en_US")
    assert locale.format_day(datetime.datetime(2018, 11, 25)) == 'Sunday, November 25'
    assert locale.format_day(datetime.datetime(2018, 11, 25), dow=False) == 'November 25'



# Generated at 2022-06-12 13:35:14.908561
# Unit test for function load_translations

# Generated at 2022-06-12 13:35:23.216711
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = 'C:/Users/涛哥/iCloudDrive/Documents/GitHub/Tornado/tornado'
    domain = 'py'
    global _translations
    global _supported_locales
    global _use_gettext
    _translations = {}
    for lang in os.listdir(directory):
        if lang.startswith("."):
            continue  # skip .svn, etc
        if os.path.isfile(os.path.join(directory, lang)):
            continue

# Generated at 2022-06-12 13:36:09.679446
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    def test_date_format(locale_code,
                         expected,
                         now,
                         date,
                         relative=True,
                         shorter=False,
                         full_format=False):
        locale = Locale.get(locale_code)
        assert locale is not None
        assert locale.format_date(date, relative=relative, shorter=shorter, full_format=full_format) == expected

    # Arrange
    now = datetime.datetime(2018, 7, 10, 16, 00, 0)
    date = datetime.datetime(2018, 7, 10, 15, 59, 0)

    assert test_date_format("en", "1 second ago", now, date,
                            relative=True, shorter=False, full_format=False)

# Generated at 2022-06-12 13:36:17.023519
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime.utcnow()
    # if you're running this test, you are more than likely on central time
    # and the program is not running on a server.  Adjust the timezone
    # accordingly:
    gmt_offset = -5
    locale = Locale.get_closest("en_US")
    locale.format_day(date, gmt_offset)
    assert locale.format_day(date, gmt_offset, dow=False) == "November 22"
    assert locale.format_day(date, gmt_offset) == "Friday, November 22"

# Generated at 2022-06-12 13:36:22.516590
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locales = {}
    for code in get_supported_locales():
        locales[code] = Locale.get(code)
    date = datetime.datetime(2019, 6, 17)
    assert(locales["en"].format_day(date) == "Monday, June 17")
    assert(locales["ru"].format_day(date) == "понедельник, 17 июня")
    assert(locales["en"].format_day(date, dow=False) == "June 17")
    assert(locales["ru"].format_day(date, dow=False) == "17 июня")
    assert(locales["pl"].format_day(date) == "poniedziałek, 17 czerwca")
   

# Generated at 2022-06-12 13:36:31.913048
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # set up
    import copy
    from stormpath.resources import Application
    from stormpath.resources.provider import Provider
    original_translations = copy.copy(_translations)
    _translations = {"en": {"unknown": {'This is an application.': 'this is an application.'}}}
    en_locale = Locale.get("en")
    application_translations = copy.copy(Application._translations)
    application_translations['en'] = {"unknown": {'This is an application.': 'this is an application.'}}
    application_translations['es'] = {"unknown": {'This is an application.': 'this is an application.'}}
    Application._translations = application_translations
    provider_translations = copy.copy(Provider._translations)

# Generated at 2022-06-12 13:36:36.660867
# Unit test for function load_translations
def test_load_translations():
    # dirname = os.path.dirname(__file__)
    # load_translations(os.path.join(dirname, "data", "locale"))
    assert _translations != {}
    return _translations != {}


# Generated at 2022-06-12 13:36:37.855997
# Unit test for function load_translations
def test_load_translations():
    """test load_translations function
    """
    load_translations(".")


# Generated at 2022-06-12 13:36:45.984760
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import time
    import unittest
    from datetime import datetime
    # set locale
    locale = "fa_IR"
    load_translations(LOCALE_PATH, locale)
    _locale = Locale.get(locale)
    # get day of week
    dow = datetime.today().weekday()
    # get day of month
    dom = datetime.today().day
    # get month of year
    moy = datetime.today().month
    # get year
    year = datetime.today().year
    # set UTC offset
    gmt_offset = 3.5 * 60
    # check dow=False
    result_dow_false = _locale.format_day(datetime.now(), gmt_offset, False)

# Generated at 2022-06-12 13:36:57.522729
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    l = Locale("en_US")
    print(l.format_day(datetime.datetime(2018, 1, 2), dow=True))
    print(l.format_day(datetime.datetime(2018, 1, 2), dow=False))
    
    print(l.format_day(datetime.datetime(2018, 2, 3), dow=True))
    print(l.format_day(datetime.datetime(2018, 2, 3), dow=False))
    
    print(l.format_day(datetime.datetime(2018, 3, 4), dow=True))
    print(l.format_day(datetime.datetime(2018, 3, 4), dow=False))

test_Locale_format_day()


# Generated at 2022-06-12 13:37:06.223944
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # before calling `load`
    assert _supported_locales == set()
    # These are dummy types, only to test the mocking
    # of the module's globals in the unit test.
    translations_type: Any = type(print)

    load_translations(os.path.dirname(__file__) + "/data/translations")
    # mocking globals
    _translations = {"es": {"unknown": {"Hola": "Hola", "Hello": "Óla"}}, "fr": {}}

    locale = Locale.get_closest("e", "fr", "es")
    assert locale.translate("Hello") == "Óla"

    assert locale.pgettext("hello", "Hello") == "Óla"
    assert locale.pgettext("hola", "Hello") == "Hola"

# Generated at 2022-06-12 13:37:13.197599
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale.get("en")
    print(locale.format_date(datetime.datetime(2016, 11, 3, 4, 25, 0)))
    print(locale.format_date(datetime.datetime(2016, 11, 3, 4, 26, 0)))
    print(locale.format_date(datetime.datetime(2016, 11, 3, 4, 26, 0), relative=False))
    print(locale.format_date(datetime.datetime(2016, 11, 3, 4, 26, 0), full_format=True))

# Generated at 2022-06-12 13:37:58.574463
# Unit test for function load_translations
def test_load_translations():
    # testing load_translations
    os.remove('/home/kbhatn/Documents/Phase1/tornado/tornado/_locale_data.py')
    translation = {}
    translation['test_locale_1'] = {}
    translation['test_locale_1']['unknown'] = {}
    translation['test_locale_1']['unknown']['one'] = 'first'
    translation['test_locale_1']['unknown']['two'] = 'second'
    translation['test_locale_1']['unknown']['three'] = 'third'
    translation['test_locale_2'] = {}
    translation['test_locale_2']['unknown'] = {}
    translation['test_locale_2']['unknown']['four'] = 'fourth'

# Generated at 2022-06-12 13:38:03.528697
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    trans = {
        "unknown": {
            "message": "unknown_message",
            "plural": "unknown_plural",
            "singular": "unknown_singular"
        },
        "plural": {
            "plural": "plural_plural"
        },
        "singular": {
            "singular": "singular_singular"
        }
    }
    locale = CSVLocale("test", trans)
    assert locale.translate("message") == "unknown_message"
    assert locale.translate("message", "plural") == "unknown_message"
    assert locale.translate("message", "plural", 1) == "unknown_message"
    assert locale.translate("message", "plural", 2) == "unknown_plural"

# Generated at 2022-06-12 13:38:11.762507
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    nb_tests_in_each_config = 2
    test_result = False
    # test with a integer value
    int_value=123456789
    now = datetime.datetime.now()
    result1 = Locale.get_closest("en-US").format_date(now)
    result2 = Locale.get_closest("en-US").format_date(int_value)
    if result1 == result2:
        test_result = True
    # test with a float value
    float_value=now.timestamp()
    result3 = Locale.get_closest("en-US").format_date(float_value)
    if result2 == result3:
        test_result = True
    # test with a datetime.datetime value
    result4 = Locale.get_

# Generated at 2022-06-12 13:38:16.420050
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    time = datetime.datetime(year=2020, month=1, day=9, hour=18, minute=30)
    assert Locale.get("en").format_day(time) == "Thursday, January 9"
    assert Locale.get("en").format_day(time, dow=False) == "January 9"


# Generated at 2022-06-12 13:38:25.524717
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # A list of tuples. The first element of each tuple is a date
    # and the second is the expected output.
    test_dates = [
        (
            datetime.datetime.utcnow() - datetime.timedelta(hours=2),
            "Today",
        ),
        (
            datetime.datetime.utcnow() - datetime.timedelta(days=1),
            "Yesterday",
        ),
        (datetime.datetime(2016, 1, 1, 0, 0, 0), "Friday, January 1"),
        (datetime.datetime(2016, 1, 2, 0, 0, 0), "Saturday, January 2"),
    ]

    for (d, e) in test_dates:
        print(Locale.get("en").format_day(d) == e)



# Generated at 2022-06-12 13:38:32.029135
# Unit test for function load_translations
def test_load_translations():
    import unittest
    #set_default_locale('en_US')
    test_file_name = 'test.csv'
    test_file = open(test_file_name,encoding='utf-8',mode='w',newline='')
    csv_writer = csv.writer(test_file)
    csv_writer.writerow(['key','value'])
    csv_writer.writerow(['key1','value1'])
    csv_writer.writerow(['key2','value2'])
    test_file.close()

    load_translations(os.getcwd())
    test_file_name = os.path.join(os.getcwd(),'test.csv')

# Generated at 2022-06-12 13:38:34.339354
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    test_translations = {"unknown": {"No Group": "Nenhum Grupo"}}
    test_locale = CSVLocale("pt_BR", test_translations)
    if test_locale.translate("No Group") != "Nenhum Grupo":
        raise AssertionError()

# Generated at 2022-06-12 13:38:36.454920
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # TODO: 'directory' should be file path and 'domain' should be string,
    # change assert to check if exception occured and if it was the right one
    assert load_gettext_translations(1,2) == Error



# Generated at 2022-06-12 13:38:47.053041
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import sys
    import gettext
    os.environ['LANGUAGE'] = 'zh_CN' #locale.getdefaultlocale()[0]
    # gettext.bindtextdomain(os.path.join(os.path.dirname(__file__), 'locale'))
    # gettext.textdomain(domain)
    # gettext.install(domain, os.path.join(os.path.dirname(__file__), 'locale'), unicode=True)
    t=gettext.translation('examples',os.path.join(os.path.dirname(__file__), 'locale'), languages=['zh_CN'])
    print(t.gettext('This is a translatable string.'))
    # sys.exit()

# Generated at 2022-06-12 13:38:53.183547
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    Locale.load_translations(os.path.join(os.path.dirname(__file__), "translations"))
    myLoc = Locale.get("fa_IR")
    now = datetime.datetime.now()
    print(myLoc.format_day(now,dow=False))
    print(myLoc.format_day(now))

if __name__ == '__main__':
    test_Locale_format_day()

# Generated at 2022-06-12 13:39:17.741068
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from collections import OrderedDict
    import inspect
    import re

    def get_local_date(date, gmt_offset=0):
        return date - datetime.timedelta(minutes=gmt_offset)

    format_day = Locale.get('fa').format_day
    assert(
        format_day(datetime(2019, 1, 1), gmt_offset=0, dow=True) ==
        '\u064a\u06a9\u0634\u0646\u0628\u0647, \u0698\u0627\u0646\u0648\u06cc\u0647 1'
    )

# Generated at 2022-06-12 13:39:24.486320
# Unit test for method list of class Locale
def test_Locale_list():
    # it should display a list of items in one line, with 'and' before the last item
    assert Locale('en_US').list(['A','B','C','D']) == 'A, B, C and D'
    assert Locale('en_US').list(['A','B','C']) == 'A, B and C'

    # it should display a single item without delimiters
    assert Locale('en_US').list(['A']) == 'A'


# Generated at 2022-06-12 13:39:25.049573
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    pass


# Generated at 2022-06-12 13:39:32.322470
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    import pytz
    # 'dow' == True, 'dow' == False
    for dow in [True, False]:
        # Case 1: No DST
        #     (GMT-06:00) Central Time (US & Canada)
        #     Encode: CST
        #     Decode: Central Standard Time
        current_datetime_1 = datetime(2019, 2, 4, 17, 24, 0, tzinfo=pytz.timezone('US/Central'))
        str_date = "Monday, February 4"
        if dow:
            assert(Locale('en_US').format_day(current_datetime_1) == str_date)

# Generated at 2022-06-12 13:39:35.021156
# Unit test for function load_translations
def test_load_translations():
    return load_translations('/home/hosein/tornado/locale/')



# Generated at 2022-06-12 13:39:35.566028
# Unit test for function load_translations
def test_load_translations():
    pass



# Generated at 2022-06-12 13:39:40.767693
# Unit test for method list of class Locale
def test_Locale_list():
    k1=Locale("ka")
    l1=k1.list("abc")
    l2=k1.list("ab")
    l3=k1.list("a")
    l4=k1.list("")
    if (l1=="abc" and l2=="ab" and l3=="a" and l4==""):
        print("Test for Locale list passed")
    else:
        print("Test for Locale list failed")

# Generated at 2022-06-12 13:39:42.170816
# Unit test for function load_translations
def test_load_translations():
    load_translations("test_load_translations")



# Generated at 2022-06-12 13:39:53.364100
# Unit test for method format_date of class Locale

# Generated at 2022-06-12 13:40:00.371154
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    date = datetime.datetime.fromtimestamp(1539772760)
    # date = datetime.datetime.now()
    date_str = date.strftime("%Y-%m-%d %H:%M:%S")
    print("date:", date_str)

    # Test static method get_closest
    locale = Locale.get_closest("zh-cn", "en", "en_US", "en_GB")
    print("locale.code:", locale.code)
    print("locale.name:", locale.name)
    print("locale.rtl:", locale.rtl)

    # Test method format_date
    date_str_format = locale.format_date(date)
    print("date_str_format:", date_str_format)



# Generated at 2022-06-12 13:40:21.128688
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import doctest
    doctest.testmod(optionflags=(doctest.IGNORE_EXCEPTION_DETAIL))

# Generated at 2022-06-12 13:40:29.906252
# Unit test for function load_translations
def test_load_translations():
    os.chdir('test/test_translations')
    load_translations('./', encoding=None)
    os.chdir('../..')
    assert(   _translations['en_US'] == {
                                          'plural': {
                                                     'goodbye': 'goodbye',
                                                     'hello': 'hello'
                                                    },
                                          'unknown': {
                                                      'this': 'this'
                                                      }
                                          }
          )

# Generated at 2022-06-12 13:40:38.351468
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # TODO: [PY3] remove this function
    import unittest

    class TestLocale(Locale):
        """Sub class of Locale for test"""

        def translate(self,message, plural_message=None, count=None):
            """Fakes the translation method"""
            return message

        def pgettext(self,context,message, plural_message=None, count=None):
            """Fakes the translation method"""
            # removes the context from message
            return re.sub("^" + context + "\04", "", message)

    class TestCase(unittest.TestCase):
        def test_locale(self):
            locale = TestLocale("fr")
            self.assertEqual(locale.pgettext("context","context\x04Service"), "Service")

    unittest.main()


# Generated at 2022-06-12 13:40:44.388355
# Unit test for function load_translations
def test_load_translations():
    test_cases = ['es_LA']
    for test_case in test_cases:
        data = '"'+test_case+'","Te amo"'
        with open('es.csv') as file:
            file.write(data)

        load_translations(directory='.', encoding='ANSI')
        assert len(_translations) > 0
