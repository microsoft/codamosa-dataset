

# Generated at 2022-06-12 13:31:37.477861
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    gettext.install("test")
    pgettext = GettextLocale("en_US", gettext.NullTranslations()).pgettext
    assert "right" == pgettext("law", "right")
    assert "right" == pgettext("good", "right")
    assert "club" == pgettext("organization", "club", "clubs", 1)
    assert "clubs" == pgettext("organization", "club", "clubs", 2)
    assert "club" == pgettext("stick", "club", "clubs", 1)
    assert "clubs" == pgettext("stick", "club", "clubs", 2)
gettext.install("locale")
default_locale = Locale.get(_default_locale)



# Generated at 2022-06-12 13:31:41.445828
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    l = Locale('en_US')
    ts = 1560873600
    l_date = l.format_day(date=datetime.datetime.utcfromtimestamp(ts), gmt_offset=0)
    assert l_date == 'Monday, June 3'


# Unit test method friendly_number of class Locale

# Generated at 2022-06-12 13:31:46.767387
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """Format a date"""

    # Set up
    date = datetime.datetime(year=2019, month=7, day=19)
    locale = Locale.get("fr")
    gmt_offset = 2
    dow = True

    # Exercise
    result = locale.format_day(date, gmt_offset, dow)
    # Verify
    should_be = "dimanche, juillet 19"
    assert result == should_be, "Got {}".format(result)

# Generated at 2022-06-12 13:31:50.047613
# Unit test for function load_translations
def test_load_translations():
    if __name__ == '__main__':
        load_translations('locale')
        print(get('zh_CN'))



# Generated at 2022-06-12 13:31:52.495517
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    try:
        load_gettext_translations("C:/Users/Vampire/Dropbox/Programming/Courses/Self-study/Tornado/tests/locale", "test")
    except Exception as e:
        print(repr(e))



# Generated at 2022-06-12 13:32:00.786685
# Unit test for function load_translations
def test_load_translations():
    directory = os.getcwd()
    encoding = "utf-8"
    path = "es_LA.csv"
    full_path = os.path.join(directory, path)
    set_default_locale("es_LA")
    if encoding is None:
            # Try to autodetect encoding based on the BOM.
            with open(full_path, "rb") as bf:
                data = bf.read(len(codecs.BOM_UTF16_LE))
            if data in (codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE):
                encoding = "utf-16"

# Generated at 2022-06-12 13:32:07.185736
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    locale=CSVLocale("zh_CN",
        {"singular": {"hello": "world"}}
    )
    assert locale.translate("hello")=="world"
    assert locale.translate("Hello", "Hello")=="Hello"
    assert locale.translate("Hello", "Hello", 0)=="Hello"
    assert locale.translate("Hello", "Hello", 1)=="Hello"


# Generated at 2022-06-12 13:32:15.060740
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert "Monday, January 22" == Locale.get("en_US").format_day(
        datetime.datetime(2018, 1, 22, 0, 0, 0)
    )
    assert "Monday, January 22" == Locale.get("en").format_day(
        datetime.datetime(2018, 1, 22, 0, 0, 0)
    )
    assert "January 22" == Locale.get("en_US").format_day(
        datetime.datetime(2018, 1, 22, 0, 0, 0), dow=False
    )
    assert "January 22" == Locale.get("en").format_day(
        datetime.datetime(2018, 1, 22, 0, 0, 0), dow=False
    )

# Generated at 2022-06-12 13:32:20.300023
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get('ja_JP').format_day(datetime.datetime(2018, 10, 13), 0, dow=True) == '土曜日, 10月13日'
    assert Locale.get('ja_JP').format_day(datetime.datetime(2018, 10, 13), 0, dow=False) == '10月13日'
    assert Locale.get('fr_FR').format_day(datetime.datetime(2018, 10, 13), 0, dow=True) == 'samedi, 13 octobre'
    assert Locale.get('fr_FR').format_day(datetime.datetime(2018, 10, 13), 0, dow=False) == '13 octobre'

# Generated at 2022-06-12 13:32:23.356475
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    if _translations['zh_CN'] is None:
        assert load_gettext_translations('/locale/', 'mydomain') is None
    else:
        assert _translations['zh_CN'] is not None



# Generated at 2022-06-12 13:33:33.446456
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    locale = GettextLocale("test", gettext.NullTranslations())
    assert locale.pgettext("test", "test") == "test"
    def _check(
        locale: GettextLocale,
        context: str,
        message: str,
        plural_message: Optional[str] = None,
        count: Optional[int] = None,
    ) -> None:
        result = locale.pgettext(context, message, plural_message, count)
        if count is None:
            assert result == message
        elif plural_message is None:
            assert result == message
        else:
            assert result == message if count == 1 else plural_message
    _check(locale, "context", "test", "tests", 1)
    _check(locale, "context", "test", "tests", 2)
   

# Generated at 2022-06-12 13:33:42.606783
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import sys
    import pytest

    def _translate(msg: str, _: Optional[str], __: Optional[int]) -> str:
        return msg

    def _pgettext(c: str, m: str) -> str:
        return m

    def test_empty_context() -> None:
        l = Locale("en")
        l._translate = _translate
        l._pgettext = _pgettext
        assert "foo" == l.pgettext("", "foo")

    def test_normal_context() -> None:
        l = Locale("en")
        l._translate = _translate
        l._pgettext = _pgettext
        assert "foo" == l.pgettext("test", "foo")

    def test_space_context() -> None:
        l = Loc

# Generated at 2022-06-12 13:33:44.981989
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    L = Locale("en")
    assert L.format_day(datetime.datetime(2015, 12, 31), dow=False) == "December 31"


# Generated at 2022-06-12 13:33:49.531493
# Unit test for function load_translations

# Generated at 2022-06-12 13:33:53.187675
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    #sample values for directory and domain
    load_gettext_translations("/usr/share/locale","tornado")
#Unit test for function gettext_translations

# Generated at 2022-06-12 13:33:59.514387
# Unit test for function load_translations
def test_load_translations():
    """
    The function creates a temporary directory and a file.

    Creates a file with the extension ".csv"

    The function load_translations() is called with the path created before.

    The function test if the load_translations loaded well the translate.

    The file is deleted after the test.
    """
    import tempfile
    import os
    import shutil
    import subprocess
    from tornado.util import bytes_type
    from tornado.log import app_log

    test_name = "test_load_translations.csv"
    test_data = b'I love you,Te amo\n"%(name)s liked this","A %(name)s le gust\xc3\xb3 esto","singular"'

    locale_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 13:34:02.342847
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("zh_CN")
    d = datetime.datetime(2018, 7, 29)
    assert d.weekday() == 6
    assert locale.format_day(d) == u"星期日, 七月 29"

# Generated at 2022-06-12 13:34:11.957603
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    '''
    Get some examples for testing
    '''
    import csv
    csv_rows = []
    csvfile = open('test_Locale_format_day.csv')
    reader = csv.reader(csvfile)
    for row in reader:  # 注意表头
        csv_rows.append(row)
    csvfile.close()
    '''
    Run test
    '''
    verbose = 0
    for row in csv_rows:
        lang = row[0]
        date = row[1]
        dow = int(row[2])
        result = row[3]
        if verbose:
            print('Try: ', date, dow)
            print('Expect: ', result)

# Generated at 2022-06-12 13:34:19.435486
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    Locale.get('en').format_day(datetime.datetime(2017, 3, 2))
    # 'Thursday, March 2'
    Locale.get('fr').format_day(datetime.datetime(2017, 3, 2))
    # 'Jeudi 2 mars'
    Locale.get('zh_CN').format_day(datetime.datetime(2017, 3, 2))
    # '2017年3月2日，星期四'
    Locale.get('en').format_day(datetime.datetime(2017, 3, 2), dow=False)
    # 'March 2'
    Locale.get('fr').format_day(datetime.datetime(2017, 3, 2), dow=False)
    # '2 mars'

# Generated at 2022-06-12 13:34:26.914806
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    code = "en"
    translations = {
        "plural": {
            u"Hello!": u"Hello!",
            u"How are you?": u"How are you?"
        }
    }
    csv_locale=CSVLocale(code, translations)
    assert csv_locale.translate(u"Hello!", count=1)==u"Hello!"
    assert csv_locale.translate(u"How are you?", count=2)==u"How are you?"



# Generated at 2022-06-12 13:35:03.697628
# Unit test for method format_date of class Locale
def test_Locale_format_date():

    load_translations(os.path.join(os.path.dirname(__file__), "locale"))
    en = Locale.get("en")
    assert (
        en.format_date(datetime.datetime(2009, 1, 6, 10, 30, 0, 0))
        == "1/6/2009 at 10:30am"
    )
    assert en.format_date(datetime.datetime(2010, 1, 6, 10, 30, 0, 0)) == "1/6/2010"
    assert en.format_date(
        datetime.datetime(2010, 1, 6, 10, 30, 0, 0), full_format=True
    ) == "January 6, 2010 at 10:30am"

    fr = Locale.get("fr")

# Generated at 2022-06-12 13:35:05.404433
# Unit test for constructor of class Locale
def test_Locale():
    "Unit test for constructor of class Locale"
    assert Locale.get("fr")



# Generated at 2022-06-12 13:35:16.527417
# Unit test for method format_day of class Locale

# Generated at 2022-06-12 13:35:22.757487
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    ml = Locale.get("en")
    assert ml.friendly_number(1) == "1"
    assert ml.friendly_number(1000) == "1,000"
    assert ml.friendly_number(1234567) == "1,234,567"
    # Non-English locales return a non-separated number
    l = Locale.get("ja")
    assert l.friendly_number(1) == "1"
    assert l.friendly_number(1000) == "1000"
    assert l.friendly_number(1234567) == "1234567"


# Generated at 2022-06-12 13:35:27.083779
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    t = load_gettext_translations("../locale", "test")    # ../locale/zh_CN/LC_MESSAGES/test.mo
    print("Supported locales:", sorted(t))

test_load_gettext_translations()




# Generated at 2022-06-12 13:35:38.297374
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for Locale format_date(date, gmt_offset, relative, shorter, full_format)
    print("Method format_date for class Locale")
    print(" testing for Locale.format_date()")
    assert (Locale.get_closest('fa').format_date(datetime.datetime(2015, 5, 14, 20, 45, 0, 0))) == '14 مرداد 1394 در 8:45 ق.ظ'
    assert (Locale.get_closest('en').format_date(datetime.datetime(2015, 5, 14, 20, 45, 0, 0))) == 'May 14, 2015 at 8:45pm'

# Generated at 2022-06-12 13:35:42.273171
# Unit test for function load_translations
def test_load_translations():
    load_translations('locale')
    for locale in _translations:
        for type in _translations[locale]:
            for english in _translations[locale][type]:
                print(english.strip(),_translations[locale][type][english].strip())
test_load_translations()



# Generated at 2022-06-12 13:35:52.766691
# Unit test for function load_translations
def test_load_translations():
    import tornado.testing
    import tornado.web
    import tornado.wsgi
    import os, csv
    import json

    class TranslateHandler(tornado.web.RequestHandler):
        def get(self, path):
            #TODO: set translations to the handler
            #TODO: translate the page
            pass

        def post(self, path):
            #TODO: set translations to the handler
            #TODO: check the translation
            pass


    class TestTranslations(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            #TODO: make sure that the translations are loaded
            return tornado.web.Application([
                (r"/([^/]+)", TranslateHandler),
            ])


# Generated at 2022-06-12 13:36:01.090731
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime.fromtimestamp(1539071118)
    dow_first = Locale("en").format_day(date)
    assert dow_first == "Sunday, October 21"

    dow_not_first = Locale("en").format_day(date, dow=False)
    assert dow_not_first == "October 21"

    dow_not_first_zhcn = Locale("zh_CN").format_day(date, dow=False)
    assert dow_not_first_zhcn == "\u670821\u65e5"

    

# Generated at 2022-06-12 13:36:11.944758
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    now = datetime.datetime.utcnow()
    d = now - datetime.timedelta(seconds=5)
    assert Locale.get("en_US").format_date(d) == "1 second ago"
    d = now - datetime.timedelta(seconds=50)
    assert Locale.get("en_US").format_date(d) == "1 minute ago"
    d = now - datetime.timedelta(minutes=5)
    assert Locale.get("en_US").format_date(d) == "5 minutes ago"
    d = now - datetime.timedelta(minutes=55)
    assert Locale.get("en_US").format_date(d) == "55 minutes ago"
    d = now - datetime.timedelta(hours=1)

# Generated at 2022-06-12 13:36:44.941862
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    """Unit test for function load_gettext_translations"""
    load_gettext_translations(os.path.dirname(__file__),"locale")
    assert _translations["en"].domain=="locale"
    assert _translations["en"].dirname.split("/")[-2]=="locale"
    assert _translations["en"].language=="en"
    assert _translations["en"].codeset=="UTF-8"


# Generated at 2022-06-12 13:36:56.115872
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale('en').friendly_number(0) == '0'
    assert Locale('en').friendly_number(1) == '1'
    assert Locale('en').friendly_number(10) == '10'
    assert Locale('en').friendly_number(100) == '100'
    assert Locale('en').friendly_number(1000) == '1,000'
    assert Locale('en').friendly_number(10000) == '10,000'
    assert Locale('en').friendly_number(100000) == '100,000'
    assert Locale('en').friendly_number(1000000) == '1,000,000'
    assert Locale('en').friendly_number(10000000) == '10,000,000'

# Generated at 2022-06-12 13:37:01.439482
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    """
    Test for 'pgettext' method of class GettextLocale.
    """
    _lang = "fa"

# Generated at 2022-06-12 13:37:05.414612
# Unit test for function load_translations
def test_load_translations():
    print("=====Begin Unit test for function load_translations=====")
    load_translations("/home/ec2-user/workspace/tornadoProjects/tornado-4.5.2/tornado/locale")
    #print("_translations = ", _translations)
    print("=====End Unit test for function load_translations=====")



# Generated at 2022-06-12 13:37:07.188707
# Unit test for function load_translations
def test_load_translations():
    get("jp")
    assert get("jp").translate("Sign Out") == "アカウントをログアウト"


# Generated at 2022-06-12 13:37:09.614350
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    #message=_("cannot load translation for '%s': %s")
    assert load_gettext_translations==load_gettext_translations


# Generated at 2022-06-12 13:37:20.754699
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
        self = GettextLocale('en_US', gettext.NullTranslations())
        test_gettext_translations = {"organization": {"club": "club"}, 
        "stick": {"club": "club"}}
        self.ngettext = translations.ngettext
        self.gettext = translations.gettext
        self.gettext = test_gettext_translations.gettext
        self.ngettext = test_gettext_translations.ngettext
        clubs = [1, 2, 3]
        self.pgettext('organization', 'club', 'clubs', len(clubs))
        self.pgettext('stick', 'club', 'clubs', len(clubs))
        self.ngettext('organization', 'club', 'clubs', len(clubs))

# Generated at 2022-06-12 13:37:23.730896
# Unit test for function load_translations
def test_load_translations():
    set_supported_locales(["es_LA"])
    import os
    path = os.path.join(os.path.dirname(__file__), "test", "resources", "i18n")
    load_translations(path)



# Generated at 2022-06-12 13:37:33.014488
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # test relative dates
    current_time = datetime.datetime.utcnow()
    # test dates within one second
    instant = current_time - datetime.timedelta(seconds=1)
    v = loc.format_date(instant)
    assert v == "1 second ago"
    # test dates within one minute
    instant = current_time - datetime.timedelta(seconds=30)
    v = loc.format_date(instant)
    assert v == "1 minute ago"
    # test dates within one hour
    instant = current_time - datetime.timedelta(minutes=30)
    v = loc.format_date(instant)
    assert v == "1 hour ago"
    # test dates within one day
    instant = current_time - datetime.timedelta(hours=12)

# Generated at 2022-06-12 13:37:38.479065
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    now = datetime.utcnow()
    for locale in get_supported_locales():
        if locale == "en_US":
            continue
        gen_log.info('Testing "%s" date format: %s',
                     locale, Locale.get(locale).format_date(now))


# Generated at 2022-06-12 13:38:12.333414
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    dict = load_gettext_translations(directory = "/home/peppyleo/project/tornado/locale/", domain = "tornado.messages")



# Generated at 2022-06-12 13:38:22.233066
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from itertools import product

    print("Test Locale.format_day")
    print("----------------------")

    # Fixture
    locale_codes = ['en', 'en_us', 'nl']
    # When you execute this script directly, `date` is the day of the execution
    date = datetime.now()
    gmt_offsets = [0, 60*3] # 30 minutes * (3 hours)
    dow_values = [True, False]
    
    # Carthesian product of multiple parameters
    carthesian_product = product(locale_codes, [date], gmt_offsets, dow_values)

    # Template for text to print
    result = "{locale_code}, {dow}, {gmt_offset}, {date} => {output}"

# Generated at 2022-06-12 13:38:23.042072
# Unit test for function load_translations
def test_load_translations():
    result = load_translations(directory = "path", encoding = "utf-8")


# Generated at 2022-06-12 13:38:30.551315
# Unit test for function load_translations
def test_load_translations():
    from tornado.test.util import unittest
    import tempfile
    import shutil
    directory = tempfile.mkdtemp()

# Generated at 2022-06-12 13:38:32.212829
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    arr = ["a", "b", "c", "d", "e"]
    objLocale = Locale("en")
    str_transitions = objLocale.list(arr)
    print(str_transitions)

# Generated at 2022-06-12 13:38:32.795380
# Unit test for function load_translations
def test_load_translations():
    load_translations('../../locale')


# Generated at 2022-06-12 13:38:36.144275
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    print(
        """The function is to load translations from gettext's locale tree."""
    )
    print(
        """The unit test for the function is to print the supported locales after loading these translations."""
    )
    print("-----The output is:------")
    domain = "tornado"
    directory = "..\\tornado\\_locale_data"
    load_gettext_translations(directory, domain)



# Generated at 2022-06-12 13:38:46.756343
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    import pytest
    from zerver.lib.test_classes import ZulipTestCase

    class TestLocale(ZulipTestCase):
        def test_Locale(self):
            # Make sure method friendly_number
            # returns the expected output
            locale = Locale("en")
            assert locale.friendly_number(1) == "1"
            locale = Locale("en_US")
            assert locale.friendly_number(1) == "1"
            assert locale.friendly_number(12) == "12"
            assert locale.friendly_number(123) == "123"
            assert locale.friendly_number(1234) == "1,234"
            assert locale.friendly_number(12345) == "12,345"
            assert locale.friendly_number(123456) == "123,456"

# Generated at 2022-06-12 13:38:51.124596
# Unit test for function load_translations
def test_load_translations():
    """ This function will test load_translations
    """
    import tornado
    path = r"C:\Users\Administrator\Desktop\tornado-6.0.3\tornado\locale"
    set_default_locale("en_US")
    load_translations(path)


# Generated at 2022-06-12 13:38:53.358386
# Unit test for function load_translations
def test_load_translations():
    try:
        load_translations("../locale_data")
        print("load_translations passed")
    except FileNotFoundError as e:
        raise e

# Generated at 2022-06-12 13:39:33.614334
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # This test is from tornado_system_code.py, too.
    # Both this and tornado's test should be changed if CSVLocale.translate is changed.
    translations = {}
    translations["unknown"] = {}
    translations["unknown"]["Message"] = "Translated Message"
    translations["unknown"]["Message with %(param)s"] = "Translated Message with %(param)s"

    translations["plural"] = {}
    translations["plural"]["One thing"] = "One translated thing"
    translations["plural"]["%(num)d things"] = "%(num)d translated things"

    translations["singular"] = {}
    translations["singular"]["One thing"] = "One translated thing"
    translations["singular"]["%(num)d things"] = "%(num)d translated things"

# Generated at 2022-06-12 13:39:42.243104
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Arrange
    for l in ["fr", "en", "es", "ru", "tr"]:
        _locale = Locale.get(l)
        # Assert
        assert _locale.pgettext(None, "Hello World") == _locale.translate(
            "Hello World"
        )
        # Assert
        assert _locale.pgettext("Junk", "Hello World") == _locale.translate(
            "Junk|Hello World"
        )
        # Assert
        assert _locale.pgettext(
            "Junk", "Hello World", plural_message="Hello Worlds"
        ) == _locale.translate("Junk|Hello World", plural_message="Junk|Hello Worlds")
        # Assert

# Generated at 2022-06-12 13:39:44.853882
# Unit test for function load_translations
def test_load_translations():
    # Change the following directory to the one for the file
    directory = '.'
    load_translations(directory)



# Generated at 2022-06-12 13:39:50.446447
# Unit test for function load_translations
def test_load_translations():
    test_directory = "./translations"
    load_translations(test_directory)
    assert(len(_translations.keys()) == 4)
    assert("en_US" in _translations.keys())
    assert("fr_FR" in _translations.keys())
    assert("pt_BR" in _translations.keys())
    assert("es_GT" in _translations.keys())



# Generated at 2022-06-12 13:39:54.003843
# Unit test for function load_translations
def test_load_translations():
    directory = "./translation"
    encoding = "utf-8"
    load_translations(directory, encoding)
    #print(list(_translations.values())[0])
    print(list(_translations.keys()))
    print(_supported_locales)


# Generated at 2022-06-12 13:40:05.661216
# Unit test for function load_translations
def test_load_translations():
    load_translations("test_data")
    assert _translations["es_MX"]["plural"]["test string"] == "prueba de cuerda"
    assert _translations["es_MX"]["singular"]["%(name)s liked this"] == "a %(name)s le gustó esto"
    assert _translations["es_MX"]["singular"]["%(name)s liked this"] == "A %(name)s le gustó esto"
    assert _translations["es_MX"]["plural"]["%(name)s liked this"] == "A %(name)s les gustó esto"
    assert len(list(_translations.keys())) == 1
    assert _supported_locales == frozenset(['es_MX'])
    assert _

# Generated at 2022-06-12 13:40:10.326836
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert not _translations
    assert not _use_gettext
    load_gettext_translations("../locale", "test")
    assert len(_translations) == 1
    assert _use_gettext
    assert _translations["en_US"]
    assert _translations["en_US"].merge == gettext._translations["en"].merge


# Generated at 2022-06-12 13:40:12.321722
# Unit test for function load_translations
def test_load_translations():
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
test_load_translations()



# Generated at 2022-06-12 13:40:13.815393
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/kalpana/Projects/Tornado/tornado/locale")



# Generated at 2022-06-12 13:40:15.310881
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(".","messages")
    print("download _translations:", _translations)
