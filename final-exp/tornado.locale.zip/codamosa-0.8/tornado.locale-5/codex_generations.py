

# Generated at 2022-06-12 13:32:12.909921
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    current_path = os.path.dirname(os.path.abspath(__file__))
    load_gettext_translations(current_path, 'test-domain')
    en_translation = _translations['en']
    assert en_translation is not None
    assert en_translation.gettext('test translation') == 'test translation'
    assert en_translation.gettext('_test translation') == 'test translation'
    assert en_translation.gettext('_test translation_') == 'test translation'
    assert en_translation.gettext('__test translation') == '_test translation'
    assert en_translation.gettext('__test translation__') == '_test translation'
    
    fr_translation = _translations['fr']
    assert fr_translation is not None

# Generated at 2022-06-12 13:32:14.504208
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert load_gettext_translations('.', 'mydomain') == None



# Generated at 2022-06-12 13:32:24.551702
# Unit test for function load_translations
def test_load_translations():
    set_default_locale("zh_CN")
    # Load the translation from csv file
    load_translations("..")
    # Get the class instance for zh_CN
    zh_CN = get("zh_CN")
    # Translate the "Bye" in English to Chinese
    assert(zh_CN.translate("Bye") == "再见")
    # Translate the "Hello %s !" in English to Chinese
    assert(zh_CN.translate("Hello %s !")%("Alpha") == "你好 Alpha !")
    assert(zh_CN.translate("Hello %s !")%("Beta") == "你好 Beta !")
    # If a translation is not found, it's returned as is

# Generated at 2022-06-12 13:32:28.432542
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    trans_dict = {"weekday": "lundi",
                  "day": "21",
                  "month_name": "février"}
    date = datetime.datetime(2019, 2, 21)
    l = Locale("fr")
    l.translate = lambda s: s % trans_dict
    assert l.format_day(date, dow=True) == "lundi, février 21"
    assert l.format_day(date, dow=False) == "février 21"


# Generated at 2022-06-12 13:32:39.332301
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    with mock.patch.dict("os.environ", {"LOCALE_OVERRIDE":"en"}):
        print("en")
        en = Locale.get("en")
        # _ = en.translate("test")
        print("format_date(1558892171)")
        print(en.format_date(1558892171)) # 2019-05-26 18:16:11
        print("format_date(1558892771)")
        print(en.format_date(1558892771)) # 2019-05-26 18:16:11
        print("format_date(1558892772)")
        print(en.format_date(1558892772)) # 2019-05-26 18:16:11
        print("format_date(1558892773)")

# Generated at 2022-06-12 13:32:49.377656
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """Test the method Locale.format_day()"""
    date_list = [
        datetime(2017, 2, 1, 0, 0, 0),
        datetime(2014, 3, 4, 0, 0, 0),
        datetime(2014, 3, 4, 1, 0, 0),
        datetime(2014, 3, 4, 13, 0, 0),
        datetime(2016, 12, 25, 0, 0, 0),
        datetime(2016, 12, 25, 23, 59, 59),
        datetime(2016, 12, 25, 1, 0, 0),
        datetime(2016, 12, 25, 13, 0, 0),
        datetime(2016, 12, 25, 23, 0, 0)
    ]

# Generated at 2022-06-12 13:32:57.413493
# Unit test for function load_translations
def test_load_translations():
    from tornado.testing import AsyncHTTPTestCase
    import unittest
    import glob
    import io
    import shutil
    import tempfile
    import os.path

    # Use a temporary directory to avoid polluting the source dir
    # with translations.
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-12 13:33:03.277314
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    locale = CSVLocale('fa', {'plural': {'a': 'aa', 'b': 'bb'}})
    assert locale.translate('a', count=2) == 'aa'
    assert locale.translate('b', count=1) == 'bb'


# Generated at 2022-06-12 13:33:10.879220
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    @classmethod
    def translate(
        cls,
        message: str,
        plural_message: Optional[str] = None,
        count: Optional[int] = None,
    ) -> str:
        if plural_message is None:
            return message
        if count == 1:
            return message
        else:
            return plural_message
    Locale.translate = translate
    locale_obj = Locale.get('en')
    print('test_Locale_format_date: ', locale_obj.format_date('01/01/2020 00:00:00'))

test_Locale_format_date()



# Generated at 2022-06-12 13:33:12.908576
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/a/Public/tornado/tests/locale")


# Generated at 2022-06-12 13:33:39.702301
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale("en_US").list(["A"]) == "A"
    assert Locale("en_US").list(["A", "B"]) == "A and B"
    assert Locale("en_US").list(["A","B","C"]) == "A, B and C"



# Generated at 2022-06-12 13:33:43.914082
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime 
    locale = Locale("de")
    date = datetime(day=22, month=1, year=2019)
    assert locale.format_day(date) == "Mittwoch, Januar 22"
    date = datetime(day=19, month=12, year=2018)
    assert locale.format_day(date) == "Freitag, Dezember 19"

# Test code for method list of class Locale

# Generated at 2022-06-12 13:33:44.934602
# Unit test for function load_translations
def test_load_translations():
    load_translations("locale/")


# Generated at 2022-06-12 13:33:55.714633
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    real_datetime = datetime.datetime
    datetime_now = real_datetime(2010, 2, 24, 2, 1, 2, 0)

    class DatetimeMock(datetime.datetime):
        @classmethod
        def utcnow(cls):
            return datetime_now

    datetime.datetime = DatetimeMock
    format_date = Locale.get("en").format_date

    # Future
    assert format_date(datetime.datetime(2010, 2, 24, 2, 1, 2, 0)) == "0 seconds ago"
    assert format_date(datetime.datetime(2010, 2, 24, 2, 1, 3, 0)) == "1 second ago"

# Generated at 2022-06-12 13:34:04.174876
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    translate = CSVLocale.translate
    l = CSVLocale(code="en", translations={"unknown": {"haha": "haha"}})
    assert l.translate("haha") == "haha"
    assert l.translate("hehe") == "hehe"
    l = CSVLocale(
        code="en", translations={"unknown": {"haha": "haha"}, "plural": {"hehe": "hehes"}}
    )
    assert l.translate("hehe", "hehes", 2) == "hehes"
    assert l.translate("hehe", "hehes", 1) == "hehe"



# Generated at 2022-06-12 13:34:13.622859
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    now = datetime.datetime.utcnow().replace(tzinfo=utc)

# Generated at 2022-06-12 13:34:16.812785
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    o = Locale("en_US")
    o.translate = gen_mock_func()
    o.pgettext("msgctxt", "msgid")
    o.translate.assert_called_with("msgid", None, None)


# Generated at 2022-06-12 13:34:24.078694
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    '''
    post: Returns an string of the date given with the format: 'weekday, month day', for example, Monday, January 22
    '''
    date = datetime.datetime(2002, 1, 22)
    assert Locale.get('pt_BR').format_day(date) == "segunda-feira, janeiro 22"
    assert Locale.get('en').format_day(date) == "Monday, January 22"
    assert Locale.get('zh_CN').format_day(date) == "星期一, 一月 22"
    assert Locale.get('zh_TW').format_day(date) == "星期一, 1月 22"

# Generated at 2022-06-12 13:34:32.230240
# Unit test for function load_translations
def test_load_translations():
    test_i18n_data_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "data", "i18n"
    )
    load_translations(test_i18n_data_dir)
    print(_supported_locales)
    # assert _supported_locales is
    # assert _translations is
    print(_translations)
    # _translations = {}
    # _supported_locales = frozenset(list(_translations.keys()) + [_default_locale])



# Generated at 2022-06-12 13:34:32.803400
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert "test"



# Generated at 2022-06-12 13:35:16.258536
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """
    Tests the Locale.format_date method:
    """
    # Set up
    locale = Locale(code='en')
    locale.code = 'en'

    # Test
    # Case 1 - Relative date.
    # In this case, the result should be a relative date.
    # Input parameters:
    #   date: datetime.datetime
    #   gmt_offset: int
    #   relative: bool
    #   shorter: bool
    #   full_format: bool
    # Expected result: str
    date = datetime.datetime.utcfromtimestamp(time.time())
    gmt_offset = 0
    relative = True
    shorter = True
    full_format = True
    expected = None

# Generated at 2022-06-12 13:35:23.933953
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import sys
    import os

    sys.path.insert(0, os.path.dirname(__file__))
    try:
        import gen_map
    finally:
        del sys.path[0]

    gen_map.load_translations("../gen/locale/")

    assert gen_map.Locale(gen_map.Locale.get("en")).pgettext("context", "message") == "message"
    assert gen_map.Locale(gen_map.Locale.get("th")).pgettext("context", "message") == "message"
    assert gen_map.Locale(gen_map.Locale.get("de")).pgettext("context", "message") == "message"
    assert gen_map.Locale(gen_map.Locale.get("pt_BR")).p

# Generated at 2022-06-12 13:35:26.142278
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
        assert Locale("en").friendly_number(1000) == "1,000"

# Generated at 2022-06-12 13:35:27.966190
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/home/xu/locale','tornado-i18n')



# Generated at 2022-06-12 13:35:39.070603
# Unit test for function load_translations
def test_load_translations():
    import tornado
    import os
    import sys
    import tempfile
    s = '"I love you","Te amo"\n"%(name)s liked this","A %(name)s les gustó esto","plural"\n"%(name)s liked this","A %(name)s le gustó esto","singular"\n'
    with tempfile.NamedTemporaryFile(mode="w+t", suffix=".csv", delete=False) as f:
        f.write(s)
    path_file = f.name
    print(path_file)
    load_translations(path_file)
    test_locale = get("es_LA")
    a = test_locale.translate("I love you")
    assert a == "Te amo"
    print(a)
    os

# Generated at 2022-06-12 13:35:49.616851
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    def testdate(date, gmt_offset):
        return t.format_day(
            datetime.datetime(date[0], date[1], date[2]),gmt_offset
        )
    t = Locale.get("en")
    assert testdate((2020,1,1),0) == 'Wednesday, January 1'
    assert testdate((2020,1,1),1) == 'Wednesday, January 1'
    assert testdate((2020,1,1),-1) == 'Wednesday, January 1'
    t = Locale.get("zh-CN")
    assert testdate((2020,1,1),0) == '1月1日星期三'
    assert testdate((2020,1,1),1) == '1月1日星期三'

# Generated at 2022-06-12 13:35:57.876375
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    class ISOString(str):
        def __init__(self, s):
            self.s = s

    class Locale(object):
        def __init__(self):
            pass

        def translate(self, s):
            return ISOString(s)

    assert_equal(
        Locale().format_date(datetime.datetime(1980, 7, 10, 0, 0, 0, 0)),
        u"July 10, 1980",
    )

    assert_equal(
        Locale().format_date(datetime.datetime(1980, 7, 10, 14, 23, 0, 0)),
        u"2:23 PM",
    )

# Generated at 2022-06-12 13:36:03.597856
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    class _MockLocale(Locale):
        def translate(self, message, plural_message=None, count=None):
            return ""

    locale = _MockLocale("en")
    now = datetime.datetime(2017, 1, 5, 9, 0, 0)
    assert locale.format_date(now, relative=True) == "yesterday"
    assert locale.format_date(now, relative=False) == "January 4, 2017 at 9:00am"

    now = datetime.datetime(2017, 1, 5, 9, 59, 0)
    assert locale.format_date(now, relative=True) == "1 minute ago"
    assert locale.format_date(now, relative=False) == "January 5, 2017 at 9:59am"


# Generated at 2022-06-12 13:36:08.217965
# Unit test for function load_translations
def test_load_translations():
    set_default_locale("en_US")
    load_translations(
        directory='..\\locale',
        encoding=None
    )
    locale = get(
        "en_US"
    )
    print(locale.translate(
        "Sign in"
    ))



# Generated at 2022-06-12 13:36:17.689467
# Unit test for function load_translations
def test_load_translations():
    directory = 'locale'
    encoding = None
    _translations = {}
    for path in os.listdir(directory):
        if not path.endswith(".csv"):
            continue
        locale, extension = path.split(".")
        if not re.match("[a-z]+(_[A-Z]+)?$", locale):
            gen_log.error(
                "Unrecognized locale %r (path: %s)",
                locale,
                os.path.join(directory, path),
            )
            continue
        full_path = os.path.join(directory, path)

# Generated at 2022-06-12 13:36:54.448560
# Unit test for function load_translations
def test_load_translations():
    global _translations
    _translations = {}
    import sys
    import pathlib
    path = pathlib.Path(__file__).parent.parent
    directory = path / "translations"
    sys.path.append(path)
    load_translations(directory)
    assert len(_translations.keys()) != 0



# Generated at 2022-06-12 13:37:04.685666
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Unit tests for Locale.format_day
    assert "Friday, November 22" == Locale.get("en_US").format_day(
        datetime.datetime(2013, 11, 22), 0, dow=True
    )
    assert "Friday, November 22" == Locale.get("en").format_day(
        datetime.datetime(2013, 11, 22), 0, dow=True
    )
    assert "1392/05/01" == Locale.get("fa").format_day(
        datetime.datetime(2013, 11, 22), 0, dow=False
    )
    assert "1392/05/01" == Locale.get("fa").format_day(
        datetime.datetime(2013, 11, 22), 0, dow=True
    )
    assert "2013/11/22"

# Generated at 2022-06-12 13:37:06.722221
# Unit test for function load_translations
def test_load_translations():
    load_translations("../test/testdata/csvtest/test.csv")
    print(_translations)
    print(_supported_locales)



# Generated at 2022-06-12 13:37:13.014521
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Arrange
    test_pgettext = translation.Locale.pgettext
    test_translate = translation.Locale.translate
    context = ""
    message = ""
    plural_message = ""
    count = 0
    result = ""
    try:
        # Arrange
        test_pgettext(context, message, plural_message, count)
    except NotImplementedError:
        # Assert
        assert True
    else:
        # Assert
        assert False



# Generated at 2022-06-12 13:37:16.098328
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/s56s/Develop/s56s_apps/tornadoweb/tests/translate')
    pass



# Generated at 2022-06-12 13:37:25.419902
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # pre-condition is that we have a supported locale (en_US or en)
    # GIVEN a Locale object representing a locale
    locale = Locale('en_US')
    locale.format_day(datetime.datetime(2017, 1, 4), dow=True) == 'Wednesday, January 04'
    locale.format_day(datetime.datetime(2017, 1, 4), dow=False) == 'January 04'
    locale.format_day(datetime.datetime(2017, 1, 5), dow=True) == 'Thursday, January 05'
    locale.format_day(datetime.datetime(2017, 1, 5), dow=False) == 'January 05'
    locale.format_day(datetime.datetime(2017, 1, 6), dow=True) == 'Friday, January 06'
    locale.format

# Generated at 2022-06-12 13:37:34.266500
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    import sys
    from types import ModuleType
    from io import StringIO
    mod = sys.modules[__name__]
    fake_stdout = StringIO()
    mod.gen_log = type(
        "Logger",
        (object,),
        {"debug": lambda msg, *args: print(msg % args, file=fake_stdout)},
    )
    mod.load_translations = lambda *args: None

    Locale.get_closest = lambda *args: Locale.get(args[0])

    english_us = Locale.get("en_US")
    english_us.friendly_number(1234)
    assert fake_stdout.getvalue() == "1,234"

    fake_stdout.truncate(0)
    german = Locale.get("de")
   

# Generated at 2022-06-12 13:37:42.583637
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("fa").format_day(datetime.datetime(2017, 12, 12)) == 'یکشنبه، دسامبر 12'
    assert Locale.get("fa").format_day(datetime.datetime(2017, 12, 12), dow=False) == 'دسامبر 12'
    assert Locale.get("en_US").format_day(datetime.datetime(2017, 12, 12)) == 'Tuesday, December 12'
    assert Locale.get("en_US").format_day(datetime.datetime(2017, 12, 12), dow=False) == 'December 12'


# Generated at 2022-06-12 13:37:49.942722
# Unit test for function load_translations
def test_load_translations():
    directory = "pt.csv"
    encoding = None
    _translations = {}
    for path in os.listdir(directory):
        if not path.endswith(".csv"):
            continue
        locale, extension = path.split(".")
        if not re.match("[a-z]+(_[A-Z]+)?$", locale):
            gen_log.error(
                "Unrecognized locale %r (path: %s)",
                locale,
                os.path.join(directory, path),
            )
            continue
        full_path = os.path.join(directory, path)

# Generated at 2022-06-12 13:37:57.722047
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    print("test start")
    a = Locale('zh_CN')
    date = datetime.datetime(2019, 10, 10)
    ret = a.format_day(date, 0, False)
    print(ret)
    date = datetime.datetime(2019, 10, 10)
    ret = a.format_day(date, 0, True)
    print(ret)
    date = datetime.datetime(2019, 1, 1)
    ret = a.format_day(date, 0, True)
    print(ret)
    print("test end")

# Generated at 2022-06-12 13:38:46.010403
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    with app.app_context():
        loc = Locale.get("zh_CN")
        date = datetime.datetime(2018, 8, 24)
        print(loc.format_day(date))

        loc = Locale.get("en")
        print(loc.format_day(date))

# Generated at 2022-06-12 13:38:56.481820
# Unit test for function load_translations
def test_load_translations():
    import os
    import shutil
    import tempfile
    import unittest

    from tornado._locale_data import LOCALE_NAMES

    from tornado.escape import to_unicode
    from tornado.testing import AsyncTestCase, LogTrapTestCase, main

    class LocaleTranslationsTest(AsyncTestCase, LogTrapTestCase):

        def setUp(self):
            super(LocaleTranslationsTest, self).setUp()
            self.data_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.data_dir)
            self.locales = os.listdir(os.path.join(os.path.dirname(__file__),
                                                   "locale_data"))


# Generated at 2022-06-12 13:39:04.692775
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    day = datetime.datetime(2018,8,15,0,0,0)
    test_gmt_offset = 0
    test_dow = True
    test_dow = False

# Generated at 2022-06-12 13:39:11.258310
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime(2017, 12, 17)
    assert Locale("en").format_day(date) == "Sunday, December 17"
    assert Locale("en").format_day(date, dow = False) == "December 17"
    assert Locale("fr").format_day(date) == "dimanche, décembre 17"
    assert Locale("fr").format_day(date, dow = False) == "décembre 17"

# Generated at 2022-06-12 13:39:15.077784
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    ta = Locale.get("ta")
    assert ta.format_day(datetime.datetime(2019, 8, 1)) == "2019-௮-01"
    assert ta.format_day(datetime.datetime(2019, 1, 1)) == "2019-01-01"


# Generated at 2022-06-12 13:39:25.115427
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import unittest
    import datetime

    class TestLocale(unittest.TestCase):
        def setUp(self):
            self.locale = Locale.get("en_US")  # type: Locale
            self.locale_msec = Locale.get("en_US")  # type: Locale

        def test_format_date_with_msec(self):
            test_date_time = datetime.datetime(2018, 5, 22, 12, 40, 50, 354000)
            self.assertEqual(
                self.locale.format_date(test_date_time), "12:40 PM"
            )


# Generated at 2022-06-12 13:39:32.384375
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime.utcnow()
    utc_offset = [0, -600, -800]
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    locales = ['en', 'en_US', 'zh']
    for utc in utc_offset:
        for locale in locales:
            locale = Locale.get(locale)
            for day in days:
                d = datetime.datetime(year=2016, month=9, day=20, hour=0, minute=0)
                while d.strftime("%A") != day:
                    d += datetime.timedelta(days=1)
                ret1 = locale.format_day(d, utc, dow=True)

# Generated at 2022-06-12 13:39:41.811900
# Unit test for method format_day of class Locale
def test_Locale_format_day():

    def format_day(locale_code, date, gmt_offset):
        return Locale.get(locale_code).format_day(date, gmt_offset)

    # Test a locale with a timezone in which the given date is not in DST
    # (so, the gmt_offset is not affected by DST)
    assert format_day('en', datetime(2020, 2, 24), 0) == 'Monday, February 24'
    assert format_day('en', datetime(2020, 2, 24), 60) == 'Monday, February 24'
    assert format_day('en', datetime(2020, 2, 24), -60) == 'Monday, February 24'
    assert format_day('en', datetime(2020, 2, 24), -120) == 'Sunday, February 23'

    # Test a locale with a time

# Generated at 2022-06-12 13:39:50.011938
# Unit test for method list of class Locale
def test_Locale_list():
    for i in range(4):
        for j in range(4):
            for k in range(4):
                for l in range(4):
                    lst = ["a"]*i + ["b"]*j + ["c"]*k + ["d"]*l
                    t = Locale("en_US").list(lst)
                    assert t == "a, b, c, and d"
Locale.list(["a", "b", "c", "d"])

Locale.friendly_number(100)


# Generated at 2022-06-12 13:39:55.461443
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    """Unit test for ``Locale.pgettext``"""
    import gettext
    from unittest import mock
    from pytest import raises

    _translations = {"en_US": gettext.NullTranslations()}

    with mock.patch("cherrypy._cpcompat.translate", new=None), raises(NotImplementedError):
        Locale.get("en_US").pgettext("", "Test context")



# Generated at 2022-06-12 13:40:32.295096
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # time in seconds
    now = int(time.time())
    s = Locale('en').format_date(now)
    assert s == '1 second ago'
    s = Locale('en').format_date(now-1)
    assert s == '1 second ago'
    s = Locale('en').format_date(now-2)
    assert s == '2 seconds ago'
    s = Locale('en').format_date(now-59)
    assert s == '59 seconds ago'
    s = Locale('en').format_date(now-61)
    assert s == '1 minute ago'
    s = Locale('en').format_date(now-60*2)
    assert s == '2 minutes ago'
    s = Locale('en').format_date(now-60*60*1)


# Generated at 2022-06-12 13:40:35.072889
# Unit test for function load_translations
def test_load_translations():
    dir = "C:/Users/makara/PycharmProjects/easy-line/test_translations"
    load_translations(dir)
    assert len(_translations) > 0



# Generated at 2022-06-12 13:40:46.271966
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    import unittest
    locale = Locale.get("en")
    test_cases = [(datetime.datetime(2017, 3, 27), 0, True),
                  (datetime.datetime(2017, 3, 27), 0, False),
                  (datetime.datetime(2017, 3, 27), -8, True),
                  (datetime.datetime(2017, 3, 27), -8, False),
                  (datetime.datetime(2017, 3, 27), 8, True),
                  (datetime.datetime(2017, 3, 27), 8, False),
                  (datetime.datetime(2016, 1, 5), 8, True),
                  (datetime.datetime(2016, 1, 5), 8, False)]