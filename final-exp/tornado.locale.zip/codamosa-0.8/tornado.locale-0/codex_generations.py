

# Generated at 2022-06-12 13:31:41.372863
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    _translations = {
        "en": {
            "__context__": {
                "trans_key": "contextual_value"
            }
        }
    }

    class test_Locale(Locale):
        def translate(self, message, plural_message=None, count=None):
            return message

        def pgettext(self, context, message, plural_message=None, count=None):
            if message in _translations["en"]["__context__"]:
                return _translations["en"]["__context__"][message]
            return message

    assert test_Locale("en").pgettext("", "trans_key") == "contextual_value"
    assert test_Locale("en").pgettext("", "trans_value") == "trans_value"

# Generated at 2022-06-12 13:31:45.674809
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    Locale.load_translations("/home/yupeng/Documents/meep/restaurant/style/locale")
    locale = Locale.get_closest("en")
    assert locale.format_day(datetime.datetime(2018, 2, 1)) == "Thursday, February 1"
# Test for method format_date in class Locale

# Generated at 2022-06-12 13:31:50.251452
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Load test data
    locale_data = load_test_data("format_day.json")
    # Test
    for case in locale_data["testcases"]:
        # Use the GMT offset from test data
        date = datetime.datetime.strptime(case["date"], "%Y-%m-%d %H:%M:%S")
        gmt_offset = int(case["gmt_offset"])
        # Call the method
        result = Locale.get(case["locale"]).format_day(date, gmt_offset)
        # Check the result

# Generated at 2022-06-12 13:31:55.365879
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale("en")
    date = datetime.datetime(2020,2,4,7,9,10)
    gmt_offset = -420
    dow = True
    assert (locale.format_day(date, gmt_offset, dow)) == "Tuesday, February 4"
    dow = False
    assert (locale.format_day(date, gmt_offset, dow)) == "February 4"

# Generated at 2022-06-12 13:32:01.790002
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    def _pgettext(context, message, values=None):
        if values is not None:
            message = message % values
        return message

    context = "test user"
    message = "test message"
    values = {"name": message}

    obj = Locale('cs')
    obj._pgettext = _pgettext
    assert "test message" == obj.pgettext(context, message, **values)



# Generated at 2022-06-12 13:32:10.443435
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_data = ((('en', 1234), '1,234'), (('en', 0), '0'), (('en', 12), '12'), (('zh_CN', 1234), '1234'), (('zh_CN', 0), '0'), (('zh_CN', 12), '12'))
    for test_case in test_data:
        locale = Locale.get(test_case[0][0])
        result = locale.friendly_number(test_case[0][1])
        assert result == test_case[1]
        print(test_case, result)

# Generated at 2022-06-12 13:32:13.880815
# Unit test for function load_translations
def test_load_translations():
    directory = "D:\Documents\tornado_todo_app\tornado_todo_app"
    load_translations(directory)
    print(1)



# Generated at 2022-06-12 13:32:24.039971
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime

    trans_file_name = "translation.csv"
    gen_log.debug("Supported locales: %s", sorted(LOCALE_NAMES.keys()))
    load_translations(os.path.join("locale", trans_file_name), encoding="utf-8")
    gen_log.debug("Supported locales: %s", sorted(LOCALE_NAMES.keys()))

    locale = Locale(LOCALE_NAMES.keys()[0])
    locale.translate("January")
    locale.translate("February")
    locale.translate("March")
    locale.translate("April")
    locale.translate("May")
    locale.translate("June")
    locale.translate("July")
    locale.translate("August")
    locale.translate("September")

# Generated at 2022-06-12 13:32:29.489718
# Unit test for method format_date of class Locale

# Generated at 2022-06-12 13:32:32.050467
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    print(Locale.get("en").format_date(datetime.datetime.now()))
    print(Locale.get("en").format_date(datetime.datetime.now(),full_format=True))
    print(Locale.get("en").format_day(datetime.datetime.now()))



# Generated at 2022-06-12 13:34:09.358026
# Unit test for function load_translations
def test_load_translations():
    load_translations("/tmp/tornado_translation_test/")
    assert _translations == {'en_US': {'unknown': {'a': 'b'}},
                             'es_ES': {'plural': {'c': 'd'}},
                             'es_MX': {'singular': {'e': 'f'}}}
    assert _supported_locales == frozenset({'en_US', 'es_ES', 'es_MX'})



# Generated at 2022-06-12 13:34:17.686083
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale("en_US")
    assert locale.format_day(datetime.datetime(
        year=2015, month=1, day=1, hour=0, minute=0, second=0, microsecond=0)) == "Thursday, January 1"
    assert locale.format_day(datetime.datetime(
        year=2015, month=1, day=2, hour=0, minute=0, second=0, microsecond=0)) == "Friday, January 2"
    assert locale.format_day(datetime.datetime(
        year=2015, month=1, day=3, hour=0, minute=0, second=0, microsecond=0)) == "Saturday, January 3"

# Generated at 2022-06-12 13:34:21.055299
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    l = CSVLocale("en_US", None)
    assert l.translate("mello", "hollo", 5) == "hollo"
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-12 13:34:23.225051
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    l = Locale('fa')
    assert l.format_day(datetime.datetime(2019, 7, 28)) == 'روز جمعه، مهر 28'

# Generated at 2022-06-12 13:34:33.989658
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Tests for Locale.format_date with relative dates
    _ = Locale('en').translate
    assert Locale('en').format_date(datetime.datetime(2020, 1, 6, 12, 0, 0)) == _("yesterday at 12:00 PM")
    assert Locale('en').format_date(datetime.datetime(2020, 1, 6, 23, 0, 0)) == _("yesterday at 11:00 PM")
    assert Locale('en').format_date(datetime.datetime(2020, 1, 7, 00, 0, 0)) == _("yesterday at 12:00 AM")
    assert Locale('en').format_date(datetime.datetime(2020, 1, 7, 12, 0, 0)) == _("today at 12:00 PM")

# Generated at 2022-06-12 13:34:45.876951
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    assert Locale('zh_TW').format_date(datetime.datetime(2020, 9, 3)) == u'2020 \u5e74 9 \u6708 3 \u65e5'

    assert Locale('en').format_date(datetime.datetime(2020, 9, 3, 0, 0, 0)) == u'September 3, 2020'
    assert Locale('en').format_date(datetime.datetime(2020, 9, 3, 0, 0, 0), gmt_offset=480) == u'September 2, 2020'

    assert Locale('en').format_date(datetime.datetime(2020, 9, 3, 0, 0, 0), relative=False) == u'September 3, 2020'

# Generated at 2022-06-12 13:34:47.275912
# Unit test for function load_translations
def test_load_translations():
    assert load_translations("locale", "utf-8") == None



# Generated at 2022-06-12 13:34:54.897316
# Unit test for function load_translations
def test_load_translations():
    set_default_locale("en_US")
    load_translations("./")
    en_US = get("en_US")
    assert en_US.translate("Cheese") == "Cheese"
    es_LA = get("es_LA")
    assert es_LA.translate("Cheese") == "Queso"
    assert en_US.translate("%(name)s liked this", "plural",name = "Nhan") == "%(name)s liked this"
    assert en_US.translate("%(name)s liked this", "singular", name = "Nhan") == "%(name)s liked this"
    assert en_US.translate("%(name)s liked this", "unknown", name = "Nhan") == "%(name)s liked this"
    assert es_LA

# Generated at 2022-06-12 13:35:03.063388
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    i = 1234567890
    loc = Locale.get("en")
    assert loc.friendly_number(i) == "1,234,567,890"
    loc = Locale.get("en_US")
    assert loc.friendly_number(i) == "1,234,567,890"
    loc = Locale.get("ar")
    assert loc.friendly_number(i) == "1234567890"
    loc = Locale.get("pt_BR")
    assert loc.friendly_number(i) == "1234567890"
# End unit test for method friendly_number of class Locale



# Generated at 2022-06-12 13:35:04.717644
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/tmp/tornado-tests/locale/", "test")



# Generated at 2022-06-12 13:35:50.161379
# Unit test for function load_translations
def test_load_translations():
    load_translations("test/test.csv")



# Generated at 2022-06-12 13:35:56.456436
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/tpai/workspace/Python/tornado/locale")
    print(_translations)
    """
    {'en_US': {'unknown': {'Sign in': 'Sign in', 'Sign out': 'Sign out'}, 'singular': {}, 'plural': {}}, 'es_LA': {'unknown': {'Sign out': 'Cerrar sesión', 'Sign in': 'Iniciar sesión'}, 'singular': {}, 'plural': {}}}

    """
#test_load_translations()


# Generated at 2022-06-12 13:36:02.805461
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    gen_log.info("test_Locale_format_date")
    local_date = Locale.get("de") 
    print(local_date.format_date(datetime.datetime.utcnow()))
    print(local_date.format_date(datetime.datetime.utcnow() + datetime.timedelta(minutes=2)))


test_Locale_format_date()

# Generated at 2022-06-12 13:36:13.613787
# Unit test for function load_translations
def test_load_translations():
    import inspect
    import io
    import os
    import sys
    # create a file to read
    test_file = "en_GB.csv".encode()
    test_data = b"\"I love you\",\"Te amo\"\n"
    test_stream = io.BytesIO(test_data)
    # save original directory
    orig_dir = os.getcwd()
    # change current directory to this file
    os.chdir(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))))
    # create a stub for open() builtin

# Generated at 2022-06-12 13:36:20.079241
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timedelta
    from datetime import timezone
    current_day = datetime.utcnow()
    for time_increment in [1,15,30,60]:
        for locale_code in LOCALE_NAMES.keys():
            my_locale = Locale.get(locale_code)
            # increment the date by some time (to make the test more reliable)
            current_day = current_day + timedelta(days=time_increment)
            # reset the time to 0 to avoid time variations
            current_day = current_day.replace(hour=0,minute=0,second=0,microsecond=0)
            current_day_name = current_day.strftime("%A")

# Generated at 2022-06-12 13:36:21.022422
# Unit test for function load_translations
def test_load_translations():
    load_translations(".")
    return _translations


# Generated at 2022-06-12 13:36:26.389600
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test with context and message
    _translations = {'pt_BR': {'plural': {'%(name)s\'s friends': '%(name)s\'s amigos',
                                          '%(name)s\'s friend': '%(name)s\'s amigo'}}}
    locale = CSVLocale('pt_BR', _translations)
    assert locale.pgettext('friend', '%(name)s\'s friend', plural_message='%(name)s\'s friends') == "%(name)s's amigo"

    # Test with context, message and count
    assert locale.pgettext('friend', '%(name)s\'s friend',
                           plural_message='%(name)s\'s friends', count=3) == "%(name)s's amigos"

    # Test

# Generated at 2022-06-12 13:36:30.948009
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    locale = CSVLocale("test", {
        "singular": {
            "hello": "test",
            "bye": "test",
            "hi": "test"
        },
        "3": {
            "hello": "test",
            "bye": "test",
            "hi": "test"
        },
        "1": {
            "hello": "test",
            "bye": "test",
            "hi": "test"
        },
    })
    result = locale.translate("hello")
    assert (result == "test")
    result = locale.translate("bye", "test", 3)
    assert (result == "test")
    result = locale.translate("hi", "test", 1)
    assert (result == "test")
    result = locale.translate("hello", "test", 1)

# Generated at 2022-06-12 13:36:42.015454
# Unit test for method pgettext of class Locale

# Generated at 2022-06-12 13:36:44.624646
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    home_dir = os.path.abspath(os.path.dirname(__file__))
    load_gettext_translations(os.path.join(home_dir, '_translations'), "test_tornado")



# Generated at 2022-06-12 13:37:12.430100
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import pathlib
    import tempfile
    import gettext
    import tornado.locale
    import tornado.testing

    def mar_decode(s):
        return tornado.escape.native_str(s).decode("utf-8")
    source = pathlib.Path(__file__).parent
    domain = "tornado-test"
    po_path = source / "tornado-test.po"
    if not po_path.exists():
        gen_log.error("missing test file %s", po_path)
        return
    with tempfile.TemporaryDirectory() as tdir:
        for lang in ["pt_BR", "en"]:
            dest = pathlib.Path(tdir) / lang / "LC_MESSAGES"

# Generated at 2022-06-12 13:37:13.852348
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    """Unit test for method pgettext of class Locale"""
    assert True

# Generated at 2022-06-12 13:37:24.424264
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Testing for one test case
    # This test case is taken from the doc string of format_date method
    # This test case is valid and we should be able to pass it.
    # Case : Given date is in the past
    _ = get_closest("en", "ko")
    now = datetime.datetime.utcnow()
    date = now - datetime.timedelta(seconds=10)
    assert _.format_date(date,relative=True) == "10 seconds ago"
    assert _.format_date(date,relative=False) == "today at 12:00 AM"

    # Case : Testing full format
    date = now - datetime.timedelta(days=365)
    assert _.format_date(date,relative=True) == "June 4, 2020"

# Generated at 2022-06-12 13:37:33.523048
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # This function is designed to be called by another function. It uses
    # the path to the tornado module as it's __file__ attribute to find
    # the path to the i18n directory. That doesn't work with the python
    # module importer, so we have to fix it.
    original_path = __file__
    __file__ = os.path.abspath(os.path.join(original_path, "..", "..", ".."))
    load_gettext_translations(os.path.join(__file__, "i18n"), "tornado")
    assert "ja_JP" in _translations
    assert "fr_FR" in _translations
    assert "en_US" not in _translations
    assert "en" not in _translations
    __file__ = original_path



# Generated at 2022-06-12 13:37:35.826105
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "base")


# Generated at 2022-06-12 13:37:38.604274
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale('fa')
    t = datetime.datetime.now()
    print(locale.format_day(t, dow=False), locale.format_date(t), sep='\n')


# Generated at 2022-06-12 13:37:42.001965
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import pytest
    test_code = 'en'
    test_context = 'key'
    test_message = 'word'
    assert Locale.pgettext(test_code, test_context, test_message) == ''


# Generated at 2022-06-12 13:37:47.212654
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Arrange
    locale_code = "en"
    date = datetime.datetime.strptime("2017-01-19", "%Y-%m-%d")
    gmt_offset = 0
    dow = True
    expected = "Thursday, January 19"
    # Act
    locale = Locale.get(locale_code)
    actual = locale.format_day(date, gmt_offset, dow)
    # Assert
    assert actual == expected



# Generated at 2022-06-12 13:37:53.772102
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    now = datetime.datetime.utcnow()
    now_gmt = now.replace(now.year,now.month,now.day,now.hour,now.minute) #仅转化成GMT时间
    test_Locale = Locale('zh_CN')
    print(test_Locale.format_day(now_gmt, 0, dow = True))


# Generated at 2022-06-12 13:37:56.354535
# Unit test for function load_translations
def test_load_translations():
    '''
    test load function before used in tornado.web.Application
    '''
    load_translations(os.path.join(os.getcwd(),'locale'))
    print(get('en','en_US','en_UK'))
    print(get('cn','cn_CN','cn_TW'))



# Generated at 2022-06-12 13:38:16.059599
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    try:
        os.environ["STORM_LOCALE"] = "en"
        locale = Locale.get('en')
        assert locale.friendly_number(12345) == "12,345"
    finally:
        del os.environ["STORM_LOCALE"]



# Generated at 2022-06-12 13:38:25.253681
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale.get('en')
    assert locale.format_date(datetime.datetime.utcnow()) == 'less than 1 second ago'
    assert (locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=40)) == '40 seconds ago')
    assert (locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=60)) == '1 minute ago')
    assert (locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(seconds=1200)) == '20 minutes ago')
    assert (locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(minutes=60)) == '1 hour ago')

# Generated at 2022-06-12 13:38:31.785560
# Unit test for method list of class Locale
def test_Locale_list():
    arr = ["A", "B", "C"]
    assert Locale(code="fa").list(arr) == "A \u0648 B و C"
    assert Locale(code="ar").list(arr) == "A \u0648 B \u0648 C"
    assert Locale(code="en").list(arr) == "A, B and C"
    assert Locale(code="fr").list(arr) == "A, B et C"
    assert Locale(code="zh_CN").list(arr) == "A, B 和 C"

    arr = ["A", "B"]
    assert Locale(code="fa").list(arr) == "A \u0648 B"
    assert Locale(code="ar").list(arr) == "A \u0648 B"

# Generated at 2022-06-12 13:38:37.735982
# Unit test for method list of class Locale
def test_Locale_list():
    _ = Locale("en").translate
    assert _("%(commas)s and %(last)s") % {
        "commas": ", ".join(["A","B"]),
        "last": "C"
    } == "A, B and C"
    assert _("%(commas)s and %(last)s") % {
        "commas": "A",
        "last": "B"
    } == "A and B"
    assert _("%(commas)s and %(last)s") % {
        "commas": "A",
        "last": "A"
    } == "A"
    _ = Locale("fa").translate

# Generated at 2022-06-12 13:38:44.761283
# Unit test for function load_translations
def test_load_translations():
    loc_codes = ['en_US', 'es_LA']
    test_dir = '/test_load_translations'
    load_translations(test_dir)
    assert _translations == {}, " _translations must be empty until now"
    assert _supported_locales == frozenset(loc_codes), "supported locales are wrong"
    assert _default_locale == 'en_US', "default locale is wrong"





# Generated at 2022-06-12 13:38:55.518232
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import tornado
    import os
    import shutil
    import tempfile
    import gettext
    import inspect
    here = os.path.abspath(os.path.dirname(inspect.getsourcefile(tornado.locale)))

# Generated at 2022-06-12 13:38:59.133905
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    print("------test_load_gettext_translations-------")
    from test import test_locale
    test_locale.test_load_gettext_translations()
# test_load_gettext_translations()


# Generated at 2022-06-12 13:39:02.929852
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("zh_CN")
    date = datetime.datetime.strptime("2018-01-09", "%Y-%m-%d")
    assert locale.format_day(date) == "星期二, 一月 9"
    assert locale.format_day(date, dow=False) == "一月 9"


# Generated at 2022-06-12 13:39:09.282220
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # initialize the locale
    load_translations("." + os.path.sep + "i18n" + os.path.sep)
    loc = Locale.get("en_US")

    # set the current time
    curr_time = datetime.datetime.utcnow()

    # set the offset
    offset = 0

    # call the method to be tested
    value = loc.format_day(curr_time, offset)

    # verify the result
    assert value != None



# Generated at 2022-06-12 13:39:17.633996
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """
    Format date with Locale
    """
    try:
        import unittest2 as unittest  # type: ignore
    except ImportError:
        import unittest
    load_translations(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "..",
            "i18n",
            "csv",
        )
    )
    now = datetime.datetime.utcnow()
    en_US = Locale.get("en_US")
    es_ES = Locale.get("es_ES")

    def utc(dt):
        return datetime.datetime(dt.year, dt.month, dt.day, dt.hour, dt.minute)


# Generated at 2022-06-12 13:39:40.090774
# Unit test for function load_translations
def test_load_translations():
    pass



# Generated at 2022-06-12 13:39:43.475628
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale("en").format_day(
        datetime.datetime(2019, 2, 6),
        gmt_offset=0,
        dow=False,
    ) == "February 6"


# Generated at 2022-06-12 13:39:54.004477
# Unit test for function load_translations
def test_load_translations():
    import tempfile
    import os
    directory_path = tempfile.mkdtemp()
    #create dummy translation file
    file_name = 'test.csv'
    file_path = os.path.join(directory_path,file_name)
    with open(file_path,'w') as file:
        file.write("""\"I love you\",\"Te amo\"\n\"%(name)s liked this\",\"A %(name)s les gustó esto\",\"plural\"\n\"%(name)s liked this\",\"A %(name)s le gustó esto\",\"singular\"""")

# Generated at 2022-06-12 13:40:05.661505
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    global _default_locale
    global _translations
    global _supported_locales
    global _use_gettext
    set_default_locale("en_US")
    load_translations("/tmp")
    assert _default_locale == "en_US"
    assert _translations == {}
    assert _supported_locales == frozenset(["en_US"])
    assert _use_gettext == False
    load_gettext_translations(directory="/tmp/locale", domain="domain")
    assert _default_locale == "en_US"
    assert _supported_locales == frozenset(["en_US"])
    assert _use_gettext == True
    _default_locale = "en_US"
    _translations = {}

# Generated at 2022-06-12 13:40:14.168511
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    code = "en_US"
    dummy_arg1 = None
    dummy_arg2 = None
    dummy_arg3 = None

    class Locale(object):
        @classmethod
        def get_closest(cls, *locale_codes: str) -> object:
            raise NotImplementedError()

        @classmethod
        def get(cls, code: str) -> object:
            raise NotImplementedError()

        def __init__(self, code: str) -> None:
            self.code = code

    loc = Locale(code)
    assert loc.pgettext(dummy_arg1, dummy_arg2, dummy_arg3) == dummy_arg2

from abc import ABC, abstractmethod

# Generated at 2022-06-12 13:40:21.282717
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale.get_closest(locale_codes=['es_ES'])
    date = datetime.datetime(2019, 7, 3, 10, 32, 41, 481443)
    print(locale.format_date(date=date, gmt_offset=60, relative=True, shorter=True, full_format=True))
    print(locale.format_date(date=date, gmt_offset=60, relative=True, shorter=False, full_format=True))
    print(locale.format_date(date=date, gmt_offset=60, relative=True, shorter=True, full_format=False))
    print(locale.format_date(date=date, gmt_offset=60, relative=True, shorter=False, full_format=False))

# Generated at 2022-06-12 13:40:26.629585
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class GettextLocale1(GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations, **kwargs: Any) -> None:
            self.ngettext = translations.ngettext
            self.gettext = translations.gettext
            # self.gettext must exist before __init__ is called, since it
            # calls into self.translate
            super().__init__(code)

    test_code = 'test_code'

# Generated at 2022-06-12 13:40:33.570695
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    class LocaleSubclass(Locale):
        def format_date(self, date, gmt_offset=0,
                        relative=True, shorter=False, full_format=False):
            return str(date)

    _default_locale = "es"
    _supported_locales = frozenset(["es"])

# Generated at 2022-06-12 13:40:44.191930
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    """
    Load translations from not exist path and then check the supported locales.
    """
    load_gettext_translations("/not/exist", "mydomain")
    assert _supported_locales == frozenset([_default_locale]), "Load translations from not exist path should set supported locales to default locale"

    os.mkdir("/tmp/tornado/locale")
    os.mkdir("/tmp/tornado/locale/pt_BR")
    os.mkdir("/tmp/tornado/locale/pt_BR/LC_MESSAGES")