

# Generated at 2022-06-26 08:02:34.604779
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    str_0 = 'Escapes a string so it is valid within HTML or XML.\n\n    Escapes the characters ``<``, ``>``, ``"``, ``\'``, and ``&``.\n    When used in attribute values the escaped strings must be enclosed\n    in quotes.\n\n    .. versionchanged:: 3.2\n\n       Added the single quote to the list of escaped characters.\n    '
    load_translations(str_0)
    date = datetime.datetime(year = 2017, month = 10, day = 10, hour = 22, minute = 30)
    get_closest = Locale.get_closest(str_1 = 'en_US', str_2 = 'fr')
    format_date = get_closest.format_date(date = date)
    assert format

# Generated at 2022-06-26 08:02:47.694141
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    str_0 = 'Escapes a string so it is valid within HTML or XML.\n\n    Escapes the characters ``<``, ``>``, ``"``, ``\'``, and ``&``.\n    When used in attribute values the escaped strings must be enclosed\n    in quotes.\n\n    .. versionchanged:: 3.2\n\n       Added the single quote to the list of escaped characters.\n    '
    load_translations(str_0)
    c_1_0 = 'en'
    int_0 = 43
    obj_0 = get_closest(c_1_0)
    str_1 = obj_0.friendly_number(int_0)
    assert_true(str_1 == '43')


# Generated at 2022-06-26 08:02:51.565184
# Unit test for function load_translations
def test_load_translations():
    print('test_load_translations function')
    load_translations('/home/zheng/workspace/tornado_proj/tornado_server/tornado/locale')


# Generated at 2022-06-26 08:02:52.666235
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    test_case_0()


# Generated at 2022-06-26 08:02:54.998616
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
#     code = str_0
    code = 'ab'
    friendly_number_expect = '1'
    locale_0 = Locale.get(code)
    friendly_number_0 = locale_0.friendly_number(1)
    if friendly_number_expect != friendly_number_0:
        print('method friendly_number of class Locale faild.') 


# Generated at 2022-06-26 08:03:02.483038
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    str_0 = 'Escapes a string so it is valid within HTML or XML.\n\n    Escapes the characters ``<``, ``>``, ``"``, ``\'``, and ``&``.\n    When used in attribute values the escaped strings must be enclosed\n    in quotes.\n\n    .. versionchanged:: 3.2\n\n       Added the single quote to the list of escaped characters.\n    '
    load_gettext_translations(str_0,str_0)


# Generated at 2022-06-26 08:03:03.609877
# Unit test for function load_translations
def test_load_translations():
    test_case_0()



# Generated at 2022-06-26 08:03:15.555730
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    str_1 = 'Escapes a string so it is valid within HTML or XML.\n\n    Escapes the characters ``<``, ``>``, ``"``, ``\'``, and ``&``.\n    When used in attribute values the escaped strings must be enclosed\n    in quotes.\n\n    .. versionchanged:: 3.2\n\n       Added the single quote to the list of escaped characters.\n    '
    load_translations(str_1)

    # test case

# Generated at 2022-06-26 08:03:19.276573
# Unit test for function load_translations
def test_load_translations():
    print("Begin Unit Test for load_translations\n")
    test_case_0()
    print("End Unit Test for load_translations\n")


# Generated at 2022-06-26 08:03:20.344875
# Unit test for function load_translations
def test_load_translations():
    test_case_0()


# Generated at 2022-06-26 08:03:38.939315
# Unit test for function load_translations
def test_load_translations():
    test_case_0()


# Generated at 2022-06-26 08:03:43.682859
# Unit test for constructor of class Locale
def test_Locale():
    test_case_0()
    str_1 = 'fr'
    str_2 = 'fr_FR'
    str_3 = 'en_US'
    locale_obj = Locale.get_closest(str_1, str_2, str_3)

# Generated at 2022-06-26 08:03:52.642319
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    str_0 = 'Escapes a string so it is valid within HTML or XML.\n\n    Escapes the characters ``<``, ``>``, ``"``, ``\'``, and ``&``.\n    When used in attribute values the escaped strings must be enclosed\n    in quotes.\n\n    .. versionchanged:: 3.2\n\n       Added the single quote to the list of escaped characters.\n    '
    load_translations(str_0)
    locale = get_closest('en')
    friendly_number = locale.friendly_number(attribute_name='title')
    print(friendly_number)


# Generated at 2022-06-26 08:03:56.802745
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    load_translations(str_0)
    obj_0 = Locale.get_closest(str_1)
    obj_0.format_day(date_0)


# Generated at 2022-06-26 08:04:06.789954
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    str_0 = 'Escapes a string so it is valid within HTML or XML.\n\n    Escapes the characters ``<``, ``>``, ``"``, ``\'``, and ``&``.\n    When used in attribute values the escaped strings must be enclosed\n    in quotes.\n\n    .. versionchanged:: 3.2\n\n       Added the single quote to the list of escaped characters.\n    '
    load_translations(str_0)
    code = 'en'
    locale = Locale.get(code)
    value = 10
    result = locale.friendly_number(value)
    assert result == '10'


# Generated at 2022-06-26 08:04:12.263190
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    print("Testing friendly_number...\n")

    code = 'en'
    value = 12345

    locale = Locale(code)
    result = locale.friendly_number(value)
    print("Result: " + result)
    assert result == '12,345'


# Generated at 2022-06-26 08:04:13.592816
# Unit test for constructor of class Locale
def test_Locale():
    test_case_0()


# Generated at 2022-06-26 08:04:21.902030
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():

    # Initilize a data
    int_0 = 0
    str_0 = "11"

    # Invoke method
    obj = Locale.get_closest()
    returned_obj = obj.friendly_number(int_0)

    # Assert result
    assert returned_obj == str_0


# Generated at 2022-06-26 08:04:31.084336
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    str_0 = 'Escapes a string so it is valid within HTML or XML.\n\n    Escapes the characters ``<``, ``>``, ``"``, ``\'``, and ``&``.\n    When used in attribute values the escaped strings must be enclosed\n    in quotes.\n\n    .. versionchanged:: 3.2\n\n       Added the single quote to the list of escaped characters.\n    '
    load_gettext_translations(str_0)


# Generated at 2022-06-26 08:04:35.567556
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Get an instance of the class
    obj_0 = Locale.get('en')
    date_0 = datetime.datetime.now()
    # Call the method
    result_0 = obj_0.format_date(date_0)


# Generated at 2022-06-26 08:05:38.938020
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert _Locale__format_day_(Locale_0, date_0, gmt_offset_0, dow_0) == bool_0


# Generated at 2022-06-26 08:05:45.364502
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    _log.info("\nTesting function Locale.format_day()")
    format_day =  Locale.get('en').format_day(datetime.datetime(2018, 3, 19, 0, 0, 0, 0), 0, True)
    assert format_day == "Monday, March 19", "Expected different test result"
    _log.info(format_day)


# Generated at 2022-06-26 08:05:50.622320
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    str_0 = 'en'
    class_0 = Locale.get_closest(str_0) # Create a new Locale object
    date_0 = datetime.datetime.utcnow()
    str_1 = 'Monday, January 8'
    b_0 = class_0.format_day(date_0, 0, True) == str_1

    return (b_0)


# Generated at 2022-06-26 08:05:56.771159
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale(str_0)
    date = datetime.datetime(2017, 11, 12)
    gmt_offset = 1
    dow = False
    # Test case 0
    assert get_str_format(locale.format_day(date, gmt_offset, dow)) == 'November 12'


# Generated at 2022-06-26 08:06:00.466500
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert True


if __name__ == "__main__":
    test_case_0()
    test_Locale_format_day()
    print("All tests passed!")



# Generated at 2022-06-26 08:06:05.867350
# Unit test for function load_translations
def test_load_translations():
    # Given
    test_dir = "../test/test_locale/"
    test_encoding = "UTF-8"
    # When
    load_translations(test_dir, test_encoding)
    # Then
    print('TEST PASSED: test_load_translations')
    


# Generated at 2022-06-26 08:06:11.088860
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    str_0 = 'en'
    load_translations('/path/to/locale_dir')
    locale = Locale.get(str_0)
    str_1 = 'context'
    str_2 = 'message'
    locale.pgettext(str_1, str_2)


# Generated at 2022-06-26 08:06:22.652609
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    str_0 = 'en'
    str_1 = 'en'
    str_2 = 'en'
    str_3 = 'en'
    str_4 = 'en'
    str_5 = 'en'
    str_6 = 'en'
    str_7 = 'en'
    str_8 = 'en'
    str_9 = 'en'
    str_10 = 'en'
    str_11 = 'en'
    str_12 = 'en'
    str_13 = 'en'
    str_14 = 'en'
    str_15 = 'en'
    str_16 = 'en'
    str_17 = 'en'
    str_18 = 'en'
    str_19 = 'en'
    str_20 = 'en'
    str_21 = 'en'
   

# Generated at 2022-06-26 08:06:35.279183
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    str_0 = 'en'
    str_1 = 'test_singular'
    str_2 = 'test_plural'
    str_3 = 'test_singular'
    int_0 = 1
    int_1 = 2
    dict_0 = dict()
    dict_1 = dict()
    dict_0['singular'] = dict()
    dict_0['singular'][str_3] = str_3
    dict_0['plural'] = dict_1
    dict_1[str_2] = str_2
    dict_1[str_3] = str_3
    csv_locale = CSVLocale(str_0, dict_0)
    assert csv_locale.translate(str_1) == str_1

# Generated at 2022-06-26 08:06:37.875439
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    unit_test_assert_equals('Monday, January 22', Locale(str_0).format_day(datetime.datetime(2012, 1, 23), 0, True))


# Generated at 2022-06-26 08:07:10.892440
# Unit test for function load_translations
def test_load_translations():
    try:
        r = load_translations('test.csv')
    except Exception as e:
        raise e
        return False
    return r is None



# Generated at 2022-06-26 08:07:14.916915
# Unit test for function load_translations
def test_load_translations():
    load_translations("C:/Users/Matthew/OneDrive/Documents/Programming Projects/Python/tornado-5.1.1/tornado/_will_be_deleted_/translation")
    return

# Generated at 2022-06-26 08:07:17.523965
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = 'test/test_locale'
    domain = 'tornado'
    load_gettext_translations(directory, domain)



# Generated at 2022-06-26 08:07:25.294742
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    pass
    # obj_0 = get()
    # context = "context"
    # message = "message"
    # plural_message = None
    # count = None
    # assert obj_0.pgettext(context, message, plural_message, count) == "translate"
    # return "test_Locale_pgettext"

# Generated at 2022-06-26 08:07:29.204366
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    test_class_0 = Locale.get('')
    test_class_0.pgettext(test_class_0.code,test_class_0.code,test_class_0.code,test_class_0.code)

# Generated at 2022-06-26 08:07:43.598106
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test with default arguments
    #assert is_equal(get().format_day(), )

    test_cases = [
        # Test with valid arguments
        {
            "arg": {
                "date": datetime.datetime.utcfromtimestamp(0),
                "gmt_offset": 0,
                "dow": True,
            },
            "exception": None,
            "expected": "Thursday, January 1",
        },
        # Test with valid arguments
        {
            "arg": {
                "date": datetime.datetime.utcfromtimestamp(0),
                "gmt_offset": 0,
                "dow": False,
            },
            "exception": None,
            "expected": "January 1",
        },
    ]

    for test in test_cases:
        test_case

# Generated at 2022-06-26 08:07:49.805921
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    date_0 = datetime.datetime(2227, 1, 14)
    gmt_offset_0 = -1236
    assert locale_0.format_day(date_0, gmt_offset_0, False) != None


# Generated at 2022-06-26 08:08:02.818873
# Unit test for method list of class Locale
def test_Locale_list():
    _ = get().translate
    _("%(commas)s and %(last)s")
    _("%(time)s")
    _("%(day)s")
    _("%(month_name)s %(day)s, %(year)s at %(time)s")
    _("%(month_name)s %(day)s, %(year)s")
    _("%(month_name)s %(day)s at %(time)s")
    _("%(weekday)s at %(time)s")
    _("%(weekday)s")
    _("yesterday at %(time)s")
    _("yesterday")
    _("%(hours)d hours ago")
    _("%(minutes)d minutes ago")

# Generated at 2022-06-26 08:08:15.268550
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    input_0_directory = "directory"
    input_0_languages__0 = "language_1"
    input_0_languages__1 = "language_2"
    input_1_domain = "domain"
    input_2_path_exists = True
    input_2_path_exists = True
    input_args = [input_0_directory, input_1_domain]
    input_kwargs = {"languages": [input_0_languages__0, input_0_languages__1]}
    expected_result = None
    expected_exception = None
    # Run the method
    actual_result = load_gettext_translations(
        *input_args, **input_kwargs)
    # Check the method's result
    assert actual_result == expected_result
    # Check for raised exceptions

# Generated at 2022-06-26 08:08:17.842020
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
   load_gettext_translations(
        "/home/kenton/tornado/tornado/locale",
        "tornado",
    )


# Generated at 2022-06-26 08:08:46.620559
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("directory", "domain")


# Generated at 2022-06-26 08:08:48.843145
# Unit test for function load_translations
def test_load_translations():
    directory_0 = 'es_LA.csv'
    encoding_0 = None
    load_translations(directory_0, encoding_0)



# Generated at 2022-06-26 08:08:57.314306
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    float_0 = float()
    float_1 = float()
    float_0 = float()
    float_0 = float()
    float_1 = float()
    float_0 = float()
    locale_0 = Locale()
    int_0 = 0
    str_0 = str()
    str_0 = locale_0.format_day(float_0, float_1, float_0)
    str_0 = locale_0.format_day(float_1, float_0, float_1)
    str_0 = locale_0.format_day(float_0, float_1, int_0)
    str_0 = locale_0.format_day(float_1, float_0, int_0)

# Generated at 2022-06-26 08:09:01.406447
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    pass


# Generated at 2022-06-26 08:09:03.040212
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(1, 1)


# Generated at 2022-06-26 08:09:07.273542
# Unit test for function load_translations
def test_load_translations():
    try:
        load_translations("./tornado/_locale_data/")
    except Exception as e:
        print(e)
        assert False
    #print(_translations)
    assert "en" in _translations


# Generated at 2022-06-26 08:09:19.623350
# Unit test for function load_translations

# Generated at 2022-06-26 08:09:30.101014
# Unit test for function load_translations
def test_load_translations():
    test_directory = "./test_directory"
    test_file = "/test.csv"
    test_file_path = test_directory + test_file
    encoding = "UTF-8"
    file_content = """\
"I love you","Te amo"
"%(name)s liked this","A %(name)s les gustó esto","plural"
"%(name)s liked this","A %(name)s le gustó esto","singular"\
"""


# Generated at 2022-06-26 08:09:31.412566
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    locale_0 = get()
    assert locale_0.pgettext("context", "message") == ""


# Generated at 2022-06-26 08:09:35.914573
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = get()
    date_0 = datetime.datetime.now()
    gmt_offset_0 = 0
    assert locale_0.format_date(date_0, gmt_offset_0) is not None
    # AssertionError is raised


# Generated at 2022-06-26 08:10:02.664419
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = get()
    print(locale.format_day(datetime.datetime.utcnow()))


# Generated at 2022-06-26 08:10:09.717699
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # get instance of the class
    locale_0 = get()
    # define the parameter
    date = datetime.datetime(2020, 12, 2, 10, 11, 12)
    gmt_offset = 0
    dow = True
    # call the method
    result = locale_0.format_day(date, gmt_offset, dow)
    print(result)
    assert result == "Wednesday, December 2"


# Generated at 2022-06-26 08:10:19.337153
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./test_locale", "test_mo")
    assert _translations.get("en")
    if "en" in _translations:
        assert _translations["en"].get("Translate this text") == "Translate this text - en"
    assert _translations.get("de")
    if "de" in _translations:
        assert _translations["de"].get("Translate this text") == "Translate this text - de"
    assert _translations.get("es")
    if "es" in _translations:
        assert _translations["es"].get("Translate this text") == "Translate this text - es"
    assert _translations.get("ru")

# Generated at 2022-06-26 08:10:22.861677
# Unit test for method list of class Locale
def test_Locale_list():
    string_0 = "A"
    string_1 = "B"
    string_2 = "C"
    array_0 = [string_0, string_1, string_2]
    locale_0 = get()
    string_3 = locale_0.list(array_0)


# Generated at 2022-06-26 08:10:27.864152
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    float_0 = -2417.24
    locale_0 = get()


# Generated at 2022-06-26 08:10:29.545705
# Unit test for function load_translations
def test_load_translations():
    load_translations("test_locale.csv")


# Generated at 2022-06-26 08:10:31.813072
# Unit test for function load_translations
def test_load_translations():
    directory = '.'
    load_translations(directory)



# Generated at 2022-06-26 08:10:39.506302
# Unit test for function load_translations
def test_load_translations():
    # Set default locale
    set_default_locale('zh_CN')
    # load translations
    load_translations('./test_data/test_translations.csv', 'utf-8-sig')
    # test translation
    assert get('zh_CN').translate('test') == '测试'
    assert get('en_US').translate('test') == 'test'


# Generated at 2022-06-26 08:10:44.365125
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    plural_message = None
    count = None
    locale_0 = get()
    result_0 = locale_0.pgettext(plural_message, count)


# Generated at 2022-06-26 08:10:49.899374
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    float_0 = -2417.24
    date_0 = datetime.datetime.utcnow()
    locale_0 = get()
    format_date_0 = format_date(date_0, float_0)


# Generated at 2022-06-26 08:11:28.892122
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    locale_1 = get()
    locale_2 = get()
    locale_3 = get()

    datetime_1 = datetime.datetime(2015, 10, 15, 13, 59, 17)
    datetime_2 = datetime.datetime(2012, 7, 10, 23, 59, 59)
    datetime_3 = datetime.datetime(2012, 7, 10, 23, 59, 59)
    datetime_4 = datetime.datetime(2012, 1, 12, 10, 32, 59)
    datetime_5 = datetime.datetime(2012, 3, 6, 4, 7, 3)
    datetime_6 = datetime.datetime(2012, 1, 12, 10, 32, 59)

# Generated at 2022-06-26 08:11:37.783846
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Test for correct handling of load_gettext_translations
    path_0 = os.getenv('HOME')+"/.pypa/pip/locales/"
    # load_gettext_translations(path_0, "pip")
    # assert(True)
    assert(True)
    # Exception: NameError: global name 'gen_log' is not defined
    # assert(True)
    assert(True)
    # Exception: NameError: global name 'gen_log' is not defined
