

# Generated at 2022-06-26 08:02:31.477207
# Unit test for method list of class Locale
def test_Locale_list():
    str_0 = None
    list_0 = [str_0]
    locale_0 = get(*list_0)
    list_1 = [str_0]
    try:
        locale_0.list(list_1)
    except Exception:
        pass



# Generated at 2022-06-26 08:02:44.245947
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Test case for property code of class Locale
    try:
        assert get("en").code == "en"
        assert get("en").code == "en"
    except:
        assert False
    # Test case for property code of class Locale
    try:
        assert get("en").code == "en"
        assert get("en").code == "en"
    except:
        assert False
    # Test case for property code of class Locale
    try:
        assert get("en").code == "en"
        assert get("en").code == "en"
    except:
        assert False
    # Test case for property code of class Locale
    try:
        assert get("en").code == "en"
        assert get("en").code == "en"
    except:
        assert False
    # Test case for property code

# Generated at 2022-06-26 08:02:45.327980
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert 1 == 2


# Generated at 2022-06-26 08:02:47.603496
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    print("Test: method Locale.format_day")


# Generated at 2022-06-26 08:02:51.086327
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    domain_0 = "mydomain"
    str_0 = "./translations"
    load_gettext_translations(str_0, domain_0)


# Generated at 2022-06-26 08:02:52.564417
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory=None, domain=None)


# Generated at 2022-06-26 08:02:58.940376
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date_0 = datetime.datetime.now()
    gmt_offset_0 = 1
    dow_0 = gmt_offset_0 < 1
    locale_0 = Locale.get(None)
    if locale_0 is None:
        locale_0 = Locale.get(None)
    locale_0.format_day(date_0, gmt_offset_0, dow_0)



# Generated at 2022-06-26 08:03:02.125449
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/home/szs/locale', 'domain')
    if True:
        raise Exception('Assertion failed')


# Generated at 2022-06-26 08:03:13.987259
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date_0 = datetime.datetime.today()
    gmt_offset_0 = -1440
    dow_0 = False
    list_0 = [date_0, gmt_offset_0, dow_0]
    result = format_day(*list_0)
    assert result is not None
    # Base case
    date_1 = datetime.datetime.today()
    gmt_offset_1 = -1440
    dow_1 = False
    list_1 = [date_1, gmt_offset_1, dow_1]
    result = format_day(*list_1)
    assert result is not None
    # Base case
    date_2 = datetime.datetime.today()
    gmt_offset_2 = -1440
    dow_2 = False

# Generated at 2022-06-26 08:03:21.533747
# Unit test for function load_translations
def test_load_translations():
    directory = None
    encoding = None
    old_translations = _translations
    old_supported_locales = _supported_locales
    try:
        load_translations(directory, encoding)
    except Exception as e:
        _translations = old_translations
        _supported_locales = old_supported_locales
        raise
    else:
        _translations = old_translations
        _supported_locales = old_supported_locales

# Generated at 2022-06-26 08:03:47.738914
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    class ModelLocale(Locale):
        def __init__(self):
            super().__init__(None)

    for date in [datetime.datetime(2019, 1, 22), datetime.datetime(2019, 1, 23)]:
        assert ModelLocale().format_day(date) == "Tuesday, January 22"
        assert ModelLocale().format_day(date,dow=False) == "January 22"


# Generated at 2022-06-26 08:03:51.802757
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    var_0 = None
    var_1 = var_0.friendly_number(var_0)
    assert type(var_1) == str


# Generated at 2022-06-26 08:03:53.797865
# Unit test for function load_translations
def test_load_translations():
    assert False, "A test of load_translations failed"


# Generated at 2022-06-26 08:03:57.838492
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    var_0 = test_module()
    var_1 = None
    var_2 = var_0.format_date(var_1, var_1, var_1, var_1, var_1)



# Generated at 2022-06-26 08:04:08.153843
# Unit test for function load_translations
def test_load_translations():
    import tornado.locale
    import sys

    var_0 = None
    var_1 = 1
    var_2 = "aa"
    var_3 = ["aa", "bb", "cc"]
    var_4 = {"aa": "bb", "cc": "dd", "ee": "ff"}
    var_5 = ("aa", "bb", "cc")
    var_6 = sys.getsizeof(var_0)
    var_7 = sys.getsizeof(var_1)
    var_8 = sys.getsizeof(var_2)
    var_9 = sys.getsizeof(var_3)
    var_10 = sys.getsizeof(var_4)
    var_11 = sys.getsizeof(var_5)
    var_12 = sys.getsizeof(var_6)

# Generated at 2022-06-26 08:04:09.982468
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    var_0 = GettextLocale('ja', 'ja')
    var_1 = 'test_string'
    var_2 = pgettext(var_0, var_1)


# Generated at 2022-06-26 08:04:19.150582
# Unit test for method format_date of class Locale

# Generated at 2022-06-26 08:04:28.197601
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    load_translations("/")
    var_0 = Locale.get("en")
    var_1 = var_0.translate("test")
    var_2 = var_0.translate("test")
    var_3 = var_0.translate("test")
    var_4 = var_0.translate("test")
    var_5 = var_0.translate("test")
    var_6 = var_0.translate("test")
    var_7 = var_0.translate("test")

test_case_0()
test_Locale_pgettext

# Generated at 2022-06-26 08:04:41.030515
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-26 08:04:47.425500
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    expected_result = "Monday, January 22"
    actual_result = Locale.get('en_US').format_day(datetime.datetime(2018, 1, 22), 0)
    if expected_result == actual_result:
        test_case_result = 'pass'
    else:
        test_case_result = 'fail'
    return test_case_result


# Generated at 2022-06-26 08:05:10.706641
# Unit test for function load_translations
def test_load_translations():
    directory_0 = "test/test_locale"
    test_load_translations_0 = load_translations(directory_0)


# Generated at 2022-06-26 08:05:22.967299
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    print("test_Locale_format_day:")
    #case: calendar.day is 2018/12/31
    test_date = datetime.datetime(year=2018, month=12, day=31)
    locale_0 = Locale("en")
    locale_1 = Locale("zh_CN")
    print("case 1:")
    print("date is 2018/12/31, locale is en")
    print(str(locale_0.format_day(test_date, 0)))
    print("case 2:")
    print("date is 2018/12/31, locale is zh_CN")
    print(str(locale_1.format_day(test_date, 0)))
    print("case 3:")
    print("date is 2018/12/31, locale is zh_CN, dow is False")

# Generated at 2022-06-26 08:05:27.505558
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = Locale("en")
    assert locale_0.friendly_number(1000) == "1,000"


# Generated at 2022-06-26 08:05:29.010759
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    print(Locale.format_day())


# Generated at 2022-06-26 08:05:42.025550
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = Locale('en')
    # The following two lines are used to test the format_day method of class Locale
    # 1. Test the implementation of the instance variable self._months. If a right string is printed, the variable is set right
    print(locale_0._months)
    # 2. Test the implementation of the instance variable self._weekdays. If a right string is printed, the variable is set right
    print(locale_0._weekdays)
    # 3. Test the implementation of the method list. If we have a string of the format 'A and B', the method is implemented right
    print(locale_0.list(['A', 'B']))
    # 4. Test the format_day method in the situation that the input date is yesterday. If we have a string of the format 'Yesterday, Month date', the method is implemented right

# Generated at 2022-06-26 08:05:44.349040
# Unit test for function load_translations
def test_load_translations():
    load_translations(os.curdir)



# Generated at 2022-06-26 08:05:47.711585
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = get()
    dt = parser.parse("2001-12-01")
    ans = locale_0.format_date(dt)
    assert ans == "Dec 1, 2001"


# Generated at 2022-06-26 08:05:53.189080
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/natalie/git/tornado-test/tornado/locale")
    assert isinstance(_translations, dict) == True


# Generated at 2022-06-26 08:05:56.769237
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    locale_1 = CSVLocale("test_locale_code_1")
    result = locale_1.pgettext("test_context_1", "test_message_1")


# Generated at 2022-06-26 08:06:03.958332
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    assert locale_0.friendly_number(3) == '3'
    assert locale_0.friendly_number(1000) == '1,000'
    assert locale_0.friendly_number(1000000) == '1,000,000'
    assert locale_0.friendly_number(1000000000) == '1,000,000,000'


# Generated at 2022-06-26 08:06:43.413114
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    assert locale_0.format_day(datetime.datetime.today()) == "Thursday, April 16"


# Generated at 2022-06-26 08:06:49.676787
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # This directory is where the 'testdata' directory is located.
    base_dir = os.path.dirname(os.path.dirname(__file__))
    directory = os.path.join(base_dir, 'testdata', 'locale')
    domain = 'testdomain'
    load_gettext_translations(directory, domain)


# Generated at 2022-06-26 08:06:51.449188
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('.', 'tornado')


# Generated at 2022-06-26 08:06:52.784866
# Unit test for function load_translations
def test_load_translations():
    load_translations('../data/locales')


# Generated at 2022-06-26 08:07:03.474538
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = './test_locale'
    domain = 'test_locale'

    load_gettext_translations(directory,domain)

    trans_0 = get('pt_BR')

    trans_1 = get('en_US')

    trans_2 = get('es_LA')

    print(trans_1.translate('hello'))

    print(trans_0.translate('hello'))

    print(trans_2.translate('hello'))
    
    print(trans_1.name())

    print(trans_0.name())

    print(trans_2.name())


# Test for class Locale

# Generated at 2022-06-26 08:07:12.277621
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Test the function at the directory: .../tornado/_locale_data/
    directory = os.path.abspath(os.path.dirname(__file__)+"/../_locale_data")
    domain = "tornado"
    load_gettext_translations(directory, domain)
    # Test the default language: en
    gen_log.debug("The default language is en")
    # Test the English str: 'Next'
    gen_log.debug("Next: " + get().translate("Next"))
    # Test the English str: 'Next Page'
    gen_log.debug("Next Page: " + get().translate("Next Page"))
    # Test the Chinese str: 'Next'
    gen_log.debug("Next: " + get("zh_CN").translate("Next"))
    # Test the Chinese

# Generated at 2022-06-26 08:07:22.844008
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    print("Testing load_gettext_translations")
    try:
        from importlib import reload
    except ImportError:
        from imp import reload  # py2
    reload(_locale_data)
    import _locale_data
    import time

    # test for non-existent directory
    print("0.1 testing non-existent directory")
    temp_dir = "temp_" + str(time.time())
    TEST_DOMAIN = "iot"
    try:
        load_gettext_translations(temp_dir, TEST_DOMAIN)
    except Exception as e:
        print("0.1.1 testing non-existent directory ok")
        print(str(e))
    # test for directory with additional files
    print("0.2 testing directory with additional files")

# Generated at 2022-06-26 08:07:26.342494
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('./locale', 'tornado')
    locale_2 = get('cn')
    print(locale_2.translate('Email'))



# Generated at 2022-06-26 08:07:34.189609
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test cases
    # Case 0:
    #   date : datetime(2019, 6, 18, 15, 39, 40, 869000)
    #   gmt_offset : 0
    #   dow : True
    #   expected : "Tuesday, June 18"
    print("\n Case 0:")
    date_0 = datetime(2019, 6, 18, 15, 39, 40, 869000)
    gmt_offset_0 = 0
    dow_0 = True
    expected_0 = "Tuesday, June 18"
    result_0 = get().format_day(date_0, gmt_offset_0, dow_0)
    assert result_0 == expected_0


# Generated at 2022-06-26 08:07:36.766696
# Unit test for function load_translations
def test_load_translations():
    directory = 'locale'
    encoding = None
    load_translations(directory, encoding)



# Generated at 2022-06-26 08:08:13.082551
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime.now()
    gmt_offset = 0
    dow = True
    get().format_day(date, gmt_offset, dow)


# Generated at 2022-06-26 08:08:24.610457
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    dictionary = {'en': '3,067', 'en_US': '3,067', 'es': '3,067', 'fa': '3067', 'ja': '3067'}
    ans = {'en': '3,067', 'en_US': '3,067', 'es': '3,067', 'fa': '3067', 'ja': '3067'}
    for key, value in dictionary.items():
        result = Locale.get(key).friendly_number(3067)
        assert result == value, 'Expected {} but got {} for key {}'.format(
            value, result, key)
    print('PASS: test_Locale_friendly_number')


# Generated at 2022-06-26 08:08:27.615409
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    test_domain = 'test'
    load_gettext_translations(os.path.join("./translations"), test_domain)



# Generated at 2022-06-26 08:08:33.282446
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = Locale(1)
    date_0 = datetime.datetime(2019, 1, 1)
    gmt_offset_0 = 0
    dow_0 = True
    result_0 = locale_0.format_day(date_0, gmt_offset_0, dow_0)
    assert result_0, 'result_0 failed'


# Generated at 2022-06-26 08:08:36.731897
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    locale_0_format_day = locale_0.format_day(datetime.datetime.utcnow())


# Generated at 2022-06-26 08:08:46.365749
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    date_0_0 = datetime.date(1,1,1)
    gmt_offset_0_1 = 0
    dow_0_2 = True

    # Call method
    result_0 = locale_0.format_day(date_0_0,gmt_offset_0_1,dow_0_2)
    # Test result
    assert result_0 == "Wednesday, January 1"


# Generated at 2022-06-26 08:08:48.270496
# Unit test for function load_translations
def test_load_translations():
    # load_translations('../translations', None)
    test_case_0()



# Generated at 2022-06-26 08:08:51.571946
# Unit test for function load_translations
def test_load_translations():
    load_translations("C:\\Users\\jiajiayi\\Documents\\Python\\Tornado\\Tornado_Learning_02\\Tornado_Learning_02\\csvs");


# Generated at 2022-06-26 08:09:02.501871
# Unit test for method friendly_number of class Locale

# Generated at 2022-06-26 08:09:14.491700
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    dt = datetime.datetime(2020, 2, 24, 16, 0)
    dow = True
    str = locale_0.format_day(dt, dow=dow)
    print(str)

    # Rule trace:
    # case 1.1
    # case 1.2
    # case 1.3



# Generated at 2022-06-26 08:10:18.623238
# Unit test for function load_translations
def test_load_translations():
    set_default_locale("en_US")
    load_translations(directory=os.path.join(os.path.dirname(__file__), 'translations'))
    l = get('en_US')
    s = l.translate("My name is %(name)s", name='Wang')
    assert s == 'My name is Wang'

    l = get('es_LA')
    s = l.translate("My name is %(name)s", name='Wang')
    assert s == 'My name is Wang'


# Generated at 2022-06-26 08:10:22.127361
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale("pt_BR") # TODO: can't add a literal of type Locale
    result = locale.format_day(datetime.datetime(2017, 4, 1), 0, True)
    assert result == "Segunda-feira, Abril 01"


# Generated at 2022-06-26 08:10:33.270720
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    Locale.get("en")
    Locale.get("en_US")
    Locale.get("zh_CN")
    Locale.get("fa")
    Locale.get("ar")
    Locale.get("he")
    dt = datetime.datetime(2017, 10, 23, 15, 39, 20)
    date = dt
    gmt_offset = 0
    dow = True
    ret = Locale.get("en").format_day(date, gmt_offset, dow)
    assert ret == 'Monday, October 23'

    ret = Locale.get("en_US").format_day(date, gmt_offset, dow)
    assert ret == 'Monday, October 23'

    ret = Locale.get("zh_CN").format_day(date, gmt_offset, dow)
   

# Generated at 2022-06-26 08:10:35.369021
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    if False:
        # Test case 0
        pass


# Generated at 2022-06-26 08:10:42.611493
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale('en')
    assert locale.friendly_number(1) == '1'
    assert locale.friendly_number(10) == '10'
    assert locale.friendly_number(100) == '100'
    assert locale.friendly_number(1000) == '1,000'
    assert locale.friendly_number(10000) == '10,000'
    assert locale.friendly_number(100000) == '100,000'
    assert locale.friendly_number(1000000) == '1,000,000'
    assert locale.friendly_number(10000000) == '10,000,000'


# Generated at 2022-06-26 08:10:48.658986
# Unit test for function load_translations
def test_load_translations():
    load_translations("../_locale_data")
    current_dir = os.path.dirname(os.path.abspath(__file__))
    load_translations( os.path.join(current_dir,"../_locale_data") )


# Generated at 2022-06-26 08:10:50.794343
# Unit test for function load_translations
def test_load_translations():
    load_translations('C:/Users/jjw77/PycharmProjects/Tornado/tornado/locale')


# Generated at 2022-06-26 08:10:57.116390
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    #TODO: Change this path to a valid path
    load_gettext_translations("/home/alex/Desktop/snowball/snowball/tornado/locale", "tornado")
    print(_translations)


# Generated at 2022-06-26 08:10:59.230419
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    test_case_0()



# Generated at 2022-06-26 08:11:02.127655
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    local_date_0 = datetime.datetime(86400, True, 2)
    locale_0 = get()
    locale_0.format_day(local_date_0, 0, False)
