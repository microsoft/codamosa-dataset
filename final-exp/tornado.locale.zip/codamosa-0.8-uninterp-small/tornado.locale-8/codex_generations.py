

# Generated at 2022-06-26 08:02:42.563146
# Unit test for function load_translations
def test_load_translations():
    # In this test, the directory is the current directory (".")
    # The file is en_US.csv (the file name is defined in this file)
    load_translations(".")
    # The function get() returns the locale en_US (the locale is defined in this file)
    locale_0 = get()
    # The function translate() in Locale class translates the string "Hello world"
    # into "Ciao, mondo"
    print(locale_0.translate("Hello world"))

test_case_0()
test_load_translations()



# Generated at 2022-06-26 08:02:45.328187
# Unit test for function load_translations
def test_load_translations():
    load_translations(
        directory=os.path.dirname(os.path.abspath(__file__)) + "/build", encoding=None,
    )


# Generated at 2022-06-26 08:02:51.662009
# Unit test for method list of class Locale
def test_Locale_list():
    locale_0 = get()
    tmp_1 = locale_0.list([])
    tmp_2 = locale_0.list(["a"])
    tmp_3 = locale_0.list(["a", "b"])
    tmp_4 = locale_0.list(["a", "b", "c"])


# Generated at 2022-06-26 08:02:58.836955
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_test = Locale.get('en')
    number_0 = locale_test.friendly_number(430000)
    if number_0 != "430,000":
        raise ValueError
    number_1 = locale_test.friendly_number(4300000)
    if number_1 != "4,300,000":
        raise ValueError

    number_2 = locale_test.friendly_number(43)
    if number_2 != "43":
        raise ValueError



# Generated at 2022-06-26 08:03:03.148322
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "E:/Misc/Program/tornado_test/project_test/project001_tornado/src/project_tornado/project001_tornado/translations"
    domain = "project001_tornado"
    load_gettext_translations(directory,domain)


# Generated at 2022-06-26 08:03:13.033163
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Add your function code to test here
    load_gettext_translations('locale', 'translation')
    language_list = []
    for lang in os.listdir('locale'):
        if lang.startswith("."):
            continue # skip .svn, etc
        if os.path.isfile(os.path.join('locale', lang)):
            continue
        try:
            os.stat(os.path.join('locale', lang, 'LC_MESSAGES', 'translation.mo'))
            language_list.append(lang)
        except:
            continue
    return language_list
    #pass



# Generated at 2022-06-26 08:03:21.754444
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    import datetime
    date_0 = datetime.datetime.now()
    gmt_offset_0 = 0
    dow_0 = True
    expected_result = str(date_0.strftime("%A")) + ", " + str(date_0.strftime("%B")) + " " + str(date_0.strftime("%d"))
    actual_result = locale_0.format_day(date_0, gmt_offset_0, dow_0)
    assert expected_result == actual_result


# Generated at 2022-06-26 08:03:25.644553
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = 'locale'
    domain = 'mydomain'
    load_gettext_translations(directory, domain)
    assert _translations != {}
    assert _supported_locales != frozenset()
    assert _use_gettext == True



# Generated at 2022-06-26 08:03:30.284511
# Unit test for function load_translations
def test_load_translations():
    test_case_0()


# Generated at 2022-06-26 08:03:34.548974
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get('en_US')
    date_0 = datetime.datetime.strptime("2018-07-26", '%Y-%m-%d')
    assert(locale_0.format_day(date_0) == "Thursday, July 26")


# Generated at 2022-06-26 08:03:56.361861
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    assert "a-b-c" == locale_0.friendly_number(123)


# Generated at 2022-06-26 08:04:02.114560
# Unit test for function load_translations
def test_load_translations():
    translations_dir = 'translations'
    test_file_name = 'en_US.csv'
    test_file = os.path.join(translations_dir, test_file_name) # relative to current working directory
    with open(test_file) as f:
        reader = csv.reader(f)
        for row in reader:
            print(row)


# Generated at 2022-06-26 08:04:10.092143
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    _ = translate
    assert _("%(date)s today") % {
        "date": get().format_day(datetime.datetime.now())
    } == "today"
    assert _("%(date)s yesterday") % {
        "date": get().format_day(datetime.datetime.now() - datetime.timedelta(days=1))
    } == "yesterday"
    assert (
        _("%(date)s tomorrow") % {
            "date": get().format_day(datetime.datetime.now() + datetime.timedelta(days=1))
        }
        == "tomorrow"
    )

# Generated at 2022-06-26 08:04:11.592039
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    pass


# Generated at 2022-06-26 08:04:15.464758
# Unit test for function load_translations
def test_load_translations():
    load_translations('./tornado/_ca/')
    return

test_load_translations()
test_case_0()



# Generated at 2022-06-26 08:04:26.126394
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_1 = Locale.get('en_US')
    # The format of year, month and day is:
    # year: yyyy
    # month: mm
    # day: dd
    date_tuple = datetime.datetime(year=2019, month=2, day=28, hour=16, minute=30)
    gmt_offset = 0
    relative = False
    shorter = False
    full_format = False
    date_str = locale_1.format_date(date_tuple, gmt_offset, relative, shorter, full_format)
    assert date_str == 'February 28, 2019 at 4:30pm'


# Generated at 2022-06-26 08:04:35.517428
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # 1. Test empty date
    date = datetime.datetime(year=2020,month=8,day=29,hour=14,minute=30,second=0)
    locale = Locale("en")
    assert locale.format_day(date) == "Saturday, August 29"

    # 2. Test empty locale
    locale = Locale("")
    assert locale.format_day(date) == "Saturday, August 29"

    # 3. Test empty string
    locale = Locale("en")
    assert locale.format_day("") == ""


# Generated at 2022-06-26 08:04:39.525650
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    assert True
    """
    assert locale_0.format_day() == "Monday, January 22"
    """


# Generated at 2022-06-26 08:04:50.994708
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Create a Locale
    locale_0 = Locale.get("en")

    # Create a datetime
    dt = datetime.datetime(2018,11,9,15,7)

    # Test the function 
    ans = locale_0.format_date(dt,full_format=True)
    print("Test 1: ",ans)

    # Test the function 
    ans = locale_0.format_date(dt,full_format=False)
    print("Test 2: ",ans)

    # Test the function 
    ans = locale_0.format_date(dt,full_format=False,relative=False)
    print("Test 3: ",ans)

    # Test the function 
    ans = locale_0.format_date(dt,full_format=True,relative=False)

# Generated at 2022-06-26 08:05:03.646063
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    STRING = 'This is a string'
    TEST_STRING = 'This is a string'
    TEST_STRING_1 = 'This is a sentence'
    TEST_STRING_2 = 'This is a sentence'
    TEST_STRING_3 = 'This is a sentence'
    TEST_CONTEXT = 'This is a context'
    TEST_CONTEXT_1 = 'This is a context'
    TEST_COUNT = 0
    TEST_COUNT_1 = 1
    TEST_COUNT_2 = 2
    TEST_COUNT_3 = 2
    TEST_COUNT_4 = 3
    TEST_COUNT_5 = 3
    TEST_COUNT_6 = 3
    TEST_COUNT_7 = 3
    TEST_COUNT_8 = 3
    TEST_COUNT_9 = 3

    test_loc

# Generated at 2022-06-26 08:05:36.234441
# Unit test for method list of class Locale
def test_Locale_list():
    test_locale = Locale("en")
    test_parts = ["A", "B", "C", "D"]
    assert test_locale.list(test_parts) == "A, B, C and D"
    test_parts = ["A", "B", "C"]
    assert test_locale.list(test_parts) == "A, B and C"
    test_parts = ["A", "B"]
    assert test_locale.list(test_parts) == "A and B"
    test_parts = ["A"]
    assert test_locale.list(test_parts) == "A"
    test_parts = []
    assert test_locale.list(test_parts) == ""
    test_locale = Locale("fa")

# Generated at 2022-06-26 08:05:44.220842
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en")
    locale_1 = Locale.get("fa")
    assert locale.friendly_number(1) == "1"
    assert locale_1.friendly_number(1) == "1"
    assert locale.friendly_number(1000) == "1,000"
    assert locale_1.friendly_number(1000) == "1000"


# Generated at 2022-06-26 08:05:47.946526
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    """
    >>> test_case_1()
    '25,667'
    """

    locale_0 = get()
    value = 25667
    actual = locale_0.friendly_number(value)
    print(actual)


# Generated at 2022-06-26 08:05:53.074274
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("fa")
    string = locale.friendly_number(123456)
    assert (string == "123,456")


# Generated at 2022-06-26 08:05:56.001770
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    global _load_gettext_translations
    _load_gettext_translations("/home/liziyang/tornado_website_clone/locale","messages")


# Generated at 2022-06-26 08:06:09.197201
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    if TEST_CASE==0: # Main thread
        # Create locales for test
        locale_0 = get()
        locale_1 = get("de_DE")
        locale_2 = get("zh_CN")
        locales = [locale_0, locale_1, locale_2]
        # Create date object 2019-05-27 08:55:55

# Generated at 2022-06-26 08:06:13.567811
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    test_locale = get('zh_CN')
    test_locale.translate('hello')
    default_language = test_locale.get_closest('en_US').get_language()
    assert default_language == 'en_US'


# Generated at 2022-06-26 08:06:18.958529
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    current_time = datetime.datetime.now()
    result_0 = locale_0.format_day(current_time, gmt_offset=0, dow=True)
    result_1 = locale_0.format_day(current_time, gmt_offset=8, dow=False)


# Generated at 2022-06-26 08:06:26.844532
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = Locale.get_closest('en_us')
    now = datetime.datetime.utcnow()
    nowtime = time.time()
    nowtime_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(nowtime))
    print('nowtime     :', nowtime_str)
    print('nowtime int :', nowtime)
    print('nowtime str :', str(nowtime))
    print('nowtime int :', int(nowtime))
    result = locale_0.format_date(now, 0)
    print(result)


# Generated at 2022-06-26 08:06:32.242523
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = Locale("en")
    result = locale_0.friendly_number(123456789)
    assert result == str(123456789)


# Generated at 2022-06-26 08:06:55.541282
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory = "locale", domain = "messages")
    print("******************************************")
    print(_translations["en_US"])
    print("******************************************")
    print(_supported_locales)
    print("******************************************")
    print(_use_gettext)
    print("******************************************")

test_load_gettext_translations()

REGEX_TYPE = type(re.compile(""))



# Generated at 2022-06-26 08:06:58.783288
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    print(Locale.format_day(datetime.datetime.utcnow(), gmt_offset=4, dow=False))


# Generated at 2022-06-26 08:07:06.877076
# Unit test for function load_translations
def test_load_translations():
    # load_translations(directory: str, encoding: Optional[str] = None) -> None
    csv_file_path = '/Users/yunfei.peng/Documents/python_workspace/tornado_project/tests/locale_files/'
    load_translations(csv_file_path)
    print('_translations', _translations)
    print('_supported_locales', _supported_locales)



# Generated at 2022-06-26 08:07:16.197222
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():

    global _translations
    global _default_locale

    locale_1 = get()
    locale_1._translate = {}
    locale_1._translate['en'] = {}
    locale_1._translate['en']['plural'] = {}
    locale_1._translate['en']['plural']['unknown'] = {}
    test_value = 0
    returned = locale_1.friendly_number(test_value)
    assert returned == str(test_value)


# Generated at 2022-06-26 08:07:24.532905
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    load_translations(os.path.join(os.getcwd(), "pyfile"))
    locale_1 = Locale.get("en_US")
    now = datetime.datetime.now()
    print(locale_1.format_day(now, dow=False))
    print(locale_1.format_day(now, dow=True))


# Generated at 2022-06-26 08:07:26.770542
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory = '../../test/translate/', encoding = None)


# Generated at 2022-06-26 08:07:30.297564
# Unit test for method format_day of class Locale
def test_Locale_format_day():
  today = datetime.datetime.now()
  utc_offset = -time.timezone / 60
  locale = Locale.get('en')
  locale.format_day(today, utc_offset, dow = True)



# Generated at 2022-06-26 08:07:44.900022
# Unit test for method format_date of class Locale
def test_Locale_format_date():

    # Test three different time zones
    test_times = [
        ("US/Eastern", -5),
        ("US/Pacific", -8),
        ("US/Central", -6),
    ]
    for zone, offset in test_times:
        gmt = pytz.timezone("UTC") 
        us_tz = pytz.timezone(zone)

        # Create a timezone aware datetime object
        now_aware = datetime.datetime.now(gmt)
        future_aware = now_aware + datetime.timedelta(seconds=60)
        past_aware = now_aware - datetime.timedelta(seconds=60)

        # Convert to another time zone for test
        now_us = now_aware.astimezone(us_tz)

# Generated at 2022-06-26 08:07:55.480259
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    default_locale_name = "en_US"
    default_locale = get()
    # Verify the default locale
    assert default_locale_name == default_locale.code
    assert default_locale in _supported_locales
    assert default_locale_name == _default_locale
    # Load translations
    supported_locale_name = "es_GT"
    domain = "tornado"
    load_gettext_translations(".", domain)
    locale_0 = get(supported_locale_name)
    # Verify we have loaded translation for supported locale
    assert locale_0 in _supported_locales
    # Verify translation for supported locale, we use a string that is translated
    # for the supported locale
    expected_translation = u"Idioma"
    # Test
    actual_translation = locale_0

# Generated at 2022-06-26 08:07:57.506627
# Unit test for function load_translations
def test_load_translations():
    load_translations('C:\\Users\\Hou\\Desktop\\codes\\tornado_practice\\translation_file\\')


# Generated at 2022-06-26 08:08:27.171227
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_1 = get()
    # parse input for test
    test_input = {'value': '10'}
    # get result from function to be tested
    test_result = locale_1.friendly_number(test_input['value'])
    # get expected result
    expect_result = '10'
    assert test_result == expect_result

if __name__ == "__main__":
    test_case_0()
    test_Locale_friendly_number()

# Generated at 2022-06-26 08:08:34.270490
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test case data
    date_0 = datetime.datetime(2020, 4, 1, 12, 00, 00)
    gmt_offset_0 = -300
    dow_0 = True

    # Perform the test
    result_0 = Locale.format_day(date_0, gmt_offset_0, dow_0)

    # Verify the results

# Generated at 2022-06-26 08:08:48.579828
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    try:
        load_translations("./test_translations")
    except:
        return
    context = 'context'
    message = 'message'
    plural_message = 'plural message'
    count = 1
    if (isinstance(Locale.get_closest('en'), CSVLocale)):
        assert Locale.get_closest('en').pgettext(context, message, plural_message, count) == 'message'
        assert Locale.get_closest('en').pgettext(context, message) == 'message'

# Generated at 2022-06-26 08:08:53.341684
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = get()
    assert locale.friendly_number(1234567) == "1,234,567"
    # Negative values
    assert locale.friendly_number(-1234567) == "-1,234,567"
    # Zero value
    assert locale.friendly_number(0) == "0"


# Generated at 2022-06-26 08:09:00.405895
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    # datetime.datetime.utcnow().date() is the value of time.strftime(%Y-%m-%d), %Y:year, %m:month, %d:day, time.strftime(%Y-%m-%d, time.gmtime())
    print(locale_0.format_day(datetime.datetime.utcnow().date()))



# Generated at 2022-06-26 08:09:07.158936
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_1 = Locale("en")
    result = locale_1.friendly_number(1234567890)
    if result != "1,234,567,890":
        print("Test for method friendly_number of class Locale FAILED:")
        print("Locale: en")
        print("number: 1234567890")
        print("result: " + result)
        raise Exception



# Generated at 2022-06-26 08:09:19.588660
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = get()
    # test case: non-relative, non-full
    dt = datetime.datetime.utcnow()
    fmt_dt = locale_0.format_date(dt, 0, False, False)
    assert fmt_dt is not None
    # test case: relative, full
    dt = datetime.datetime.utcnow()
    fmt_dt = locale_0.format_date(dt, 0, True, True)
    assert fmt_dt is not None
    # test case: non-relative, full
    dt = datetime.datetime.utcnow()
    fmt_dt = locale_0.format_date(dt, 0, False, True)
    assert fmt_dt is not None
    # test case: relative, non-full
    dt = datetime.datetime

# Generated at 2022-06-26 08:09:25.259722
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    test_dir = "../../test_dir"
    test_domain = "test_domain"
    load_gettext_translations(test_dir, test_domain)
    for i in range(0, 10):
        test_case_0()
    print("test_load_gettext_translations ok.")


# Generated at 2022-06-26 08:09:26.703845
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    assert locale_0.friendly_number(6) == "6"


# Generated at 2022-06-26 08:09:28.014297
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    """Test for method pgettext of class Locale"""
    test_case_0()


# Generated at 2022-06-26 08:10:15.001692
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    assert(Locale.get("en_US").format_date(datetime.datetime(year=2020,month=4,day=30,hour=0,minute=0,second=0))=="11:00 pm")
    assert(Locale.get("en_US").format_date(datetime.datetime(year=2020,month=4,day=30,hour=23,minute=30,second=0))=="11:30 pm")
    assert(Locale.get("pt_BR").format_date(datetime.datetime(year=2020,month=5,day=1,hour=0,minute=0,second=0))=="30 de Abril de 2020 às 23:00")

# Generated at 2022-06-26 08:10:25.455872
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # If a negative number is given, it should return a negative string
    locale_0 = get()
    result = locale_0.friendly_number(-100)
    assert (result == "-100")
    # If a string is given, it should raise a TypeError
    result = locale_0.friendly_number("string")
    assert (result == TypeError)
    # Zero is accepted as number
    result = locale_0.friendly_number(0)
    assert (result == "0")
    # If one is given, it should return a string of one
    result = locale_0.friendly_number(1)
    assert (result == "1")
    # If a random number is given, it should return a string with a comma in the middle
    number = random.randint(1, 1000000)
    result = locale_0.friendly_number

# Generated at 2022-06-26 08:10:31.264845
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    base_dir = os.path.dirname(os.path.dirname(__file__))
    tornado.locale.load_gettext_translations(os.path.join(base_dir, 'locale'), domain="tornado_py3")


# Generated at 2022-06-26 08:10:40.171353
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/Users/jeremy.zhu/Documents/Programming/tornado/tornado/locale', 'tornado')
    print(get('zh_CN'))
    # strings = {'Sign in': 'Sign in', 'Sign out': 'Sign out'}
    # assert_equal(get('zh_CN').translate('Sign in'), 'Sign in')
    # assert_equal(get('zh_CN').translate('Sign out'), 'Sign out')



# Generated at 2022-06-26 08:10:45.587595
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/xiongpeng/Code/tornado-5.1.1/tornado/locale")
    # Unit test for function test_case_0
    test_case_0()


# Generated at 2022-06-26 08:10:52.890136
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    assert (
        locale_0.friendly_number(value=100)
        == "100"
    ), "Assertion failed, method friendly_number of class Locale"
    assert (
        locale_0.friendly_number(value=10000)
        == "10,000"
    ), "Assertion failed, method friendly_number of class Locale"
    assert (
        locale_0.friendly_number(value=1000000)
        == "1,000,000"
    ), "Assertion failed, method friendly_number of class Locale"



# Generated at 2022-06-26 08:11:03.709323
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Create a dummy Locale instance
    locale_1 = Locale("zh_CN")

    # create dummy datetime objects
    d1 = datetime.datetime(year = 2020, month = 1, day = 15, hour = 16, minute = 30, second = 0)
    d2 = datetime.datetime(year = 2019, month = 3, day = 4, hour = 6, minute = 50, second = 0)
    d3 = datetime.datetime(year = 2018, month = 11, day = 23, hour = 13, minute = 25, second = 0)
    d4 = datetime.datetime(year = 2022, month = 2, day = 2, hour = 2, minute = 2, second = 0)

    # Test 1
    # Input: 2020-01-15 16:30:00
    # Expected Output: 星

# Generated at 2022-06-26 08:11:06.620623
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert get().friendly_number(1234567) == '1,234,567'


# Generated at 2022-06-26 08:11:09.994979
# Unit test for function load_translations
def test_load_translations():
    load_translations('C:/Users/Administrator/PycharmProjects/tornado_project/tornado')
    print(_translations)


# Generated at 2022-06-26 08:11:12.695676
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    locale_0.friendly_number(1)
