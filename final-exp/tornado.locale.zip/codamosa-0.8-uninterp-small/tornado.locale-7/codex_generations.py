

# Generated at 2022-06-26 08:02:06.563282
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    now = datetime.datetime.today()
    locale_0 = get()
    print(locale_0.format_day(now, dow=False))
    print(locale_0.format_day(now, dow=True))


# Generated at 2022-06-26 08:02:12.131017
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    print("\n=========== Unit test for method format_date of class Locale =============")
    print("```")
    l_0 = load_translations("resources/i18n/translation")
    l_0.get("en").format_date(1551830260000)
    print(l_0.get("en").format_date(1551830260000))
    l_1 = load_gettext_translations("resources/i18n/translation", "i18n")
    l_1.get("en").format_date(1551830260000)
    print(l_1.get("en").format_date(1551830260000))
    print("```")



# Generated at 2022-06-26 08:02:14.561132
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    """
    Test function load_gettext_translations
    """
    directory = "./tornado_translations"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    assert _use_gettext == True



# Generated at 2022-06-26 08:02:26.102022
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    case_0_date = datetime.datetime.utcnow()
    case_0_gmt_offset = 8
    case_0_relative = True
    case_0_shorter = False
    case_0_full_format = False

    # case 1: date in the past, relative time
    case_1_date = datetime.datetime.utcnow() - datetime.timedelta(minutes = 10)
    # case 4: date in the past, full format
    case_4_date = datetime.datetime.utcnow() - datetime.timedelta(minutes = 10)

    # case 2: future date, relative time
    case_2_date = datetime.datetime.utcnow() + datetime.timedelta(minutes = 10)
    # case 5: future date, full

# Generated at 2022-06-26 08:02:30.580900
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = get()
    ct = time.time()
    print("time in timestamp:", ct)
    print("time in string:", locale_0.format_date(ct))



# Generated at 2022-06-26 08:02:37.875877
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/shiyanlou/shiyanlou_tornado_1/translations/")
    try:
        locale_0 = get()
        locale_1 = get('en_US')
        locale_2 = get('en_US', 'en_AU')
        locale_3 = get('en_US', 'en_AU', 'en_US')
        assert 1 == 2
    except NotImplementedError:
        pass


# Generated at 2022-06-26 08:02:42.700517
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = get()
    test_1 = locale_0.format_date(datetime.datetime(2018, 8, 20, 0, 0), False)
    assert test_1 == 'Aug 20, 2018'


# Generated at 2022-06-26 08:02:45.469683
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/Users/yuecen/PycharmProjects/tornado-examples/locale', "tornado")


# Generated at 2022-06-26 08:02:47.096349
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # Test Locale.translate(message, plural_message=None, count=None)
    locale_0 = CSVLocale('zh_CN', {})
    with pytest.raises(AssertionError):
        locale_0.translate('message')


# Generated at 2022-06-26 08:02:59.037374
# Unit test for function load_translations
def test_load_translations():
    path = "./test_locale_data/"
    load_translations(path)
    for path in os.listdir(path):
        if not path.endswith(".csv"):
            continue
        locale, extension = path.split(".")
        if not re.match("[a-z]+(_[A-Z]+)?$", locale):
            gen_log.error(
                "Unrecognized locale %r (path: %s)",
                locale,
                os.path.join(path, path),
            )
            continue
        # python 3: csv.reader requires a file open in text mode.
        # Specify an encoding to avoid dependence on $LANG environment variable.

# Generated at 2022-06-26 08:04:02.077197
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    global _supported_locales

    # 1. Test case:
    #   + code = 'en'
    #   + date = datetime.datetime.utcnow()
    #   + gmt_offset = 0
    #   + dow = True
    #   => return a string like 'Monday, January 22'

    # Prepare for the test
    code = 'en'
    date = datetime.datetime.utcnow()
    gmt_offset = 0
    dow = True
    _supported_locales = set(code)
    # Run the function and check the output
    result = Locale.get(code).format_day(date, gmt_offset, dow)
    assert type(result) is str
    assert len(result.split()) == 3

# Generated at 2022-06-26 08:04:06.142272
# Unit test for function load_translations
def test_load_translations():
    dirname = './translations'
    if os.path.isdir(dirname):
        load_translations(dirname)
    else:
        print('The translation directory is not exist.')


# Generated at 2022-06-26 08:04:08.975664
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    load_translations(resource_filename(Requirement.parse('mine'), 'pystache/tests/locale'))
    locale = Locale.get('en_US')
    text = locale.pgettext(context='c', message='a')
    assert(text=='b'), "test_Locale_pgettext: failed"


# Generated at 2022-06-26 08:04:12.452971
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/zhaodong/Downloads/zhaodong_git/tornado/tornado/locale")
    print('...Over...')


# Generated at 2022-06-26 08:04:20.427559
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    try:
        load_gettext_translations(os.getcwd() + r"/test/test_gettext_locale", "test")
    except:
        assert False, "An exception occurred while test function load_gettext_translations."
    else:
        assert True, "The function load_gettext_translations did not work correctly."


# Generated at 2022-06-26 08:04:26.493509
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Run a test and check if it returns the correct result
    assert get('en').format_day(datetime.datetime(2000, 1, 1)) == 'Saturday, January 1'


# Generated at 2022-06-26 08:04:29.976480
# Unit test for function load_translations
def test_load_translations():
    my_dir = os.path.dirname(os.path.abspath(__file__))
    load_translations(my_dir)



# Generated at 2022-06-26 08:04:31.111011
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("C:\Git\Projects\Tornado\tornado\locale", "en_US")



# Generated at 2022-06-26 08:04:34.468973
# Unit test for function load_translations
def test_load_translations():
    load_translations("../../../examples/locale/")
    print(_supported_locales)
    result = "en_US" in _supported_locales
    assert result == True



# Generated at 2022-06-26 08:04:35.268578
# Unit test for function load_translations
def test_load_translations():
    test_directory = "./locale"
    load_translations(test_directory)


# Generated at 2022-06-26 08:05:23.732654
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    locale_0 = Locale.get("en_US")
    result = locale_0.pgettext("msg", "Hello")
    assert result == "Hello"


# Generated at 2022-06-26 08:05:36.488657
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # msgid 'Slides'
    # msgid_plural 'Slides'
    # msgstr[0] 'Slides'
    # msgstr[1] 'Slides'
    class MockTranslations(object):
        def pgettext(self, context, single, plural=None, amount=None):
            return "Slides"
    t = MockTranslations()
    values = ['Slides', 'Slides', 'Slides', 'Slides', 'Slides']

    for use_gettext in [True, False]:
        for i in range(5):
            load_translations({"en": t}) if not use_gettext else load_gettext_translations('.', 'messages')
            locale = get()
            print (locale.pgettext('slide_class', 'Slides'), values[i])


# Generated at 2022-06-26 08:05:39.402472
# Unit test for function load_translations
def test_load_translations():
    load_translations(os.path.dirname(__file__) + "/locale")
    locale_0 = get()
    assert locale_0.translate("sign in") == "sign in"


# Generated at 2022-06-26 08:05:42.437161
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    pass


# Generated at 2022-06-26 08:05:52.388601
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    law_translation = 'закон'
    good_translation = 'хороший'

    class GettextLocale_:
        def __init__(self, code: str, translations: gettext.NullTranslations):
            self.ngettext = translations.ngettext
            self.gettext = translations.gettext

        def pgettext(
            self,
            context: str,
            message: str,
            plural_message: Optional[str] = None,
            count: Optional[int] = None,
        ) -> str:
            if self.translations:
                gen_log.warning("pgettext is not supported by CSVLocale")
            return self.translate(message, plural_message, count)


# Generated at 2022-06-26 08:06:05.214129
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale("en_US")
    date_1 = datetime.datetime.utcnow() + datetime(hour=2,minute=30)
    date_2 = datetime.datetime.utcnow() + datetime(hour=6,minute=30)
    date_3 = datetime.datetime.utcnow() + datetime(hour=18,minute=30)
    date_4 = datetime.datetime.utcnow() + datetime(hour=1,minute=30)
    print(locale.format_date(date_1))
    print(locale.format_date(date_2))
    print(locale.format_date(date_3))
    print(locale.format_date(date_4))

if __name__ == '__main__':
    test_Loc

# Generated at 2022-06-26 08:06:14.494022
# Unit test for method list of class Locale
def test_Locale_list():
    locale_0 = get("en-US")
    test_case_1 = locale_0.list(["A", "B", "C"])
    assert test_case_1 == "A, B and C"
    print("Testcase 1 passed.")
    test_case_2 = locale_0.list(["A", "B"])
    assert test_case_2 == "A and B"
    print("Testcase 2 passed.")
    test_case_3 = locale_0.list(["A"])
    assert test_case_3 == "A"
    print("Testcase 3 passed.")


# Generated at 2022-06-26 08:06:19.107269
# Unit test for function load_translations
def test_load_translations():
    dir = "./translations"
    locale = "en_US"
    load_translations(dir)
    code = "I love you"
    # Test one code
    assert _translations[locale]["unknown"][code] == "I love you"


# Generated at 2022-06-26 08:06:24.206752
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # load the gettext locale es_ES from /usr/share/locale
    load_gettext_translations("/usr/share/locale", "es_ES")

_COLLAPSE = re.compile(r"[\s\xa0]+")



# Generated at 2022-06-26 08:06:33.544708
# Unit test for function load_translations
def test_load_translations():
    import time
    load_translations('../tornado/locale')
    print(get('ja').translate("%(name)s liked this","%(name)s liked this",2))
    start = time.time()
    for i in range(0,1000):
        get('ja').translate("%(name)s liked this","%(name)s liked this",2)
        get('ja').translate("%(name)s liked this","%(name)s liked this",1)
    end = time.time()
    print("Test of load_translations: 1000 times")
    print("Average time costed: " + str((end-start)/2000))


# Generated at 2022-06-26 08:07:14.546489
# Unit test for function load_translations
def test_load_translations():
    # Testing
    assert os.path.exists(os.path.join(os.path.curdir, 'locale'))


# Generated at 2022-06-26 08:07:23.914196
# Unit test for method format_date of class Locale

# Generated at 2022-06-26 08:07:27.964987
# Unit test for method list of class Locale
def test_Locale_list():
    locale_0 = get("fr")
    lst = [u"A", u"B", u"C"]
    expected = u"A, B et C"
    assert locale_0.list(lst) == expected


# Generated at 2022-06-26 08:07:29.307721
# Unit test for function load_translations
def test_load_translations():
    load_translations('locale')


# Generated at 2022-06-26 08:07:34.006223
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/Users/zhangchao/github/lib/tornado/i18n", "mydomain")


# Generated at 2022-06-26 08:07:41.097318
# Unit test for method list of class Locale
def test_Locale_list():
    # Test for list of length 0
    assert (locale_0.list([]) == "")
    # Test for list of length 1
    assert (locale_0.list(["I"]) == "I")
    # Test for list of length > 1
    assert (locale_0.list(["I", "you"]) == "I and you")

# Unit  test for method translate of class Locale

# Generated at 2022-06-26 08:07:53.548379
# Unit test for function load_translations
def test_load_translations():
    dir_0 = "./data"
    load_translations(dir_0)
    print(list(_translations.keys()))
    print(list(_translations["en_US"].keys()))
    print(list(_translations["en_US"]["unknown"].keys()))
    print(_translations["en_US"]["unknown"]["I love you"])
    print(_translations["en_US"]["unknown"]["%(name)s liked this"])
    print(list(_translations["en_PT"].keys()))
    print(list(_translations["en_PT"]["unknown"].keys()))
    print(_translations["en_PT"]["unknown"]["I love you"])

# Generated at 2022-06-26 08:07:58.359361
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # Locale() is tested in test_case_0()
    # CSVLocale.__init__() also is tested in test_case_0()
    locale_0 = get()
    # Locale.translate() is tested in test_case_0()
    # CSVLocale.translate() is tested in test_case_0()
    return


if __name__ == "__main__":
    test_case_0()
    test_CSVLocale_translate()

# Generated at 2022-06-26 08:08:05.243824
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    default_locale = _default_locale
    for code in _supported_locales:
        _default_locale = code
        locale = get(code)
        trans_str = locale.pgettext("context", "hello")
        assert isinstance(trans_str, str)

        not_exist_str = locale.pgettext("context_not_exist", "hello_not_exist")
        assert isinstance(not_exist_str, str)
    _default_locale = default_locale


# Generated at 2022-06-26 08:08:17.672443
# Unit test for method format_day of class Locale