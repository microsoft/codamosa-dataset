

# Generated at 2022-06-26 08:02:39.207475
# Unit test for method format_date of class Locale
def test_Locale_format_date():

    locale = Locale('en_US')
    date = datetime.datetime.utcnow()
    gmt_offset = -1
    relative = True
    shorter = False
    full_format = False

    def test(date_pt, full_format_pt):
        relative1 = True
        shorter1 = False
        full_format1 = False

        def test_case_0():
            dst = locale.format_date(date, gmt_offset, relative1, shorter1, full_format1)
            dst_pt = locale.format_date(date_pt, gmt_offset, relative1, shorter1, full_format1)
            assert dst == dst_pt

        def test_case_1():
            dst = locale.format_date(date, gmt_offset, relative, shorter1, full_format1)


# Generated at 2022-06-26 08:02:42.738715
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    value_0 = locale_0.friendly_number(10)
    print("value friendly_number:" + value_0)


# Generated at 2022-06-26 08:02:46.772258
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Create an object of class Locale
    locale_0 = Locale()
    # Apply method friendly_number
    result = locale_0.friendly_number(int(1))
    print(result)


# Generated at 2022-06-26 08:02:58.732469
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime, timedelta
    from time import time

    def _format(t: float, s: str) -> bool:
        assert get().format_date(t) == s
        return True

    assert _format(1410417047, "3 minutes ago")
    assert _format(1410417049, "now")
    assert _format(1410417046, "1 minute ago")
    assert _format(1410415184, "5 hours ago")
    assert _format(1410322047, "yesterday")
    assert _format(1409817047, "July 14 at 5:50 pm")
    assert _format(1409817051, "July 14, 2014 at 5:50 pm")

    # Test that dates in the future work

# Generated at 2022-06-26 08:03:11.098767
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_format_date = get()
    # unit_case1
    print(locale_format_date.format_date(1468922173, 0, True, False, False))

    # unit_case2
    print(locale_format_date.format_date(1468922173, 0, False, False, False))

    # unit_case3
    print(locale_format_date.format_date(1468922173, 0, False, False, True))

    # unit_case4
    print(locale_format_date.format_date(1468922173, 0, True, True, False))

    # unit_case5
    print(locale_format_date.format_date(1468922173, 0, False, True, False))

    # unit_case6

# Generated at 2022-06-26 08:03:23.007147
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    translation_0 = get("pt_BR")
    translation_1 = get("pt_BR")
    translation_2 = get("pt_BR")
    translation_3 = get("pt_BR")
    translation_4 = get("pt_BR")
    translation_5 = get("pt_BR")
    translated_0 = translation_0.pgettext("pt_BR", "Shared in")
    translated_1 = translation_1.pgettext("pt_BR", "Shared with")
    translated_2 = translation_2.pgettext("pt_BR", "Shared with")
    translated_3 = translation_3.pgettext("pt_BR", "Shared with")
    translated_4 = translation_4.pgettext("pt_BR", "Shared with")
    translated_5 = translation_5.pgettext

# Generated at 2022-06-26 08:03:27.253922
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    try:
        translation_dir_path = os.path.dirname(os.path.abspath(__file__))
        translation_dir_path = os.path.join(translation_dir_path, "data")
        load_gettext_translations(translation_dir_path, "tornado")
    except Exception as e:
        print(e)



# Generated at 2022-06-26 08:03:41.756188
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(os.path.expanduser("~/Downloads/tornado-4.5.3/tornado/translations"), "tornado")
    for lang in os.listdir(os.path.expanduser("~/Downloads/tornado-4.5.3/tornado/translations")):
        if lang.startswith("."):
            continue  # skip .svn, etc
        if os.path.isfile(os.path.join(os.path.expanduser("~/Downloads/tornado-4.5.3/tornado/translations"), lang)):
            continue

# Generated at 2022-06-26 08:03:53.731045
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    global _default_locale
    global _supported_locales
    global _use_gettext
    global _translations
    _default_locale = "fa"
    _translations = {_default_locale: {}}
    _supported_locales = frozenset(list(_translations.keys()) + [_default_locale])
    _use_gettext = False

    locale = Locale.get(_default_locale)
    result = locale.format_day(date = datetime.datetime(2000, 12, 12), gmt_offset = 1, dow = True)
    assert result == "Tuesday, دسامبر 12"

    result = locale.format_day(date = datetime.datetime(2000, 12, 12), gmt_offset = 1, dow = False)

# Generated at 2022-06-26 08:03:57.023376
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("locale", "tornado")
    # print(locale.translate("Sign out","it_IT"))


# Generated at 2022-06-26 08:04:27.010545
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_format_date_1 = Locale.get("en")
    date_0 = datetime.datetime(2018, 3, 15, 7, 10, 0)
    assert locale_format_date_1.format_date(date_0) == "just now"
    date_1 = datetime.datetime(2018, 3, 15, 7, 10, 0)
    assert locale_format_date_1.format_date(date_1, gmt_offset=0, relative=False, shorter=False, full_format=False) == "March 15 at 7:10am"
    date_2 = datetime.datetime(2018, 3, 15, 7, 10, 0)

# Generated at 2022-06-26 08:04:31.191085
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/tianzhan/PycharmProjects/tornado_project/lib/python3.7/site-packages/tornado/_locale_data')


# Generated at 2022-06-26 08:04:44.774003
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale("en")
    # Case 0: current time
    actual = locale.format_date(datetime.datetime.utcnow())
    expected = "just now"
    assert actual == expected
    # Case 1: 1 day ago
    actual = locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(days=1))
    expected = "yesterday"
    assert actual == expected
    # Case 2: 1 day ago
    actual = locale.format_date(datetime.datetime.utcnow() - datetime.timedelta(days=30))
    expected = "1 month ago"
    assert actual == expected
    # Case 3: 1 day ago

# Generated at 2022-06-26 08:04:49.723205
# Unit test for function load_translations
def test_load_translations():
    '''
    # load_translations(path: str, encoding: Optional[str] = None) -> None
    # Loads translations from CSV files in a directory.
    '''
    try:
        load_translations('\\temp\\tornado_local')
        test_case_0()
    except Exception:
        print('Failed to load_translations')


# Generated at 2022-06-26 08:04:55.227147
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("tests/locale", "tornado_locale")
    locale_get = get("zh_CN")
    assert locale_get._translations != {}
    assert len(locale_get._translations.keys()) == 1
    assert "zh_CN" in locale_get._translations.keys()


# Generated at 2022-06-26 08:05:06.177552
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Case 0
    print(
        Locale(
            "en_US"
        ).format_day(
            datetime.datetime(2020, 1, 8),
            0,
            True
        ),
        end="\n" * 2
    )

    # Case 1
    print(
        Locale(
            "en_US"
        ).format_day(
            datetime.datetime(2020, 1, 8),
            0,
            False
        ),
        end="\n" * 2
    )

    # Case 2
    print(
        Locale(
            "en_US"
        ).format_day(
            datetime.datetime(2020, 1, 8),
            None,
            True
        ),
        end="\n" * 2
    )


# Generated at 2022-06-26 08:05:17.381872
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    test_date = datetime.datetime(2016, 5, 18)
    # test_date.year == 2016
    # test_date.month == 5
    # test_date.day == 18
    # test_date.weekday() == 2, which represents Wednesday
    expected_result = "Wednesday, May 18"
    assert Locale.get("en").format_day(test_date) == expected_result
    assert Locale.get("en_US").format_day(test_date) == expected_result
    assert Locale.get("zh_CN").format_day(test_date) == expected_result
    assert Locale.get("fa").format_day(test_date) == expected_r

# Generated at 2022-06-26 08:05:24.597056
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_1 = Locale('en')
    format_day_1 = locale_1.format_day
    print(format_day_1)
    # Convert unix timestamp to datetime
    tm = 1443314456
    day = datetime.datetime.fromtimestamp(tm)
    format_day_1(day)

if __name__ == "__main__":
    import doctest

    doctest.testmod()
    # test_case_0()
    # test_Locale_format_day()

# Generated at 2022-06-26 08:05:27.864545
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    assert locale_0.pgettext("context_0", "message_0") == "translation_0"


# Generated at 2022-06-26 08:05:39.055176
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en")
    date = datetime.datetime(2017, 1, 1, 7, 30, 0)
    gmt_offset = 0
    dow = True
    result = locale.format_day(date, gmt_offset, dow)
    if result != "Sunday, January 1":
        print("Error: test_Locale_format_day test #0 failed")
    locale = Locale.get("en")
    date = datetime.datetime(2017, 1, 1, 7, 30, 0)
    gmt_offset = 0
    dow = False
    result = locale.format_day(date, gmt_offset, dow)
    if result != "January 1":
        print("Error: test_Locale_format_day test #1 failed")
    locale = Locale.get("en")


# Generated at 2022-06-26 08:06:17.151062
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Create five Locale objects

    # Create a list containing the number expected output
    expected = ['1', '12', '123', '1,234', '12,345', '123,456', '1,234,567', '12,345,678']
    for n, e in zip(range(1, 9), expected):
        # Create a Locale object
        locale_1 = Locale("en")
        # Get the actual output
        actual = locale_1.friendly_number(n)
        # Assert expected output equals actual output
        assert actual == e
        # Print result
        print("Input: ", n)
        print("Expected: ", e)
        print("Actual: ", actual)
        print("==============================")


# Generated at 2022-06-26 08:06:19.870342
# Unit test for function load_translations
def test_load_translations():
    # define the test path
    test_path = "./test_data/translations.csv"
    load_translations(test_path)


# Generated at 2022-06-26 08:06:22.938813
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale")
    test_case_0()


# Generated at 2022-06-26 08:06:31.109452
# Unit test for function load_translations
def test_load_translations():
    print("*" * 50)
    print("Unit test for load_translations")
    load_translations("locales")
    assert(len(_translations) >= 1)
    print("\tPassed!\n")
    print("*" * 50)


# Generated at 2022-06-26 08:06:33.115032
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_obj = get()
    assert None != str(type(locale_obj.format_day(0)))


# Generated at 2022-06-26 08:06:42.481786
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Test cases
    test_cases = [
        (0, "0"),
        (10, "10"),
        (100, "100"),
        (1000, "1,000"),
        (10000, "10,000"),
        (100000, "100,000"),
        (1000000, "1,000,000"),
        (10000000, "10,000,000"),
        (100000000, "100,000,000"),
        (1000000000, "1,000,000,000"),
    ]
    # Run test
    for test_case in test_cases:
        value = test_case[0]
        expected = test_case[1]
        locale = Locale("en")
        actual = locale.friendly_number(value)
        assert actual == expected

# if __name__ == "__main__

# Generated at 2022-06-26 08:06:45.863844
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Create object of class Locale
    locale_0 = Locale()

    # Set the parameter for locale_0.format_date
    date = str(datetime.datetime.utcnow())
    gmt_offset = 0
    relative = True
    shorter = False
    full_format = False
    # Call method format_date of class Locale
    locale_0.format_date(date, gmt_offset, relative, shorter, full_format)


if __name__ == "__main__":
    test_case_0()
    test_Locale_format_date()

# Generated at 2022-06-26 08:06:53.319624
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = Locale.get("en")
    print(locale_0.friendly_number(1234567))
    print(locale_0.friendly_number(1))
    print(locale_0.friendly_number(12))
    print(locale_0.friendly_number(123))
    print(locale_0.friendly_number(1234))
    print(locale_0.friendly_number(12345))
    print(locale_0.friendly_number(123456))



# Generated at 2022-06-26 08:06:56.520525
# Unit test for function load_translations
def test_load_translations():
    load_translations("test_load_translations", "utf-8")


# Generated at 2022-06-26 08:07:02.835012
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    try:
        locale = Locale("en")
        assert locale.friendly_number(123) == "123"
        assert locale.friendly_number(1234) == "1,234"
        assert locale.friendly_number(12345) == "12,345"
        assert locale.friendly_number(1234567) == "1,234,567"
    except Exception as e:
        raise e


# Generated at 2022-06-26 08:07:36.272712
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = Locale.get('en')
    n = locale_0.friendly_number(123456)
    print(n)
    assert n == '123,456'

    locale_1 = Locale.get('fr')
    n = locale_1.friendly_number(123456)
    print(n)
    assert n == '123456'


# Generated at 2022-06-26 08:07:46.615524
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = get()
    time_0 = locale_0.format_date(datetime.datetime.now(), 0, True, False, False)
    time_1 = locale_0.format_date(datetime.datetime.now(), 0, False, False, False)
    time_2 = locale_0.format_date(datetime.datetime.now(), 0, True, False, True)
    time_3 = locale_0.format_date(datetime.datetime.now(), 0, True, True, False)
    time_4 = locale_0.format_date(datetime.datetime.now(), 0, False, True, False)
    print(time_0)
    print(time_1)
    print(time_2)
    print(time_3)
    print(time_4)
   

# Generated at 2022-06-26 08:07:58.688851
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # First, create a locale
    locale = Locale('en')
    # Compute the result using friendly_number
    result = locale.friendly_number(3)
    # Check the result
    if(result != '3'):
        raise AssertionError

    # Compute the result using friendly_number
    result = locale.friendly_number(3003)
    # Check the result
    if(result != '3,003'):
        raise AssertionError

    # Compute the result using friendly_number
    result = locale.friendly_number(10000)
    # Check the result
    if(result != '10,000'):
        raise AssertionError

    print ("Testcase for friendly_number passed!")


# Generated at 2022-06-26 08:08:01.786125
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Test case 0:
    assert friendly_number('en', 1000) == '1,000'


if __name__ == '__main__':
    print(friendly_number('en', 1000))

# Generated at 2022-06-26 08:08:13.719536
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    #directory = "./repo-tornado/tornado/locale"
    #domain = "tornado.po"
    directory = "C:\\Users\\c2412\\Tornado\\Tornado-master\\repo-tornado\\tornado\\locale"
    domain = "test.po"
    
    # Assert
    load_gettext_translations(directory, domain)

    # Assert 2
    local_0 = get()
    assert local_0.translate("%(name)s liked this") == "A %(name)s le gustó esto"
    
    # Assert 3
    local_1 = get("es_LA")
    assert local_1.translate("%(name)s liked this") == "A %(name)s le gustó esto"



# Generated at 2022-06-26 08:08:16.701303
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/Users/shawn/Documents/Tornado/Tornado-5.1.1/tornado/locale', 'tornado')


# Generated at 2022-06-26 08:08:28.849261
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Set the unit test environment
    import sys
    reload(sys)
    sys.setdefaultencoding('UTF8')
    # Set the unit test data
    locale_string = "en_US"
    context_string = "context_string"
    message_string = "The total number of payments is %(count)s"
    plural_message_string = "The total number of payments is %(count)s"
    count_value = 3
    expect_value = "The total number of payments is 3"
    test_locale = Locale.get(locale_string)
    # Execute the unit test
    result = test_locale.pgettext(context_string, message_string, plural_message_string, count_value)
    # Verify the unit test result

# Generated at 2022-06-26 08:08:37.130834
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    print(Locale.get('en').format_day(datetime.datetime(2019, 4, 22)))
    print(Locale.get('en').format_day(datetime.datetime(2019, 4, 22), gmt_offset=2, dow=False))
    print(Locale.get('fa').format_day(datetime.datetime(2019, 4, 22)))
    print(Locale.get('fa').format_day(datetime.datetime(2019, 4, 22), gmt_offset=2, dow=False))


# Generated at 2022-06-26 08:08:38.875612
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/Users/charlie/workspace/repositories/tornado/translations/pt_BR/LC_MESSAGES", "mydomain")
    print("There are two supported languages" + str(_supported_locales))


# Generated at 2022-06-26 08:08:40.135100
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:09:22.372828
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    test_locale = "ar"
    locale = Locale(test_locale)
    test_date = datetime.datetime(2020, 2, 1)
    result = locale.format_day(test_date, 0)
    expected = LOCALE_NAMES.get(test_locale, {}).get("day")
    if result != expected:
        print("Error formatting day for locale", test_locale)
        print("Expected:", expected)
        print("Got:", result)
        raise Exception("Test failed")
    print("Successfully formatted day for locale", test_locale)

if __name__ == "__main__":
    test_Locale_format_day()

# Generated at 2022-06-26 08:09:31.055563
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Get datetime now and GMT offset
    now = datetime.datetime.now()
    gmt_offset = now.utcoffset().total_seconds() / 60
    now = now.replace(hour=0, minute=0, second=0, microsecond=0)

    # Test for the case that dow == True
    for lang in list(_translations.keys()):
        locale_0 = get(lang)
        result_0 = locale_0.format_day(now, gmt_offset, dow=True)
        result_1 = locale_0._weekdays[now.weekday()] + ", " + locale_0._months[now.month - 1] + " " + str(now.day)
        assert result_0 == result_1
    
    # Test for the case that dow == False

# Generated at 2022-06-26 08:09:31.878026
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    _ = get().translate
    _("1")
    return


# Generated at 2022-06-26 08:09:37.620279
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    # assert format_day returns str
    assert isinstance(locale_0.format_day(date=datetime.datetime.now(), dow=True), str)
    # assert format_day returns str
    assert isinstance(locale_0.format_day(date=datetime.datetime.now(), dow=False), str)


# Generated at 2022-06-26 08:09:39.885571
# Unit test for function load_translations
def test_load_translations():
    directory = "I:\\Projects\\python_tornado_study\\tornado\\locale\\"
    load_translations(directory)
    print(_translations)


# Generated at 2022-06-26 08:09:40.698055
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    pass


# Generated at 2022-06-26 08:09:42.048832
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    # test 1
    return locale_0.format_day


# Generated at 2022-06-26 08:09:56.634087
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    date_0 = datetime.datetime(2019, 3, 17, 0, 0, 0)
    gmt_offset_0 = 0
    dow_0 = True
    output_0 = "Sunday, March 17"
    res_0 = locale_0.format_day(date_0, gmt_offset_0, dow_0)
    assert res_0 == output_0

    locale_1 = get("zh_CN")
    date_1 = datetime.datetime(2019, 3, 17, 0, 0, 0)
    gmt_offset_1 = 0
    dow_1 = True
    output_1 = "2019\u5e7405\u670817\u65e5"

# Generated at 2022-06-26 08:10:03.049455
# Unit test for function load_translations
def test_load_translations():
    load_translations(
        directory="/home/ting/Dropbox/workspace/tornado/tests/locale/", encoding="utf-8")
    locale_0 = get()




# Generated at 2022-06-26 08:10:06.112207
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Locale.pgettext(context, message, plural_message=None, count=None)
    pass
