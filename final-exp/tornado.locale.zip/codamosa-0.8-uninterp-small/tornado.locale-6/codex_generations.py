

# Generated at 2022-06-26 08:02:21.443599
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    cls = Locale
    test_case_0()
    test_case_1 = Locale.get_closest('fa')
    test_case_2 = Locale.get_closest('en')
    test_case_3 = cls.get('en_US')
    test_case_4 = cls.get('en')
    test_case_5 = cls.get_closest('fa', 'en')


# Generated at 2022-06-26 08:02:25.980582
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Test number values
    friendly_number1 = Locale.friendly_number(123)
    friendly_number2 = Locale.friendly_number(1234)
    friendly_number3 = Locale.friendly_number(12345)
    friendly_number4 = Locale.friendly_number(123456)


# Generated at 2022-06-26 08:02:31.796403
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get_closest("en_US")
    date = datetime.datetime(2017, 12, 25)
    assert locale.format_day(date, 0, True) == "Monday, December 25"
    assert locale.format_day(date, 0, False) == "December 25"


# Generated at 2022-06-26 08:02:36.765707
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    print("# Unit test for method pgettext of class Locale")
    iterable_0 = get_supported_locales()
    for arg_0 in iterable_0:
        test_case_0(arg_0)
    print('passed')


# Generated at 2022-06-26 08:02:46.935180
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime(2020, 11, 1)
    test_case_0 = Locale.get("en_US").format_day(date, gmt_offset = 0, dow = True)
    assert test_case_0 == "Sunday, November 1", "test_Locale_format_day: test_case_0"

    test_case_1 = Locale.get("en_US").format_day(date, gmt_offset = 0, dow = False)
    assert test_case_1 == "November 1", "test_Locale_format_day: test_case_1"


# Generated at 2022-06-26 08:02:49.176143
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.friendly_number(self, value) == str(value)



# Generated at 2022-06-26 08:02:59.896629
# Unit test for function load_translations
def test_load_translations():
    load_translations("./file_locale", "utf-8")
    translation_default = _translations.get(_default_locale).get("unknown").get("Sign in")
    translation_spanish = _translations.get("es_LA").get("unknown").get("Sign in")
    translation_spanish_plural = _translations.get("es_LA").get("plural").get("Sign in")
    translation_spanish_singular = _translations.get("es_LA").get("singular").get("Sign in")
    print(translation_default)
    print(translation_spanish)
    print(translation_spanish_plural)
    print(translation_spanish_singular)


# Generated at 2022-06-26 08:03:00.491833
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    pass


# Generated at 2022-06-26 08:03:12.287635
# Unit test for function load_translations
def test_load_translations():
    from tornado.util import b
    import os
    import shutil
    import tempfile
    import unittest
    from tornado.testing import AsyncTestCase, ExpectLog, gen_test

    class LoadTranslationsTest(unittest.TestCase):
        def setUp(self):
            self.directory = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.directory)

        def assertSupportedLocales(self, expected_locales: Iterable[str]) -> None:
            self.assertEqual(
                frozenset(expected_locales), get_supported_locales() 
            )


# Generated at 2022-06-26 08:03:20.684934
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    global _translations
    global _supported_locales
    global _use_gettext
    _translations = {}
    _supported_locales = {}
    _use_gettext = False
    load_gettext_translations("./locale", "mydomain")
    print("translations:")
    print(str(_translations))
    print("_supported_locales:")
    print(str(_supported_locales))
    print("_use_gettext:")
    print(str(_use_gettext))


# Generated at 2022-06-26 08:03:46.526222
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert load_gettext_translations("x","x") == None


# Generated at 2022-06-26 08:03:53.090080
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    a_date = datetime.datetime.strptime("2016-01-12 00:00:00", "%Y-%m-%d %H:%M:%S")
    locale_1 = Locale.get("ja")
    locale_1.format_day(a_date)
    locale_1.format_day(a_date, dow = False)



# Generated at 2022-06-26 08:04:06.040704
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    def _pgettext(context: str, message: str, plural_message: Optional[str] = None, count: Optional[int] = None) -> str:
        if plural_message is None:
            plural_message = message + 's'
        if count is None:
            i = message.find('|')
            count = 1 if i == -1 else int(message[i + 1:])
        return locale.pgettext(context, message, plural_message, count)
    locale = Locale.get('en_US')
    message = 'A |1 apple'
    assert(_pgettext(locale, 'test.string', message, 1) == 'A apple')
    assert(_pgettext(locale, 'test.string', message, 2) == 'A apples')


# Generated at 2022-06-26 08:04:17.800209
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    date_0 = datetime.datetime(2019,8,21,0,0,0)
    date_1 = datetime.datetime(2019,8,22,1,1,2)
    date_2 = datetime.datetime(2019,8,22,13,13,13)
    date_3 = datetime.datetime(2019,8,23,0,0,0)
    date_4 = datetime.datetime(2019,8,30,0,0,0)
    date_5 = datetime.datetime(2019,8,21,0,50,0)
    date_6 = datetime.datetime(2019,8,21,0,0,50)
    date_7 = datetime.datetime(2019,8,21,1,1,2)
    date_8 = datetime

# Generated at 2022-06-26 08:04:22.327922
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(os.path.join(os.path.dirname(__file__),"locale"), "tornado")



# Generated at 2022-06-26 08:04:31.548055
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import unittest
    import random

    class LocaleTester(unittest.TestCase):
        def test_pgettext(self):

            # test case 0
            print('Test Case 0')
            print('Expected: {}'.format('Virhe'))
            print('Actual: {}'.format(locale_0.pgettext('fi')))
            return

    unit_test_0 = LocaleTester()
    unit_test_0.test_pgettext()


# Generated at 2022-06-26 08:04:33.113401
# Unit test for function load_translations
def test_load_translations():
    load_translations("locale")
    locale_1 = get()


# Generated at 2022-06-26 08:04:35.763638
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    def test_case_0():
        load_gettext_translations('./locale','helloworld')



# Generated at 2022-06-26 08:04:44.232627
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_1 = Locale.get('zh_CN')
    date_0 = datetime.datetime.utcnow()
    #print(date_0)
    #print(locale_1.format_date(date_0))
    date_1 = date_0
    date_1.replace(hour=13)
    date_1.replace(minute=10)
    print(locale_1.format_date(date_1))


# Generated at 2022-06-26 08:04:55.324406
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    format_day_locale = get("en_US")
    # test case 1
    gmt_offset_1 = 0
    dow_1 = True
    date_1 = datetime.datetime.utcnow()
    test_case_format_day_1 = format_day_locale.format_day(date_1, gmt_offset_1, dow_1)
    # test case 2
    gmt_offset_2 = 0
    dow_2 = False
    date_2 = datetime.datetime.utcnow()
    test_case_format_day_2 = format_day_locale.format_day(date_2, gmt_offset_2, dow_2)
    # test case 3
    gmt_offset_3 = 1
    dow_3 = True
    date_3 = datetime

# Generated at 2022-06-26 08:05:20.706985
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test case 1:
    #   Objective: test when some fields are missing in the dicts
    #   Expected result: raise exception
    translations = {}
    test_locale = CSVLocale("zh_CN", translations)
    context = "context"
    message = "message"
    plural_message = "plural_message"
    count = 10
    with pytest.raises(AssertionError):
        test_locale.pgettext(context, message)
        test_locale.pgettext(context, message, plural_message)
        test_locale.pgettext(context, message, plural_message, count)
    # Test case 2:
    #   Objective: test when the context and message are not in the dicts
    #   Expected result: return the message and plural_message

# Generated at 2022-06-26 08:05:28.244124
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    date_0 = datetime.datetime(2019, 4, 17, 9, 5, 10)
    gmt_offset_0 = 0
    locale_1 = get()
    date_1 = datetime.datetime(2018, 1, 10, 10, 42, 10)
    gmt_offset_1 = 0
    dow_0 = True
    dow_1 = False
    assert locale_0.format_day(date_0, gmt_offset_0, dow_0) == 'Wednesday, April 17'
    assert locale_0.format_day(date_1, gmt_offset_1, dow_1) == 'January 10'
    locale_2 = get('zh_CN')
    date_2 = datetime.datetime(2018, 6, 1, 20, 42, 10)
   

# Generated at 2022-06-26 08:05:33.105458
# Unit test for function load_translations
def test_load_translations():
    test_locale = get()

    # Case 1: Check locale is not none
    assert test_locale

    # Case 2: Check if function has successful return.
    try:
        load_translations(".")
    except:
        assert False


# Generated at 2022-06-26 08:05:43.094491
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import sys
    import shutil
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from tornado.testing import AsyncHTTPTestCase, gen_test, LogTrapTestCase
    from tornado.web import Application, RequestHandler
    from tornado.util import PY3
    from tornado.log import app_log
    load_gettext_translations('C:\GitHub\Tornado\v4.5.3\tornado\locale\data', 'tornado')



# Generated at 2022-06-26 08:05:45.616338
# Unit test for function load_translations
def test_load_translations():
    directory = "locale"
    encoding = None
    load_translations(directory, encoding)


# Generated at 2022-06-26 08:05:53.247825
# Unit test for function load_translations
def test_load_translations():
    # If a translation file can be loaded successfully, the dictionnary _translations should
    # not be empty.
    # It also tests if a translation file not ending with .csv can be loaded successfully.
    if _translations:
        del _translations["fr"]
        del _translations["en_US"]
        del _translations["und"]
        assert not _translations, "The dictionnary _translations should be empty."
    dir_path = os.path.dirname(os.path.realpath(__file__))
    dir_path = os.path.join(os.path.dirname(dir_path), "locale")
    load_translations(dir_path)
    assert _translations, "The dictionnary _translations should not be empty."
    # It also tests if the language code is valid
    code

# Generated at 2022-06-26 08:05:54.780444
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    Locale.load_translations("./test_locale")
    locale_0 = get()
    locale_0.pgettext("context", "test")


# Generated at 2022-06-26 08:05:56.288830
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('.', 'test')


# Generated at 2022-06-26 08:05:59.888808
# Unit test for function load_translations
def test_load_translations():
    load_translations('./data_test/test_locale_0')

if __name__ == "__main__":
    test_load_translations()


# Generated at 2022-06-26 08:06:05.260931
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    failure = 0
    locale_0 = get()
    context_0 = ""
    message_0 = ""
    try:
        locale_0.pgettext(context_0, message_0)
    except NotImplementedError as error:
        failure = 1
    assert failure == 1


# Generated at 2022-06-26 08:06:27.859422
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')


# Generated at 2022-06-26 08:06:33.864007
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    locale_1 = get("fr")
    locale_2 = get("zh_CN")
    locale_3 = get("en_US")

    date = datetime.datetime(2018, 12, 31)
    gmt_offset = 0
    dow = True

    print("English:", locale_3.format_day(date, gmt_offset, dow))
    print("French:", locale_1.format_day(date, gmt_offset, dow))
    print("Chinese:", locale_2.format_day(date, gmt_offset, dow))



# Generated at 2022-06-26 08:06:48.090597
# Unit test for method format_date of class Locale

# Generated at 2022-06-26 08:06:54.263202
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    # Declare test data
    date_0 = datetime.datetime(2020, 3, 13)
    gmt_offset_0 = 0
    dow_0 = True
    # Call function to test
    test_result_0 = locale_0.format_day(date_0, gmt_offset_0, dow_0)
    # Assert result
    assert test_result_0 == "Friday, March 13"


# Generated at 2022-06-26 08:06:59.508161
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    global _use_gettext
    _use_gettext = False
    load_gettext_translations("./locale/","test")
    assert _use_gettext == True


# Generated at 2022-06-26 08:07:05.460346
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Test error case
    try:
        locale_1 = get()
        locale_1.friendly_number(None)
    except TypeError as e:
        assert type(e) == TypeError
    
    # Test expected case
    locale_2 = get()
    assert locale_2.friendly_number(1234567) == '1,234,567'
    

# Generated at 2022-06-26 08:07:09.340671
# Unit test for function load_translations
def test_load_translations():
    load_translations("locales")
    locale_0 = get()


# Generated at 2022-06-26 08:07:17.323808
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale.get('en')
    test_date = datetime.datetime.strptime("Fri, 10 Jul 2020 11:40:00 GMT", '%a, %d %b %Y %H:%M:%S %Z')
    print(locale.format_date(test_date, -240))
    test_date = datetime.datetime.now()
    print(locale.format_date(test_date, -240))


# Generated at 2022-06-26 08:07:26.856222
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    time_obj = time.time()
    time_gm = time.gmtime(time_obj)
    time_delta = time.timezone
    time_local_obj = time_gm - time_delta
    time_local_obj_delta = time.localtime(time_local_obj)
    locale_1 = Locale('en')
    locale_1.format_date(time_obj, time_delta)
    locale_1.format_date(time_local_obj, 0)
    os.system("pause")


test_Locale_format_date()

# Generated at 2022-06-26 08:07:29.543975
# Unit test for function load_translations
def test_load_translations():
    load_translations("/locale_data/zh_CN")
    print("Translations are %s" % _translations)



# Generated at 2022-06-26 08:08:06.241090
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale_test_data/")


# Generated at 2022-06-26 08:08:10.268373
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = Locale('en_US')
    dt = datetime.datetime.utcnow()
    # print(dt)
    # print(locale_0.format_day(dt))
    return True


# Generated at 2022-06-26 08:08:22.115854
# Unit test for function load_translations
def test_load_translations():
    # load translations
    load_translations("/home/lzj/work/tornado-6.0.4/tornado/locale")

    # get locale
    locale_0 = get()
    assert "sign in" == locale_0.translate("sign in")

    # get locale
    locale_1 = get("en")
    assert "sign in" == locale_1.translate("sign in")

    # get locale
    locale_2 = get("zh")
    assert "我的账号" == locale_2.translate("My account")

    # get locale
    locale_3 = get("ko")
    assert "로그인" == locale_3.translate("Sign in")

    # get locale
    locale_4 = get("zh_CN")

# Generated at 2022-06-26 08:08:34.554706
# Unit test for function load_translations
def test_load_translations():
    from tornado import testing
    import _locale_data
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import random
    import os
    import shutil
    import tempfile
    import json

    data = [
        "en , en, , ,en",
        "en_US , en,United States , ,en_US",
        "en_US_POSIX , en,United States,POSIX ,en_US_POSIX",
        "es , es, , ,es",
        "es_AR , es,Argentina , ,es_AR",
    ]

    @testing.gen_test
    def test_case():
        dir_path = tempfile.mkdtemp(dir="/tmp")


# Generated at 2022-06-26 08:08:37.600668
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    def func():
        locale_0 = get()
        print(locale_0.pgettext())
    func()


# Generated at 2022-06-26 08:08:39.087741
# Unit test for function load_translations
def test_load_translations():
    load_translations("../locale")


# Generated at 2022-06-26 08:08:52.846661
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    gmt_offset = 0
    dow = True
    date = datetime.datetime.utcfromtimestamp(time.time())
    now_year = date.year
    now_month = date.month
    now_day = date.day
    now_hour = date.hour
    now_minute = date.minute
    
    # normal case
    test_0 = Locale.get("en").format_day(date, gmt_offset, dow)
    expect_0 = "{} {}, {}".format(calendar.month_name[now_month], str(now_day), now_year)
    if test_0 == expect_0:
        print("Passed")
    else:
        print("Failed")
        print("Expected:", expect_0)
        print("Get:", test_0)
   

# Generated at 2022-06-26 08:08:59.280896
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    local_date = datetime.datetime(2019, 1, 22)
    locale_0 = get()
    print(locale_0.format_day(local_date, dow=True))

if __name__ == "__main__":
    test_Locale_format_day()
    # test_case_0()
    print("Test finished")

# Generated at 2022-06-26 08:09:00.405566
# Unit test for function load_translations
def test_load_translations():
    load_translations("translations")
    locale_1 = get()



# Generated at 2022-06-26 08:09:02.099736
# Unit test for function load_translations
def test_load_translations():
    # Test file name in the current directory
    load_translations('./')


# Generated at 2022-06-26 08:09:36.213365
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    locale_0.format_day()


# Generated at 2022-06-26 08:09:37.932416
# Unit test for function load_translations
def test_load_translations():
    directory = "test_tornado.txt"
    load_translations(directory)



# Generated at 2022-06-26 08:09:43.823105
# Unit test for method format_date of class Locale

# Generated at 2022-06-26 08:09:56.692944
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    datetime_0 = datetime.datetime(9, 1, 3)
    result_0 = locale_0.format_day(datetime_0)
    print(result_0)
    datetime_0 = datetime.datetime(1149, 7, 6)
    result_0 = locale_0.format_day(datetime_0)
    print(result_0)
    datetime_0 = datetime.datetime(1730, 7, 28)
    result_0 = locale_0.format_day(datetime_0)
    print(result_0)
    datetime_0 = datetime.datetime(1143, 10, 9)
    result_0 = locale_0.format_day(datetime_0)
    print(result_0)
    datetime_

# Generated at 2022-06-26 08:10:03.942624
# Unit test for function load_translations
def test_load_translations():
    """Load translation function for test.
    """
    directory = "path/to/project/"
    encoding = 'utf-8'
    load_translations(directory)
    # TODO: Add assertion.
    pass



# Generated at 2022-06-26 08:10:11.308667
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Build a demo Locale object
    locale = Locale("en")

    # Build a datetime object
    date = datetime.datetime(2020, 5, 27, 20, 56, 56, 739625)

    # Run the format_day method
    locale.format_day(date, gmt_offset=0, dow=True)

    # assert equal 
    assert locale.format_day(date, gmt_offset=0, dow=True) == "Wednesday, May 27"
    return True


# Generated at 2022-06-26 08:10:20.726531
# Unit test for function load_translations
def test_load_translations():
    import os
    import os.path
    import glob
    import shutil

    # Setup
    TRANSLATIONS_DIR = 'translations'
    os.makedirs(TRANSLATIONS_DIR, exist_ok=True)
    files = glob.glob(os.path.join(TRANSLATIONS_DIR, '*.csv'))
    for f in files:
        os.unlink(f)

    # Test

# Generated at 2022-06-26 08:10:21.930204
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory="translations", domain="tornado")



# Generated at 2022-06-26 08:10:33.161890
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # "default" is `None`
    example_0 = Locale.pgettext('example', 'example', None, None)
    assert example_0 == 'example'
    # context is `None`
    context_0 = Locale.pgettext(None, 'abc', 'def', 123)
    assert context_0 == 'abc'
    # non-positive `count` is not allowed
    count_0 = Locale.pgettext('count', 'count', 'count', 0)
    assert count_0 == 'count'
    count_1 = Locale.pgettext('count', 'count', 'count', -123)
    assert count_1 == 'count'
    # one plural form
    count_2 = Locale.pgettext('count', 'count', 'count', 2)

# Generated at 2022-06-26 08:10:38.763884
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    testdir = "D:/Tornado_Tutorial_Code/tornado-5.1.1/tornado/test/locale"
    testdomain = "helloworld"
    load_gettext_translations(testdir, testdomain)
    print('OK2')
    