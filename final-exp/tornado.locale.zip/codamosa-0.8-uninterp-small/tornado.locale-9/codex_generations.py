

# Generated at 2022-06-26 08:02:37.235059
# Unit test for function load_translations
def test_load_translations():
    import csv
    import os
    import traceback

    global _translations
    global _supported_locales
    _translations = {}
    directory = '.'
    for path in os.listdir(directory):
        if not path.endswith(".csv"):
            continue
        locale, extension = path.split(".")
        if not re.match("[a-z]+(_[A-Z]+)?$", locale):
            gen_log.error(
                "Unrecognized locale %r (path: %s)",
                locale,
                os.path.join(directory, path),
            )
            continue
        full_path = os.path.join(directory, path)
        # python 3: csv.reader requires a file open in text mode.
        # Specify an encoding to avoid dependence on $LANG environment variable

# Generated at 2022-06-26 08:02:38.313837
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    test_case_0()


# Generated at 2022-06-26 08:02:42.689331
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/purnendu/py3_ws_tornado4.5/test_translations", "test_mydomain")
    _translations = {}


# Generated at 2022-06-26 08:02:43.820860
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert False


# Generated at 2022-06-26 08:02:48.916344
# Unit test for function load_translations
def test_load_translations():
    directory = './locale'
    encoding = 'utf-8-sig'
    load_translations(directory, encoding)
    print('Supported locales:', get_supported_locales())
    print(_translations['en_US']['plural'])


# Generated at 2022-06-26 08:02:52.667782
# Unit test for function load_translations
def test_load_translations():
    '''
    # Test condition 0: testing if the translations are loaded correctly
    # Expected result: raise FileNotFoundError
    '''
    try: 
        load_translations('.')
    except:
        pass #
    iterable_0 = get_supported_locales()
    assert(iterable_0 != ['en_US'])

    # Test condition 0: testing if the translations are loaded correctly
    # Expected result: raise FileNotFoundError
    class TestPath(object):
        def __init__(self, path):
            self.path = path
        def listdir(self):
            return self.path
    try:
        load_translations(TestPath(''))
    except FileNotFoundError:
        pass #
    iterable_0 = get_supported_locales()

# Generated at 2022-06-26 08:03:04.515790
# Unit test for method format_date of class Locale
def test_Locale_format_date():
  # Test #0:
  try:
    # Should fail to format a date with the default format
    disallowed_format = ''
    locale = Locale('en')
    locale.format_date(date=datetime.datetime.utcnow(), format=disallowed_format)
    print('FAIL: format_date allowed format "%s" when it should not.' % disallowed_format)
  except:
    print('PASS: format_date disallows default format.')

  # Test #1:

# Generated at 2022-06-26 08:03:07.993357
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Test if this function throws an exception
    try:
        load_gettext_translations("directory", "domain")
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-26 08:03:14.453757
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    L = Locale.get('en')

    assert L.friendly_number(100) == '100'

    assert L.friendly_number(1000) == '1,000'

    assert L.friendly_number(1000000) == '1,000,000'

    assert L.friendly_number(10000000) == '10,000,000'

    assert L.friendly_number(123123123) == '123,123,123'


# Generated at 2022-06-26 08:03:23.514156
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    local_date = datetime.datetime.utcnow()
    kwargs = {
        "date": local_date,
        "gmt_offset": 0,
        "dow": True
    }
    expected_0 = "Monday, January 22"
    result_0 = Locale.get_closest("en").format_day(**kwargs)
    if result_0 == expected_0:
        print("test_Locale_format_day: PASS")
    else:
        print("test_Locale_format_day: FAIL")




# Generated at 2022-06-26 08:04:00.071194
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Initialize an object Locale
    locale_0 = Locale.get("en")
    # Test if the method behaves as expected
    value_0 = 1
    value_1 = locale_0.friendly_number(value_0)
    assert value_1 == "1"


# Generated at 2022-06-26 08:04:09.051212
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # TEST CASE: Test format_date
    locale = Locale.get("en_US")
    date_format = locale.format_date(datetime.datetime.now())
    print(date_format)
    # TEST CASE: Test format_date with a date in the future
    cur_date = datetime.datetime.now()
    a5_mins_date = cur_date + datetime.timedelta(minutes=5)
    date_format = locale.format_date(a5_mins_date)
    print(date_format)
    # TEST CASE: Test format_date with a date in the past
    a5_mins_date = cur_date - datetime.timedelta(minutes=5)
    date_format = locale.format_date(a5_mins_date)

# Generated at 2022-06-26 08:04:16.504180
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # A mocker fixture is required here because we define Locale as an abstract
    # class in order to prevent users from instantiating them directly.
    # Unfortunately, that also prevents nose from doing it for us, so we need
    # to patch it. We don't want to make the class instantiable in production
    # code.
    with mock.patch("__main__.Locale"):
        locale = Locale("en")
        assert locale.friendly_number(value = 1) == "1"


# Generated at 2022-06-26 08:04:27.513332
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """Unit test for method format_date of class Locale"""
    from datetime import datetime
    from tornado.util import ObjectDict
    import pytz

    local_object = get_closest("zh", "zh-CN")
    fake_date_0 = ObjectDict(month=3, day=26, year=2019, hour=15, minute=3, second=20, microsecond=0, tzinfo=pytz.utc)
    print(local_object.format_date(fake_date_0))
    fake_date_1 = ObjectDict(month=5, day=5, year=2019, hour=22, minute=23, second=32, microsecond=0, tzinfo=pytz.utc)
    print(local_object.format_date(fake_date_1))


# Unit test

# Generated at 2022-06-26 08:04:30.556459
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/travis/build/Shangyu-CVTE/Tornado/tornado")


# Generated at 2022-06-26 08:04:35.919106
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    name_0 = "test_Locale_friendly_number_0"
    locale_0 = Locale.get('en_US')
    value_0 = 100
    value_1 = locale_0.friendly_number(value_0)
    # Unit test for class Locale: method friendly_number (0)




# Generated at 2022-06-26 08:04:39.418949
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    Locale_instance_0 = Locale('')
    Locale_instance_0.friendly_number(arg_0)


# Generated at 2022-06-26 08:04:50.807240
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    global _translations
    global _supported_locales
    global _use_gettext
    _translations = {}
    directory = "tests/translations"
    domain = "mydomain"
    for lang in os.listdir(directory):
        if lang.startswith("."):
            continue  # skip .svn, etc
        if os.path.isfile(os.path.join(directory, lang)):
            continue
        try:
            os.stat(os.path.join(directory, lang, "LC_MESSAGES", domain + ".mo"))
            _translations[lang] = gettext.translation(
                domain, directory, languages=[lang]
            )
        except Exception as e:
            gen_log.error("Cannot load translation for '%s': %s", lang, str(e))
           

# Generated at 2022-06-26 08:04:55.799147
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    _Locale_0 = Locale.get_closest('en', 'en_US')
    int_0 = 1
    str_0 = _Locale_0.friendly_number(int_0)
    print(str_0)


# Generated at 2022-06-26 08:05:06.453168
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    _supported_locales = set()
    _default_locale = "en_US"
    _translations = {}
    _use_gettext = False

    _supported_locales.add(_default_locale)

    translations = dict()
    translations["en_US"] = {}
    translations["en_US"].setdefault("plural", {})["January"] = "January"
    translations["en_US"].setdefault("plural", {})["February"] = "February"
    translations["en_US"].setdefault("plural", {})["March"] = "March"
    translations["en_US"].setdefault("plural", {})["April"] = "April"
    translations["en_US"].setdefault("plural", {})["May"] = "May"
    translations["en_US"].set

# Generated at 2022-06-26 08:05:29.617992
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get('en_US')
    assert locale.friendly_number(12345) == "12,345"


# Generated at 2022-06-26 08:05:34.352898
# Unit test for function load_translations
def test_load_translations():

    # Load the hard coded csv file into the local memory.
    load_translations("./locale")
    iterable_0 = get_supported_locales()
    if "en_US" in iterable_0:
        return True
    else:
        return False


# Generated at 2022-06-26 08:05:42.088685
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
  # The following call to pgettext is suppose to raise a TypeError.
  # Please add your code here.
    try:
        Locale.pgettext("str", "str", count=None)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 08:05:45.035925
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    try:
        load_gettext_translations(os.getcwd()+"/locale","messages")
        print(_translations)
    except Exception as e:
        print(str(e))



# Generated at 2022-06-26 08:05:47.936696
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = Locale.get_closest("")
    str_0 = locale_0.friendly_number(1)
    if str_0 != "1":
        raise RuntimeError


# Generated at 2022-06-26 08:05:48.907529
# Unit test for method list of class Locale
def test_Locale_list():
    pass


# Generated at 2022-06-26 08:06:04.546090
# Unit test for function load_translations
def test_load_translations():
    global _translations
    global _supported_locales
    test_dir = "test_dir"
    test_path = "test_path.csv"
    test_locale = "fr_FR"
    test_extension = "csv"
    test_full_path = os.path.join(test_dir, test_path)
    test_encoding = "utf-8"
    test_row = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"]
    test_row_filtered = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l"]
    test_plural_indicator = "test_plural_indicator"

# Generated at 2022-06-26 08:06:07.945240
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = Locale.get("en_US")
    assert type(locale_0.friendly_number(int(0))) is str


# Generated at 2022-06-26 08:06:09.813212
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    raise NotImplementedError("Test case for friendly_number of class Locale is not implemented")



# Generated at 2022-06-26 08:06:17.478270
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get_closest('ar_AR')
    assert locale.friendly_number(100) == "100"

    locale = Locale.get_closest('en_US')
    assert locale.friendly_number(100) == "100"
    assert locale.friendly_number(1000) == "1,000"
    assert locale.friendly_number(10000) == "10,000"
    assert locale.friendly_number(100000) == "100,000"


# Generated at 2022-06-26 08:07:01.103326
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    date = datetime.datetime.utcnow()
    locale = Locale.get_closest('en')
    gmt_offset = 0
    relative = True
    shorter = False
    full_format = False
    result = locale.format_date(date, gmt_offset, relative, shorter, full_format)


# Generated at 2022-06-26 08:07:04.062835
# Unit test for function load_translations
def test_load_translations():
    load_translations("test/test_locale_csv/")
    locales = get_supported_locales()
    assert locales == ['en_US', 'es', 'es_LA']


# Generated at 2022-06-26 08:07:12.069037
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    """
    Unit test for function load_gettext_translations.
    """
    _ = get_supported_locales()
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    if isinstance(cur_dir, bytes):
        cur_dir = cur_dir.decode()
    load_gettext_translations(cur_dir + "/locale", "tornado")
    iterable_0 = get_supported_locales()
    _ = iterable_0[0]
    _ = get_supported_locales()
    _ = get_supported_locales()
    _ = get_supported_locales()
    _ = get_supported_locales()



# Generated at 2022-06-26 08:07:17.573762
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/Users/lucas/Documents/my_project/tornado_demo/project/tornado/locale/', 'tornado')
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-26 08:07:25.322764
# Unit test for function load_translations
def test_load_translations():
    global _translations
    global _supported_locales
    global _default_locale
    if not _translations.__contains__("es_LA"):
        raise RuntimeError("Did not load translations into _translations")
    #gen_log.error("Cannot assert that default locale is es_LA directly, it is %r", _default_locale)
    #if not _default_locale == "es_LA":
    #    raise RuntimeError("_default_locale is not \"es_LA\"")
    if not _supported_locales.__contains__("es_LA"):
        raise RuntimeError("Did not load translations into _supported_locales")
    if not _supported_locales.__contains__("en_US"):
        raise RuntimeError("Did not load translations into _supported_locales")
   

# Generated at 2022-06-26 08:07:27.107510
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert "100,000" == Locale.get('en').friendly_number(100000)



# Generated at 2022-06-26 08:07:29.933215
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Call get_supported_locales()
    function_return_value = get_supported_locales()
    iterable_0 = function_return_value

# Generated at 2022-06-26 08:07:44.291045
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    test_Locale_format_day_date = datetime.datetime(2025, 12, 7)
    test_Locale_format_day_gmt_offset = -300
    test_Locale_format_day_dow = False
    test_Locale_format_day_instance = Locale(test_Locale_format_day_code)
    test_Locale_format_day_result = test_Locale_format_day_instance.format_day(test_Locale_format_day_date, test_Locale_format_day_gmt_offset, test_Locale_format_day_dow)
    if(test_Locale_format_day_result == test_Locale_format_day_expect):
        return True
    else:
        return False
test_Locale_format_day_

# Generated at 2022-06-26 08:07:46.155791
# Unit test for function load_translations
def test_load_translations():
    directory = 'C:/Users/etripathi/Desktop/Tornado/locale_data'
    load_translations(directory)



# Generated at 2022-06-26 08:07:49.210207
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    Locale.friendly_number(Locale, 11)
    Locale.friendly_number(Locale, 22)
    Locale.friendly_number(Locale, 33)

# Generated at 2022-06-26 08:08:31.421481
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    test_0 = Locale.get("en_US")
    test_1 = test_0.format_day(datetime.datetime.utcnow())
    # Assert that the function returns a string



# Generated at 2022-06-26 08:08:40.499366
# Unit test for method format_date of class Locale
def test_Locale_format_date():

    # Arguments
    instance_0 = None
    date_0 = datetime.datetime.now()
    gmt_offset_0 = 0
    relative_0 = True
    shorter_0 = False
    full_format_0 = False
    # Return type
    # Return type
    # Return type
    # Return type
    # Return type
    # Return type
    # Return type

    # Return type
    # Return type
    return

    # Return type
    # Return type
    # Return type
    # Return type
    # Return type
    # Return type
    # Return type


# Generated at 2022-06-26 08:08:49.357137
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    def assert_equals(cls_0, date_0, gmt_offset_0, relative_0, shorter_0, full_format_0):
        assert_equals_0 = cls_0.format_date(date=date_0, gmt_offset=gmt_offset_0, relative=relative_0, shorter=shorter_0, full_format=full_format_0)


# Generated at 2022-06-26 08:09:00.577844
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = Locale.get("fr_FR")

    # Test with first argument value: datetime.datetime(2020, 7, 25, 22, 16, 7, 836028)
    # Test with second argument value: 0
    # Test with third argument value: True
    actual_0 = locale_0.format_day(datetime.datetime(2020, 7, 25, 22, 16, 7, 836028))
    # Check for expected evaluation
    assert actual_0 == 'samedi, juillet 25', "Expected different evaluation result"

    # Test with first argument value: datetime.datetime(2020, 7, 25, 22, 16, 7, 836028)
    # Test with second argument value: 0
    # Test with third argument value: True

# Generated at 2022-06-26 08:09:02.284913
# Unit test for function load_translations
def test_load_translations():
    load_translations(directory = "./en_US.csv")


# Generated at 2022-06-26 08:09:04.201951
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    test_load_gettext_translations_0()


# Generated at 2022-06-26 08:09:08.141583
# Unit test for function load_translations
def test_load_translations():
    directory = "tornado/_locale_data/en"
    try:
        load_translations(directory)
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-26 08:09:11.552279
# Unit test for function load_translations
def test_load_translations():
    directory="C:\\Users\\seanh\\Desktop\\GIS\\Dev\\tornado\\locale"
    load_translations(directory, "utf-8")
    print(get_supported_locales())


# Generated at 2022-06-26 08:09:14.385292
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/ruiyan/Documents/Git/Test/python-tornado/tornado/locale")



# Generated at 2022-06-26 08:09:19.516951
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    first = Locale.get_closest()
    date = datetime.datetime(2020, 1, 22)
    gmt_offset = 0
    dow = True
    result = first.format_day(date, gmt_offset, dow)
    return


# Generated at 2022-06-26 08:10:07.328405
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    sep = os.path.sep
    test_path = "{}{}{}{}{}{}{}{}{}{}".format("test", sep, "test_d3", sep, "test_d3_format_date", sep, "test_format_date", sep, "test_format_date", sep)
    load_csv_translations(test_path, encoding="utf8")
    date = 1
    gmt_offset = 0
    relative = True
    shorter = False
    full_format = False
    locale_obj = Locale.get("pt_BR")
    res = locale_obj.format_date(date, gmt_offset, relative, shorter, full_format)
    assert res == "January 01"


# Generated at 2022-06-26 08:10:10.185831
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import datetime
    locale = Locale.get('en')
    locale.format_day(datetime.datetime(1,1,1), 1)


# Generated at 2022-06-26 08:10:12.185715
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/home/pwxcoo/Projects/Tornado/tornado/locale', 'tornado')


# Generated at 2022-06-26 08:10:13.290752
# Unit test for function load_translations
def test_load_translations():
    load_translations()


# Generated at 2022-06-26 08:10:21.122035
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    test_locale_0 = Locale.get_closest("en_US")
    test_locale_0.format_date(0.0)
    test_locale_0.format_date(0.0, gmt_offset=0)
    test_locale_0.format_date(0.0, gmt_offset=0, relative=True)
    test_locale_0.format_date(0.0, gmt_offset=0, relative=True, shorter=False)
    test_locale_0.format_date(0.0, gmt_offset=0, relative=True, shorter=False, full_format=False)



# Generated at 2022-06-26 08:10:30.086826
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    __date = datetime.datetime.utcnow()
    __gmt_offset = 0
    __relative = True
    __shorter = False
    __full_format = False
    local_0 = get_closest('en')
    ret_0 = local_0.format_date(__date, __gmt_offset, __relative, __shorter, __full_format)
    # assert 10 < ret_0 < 100


# Generated at 2022-06-26 08:10:41.318070
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime.utcnow()
    _ = Locale("en_US").translate
    Locale("en_US").format_day(date, 0, True)
    _("%(weekday)s, %(month_name)s %(day)s") % {
                "month_name": _("January"),
                "weekday": _("Monday"),
                "day": str(date.day),
            }
    Locale("en_US").format_day(date, 0, False)
    _("%(month_name)s %(day)s") % {
                "month_name": _("January"),
                "day": str(date.day),
            }



# Generated at 2022-06-26 08:10:46.588654
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    iterable_0 = get_supported_locales()
    messages = {}
    code = iterable_0[0]
    locale = CSVLocale(code, messages)
    locale.translate("message", "plural_message", 1)
    locale.translate("message", None, None)
    test_CSVLocale_translate()


# Generated at 2022-06-26 08:10:50.888707
# Unit test for function load_translations
def test_load_translations():
    assert list(get_supported_locales()) == [], "Empty get_supported_locales()"
    load_translations("/Users/almukhambetov/locale")
    get("ru_RU")
    get("de_DE")



# Generated at 2022-06-26 08:10:55.467356
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    assert (Locale('en_us')).format_date(datetime.datetime.utcnow()) == '1 second ago'
