

# Generated at 2022-06-26 08:02:36.478755
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    locale_0 = CSVLocale("en", {"one": {"value_0": "value_0"}})
    str_0 = locale_0.translate("value_0")
    print('Translation of "value_0" is ' + str_0)
    if str_0 != "value_0":
        raise Exception('Wrong translation of "value_0"')


# Generated at 2022-06-26 08:02:43.710890
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    import os
    print('start to test Locale_format_date')
    os.environ['TZ'] = 'Asia/Shanghai'  # (UTC+08:00)
    time.tzset()
    d = datetime.datetime.fromtimestamp(time.time() - 60*60)
    print(d)
    locale_0 = get()
    print(locale_0.format_date(d))



# Generated at 2022-06-26 08:02:46.555139
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    gettext.textdomain("cairo-dock-core")
    _ = gettext.gettext

    locale = GettextLocale("en", gettext.NullTranslations())
    assert locale.pgettext("law", "right") == _("right")
    assert locale.pgettext("good", "right") == _("right")
    assert locale.pgettext("law", "right", "rights", 2) == _("rights")
    assert locale.pgettext("good", "right", "rights", 2) == _("rights")

# Generated at 2022-06-26 08:02:51.232855
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/louis/Documents/GitHub/kindergarten/kindergarten/locale", "tornado")
    print(_translations["es_VE"].gettext("Please input valid user id!"))


# Generated at 2022-06-26 08:02:57.472536
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Directory
    directory = "E:\MyCodes\PycharmProjects\TornadoLearning\venv\lib\site-packages\tornado\locale\zh_CN"
    # Domain
    domain = "tornado"
    load_gettext_translations(directory, domain)
    print(_translations)
    print(_supported_locales)
    print(_use_gettext)


# Generated at 2022-06-26 08:03:09.536190
# Unit test for constructor of class Locale
def test_Locale():
    test_data = [
        # (code, name, rtl)
        ('en', 'English', False),
        ('en_US', 'English (United States)', False),
        ('fa', 'Persian', True),
        ('ar', 'Arabic', True),
        ('he', 'Hebrew', True),
        ('cn', 'Unknown', False),
    ]
    for (code, name, rtl) in test_data:
        locale = Locale(code)
        assert locale.code == code
        assert locale.name == name
        assert locale.rtl == rtl


# Generated at 2022-06-26 08:03:10.778546
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    pass


# Generated at 2022-06-26 08:03:22.676520
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():

    csv_locale = CSVLocale("en", {
        "plural": {"A": "B", "C": "D"},
        "singular": {"E": "F", "G": "H"},
    })

    assert csv_locale.pgettext("context1", "A") == "B"
    assert csv_locale.pgettext("context1", "C") == "D"
    assert csv_locale.pgettext("context1", "E", count=2) == "F"
    assert csv_locale.pgettext("context1", "G", count=2) == "H"
    assert csv_locale.pgettext("context1", "A", count=2) == "B"

# Generated at 2022-06-26 08:03:26.146531
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    test_locale_0 = Locale("en_US")
    test_result = test_locale_0.pgettext("context", "arg_message", "arg_plural_message", 123)
    assert (test_result == "arg_message")


# Generated at 2022-06-26 08:03:37.357652
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    def friendly_number_helper(value, result):
        print("friendly_number tests for value:  ", value, "result: ", result)
        assert (get().friendly_number(value) == result)
        print("Passed!")

    test_case_0()

    friendly_number_helper(11, "11")
    friendly_number_helper(11000, "11,000")
    friendly_number_helper(11000000, "11,000,000")



# Generated at 2022-06-26 08:03:52.938472
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    date = datetime.datetime(2017, 7, 10)
    dow = True
    # test_format_day(locale_0, date, dow)



# Generated at 2022-06-26 08:04:02.414103
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Create a fake directory
    import os, shutil
    os.mkdir('fake_dir')
    # Copy a fake mo file to fake_dir
    shutil.copyfile('fake_mo.mo','fake_dir/fake_mo.mo')
    # Run load_gettext_translations
    load_gettext_translations('fake_dir','fake_mo')
    # Check that _translations is set correctly
    # Check that _supported_locales is set correctly
    assert _translations['fake_dir'] != None
    assert _supported_locales == {'fake_dir', 'en_US'}



# Generated at 2022-06-26 08:04:05.907417
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get('en_US')
    assert locale.friendly_number(1234) == '1,234'


# Generated at 2022-06-26 08:04:09.096167
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    locale_0.friendly_number(11)


# Generated at 2022-06-26 08:04:18.750582
# Unit test for function load_gettext_translations

# Generated at 2022-06-26 08:04:22.905797
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    domain = "zh.domain"
    directory = "./lang"
    load_gettext_translations(directory, domain)



# Generated at 2022-06-26 08:04:28.699298
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    print("Run test_Locale_format_day()")
    # Create an instance of class Locale
    locale_0 = get()
    # Call the method format_day
    date_0 = datetime.datetime(2019, 7, 22)
    locale_0.format_day(date_0)


# Generated at 2022-06-26 08:04:31.389497
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = 'translations/mo'
    domain = 'commons'
    load_gettext_translations(directory, domain)


# Generated at 2022-06-26 08:04:44.982620
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test case 0
    locale_0 = get()
    date_0 = datetime.datetime.utcnow()
    gmt_offset_0 = 0
    relative_0 = True
    shorter_0 = False
    full_format_0 = False
    try:
        locale_0.format_date(date_0, gmt_offset_0, relative_0, shorter_0, full_format_0)
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

    # Test case 1
    locale_0 = get()
    date_0 = datetime.datetime.utcnow()
    gmt_offset_0 = 0
    relative_0 = True
    shorter_0 = False
    full_format_0 = True

# Generated at 2022-06-26 08:04:47.911637
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Test for argument directory as an empty string
    try:
        load_gettext_translations('', 'mydomain')
    except Exception as e:
        print(str(e))


# Generated at 2022-06-26 08:05:27.899495
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import tornado.ioloop
    import time
    class TestHandler(tornado.web.RequestHandler):
        def get(self):
            self.write(
                _("Hello, world") + "<br>"
            )
            self.write(
                _("test") + "<br>"
            )
            self.write(
                _("%(name)s is %(age)d years old") % {'name': 'Mary', 'age': 13} + "<br>"
            )
            self.write(
                _("%s is %d years old") % ('Susan', 18) + "<br>"
            )
            self.write(
                ngettext("%d cat", "%d cats", 0) % 0 + "<br>"
            )

# Generated at 2022-06-26 08:05:39.054949
# Unit test for method format_day of class Locale
def test_Locale_format_day():

    # Test case 1
    date = datetime.datetime(2018, 1, 22)
    dow = True
    gmt_offset = -120
    result = Locale.get(code = 'en').format_day(date = date, gmt_offset = gmt_offset, dow = dow)
    assert result == "Monday, January 22"

    # Test case 2
    date = datetime.datetime(2018, 1, 22)
    dow = False
    gmt_offset = -120
    result = Locale.get(code = 'en').format_day(date = date, gmt_offset = gmt_offset, dow = dow)
    assert result == "January 22"

    # Test case 3
    date = datetime.datetime(2018, 1, 22)
    dow = True
    gmt_offset = -120

# Generated at 2022-06-26 08:05:53.309412
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    mock_date = datetime.datetime.utcnow()
    mock_date = datetime.datetime.utcfromtimestamp(mock_date.timestamp())
    now = datetime.datetime.utcnow()
    now = datetime.datetime.utcfromtimestamp(now.timestamp())
    mock_gmt_offset = 0
    assert isinstance(get().format_date(mock_date,mock_gmt_offset),str)
    assert get().format_date(mock_date,mock_gmt_offset,relative=True) == "1 second ago"

# Generated at 2022-06-26 08:05:56.197637
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    assert locale_0.friendly_number(123456789) == '123,456,789'

#
# CSVLocale
#



# Generated at 2022-06-26 08:05:58.030343
# Unit test for constructor of class Locale
def test_Locale():
    assert(True)


# Generated at 2022-06-26 08:06:10.623322
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert get().friendly_number(123456) == '123,456'
    assert get().friendly_number(123456789) == '123,456,789'
    assert get().friendly_number(1) == '1'
    assert get().friendly_number(123) == '123'
    assert get().friendly_number(1234) == '1,234'
    assert get().friendly_number(12345) == '12,345'
    assert get().friendly_number(123456) == '123,456'
    assert get().friendly_number(1234567) == '1,234,567'
    assert get().friendly_number(12345678) == '12,345,678'
    assert get().friendly_number(123456789) == '123,456,789'


# Generated at 2022-06-26 08:06:14.483546
# Unit test for constructor of class Locale
def test_Locale():
    locale_0 = Locale("test_code")
    locale_1 = Locale("test_code")
    locale_2 = Locale("test_code")
    test_case_0()

test_Locale()



# Generated at 2022-06-26 08:06:16.945120
# Unit test for function load_translations
def test_load_translations():
    load_translations("test_locale/")

test_load_translations()
test_case_0()



# Generated at 2022-06-26 08:06:24.631748
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    msg = "this is a test message"
    ctx = "this is a test context"
    ctx += "\x04" # add control character at end
    context_test = ctx + msg
    assert context_test == f'{ctx}{msg}' # check that the control character was added
    locale = get()
    p = locale.pgettext(ctx, msg)
    assert p == msg # check that the context was stripped


# Generated at 2022-06-26 08:06:30.006990
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():

    # Test case 0
    locale_0 = get()
    result_0 = locale_0.friendly_number(123)
    # check if do not throw exception
    assert True

# Generated at 2022-06-26 08:07:50.384958
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = Locale("en_US")
    if locale_0.code == "en_US":
        assert locale_0.friendly_number(1234) == "1,234"
    else:
        assert locale_0.friendly_number(1234) == "1234"

# Unit tests for method list of class Locale

# Generated at 2022-06-26 08:08:02.484749
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('./locale/', 'tornado-django')
    locale_1 = get('pt_BR')
    locale_2 = get('ko_KR')
    locale_3 = get('hu_HU')
    locale_4 = get('en_US')
    test_str = 'Sign out'
    assert locale_1.translate(test_str) == 'Sair'
    assert locale_2.translate(test_str) == '로그아웃'
    assert locale_3.translate(test_str) == 'Kilépés'
    assert locale_4.translate(test_str) == test_str


# Generated at 2022-06-26 08:08:14.954157
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():

    locale = CSVLocale.get('en')
    # None -> None
    expected = None
    assert (locale.pgettext(None, None) == expected)
    # Bad context -> context
    expected = "BAD"
    assert (locale.pgettext("BAD", None) == expected)
    # Bad string -> string
    expected = "BAD"
    assert (locale.pgettext(None, "BAD") == expected)
    # Bad plural -> plural
    expected = "BAD"
    assert (locale.pgettext(None, None, plural="BAD") == expected)
    # Bad count -> 1
    expected = "BAD"
    assert (locale.pgettext(None, "BAD", plural="BAD", count=None) == expected)

    # A simple context with no

# Generated at 2022-06-26 08:08:19.863544
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    global _translations
    global _supported_locales
    global _use_gettext
    load_gettext_translations("./locale", "messages")
    assert _translations["en_US"]
    assert _supported_locales == frozenset(["en_US"])
    assert _use_gettext


# Generated at 2022-06-26 08:08:29.101253
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    _test_Locale_friendly_number(1232, '1232')
    _test_Locale_friendly_number(12331, '12,331')
    _test_Locale_friendly_number(1233131, '1,233,131')
    _test_Locale_friendly_number(12333331, '12,333,331')
    _test_Locale_friendly_number(1233333131, '123,333,131')
    _test_Locale_friendly_number(1233333331, '1,233,333,331')


# Generated at 2022-06-26 08:08:32.382152
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./locale"
    domain = "messages"
    test_locale = load_gettext_translations(directory, domain)
    assert not test_locale


# Generated at 2022-06-26 08:08:34.822659
# Unit test for function load_translations
def test_load_translations():
    try:
        load_translations('.')
    except Exception as e:
        raise e
    print("load_translations()")



# Generated at 2022-06-26 08:08:49.095046
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Use the simpler CSV translation method, since gettext doesn't provide
    # an API for translating months and weekdays.
    load_translations(os.path.join(os.path.dirname(__file__), "data"))

    # Create a datetime object to represent the date/time that is to be formatted.
    date_0 = datetime.utcnow()
    date_0 = datetime.datetime(2020, 7, 2, 20, 10, 40)

    # Method Locale.get is used when the locale code is known.
    locale_0 = Locale.get("en")
    s = locale_0.format_date(date_0)
    assert s == "yesterday at 4:10 pm"
    s = locale_0.format_date(date_0, full_format=True)

# Generated at 2022-06-26 08:08:55.320860
# Unit test for function load_translations
def test_load_translations():
    print("start test_load_translations", end='\n')
    # Unit test for function load_translations
    assert os.path.isdir("/Users/yulei/Project/tornado/demos/t/conf")
    if not os.path.isdir("/Users/yulei/Project/tornado/demos/t/conf"):
        assert False
        raise Exception("Directory not exist")
    print("Passed test_load_translations", end='\n')


# Generated at 2022-06-26 08:08:56.998377
# Unit test for function load_translations
def test_load_translations():
    # It's not a good practice to write the test data in the same file as the source code
    translations_dir = 'locale_translations'
    load_translations(translations_dir)


# Generated at 2022-06-26 08:11:34.189947
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    locale_0 = GettextLocale("en")
    context = "context"
    message = "message"
    plural_message = "plural_message"
    count = 1
    result_0 = locale_0.pgettext(context, message, plural_message, count)
    assert result_0 == "message"

test_case_0()
test_GettextLocale_pgettext()

# Generated at 2022-06-26 08:11:37.597258
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    """
    This function test function friendly_number in class Locale
    """
    locale_0 = get()
    assert locale_0.friendly_number(12345) == "12,345"
