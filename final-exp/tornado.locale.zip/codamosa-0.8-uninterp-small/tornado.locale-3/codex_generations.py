

# Generated at 2022-06-26 08:03:06.225569
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    _supported_locales.add('bg_BG')
    _translations.update( {'bg_BG': {'unknown':{'July':u'Юли'}}})
    locale = Locale.get('bg_BG')
    assert locale.format_day(datetime.datetime(1980, 7, 10)) == u'Четвъртък, Юли 10'
    assert locale.format_day(datetime.datetime(1980, 7, 10), dow=False) == u'Юли 10'

# Generated at 2022-06-26 08:03:17.892479
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    class TestLocale(Locale):
        def translate(self, message: str, plural_message: Optional[str] = None,
                      count: Optional[int] = None) -> str:
            return 'translation'

        def pgettext(self, context: str, message: str,
                     plural_message: Optional[str] = None,
                     count: Optional[int] = None) -> str:
            return 'translation'

    locale = TestLocale('code')

    test_date = datetime.datetime.utcnow()
    test_results = []
    test_results.append(locale.format_date(test_date))
    test_results.append(locale.format_date(test_date, relative=False))
    test_results.append(locale.format_date(test_date, shorter=True))

# Generated at 2022-06-26 08:03:28.057997
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # test case 0
    locale_0 = get()
    date_0 = datetime.datetime.utcnow()
    gmt_offset_0 = 0
    relative_0 = True
    shorter_0 = False
    full_format_0 = False
    assert type(locale_0.format_date(date_0, gmt_offset_0, relative_0, shorter_0, full_format_0)) == str
    # test case 1
    locale_1 = get()
    date_1 = datetime.datetime.utcnow()
    gmt_offset_1 = 0
    relative_1 = True
    shorter_1 = False
    full_format_1 = False

# Generated at 2022-06-26 08:03:34.463247
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_cases = [
        (1, "1"),
        (20000, "20,000"),
    ]
    for case in test_cases:
        number, res = case
        l = get()
        assert l.friendly_number(number) == res
    print("Passed Locale.friendly_number test")


# Generated at 2022-06-26 08:03:39.455728
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    #create a Locale object
    l = Locale('en')
    # Month, Day and Year 
    assert l.format_day(datetime.datetime(2016,12,25)) == 'Sunday, December 25'



# Generated at 2022-06-26 08:03:41.652022
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale("en")
    assert locale.friendly_number(100) == "100"


# Generated at 2022-06-26 08:03:53.654876
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    """
    Loads translations from `gettext`'s locale tree

    Locale tree is similar to system's ``/usr/share/locale``, like::

        {directory}/{lang}/LC_MESSAGES/{domain}.mo

    Three steps are required to have your app translated:

    1. Generate POT translation file::

        xgettext --language=Python --keyword=_:1,2 -d mydomain file1.py file2.html etc

    2. Merge against existing POT file::

        msgmerge old.po mydomain.po > new.po

    3. Compile::

        msgfmt mydomain.po -o {directory}/pt_BR/LC_MESSAGES/mydomain.mo
    """
    global _translations
    global _supported_locales
    global _use

# Generated at 2022-06-26 08:04:06.243717
# Unit test for function load_translations
def test_load_translations():
    directory = "./tests/ex_translations/test_load_translations"
    load_translations(directory)
    locale_en = get("en_US")
    locale_en_sing = locale_en.translate("%(name)s liked this", name="aaa")
    assert locale_en_sing == "aaa liked this"
    locale_en_plur = locale_en.translate("%(name)s liked this", name=["aaa", "bbb"], plural_indicator="plural")
    assert locale_en_plur == "aaa and bbb liked this"
    locale_es = get("es_LA")
    locale_es_sing = locale_es.translate("%(name)s liked this", name="aaa")
    assert locale_es_sing == "aaa le gustó esto"
    locale

# Generated at 2022-06-26 08:04:09.602095
# Unit test for method list of class Locale
def test_Locale_list():
    locale_0 = get()
    parts_0 = ["A", "B", "C"]
    ret_0 = locale_0.list(parts_0)
    # Check if ret_0 is equal to "A, B and C"
    if ret_0 == "A, B and C":
        print("test_Locale_list Test Case Passed!")
    else:
        print("test_Locale_list Test Case Failed!")


# Generated at 2022-06-26 08:04:17.533323
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # test case 1
    test_case_1_locale = Locale('de')
    test_case_1_integer = 123456789
    assert test_case_1_locale.friendly_number(test_case_1_integer) == '123456789'
    # test case 2
    test_case_2_locale = Locale('en')
    test_case_2_integer = 1234567
    assert test_case_2_locale.friendly_number(test_case_2_integer) == '123,456,700'


# Generated at 2022-06-26 08:05:33.105708
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    value_0 = 0
    expected_result_0 = "0"
    print("expected_result_0: ", expected_result_0)
    actual_result_0 = locale_0.friendly_number(value_0)
    print("actual_result_0: ", actual_result_0)
    assert actual_result_0 == expected_result_0


# Generated at 2022-06-26 08:05:38.720216
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test Case:
    # self = Locale instance
    # context = "UNKNOWN"
    # message = "UNKNOWN"
    # locale = Locale instance
    # TODO: REPLACE THESE CODE WITH YOUR OWN.
    self = Locale('en_US')
    context = "UNKNOWN"
    message = "UNKNOWN"
    locale = self.get_closest('en_US')

    # Expected Result:
    # result = Locale instance
    
    result = self.pgettext(context, message, plural_message="UNKNOWN", count=5)
    if (result == locale):
        print("PASS")
    else:
        print("FAIL")


# Generated at 2022-06-26 08:05:52.956199
# Unit test for method translate of class CSVLocale

# Generated at 2022-06-26 08:06:05.270535
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    from tornado.escape import native_str
    from tornado.util import u
    '''First try to load English .mo file.'''
    load_gettext_translations("locale", "kojihub")
    locale_0 = get("en_US")
    translated = locale_0.translate("en_US")
    assert translated == "en_US"

    '''Test Chinese .mo file.'''
    locale_1 = get("zh_CN")
    translated = locale_1.translate("en_US")
    assert translated == "en_US"

    '''Test korean .mo file.'''
    locale_2 = get("ko_KR")
    translated = locale_2.translate("en_US")
    assert translated == "en_US"



# Generated at 2022-06-26 08:06:08.272454
# Unit test for method list of class Locale
def test_Locale_list():
    assert len(Locale.get("pt_BR").list(["A", "B", "C"])) == len("A, B e C")


# Generated at 2022-06-26 08:06:10.812419
# Unit test for function load_translations
def test_load_translations():
    load_translations("E:\\Lab\\Tornado-5.0.2\\tornado\\locale\\test_load_translations")


# Generated at 2022-06-26 08:06:16.653101
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    gmt = 0
    dow = True
    date = datetime.datetime.utcnow()
    locale_0.format_day(date, gmt, dow)
    locale_0.format_day(date, gmt)
    locale_0.format_day(date, dow=True)
    locale_0.format_day(date)


# Generated at 2022-06-26 08:06:18.125065
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    pass


# Generated at 2022-06-26 08:06:32.284087
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Edge case 1: value is None
    friendly_number_0 = get().friendly_number(None)
    # Edge case 2: value is integer type
    friendly_number_1 = get().friendly_number(0)
    # Edge case 3: value is integer type, but not whole
    friendly_number_2 = get().friendly_number(3.0)
    # Edge case 4: value is float type, but >=1
    friendly_number_3 = get().friendly_number(7.0)
    # Edge case 5: value is float type, but <1
    friendly_number_4 = get().friendly_number(0.0)
    # Edge case 6: value is float type, but not whole
    friendly_number_5 = get().friendly_number(4.0)
    # Normal case 1: value is negative
    friendly_number

# Generated at 2022-06-26 08:06:42.076291
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    assert locale_0.friendly_number(73) == "73"
    assert locale_0.friendly_number(21) == "21"
    assert locale_0.friendly_number(3001) == "3,001"
    assert locale_0.friendly_number(73) == "73"
    assert locale_0.friendly_number(0) == "0"
    assert locale_0.friendly_number(3001) == "3,001"
    assert locale_0.friendly_number(73) == "73"
    assert locale_0.friendly_number(0) == "0"
    assert locale_0.friendly_number(3001) == "3,001"
    assert locale_0.friendly_number(0) == "0"
    assert locale_0.friendly_number(73)

# Generated at 2022-06-26 08:07:20.512927
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    message = "gettext"
    directory = "./locale"
    domain = "language"
    load_gettext_translations(directory, domain)
    assert get().translate(message) == "переводчик"
    assert get("zh_CN").translate(message) == "翻译"
    assert get("en_US").translate(message) == "gettext"


# Generated at 2022-06-26 08:07:23.620771
# Unit test for function load_translations
def test_load_translations():
    load_translations("locale")


# Generated at 2022-06-26 08:07:30.179379
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    _ = get().translate

    # get input time and time zone
    time_input = time.localtime()
    gmt_input = float(input("Please enter time zone(offset from GMT): "))

    # show input time
    print("Input time: ", time.asctime(time_input))

    # show output time
    print("Output time: ", get().format_day(time_input, gmt_input))


# Generated at 2022-06-26 08:07:44.851205
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # \nTODO: Add test case for method format_date of class Locale

    # Need to call method load_translations
    # Need to call method get_closest
    # Need to call method get
    locale_0 = Locale.get('en')
    date_0 = datetime.datetime.utcnow()
    str_0 = locale_0.format_date(date_0)
    print(str_0)

    # Need to call method load_translations
    # Need to call method get_closest
    # Need to call method get
    locale_0 = Locale.get('en')
    now_0 = datetime.datetime.utcnow()
    days_0 = 0
    str_0 = locale_0.format_date(now_0, days_0)

# Generated at 2022-06-26 08:07:47.038426
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = get()
    assert locale_0.friendly_number(1) == "1"


# Generated at 2022-06-26 08:07:50.336463
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # This test case must be added. 
    locale_0 = get()
    locale_0.friendly_number(1777777)
    locale_0.friendly_number(18000000)
    locale_0.friendly_number(50000000)
   

# Generated at 2022-06-26 08:07:56.198367
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # define a test case
    LC_MESSAGES = "LC_MESSAGES"
    LC_MESSAGES_dir = "./LC_MESSAGES_0"
    make_dir(LC_MESSAGES_dir)
    make_dir(os.path.join(LC_MESSAGES_dir, LC_MESSAGES))
    # write test data in the first csv file
    csv_fn_0 = os.path.join(LC_MESSAGES_dir, LC_MESSAGES, "message_0.csv")
    write_csv_file(csv_fn_0, ["message", "translation", "plural"], [['a', 'b', 'c']])

# Generated at 2022-06-26 08:08:06.136061
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    print("Locale.format_day")
    # Test case 0
    locale_0 = Locale('zh_CN') # (code)
    date_0 = datetime.datetime(2020, 4, 3) # (date)
    result_0 = locale_0.format_day(date_0)
    # Value should be 2020-04-03 00:00:00, but type does not match
    assert isinstance(result_0, str) # (result)
    # Test case 1
    locale_1 = Locale('en') # (code)
    date_1 = datetime.datetime(2020, 4, 3) # (date)
    result_1 = locale_1.format_day(date_1)
    # Value should be 2020-04-03 00:00:00, but type does not match
    assert isinstance

# Generated at 2022-06-26 08:08:18.101091
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    test_function = "test_Locale_pgettext"
    test_type = "UNIT"
    locale_0 = get()
    message_0 = "message_0"
    context_0 = "context_0"
    result_0 = locale_0.pgettext(message_0, context_0)
    test_passed = True
    if result_0:
        test_passed = False
        failure_info = "".join(("    FAILED: Locale.pgettext: result is \"", result_0, "\". "))
        report(test_function, test_type, failure_info)
        return test_passed
    else:
        pass
    report(test_function, test_type)
    return test_passed


# Generated at 2022-06-26 08:08:23.016947
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    global _translations
    global _supported_locales
    global _use_gettext
    global _default_locale
    _translations = {}
    _supported_locales = {}
    _use_gettext = False
    _default_locale = 'en_US'
    locale_0 = get()
    locale_0.friendly_number(2047)


# Generated at 2022-06-26 08:09:40.013703
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    assert locale_0.format_day(datetime.datetime(year=2019, month=8, day=13)) == 'Tuesday, August 13'
    assert locale_0.format_day(datetime.datetime(year=2019, month=8, day=13), 1) == 'Tuesday, August 13'
    assert locale_0.format_day(datetime.datetime(year=2019, month=8, day=13), 0) == 'Tuesday, August 13'
    assert locale_0.format_day(datetime.datetime(year=2019, month=8, day=13), True) == 'Tuesday, August 13'
    assert locale_0.format_day(datetime.datetime(year=2019, month=8, day=13), False) == 'August 13'


# Generated at 2022-06-26 08:09:47.599292
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    locale_1 = get()
    print(locale_1.translate("test"))
    print(locale_1.translate("test2"))
    print(locale_1.translate("test", "test1", 1))
    print(locale_1.translate("test", "test1", 2))


# Generated at 2022-06-26 08:09:53.723002
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    date = datetime.datetime.fromtimestamp(0)
    gen_log.debug("Getting date as string")
    if locale_0.format_day(date) != "January 1":
        gen_log.error("Date was not printed as expected")
        raise Exception("Date was not printed as expected")


# Generated at 2022-06-26 08:09:56.291090
# Unit test for method list of class Locale
def test_Locale_list():
    parts = []
    locale_1 = get()
    ret = locale_1.list(parts)
    return ret


# Generated at 2022-06-26 08:10:01.702324
# Unit test for function load_translations
def test_load_translations():
    print("Unit test for function load_translations")
    load_translations("locale")


# Generated at 2022-06-26 08:10:05.327791
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    # str_0 = locale_0.format_day(date_0, time.timezone, dow_0)
    # assert str_0 == expected_result
    pass


# Generated at 2022-06-26 08:10:08.552549
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    print(locale_0.format_day(datetime.datetime.now(), gmt_offset=0, dow=True))


# Generated at 2022-06-26 08:10:10.446861
# Unit test for function load_translations
def test_load_translations():
    load_translations("./locale_data", "utf-8")


# Generated at 2022-06-26 08:10:12.495995
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = get()
    assert locale_0.format_date(0) == '70 years ago'


# Generated at 2022-06-26 08:10:19.256772
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    start_time = time.time()
    locale = get()
    # TODO: Get a list of dates and dow values from a file
    start_date = datetime.date(2019, 3, 15)
    end_date = datetime.date(2019, 3, 21)
    dow = False
    gmt_offset = 0
    for date in range(start_date, end_date):
        locale.format_day(date, gmt_offset, dow)
    print("Execution time of ", time.time() - start_time)



# Generated at 2022-06-26 08:11:39.996403
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    print("")
    print("Testing format_date on Locale.get('en')")
    print("")
    print("  -- Expected --")
    print("")
    print("                1 second ago")
    print("                59 seconds ago")
    print("                1 minute ago")
    print("                59 minutes ago")
    print("                1 hour ago")
    print("                23 hours ago")
    print("                yesterday")
    print("                yesterday at 11:30pm")
    print("                Monday")
    print("                Monday at 12:00am")
    print("                Friday, January 26")
    print("                Friday, January 26 at 12:00am")
    print("                January 26, 2018")
    print("                January 26, 2018 at 12:00am")
    print("")
    print("  -- Result --")
   