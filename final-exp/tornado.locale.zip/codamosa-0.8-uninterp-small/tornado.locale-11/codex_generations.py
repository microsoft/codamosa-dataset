

# Generated at 2022-06-26 08:02:21.332478
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.locale import load_gettext_translations

    load_gettext_translations(localedir, "tornadoweb", ("en_US", ))
    locale_1 = Localized.get(locale = "en_US")

    msg_0 = locale_1.pgettext("test", "test")
    assert msg_0 == "test"

    msg_1 = locale_1.pgettext("test", "test", "tests", 3)
    assert msg_1 == "tests"


# test_locale.py:23: error: Item not found: <class 'build.toml_builder.Line'>
_ = Localized.get(locale = "en_US").translate
_ = GettextLocale.pgettext


if __name__ == "__main__":
    test_case_0

# Generated at 2022-06-26 08:02:26.759295
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get("en_US")
    year = 2020
    month = 1
    day = 7
    date = datetime.datetime(year, month, day)
    assert locale.format_day(date, dow = True) == "Tuesday, January 7"
    assert locale.format_day(date, dow = False) == "January 7"



# Generated at 2022-06-26 08:02:28.768987
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./test_locale", "test_domain")


# Generated at 2022-06-26 08:02:41.037699
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = get()
    x = datetime.datetime.now()
    y = datetime.datetime.now() + datetime.timedelta(hours=1)
    z = datetime.datetime.now() - datetime.timedelta(hours=2)
    print("Start Locale.format_date test")
    print("x is", x)
    print("y is", y)
    print("z is", z)
    print("x format date is", locale_0.format_date(x))
    print("y format date is", locale_0.format_date(y))
    print("z format date is", locale_0.format_date(z))
    print("End Locale.format_date test")



# Generated at 2022-06-26 08:02:42.993197
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    # Create the object
    gettext_locale = GettextLocale("en", None)
    # Specify input parameters
    message = "test"
    count = 1
    # Call the method
    result = gettext_locale.translate(message, None, count)
    # Check the result
    assert result == "test"


# Generated at 2022-06-26 08:02:53.079511
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date_0 = datetime.datetime(year=2019,month=5,day=5,hour=5,minute=5)
    result_0 = Locale.get("en").format_day(date=date_0)
    assert result_0 == 'Sunday, May 5'

    result_1 = Locale.get("en").format_day(date=date_0, dow=False)
    assert result_1 == 'May 5'

    result_2 = Locale.get("en").format_day(date=date_0, dow=True, gmt_offset=0)
    assert result_2 == 'Sunday, May 5'


# Generated at 2022-06-26 08:03:05.014880
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    now = datetime.datetime.now()
    now = now - datetime.timedelta(seconds=10)
    localized_date_str = "1 second ago"
    locale_0 = get('en_US')
    locale_0.format_date(now) == localized_date_str
    now = now - datetime.timedelta(seconds=40)
    localized_date_str = "1 minute ago"
    locale_0.format_date(now) == localized_date_str
    now = now - datetime.timedelta(seconds=20*60)
    localized_date_str = "1 hour ago"
    locale_0.format_date(now) == localized_date_str
    now = now - datetime.timedelta(seconds=20*60*60)

# Generated at 2022-06-26 08:03:10.290790
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    test_date = datetime.datetime(2019, 1, 22)
    test_locale = Locale.get("zh_CN")
    print(test_locale.format_day(test_date))

if __name__ == "__main__":
    test_Locale_format_day()

# Generated at 2022-06-26 08:03:19.825654
# Unit test for function load_translations
def test_load_translations():
    test_load_translations.cnt = 0
    def test_case_1(directory = "../locale"):
        encoding = "utf-8"
        load_translations(directory, encoding)
    def test_case_2(directory = "../locale"):
        encoding = "utf-16"
        load_translations(directory, encoding)

    test_case_1()
    test_case_2()
    #assert test_load_translations.cnt == 0, "load_translations: detected bug."
    print("module 'tornado.locale' test passed.")


# Generated at 2022-06-26 08:03:22.003206
# Unit test for function load_translations
def test_load_translations():
    load_translations('/home/shawn/git/backend/tornado_tutorial/test_trl')
    locale_0 = get()


# Generated at 2022-06-26 08:04:05.277510
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    date = datetime.date(2020,1,28)
    locale_0 = Locale.get('en')
    assert locale_0.format_date(date) == 'January 28, 2020'


# Generated at 2022-06-26 08:04:11.592634
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    test_day     = datetime.datetime(2019, 10, 21, 0, 0)
    test_locale  = Locale('en_US')
    test_result  = 'Monday, October 21'
    assert_equal(test_locale.format_day(test_day), test_result)

# Generated at 2022-06-26 08:04:13.434120
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')


# Generated at 2022-06-26 08:04:18.639294
# Unit test for function load_translations
def test_load_translations():
    locations = [
        "en_US",
        "fr_FR",
        "es_LA",
        "en_UK"
    ]
    for loc in locations:
        print(loc)
        load_translations(loc)


# Generated at 2022-06-26 08:04:27.358443
# Unit test for function load_translations
def test_load_translations():
    load_translations("../locale")
    # get() using default locale (en_US)
    locale_0 = get()
    print("locale_0: ", locale_0)
    # get() for es_LA
    locale_1 = get("es_LA")
    print("locale_1: ", locale_1)
    # get() for fr
    locale_2 = get("fr")
    print("locale_2: ", locale_2)
    # get() for es
    locale_3 = get("es")
    print("locale_3: ", locale_3)
    return

# unit test for function test_case_1()

# Generated at 2022-06-26 08:04:32.543261
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Initialize data
    code = "a_code"
    # c = Locale(code)
    # This call will result in an exception
    # c.pgettext(context, message, plural_message, count)
    print("test_Locale_pgettext passed!")


# Generated at 2022-06-26 08:04:42.979469
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    date_0 = datetime.datetime()
    gmt_offset_0 = 0
    dow_0 = True
    res = locale_0.format_day(date_0, gmt_offset_0, dow_0)
    print(res)
    date_1 = datetime.datetime(2019, 11, 15)
    gmt_offset_1 = 1423
    dow_1 = True
    res = locale_0.format_day(date_1, gmt_offset_1, dow_1)
    print(res)


# Generated at 2022-06-26 08:04:46.695795
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    locale_0 = get()
    count = 1
    assert locale_0.translate(_('网络不可用'), _('网络不可用'), count) == _('网络不可用')
    assert locale_0.translate(message='未知错误', count=count) == '未知错误'
    assert locale_0.translate(message='你好啊', plural_message='你好啊', count=count) == '你好啊'

# Generated at 2022-06-26 08:04:48.945313
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./mo", "tornado")
    locale_1 = get()

    locale_2 = get()


# Generated at 2022-06-26 08:04:58.369163
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    print(Locale.get('en_US').format_day(datetime.datetime(2019, 3, 31), 0))
    print(Locale.get('en_US').format_day(datetime.datetime(2019, 5, 2), 0))
    print(Locale.get('en_US').format_day(datetime.datetime(2019, 7, 12), 0))
    print(Locale.get('en_US').format_day(datetime.datetime(2019, 9, 14), 0))
    print(Locale.get('en_US').format_day(datetime.datetime(2019, 11, 9), 0))


# Generated at 2022-06-26 08:05:28.205563
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Setup the test case
    # Case 0
    locale_0 = get()
    date_0 = datetime.datetime(2016, 1, 1, 0, 0)
    gmt_offset_0 = 0
    dow_0 = True

    # Execute the method
    result_0 = locale_0.format_day(date_0, gmt_offset_0, dow_0)
    # Check if the result is correct
    assert result_0 == "Friday, January 1"

    # Case 1
    locale_1 = get()
    date_1 = datetime.datetime(2016, 2, 1, 0, 0)
    gmt_offset_1 = 0
    dow_1 = False

    # Execute the method

# Generated at 2022-06-26 08:05:38.977204
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/naw/Programs/build/www/locale", "simplest")
    translation = _translations.get("en_US")  # type: Any
    assert translation
    assert translation.gettext("hello") == "hello"
    assert translation.gettext("hello %(name)s") == "hello %(name)s"
    assert translation.gettext("hello %(name)s") == "hello %(name)s"
    # Gettext has singular/plural distinction
    assert translation.ngettext(
        "singular", "plural", 2
    ) == "plural"
    assert translation.ngettext(
        "singular", "plural", 1
    ) == "singular"



# Generated at 2022-06-26 08:05:41.635482
# Unit test for function load_translations
def test_load_translations():
    load_translations('../locale/csv')


# Generated at 2022-06-26 08:05:47.339958
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    text = "你好"
    print(text)
    directory = "/Users/paulha/src/tornado-6.0.3/tornado/locale"
    load_gettext_translations(directory, "tornado")
    locale_0 = get()
    print(locale_0.translate(text))
    locale_1 = get("zh_CN")
    print(locale_1.translate(text))


# Generated at 2022-06-26 08:06:02.610861
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # try default locale
    locale_0 = get()
    assert locale_0.pgettext("a", "hello") == "hello"
    assert locale_0.pgettext("b", "hello") == "hello"

    load_translations(locale_path)
    locale = get('en_US')

    assert locale.pgettext("a", "hello") == "hello"
    assert locale.pgettext("a", "hello", "hello") == "hello"
    assert locale.pgettext("b", "hello") == "hello"
    assert locale.pgettext("b", "hello", "hello") == "hello"
    assert locale.pgettext("a", "hello", count=1) == "hello"

# Generated at 2022-06-26 08:06:14.642169
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_0 = get()
    date_0 = datetime.datetime.now()
    date_1 = date_0 + datetime.timedelta(hours=1)
    date_2 = date_0 - datetime.timedelta(hours=1)
    date_3 = date_0 + datetime.timedelta(seconds=1)
    date_4 = date_0 + datetime.timedelta(hours=24)
    date_5 = date_0 - datetime.timedelta(hours=24)
    date_6 = date_0 + datetime.timedelta(days=1)
    date_7 = date_0 - datetime.timedelta(days=1)
    date_8 = date_0 - datetime.timedelta(days=2)

# Generated at 2022-06-26 08:06:21.835689
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    assert get().format_date(datetime.datetime(2020, 8, 7, 10, 4, 15)) == "3 hours ago"
    assert get().format_date(datetime.datetime(2020, 8, 9, 10, 4, 15), gmt_offset=2) == "1 day ago"
    assert get().format_date(datetime.datetime(2020, 8, 10, 4, 4, 15), gmt_offset=1) == "13 hours ago"


# Generated at 2022-06-26 08:06:25.284008
# Unit test for function load_translations
def test_load_translations():
    load_translations("C:\\Users\\WangC\\Downloads\\locale_data")
    test_case_0()



# Generated at 2022-06-26 08:06:31.614389
# Unit test for method list of class Locale
def test_Locale_list():
    # initialize global data
    locale_0 = Locale("en_US")
    a = ["one"]
    a_expected = "one"
    # test list
    a_actual = locale_0.list(a)
    assert a_expected == a_actual


# Generated at 2022-06-26 08:06:33.728614
# Unit test for function load_translations
def test_load_translations():
    print("In test")
    load_translations("../../locale")
    print("Loaded")
    locale_0 = get()
    test_case_0()


# Generated at 2022-06-26 08:07:03.348240
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    date_0 = datetime.datetime.strptime("10/14/2020", "%m/%d/%Y")
    locale_rtn_0 = locale_0.format_day(date_0)
    assert_equal("Sunday, October 14", locale_rtn_0)


# Generated at 2022-06-26 08:07:10.257052
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # _DATE_0 is Mon, May 18, 2020
    _DATE_0 = datetime.datetime(year=2020, month=5, day=18)
    _GMT_OFFSET_0 = 0
    _DOW_0 = True
    locale_0 = get()
    locale_0.format_day(_DATE_0, _GMT_OFFSET_0, _DOW_0)
    # should not raise an exception


# Generated at 2022-06-26 08:07:21.415104
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get_closest('en')
    # 全局默认内置时区是 GMT-8，即北京时间，东八区
    now = datetime.datetime.utcnow()
    # 北京时间是格林尼治时间加8个小时，即东8区
    time_beijing = str(now + datetime.timedelta(minutes=480))
    # 格林尼治时间计算，开头4位是年份后面是月日时

# Generated at 2022-06-26 08:07:25.193642
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Get a new instance of class Locale
    locale_0 = Locale('en_US')
    # Call method pgettext
    pgettext_result = locale_0.pgettext('context', 'message')

    print(pgettext_result)


# Generated at 2022-06-26 08:07:28.347668
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('c:\\msg', 'tornado')

    print(get('zh-CN').translate('[Debug]No IOLoop available for socket'))


# Generated at 2022-06-26 08:07:31.274543
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    domain = 'mydomain'
    directory = os.path.join('locale')
    load_gettext_translations(directory, domain)
    assert(len(_translations) == 1)
    assert( _translations['pt_BR'] is not None)


# Generated at 2022-06-26 08:07:38.596008
# Unit test for function load_translations
def test_load_translations():
    print("Testing for function load_translations")
    try:
        load_translations("/Users/jianwang/Desktop/buf_github/tornado/tornado/locale/tests/")
    except:
        print("could not find locale directory")



# Generated at 2022-06-26 08:07:42.637402
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = get()

    # Setting date
    date = locale.format_date(datetime.datetime.now())

    if type(date) is not str:
        raise AssertionError("Incorrect type: " + str(type(date)))



# Generated at 2022-06-26 08:07:53.896758
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test 0:
    my_locale = Locale("en")
    date = datetime.datetime(2020, 1, 22)
    gmt_offset=0
    dow=True
    answer =  "Wednesday, January 22"
    result = my_locale.format_day(date, gmt_offset, dow)
    assert(answer == result)
    # Test 1:
    my_locale = Locale("en")
    date = datetime.datetime(2020, 1, 22)
    gmt_offset=0
    dow=False
    answer =  "January 22"
    result = my_locale.format_day(date, gmt_offset, dow)
    assert(answer == result)

# Generated at 2022-06-26 08:08:00.311749
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Assume that the file "locale/{lang}/LC_MESSAGES/mydomain.mo"
    # exists. Create a fake directory "test_locale"
    # which mimics "locale" directory.
    test_locale = os.path.join(os.getcwd(), "test_locale")
    os.makedirs(test_locale, exist_ok=True)

    # Copy "locale/{lang}/LC_MESSAGES/mydomain.mo" file to
    # "test_locale/{lang}/LC_MESSAGES/mydomain.mo"

# Generated at 2022-06-26 08:08:52.512261
# Unit test for method format_date of class Locale

# Generated at 2022-06-26 08:09:02.702939
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    date = datetime.datetime(2019, 6, 4, 20, 10, 29)
    time_delta = datetime.timedelta(minutes=29, seconds=31)
    timestamp = datetime.datetime.timestamp(date)
    timestamp = timestamp - time_delta.total_seconds()

    minute_delta = datetime.timedelta(minutes=1)
    minute_delta_seconds = minute_delta.total_seconds()
    one_minute_ago = timestamp - minute_delta_seconds
    two_minute_ago = one_minute_ago - minute_delta_seconds
    two_hour_ago = two_minute_ago - (minute_delta_seconds*60*2)

    gmt_offset = 29
    now = datetime.datetime.utcnow()
    
   

# Generated at 2022-06-26 08:09:06.456226
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    locale_obj = get()
    context = ""
    message = ""
    plural_message = ""
    count = 0
    locale_obj.pgettext(context, message, plural_message, count)

# Generated at 2022-06-26 08:09:07.921712
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    Locale.get_closest()
    assert False


# Generated at 2022-06-26 08:09:17.012023
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = Locale("test value")
    date_0 = datetime.datetime.fromtimestamp(0)
    gmt_offset_0 = 0
    dow_0 = True
    result_0 = locale_0.format_day(date_0, gmt_offset_0, dow_0)
    str_0 = "Sunday, January 1"
    success_0 = str_0 == result_0
    print("Success Locale.format_day: " + str(success_0))
    assert success_0


# Generated at 2022-06-26 08:09:19.517966
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    locale_0 = get()
    assert locale_0.pgettext('hi', 'hi') == 'hia'


# Generated at 2022-06-26 08:09:30.101434
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    DEFAULT_LOCALE = "en_US"
    CSV_FILE_NAME = "./test/locale/locale.csv"
    encoding = "utf8"
    message = _("January")
    gen_log.info("%s , %s ,%s  ", encoding, message, type(message))
    load_translations(CSV_FILE_NAME, encoding)
    locale_1 = Locale.get(DEFAULT_LOCALE)
    default_date = time.time()
    gmt_offset = 0
    relative = True
    shorter = False
    full_format = False
    date_format = locale_1.format_date(default_date, gmt_offset, relative, shorter, full_format)
    print("format_date = %s , %s", default_date, date_format)

# Generated at 2022-06-26 08:09:31.382086
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(os.path.join('.', 'locale'), 'tornado')


# Generated at 2022-06-26 08:09:33.200416
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('locale', 'base')


# Generated at 2022-06-26 08:09:36.161002
# Unit test for function load_translations
def test_load_translations():
    load_translations("/home/marco/Desktop/cps/tornado-6.0.1/tornado")
    #print(_translations)


# Generated at 2022-06-26 08:10:30.203772
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Path to the test directory, which contains .mo files
    path_to_test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "gettext-test")

    # Domain is the project name
    domain = "tornado_demo"

    # Load translation
    load_gettext_translations(path_to_test_dir, domain)

    # Test code
    assert len(_translations) == 2
    assert _translations["ja_JP"].gettext("Hello") == "こんにちは"
    assert _translations["ko_KR"].gettext("Hello") == "안녕하세요"


# If `gettext` is unavailable but the translations are loaded, we warn
# the user that

# Generated at 2022-06-26 08:10:39.635767
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    test_Locale = Locale(code = "zh_CN")
    assert test_Locale.pgettext(context = '', message = '', plural_message = '', count = None) == "translate"
    assert test_Locale.pgettext(context = '', message = '', plural_message = '', count = 1) == "translate"
    assert test_Locale.pgettext(context = '', message = '', plural_message = '', count = 2) == "translate"


# Generated at 2022-06-26 08:10:49.682617
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_0 = get()
    date_0 = datetime.datetime.now()
    gmt_offset_0 = 0
    dow_0 = True
    ret_0 = locale_0.format_day(date_0, gmt_offset_0, dow_0)
    print("Test for method format_day of class Locale")
    print("result\t", ret_0)
    assert ret_0 != None


# Generated at 2022-06-26 08:11:02.866759
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    from tornado.test.util import unittest
    from tornado.util import ObjectDict

    dir_0 = 'test/test_data/test_gettext_translations'
    domain_0 = 'test'

    test_locale_0 = get()
    test_locale_1 = get('en_US')
    test_locale_2 = get('zh_CN')

    load_gettext_translations(dir_0, domain_0)
    
    test_locale_0 = get()
    test_locale_1 = get('en_US')
    test_locale_2 = get('zh_CN')

    print('test_gettext_translations:')
    print(test_locale_0.translate('I am a lion'))

# Generated at 2022-06-26 08:11:14.785995
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date_1 = datetime.datetime(2019,9,9)
    date_2 = datetime.datetime(2019,9,17)
    date_3 = datetime.datetime(2019,9,20)
    date_4 = datetime.datetime(2019,9,24)
    date_5 = datetime.datetime(2019,9,28)
    locale_1 = Locale("en_US")
    print("case 1: " + locale_1.format_day(date_1, 0, True))
    print("case 1: " + locale_1.format_day(date_1, 0, False))
    print("case 2: " + locale_1.format_day(date_2, 0, True))

# Generated at 2022-06-26 08:11:19.854541
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date_0 = datetime.datetime.utcnow()
    # gmt_offset = 0
    # dow = True
    result_0 = format_day(date_0, 0, True)


# Generated at 2022-06-26 08:11:25.228990
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    local_date = datetime.datetime(2020, 2, 5)
    locale_obj = Locale('en')
    result = locale_obj.format_day(local_date)
    assert result == 'Wednesday, February 5'


# Generated at 2022-06-26 08:11:39.280185
# Unit test for function load_translations
def test_load_translations():
    cur_dir = os.path.dirname(os.path.realpath(__file__))
    translator_cur_dir = os.path.abspath(os.path.join(cur_dir, '../..'))
    translator_cur_dir = os.path.abspath(os.path.join(translator_cur_dir, '..'))
    locale_dir = os.path.abspath(os.path.join(translator_cur_dir, 'locales'))