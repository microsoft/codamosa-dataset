

# Generated at 2022-06-22 03:41:12.485776
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    translate = CSVLocale("zh_CN", {"unknown": {}, "singular": {}, "plural": {}})
    class _:
        def pgettext(*args, **kws):
            return "test"
    _(translate)



# Generated at 2022-06-22 03:41:14.655510
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    pass


# Generated at 2022-06-22 03:41:17.084070
# Unit test for function set_default_locale
def test_set_default_locale():
    c = "hi"
    set_default_locale(c)
    assert _default_locale == c


# Generated at 2022-06-22 03:41:20.560573
# Unit test for function load_translations
def test_load_translations():
    dir = "/Users/uso/tornado_my/tornado_my"
    # dir = "/Users/uso/PycharmProjects/tornado_my/tornado_my"
    load_translations(dir)
    print(_translations)



# Generated at 2022-06-22 03:41:22.790939
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    assert Locale.get("en").pgettext("c1", "message1") == "message1"

# Generated at 2022-06-22 03:41:30.575301
# Unit test for method list of class Locale
def test_Locale_list():
    a = Locale('ar')
    a = Locale('fa')
    assert a.list(['A','B','C']) == u' A \u0648  B \u0648  C'
    assert a.list(['A','B','C','D','E']) == u' A \u0648  B \u0648  C \u0648  D \u0648  E'
    assert a.list(['A']) == u' A'
    assert a.list([]) == u''

# Test for method friendly_number of class Locale

# Generated at 2022-06-22 03:41:42.664628
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    if not _use_gettext:
        return

    import gettext
    from pathlib import Path
    from typing import Optional

    from tornado.options import options

    # gettext.install() is called by load_gettext_translations()
    options.locale = "ja"
    _default_locale = "ja"
    locale_names = {
        "ja": {"name": "Japanese, 日本語", "nativeName": "日本語"},
        "en": {"name": "English, English", "nativeName": "English"},
    }
    _supported_locales = ["en", "ja"]
    LOCALE_NAMES = locale_names
    _translations = {}

# Generated at 2022-06-22 03:41:44.305368
# Unit test for function get_supported_locales
def test_get_supported_locales():
  assert get_supported_locales == _supported_locales



# Generated at 2022-06-22 03:41:47.910774
# Unit test for constructor of class Locale
def test_Locale():
    load_translations(os.path.dirname(__file__))
    loc = Locale.get("en")
    loc.format_date(0)
    loc.format_day(datetime.datetime.utcnow())


# Generated at 2022-06-22 03:41:49.362320
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")



# Generated at 2022-06-22 03:42:07.848273
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales
    assert len(_supported_locales) > 1
    assert _default_locale in _supported_locales


# Generated at 2022-06-22 03:42:09.800360
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert get_supported_locales() == frozenset(['en_US'])



# Generated at 2022-06-22 03:42:11.081661
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")


# Generated at 2022-06-22 03:42:17.934163
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    print("*"*20)
    print("Testing method translate of class CSVLocale")
    locale_dict = {'unknown': {'No results found': 'No results found'}, 'singular': {'1 result found': '1 result found'}}
    csvlocale = CSVLocale('en', locale_dict)
    assert csvlocale.translate('No results found') == 'No results found'
    assert csvlocale.translate('No results found', 'This is plural', 3) == 'This is plural'
    assert csvlocale.translate('1 result found') == '1 result found'
    print("Method translate of class CSVLocale working fine!")
test_CSVLocale_translate()



# Generated at 2022-06-22 03:42:20.868065
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    locale=CSVLocale("en", {})
    assert locale.pgettext("", "Foo") == "Foo"



# Generated at 2022-06-22 03:42:24.195038
# Unit test for function load_translations
def test_load_translations():
    test_dir="test_dir"
    set_default_locale("en_US")
    load_translations(test_dir)
    assert _translations


# Generated at 2022-06-22 03:42:25.872942
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    assert CSVLocale.pgettext == Locale.pgettext



# Generated at 2022-06-22 03:42:28.881963
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    from .i18n import CSVLocale
    test_locale = CSVLocale("zz", {"unknown": {"Hello": "Bonjour"}})
    assert test_locale.pgettext("hello", "Hello") == "Bonjour"



# Generated at 2022-06-22 03:42:41.689761
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    Locale.get_closest("")
    Locale.get_closest("abc")
    Locale.get_closest("abc", "def", "g")
    try:
        Locale.get("abc")
    except:
        pass
    locale = Locale.get_closest("")
    locale.translate("")
    locale.translate("", "")
    locale.translate("", "", 0)
    locale.pgettext("", "")
    locale.pgettext("", "", "")
    locale.pgettext("", "", "", 0)
    locale.format_date(0)
    locale.format_day(0, 0)
    locale.format_day(0, 0, True)
    locale.list(None)

# Generated at 2022-06-22 03:42:47.386436
# Unit test for method translate of class CSVLocale

# Generated at 2022-06-22 03:43:06.716730
# Unit test for function set_default_locale
def test_set_default_locale():
    default = 'en-US'
    set_default_locale(default)
    assert _default_locale == default


# Generated at 2022-06-22 03:43:07.711843
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales == get_supported_locales()



# Generated at 2022-06-22 03:43:14.668077
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    l = CSVLocale("en", {'singular': {'1 month': '1 month'}})
    assert l.translate("1 month") == '1 month'
    assert l.translate("1 month", "2 months", count=1) == '1 month'
    assert l.translate("1 month", "2 months", count=2) == '2 months'

# Generated at 2022-06-22 03:43:25.504686
# Unit test for function set_default_locale
def test_set_default_locale():
    # set_default_locale(). _default_locale is set to code.
    code = 'en_US'
    set_default_locale(code)
    assert _default_locale == code
    #set_default_locale(). _supported_locales includes _default_locale.
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    # set_default_locale(). _supported_locales includes _default_locale.
    code = 'en_US'
    set_default_locale(code)
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])


# Generated at 2022-06-22 03:43:29.935809
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    given = (
        ('en', '', '', ''),
        ('en', 'context', '', ''),
        ('en', 'context', 'message', ''),
        ('en', 'context', 'message', 'None'),
        ('en', 'context', 'message', '0'),
        ('en', 'context', 'message', '1'),
        ('en', 'context', 'message', '2'),
        ('en', 'context', '', 'plural'),
        ('en', 'context', 'message', 'plural')
    )
    expected = (
        None, None, None, None, None, None, None, None, None
    )


# Generated at 2022-06-22 03:43:42.422504
# Unit test for method translate of class Locale
def test_Locale_translate():
    test_dict = {
        "plural": {
            "foo": "foos",
            "1 bar": "1 bar",
            "2 bars": "2 bars",
            "0 bars": "0 bars",
            "0": "%(count)d",
            "1": "%(count)d",
            "2": "%(count)d",
        },
        "singular": {"sushi": "sushi"},
    }
    locale_obj = CSVLocale("en", test_dict)
    assert locale_obj.translate("foo") == "foo"
    assert(locale_obj.translate("1 bar") == "1 bar")
    assert(locale_obj.translate("2 bars", plural_message="2 bars", count=2) == "2 bars")

# Generated at 2022-06-22 03:43:46.091935
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    csv_dict = {"unknown": {"Please click on the following link": "Please click on the following link"}}
    csv_locale_test = CSVLocale("en", csv_dict)
    assert not csv_locale_test.translations


# Generated at 2022-06-22 03:43:51.582520
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = os.path.join(os.getcwd())
    domain = "tornado"
    assert load_gettext_translations(directory, domain)
    #assert os.path.exists(os.path.join(directory, "zh_CN", "LC_MESSAGES", "tornado.mo"))


# Generated at 2022-06-22 03:43:59.084119
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    # Empty locale (to avoid loading)
    locale = GettextLocale('en', None)
    assert locale.pgettext('good', 'right') == 'right'
    assert locale.pgettext('law', 'right') == 'right'
    assert locale.pgettext('organization', 'club', 'clubs', len('clubs')) == 'clubs'
    assert locale.pgettext('stick', 'club', 'clubs', len('clubs')) == 'clubs'

# Generated at 2022-06-22 03:44:05.708406
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # return correct value when code is 'en' or 'en_US'
    assert Locale.get("en_US").friendly_number(1000) == "1,000"
    assert Locale.get("en_US").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"



# Generated at 2022-06-22 03:44:25.624838
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    assert _default_locale == "en_US"
    assert 'en_US' in _supported_locales


# Generated at 2022-06-22 03:44:28.962117
# Unit test for function get_supported_locales
def test_get_supported_locales():
    load_translations("/test")
    assert get_supported_locales() == set(["en_CA"])



# Generated at 2022-06-22 03:44:39.536585
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    import os
    import pathlib
    base_path = os.path.abspath(os.path.dirname(__file__))
    test_data_path = os.path.abspath(pathlib.Path.cwd() / "test/data/")
    f = open(test_data_path + '/locale/en_US/LC_MESSAGES/messages.mo')
    data = f.read()
    translations = tornado.locale.load_translations(data, f.close)
    locale = CSVLocale("en_US", translations)
    assert locale.translate("test") == "test"
    assert locale.translate("test", "tests", 2) == "tests"

# Generated at 2022-06-22 03:44:41.419669
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    from .test_translation import test_translate
    test_translate(CSVLocale)

# Generated at 2022-06-22 03:44:42.046978
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    pass



# Generated at 2022-06-22 03:44:54.442740
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    #test the "en" case
    test_number = Locale("en")
    assert test_number.friendly_number(0) == "0"
    assert test_number.friendly_number(1) == "1"
    assert test_number.friendly_number(10) == "10"
    assert test_number.friendly_number(100) == "100"
    assert test_number.friendly_number(1000) == "1,000"
    assert test_number.friendly_number(10000) == "10,000"
    assert test_number.friendly_number(100000) == "100,000"
    assert test_number.friendly_number(1000000) == "1,000,000"
    assert test_number.friendly_number(10000000) == "10,000,000"
    assert test_number.friendly_number

# Generated at 2022-06-22 03:44:56.303200
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    print("unit test for method translate of class GettextLocale")
    print("bye")
    return None


# Generated at 2022-06-22 03:45:09.233912
# Unit test for function load_translations
def test_load_translations():
    """
    test_load_translations
    :return:
    """
    import tornado.testing
    import tornado.ioloop
    import unittest
    import functools

    class TranslationsTest(unittest.TestCase):

        def test_translations(self):
            # Load the translation file and test it.
            # Write a temporary translation file to test
            # against the test contents below.
            try:
                from tempfile import NamedTemporaryFile
            except ImportError:
                from backports.tempfile import NamedTemporaryFile

# Generated at 2022-06-22 03:45:13.458408
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    GettextLocale("de", gettext.NullTranslations())

# Generated at 2022-06-22 03:45:25.443897
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get_closest('en', 'en_US')
    date = datetime.datetime(2012, 1, 23)
    assert locale.format_day(date, dow=True) == 'Monday, January 23'
    assert locale.format_day(date, dow=False) == 'January 23'
    date = datetime.datetime(2012, 1, 22)
    assert locale.format_day(date, dow=False) == 'January 22'
    locale = Locale.get_closest('fa', 'fa_IR')
    date = datetime.datetime(2012, 1, 22)

# Generated at 2022-06-22 03:45:41.936670
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    # this test is pending to review
    assert True == False


# Generated at 2022-06-22 03:45:46.089144
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    
    def _init():
        global _translations
        global _supported_locales
        global _use_gettext
        _translations = {}
        _supported_locales = {}
        _use_gettext = True

    def testCase(csv_file_path):
        _init()
        nonlocal _translations, _supported_locales, _use_gettext
        _supported_locales = ("en", "en_US", "zh_CN")
        def _fake_csv_read(path):
            return ({'test': {'Hello': '你好'}}, {'test': {'Hello': 'Hello'}})
        mock_csv_read = mock.Mock(side_effect=_fake_csv_read)

# Generated at 2022-06-22 03:45:51.293758
# Unit test for method list of class Locale
def test_Locale_list():
    translation_obj = Locale('en')
    parts = ["A", "B", "C"]
    assert translation_obj.list(parts) == "A, B, and C"
    parts = ["A"]
    assert translation_obj.list(parts) == "A"
    parts = ["A", "B"]
    assert translation_obj.list(parts) == "A and B"


# Generated at 2022-06-22 03:45:55.609040
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime(2020,11,15,10,30)
    myLocale = Locale("en_US")    
    result = myLocale.format_day(date, dow=True)
    assert result == 'Sunday, November 15'

# Generated at 2022-06-22 03:46:00.665524
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get('en').friendly_number(100) == '100'
    assert Locale.get('en').friendly_number(1000) == '1,000'
    assert Locale.get('en').friendly_number(10000) == '10,000'
    assert Locale.get('fa').friendly_number(10000) == '10000'



# Generated at 2022-06-22 03:46:03.844018
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l = Locale.get("en_US")
    assert l.friendly_number(1000) == "1,000"
    assert l.friendly_number(1000000) == "1,000,000"

    l = Locale.get("en_GB")
    assert l.friendly_number(1000) == "1,000"
    assert l.friendly_number(1000000) == "1,000,000"

    l = Locale.get("fa")
    assert l.friendly_number(1000) == "1000"
    assert l.friendly_number(1000000) == "1000000"



# Generated at 2022-06-22 03:46:13.831393
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime

    #noinspection PyUnusedLocal
    _translations: Dict[str, Dict[str, str]] = {}

# Generated at 2022-06-22 03:46:25.520373
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    LOCALE_CODE = 'en'
    class DummyGettextNullTranslations:
        def dummy_ngettext(self, singular, plural, number):
            return 'dummy_ngettext_result'
        def dummy_gettext(self, singular):
            return 'dummy_gettext_result'
    dummy_translations = DummyGettextNullTranslations()
    dummy_translations.ngettext = dummy_translations.dummy_ngettext
    dummy_translations.gettext = dummy_translations.dummy_gettext
    test_instance = GettextLocale(LOCALE_CODE, dummy_translations)
    singular = 'singular'
    plural = 'plural'
    number = 123

# Generated at 2022-06-22 03:46:37.495212
# Unit test for function get_supported_locales
def test_get_supported_locales():
    load_translations("./")
    assert (set(_supported_locales) == {"en_US"})
    load_gettext_translations("./")
    assert (set(_supported_locales) == {"en_US"})
    load_gettext_translations("./", domain = "test_domain")
    assert (set(_supported_locales) == {"en_US"})
    load_translations("./", encoding = "UTF-16")
    assert (set(_supported_locales) == {"en_US"})
    load_gettext_translations("./", domain = "test_domain")
    assert (set(_supported_locales) == {"en_US"})
    load_translations("./locale")

# Generated at 2022-06-22 03:46:48.300279
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    global _translations
    global _supported_locales
    global _use_gettext
    _translations = {}
    for lang in os.listdir('.'):
        if lang.startswith("."):
            continue  # skip .svn, etc
        if os.path.isfile(os.path.join('.', lang)):
            continue
        try:
            os.stat(os.path.join('.', lang, "LC_MESSAGES", "messages" + ".mo"))
            _translations[lang] = gettext.translation(
                "messages", ".", languages=[lang]
            )
        except Exception as e:
            gen_log.error("Cannot load translation for '%s': %s", lang, str(e))
            continue

# Generated at 2022-06-22 03:47:10.081926
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    _translations = {}
    _supported_locales = ['en']
    csv_locale = CSVLocale('en', _translations)
    test_gettext = csv_locale.translate('test_GettextLocale_translate')
    assert test_gettext == 'test_GettextLocale_translate'

# Generated at 2022-06-22 03:47:19.238183
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for Locale.get method
    def test_get():
        # Fail case
        # If there are no supported locales, it returns None
        assert Locale.get("unknown") is None

        # Success case
        # If there is a Locale instance of the code, it returns the
        # correct value
        assert isinstance(Locale.get("en"), CSVLocale)
        assert Locale.get("en").code == "en"

    test_get()

    # Test for Locale.format_date method

# Generated at 2022-06-22 03:47:21.169253
# Unit test for function get
def test_get():
    get("en_US")
    get("en_US","en")
    get("en_US","en","en_US","zh_CN")


# Generated at 2022-06-22 03:47:23.142732
# Unit test for constructor of class Locale
def test_Locale():
    Locale.get_closest("dfdf", "en_US", "en")
    Locale.get_closest("dfsd", "fa", "en")
    Locale.get("fa")



# Generated at 2022-06-22 03:47:27.082392
# Unit test for function set_default_locale
def test_set_default_locale():
  set_default_locale("en_US")
  assert _default_locale == "en_US"


# Generated at 2022-06-22 03:47:36.808740
# Unit test for constructor of class Locale
def test_Locale():
    def test_translate(locale, in_msg, out_msg):
        if locale.translate(in_msg) != out_msg:
            raise Exception("Failed to translate msg: " + in_msg)

    """ test_Locale constructs a Locale object and checks the translation
    """
    try:
        load_gettext_translations(
            os.path.dirname(os.path.dirname(__file__)) + "/translations", "gen"
        )
    except Exception:
        pass
    locale = Locale.get("zh_CN")
    test_translate(locale, "Function", "函数")
    test_translate(locale, "Function ", "函数 ")
    test_translate(locale, "", "")

# Generated at 2022-06-22 03:47:47.631124
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    from tornado.test.util import unittest
    from tornado.i18n import _translations
    from tornado.i18n import LOCALE_NAMES

    class GettextLocaleTestCase(unittest.TestCase):
        def test_init(self):
            print(_translations)
            gl = GettextLocale('fr', _translations['fr'])
            self.assertEqual(gl.code, 'fr')
            self.assertEqual(gl.name, LOCALE_NAMES['fr']['name'])
            self.assertEqual(gl.rtl, False)

    test = unittest.main()


# Generated at 2022-06-22 03:47:58.147820
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    now = datetime.datetime.now()
    yesterday = now - datetime.timedelta(hours=24)
    tomorrow = now + datetime.timedelta(hours=12)
    locale = Locale.get('fr_FR')
    assert locale.format_date(now) == 'à l’instant'
    assert locale.format_date(yesterday) == 'hier à {0}'.format(yesterday.strftime('%H:%M'))
    assert locale.format_date(yesterday, full_format=True) == yesterday.strftime('%A %d %B %Y à %H:%M')
    assert locale.format_date(tomorrow) == tomorrow.strftime('%A %d %B %Y à %H:%M')

# Generated at 2022-06-22 03:48:01.239002
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("../tornado/locale", "mydomain")


# Generated at 2022-06-22 03:48:04.418145
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("zh")
    assert _default_locale == "zh"
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])



# Generated at 2022-06-22 03:48:46.205574
# Unit test for method list of class Locale
def test_Locale_list():
    #Locale.list([]) = ''
    assert(Locale.list([]) == '')
    #Locale.list(['A']) = 'A'
    assert(Locale.list(['A']) == 'A')
    #Locale.list(['A', 'B', 'C']) = 'A, B and C'
    assert(Locale.list(['A', 'B', 'C']) == 'A, B and C')


if __name__ == '__main__':
    test_Locale_list()



# Generated at 2022-06-22 03:48:55.134799
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():

    testLocale = Locale("en")
    assert "1,234" == testLocale.friendly_number(1234)
    testLocale = Locale("en")
    assert "12,345" == testLocale.friendly_number(12345)
    testLocale = Locale("en")
    assert "123,456,789" == testLocale.friendly_number(123456789)

    testLocale = Locale("fa")
    assert "1,234" == testLocale.friendly_number(1234)



# Generated at 2022-06-22 03:49:00.551008
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    assert get_test_locale().translate("test string") == "test string"
    assert get_test_locale().translate("test string", "test strings", 1) == "test string"
    assert get_test_locale().translate("test string", "test strings", 10) == "test strings"


# Generated at 2022-06-22 03:49:01.509570
# Unit test for method translate of class Locale
def test_Locale_translate():
    assert True

# Generated at 2022-06-22 03:49:03.176302
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("zh_CN")
    assert _default_locale == "zh_CN"


# Generated at 2022-06-22 03:49:09.241295
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    """
    Unit test for method pgettext of class GettextLocale
    """
    # arrange
    locale = GettextLocale("en", None)
    # act
    result = locale.pgettext("context1", "message1")
    # assert
    assert result == "message1"
    assert True

# Generated at 2022-06-22 03:49:19.001580
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import tornado.locale
    import os
    # /www/tornado/tornado/test/i18n/admin/LC_MESSAGES 
    tornado.locale.load_gettext_translations(os.path.dirname(__file__)+'/i18n/admin/LC_MESSAGES/',domain='admin')
    from tornado.locale import _translations
    assert _translations
    assert 'zh_CN' in _translations
    assert _translations['zh_CN']
    print(_translations['zh_CN'].gettext('Logout'))
    print(_translations['zh_CN'].gettext('Login'))
    print(_translations['zh_CN'].gettext('Input something,please.'))

# Generated at 2022-06-22 03:49:26.871473
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    locale = GettextLocale("en", gettext.NullTranslations())
    assert locale.translate("first") == "first"
    assert locale.translate("first", count=10) == "first"
    assert locale.translate("first", "second", count=1) == "first"
    assert locale.translate("first", "second", count=10) == "second"

# Generated at 2022-06-22 03:49:37.506115
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    locale1 = CSVLocale("en_US", {})
    assert locale1.translate("Hello world") == "Hello world"
    assert locale1.translate("Hello world", "Hello worlds", 2) == "Hello worlds"
    assert (
        locale1.translate(
            "Hello world", "Hello worlds", count=2
        ) == "Hello worlds"
    )

    locale2 = CSVLocale(
        "en_US",
        {
            "singular": {
                "Hello world": "Hello world",
                "My name is %(name)s": "My name is %(name)s",
                "My name is %(name)s and my age is %(age)d": "My name is %(name)s and my age is %(age)d",
            }
        },
    )
   

# Generated at 2022-06-22 03:49:42.405970
# Unit test for function load_translations
def test_load_translations():
    load_translations('/Users/chua/github/tornado/tornado/locale')
    # print(type(_translations))
    # print(_translations)
    return _translations



# Generated at 2022-06-22 03:50:22.676953
# Unit test for method list of class Locale
def test_Locale_list():
    """Unit test for method list of class Locale
    """
    fr_FR = Locale.get("fr_FR")
    assert fr_FR.list(['A']) == 'A'
    assert fr_FR.list(['A', 'B']) == 'A et B'
    assert fr_FR.list(['A', 'B', 'C']) == 'A, B et C'
    fa_IR = Locale.get("fa_IR")
    assert fa_IR.list(['A']) == 'A'
    assert fa_IR.list(['A', 'B']) == 'A \u0648 B'
    assert fa_IR.list(['A', 'B', 'C']) == 'A, B \u0648 C'