

# Generated at 2022-06-22 03:40:41.341922
# Unit test for function get
def test_get():
    assert get('en_US')
    assert get('en_US', 'es_LA')
    assert get('en_US', 'es', 'ar')
    assert get('en_US', 'zh-CN', 'zh-TW')
    assert get('es-419')



# Generated at 2022-06-22 03:40:51.588524
# Unit test for method list of class Locale
def test_Locale_list():
    """Unit test for method list of class Locale"""
    assert Locale.get("ar").list(["A", "B"]) == u"\u0627\u0648 \u0628"
    assert Locale.get("fa").list(["A", "B"]) == u"\u0627 \u0648 \u0628"
    assert Locale.get("en").list(["A", "B"]) == "A and B"
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B and C"
    assert Locale.get("en").list(["A", "B", "C", "D"]) == "A, B, C and D"
    assert Locale.get("en").list([]) == ""

# Generated at 2022-06-22 03:41:00.041229
# Unit test for constructor of class Locale
def test_Locale():
    from tornado.escape import to_unicode
    cn = Locale("zh_CN")
    assert isinstance(cn, Locale)
    assert cn.code == "zh_CN"
    assert cn.name == "Chinese (Simplified)"
    assert cn.rtl == False
    assert isinstance(cn.translate("test"), str)
    assert isinstance(cn.pgettext("test", "test"), str)
    assert cn.format_date(datetime.datetime.now())
    assert isinstance(cn.format_day(datetime.datetime.now()), str)
    assert isinstance(cn.list(["a", "b"]), str)
    assert isinstance(cn.friendly_number(100), str)


# Generated at 2022-06-22 03:41:13.273517
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    a = CSVLocale("en", {})
    assert a.pgettext("", "") == ""
    assert a.pgettext("", "1") == "1"
    assert a.pgettext("", "1", "2") == "1"
    assert a.pgettext("", "1", "2", 1) == "1"
    assert a.pgettext("", "1", "2", 2) == "2"
    assert a.pgettext("CONTEXT", "") == ""
    assert a.pgettext("CONTEXT", "1") == "1"
    assert a.pgettext("CONTEXT", "1", "2") == "1"
    assert a.pgettext("CONTEXT", "1", "2", 1) == "1"

# Generated at 2022-06-22 03:41:18.697582
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    code = 'test'
    translations = {'test': {'test': 'test'}}
    locale = CSVLocale(code, translations)
    context = 'test'
    message = 'test'
    plural_message = 'test'
    count = 1
    assert locale.pgettext(context, message, plural_message, count) == 'test'



# Generated at 2022-06-22 03:41:23.580487
# Unit test for function get_supported_locales
def test_get_supported_locales():
    def test_load_translations():
        load_translations('.', '')
        assert len(get_supported_locales()) == 1
    def test_load_gettext_translations():
        load_gettext_translations('.', 'test')
        assert len(get_supported_locales()) == 1



# Generated at 2022-06-22 03:41:30.989290
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    print ("Unit test for method friendly_number of class Locale ...")
    locale = Locale.get("en_US")
    assert locale.friendly_number(123456) == "123,456"
    assert locale.friendly_number(123) == "123"
    assert locale.friendly_number(12) == "12"
    assert locale.friendly_number(1) == "1"
    assert locale.friendly_number(0) == "0"
    print ("Locale.friendly_number passed!")


# Generated at 2022-06-22 03:41:38.803819
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    code = 'en_US'
    class messages:
        default = 'Default message'
        singular = 'Singular message'
        plural = 'Plural message'
    gt_locale = GettextLocale(code, messages)
    assert gt_locale.translate('default') == 'Default message'
    assert gt_locale.translate('default', count=1) == 'Default message'
    assert gt_locale.translate('default', 'plural', 2) == 'Plural message'
    assert gt_locale.translate('default', 'plural', 1) == 'Default message'


# Generated at 2022-06-22 03:41:50.044907
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    date = '2020-05-22 23:32:50.074000'
    local_date = datetime.datetime.strptime(date, '%Y-%m-%d %H:%M:%S.%f')
    t = time.time()
    t = float(t)
    gmt_offset = 0
    now = datetime.datetime.utcnow()
    local_now = now - datetime.timedelta(minutes=gmt_offset)
    local_yesterday = local_now - datetime.timedelta(hours=24)
    difference = now - local_date
    seconds = difference.seconds
    days = difference.days
    _ = Locale.translate
    format = None
    full_format = False

# Generated at 2022-06-22 03:41:55.119983
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert _translations == {}
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    assert _use_gettext == False
    load_gettext_translations("directory","domain")
    assert _translations != {}
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    assert _use_gettext == True
    gen_log.debug("Supported locales: %s", sorted(_supported_locales))



# Generated at 2022-06-22 03:42:26.500804
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    test_code = 'en'
    test_translations = gettext.NullTranslations()
    test = GettextLocale(test_code, test_translations)
    assert test.ngettext == test_translations.ngettext
    assert test.gettext == test_translations.gettext
    assert test.code is test_code



# Generated at 2022-06-22 03:42:33.894518
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    l = CSVLocale("en", {'plural': {'my_message': 'my_translation', 'my_message2': 'my_translation2'}})
    assert l.translate("my_message", "my_message_plural", count=1) == "my_translation"
    assert l.translate("my_message", "my_message_plural") == "my_translation"
    assert l.translate("my_message", "my_message_plural", count=2) == "my_message_plural"



# Generated at 2022-06-22 03:42:46.693769
# Unit test for method format_date of class Locale

# Generated at 2022-06-22 03:42:56.997655
# Unit test for method translate of class Locale
def test_Locale_translate():
    assert _translations['zh_CN'] == {}
    assert _supported_locales == frozenset(['zh_CN'])
    assert _use_gettext == False
    # function-local variables
    code = 'zh_CN'

    # function body
    if code not in cls._cache:
        assert code in _supported_locales
        translations = _translations.get(code, None)
        if not translations:
            locale = CSVLocale(code, {})  # type: Locale
        elif _use_gettext:
            locale = GettextLocale(code, translations)
        else:
            locale = CSVLocale(code, translations)
        cls._cache[code] = locale
    return cls._cache[code]


# Generated at 2022-06-22 03:42:58.592222
# Unit test for constructor of class Locale
def test_Locale():
    test = Locale("en_US")
    result = test.__class__
    assert(result.__name__ == "Locale")


# Generated at 2022-06-22 03:43:11.510593
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    assert Locale('en_US').format_date(datetime.datetime(2016, 5, 13),
                                       gmt_offset=0,
                                       relative=True,
                                       shorter=False,
                                       full_format=False) == 'Friday, May 13'
    assert Locale('en_US').format_date(datetime.datetime(2016, 5, 13),
                                       gmt_offset=0,
                                       relative=False,
                                       shorter=False,
                                       full_format=False) == 'Friday, May 13 at 12:00 AM'

# Generated at 2022-06-22 03:43:18.072865
# Unit test for constructor of class Locale
def test_Locale():
    assert not h._support_locales
    load_translations('locale/csv', _default_locale='en')
    test_Locale = h.Locale.get('en')
    assert test_Locale
    assert test_Locale.code == 'en'
    assert test_Locale.name == 'English'
    assert not test_Locale.rtl


# Generated at 2022-06-22 03:43:23.106996
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    result = GettextLocale("en_US", _translations["en_US"]["unknown"]).pgettext("law", "right")
    assert result == "right"


_locale_cache: Dict[str, Locale] = {}



# Generated at 2022-06-22 03:43:25.370189
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    assert Locale.get_closest("en_US").code == "en_US"



# Generated at 2022-06-22 03:43:27.318949
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _default_locale in _supported_locales
    assert _default_locale in get_supported_locales()



# Generated at 2022-06-22 03:43:50.290809
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    loc = Locale.get('all')
    assert loc.friendly_number(123456789)=='123,456,789'


# Generated at 2022-06-22 03:43:59.150845
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    csvLocale = CSVLocale("und_UND", {"unknown": {"hello": "hallo"}})
    result = csvLocale.translate("hello")
    assert result == "hallo"
    result = csvLocale.translate("hi")
    assert result == "hi"
    result = csvLocale.translate("hi", "hui", 1)
    assert result == "hi"
    result = csvLocale.translate("hi", "hui", 2)
    assert result == "hui"



# Generated at 2022-06-22 03:44:04.557605
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    l = Locale.get("en")
    s = l.format_day(datetime(2020, 1, 22), gmt_offset=-5, dow=True)
    assert s == "Wednesday, January 22"
    s = l.format_day(datetime(2020, 2, 5), gmt_offset=-5, dow=False)
    assert s == "February 5"


# Generated at 2022-06-22 03:44:13.175221
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    locale = CSVLocale("...", {})
    assert locale.translate("foo") == "foo"
    assert locale.translate("foo", "foo", 1) == "foo"
    assert locale.translate("foo", "foo", 2) == "foo"
    locale = CSVLocale("...", {"unknown": {"foo": "bar"}})
    assert locale.translate("foo") == "bar"
    assert locale.translate("foo", "foo", 1) == "bar"
    assert locale.translate("foo", "foo", 2) == "foo"
    locale = CSVLocale("...", {"plural": {"foo": "bar"}})
    assert locale.translate("foo") == "foo"
    assert locale.translate("foo", "foo", 1) == "foo"

# Generated at 2022-06-22 03:44:26.558466
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class TestLocale(GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations):
            self.ngettext = translations.ngettext
            self.gettext = translations.gettext
        def translate(self,
                      message: str,
                      plural_message: Optional[str] = None,
                      count: Optional[int] = None):
            if plural_message is not None:
                assert count is not None
                return self.ngettext(message, plural_message, count)
            else:
                return self.gettext(message)

    # Sample translations file
    translations = gettext.NullTranslations()

# Generated at 2022-06-22 03:44:39.085632
# Unit test for method translate of class Locale
def test_Locale_translate():
    """Unit test for method translate of class Locale"""
    # Include your application code here.
    # If it uses Tornado, use `from tornado.testing import AsyncHTTPTestCase`
    # instead of `unittest` and call `self.stop` on completion
    # instead of `return`.

    # This method will be run in a separate process.
    # Here we just simulate it by calling test() synchronously.
    # Tests should send output to stdout or stderr or write it
    # to a file in self.get_output_dir(), which is deleted after
    # the test finishes.
    # You can also use self.io_loop: it is set up to forward
    # stdin, stdout, and stderr.

# Generated at 2022-06-22 03:44:50.469871
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    translations = {
        "unknown": {
            "WORD": "context-WORD",
            "WORD-OTHERWORD": "context-WORD-OTHERWORD"
        }
    }
    l = CSVLocale("en", translations)
    assert l.pgettext("context", "WORD") == "context-WORD"
    assert l.pgettext("context", "WORD", "WORD-OTHERWORD") == "context-WORD-OTHERWORD"
    assert l.pgettext("context", "WORD", "WORD-OTHERWORD", count=2) == "context-WORD-OTHERWORD"
test_CSVLocale_pgettext()



# Generated at 2022-06-22 03:44:51.819156
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")


# Generated at 2022-06-22 03:44:55.007083
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("it_IT")
    assert (_default_locale == "it_IT")
    assert (_supported_locales == frozenset(list(_translations.keys()) + [_default_locale]))


# Generated at 2022-06-22 03:45:08.156741
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    code = "ru" # taken from above list _supported_locales
    class POT:
        """Mockup of class `gettext.POT` which is used by class GettextTranslations"""
        def __init__(self, locale_code, locale_name):
            self.name = locale_name
            self.locale = locale_code
    class GettextTranslations(object):
        """
        Mockup of class gettext.GettextTranslations.

        This class is used only for python <= 3.7. In python 3.8
        gettext.NullTranslations was replaced with gettext.GettextTranslations
        so we need to emulate it in tests.
        """
        def __init__(self, locale_code, locale_name):
            self.pot = POT(locale_code, locale_name)

# Generated at 2022-06-22 03:45:49.333337
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    def check_translations(final_dict: Any, message: Any) -> None:
        for k, v in message.items():
            if isinstance(v, dict):
                check_translations(final_dict[k], v)
            elif isinstance(v, list):
                for i in v:
                    assert i in final_dict[k]
            else:
                assert v in final_dict[k]

    with open("locale/zh_TW/LC_MESSAGES/messages.json") as f:
        messages_zh_TW = json.load(f)
        locale = Locale("zh_TW")
        check_translations(messages_zh_TW, messages_zh_TW)
        final_dict = {} # type: Any
        print("Starting.")

# Generated at 2022-06-22 03:45:55.748296
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(1234567890) == "1,234,567,890"
    assert Locale.get("fa_IR").friendly_number(1) == "1"
    assert Locale.get("fa_IR").friendly_number(1234567890) == "1234567890"



# Generated at 2022-06-22 03:46:01.872102
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    from unittest.mock import patch
    from typing import Dict, Any

    # Mock the translation function to return the same translation as input message
    with patch('matrix_tornado.i18n.translate', return_value = 'test'):
        # The constructor should not raise any exception.
        translations = {} # type: Dict[str, Dict[str, str]]
        locale = CSVLocale('id', translations)



# Generated at 2022-06-22 03:46:03.300842
# Unit test for method translate of class Locale
def test_Locale_translate():
    _test_translate(translate=Locale.translate)


# Generated at 2022-06-22 03:46:03.904019
# Unit test for function get
def test_get():
    pass



# Generated at 2022-06-22 03:46:10.317346
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    cls = CSVLocale
    locale_code = 'pt_BR'
    context = 'context'
    message = 'message'
    plural_message = 'plural message'
    count = 2
    translations = dict()
    csv_locale = cls(locale_code,translations)
    assert csv_locale.pgettext(context,message,plural_message,count) == translation.translate(message, plural_message, count)



# Generated at 2022-06-22 03:46:12.147154
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    assert GettextLocale('en_US', gettext.NullTranslations()).translate('unknown') == 'unknown'

# Generated at 2022-06-22 03:46:18.877333
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    try:
        csv_file = "{}/{}".format(os.path.dirname(os.path.dirname(__file__)), 'locale/templates/test.csv')
        load_translations(csv_file, ('test'))
        _ = Locale('test').translate
        
        # Test #1
        assert _('&nbsp;') == '&nbsp;'
        
        # Test #2
        assert _('test','test2') == 'test'
        
        # Test #3
        assert _('test','test2', 1) == 'test'
        
        # Test #4
        assert _('test','test2', 2) == 'test2'

        # Test #5
        assert _('test','test2', 3) == 'test2'
    except:
        pass

# Generated at 2022-06-22 03:46:29.837107
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    def run(code: str, translations, result: str):
        locale = CSVLocale(code, translations)
        assert locale.translate("test") == result
    run("en", {"unknown": {"test": "test"}}, "test")
    run("en_US", {"unknown": {"test": "test"}}, "test")
    run("zh_CN", {"unknown": {"test": "测试"}}, "测试")
    run("zh_TW", {"unknown": {"test": "測試"}}, "測試")
    run("zh_MO", {"unknown": {"test": "測試"}}, "測試")
    run("fa", {"unknown": {"test": "تست"}}, "تست")

# Generated at 2022-06-22 03:46:35.984592
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    count = 1
    context = 'unknown'
    message = 'singular'
    plural_message = 'plural'
    locale = CSVLocale(context, {'singular': {message: plural_message}})
    translation = locale.pgettext(context, message, plural_message, count)
    assert (translation == plural_message) is True


# Generated at 2022-06-22 03:47:09.076086
# Unit test for method list of class Locale
def test_Locale_list():
    load_translations("locale", "ko")
    ko = Locale.get("ko")
    assert ko.list([]) == ""
    assert ko.list(["A"]) == "A"
    assert ko.list(["A", "B"]) == "A, B"
    assert ko.list(["A", "B", "C"]) == "A, B, C"
    assert ko.list(["A", "B", "C", "D"]) == "A, B, C, D"
    assert ko.list(["A", "B", "C", "D", "E"]) == "A, B, C, D, E"
    load_translations("locale", "ja")
    ja = Locale.get("ja")
    assert ja.list([]) == ""

# Generated at 2022-06-22 03:47:14.575307
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
	locale_object1 = Locale.get('en')
	locale_object2 = Locale.get('en_US')
	input_value = 12345678
	expect_value = "12,345,678"
	result1 = locale_object1.friendly_number(input_value)
	result2 = locale_object2.friendly_number(input_value)
	assert result1 == expect_value and result2 == expect_value



# Generated at 2022-06-22 03:47:15.669295
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    pass


# Generated at 2022-06-22 03:47:19.424536
# Unit test for function get
def test_get():
    test_locale_codes = ["fake_locale", "en_US", "en_WTF"]
    result = get(*test_locale_codes)
    assert result == Locale.get_closest("fake_locale", "en_US", "en_WTF")
    assert result.code == "en_US"



# Generated at 2022-06-22 03:47:31.814286
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    rootpath = Path("/home/chris/Documents/Programming/realpython/ZulipProject/")
    po_path = rootpath / "pgettext_tests" / "zh_TW" / "LC_MESSAGES" / "messages.po"
    path = rootpath / "pgettext_tests" / "zh_TW" / "LC_MESSAGES" / "django.mo"
    path = str(path)

    p = GettextParser()
    test = p.parse(po_path)
    ba = BuildAction(test.translations, path)
    ba.execute()

    locale = GettextLocale("zh_TW", gettext.GNUTranslations(open(path, "rb")))
    # print(locale.pgettext(u"law", u"right"))
   

# Generated at 2022-06-22 03:47:36.188342
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    with open(
        os.path.join(os.path.dirname(__file__), "locale", "test_CSVLocale_translate.json")
        ) as f:
        data = json.load(f)
        for k, v in data.items():
            x = str(k)
            y = str(v)
            if x == y:
                continue
            print(x)



# Generated at 2022-06-22 03:47:48.599214
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    import sys
    import os
    
    class DummyObject(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    sys.modules['tornado'] = DummyObject()
    sys.modules['tornado.locale'] = DummyObject()
    sys.modules['tornado.locale.load_translations'] = DummyObject(
        load_translations=load_translations)
    sys.modules['gettext'] = DummyObject(
        gettext=gettext,
        NullTranslations=DummyObject)

    # one segment of 1, then two segment of 5, then one segment of 30, 
    # then two segment of 5
    
    # add translation
    load_translations("locale")


# Generated at 2022-06-22 03:47:51.968330
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    import inspect
    import logging
    lines = inspect.getsource(CSVLocale.translate)
    logging.info(lines)
    if "plural_message" in lines:
        assert True
    else:
        assert False



# Generated at 2022-06-22 03:47:56.762368
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    my_locale = CSVLocale(str, dict())
    msg, msg_plural, cnt = "msg", "msg_plural", 2
    my_locale.pgettext(context = "context", message = msg, plural_message = msg_plural, count = cnt)


# Generated at 2022-06-22 03:48:08.429189
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test case to check if the weekdays and month_names are formed as
    # per the locale
    _de_de = Locale("de_DE")
    _de_de_date = _de_de.format_date(1476907200-7200, relative=False)
    assert _de_de_date == 'Donnerstag, 22. Sept. 2016'
    # Test case to check the output of method format_date
    _de_de = Locale("de_DE")
    _de_de_date = _de_de.format_date(1476907200, relative=True)
    assert _de_de_date == 'vor 2 Tagen'
    _de_de = Locale("de_DE")

# Generated at 2022-06-22 03:48:38.755059
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert(Locale.get("en").friendly_number(1) == "1")
    assert(Locale.get("en").friendly_number(12) == "12")
    assert(Locale.get("en").friendly_number(123) == "123")
    assert(Locale.get("en").friendly_number(1234) == "1,234")
    assert(Locale.get("en").friendly_number(12345) == "12,345")
    assert(Locale.get("en").friendly_number(123456) == "123,456")
    assert(Locale.get("en").friendly_number(1234567) == "1,234,567")
    assert(Locale.get("en").friendly_number(12345678) == "12,345,678")

# Generated at 2022-06-22 03:48:41.154715
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales == get_supported_locales()



# Generated at 2022-06-22 03:48:41.707085
# Unit test for function get
def test_get():
    pass



# Generated at 2022-06-22 03:48:53.318987
# Unit test for method list of class Locale
def test_Locale_list():
    """ Returns a comma-separated list for the given list of parts.
    The format is, e.g., "A, B and C", "A and B" or just "A" for lists
    of size 1.
    """
    # Simple testcase
    locale = Locale("ja")
    list_parts = ["A","B","C"]
    comma = u" \u0648 "
    assert locale.list(list_parts) == "A, B and C"
    # Using comma in Persian(fa)
    locale = Locale("fa")
    assert locale.list(list_parts) == "A \u0648 B \u0648 C"
    # Simple testcase
    locale = Locale("ja")
    list_parts = ["A","B","C","D","E","F"]

# Generated at 2022-06-22 03:49:04.687486
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    def test_helper():
        sample_input = input()
        if sample_input in (None, ""):
            sample_input = "English"
        locale_code = sample_input
        translations = {
            "context": {
                "plural": {
                    "Unread %(num)s messages": "You have %(num)s unread messages",
                    "Unread %(num)s message": "You have %(num)s unread message"
                },
                "singular": {
                    "Unread 1 message": "You have %(num)s unread message",
                    "Unread 1 messages": "You have %(num)s unread messages"
                },
                "unknown": {"Unread %(num)s messages": "%(num)s unread messages"}
            }
        }
        translations = translations

# Generated at 2022-06-22 03:49:17.200268
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en_US").friendly_number(123456789) == "123,456,789"
    assert Locale.get("en_US").friendly_number(12345) == "12,345"
    assert Locale.get("en_US").friendly_number(0) == "0"

    assert Locale.get("en").friendly_number(123456789) == "123,456,789"
    assert Locale.get("en").friendly_number(12345) == "12,345"
    assert Locale.get("en").friendly_number(0) == "0"

    assert Locale.get("zh_CN").friendly_number(123456789) == "123456789"
    assert Locale.get("zh_CN").friendly_number(12345) == "12345"
   

# Generated at 2022-06-22 03:49:20.154347
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("en").format_day(datetime.datetime(2019, 2, 10)) == "Sunday, Feb 10"
    assert Locale.get("en").format_day(datetime.datetime(2019, 2, 10), dow=False) == "Feb 10"



# Generated at 2022-06-22 03:49:29.237391
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    code = "en"
    # translations is a gettext.NullTranslations() object
    translations = gettext.NullTranslations()
    obj = GettextLocale(code, translations)
    assert obj.code == "en"


_supported_locales = ["en"]
# Specifies which locales we make available to the browser client.
# This is used when we generate our Javascript locale file.
_js_locales = ["en"]

# The locale that we assume users speak if we have no other information
_default_locale = "en"



# Generated at 2022-06-22 03:49:34.347959
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    c = CSVLocale('pt_BR', {})
    assert (c.translate('hola') == 'hola'), 'test_CSVLocale_translate failed'
test_CSVLocale_translate()


# Generated at 2022-06-22 03:49:39.434942
# Unit test for constructor of class Locale
def test_Locale():
    Locale("en")
    Locale("en_US")
    Locale("en_GB")
    Locale("zh_CN")
    Locale("de_DE")
    Locale("pt_BR")
    Locale("fr_FR")

