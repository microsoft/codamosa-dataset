

# Generated at 2022-06-22 03:41:07.929719
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # test 1
    set_default_locale('en_US')
    test = Locale.get('en_US').format_date(time.mktime((2020, 1, 1, 5, 23, 0, 0, 0, 0)))
    assert test == 'January 1 at 5:23 am'
    # test 2
    set_default_locale('en_US')
    test = Locale.get('en_US').format_date(time.mktime((2020, 1, 1, 5, 23, 0, 0, 0, 0)), full_format=True)
    assert test == 'January 1, 2020 at 5:23 am'


# Generated at 2022-06-22 03:41:15.020685
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    test_code = "code_0"
    test_translations = {
        "unknown": {
            "one": "uno",
            "two": "dos",
            "three": "tres",
            "four": "quatro",
        }
    }
    test_locale = CSVLocale(test_code, test_translations)
    assert test_locale.code == test_code
    assert test_locale.translations == test_translations



# Generated at 2022-06-22 03:41:18.624506
# Unit test for function set_default_locale
def test_set_default_locale():
    print ("Testing function set_default_locale")
    set_default_locale("es_LA")
    c=get_default_locale()
    assert c=="es_LA"
    print ("passed")

# Generated at 2022-06-22 03:41:23.394831
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    c = CSVLocale('en', {'singular': {'hello':'hello'}})
    c.pgettext('', 'hello')


# Generated at 2022-06-22 03:41:34.619168
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    # Python 2.6 does not have timegm function
    import time
    if not hasattr(time, "timegm"):
        time.timegm = time.mktime
        import calendar
        calendar.timegm = time.mktime
    translator = gettext.translation(
        "windmill", None, ["locale_data"], fallback=True
    )
    locale = GettextLocale("fa", translator)
    assert locale.code == "fa"
    assert locale.name == "Persian"
    assert locale.rtl is True
    assert locale.translate(u"Welcome") == u"خوش آمدید"

    locale = GettextLocale("en", translator)
    assert locale.code == "en"
    assert locale.name == u"English"

# Generated at 2022-06-22 03:41:39.252288
# Unit test for method translate of class Locale
def test_Locale_translate():
    load_translations('locale')
    locale=Locale.get('en')
    locale.translate('Hello',plural_message=None,count=None)

# Generated at 2022-06-22 03:41:42.951941
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(directory=TESTDIR, domain=TESTDOMAIN)
    assert load_gettext_translations(directory=TESTDIR, domain=TESTDOMAIN)



# Generated at 2022-06-22 03:41:44.166251
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("abc")



# Generated at 2022-06-22 03:41:45.728088
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert isinstance(get_supported_locales(), frozenset)



# Generated at 2022-06-22 03:41:46.373281
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    pass

# Generated at 2022-06-22 03:42:26.280368
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    gt = FakeGettext()
    test_loc = GettextLocale("fake", gt)
    test_loc.code = "und"
    test_loc.name = u"Unknown"
    test_loc._months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ]
    test_loc._weekdays = [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
    ]
    test_loc.rtl = False
    # test 1

    result = test_loc.pgettext("law", "right")

# Generated at 2022-06-22 03:42:29.774191
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import sys
    import os
    # setup test environment
    cur_path = os.path.dirname(os.path.realpath(__file__))
    sys.path = [cur_path] + sys.path
    # import tornado.locale
    from tornado.locale import *  
    #
    load_gettext_translations(os.path.join(cur_path, "test_data"), "mydomain")
    assert _translations is not None
    assert _supported_locales is not None
    assert _use_gettext is True
    assert len(_translations) == 2



# Generated at 2022-06-22 03:42:36.485535
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    d = {'选择所有': {'singular': {'Select all': '选择所有'}, 'unknown': {'Select all': '选择所有'}}}
    l = CSVLocale('zh_CN', d)
    assert l.pgettext('', 'Select all') == '选择所有'



# Generated at 2022-06-22 03:42:48.603076
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():

    #Test for English language
    locale_obj = Locale.get("en")
    result = locale_obj.friendly_number(100)
    result_expected = "100"
    assert result == result_expected, "Test case for English failed"

    #Test for German language
    locale_obj = Locale.get("de")
    result = locale_obj.friendly_number(100)
    result_expected = "100"
    assert result == result_expected, "Test case for German failed"

    #Test for Japanese language
    locale_obj = Locale.get("ja")
    result = locale_obj.friendly_number(100)
    result_expected = "100"
    assert result == result_expected, "Test case for Japanese failed"

    #Test for Hindi language
    locale_obj = Locale.get("hi")
    result

# Generated at 2022-06-22 03:42:58.592979
# Unit test for constructor of class Locale
def test_Locale():
    x = Locale.get('en')
    assert x is not None
    # check to make sure the Locale class isn't empty
    assert 'name' in vars(x)
    assert x.name == 'English'
    assert 'code' in vars(x)
    assert x.code == 'en'
    assert 'rtl' in vars(x)
    assert x.rtl == False
    assert '_months' in vars(x)
    assert x._months == ['January', 'February', 'March',
            'April', 'May', 'June', 'July', 'August',
            'September', 'October', 'November', 'December']
    assert '_weekdays' in vars(x)

# Generated at 2022-06-22 03:43:07.310632
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    a = Locale.get("en")
    assert "100" == a.friendly_number(100)
    assert "1,000" == a.friendly_number(1000)
    assert "1,234,567" == a.friendly_number(1234567)

    b = Locale.get("zh_CN")
    assert "100" == b.friendly_number(100)
    assert "1000" == b.friendly_number(1000)
    assert "1234567" == b.friendly_number(1234567)



# Generated at 2022-06-22 03:43:08.379556
# Unit test for method translate of class Locale
def test_Locale_translate():
    assert True


# Generated at 2022-06-22 03:43:12.883879
# Unit test for constructor of class Locale
def test_Locale():
    for lang in LOCALE_NAMES.keys():
        if lang in _supported_locales:
            assert Locale(lang)
        else:
            assert not Locale(lang)



# Generated at 2022-06-22 03:43:17.284466
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = './translations'
    domain = 'messages'
    load_gettext_translations(directory, domain)
    assert(_translations['ja'].gettext('登录') == 'ログイン')



# Generated at 2022-06-22 03:43:24.066027
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/carlos/git/tornado-exercise/exercise/locale/en_US.csv")
    assert len(_translations) > 0
    global _translations
    global _supported_locales
    _translations = {"en_US": {}}
    _supported_locales = (_translations.keys()) + [_default_locale]



# Generated at 2022-06-22 03:44:02.062556
# Unit test for method translate of class Locale
def test_Locale_translate():
    """Unit tests for the translate method of the Locale class"""
    import sys
    try:
        # Python 2
        reload(sys)
        sys.setdefaultencoding('utf8')
    except NameError:
        # Python 3
        pass

    # Test method translate of class Locale
    # Test case 1
    # Description of test case:
    # locale: None
    # message: "test_message"
    # plural_message: None
    # count: None
    # expected result: "test_message"
    test_message = "test_message"
    result = Locale.get(None).translate(test_message)
    assert result == test_message, "Locale.translate error: " + result

    # Test case 2
    # Description of test case:
    # locale: None
    # message: "

# Generated at 2022-06-22 03:44:10.118896
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    locale = CSVLocale("en", None)
    assert locale.code == "en"
    assert str(locale) == "Locale (en)"
    assert locale.name == "English"
    assert not locale.rtl
    assert locale.translations is None

    locale = CSVLocale("ko_KR", {"unknown": {"hi": "안녕하세요."}})
    assert locale.translate("hi") == "안녕하세요."
    assert locale.translate("hi", count=2) == "hi"

    assert locale.friendly_number(1234567890) == "1,234,567,890"



# Generated at 2022-06-22 03:44:21.485078
# Unit test for method translate of class Locale
def test_Locale_translate():
    # Testing method translate of class Locale
    # format of the language code of a Locale is not correct
    with pytest.raises(NotImplementedError):
        Locale('en_EN').translate('login')
    # format of the language code of a Locale is not correct
    with pytest.raises(NotImplementedError):
        # test the format of the plural_message parameter
        Locale('en_EN').translate('login', 'new login', 2)
        # test the value of the variable count
        Locale('en_EN').translate('login', 'new login', 5)
    # test the format of the variable message
    with pytest.raises(NotImplementedError):
        Locale('en').translate(123)
    # test the format of the variable message

# Generated at 2022-06-22 03:44:33.490698
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    import random
    import os
    import json
    from tornado.ioloop import IOLoop
    from tornado.web import Application, RequestHandler
    from tornado.web import StaticFileHandler
    from tornado.httpclient import HTTPClient, HTTPRequest
    from tornado.httpserver import HTTPServer
    from tornado.testing import LogTrapTestCase
    from tornado.options import options, parse_command_line
    import tornado.web
    import tornado.escape
    import tornado.platform.asyncio
    import tornado_mysql
    import tornado.autoreload
    import tornado.gen
    import argparse
    import functools
    import logging
    import tornado
    reload(tornado.platform.asyncio)
    # tornado.autoreload can interfere with threading tests

# Generated at 2022-06-22 03:44:39.447883
# Unit test for method translate of class Locale
def test_Locale_translate():
    '''
     Args:
         message(str): message to be translated.
         plural_message(Optional[str]): plural message to be translated.
         count(Optional[int]): Number of times message is to be repeated.
     Returns:
         str: translated message.
    '''
    assert 1 == 1


# Generated at 2022-06-22 03:44:51.909018
# Unit test for function get
def test_get():
    locales = ['en_US', 'es_AR', 'es_PE', 'es_CL', 'es_MX', 'es_ES']
    for i in range(3):
        for locale_code in locales:
            locale = get(locale_code)
            assert locale.code == locale_code
            assert locale.codes == locale_code.split('_')
            assert isinstance(locale.name, str)
            assert isinstance(locale.translate('Test'), str)
            assert isinstance(locale.date(datetime.date(2013, 1, 2)), str)
            assert isinstance(locale.time(datetime.time(15, 30)), str)
            assert isinstance(locale.datetime(datetime.datetime(2013, 1, 2,
                                                               15, 30)), str)

# Generated at 2022-06-22 03:44:54.043692
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = 'locale'
    domain = 'quotes'
    load_gettext_translations(directory, domain)


# Generated at 2022-06-22 03:44:54.778476
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    pass



# Generated at 2022-06-22 03:45:03.995178
# Unit test for function get
def test_get():
    assert get('ja_JP') == 'ja_JP'
    assert get('ja') == 'ja_JP'
    assert get('ja', 'en') == 'ja_JP'
    assert get('ja', 'en_US') == 'en_US'
    assert get('ja', 'en_US') == 'en_US'
    assert get('ja', 'en_US') == 'en_US'
    assert get() == 'en_US'




# Generated at 2022-06-22 03:45:11.278985
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    """Test for CSVLocale class constructor.
    """
    # pylint: disable=unused-variable
    # pylint: disable=no-value-for-parameter
    translations = {
        "singular": {"Add": "Add"},
        "unknown": {"Audio": "Audio"},
        "plural": {"Photos": "Photos"}
    }
    locale = CSVLocale("en", translations)
    assert(locale.translate("Add") == "Add")
    assert(locale.translate("Audio") == "Audio")
    assert(locale.translate("Photos") == "Photos")



# Generated at 2022-06-22 03:45:44.589087
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import tornado
    import os
    import tornado.testing
    import tornado.ioloop
    import tempfile
    import io
    import gettext
    import subprocess

    def _check_translation_check_translation(string):
        return "Run " + string

    def _check_translation(root_directory):

        test_locale = "de"
        expected_result = "Laufen Sie"

        # Create a .mo file in the temporary directory
        locale_directory = os.path.join(root_directory, test_locale, "LC_MESSAGES")
        try:
            os.makedirs(locale_directory)
        except OSError as e:
            assert False, "Error creating a temporary directory during test_translation: %s" % e

# Generated at 2022-06-22 03:45:48.197044
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import sys, os
    import unittest
    from tornado.test.util import unittest

    test_directory = os.path.dirname(os.path.abspath(__file__))
    os.path.join(test_directory, "data", "locale")
    load_gettext_translations(
        directory=os.path.join(test_directory, "data", "locale"),
        domain="tornado.test",
    )



# Generated at 2022-06-22 03:45:56.284039
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    t = gettext.translation(
        "pytest",
        localedir=os.path.join(os.path.dirname(__file__), "i18n"),
        languages=["en_US"],
    )
    code = "en_US"
    locale = CSVLocale(code, t)
    plural_message = locale.pgettext("context", "Hello, {name}!\nHow are you?", "Hello, {name}!\nHow are you?", 1)
    assert plural_message == "Hello, {name}!\nHow are you?"


# Generated at 2022-06-22 03:45:58.094365
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    assert _default_locale == "en_US"


# Generated at 2022-06-22 03:46:03.760779
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert _translations == {}
    assert _supported_locales == frozenset()
    assert _use_gettext == False
    load_gettext_translations(directory="my_directory", domain="my_domain")
    assert _translations != {}
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    assert _use_gettext == True


# Generated at 2022-06-22 03:46:12.491722
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    x = GettextLocale(code="en", translations=gettext.NullTranslations())
    assert x.pgettext(context="law", message="right") == "right"
    assert x.pgettext(context="good", message="right") == "right"
    assert x.pgettext(context="stick", message="club", plural_message="clubs", count=2) == "clubs"
    assert x.pgettext(context="good", message="club", plural_message="clubs", count=2) == "clubs"
    assert x.pgettext(context="good", message="club", plural_message="clubs", count=1) == "club"


# Generated at 2022-06-22 03:46:21.531085
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    csv_translations = {
        "singular": {
            "Hello": "Hello",
            "You have a new message.": "You have a new message.",
        }
    }
    my_locale = CSVLocale("en", csv_translations)
    csv_translations_p = my_locale.pgettext("test", "Hello", "You have %s new messages.", 1)
    assert csv_translations_p == my_locale.translate("Hello", "You have %s new messages.", 1)
    # Since we are implementing the case with no context, the returned value is the same as that
    # returned by method translate



# Generated at 2022-06-22 03:46:32.717006
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    code = 'es'

# Generated at 2022-06-22 03:46:45.073865
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    import tornado.locale

    class MyGettextLocale(tornado.locale.GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations) -> None:
            self.ngettext = translations.ngettext
            self.gettext = translations.gettext
            # self.gettext must exist before __init__ is called, since it
            # calls into self.translate
            super().__init__(code, translations)

    tornado.locale.GettextLocale = MyGettextLocale

    translation = tornado.locale.get("ru")
    assert translation
    # gettext.NullTranslations has only one method ngettext so it can't be used for testing
    # and the method gettext must be created
    translation.gettext = lambda s: s

# Generated at 2022-06-22 03:46:49.872545
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    """Ensure that the constructor of GettextLocale is not broken"""
    t = gettext.GNUTranslations(io.BytesIO("""
msgid ""
msgstr ""
"Language: en\n"

msgid "Hello"
msgstr "Hello"
"""))
    locale = GettextLocale("en", t)
    assert locale.translate("Hello") == "Hello"


# Generated at 2022-06-22 03:47:51.130922
# Unit test for function load_translations
def test_load_translations():
    import os
    import shutil
    import tempfile

    def get_translations(locale):
        return _translations[locale]

    dir_name = tempfile.mkdtemp()


# Generated at 2022-06-22 03:47:56.305716
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    CSVLocale = CSVLocale('en',translations={'singular':{'Hello':'Hello','world':'World'}})
    assert CSVLocale.translate('Hello') == 'Hello','translate singular'
    assert CSVLocale.translate('world') == 'World','translate singular'
    assert CSVLocale.translate('not_a_word') == 'not_a_word','translate singular'
    CSVLocale = CSVLocale('en',translations={'plural':{'Hello':'Hello','world':'World'},'singular':{}})
    assert CSVLocale.translate('Hello') == 'Hello','translate plural'
    assert CSVLocale.translate('world') == 'World','translate plural'

# Generated at 2022-06-22 03:47:58.100189
# Unit test for function get_supported_locales
def test_get_supported_locales():
    return get_supported_locales() == frozenset(["en_US"])



# Generated at 2022-06-22 03:47:59.594702
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert get_supported_locales() == sorted(_supported_locales)



# Generated at 2022-06-22 03:48:07.203654
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en").list(["a", "b", "c"]) == "a, b and c"
    assert Locale.get("en").list(["a", "b"]) == "a and b"
    assert Locale.get("en").list(["a"]) == "a"
    assert Locale.get("es").list(["a", "b", "c"]) == "a, b y c"


# Generated at 2022-06-22 03:48:09.705361
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    code = 'en'
    translations = {"test": {"unknown": "test"}}
    CSVLocale(code, translations)


# Generated at 2022-06-22 03:48:19.936736
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    import gettext
    mo_file_path = "../build/locale/ja/LC_MESSAGES/zulip.mo"
    mo_file = gettext.GNUTranslations(open(mo_file_path, "rb"))
    ja_locale = GettextLocale("ja", mo_file)
    test_sentence = "Test sentence: %s"
    print(ja_locale.pgettext("law", test_sentence))
    print(ja_locale.pgettext("good", test_sentence, "Test sentences", 2))


# Generated at 2022-06-22 03:48:32.238162
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    import unittest
    # create some dates
    # UTC
    date1 = datetime.datetime(2017,12,3)
    date2 = datetime.datetime(2016,1,12)
    # not UTC
    date_not_utc = datetime.datetime(2018,12,3,7,20)

    # create a TestCase class
    test_case = unittest.TestCase()
    for code in _supported_locales:
        # create a Local object
        locale = Locale.get(code)
        # test the given date with GMT 0 offset is UTC
        test_case.assertEqual(locale.format_day(date1,gmt_offset=0,dow=True), 'Sunday, December 3')
        # test the given date with GMT 2 offset is not UTC
        test_case

# Generated at 2022-06-22 03:48:43.555428
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import tempfile
    from glob import glob
    from contextlib import contextmanager
    from os import path

    @contextmanager
    def tmpdir():
        name = tempfile.mkdtemp()
        try:
            yield name
        finally:
            for f in glob(name + "/*"):
                os.remove(f)
            os.rmdir(name)


# Generated at 2022-06-22 03:48:50.426490
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    now = datetime.datetime.utcnow()
    tokyo = Locale.get("ja")
    assert tokyo.format_day(now, dow=False) == u"1月1日"
    assert now.day > 6
    assert tokyo.format_day(now, dow=True) == u"1月1日, 日曜日"

# Generated at 2022-06-22 03:49:18.179179
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    locale = CSVLocale('en', {})
    locale.pgettext('context', 'message')


# Generated at 2022-06-22 03:49:23.748703
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    class TestLocale(Locale):
        def translate(self, message):
            return message
    l = TestLocale("en")
    print(l.format_date(datetime.datetime(2009,2,14,11,22,33),gmt_offset=-5))


# Generated at 2022-06-22 03:49:34.095517
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    msg_dict1 = {'hello': 'hallo'}
    msg_dict2 = {'hello': 'hallo', 'goodbye': 'auf wiedersehen'}
    msg_dict3 = {'message': 'nachricht', 'messages': 'nachrichten'}
    msg_dict4 = {'message': 'nachricht', 'messages': 'nachrichten', 'hello': 'hallo'}
    msg_dict5 = {'message': 'nachricht', 'messages': 'nachrichten', 'hello': 'hallo', 'goodbye': 'auf wiedersehen'}
    msg_dict6 = {'hello': 'hallo'}

    class fake_gettext(object):
        def __init__(self, trans):
            super().__init__

# Generated at 2022-06-22 03:49:40.543202
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    """Test to confirm the constructor works as expected.
    """
    a_locale = GettextLocale("en_US", gettext.NullTranslations())
    assert a_locale.code == "en_US"
    assert a_locale.name == "English"
    assert not a_locale.rtl
    assert len(a_locale._months) == 12
    assert len(a_locale._weekdays) == 7



# Generated at 2022-06-22 03:49:47.308049
# Unit test for function get
def test_get():
    # 1. Test if the get() method can get Locale object correctly
    assert isinstance(get(), Locale)

    # 2. Test if get() can get correct locale object with locale code
    locale_codes = locale_codes = ['en', 'en_US']
    assert get() == get(*locale_codes)

    # 3. Test if the get() can get correct locale object with correct
    # locale names
    locale_names = ['English', 'English (United States)']
    assert get() == get(*locale_names)

    # 4. Test if get() can return none correctly
    locale_names = ['asd']
    assert get() != get(*locale_names)

    # 5. Test if get() can handle locale code correctly
    locale_codes = ['zh', 'zh_CN']

# Generated at 2022-06-22 03:49:48.527034
# Unit test for method translate of class Locale
def test_Locale_translate():
    a = Locale("a")
    assert a.translate("message") == "message"



# Generated at 2022-06-22 03:49:53.625810
# Unit test for method translate of class Locale
def test_Locale_translate():
    class DummyLocale(Locale):
        def __init__(self, code):
            Locale.__init__(self, code)

    loc = DummyLocale("pt")
    assert loc.translate("I am a banana") == "Eu sou uma banana"


# Generated at 2022-06-22 03:49:54.611974
# Unit test for function get
def test_get():
    print(get("en"))


# Generated at 2022-06-22 03:50:03.705684
# Unit test for method friendly_number of class Locale

# Generated at 2022-06-22 03:50:05.575154
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    class test_translations():
        def get(self, msg):
            return {'text1': 'test1'}
    test_code = 'en_US'
    test_object = CSVLocale(test_code, test_translations())
    test_object.pgettext('context', 'text1')

