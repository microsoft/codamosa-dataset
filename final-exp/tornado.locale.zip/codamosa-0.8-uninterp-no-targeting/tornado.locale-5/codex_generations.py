

# Generated at 2022-06-22 03:40:57.280689
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    loc = GettextLocale('zh_CN', gettext.translation('messages', './locale', ['zh_CN']))
    assert loc.code == 'zh_CN'

# Generated at 2022-06-22 03:41:04.529329
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    import gettext
    import os
    import zulip
    locale_path = os.path.join(zulip.__path__[0], "locale")
    translations = gettext.translation(
        "zulip", localedir=locale_path, languages=["en_US"], fallback=True
    )
    try:
        GettextLocale("en_US", translations)
        assert True
    except AssertionError:
        assert False



# Generated at 2022-06-22 03:41:17.159041
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    # Create dummy translation dictionary
    mock_translations = {
        "".join([CONTEXT_SEPARATOR, "law"]): {"right": "pravo"},
        "".join([CONTEXT_SEPARATOR, "stick"]): {"club": "kij", "clubs": "kiji"},
        "".join([CONTEXT_SEPARATOR, "organization"]): {"club": "klub", "clubs": "klubi"},
    }
    # Create dummy translations instance
    translations = gettext.translation("dummy", "locale", ["en_US"], fallback=True)
    translations.__dict__["_catalog"] = mock_translations
    # Create instance of GettextLocale
    locale = GettextLocale("en_US", translations)
    # Check that pgettext uses context, if available

# Generated at 2022-06-22 03:41:30.269503
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    l = Locale.get('en_US')
    assert l.format_date(1476331245.0) == '1 hour ago'
    assert l.format_date(time.time()) == '1 second ago'
    assert l.format_date(time.time()-4) == '4 seconds ago'
    assert l.format_date(time.time()-9) == '9 seconds ago'
    assert l.format_date(time.time()-10) == '10 seconds ago'
    assert l.format_date(time.time()-49) == '49 seconds ago'
    assert l.format_date(time.time()-50) == '1 minute ago'
    assert l.format_date(time.time()-60) == '1 minute ago'

# Generated at 2022-06-22 03:41:39.744155
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from gettext import NullTranslations
    from io import BytesIO

    def _fake_translations(codeset: str) -> gettext.NullTranslations:
        t = NullTranslations()
        t.codeset = lambda: codeset
        return t

    # Define locale PO file with context.

# Generated at 2022-06-22 03:41:49.962627
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    def mock_gettext(message: str) -> str:
        return message
    def mock_ngettext(message: str, plural_message: str, count: int) -> str:
        if count == 1:
            return message
        else:
            return plural_message
    locale = GettextLocale("en", translations=gettext.NullTranslations())
    locale.translate = mock_gettext
    locale.ngettext = mock_ngettext
    assert locale.translate("hello") == "hello"
    assert locale.translate("friend", plural_message="friends", count=1) == "friend"
    assert locale.translate("friend", plural_message="friends", count=2) == "friends"


# Generated at 2022-06-22 03:41:51.052521
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert get_supported_locales() == _supported_locales
    return True



# Generated at 2022-06-22 03:42:03.111862
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """Unit test for method format_date of class Locale"""

    from tornado.options import options
    from tornado.options import define
    from tornado.options import parse_config_file
    from datetime import datetime
    from datetime import timedelta
    import random
    import tempfile
    import os
    import shutil
    import locale

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--default-locale",
        default=None,
        help="Override default_locale",
        metavar="LOCALE",
    )
    args, remaining_argv = parser.parse_known_args()

    if args.default_locale:
        options.default_locale = args.default_locale
    else:
        options.no_translation = True

    thisdir = os.path

# Generated at 2022-06-22 03:42:14.551594
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l = Locale.get("en_US")
    assert l.friendly_number(0) == "0"
    assert l.friendly_number(1) == "1"
    assert l.friendly_number(12) == "12"
    assert l.friendly_number(123) == "123"
    assert l.friendly_number(1234) == "1,234"
    assert l.friendly_number(12345) == "12,345"
    assert l.friendly_number(123456) == "123,456"
    assert l.friendly_number(1234567) == "1,234,567"
    assert l.friendly_number(12345678) == "12,345,678"
    assert l.friendly_number(123456789) == "123,456,789"



# Generated at 2022-06-22 03:42:24.194962
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en")
    assert "2,500" == locale.friendly_number(2500)
    assert "25,000" == locale.friendly_number(25000)
    assert "250,000" == locale.friendly_number(250000)
    assert "2,500,000" == locale.friendly_number(2500000)
    assert "25,000,000" == locale.friendly_number(25000000)
    assert "250,000,000" == locale.friendly_number(250000000)
    assert "2,500,000,000" == locale.friendly_number(2500000000)



# Generated at 2022-06-22 03:42:59.158556
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    now = datetime.datetime.now()
    t = now.strftime("%Y-%m-%d")
    for culture, expected in [("en_US", "{}, {}".format(now.strftime("%A"), t)),
                              ("zh_CN", "{} {}".format(now.strftime("%x"), now.strftime("%A"))),
                              ("fa_IR", "{} {}".format(now.strftime("%x"), now.strftime("%A")))]:
        actual = Locale.get(culture).format_day(now)
        assert actual == expected, "Locale format_day ({}) expected to be '{}' but is '{}'".format(culture, expected, actual)
        
if __name__ == "__main__":
    test_Locale_format_day()

# Generated at 2022-06-22 03:43:11.861438
# Unit test for constructor of class Locale
def test_Locale():
    """Test: Constructor of class Locale"""
    locale = Locale("en_US")
    assert locale.code == "en_US"
    assert locale.name == "English (US)"
    assert locale.rtl == False
    assert locale._months == [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ]
    assert locale._weekdays == [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
    ]
    assert len(locale._cache) == 1
    assert "en_US" in locale._cache




# Generated at 2022-06-22 03:43:24.878388
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    global _translations
    global _supported_locales
    global _use_gettext
    _translations = {} #type: Dict[str,Any]
    _supported_locales = frozenset([])
    _use_gettext = False

    # The following test is to test the method format_date of class Locale
    # In this test, we will build a fake Locale object called testLocale
    # which is using the same code with the localization file "fake.csv"
    # which is designed for the test.
    # Then we will test the format of date for each scenario below.
    
    # scenario 1: when the given date is in future
    # we will expect it to use the full format
    fake_path = "locale/fake.csv"
    load_translations(fake_path, encoding="utf-8")

# Generated at 2022-06-22 03:43:28.549598
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    loc = Locale.get("en")
    assert loc.format_day(datetime(2018, 8, 8)) == "Wednesday, August 8"
    assert loc.format_day(datetime(2018, 8, 8), dow=False) == "August 8"



# Generated at 2022-06-22 03:43:40.933431
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    l = GettextLocale('en_US', translations.get('en_US'))
    assert l.translate('Welcome to <b>Zulip</b>!') == 'Welcome to <b>Zulip</b>!'
    assert l.translate('Welcome to <b>Zulip</b>!', 'Welcome to <b>Zulips</b>!', 2) == 'Welcome to <b>Zulips</b>!'
    assert l.translate('Welcome to <b>Zulip</b>!', 'Welcome to <b>Zulips</b>!', 1) == 'Welcome to <b>Zulip</b>!'

# Generated at 2022-06-22 03:43:41.847034
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales == frozenset(
        list(_translations.keys()) + [_default_locale])



# Generated at 2022-06-22 03:43:54.179852
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class _GettextLocale(GettextLocale):
        def __init__(self, code: str) -> None:
            self.ngettext = lambda *args: args[1] if args[3]!=1 else args[0]
            self.gettext = lambda s: s
            # self.gettext must exist before __init__ is called, since it
            # calls into self.translate
            super().__init__(code, None)
    _GettextLocale("en").pgettext("context", "message", "messages", 2) == "messages"
    _GettextLocale("en").pgettext("context", "message", "messages", 1) == "message"
    _GettextLocale("en").pgettext("context", "message") == "message"
test_GettextLocale_p

# Generated at 2022-06-22 03:43:59.932402
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    print("Test Locale.format_date\n")
    load_translations(os.path.dirname(os.path.realpath(__file__)) +
                      '/locale/translations')
    print("\n    The default locale is: "+_default_locale)
    print("    The supported locale is: "+str(sorted(_supported_locales)))

    locale_codes = ["en_US", "zh_CN", "fa_IR", "zh_TW", "de_DE"]


# Generated at 2022-06-22 03:44:06.732222
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    gen_log = logging.getLogger("generated_log")
    if _translations:
        for i in range(1, 11):
            for j in range(2, 7):
                log = random.randint(1,10)
                num = int(log ** j)
                gen_log.info("Testing with %s" % str(num))
                result = _locale.friendly_number(num)
                gen_log.info("Testing with %s" % result)
        gen_log.info("None test passed")
    else:
        gen_log.error("None test failed")

# Helper function to recursively freeze nested dictionaries

# Generated at 2022-06-22 03:44:17.624293
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # pre-requisite 1 - Set the variable to generate the test coverage report.
    from coverage import coverage
    cov = coverage(branch=True, omit=["/opt/python3.6.9/lib/python3.6/site-packages*","test_*.py"])
    cov.start()
    csv_locale = CSVLocale(code = 'de_DE',
                           translations = {'unknown': {'Unknown locale. Using default': 'Unbekannte Sprache. Verwende Standard Sprache'}
                                           })
    ret = csv_locale.translate("Unknown locale. Using default")
    # post-requisite 1 - Stop coverage report
    cov.stop()
    cov.save()
    # post-requisite 2 - Create report
    cov.html_report(directory='tmp/coverage')

# Generated at 2022-06-22 03:44:54.727151
# Unit test for function get
def test_get():
    assert get("en_US").name == "en_US"
    assert get("en").name == "en_US"
    assert get("en", "es").name == "en_US"
    assert get("en", "es_ES").name == "es_ES"
    assert get("zz_YY").name == "en_US"
    assert get("es", "zz_YY").name == "es_US"
    assert get("zz_YY", "es").name == "es_US"



# Generated at 2022-06-22 03:45:01.138689
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert(Locale("zh_CN").format_day(datetime.datetime(2019, 6, 5)) == u'2019\u5e746\u67085\u65e5\u661f\u671f\u4e00')


# Generated at 2022-06-22 03:45:06.507445
# Unit test for function get
def test_get():
    a = get("en_US")
    assert type(a) == Locale
    assert a.code == "en_US"
    b = a.translate("hello")
    assert b == "hello"
    b = a.translate("hello", "hola")
    assert b == "hola"
    assert a.list == ", "
test_get()


# Generated at 2022-06-22 03:45:15.836719
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # one parameter
    loc = Locale.get('ko_KR')
    dt = datetime.datetime(2020, 1, 22)
    result = loc.format_day(dt)
    assert result == "수요일, 1월 22"

    # two parameters
    result = loc.format_day(dt, 0)
    assert result == "수요일, 1월 22"

    # three parameters
    result = loc.format_day(dt, 0, True)
    assert result == "수요일, 1월 22"

    # three parameters
    result = loc.format_day(dt, 0, False)
    assert result == "1월 22"


# Generated at 2022-06-22 03:45:23.942070
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale_codes = [
        "sv",
        "es",
        "zh_CN",
        "zh_TW",
        "ar",
        "en_US",
    ]
    date = datetime.datetime.utcnow()
    for code in locale_codes:
        locale = Locale.get(code)
        print(locale.code + " " + locale.format_date(date))
        time.sleep(1)



# Generated at 2022-06-22 03:45:30.848336
# Unit test for constructor of class Locale
def test_Locale():
    assert(hasattr(Locale, "get_closest"))
    assert(hasattr(Locale, "get"))
    assert(hasattr(Locale, "translate"))
    assert(hasattr(Locale, "format_date"))
    assert(hasattr(Locale, "format_day"))
    assert(hasattr(Locale, "list"))
    assert(hasattr(Locale, "friendly_number"))
    assert(hasattr(Locale, "pgettext"))


# Generated at 2022-06-22 03:45:34.405091
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('/var/www/tornado-webserver/tornado/locale/', 'tornado')
    pass


# Generated at 2022-06-22 03:45:39.894676
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import locale
    config = {
        "locale": "it_IT",
        "environment": "prod"
    }
    load_translations(os.path.join(os.path.dirname(os.path.realpath(__file__)), "../../"), config)



# Generated at 2022-06-22 03:45:42.318347
# Unit test for constructor of class Locale
def test_Locale():
    assert _default_locale == 'en'
    assert not _translations
    assert not _use_gettext
    assert not Locale._cache
    

# Generated at 2022-06-22 03:45:44.763097
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("zh_CN")
    assert _default_locale == "zh_CN"


# Generated at 2022-06-22 03:47:21.373525
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # test of type datetime
    test_date = datetime.datetime.now()
    t_locale = Locale.get('en')
    format_date = t_locale.format_date(test_date)
    assert isinstance(format_date, str)
    # test of type int
    test_date = int(time.time())
    t_locale = Locale.get('en')
    format_date = t_locale.format_date(test_date)
    assert isinstance(format_date, str)
    # test of type float
    test_date = time.time()
    t_locale = Locale.get('en')
    format_date = t_locale.format_date(test_date)
    assert isinstance(format_date, str)


# Generated at 2022-06-22 03:47:34.168519
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    translations = {
        "unknown": {"message": "Unknown", "hello": "Hello", "world": "World"},
        "singular": {
            "goodbye": "Goodbye",
            "message": "Singular",
            "hello, world": "Hello World",
        },
        "plural": {"goodbye": "Goodbyes", "message": "Plural"},
    }
    locale = CSVLocale("en", translations)

    assert locale is not None
    assert locale.translate("hello") == "Hello"
    assert locale.translate("world") == "World"
    assert locale.translate("goodbye") == "Goodbye"
    assert locale.translate("hello, world") == "Hello World"
    assert locale.translate("goodbye", "goodbyes") == "Goodbye"
    assert locale.trans

# Generated at 2022-06-22 03:47:40.745590
# Unit test for function get_supported_locales
def test_get_supported_locales():
    import tornado.testing

    class TestLocale(
        unittest.TestCase,
        tornado.testing.AsyncHTTPTestCase,
        tornado.testing.LogTrapTestCase
    ):
        def test_get_supported_locales(self):
            self.assertRaises(NotImplementedError, get_supported_locales)
            set_default_locale("en_US")
            load_translations(
                os.path.join(
                    os.path.dirname(__file__),
                    "test",
                    "locale"
                )
            )
            self.assertEqual(
                set(["en_US", "es_AR", "es_CO", "es_MX", "fr_FR", "fr_CA"]),
                set(get_supported_locales())
            )

    return

# Generated at 2022-06-22 03:47:43.293298
# Unit test for function get
def test_get():
    l = Locale.get_closest('en')
    assert l.code == 'en'


# Generated at 2022-06-22 03:47:54.366076
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    # print('test_GettextLocale_translate()')
    from tornado.options import options
    options.locale = "en"
    options.default_locale = "en"
    _supported_locales = ['en']
    _default_locale = 'en'
    _translations = {}
    _use_gettext = False
    locale = Locale.get(options.locale)
    assert locale.translate("hello") == "hello"

    options.locale = "en"
    options.default_locale = "en"
    _supported_locales = ['en']
    _default_locale = 'en'
    _translations = {'en': {'plural': {'hello': "hi"}}}
    _use_gettext = False

# Generated at 2022-06-22 03:48:07.053687
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    # Test case1 : if date is set current date, relative date is yesterday and format date is 1 day ago
    date = datetime.today()
    locale = Locale(code='en_US')
    assert locale.format_date(date) == '1 day ago'
    # Test case2 : if date is set current date and relative is set to false, format date is today
    assert locale.format_date(date, relative=False) == 'today'
    # Test case3 : if date is set current date and relative is set to true, format date is yesterday
    assert locale.format_date(date, relative=True) == 'yesterday'
    # Test case4 : if date is set current date and full_format is set to true, format date is today/yesterday

# Generated at 2022-06-22 03:48:08.463343
# Unit test for function get_supported_locales
def test_get_supported_locales():
    return _supported_locales



# Generated at 2022-06-22 03:48:15.895356
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    csv_locale = CSVLocale('en', _translations['en'])
    assert csv_locale.translate('Loading...') == 'Loading...'
    assert csv_locale.translate('Loading...', 'Loadings...', 2) == 'Loadings...'
    assert csv_locale.translate('Loading...', 'Loadings...', 1) == 'Loading...'


# Generated at 2022-06-22 03:48:27.670258
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.options import options
    from tornado.util import import_object
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_runner import slow
    from typing import List

    import_path = "zerver.lib.locale.GettextLocale"
    InitTranslationsFunc = import_object(import_path, "InitTranslations")
    class_translations = InitTranslationsFunc()
    locale_translations = class_translations.get(class_translations.keys()[0])
    locale_translations = locale_translations.get(locale_translations.keys()[0])
    GettextLocale = import_object(import_path, "GettextLocale")

# Generated at 2022-06-22 03:48:38.115357
# Unit test for function load_translations
def test_load_translations():
    test_dir = os.path.dirname(__file__)
    load_translations(os.path.join(test_dir, 'locale_data_test'))
    assert _translations == {'test': {'unknown': {'test_string': 'test_translated_string'}}}
    assert _supported_locales == frozenset(["test", "en_US"])
    for locale in _supported_locales:
        assert "test_string" in _translations[locale]["unknown"]
        assert _translations[locale]["unknown"]["test_string"] == "test_translated_string"



# Generated at 2022-06-22 03:49:29.522678
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    class Test_Dummy_Class_CSVLocale_pgettext(CSVLocale):
        def __init__(self, code: str, translations: Dict[str, Dict[str, str]]):
            super().__init__(code, translations)
            self.code = "en"
    print("Testing function CSVLocale.pgettext")
    test_dict = {"singular": {"test_message": "message"}}
    test = Test_Dummy_Class_CSVLocale_pgettext("en", test_dict)
    test_message = "test_message"
    print("Test 1: Translation of ", test_message, " is: ", test.translate(test_message))

# Generated at 2022-06-22 03:49:33.740014
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    context = ""
    message = "A"
    plural_message = "B"
    count = 3
    l=CSVLocale("en_US", {'unknown': {"A":"aa"}})
    l.pgettext(context, message, plural_message, count)


# Generated at 2022-06-22 03:49:37.620359
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("de_DE")
    l = get("de_DE")
    assert(str(l) == "de_DE")
    


# Generated at 2022-06-22 03:49:48.305506
# Unit test for method translate of class CSVLocale

# Generated at 2022-06-22 03:49:59.114715
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import os
    import types
    import unittest
    from pkg_resources import resource_filename

    l = CSVLocale('pt_BR', {})
    assert l.pgettext == l.translate, "%s.pgettext != %s.translate (%s, %s)"%(
                l.__class__.__name__,l.__class__.__name__,l.pgettext,l.translate)


    l = GettextLocale.get('pt_BR')
    assert l.pgettext == l.translate, "%s.pgettext != %s.translate (%s, %s)"%(
                l.__class__.__name__,l.__class__.__name__,l.pgettext,l.translate)


# Generated at 2022-06-22 03:50:01.692311
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    translations = {}
    test_code = "en"
    csvLocale = CSVLocale(test_code, translations)
    assert csvLocale.code == test_code


# Generated at 2022-06-22 03:50:04.593845
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    assert Locale.get('en_US').pgettext('a', 'A', 'B', count=1) == 'A'
    assert Locale.get('en_US').pgettext('a', 'A', 'B', count=2) == 'B'



# Generated at 2022-06-22 03:50:05.599576
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales



# Generated at 2022-06-22 03:50:13.426753
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_cases = [(1, "1"), (12, "12"), (123, "123"), (1234, "1,234"), (12345678, "12,345,678")]
    for value_input, value_expected in test_cases:
        locale_obj = Locale.get("en_US")
        value_returned = locale_obj.friendly_number(value_input)
        print(value_returned)
        assert value_returned == value_expected

