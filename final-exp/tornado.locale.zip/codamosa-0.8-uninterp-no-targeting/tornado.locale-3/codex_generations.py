

# Generated at 2022-06-22 03:40:58.108440
# Unit test for function load_translations
def test_load_translations():
    load_translations('./locale')
    print(_translations)
    return


# Generated at 2022-06-22 03:41:00.266192
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    Locale.get("en").friendly_number(1000) == "1,000"
    # TODO: add more unit tests for method friendly_number of class Locale



# Generated at 2022-06-22 03:41:02.873124
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale('zh_CN')
    print(_default_locale)


# Generated at 2022-06-22 03:41:16.149761
# Unit test for function get
def test_get():
    global LOCALE_NAMES, _translations, _supported_locales, _default_locale

# Generated at 2022-06-22 03:41:25.182524
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.util import _translations
    from tornado.locale import GettextLocale
    from tornado.locale import LOCALE_NAMES
    from tornado.locale import LOCALE_NAMES
    from tornado.locale import CSVLocale
    import locale
    import gettext
    locale.setlocale(locale.LC_ALL, '')
    _translations = {
        'ru': {
            'unknown': {
                'not found': 'not found with context',
                'not found without context':'not found without context',
            },
            'singular': {
                '': ''
            },
            'plural': {
                '': ''
            },
        }
    }

# Generated at 2022-06-22 03:41:33.299635
# Unit test for constructor of class Locale
def test_Locale():
    locale = Locale("a")
    assert locale.code == "a"
    assert locale.name == "Unknown"
    assert locale.rtl == False
    assert locale._months == list(map(lambda x: str(x), range(12)))
    assert locale._weekdays == ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    assert locale.translate("A") == "A"
    assert locale.pgettext("A", "B") == "B"
    assert locale.format_date(datetime.datetime.now()) == str(datetime.datetime.now())
    assert locale.format_day(datetime.datetime.now()) == datetime.datetime.now().strftime("%A, %B %d")

# Generated at 2022-06-22 03:41:46.506735
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from ..gen_base.type_date import TypeDate

    _default_locale = "en"
    _translations = {}
    _supported_locales = []
    _use_gettext = False


# Generated at 2022-06-22 03:41:49.080158
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/shijiex/Downloads/tornado-5.0.tar/tornado-5.0/tornado/locale/data")


# Generated at 2022-06-22 03:42:01.811054
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():

    # There're always 2 dictionaries inside var translations (default dictionary)
    translations = { "unknown": { "unknown": "TEST", "plural": "TEST" } }

    _translations["en"] = translations
    _default_locale = "en"

    # Test Locale object
    locale = Locale.get("en")

    # Testing "default" case
    assert locale.pgettext("context", "unknown") == "TEST"
    assert locale.pgettext("context", "unknown") == "TEST"
    assert locale.pgettext("context", "unknown", "unknown", 0) == "TEST"
    assert locale.pgettext("context", "unknown", "unknown", 1) == "TEST"

    # Testing plural case

# Generated at 2022-06-22 03:42:03.858592
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # TODO: fix it
    pass


# Generated at 2022-06-22 03:42:35.521680
# Unit test for function load_translations
def test_load_translations():
    load_translations("./test")

# Generated at 2022-06-22 03:42:37.115412
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales is not None



# Generated at 2022-06-22 03:42:42.332959
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    translations = {
        "unknown": {},
        "plural": {},
        "singular": {},
    }
    locale = CSVLocale('', translations)
    assert locale.pgettext(context="", message="") == ""


# Generated at 2022-06-22 03:42:54.266334
# Unit test for constructor of class Locale
def test_Locale():
    class _Locale(Locale):
        def translate(
            self,
            message: str,
            plural_message: Optional[str] = None,
            count: Optional[int] = None,
        ) -> str:
            raise NotImplementedError()

        def pgettext(
            self,
            context: str,
            message: str,
            plural_message: Optional[str] = None,
            count: Optional[int] = None,
        ) -> str:
            raise NotImplementedError()

    locale = _Locale.get("zh_CH")
    assert locale.rtl == False
    assert locale._weekdays == ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
    assert locale

# Generated at 2022-06-22 03:43:08.379582
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    def load_translations(directory: str) -> None:
        global _translations
        global _supported_locales
        global _use_gettext
        _translations = {}
        _supported_locales = set()
        _use_gettext = False
        path = os.path.join(directory, "translations.csv")
        encoding = "utf-8"  # we do not need to detect the encoding here
        with open(path, encoding=encoding) as f:
            _translations["en"] = {}
            for i, row in enumerate(csv.reader(f)):
                if not row or len(row) < 2:
                    continue
                row = [escape.to_unicode(c).strip() for c in row]
                english, translation = row[:2]

# Generated at 2022-06-22 03:43:21.905871
# Unit test for constructor of class Locale
def test_Locale():
    test_code = "en_US"
    test_translations_1 = {"english": "english", "english plural": "english plural", "english singular": "english singular"}
    test_translations_2 = {"english": "english", "english plural": "english plural"}
    test_translations_3 = {"english": "english"}
    CSVLocale("", {})
    CSVLocale("", test_translations_1)
    CSVLocale("", test_translations_2)
    CSVLocale("", test_translations_3)
    GettextLocale("", test_translations_1)
    GettextLocale("", test_translations_2)
    GettextLocale("", test_translations_3)
    Locale.get(test_code)
    
    

# Generated at 2022-06-22 03:43:31.611960
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from .test_util import MockOs
    
    def _test_format_day(os):
        LANGUAGE = "es_ES" 
        os.environ["LANGUAGE"] = LANGUAGE
        from .i18n import load_translations
        from .i18n import get_closest_locale
        from .i18n import get_supported_locales
        from .i18n import Locale
        gen_log.info(os.environ["LANGUAGE"])
        load_translations(
            os.path.join(os.path.dirname(__file__), "../locale"), domain = "messages")
        gen_log.info(get_supported_locales())

# Generated at 2022-06-22 03:43:38.965099
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    t = Locale.get("en")
    assert t.pgettext("file", "File") == "File"
    assert t.pgettext("file", "File", "Files") == "File"
    assert t.pgettext("file", "File", "Files", 1) == "File"
    assert t.pgettext("file", "File", "Files", 2) == "Files"


# Generated at 2022-06-22 03:43:45.308614
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime(2020, 6, 3, 11, 0, 0)
    local = Locale('en_US')
    local.format_day(date)
    # local.format_day(date,dow=False)
    # print("*" * 100, "testing format_day")
    # print("*" * 100, "testing format_day")
    # print("*" * 100, "testing format_day")

# Generated at 2022-06-22 03:43:52.381932
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations('./locale', 'tornado_locale')
    _translations['zh']('hello')
    _translations['zh'].gettext('hello')
    _translations['zh'].ngettext('hello', 'goodbye', 2)
    _translations['zh'].ngettext('hello', 'goodbye', 1)
    _translations['zh'].ngettext('hello', 'goodbye', 0)



# Generated at 2022-06-22 03:44:12.267802
# Unit test for method translate of class Locale
def test_Locale_translate():
    obj = Locale("en")
    messages = obj.translate("The quick brown fox jumps over the lazy dog")
    assert messages == "The quick brown fox jumps over the lazy dog"



# Generated at 2022-06-22 03:44:18.755922
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    csvloc = CSVLocale("en", {"singular": {"string": _}, "unknown": {"str": _}})
    assert csvloc.code == "en"
    assert csvloc.translations == {"singular": {"string": _}, "unknown": {"str": _}}
    assert csvloc.name == "English"
    assert csvloc.rtl == False



# Generated at 2022-06-22 03:44:31.190887
# Unit test for function load_translations
def test_load_translations():
    load_translations("/Users/piotrmostowski/rep/python/tornado/translations")
    print(Locale.get_closest("fr", "foo", "bar"))
    print(Locale.get_closest("es", "foo", "bar").translate("My name is %(name)s"))
    print(Locale.get_closest("es_AR", "foo", "bar").translate("My name is %(name)s"))
    print(_supported_locales)
    print(_translations.keys())
    print(_translations["es"].keys())
    print(_translations["es"]["unknown"]["My name is %(name)s"])
    print(_translations["es"]["plural"]["%(name)s liked this"])

# Generated at 2022-06-22 03:44:36.829506
# Unit test for method list of class Locale
def test_Locale_list():
    greek = Locale.get("el")
    assert greek.list(["A", "B", "C"]) == "Α, B και C"
    assert greek.list(["A", "B"]) == "Α και B"
    assert greek.list(["A"]) == "Α"
    assert greek.list([]) == ""

# Generated at 2022-06-22 03:44:50.235415
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # tests for locale en_US
    locale = Locale.get("en_US")
    assert locale.format_day(datetime.datetime(2019, 1, 1)) == "Tuesday, January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=False) == "January 1"
    assert locale.format_day(datetime.datetime(2019, 1, 1), dow=True) == "Tuesday, January 1"
    # tests for locale fa
    locale = Locale.get("fa")

# Generated at 2022-06-22 03:44:55.520825
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale=Locale.get("en")
    assert locale.friendly_number(6000) == "6,000"
    assert locale.friendly_number(123456789) == "123,456,789"
    assert locale.friendly_number(123456) == "123,456"
    assert locale.friendly_number(1) == "1"
    assert locale.friendly_number(0) == "0"

# Generated at 2022-06-22 03:45:07.365989
# Unit test for constructor of class Locale
def test_Locale():
    assert not hasattr(Locale, "_cache")
    assert not hasattr(Locale, "code")
    assert not hasattr(Locale, "name")
    assert not hasattr(Locale, "rtl")
    assert not hasattr(Locale, "_months")
    assert not hasattr(Locale, "_weekdays")
    assert not hasattr(Locale, "translate")
    assert not hasattr(Locale, "pgettext")
    assert not hasattr(Locale, "format_date")
    assert not hasattr(Locale, "format_day")
    assert not hasattr(Locale, "list")
    assert not hasattr(Locale, "friendly_number")


# Generated at 2022-06-22 03:45:09.808897
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_Locale_friendly_number_result = Locale.friendly_number(12345)
    assert test_Locale_friendly_number_result == "12,345"



# Generated at 2022-06-22 03:45:18.975352
# Unit test for constructor of class Locale
def test_Locale():
    assert Locale.get('en').format_date(datetime.datetime.now()) == "1 second ago"
    ##assert Locale.get('fa').format_date(datetime.datetime.now()) == "1 second ago"
    assert Locale.get('en_US').format_date(datetime.datetime.now()) == "1 second ago"
    assert Locale.get('zh_CN').format_date(datetime.datetime.now()) == "1 second ago"
    assert Locale.get('ja').format_date(datetime.datetime.now()) == "1 second ago"



# Generated at 2022-06-22 03:45:30.576398
# Unit test for method translate of class Locale
def test_Locale_translate():
    assert 'Hello world!' == Locale('en').translate('Hello world!')
    assert 'Hello world!' == Locale('en').translate('Hello world!', '', 0)
    assert 'Hello worlds!' == Locale('en').translate('Hello world!', 'Hello worlds!', 1)
    assert 'Hello worlds!' == Locale('en').translate('Hello world!', 'Hello worlds!', 2)
    assert 'Hello worlds!' == Locale('en').translate('Hello world!', 'Hello worlds!', 100)
    assert 'Hello worlds!' == Locale('en').translate('Hello world!', 'Hello worlds!', -1)

    assert 'Hello world!' == Locale('es').translate('Hello world!')
    assert 'Hello world!' == Locale('es').translate('Hello world!', '', 0)

# Generated at 2022-06-22 03:46:02.005478
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en_US")
    print(locale.friendly_number(11))
    print(locale.friendly_number(12))
    print(locale.friendly_number(123))
    print(locale.friendly_number(1234))
    print(locale.friendly_number(12345))
    print(locale.friendly_number(123456))
    print(locale.friendly_number(1234567))
    print(locale.friendly_number(12345678))
    print(locale.friendly_number(123456789))
    print(locale.friendly_number(1234567890))
    print(locale.friendly_number(12345678901))
    print(locale.friendly_number(123456789012))


# Generated at 2022-06-22 03:46:09.289338
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    code = "zh_CN"
    translations = gettext.translation(
        "messages", localedir=os.path.join(os.path.dirname(__file__), "../locale"), languages=[code]
    )
    locale = GettextLocale(code, translations)

    assert locale.code == code
    assert locale.translate("Loan") == u"贷款"
    assert locale.translate(u"1 Loan", u"%(count)d Loans", 2) == u"2 贷款"

# Generated at 2022-06-22 03:46:09.932392
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    pass

# Generated at 2022-06-22 03:46:11.755449
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    assert GettextLocale("en", gettext.NullTranslations()) is not None


# Generated at 2022-06-22 03:46:18.666649
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    from zerver.lib import bugdown
    from zerver.lib.test_classes import ZulipTestCase
    class TestGettextLocale(ZulipTestCase):
        def test_translate(self):
            # type: () -> None
            timestamp = time.time()
            for locale in ["en", "zh_CN", "de", "uk"]:
                with self.settings(LOCALE_FUNC=lambda x: locale), \
                        self.settings(TIME_ZONE="Asia/Kolkata"), \
                        self.settings(USE_X_ACCEL_REDIRECT=False):
                    rendered_message = "[outgoing](/help/outgoing-webhooks) [link](https://outgoing.example.com)"


# Generated at 2022-06-22 03:46:22.696890
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "messages")
    gettext.translation(
        "messages", "./locale", languages=["en_US"]
    )
    gettext.translation(
        "messages", "./locale", languages=["es_ES"]
    )


# Generated at 2022-06-22 03:46:25.177613
# Unit test for function get
def test_get():
    locale = get("en")
    assert locale
    assert locale.code == "en_US"


# Generated at 2022-06-22 03:46:33.297845
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l = Locale.get("en")
    assert l.friendly_number(1) == "1"
    assert l.friendly_number(100) == "100"
    assert l.friendly_number(1000) == "1,000"
    assert l.friendly_number(1000000) == "1,000,000"
    assert l.friendly_number(1000000000) == "1,000,000,000"
    assert l.friendly_number(123456789) == "123,456,789"
    assert l.friendly_number(500000) == "500,000"



# Generated at 2022-06-22 03:46:39.849444
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_cases = [
        (1234, '1,234'),
        (123456, '123,456'),
        (12345678, '12,345,678'),
        (1234567890, '1,234,567,890'),
    ]
    for i, o in test_cases:
        assert en_US().friendly_number(i) == o



# Generated at 2022-06-22 03:46:43.216798
# Unit test for method list of class Locale
def test_Locale_list():
    print("########## test_Locale_list")
    locale = Locale.get("en")
    lst = ["A", "B", "C"]
    print(locale.list(lst))



# Generated at 2022-06-22 03:47:34.208603
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    dire = "/Users/luochen/Documents/program/python/APIserver"
    domain = "test"
    load_gettext_translations(dire, domain)
    # print(_translations.keys(), _supported_locales)
    print(_translations['zh_CN'].gettext('hello world!'), _translations['zh_CN'].gettext('hello %(name)s!'), _translations['zh_CN'].gettext('I am %(name)d!'))
    print(get('en_US').translate("hello world!"), get('en_US').translate("hello %(name)s!"), get('en_US').translate("I am %(name)d!"))

# Generated at 2022-06-22 03:47:35.264717
# Unit test for function get_supported_locales
def test_get_supported_locales():
    pass



# Generated at 2022-06-22 03:47:36.430812
# Unit test for function get_supported_locales
def test_get_supported_locales():
    print(get_supported_locales())


# Generated at 2022-06-22 03:47:41.358817
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    _translations = {
        "es": {
            "plural": {
                "one": "Singular",
                "other": "Plural",
            }
        }
    }
    _use_gettext = True
    _default_locale = "en"
    # Arg1: /home/alex/Documents/GitHub/tornado-framework/tornado/locale
    # Arg2: tornado.locale
    load_gettext_translations(r"D:\GitHub\tornado-framework\tornado\locale", "tornado.locale")
    assert _translations["es"].gettext("Plural") == "Plural"
    assert _translations["es"].gettext("one") == "Singular"

# Generated at 2022-06-22 03:47:52.836521
# Unit test for method translate of class Locale
def test_Locale_translate():
    """Tests the method translate of class Locale"""
    # import here so that current tests don't break it
    from tornado.escape import to_unicode
    import tornado.web
    import os
    import sys
    import time

    # modified version of the class for testing
    class Locale(object):
        """Object representing a locale.

        After calling one of `load_translations` or `load_gettext_translations`,
        call `get` or `get_closest` to get a Locale object.
        """

        _cache = {}  # type: Dict[str, Locale]

        @classmethod
        def get_closest(cls, *locale_codes: str) -> "Locale":
            """Returns the closest match for the given locale code."""

# Generated at 2022-06-22 03:48:02.824268
# Unit test for method translate of class Locale
def test_Locale_translate():
    # 1
    if not test.test_is_server():
        return
    try:
        i18n.load_translations(os.path.join(os.getcwd(), "translations"))
        l = i18n.Locale.get("zh_CN")
        assert l.translate("User-visible setting") == "用户可见设置"
        assert l.translate("User-visible setting", plural_message="User-visible settings", count=2) == "User-visible settings"
    except:
        print (traceback.format_exc())
        raise


# Generated at 2022-06-22 03:48:04.639017
# Unit test for constructor of class Locale
def test_Locale():
    assert Locale.get("fr").name == "Français"


# Generated at 2022-06-22 03:48:12.242495
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from zerver.lib.test_helpers import tornado_redirected_to_list
    from django.core.urlresolvers import resolve
    from django.core.urlresolvers import reverse
    from zerver.lib.test_classes import ZulipTestCase
    from zerver.lib.test_runner import slow
    from zerver.lib.test_helpers import POSTRequestMock

    class TestGettextLocale(ZulipTestCase):
        @slow("Need to load several gettext files")
        @tornado_redirected_to_list
        def test_pgettext_with_context(self) -> None:
            user_profile = self.example_user("hamlet")
            self.login_user(user_profile)

            result = self.client_get("/")


# Generated at 2022-06-22 03:48:24.111059
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    # test good init
    translations = {
        "unknown": {message: message for message in ["label", "username"]},
        "singular": {message: message for message in ["user", "team"]},
        "plural": {
            message: message for message in ["users", "teams"]
        },
    }
    locale = CSVLocale("en", translations)
    assert locale.code == "en"
    assert locale.name == "English"
    assert locale.rtl == False
    assert locale.translations == translations
    # test bad init
    with pytest.raises(TypeError):
        # translations must be a dictionary
        locale = CSVLocale("fa", 0)
    with pytest.raises(TypeError):
        # code must be a string
        locale = CSVLocale(0, translations)




# Generated at 2022-06-22 03:48:32.290903
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # Test arabic locale
    locale = Locale.get_closest('ar_AR')
    assert locale.format_day(date=datetime.datetime(day=22, month=1, year=2020), dow=True) == "الاثنين، يناير 22"
    assert locale.format_day(date=datetime.datetime(day=22, month=1, year=2020), dow=False) == "يناير 22"



# Generated at 2022-06-22 03:49:06.205035
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # Arrange
    expected = "März"
    actual = ""
    translation_de = {"singular": {"March": "März"}, "plural": {"March": "Märze"}}
    l = CSVLocale("de", translation_de)
    # Act
    actual = l.translate("March")
    # Assert
    assert actual == expected



# Generated at 2022-06-22 03:49:18.224121
# Unit test for constructor of class Locale
def test_Locale():
    # Initialize strings for date formatting

    _ = lambda msg, msg_plural=None, n=0: msg

    _months = [
        _("January"),
        _("February"),
        _("March"),
        _("April"),
        _("May"),
        _("June"),
        _("July"),
        _("August"),
        _("September"),
        _("October"),
        _("November"),
        _("December"),
    ]

    _weekdays = [
        _("Monday"),
        _("Tuesday"),
        _("Wednesday"),
        _("Thursday"),
        _("Friday"),
        _("Saturday"),
        _("Sunday"),
    ]

    # Initialize strings for number formatting
    _ = lambda msg, msg_plural=None, n=0: msg


# Generated at 2022-06-22 03:49:19.279189
# Unit test for function get
def test_get():
    assert str(get()) == "en_US"
test_get()



# Generated at 2022-06-22 03:49:30.881804
# Unit test for method list of class Locale
def test_Locale_list():
    locale_codes = [
        ("fa", "A, B \u0648 C", "A \u0648 B", "A", "", []),
        ("ar", "\u0648 ", "A, B \u0648 C", "A \u0648 B", "A", ""),
        ("en", ", ", "A, B and C", "A and B", "A", ""),
        ("en_US", ", ", "A, B and C", "A and B", "A", ""),
    ]
    for code, comma, expectation_3, expectation_2, expectation_1, empty_parts in locale_codes:
        locale = Locale.get(code)
        assert locale.list(["A", "B", "C"]) == expectation_3
        assert locale.list(["A", "B"]) == expectation_2

# Generated at 2022-06-22 03:49:34.892337
# Unit test for method translate of class Locale
def test_Locale_translate():
    assert(Locale('en').translate('hello') == 'hello')
    assert(Locale('en').translate('hello', 'goodbye', 1) == 'hello')
    assert(Locale('en').translate('hello', 'goodbye', 2) == 'goodbye')


# Generated at 2022-06-22 03:49:41.340928
# Unit test for constructor of class Locale
def test_Locale():
    assert str(type(Locale.get("en_US"))) == "<class '__main__.CSVLocale'>"
    assert str(type(Locale.get("zh_CN"))) == "<class '__main__.CSVLocale'>"
    assert str(type(Locale.get("french"))) == "<class '__main__.CSVLocale'>"
    assert str(type(Locale.get("en"))) == "<class '__main__.CSVLocale'>"


# Generated at 2022-06-22 03:49:43.284575
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    """test method translate of class CSVLocale"""
    import pytest
    csvlocale=CSVLocale("en","")
    assert csvlocale.translate("1",2) == "2"

# Generated at 2022-06-22 03:49:45.179433
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    assert not hasattr(Locale, "pgettext")
    assert str(
        inspect.getsource(Locale.pgettext))

# Generated at 2022-06-22 03:49:50.829919
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale_0 = Locale.get("en_US")
    assert locale_0.friendly_number(0) == "0"
    assert locale_0.friendly_number(123) == "123"
    assert locale_0.friendly_number(1234) == "1,234"
    assert locale_0.friendly_number(12345) == "12,345"
    assert locale_0.friendly_number(123456) == "123,456"
    assert locale_0.friendly_number(1234567) == "1,234,567"


# Generated at 2022-06-22 03:50:01.229696
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    import gettext
    # 1. set up some test data
    en_msgid = "org"
    en_msgid_plural = "orgs"
    zh_msgstr = zh_msgstr_plural = "组织"
    zh_msgid = zh_msgid_plural = "组织"
    zh_msgctxt = "law"
    # 2. initialize gettext for test
    t = gettext.translation(
        "messages",
        localedir="approot/translations",
        languages=["zh_CN"],
        class_=gettext.GNUTranslations,
    )

    t.add_fallback(
        gettext.NullTranslations()
    )  # empty catalog (instead of writing own one)
    t.add