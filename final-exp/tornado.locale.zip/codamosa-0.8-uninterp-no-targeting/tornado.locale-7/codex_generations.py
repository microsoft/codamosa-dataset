

# Generated at 2022-06-22 03:40:55.723328
# Unit test for method list of class Locale
def test_Locale_list():
    from typing import Any, List
    assert Locale('fa').list([]) == ''
    assert Locale('fa').list(['test']) == 'test'
    assert Locale('fa').list(['test1', 'test2']) == 'test1 و test2'
    assert Locale('fa').list(['test1', 'test2', 'test3']) == 'test1 و test2 و test3'
    assert Locale('fa').list(['test1', 'test2', 'test3', 'test4']) == 'test1 و test2 و test3 و test4'

# Generated at 2022-06-22 03:40:57.206891
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert isinstance(get_supported_locales(), Iterable)
    assert _supported_locales == get_supported_locales()

# Generated at 2022-06-22 03:40:58.561559
# Unit test for constructor of class Locale
def test_Locale():
    with pytest.raises(TypeError):
        Locale()



# Generated at 2022-06-22 03:41:02.425665
# Unit test for method translate of class Locale
def test_Locale_translate():
    print("test_Locale_translate")
    try:
        load_translations(path=os.path.join(os.path.dirname(__file__),"../locale/"))
    except Exception as ex:
        print(ex)
    try:
        print(Locale.get_closest("en_US").translate("hello"))
    except Exception as ex:
        print(ex)



# Generated at 2022-06-22 03:41:08.423473
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # If a number is below 1000, it will be returned as a string
    # Numbers not below 1000 will be formatted as a comma-separated number
    assert Locale.get("en_US").friendly_number(12)  == "12"
    assert Locale.get("en_US").friendly_number(1234)  == "1,234"
    assert Locale.get("en_US").friendly_number(123456789)  == "123,456,789"
    assert Locale.get("en").friendly_number(12)  == "12"
    assert Locale.get("en").friendly_number(1234)  == "1,234"
    assert Locale.get("en").friendly_number(123456789)  == "123,456,789"

    # If locale is not English or English American, return number

# Generated at 2022-06-22 03:41:12.782666
# Unit test for method list of class Locale
def test_Locale_list():
    locale = Locale("fa_IR")
    assert locale.list([]) == "" # This function is a NOOP.
    assert locale.list(["A"]) == "A" # Just one item in the list.
    assert locale.list(["A", "B", "C"]) == "A \u0648 B \u0648 C"

# Generated at 2022-06-22 03:41:17.083235
# Unit test for function load_translations
def test_load_translations():
    directory = os.getcwd() + "\\locale"
    set_default_locale('en_US')
    load_translations(directory)
    assert(len(_translations) == 2)



# Generated at 2022-06-22 03:41:21.660619
# Unit test for constructor of class Locale
def test_Locale():
    import pytest
    with pytest.raises(NotImplementedError):
        Locale("test").translate("test")


# Generated at 2022-06-22 03:41:33.122674
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """Test format_date"""
    # given
    LOCALE_NAMES[None].update({"name": "Unknown"})
    LOCALE_NAMES["en_US"].update({"name": "American Language (United States)"})
    LOCALE_NAMES["en"].update({"name": "English Language"})
    LOCALE_NAMES["fa"].update({"name": "Persian Language"})
    LOCALE_NAMES["pt"].update({"name": "Portuguese Language"})
    LOCALE_NAMES["zh"].update({"name": "Chinese Language"})
    LOCALE_NAMES["zh_CN"].update({"name": "Mandarin Chinese"})
    # Test Method format_date
    Locale.get("en_US")
    Locale.get("en")
    Locale

# Generated at 2022-06-22 03:41:39.669700
# Unit test for method translate of class Locale
def test_Locale_translate():
    load_translations(
            os.path.join(os.path.dirname(os.path.dirname(__file__)), "translations")
            )
    locale = get("en_US")
    locale.translate("News & Blog")
    locale.translate("Article","Articles", 1)


# Generated at 2022-06-22 03:42:42.542660
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    assert GettextLocale.translate('test')


# Generated at 2022-06-22 03:42:52.544012
# Unit test for method list of class Locale
def test_Locale_list():
    print("Testing Locale.list")
    ar_locale = Locale.get("ar")
    en_locale = Locale.get("en")
    test_list = ['1', '2', '3', '4']
    ar_expected_list = "1 \u0648 2 \u0648 3 \u0648 4"
    en_expected_list = "1, 2, 3 and 4"
    assert ar_locale.list(test_list) == ar_expected_list
    assert en_locale.list(test_list) == en_expected_list
    print("Successfully passed all Locale.list tests!")



# Generated at 2022-06-22 03:42:57.827610
# Unit test for constructor of class Locale
def test_Locale():
    set_supported_locales(["en_US", "fr_FR"])
    with pytest.raises(NotImplementedError):
        Locale.get("en_US").translate("test")


# Generated at 2022-06-22 03:43:09.805752
# Unit test for function load_translations
def test_load_translations():
    # Notice: This function is a test function for function load_translations
    # The following code passes the test for load_translations
    set_default_locale("en_US")
    load_translations("/Users/silence/Cloud/工作/Projects/Github/tornado-examples/locale/")
    my_locale = get("en_US", "es_LA")
    assert my_locale.code == "en_US"
    assert my_locale.translate("Sign out") == "Sign out"
    assert my_locale.translate("%%s") == "%%s"

    my_locale = get("es_LA", "en_US")
    assert my_locale.code == "es_LA"

# Generated at 2022-06-22 03:43:23.787421
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    gen_log.debug(Locale.get_closest()
                  .format_date(datetime.datetime(2004, 3, 3, 14, 35), 7220, True))
    gen_log.debug(Locale.get_closest()
                  .format_date(datetime.datetime(2004, 3, 3, 14, 35), 7220, False))
    gen_log.debug(Locale.get_closest()
                  .format_day(datetime.datetime(2014, 4, 3, 14, 35), 0, True))
    gen_log.debug(Locale.get_closest()
                  .format_day(datetime.datetime(2014, 4, 3, 14, 35), 0, False))

# Generated at 2022-06-22 03:43:28.269883
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    csv_locale = CSVLocale("en", {"unknown": {"apple": "apple", "banana": "banana"}})
    assert csv_locale.translate("apple") == "apple"
    assert csv_locale.translate("banana") == "banana"
    assert csv_locale.translate("kiwi") == "kiwi"


# Generated at 2022-06-22 03:43:40.671945
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    now = time.time()
    past = lambda days: now - days * 24 * 3600
    future = lambda days: now + days * 24 * 3600

    def fmt(date, lang, **args):
        return Locale.get(lang).format_date(date, **args)

    # English
    assert fmt(now, "en") == "1 second ago"
    assert fmt(now, "en", relative=False) == "1 second ago"
    assert fmt(now, "en", full_format=True) == "1 second ago"
    assert fmt(future(1), "en") == "in 1 second"
    assert fmt(future(1), "en", relative=False) == "in 1 second"
    assert fmt(future(1), "en", full_format=True) == "in 1 second"

# Generated at 2022-06-22 03:43:43.337595
# Unit test for function get
def test_get():
    assert get("en_US") == Locale("en_US")
    assert get("fr") == Locale("fr_FR")
test_get()



# Generated at 2022-06-22 03:43:50.329593
# Unit test for method list of class Locale
def test_Locale_list():
    x = ["A", "B", "C"]
    assert(Locale.get("en").list(x) == 'A, B and C')
    x = ["A", "B", "C", "D"]
    assert(Locale.get("en").list(x) == 'A, B, C and D')
    x = ["A"]
    assert(Locale.get("en").list(x) == 'A')
    x = []
    assert(Locale.get("en").list(x) == '')


# Generated at 2022-06-22 03:44:00.611940
# Unit test for method translate of class Locale
def test_Locale_translate():
    # check that the default locale is English
    locale = Locale.get_closest(None)
    assert repr(locale) == "<Locale(code=en_US)>"
    # test that missing translations are returned as the english
    # text with the underscores removed and the leading space
    # preserved.
    assert locale.translate(" No test ") == "No test"
    # test that missing translations are returned as the english
    # text with the underscores removed and the leading space
    # preserved. (Missing plural translations are also returned this
    # way.)
    assert locale.translate(" No test ", "No tests", 2) == "No test"
    
    

# Generated at 2022-06-22 03:44:21.116341
# Unit test for method translate of class Locale
def test_Locale_translate():
    code = 'de'
    translation = {
        'unknown': {u'hello': u'hellow'}
    }
    locale = Locale(code)
    assert str(locale.translate('hello')) == "hellow"

# Generated at 2022-06-22 03:44:28.838369
# Unit test for constructor of class Locale
def test_Locale():
    """
    >>> l = Locale.get_closest("en", "fr", "ru")
    >>> l.code
    'en'
    >>> l = Locale.get_closest("fr", "en", "ru")
    >>> l.code
    'fr'
    >>> l = Locale.get_closest("xyz_XY")
    >>> l.code
    'en_US'
    """


# Generated at 2022-06-22 03:44:40.205472
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Test pgettext of class Locale
    get_supported_locales()
    d = os.path.join(os.path.dirname(__file__), "data", "locale")
    noise = gen_log.getEffectiveLevel() <= logging.DEBUG
    if noise:
        gen_log.setLevel(logging.INFO)

# Generated at 2022-06-22 03:44:52.654405
# Unit test for constructor of class Locale
def test_Locale():
    assert (Locale.get('en').name == 'English (US)')
    assert (Locale.get('en').code == 'en')
    assert (Locale.get('en').rtl == False)
    assert (Locale.get('fa').name == u'\u0641\u0631\u0627\u06cc\u0633\u06cc')
    assert (Locale.get('fa').code == 'fa')
    assert (Locale.get('fa').rtl == True)
    assert (Locale.get('ar').name == u'\u0627\u0644\u0639\u0631\u0628\u064a\u0629')
    assert (Locale.get('ar').code == 'ar')
    assert (Locale.get('ar').rtl == True)

# Generated at 2022-06-22 03:45:05.651933
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """test_Locale_format_day is the unit test for the method Locale_format_day of class Locale.
    """
    from datetime import datetime
    from zulip_bots.lib import NameParser

    bot_mock = Mock()
    bot_mock.name = 'test'  # type: str

    bot_mock.client = Mock()
    bot_mock.client.users = [{'email': 'test@zulip.com', 'full_name': 'Test User'}]  # type: List[Dict[str, str]]

    bot_mock.client.users_by_email = {'test@zulip.com': {'email': 'test@zulip.com', 'full_name': 'Test User'}} # type: Dict[str, Dict[str,

# Generated at 2022-06-22 03:45:14.609316
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    csv_locale = CSVLocale("en", {
        "plural": {
            "a plural message": "a translated plural message",
            "a singular message": "a translated singular message"
        },
        "singular": {
            "a singular message": "a translated singular message",
            "a plural message": "a translated plural message"
        },
        "unknown": {
            "a singular message": "a translated singular message",
            "a plural message": "a translated plural message"
        }
    })
    translated_string = csv_locale.translate("a plural message", "a singular message", 2)
    assert translated_string == "a translated plural message"


# Generated at 2022-06-22 03:45:26.064051
# Unit test for function load_translations
def test_load_translations():
    '''Test function load_translations'''
    import tempfile
    import shutil
    # Create a temp directory
    test_dir = tempfile.mkdtemp()
    locale_file = os.path.join(test_dir, 'ko_KR.csv')
    with open(locale_file, 'w') as f:
        f.write('"누구냐?","아루가냐?"')
    try:
        load_translations(test_dir)
        assert "ko_KR" in _translations.keys()
    except:
        raise
    finally:
        shutil.rmtree(test_dir)
        # Reset _translations
        _translations = {}
        _supported_locales = frozenset([_default_locale])



# Generated at 2022-06-22 03:45:35.932738
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    try:
        trans = {
            "neighborhood": {"context": {"Harlem": "Harlem", "Upper West Side": "Upper West Side"}},
        }
        locale = CSVLocale("en", trans)
        locale.pgettext("neighborhood", "Harlem")
        locale.pgettext("station", "Harlem", None, 42)
        locale.pgettext("neighborhood", "Harlem", "Harlem", 1)
        locale.pgettext("neighborhood", "Upper West Side", "Upper West Side", 2)
    except:
        return False
    return True

# Generated at 2022-06-22 03:45:46.062430
# Unit test for method list of class Locale
def test_Locale_list():
    for lang in _supported_locales:
        locale = Locale.get(lang)
        assert locale.list(()) == ""
        assert locale.list(("Albert")) == "Albert"
        assert locale.list(("Albert", "Berta")) in {
            "Albert and Berta",
            "Albert, Berta",
            "Berta and Albert",
            "Berta, Albert",
        }

# Generated at 2022-06-22 03:45:56.765179
# Unit test for function get
def test_get():
    print(get("en_US"))  # returns en_US
    print(get("en-US"))  # returns en_US
    print(get("en")) # returns en_US
    print(get("es_LA")) # returns es_LA 
    print(get("es_MX")) # returns es_LA
    print(get("fr_FR")) # returns fr_FR
    print(get("pt-BR")) # returns pt_BR
    print(get("pt")) # returns pt_BR
    print(get("zh-cn")) # returns zh_CN
    print(get("zh-hk")) # returns zh_CN
    print(get("zh")) # returns zh_CN
    print(get("zh-tw")) # returns zh_TW
    print(get("zh-mo")) # returns zh_TW



# Generated at 2022-06-22 03:46:18.809871
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    translations = {
        "unknown": {"hello": "hello!"},
        "singular": {"hello": "singular hello!"},
        "plural": {"hello": "plural hello!"},
    }
    en = CSVLocale("en", translations)
    assert _translations == {}
    assert _supported_locales == []
    assert en.translations == translations
    assert en.code == "en"
    assert en.name == "English"
    assert en.rtl == False



# Generated at 2022-06-22 03:46:29.606287
# Unit test for method translate of class Locale
def test_Locale_translate():
    import base64
    import json
    import os
    import re
    import unittest
    import tornado.web
    import tornado.testing
    import tornado.httpserver
    import tornado.ioloop
    import tornado.web
    import tenjin
    import tenjin.gae
    from io import BytesIO
    from io import StringIO
    from google.appengine.ext import db
    import gae_mini_profiler.templates.jinja2 as module
    import jinja2
    import webtest
    import webob

    # Create environment.
    environment = jinja2.Environment()
    environment.globals.update({"_": module.translate})

    # Create template data.
    template_data = """'{{_("Hello world")}}'""".encode("utf-8")

    # Create

# Generated at 2022-06-22 03:46:33.536564
# Unit test for function get_supported_locales
def test_get_supported_locales():
    locals()['_supported_locales'] = frozenset([])
    assert get_supported_locales() == frozenset([])
    get_supported_locales.__wrapped__()

# Generated at 2022-06-22 03:46:45.673095
# Unit test for method translate of class Locale
def test_Locale_translate():
    from unittest import TestCase

    class Test_Locale(TestCase):
        def test_translate(self):
            code = 'en'
            msg = "test"
            plural_msg = "tests"
            count = 0
            test_locale = Locale(code)
            result = test_locale.translate(msg, plural_msg, count)
            print(result)
            self.assertEqual(result, plural_msg, msg="translate test failed")

        def test_pgettext(self):
            code = 'en'
            context = "context"
            msg = "test"
            plural_msg = "tests"
            count = 0
            test_locale = Locale(code)
            result = test_locale.pgettext(context, msg, plural_msg, count)
           

# Generated at 2022-06-22 03:46:48.874047
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    print(GettextLocale._months)
    assert GettextLocale._months == ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]


# Generated at 2022-06-22 03:46:50.044066
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale('en_US')



# Generated at 2022-06-22 03:47:00.229890
# Unit test for method list of class Locale
def test_Locale_list():
    locale = Locale.get("en")
    assert locale.list(["A", "B", "C"]) == 'A and C'
    assert locale.list(["A", "B", "C", "D"]) == 'A and C'
    assert locale.list(["A", "B", "C", "D", "E"]) == 'A and C'
    assert locale.list(["A"]) == 'A'
    assert locale.list([]) == ''
    locale = Locale.get("fa")
    assert locale.list(["A", "B", "C"]) == 'A \u0648 C'
    assert locale.list(["A", "B", "C", "D"]) == 'A \u0648 C'

# Generated at 2022-06-22 03:47:10.696736
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    for l in ["en", "en_US", "zh", "zh_CN",
              "fa", "ar", "he"]:
        loc = Locale.get(l)
        print(loc.code)
        print(loc.format_date(datetime.datetime.now()))
if __name__ == "__main__":
    init()
    test_Locale_format_date()

__all__ = ["load_gettext_translations", "load_translations", "init",
            "get_supported_locales", "get_closest_locale", "get_closest_locales",
            "get_locale", "set_locale", "Locale"]

# Generated at 2022-06-22 03:47:13.212736
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    locale = CSVLocale("test", {"unknown":{"name":"test locale"}})
    assert locale.translations["unknown"]["name"] == "test locale"


# Generated at 2022-06-22 03:47:16.065259
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_locale = Locale.get("en")
    answer = test_locale.friendly_number(123456789)
    assert (answer == "123,456,789")



# Generated at 2022-06-22 03:47:38.421716
# Unit test for constructor of class Locale
def test_Locale():
    locale1 = Locale("en")
    assert locale1.code == "en"
    assert locale1.name == "English"
    assert locale1.rtl == False



# Generated at 2022-06-22 03:47:43.990071
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale('en_US').friendly_number(100) == '100'
    assert Locale('en_US').friendly_number(1000) == '1,000'
    assert Locale('zh_CN').friendly_number(1000) == '1000'


# Generated at 2022-06-22 03:47:54.949616
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    tree = os.path.join(os.path.dirname(__file__), "translations")
    domain = "tornado"
    load_gettext_translations(tree, domain)
    english = _translations["en_US"]
    spanish = _translations["es_LA"]

    # test date formatting
    date = datetime.date(2010, 1, 2)
    assert english.strftime(date) == "01/02/10"
    assert spanish.strftime(date) == "02/01/10"

    # test string formatting
    assert english.ugettext("I'm a test") == "I'm a test"
    assert spanish.ugettext("I'm a test") == u"Soy una prueba"

    # test different plural forms

# Generated at 2022-06-22 03:48:00.105047
# Unit test for method list of class Locale
def test_Locale_list():
    o_Locale = Locale.get("en")

    assert o_Locale.list(["A", "B", "C"]) == "A, B and C"
    assert o_Locale.list([]) == ""
    assert o_Locale.list(["A"]) == "A"


# Generated at 2022-06-22 03:48:10.217751
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    from lite_mms.apis.translation import load_translations
    from .const import BASE_DIR

    import os
    from lite_mms.const import BASE_DIR
    load_translations(os.path.join(BASE_DIR, "translations"))
    csv_locale = CSVLocale("en_US", {})
    
    csv = {
        "singular": {"appointment": "appointment", "appointment[p]": "appointments"},
        "plural": {"appointment": "appointments"},
        "unknown": {},
    }

    csv_locale = CSVLocale("zh_CN", csv)
    assert csv_locale.translate("appointment", count=1) == "appointment"

# Generated at 2022-06-22 03:48:23.387584
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en_US").friendly_number(100) == '100'
    assert Locale.get("en_US").friendly_number(1000) == '1,000'
    assert Locale.get("en_US").friendly_number(1000000) == '1,000,000'
    assert Locale.get("en").friendly_number(100) == '100'
    assert Locale.get("en").friendly_number(1000) == '1,000'
    assert Locale.get("en").friendly_number(1000000) == '1,000,000'
    assert Locale.get("de").friendly_number(100) == '100'
    assert Locale.get("de").friendly_number(1000) == '1000'

# Generated at 2022-06-22 03:48:35.851234
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    def test_format_day(date):
        day = date.day
        month = date.month
        year = date.year
        locale = Locale.get('en_US')
        date_str = locale.format_day(date)
        assert date_str == '{:%A}, {:%B} {:%d}'.format(date)

    def test_format_day_dow(date):
        day = date.day
        month = date.month
        year = date.year
        locale = Locale.get('en_US')
        date_str = locale.format_day(date, dow=False)
        assert date_str == '{:%B} {:%d}'.format(date)

    test_format_day(datetime.date(2019, 7, 22))
    test_format_day_

# Generated at 2022-06-22 03:48:47.112106
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    loc = CSVLocale("en_US", {})
    assert loc.translate("Hello, $name", None, None) == "Hello, $name"
    loc = CSVLocale("en_US", {"singular":{"Hello, $name": "Hello, $name"}})
    assert loc.translate("Hello, $name", None, None) == "Hello, $name"
    loc = CSVLocale("en_US", {"plural":{"Hello, $name": "Hello, $name"}})
    assert loc.translate("Hello, $name", None, 1) == "Hello, $name"
    loc = CSVLocale("en_US", {"unknown":{"Hello, $name": "Hello, $name"}})
    assert loc.translate("Hello, $name", None, 1) == "Hello, $name"

# Generated at 2022-06-22 03:48:53.369944
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    locale = CSVLocale("en", translations={
        "singular": {
            "No results found.": "No results found."
        },
        "unknown": {
            "No results found.": "No results found."
        }
    })
    assert locale.pgettext("search_results", "No results found.") == "No results found."


# Generated at 2022-06-22 03:49:04.730404
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import unittest
    import inspect
    import datetime
    import pytz

    class Locale_format_date_TestCase(unittest.TestCase):
        
        def test_locale(self):
            
            class TestLocale(Locale):
                def translate(self, message, plural_message=None, count=None):
                    return message
                    
            l = TestLocale('en_US')
            
            def test_format_date(self, date, expected):
                self.assertEqual(l.format_date(date), expected)

            # future date
            test_format_date(self, datetime.datetime.now()+datetime.timedelta(days=1), "Wednesday, July 25, 2018 at 4:25 pm")
            # today

# Generated at 2022-06-22 03:49:23.013489
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    locale = CSVLocale('zh_CN', dict())
    context = ''
    message = 'test message'
    assert locale.pgettext(context, message) == 'test message'



# Generated at 2022-06-22 03:49:33.933977
# Unit test for method list of class Locale
def test_Locale_list():
    locale = Locale("en_UK")
    assert locale.list(["a", "b", "c"]) == "a, b and c"
    assert locale.list(["a", "b"]) == "a and b"
    assert locale.list(["a"]) == "a"
    assert locale.list([]) == ""
    # Test that we can translate the translation.
    def dummy_translate(message, plural_message=None, count=None):
        return "translated: " + message

    locale.translate = dummy_translate
    assert locale.list(["a", "b", "c"]) == "translated: a, b and c"

    locale = Locale("fa")

# Generated at 2022-06-22 03:49:38.638952
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    assert CSVLocale(None, None).pgettext('context', 'message') == 'message'



# Generated at 2022-06-22 03:49:48.641516
# Unit test for method translate of class Locale
def test_Locale_translate():
    l = Locale("en")
    assert l.translate("testing") == "testing"
    assert l.translate("%(testing)s", count=1,
                       plural_message="%(testing)s testings") == "testing"
    assert l.translate("%(testing)s", count=2,
                       plural_message="%(testing)s testings") == "2 testings"
    l = Locale("fr")
    assert l.translate("testing") == "expérimentation"
    assert l.translate("%(testing)s", count=1,
                       plural_message="%(testing)s testings") == "expérimentation"

# Generated at 2022-06-22 03:49:59.703345
# Unit test for constructor of class Locale

# Generated at 2022-06-22 03:50:07.793177
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class GettextLocaleMock(GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations):
            self.translations = translations
            self.code = code
            self.translations.gettext = self.gettext
            self.translations.ngettext = self.ngettext
    _test_locale = GettextLocaleMock("en", gettext.NullTranslations())
    # test `self.ngettext` with the context
    assert _test_locale.pgettext(
        "organization", "club", "clubs", 2
    ) == "clubs_with_context"
    # test `self.ngettext` without the context

# Generated at 2022-06-22 03:50:11.929987
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_number = 100000
    assert (Locale.get('en_US').friendly_number(test_number) == "100,000")