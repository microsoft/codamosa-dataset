

# Generated at 2022-06-22 03:41:30.565872
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    csv_locale = CSVLocale("en", {
        'plural': {'Plural': 'Plural', 'Singular': 'Singular'},
        'singular': {'Plural': 'Plural', 'Singular': 'Singular'},
        'unknown': {'Plural': 'Plural', 'Singular': 'Singular'}})

    csv_locale.translate('Singular', 'Plural', 2)
    csv_locale.translate('Singular')



# Generated at 2022-06-22 03:41:37.520827
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from zulip_bots.lib import i18n
    # adding arabic locale name
    LOCALE_NAMES["ar"] = {"name": "Arabic"}
    _ = lambda s: s
    ar = i18n.Locale.get("ar")
    date = datetime.datetime(2018, 2, 20)
    output = ar.format_day(date)
    # arabic locale name is added so output of this function should not be empty
    assert output



# Generated at 2022-06-22 03:41:49.125922
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale("en_US").friendly_number(10000) == "10,000"
    assert Locale("en_US").friendly_number(123456789) == "123,456,789"
    assert Locale("en_US").friendly_number(1000) == "1,000"
    assert Locale("en_US").friendly_number(1) == "1"
    assert Locale("en_US").friendly_number(100) == "100"
    assert Locale("en_US").friendly_number(1000000000) == "1,000,000,000"
    assert Locale("de_DE").friendly_number(10000) == "10000"
    assert Locale("de_DE").friendly_number(123456789) == "123456789"

# Generated at 2022-06-22 03:41:57.065071
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # set up
    expected_result = 0
    actual_result = 0
    # Check that the method is not implemented
    try:
        Locale.get("en").pgettext("","")
    except NotImplementedError as e:
        if (e.args[0] == "pgettext is an abstract method"):
            actual_result = 1
    assert actual_result == expected_result

# Generated at 2022-06-22 03:42:08.445052
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    sample_code = "en_GB"
    sample_translations = {"unknown": {"name": "English (UK)"},
                           "singular": {"name": "English (UK)"},
                           "plural": {"name": "English (UK)"}}

    sample_locale = CSVLocale(sample_code, sample_translations)

    assert sample_locale.code == sample_code, \
           "CSVLocale.__init__() assigns wrong code to self.code."

    assert sample_locale.name == "English (UK)", \
           "CSVLocale.__init__() assigns wrong name to self.name."

    assert sample_locale.rtl == False, \
           "CSVLocale.__init__() assigns wrong value to self.rtl."

    assert sample_locale.translations == sample

# Generated at 2022-06-22 03:42:13.066503
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    """Test load_gettext_translations()"""
    translation_file = os.path.join(os.path.dirname(__file__), 'locale/de/LC_MESSAGES/tornado.mo')
    load_gettext_translations(translation_file, 'tornado')
    assert get('de') is not None

# Generated at 2022-06-22 03:42:26.191338
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale_date_obj = datetime.datetime(2020, 2, 23, 0, 0)
    locale_date_str = "Sunday, February 23"
    locale_date_str_no_dow = "February 23"

    # Test en_US
    locale_obj = Locale.get("en_US")
    assert locale_obj.format_day(locale_date_obj) == locale_date_str
    assert locale_obj.format_day(locale_date_obj, dow=False) == locale_date_str_no_dow

    # Test de_DE
    locale_obj = Locale.get("de_DE")
    assert locale_obj.format_day(locale_date_obj) == locale_date_str

# Generated at 2022-06-22 03:42:28.996439
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    with raises(AssertionError):
        CSVLocale("fr", {})
        CSVLocale("fr", {"plural": {}})
    with raises(AssertionError):
        CSVLocale("fr", {"plural": {}, "unknown": {}})
    with raises(AssertionError):
        CSVLocale("fr", {"plural": {}, "unknown": {}, "singular": {}})



# Generated at 2022-06-22 03:42:41.802234
# Unit test for method translate of class Locale
def test_Locale_translate():
    from .translations_test_utils import get_test_translations
    trans = get_test_translations()
    trans.set_translation("de_DE", "foo", "bar")
    trans.set_translation("de_DE", "value", "Wert")
    trans.set_translation("de_DE", "value", "Werte", 2)
    trans.set_translation("de_DE", "value", "Werte", "plural")
    trans.set_translation("en_US", "value", "value")
    trans.set_translation("en_US", "value", "values", 2)
    trans.set_translation("en_US", "value", "values", "plural")
    load_translations(trans)
    de = Locale.get("de_DE")

# Generated at 2022-06-22 03:42:53.830115
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    load_translations("_", ["en_US", "zh_CN"], default_locale="zh_CN")
    assert Locale("zh_CN").format_date(datetime.datetime(1980, 7, 10, 0, 0)) == "7月 10日 上午 12:00"
    assert Locale("zh_CN").format_date(datetime.datetime(1980, 7, 10, 0, 0), full_format=True) == "7月 10日, 1980 上午 12:00"
    assert Locale("zh_CN").format_date(datetime.datetime(1980, 7, 10, 0, 0), shorter=True) == "7月 10日"

# Generated at 2022-06-22 03:43:13.887988
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations(os.getcwd() + "/../locale", "tornado.tests")


# Generated at 2022-06-22 03:43:26.186485
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    #Unit test for method translate of class GettextLocale
    _translations = {
        'plural': {
            'Joel has %(points)d points': 'Joel有%(points)d分'
        },
        'singular': {
            '1 point': '1分',
            '2 point': '2分'
        },
        'unknown': {

        }
    }
    translations = gettext.NullTranslations()
    gtl = GettextLocale('zh_CN',translations)
    assert gtl.translate('Joel has %(points)d points', None, 3) == 'Joel有3分'
    assert gtl.translate('Joel has %(points)d points', None, 1) == 'Joel has 1 point'

# Generated at 2022-06-22 03:43:30.607698
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert (Locale.get("en").friendly_number(0) == "0")
    assert (Locale.get("en").friendly_number(1) == "1")
    assert (Locale.get("en").friendly_number(10) == "10")
    assert (Locale.get("en").friendly_number(100) == "100")
    assert (Locale.get("en").friendly_number(1000) == "1,000")
    assert (Locale.get("en").friendly_number(10000) == "10,000")
    assert (Locale.get("en").friendly_number(100000) == "100,000")
    assert (Locale.get("en").friendly_number(1000000) == "1,000,000")

# Generated at 2022-06-22 03:43:34.914337
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale('fa')
    date = datetime.datetime.now()
    print(locale.format_day(date))

#

# Generated at 2022-06-22 03:43:35.929175
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    a_locale = GettextLocale(
        code='ru',
        translations=gettext.NullTranslations(),
    )

# Generated at 2022-06-22 03:43:43.604731
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    csvlocale_lang = 'de_DE'
    csvlocale_translations = {'plural': {'today': 'heute', 'yesterday': 'gestern'}, 'unknown': {'tomorrow': 'morgen', 'last week': 'letzte Woche'}}
    csvlocale = CSVLocale(csvlocale_lang, csvlocale_translations)
    assert csvlocale.code == csvlocale_lang
    assert csvlocale.translations == csvlocale_translations

# Generated at 2022-06-22 03:43:55.688072
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    try:
        locale = CSVLocale("test", {})
        locale.translate("no message")
        locale.pgettext("context", "no message")
        gen_log.info("Passed test: basic test for CSVLocale.pgettext")
    except Exception as e:
        gen_log.error("Failed test: basic test for CSVLocale.pgettext")
        raise e

# Generated at 2022-06-22 03:44:05.843693
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    """Verify that there are no un-translated messages in pgettext output.

    This is done by simple test on zero-length separator.
    """
    l = GettextLocale("en", gettext.NullTranslations())
    assert l.pgettext("translatable_context", "translatable_message") == "translatable_message"
    assert l.pgettext("translatable_context", "translatable_message", count=0) == "translatable_message"
    assert l.pgettext("translatable_context", "translatable_message", count=2) == "translatable_message"
    assert l.pgettext("translatable_context", "translatable_message", count=2, plural_message="translatable_message") == "translatable_message"

# Generated at 2022-06-22 03:44:10.570948
# Unit test for method list of class Locale
def test_Locale_list():
    import pytest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import coroutine
    locale = locale_module.Locale.get('ar')
    # Calling list() with argument(s) and check the result 
    assert locale.list(["A", "B" ,"C"]) == 'A و B و C'
    

# Generated at 2022-06-22 03:44:13.038027
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    test_Locale = GettextLocale('zh_CN', {'zh_CN':{'unknown':{'{test}':'test'}}})
    print(test_Locale.translate('{test}'))

# Generated at 2022-06-22 03:44:42.979789
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    test_obj = Locale
    test_obj._cache = {}
    assert test_obj.get_closest(None) == test_obj.get("en_US")
    assert test_obj.get_closest("") == test_obj.get("en_US")
    assert test_obj.get_closest("en-US") == test_obj.get("en_US")
    assert test_obj.get_closest("en_US") == test_obj.get("en_US")
    assert test_obj.get_closest("en_UK") == test_obj.get("en_US")
    assert test_obj.get_closest("en") == test_obj.get("en_US")

# Generated at 2022-06-22 03:44:46.032438
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    print(GettextLocale('en', 'en'))


# Generated at 2022-06-22 03:44:50.279498
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    locale = Locale.get("en")
    assert locale.pgettext("one", "Singular") == "Singular"
    assert locale.pgettext("one", "Singular", "Plural", 3) == "Plural"



# Generated at 2022-06-22 03:44:53.180367
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    #translations = {'unknown': {}, 'singular': {'a': 'b'}, 'plural': {}}
    #locale = CSVLocale('code', translations)
    assert 1 == 1

# Generated at 2022-06-22 03:45:06.204151
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    locale = CSVLocale("en", {})
    locale.translate = MagicMock()
    locale.pgettext("foo", "bar")
    locale.translate.assert_called_with("bar", None, None)
    locale.translate.reset_mock()
    locale.pgettext("foo", "bar", None, None)
    locale.translate.assert_called_with("bar", None, None)
    locale.translate.reset_mock()
    locale.pgettext("foo", "bar", "baz", None)
    locale.translate.assert_called_with("bar", "baz", None)
    locale.translate.reset_mock()
    locale.pgettext("foo", "bar", "baz", 3)

# Generated at 2022-06-22 03:45:15.945498
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    x = CSVLocale("en", {
        "plural": {
            "hours ago": "%(num)d hours ago",
            "seconds ago": "%(num)s seconds ago",
            "minutes ago": "%(num)d minutes ago"
        },
        "singular": {
            "seconds ago": "%(num)s second ago",
            "minutes ago": "%(num)d minute ago",
            "hours ago": "%(num)d hour ago"
        },
        "unknown": {
            "older than a month": "older than a month"
        }
    })
    assert x.translate("hours ago", "hours ago", 720) == "720 hours ago"
    assert x.translate("hours ago", "hours ago", 1) == "1 hour ago"

# Generated at 2022-06-22 03:45:19.958922
# Unit test for method list of class Locale
def test_Locale_list():
    locale = Locale("fa_IR")
    print(locale.list(["a", "b", "c", "d", "e"]))

if __name__ == "__main__":
    test_Locale_list()

# Generated at 2022-06-22 03:45:25.801359
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    _ = GettextLocale('en_US').translate
    assert _('Pot') == 'Pot'
    assert _('Pot', count=1) == 'Pot'
    assert _('Pot', count=2) == 'Pots'
    assert _('Pot', 'Pots', count=2) == 'Pots'
    

# Generated at 2022-06-22 03:45:36.022501
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en_US")
    assert locale.friendly_number(0) == "0"
    assert locale.friendly_number(1000) == "1,000"
    assert locale.friendly_number(1000000) == "1,000,000"

    locale = Locale.get("it")
    assert locale.friendly_number(0) == "0"
    assert locale.friendly_number(1000) == "1" + "\u00a0" + "000"
    assert locale.friendly_number(1000000) == "1" + "\u00a0" + "000" + "\u00a0" + "000"
    
    
    

# Generated at 2022-06-22 03:45:39.666615
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/home/alex/Documents/python_django/tornado/tornado/locale/","tornado")



# Generated at 2022-06-22 03:46:07.715624
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l=Locale.get('en')
    assert l.friendly_number(3) == "3"
    assert l.friendly_number(3003) == "3,003"
    assert l.friendly_number(3003003) == "3,003,003"
    assert l.friendly_number(3003003003) == "300,300,3003"
    assert l.friendly_number(123456789) == "123,456,789"
    assert l.friendly_number(0) == "0"



# Generated at 2022-06-22 03:46:14.962866
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    mycode = "nl"
    mytrans = gettext.NullTranslations()
    locale_instance = GettextLocale(mycode, mytrans)
    message = "Ik heb geen idee"
    context = "law"
    plural_message = "Ik heb nog steeds geen idee"
    count = 3
    result = locale_instance.pgettext(context, message, plural_message, count)
    assert len(result) == len(message)
    result = locale_instance.pgettext(context, message)
    assert len(result) == len(message)

# test_GettextLocale_pgettext()

# Generated at 2022-06-22 03:46:27.221276
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    pass
    mylocale = GettextLocale("fr", {
    "domain": "messages",
    "localedir": "locale",
    "fallback": True,
    "codeset": "UTF-8"})
    assert mylocale.translate("Welcome to Zulip!") == "Bienvenue sur Zulip !"
    assert mylocale.translate("Welcome to Zulip!", "Welcomes to Zulip!", 1) == "Bienvenue sur Zulip !"
    assert mylocale.translate("Welcome to Zulip!", "Welcomes to Zulip!", 2) == "Bienvenues sur Zulip !"
    # Unit test for method pgettext of class GettextLocale
    assert mylocale.pgettext("law","right") == "right"

# Generated at 2022-06-22 03:46:39.486038
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    import unittest
    from tornado.options import options
    from tornado.testing import AsyncTestCase, gen_test


# Generated at 2022-06-22 03:46:42.704916
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    assert _default_locale == "en_US"
    assert _supported_locales != {}
test_set_default_locale()


# Generated at 2022-06-22 03:46:49.320308
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    print("Testing friendly_number method in Locale")
    assert Locale.get("en").friendly_number(10) == "10"
    assert Locale.get("en").friendly_number(100) == "100"
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"



# Generated at 2022-06-22 03:46:52.602215
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    test_gettext_locale_dir = os.path.join(os.path.dirname(__file__), 'test_gettext_locale')
    load_gettext_translations(test_gettext_locale_dir, "testgettext")


# Generated at 2022-06-22 03:47:04.475060
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    import time
    import pytz
    now = datetime.datetime.now(pytz.timezone("America/New_York"))
    test_date = datetime.datetime(2018, 1, 2, 13, 37, 0)
    locale = Locale.get_closest("en_US")
    # test when relative days is 0
    assert locale.format_date(test_date, now.utcoffset().seconds // 60, True, False) == "January 2, 2018 at 3:37:00 PM"
    assert locale.format_date(test_date, now.utcoffset().seconds // 60, True, True) == "January 2, 2018"

# Generated at 2022-06-22 03:47:05.753204
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert len(get_supported_locales()) == 1


# Generated at 2022-06-22 03:47:15.848545
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    from tornado.escape import utf8

    translations = {
        "singular": {
            utf8(
                "What's the difference between a crocodile and an alligator?\n"
            ): utf8(
                "One says 'See you later!', and the other one says 'In a while, crocodile!'\n"
            ),
            utf8(
                "What did the student with a cold in his head say?\n"
            ): utf8(
                "I can't think straight right now.\n"
            ),
        },
    }
    locale = CSVLocale("en", translations)

# Generated at 2022-06-22 03:47:36.499202
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    return True



# Generated at 2022-06-22 03:47:37.903720
# Unit test for function get
def test_get():
    user_locale = tornado.locale.get("es_LA")
    print(user_locale.translate("Sign out"))

# Generated at 2022-06-22 03:47:50.961964
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    def test_format(date, local_date, gmt_offset, dow, expected):
        actual = Locale("en").format_day(date, gmt_offset, dow)
        assert actual == expected

    # Test that the offset is applied correctly
    test_format(
        date=datetime.datetime(2018, 1, 22),
        local_date=datetime.datetime(2018, 1, 22),
        gmt_offset=0,
        dow=True,
        expected="Monday, January 22",
    )
    test_format(
        date=datetime.datetime(2018, 1, 22),
        local_date=datetime.datetime(2018, 1, 21),
        gmt_offset=24,
        dow=True,
        expected="Monday, January 22",
    )

# Generated at 2022-06-22 03:47:54.788316
# Unit test for function load_translations
def test_load_translations():
    load_translations(os.curdir, 'utf-8')
    assert _translations is not None
    assert _supported_locales is not None
    assert _translations['es_LA']
    assert _supported_locales == frozenset([_default_locale, 'es_LA'])



# Generated at 2022-06-22 03:47:57.304660
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert(Locale.get('').friendly_number(1000) == '1,000')


# Generated at 2022-06-22 03:47:58.813402
# Unit test for function load_translations
def test_load_translations():
    load_translations('locale.csv', 'utf-8')



# Generated at 2022-06-22 03:48:09.674673
# Unit test for function load_translations

# Generated at 2022-06-22 03:48:23.302836
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en_US")
    assert locale.friendly_number(1) == '1'
    assert locale.friendly_number(123) == '123'
    assert locale.friendly_number(1234) == '1,234'
    assert locale.friendly_number(12345) == '12,345'
    assert locale.friendly_number(123456) == '123,456'
    assert locale.friendly_number(1234567) == '1,234,567'
    assert locale.friendly_number(12345678) == '12,345,678'
    assert locale.friendly_number(123456789) == '123,456,789'
    assert locale.friendly_number(1234567890) == '1,234,567,890'

# Generated at 2022-06-22 03:48:34.577844
# Unit test for function get
def test_get():
    Locale.get_closest = get_closest
    assert get() == Locale(default_locale)
    assert get('en', 'fa_IR') == Locale(default_locale)
    assert get('en_US', 'fa_IR') == Locale(default_locale)
    assert get('en_UK', 'en_US') == Locale('en_US')
    assert get('en_UK', 'en_US', 'fr') == Locale('en_US')
    assert get('en_UK', 'fr', 'en_US') == Locale('en_US')
    assert get('fr', 'en_UK') == Locale('en_UK')
    Locale.get_closest = get_closest_orig


# Generated at 2022-06-22 03:48:46.513343
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale("en_US")
    test_datetime = datetime.datetime(2017, 9, 5, 12, 15, 0)
    assert locale.format_day(test_datetime) == "Tuesday, September 5"
    assert locale.format_day(test_datetime, dow=False) == "September 5"
    assert locale.format_day(test_datetime, gmt_offset=1, dow=False) == "September 5"
    assert locale.format_day(test_datetime, gmt_offset=2, dow=False) == "September 5"
    assert locale.format_day(test_datetime, gmt_offset=-1, dow=False) == "September 4"
    assert locale.format_day(test_datetime, gmt_offset=-2, dow=False) == "September 4"

# Generated at 2022-06-22 03:49:24.863955
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert type(get_supported_locales) == type(tuple()), "Function get_supported_locales is not returning a tuple"


# Generated at 2022-06-22 03:49:35.120973
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    code_1 = "ko_KR"
    code_2 = "zh_CN"
    code_3 = "en_US"
    translations_1 = {"unknown": {"msg_1": "ko_KR_msg_1", "msg_2": "ko_KR_msg_2"},
                      "singular": {"msg_1": "ko_KR_msg_1", "msg_2": "ko_KR_msg_2"},
                      "plural": {"msg_1": "ko_KR_msg_1", "msg_2": "ko_KR_msg_2"}}

# Generated at 2022-06-22 03:49:40.177670
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    # class CSVLocale
    # method pgettext
    _lang = "zh_CN"
    _local = CSVLocale(_lang, None)
    _context = "Test"
    _message = "Test message"
    _count = 1
    assert _local.pgettext(_context, _message, _count=_count) == _message



# Generated at 2022-06-22 03:49:49.377151
# Unit test for method list of class Locale
def test_Locale_list():
    # check the function list when given a empty parts []
    l = Locale.get("en")
    assert l.list([]) == ""
    # check the function list when given a parts with one element
    l = Locale.get("en")
    assert l.list(["a"]) == "a"
    # check the function list when given a parts with two elements
    l = Locale.get("en")
    assert l.list(["a", "b"]) == "a and b"
    # check the function list when given a parts with more than two elements
    l = Locale.get("en")
    assert l.list(["a", "b", "c"]) == "a, b and c"
    # check the function list when given a parts with more than two elements
    # in this case, the given language is not English

# Generated at 2022-06-22 03:49:57.559247
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    from .locale import Locale
    loc = Locale.get_closest('en')
    assert loc.friendly_number(12345678)=='12,345,678'
    loc = Locale.get_closest('hi')
    assert loc.friendly_number(12345678)=='12345678'

    loc = Locale.get_closest('fa')
    assert loc.friendly_number(12345678)=='12,345,678'
    assert loc.friendly_number(0)=='0'



# Generated at 2022-06-22 03:50:03.417099
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    locale = CSVLocale("en", {"unknown": {"_": "unknown"}})
    assert locale.pgettext("context", "_") == "unknown"

_digits = [u"\u06f0", u"\u06f1", u"\u06f2", u"\u06f3", u"\u06f4", u"\u06f5", u"\u06f6", u"\u06f7", u"\u06f8", u"\u06f9"]


# Generated at 2022-06-22 03:50:14.047624
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    # UTC offset of Hong Kong(+08:00)
    hk_offset = 480
    # Create a datetime object for Hong Kong time zone
    d = datetime.datetime(2015, 1, 22, 5, 30, 0, 0, tzinfo=datetime.timezone(datetime.timedelta(minutes=hk_offset)))
    locale = Locale.get('zh_CN')
    assert locale.format_day(d, hk_offset) == "星期四，一月 22"
    assert locale.format_day(d, hk_offset, False) == "一月 22"
    locale = Locale.get('en_US')
    assert locale.format_day(d, hk_offset) == "Wednesday, January 22"