

# Generated at 2022-06-22 03:41:08.621315
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    # An empty GettextLocale
    gtl = GettextLocale('fa_IR', gettext.NullTranslations())
    assert gtl.translate('standing') == 'standing'
    # A filled in GettextLocale
    gtl_ = GettextLocale('fa_IR', gettext.GNUTranslations(StringIO('msgid "standing"\nmsgstr "sitting"\n')))
    assert gtl_.translate('standing') == 'sitting'
    print('Tests for GettextLocale.translate() passed')


# Generated at 2022-06-22 03:41:12.043941
# Unit test for constructor of class Locale
def test_Locale():
    # Construct a Locale
    test_loc = Locale('en')
    assert test_loc.code == 'en'
    assert test_loc.name == 'English'
    assert test_loc.rtl == False



# Generated at 2022-06-22 03:41:16.435279
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    x = Locale.get('en')
    assert x.pgettext('context', 'test') == 'test'
    assert x.pgettext('context', 'test', count = 1) == 'test'
    assert x.pgettext('context', 'test', 'tests', 1) == 'test'
    assert x.pgettext('context', 'test', 'tests', 2) == 'tests'

# Generated at 2022-06-22 03:41:24.989087
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    import unittest
    from unittest import mock
    
    locales = ["fa", "en"]
    
    for locale in locales:
        test = Locale.get(locale)
        if locale == "fa":
            result = test.friendly_number(153984)
            assert result == "153984"
        if locale == "en":
            result = test.friendly_number(100000)
            assert result == "100,000"



# Generated at 2022-06-22 03:41:32.535084
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from tornado.template import Template
    from tornado.testing import AsyncTestCase, gen_test
    from motor import motor_tornado


    class TestLocale(AsyncTestCase):

        @gen_test
        async def test_format_day(self):
            locale = Locale.get('es')
            day = datetime(2018, 3, 8)
            title = locale.format_day(day)
            print(title)  # Jueves, marzo 8
            self.assertEqual(title, 'Jueves, marzo 8')


    if __name__ == '__main__':
        import unittest
        unittest.main()



# Generated at 2022-06-22 03:41:40.703681
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():

    csv_locale = CSVLocale("en", {})
    assert csv_locale.translate("test") == "test"
    assert csv_locale.translate("test", "tests", 0) == "tests"
    assert csv_locale.translate("test", "tests", 1) == "test"
    assert csv_locale.translate("test", "tests", 5) == "tests"
    assert csv_locale.translate("test", "tests", "str") == "test"
    assert csv_locale.translate("test", "tests") == "test"
    assert csv_locale.translate("test", "tests", None) == "test"

    # Test case with empty translations
    translations = {
        "unknown": {}
    }

    csv_locale

# Generated at 2022-06-22 03:41:48.163897
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from tzlocal import get_localzone
    
    l = Locale.get("en_US")
    date = datetime(2018, 5, 11)
    date_str = l.format_day(date, gmt_offset = get_localzone().utcoffset(date).seconds / 60, dow = True)
    if date_str != "Friday, May 11":
        raise Exception("failed")
    else:
        print("Passed")


# Generated at 2022-06-22 03:41:52.648484
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    t = dict(unknown=dict(Hello="Hola"))
    c = CSVLocale('en', t)
    assert c.translations == t
    assert c.code == 'en'
    assert c.name == 'Unknown'
    assert c.rtl == False


# Generated at 2022-06-22 03:41:55.193915
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    assert test_GettextLocale_translate

# Generated at 2022-06-22 03:41:56.534691
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    pass


# Generated at 2022-06-22 03:42:21.669125
# Unit test for method translate of class Locale
def test_Locale_translate():
    pass

# Generated at 2022-06-22 03:42:29.190841
# Unit test for function get_supported_locales
def test_get_supported_locales():
    """Tests get_supported_locales."""
    load_translations("./test_translations")
    assert get_supported_locales() == [
        "en_US",
        "es_AR",
        "es_CL",
        "es_GT",
        "es_LA",
        "es_MX",
        "es_PR",
        "es_US",
        "es_VE",
        "pt_BR",
    ], (
        "get_supported_locales returned inaccurate list of supported locales")



# Generated at 2022-06-22 03:42:37.835293
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    date = datetime.datetime(2020, 5, 14, 6, 0)
    locale = Locale.get('en')
    assert locale.format_day(date) == "Thursday, May 14"
    assert locale.format_day(date, dow=False) == "May 14"
    assert locale.format_day(date, gmt_offset=1440) == "Friday, May 15"
    assert locale.format_day(date, gmt_offset=1440, dow=False) == "May 15"
    

# Generated at 2022-06-22 03:42:50.957534
# Unit test for function get
def test_get():
    global _default_locale, _supported_locales, _translations

# Generated at 2022-06-22 03:42:59.245210
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    now=datetime.now()
    code='en_US'
    current_date=[now.year,now.month,now.day,now.hour,now.minute]
    #defaul
    assert Locale.get(code).format_date(datetime(current_date[0],current_date[1],current_date[2],current_date[3],current_date[4]))=="a few seconds ago"
    #short
    assert Locale.get(code).format_date(datetime(current_date[0],current_date[1],current_date[2],current_date[3],current_date[4]),shorter=True)=="1 second ago"
    #shorter not used

# Generated at 2022-06-22 03:43:00.883473
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales == get_supported_locales()



# Generated at 2022-06-22 03:43:11.684344
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    translations = {}
    translations["singular"] = {"right":"десница", "club": "клуб"}
    translations["plural"] = {"clubs": "клубова"}
    codes = ["custom"]
    gettext_translations = {}
    gettext_translations["custom"] = translations
    text = "клубова"
    context = "organization"
    message = "club"
    plural_message = "clubs"
    count = 5
    actual = CSVLocale("custom", translations).pgettext(context, message, plural_message, count)
    expected = text
    assert actual == expected

# Generated at 2022-06-22 03:43:14.829491
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    assert GettextLocale("en", gettext.NullTranslations()).translate("one") == "one"


# Generated at 2022-06-22 03:43:26.729193
# Unit test for method translate of class Locale
def test_Locale_translate():
    print(Locale.get_closest('en-us').translate('hello'))
    print(Locale.get_closest('zh_CN').translate('hello'))
    print(Locale.get_closest('en-us').translate('you'))
    print(Locale.get_closest('zh_CN').translate('you'))
    print(Locale.get_closest('en-us').translate('world'))
    print(Locale.get_closest('zh_CN').translate('world'))
    print(Locale.get_closest('en-us').translate('hello','world'))
    print(Locale.get_closest('zh_CN').translate('hello','world'))

# Generated at 2022-06-22 03:43:30.553783
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("test_set_default_locale")
    assert _default_locale == "test_set_default_locale"
    assert _supported_locales == frozenset(list(_translations.keys()) + [_default_locale])
    set_default_locale("en_US")


# Generated at 2022-06-22 03:43:52.188927
# Unit test for function get
def test_get():
    assert isinstance(get("en"), Locale)


# Generated at 2022-06-22 03:44:02.962297
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Load existing locale directory
    load_gettext_translations('./locale', 'tornado')
    # Check if it works
    hello_message = get('zh_CN').translate('Hello')
    assert hello_message == '你好'
    hello_message = get('fr_FR').translate('Hello')
    assert hello_message == "Salut"
    # Load empty directory
    import tempfile
    empty_directory = tempfile.TemporaryDirectory()
    load_gettext_translations(empty_directory.name, 'tornado')
    # Check if it works
    hello_message = get('zh_CN').translate('Hello')
    assert hello_message == 'Hello'
    # Load a wrong directory
    wrong_directory = tempfile.TemporaryDirectory()

# Generated at 2022-06-22 03:44:06.480328
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale('en_US')
    assert _default_locale == 'en_US'
    assert _supported_locales == frozenset({'en_US'})



# Generated at 2022-06-22 03:44:14.409179
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    global _translations
    global _supported_locales
    global _use_gettext
    _translations = {}
    directory = os.path.join(os.path.dirname(__file__), "translations")
    domain = "messages"
    for lang in os.listdir(directory):
        if lang.startswith("."):
            continue  # skip .svn, etc
        if os.path.isfile(os.path.join(directory, lang)):
            continue

# Generated at 2022-06-22 03:44:16.658749
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")



# Generated at 2022-06-22 03:44:26.877075
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    csv = {'plural': {'You have %(num)d apples': 'You have two apples'}, 'singular': {'%(num)d apple': 'one apple'}, 'unknown': {'apple': 'apple'}}
    locale = CSVLocale("unknown", csv)
    assert locale.pgettext(None, "apple") == "apple"
    assert locale.pgettext(None, "%(num)d apple", "You have %(num)d apples", count=1) == "one apple"
    assert locale.pgettext(None, "%(num)d apple", "You have %(num)d apples", count=2) == "You have two apples"



# Generated at 2022-06-22 03:44:27.681111
# Unit test for function load_translations
def test_load_translations():
    pass



# Generated at 2022-06-22 03:44:39.854347
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    from pathlib import Path
    from collections import defaultdict

    # test empty translations
    test_translations = defaultdict(lambda: defaultdict(str))
    csvloc = CSVLocale('en', test_translations)
    assert csvloc.code == 'en'
    assert csvloc.translations == test_translations

    # test singular translations
    singular_translations = defaultdict(str)
    singular_translations['en'] = 'The Red Sea'
    singular_translations['fr'] = 'La Mer Rouge'
    singular_translations['es'] = 'El Mar Rojo'
    test_translations['singular'] = singular_translations
    csvloc = CSVLocale('en', test_translations)
    assert csvloc.code == 'en'
    assert csvloc.translations == test_

# Generated at 2022-06-22 03:44:40.558016
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    pass



# Generated at 2022-06-22 03:44:53.042529
# Unit test for method translate of class CSVLocale

# Generated at 2022-06-22 03:45:20.859831
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale("en").friendly_number(1) == "1"
    assert Locale("en").friendly_number(12) == "12"
    assert Locale("en").friendly_number(123) == "123"
    assert Locale("en").friendly_number(1234) == "1,234"
    assert Locale("en").friendly_number(12345) == "12,345"
    assert Locale("en").friendly_number(123456) == "123,456"
    assert Locale("en").friendly_number(1234567) == "1,234,567"
    assert Locale("en").friendly_number(12345678) == "12,345,678"
    assert Locale("en").friendly_number(123456789) == "123,456,789"
    assert Locale("en").friendly

# Generated at 2022-06-22 03:45:33.744417
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    test_csv_translations = {
        'unknown': {
            'A': 'a',
            'B': 'b',
            'C': 'c',
            'D': 'd',
            'E': 'e',
        },
        'singular': {
            'A': 'a',
            'B': 'b',
            'C': 'c',
            'D': 'd',
            'E': 'e',
        },
        'plural': {
            'A': 'a',
            'B': 'b',
            'C': 'c',
            'D': 'd',
            'E': 'e',
        },
    }
    csv_locale = CSVLocale('en_US', test_csv_translations)

# Generated at 2022-06-22 03:45:44.553764
# Unit test for function load_translations
def test_load_translations():
    from tornado import gen
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.web import Application, RequestHandler
    from tornado.testing import AsyncHTTPTestCase

    import os, sys
    root = os.path.realpath(os.path.join(os.path.dirname(__file__), ".."))
    tornado_locale_path = os.path.join(root, "tornado", "locale")
    sys.path.append(tornado_locale_path)
    global load_translations
    from tornado.locale import load_translations
    load_translations(os.path.join(tornado_locale_path, "translations"))


# Generated at 2022-06-22 03:45:49.378680
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    for code in ("en", "en_US", "zxx"):
        l = Locale.get(code = code)
        assert l.pgettext("Context", "Test") == "Test", "Unexpected result"
    l = Locale.get(code = "pt_BR")
    assert l.pgettext("Context", "Test") == "Test Context", "Unexpected result"

# Generated at 2022-06-22 03:45:51.379850
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert friendly_number(1000) == '1,000'
    assert friendly_number(1000000) == '1,000,000'

# Generated at 2022-06-22 03:45:53.175346
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    Locale.get("en_US").translate("Hello!")


# Generated at 2022-06-22 03:46:04.082473
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import copy
    import pickle
    import sys
    import unittest

    from tornado.util import ObjectDict
    import gen.locale

    # Setup a locale
    gen.locale.load_translations("locale")
    locale = gen.locale.Locale('en')

    # Test 1
    try:
        class TestException(Exception):
            pass
        try:
            import typing
        except ImportError:
            raise TestException("SKIP: no typing module")

        def test1():
            def f(x: typing.List, y: typing.List):
                return locale.pgettext('context', 'Hello')
            return f
        test1()
    except TestException as e:
        print(e)
    except Exception as e:
        print('FAIL: test 1')

    # Test 2

# Generated at 2022-06-22 03:46:12.411309
# Unit test for method list of class Locale
def test_Locale_list():
    def check(locale, parts, expected):
        assert locale.list(parts) == expected

    check(Locale("en"), ["a"], "a")
    check(Locale("en"), ["a", "b"], "a and b")
    check(Locale("en"), ["a", "b", "c"], "a, b and c")

    check(Locale("ar"), ["a"], "a")
    check(Locale("ar"), ["a", "b"], "a \u0648 b")
    check(Locale("ar"), ["a", "b", "c"], "a, b \u0648 c")



# Generated at 2022-06-22 03:46:16.149732
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    context = ""
    message = ""
    plural_message = ""
    count = 2
    code = "en_US"
    translations = {"unknown":{}, "plural":{}, "singular":{}}
    locale = CSVLocale(code, translations)
    locale.pgettext(context, message, plural_message, count)
    return



# Generated at 2022-06-22 03:46:24.733170
# Unit test for method translate of class Locale
def test_Locale_translate():
    file_path = os.path.join(os.path.dirname(__file__), "test_locale.csv")
    load_translations(file_path, ".csv")
    result1 = Locale.get("fa_IR").translate("Hello")
    assert result1 == "سلام"
    result2 = Locale.get("en_US").translate("Hello")
    assert result2 == "Hello"

# Generated at 2022-06-22 03:46:46.241918
# Unit test for function set_default_locale
def test_set_default_locale():
    assert _default_locale == "en_US"
    set_default_locale("en_UK")
    assert _default_locale == "en_UK"
    set_default_locale("en_US")
    assert _default_locale == "en_US"



# Generated at 2022-06-22 03:46:53.046199
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    s = GettextLocale(code='zh_CN', translations=zh_CN)
    assert s.translate('%(name)s created room %(room_link)s', '%(name)s 创建了房间 %(room_link)s') == '%(name)s 创建了房间 %(room_link)s'
    assert s.translate('%(name)s has joined %(room)s', count=1) == '%(name)s 加入了 %(room)s'
    assert s.translate('%(name)s has joined %(room)s', count=2) == '%(name)s 加入了 %(room)s'


# Generated at 2022-06-22 03:47:04.833755
# Unit test for function load_translations
def test_load_translations():
    directory = r"path/to/your/directory"
    encoding="utf-8"

    def load_translations(directory: str, encoding: Optional[str] = None) -> None:
        global _translations
        global _supported_locales
        _translations = {}
        for path in os.listdir(directory):
            if not path.endswith(".csv"):
                continue
            locale, extension = path.split(".")
            if not re.match("[a-z]+(_[A-Z]+)?$", locale):
                gen_log.error(
                    "Unrecognized locale %r (path: %s)",
                    locale,
                    os.path.join(directory, path),
                )
                continue
            full_path = os.path.join(directory, path)

# Generated at 2022-06-22 03:47:14.741273
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    # Cases for method 'translate'
    assert GettextLocale('en', None).translate('abc') == 'abc'
    assert GettextLocale('en', None).translate('abc', 'abcs', 'abcs') == 'abcs'
    assert GettextLocale('en', None).translate('abc', 'abcs', 1) == 'abc'
    assert GettextLocale('en', None).translate('abc', plural_message='abcs', count='abcs') == 'abcs'

    # Cases for method 'pgettext'
    assert GettextLocale('en', None).pgettext('law', 'right') == 'right'
    assert GettextLocale('en', None).pgettext('good', 'right') == 'right'

# Generated at 2022-06-22 03:47:24.849340
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    os.environ["LANG"] = "en_US.utf-8"
    load_translations("messages.csv")

    # Locale.get_closest()
    assert str(Locale.get_closest("en_US")) == "<Locale en_US>"
    assert str(Locale.get_closest("en-US")) == "<Locale en_US>"
    assert str(Locale.get_closest("en")) == "<Locale en_US>"

    assert str(Locale.get_closest("ru")) == "<Locale ru_RU>"
    assert str(Locale.get_closest("pt-BR")) == "<Locale pt_BR>"

# Generated at 2022-06-22 03:47:35.961403
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    global _translations
    # For a Locale object representing a language, it returns a string
    # containing the language's equivalent for the current date and time.
    # The input date is given in a particular format, in UTC format.
    # If the input date is later than the current date, the current date is
    # returned in full format. However, the method will throw an error if the
    # input date is earlier than the current date.
    # If the format is changed, the format of date should be changed too.
    # If the format is not in UTC, an error will occur.

    # test 1: test normal cases
    load_translations("locale", "en")
    print(Locale.get("en").format_date(1549125689))

# Generated at 2022-06-22 03:47:44.924521
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    langs = ["en", "zh_CN", "fa"]
    expected = {
        "en": "100,000",
        "zh_CN": "100000",
        "fa": "100000",
    }
    for lang, _ in LOCALE_NAMES.items():
        if lang not in langs:
            continue
        locale = Locale(lang)
        actual = locale.friendly_number(100000)
        if actual != expected[lang]:
            raise Exception(
                "Incorrect friendly_number for '%s' lang: %s" % (lang, actual)
            )



# Generated at 2022-06-22 03:47:56.413475
# Unit test for function load_translations
def test_load_translations():
    class InputError(Exception):
        pass
    dir='/Users/yuanbo/code/research/projects/dygraph/tornado'
    encoding=None
    _translations = {}
    for path in os.listdir(dir):
        if not path.endswith(".csv"):
            continue
        locale, extension = path.split(".")
        if not re.match("[a-z]+(_[A-Z]+)?$", locale):
            raise InputError("Unrecognized locale %r (path: %s)",
                locale,
                os.path.join(dir, path),
            )
        full_path = os.path.join(dir, path)

# Generated at 2022-06-22 03:48:04.373497
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l = Locale.get('en')
    assert l.friendly_number(1000) == "1,000"
    assert l.friendly_number(100) == "100"
    assert l.friendly_number(10) == "10"
    assert l.friendly_number(1000000) == "1,000,000"
    assert l.friendly_number(10**21) == "1" + "0"*21
    assert l.friendly_number(123456789) == "123,456,789"


# Generated at 2022-06-22 03:48:12.111853
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from temba.tests import TembaTest
    from temba.orgs.models import Org
    from temba.utils.format import get_dt_format

    def assert_date_format(self, date, format, expected_format):
        self.org.date_format = format
        self.org.save()

        date_format = get_dt_format(self.org, date)
        self.assertEqual(date_format, expected_format)

    def assert_date_format_strftime(self, date, format, expected_format):
        self.org.date_format = format
        self.org.save()

        date_format = get_dt_format(self.org, date, strftime=True)
        self.assertEqual(date_format, expected_format)


# Generated at 2022-06-22 03:48:51.960157
# Unit test for method list of class Locale
def test_Locale_list():
    #Arrange
    from core.tba_tornado import Locale
    _ = Locale.get("fa")
    #Act
    x = _.list(["a", "b", "c"])
    #Assert
    assert x == "a \u0648 b و c"

    x = _.list(["a", "b"])
    assert x == "a \u0648 b"

# Generated at 2022-06-22 03:48:56.196749
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    with pytest.raises(NotImplementedError):
        Locale("en").pgettext("context","message","plural_message",0)


# Generated at 2022-06-22 03:48:56.795199
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./i18n","tornado")

# Generated at 2022-06-22 03:48:58.441974
# Unit test for function get
def test_get():
    locale = get("es")
    assert locale.code == "es_ES"


# Generated at 2022-06-22 03:49:11.219952
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    """Unit test for method pgettext of class GettextLocale."""
    assert GettextLocale("en_US", gettext.translation("test", localedir=LOCALE_DIR))
    test_locale = GettextLocale("en_US", gettext.translation("test", localedir=LOCALE_DIR))
    assert test_locale.pgettext("law", "right") == "right"
    assert test_locale.pgettext("stick", "club", "clubs", len(["foo", "bar"])) == "clubs"
    assert test_locale.pgettext("law", "right", "rights", len(["foo", "bar"])) == "rights"

# Generated at 2022-06-22 03:49:20.337225
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert(Locale('en_US').friendly_number(123) == "123")
    assert(Locale('en_US').friendly_number(1234) == "1,234")
    assert(Locale('en_US').friendly_number(-1234) == "-1,234")
    assert(Locale('en_US').friendly_number(12345) == "12,345")
    assert(Locale('en_US').friendly_number(123456) == "123,456")
    assert(Locale('en_US').friendly_number(1234567) == "1,234,567")
    assert(Locale('en_US').friendly_number(12345678) == "12,345,678")
    assert(Locale('en_US').friendly_number(123456789) == "123,456,789")

# Generated at 2022-06-22 03:49:23.694767
# Unit test for function get
def test_get():
    assert get("zh_CN") != None
    pass


# Generated at 2022-06-22 03:49:28.903493
# Unit test for function load_translations
def test_load_translations():
    directory='/home/pengfeimao/Coding/python/tornado/django_tornado/tornado'
    load_translations(directory)
    assert _supported_locales == frozenset({'ja_JP', 'zh_CN'})
    assert _translations['zh_CN']['unknown']['Cancel'] == '取消'


# Generated at 2022-06-22 03:49:32.622531
# Unit test for constructor of class Locale
def test_Locale():
    assert isinstance(Locale.get('it'), Locale)



# Generated at 2022-06-22 03:49:43.145650
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    x = CSVLocale(code="en", translations={"unknown": {}})
    assert x.pgettext(context="abc", message="abc") == "abc"
    x = CSVLocale(code="en", translations={"unknown": {"abc": "def"}})
    assert x.pgettext(context="abc", message="abc") == "def"

