

# Generated at 2022-06-22 03:41:15.067463
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    '''
    Test for method translate of class GettextLocale
    '''
    import gettext
    trans = gettext.NullTranslations()
    locale = GettextLocale("en_US", trans)
    # two parameters example
    assert isinstance(locale.translate("test message"), str)
    return True


# Generated at 2022-06-22 03:41:17.451080
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert(Locale.get("en").friendly_number(123456789) == "123,456,789")

# Generated at 2022-06-22 03:41:27.102991
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    test_locale = GettextLocale("en", gettext.NullTranslations())
    assert test_locale.translate("example") == "example"
    assert test_locale.pgettext("context", "example") == "example"
    assert test_locale.translate(
        "example", plural_message="examples", count=2
    ) == "examples"
    assert test_locale.pgettext(
        "context", "example", plural_message="examples", count=2
    ) == "examples"

# Generated at 2022-06-22 03:41:38.048510
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    import random
    import base64
    for _ in range(500):
        message = base64.b64encode(str(random.random()).encode()).decode()
        singular_message = base64.b64encode(str(random.random()).encode()).decode()
        count = random.randint(1, 2000)
        context = base64.b64encode(str(random.random()).encode()).decode()
        translations = ["abc", "def", "ghi", "jkl"]
        if random.random() < 0.5:
            translation = translations[random.randint(0, len(translations) - 1)]
            correctly_translated = translation
        else:
            correctly_translated = message

# Generated at 2022-06-22 03:41:47.710945
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # -> assume the input variables exist
    # -> assume the input variables are valid
    # -> assume that the CSVLocale class has a method called translate
    # -> assume the translate method is not implemented
    CSVLocale.translate = lambda self, message, plural_message = None, count = None : message
    # -> assume the output of the method translate is invalid
    # -> assume that the messages are valid
    # -> assume the input variables are valid
    # -> assume the input variables are valid
    # -> test that the output of the method translate is the same as the input variable message
    assert CSVLocale.translate(message, plural_message, count) == message



# Generated at 2022-06-22 03:41:51.260616
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    CSVLocale.get("en").pgettext("", "hello", "goodbye")
    CSVLocale.get("en").pgettext("one", "hello", "goodbye")
    CSVLocale.get("en").pgettext("one", "hello", "goodbye", 1)



# Generated at 2022-06-22 03:41:58.832390
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
  try:
    GettextLocale(
        code="fr",
        translations=gettext.translation(
            "languagetool", localedir=".", fallback=True, languages=["fr"]
        ),
    )
  except Exception as _:
    pass
try:
  test_GettextLocale_translate()
except:
  pass


# Generated at 2022-06-22 03:41:59.289302
# Unit test for method translate of class Locale
def test_Locale_translate():
    pass

# Generated at 2022-06-22 03:42:01.262038
# Unit test for function get_supported_locales
def test_get_supported_locales():
    for locale in _supported_locales:
        assert isinstance(locale, str)
    return _supported_locales



# Generated at 2022-06-22 03:42:13.811324
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    # Create a mockup of GettextLocale
    locale = gettext.NullTranslations()
    locale.gettext = lambda msg_with_ctxt: 'test: %s' % (msg_with_ctxt)
    locale.ngettext = lambda msg_with_ctxt, *args: 'test: %s' % (msg_with_ctxt)

    # Call tested method
    gettext_locale = GettextLocale('en-US', locale)
    result = gettext_locale.pgettext("law", "right")
    assert result is not None, 'Expected pgettext to return a string'
    assert result == 'test: law%sright' % CONTEXT_SEPARATOR, 'Expected pgettext to return "test: law%sright"' % CONTEXT_SEPARATOR
    result = gettext

# Generated at 2022-06-22 03:42:43.776901
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    csvlocale = CSVLocale("",{})
    assert 'hello' == csvlocale.pgettext(None, 'hello')
    assert 'hello' == csvlocale.pgettext(None, 'hello', 'hi', 2)
    assert 'hello' == csvlocale.pgettext(None, 'hello', 'hi', 1)



# Generated at 2022-06-22 03:42:55.431677
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    ngettext = lambda a, b, c: a if c == 1 else b

    gettext_cls = GettextLocale("ru", type("fake_gettext", (), {"ngettext": ngettext}))
    assert gettext_cls.pgettext("law", "right") == "right"
    assert gettext_cls.pgettext("good", "right") == "right"
    assert gettext_cls.pgettext("organization", "club", "clubs", 1) == "club"
    assert gettext_cls.pgettext("stick", "club", "clubs", 1) == "club"
    assert gettext_cls.pgettext("organization", "club", "clubs", 2) == "clubs"

# Generated at 2022-06-22 03:42:58.311933
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert len(get_supported_locales()) > 0



# Generated at 2022-06-22 03:43:00.556719
# Unit test for function get
def test_get():
    """
    >>> get()
    <Locale en_US>
    """
test_get()

# Generated at 2022-06-22 03:43:13.602395
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    print(u"testing Locale.friendly_number()")
    locale = Locale.get("en_US")
    assert locale.friendly_number(100) == "100"
    assert locale.friendly_number(1000) == "1,000"
    assert locale.friendly_number(10000) == "10,000"
    assert locale.friendly_number(100000) == "100,000"
    assert locale.friendly_number(1000000) == "1,000,000"
    assert locale.friendly_number(10000000) == "10,000,000"
    assert locale.friendly_number(100000000) == "100,000,000"

    locale = Locale.get("fa_IR")
    assert locale.friendly_number(1000) == "۱۰۰۰"

# Generated at 2022-06-22 03:43:17.124359
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    locale = GettextLocale('en', gettext.NullTranslations())
    result = locale.pgettext("law", "right")
    assert result == 'right'



# Generated at 2022-06-22 03:43:26.176410
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    testLocale = CSVLocale('en', {'unknown': {'string': 'translation'}})
    testLocale.code = 'en'
    testLocale.name = 'en'
    testLocale.rtl = False
    testLocale.translations = {'unknown': {'string': 'translation'}}
    testLocale.format_date() # not tested
    testLocale.format_day() # not tested
    testLocale.list() # not tested
    testLocale.friendly_number() # not tested
    assert testLocale.translate('string') == 'translation'


# Generated at 2022-06-22 03:43:37.589343
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en_US")
    assert locale.friendly_number(1) == "1"
    assert locale.friendly_number(12) == "12"
    assert locale.friendly_number(123) == "123"
    assert locale.friendly_number(1234) == "1,234"
    assert locale.friendly_number(12345) == "12,345"
    assert locale.friendly_number(123456) == "123,456"
    assert locale.friendly_number(1234567) == "1,234,567"
    assert locale.friendly_number(12345678) == "12,345,678"
    assert locale.friendly_number(123456789) == "123,456,789"

# Generated at 2022-06-22 03:43:41.194398
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    locale = CSVLocale("zh_CN", {})
    locale.pgettext("plural", "yes", "no", 1)
    locale.pgettext("plural", "yes", "no", 2)



# Generated at 2022-06-22 03:43:52.141799
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get('mn')
    date = datetime.datetime(2009, 12, 29, 4, 31, 0) # equivalent to 2009-12-29 00:00:00 UTC
    gmt_offset = 0 # timezone offset
    dow = True # True for day of week, false for month and day

    # Tests that work correctly
    assert locale.format_day(date, gmt_offset, dow) == u"Их ням, 2009 оны 12-р сарын 29"

    # Tests that should fail
    try:
        locale.format_day(date, gmt_offset, True)
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-22 03:44:17.264479
# Unit test for function set_default_locale
def test_set_default_locale():
  global _default_locale
  set_default_locale("fr_CA")
  assert _default_locale == "fr_CA"



# Generated at 2022-06-22 03:44:30.081134
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # Test for plural message and count
    assert CSVLocale('en', {'singular': {'month': 'month'}, 'plural': {'month': 'months'}}).translate('month', 'months', 1) == 'month'
    assert CSVLocale('en', {'singular': {'month': 'month'}, 'plural': {'month': 'months'}}).translate('month', 'months', 2) == 'months'
    assert CSVLocale('en', {}).translate('month', 'months', 2) == 'months'
    assert CSVLocale('en', {}).translate('month', 'months', 1) == 'month'
    # Test for singular message
    assert CSVLocale('en', {'singular': {'month': 'month'}}).translate('month') == 'month'
    assert CSV

# Generated at 2022-06-22 03:44:31.215774
# Unit test for constructor of class Locale
def test_Locale():
    Locale.get("en_US")



# Generated at 2022-06-22 03:44:42.825886
# Unit test for method list of class Locale
def test_Locale_list():
    # load_translations(language_code="es")
    print("\n----\ntest_Locale_list: ")
    print("Spanish: ")
    es = Locale.get_closest("es")
    print(es.list(["A", "B", "C"]))
    print(es.list(["A", "B"]))
    print(es.list(["A"]))
    print(es.list([]))
    print("Persian: ")
    fa = Locale.get_closest("fa")
    print(fa.list(["A", "B", "C"]))
    print(fa.list(["A", "B"]))
    print(fa.list(["A"]))
    print(fa.list([]))



# Generated at 2022-06-22 03:44:45.869586
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    """
    Default test case
    """
    assert True

# Generated at 2022-06-22 03:44:56.520658
# Unit test for function load_translations
def test_load_translations():
    import os
    import time
    directory = os.path.join(os.path.dirname(__file__), "locale")
    load_translations(directory)
    print(get("en_US").translate("%(name)s liked this",name="aname"))
    print(get("en_US").translate("%(name)s liked this","plural",name="aname"))
    print(get("en_US").translate("%(name)s liked this","singular",name="aname"))
    print(get("zh_CN").translate("%(name)s liked this",name="aname"))
    print(get("zh_CN").translate("%(name)s liked this","plural",name="aname"))

# Generated at 2022-06-22 03:45:09.544469
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    assert CSVLocale("en", {}).code == "en"
    # Test translate
    assert CSVLocale("en", {}).translate("test_en") == "test_en"
    assert CSVLocale(
        "en", {"singular": {"test_en": "test_en_singular"}, "plural": {"test_en": "test_en_plural"}}
    ).translate("test_en") == "test_en_singular"
    assert CSVLocale(
        "en", {"singular": {"test_en": "test_en_singular"}, "plural": {"test_en": "test_en_plural"}}
    ).translate("test_en", "test_en_plural", 10) == "test_en_plural"

# Generated at 2022-06-22 03:45:20.460512
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test cases to check return of the method format_date of class Locale
    # Formatting the date (ie., Sunday, June 30, 2019 at 8:30 PM)
    assert Locale.get("en").format_date(datetime.datetime(2019, 6, 30, 20, 30)) == "Sunday, June 30, 2019 at 8:30 PM", "The date is formatted incorrectly"
    # Formatting the date (ie., Sunday, June 30 at 8:30 PM)
    assert Locale.get("en").format_date(datetime.datetime(2019, 6, 30, 20, 30), shorter=True) == "Sunday, June 30 at 8:30 PM", "The date is formatted incorrectly"
    # Formatting the date (ie., 6/30/19)

# Generated at 2022-06-22 03:45:23.892586
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale("fa").list(["a","b","c"]) == "a \u0648 b \u0648 c"

# Generated at 2022-06-22 03:45:35.611705
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    test_string1 = 'this is a test string'
    test_string2 = 'this is another test string'
    test_string3 = 'this is the third test string'
    test_string4 = 'this is the fourth test string'
    test_string5 = 'this is actually the 3rd string'
    test_string6 = 'this is not the third string'

    test_dict1 = {
        'unknown': {
            test_string1: test_string2
        }
    }

    test_dict2 = {
        'plural': {
            test_string1: test_string2,
            '1': test_string3,
            '0': test_string4
        }
    }


# Generated at 2022-06-22 03:46:28.343004
# Unit test for function get
def test_get():
    # If a locale is set, we get it directly.
    set_default_locale("es")
    assert get("es") == Locale("es")
    assert get("es_CO") == Locale("es", "CO")
    assert get("es_CO", "en") == Locale("es", "CO")
    assert get("es_CO", "es", "en") == Locale("es", "CO")
    assert get("es", "en_AU") == Locale("es")
    # If a locale is not set, we get the default one.
    assert get("xx") == Locale("en", "US")
    # We can change the default one.
    set_default_locale("zh_CN")
    assert get("xx") == Locale("zh", "CN")

# Generated at 2022-06-22 03:46:40.948528
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    # Check that friendly_number returns a comma separated number for value > 999
    l = Locale.get("en_US")
    assert l.friendly_number(1234) == "1,234"
    assert l.friendly_number(1000000) == "1,000,000"
    assert l.friendly_number(1000000000) == "1,000,000,000"
    assert l.friendly_number(-1234) == "-1,234"

    # Check that friendly_number returns an unmodified number for value <= 999
    assert l.friendly_number(0) == "0"
    assert l.friendly_number(10) == "10"
    assert l.friendly_number(100) == "100"
    assert l.friendly_number(999) == "999"

# Generated at 2022-06-22 03:46:50.155788
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en_US").list(["1", "2", "3"]) == "1, 2, and 3"
    assert Locale.get("en_US").list(["1", "2"]) == "1 and 2"
    assert Locale.get("en_US").list(["1"]) == "1"
    assert Locale.get("fa_IR").list(["1", "2", "3"]) == "1 \u0648 2 \u0648 3"
    assert Locale.get("fa_IR").list(["1", "2"]) == "1 \u0648 2"
    assert Locale.get("fa_IR").list(["1"]) == "1"

# Generated at 2022-06-22 03:46:51.922127
# Unit test for function get
def test_get():
    assert Locale.get_closest('en_GB') == Locale('en_US')


# Generated at 2022-06-22 03:47:03.218726
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    import unittest
    import io
    import gettext
    import tornado

    class Test(unittest.TestCase, GettextLocale):
        def __init__(self, *args, **kwargs):
            super().__init__("fr", gettext.translation("tests", io.StringIO(""), [], tornado.locale.GettextLocale.Fallback(""), tornado.locale.GettextLocale.UnknownTranslationError))

        def test_pgettext(self):
            self.assertEqual(self.pgettext("good", "right"), "right")
            self.assertEqual(self.pgettext("bad", "wrong"), "wrong")
            self.assertEqual(self.pgettext("law", "right"), "right")

# Generated at 2022-06-22 03:47:13.466782
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    _use_gettext = True
    _supported_locales = ["en", "en_US", "zh_CN"]
    _translations = {
        "en": {"singular": {"test": "English Translation of test"}}
    }

    code = "en"
    translations = _translations.get(code)
    if translations is None:
        locale = CSVLocale(code, {})  # type: Locale
    elif _use_gettext:
        locale = GettextLocale(code, translations)
    else:
        locale = CSVLocale(code, translations)
    assert isinstance(locale, GettextLocale)
    assert locale.translate("test") == "English Translation of test"

# Generated at 2022-06-22 03:47:21.872636
# Unit test for method translate of class Locale
def test_Locale_translate():
    # Test Cases
    test_cases = [
        ("test_message", "test_message"),
        ("test_plural", "test_singular", 1),
        ("test_plural", "test_plural", 2),
        ("test_plural", "test_unknown", 4),
    ]
    # Test Behavior
    for t in test_cases:
        case_name = t[0]
        case_message = t[0]
        case_singular_message = (
            t[1]
            if len(t) >= 3 and t[2] == 1
            else case_message
        )
        case_plural_message = (
            t[1]
            if len(t) >= 3 and t[2] > 1
            else case_message
        )

# Generated at 2022-06-22 03:47:33.269894
# Unit test for function set_default_locale
def test_set_default_locale():
    """Unit test for function set_default_locale"""
    if "UNITTEST_ON" not in os.environ:
        return
    global _default_locale
    global _supported_locales
    _default_locale = "en_US"
    _supported_locales = frozenset([_default_locale])
    old_locale = _default_locale
    set_default_locale("es_LA")
    assert _default_locale == "es_LA"
    assert _supported_locales == frozenset(["es_LA"])
    set_default_locale(old_locale)
test_set_default_locale()


# Generated at 2022-06-22 03:47:43.602521
# Unit test for method format_date of class Locale

# Generated at 2022-06-22 03:47:48.145452
# Unit test for method translate of class Locale
def test_Locale_translate():
    l = Locale.get("en_US")
    try:
        l.translate("Hello!")
    except NotImplementedError:
        print("Fail")
        return 0
    print("Success")



# Generated at 2022-06-22 03:49:01.556813
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import tornado
    import tornado._locale_data
    f = tornado._locale_data._get_translation_file
    dir = os.path.abspath(os.path.join(f, '..', '..', '..', 'locale'))
    load_gettext_translations(dir, 'tornado')

# Generated at 2022-06-22 03:49:12.475226
# Unit test for function load_translations
def test_load_translations():
    import tornado.testing
    import tornado.web
    import tornado.locale
    import tornado.platform.asyncio
    import asyncio
    asyncio.set_event_loop(asyncio.new_event_loop())
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    assert tornado.locale.load_translations("./test_files") == None
    assert tornado.locale.get() != None
    assert tornado.locale.get("en_US", "fr") != None
    assert tornado.locale.get("es_LA") != None
    assert tornado.locale.get("es_LA").code == "es_LA"
    
    



# Generated at 2022-06-22 03:49:14.406875
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert 'en_US' in _supported_locales # just check if we have default locale
    assert 'en' in _supported_locales # just check if we have default locale

# Generated at 2022-06-22 03:49:24.955800
# Unit test for function load_translations
def test_load_translations():
    directory = "./temp"
    path = "fr_FR.csv"
    encoding = "utf-8"

    full_path = os.path.join(directory, path)
    # python 3: csv.reader requires a file open in text mode.
    # Specify an encoding to avoid dependence on $LANG environment variable.
    with open(full_path, encoding=encoding) as f:
        _translations["fr_FR"] = {}
        for i, row in enumerate(csv.reader(f)):
            if not row or len(row) < 2:
                continue
            row = [escape.to_unicode(c).strip() for c in row]
            english, translation = row[:2]
            if len(row) > 2:
                plural = row[2] or "unknown"

# Generated at 2022-06-22 03:49:27.589678
# Unit test for function load_translations
def test_load_translations():
    test_dir = "./test/test_locale"
    load_translations(test_dir)
    print(_translations)
test_load_translations()


# Generated at 2022-06-22 03:49:37.525619
# Unit test for method translate of class Locale
def test_Locale_translate():
    for locale in ["en", "fr", "zh_CN"]:
        _translations[locale] = {}
        assert Locale(locale).translate("foo bar") == "foo bar"
        _translations[locale] = {
            "plural": {
                "foo bar": ("singular", "plural"),
                "foo bar %(name)s": ("singular with name %(name)s", "plural with name %(name)s"),
                "foo bar {name}": ("singular with name {name}", "plural with name {name}"),
            }
        }
        assert Locale(locale).translate("foo bar") == "singular"
        assert Locale(locale).translate("foo bar", count=0) == "plural"
        assert Locale(locale).trans

# Generated at 2022-06-22 03:49:45.032407
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    class DummyLocale(Locale):
        def __init__(self, code):
            self.code = code
            self.name = ''
            self.rtl = False
            self._months = [
                'January',
                'February',
                'March',
                'April',
                'May',
                'June',
                'July',
                'August',
                'September',
                'October',
                'November',
                'December'
            ]
            self._weekdays = [
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday',
                'Sunday'
            ]

        def translate(self,
                      message,
                      plural_message=None,
                      count=None):
            return message

    test_time = datetime.datetime

# Generated at 2022-06-22 03:49:47.774396
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    assert _default_locale == "en_US", "Default locale must be en_US"
    assert _supported_locales == frozenset(list(_translations.keys()) + ["en_US"]), "supported locales must be en_US"


# Generated at 2022-06-22 03:49:57.990793
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    code = "test_code"
    gettext_ = gettext.NullTranslations()
    locale = GettextLocale(code, gettext_)
    assert len(locale.code)>0
    assert len(locale.name)>0
    assert isinstance(locale.translate("hello"), str)
    assert isinstance(locale.pgettext("context", "hello"), str)
    assert isinstance(locale.format_date(time.time()), str)
    assert isinstance(locale.format_day(datetime.datetime.now()), str)
    assert isinstance(locale.list(["a","b"]), str)
    assert isinstance(locale.friendly_number(123), str)
    assert isinstance(locale.rtl, bool)

# Generated at 2022-06-22 03:50:04.086673
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    import pytest
    assert Locale("en").friendly_number(1000) == '1,000'
    assert Locale("en").friendly_number(1010) == '1,010'
    assert Locale("en").friendly_number(10000) == '10,000'
    assert Locale("en").friendly_number(123456789) == '123,456,789'
    assert Locale("en").friendly_number(12345678) == '12,345,678'
    assert Locale("es").friendly_number(1010) == '1010'

