

# Generated at 2022-06-22 03:41:23.816976
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    """
    Calling pgettext method on a GettextLocale object
    """
    n = GettextLocale('ch_CH', gettext.GNUTranslations(io.StringIO("")))
    context = "context"
    message = "message"
    plural_message = "plural message"
    # check for pgettext method with only message argument
    assert n.pgettext(context, message) == "message"
    # check for pgettext with message and plural message as inputs
    assert n.pgettext(context, message, plural_message) == "message"
    assert n.pgettext(context, message, plural_message, 2) == "plural message"

# Generated at 2022-06-22 03:41:25.165801
# Unit test for method translate of class Locale
def test_Locale_translate():
    assert 1 == 1

# Generated at 2022-06-22 03:41:26.205238
# Unit test for method translate of class Locale
def test_Locale_translate():
    pass


# Generated at 2022-06-22 03:41:37.174808
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    # Some string literals to be used in tests
    # They are not translated, because they have no translation in .mo files
    string_not_translated = "Not translated"
    string_translated = "Москва"
    string_plural_translated = "Столица"

    # pgettext() will test the translation in the 1st parameter
    # It is necessary to add one string to .mo files
    # Add to en_US/LC_MESSAGES/messages.mo and ru/LC_MESSAGES/messages.mo
    # msgid "Moscow"
    # msgstr "Москва"
    locale = Locale.get("en_US")
    # Set the context to get the translated string
    # The 1st parameter is the context,

# Generated at 2022-06-22 03:41:43.003276
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert(Locale.get("en").friendly_number(123456) == "123,456")
    assert(Locale.get("en_US").friendly_number(123456) == "123,456")
    assert(Locale.get("en").friendly_number(1234567) == "1,234,567")



# Generated at 2022-06-22 03:41:49.035542
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    # Testing empty string input
    Locale.autodetect = lambda : GettextLocale("ja")
    assert Locale.autodetect().translate("") == ""
    # Testing multiple strings as input
    assert Locale.autodetect().translate("a", "b", 2) == "b"
    # Testing single string input
    assert Locale.autodetect().translate("a") == "a"


# Generated at 2022-06-22 03:41:51.682162
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    result = Locale("en").friendly_number(1234567)
    assert result == "1,234,567"


# Generated at 2022-06-22 03:42:03.519222
# Unit test for function load_translations
def test_load_translations():
    import tempfile
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncHTTPTestCase, gen_test

    from tornado.web import Application
    from tornado.httputil import url_concat

    class TestTranslationHandler(tornado.web.RequestHandler):
        def get(self):
            locale = get(self.get_argument("locale"))
            self.write(locale.translate(
                "%(name)s liked this", "%(name)s liked these",
                self.get_argument("num_likes")
            ))

    class TranslationTest(AsyncHTTPTestCase):
        def get_app(self):
            return Application([("/", TestTranslationHandler)])


# Generated at 2022-06-22 03:42:10.687530
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    test_module = gettext.NullTranslations()
    test_locale = GettextLocale("en", test_module)
    assert test_locale.code == "en"
    assert test_locale.translate("test") == "test"
    assert test_locale.pgettext("", "test") == "test"
    assert test_locale.pgettext("test", "test") == "test"



# Generated at 2022-06-22 03:42:11.259259
# Unit test for function get
def test_get():
    pass


# Generated at 2022-06-22 03:42:30.676587
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    csvlocale = CSVLocale("", {})
    assert(csvlocale.pgettext("foo", "Foo", "Foos", 1) == "Foo")



# Generated at 2022-06-22 03:42:34.351273
# Unit test for method translate of class Locale
def test_Locale_translate():
    Locale.get("en")
    get_supported_locales()
    load_translations("")
    load_gettext_translations("", "")
    Locale("")
    

# Generated at 2022-06-22 03:42:42.647681
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    # trying to create GettextLocale with empty and invalid parameters
    assert isinstance(GettextLocale("code", "translations"), GettextLocale)
    assert isinstance(GettextLocale("", ""), GettextLocale)

    # trying to call translate, pgettext methods
    locale = GettextLocale("code", ("translations"))
    assert locale.translate("message") != None
    assert locale.pgettext("context", "message") != None



# Generated at 2022-06-22 03:42:46.237013
# Unit test for function get_supported_locales
def test_get_supported_locales():
    set_default_locale('en_US')
    l_set_support = frozenset({'en_US'})
    assert get_supported_locales() == l_set_support


# Generated at 2022-06-22 03:42:51.709214
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    data = {"unknown": {"test": "csvtest"}}
    test_locale = CSVLocale("test", translations=data)
    assert test_locale.translations == data
    assert test_locale.name == "Unknown"
    assert test_locale.rtl == False



# Generated at 2022-06-22 03:43:02.314909
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    msg = "right"
    context = "law"
    msg_with_context = "%s%s%s" % (context, CONTEXT_SEPARATOR, msg)
    result = GettextLocale.pgettext(GettextLocale, context, msg)
    assert result == msg_with_context
    context = "wrong"
    msg_with_context = "%s%s%s" % (context, CONTEXT_SEPARATOR, msg)
    result = GettextLocale.pgettext(GettextLocale, context, msg)
    assert result == msg_with_context



# Generated at 2022-06-22 03:43:06.037156
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    csv_locale = CSVLocale('en_US', {})
    assert csv_locale.pgettext('context', 'message', 'plural_message', 2) == 'plural_message'



# Generated at 2022-06-22 03:43:19.444839
# Unit test for method translate of class Locale
def test_Locale_translate():
    # We use an English locale
    locale = CSVLocale("en", {csv_en})
    assert locale.translate("hello") == "hello"
    assert locale.translate("welcome to you") == "welcome to you"
    # It doesn't work with plural message
    assert locale.translate("hello", plural_message="hello", count=1) == "hello"
    assert locale.translate("hello", plural_message="hello", count=2) == "hello"
    # We use a French locale
    locale = CSVLocale("fr", {csv_fr})
    assert locale.translate("hello") == "salut"
    assert locale.translate("welcome to you") == "bienvenue à vous"
    # Plural message

# Generated at 2022-06-22 03:43:29.629898
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    """Unit test for method pgettext of class CSVLocale"""
    import sys, os.path

    dirPath = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(dirPath, "../../.."))

    # load the Translations
    import yaml
    with open(os.path.join(dirPath, "test.yaml"), "r") as f:
        data = yaml.load(f)
    load_translations(data)

    # test GettextLocale
    hl = GettextLocale
    assert hl.pgettext(hl, 'context', 'message') == 'message'

    # test CSVLocale
    cl = CSVLocale

# Generated at 2022-06-22 03:43:36.498098
# Unit test for function load_translations
def test_load_translations():
    try:
        set_default_locale("en_US")
        assert set_default_locale("en_US") is None
        assert type(get("en_US")) is Locale
        directory = os.path.dirname(__file__)
        try:
            load_translations(directory)
        except:
            assert False
    except:
        assert False



# Generated at 2022-06-22 03:44:06.891535
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """Tests format_date method of class Locale"""
    load_gettext_translations(directory = r"C:\Users\user\Downloads\gettext-0.19.8.1\gettext-tools-0.19.8.1\intl",domain = "messages")

    date = datetime.datetime.now()
    assert type(date) == datetime.datetime
    gmt_offset = 0 # GMT offset
    relative = True
    shorter = False
    full_format = False

    locale = Locale.get_closest('en','en_US','pt','pt_BR','zh','zh_CN','he','fa','ar')
    assert type(locale) == CSVLocale or type(locale) == GettextLocale

# Generated at 2022-06-22 03:44:07.777816
# Unit test for function load_translations
def test_load_translations():
    load_translations("../translations",encoding="utf-8")



# Generated at 2022-06-22 03:44:15.048093
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """Unit test for method format_day of class Locale"""
    import random
    import datetime
    for i in range(10000):
        locale = Locale.get(random.choice(list(LOCALE_NAMES.keys())))
        date = datetime.datetime(year=random.choice(range(2000, 2019)),
                                 month=random.choice(range(1,13)),
                                 day=random.choice(range(1,29)),
                                 hour=random.choice(range(0,24)))
        dow = random.choice([True, False])
        result = locale.format_day(date=date, dow=dow)
        if dow:
            assert locale._weekdays[date.weekday()] in result
        assert locale._months[date.month - 1] in result
        assert str(date.day)

# Generated at 2022-06-22 03:44:16.758349
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("directory", "domain")



# Generated at 2022-06-22 03:44:29.585066
# Unit test for constructor of class Locale
def test_Locale():
    locale = Locale("zh_CN")
    assert locale.code == "zh_CN"
    assert locale.name == LOCALE_NAMES.get("zh_CN", {}).get("name", u"Unknown")
    assert locale.rtl == False
    assert locale._months[0] == u"一月"
    assert locale._weekdays[0] == u"星期一"
    assert locale.translate("My birthday is %(month_name)s %(day)s, %(year)s",
                            "%(month_name)s %(day)s, %(year)s", 1) == u"我的生日是一月1日, 1970"

# Generated at 2022-06-22 03:44:33.406059
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    csv_locale = CSVLocale('code',{'unknown':{'message':'message'}})
    assert csv_locale.code == 'code'
    assert csv_locale.translations == {'unknown': {'message':'message'}}


# Generated at 2022-06-22 03:44:34.003232
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    pass

# Generated at 2022-06-22 03:44:35.670298
# Unit test for constructor of class Locale
def test_Locale():
    Locale("en_US")


# Generated at 2022-06-22 03:44:48.323566
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    new_Locale = Locale("en")
    res = new_Locale.friendly_number(1000)
    assert res == "1,000"
    res = new_Locale.friendly_number(10000)
    assert res == "10,000"
    res = new_Locale.friendly_number(100000)
    assert res == "100,000"
    res = new_Locale.friendly_number(1000000)
    assert res == "1,000,000"
    new_Locale = Locale("es")
    res = new_Locale.friendly_number(1000)
    assert res == "1000"
    res = new_Locale.friendly_number(10000)
    assert res == "10000"
    res = new_Locale.friendly_number(100000)
    assert res == "100000"


# Generated at 2022-06-22 03:44:50.413711
# Unit test for constructor of class Locale
def test_Locale():
    locale = Locale("en")
    assert locale is not None


# Generated at 2022-06-22 03:45:15.665151
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    import gettext
    code = "en"
    domain = "zulip"
    translations = gettext.translation(domain, localedir=None, languages=[code])
    locale = GettextLocale(code, translations)



# Generated at 2022-06-22 03:45:22.267779
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    message = "Howdy"
    context = "context"

    def test_case(locale_translations: Dict[str, Dict[str, str]], 
                  expected_output: str) -> None:
        locale = CSVLocale("en", locale_translations)
        actual_output = locale.pgettext(context, message)
        return expected_output == actual_output

    case1 = test_case({}, message)
    case2 = test_case({"unknown": {}}, message)
    case3 = test_case({"unknown": {message: ""}}, "")
    case4 = test_case({"unknown": {message: None}}, message)
    case5 = test_case({"unknown": {"Hellow": ""}}, message)

# Generated at 2022-06-22 03:45:30.442655
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """
    Testing for format_date(date, gmt_offset, relative, shorter, full_format)
    """
    _supported_locales = frozenset(list(_translations.keys()) + [_default_locale])
    if "ar" in _supported_locales:
        locale = "ar"
    else:
        locale = "en"
    local = Locale.get(locale).format_date(datetime.datetime(2020, 2, 16, 20, 0))
    print(locale)
    print(local)
    return local


# Generated at 2022-06-22 03:45:32.866142
# Unit test for function get
def test_get():
    assert get("en","de") != get("de","en")


# Generated at 2022-06-22 03:45:35.703903
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    assert CSVLocale('en', {'unknown': {}, 'plural': {}, 'singular': {}}).translate('apple', None, None)=='apple'


# Generated at 2022-06-22 03:45:45.846616
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    g = GettextLocale("de", None)
    assert g.pgettext("law", "right") == "right"
    assert g.pgettext("law", "right", "wrongs", 2) == "wrongs"
    assert g.pgettext("good", "right") == "right"
    assert g.pgettext("good", "right", "wrongs", 2) == "wrongs"
    assert g.pgettext("organization", "club", "clubs", 1) == "club"
    assert g.pgettext("organization", "club", "clubs", 2) == "clubs"
    assert g.pgettext("stick", "club", "clubs", 1) == "club"
    assert g.pgettext("stick", "club", "clubs", 2) == "clubs"



# Generated at 2022-06-22 03:45:55.742544
# Unit test for function load_translations
def test_load_translations():
    # directory = '/home/cancui/change/t-translations/locale/'
    # with open(directory+'en_US.csv','r',encoding="utf-8") as f:
    #     reader = csv.reader(f)
    #     for row in reader:
    #         print(row)
    # load_translations(directory)
    test_load_gettext_translations()
    print(_translations['en_US']['unknown']['Sign out'])
    print(_translations['en_US']['unknown']['(no subject)'])
    print(_translations['en_US']['unknown']['There are %(num)s apples'])


# Generated at 2022-06-22 03:45:58.740673
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    assert _default_locale == "en_US", \
        "expected en_US, got %s"%_default_locale

# Generated at 2022-06-22 03:46:06.213387
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert(_translations == {})
    assert(_supported_locales == frozenset([_default_locale]))
    assert(_use_gettext == False)
    load_gettext_translations('/usr/share/locale', 'messages')
    assert(_translations != {})
    assert(_supported_locales != frozenset([_default_locale]))
    assert(_supported_locales == frozenset(list(_translations.keys()) + [_default_locale]))
    assert(_use_gettext == True)


# Generated at 2022-06-22 03:46:15.375708
# Unit test for constructor of class Locale
def test_Locale():
    assert Locale.get('en-US').code == 'en_US'
    assert Locale.get_closest('', '').code == _default_locale
    assert (Locale.get_closest('zh_CN', '').code in _supported_locales) == True
    assert (Locale.get_closest('', 'zh_CN').code in _supported_locales) == True
    assert (Locale.get_closest('', 'zh_CN.utf8').code in _supported_locales) == True
    assert (Locale.get_closest('', 'zh_CN_Silly').code in _supported_locales) == True
    assert (Locale.get_closest('', 'zh_Silly').code in _supported_locales) == False


# Generated at 2022-06-22 03:46:37.785928
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class TestGettextLocale(GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations) -> None:
            self.ngettext = lambda msgid1, msgid2, n: TestGettextLocale.test_gettext(
                msgid1, msgid2, n
            )
            self.gettext = lambda msgid: TestGettextLocale.test_gettext(msgid)
            super().__init__(code, translations)
        
        @staticmethod
        def test_gettext(msgid1: str, msgid2: str, n: int) -> str:
            if msgid1.find('can') != -1:
                return 'can'

# Generated at 2022-06-22 03:46:40.138165
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    csv_locale = CSVLocale("en_US", {})
    assert csv_locale.translations == {}


# Generated at 2022-06-22 03:46:50.125117
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    from . import load_translations
    load_translations(str(here / 'translations'))
    assert Locale.get('en_US').format_date(datetime(2018, 4, 13)) == 'yesterday'
    assert Locale.get('en_US').format_date(datetime(2018, 4, 14)) == 'today'
    assert Locale.get('en_US').format_date(datetime(2018, 4, 15)) == 'tomorrow'
    assert Locale.get('en_US').format_date(datetime(2018, 4, 15), full_format=True) == 'Saturday, April 14'
    assert Locale.get('en_US').format_date(datetime(2018, 4, 12)) == 'Thursday at 4:26 pm'



# Generated at 2022-06-22 03:46:56.180326
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    from translate.storage import po

    message = 'GettextLocale success'
    po_text = '''msgid "{}"
msgstr "GettextLocale成功"
'''.format(message)

    translations = po.pofile(po_text)
    locale = GettextLocale('default_locale', translations)
    assert isinstance(locale, GettextLocale)
    assert locale.translate(message) == 'GettextLocale成功'



# Generated at 2022-06-22 03:47:08.484596
# Unit test for method list of class Locale
def test_Locale_list():
    # exmple of usage
    L = Locale.get_closest
    L('ar_AR').list(['A', 'B', 'C']) == 'A، B و C'
    L('en_US').list(['A', 'B', 'C']) == 'A, B and C'
    L('fa_IR').list(['A', 'B', 'C']) == 'A، B و C'
    L('pt_BR').list(['A', 'B', 'C']) == 'A, B e C'
    L('ru_RU').list(['A', 'B', 'C']) == 'A, B и C'
    L('zh_CN').list(['A', 'B', 'C']) == 'A，B和C'



# Generated at 2022-06-22 03:47:17.721063
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import tornado.testing
    import tornado.web
    import zlib
    import io

    class LocalizedHandler(tornado.web.RequestHandler):
        def get(self):
            user_locale = self.get_argument("lang", None)
            if user_locale is None:
                user_locale = "ru_RU" 
            user_locale = tornado.locale.get(user_locale)
            translation = user_locale.translate("foo")
            self.write(translation)

    class GetTextLocaleDataTest(tornado.testing.AsyncHTTPTestCase):
        def get_app(self):
            return tornado.web.Application([("/", LocalizedHandler)])

        def test_gettext_locale_data(self):
            # test for setting gettext locale data
            po_

# Generated at 2022-06-22 03:47:23.078341
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale.get("en_US")
    assert locale.friendly_number(0) == "0"
    assert locale.friendly_number(1) == "1"
    assert locale.friendly_number(123) == "123"
    assert locale.friendly_number(1234) == "1,234"
    assert locale.friendly_number(12345) == "12,345"
    assert locale.friendly_number(123456) == "123,456"
    assert locale.friendly_number(1234567) == "1,234,567"
    assert locale.friendly_number(12345678) == "12,345,678"
    assert locale.friendly_number(123456789) == "123,456,789"

# Generated at 2022-06-22 03:47:35.355343
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    test_obj = CSVLocale('code', {'unknown': {'message': 'msg_translated', 'message_two': 'msg_translated_two'}})
    test_obj.translate('message')
    test_obj.translate('message_two')
    test_obj.pgettext('context_info', 'message')
    test_obj.pgettext('context_info', 'message_two')
    test_obj.pgettext('context_info', 'message', 'plural_message')
    test_obj.pgettext('context_info', 'message_two', 'plural_message')
    test_obj.pgettext('context_info', 'message', 'plural_message', 1)

# Generated at 2022-06-22 03:47:42.702069
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    test_code = 'test_code'
    test_translations = {
        'singular': {
            'test_message': 'test_singular',
        },
        'plural': {
            'test_message': 'test_plural',
        },
    }
    test_csv_locale = CSVLocale(test_code, test_translations)
    assert test_csv_locale.translations == test_translations
    assert test_csv_locale.code == test_code


# Generated at 2022-06-22 03:47:53.420529
# Unit test for function get
def test_get():
    
    # Case 1: If the code is an exact match
    # Case 2: If the code is a language only match
    # Case 3: If the code is a language only match
    l = get('en', 'de_DE')
    assert(l.code == 'en_US')
    
    l = get('en_US', 'de_DE')
    assert(l.code == 'en_US')
    
    l = get('en_GB', 'de_DE')
    assert(l.code == 'en_GB')

    # Case 4: If the code is not a language match, but is a country match
    # Case 5: If the code is not a language match, but is a country match
    l = get('en_GB', 'de_AT')
    assert(l.code == 'en_GB')

    l

# Generated at 2022-06-22 03:48:43.956736
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    code = "test_CSVLocale_pgettext"
    translations = {}
    locale = CSVLocale(code, translations)
    assert locale.pgettext("context","message") == "message"
    return True
test_CSVLocale_pgettext()


# Generated at 2022-06-22 03:48:51.634984
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    csv_locale = CSVLocale("code", {"singular": {"message": "value"}})
    assert csv_locale.translations == {"singular": {"message": "value"}}
    assert csv_locale.code == "code"
    assert csv_locale.name == "Unknown"
    assert not csv_locale.rtl
    assert csv_locale.translate("message") == "value"


# Generated at 2022-06-22 03:48:54.725015
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    with pytest.raises(NotImplementedError):
        GettextLocale(code="en", translations=None)

# Generated at 2022-06-22 03:49:02.995541
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("fr_CA")
    assert _default_locale == "fr_CA"
    assert _supported_locales == frozenset(["fr_CA"])
    set_default_locale("ar_EG")
    assert _default_locale == "ar_EG"
    assert _supported_locales == frozenset(["ar_EG"])
    # TODO(jschwarz): add a test that actually loads translations in between
    # calls to set_default_locale and checks that _supported_locales is updated
# End of function test_set_default_locale


# Generated at 2022-06-22 03:49:08.127046
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("en").list(["A", "B", "C"]) == "A, B, and C"
    assert Locale.get("fa").list(["A", "B", "C"]) == "A و B و C"


# Generated at 2022-06-22 03:49:10.757173
# Unit test for constructor of class Locale
def test_Locale():
    newLocale = Locale("en")
    assert newLocale.code == "en"



# Generated at 2022-06-22 03:49:19.928783
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    import tornado.locale
    import tornado.testing
    import tornado.web

    LOCALE_DICTIONARY = {
        "de_DE": {
            "unknown": {
                "": "",
                "test": "Test",
                "test_test": "Test Test",
                "test_%(value)s": "Test %(value)s",
                "%(value)s_test": "%(value)s Test",
                "%(value)s_test_%(value)s": "%(value)s Test %(value)s",
            }
        }
    }


# Generated at 2022-06-22 03:49:31.097310
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    import gettext
    from unittest import mock

    GettextLocale('en',gettext.NullTranslations())
    with mock.patch.object(gettext.NullTranslations, 'ngettext',
                           return_value='test_result'):
        assert GettextLocale('en',gettext.NullTranslations()).translate('test_message','test_plural_message', 2) == 'test_result'
    with mock.patch.object(gettext.NullTranslations, 'gettext',
                           return_value='test_result'):
        assert GettextLocale('en',gettext.NullTranslations()).pgettext('test_context', 'test_message', 'test_plural_message', 2) == 'test_result'



# Generated at 2022-06-22 03:49:32.379441
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert _supported_locales

# Generated at 2022-06-22 03:49:34.080184
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_UK")
    assert _default_locale == "en_UK"
