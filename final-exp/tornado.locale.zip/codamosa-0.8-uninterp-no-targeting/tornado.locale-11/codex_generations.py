

# Generated at 2022-06-22 03:40:45.299293
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from tornado.locale import load_gettext_translations
    from gettext import translation
    from mock import patch
    from unittest import TestCase

    class TestGettextLocale(TestCase):

        def setUp(self):
            translation_mock = translation(
                "tornado", "/my/path/to/locale", ["en_US", "ru_RU"], fallback=True
            )
            with patch(
                "tornado.locale.translation", return_value=translation_mock
            ) as patched:
                load_gettext_translations(
                    "/my/path/to/locale",
                    "tornado",
                    ["en", "ru"],
                    fallback=True,
                )

# Generated at 2022-06-22 03:40:50.525331
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    # Normal case
    try:
        load_gettext_translations('locale','tornado')
    except Exception:
        assert False, "Fail to load gettext translations"
    # Except case
    with pytest.raises(Exception):
        load_gettext_translations('no_such_directory','tornado')



# Generated at 2022-06-22 03:40:54.622220
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    translations = load_gettext_translations(".", "base")
    en_US = Locale.get("en_US")
    es_GT = Locale.get("es_GT")
    assert en_US.translate('No files') == 'No files'
    assert es_GT.translate('No files') == 'No hay archivos'


# Generated at 2022-06-22 03:40:57.035306
# Unit test for method list of class Locale
def test_Locale_list():
        #given
        locale=Locale.get('fa_IR')
        parts=[1,2,3]
        #when
        result=locale.list(parts)
        #then
        assert result == '1 و 2 و 3'



# Generated at 2022-06-22 03:41:04.226553
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Unit test for method pgettext of class Locale
    class Locale_pgettext(Locale):
        def __init__(self, code):
            super(Locale_pgettext, self).__init__(code)
        def translate(self, message, plural_message=None, count=None):
            return (f'{message} {plural_message} {count}').strip()
        def pgettext(self, context, message, plural_message=None, count=None):
            return (f'{context} {message} {plural_message} {count}').strip()


# Generated at 2022-06-22 03:41:07.027406
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():

    def my_func(x):
        # x is an instance of Locale
        return x.pgettext("context", "A")

    my_func(Locale.get('en'))
    my_func(Locale.get('zh_CN'))
    my_func(Locale.get('fa'))


# Generated at 2022-06-22 03:41:18.697228
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    mock_translations = MagicMock()
    mock_ngettext = MagicMock()

    mock_translations.ngettext = mock_ngettext
    mock_translations.gettext = MagicMock()
 
    locale = GettextLocale(
                "en",
                mock_translations
            )
    
    # Single
    locale.translate(
            message = "abc"
    )

    mock_translations.gettext.assert_called_with("abc")

    # Plural
    locale.translate(
            message = "abc",
            plural_message = "abcd",
            count = 2
    )

    mock_ngettext.assert_called_with(
        "abc",
        "abcd",
        2
    )


# Generated at 2022-06-22 03:41:32.245429
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    print("Testing method friendly_number of class Locale")
    fa_locale = Locale("fa")
    en_locale = Locale("en")

    print("Testing Persian friendly number")
    assert fa_locale.friendly_number(123) == '123'
    assert fa_locale.friendly_number(1234) == '1234'
    assert fa_locale.friendly_number(12345) == '12345'
    assert fa_locale.friendly_number(123456) == '123456'
    assert fa_locale.friendly_number(1234567) == '1234567'
    assert fa_locale.friendly_number(12345678) == '12345678'
    assert fa_locale.friendly_number(123456789) == '123456789'
    assert fa_locale

# Generated at 2022-06-22 03:41:44.636147
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():

    class DummyTranslations(gettext.NullTranslations):
        def gettext(self, msg):
            return msg

        def ngettext(self, msg, msg_plural, n):
            return msg_plural if n > 1 else msg

    assert GettextLocale("", DummyTranslations()).pgettext("law", "right") == "right"
    assert GettextLocale("", DummyTranslations()).pgettext("good", "right") == "right"
    assert GettextLocale("", DummyTranslations()).pgettext(
        "law", "right", "rights", 1
    ) == "right"
    assert GettextLocale("", DummyTranslations()).pgettext(
        "law", "right", "rights", 2
    ) == "rights"

# Generated at 2022-06-22 03:41:53.897219
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    lang_code = "en_US"
    lang_code = "fr_FR"
    lang_code = "de_DE"
    lang_code = "ar_AR"
    lang_code = "ne_NP"
    lang_code = "zh_CN"
    lang_code = "zh_TW"
    lang_code = "ja_JP"
    lang_code = "ko_KR"
    lang_code = "nl_NL"
    lang_code = "tr_TR"
    _default_locale = lang_code  # type: str

    _supported_locales = {lang_code}

    translations = {}

    _translations = {lang_code:  translations}

    _use_gettext = False

    locale = Locale.get(lang_code)
    # print(locale.trans

# Generated at 2022-06-22 03:42:35.057522
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "./"
    domain = "tornado.locale"
    load_gettext_translations(directory, domain)



# Generated at 2022-06-22 03:42:37.060410
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("test_set_default_locale")


# Generated at 2022-06-22 03:42:50.399081
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """
    Unit test for the method format_day of the class Locale.
    """
    tester = tornado.testing.AsyncHTTPTestCase()
    tester.assertEqual("Monday, January 22", Locale(
        "en_US").format_day(datetime.datetime(2018, 1, 22)))
    tester.assertEqual("22/1/2018", Locale("zh_CN").format_day(datetime.datetime(
        2018, 1, 22)))
    tester.assertEqual("Monday, January 22", Locale(
        "en_US").format_day(datetime.datetime(2018, 1, 22), dow=True))

# Generated at 2022-06-22 03:42:58.975569
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    try:
        _ = gettext.gettext
    except AttributeError:
        return
    translations = gettext.NullTranslations()
    def fake_gettext(msg):
        return msg
    def fake_ngettext(msg, plural_msg, n):
        return msg if n == 1 else plural_msg
    translations._catalog["right"] = "droit"
    translations._catalog["club"] = "club"
    translations._catalog["clubs"] = "clubs"
    translations.ngettext = fake_ngettext
    translations.gettext = fake_gettext
    locale = GettextLocale("fr", translations)
    assert locale.pgettext("law", "right") == "droit"
    assert locale.pgettext("good", "right") == "right"
    assert locale.pget

# Generated at 2022-06-22 03:43:02.699517
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    test_translations = {'unknown': {'Home': 'Homeee'}, 'singular': {}, 'plural': {}}
    CSVLocale('en_US', test_translations)



# Generated at 2022-06-22 03:43:05.425109
# Unit test for constructor of class Locale
def test_Locale():
    assert _default_locale is not None
    assert _translations is not None
    assert _supported_locales is not None



# Generated at 2022-06-22 03:43:17.232457
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale.get('fa')
    date = datetime.datetime(2010, 11, 19)
    dow = locale.format_day(date, 0, True)
    assert dow == '\u06cc\u06a9\u0634\u0646\u0628\u0647, \u062f\u06cc\u0633\u062a\u0645\u0628\u0631 19'
    noDow = locale.format_day(date, 0, False)
    assert noDow == '\u062f\u06cc\u0633\u062a\u0645\u0628\u0631 19'



# Generated at 2022-06-22 03:43:20.494730
# Unit test for method list of class Locale
def test_Locale_list():
    test_s = Locale('fa')
    assert (test_s.list(["a", "b", "c"]) == "a و b و c")


# Generated at 2022-06-22 03:43:30.441698
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    global _use_gettext
    _use_gettext = True
    i18n_path = "app/i18n"
    test_locale = "en"

# Generated at 2022-06-22 03:43:34.810218
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    result = GettextLocale('ja').translate('test_message')
    assert result == 'test_message' , "You can not translate this message"

# Generated at 2022-06-22 03:43:55.235681
# Unit test for method translate of class Locale
def test_Locale_translate():
    assert isinstance(Locale(1), Locale)


# Generated at 2022-06-22 03:44:05.452630
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    import inspect
    import locale
    import gettext

    class test_gettext_locale(GettextLocale):
        def __init__(self, code: str, translations: gettext.NullTranslations) -> None:
            # self.gettext must exist before __init__ is called, since it
            # calls into self.translate
            self.gettext = translations.gettext
            super().__init__(code, translations)

# Generated at 2022-06-22 03:44:13.666773
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    test_period = '. '
    test_p_message = "test_p_message"
    translated_test_p_message = "translated_test_p_message"
    # Change context to "messages" to test the conditional block in method pgettext
    test_context = "messages"
    i = 'i'
    unknown = "unknown"
    # Change the value of p_translations to an empty dict to test the else block in method pgettext
    p_translations = {
        (test_p_message, unknown): translated_test_p_message,
    }
    t = CSVLocale('en', p_translations)
    # Call method translate to test condition1 of method pgettext to be true
    translated_message = t.translate(test_p_message, None, None)
    # Call

# Generated at 2022-06-22 03:44:26.877948
# Unit test for function get
def test_get():
  assert get().code == "en_US"
  assert get("en_US").code == "en_US"
  assert get("en").code == "en_US"
  assert get("ja").code == "ja_JP"
  assert get("_JA").code == "ja_JP"
  assert get("JA").code == "ja_JP"
  assert get("xx").code == "en_US"
  assert get("xx_YY").code == "en_US"
  assert get("en_XX").code == "en_US"
  assert get("xx", "en_XX").code == "en_US"
  assert get("de", "en_XX").code == "de_DE"
  assert get("de_XX", "en_XX").code == "de_DE"
  assert get("de_DE").code

# Generated at 2022-06-22 03:44:29.348614
# Unit test for constructor of class Locale
def test_Locale():
    Locale(code='en_US')



# Generated at 2022-06-22 03:44:34.940822
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    print(Locale.get("de_DE").format_day(datetime.datetime(2015, 10, 14)))
    print(Locale.get("de_DE").format_day(datetime.datetime(2015, 10, 14), False))
    print(Locale.get("ar_SA").format_day(datetime.datetime(2015, 10, 14)))
    print(Locale.get("ar_SA").format_day(datetime.datetime(2015, 10, 14), False))


# Generated at 2022-06-22 03:44:35.591539
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    return NotImplemented

# Generated at 2022-06-22 03:44:36.970771
# Unit test for function get_supported_locales
def test_get_supported_locales(): 
    assert get_supported_locales() == _supported_locales



# Generated at 2022-06-22 03:44:40.407430
# Unit test for function get
def test_get():
    set_default_locale("en_US")
    result = get("en_US") # Returns True if it works
    assert True == result, "test_get failed"


# Generated at 2022-06-22 03:44:52.854306
# Unit test for method list of class Locale
def test_Locale_list():

    _translations = {
        "fa": {
            "unknown": {"مقدار واحد": "%(value)s", "مقداران": "%(value1)s و %(value2)s", "مقداران و یک مقدار دیگر": "%(value1)s و %(value2)s و %(value3)s", "مقدار دیگر": "%(value1)s و %(value2)s و %(value3)s و %(value4)s"},
        },
    }
    # Case when parts length is 1
    parts = ["one"]
    list_result = CSVLocale("fa", _translations).list(parts)

# Generated at 2022-06-22 03:45:17.789315
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    en_US_locale = GettextLocale("en_US", _translations["en"])
    assert en_US_locale.translate("1 second ago") == "1 second ago"
    assert en_US_locale.translate("1 second ago", plural_message = "%(seconds)d seconds ago", count = 2) == "2 seconds ago"
    assert en_US_locale.translate("1 minute ago") == "1 minute ago"
    assert en_US_locale.translate("1 minute ago", plural_message = "%(minutes)d minutes ago", count = 2) == "2 minutes ago"
    assert en_US_locale.translate("1 hour ago") == "1 hour ago"

# Generated at 2022-06-22 03:45:27.494440
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    CSVLocale_ = CSVLocale('en', {'plural': {'There are %s messages.': "There are %s messages on your disk."}, 'singular': {'There is 1 message.': "There is a message on your disk."}, 'unknown': {}})
    assert CSVLocale_.translate('There is 1 message.') == "There is a message on your disk."
    assert CSVLocale_.translate('There are %s messages.', count=2) == "There are 2 messages on your disk."
    assert CSVLocale_.translate('There are %s messages.', count=1) == "There is 1 message."



# Generated at 2022-06-22 03:45:40.397840
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    ws = {}
    import copy
    trans_orig = copy.deepcopy(_translations)
    _translations['zh_CN'] = {}
    _translations['zh_CN']['plural'] = {'Messages':'Messages (zh_CN)', 'Message':'Message (zh_CN)'}
    _translations['zh_CN']['singular'] = {'Messages':'Message (zh_CN)', 'Message':'Messages (zh_CN)'}
    _translations['zh_CN']['unknown'] = {'Messages':'Message (zh_CN)', 'Message':'Message (zh_CN)'}
    _supported_locales = frozenset(list(_translations.keys()) + [_default_locale])
    _use_gettext = False    
    
    # test

# Generated at 2022-06-22 03:45:42.445920
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    test_locale = CSVLocale('en', {})
    assert isinstance(test_locale, CSVLocale)



# Generated at 2022-06-22 03:45:46.717921
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    #The function is used to make sure the value get from the gettext is equal to
    #the original value
    code = 'en'
    pre_value = 'hi'
    trans = gettext.NullTranslations()
    gettext_locale = GettextLocale(code, trans)
    value = gettext_locale.translate(pre_value)
    assert value == pre_value


# Generated at 2022-06-22 03:45:57.381358
# Unit test for constructor of class Locale
def test_Locale():
    import tornado.options
    from tornado.options import define, options

    # First create a test option
    define("test_option", default=False, help="test option", type=bool)
    # Then parse command line arguments
    tornado.options.parse_command_line()
    # If test_option is being used, then we run the test
    if options.test_option:
        # Create a new locale object
        locale = Locale("en")
        # Since the constructor of class Locale is private to class,
        # we cannot directly call the constructor
        # So we use GettextLocale to call the constructor
        # But the class GettextLocale is also private to class
        class GettextLocale(Locale):
            def __init__(self, code: str) -> None:
                super().__init__(code)
        get

# Generated at 2022-06-22 03:45:59.167042
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert (Locale.get('en').friendly_number(1999999) == '1,999,999')


# Generated at 2022-06-22 03:46:02.756728
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    locale = CSVLocale("", {"hello": {"foo": "bar"}})
    assert locale.pgettext("foo", "hello") == "hello"
    assert locale.pgettext("foo", "hello", "hi") == "hello"



# Generated at 2022-06-22 03:46:04.214996
# Unit test for method translate of class Locale
def test_Locale_translate():
    assert 0 == 1, "TODO: Implement..."



# Generated at 2022-06-22 03:46:06.881419
# Unit test for function get_supported_locales
def test_get_supported_locales():
    '''
    :return:
    '''
    load_translations(".")
    print(get_supported_locales())


# Generated at 2022-06-22 03:46:34.331898
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    class Translations(gettext.NullTranslations):
        def pgettext(
            self, context: str, message: str) -> str:
            return "TEST"
    l = GettextLocale("en", Translations())
    assert l.pgettext("test", "test") == "TEST"
    assert l.pgettext("test", "test", "test", 1) == "test"



# Generated at 2022-06-22 03:46:45.023307
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    for language in "ar_SA","cz_CZ","da_DK","de_DE","de_CH","en_US","fa_IR","fa_IR_fa","fr_FR","hi_IN","my_MM","ja_JP","ko_KR","nl_NL","pl_PL","pt_BR","ru_RU","sr_SP","th_TH","tr_TR","vi_VT","zh_CN","zh_TW".split('_') :
        date = datetime.datetime.utcfromtimestamp(time.time())
        string = get_strftime(date,date,language)
        l = Locale.get(language)
        assert l.format_date(date) == string

# Generated at 2022-06-22 03:46:51.212863
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("/Volumes/GoogleDrive/My Drive/Graduate/2nd year/csse483/projects/Tornado-Projects-and-Examples/tutorial/example-project/locale", "tornado")
    test_locales = ["en_US", "zh_CN"]
    for lang in test_locales:
        test_locale = get(lang)
        assert lang in _translations
        assert test_locale.translate("cookie") == test_locale.translate("cookie")
    print("test_load_gettext_translations passed")



# Generated at 2022-06-22 03:46:52.345793
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")


# Generated at 2022-06-22 03:46:59.113906
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import datetime
    dt = datetime.datetime.now()
    dt_str = Locale("en_US").format_date(dt)
    dt_str_in_short = Locale("en_US").format_date(dt,shorter= True)
    print("Days of week, Month day, year time: %s" %(dt_str))
    print("Days of week, Month day: %s" %(dt_str_in_short))


# Generated at 2022-06-22 03:47:01.274924
# Unit test for function get
def test_get():
    import unittest
    class TestGet(unittest.TestCase):
        def test_get(self):
            print(get("de"))

    unittest.main()


# Generated at 2022-06-22 03:47:12.840341
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime

    tz = pytz.timezone('Asia/Shanghai')

    dt = datetime(2018, 1, 29, 12, 00, 00)
    dt_date = tz.localize(dt)
    dt_date_str = dt_date.strftime('%Y-%m-%d %H:%M:%S')

    gettext = pygettext.GettextBase()
    gettext.set_output_charset('utf-8')
    gettext.add_messages(load_po_file('./test/test.zh_CN.po'))

    #test format_day of ZH_CN
    assert gettext.get_lang() == "zh_CN"

# Generated at 2022-06-22 03:47:21.246418
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
  assert(Locale.get_closest("en").friendly_number(123456789) == "123,456,789")
  assert(Locale.get_closest("en").friendly_number(1) == "1")
  assert(Locale.get_closest("en").friendly_number(45678) == "45,678")
  assert(Locale.get_closest("en").friendly_number(4567) == "4,567")
  assert(Locale.get_closest("en").friendly_number(456) == "456")
  assert(Locale.get_closest("en").friendly_number(45) == "45")
  assert(Locale.get_closest("en").friendly_number(4) == "4")


# Generated at 2022-06-22 03:47:25.365521
# Unit test for function get_supported_locales
def test_get_supported_locales():
    load_translations(os.path.dirname(__file__))
    loc = get('es_LA')
    msg = loc.translate('Hello')
    assert msg == 'Hola'



# Generated at 2022-06-22 03:47:28.437142
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert get_supported_locales() == _supported_locales, \
        'Failed to return _supported_locales'



# Generated at 2022-06-22 03:48:07.753054
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    csv_file_contents = """
    "","",""
    "Generic","Hello %(name)s!","Hello %(name)s!"
    "Singular","1 thing","%(num)d thing"
    "Plural","%(num)d things","%(num)d things"
    "Context","yesterday","%(date)s"
    """
    with open("test_csv.csv", "w") as fh:
        fh.write(csv_file_contents)

    # No context
    load_translations("test_csv.csv", "test")
    l = get_closest_supported_locale("en_US")
    assert l.translate("Hello %(name)s!") == "Hello %(name)s!"

    # With context

# Generated at 2022-06-22 03:48:16.399005
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Setup code
    assert 'load_gettext_translations' in globals()
    load_gettext_translations("../locale/test_mocklocale_dat", "test_mocklocale")
    # Test code
    assert Locale.get("fa").translate("A dog") == "A dog"
    # Verify method pgettext of the class Locale
    assert Locale.get("fa").pgettext("A dog", "A dog") == "A dog"
    return

# Generated at 2022-06-22 03:48:22.036381
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale("en_US")
    assert locale.friendly_number(123) == "123"
    locale = Locale("en")
    assert locale.friendly_number(123) == "123"
    locale = Locale("fr")
    assert locale.friendly_number(123) == "123"



# Generated at 2022-06-22 03:48:23.428632
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("./locale", "app")



# Generated at 2022-06-22 03:48:35.851498
# Unit test for constructor of class Locale
def test_Locale():
    _ = Locale('en').translate
    assert _("January") == 'January'
    assert _("February") == 'February'
    assert _("March") == 'March'
    assert _("April") == 'April'
    assert _("May") == 'May'
    assert _("June") == 'June'
    assert _("July") == 'July'
    assert _("August") == 'August'
    assert _("September") == 'September'
    assert _("October") == 'October'
    assert _("November") == 'November'
    assert _("December") == 'December'
    assert _("Monday") == 'Monday'
    assert _("Tuesday") == 'Tuesday'
    assert _("Wednesday") == 'Wednesday'
    assert _("Thursday") == 'Thursday'
    assert _("Friday") == 'Friday'
   

# Generated at 2022-06-22 03:48:40.264867
# Unit test for function load_translations
def test_load_translations():
    directory = os.path.abspath(os.path.join(os.path.dirname(__file__), './locale'))
    load_translations(directory)
    print(LOCALE_NAMES)
    print(_translations)



# Generated at 2022-06-22 03:48:51.592655
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import random
    import string
    random_string = ''.join(random.choice(string.ascii_uppercase) for i in range(10))
    # Testing that the code raises an exception when the arguments are invalid
    try:
        __Locale__ = locale.Locale(random_string)
        __Locale__.pgettext(random_string, random_string, count = 100)
        raise Exception('AssertionError expected, but no exception occurred')
    except:
        pass

    # Asserting the returned value for invalid arguments is the same as the exception message
    # The returned value is expected to be a string, so we assert that the returned value is an instance of the string class
    return_value = __Locale__.pgettext(random_string, random_string, count = 100)

# Generated at 2022-06-22 03:49:03.424160
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    _use_gettext = False
    _supported_locales = ['en', 'ar']
    _default_locale = 'en'
    _translations = {'ar': {'unknown': {'welcome': 'ترحيب'}, 'plural': {'hours ago': '{} ساعة منذ',
                '1 hour ago': ' 1 ساعة منذ'}}}
    
    try:
        from tornado.options import options, define
        define("locale", default=None)
        print(Locale.get('ar').translate("welcome"))
    except:
        print("Not located in Tornado")
        print(Locale.get('ar').translate("welcome"))
    
    
    
print(test_GettextLocale_translate())

#

# Generated at 2022-06-22 03:49:16.259657
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    # Test translation with context
    gettext_locale = GettextLocale(code="en", translations=None)
    assert (
        gettext_locale.pgettext(context="law", message="right")
        == "right"
    )
    assert (gettext_locale.pgettext(context="stick", message="right") == "right")
    # Test plural translation with context
    assert (
        gettext_locale.pgettext(
            context="stick", message="club", plural_message="clubs", count=1
        )
        == "club"
    )
    assert (
        gettext_locale.pgettext(
            context="stick", message="club", plural_message="clubs", count=0
        )
        == "clubs"
    )
    # Test translation without context


# Generated at 2022-06-22 03:49:22.606760
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    class TestCSVLocale(CSVLocale):
        def __init__(self, code: str, translations: Dict[str, Dict[str, str]]) -> None:
            self.translations = translations
            super().__init__(code, translations)
    csv = TestCSVLocale("en_US", {"unknown": {"test": "test_res"}})
    assert csv.translate("test") == "test_res"