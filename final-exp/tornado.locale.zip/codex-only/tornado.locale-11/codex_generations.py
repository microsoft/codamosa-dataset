

# Generated at 2022-06-24 08:30:29.155571
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    """Test for constructor"""
    assert GettextLocale('en', gettext.NullTranslations())


# Generated at 2022-06-24 08:30:32.058449
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test for method format_date(self, date, gmt_offset, relative, shorter, full_format)
    # of class Locale
    pass

# Generated at 2022-06-24 08:30:40.599072
# Unit test for constructor of class Locale
def test_Locale():
    import nose
    import tornado
    import logging
    import tornado.locale
    # Get the logger
    logger = logging.getLogger(__name__)
    try:
        # Load a dummy translation file
        tornado.locale.load_translations("tests/i18n/locale_en.csv")
    except Exception:
        logger.warning("Failed to load translation file", exc_info=1)
    try:
        # Load a dummy locale
        locale = tornado.locale.get("en")
    except Exception:
        logger.warning("Failed to get locale", exc_info=1)
    # Test the method of list
    nose.tools.assert_equal(locale.list(["a", "b"]), "a, b")
    # Test the method of format_day
    import datetime
    date

# Generated at 2022-06-24 08:30:54.116923
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    code_ = "en"

# Generated at 2022-06-24 08:30:57.435283
# Unit test for method translate of class Locale
def test_Locale_translate():
    with pytest.raises(NotImplementedError):
        locale = Locale.get(code='')
        locale.translate(message='')

# Generated at 2022-06-24 08:31:00.404012
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales == frozenset(["en_US"])

test_get_supported_locales()

# copied from gettext, to work around the fact that it can't be imported
# until translations are loaded

# Generated at 2022-06-24 08:31:09.465554
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    en = Locale("en")
    assert en.friendly_number(1) == "1"
    assert en.friendly_number(12) == "12"
    assert en.friendly_number(123) == "123"
    assert en.friendly_number(1234) == "1,234"
    assert en.friendly_number(12345) == "12,345"
    assert en.friendly_number(123456) == "123,456"
    assert en.friendly_number(1234567) == "1,234,567"
    assert en.friendly_number(12345678) == "12,345,678"
    assert en.friendly_number(123456789) == "123,456,789"
    assert en.friendly_number(1234567890) == "1,234,567,890"


# Generated at 2022-06-24 08:31:11.890324
# Unit test for function get
def test_get():
    from tornado.locale import get
    assert get("zh_CN") == Locale("zh_CN")
test_get()



# Generated at 2022-06-24 08:31:23.184708
# Unit test for method translate of class Locale
def test_Locale_translate():
    _supported_locales = ['en', 'nl']
    _use_gettext = True
    _translations = {
        'en': {'plural': {'An error occurred.': 'An error occured.'},
            'singular': {'An error occurred.': 'An error occured.'}
        },
        'nl': {'plural': {'An error occurred.': 'Er is een fout opgetreden.'},
            'singular': {'An error occurred.': 'Er is een fout opgetreden.'}
        }
    }
    locale = 'en'
    message = 'An error occurred.'
    plural_message = ''
    count = 0
    expected = 'An error occured.'
    result = Locale(locale).translate(message,plural_message,count)


# Generated at 2022-06-24 08:31:28.151524
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    assert CSVLocale("en", {}).translate("Hello", "Goodbye") == "Hello"
    assert CSVLocale("en", {}).translate("Hello", "Goodbye", 1) == "Hello"
    assert CSVLocale("en", {"plural": {"Goodbye": "Bye"}}).translate("Hello", "Goodbye", 2) == "Bye"
    assert CSVLocale("en", {"unknown": {"Hello": "Hi"}}).translate("Hello", "Goodbye") == "Hi"



# Generated at 2022-06-24 08:31:32.713700
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en_US").friendly_number(0) == "0"
    assert Locale.get("en_US").friendly_number(12) == "12"
    assert Locale.get("en_US").friendly_number(123) == "123"
    assert Locale.get("en_US").friendly_number(1234) == "1,234"
    assert Locale.get("en_US").friendly_number(1234567890) == "1,234,567,890"



# Generated at 2022-06-24 08:31:34.395027
# Unit test for function load_translations
def test_load_translations():
  from tornado import locale
  load_translations('./translations')
  print(locale._translations)

# Generated at 2022-06-24 08:31:39.174470
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    class Locale(object):
        def pgettext(  # type: ignore
            self,
            context: str,
            message: str,
            plural_message: Optional[str] = None,  # type: ignore
            count: Optional[int] = None,  # type: ignore
        ) -> str:
            return ""

    # create an instance of Locale
    locale = Locale()
    assert isinstance(locale, Locale)

    # this should not raise an error
    locale.pgettext(context="", message="")



# Generated at 2022-06-24 08:31:41.850350
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    from unittest.mock import MagicMock
    gen_log = MagicMock()
    l = CSVLocale("en", {})

    l.pgettext("test", "message")


# Generated at 2022-06-24 08:31:50.053423
# Unit test for method translate of class Locale
def test_Locale_translate():
    print("Testing Locale.translate ...")
    load_translations("test/test_translations")
    l = Locale("en")
    print("Should return 'Hello' ...")
    print("Returned '{0}'".format(l.translate("Hello",count=0)))
    print("Should return 'Hello World' ...")
    print("Returned '{0}'".format(l.translate("Hello World",count=0)))
    print("Should return 'Hello World...' ...")
    print("Returned '{0}'".format(l.translate("Hello World...",count=0)))
    print("Should return 'Hello Worlds' ...")
    print("Returned '{0}'".format(l.translate("Hello World",count=2)))
    print("Should return 'Hello Worlds' ...")


# Generated at 2022-06-24 08:31:52.835997
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    """Unit test for method pgettext of class CSVLocale."""
    message = 'Hello world'
    context = 'context'
    plural_message = 'Hello worlds'
    count = 1
    code = 'en'
    csvlocale1 = CSVLocale(code,{})
    csvlocale1.pgettext(context=context, message=message, plural_message=plural_message, count=count)



# Generated at 2022-06-24 08:31:54.623608
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
        GettextLocale.translate("not a plural message")



# Generated at 2022-06-24 08:32:05.551273
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import timedelta, datetime
    import pytz

    test_tz = pytz.timezone('America/New_York')
    # test_tz_str = 'US/Eastern'
    test_time = datetime.now(test_tz)
    test_hour = test_time.time().hour
    test_date = datetime(2016, 12, 19, test_hour, 20, 30, tzinfo=test_tz)
    test_date_and_time = datetime(2016, 12, 19, test_hour, 20, 30, tzinfo=test_tz)
    test_date_2 = test_date + timedelta(days=3)
    test_date_and_time_2 = test_date + timedelta(days=4)


# Generated at 2022-06-24 08:32:08.819776
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    _translations = {"en": {"unknown": {"foo": "bar"}}}
    GettextLocale("en", gettext.translation("foolib", localedir="/directory", languages=["en"]))
    # Should be no failed assertions



# Generated at 2022-06-24 08:32:12.454586
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory="./locale/"
    domain="messages"
    my_translations = load_gettext_translations(directory, domain)
    assert "en_US" in my_translations.keys()
    assert "pt_BR" in my_translations.keys()


# Generated at 2022-06-24 08:32:15.484535
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale('en_US')


# Generated at 2022-06-24 08:32:25.072368
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    code = 'en'
    translations = {
        'unknown': {
            'key1_msg': 'value1_msg',
            'key2_msg': 'value2_msg'
        },
        'singular': {
            'key3_msg': 'value3_msg',
            'key4_msg': 'value4_msg'
        },
        'plural': {
            'key5_msg': 'value5_msg',
            'key6_msg': 'value6_msg'
        }
    }
    loc = CSVLocale(code, translations)
    assert loc.code == code
    assert loc.translations == translations

# Generated at 2022-06-24 08:32:29.736395
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    # Test this code path
    code = "en"
    translations = None
    gt_locale = GettextLocale(code, translations)
    assert gt_locale.ngettext == None
    assert gt_locale.gettext != None

    # Test this code path
    code = "en"
    translations = gettext.NullTranslations()
    gt_locale = GettextLocale(code, translations)
    assert gt_locale.ngettext != None
    assert gt_locale.gettext != None



# Generated at 2022-06-24 08:32:36.536450
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    from ugettext_lazy import ugettext_lazy as _

    # Loads of GetTextLocale from message from code: 'test'
    assert GettextLocale('test', {'test': _('test')}).pgettext('test', 'test') == 'test'
    assert GettextLocale('test', {'test': _('test')}).pgettext('test', 'test') == 'test'

    assert GettextLocale('test', {'test': _('test')}).pgettext('test', 'test') == 'test'
    assert GettextLocale('test', {'test': _('test')}).pgettext('test', 'test') == 'test'


# Generated at 2022-06-24 08:32:47.501065
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    pl_translations = {
        '': {
            'year': 'rok',
            'years': 'lata',
            'month': 'miesiąc',
            'months': 'miesiące',
            'week': 'tydzień',
            'weeks': 'tygodnie',
            'day': 'dzień',
            'days': 'dni',
            'hour': 'godzina',
            'hours': 'godziny',
            'minute': 'minuta',
            'minutes': 'minuty',
            'second': 'sekunda',
            'seconds': 'sekundy',
        }
    }
    

# Generated at 2022-06-24 08:32:57.131355
# Unit test for method translate of class Locale
def test_Locale_translate():
    import os
    import warnings
    import mock
    import inspect
    import pytest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.httputil import url_concat
    from tornado.httpclient import HTTPRequest, HTTPError, AsyncHTTPClient
    from tornado.httpclient import HTTPResponse
    from tornado.httputil import HTTPHeaders
    from tornado.escape import json_decode
    from tornado.escape import json_encode
    from tornado.web import Application, RequestHandler, HTTPError
    from tornado.testing import AsyncHTTPTestCase
    from tornado.testing import bind_unused_port
    from tornado.websocket import WebSocketHandler
    import tornado.ioloop
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    asyncio.set_event_loop_policy

# Generated at 2022-06-24 08:33:04.122652
# Unit test for method list of class Locale

# Generated at 2022-06-24 08:33:05.925583
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales == get_supported_locales()
test_get_supported_locales()



# Generated at 2022-06-24 08:33:08.379448
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    translations = GettextLocale("en", gettext.NullTranslations())
    print("test_GettextLocale_translate():", translations.translate("test"))



# Generated at 2022-06-24 08:33:09.401508
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    assert GettextLocale('en', 'en') is not None

# Generated at 2022-06-24 08:33:13.878218
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    assert CSVLocale("", {}).code == ""
    assert len(CSVLocale("", {})._months) == 12
    assert len(CSVLocale("", {})._weekdays) == 7
    assert not CSVLocale("", {}).rtl
    assert CSVLocale("ar", {}).rtl


# Generated at 2022-06-24 08:33:19.258512
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    test_locale = CSVLocale('en', {"plural": {"apple": "apples"}, "singular": {}})
    assert test_locale.pgettext("", "apple", "apples", 1) == "apple"
    assert test_locale.pgettext("", "apple", "apples", 2) == "apples"



# Generated at 2022-06-24 08:33:23.874691
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import tornado.testing
    import unittest
    import os
    import shutil
    import tempfile
    import subprocess
    import time
    import sys

    class LocaleTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(LocaleTest, self).setUp()
            self.locale_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.locale_dir)
            super(LocaleTest, self).tearDown()

        def run_makemessages(self, lang):
            """runs 'django-admin makemessages' in a subprocess"""
            makemessages = os.path.join(
                os.path.dirname(sys.executable), "django-admin.py")

# Generated at 2022-06-24 08:33:33.785569
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale("it").list(["one", "two", "three", "four"]) == u'one, two e three'
    assert Locale("it").list(["one", "two", "three"]) == u'two e three'
    assert Locale("it").list(["one", "two", "three", "four", "five"]) == u'one, two, three e five'
    assert Locale("it").list(["one", "two", "three", "four", "five", "six"]) == u'one, two, three, four e six'
    assert Locale("it").list(["one", "two", "three", "four", "five", "six", "seven"]) == u'one, two, three, four, five e seven'

# Generated at 2022-06-24 08:33:40.336302
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    class DummyTranslations:
        def __init__(self):
            self.en = None

        def ngettext(self, message: str, plural_message: Optional[str] = None, count: Optional[int] = None) -> str:
            assert message == 'message'
            assert plural_message == 'plural_message'
            assert count == 5
            return 'plural_message'

        def gettext(self, message: str) -> str:
            assert message == 'message'
            return 'plural_message'

    translations = DummyTranslations()
    locale = GettextLocale('en', translations)
    assert locale.translate('message', 'plural_message', 5) == 'plural_message'

# Generated at 2022-06-24 08:33:42.113844
# Unit test for function get
def test_get():
    loc = get("en_US","en")


# Generated at 2022-06-24 08:33:44.016536
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    locale = Locale.get("en")
    locale.pgettext("foo", "bar")


# Generated at 2022-06-24 08:33:49.978778
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    code = "en"
    sing_dict = {"hello": "hi", "world": "earth"}
    plural_dict = {}
    translations = {"unknown": sing_dict, "plural": plural_dict}
    csv_locale = CSVLocale(code, translations)
    assert csv_locale.translations == translations
    assert csv_locale.code == code


# Generated at 2022-06-24 08:33:53.718389
# Unit test for function set_default_locale
def test_set_default_locale():
    get_obj = get('es_LA')
    get_obj.locale = "en_US"
    set_default_locale('en_US')
    assert _default_locale == 'en_US'


# Generated at 2022-06-24 08:34:00.420422
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    csv_locale = CSVLocale("code", translations={"a": {"b": "c"}})
    assert csv_locale.code == 'code'
    csv_locale.translate("a")
    csv_locale.translate("b")
    csv_locale.translate("c", "c")



# Generated at 2022-06-24 08:34:02.194200
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    assert not hasattr(Locale, 'pgettext')
    try:
        Locale.pgettext
    except:
        pass
    else:
        raise Exception('Expected NameError')

# Generated at 2022-06-24 08:34:08.041170
# Unit test for method list of class Locale
def test_Locale_list():
    load_translations(LOCALE_DIR)
    expected_result = "فصحيح، سليم و رباعي"
    result = Locale.get("ar_SY").list(["فصحيح", "سليم", "رباعي"])
    assert result == expected_result


# Generated at 2022-06-24 08:34:10.689487
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales == _translations.keys()



# Generated at 2022-06-24 08:34:11.945176
# Unit test for function get
def test_get():
    test_get_two()


# Generated at 2022-06-24 08:34:21.738952
# Unit test for function get
def test_get():
    if get('de_DE') == 'de_DE':
        print('de_DE')
    if get('de_DE', 'en_US') == 'de_DE':
        print('de_DE,en_US')
    if get('de', 'en_US') == 'en_US':
        print('de,en_US')
    if get('de_DE', 'en') == 'de_DE':
        print('de_DE,en')
    if get('de_DE', 'en', 'ar') == 'de_DE':
        print('de_DE,en,ar')
    if get('de', 'en_US', 'ar_SY') == 'en_US':
        print('de,en_US,ar_SY')

# Generated at 2022-06-24 08:34:24.305398
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    g = GettextLocale(code='en_US', translations='')
    assert (g.translate('test') == 'test')



# Generated at 2022-06-24 08:34:28.050210
# Unit test for function get_supported_locales
def test_get_supported_locales():
    answer = _supported_locales
    assert get_supported_locales() == answer
    assert get_supported_locales() != None

# Generated at 2022-06-24 08:34:34.020491
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    csv_locale = CSVLocale("qq",{"unknown":{"a":"b"}})
    assert csv_locale.code == "qq"
    assert csv_locale.name == u"Unknown"
    assert csv_locale.rtl == False
    assert csv_locale.translations  == {"unknown":{"a":"b"}}
    assert csv_locale.translate("a") == "b"

# Generated at 2022-06-24 08:34:40.757706
# Unit test for function get_supported_locales
def test_get_supported_locales():
    set_default_locale("en_US")
    assert get_supported_locales() == {"en_US"}

    assert _translations == {}
    load_translations(os.path.join(os.path.dirname(__file__), "data"))
    assert get_supported_locales() == {"en_US", "es_LA"}


# Generated at 2022-06-24 08:34:52.408917
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    #  Create a new Locale of type CSVLocale
    _translations = dict()
    _translations["pl"] = dict()
    _translations["pl"]["singular"] = dict()
    _translations["pl"]["singular"]["1 second ago"] = "1 sekundę temu"
    _translations["pl"]["singular"]["1 minute ago"] = "1 minutę temu"
    _translations["pl"]["singular"]["1 hour ago"] = "1 godzinę temu"
    _translations["pl"]["singular"]["%(time)s"] = "%(time)s"
    _translations["pl"]["singular"]["yesterday"] = "wczoraj"

# Generated at 2022-06-24 08:34:55.089876
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    gettext_translations = gettext.NullTranslations()
    gettext_locale = GettextLocale("fa", gettext_translations)

    assert gettext_locale

# Generated at 2022-06-24 08:34:56.411995
# Unit test for function load_translations
def test_load_translations():
    translations = {}
    print(load_translations)



# Generated at 2022-06-24 08:35:04.100694
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    # Testing for dictionary translations
    load_translations(os.path.join(os.path.dirname(__file__), "csv_translations"))
    nl = Locale.get("nl")
    assert nl.pgettext("testcontext", "test", "plural") == "test"
    assert nl.pgettext("testcontext", "test", "plural", 2) == "plural"

    # Testing for gettext translations
    load_gettext_translations(
        os.path.join(os.path.dirname(__file__), "gettext_translations"),
        "test",
    )
    nl = Locale.get("nl")
    assert nl.pgettext("testcontext", "test", "plural") == "test"

# Generated at 2022-06-24 08:35:12.196354
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    test_translations = {'unknown': {'test_message1': 'test_translation1', 'test_message2': 'test_translation2'},
                         'singular': {'test_message1': 'test_translation1', 'test_message2': 'test_translation2'},
                         'plural': {'test_message1': 'test_translation1', 'test_message2': 'test_translation2'}}
    translator = CSVLocale('test_language', test_translations)
    assert translator.code == 'test_language'
    assert translator.name == 'Unknown'
    assert translator.rtl == False
    assert translator._months == ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September',
                                  'October', 'November', 'December']
    assert translator._

# Generated at 2022-06-24 08:35:13.814643
# Unit test for function get_supported_locales
def test_get_supported_locales():
    return (len(get_supported_locales()) > 0)


# Generated at 2022-06-24 08:35:25.682260
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    """Unit test for method format_date of class Locale."""
    import time
    import pytz



# Generated at 2022-06-24 08:35:26.892907
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert isinstance(get_supported_locales(), frozenset)



# Generated at 2022-06-24 08:35:33.490212
# Unit test for function load_translations
def test_load_translations():
    """Test for function load_translations"""
    load_translations("test/test_locale/")
    for key in _translations.keys():
        assert isinstance(_translations[key], dict)
        for subkey in _translations[key].keys():
            assert _translations[key][subkey]
            for i in range(len(_translations[key][subkey])):
                # i is the key in the dictionary
                #i+1 is the value in the dictionary
                assert i < i+1

# Generated at 2022-06-24 08:35:45.458606
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    """
    Tests a couple of simple translations of GettextLocale
    """
    locale = GettextLocale("de", _translations.get("de")) # type: GettextLocale
    assert locale.translate("a") == "ein"
    assert locale.translate("1") == "1"
    assert locale.translate("one fish two fish red fish blue fish") == "ein Fisch zwei Fische rot Fisch blau Fisch"
    assert locale.translate("one fish two fish red fish blue fish", "fish fish fish fish") == "ein Fisch zwei Fische rot Fisch blau Fisch"
    assert locale.translate("1", plural_message="%(num)s fishes", count=2) == "2 Fische"

# Generated at 2022-06-24 08:35:50.515029
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    path = "./locale"
    domain = "tornado"
    load_gettext_translations(path, domain)
    set_default_locale("en_US")
    lang = get("en_US")
    print(lang.translate("Help"))
    errors = []
    lang = get("zh_CN")
    print(lang.translate("Help"))


# Generated at 2022-06-24 08:36:02.796191
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en_US").friendly_number(1000) == "1,000"
    assert Locale.get("en_US").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en_US").friendly_number(1000000000) == "1,000,000,000"
    assert Locale.get("en_US").friendly_number(123456789) == "123,456,789"

    assert Locale.get("en").friendly_number(1000) == "1,000"
    assert Locale.get("en").friendly_number(1000000) == "1,000,000"
    assert Locale.get("en").friendly_number(1000000000) == "1,000,000,000"

# Generated at 2022-06-24 08:36:09.355367
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    # Create the CSV
    csv_file = io.StringIO()
    # Write the CSV file
    writer = csv.writer(csv_file, quoting=csv.QUOTE_ALL)
    writer.writerow(['key', 'value'])
    writer.writerow(['plural/singular', 'few'])
    writer.writerow(['plural/plural', 'others'])
    writer.writerow(['unknown/I am a test', 'trasnlate_me'])
    csv_file.seek(0)
    reader = csv.reader(csv_file)
    csv_translations = {}
    plural_translation = {}
    singular_translation = {}
    for row in reader:
        if row[0].startswith("unknown"):
            csv_translations["unknown"]

# Generated at 2022-06-24 08:36:11.054015
# Unit test for function get_supported_locales
def test_get_supported_locales():
    load_translations("currentdir")
    assert get_supported_locales() == frozenset(['en_US'])


# Generated at 2022-06-24 08:36:24.350687
# Unit test for constructor of class Locale
def test_Locale():
    class TestLocale(Locale):
        def translate(
            self,
            message: str,
            plural_message: Optional[str] = None,
            count: Optional[int] = None,
        ) -> str:
            return message

    Locale.get_closest(None)
    Locale.get_closest('')
    Locale.get_closest('en')
    Locale.get_closest('en', 'zh_CN')
    Locale.get_closest('en', 'zh_CN', 'fr')
    Locale.get_closest('zh_CN')
    Locale.get_closest('zh_CN', 'fa')

    locale = Locale.get('en')
    assert locale.code == 'en'
    locale.list([])
   

# Generated at 2022-06-24 08:36:34.903423
# Unit test for method pgettext of class CSVLocale

# Generated at 2022-06-24 08:36:45.036551
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    ng = gettext.NullTranslations()
    
    gt = GettextLocale("fa", ng)
    assert gt.translate("string") == "string"

    ng = gettext.NullTranslations()
    ng.add_fallback(gettext.NullTranslations())
    gt = GettextLocale("fa", ng)
    assert gt.translate("string") == "string"

    ng = gettext.NullTranslations()
    ng.add_fallback(gettext.NullTranslations())
    ng.add_fallback(gettext.NullTranslations())
    gt = GettextLocale("fa", ng)
    assert gt.translate("string") == "string"


# Generated at 2022-06-24 08:36:48.892374
# Unit test for function get_supported_locales
def test_get_supported_locales():
    '''
    There is only one variable _supported_locales
    '''
    old_supported_locales = _supported_locales
    _supported_locales = [1]
    assert get_supported_locales() == [1]
    _supported_locales = old_supported_locales


# Generated at 2022-06-24 08:37:02.217525
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    locale = Locale("en_US")
    assert locale.format_day(datetime.datetime(2016, 1, 22)) == "Friday, January 22"
    assert locale.format_day(datetime.datetime(2016, 1, 22), gmt_offset=6) == "Friday, January 22"
    assert locale.format_day(datetime.datetime(2016, 1, 23), gmt_offset=6) == "Saturday, January 23"
    assert locale.format_day(datetime.datetime(2016, 11, 22), gmt_offset=6) == "Tuesday, November 22"
    assert locale.format_day(datetime.datetime(2016, 1, 22), dow=False) == "January 22"

# Generated at 2022-06-24 08:37:03.520696
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    pass


# Generated at 2022-06-24 08:37:14.206915
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    # import os
    # os.environ['TZ'] = 'GMT'
    # os.environ['TRANSLATION_PATH'] = 'translations'
    global _default_locale
    global _translations
    global _supported_locales
    global _use_gettext
    _default_locale = "en"
    _supported_locales = ["en", "fr_FR"]
    _translations = {}

# Generated at 2022-06-24 08:37:17.177732
# Unit test for method translate of class Locale
def test_Locale_translate():
    Locale.load_translations("locale", "csv")
    assert Locale("en").translate("missing") == "missing"
    assert Locale("fr").translate("missing") == "manquant"


# Generated at 2022-06-24 08:37:29.917476
# Unit test for function get
def test_get():
    """

    :return:
    """
    from tornado.test.util import unittest
    class GetTest(unittest.TestCase):
        def setUp(self):
            self.default_locale = Locale._get_default_locale()

        def tearDown(self):
            Locale.set_default_locale(self.default_locale)

        def test_get(self):
            Locale.load_translations(os.path.join(os.path.dirname(__file__),
                                        "locale_data"))
            en_locale = Locale.get("en_US")
            self.assertEqual("en_US", en_locale.code)
            self.assertEqual("English (United States)", en_locale.name)
            pt_BR_locale = Loc

# Generated at 2022-06-24 08:37:31.713482
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale('en_US')
    assert _default_locale == 'en_US'


# Generated at 2022-06-24 08:37:39.345088
# Unit test for constructor of class Locale
def test_Locale():
    l1 = Locale('zh_CN')
    l2 = Locale('en_US')
    l3 = Locale('fr_FR')
    l4 = Locale('fa_FA')
    assert l1.code == 'zh_CN'
    assert l2.code == 'en_US'
    assert l3.code == 'fr_FR'
    assert l4.code == 'fa_FA'
    assert l1.name == '中文(中国)'
    assert l2.name == 'English'
    assert l3.name == 'français'
    assert l4.name == 'Unknown'
    assert l1.rtl == False
    assert l2.rtl == False
    assert l3.rtl == False
    assert l4.rtl == True

# Generated at 2022-06-24 08:37:50.425376
# Unit test for function load_translations
def test_load_translations():
    import tempfile
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 08:37:54.850135
# Unit test for function load_translations
def test_load_translations():
    assert(_translations == {})
    load_translations(directory = './locale/', encoding = None)
    assert(isinstance(_translations, dict))
    assert(len(_translations) > 0)


# Generated at 2022-06-24 08:38:06.282728
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    for code in ["en", "en_US"]:
        l = Locale.get(code)
        assert l.friendly_number(123) == "123"
        assert l.friendly_number(1234) == "1,234"
        assert l.friendly_number(12345) == "12,345"
        assert l.friendly_number(123456) == "123,456"
    for code in ["zh", "zh_TW"]:
        l = Locale.get(code)
        assert l.friendly_number(123) == "123"
        assert l.friendly_number(1234) == "1234"
        assert l.friendly_number(12345) == "12345"
        assert l.friendly_number(123456) == "123456"



# Generated at 2022-06-24 08:38:13.106140
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():

    tdict = {}
    translation = GettextTranslation(tdict)
    tdict['msgid "context\x04message"'] = '"context\x04translated"'
    tdict['msgid "context\x04message"'] = '"context\x04translated"'
    locale = GettextLocale("zh", translation)

    assert locale.pgettext("context", "message") == 'translated'



# Generated at 2022-06-24 08:38:23.697416
# Unit test for method list of class Locale
def test_Locale_list():
    assert Locale.get("zh_CN").list(["a", "b", "c"]) == "a, b 和 c"
    assert Locale.get("fa").list(["a", "b", "c"]) == "a, b به‌پێوەندی c"
    assert Locale.get("en_US").list(["a", "b", "c"]) == "a, b, and c"
    assert Locale.get("en").list(["a", "b", "c"]) == "a, b, and c"
    assert Locale.get("zh_CN").list(["a", "b"]) == "a 和 b"

# Generated at 2022-06-24 08:38:29.316742
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l = Locale("en")
    assert "1,000" == l.friendly_number(1000)
    assert "2,000,000" == l.friendly_number(2000000)
    assert "1,234,567" == l.friendly_number(1234567)
    assert "1,234,567,890" == l.friendly_number(1234567890)

# Generated at 2022-06-24 08:38:39.768925
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    value = 0
    result = Locale.get("en").friendly_number(value)
    assert result == str(0)

    value = 9
    result = Locale.get("en").friendly_number(value)
    assert result == str(9)

    value = 10
    result = Locale.get("en").friendly_number(value)
    assert result == str(10)

    value = 99
    result = Locale.get("en").friendly_number(value)
    assert result == str(99)

    value = 100
    result = Locale.get("en").friendly_number(value)
    assert result == str(100)

    value = 101
    result = Locale.get("en").friendly_number(value)
    assert result == str(101)

    value = 999

# Generated at 2022-06-24 08:38:52.305235
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    CSVLocale('en_US', {}).translate('message', 'against_n')
    CSVLocale('en_US', {}).translate('message', 'against_n', count=22)
    # Only singular
    CSVLocale('en_US', {'singular': {'message': 'plural_message'}}).translate('message', 'against_n', count=1)
    # Only plural
    CSVLocale('en_US', {'plural': {'message': 'plural_message'}}).translate('message', 'against_n', count=22)
    # Plural = singular
    CSVLocale('en_US', {'singular': {'message': 'plural_message'}, 'plural': {'message': 'plural_message'}}).translate('message', 'against_n')


# Generated at 2022-06-24 08:39:04.652383
# Unit test for method list of class Locale
def test_Locale_list():
    l = Locale.get_closest("fa")
    assert l.list([]) == ""
    assert l.list(["a"]) == "a"
    assert l.list(["a", "b"]) == "a \u0648 b"
    assert l.list(["a", "b", "c"]) == "a, b \u0648 c"
    assert l.list(["بهزاد", "زهرا"]) == "بهزاد \u0648 زهرا"

    l = Locale.get_closest("en")
    assert l.list([]) == ""
    assert l.list(["a"]) == "a"
    assert l.list(["a", "b"]) == "a and b"

# Generated at 2022-06-24 08:39:08.797070
# Unit test for method translate of class Locale
def test_Locale_translate():
    load_translations('./translations')
    locale = Locale.get('de')
    assert locale.translate('test') == 'test'
    assert locale.translate('test', 'tests', 2) == 'tests'

if __name__ == '__main__':
    test_Locale_translate()

# Generated at 2022-06-24 08:39:18.211759
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    _ = Locale("en_US").translate
    date = datetime.datetime(2017, 9, 26)
    assert _("%(weekday)s, %(month_name)s %(day)s") % {
        "month_name": Locale("en_US")._months[date.month - 1],
        "weekday": Locale("en_US")._weekdays[date.weekday()],
        "day": str(date.day),
    } == "Tuesday, September 26"
    return



# Generated at 2022-06-24 08:39:23.188917
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    print("Test CSVLocale: constructor")
    code = "jp"
    translations = {"plural":{"hello world":"こんにちは世界", "good": "good"}}
    test=CSVLocale(code, translations)
    assert test.code==code
    assert test.translations==translations
    assert test.name==u"Unknown"
    assert test.rtl == False


# Generated at 2022-06-24 08:39:28.980906
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale("en").friendly_number(0) == "0"
    assert Locale("en").friendly_number(1) == "1"
    assert Locale("en").friendly_number(999) == "999"
    assert Locale("en").friendly_number(1000) == "1,000"
    assert Locale("en").friendly_number(12345678) == "12,345,678"



# Generated at 2022-06-24 08:39:34.264783
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    d = {"unknown": {"test": "Testing pgettext"}}
    csv_locale = CSVLocale("en", d)
    assert csv_locale.pgettext("test", "Test") == csv_locale.translate("Test")


# Generated at 2022-06-24 08:39:39.932431
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    csvLocale = CSVLocale(code="en_uk", translations={})
    assert csvLocale.translate("test") == "test"
    assert csvLocale.translate("test", "plural_test", 1) == "test"
    assert csvLocale.translate("test", "plural_test", 2) == "plural_test"
    # Test with translations
    csvLocale = CSVLocale(code="en_uk", translations={"unknown": {"test": "tested"}})
    assert csvLocale.translate("test") == "tested"
    assert csvLocale.translate("test", "plural_test", 1) == "tested"
    assert csvLocale.translate("test", "plural_test", 2) == "plural_test"
    csv

# Generated at 2022-06-24 08:39:49.301536
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    import pytest
    from csv import reader

    class CSVLocaleTest(CSVLocale):
        def pgettext(self, context, message, pluaral_message = None, count = None):
            if not context:
                return message
            else:
                return "Hello, World"
    m_translate = Locale.translate
    c_translate = CSVLocale.translate

    messages_dict = {}
    with open("test.csv", encoding="utf-8") as f:
        for i, row in enumerate(reader(f)):
            if not row or len(row) < 2:
                continue
            row = [escape.to_unicode(c).strip() for c in row]
            english = row[1]

# Generated at 2022-06-24 08:39:54.751223
# Unit test for function get_supported_locales
def test_get_supported_locales():
    load_translations(r"D:\GitHub\Tornado-Semantic-UI\tornado\static")
    a = get_supported_locales()
    assert isinstance(a, (tuple, list)) == True
    assert isinstance(a[0], str) == True
    assert "%s" % a == '("en_US",)'
# Function test_get_supported_locales ends


# Generated at 2022-06-24 08:39:57.768279
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    via = GettextLocale("en", translations=None)
    print(via.translate("test"))
    print(via.translate("test", "tests", 5))

# Generated at 2022-06-24 08:39:58.687001
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert True == True

# Generated at 2022-06-24 08:40:04.353858
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    class TestLocale(Locale):
        def pgettext(
            self,
            context: str,
            message: str,
            plural_message: Optional[str] = None,
            count: Optional[int] = None,
        ) -> str:
            pass
        if __name__ == '__main__':
            unittest.main()


# Generated at 2022-06-24 08:40:06.062454
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert isinstance(get_supported_locales(), frozenset)



# Generated at 2022-06-24 08:40:09.736280
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    locale = Locale("en_US")
    assert locale.friendly_number(0) == "0"
    assert locale.friendly_number(1000000) == "1,000,000"


# Generated at 2022-06-24 08:40:20.114499
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    gen_log.info('Test Locale.pgettext')
    global _translations
    _translations ={
        'zh_CN': {'plural': {'apple': 'apple'}}
    }
    translation = _translations.get('zh_CN', None)
    cls = Locale
    cls.get_closest('zh_CN')
    pgettext_test = cls.get('zh_CN')
    pgettext_test.translate('apple')
    pgettext_test.pgettext('zh_CN', 'apple')
    gen_log.info('Finish test for Locale.pgettext')

# Generated at 2022-06-24 08:40:24.536864
# Unit test for function set_default_locale
def test_set_default_locale():
    import tornado.locale
    tornado.locale.set_default_locale("zh_CN")
    assert tornado.locale.get_default_locale() == "zh_CN"



# Generated at 2022-06-24 08:40:28.077296
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert get_supported_locales() == frozenset(
        ['fr_FR', 'zh_CN', 'de_DE', 'pt_BR', 'es_ES', 'it_IT', 'en_US', 'ja_JP']
    )

