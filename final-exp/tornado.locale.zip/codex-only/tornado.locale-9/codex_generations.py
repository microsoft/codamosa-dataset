

# Generated at 2022-06-24 08:30:22.547686
# Unit test for function get
def test_get():
    assert get('en_US')



# Generated at 2022-06-24 08:30:24.127206
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale('en_US')



# Generated at 2022-06-24 08:30:34.233835
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    assert Locale("en_US").format_day(datetime(2015, 1, 1)) == "Thursday, January 1"
    assert Locale("en_US").format_day(datetime(2015, 1, 1), dow = False) == "January 1"
    assert Locale("fa_IR").format_day(datetime(2015, 1, 1)) == "پنجشنبه، ژانویهٔ 1"
    assert Locale("fa_IR").format_day(datetime(2015, 1, 1), dow = False) == "ژانویهٔ 1"
    assert Locale("zh_CN").format_day(datetime(2015, 1, 1)) == "星期四, 一月 1"


# Generated at 2022-06-24 08:30:36.136811
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    print(load_gettext_translations())
    return _translations,_supported_locales,_use_gettext

# Generated at 2022-06-24 08:30:47.055005
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    """Test method format_day of class Locale
    """
    for locale_name in ['en-CA', 'en-US']:
        locale = Locale.get(locale_name)
        assert locale is not None
        for month_day in range(1,13):
            for year in range(2000,2020):
                test_date = datetime.datetime(year, month_day, 1)
                out = locale.format_day(test_date)
                if locale_name == 'en-CA':
                    assert out == calendar.day_name[test_date.weekday()] + ", " + calendar.month_name[month_day] + " 1"
                elif locale_name == 'en-US':
                    assert out == calendar.month_name[month_day] + " 1"


# Generated at 2022-06-24 08:30:48.833933
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    CSVLocale('test', None).pgettext('test', 'test', 'test', 'test')



# Generated at 2022-06-24 08:30:52.828310
# Unit test for function load_translations
def test_load_translations():
    load_translations('./examples/locale_example')
    assert _supported_locales==frozenset(list(_translations.keys()) + [_default_locale])
    assert sorted(_translations.items())[0][1]['unknown']['Translation test'] == 'Traducción de prueba'


# Generated at 2022-06-24 08:30:59.565137
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import unittest
    from .test.support import _get_data_files_dir
    from .util import create_temp_dir
    from .options import options
    from .httpclient import AsyncHTTPClient
    from .ioloop import IOLoop

    class LocaleGettextTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = create_temp_dir()

            # data dir contains locale test data
            self.data_dir = os.path.join(_get_data_files_dir(), "locale_data")

            # copy the test data to a temp directory
            test_translations = os.path.join(self.data_dir, "gettext")

# Generated at 2022-06-24 08:31:03.103438
# Unit test for constructor of class Locale
def test_Locale():
    import pytest
    from typhoon.localization import Locale
    with pytest.raises(NotImplementedError):
        Locale.get('en')

# Generated at 2022-06-24 08:31:11.501508
# Unit test for function get_supported_locales
def test_get_supported_locales():
    global _translations
    global _supported_locales
    global _use_gettext
    _translations = {"fr_FR": [""],
        "es_ES": [""],
        "de_DE": [""],
        "en_EN": [""]}
    _supported_locales = frozenset(list(_translations.keys()) + [_default_locale])
    _use_gettext = True
    assert get_supported_locales() == frozenset(['en_EN', 'de_DE', 'es_ES', 'fr_FR', 'en_US'])



# Generated at 2022-06-24 08:31:12.853300
# Unit test for function load_translations
def test_load_translations():
    directory = "."
    encoding = "utf-8"
    load_translations(directory=directory, encoding=encoding)



# Generated at 2022-06-24 08:31:16.847885
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    csv_locale = CSVLocale("en", {})
    assert csv_locale.pgettext("mozilla", "Mozilla") == 'Mozilla'
    assert csv_locale.pgettext("firefox", "Firefox", "Firefoxes", 5) == 'Firefoxes'



# Generated at 2022-06-24 08:31:26.697028
# Unit test for method list of class Locale
def test_Locale_list():
    _translations = {
        "fa": {
            "singular": {
                "A": u"\u062a",
                "B": u"\u062b",
                "C": u"\u062c",
            },
        },
    }
    locale = Locale.get("fa")
    assert locale.list([u"\u062a", u"\u062b"]) == u"\u062a \u0648 \u062b"
    assert locale.list([u"\u062a", u"\u062b", u"\u062c"]) == u"\u062a \u0648 \u062b \u0648 \u062c"

# Generated at 2022-06-24 08:31:38.052491
# Unit test for function get
def test_get():
    Locale.set_default_locale("en_US")
    # type(get("en_US")) == "Locale"
    assert isinstance(get("en_US"), Locale)
    # type(get('en-us')) == "Locale"
    assert isinstance(get('en-us'), Locale)
    # type(get("en")) == "Locale"
    assert isinstance(get("en"), Locale)
    # type(get("en_CA")) == "Locale"
    assert isinstance(get("en_CA"), Locale)
    # type(get("de_DE")) == "Locale"
    assert isinstance(get("de_DE"), Locale)
    Locale.set_supported_locales(["en_CA"])

    # type(get("en_CA")) == "Loc

# Generated at 2022-06-24 08:31:47.366745
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    import os
    import sys
    import unittest

    class TestLoadGettextTranslations(unittest.TestCase):
        def test_load_gettext_translations(self):
            sys.argv = [""]
            dirname = os.path.dirname(os.path.abspath(__file__))
            load_gettext_translations(os.path.join(dirname, 'translations'), "tornado")
            self.assertIn('en_US', _supported_locales)
            self.assertIn('es_LA', _supported_locales)
            self.assertIn('en_US', _translations)
            self.assertIn('es_LA', _translations)
            self.assertTrue(_use_gettext)
    return TestLoadGettextTranslations



# Generated at 2022-06-24 08:31:49.287107
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    load_gettext_translations("../locale", "tornado")



# Generated at 2022-06-24 08:31:55.253878
# Unit test for function load_translations
def test_load_translations():
    code = "en_US"
    set_default_locale(code)
    load_translations("./tornado/_locale_data")
    assert(len(_translations[code]))


# Let's us know if any string was ever translated.  Set in Locale.translate().
_translated = False



# Generated at 2022-06-24 08:32:06.032798
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    from datetime import datetime
    from datetime import timedelta
    import locale
    import sys
    import os
    from unittest import TestCase

    if sys.version_info > (3, 0):
        import builtins
    else:
        import __builtin__ as builtins # type: ignore

    # To support running this test on the CI using Python 3
    # we define an equivalent to the xrange function
    # which is not available in any Py3 library
    if hasattr(builtins, "xrange"):
        xrange = builtins.xrange
    else:
        xrange = range

    class FakeTranslator:
        def gettext(self, msgid):
            return msgid

        def ngettext(self, msgid, msgid_plural, n):
            return msgid if n == 1 else msg

# Generated at 2022-06-24 08:32:09.502416
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    translations_csv = {
        'singular': {
            'A': 'B',
            'C': 'D'
        },
        'plural': {
            'E': 'F',
            'G': 'H'
        }
    }
    csv = CSVLocale("en", translations_csv)
    assert csv.translate("A") == "B"
    assert csv.translate("E") == "E"
    assert csv.translate("E", "F", 3) == "F"



# Generated at 2022-06-24 08:32:10.748508
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert not _supported_locales



# Generated at 2022-06-24 08:32:17.904996
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    assert Locale.get("en").friendly_number(1) == "1"
    assert Locale.get("en").friendly_number(123) == "123"
    assert Locale.get("en").friendly_number(1234) == "1,234"
    assert Locale.get("en").friendly_number(1234567890) == "1,234,567,890"



# Generated at 2022-06-24 08:32:18.610027
# Unit test for constructor of class Locale
def test_Locale():
    Locale('en_us')



# Generated at 2022-06-24 08:32:26.456926
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    def load_translations():
        _translations = gettext.NullTranslations()
        _translations.add_fallback(_translations)
        return _translations

    if sys.version_info < (3, 0):
        _translations = load_translations()
    else:
        _translations = {}

    _supported_locales = ["en"]
    _use_gettext = True
    _default_locale = "en"

    translations = _translations.get("en", None)
    if translations is None:
        locale = CSVLocale("en", {})  # type: Locale
    else:
        locale = GettextLocale("en", translations)

    translation1 = locale.translate("test_message")
    assert translation1 == "test_message"


# Generated at 2022-06-24 08:32:28.751954
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    assert _default_locale == "en_US"
    assert _supported_locales == frozenset(["en_US"])

# Generated at 2022-06-24 08:32:35.993685
# Unit test for function get
def test_get():
    assert(get("en_US") == get("en"))
    assert(get("en_US") == get("en_US", "es_LA"))
    assert(get("en") == get("en", "es_LA"))
    assert(get("es_ES") == get("es_ES", "es_LA"))
    assert(get("es") == get("es", "es_LA"))
    assert(get() == get("nonexistent"))
    assert(get() == get("nonexistent", "nonexistent"))
    assert(get(None) == get("nonexistent"))
    assert(get(None, None) == get("nonexistent"))



# Generated at 2022-06-24 08:32:43.837772
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    translations = {"unknown": {"hello": "hola", "world": "mundo"}}
    l = CSVLocale("es_ES", translations)
    assert l.translate("hello") == "hola"
    assert l.translate("world") == "mundo"
    translations = {"singular": {"hello": "hi"}, "plural": {"hello": "hey"}}
    assert l.translate("hello", "hello", 1) == "hi"
    assert l.translate("hello", "hello", 5) == "hey"



# Generated at 2022-06-24 08:32:48.429838
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    msg = "hola"
    plural_msg = "holas"
    count = 2
    gettext = GettextLocale("es", nulltranslations())
    assert gettext.translate(msg, plural_msg, count) == "holas"
    assert gettext.translate(msg) == "hola"



# Generated at 2022-06-24 08:32:52.130360
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    class MockLocale(Locale):
        def translate(self, message, plural_message, count):
            return "MOCK"
    l = MockLocale("en")
    assert l.pgettext("context", "message") == "MOCK"



# Generated at 2022-06-24 08:32:53.900186
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale('en_US')
    assert _default_locale == 'en_US'



# Generated at 2022-06-24 08:33:01.705447
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    locale_coding = Locale.get('zh_CN')
    assert locale_coding.format_day(datetime.strptime("2019 10 20", "%Y %m %d")) == "星期日, 十月 20"
    assert locale_coding.format_day(datetime.strptime("2019 10 20", "%Y %m %d"), dow=False) == "十月 20"
    locale_coding = Locale.get('zh_TW')
    assert locale_coding.format_day(datetime.strptime("2019 10 20", "%Y %m %d")) == "星期日, 十月 20"

# Generated at 2022-06-24 08:33:06.470111
# Unit test for method list of class Locale
def test_Locale_list():
    l = Locale("en")
    assert l.list([]) == ""
    assert l.list(["A"]) == "A"
    assert l.list(["A", "B"]) == "A and B"
    assert l.list(["A", "B", "C"]) == "A, B and C"



# Generated at 2022-06-24 08:33:08.558540
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert _supported_locales == get_supported_locales()



# Generated at 2022-06-24 08:33:16.550762
# Unit test for method list of class Locale
def test_Locale_list():
    import numpy as np
    from collections import Counter
    from tqdm import tqdm
    cur_locale = Locale('en_US')
    test_lst = [["A", "B", "C"], ["A", "B", "C", "D"], ["A", "B"], ["A"]]
    test_ans = ["A, B and C", "A, B, C and D", "A and B", "A"]
    temp_lst = []
    for i in test_lst:
        temp_lst.append(cur_locale.list(i))
    assert Counter(temp_lst) == Counter(test_ans)
    print("\nTest of Locale.list() passed!")

# Generated at 2022-06-24 08:33:19.000548
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("my_default")
    assert _default_locale == "my_default"


# Generated at 2022-06-24 08:33:26.987708
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    translations = {
        "plural": {
            "1 second ago": "1 segundo atrás",
            "%(seconds)d seconds ago": "%(seconds)d segundos atrás",
            "1 minute ago": "1 minuto atrás",
            "%(minutes)d minutes ago": "%(minutes)d minutos atrás",
            "1 hour ago": "1 hora atrás",
            "%(hours)d hours ago": "%(hours)d horas atrás",
        },
        "unknown": {"yesterday": "ontem", "yesterday at %(time)s": "ontem às %(time)s"},
    }
    locale = CSVLocale("pt_BR", translations)
    assert locale.translate("yesterday") == "ontem"
    assert locale

# Generated at 2022-06-24 08:33:29.344268
# Unit test for function load_translations
def test_load_translations():

    directory = "E:\Programming\GitHub\tornado-examples-master\demos\i18n\translations"
    load_translations(directory)

    print(str(_translations))


# Generated at 2022-06-24 08:33:31.370684
# Unit test for function set_default_locale
def test_set_default_locale():
    # Assume
    code = "en_US"

    # Action
    set_default_locale(code)

    # Assert
    assert _default_locale == code



# Generated at 2022-06-24 08:33:39.478310
# Unit test for method format_day of class Locale
def test_Locale_format_day():
 
    #First, we create the datetime object
    #for the day January 22, 2012
    test_date = datetime.datetime(2012,1,22)
    #We build a dictionary of test cases
    #first, we test with  day of week
    test_cases = {
        'en': 'Sunday, January 22',
        'fa': '\u0634\u0646\u0628\u0647\u002c 22 \u0698\u0627\u0646\u0648\u06cc\u0647',
        'ar': '\u0627\u0644\u0623\u062d\u062f\u002c 22 \u064a\u0646\u0627\u064a\u0631'
    }
    #Another test case to test

# Generated at 2022-06-24 08:33:44.651029
# Unit test for function load_translations
def test_load_translations():
    directory = "../locale"
    set_default_locale("en_US")
    load_translations(directory, encoding="utf-8")
    user_locale = get("es_LA")
    print(user_locale.translate("Sign out"))



# Generated at 2022-06-24 08:33:57.314999
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    """
    Test if pgettext method of class GettextLocale works as intended.
    """

    def setup():
        d = {}
        d["en"] = {}
        d["en"]["plural"] = {}
        d["en"]["singular"] = {}
        d["en"]["unknown"] = {}
        d["en"]["plural"][
            "Hello, %(username)s!  There are %(count)d people online."
        ] = "Hello, %(username)s!  There are %(count)d people online."
        d["en"]["singular"][
            "Hello, %(username)s!  There is one other person online."
        ] = "Hello, %(username)s!  There is one other person online."

# Generated at 2022-06-24 08:34:09.316587
# Unit test for constructor of class Locale
def test_Locale():
    code = 'en'
    test_locale = Locale.get(code)
    assert test_locale.code == code
    months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ]
    weekdays = [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
    ]

# Generated at 2022-06-24 08:34:11.677290
# Unit test for constructor of class Locale
def test_Locale():
    assert len(LOCALE_NAMES) > 0



# Generated at 2022-06-24 08:34:12.931537
# Unit test for constructor of class Locale
def test_Locale():
    assert Locale("en")



# Generated at 2022-06-24 08:34:22.302628
# Unit test for method format_date of class Locale

# Generated at 2022-06-24 08:34:24.719667
# Unit test for method translate of class Locale
def test_Locale_translate():
    testTranslate = Locale.translate('hello world')
    assert testTranslate == ('hello world')


# Generated at 2022-06-24 08:34:37.078105
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    gl = GettextLocale("fr", gettext.translation('messages', localedir='./locales', languages=['fr']))
    assert gl.gettext("Hello!") == "Bonjour!"
    assert gl.ngettext("%d dog", "%d dogs", 0) == "0 chien"
    assert gl.ngettext("%d dog", "%d dogs", 1) == "1 chien"
    assert gl.ngettext("%d dog", "%d dogs", 2) == "2 chiens"    
    
    gl = GettextLocale("en", gettext.translation('messages', localedir='./locales', languages=['en']))
    assert gl.gettext("Hello!") == "Hello!"

# Generated at 2022-06-24 08:34:44.237251
# Unit test for method translate of class Locale
def test_Locale_translate():
    import sys

    # Set up the test environment
    locale = Locale("es")
    sys.modules["__main__"].__dict__.update(locale=locale)
    # Should return 'Es una prueba, señor'
    assert locale.translate("It's a test, sir") == "Es una prueba, señor"

# Generated at 2022-06-24 08:34:54.585820
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():

    # case 1:
    test1 = {
        'unknown': {
            'test_message': 'test_result1'
        }
    }
    locale = CSVLocale('en_US',test1)
    assert locale.translate('test_message') == 'test_result1'

    # case 2:
    test2 = {
        'unknown': {
            'test_message': 'test_result2'
        },
        'plural': {
            'test_message': 'test_result3'
        }
    }
    locale = CSVLocale('en_US',test2)
    assert locale.translate('test_message') == 'test_result2'
    assert locale.translate('test_message', 'test_message', 1) == 'test_result2'

# Generated at 2022-06-24 08:35:01.171727
# Unit test for function set_default_locale
def test_set_default_locale():
    # type: () -> None
    from tornado import gen
    from tornado import testing
    from tornado import web

    ioloop = testing.IOLoop.current()

    @gen.coroutine
    def test_default_locale():
        # type: () -> None
        # Verify that the default locale is "en_US"
        user_locale = Locale.get_closest('fr_FR')
        self.assertEqual(user_locale.code, 'en_US')
        # Changing the default locale should be reflected in get_closest
        set_default_locale('fr_FR')
        user_locale = Locale.get_closest('de_DE')
        self.assertEqual(user_locale.code, 'fr_FR')


# Generated at 2022-06-24 08:35:06.894069
# Unit test for method translate of class Locale
def test_Locale_translate():
    import sys, os
    sys.path.insert(0, "../")
    from datetime import datetime
    import tempfile
    import csv

    # Get language code
    lang = "en_US"

    #------------------------
    # test get_supported_locales()
    #------------------------
    # make a dictionary with translation for "en_US"
    translations = {}
    translations["en_US"] = {}
    translations["en_US"]["unknown"] = {}
    translations["en_US"]["unknown"]["one"] = "one"
    translations["en_US"]["unknown"]["two"] = "two"
    # Create a CSV file and write to it

# Generated at 2022-06-24 08:35:14.076835
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    global_config['locale'] = 'ru'
    _internal_init_locale()
    test_case = GettextLocale('ru', _translations['ru'])
    assert test_case.translate("January") == "января"
    assert test_case.translate("February") == "февраля"
    assert test_case.translate("March") == "марта"
    assert test_case.translate("April") == "апреля"
    assert test_case.translate("May") == "мая"
    assert test_case.translate("June") == "июня"
    assert test_case.translate("July") == "июля"

# Generated at 2022-06-24 08:35:17.146159
# Unit test for function load_translations
def test_load_translations():
    load_translations("C:\\Users\\lenovo\\project\\tornado_test\\test.csv")



# Generated at 2022-06-24 08:35:24.796132
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "."
    domain = "messages"
    load_gettext_translations(directory, domain)
    print("_translations: ", _translations)
    print("_supported_locales: ", _supported_locales)
    print("_use_gettext: ", _use_gettext)
    for i in _translations.keys():
        get(i)
    print("finished")


# Generated at 2022-06-24 08:35:33.904889
# Unit test for function get
def test_get():
    # test matching passed locales
    assert get("xx", "yy").code == "en_US"
    assert get("en_UK").code == "en_US"
    assert get("de").code == "de_DE"
    assert get("de_AT").code == "de_AT"
    assert get("de_AT_oo").code == "de_AT"
    # test default locales
    # assert get().code == "en_US"
    assert get("en_UK", "xx", "de").code == "en_US"
    assert get("es").code == "en_US"
    # test unicode locales
    assert get(u"de").code == "de_DE"
    assert get(u"de_AT").code == "de_AT"

# Generated at 2022-06-24 08:35:39.399529
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    from tornado.testing import gen_test
    from .test.util import ObjectDict
    import zlib

    # Write data to csv file
    csv_data = b""""context","message","translation"
"a","b","c"
"""
    with open(os.path.join(os.path.dirname(__file__), 'test_locale.csv'), 'wb') as f:
        f.write(zlib.compress(csv_data))

    load_translations(os.path.join(os.path.dirname(__file__), 'test_locale.csv'))

    def test_pgettext_locale(locale):
        locale_obj = get_closest_locales('en')
        assert locale_obj.pgettext('a', 'b') == 'c'

       

# Generated at 2022-06-24 08:35:45.190371
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    from datetime import datetime
    from datetime import timezone
    from datetime import timedelta
    import pytest
    from tornado.util import ObjectDict

    def test_results(test_locale: str, test_date: datetime, test_gmt_offset: int, \
            test_dow: bool, test_expected_output: str) -> None:
        locale = Locale.get(test_locale)  # type: Locale
        results = locale.format_day(test_date, test_gmt_offset, test_dow)
        assert results == test_expected_output
    

# Generated at 2022-06-24 08:35:46.888591
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert get_supported_locales() == _supported_locales



# Generated at 2022-06-24 08:35:50.471852
# Unit test for method list of class Locale
def test_Locale_list():
    l = Locale.get_closest("en")
    print(l.list(["A", "B", "C"]))
    print(l.list(["A", "B"]))
    print(l.list(["A"]))

# Generated at 2022-06-24 08:35:53.683267
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    test_num = 234123
    test_result = Locale("en").friendly_number(test_num)
    assert test_result == "234,123"
    test_num = 123
    test_result = Locale("en").friendly_number(test_num)
    assert test_result == "123"



# Generated at 2022-06-24 08:36:05.105496
# Unit test for method format_day of class Locale
def test_Locale_format_day():
    assert Locale.get("zh_CN").format_day(datetime.datetime(2016, 5, 1), 0, dow=True) == '\u661f\u671f\u4e00, \u4e00\u6708 1'
    assert Locale.get("en").format_day(datetime.datetime(2016, 5, 1), 0, dow=True) == u'Sunday, May 1'
    assert Locale.get("en").format_day(datetime.datetime(2016, 5, 1), 0, dow=False) == u'May 1'
    assert Locale.get("zh_CN").format_day(datetime.datetime(2016, 5, 1), 0, dow=False) == '\u4e00\u6708 1'



# Generated at 2022-06-24 08:36:08.374747
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    directory = "../../tests/locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    assert _translations == {"pt_BR": gettext.GNUTranslations(None)}
    assert _supported_locales == frozenset({"pt_BR", "en_US"})
    assert _use_gettext == True



# Generated at 2022-06-24 08:36:14.121077
# Unit test for method list of class Locale
def test_Locale_list():
    Locale.load_translations(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "translations"))
    l = Locale.get_closest("fa") # get locale 'fa'
    print(l.list(["A", "B", "C"]))
    print(l.list(["A", "B"]))
    print(l.list(["A"]))
test_Locale_list()


# Generated at 2022-06-24 08:36:16.098285
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert load_gettext_translations(".","mydomain") == None



# Generated at 2022-06-24 08:36:16.761468
# Unit test for function get
def test_get():
    pass



# Generated at 2022-06-24 08:36:22.129468
# Unit test for constructor of class CSVLocale
def test_CSVLocale():
    # Construct an instance of CSVLocale with no arguments,
    # and then call its translate method
    with pytest.raises(AssertionError):
        l = CSVLocale("en", {})
        l.translate("Hello")
# End test for class CSVLocale



# Generated at 2022-06-24 08:36:28.192716
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    assert _default_locale == "en_US"
    set_default_locale("de_DE")
    assert _default_locale == "de_DE"
    assert _translations["en_US"]["Hello"] == "Hello"
    assert _translations["de_DE"]["Hello"] == "Hallo"


# Generated at 2022-06-24 08:36:31.140288
# Unit test for function get_supported_locales
def test_get_supported_locales():
    assert isinstance(_supported_locales, frozenset)
    assert isinstance(get_supported_locales(), Iterable)



# Generated at 2022-06-24 08:36:36.349058
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    translations = {
        "plural": {"One": "1", "Other": "other"},
        "singular": {"One": "one"},
        "unknown": {},
    }
    loc = CSVLocale("en", translations)
    assert loc.pgettext("context", "One", plural_message="Other", count=1) == "one"
    assert loc.pgettext("context", "One", plural_message="Other", count=2) == "other"



# Generated at 2022-06-24 08:36:42.791702
# Unit test for method pgettext of class CSVLocale

# Generated at 2022-06-24 08:36:44.634377
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")
    print(_default_locale)


# Generated at 2022-06-24 08:36:47.096538
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale('en_US')
    assert _default_locale == 'en_US'
test_set_default_locale()



# Generated at 2022-06-24 08:36:50.043337
# Unit test for constructor of class Locale
def test_Locale():
    l = Locale.get("pt_br")
    assert l.code == "pt_BR"
    assert l.name == u"Português (Brasil)"


###############################################################################
# GettextLocale locale object



# Generated at 2022-06-24 08:36:51.008540
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")


# Generated at 2022-06-24 08:37:03.229886
# Unit test for constructor of class Locale
def test_Locale():
    code = "en_US"
    code2 = "zh_CN"
    code3 = "fa_IR"
    months = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ]
    weekdays = [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
    ]
    Locale.get(code)
    Locale.get(code2)
    Locale.get(code3)
    assert Locale.get(code).code == code
    assert Locale.get(code2).code == code2
   

# Generated at 2022-06-24 08:37:13.335348
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    this_module = sys.modules[__name__]
    i18n = tornado.locale.get(this_module.get_current_locale().code)
    assert isinstance(i18n, GettextLocale)
    assert i18n.pgettext("law", "right") == "право"
    assert i18n.pgettext("good", "right") == "right"
    assert i18n.pgettext("organization", "club", "clubs", len(["club1", "club2"])) == "клубы"
    assert i18n.pgettext("stick", "club", "clubs", len(["club1", "club2"])) == "clubs"

# Generated at 2022-06-24 08:37:22.370274
# Unit test for function get
def test_get():
    from tornado.locale import load_translations
    import pathlib
    path = pathlib.Path(__file__).parent / "locale" / "test" / "locale"
    load_translations(path)
    for _ in range(2):
        user_locale = get('ja')
        assert user_locale.code == 'ja'
        assert user_locale.translate('Hello') == 'こんにちは'
        assert user_locale.translate('Hello %s') == 'こんにちは %s'
        assert user_locale.translate('Hello %s', 'Taro') == 'こんにちは Taro'
        #
        user_locale = get('ja', 'en_US')
        assert user_locale.code == 'ja'

# Generated at 2022-06-24 08:37:23.883087
# Unit test for constructor of class Locale
def test_Locale():
    assert len(Locale.get("en").months) == 9
    assert len(Locale.get("fa").months) == 9


# Generated at 2022-06-24 08:37:30.346491
# Unit test for method translate of class CSVLocale
def test_CSVLocale_translate():
    assert CSVLocale("en_US", {"singular":{"hello":"Hello", "world":"World"}, "plural":{"hello":"Hellos", "world":"Worlds"}}).translate("hello", "world") == "Hello"

    assert CSVLocale("en_US", {"singular":{"hello":"Hello", "world":"World"}, "plural":{"hello":"Hellos", "world":"Worlds"}}).translate("hello", "world", 2) == "Hellos"

    assert CSVLocale("en_US", {"singular":{"hello":"Hello", "world":"World"}, "plural":{"hello":"Hellos", "world":"Worlds"}}).translate("hello", "world", 3) == "Hellos"



# Generated at 2022-06-24 08:37:37.892365
# Unit test for constructor of class Locale
def test_Locale():
    # Initialize strings for date formatting
    _ = _Locale.translate
    _Locale._months = [
        _("January"),
        _("February"),
        _("March"),
        _("April"),
        _("May"),
        _("June"),
        _("July"),
        _("August"),
        _("September"),
        _("October"),
        _("November"),
        _("December"),
    ]
    _Locale._weekdays = [
        _("Monday"),
        _("Tuesday"),
        _("Wednesday"),
        _("Thursday"),
        _("Friday"),
        _("Saturday"),
        _("Sunday"),
    ]
    assert _Locale.code == "en"


# Generated at 2022-06-24 08:37:41.513699
# Unit test for method pgettext of class CSVLocale
def test_CSVLocale_pgettext():
    l = CSVLocale(code="en_US", translations={"unknown":{}})
    assert isinstance(l.pgettext(context="", message="", plural_message=None, count=None),str)


# Generated at 2022-06-24 08:37:44.524973
# Unit test for function load_translations
def test_load_translations():
 read_locales = load_translations('./locale')
 print(_translations["es_LA"]["plural"]["%(name)s liked this"])


# Generated at 2022-06-24 08:37:47.746350
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
	print(GettextLocale('fa_IR', gettext.NullTranslations()).code)

# vi: ft=python:sw=4:ts=4

# Generated at 2022-06-24 08:37:53.654117
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    locale = Locale("en_US")
    assert locale.format_date(0) == u"1 second ago"
    assert locale.format_date(1) == u"1 second ago"
    assert locale.format_date(59) == u"59 seconds ago"
    assert locale.format_date(60) == u"1 minute ago"



# Generated at 2022-06-24 08:37:57.149628
# Unit test for function get_supported_locales
def test_get_supported_locales():
    load_translations("tests/data/translations")
    locale = get_supported_locales()
    assert locale == frozenset(["es_GT", "en_US"])



# Generated at 2022-06-24 08:37:58.670226
# Unit test for function get
def test_get():
    locale = get("zh_CN")
    print(locale.name)



# Generated at 2022-06-24 08:38:09.009610
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    import unittest
    import random
    # Set the default locale, default is 'en'
    set_default_locale('fr')
    if not os.path.exists('test/test_logs'):
        os.makedirs('test/test_logs')
    with open(os.path.join('test/test_logs','test_locale_format_date.log'),'w') as f:
        sys.stdout = f
        # Initialize the log system
        init_log(level=logging.DEBUG)
        # Local time zone
        gmt_offset = datetime.datetime.utcnow() - datetime.datetime.now()
        gmt_offset_in_minutes = gmt_offset.seconds // 60

# Generated at 2022-06-24 08:38:20.140905
# Unit test for method pgettext of class Locale
def test_Locale_pgettext():
    from pytest import raises
    from random import choice, randint
    from string import ascii_letters, digits
    from tornado.escape import to_unicode

# Generated at 2022-06-24 08:38:30.167175
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    l = GettextLocale("en", gettext.NullTranslations())
    assert l.pgettext("law", "right") == "right"
    assert l.pgettext("law", "right", "rights", 1) == "right"
    assert l.pgettext("law", "right", "rights", 2) == "rights"
    assert l.pgettext("law", "right", "rights", 1) == "right"
    assert l.pgettext("bad", "good") == "good"
    assert l.pgettext("bad", "right") == "right"


# Generated at 2022-06-24 08:38:40.466515
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    for test_data in [("en", ["100", "1223", "1234", "1234567890"]),
                      ("fa", ["\u06F0\u06F0", "\u06F1\u06F2\u06F2\u06F3",
                              "\u06F1\u06F2\u06F3\u06F4", "\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9\u06F0"])]:
        lang_code = test_data[0]
        test_values = test_data[1]
        l = Locale.get(lang_code)
        for test_value in test_values:
            assert test_value == l

# Generated at 2022-06-24 08:38:53.028938
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    import time
    import datetime
    import unittest
    
    # Add a fake 'de' locale so we don't have to find or download a fake 'de' locale
    _translations['de'] = {'plural': {}, 'singular': {}}
    _supported_locales = frozenset(list(_translations.keys()))
    _default_locale = "de"
    
    class TestLocale(unittest.TestCase):
        def setUp(self):
            self.l = Locale.get("de")
        
        def test_format_date_now(self):
            now = datetime.datetime.utcnow()
            now_str = self.l.format_date(now)
            self.assertEqual(now_str, "jetzt")
    

# Generated at 2022-06-24 08:38:59.178368
# Unit test for constructor of class GettextLocale
def test_GettextLocale():
    test_code = 'en'
    test_translations = gettext.NullTranslations()
    print(test_translations)
    test_locale = GettextLocale(test_code, test_translations)
    print(test_locale)


# Generated at 2022-06-24 08:39:09.972929
# Unit test for method format_date of class Locale
def test_Locale_format_date():
    # Test with locale en_US
    locale_en_US = Locale.get("en_US")
    date = datetime.datetime(year=2018, month=7, day=3, hour=9, minute=0, second=0)
    gmt_offset = 4
    date_str_short = "Tue, Jul 3"
    date_str_full = "Tuesday, July 3, 2018 at 9:00 am"
    # Test format method with format: relative=False, shorter=False, full_format=False
    assert locale_en_US.format_date(date, gmt_offset) == date_str_short

    # Test format method with format: relative=False, shorter=True, full_format=False
    assert locale_en_US.format_date(date, gmt_offset, shorter=True) == date_

# Generated at 2022-06-24 08:39:12.081833
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    assert not callable(load_gettext_translations)



# Generated at 2022-06-24 08:39:23.017422
# Unit test for method list of class Locale
def test_Locale_list():
    """Unit test for method list of class Locale"""
    print("Locale: list")
    locale = Locale.get("en")
    assert locale.list(["A"]) == "A"
    assert locale.list(["A", "B"]) == "A and B"
    assert locale.list(["A", "B", "C"]) == "A, B and C"
    assert locale.list(["A", "B", "C", "D"]) == "A, B, C and D"

    locale = Locale.get("fa")
    assert locale.list(["A"]) == "A"
    assert locale.list(["A", "B"]) == "A \u0648 B"
    assert locale.list(["A", "B", "C"]) == "A, B \u0648 C"

# Generated at 2022-06-24 08:39:29.405386
# Unit test for method pgettext of class GettextLocale
def test_GettextLocale_pgettext():
    gl = GettextLocale(code='en', translations=gettext.NullTranslations())
    assert gl.pgettext('law', 'right') == 'right'
    assert gl.pgettext('good', 'right') == 'right'
    assert gl.pgettext('organization', 'club', 'clubs', 3) == 'clubs'
    assert gl.pgettext('stick', 'club', 'clubs', 3) == 'clubs'



# Generated at 2022-06-24 08:39:39.758779
# Unit test for function load_translations
def test_load_translations():
    directory = "C:/Users/David Liu/PycharmProjects/Tornado_Tutorial/locale"
    encoding = "UTF-8"
    set_default_locale("en_US")
    load_translations(directory, encoding)
    assert _translations["en_US"] == \
           {'unknown': {'"Hello"': '"Hello"'}} # the csv file is not right, so the output is wrong too, need to fix
    assert _supported_locales == frozenset({'en_US'})
    assert get("en_US").translate("Hello") == "Hello"
    assert _default_locale == "en_US"


# Generated at 2022-06-24 08:39:45.636983
# Unit test for method friendly_number of class Locale
def test_Locale_friendly_number():
    l = Locale('en_US')
    assert l.friendly_number(123) == '123'
    assert l.friendly_number(1234) == '1,234'
    assert l.friendly_number(123456) == '123,456'
    assert l.friendly_number(1234567) == '1,234,567'
        


# Generated at 2022-06-24 08:39:48.444125
# Unit test for function load_gettext_translations
def test_load_gettext_translations():
    print("In testing translation")
    directory = "locale"
    domain = "tornado"
    load_gettext_translations(directory, domain)
    print("Supported locales: ", sorted(_supported_locales))
    print("Translations: ", _translations)



# Generated at 2022-06-24 08:39:56.344418
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    res = []
    translations = FakeTranslations()
    gtl = GettextLocale('new_code',translations)
    msg = 'message'
    if gtl.ngettext(msg,'','2') == translations.ngettext(msg,'','2'):
        res.append(True)
    if gtl.gettext(msg) == translations.gettext(msg):
        res.append(True)
    if all(res):
        print('test_GettextLocale_translate passed')
    else:
        print('test_GettextLocale_translate failed')


# Generated at 2022-06-24 08:39:57.811070
# Unit test for function set_default_locale
def test_set_default_locale():
    set_default_locale("en_US")


# Generated at 2022-06-24 08:40:09.878103
# Unit test for constructor of class Locale
def test_Locale():
    class TestLocale(Locale):
        def translate(
            self,
            message: str,
            plural_message: Optional[str] = None,
            count: Optional[int] = None,
        ) -> str:
            return "translated"

        def pgettext(
            self,
            context: str,
            message: str,
            plural_message: Optional[str] = None,
            count: Optional[int] = None,
        ) -> str:
            return "translated"
    locale = TestLocale("en")
    assert locale.code == "en"
    assert locale.name == u"Unknown"
    assert locale.rtl == False
    assert locale.translate("test") == "translated"
    assert locale.pgettext("context", "test") == "translated"

# Generated at 2022-06-24 08:40:21.855149
# Unit test for method translate of class GettextLocale
def test_GettextLocale_translate():
    global _translations # pylint: disable=global-statement
    _translations = defaultdict(lambda: {'C': {'welcome_message': 'Welcome to Hongloumeng'}})
    gettext_obj = gettext.translation('C', 'locale', ['en', 'zh_CN'], fallback=True)
    get_locale = GettextLocale('zh_CN', gettext_obj)
    assert get_locale.translate('welcome_message') == 'Welcome to Hongloumeng'
    assert get_locale.translate('welcome_message', None, None) == 'Welcome to Hongloumeng'

    # test plural_message