

# Generated at 2022-06-12 00:30:16.660743
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.jpeg') == 'image/jpeg'
    assert get_content_type('test.jpe') == 'image/jpeg'
    assert get_content_type('test.jfif') == 'image/jpeg'

# Generated at 2022-06-12 00:30:27.492606
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:30:31.891383
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.css') == 'text/css'
    # Make sure that the file extension is case-insensitive
    assert get_content_type('test.CSs') == 'text/css'
    assert get_content_type('test.py') is None

# Generated at 2022-06-12 00:30:36.126574
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.jpg') == 'image/jpeg'
    assert get_content_type('example.jpg.xz') == 'image/jpeg'



# Generated at 2022-06-12 00:30:43.161704
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test/test.txt') == 'text/plain'
    assert get_content_type('test/test.html') == 'text/html'
    assert get_content_type('test/test.jpg') == 'image/jpeg'
    assert get_content_type('test/test.png') == 'image/png'
    assert get_content_type('test/test.gif') == 'image/gif'

# Generated at 2022-06-12 00:30:46.650823
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.py') == 'text/x-python'
    assert get_content_type(
        'test.pyc'
    ) == 'application/octet-stream'

# Generated at 2022-06-12 00:30:53.333232
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    expire_cookies = get_expired_cookies([
        ('Set-Cookie', 'SessionID=value'),
        ('Set-Cookie', 'foo=bar; path=/baz; '
                       'expires=Sun, 10 Jun 2012 19:37:39 GMT'),
        # There should be no expires attr if max-age is 0.
        ('Set-Cookie', 'baz=quux; path=/; max-age=0'),
        # This expires attr should take precendence over max-age.
        ('Set-Cookie', 'qux=quux; path=/; '
                       'expires=Fri, 29 Jan 2038 03:14:07 GMT; '
                       'max-age=1000000')
    ], now=1339510520)

# Generated at 2022-06-12 00:31:03.185967
# Unit test for function get_content_type
def test_get_content_type():
    import sys
    import tempfile
    from os.path import basename

    def random_file_with_ext(ext):
        f = tempfile.NamedTemporaryFile(suffix='.%s' % ext, delete=False)
        f.close()
        return f.name

    def test_file(filename):
        content_type = get_content_type(filename)
        print('%s: %s' % (basename(filename), content_type))
        assert content_type

    def test_ext(ext):
        test_file(random_file_with_ext(ext))

    test_ext('pdf')
    test_ext('xml')
    test_ext('txt')
    test_ext('html')
    test_ext('json')
    test_ext('xls')

# Generated at 2022-06-12 00:31:14.170751
# Unit test for function get_content_type
def test_get_content_type():
    # Cases taken from the source code for mimetypes.guess_type,
    # where the only difference is that we use '/' as the directory
    # separator on Windows, whereas mimetypes always uses the Unix
    # separator '\'.
    assert get_content_type('/etc/passwd') == 'text/plain'
    assert get_content_type(r'c:\windows\passwd') == 'text/plain'
    assert get_content_type('/etc/') == 'application/x-directory'
    assert get_content_type(r'c:\windows\fonts') == 'application/x-font-ttf'
    assert get_content_type(r'.htaccess') == 'text/x-c'
    assert get_content_type('readme.txt') == 'text/plain'
    assert get

# Generated at 2022-06-12 00:31:21.377385
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:31:30.455576
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from unittest import TestCase
    from io import StringIO
    from requests import Request

    class DummyRequest(Request):
        @property
        def headers(self):
            return self._headers

    class ExplicitNullAuthTestCase(TestCase):
        def test_ExplicitNullAuth___call__(self):
            request = DummyRequest()
            request.prepare()

            with self.assertRaises(KeyError):
                print(request.headers['User-Agent'])

            auth = ExplicitNullAuth()
            auth(request)
            self.assertEqual(request.headers['User-Agent'], 'Python-urllib/2.7')

# Generated at 2022-06-12 00:31:41.994503
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    headers = [('Set-Cookie', 'foo=bar'),
               ('Set-Cookie', 'baz=quux')]
    cookies = get_expired_cookies(headers)

    assert len(cookies) == 2
    assert len(cookies[0]) == 2
    assert cookies[0]['name'] == 'foo'
    assert cookies[0]['path'] == '/'
    assert len(cookies[1]) == 2
    assert cookies[1]['name'] == 'baz'
    assert cookies[1]['path'] == '/'

    headers = [('Set-Cookie', 'foo=bar'),
               ('Set-Cookie', 'baz=quux; path=/foo')]
    cookies = get_expired_cookies(headers)

    assert len(cookies) == 2

# Generated at 2022-06-12 00:31:43.004965
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth

# Generated at 2022-06-12 00:31:51.385312
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'a=1; expires=%s' % (now + 100)),
        ('Set-Cookie', 'b=1; max-age=123'),
        ('Set-Cookie', 'c=1; path=/'),
        ('Set-Cookie', 'd=1; expires=%s' % (now - 100)),
        ('Not-A-Cookie', 'x'),
    ]
    assert get_expired_cookies(headers) == [
        {'name': 'd', 'path': '/'},
    ]

# Generated at 2022-06-12 00:31:56.709240
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    Unit test for function load_json_preserve_order.
    """
    from nose.tools import assert_is_instance

    data = '[{"b":2,"a":1},{"d":4,"c":3}]'
    result = load_json_preserve_order(data)
    assert_is_instance(result, list)
    assert result[0]["a"]
    assert result[0]["b"]
    assert result[1]["c"]
    assert result[1]["d"]

# Generated at 2022-06-12 00:32:04.572349
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '''
    {"f": "z", "a": 1, "b": 2, "c": 2, "e": ["z", "b", "a", "d"], "d": "f"}
    '''
    expected = OrderedDict((
        ('f', 'z'),
        ('a', 1),
        ('b', 2),
        ('c', 2),
        ('e', ['z', 'b', 'a', 'd']),
        ('d', 'f'),
    ))
    actual = load_json_preserve_order(s)
    assert expected == actual



# Generated at 2022-06-12 00:32:16.685008
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('') == OrderedDict()
    assert load_json_preserve_order('{}') == OrderedDict()
    assert load_json_preserve_order('{"a":1}') == OrderedDict([('a', 1)])
    assert load_json_preserve_order('{"a":1,"b":2}') == OrderedDict([('a', 1), ('b', 2)])
    assert load_json_preserve_order('{"a":1,"b":2,"c":3}') == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-12 00:32:24.545442
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        (2 ** 20, '1.0 MB'),
        (2 ** 20 + 2 ** 10, '1.0 MB'),
        (2 ** 20 + 2 ** 15, '1.0 MB'),
        (2 ** 20 + 2 ** 16, '1.0 MB'),
        (2 ** 20 + 2 ** 17, '1.1 MB'),
        (2 ** 21 + 2 ** 10, '2.0 MB'),
        (2 ** 21 + 2 ** 15, '2.0 MB'),
        (2 ** 21 + 2 ** 16, '2.1 MB'),
        (2 ** 21 + 2 ** 17, '2.1 MB'),
    ]
    for k, v in tests:
        assert humanize_bytes(k) == v

# Generated at 2022-06-12 00:32:32.735773
# Unit test for function humanize_bytes

# Generated at 2022-06-12 00:32:41.950775
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:32:49.225108
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert load_json_preserve_order('{"b": "b", "a": "d"}') != {"a": "b", "c": "d"}

# Generated at 2022-06-12 00:32:57.256988
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Generate dict such that the keys are unordered. The JSON library
    # will re-order them in a consistent way unless the
    # object_pairs_hook argument is used.
    attrs = dict(
        (str(i), i)
        for i in range(8, 0, -1)
    )
    attrs_json = load_json_preserve_order(json.dumps(attrs))
    assert attrs == attrs_json
    assert list(attrs.keys()) == list(attrs_json.keys())

# Generated at 2022-06-12 00:33:04.268764
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"foo": "bar", "biz": "buz"}') == {'foo': 'bar', 'biz': 'buz'}
    assert load_json_preserve_order(
        '{"foo": "bar", "biz": "buz", "xyz": "qwerty"}') == {'foo': 'bar', 'biz': 'buz', 'xyz': 'qwerty'}



# Generated at 2022-06-12 00:33:15.226303
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # import doctest
    # doctest.testmod()

    from pytest import approx

    assert approx(humanize_bytes(1)) == '1 B'
    assert approx(humanize_bytes(1024, precision=1)) == '1.0 kB'
    assert approx(humanize_bytes(1024 * 123, precision=1)) == '123.0 kB'
    assert approx(humanize_bytes(1024 * 12342, precision=1)) == '12.1 MB'
    assert approx(humanize_bytes(1024 * 12342, precision=2)) == '12.05 MB'
    assert approx(humanize_bytes(1024 * 1234, precision=2)) == '1.21 MB'
    assert approx(humanize_bytes(1024 * 1234 * 1111, precision=2)) == '1.31 GB'
    assert approx

# Generated at 2022-06-12 00:33:17.398074
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert {'a': 1, 'b': 2} == load_json_preserve_order('{"b": 2, "a": 1}')

# Generated at 2022-06-12 00:33:24.277416
# Unit test for function get_content_type
def test_get_content_type():
    mimetypes.init([])
    mimetypes.types_map['.html'] = 'text/html'
    mimetypes.types_map['.pdf'] = 'application/pdf'
    assert get_content_type('hello.html') == 'text/html'
    assert get_content_type('hello.pdf') == 'application/pdf'
    assert get_content_type('hello') is None


if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-12 00:33:30.223086
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    a = """
    {"t": 123, "a": 456, "b": "abc", "q": 1, "y": 2, "z": 3}
    """

    b = load_json_preserve_order(a)

    assert list(b.values()) == [123, 456, "abc", 1, 2, 3]
    assert list(b.keys()) == ['t', 'a', 'b', 'q', 'y', 'z']

# Generated at 2022-06-12 00:33:30.824464
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-12 00:33:33.256671
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert str(auth) == '<ExplicitNullAuth>'

# Generated at 2022-06-12 00:33:41.925577
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

