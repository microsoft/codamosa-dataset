

# Generated at 2022-06-12 00:30:16.662134
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=b'),
        ('Set-Cookie', 'c=d; max-age=120'),
        ('Set-Cookie', 'e=f; max-age=120'),
        ('Set-Cookie', 'g=h; max-age=10; expires=Mon, 01-Jan-2018 00:00:00 GMT'),
        ('Set-Cookie', 'j=k; max-age=10; expires=Fri, 01-Jan-2038 05:14:38 GMT'),
        ('Set-Cookie', 'l=m; max-age=10; expires=Sat, 01-Jan-2038 05:14:38 GMT'),
    ]

    # Monkey patch time.time() to return constant
    time_now = time.time()
    time.time = lambda: time_now



# Generated at 2022-06-12 00:30:27.491162
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('filename.7z') == 'application/x-7z-compressed'
    assert get_content_type('filename.py') == 'text/x-python'
    assert get_content_type('filename.pyc') == 'application/octet-stream'
    assert get_content_type('filename.md') == 'text/x-markdown'
    assert get_content_type('filename.zip') == 'application/zip'
    assert get_content_type('filename.gz') == 'application/x-gzip'
    assert get_content_type('filename.json') == 'application/json'
    assert get_content_type('filename.json.txt') == 'text/plain'
    assert get_content_type

# Generated at 2022-06-12 00:30:38.057430
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    format = '%a, %d %b %Y %H:%M:%S %Z'
    now = time.strptime('Sun, 21 Jun 2020 05:52:39 GMT', format)
    now = time.mktime(now)

    cookies = get_expired_cookies([('Set-Cookie', '_session=a')], now=now)
    assert cookies == []

    cookies = get_expired_cookies([
        ('Set-Cookie', '_sessione=a'),
        ('Another-Header', 'b')
    ], now=now)
    assert cookies == []

    cookies = get_expired_cookies([
        ('Set-Cookie', '_session=a; Expires=Fri, 01 Jan 1988 00:00:00 GMT'),
    ], now=now)

# Generated at 2022-06-12 00:30:49.868707
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime
    from collections import namedtuple

    date_format = '%a, %d-%b-%Y %H:%M:%S GMT'

    Cookie = namedtuple('Cookie', ['name', 'value', 'path',
                                   'domain', 'expires', 'max_age'])

    now = time.time()

    # test a cookie that's not expired
    cookie = Cookie('name1', 'value1', '/', '.example.com',
                    datetime.fromtimestamp(now + 1000).strftime(date_format),
                    None)
    cookies = [cookie]
    expected = []
    _max_age_to_expires(cookies, now)
    assert get_expired_cookies(cookies, now) == expected

    # test a cookie that's expired
   

# Generated at 2022-06-12 00:30:57.557962
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.htm') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-12 00:31:01.316181
# Unit test for function get_content_type
def test_get_content_type():
    # file in current working directory
    assert get_content_type('this_is_a_file.json') == 'application/json'
    # file in directory above
    assert get_content_type('../this_is_a_file.json') == 'application/json'

# Generated at 2022-06-12 00:31:04.182841
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('index.html') == 'text/html'
    assert get_content_type('data.bin') is None

# Generated at 2022-06-12 00:31:11.263680
# Unit test for function get_content_type
def test_get_content_type():
    """
    Test function get_content_type against a few known mimetypes.

    """

# Generated at 2022-06-12 00:31:20.050187
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from unittest import TestCase
    from io import StringIO
    from collections import namedtuple

    Case = namedtuple('Case', 'headers now expected')


# Generated at 2022-06-12 00:31:30.125341
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Different time zone on different machines,
    # so we have to convert time zone.
    now = int(time.time())
    expires_date = '%a, %d %b %Y %H:%M:%S GMT'

# Generated at 2022-06-12 00:31:35.328644
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('text.txt') == 'text/plain'
    assert get_content_type('text.json') == 'application/json'



# Generated at 2022-06-12 00:31:47.323198
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1540435200.0  # 2018-10-26T12:00:00Z

# Generated at 2022-06-12 00:31:54.091982
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('set-cookie', 'name_1=value_1; path=/; expires=Fri, 10 Feb 2012 10:00:00 GMT'),
        ('set-cookie', 'name_2=value_2; path=/; max-age=86400'),
    ]
    expected = [
        {'name': 'name_1', 'path': '/'},
    ]
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == expected

# Generated at 2022-06-12 00:32:04.572657
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Set up a basic cookie set.
    now = time.time()
    in_an_hour = now + 60 * 60
    in_a_day = now + 24 * 60 * 60
    headers = [
        ('Set-Cookie', 'foo=bar'),
        ('Set-Cookie', 'qux=quux; expires=%s' % in_an_hour),
        ('Set-Cookie', 'norf=nork; max-age=86400'),
    ]

    # Should only pick up the cookie about to expire.
    assert get_expired_cookies(headers, now=now) == []

    # Make two cookies about to expire.

# Generated at 2022-06-12 00:32:15.680854
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.pdf') == 'application/pdf'
    assert get_content_type('file.unknown') is None


if __name__ == '__main__':
    import sys
    import unittest

    class TestGetContentType(unittest.TestCase):
        def test_get_content_type(self):
            self.assertEqual(get_content_type('file.txt'), 'text/plain')
            self.assertEqual(get_content_type('file.pdf'), 'application/pdf')
            self.assertIsNone(get_content_type('file.unknown'))

    sys.exit(unittest.main())

# Generated at 2022-06-12 00:32:21.237231
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'cookiename=cookievalue; Expires=Tue, 01 Jan 2030 00:00:00 GMT'),
        ('Set-Cookie', 'cookiename2=cookievalue2; Max-Age=4242'),
    ]
    cookies = get_expired_cookies(headers)
    assert (cookies == [{'name': 'cookiename', 'path': '/'}])

# Generated at 2022-06-12 00:32:31.861048
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-12 00:32:40.764042
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    response_headers = [
        ('Set-Cookie', 'foo=bar; Max-Age=100'),
        ('Set-Cookie', 'baz=qux; Max-Age=200'),
        ('Set-Cookie', 'bat=boo; Expires=Mon, 10 Apr 2017 11:37:37 GMT'),
    ]
    cookies = get_expired_cookies(headers=response_headers, now=1491813250.9465315)
    assert len(cookies) == 2
    assert cookies[0]['name'] == 'foo'
    assert cookies[0]['path'] == '/'
    assert cookies[1]['name'] == 'baz'
    assert cookies[1]['path'] == '/'

# Generated at 2022-06-12 00:32:48.584015
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    """Test get_expired_cookies()"""
    import datetime
    now = datetime.datetime.now().timestamp()
    assert get_expired_cookies([
        (
            'Set-Cookie',
            'key=value; '
            'expires={}; '
            'path=/'.format(
                datetime.datetime.utcfromtimestamp(now - 1)
                .isoformat() + 'Z',
            )
        )
    ], now=now) == [{'name': 'key', 'path': '/'}]

# Generated at 2022-06-12 00:32:52.272354
# Unit test for function get_content_type
def test_get_content_type():
    # Test known type
    filename = 'example.csv'
    content_type = get_content_type(filename)
    assert content_type == 'text/csv'

    # Test unknown type
    filename = 'example.&*$##'
    content_type = get_content_type(filename)
    assert content_type is None

# Generated at 2022-06-12 00:33:01.785467
# Unit test for function get_content_type
def test_get_content_type():
    import tempfile

    with tempfile.NamedTemporaryFile(
        suffix='.txt', mode='w', delete=False
    ) as f:
        f.write('Some text.')

    assert 'text/plain' == get_content_type(f.name)

# Generated at 2022-06-12 00:33:08.357118
# Unit test for function get_content_type
def test_get_content_type():
    import os
    import tempfile
    with tempfile.NamedTemporaryFile(suffix='.bin') as tmp_f:
        content_type = get_content_type(tmp_f.name)
        assert content_type == 'application/octet-stream'
        with open(tmp_f.name, 'w') as tmp_f:
            print('Hello, world!', end='', file=tmp_f)
        content_type = get_content_type(tmp_f.name)
        assert content_type == 'text/plain'
        os.remove(tmp_f.name)


if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-12 00:33:17.866933
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.PNG') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.JPG') == 'image/jpeg'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.TXT') == 'text/plain'
    assert get_content_type('foo.tXT') == 'text/plain'
    assert get_content_type('foo.foo') is None

# Generated at 2022-06-12 00:33:27.371840
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.csv') == 'text/csv'
    assert get_content_type('test.gif') == 'image/gif'
    assert get_content_type('test.jpeg') == 'image/jpeg'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.mp4') == 'video/mp4'
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.doc') == 'application/msword'
    assert get

# Generated at 2022-06-12 00:33:30.076698
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test/test.txt') == 'test/test'



# Generated at 2022-06-12 00:33:33.361461
# Unit test for function get_content_type
def test_get_content_type():
    """
    Run doctests on function ``get_content_type``.
    """
    import doctest
    print(doctest.testmod(verbose=1))

# Generated at 2022-06-12 00:33:37.248767
# Unit test for function get_content_type
def test_get_content_type():
    actual = get_content_type('/tmp/requests-docs/source/docs/user/quickstart.rst')
    expected = 'text/x-rst; charset=us-ascii'
    assert expected == actual


if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-12 00:33:44.096091
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('filename.html') == 'text/html'
    assert get_content_type('filename.html') == 'text/html'
    assert get_content_type('filename.html') == 'text/html'
    assert get_content_type('filename.jpeg') == 'image/jpeg'
    assert get_content_type('filename.jpg') == 'image/jpeg'
    assert get_content_type('filename.png') == 'image/png'
    assert get_content_type('filename.gif') == 'image/gif'
    assert get_content_type('filename.css') == 'text/css'
    assert get_content_type('filename.js') == 'application/javascript'
    assert get_content_

# Generated at 2022-06-12 00:33:47.951700
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('foo.txt')
    assert 'image/jpeg' == get_content_type('image.jpeg')
    assert 'application/javascript' == get_content_type('script.js')



# Generated at 2022-06-12 00:33:52.406758
# Unit test for function get_content_type
def test_get_content_type():
    from . import IntegrationTestCase

    class TestCase(IntegrationTestCase):
        def test_something(self):
            assert get_content_type('/tmp/something') is None
            assert get_content_type('/tmp/something.txt') == 'text/plain'

    IntegrationTestCase.run_class(TestCase)

# Generated at 2022-06-12 00:33:57.537478
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.json') == 'application/json'
    assert get_content_type('file.nonexistent-ext') is None



# Generated at 2022-06-12 00:34:01.910857
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.htm') == 'text/html'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.jpg') == 'image/jpeg'

# Generated at 2022-06-12 00:34:02.969340
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'

# Generated at 2022-06-12 00:34:13.188441
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('test.pdf')
    assert content_type == 'application/pdf'
    content_type = get_content_type('test.jpg')
    assert content_type == 'image/jpeg'
    content_type = get_content_type('test.pdf')
    assert content_type == 'application/pdf'
    content_type = get_content_type('test.html')
    assert content_type == 'text/html'
    content_type = get_content_type('test.css')
    assert content_type == 'text/css'


if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-12 00:34:19.303882
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('README.md') == 'text/plain'
    assert get_content_type('mimetypes.py') == 'text/x-python'
    assert get_content_type('mimetypes.py.bak') == 'text/x-python'
    assert get_content_type('mimetypes.py.bak') == 'text/x-python'
    assert get_content_type('nonexistent.py.bak') is None

# Generated at 2022-06-12 00:34:20.477114
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("index.html") == "text/html"

# Generated at 2022-06-12 00:34:30.346770
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/a/b/c.png') == 'image/png'
    assert get_content_type('/a/b/c.html') == 'text/html'
    assert get_content_type('/a/b/c.p12') == 'application/x-pkcs12'
    assert get_content_type('/a/b/c.tar.gz') == 'application/x-tar'
    assert get_content_type('/a/b/c.js') == 'application/javascript'
    assert get_content_type('/a/b/c.css') == 'text/css'
    assert get_content_type('/a/b/c.txt') == 'text/plain'
    assert get_content_type('/a/b/c.unknown') is None
   

# Generated at 2022-06-12 00:34:37.832803
# Unit test for function get_content_type
def test_get_content_type():
    """
    Test the filename-to-content-type mappings returned by
    ``get_content_type``.

    """

# Generated at 2022-06-12 00:34:40.736149
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo') is None
    assert get_content_type('foo.txt') == 'text/plain'

# Generated at 2022-06-12 00:34:42.360043
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.jpg') == 'image/jpeg'