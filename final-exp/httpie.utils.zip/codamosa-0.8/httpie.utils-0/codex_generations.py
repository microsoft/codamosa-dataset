

# Generated at 2022-06-12 00:30:15.423212
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    cookie_time = now - 10
    headers = [
        (
            'Set-Cookie',
            'foo=foo_value; expires=Fri, 27 Jul 2018 14:29:11 GMT',
        ),
        (
            'Set-Cookie',
            'bar=bar_value; expires={}; path=/'.format(
                time.strftime(
                    '%a, %d %b %Y %H:%M:%S %Z',
                    time.gmtime(cookie_time),
                ),
            ),
        ),
    ]
    assert get_expired_cookies(headers, now) == [{
        'name': 'bar',
        'path': '/'
    }]

# Generated at 2022-06-12 00:30:23.312683
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('image.png') == 'image/png'
    assert get_content_type('image.jpeg') == 'image/jpeg'
    assert get_content_type('image.jpg') == 'image/jpeg'
    assert get_content_type('image.jpe') == 'image/jpeg'
    assert get_content_type('image.jfif') == 'image/jpeg'
    assert get_content_type('image.svg') == 'image/svg+xml'



# Generated at 2022-06-12 00:30:33.344611
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:30:41.753975
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', r'c1=1; Max-Age=1; Path=/'),
        ('Set-Cookie', r'c2=2; Expires=Wed, 09 Jun 2021 10:18:14 GMT; Path=/'),
        ('Set-Cookie', r'c3=3; Expires=Wed, 09 Jun 2021 10:18:14 GMT; Path=/')
    ]
    cookies = get_expired_cookies(headers, now)
    print('cookies:', cookies)
    assert cookies == [
        {'name': 'c1', 'path': '/'},
    ]

    time.sleep(2)
    cookies = get_expired_cookies(headers, now=time.time())
    print('cookies:', cookies)

# Generated at 2022-06-12 00:30:46.390158
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    REQUEST = [
        ('Set-Cookie', 'foo=bar; max-age=3600; path=/'),
        ('Set-Cookie', 'boo=far; path=/; expires=Fri, 31-Dec-2017 23:59:59 GMT'),
    ]
    NOW = time.time()
    EXPECTED = [
        {'name': 'boo', 'path': '/'}
    ]
    assert get_expired_cookies(REQUEST, now=NOW) == EXPECTED

# Generated at 2022-06-12 00:30:55.995853
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    req = requests.Request('GET', 'http://example.com')
    resp = requests.Response()
    resp.request = req
    resp.headers = {
        'Content-Type': 'text/html',
        'Set-Cookie': (
            'session_id=fake-session-id; Path=/; Expires=Sat, 01 Jan '
            '2033 01:02:03 GMT; Secure'
        ),
        'Set-Cookie2': 'session_id=fake-session-id-2; Max-Age=1',
    }
    cookies = get_expired_cookies(resp.headers, now=0)
    assert len(cookies) == 1
    assert cookies[0] == {'name': 'session_id', 'path': '/'}

# Generated at 2022-06-12 00:30:59.755551
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("file.txt") == 'text/plain'
    assert get_content_type("file.txt;encoding=utf-8") == 'text/plain; charset=utf-8'



# Generated at 2022-06-12 00:31:10.922466
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    # High-level tests

    from pytest import approx

    now = time.time()

    # Test normal cases with known expiry dates.
    cookies = get_expired_cookies([
        ('Set-Cookie', 'foo=bar; Expires=Sun, 06 Nov 1994 08:49:37 GMT'),
    ])
    assert cookies == []

    cookies = get_expired_cookies([
        ('Set-Cookie', 'foo=bar; Expires={}'.format(now + 3600)),
    ], now=now)
    assert cookies == []

    cookies = get_expired_cookies([
        ('Set-Cookie', 'foo=bar; expires={}'.format(now + 3600)),
    ], now=now)
    assert cookies == []

    # Test expiry cases for all known scenarios.
    cookies = get_

# Generated at 2022-06-12 00:31:19.880766
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') is None
    assert get_content_type('foo.txt.gz') is None
    assert get_content_type('foo.txt.bz2') is None
    assert get_content_type('foo.csv') is None
    assert get_content_type('foo.csv.zip') is None
    assert get_content_type('foo.csv.bz2') is None

    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.json.gz') == 'application/json'
    assert get_content_type('foo.json.bz2') == 'application/json'
    assert get_content_type('foo.json.zip') == 'application/json'


# Generated at 2022-06-12 00:31:22.630986
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.json') == 'application/json'



# Generated at 2022-06-12 00:31:32.624758
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"foo":1}') == {"foo": 1}
    assert load_json_preserve_order('{"foo":1,"bar":2}') == {"foo": 1, "bar": 2}
    assert load_json_preserve_order('{"bar":2,"foo":1}') != {"foo": 1, "bar": 2}
    assert "foo" in repr(load_json_preserve_order('{"bar":2,"foo":1}'))
    assert "bar" in repr(load_json_preserve_order('{"bar":2,"foo":1}'))
    assert repr_dict(load_json_preserve_order('{"bar":2,"foo":1}')) == "{'bar': 2, 'foo': 1}"

# Generated at 2022-06-12 00:31:33.646136
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth



# Generated at 2022-06-12 00:31:43.788847
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 12342) == '12.05 MB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'


# Generated at 2022-06-12 00:31:46.007740
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == '<ExplicitNullAuth>'

# Generated at 2022-06-12 00:31:47.978150
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Tests for method __call__ of class ExplicitNullAuth
    # This method is a noop.
    pass

# Generated at 2022-06-12 00:31:48.621790
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(object()) is not None

# Generated at 2022-06-12 00:31:52.293500
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """ __call__ of class ExplicitNullAuth """
    r = requests.Request(method='GET', url='http://127.0.0.1:8080/')
    req = ExplicitNullAuth().__call__(r)
    assert isinstance(req, requests.Request)

# Generated at 2022-06-12 00:31:53.583151
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth(None) is None

# Generated at 2022-06-12 00:31:58.314771
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():

    class FakeResponse:
        def __init__(self, headers):
            self.headers = headers

        def info(self):
            return self.headers

    content_type = 'text/html; charset=utf-8'
    headers_as_tuple = [('Content-Type', content_type)]
    resp = FakeResponse(headers_as_tuple)
    res = ExplicitNullAuth()(resp)
    assert res.headers == headers_as_tuple

# Generated at 2022-06-12 00:32:03.871553
# Unit test for function humanize_bytes
def test_humanize_bytes():
    inputs = [
        (1, '1 B'),
        (1024, '1.00 kB'),
        (1024 * 123, '123.00 kB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
    ]
    for n, expected in inputs:
        assert expected == humanize_bytes(n, 2)

# Generated at 2022-06-12 00:32:17.867161
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:32:19.896727
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.jpg') == 'image/jpeg'
    assert get_content_type('example.txt') == 'text/plain'

# Generated at 2022-06-12 00:32:22.714554
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'foo': 1}) == "{'foo': 1}"
    assert repr_dict({'foo': 1, 'bar': 2}) == "{'foo': 1, 'bar': 2}"

# Generated at 2022-06-12 00:32:33.374310
# Unit test for function repr_dict
def test_repr_dict():
    d1 = {'a': 1, 'b': 2, 'c': 3}
    assert repr_dict(d1) == "{\n    'a': 1,\n    'b': 2,\n    'c': 3\n}"

    d2 = {
        'a': 1,
        'b': [2, 3],
        'c': {'a': 2}
    }
    assert repr_dict(d2) == """{
    'a': 1,
    'b': [
        2,
        3
    ],
    'c': {
        'a': 2
    }
}"""

    d3 = {
        'b': [2, 3],
        'a': 1,
        'c': {'a': 2}
    }

# Generated at 2022-06-12 00:32:42.194934
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # noinspection PyProtectedMember
    from .test_utils import _TestUtils
    from requests.cookies import RequestsCookieJar

    cookies = [
        ('SESSIONID', '12345'),
        ('SSO_SESSIONID', '67890'),
        ('expiring_cookie', '65'),
        ('simple_cookie', '4321'),
    ]
    headers = [
        ('Set-Cookie', '='.join(cookie) + '; Path=/; Domain=.domain.com; '
                                          'Expires=Tue, 31-Dec-2019 00:00:00 GMT')
        for cookie in cookies
    ]

    expired = get_expired_cookies(headers, now=_TestUtils.TEST_TIME)

# Generated at 2022-06-12 00:32:52.306957
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(2) == '2 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024 * 0.5) == '512.0 B'
    assert humanize_bytes(1024 * 0.51) == '511.0 B'
    assert humanize_bytes(1024 * 0.510) == '510.0 B'
    assert humanize_bytes(1024 * 0.51 + 1) == '511.0 B'
    assert humanize_bytes(1024 * 0.51 + 2) == '512.0 B'
    assert humanize_bytes(1024 * 0.5 + 2) == '512.0 B'

# Generated at 2022-06-12 00:32:59.976461
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Test whether __call__ loads the netrc file or not.
    # If it loads the netrc file, it will try to find a ``default``
    # machine, and if that doesn't exist, it will throw an error.
    # Use netrc here: <https://pythonhosted.org/netrc/>

    # Copy and paste of the source code at
    # <https://docs.python.org/3/library/netrc.html>
    # adapted to use the ExplicitNullAuth class.

    # Start of copy and paste from <https://docs.python.org/3/library/netrc.html>
    # Example of a .netrc file:
    #  machine foo.example.com login fred password "This is fred's password."
    #  default login jim password "This is jim's password."

    import netrc

# Generated at 2022-06-12 00:33:05.778619
# Unit test for function repr_dict
def test_repr_dict():
    _a = {
        'a': 'a',
    }

    _b = {
        'b': 'b'
    }

    assert repr_dict({'a': _a, 'b': _b}) == \
        "{'a': {'a': 'a'}, 'b': {'b': 'b'}}"
    assert repr_dict({'a': _a, 'b': _b}) == \
        repr_dict(_a) + repr_dict(_b)

# Generated at 2022-06-12 00:33:10.871558
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"foo": "bar"}') == {
        "foo": "bar"
    }
    assert load_json_preserve_order('{"foo1": "bar1", "foo2": "bar2"}') == {
        "foo1": "bar1",
        "foo2": "bar2"
    }

# Generated at 2022-06-12 00:33:12.445935
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # The method does nothing.
    pass

# Generated at 2022-06-12 00:33:20.746290
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.csv') == 'text/csv'
    assert get_content_type('test.mp4') == 'video/mp4'

# Generated at 2022-06-12 00:33:28.943861
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime
    import time

    now = time.time()
    headers = [
        ('Set-Cookie', 'a=b; path=/; Max-Age=5'),
        ('Set-Cookie', 'c=d; path=/; expires=%s' %
         datetime.datetime.utcfromtimestamp(now + 10).strftime(
             '%a, %d %b %Y %T GMT')),
        ('Set-Cookie', 'e=f; path=/; expires=%s' %
         datetime.datetime.utcfromtimestamp(now + 4).strftime(
             '%a, %d %b %Y %T GMT')),
        ('Set-Cookie', 'g=h; path=/'),
    ]

# Generated at 2022-06-12 00:33:39.770584
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime
    import pytest

    def check_cookies(
        headers,
        expected_cookies,
        now=None,
        check_path=True
    ) -> None:
        now = now or time.time()
        cookies = get_expired_cookies(headers, now=now)
        assert len(cookies) == len(expected_cookies)
        for expected_cookie in expected_cookies:
            cookie_by_name = next(
                cookie for cookie in cookies
                if cookie['name'] == expected_cookie['name']
            )
            assert cookie_by_name['name'] == expected_cookie['name']
            if check_path:
                assert cookie_by_name['path'] == expected_cookie['path']


# Generated at 2022-06-12 00:33:50.538888
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 12342) == '12.05 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 123, 2) == '123.00 kB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-12 00:33:51.399798
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-12 00:34:00.008474
# Unit test for function get_content_type
def test_get_content_type():
    # ``mimetypes`` has no knowledge of the ``.sh`` file type.
    assert get_content_type('test.sh') is None

    # For the ``.txt`` type, ``mimetypes`` knows the MIME type, but not
    # the encoding, so it doesn't return one.
    assert get_content_type('test.txt') == 'text/plain'

    # For the ``.csv`` type, ``mimetypes`` knows the MIME type and the
    # encoding, so it returns both.
    assert get_content_type('test.csv') == 'text/csv; charset=utf-8'


# Generated at 2022-06-12 00:34:02.927433
# Unit test for function repr_dict
def test_repr_dict():
    from pprint import pformat as ppf
    d = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {
            'e': 1,
            'f': 2,
        }
    }
    assert repr_dict(d) == ppf(d)

# Generated at 2022-06-12 00:34:14.590380
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import re

    test_cases = {
        '{"a": 1, "b": 2, "c": 3}': '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}',
        '{"c": 3, "b": 2, "a": 1}': '{\n    "c": 3,\n    "b": 2,\n    "a": 1\n}',
    }
    for json_string, expected_output in test_cases.items():
        result = load_json_preserve_order(json_string)
        match = re.match(r'\{\n(\s+).*\n\}', result)
        assert (match.group(1) == '    '), "Incorrect indentation of string: %s" % result
        result = result

# Generated at 2022-06-12 00:34:24.247053
# Unit test for function humanize_bytes

# Generated at 2022-06-12 00:34:31.132250
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('''{"a": "b"}''') == {'a': 'b'}
    assert load_json_preserve_order('''{"a": "b", "c": "d"}''') == {'a': 'b', 'c': 'd'}
    assert load_json_preserve_order('''{"a": "b", "c": "d", "e": "f"}''') == {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-12 00:34:51.597588
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-12 00:34:54.975450
# Unit test for function get_content_type
def test_get_content_type():
    """
    Only tests that the function works as expected.
    See :meth:`test_content_type` for sanity check.

    """
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.bin') is None

# Generated at 2022-06-12 00:35:05.513596
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-12 00:35:06.330699
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-12 00:35:12.701843
# Unit test for function repr_dict
def test_repr_dict():
    d1 = {'a': 0, 'b': 1}
    assert repr_dict(d1) == '{\'a\': 0, \'b\': 1}'
    d2 = {'a': 0, 'b': [1, 'foo', {'c': 1}]}
    assert repr_dict(d2) == """{
    \'a\': 0,
    \'b\': [
        1,
        \'foo\',
        {
            \'c\': 1
        }
    ]
}"""



# Generated at 2022-06-12 00:35:15.465676
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Smoke-test
    d = load_json_preserve_order('{"a": 1, "b": 2}')
    assert d == OrderedDict([('a', 1), ('b', 2)])

# Generated at 2022-06-12 00:35:25.440464
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest

    now = 0

    def get_expired_cookies(*args, **kwargs):
        return pytest.helpers.get_expired_cookies(
            *args,
            now=now,
            **kwargs
        )

    def assert_expired_cookies(expected_cookies, headers, now=0):
        for i, cookie in enumerate(get_expired_cookies(headers, now=now)):
            expected = expected_cookies[i]
            assert cookie == expected, cookie


# Generated at 2022-06-12 00:35:31.300034
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime


# Generated at 2022-06-12 00:35:32.155266
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-12 00:35:37.373432
# Unit test for function get_content_type
def test_get_content_type():
    from tempfile import mkstemp

    fd, fname = mkstemp(prefix='teste-', suffix='.txt')
    with open(fname, 'w') as f:
        f.write('oh hai caption')
    assert get_content_type(fname) == 'text/plain'

# Generated at 2022-06-12 00:35:59.290499
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """__call__

    Args:
        None

    Returns:
        None

    Raises:
        None

    """
    test_result = ExplicitNullAuth().__call__(None)
    assert test_result == None

# Generated at 2022-06-12 00:36:03.033725
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_string = """
    {"2": 3, "1": 2, "4": 5, "3": 4}
    """
    test_dict = load_json_preserve_order(test_string)
    assert "2" in test_dict
    assert "1" in test_dict



# Generated at 2022-06-12 00:36:10.264489
# Unit test for function load_json_preserve_order

# Generated at 2022-06-12 00:36:18.079179
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies(
        [
            ('Set-Cookie', 'csrftoken=foobar; Max-Age=999999999; '
                           'Path=/; HttpOnly'),
            ('Set-Cookie', 'expiring_cookie=foobar; Max-Age=0; '
                           'Path=/; HttpOnly'),
        ],
        now=time.time()
    )
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'expiring_cookie'
    assert cookies[0]['path'] == '/'

# Generated at 2022-06-12 00:36:18.906646
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)

# Generated at 2022-06-12 00:36:27.685914
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024 * 123) == '123.0 kB'
    assert humanize_bytes(1024 * 12342) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-12 00:36:36.997690
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = ('{"foo": "bar", "baz": [1, 2, 3, 4], '
                '"quux": {"a": 1, "b": 2, "c": "three"}}')
    result = load_json_preserve_order(json_str)
    assert result['baz'][0] == 1
    assert result == OrderedDict([('foo', 'bar'),
                                  ('baz', [1, 2, 3, 4]),
                                  ('quux', OrderedDict([('a', 1),
                                                        ('b', 2),
                                                        ('c', 'three')]))])

# Generated at 2022-06-12 00:36:40.356542
# Unit test for function repr_dict
def test_repr_dict():
    d = {'key0': 'value', 'key1': 'another value'}
    expected = "{'key0': 'value', 'key1': 'another value'}"
    assert repr_dict(d) == expected

# Generated at 2022-06-12 00:36:47.161598
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('test.txt')
    assert 'text/plain' == get_content_type('test.TXT')
    assert 'unknown/unknown' == get_content_type('test')
    assert 'image/jpeg' == get_content_type('test.jpeg')
    assert 'image/jpeg' == get_content_type('test.jpg')
    assert 'image/jpeg' == get_content_type('test.JPEG')
    assert 'image/jpeg' == get_content_type('test.JPG')
    assert 'image/png' == get_content_type('test.png')
    assert 'image/png' == get_content_type('test.PNG')

# Generated at 2022-06-12 00:36:52.009709
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": "b", "c": "d"}'
    ordered_dict = load_json_preserve_order(s)
    assert ordered_dict.items() == [('a', 'b'), ('c', 'd')]

# Generated at 2022-06-12 00:37:28.841746
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    req = object()
    obj = ExplicitNullAuth()
    assert obj(req) == req

# Generated at 2022-06-12 00:37:29.400424
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-12 00:37:30.369427
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(None) is None

# Generated at 2022-06-12 00:37:39.293273
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from http.cookiejar import CookieJar
    from io import BytesIO
    import requests

    cookie_jar = CookieJar()

    response = requests.Response()
    response.raw = BytesIO(b'')

    r = requests.Request(
        method='GET',
        url='http://localhost/',
        headers={
            'User-Agent': 'Mock',
        },
        cookies=cookie_jar,
    ).prepare()

    r.register_hook('response', ExplicitNullAuth())
    cookie_jar.extract_cookies(response, r)

    assert 'set-cookie' not in r.headers
    assert not cookie_jar



# Generated at 2022-06-12 00:37:42.705041
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    expected_result_type = type(requests.auth.HTTPBasicAuth('', ''))
    assert issubclass(
        type(ExplicitNullAuth()),
        expected_result_type
    )

# Generated at 2022-06-12 00:37:43.767899
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth(None) is None

# Generated at 2022-06-12 00:37:52.260563
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    def check(s, obj):
        assert load_json_preserve_order(s) == obj

    check("[]", [])
    check("{}", {})
    check("{\"a\": 1}", {"a": 1})
    check("{\"a\": 1, \"b\": 2}", {"a": 1, "b": 2})
    check("{\"a\": 1, \"b\": 2}", OrderedDict([("a", 1), ("b", 2)]))
    check("{\"b\": 2, \"a\": 1}", OrderedDict([("a", 1), ("b", 2)]))


# Generated at 2022-06-12 00:37:55.713839
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 'b', 'c': 'd'}
    assert repr_dict(d) == "{'a': 'b', 'c': 'd'}"



# Generated at 2022-06-12 00:37:59.704153
# Unit test for function get_content_type
def test_get_content_type():
    import os
    import sys
    dirname = os.path.dirname(__file__)
    filename = os.path.join(dirname, 'mimetypes.py')
    assert get_content_type(filename) == 'text/x-python'

# Generated at 2022-06-12 00:38:02.150145
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
    {
        "b": 2,
        "a": 1
    }
    """
    assert load_json_preserve_order(s) == {"a": 1, "b": 2}



# Generated at 2022-06-12 00:39:15.972040
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    try:
        Auth = ExplicitNullAuth()
    except NameError:
        raise AssertionError('Expected ExplicitNullAuth to be defined')

    assert Auth is not None

# Generated at 2022-06-12 00:39:18.394261
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'a': '1',
        'b': '2',
        'c': '3',
    }
    assert repr_dict(d) == "{'a': '1', 'b': '2', 'c': '3'}"

# Generated at 2022-06-12 00:39:28.990587
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('a.txt') == 'text/plain'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.svg') == 'image/svg+xml'
    assert get_content_type('a.x-svg') is None
    # Currently inconsistent with Google Chrome:
    # https://bugs.chromium.org/p/chromium/issues/detail?id=915931#c23
    assert get_content_type(
        'a.svgz'
    ) == 'application/x-gzip'
    assert get_content_type('a.png') == 'image/png'
    assert get_content_type('a.jpg') == 'image/jpeg'


# Generated at 2022-06-12 00:39:35.937838
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # no expired cookies
    cookies = get_expired_cookies([('Set-Cookie', 'name=value')])
    assert len(cookies) == 0

    # expired cookies
    cookies = get_expired_cookies([
        ('Set-Cookie', 'name=value'),
        ('Set-Cookie', 'name2=value; Expires=Sat, 01 Jan 2000 00:00:00 GMT')
    ])
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'name2'
    assert cookies[0]['path'] == '/'

# Generated at 2022-06-12 00:39:40.432805
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{ "a": 1, "b": 2 }'
    d_loaded = load_json_preserve_order(s)
    assert isinstance(d_loaded, OrderedDict)
    d_expected = OrderedDict([('a', 1), ('b', 2)])
    assert d_loaded == d_expected



# Generated at 2022-06-12 00:39:41.404789
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 00:39:43.808586
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    request = requests.Request('GET', 'https://gitlab.com')
    assert auth(request) == request

# Generated at 2022-06-12 00:39:47.957990
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({'a': 'b', 'c': 'd'}) == "{'a': 'b', 'c': 'd'}"
    assert repr_dict({}) == '{}'



# Generated at 2022-06-12 00:39:56.452379
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert(humanize_bytes(1)=='1 B')
    assert(humanize_bytes(1024, precision=1)=='1.0 kB')
    assert(humanize_bytes(1024 * 123, precision=1)=='123.0 kB')
    assert(humanize_bytes(1024 * 12342, precision=1)=='12.1 MB')
    assert(humanize_bytes(1024 * 12342, precision=2)=='12.05 MB')
    assert(humanize_bytes(1024 * 1234, precision=2)=='1.21 MB')
    assert(humanize_bytes(1024 * 1234 * 1111, precision=2)=='1.31 GB')
    assert(humanize_bytes(1024 * 1234 * 1111, precision=1)=='1.3 GB')

# Generated at 2022-06-12 00:39:58.103631
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    arg0 = None
    x = ExplicitNullAuth()
    return x.__call__(arg0)

