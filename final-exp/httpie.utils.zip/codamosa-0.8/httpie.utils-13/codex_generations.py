

# Generated at 2022-06-12 00:30:16.763500
# Unit test for function get_content_type
def test_get_content_type():
    from rst2html5slides.tests import testdir

    assert get_content_type(
        testdir / 'presentation.rst'
    ) == 'text/x-rst; charset=us-ascii'
    assert get_content_type(
        testdir / 'presentation.rst.html'
    ) == 'text/html; charset=us-ascii'

    assert get_content_type(
        testdir / 'presentation.rst.html.zip'
    ) == 'application/zip'
    assert get_content_type(
        testdir / 'presentation.html'
    ) == 'text/html; charset=us-ascii'

# Generated at 2022-06-12 00:30:18.640121
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.json') == 'application/json'

# Generated at 2022-06-12 00:30:23.887288
# Unit test for function get_content_type
def test_get_content_type():
    test_file_types = [('file.txt', 'text/plain'),
                       ('file.txt.gz', 'application/x-gzip')]
    for file_info in test_file_types:
        assert get_content_type(file_info[0]) == file_info[1]

# Generated at 2022-06-12 00:30:34.825183
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    headers = [
        ('Set-Cookie', 'sessionid=123; path=/; expires=Sun, 07 Feb 2030'),
        ('Set-Cookie', 'other=456; path=/; max-age=0'),
        ('Set-Cookie', 'some=789; path=/; Max-Age=86400'),
        ('Set-Cookie', 'one=456; path=/; expires=Mon, 02 Feb 2031'),
        ('Set-Cookie', 'two=456; path=/; expires=Tue, 03 Feb 2032'),
        ('Set-Cookie', 'three=456; path=/; expires=Wed, 04 Feb 2033'),
        ('Set-Cookie', 'four=456; path=/; expires=Thu, 05 Feb 2034')
    ]


# Generated at 2022-06-12 00:30:42.054267
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil import tz
    from dateutil.parser import parse
    import pytest

    now = datetime.now(tz=tz.tzutc()).timestamp()

# Generated at 2022-06-12 00:30:52.390314
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import unittest
    import datetime

    class TestGetExpiredCookies(unittest.TestCase):
        def test_get_expired_cookies(self):
            max_age_headers = [
                'foo=bar; Max-Age=1000',
            ]
            max_age_cookies = get_expired_cookies(
                headers=[
                    (name, value)
                    for name, value in (header.split(': ', 1)
                                        for header in max_age_headers)
                ]
            )
            self.assertEqual(max_age_cookies, [])

            max_age_headers = [
                'foo=bar; Max-Age=0',
            ]

# Generated at 2022-06-12 00:30:59.996093
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import timedelta

    from requests.structures import CaseInsensitiveDict

    now = time.time()
    expire_at = now + timedelta(seconds=1).total_seconds()

    headers = CaseInsensitiveDict([
        ('set-cookie', 'yummy_cookie=choco; Expires={}'.format(
            time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime(expire_at)))),
        ('set-cookie', 'tasty_cookie=strawberry'),
    ])

    # Make sure that the first cookie expires.
    time.sleep(1)

# Generated at 2022-06-12 00:31:02.445305
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.js') == 'application/javascript'

# Generated at 2022-06-12 00:31:13.686200
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from pprint import pprint


# Generated at 2022-06-12 00:31:16.576170
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.jpg') == 'image/jpeg'
    assert get_content_type('filename.jpeg') == 'image/jpeg'
    assert get_content_type('filename') is None

# Generated at 2022-06-12 00:31:29.144880
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime
    from pytz import UTC
    from freezegun import freeze_time

    response_headers = [
        ('Set-Cookie', 'a=1; Max-Age=10; Path=/'),
        ('Set-Cookie', 'b=1'),
        ('Set-Cookie', 'c=1; Max-Age=0; Path=/'),
        ('Set-Cookie', 'd=1; Max-Age=5; Path=/'),
        ('Set-Cookie', 'e=1; Max-Age=15; Path=/'),
    ]

    expected_expired_cookies = [
        {'name': 'c', 'path': '/'},
    ]


# Generated at 2022-06-12 00:31:39.653439
# Unit test for function get_content_type

# Generated at 2022-06-12 00:31:43.696978
# Unit test for function get_content_type
def test_get_content_type():
    """Test get_content_type function"""
    assert get_content_type('zzz_xxx') == None
    assert get_content_type('zzz.pdf') != None


# Generated at 2022-06-12 00:31:54.132473
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from requests import Session
    from http.cookies import SimpleCookie

    def build_expiry_datetime(delta=None):
        return datetime.utcnow() + (delta or timedelta(minutes=5))

    def build_ns_headers(cookie_str, expires=None):
        if expires is None:
            expires = build_expiry_datetime()
        cookie = SimpleCookie(cookie_str)
        cookie['name']['expires'] = expires.strftime("%a, %d-%b-%Y %H:%M:%S GMT")
        return cookie


# Generated at 2022-06-12 00:32:04.572981
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    cookie_attrs_lists = [
        {
            'name': 'foo',
            'value': 'bar',
            'expires': 0,
        },
        {
            'name': 'foo1',
            'value': 'bar1',
            'expires': now,
        },
        {
            'name': 'foo2',
            'value': 'bar2',
            'expires': now + 1
        },
        {
            'name': 'foo3',
            'value': 'bar3',
            'max-age': '1'
        },
    ]
    # Get the cookie attributes as HTTP headers
    headers = []

# Generated at 2022-06-12 00:32:16.685208
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Cookie with max-age
    headers = [
        ('Set-Cookie', 'foo=bar; max-age=31536000; Path=/')
    ]
    now = time.time()
    cookies = get_expired_cookies(headers, now=now)
    assert cookies == [
        {
            'name': 'foo',
            'path': '/'
        }
    ]
    # Cookie with max-age and expires
    headers = [
        ('Set-Cookie', 'foo=bar; max-age=31536000; expires=Sat, '
                       '31 Jan 1998 21:22:01 GMT; Path=/')
    ]
    cookies = get_expired_cookies(headers, now=now)

# Generated at 2022-06-12 00:32:25.015233
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Test data from https://en.wikipedia.org/wiki/HTTP_cookie
    # Should return the cookie called "valid-cookie"
    # and the cookie called "session-cookie"
    # They both expire 2016-09-01 11:20:00
    from datetime import datetime
    now = datetime.utcfromtimestamp(1472700800)

# Generated at 2022-06-12 00:32:34.423001
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    import pytz
    now = datetime(2019, 3, 9, 0, 0, tzinfo=pytz.utc)

# Generated at 2022-06-12 00:32:42.818849
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    import iso8601
    now = datetime.utcnow()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Max-Age=1'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=%s' % (now + timedelta(seconds=1)).isoformat()),
        ('Set-Cookie', 'baz=bazoo; Path=/; Max-Age=1'),
    ]
    assert get_expired_cookies(headers, now=now.timestamp()) == [{'name': 'foo', 'path': '/'}]

# Generated at 2022-06-12 00:32:52.705159
# Unit test for function get_content_type
def test_get_content_type():
    # This is a list of filename extensions that should be treated as text
    # and loaded as ASCII.
    ASCII_EXTENSIONS = [
        'ref', 'fasta', 'fna', 'gff', 'vcf', 'txt', 'tsv', 'csv', 'tab',
        'bam', 'bed', 'srt', 'sra', 'sff', 'xml', 'sam', 'json', 'fastq',
        'fa', 'fq', 'md', 'html', 'htm', 'css', 'js', 'exp'
    ]

    for ex in ASCII_EXTENSIONS:
        assert get_content_type(f'filename.{ex}').startswith('text/')


# Generated at 2022-06-12 00:33:04.105196
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    expired_cookies = get_expired_cookies([
        ('Set-Cookie', 'foo=bar; expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'bar=foo; max-age=1'),
        ('Set-Cookie', 'baz=re; path=/baz; max-age=123'),
    ], now=time.time())
    assert expired_cookies == [
        {
            'name': 'bar',
            'path': '/',
        },
    ]

# Generated at 2022-06-12 00:33:14.983573
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None

    assert get_content_type('mail.txt') == 'text/plain'

    assert get_content_type('index.html') == 'text/html'

    assert get_content_type('image.jpeg') == 'image/jpeg'

    assert get_content_type('file.txt') == 'text/plain'

    assert get_content_type('test.md') == 'text/x-markdown'

    assert get_content_type('test.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'

    assert get_content_type('test.py') == 'text/x-python'

    assert get_content_type('test.c') == 'text/x-c'


# Generated at 2022-06-12 00:33:23.755942
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies(headers=[
        ('Set-Cookie', 'foo=bar'),
        ('Set-Cookie', 'bar=zoo; Max-Age=60'),
        ('Set-Cookie', 'baz=zoo; Expires=Wed, 13-Jan-2021 22:23:01 GMT'),
        ('Set-Cookie', 'qux=quux; Max-Age=0')
    ], now=120)
    assert cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'qux', 'path': '/'}
    ]

# Generated at 2022-06-12 00:33:30.482114
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'session_id=abc; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'session_id=abc; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'session_id=abc; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'session_id=abc; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'session_id=abc; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'session_id=abc; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]

# Generated at 2022-06-12 00:33:40.692132
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'sess1=value1; path=/; Max-Age=3600; Expires=Tue, '
                       '27 Jun 2017 12:50:59 GMT'),
        ('Set-Cookie', 'sess2=value2; path=/; Max-Age=3600; Expires=Wed, '
                       '28 Jun 2017 12:50:59 GMT'),
        ('Set-Cookie', 'sess3=value3; path=/; Max-Age=3600; Expires=Thu, '
                       '29 Jun 2017 12:50:59 GMT'),
    ]
    now = time.time()
    cookies = get_expired_cookies(headers, now)
    assert len(cookies) == 2
    # The last cookie is not expired

# Generated at 2022-06-12 00:33:52.406097
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    # An expired cookie
    cookie_tuples_1 = [
        ('Set-Cookie', 'session=bar; expires=Thu, 01 Jan 1970 00:00:00 GMT'),
    ]

    # An expired cookie
    cookie_tuples_2 = [
        ('Set-Cookie', 'session=bar; max-age=0; path=/'),
    ]

    # An expired cookie
    cookie_tuples_3 = [
        ('Set-Cookie', 'session=bar; expires=0; path=/'),
    ]

    # An expired cookie
    expires = time.time() - 1
    cookie_tuples_4 = [
        ('Set-Cookie', 'session=bar; expires=%s; path=/' % expires),
    ]

    # A non-expired cookie

# Generated at 2022-06-12 00:34:02.508930
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    # Test 1

# Generated at 2022-06-12 00:34:14.126635
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:34:23.809815
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    expeceted = [
        {'name': 'expired1', 'path': '/'},
        {'name': 'expired2', 'path': '/'},
    ]
    result = get_expired_cookies([
        ('Set-Cookie', 'expired1=1; expires=Tue, 30 Oct 2018 18:49:38 GMT'),
        ('Set-Cookie', 'expired2=1; max-age=30'),
        ('Set-Cookie', 'not_expired1=1; expires=Tue, 30 Oct 2018 19:49:38 GMT'),
        ('Set-Cookie', 'not_expired2=1; max-age=63000'),
        ('Set-Cookie', 'not_expired3=1'),
    ], now)
    assert result == expecet

# Generated at 2022-06-12 00:34:33.281120
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'baz=quux; expires=Wed, 29 Oct 2025 20:00:00 GMT'),
        ('Set-Cookie', 'abc=def; expires=Sun, 06 Nov 1994 08:49:37 GMT'),
        ('Set-Cookie', 'xyz=123; max-age=600'),
    ]

    cookies = get_expired_cookies(headers, now=time.mktime((2018, 1, 1, 0, 0, 0, 0, 0, 0)))

    assert len(cookies) == 2

    # Both of the following tests depend on insertion order of dicts, which
    # is preserved in Python 3.6+ (GitHub issue #558)
    assert cookies

# Generated at 2022-06-12 00:34:37.984224
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.md') == 'text/plain'
    assert get_content_type('file.docx') == 'application/vnd.openxmlformats-' \
                                           'officedocument.wordprocessingml.' \
                                           'document'



# Generated at 2022-06-12 00:34:49.838142
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.html') == 'text/html'
    assert get_content_type('example.css') == 'text/css'
    assert get_content_type('example.csv') == 'text/csv'
    assert get_content_type('example.js') == 'application/javascript'
    assert get_content_type('example.json') == 'application/json'
    assert get_content_type('example.xml') == 'application/xml'
    assert get_content_type('example.pdf') == 'application/pdf'
    assert get_content_type('example.pkl') == 'application/octet-stream'
    assert get_content_type('example.txt') is None
    assert get_content_type('example.notdef') is None

# Generated at 2022-06-12 00:34:57.748842
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.js.gz') == 'application/javascript; charset=gzip'
    assert get_content_type('foo.js.bz2') == 'application/javascript; charset=bzip2'
    assert get_content_type('foo.js.lzma') == 'application/javascript; charset=x-lzma'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-12 00:35:03.196662
# Unit test for function get_content_type
def test_get_content_type():
    # Build local fixture
    filename = 'test_file.txt'
    with open(filename, 'w') as f:
        f.write('hello world')
    content_type = get_content_type(filename)
    # Run actual test
    assert content_type == 'text/plain'


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-12 00:35:05.403447
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.txt.gz') == 'application/gzip'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpg.tar') == 'application/x-tar'

# Generated at 2022-06-12 00:35:14.681722
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('hello.txt') == 'text/plain'
    assert get_content_type('hello.json') == 'application/json'
    assert get_content_type('hello.js') == 'application/javascript'
    assert get_content_type('hello.pdf') == 'application/pdf'
    assert get_content_type('hello.exe') is None
    assert get_content_type('hello.jpg') == 'image/jpeg'
    assert get_content_type('hello.jpeg') == 'image/jpeg'
    assert get_content_type('hello.JPG') == 'image/jpeg'
    assert get_content_type('hello.JPEG') == 'image/jpeg'
    # This is odd but it is how mimetypes works.

# Generated at 2022-06-12 00:35:20.302120
# Unit test for function get_content_type
def test_get_content_type():
    assert (get_content_type('toy.tar') == 'application/x-tar')
    assert (get_content_type('toy.gz') == 'application/gzip')
    assert (get_content_type('toy.tar.gz') == 'application/x-gtar')
    assert (get_content_type('README') is None)



# Generated at 2022-06-12 00:35:22.634029
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'

# Generated at 2022-06-12 00:35:29.966953
# Unit test for function get_content_type

# Generated at 2022-06-12 00:35:41.467691
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.txt') == 'text/plain'
    assert get_content_type('example.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('example.txt.gz') == 'application/gzip'
    assert get_content_type('example.txt.tar.gz') == 'application/gzip'
    assert get_content_type('example.bat') == 'application/x-msdownload'
    assert get_content_type('example.exe') == 'application/x-msdownload'
    assert get_content_type('example.zip') == 'application/zip'
    assert get_content_type('example.html') == 'text/html'
    assert get_content_type('example.htm') == 'text/html'
    assert get_content_