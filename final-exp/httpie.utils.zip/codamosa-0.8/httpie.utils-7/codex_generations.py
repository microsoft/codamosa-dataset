

# Generated at 2022-06-12 00:30:16.413960
# Unit test for function get_content_type
def test_get_content_type():
    def check(filename, expected):
        assert get_content_type(filename) == expected

    check('image.jpeg', 'image/jpeg')
    check('image.jpg', 'image/jpeg')
    check('image.png', 'image/png')
    check('image.pdf', 'application/pdf')
    check('image.rar', 'application/x-rar-compressed')
    check('plain_text.txt', 'text/plain')
    check('empty.txt', 'text/plain')
    check('empty.txt.gz', 'application/gzip')
    check('nonexistent.txt', None)

# Generated at 2022-06-12 00:30:27.236514
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from requests.cookies import create_cookie

    now = datetime.utcnow()

    def get_expired_cookies(
        expired: datetime,
        now: datetime = now,
    ) -> List[dict]:
        return get_expired_cookies(
            headers=[
                ('set-cookie', create_cookie(
                    name='foo',
                    value='bar',
                    path='/',
                    expires=expired.timestamp(),
                    discard=True,
                ).output(header=''))
            ],
            now=now.timestamp(),
        )

    # no expiration
    assert [] == get_expired_cookies(
        expired=now + timedelta(days=1),
    )
    # with expiration

# Generated at 2022-06-12 00:30:35.643227
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'key=value'),
        ('Set-Cookie', 'expired_key=expired_value; Expires=Tue, 01-Jan-1980 00:00:00 GMT'),
        ('Set-Cookie', 'maxage_key=maxage_value; Max-Age=60'),
    ]
    expired_cookies = get_expired_cookies(headers)
    assert len(expired_cookies) == 1
    assert expired_cookies[0] == {'name': 'expired_key', 'path': '/'}



# Generated at 2022-06-12 00:30:47.820523
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from munch import Munch
    from hypothesis import given
    from hypothesis.strategies import text, lists, permutations

    @given(
        cookies=permutations(
            lists(
                text(),
                min_size=2,
                max_size=2
            ),
            min_size=1,
            max_size=100
        ),
        now=text(min_size=1),
    )
    def test_cookies_expiration(cookies, now):
        # The hypothesis strategy `text()` matches empty strings,
        # so we should avoid them in the headers.
        headers: List[Tuple[str, str]] = [
            ('Set-Cookie', '; '.join(cookie))
            for cookie in cookies
        ]
        cookies = get_expired_cookies(headers, float(now))


# Generated at 2022-06-12 00:30:57.557283
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:31:02.063613
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('image.jpg') == 'image/jpeg'
    assert get_content_type('video.mp4') == 'video/mp4'
    assert get_content_type('foo.bar') == 'application/octet-stream'
    assert get_content_type('.hidden') is None

# Generated at 2022-06-12 00:31:08.238160
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('some.unknown') is None
    assert get_content_type('setup.py') == 'text/x-python'
    assert get_content_type('some.png') == 'image/png'
    assert get_content_type('some.gif') == 'image/gif'
    assert get_content_type('some.svg') == 'image/svg+xml'

# Generated at 2022-06-12 00:31:17.160542
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = [
        'foo=bar, path=/, expires=Wed, 21 Oct 2020 07:28:00 GMT',
        'baz=bonk; path=/; expires=Tue, 18 Oct 2016 07:28:00 GMT',
        'ding=dong; path=/; Max-Age=5, baz=bonk',
        'baz=bonk, path=/, Max-Age=5',
    ]
    now = time.time()

    assert (
        get_expired_cookies(cookies, now=now) == [
            {'name': 'baz', 'path': '/'},
            {'name': 'ding', 'path': '/'},
        ]
    )



# Generated at 2022-06-12 00:31:22.868187
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.py') == 'text/x-python'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-12 00:31:28.409466
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.pdf') == 'application/pdf'
    assert get_content_type('file.tar.gz') == 'application/x-gzip'
    assert get_content_type('file.json') == 'application/json'
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.not_registered') is None

# Generated at 2022-06-12 00:31:40.133025
# Unit test for function humanize_bytes

# Generated at 2022-06-12 00:31:41.232295
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-12 00:31:41.951770
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-12 00:31:52.544653
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-12 00:31:59.715960
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:32:00.256540
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert True

# Generated at 2022-06-12 00:32:01.745047
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)


# Generated at 2022-06-12 00:32:06.273873
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import pytest

    @pytest.fixture
    def request(monkeypatch):
        request = requests.Request('GET', 'https://example.com')
        request.auth = ExplicitNullAuth()
        request.parsed_netrc = ('login', 'password')
        return request

    def test_request_parsed_netrc_is_None(request):
        request.auth(request)
        assert request.parsed_netrc is None
    return test_request_parsed_netrc_is_None

# Generated at 2022-06-12 00:32:17.863522
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from nose.tools import assert_equal


# Generated at 2022-06-12 00:32:20.677483
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == \
           OrderedDict([('a', 1), ('b', 2)])

