

# Generated at 2022-06-12 00:30:19.817283
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([
        ('Set-Cookie', 'X=Y; Path=/; Expires=Sat, 05 Jan 2019 09:11:00 GMT')
    ]) == [{
        'name': 'X',
        'path': '/'
    }]
    assert get_expired_cookies([
        ('Set-Cookie', 'X=Y; Path=/; Max-Age=0')
    ], now=1546397860) == [{
        'name': 'X',
        'path': '/'
    }]
    assert get_expired_cookies([
        ('Set-Cookie', 'X=Y; Path=/')
    ]) == []

# Generated at 2022-06-12 00:30:22.910974
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/file/with/name.tar.gz') \
        == 'application/x-gzip'



# Generated at 2022-06-12 00:30:26.661186
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.db') == 'application/octet-stream'

# Generated at 2022-06-12 00:30:37.390616
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=2; Max-Age=200; path=/'),
        ('Set-Cookie', 'b=1; Max-Age=100; expires=Tue, 07 Aug 2018 21:24:11 GMT; path=/'),
        ('Set-Cookie', 'c=3; Max-Age=300; expires=Tue, 07 Aug 2018 21:24:11 GMT; path=/'),
        ('Set-Cookie', 'd=4; Max-Age=400; expires=Tue, 07 Aug 2018 21:24:11 GMT; path=/'),
    ]
    now = time.time()


# Generated at 2022-06-12 00:30:48.940398
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:30:55.626016
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.csv') == 'text/csv'
    assert get_content_type('file.svg') == 'image/svg+xml'
    assert get_content_type('file.gz') == 'application/gzip'
    assert get_content_type('file.zip') == 'application/zip'
    assert get_content_type('file.jpeg') == 'image/jpeg'



# Generated at 2022-06-12 00:31:07.214262
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from . import utils
    from .utils import get_expired_cookies

    def get_response_headers(cookies):
        headers = []
        for cookie in cookies:
            for attr_name, attr_value in cookie.items():
                headers.append(('Set-Cookie', '{}={}'.format(attr_name, attr_value)))
        return headers

    now = time.time()
    cookies = [
        {
            'expires': now + 10
        },
        {
            'max-age': 10
        },
        {
            'max-age': 10,
            'expires': now + 20
        },
        {
            'max-age': '10'
        }
    ]

# Generated at 2022-06-12 00:31:09.699231
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.PDF') == 'application/pdf'



# Generated at 2022-06-12 00:31:15.741657
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'name=value; Expires=Wed, 07-Aug-2019 18:05:00 GMT'),
        ('Set-Cookie', 'name1=value; Expires=Wed, 07-Aug-2019 18:05:00 GMT;'),
    ]
    assert get_expired_cookies(headers) == [{'name': 'name'}, {'name': 'name1', 'path': '/'}]

# Generated at 2022-06-12 00:31:24.872887
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    past = time.time() - 1
    future = time.time() + 60

    cookies = get_expired_cookies([
        ('Set-Cookie', 'a=b; Path=/'),
        ('Set-Cookie', 'c=d; Path=/xyz; Expires=%s; Max-Age=1' % past),
        ('Set-Cookie', 'e=f; Path=/xyz; Expires=%s; Max-Age=10' % future),
    ], now=past)

    assert cookies == [
        {'name': 'c', 'path': '/xyz'},
    ]