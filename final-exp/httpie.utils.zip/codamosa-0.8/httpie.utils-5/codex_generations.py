

# Generated at 2022-06-12 00:30:22.990376
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    expired_cookies = get_expired_cookies(
        [(
            'Set-Cookie',
            'a=b; Path=/'
        ), (
            'Set-Cookie',
            'c=d; Max-Age=1'
        ), (
            'Set-Cookie',
            'e=f; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT'
        )],
        time.time() + 2
    )
    assert len(expired_cookies) == 2
    assert expired_cookies[0] == {'name': 'c', 'path': '/'}
    assert expired_cookies[1] == {'name': 'e', 'path': '/'}


# Generated at 2022-06-12 00:30:28.926150
# Unit test for function get_content_type
def test_get_content_type():
    assert(
        get_content_type('test/data/test_file.txt') ==
        'text/plain; charset=us-ascii'
    )
    assert get_content_type('test/data/test_file.txt.gz') is None
    assert get_content_type('test/data/test_file.bz2') is None
    assert get_content_type('test/data/test_file.csv') == 'text/csv'

# Generated at 2022-06-12 00:30:36.533316
# Unit test for function get_content_type
def test_get_content_type():
    """
    >>> test_get_content_type()
    """

    filename = 'foo.png'
    expected_content_type = 'image/png'
    content_type = get_content_type(filename)
    assert content_type == expected_content_type, (
        'Expected: %s\nGot: %s' % (expected_content_type, content_type)
    )


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 00:30:39.771315
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/tmp/foo') == 'text/x-c'
    assert get_content_type('/tmp/foo.txt') == 'text/plain'
    assert get_content_type('/tmp/foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('/tmp/foo.bin') is None

# Generated at 2022-06-12 00:30:43.214287
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('x.txt') == 'text/plain'
    assert get_content_type('x.txt; charset=utf-8') == 'text/plain; charset=utf-8'

# Generated at 2022-06-12 00:30:46.609854
# Unit test for function get_content_type
def test_get_content_type():
    from io import StringIO

    from pytest import raises

    from .script import ScriptBase

    class TestScript(ScriptBase):
        def run(self):
            with raises(SystemExit):
                self.get_content_type(StringIO('foo'))

    TestScript().catch_and_exit()

# Generated at 2022-06-12 00:30:56.519306
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import os
    import sys
    import unittest
    from datetime import datetime, timedelta

    my_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(os.path.join(my_path, '../demo_requests/'))
    from demo_requests import make_test_request

    cookies_db = {
        'max-age': {
            'max-age': '30',
            'expires': datetime.now() + timedelta(seconds=30),
        },
        'expires': {
            'expires': datetime.now() - timedelta(seconds=0.5),
        },
        'no_expires': {
            'expires': None,
        },
    }


# Generated at 2022-06-12 00:31:08.333476
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import unittest
    class Test(unittest.TestCase):
        def setUp(self):
            self.now = 1422208048.345869
            # Cookie has no max-age or expires, so should never expire
            self.headers_session = [
                ('Set-cookie', 'sessionid="123"; Path=/'),
            ]
            # Cookie has max-age, so should expire at now + max_age
            self.headers_session_max_age = [
                ('Set-cookie', 'sessionid="123"; Path=/; Max-age=123')
            ]
            # Cookie has expires, so should expire at the given time

# Generated at 2022-06-12 00:31:11.311609
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('bar.txt') == 'text/plain'
    assert get_content_type('baz.gz') is None

# Generated at 2022-06-12 00:31:20.079698
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:31:29.507375
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies(
        [
            ('Set-Cookie',
             'ABC=123; path=/'),
            ('Set-Cookie',
             'DEF=456; path=/; expires=Sat, 17 Jun 2017 09:48:36 GMT'),
            ('Set-Cookie',
             'GHI=789; path=/; expires=Sat, 16 Jun 2018 09:48:36 GMT'),
        ])
    assert cookies == [{'name': 'DEF', 'path': '/'}], \
           'Wrong expired cookies.'

# Generated at 2022-06-12 00:31:40.039709
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Test expired cookie
    headers = [
        ('Location', 'https://example.com/'),
        (
            'Set-cookie',
            'sessionid=abcd; expires=Fri, 31 Dec 1999 23:59:59 GMT;'
            ' Max-Age=0; Path=/'
        )
    ]
    expected = [{'name': 'sessionid', 'path': '/'}]
    result = get_expired_cookies(headers)
    assert result == expected

    # Test non expired cookie
    headers = [
        ('Location', 'https://example.com/'),
        (
            'Set-cookie',
            'sessionid=abcd; expires=Wed, 31 Mar 2021 00:00:00 GMT;'
            ' Max-Age=3600; Path=/'
        )
    ]
    expected = []


# Generated at 2022-06-12 00:31:51.821908
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1549881824.0
    headers = [
        ('Set-Cookie', 'foo=bar; Expires=Fri, 15-Feb-19 10:12:03 GMT; Path=/; HttpOnly; SameSite=Strict'),
        ('Set-Cookie', 'baz=quux; Expires=Fri, 15-Feb-19 09:40:24 GMT; Path=/some; HttpOnly; SameSite=Strict'),
        ('Set-Cookie', 'quux=bla; Max-Age=28800; Path=/; HttpOnly; SameSite=Strict'),
    ]
    cookies = get_expired_cookies(headers=headers, now=now)

# Generated at 2022-06-12 00:31:59.131885
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.utcnow()
    expired_cookie_name = 'expires=bar'
    expired_cookie_value = 'foo=%s' % (
        (now - timedelta(minutes=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')
    )
    expired_cookie = expired_cookie_name + '; ' + expired_cookie_value
    cookies = [
        ('Set-Cookie', expired_cookie),
        ('Content-Type', 'text/plain'),
    ]
    assert get_expired_cookies(headers=cookies, now=time.time()) == [
        {'name': 'foo', 'path': '/'}
    ]

# Generated at 2022-06-12 00:32:06.837838
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # FIXME: Ensure that this test is exercising the functionality that it is
    # supposed to be exercising. It isn't clear how to do that.
    headers = [
        ('Set-Cookie', 'a=b; path=/; Expires=Thu, 01-Jan-1970 00:00:00 GMT'),
        ('Set-Cookie', 'c=d; path=/; max-age=0'),
        ('Set-Cookie', 'e=f; path=/; Expires=Thu, 01-Jan-1970 00:00:00 GMT'),
        ('Set-Cookie', 'g=h; path=/; Expires=Thu, 01-Jan-1970 00:00:00 GMT'),
        ('Set-Cookie', 'i=j; path=/; Expires=Thu, 01-Jan-1970 00:00:00 GMT'),
    ]

# Generated at 2022-06-12 00:32:18.335555
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from requests.cookies import RequestsCookieJar

    cookie_headers = [
        ('Set-Cookie', 'foo1=bar1; Path=/'),
        ('Set-Cookie', 'foo2=bar2; Path=/'),
        ('Set-Cookie', 'foo3=bar3; Path=/; Max-Age=1'),
        ('Set-Cookie', 'foo4=bar4; Path=/; Expires=Sat, 01 Jan 2000 00:00:00 GMT'),
        ('Set-Cookie', 'foo5=bar5; Path=/; Expires=Fri, 31 Jan 3000 00:00:00 GMT'),
        ('Set-Cookie', 'foo6=bar6; Path=/; Expires=Fri, 31 Jan 3000 00:00:00 GMT'),
    ]

    now = time.time()
    # expires=Fri, 31 Jan 3000

# Generated at 2022-06-12 00:32:25.785298
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime

    cookie_str1 = 'sessionid=123; expires=Mon, 20 Aug 2018 14:05:34 GMT; Max-Age=1209600; Path=/'
    cookie_str2 = 'sessionid=124; expires=Wed, 29 Jul 2020 15:30:00 GMT; Max-Age=1209600; Path=/'
    cookie_str3 = 'sessionid=125; Max-Age=1209600; Path=/'
    cookies1 = get_expired_cookies([('Set-Cookie', cookie_str1)])
    assert len(cookies1) == 1
    assert cookies1[0] == {'name': 'sessionid', 'path': '/'}
    cookies2 = get_expired_cookies([('Set-Cookie', cookie_str2)])
    assert len(cookies2) == 0

# Generated at 2022-06-12 00:32:34.854635
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Given
    headers = [
        ('Set-Cookie', 'session=12345; expires=Wed, 09 Jun 2021 10:18:14 GMT; HttpOnly; SameSite=Strict'),
        ('Set-Cookie', 'lang=sv; Domain=.example.com; Expires=Tue, 11-Sep-2030 11:53:50 GMT; Secure; SameSite=None'),
        ('Set-Cookie', 'lang=en; Domain=.example.com; Expires=Tue, 11-Sep-2025 11:53:50 GMT; Secure; SameSite=none'),
        ('Set-Cookie', 'max-age=3600; Expires=Wed, 11 Nov 2020 16:02:14 GMT; path=/')
    ]
    expiry_time = time.time() + 3600 * 1.5

    # When

# Generated at 2022-06-12 00:32:43.707999
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    now = time.time()
    future = now + 100
    past = now - 100
    headers = [
        ('Set-Cookie', 'name1=value1;'),
        ('Set-Cookie', 'name2=value2; Expires=Wed, 23 Jan 2019 14:56:20 GMT'),
        ('Set-Cookie', 'name3=value3; Expires=Wed, 23 Jan 1968 14:56:20 GMT'),
        ('Set-Cookie', f'name4=value4; Max-Age={future}'),
        ('Set-Cookie', f'name5=value5; Max-Age={past}'),
    ]
    cookies = get_expired_cookies(headers=headers, now=now)
    assert cookies == [{'name': 'name5', 'path': '/'}]

# Generated at 2022-06-12 00:32:53.125536
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta


# Generated at 2022-06-12 00:32:56.017434
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert hasattr(auth, '__call__')

# Generated at 2022-06-12 00:33:05.372104
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = [
        ('set-cookie', 'foo=bar; path=/'),
        ('set-cookie', 'foo=bar'),
        ('set-cookie', 'baz=qux; domain=example.com; path=/path')
    ]
    assert get_expired_cookies(headers=cookies) == [
        {
            'name': 'foo',
            'path': '/'
        },
        {
            'name': 'foo',
            'path': '/'
        },
        {
            'name': 'baz',
            'path': '/path'
        }
    ]



# Generated at 2022-06-12 00:33:16.808153
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '''{
      "key1": [1, 2, 3, 4],
      "key2": ["a", "b", "c", "d"],
      "key3": {
        "key31": 1,
        "key32": "a",
        "key33": [
          1,
          2,
          3
        ]
      }
    }'''
    json_obj = load_json_preserve_order(json_string)
    assert json_obj == json.loads(json_string)

# Generated at 2022-06-12 00:33:26.567298
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil import parser, tz

    headers = [
        ('Set-Cookie', 'c1=v1; Path=/p1; Max-Age=60'),
        ('Set-Cookie', 'c2=v2; Path=/p2; Max-Age=90'),
        ('Set-Cookie', 'c3=v3; Path=/p3; Max-Age=120'),
        ('Set-Cookie', 'c4=v4; Path=/p4'),
        ('Set-Cookie', 'c5=v5; Path=/p5; Expires=Fri, 10 Aug 2012 20:18:27 GMT'),
    ]

    now = datetime.now(tz.tzutc()).timestamp()

# Generated at 2022-06-12 00:33:37.968887
# Unit test for function humanize_bytes
def test_humanize_bytes():
    """Tests that humanize_bytes returns expected values."""

    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-12 00:33:44.448975
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():

    from requests.auth import HTTPBasicAuth
    from requests.auth import HTTPProxyAuth

    class CustomAuth(requests.auth.AuthBase):
        def __call__(self, r):
            r.headers['Custom'] = 'Custom'
            return r

    r = requests.Request(
        method='GET',
        url='https://www.python.org',
        auth=HTTPBasicAuth('user', 'password')
    ).prepare()

    assert 'Authorization' in r.headers

    r = requests.Request(
        method='GET',
        url='https://www.python.org',
        auth=HTTPProxyAuth('user', 'password')
    ).prepare()

    assert 'Proxy-Authorization' in r.headers


# Generated at 2022-06-12 00:33:45.442502
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-12 00:33:54.967731
# Unit test for function get_content_type

# Generated at 2022-06-12 00:33:56.224909
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'1': 1}) == "{'1': 1}"

# Generated at 2022-06-12 00:33:56.789919
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-12 00:34:00.755598
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(object()) is not None



# Generated at 2022-06-12 00:34:05.420111
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'x': 3}) == "{'x': 3}"
    assert repr_dict({'x': 3, 'y': 4}) == "{'x': 3, 'y': 4}"
    assert repr_dict({'x': 3, 'y': {'z': 5}}) == "{'x': 3, 'y': {'z': 5}}"

# Generated at 2022-06-12 00:34:07.758007
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    null_auth = ExplicitNullAuth()
    assert null_auth is not None


# Generated at 2022-06-12 00:34:08.855402
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()()



# Generated at 2022-06-12 00:34:13.476990
# Unit test for function get_content_type
def test_get_content_type():
    from test_requests_common import assert_raises

    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('.jpg') is None
    assert_raises(TypeError, get_content_type)

# Generated at 2022-06-12 00:34:22.918912
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == "1 B"
    assert humanize_bytes(1024, precision=1) == "1.0 kB"
    assert humanize_bytes(1024 * 123, precision=1) == "123.0 kB"
    assert humanize_bytes(1024 * 12342, precision=1) == "12.1 MB"
    assert humanize_bytes(1024 * 12342, precision=2) == "12.05 MB"
    assert humanize_bytes(1024 * 1234, precision=2) == "1.21 MB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == "1.31 GB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == "1.3 GB"

# Generated at 2022-06-12 00:34:25.088786
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    assert s == json.dumps(load_json_preserve_order(s))


# Generated at 2022-06-12 00:34:26.630979
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    response = auth(object)
    assert response is not None


# Generated at 2022-06-12 00:34:29.263019
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.yaml") is None
    assert get_content_type("test.yml") == "text/x-yaml"

# Generated at 2022-06-12 00:34:36.894518
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-12 00:34:51.970834
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # pylint: disable=invalid-name

    def _cookies_to_set_cookie_list(cookies):
        return [
            '%s=%s; max-age=1' % (cookie['name'], cookie['value'])
            for cookie in cookies
        ]

    def _test_expired_cookies(cookies, now, expected_names):
        assert (
            get_expired_cookies(
                [('set-cookie', cookie) for cookie in cookies],
                now=now
            )
        ) == expected_names

    # HACK/FIXME: There is no way to add cookies to requests.Session, so we
    # need to use responses.
    from requests_mock import MockResponse


# Generated at 2022-06-12 00:34:53.425122
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-12 00:34:57.240707
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
    {
        "b": "value1",
        "c": "value2",
        "a": "value3"
    }
    """
    expected = OrderedDict([
        ('b', 'value1'),
        ('c', 'value2'),
        ('a', 'value3'),
    ])
    assert expected == load_json_preserve_order(s)



# Generated at 2022-06-12 00:35:02.868220
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'a': 1,
        'b': {'c': 'abc', 'd': 'def'},
    }
    expected = "{\n    'a': 1,\n    'b': {\n        'c': 'abc',\n        'd': 'def'\n    }\n}"
    assert repr_dict(d) == expected

# Generated at 2022-06-12 00:35:03.830712
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-12 00:35:04.625969
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # pylint: disable=invalid-name
    ExplicitNullAuth()

# Generated at 2022-06-12 00:35:14.037471
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def hb(n, precision=2):
        return humanize_bytes(n, precision)

    assert hb(0) == '0 B'
    assert hb(1) == '1 B'
    assert hb(10) == '10 B'
    assert hb(100) == '100 B'
    assert hb(1000) == '1000 B'
    assert hb(1010) == '1010 B'
    assert hb(1024) == '1.00 kB'
    assert hb(1024 * 1024) == '1.00 MB'
    assert hb(1024 * 1024 * 1024) == '1.00 GB'
    assert hb(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert hb(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'

# Generated at 2022-06-12 00:35:14.829956
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 00:35:23.895402
# Unit test for function get_content_type
def test_get_content_type():
    """
    >>> test_get_content_type()
    Test cases: [('README.md', 'text/plain'), ('setup.py', None)]
    Test cases passed
    """

    test_cases = [
        ('README.md', 'text/plain'),
        ('setup.py', None)
    ]
    for filename, expected_mime in test_cases:
        got_mime = get_content_type(filename)
        assert got_mime == expected_mime

    print('Test cases:', test_cases)
    print('Test cases passed')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 00:35:24.940402
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None