

# Generated at 2022-06-12 00:30:17.855621
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:30:27.658463
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/path/to/file.js') == 'application/javascript'
    assert get_content_type('/path/to/file.json') == 'application/json'
    assert get_content_type('/path/to/file.txt') == 'text/plain'
    assert get_content_type('/path/to/file.html') == 'text/html'
    assert get_content_type('/path/to/file.xml') == 'application/xml'
    assert get_content_type('/path/to/file.pdf') == 'application/pdf'
    assert get_content_type('/path/to/file.csv') == 'text/csv'

# Generated at 2022-06-12 00:30:32.836513
# Unit test for function get_content_type
def test_get_content_type():

    assert get_content_type("a.html") == "text/html"
    assert get_content_type("b.txt") == "text/plain"
    assert get_content_type("c.h") == "text/x-c"
    assert get_content_type("d.py") == "text/x-python"
    assert get_content_type("e.tiff") == "image/tiff"

# Generated at 2022-06-12 00:30:38.954675
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    expired = get_expired_cookies([
        ('Set-Cookie', 'foo=bar; Path=/; expires=Sat, 01 Jan 2200 00:00:00 GMT'),
        ('Set-Cookie', 'foo=baz; Path=/; max-age=1000'),
        ('Set-Cookie', 'foo=quux; Path=/; foo=bar')
    ], now=time.time() + 2000)
    assert expired == [{'name': 'foo', 'path': '/'}]

# Generated at 2022-06-12 00:30:50.506491
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime
    import pytest
    import requests

    now = 0
    delta = datetime.timedelta(seconds=10)

    def httpbin(*args, **kwargs):
        nonlocal now

        r = requests.get(*args, **kwargs)
        headers = r.request.headers.get_all('Cookie', None)
        assert headers

        cookies = get_expired_cookies(headers, now)
        assert len(cookies), 'no expired cookies'

        for cookie in cookies:
            assert 'name' in cookie
            assert 'path' in cookie
            assert cookie['path'] == '/'

        now += delta.total_seconds()
        return r

    def assert_ok(r):
        assert r.status_code == 200


# Generated at 2022-06-12 00:30:59.182349
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # Tests adapted from <https://tox.readthedocs.io/en/latest/example/general.html>
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-12 00:31:10.275130
# Unit test for function get_content_type
def test_get_content_type():
    """

    >>> test_get_content_type()
    content_type: application/json; charset=utf-8
    content_type: text/plain; charset=us-ascii
    content_type: text/x-python; charset=us-ascii
    content_type: audio/x-aiff
    content_type: None

    """
    files = [
        '.vscode/settings.json',
        'resources/README',
        'resources/README.md',
        'resources/sample_aiff_file.aiff',
        'resources/sample_mp4_file.mp4',
    ]
    for f in files:
        print('content_type: {}'.format(get_content_type(f)))


if __name__ == '__main__':
    import doct

# Generated at 2022-06-12 00:31:11.260136
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'



# Generated at 2022-06-12 00:31:20.050187
# Unit test for function get_content_type
def test_get_content_type():
    assert None == get_content_type('no_file.txt')
    assert 'text/html' == get_content_type('filename.html')
    assert 'text/html; charset=utf-8' == get_content_type('filename.htm')
    assert 'text/html; charset=utf-16' == get_content_type('filename.shtml')
    assert 'application/javascript' == get_content_type('filename.js')
    assert 'application/json' == get_content_type('filename.json')
    assert 'application/pdf' == get_content_type('filename.pdf')
    assert 'application/xml' == get_content_type('filename.xml')
    assert 'image/png' == get_content_type('filename.png')

# Generated at 2022-06-12 00:31:25.694904
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from .test_helpers import load_fixture

    cookies = load_json_preserve_order(
        load_fixture('cookies.json')
    )['expired-cookies']
    headers = list(map(tuple, cookies['headers']))
    expired_cookies = get_expired_cookies(headers)
    assert expired_cookies == cookies['expired-cookies']

# Generated at 2022-06-12 00:31:31.254144
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.py') is None

# Generated at 2022-06-12 00:31:36.255442
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import io
    import json
    import os.path
    import unittest
    import urllib.parse

    from tempfile import NamedTemporaryFile

    from requests.models import CaseInsensitiveDict

    self = unittest.TestCase()

    def build_response_headers(**kwargs) -> CaseInsensitiveDict:
        return CaseInsensitiveDict({
            'Set-Cookie': r.build_cookie_header(**kwargs)
        })

    def test_cookie(self, cookie_filepath: str, cookie: dict):
        with open(cookie_filepath) as f:
            cookies_from_file = list(json.load(f))

        self.assertIn(cookie, cookies_from_file)


# Generated at 2022-06-12 00:31:48.165131
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def get_headers(expires):
        return [
            ("Set-Cookie", "JSESSIONID={};Path=/;Expires={};HttpOnly"
             .format('nonsense-kakfa-id', expires))
        ]
    date_format = '%a, %d-%b-%Y %H:%M:%S GMT'
    now = time.time()
    tomorrow = now + 24 * 3600
    yesterday = now - 24 * 3600

    cases = [
        (get_headers(time.strftime(date_format, time.gmtime(tomorrow))), []),
        (get_headers(time.strftime(date_format, time.gmtime(yesterday))),
         [{'name': 'JSESSIONID', 'path': '/'}])
    ]


# Generated at 2022-06-12 00:31:48.809270
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'

# Generated at 2022-06-12 00:31:52.837300
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # test for input data
    headers = [
        ('Set-Cookie', 'a=b; secure; expires=Sat, 12 Jan 2019 12:34:56 GMT'),
        ('Set-Cookie', 'c=d; max-age=20'),
        ('Set-Cookie', 'e=f; max-age=20; expires=Sat, 12 Jan 2099 12:34:56 GMT'),
        ('Set-Cookie', 'g=h; max-age=20; path=/; HttpOnly; Secure')
    ]
    # the time is still 2019 so the first cookie should be expired
    # the second and the third cookie should expire after 25 seconds
    # the fourth cookie has a max-age, but also an expiry date.

# Generated at 2022-06-12 00:31:57.490637
# Unit test for function get_expired_cookies
def test_get_expired_cookies():  # noqa: D202
    # noinspection PyUnresolvedReferences
    from . import test_fs as raw_test_fs

    expired_cookies = get_expired_cookies(
        headers=raw_test_fs.test_cookie_headers,
        now=time.time()
    )

    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'bar', 'path': '/'},
    ]

# Generated at 2022-06-12 00:32:06.295804
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1523182600
    headers = [
        ('Set-Cookie', 'a=1; expires=Mon, 23-Apr-07 22:23:01 GMT; path=/; domain=.example.com'),
        ('Set-Cookie', 'b=2; expires=Mon, 23-Apr-07 22:22:01 GMT; path=/; domain=.example.com'),
        ('Set-Cookie', 'c=3; expires=Mon, 23-Apr-07 22:23:01 GMT; path=/; domain=.example.com'),
        ('Set-Cookie', 'd=4; expires=Mon, 23-Apr-07 20:22:01 GMT; path=/; domain=.example.com')
    ]
    expected = [
        {'name': 'd', 'path': '/'}
    ]

# Generated at 2022-06-12 00:32:10.408562
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Only for test purposes:
    from datetime import datetime

    def _(s):
        return datetime.strptime(s, '%a, %d-%b-%Y %H:%M:%S %Z')

    assert get_expired_cookies([
        ('Set-Cookie', 'sessionid=Yw==; expires=Mon, 23-Apr-2018 07:14:30 GMT; Max-Age=86400; Path=/; HttpOnly')
    ]) == []

    # The following should not be included in the expired cookies:
    assert get_expired_cookies([
        ('Set-Cookie', 'sessionid=Yw==; expires=Mon, 23-Apr-2018 07:13:30 GMT; Max-Age=86400; Path=/; HttpOnly')
    ]) == []

    assert get

# Generated at 2022-06-12 00:32:20.890889
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    """
    Asserts that get_expired_cookies returns the correct expired cookies.
    """
    headers = [
        ("Set-Cookie", "woohoo=1; Max-Age=60"),
        ("Set-Cookie", "this_one=expired; Max-Age=0"),
        ("Set-Cookie", "omg=please; Max-Age=3000"),
        ("Set-Cookie", "this_one_too=expired; expires=Wed, 09 Jun 2021 10:18:14 GMT"),
        ("Set-Cookie", "not_expired=yes; expires=Wed, 09 Jun 2115 10:18:14 GMT")
    ]

    result = get_expired_cookies(headers, now=10)


# Generated at 2022-06-12 00:32:24.006581
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.txt') == 'text/plain'
    assert get_content_type('example.jpeg') == 'image/jpeg'
    assert get_content_type('example.unknown') is None

# Generated at 2022-06-12 00:32:27.921648
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('nonexistent_file.nonexisting') is None

# Generated at 2022-06-12 00:32:33.748303
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt; charset=utf-8') is None
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html; charset=utf-8') == 'text/html; charset=utf-8'
    assert get_content_type('foo.txt application/json') is None


# Generated at 2022-06-12 00:32:42.417617
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.exe') == 'application/octet-stream'
    assert get_content_type('foo.zip') == 'application/zip'

# Generated at 2022-06-12 00:32:50.192445
# Unit test for function get_content_type
def test_get_content_type():
    """
    >>> test_get_content_type()
    """
    test_files = [
        ('test.doc', 'application/msword'),
        ('test.html', 'text/html'),
        ('test.xml', 'application/xml')
    ]
    for filename, expected_content_type in test_files:
        content_type = get_content_type(filename)
        assert content_type == expected_content_type


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 00:32:53.936603
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.pdf") == "application/pdf"
    assert get_content_type("unknown.bla") is None
    assert get_content_type("unknown") is None

# Generated at 2022-06-12 00:33:00.289122
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') is None
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.js') == 'text/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'

# Generated at 2022-06-12 00:33:04.791405
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.xhtml') == 'application/xhtml+xml'
    assert get_content_type('test.html') == 'text/html'
    assert not get_content_type('test.invalid')
    assert get_content_type('test.invalid', True) == 'application/octet-stream'

# Generated at 2022-06-12 00:33:16.264740
# Unit test for function get_content_type

# Generated at 2022-06-12 00:33:20.240721
# Unit test for function get_content_type
def test_get_content_type():
    MIME_TYPES = {
        'foo.pdf': 'application/pdf',
        'foo.foo': None
    }

    for filename, expected_result in MIME_TYPES.items():
        result = get_content_type(filename)
        assert result == expected_result

# Generated at 2022-06-12 00:33:21.635995
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.html') == 'text/html'

# Generated at 2022-06-12 00:33:25.328893
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.html') == 'text/html'

if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-12 00:33:26.816259
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(__file__) == 'text/x-python'

# Generated at 2022-06-12 00:33:34.857666
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.gif') == 'image/gif'
    assert get_content_type('test.svg') == 'image/svg+xml'
    assert get_content_type('test.py') == 'text/x-python'
    assert get_content_type('test.WEBP') is None

# Generated at 2022-06-12 00:33:40.988408
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('elephant.jpg') == 'image/jpeg'
    assert get_content_type('wombat.png') == 'image/png'
    assert get_content_type('manatee.pdf') == 'application/pdf'
    assert get_content_type('hello.py') == 'text/x-python'
    assert get_content_type('hello.c') == 'text/x-c'
    assert get_content_type('hello.h') == 'text/x-h'



# Generated at 2022-06-12 00:33:46.116308
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.js') == 'application/javascript'
    assert get_content_type('test.css') == 'text/css'
    assert get_content_type('test.bmp') == 'image/bmp'



# Generated at 2022-06-12 00:33:53.735028
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('README.md') == 'text/x-markdown'
    assert get_content_type('requre/__init__.py') == 'text/x-python'
    assert get_content_type('requre/__init__.pyc') == 'application/octet-stream'
    assert get_content_type('requre/__init__.pyo') == 'application/octet-stream'
    assert get_content_type('requre/test/test_static.py') == 'text/x-python'



# Generated at 2022-06-12 00:34:02.329149
# Unit test for function get_content_type
def test_get_content_type():  # noqa: D103
    # Content type for empty file.
    with open('test_files/test_empty.txt') as file_:
        content_type = get_content_type(file_.name)
        assert content_type == 'text/plain'

    # Content type for plain text file.
    with open('test_files/test.txt') as file_:
        content_type = get_content_type(file_.name)
        assert content_type == 'text/plain'

    # Content type for file with no extension.
    with open('test_files/test') as file_:
        content_type = get_content_type(file_.name)
        assert content_type == 'text/plain'

# Generated at 2022-06-12 00:34:04.888387
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.svg') == 'image/svg+xml'



# Generated at 2022-06-12 00:34:16.719048
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html.gz') == 'text/html'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.svgz') == 'image/svg+xml'

# Generated at 2022-06-12 00:34:22.461354
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('.abc') is None
    assert get_content_type('/abc') is None
    assert get_content_type('abc.html') == 'text/html'
    assert get_content_type('abc.html; charset=utf-8') == 'text/html; charset=utf-8'
    assert get_content_type('abc.html; charset=utf-8;') == 'text/html; charset=utf-8'