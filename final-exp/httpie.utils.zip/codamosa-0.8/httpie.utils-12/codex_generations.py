

# Generated at 2022-06-12 00:30:14.563273
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # fmt: off
    for x, y in [
         (0, "0 B"),
         (1, "1 B"),
         (1023, "1023 B"),
         (1024, "1.00 kB"),
         (1025, "1.00 kB"),
         (1048576, "1.00 MB"),
         (1073741824, "1.00 GB"),
         (1099511627776, "1.00 TB"),
    ]:
        assert humanize_bytes(x) == y, repr(humanize_bytes(x))
    # fmt: on

# Generated at 2022-06-12 00:30:16.685323
# Unit test for function get_content_type
def test_get_content_type():
    type = get_content_type('requests/tests/data/example.xls')
    assert type, 'application/vnd.ms-excel'

# Generated at 2022-06-12 00:30:23.557631
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('a') == 'text/plain'
    assert get_content_type('a.txt') == 'text/plain'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.jpg') == 'image/jpeg'
    assert get_content_type('a.JPG') == 'image/jpeg'


# Generated at 2022-06-12 00:30:27.699854
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('venv/bin/python') == 'application/x-executable'
    assert get_content_type('setup.py') == 'text/x-python'
    assert get_content_type('requests_testadapter/__init__.py') == \
        'text/x-python'

# Generated at 2022-06-12 00:30:38.221057
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 12345


# Generated at 2022-06-12 00:30:49.992272
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # assert humanize_bytes(0) == '0.0 B'
    # assert humanize_bytes(1) == '1.0 B'
    # assert humanize_bytes(0, precision=1) == '0.0 B'
    # assert humanize_bytes(1, precision=1) == '1.0 B'
    # assert humanize_bytes(0, precision=2) == '0.00 B'
    # assert humanize_bytes(1, precision=2) == '1.00 B'
    assert humanize_bytes(10) == '10 B'
    assert humanize_bytes(100) == '100 B'
    assert humanize_bytes(768) == '768 B'
    assert humanize_bytes(1024) == '1.0 kB'

# Generated at 2022-06-12 00:30:58.869488
# Unit test for function get_content_type
def test_get_content_type():

    from http.client import responses

    import requests

    # Make a filehandle that contains a given string
    def make_filehandle(str):
        from io import StringIO
        return StringIO(str)

    # Test get_content_type with various strings/filehandles
    for (str, content_type) in \
        [('This file is text', 'text/plain'),
         ('<html>This file is HTML</html>', 'text/html')]:
        filehandle = make_filehandle(str)
        assert get_content_type(filehandle) == content_type
        assert get_content_type(filehandle.name) == content_type
        combined_filehandle_name = '%s;%s' % (filehandle, filehandle.name)
        assert get_content_type(combined_filehandle_name)

# Generated at 2022-06-12 00:31:09.597453
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(2) == '2 B'
    assert humanize_bytes(1023) == '1023 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024 * 125) == '125.0 kB'
    assert humanize_bytes(1024 * 1250) == '1.2 MB'
    assert humanize_bytes(1024 * 1250 * 100) == '100.0 MB'
    assert humanize_bytes(1024 * 1250 * 1000) == '1.1 GB'
    assert humanize_bytes(1024 * 1250 * 1000 * 10) == '10.0 GB'



# Generated at 2022-06-12 00:31:19.074049
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:31:29.226115
# Unit test for function get_content_type
def test_get_content_type():
    # https://tools.ietf.org/html/rfc6838#section-4.2
    assert get_content_type('/path/to/file.txt') == 'text/plain'
    assert get_content_type('/path/to/file.png') == 'image/png'
    assert get_content_type('/path/to/file.PNG') == 'image/png'
    assert get_content_type('/path/to/file.dwg') == 'image/vnd.dwg'
    assert get_content_type('/path/to/file.fmt') == 'text/vnd.fmi.flexstor'
    assert get_content_type('/path/to/file.hta') == 'application/hta'

# Generated at 2022-06-12 00:31:41.550240
# Unit test for function get_content_type
def test_get_content_type():
    # Tests for an existing file type
    expected = 'text/plain'
    result = get_content_type('test.txt')
    if result != expected:
        error =  'result = {result}'.format(result = result)
        error += '\nexpected = {expected}'.format(expected = expected)
        raise AssertionError(error)

    # Tests for an unknown file type
    expected = None
    result = get_content_type('test.unknown')
    if result != expected:
        error =  'result = {result}'.format(result = result)
        error += '\nexpected = {expected}'.format(expected = expected)
        raise AssertionError(error)

# Generated at 2022-06-12 00:31:52.599599
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', ('session-token=ABCDEFGHIJKLMNOPQRST; '
                        'Expires=Tue, 18 Dec 2018 04:04:21 GMT; '
                        'Path=/; HttpOnly')),
        ('Set-Cookie', ('other-token=123; Max-Age=1800; '
                        'Expires=Tue, 18 Dec 2018 04:04:21 GMT; '
                        'Path=/')),
        ('Set-Cookie', ('yet-another-token=foo; Max-Age=86400; '
                        'Expires=Tue, 18 Dec 2018 04:04:21 GMT; '
                        'Path=/'))
    ]

# Generated at 2022-06-12 00:31:56.870005
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') == 'text/html'

# Generated at 2022-06-12 00:32:06.078202
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1549686425.8452327

# Generated at 2022-06-12 00:32:17.815322
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:32:25.569946
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # pylint: disable=missing-docstring
    # pylint: disable=invalid-name
    from urllib.parse import parse_qsl as parse_qs

    def expired_cookies(
        headers,
        now=None,
        *,
        secure=False
    ):
        return list(map(dict, secure_expired_cookies(
            headers=headers,
            now=now,
            secure=secure
        )))

    def secure_expired_cookies(
        headers,
        now=None,
        *,
        secure=False
    ):
        return (
            expired
            for expired in get_expired_cookies(
                headers=headers,
                now=now,
            )
            if expired['path'].startswith('/') and not secure
        )

   

# Generated at 2022-06-12 00:32:34.709925
# Unit test for function get_content_type
def test_get_content_type():
    """
    A unit test for function ``get_content_type``.

    """
    assert get_content_type('.bashrc') is None
    assert get_content_type('.bashrc') is None

    assert get_content_type('doc.txt') == 'text/plain'
    assert get_content_type('doc.foo.txt') == 'text/plain'

    assert get_content_type('doc.html') == 'text/html'
    assert get_content_type('doc.htm') == 'text/html'
    assert get_content_type('doc.foo.html') == 'text/html'

    assert get_content_type('doc.rdf') == 'application/rdf+xml'
    assert get_content_type('doc.foo.rdf') == 'application/rdf+xml'
   

# Generated at 2022-06-12 00:32:42.979611
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).timestamp()

    headers = [('Set-Cookie', 'a=b')]
    cookies = get_expired_cookies(headers, now)
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'a'
    assert cookies[0]['path'] == '/'

    headers = [('Set-Cookie', 'a=b; max-age=600; Path=/docs;')]
    cookies = get_expired_cookies(headers, now)
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'a'
    assert cookies[0]['path'] == '/docs'


# Generated at 2022-06-12 00:32:52.703730
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    expired_cookies = get_expired_cookies([
        ("Set-Cookie", "foo=bar; Max-Age=60"),
        ("Set-Cookie", "non-expired=bar; Max-Age=90"),
        ("Set-Cookie", "expired=bar; Max-Age=30"),
        ("Set-Cookie", "expired=bar; expires=Thu, 01-Jan-1970 00:00:00 GMT"),
        ("Set-Cookie", "non-expired-expires=xyz; expires=Fri, 01-Jan-2099 00:00:00 GMT"),
    ], now=1546370162)
    assert expired_cookies == [
        {'name': 'expired', 'path': '/'},
        {'name': 'expired', 'path': '/'},
    ]
   

# Generated at 2022-06-12 00:33:00.164179
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('set-cookie', 'foo=bar; path=/; secure'),
        ('set-cookie', 'SESSID=a1237b3f; expires=Thu, '
         '21-Mar-2019 14:49:24 GMT; Max-Age=7200; path=/; secure'),
        ('set-cookie', 'bar=baz; path=/; secure; HttpOnly')
    ]

    assert get_expired_cookies(headers, now=0.0) == []
    assert get_expired_cookies(headers, now=1458161064) == []
    assert get_expired_cookies(headers, now=1458161065) == [
        {'name': 'SESSID', 'path': '/'}
    ]

# Generated at 2022-06-12 00:33:03.816770
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'

# Generated at 2022-06-12 00:33:12.199823
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') != 'text/plain'
    assert get_content_type('foo.html') != 'text/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt') != 'text/html'
    assert get_content_type('foo.txt') != 'text/jpeg'

# Generated at 2022-06-12 00:33:17.398006
# Unit test for function get_content_type
def test_get_content_type():
    """Test for correct content types"""
    assert get_content_type('image.png') == 'image/png'
    assert get_content_type('image.jpg') == 'image/jpeg'
    assert get_content_type('image.jpeg') == 'image/jpeg'
    assert get_content_type('image.jpe') == 'image/jpeg'

# Generated at 2022-06-12 00:33:22.314768
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.tar.gz') == 'application/x-gzip'

# Generated at 2022-06-12 00:33:24.085597
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'



# Generated at 2022-06-12 00:33:25.250946
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.jpg') == 'image/jpeg'

# Generated at 2022-06-12 00:33:31.262753
# Unit test for function get_content_type
def test_get_content_type():
    return {
        'example.gif': 'image/gif',
        'example.jpeg': 'image/jpeg',
        'example.png': 'image/png',
        'example.xml': 'text/xml',
        'example.html': 'text/html',
        'example.txt': 'text/plain',
        'example.pdf': 'application/pdf',
        'example.pdf?pid=123': 'application/pdf',
        'example.pdf;abc=123': 'application/pdf',
        'example.pdf;abc=123;def=456': 'application/pdf',
        'example.pdf?pid=123&path=xyz': 'application/pdf',
        'example.pdf?pid=123&path=xyz;abc=123;def=456': 'application/pdf',
    }


# Unit test

# Generated at 2022-06-12 00:33:33.960508
# Unit test for function get_content_type
def test_get_content_type():
    filename = 'test.txt'
    content_type = 'text/plain'
    assert get_content_type(filename) == content_type



# Generated at 2022-06-12 00:33:36.767717
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.txt') == 'text/plain'
    assert get_content_type('example.json.txt') is None
    assert get_content_type('example.json') == 'application/json'

# Generated at 2022-06-12 00:33:38.114603
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.csv') is not None
    assert get_content_type(None) is None
    assert get_content_type('') is None