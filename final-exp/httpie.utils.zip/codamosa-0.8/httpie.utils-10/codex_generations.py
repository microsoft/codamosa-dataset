

# Generated at 2022-06-12 00:30:17.626774
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from time import time
    from copy import deepcopy
    from datetime import timedelta
    from http.cookies import SimpleCookie

    def encode_ns_headers(cookies: list) -> List[List[str]]:
        'Convert list of dicts to RFC 7540 "Set-Cookie" headers'
        sc = SimpleCookie()
        for cookie in cookies:
            for key in cookie:
                sc[cookie['name']][key] = cookie[key]
        return [[
            'Set-Cookie',
            str(cookie).split(': ', 1)[1]
        ] for cookie in sc.values()]

    def expired_cookies_keys(cookies: List[dict]) -> set:
        return {'name', 'path'} - set(cookies[0].keys())

    assert get_expired_cook

# Generated at 2022-06-12 00:30:27.404674
# Unit test for function get_content_type
def test_get_content_type():

    cases = [
        ('.json', 'application/json'),
        ('.js', 'application/javascript'),
        ('.html', 'text/html'),
        ('.txt', 'text/plain'),
        ('.xz', 'application/x-xz'),
        ('.gz', 'application/gzip'),
        ('.bz2', 'application/x-bzip2'),
        ('.bad', None),
    ]

    for ext, expected in cases:
        result = get_content_type('foo' + ext)
        assert result == expected, ext


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-12 00:30:37.991744
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    now = time.time()


# Generated at 2022-06-12 00:30:49.780999
# Unit test for function get_content_type
def test_get_content_type():
    from werkzeug._compat import to_bytes
    from unittest import mock

    with mock.patch.object(
        mimetypes, 'guess_type', return_value=('foo/bar', 'gzip')
    ) as guess_type:
        assert get_content_type('mock') == 'foo/bar; charset=gzip'
        guess_type.assert_called_once_with('mock', strict=False)

    with mock.patch.object(mimetypes, 'guess_type', return_value=('foo/bar', None)):
        assert get_content_type('mock') == 'foo/bar'

    with mock.patch.object(mimetypes, 'guess_type', return_value=(None, None)):
        assert get_content_type('mock')

# Generated at 2022-06-12 00:30:51.759783
# Unit test for function get_content_type
def test_get_content_type():
    expected = 'application/gzip'
    result = get_content_type('/home/jmiller/file.gz')
    assert result == expected

# Generated at 2022-06-12 00:30:59.755514
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import unittest
    import datetime
    import time

    class TestGetExpiredCookies(unittest.TestCase):
        def test_it(self):
            headers = [
                ('Set-Cookie', 'one=1; path=/'),
                ('Set-Cookie', 'two=2; path=/; expires=Sun, 07-Jan-2018 00:00:00 GMT'),
                ('Set-Cookie', 'three=3'),
                ('X-Foo', 'Bar'),
            ]
            now = time.mktime(datetime.datetime(year=2018, month=1, day=7, hour=0, minute=0, second=0).timetuple())
            expected = [
                {'name': 'two', 'path': '/'},
            ]

# Generated at 2022-06-12 00:31:10.922573
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'name=value'),
        ('Set-Cookie', 'name=value; expires=Fri, 01 Jan 2021 00:00:00 GMT; '
                       'path=/'),
        ('Set-Cookie', 'name=value; expires=Sun, 12-Apr-2020 08:42:32 GMT; '
                       'path=/'),
        ('Set-Cookie', 'name=value; max-age=86400; path=/'),
        ('Set-Cookie', 'name=value; max-age=3600; path=/'),
        ('Set-Cookie', 'name=value; max-age=0; path=/'),
        ('Set-Cookie', 'name=value; path=/')
    ]
    now = int(time.time())

# Generated at 2022-06-12 00:31:16.118418
# Unit test for function get_content_type
def test_get_content_type():
    mime, encoding = mimetypes.guess_type("foo.bar.baz")
    assert mime == 'application/octet-stream'
    assert encoding is None

    mime = get_content_type("foo.bar.baz")
    assert mime is None

    mime = get_content_type("foo.txt")
    assert mime == "text/plain"

# Generated at 2022-06-12 00:31:19.340106
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('hello.txt') == 'text/plain'
    assert get_content_type('hello.html') == 'text/html'
    assert get_content_type('hello.js') == 'application/javascript'
    assert get_content_type('hello.css') == 'text/css'



# Generated at 2022-06-12 00:31:20.555273
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-12 00:31:32.080081
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    past = now - 1000
    future = now + 1000

    def assert_cookies(
        *expected_cookies,
        now=now,
        headers=[]
    ):
        cookies = get_expired_cookies(headers=headers, now=now)
        assert expected_cookies == [
            {'name': cookie['name'], 'path': cookie.get('path', '/')}
            for cookie in cookies
        ]


# Generated at 2022-06-12 00:31:44.046043
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Verify that expired cookies are removed
    cookies = get_expired_cookies(headers=[
        ('Set-Cookie', 'c1=hello'),
        ('Set-Cookie', 'c2=world; Expires=Sun, 06 Nov 1994 08:49:37 GMT'),
        ('Set-Cookie', 'c3=42; Expires=Thu, 01 Jan 1970 00:00:00 GMT'),
    ], now=1000000000)
    assert cookies == [
        {'name': 'c3', 'path': '/'}
    ]

    # Verify that max-age is taken into account

# Generated at 2022-06-12 00:31:48.559343
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.html') == 'text/html'
    assert get_content_type('file.pdf') == 'application/pdf'
    assert get_content_type('file') is None

# Generated at 2022-06-12 00:31:57.220317
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest
    from http.cookiejar import Cookie

    # We don't want to test parsing in this function, so let's assume
    # the Cookie objects are pre-populated with the right data.

# Generated at 2022-06-12 00:32:05.631584
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'one=a; Path=/'),
        ('Set-Cookie', 'two=b; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'three=c; Path=/; Max-Age=0'),
        ('Set-Cookie', 'four=d; Path=/; Max-Age=123'),
    ]
    expected = [
        {'name': 'two', 'path': '/'},
        {'name': 'three', 'path': '/'},
    ]
    # time.time() is depended on, so no option to mock it
    assert get_expired_cookies(headers, now=0) == expected

# Generated at 2022-06-12 00:32:17.400922
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from hypothesis import given, settings
    from hypothesis.strategies import text, timestamps
    from .strategies import headers, set_cookie_headers

    @given(headers(set_cookie_headers()), timestamps())
    @settings(deadline=None)
    def test_expired_cookies(headers, now):
        cookies = get_expired_cookies(headers, now)
        for cookie in cookies:
            assert 'expires' not in cookie
            assert 'max-age' not in cookie


# Generated at 2022-06-12 00:32:24.225640
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from requests.cookies import get_cookie_header

    headers = [
        ('Set-Cookie', 'a=1;'),
        ('set-Cookie', 'b=2; Max-Age=3600'),
        ('Set-Cookie', 'c=3; Expires=Sat, 01 Jan 2000 00:02:03 GMT'),
    ]

    expired_cookies = get_expired_cookies(headers, now=time.time())

    assert expired_cookies == [
        {'name': 'c', 'path': '/'},
    ]

    assert get_cookie_header(expired_cookies) == 'c=3; path=/'

# Generated at 2022-06-12 00:32:34.074724
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    sni_cookie_header = 'sessionid=596b317c07447a16; expires=Sat, 01 Apr 2017 23:21:00 GMT; Max-Age=1799; Path=/; secure'
    cookie_header = 'csrftoken=9XDpHgFYTzDkxivYoKVF8DlmE7ESuGli; expires=Fri, 10 Mar 2017 00:21:00 GMT; Max-Age=31449600; Path=/'

    cookie_list = [('set-cookie', sni_cookie_header), ('set-cookie', cookie_header)]
    expected_cookie_list = [
        {
            'name': 'sessionid',
            'path': '/'
        },
        {
            'name': 'csrftoken',
            'path': '/'
        }
    ]


# Generated at 2022-06-12 00:32:42.626739
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest

    # Not expired
    expired_cookies = get_expired_cookies([
        (
            'Set-Cookie',
            (
                'PHPSESSID=8edf2d2f1c7d9b4919aac7fde412ba26'
                '; path=/; HttpOnly'
            )
        ),
    ], now=1566812447)
    assert expired_cookies == []

    # Expired

# Generated at 2022-06-12 00:32:52.592100
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def assert_expired_cookies(cookies, expected, now):
        assert get_expired_cookies(cookies, now) == expected


# Generated at 2022-06-12 00:32:57.442439
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo') is None

# Generated at 2022-06-12 00:33:07.469619
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.jpeg') == 'image/jpeg'
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.csv') == 'text/csv'
    assert get_content_type('test.jar') == 'application/java-archive'
    assert get_content_type('test.json') == 'application/json'
    assert get_content_type('test.xlsx') == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    assert get_content_type('test.xls') == 'application/vnd.ms-excel'
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test') is None

# Generated at 2022-06-12 00:33:11.901996
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.json') == 'application/json'



# Generated at 2022-06-12 00:33:16.428678
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'

# Generated at 2022-06-12 00:33:19.180348
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.py') == 'text/x-python'

# Generated at 2022-06-12 00:33:24.859996
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/foo/bar.txt') == 'text/plain'
    assert get_content_type('/foo/bar.html') == 'text/html'
    assert get_content_type('/foo/bar.css') == 'text/css'
    # At time of writing this request, 'fancy.gif' is actually a PNG
    assert get_content_type('/foo/fancy.gif') == 'image/gif'

# Generated at 2022-06-12 00:33:26.566274
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('test.example')
    assert content_type == 'text/example', 'Unexpected content type'

# Generated at 2022-06-12 00:33:33.266954
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('hello-world.txt')
    assert 'application/pdf' == get_content_type('hello-world.pdf')
    assert 'application/pdf' == get_content_type('hello-world.PDF')
    assert 'application/octet-stream' == get_content_type(
        'hello-world.application/octet-stream')

# Generated at 2022-06-12 00:33:34.746914
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.html') == 'text/html'

# Generated at 2022-06-12 00:33:36.685809
# Unit test for function get_content_type
def test_get_content_type():
    """
    Tests for function get_content_type
    """
    assert get_content_type('data.json') == 'application/json'

# Generated at 2022-06-12 00:33:44.448661
# Unit test for function get_content_type
def test_get_content_type():
    from pytest import approx
    ct = get_content_type('example.html')
    assert ct == 'text/html'
    ct = get_content_type('example.bin')
    assert ct == 'application/octet-stream'
    ct = get_content_type('/path/to/file/example.bin')
    assert ct == 'application/octet-stream'
    ct = get_content_type('/path/to/dir/')
    assert ct is None
    ct = get_content_type('/path/to/dir')
    assert ct is None
    assert approx(humanize_bytes(1)) == '1 B'
    assert approx(humanize_bytes(1024)) == '1.0 kB'

# Generated at 2022-06-12 00:33:54.434097
# Unit test for function get_content_type

# Generated at 2022-06-12 00:34:03.360483
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.bin') == 'application/octet-stream'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') != 'text/plain'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.svgz') == 'image/svg+xml'

# Generated at 2022-06-12 00:34:15.062991
# Unit test for function get_content_type
def test_get_content_type():
    """Unit test for function get_content_type"""
    from os.path import join, dirname, abspath
    from . import test_dir

    test_data = (
        ('h.jpeg', 'image/jpeg'),
        ('h.jpg', 'image/jpeg'),
        ('h.gif', 'image/gif'),
        ('h.png', 'image/png'),
        ('h.mp3', 'audio/mpeg'),
        ('h.html', 'text/html'),
        ('h.css', 'text/css'),
        ('h.json', 'application/json'),
        ('h.xml', 'text/xml'),
    )

    for content_file, expected_content_type in test_data:
        content_file = join(test_dir, content_file)
        content_type = get_content_

# Generated at 2022-06-12 00:34:24.565007
# Unit test for function get_content_type
def test_get_content_type():

    def assert_type(filename, expected_type):
        assert get_content_type(filename) == expected_type

    # From <https://www.iana.org/assignments/media-types/text/html>.
    assert_type('index.html', 'text/html; charset=us-ascii')
    assert_type('index.htm', 'text/html; charset=us-ascii')

    # From <https://www.iana.org/assignments/media-types/text/css>.
    assert_type('default.css', 'text/css; charset=us-ascii')

    # From <https://www.iana.org/assignments/media-types/text/javascript>.
    assert_type('custom.js', 'application/javascript; charset=us-ascii')



# Generated at 2022-06-12 00:34:27.608529
# Unit test for function get_content_type
def test_get_content_type():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(suffix='.png', delete=False) as f:
        f.write(b'hello')

    assert get_content_type(f.name) == 'image/png'

# Generated at 2022-06-12 00:34:33.505991
# Unit test for function get_content_type
def test_get_content_type():
    import os
    import tempfile
    from requests_file.core import unquote

    with tempfile.TemporaryDirectory() as tmpdirname:
        filename = os.path.join(tmpdirname, 'foo.txt')
        with open(filename, 'wb') as fp:
            fp.write(b'foo')
        expected = 'text/plain; charset=us-ascii'
        assert expected == get_content_type(unquote(filename))

# Generated at 2022-06-12 00:34:39.899243
# Unit test for function get_content_type

# Generated at 2022-06-12 00:34:43.447724
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('foo.txt')
    assert 'application/vnd.ms-excel' == get_content_type('foo.xls')
    assert 'application/xml; charset=utf-8' == get_content_type('foo.xml')
    assert 'application/xml; charset=ISO-8859-1' == get_content_type('foo.svg')
    assert not get_content_type('foo')
    assert not get_content_type('foo.bin')

# Generated at 2022-06-12 00:34:51.642101
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('.txt') == 'text/plain'
    assert get_content_type('.txt.html') == 'text/html'
    assert get_content_type('txt') is None
    assert get_content_type('.txt.html.rst') == 'text/x-rst'
    assert get_content_type('.png') == 'image/png'
    assert get_content_type('.mp4') == 'video/mp4'
    assert get_content_type('.pdf') == 'application/pdf'

# Generated at 2022-06-12 00:34:59.106737
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-12 00:34:59.687822
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-12 00:35:09.641323
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=1; max-age=1'),
        ('Set-Cookie', 'b=2; max-age=2'),
        ('Set-Cookie', 'c=3; max-age=3'),
        ('Set-Cookie', 'd=4; max-age=4'),
    ]
    cookies = get_expired_cookies(headers, now=time.time())
    assert len(cookies) == 4
    assert cookies[0]['name'] == 'a'
    assert cookies[0]['path'] == '/'
    assert cookies[1]['name'] == 'b'
    assert cookies[1]['path'] == '/'
    assert cookies[2]['name'] == 'c'
    assert cookies[2]['path'] == '/'

# Generated at 2022-06-12 00:35:17.796246
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from unittest.mock import Mock

    now = time.time()
    soon = now + 60 * 60


# Generated at 2022-06-12 00:35:24.942255
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict({'a': 10}) == "{'a': 10}"
    assert repr_dict({'a': 10, 'b': True}) == "{'a': 10, 'b': True}"
    assert repr_dict({'a': 10, 'b': True, 'c': False}) == "{'a': 10, 'b': True, 'c': False}"
    assert repr_dict({'a': 10, 'b': 'abc', 'c': False}) == "{'a': 10, 'b': 'abc', 'c': False}"



# Generated at 2022-06-12 00:35:27.784489
# Unit test for function get_content_type
def test_get_content_type():
    # type: () -> None
    assert 'image/png' == get_content_type('foo.png')
    assert 'application/octet-stream' == get_content_type('foo.pyc')
    assert get_content_type('foo.notarealtype') is None

# Generated at 2022-06-12 00:35:39.196721
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # JSON deserialization into OrderedDict
    json_str = """{"a": 1, "b": 2, "c": {"d": 4, "e": 5}}"""
    json_obj = load_json_preserve_order(json_str)
    assert json_obj == {"a": 1, "b": 2, "c": {"d": 4, "e": 5}}
    assert type(json_obj) == OrderedDict
    # JSON deserialization into OrderedDict with custom object_pairs_hook
    def custom_hook(pairs):
        return pairs
    json_obj = load_json_preserve_order(json_str, custom_hook)
    assert json_obj == [("a", 1), ("b", 2), ("c", [("d", 4), ("e", 5)])]

# Generated at 2022-06-12 00:35:41.302093
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():

	from unittest.mock import Mock

	ExplicitNullAuth()(Mock())



# Generated at 2022-06-12 00:35:46.156654
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('application/json') == 'application/json'
    assert get_content_type('text/html; charset=UTF-8') == \
        'text/html; charset=UTF-8'
    assert get_content_type('image/svg+xml') == 'image/svg+xml'
    assert get_content_type('some/unknown/mime/type') is None
    assert get_content_type('script.py') is None

# Generated at 2022-06-12 00:35:54.234115
# Unit test for function humanize_bytes
def test_humanize_bytes():
    """
    >>> humanize_bytes(1)
    '1 B'
    >>> humanize_bytes(1024, precision=1)
    '1.0 kB'
    >>> humanize_bytes(1024*123, precision=1)
    '123.0 kB'
    >>> humanize_bytes(1024*12342, precision=1)
    '12.1 MB'
    >>> humanize_bytes(1024*12342, precision=2)
    '12.05 MB'
    >>> humanize_bytes(1024*1234, precision=2)
    '1.21 MB'
    >>> humanize_bytes(1024*1234*1111, precision=2)
    '1.31 GB'
    >>> humanize_bytes(1024*1234*1111, precision=1)
    '1.3 GB'
    """

