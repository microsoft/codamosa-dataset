

# Generated at 2022-06-12 00:30:13.956114
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('bar') is None

# Generated at 2022-06-12 00:30:18.381385
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('README.md') == 'text/x-markdown'
    assert get_content_type('timeline.html') == 'text/html'
    assert get_content_type('timeline.svg') == 'image/svg+xml'
    assert get_content_type('timeline.french.svg') == 'image/svg+xml'
    assert get_content_type('timeline.pt_BR.svg') == 'image/svg+xml'
    assert get_content_type('timeline.png') == 'image/png'
    assert get_content_type('timeline.nonsense') is None

# Generated at 2022-06-12 00:30:22.355764
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(None) is None
    assert get_content_type('') is None
    assert get_content_type('test.txt') == 'text/plain'

# Generated at 2022-06-12 00:30:26.755721
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('README.rst') == 'text/x-rst'
    assert get_content_type('logo.png') == 'image/png'
    assert get_content_type('logo.svg') == 'image/svg+xml'
    assert get_content_type('logo.SVG') is None

# Generated at 2022-06-12 00:30:28.796894
# Unit test for function get_content_type
def test_get_content_type():
    filename = 'projekt.txt'
    assert get_content_type(filename) == 'text/plain; charset=utf-8'

# Generated at 2022-06-12 00:30:36.416590
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'text/javascript'
    assert get_content_type('foo.bar') is None
    assert get_content_type('foo.unknown') is None

# Generated at 2022-06-12 00:30:42.715890
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def parse_cookies(cookies):
        return dict((cookie['name'], cookie['path']) for cookie in cookies)


# Generated at 2022-06-12 00:30:53.650255
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert 'text/plain' in get_content_type('foo.html.txt')
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/x-javascript'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.svgz') == 'image/svg+xml'
    assert get_content_type('foo.gz') == 'application/x-gzip'
    assert get_content_type('foo.gzip')

# Generated at 2022-06-12 00:30:59.279598
# Unit test for function get_content_type
def test_get_content_type():
    # image/png; charset=binary
    assert get_content_type('png-image.png') == 'image/png; charset=binary'

    # application/json
    assert get_content_type('json-file.json') == 'application/json'

    # 'application/json; charset=utf-8'
    assert get_content_type('json-file.json?foo=bar') == 'application/json; charset=utf-8'



# Generated at 2022-06-12 00:31:08.091961
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    """
    Unit test for function get_expired_cookies
    """
    now = time.time()
    headers = [
        ('Set-Cookie', 'session=deadbeef; path=/; max-age=3600'),
        ('Set-Cookie', 'username=deadbeef; path=/; expires=1577833200'),
        ('Set-Cookie', 'avatar=deadbeef; path=/; expires=1577833200'),
    ]

    expired_cookies = get_expired_cookies(headers, now=now)
    assert len(expired_cookies) == 3



# Generated at 2022-06-12 00:31:19.795286
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import unittest
    import datetime

    cookies = [{'name': 'foo'}]
    _max_age_to_expires(cookies, now=0)
    assert cookies == [{'name': 'foo'}]

    cookies = [{'name': 'foo', 'max-age': '100'}]
    _max_age_to_expires(cookies, now=0)
    assert cookies == [{'name': 'foo', 'max-age': '100', 'expires': 100.0}]

    cookies = [{'name': 'foo', 'max-age': '100.'}]
    _max_age_to_expires(cookies, now=0)
    assert cookies == [{'name': 'foo', 'max-age': '100.'}]


# Generated at 2022-06-12 00:31:28.935658
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    header = [
        'Set-Cookie: foo=bar; Expires=Thu, 01-Jan-1970 00:00:10 GMT',
        'Set-Cookie: bar=baz; Max-Age=5',
        'Set-Cookie: baz=qux; Expires=Thu, 01-Jan-1970 00:00:10 GMT',
    ]
    expired_cookies = get_expired_cookies(headers=header, now=0)
    assert expired_cookies == [{'name': 'bar', 'path': '/'},
                               {'name': 'baz', 'path': '/'}]


# For testing `_max_age_to_expires`:

# Generated at 2022-06-12 00:31:39.421186
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:31:51.260896
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:31:59.014684
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([('Set-Cookie', 'foo=bar; path=/'),
                                   ('Set-Cookie', 'bar=baz; path=/; expires=Mon, 18 Aug 2039 20:00:00 GMT'),
                                   ('Set-Cookie', 'baz=biz; path=/; max-age=86400'),
                                   ('Set-Cookie', 'biz=buz; path=/; expires=Mon, 18 Aug 1997 20:00:00 GMT'),
                                   ('Set-Cookie', 'buz=buu; path=/; max-age=86401')],
                                  1277894668)
    assert len(cookies) == 2
    assert cookies[0] == {'name': 'baz', 'path': '/'}

# Generated at 2022-06-12 00:32:05.902929
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:32:17.738222
# Unit test for function get_expired_cookies

# Generated at 2022-06-12 00:32:25.527870
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-12 00:32:34.713792
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    test_headers = [
        ('Set-Cookie', 'name=value'),
        ('Set-Cookie', 'expired=value; Max-Age=0'),
        ('Set-Cookie', 'path=/; other=value; Max-Age=1440'),
        ('Set-Cookie', 'multiple=values; Max-Age=0'),
        ('Set-Cookie', 'other; multiple=values; Max-Age=0'),
        ('Set-Cookie', 'long; multiple=values; Max-Age=3600'),
        ('Set-Cookie', 'multiple=values; Max-Age=0; short'),
    ]
    now = 1520478811.948466

# Generated at 2022-06-12 00:32:40.216662
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # type: () -> None
    get_expired_cookies(
        headers=[
            ('Set-Cookie', 'a=b; Expires=Mon, 01 Jan 1990 00:00:00 GMT'),
            ('Set-Cookie',  'c=d; Max-Age=10; Path=/foo; Secure')
        ],
        now=1,
    ) == [
        {'path': '/foo', 'name': 'c'}
    ]