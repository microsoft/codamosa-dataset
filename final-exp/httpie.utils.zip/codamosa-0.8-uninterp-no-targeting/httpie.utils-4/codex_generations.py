

# Generated at 2022-06-21 14:55:35.334541
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 14:55:39.636135
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'foo': 'bar',
        'baz': [1, 2, 3, 4],
        'qux': {
            'quux': 'corge',
            'grault': {
                'garply': 'waldo',
                'fred': [1, 2]
            },
            'waldo': True
        }
    }
    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-21 14:55:40.828391
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"

# Generated at 2022-06-21 14:55:51.167400
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'



# Generated at 2022-06-21 14:55:58.777119
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([
        ('Set-Cookie', 'A1=Q1; expires=Wed, 13-Jan-2021 22:23:01 GMT'),
        ('Set-Cookie', 'A2=Q2; expires=Wed, 13-Jan-2020 22:23:01 GMT'),
        ('Set-Cookie', 'A3=Q3; max-age=1234'),
    ], now=time.mktime(time.strptime('2020-02-06', '%Y-%m-%d')))
    assert len(cookies) == 1
    assert cookies[0] == {'name': 'A2', 'path': '/'}

# Generated at 2022-06-21 14:56:03.345908
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    example_json_str = """
    {
        "z": "Z",
        "a": "a",
        "n": ["2", "3", "1"]
    }
    """
    assert load_json_preserve_order(example_json_str) == {
        'z': 'Z',
        'a': 'a',
        'n': ['2', '3', '1']
    }

# Generated at 2022-06-21 14:56:04.846319
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(object())

# Generated at 2022-06-21 14:56:10.068691
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 'b', 'c': ['d', 'e'], 'f': {'g': 'h'}}
    assert repr_dict(d) == "{\n    'a': 'b',\n    'c': ['d', 'e'],\n    'f': {'g': 'h'},\n}"

# Generated at 2022-06-21 14:56:15.223114
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # noinspection PyUnresolvedReferences
    """Doctest in __doc__."""
    import doctest
    from . import __doc__
    doctest.testmod(verbose=False, optionflags=doctest.ELLIPSIS,
                    extraglobs={'humanize_bytes': humanize_bytes})


test_humanize_bytes()

# Generated at 2022-06-21 14:56:20.660952
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict)
    assert d == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-21 14:56:25.121177
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr_dict(d) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 14:56:30.829547
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.csv') == 'text/csv'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'



# Generated at 2022-06-21 14:56:40.179881
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB', 2),
        (1024 * 1234, '1.21 MB', 2),
        (1024 * 1234 * 1111, '1.31 GB', 2),
        (1024 * 1234 * 1111, '1.3 GB', 1),
    ]
    for n, expected, precision in tests:
        assert humanize_bytes(n, precision) == expected


if __name__ == '__main__':
    test_humanize_bytes()

# Generated at 2022-06-21 14:56:44.073826
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    req = requests.Request('GET', 'https://example.com/foo')
    prepped = auth(req)
    prepped.prepare()

# Generated at 2022-06-21 14:56:48.389316
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # The only reason to test __call__(...) is that the method is a
    # callback for the requests library, so we should make sure
    # it does not break when called with this signature.

    auth = ExplicitNullAuth()
    auth(None)  # no exception should be raised.

# Generated at 2022-06-21 14:56:49.885785
# Unit test for function repr_dict
def test_repr_dict():
    d = {'b': 2, 'a': 1}
    assert repr_dict(d) == "{'b': 2, 'a': 1}"

# Generated at 2022-06-21 14:56:58.924250
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert(str(humanize_bytes(1)) == '1 B')
    assert(str(humanize_bytes(1024, precision=1)) == '1.0 kB')
    assert(str(humanize_bytes(1024 * 123, precision=1)) == '123.0 kB')
    assert(str(humanize_bytes(1024 * 12342, precision=1)) == '12.1 MB')
    assert(str(humanize_bytes(1024 * 12342, precision=2)) == '12.05 MB')
    assert(str(humanize_bytes(1024 * 1234, precision=2)) == '1.21 MB')
    assert(str(humanize_bytes(1024 * 1234 * 1111, precision=2)) == '1.31 GB')

# Generated at 2022-06-21 14:57:02.213724
# Unit test for function repr_dict
def test_repr_dict():
    result = repr_dict({'a': 1})
    assert result == "{'a': 1}"
    result = repr_dict({'a': 1, 'b': 2})
    assert result == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 14:57:13.037364
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    tests = []  # type: List[Tuple[List[Tuple[str, str]], List[dict]]]

    tests.append((
        [],
        []
    ))

    tests.append((
        [('Set-Cookie', 'name="value"')],
        []
    ))

    tests.append((
        [('Set-Cookie', 'name="value"; Expires=Wed, 09 Jun 2021 10:18:14 GMT')],
        []
    ))

    tests.append((
        [('Set-Cookie', 'name="value"; Expires=Wed, 09 Jun 2010 10:18:14 GMT')],
        [{'name': 'name', 'path': '/'}]
    ))


# Generated at 2022-06-21 14:57:20.978411
# Unit test for function get_content_type
def test_get_content_type():
    from .compat import unittest

    class TestGetContentType(unittest.TestCase):
        def test_simple(self):
            with open('README.rst', 'rb') as f:
                self.assertEqual(
                    get_content_type('README.rst'),
                    'text/x-rst; charset=us-ascii'
                )

        def test_no_extension(self):
            with open('README.rst', 'rb') as f:
                self.assertIsNone(
                    get_content_type('README.rst.foo'),
                )


# Generated at 2022-06-21 14:57:27.181203
# Unit test for function repr_dict
def test_repr_dict():
    # given
    d = {'foo': 'bar', 'baz': 'qux'}
    # when
    rep = repr_dict(d)
    # then
    assert rep == "{'foo': 'bar', 'baz': 'qux'}"

# Generated at 2022-06-21 14:57:28.526838
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    pass  # Nothing to test here.

# Generated at 2022-06-21 14:57:32.091359
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert repr(auth) == "ExplicitNullAuth()"
    a = auth('a')
    assert a == 'a'
    b = auth('b')
    assert b == 'b'
    assert a == b
    assert repr(auth) == "ExplicitNullAuth()"



# Generated at 2022-06-21 14:57:36.644670
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('a.txt') == 'text/plain'
    assert get_content_type('a.exe') == 'application/octet-stream'
    assert get_content_type('') is None

# Generated at 2022-06-21 14:57:45.210417
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; max-age=5; Path=/'),
        ('Set-Cookie', 'qux=baz; Expires=Wed, 21 Oct 2015 07:28:00 GMT; Path=/'),
        ('Set-Cookie', 'meh=buh; Expires=Wed, 21 Oct 2015 07:28:00 GMT; Path=/'),
        ('Set-Cookie', 'yum=yum; max-age=20; Path=/'),
        ('Set-Cookie', 'nope=yup; expires=Fri, 21 Oct 2025 07:28:00 GMT; Path=/'),
    ]

    expected = [
        {'name': 'qux', 'path': '/'},
        {'name': 'meh', 'path': '/'},
    ]

    # NOTE: test is sensitive

# Generated at 2022-06-21 14:57:47.930512
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'b': 2,
        'a': 1,
    }

    assert repr_dict(d) == (
        "{\n"
        "    'a': 1,\n"
        "    'b': 2\n"
        "}"
    )

# Generated at 2022-06-21 14:57:56.372483
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_string = '{"field_1": "value 1", "field_2": "value 2"}'
    test_json = load_json_preserve_order(test_string)
    assert(len(test_json) == 2)
    assert(test_json.keys()[0] == "field_1")
    assert(test_json.keys()[1] == "field_2")
    assert(test_json["field_1"] == "value 1")
    assert(test_json["field_2"] == "value 2")

# Generated at 2022-06-21 14:57:57.370520
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()({}).auth is None

# Generated at 2022-06-21 14:58:03.188697
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('spam.png') == 'image/png'
    assert get_content_type('spam.jpg') == 'image/jpeg'
    assert get_content_type('spam.foo') is None

# Generated at 2022-06-21 14:58:10.160573
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:58:14.134960
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert isinstance(auth, requests.auth.AuthBase)

# Generated at 2022-06-21 14:58:18.036255
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{
  "key1": "value1",
  "key2": "value2"
}"""
    assert load_json_preserve_order(s) == OrderedDict([
        ('key1', 'value1'),
        ('key2', 'value2'),
    ])

# Generated at 2022-06-21 14:58:19.529178
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    a = ExplicitNullAuth()
    assert a is not None
    a(None)

# Generated at 2022-06-21 14:58:27.080219
# Unit test for function repr_dict
def test_repr_dict():
    rec1 = {
        'foo': 'bar',
        'lorem': {
            'dolor': 'sit',
            'amet': [
                1,
                2,
                3
            ]
        }
    }
    x = repr_dict(rec1)
    assert x == '{\'foo\': \'bar\', \'lorem\': {\'dolor\': \'sit\', \'amet\': [1, 2, 3]}}'

# Generated at 2022-06-21 14:58:31.377834
# Unit test for function humanize_bytes
def test_humanize_bytes():
    print('Here are a few sample results')
    print(humanize_bytes(1))
    print(humanize_bytes(1024))
    print(humanize_bytes(1024*123))
    print(humanize_bytes(1024*12342))
    print(humanize_bytes(1024*12342,precision=1))
    print(humanize_bytes(1024*1234,precision=2))
    print(humanize_bytes(1024*1234*1111,precision=2))

# Generated at 2022-06-21 14:58:35.584731
# Unit test for function humanize_bytes
def test_humanize_bytes():
    table = (
        (0, '0 B'),
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 1024, '1.0 MB'),
    )
    for n, s in table:
        assert humanize_bytes(n) == s

# Generated at 2022-06-21 14:58:37.098271
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert a is not None


# Generated at 2022-06-21 14:58:40.163278
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{"foo": 1, "bar": 2, "baz": 3}"""
    j = load_json_preserve_order(s)
    assert list(j.keys()) == ['foo', 'bar', 'baz']

# Generated at 2022-06-21 14:58:41.692750
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest
    doctest.testmod()


# Generated at 2022-06-21 14:58:46.489215
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({'a': 'b', 'c': {'d': 'e'}}) == "{'a': 'b', 'c': {'d': 'e'}}"

# Generated at 2022-06-21 14:58:58.503075
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.txt.gzip') == 'application/x-gzip'
    assert get_content_type('foo.txt.gz') == 'application/x-gzip'
    assert get_content_type('foo.csv') == 'text/csv'
    assert get_content_type('no_extension') is None
    assert get_content_type('foo.no_extension_in_mimetypes') is None

# Generated at 2022-06-21 14:59:02.551666
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 14:59:07.844189
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a":1,"b":2,"c":3}'
    d = load_json_preserve_order(s)
    assert type(d) == OrderedDict
    assert list(d.keys()) == ['a', 'b', 'c']
    assert d['a'] == 1
    assert d['b'] == 2
    assert d['c'] == 3

# Generated at 2022-06-21 14:59:10.524010
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from unittest.mock import Mock
    request = Mock()
    auth = ExplicitNullAuth()
    assert auth(request) is request

# Generated at 2022-06-21 14:59:11.510078
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None

# Generated at 2022-06-21 14:59:15.064693
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # add some float numbers to make sure order is preserved
    content = '{"a":"b","c":"d","e":3.333,"f":4.444}'
    d = load_json_preserve_order(content)
    assert d['e'] == 3.333


# Generated at 2022-06-21 14:59:17.625103
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    data = load_json_preserve_order(
        '{"abc": 12, "def": "test"}'
    )
    assert data == OrderedDict([('abc', 12), ('def', 'test')])

# Generated at 2022-06-21 14:59:25.377537
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert load_json_preserve_order('{"a": 1, "b": 2}') != {'b': 2, 'a': 1}
    assert repr(load_json_preserve_order('{"a": 1, "b": 2}')) == (
        "OrderedDict([('a', 1), ('b', 2)])")
    assert repr(load_json_preserve_order('{"b": 2, "a": 1}')) == (
        "OrderedDict([('b', 2), ('a', 1)])")

# Generated at 2022-06-21 14:59:36.953283
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookie_expired = (
        'set-cookie: lc-acb=en_US; expires=Mon, 01-Jan-18 00:00:00 GMT;'
        ' path=/; domain=.uber.com'
    )
    cookie_not_expired = (
        'set-cookie: c=a; expires=Fri, 01-Jan-2038 00:00:00 GMT;'
        ' path=/; domain=.uber.com'
    )
    cookie_max_age = (
        'set-cookie: foo=max-age=60; domain=.uber.com; path=/'
    )
    cookie_max_age_not_expired = (
        'set-cookie: bar=max-age=3600; domain=.uber.com; path=/'
    )

# Generated at 2022-06-21 14:59:42.527478
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    j = """{"c": 3, "a": 1, "b": 2}"""

    # Standard json library
    d = json.loads(j)
    assert d["a"] == 1
    assert d["b"] == 2
    assert d["c"] == 3

    # With function load_json_preserve_order
    d = load_json_preserve_order(j)
    assert d["a"] == 1
    assert d["b"] == 2
    assert d["c"] == 3
    assert list(d.keys()) == ["c", "a", "b"]

# Generated at 2022-06-21 15:00:27.563219
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(2), '2 B'
    assert humanize_bytes(1023) == '1023 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1025) == '1.00 kB'
    assert humanize_bytes(1024 * 1023) == '1023.00 kB'
    assert humanize_bytes(1024 * 1024) == '1.00 MB'
    assert humanize_bytes(1024 * 1024 * 1023) == '1023.00 MB'
    assert humanize_bytes(1024 * 1024 * 1024) == '1.00 GB'
    assert humanize_bytes(1024 * 1024 * 1024 * 1023)

# Generated at 2022-06-21 15:00:33.053621
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from unittest import TestCase

    class TestGetExpiredCookies(TestCase):
        def test_get_expired_cookies(self):
            expired_at = 1530552295.144746

# Generated at 2022-06-21 15:00:43.913970
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 15:00:48.510433
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-21 15:00:58.240499
# Unit test for function humanize_bytes
def test_humanize_bytes():  # noqa: D103
    # 13 for ``humanize_bytes`` and 1 for ``test_humanize_bytes``
    assert len(locals()) == 14
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'


# Generated at 2022-06-21 15:01:02.517197
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    sample_cookie = 'test=value; expires=Sun, 06 Nov 2016 10:23:24 GMT'
    assert get_expired_cookies([('set-cookie', sample_cookie)], now=1478385000) == [
        {'name': 'test', 'path': '/'}
    ]

# Generated at 2022-06-21 15:01:09.782685
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/home/joe/foo/bar/baz') is None
    assert get_content_type('/home/joe/foo/bar/baz.png') == 'image/png'
    assert get_content_type('/home/joe/foo/bar/baz.xhtml') == (
        'application/xhtml+xml'
    )
    assert get_content_type('baz-us-ascii.txt') == 'text/plain'
    assert get_content_type('baz-utf-8.txt') == 'text/plain; charset=utf-8'

# Generated at 2022-06-21 15:01:18.210471
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    def _test(set_cookie_headers: List[str],
              now: float,
              expected: List[dict]) -> None:

        cookies = get_expired_cookies(
            headers=[
                (name, value)
                for name, value in [
                    header.split(': ', 1)
                    for header in set_cookie_headers
                ]
            ],
            now=now,
        )
        assert cookies == expected


# Generated at 2022-06-21 15:01:22.384691
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"c": 3, "a": 1, "b": 2}'
    d = load_json_preserve_order(s)
    assert d == {'c': 3, 'a': 1, 'b': 2}
    assert list(d) == list(d.keys())  # noqa: S001

# Generated at 2022-06-21 15:01:28.162984
# Unit test for function get_content_type
def test_get_content_type():
    from tempfile import NamedTemporaryFile

    def assert_eq(content_type, filename):
        assert content_type == get_content_type(filename)

    assert_eq(None, 'foobar.unknown')
    assert_eq('text/plain', 'foobar.txt')
    assert_eq('text/html', 'foobar.htm')

    with NamedTemporaryFile(prefix='tmp', suffix='.html') as f:
        assert_eq('text/html', f.name)

# Generated at 2022-06-21 15:02:12.314675
# Unit test for function repr_dict
def test_repr_dict():
    d = {'key1': ['value1', 'value2']}
    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-21 15:02:12.924347
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 15:02:17.769589
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    >>> import requests
    >>> auth = ExplicitNullAuth()
    >>> r = requests.get('https://httpbin.org/cookies/set?foo=bar', auth=auth)
    >>> r.request.body
    None
    >>> r.request.headers['Authorization']
    Traceback (most recent call last):
    ...
    KeyError: 'Authorization'

    """

# Generated at 2022-06-21 15:02:20.781895
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Tests both dict and list
    inp = '[{"foo": "bar"},{"baz": "qux"}]'
    outp = load_json_preserve_order(inp)
    assert (outp[0]['foo'] == 'bar' and
            outp[1]['baz'] == 'qux')



# Generated at 2022-06-21 15:02:22.399794
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # this test is not really needed. It just exists to keep the coverage tools
    # happy.
    assert ExplicitNullAuth()

# Generated at 2022-06-21 15:02:26.861899
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_string = '{"key": "value", "second_key": "second_value"}'
    result = load_json_preserve_order(test_string)
    assert result['key'] == 'value'
    assert result['second_key'] == 'second_value'
    assert list(result.keys()) == ['key', 'second_key']



# Generated at 2022-06-21 15:02:32.446008
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_json = '''{
        "a": "A",
        "b": "B",
        "c": "C"
    }'''
    test_obj = load_json_preserve_order(test_json)
    assert list(test_obj.keys()) == ['a', 'b', 'c']

__test__ = {
    'test_load_json_preserve_order': test_load_json_preserve_order
}

# Generated at 2022-06-21 15:02:37.788961
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('curly.gif') == 'image/gif'
    assert get_content_type('curly.html') == 'text/html'
    assert get_content_type('curly.jpg') == 'image/jpeg'
    assert get_content_type('curly.txt') == 'text/plain'
    assert get_content_type('curly.xml') == 'application/xml'
    assert get_content_type('curly.zip') == 'application/zip'
    assert get_content_type('favicon.ico') == 'image/vnd.microsoft.icon'
    assert get_content_type('guidotto.html') == 'text/html'
    assert get_content_type('robots.txt') == 'text/plain'

# Generated at 2022-06-21 15:02:41.457484
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_input = '''{"foo":1,"bar":2}'''
    test_output = load_json_preserve_order(test_input)
    assert isinstance(test_output, OrderedDict)
    assert test_output.keys() == ['foo', 'bar']

# Generated at 2022-06-21 15:02:50.034192
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie',
         'SESSION=a46f4597-dd1c-4f4b-a4b0-8d93794f3213; Path=/; '
         'Expires=Thu, 30 Jan 2020 18:44:25 GMT; HttpOnly'),
        ('Set-Cookie', 'ARRAffinity=a46f4597-dd1c-4f4b-a4b0-8d93794f3213; '
         'Path=/; Expires=Thu, 30 Jan 2020 18:44:25 GMT; Secure'),
    ]
    now = time.time() + 1000.0
    assert not get_expired_cookies(headers=headers, now=now)
    now = time.time() - 1000.0

# Generated at 2022-06-21 15:03:01.698308
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # The output should be the same as the input
    s = '''
    [
        {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3"
        },
        {
            "key4": "value4",
            "key5": "value5"
        }
    ]
    '''
    print(s)
    print(load_json_preserve_order(s))
    assert load_json_preserve_order(s) == json.loads(s)

# Generated at 2022-06-21 15:03:07.441480
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies(
        headers=[
            ('Set-Cookie',
             'foo=bar; '
             'Max-Age=3600; '
             'Path=/; '
             'Expires=Wed, 16 Dec 2020 21:48:48 GMT'
             )
        ],
        now=1608002928.0  # Wed, 16 Dec 2020 21:48:48 GMT
    ) == [{
        'name': 'foo',
        'path': '/'
    }]

# Generated at 2022-06-21 15:03:15.137409
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'name=value'),
        ('Set-Cookie', 'name=value; Expires=Wed, 09 Jun 2021 10:18:14 GMT'),  # noqa: E501
        ('Set-Cookie', 'name=value; Max-Age=86400; Path=/'),
        ('Set-Cookie', 'name=value; Max-Age=100000; Path=/'),
        ('Set-Cookie', 'name=value; Max-Age=86400; Path=/other'),
    ]
    now = 1257894000
    invalid_cookies = get_expired_cookies(headers=headers, now=now)

    assert invalid_cookies == [
        {'name': 'name', 'path': '/'},
        {'name': 'name', 'path': '/other'},
    ]

# Generated at 2022-06-21 15:03:24.365062
# Unit test for function repr_dict
def test_repr_dict():
    test_inputs = [
        {
            'key': 'value',
            'key1': 'value1',
            'key2': 'value2'
        },
        {
            'key': 'value'
        },
        {
            'key': 'value',
            'key1': 'value1',
            'key2': 'value2',
            'key3': 'value3',
            'key4': 'value4',
            'key5': 'value5'
        }
    ]


# Generated at 2022-06-21 15:03:30.833732
# Unit test for function get_content_type
def test_get_content_type():
    from pytest import raises

    ct = get_content_type

    assert ct('foo.tar.gz') == 'application/x-tar'
    assert ct('foo.txt') == 'text/plain'
    assert ct('.htaccess') == 'text/plain'
    assert ct('foo.doc') == 'application/msword'
    assert ct('foo.jpg') == 'image/jpeg'
    assert ct('foo.svg') == 'image/svg+xml'

    with raises(AttributeError):
        get_content_type()

# Generated at 2022-06-21 15:03:31.834663
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"

# Generated at 2022-06-21 15:03:32.871528
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == '<ExplicitNullAuth>'

# Generated at 2022-06-21 15:03:37.143683
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Request
    from requests.models import PreparedRequest

    class DummyRequest(Request):
        def __init__(self, url='http://example.com/'):
            super().__init__('GET', url)

    auth = ExplicitNullAuth()
    obj = DummyRequest()
    assert isinstance(auth(obj), PreparedRequest)


# Unit tests
# FIXME: in-file unit tests

# Generated at 2022-06-21 15:03:39.724603
# Unit test for function get_content_type
def test_get_content_type():
    """Test whether get_content_type returns the expected string."""
    assert get_content_type('test.pdf') == 'application/pdf'

# Generated at 2022-06-21 15:03:46.802185
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_json = """{
    "a": "text",
    "b": "more text",
    "c": {
        "c1": "more",
        "c2": "and more"
    }
    }"""
    test_json_v2 = """{
    "a": "text",
    "b": "more text",
    "c": {
        "c2": "and more",
        "c1": "more"
    }
    }"""
    assert load_json_preserve_order(test_json) == load_json_preserve_order(test_json_v2)