

# Generated at 2022-06-21 14:55:28.523223
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert isinstance(auth, type(ExplicitNullAuth.__call__))



# Generated at 2022-06-21 14:55:32.310250
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Parameter r of method __call__ of class ExplicitNullAuth
    should be equal to the explicit parameter of __call__.

    """
    expected = 'expected'
    obj = ExplicitNullAuth()
    actual = obj(expected)
    assert actual == expected

# Generated at 2022-06-21 14:55:34.441121
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == "<ExplicitNullAuth()>"

# Generated at 2022-06-21 14:55:35.347890
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()(None) is None

# Generated at 2022-06-21 14:55:39.992137
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({1: 'a', 2: 'b'}) == "{1: 'a', 2: 'b'}"
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': {'a': 1, 'b': 2}}) == "{'a': {'a': 1, 'b': 2}}"



# Generated at 2022-06-21 14:55:42.195632
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.tar.bz2') == 'application/x-bzip2'

# Generated at 2022-06-21 14:55:49.054779
# Unit test for function humanize_bytes
def test_humanize_bytes():
    for humanized, value in [
        ('1 B', 1),
        ('1021 B', 1021),
        ('1.0 kB', 1024),
        ('1.0 kB', 1024 * 1.2),
        ('1.2 MB', 1024 * 1234),
        ('1.3 GB', 1024 * 1234 * 1111),
    ]:
        assert humanized == humanize_bytes(value)
        assert humanized == humanize_bytes(value, precision=1)

# Generated at 2022-06-21 14:55:52.995412
# Unit test for function repr_dict
def test_repr_dict():
    expected_dict = {'a': 1, 'b': 2}

    repr_dict(expected_dict)

    actual_dict = repr_dict({'a': 1, 'b': 2})

    assert actual_dict == expected_dict

# Generated at 2022-06-21 14:56:01.793031
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:56:05.188927
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.bin') is None

# Generated at 2022-06-21 14:56:09.234143
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'

# Generated at 2022-06-21 14:56:11.775606
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    request = requests.Request()
    request.auth = auth
    assert request.auth is auth

# Generated at 2022-06-21 14:56:23.554393
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.PNG') == 'image/png'
    assert get_content_type('foo.JSON') == 'application/json'
    assert get_content_type('foo.JSON') == 'application/json'
    assert get_content_type('foo.sh') is None
    assert get_content_type('foo.sh') is None
    assert get_content_type('/path/to/foo.png') == 'image/png'
    assert get_content_type('/path/to/foo.json') == 'application/json'
    assert get_content_

# Generated at 2022-06-21 14:56:33.510422
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2, "c": 3}') == OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert load_json_preserve_order('{"a": 1, "b": 2, "c": {"d": 4, "e": 5, "f": 6}, "g": 7}') == OrderedDict(
        [('a', 1), ('b', 2), ('c', OrderedDict([('d', 4), ('e', 5), ('f', 6)])), ('g', 7)])
    assert "TypeError" in str(load_json_preserve_order("THIS IS NOT A VALID JSON STRING"))

# Generated at 2022-06-21 14:56:40.447177
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """[{"key1": "value1", "key2": "value2"}, {"key3": "value3", "key4": "value4"}]"""
    d = [{"key1": "value1", "key2": "value2"}, {"key3": "value3", "key4": "value4"}]
    assert d == load_json_preserve_order(s)

# Generated at 2022-06-21 14:56:46.341624
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a":1,"b":2,"c":3,"d":4,"e":5}'
    assert load_json_preserve_order(s) == {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5
    }

# Generated at 2022-06-21 14:56:49.877770
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-21 14:56:51.783892
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    e = ExplicitNullAuth()
    assert repr(e) == '<ExplicitNullAuth>'

# Generated at 2022-06-21 14:56:58.559816
# Unit test for function repr_dict
def test_repr_dict():
    def _check(expected: str, d: dict):
        assert expected == repr_dict(d)

    _check('{}', {})
    _check('{a: 1, b: 2}', {'a': 1, 'b': 2})
    _check('{a: 1, b: 2}', OrderedDict({'a': 1, 'b': 2}))
    _check('{a: 1, b: 2}', OrderedDict({'b': 2, 'a': 1}))
    _check(
        '{a: 1, b: {a: 2, b: 3}}',
        {'a': 1, 'b': {'a': 2, 'b': 3}}
    )

# Generated at 2022-06-21 14:57:02.534892
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.xhtml') == 'application/xhtml+xml'
    assert get_content_type('foo.tar.gz') == 'application/x-gzip'
    assert get_content_type('foo') is None

# Generated at 2022-06-21 14:57:06.034868
# Unit test for function get_content_type
def test_get_content_type():
    assert(get_content_type('foo.tar.gz') == 'application/x-gzip')



# Generated at 2022-06-21 14:57:17.268474
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import HTTPBasicAuth
    from requests.models import PreparedRequest

    auth = ExplicitNullAuth()
    headers = {'Authorization': 'Basic YWxhZGRpbjpvcGVuc2VzYW1l'}
    request = PreparedRequest()
    request.headers.update(headers)

    auth(request)
    assert request.headers == headers

    headers = {'Authorization': 'Basic YWxhZGRpbjpvcGVuc2VzYW1l'}
    request = PreparedRequest()
    request.headers.update(headers)
    auth = ExplicitNullAuth()

    auth(request)
    assert request.headers == headers

    auth = HTTPBasicAuth('aladdin', 'opensesame')

# Generated at 2022-06-21 14:57:29.249780
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:57:29.658223
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:57:35.291690
# Unit test for function get_content_type
def test_get_content_type():
    # https://github.com/jupyterhub/binderhub/pull/1235#discussion_r308523709
    # added test
    assert get_content_type('binder') == 'application/octet-stream'
    # ensure this test exists
    assert get_content_type('binder.ipynb') == 'application/x-ipynb+json'

# Generated at 2022-06-21 14:57:44.314889
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:57:47.505742
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"foo": 123, "bar": 456}') == {
        'foo': 123,
        'bar': 456
    }


if __name__ == '__main__':
    import pytest
    pytest.main(['-sv', __file__])

# Generated at 2022-06-21 14:57:58.462099
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{}') == {}
    assert load_json_preserve_order('{"a": "1", "b": "2"}') == {
        'a': "1",
        'b': "2"
    }
    assert load_json_preserve_order('{"a": "1", "b": "2", "a": "2"}') == {
        'a': "2",
        'b': "2"
    }

# Generated at 2022-06-21 14:58:03.008072
# Unit test for function repr_dict
def test_repr_dict():
    d = {'foo': 'bar', 'baz': [1, 2, 3]}
    assert repr_dict(d) == "{'foo': 'bar', 'baz': [1, 2, 3]}"



# Generated at 2022-06-21 14:58:06.301037
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
    {
      "a": 1,
      "b": 2,
      "c": 3
    }
    """
    d = load_json_preserve_order(s)
    assert list(d.keys()) == ['a', 'b', 'c']

# Generated at 2022-06-21 14:58:14.406312
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; expires=Fri, 01 Jan 2038 00:00:00 GMT'),
        ('Set-Cookie', 'foo=bar; Max-Age=2'),
    ]
    expired_cookies = get_expired_cookies(headers, now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
    ]

# Generated at 2022-06-21 14:58:24.827986
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('README.rst') == 'text/x-rst; charset=us-ascii'
    assert get_content_type('README.txt') == 'text/plain; charset=us-ascii'
    assert get_content_type('pip-package-requirements.txt') == \
        'text/plain; charset=us-ascii'
    assert get_content_type('test_requests_toolbelt.py') == \
        'text/x-python; charset=us-ascii'
    assert get_content_type('setup.py') == 'text/x-python; charset=us-ascii'
    assert get_content_type('PKG-INFO') == 'text/plain; charset=us-ascii'

# Generated at 2022-06-21 14:58:26.189221
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 14:58:29.345584
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "OrderedDict([('a', 1)])"
    assert repr_dict({'a': 1, 'b': 2}) == "OrderedDict([('a', 1), ('b', 2)])"

# Generated at 2022-06-21 14:58:35.188440
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('doc.json') == 'application/json'
    assert get_content_type('doc.json; charset=UTF-8') == 'application/json; charset=UTF-8'
    assert get_content_type('invalid/path') is None

# Generated at 2022-06-21 14:58:39.291617
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests

    def f():
        return requests.get('http://example.com')

    # noinspection PyProtectedMember
    f.__self__.auth = ExplicitNullAuth()

    # noinspection PyProtectedMember
    assert f.__self__.auth.__call__(None) is None

# Generated at 2022-06-21 14:58:45.505476
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 14:58:48.686566
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('./foo/bar.js') == 'application/javascript'
    assert get_content_type('./foo/bar.js.map') == 'application/javascript'

# Generated at 2022-06-21 14:58:51.194292
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 14:58:53.143481
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': {'c': 2}}
    assert repr_dict(d) == repr(d)

# Generated at 2022-06-21 14:58:56.607021
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()(None) is None


# Generated at 2022-06-21 14:58:59.916241
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('stub.txt') == 'text/plain'
    assert get_content_type('stub.html') == 'text/html'
    assert get_content_type('stub.css') == 'text/css'
    assert get_content_type('stub.js') == 'application/javascript'

# Generated at 2022-06-21 14:59:01.171717
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    obj = ExplicitNullAuth()

    assert obj == obj

# Generated at 2022-06-21 14:59:11.662274
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime
    import time

    headers = [
        ('Content-Type', 'text/html; charset=utf-8'),
        ('Set-Cookie', 'session=529e6e3c6b3a6; Max-Age=3600; Path=/'),
        ('Set-Cookie', 'session=deleted; Expires=Sun, 31 May 2015 18:08:12 GMT'),
        ('Set-Cookie', 'session=deleted; Expires=Tue, 31 May 2016 18:08:12 GMT'),
    ]
    now = 1454367692

    expected = [
        {
            'name': 'session',
            'path': '/'
        }
    ]
    actual = get_expired_cookies(headers=headers, now=now)
    assert expected == actual



# Generated at 2022-06-21 14:59:14.180001
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import doctest
    # noinspection PyUnresolvedReferences
    doctest.testmod(verbose=True)


get_expired_cookies.__test__ = True

# Generated at 2022-06-21 14:59:15.064147
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()(object())

# Generated at 2022-06-21 14:59:18.252773
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": "b", "c": "d"}'
    d = load_json_preserve_order(s)
    expected = OrderedDict([('a', 'b'), ('c', 'd')])
    assert d == expected



# Generated at 2022-06-21 14:59:25.647352
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:59:30.516583
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({"a":"f","b":"g"}) == "{'a': 'f', 'b': 'g'}"
    assert repr_dict({}) == '{}'
    assert repr_dict({"a": {"a": "f"}}) == "{'a': {'a': 'f'}}"


# Generated at 2022-06-21 14:59:37.502707
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    with open('tests/fixtures/preserve-order.json') as file:
        json_string = file.read()

    result = load_json_preserve_order(json_string)

    # `result['items'][0]` is the item with `url=http://example.com/1`,
    # which is the first one in the `preserve-order.json` fixture
    assert 'content' in result['items'][0]

# Generated at 2022-06-21 14:59:42.356923
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_string = """
    {
        "foo": "bar",
        "baz": 42
    }
    """
    assert load_json_preserve_order(test_string) == {
        'foo': 'bar',
        'baz': 42
    }



# Generated at 2022-06-21 14:59:50.617517
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/foo/bar/') is None
    assert get_content_type('/foo/bar/file.txt') == 'text/plain'
    assert get_content_type('/foo/bar/.hidden') == 'text/plain'
    assert get_content_type('/foo/bar/.hidden.txt') == 'text/plain'
    assert get_content_type('/foo/bar/.hidden.pdf') == 'application/pdf'
    assert get_content_type('/foo/bar/binary_file') is None
    assert get_content_type('/foo/bar/binary_file.png') == 'image/png'


# Generated at 2022-06-21 14:59:59.287291
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [('1 B', 1), ('1.0 kB', 1024), ('123.0 kB', 1024 * 123),
             ('12.1 MB', 1024 * 12342), ('12.05 MB', 1024 * 12342, 2),
             ('1.21 MB', 1024 * 1234, 2), ('1.31 GB', 1024 * 1234 * 1111, 2),
             ('1.3 GB', 1024 * 1234 * 1111, 1)]

    for expected, n, precision in tests:
        result = humanize_bytes(n, precision)
        assert expected == result, '%s != %s' % (expected, result)


# Generated at 2022-06-21 15:00:03.140592
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = """{
        "c": 3,
        "a": 1,
        "b": 2
    }"""
    # Assert for equality
    assert(
        load_json_preserve_order(json_str) ==
        {'c': 3, 'a': 1, 'b': 2}
    )


# Generated at 2022-06-21 15:00:11.034507
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'name1=value1'),
        ('Set-Cookie', 'name2=value2; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'name3=value3; Max-Age=60'),
    ]

    expired_cookies = get_expired_cookies(headers, now=time.time())

    assert expired_cookies == [
        {'name': 'name1', 'path': '/'},
        {'name': 'name2', 'path': '/'},
        {'name': 'name3', 'path': '/'},
    ]

# Generated at 2022-06-21 15:00:12.212745
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

# Generated at 2022-06-21 15:00:21.409207
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.docx') == ('application/vnd.openxmlformats-'
                                             'officedocument.wordprocessingml.'
                                             'document')
    assert get_content_type('test.svg') == 'image/svg+xml'
    assert get_content_type('test.mp3') == 'audio/mpeg'
    assert get_content_type('test.json') == 'application/json'
    assert get_content_type('test.zip') == 'application/zip'
    assert get_content_type('test.unknown') is None

# Generated at 2022-06-21 15:00:28.994029
# Unit test for function get_content_type
def test_get_content_type():

    def check_content_type(filename, content_type):
        assert get_content_type(filename) == content_type

    check_content_type('.dotfile', None)
    check_content_type('gear.png', 'image/png')
    check_content_type('gear.PNG', 'image/png')
    check_content_type('gear.jpg', 'image/jpeg')
    check_content_type('gear.jpeg', 'image/jpeg')
    check_content_type('gear.JPEG', 'image/jpeg')
    check_content_type('file.txt.gz', 'application/x-gzip')
    check_content_type('file.txt', 'text/plain')
    check_content_type('file.txt.gz', 'application/x-gzip')
    check_

# Generated at 2022-06-21 15:00:39.654157
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from flask import make_response

    cookies = [
        [('Name', 'foo'), ('Value', 'baz')],
        [('Name', 'bar'), ('Value', 'qux')],
        [('Name', 'baz'), ('Value', 'corge')],
    ]

    now = time.time() - 3

    response = make_response('', 200)
    for cookie in cookies:
        response.headers.add('Set-Cookie', '; '.join(f'{k}={v}' for k, v in cookie))


# Generated at 2022-06-21 15:00:43.951263
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"a": 1, "b": [1, 2, 3], "c": {"d": 4, "e": 5}}'
    json_object = load_json_preserve_order(json_string)
    assert list(json_object.keys()) == ['a', 'b', 'c']