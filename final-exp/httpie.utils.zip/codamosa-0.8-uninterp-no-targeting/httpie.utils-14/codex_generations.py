

# Generated at 2022-06-21 14:55:42.980163
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from pytest import raises

    with raises(AssertionError, match=r'^headers must be a non-empty list$'):
        get_expired_cookies(headers=[])

    headers_no_cookies = [('foo', 'bar')]

    assert not get_expired_cookies(headers=headers_no_cookies)

    headers_one_non_cookie = [(
        'Set-Cookie',
        'foo=bar; Domain=github.com; Path=/; Secure; HttpOnly'
    )]

    assert not get_expired_cookies(headers=headers_one_non_cookie)


# Generated at 2022-06-21 14:55:48.089401
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    string_with_ordered_dict = '{"a": 1, "b": 2}'
    ordered_dict = load_json_preserve_order(string_with_ordered_dict)
    assert isinstance(ordered_dict, OrderedDict), "Expected `OrderedDict`, got {}".format(
        type(ordered_dict))

# Generated at 2022-06-21 14:55:50.809136
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.txt') == 'text/plain'

# Generated at 2022-06-21 14:55:55.997665
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
    {
        "beta": "beta value",
        "gamma": "gamma value",
        "alpha": "alpha value"
    }
    """
    expected = OrderedDict([
        ('beta', 'beta value'),
        ('gamma', 'gamma value'),
        ('alpha', 'alpha value'),
    ])
    assert load_json_preserve_order(s) == expected



# Generated at 2022-06-21 14:56:04.234583
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 14:56:08.751877
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    r = requests.Request(
        method='GET',
        url='http://example.com',
        auth=ExplicitNullAuth(),
    )
    p = r.prepare()
    assert 'Authorization' not in p.headers

# Generated at 2022-06-21 14:56:09.646075
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)

# Generated at 2022-06-21 14:56:21.917007
# Unit test for function repr_dict
def test_repr_dict():
    # Test that repr_dict() doesn't sort dictionaries
    d = {
        "foo": "bla",
        "bar": "bla",
        "bar1": "bla",
        "bar2": "bla",
        "bar3": "bla",
        "bar4": "bla",
        "bar5": "bla",
        "bar6": "bla",
        "bar7": "bla",
        "bar8": "bla",
        "bar9": "bla",
        "bar10": "bla",
        "bar11": "bla",
        "bar12": "bla",
    }

# Generated at 2022-06-21 14:56:32.944863
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import timedelta, datetime
    now = datetime.now()
    prev = now - timedelta(days=5)


# Generated at 2022-06-21 14:56:33.654035
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 14:56:44.167286
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:56:54.763803
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # type: () -> None
    now = 1465486856.4151282  # 2016-06-09T16:00:56.415128-07:00
    now_http = 'Thu, 09 Jun 2016 16:00:56 GMT'

# Generated at 2022-06-21 14:57:01.641363
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('note.txt') == 'text/plain'
    assert get_content_type('__init__.py') == 'text/x-python'
    assert get_content_type('index.html') == 'text/html'
    assert get_content_type('README.rst') == 'text/x-rst'
    assert get_content_type('/dev/null') is None
    assert get_content_type('.') is None

# Generated at 2022-06-21 14:57:08.950075
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


# Generated at 2022-06-21 14:57:16.001175
# Unit test for function get_content_type
def test_get_content_type():
    # Mimetype of the file used to write the unit test.
    assert get_content_type(__file__) == 'text/x-python'

    # Mimetype of the (manually crafted) file used to write the unit test.
    assert get_content_type('foo.json') == 'application/json'

    # Mimetype of a file for which no mimetype is registered with
    # mimetypes.
    assert get_content_type('foo.bar') is None

# Generated at 2022-06-21 14:57:22.524630
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # a = get_expired_cookies(['foo=bar; Expires=Tue, 24 Dec 2019 11:25:03 GMT; HttpOnly; Secure; Path=/'])
    # print(a)
    # assert a == []

    a = get_expired_cookies(['foo=bar; max-age=600; HttpOnly; Secure; Path=/'], 1567064113)
    print(a)
    assert a == []

    a = get_expired_cookies(['foo=bar; max-age=1; HttpOnly; Secure; Path=/'], 1567064113)
    print(a)
    assert a == [{'name': 'foo', 'path': '/'}]


# Generated at 2022-06-21 14:57:29.811993
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_text = """{
        "1": ["a", "b", "c"],
        "2": ["a", "b", "c"],
        "3": ["a", "b", "c"]
    }"""
    j = load_json_preserve_order(json_text)
    expected = dict(
        [(str(i), ["a", "b", "c"]) for i in range(1, 4)]
    )
    assert j == expected



# Generated at 2022-06-21 14:57:37.321545
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'foo': 'bar',
        'baz': 'quux',
        'key': {'nested': 'value'},
    }
    assert repr_dict(d) == (
        "{\n"
        "    'baz': 'quux',\n"
        "    'foo': 'bar',\n"
        "    'key': {'nested': 'value'},\n"
        "}"
    )

# Generated at 2022-06-21 14:57:45.564195
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert (
        humanize_bytes(1024 * 1234 * 1111, precision=2)
        ==
        '1.31 GB'
    )

# Generated at 2022-06-21 14:57:53.946813
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.css') == 'text/css'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.xml') == 'application/xml'



# Generated at 2022-06-21 14:57:57.895555
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    func = ExplicitNullAuth()
    assert func('arg') == 'arg'


# Generated at 2022-06-21 14:58:07.384937
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = (
        ('Set-Cookie', 'sessionid=123; Domain=.example.org; Secure; HttpOnly'),
        ('Set-Cookie', 'foo=bar'),
        ('Set-cookie', 'baz=quux; Expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-cookie', 'one=two; Max-Age=600; Domain=.example.org'),
    )
    expected = [
        {'name': 'baz', 'path': '/'},
        {'name': 'one', 'path': '/'},
    ]
    cookies = get_expired_cookies(headers, now=0)
    assert cookies == expected

# Generated at 2022-06-21 14:58:12.421169
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/dev/null') == 'application/x-empty'
    assert get_content_type('/dev/null.bin') == 'application/octet-stream'
    assert get_content_type('/dev/null.bin.gz') == 'application/gzip'

# Generated at 2022-06-21 14:58:22.748115
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def assert_cookies_match(r, cookies):
        assert r == get_expired_cookies(headers=[
            ('Set-Cookie', cookie)
            for cookie in cookies
        ])

    assert_cookies_match([], [])
    assert_cookies_match(
        [{'name': 'name1'}],
        ['name1=value1']
    )
    assert_cookies_match(
        [{'name': 'name1'}],
        ['name1=value1; expires=invalid-date']
    )
    assert_cookies_match(
        [{'name': 'name1', 'path': '/'}],
        ['name1=value1; path=/']
    )

# Generated at 2022-06-21 14:58:27.415106
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    u"""ExplicitNullAuth.__call__() → returns the same passed argument."""

    # Arrange
    auth = ExplicitNullAuth()
    request = object()

    # Act
    actual = auth(request)

    # Assert
    assert actual is request

# Generated at 2022-06-21 14:58:30.424540
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1,b=2)) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 14:58:36.926973
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'foo': 'bar',
        'baz': [
            (1, 2, 'hey'),
            {'spam': 'eggs'}
        ]
    }
    result = repr_dict(d)
    expected = """\
{'baz': [(1, 2, 'hey'), {'spam': 'eggs'}],
 'foo': 'bar'}"""
    assert result == expected



# Generated at 2022-06-21 14:58:37.635719
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:58:40.580247
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    input_json = '{"a": 1, "b": 2}'
    expected_output = OrderedDict([("a", 1), ("b", 2)])
    assert load_json_preserve_order(input_json) == expected_output

# Generated at 2022-06-21 14:58:43.694459
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"key": 1, "other_key": 2}'
    assert load_json_preserve_order(s) == OrderedDict([
        ("key", 1),
        ("other_key", 2)
    ])


# Generated at 2022-06-21 14:58:46.264326
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-21 14:58:51.244953
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import get
    from . import MOCK_SERVER_URL

    try:
        get(MOCK_SERVER_URL, auth=ExplicitNullAuth())
    except:
        raise AssertionError(
            'The authentication credentials must stay empty and '
            '``.netrc`` must be ignored.')

# Generated at 2022-06-21 14:58:52.456755
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'



# Generated at 2022-06-21 14:59:00.668038
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


# Generated at 2022-06-21 14:59:01.596316
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None



# Generated at 2022-06-21 14:59:12.152810
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    s = """<!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title></title>
      </head>
      <body>

      </body>
    </html>
    """
    expected = """<!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title></title>
      </head>
      <body>

      </body>
    </html>
    """
    import requests
    from pprint import pformat

    URL = 'https://httpbin.org/'
    auth = ExplicitNullAuth()
    r = requests.get(URL, auth=auth)
    r.raise_for_status()
    session = requests.Session()
    r = session.get

# Generated at 2022-06-21 14:59:13.182483
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-21 14:59:21.546042
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('x.txt') == 'text/plain'
    assert get_content_type('x.html') == 'text/html'
    assert get_content_type('x.png') == 'image/png'
    assert get_content_type('x.gif') == 'image/gif'
    assert get_content_type('x.jpg') == 'image/jpeg'
    assert get_content_type('x.jpeg') == 'image/jpeg'
    assert get_content_type('x.zip') == 'application/zip'
    assert get_content_type('x.pdf') == 'application/pdf'
    assert get_content_type('x.csv') == 'text/csv'
    assert get_content_type('x.exe') == 'application/octet-stream'

# Generated at 2022-06-21 14:59:24.685603
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '''{"a": ["b", "c"], "d": [true, false]}'''
    assert load_json_preserve_order(json_str) == OrderedDict([
        ('a', ['b', 'c']),
        ('d', [True, False])
    ])



# Generated at 2022-06-21 14:59:35.756913
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:59:40.049524
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    r = auth(r=requests.Request())
    assert isinstance(r, requests.PreparedRequest)



# Generated at 2022-06-21 14:59:49.268531
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([
        (None, 'foo=bar; Expires=Sun, 31-Dec-2017 23:59:59 GMT; Path=/'),
        (None, 'foo=bar; Max-Age=1; Path=/'),
    ], now=time.time()) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'foo', 'path': '/'},
    ]
    assert get_expired_cookies([
        (None, 'foo=bar; Expires=Sun, 31-Dec-2028 23:59:59 GMT; Path=/'),
        (None, 'foo=bar; Max-Age=1; Path=/'),
    ], now=time.time()) == [
        {'name': 'foo', 'path': '/'},
    ]
    assert get_ex

# Generated at 2022-06-21 14:59:54.113778
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'z': {'a': 1, 'b': 2}}) == "{'z': {'a': 1, 'b': 2}}"


# Generated at 2022-06-21 14:59:56.761335
# Unit test for function repr_dict
def test_repr_dict():

    d = {'key1': 'value1', 'key2': 'value2'}
    assert repr_dict(d) == "{'key1': 'value1', 'key2': 'value2'}"

# Generated at 2022-06-21 14:59:59.068920
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert(load_json_preserve_order('{"a":1, "b":2}') == {"a":1, "b":2})

# Generated at 2022-06-21 14:59:59.954156
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 15:00:02.889966
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Instantiate the class.
    explicit_null_auth = ExplicitNullAuth()

    # Arrange
    response = object()

    # Act
    actual_result = explicit_null_auth(response)

    # Assert
    assert actual_result is response

# Generated at 2022-06-21 15:00:11.034921
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import AuthBase

    class TestAuth(AuthBase):
        def __call__(self, request):
            raise NotImplementedError

    explicit_null_auth = ExplicitNullAuth()
    test_auth = TestAuth()
    r = requests.Request('POST', 'http://example.com')
    assert str(explicit_null_auth) == '<{}>'.format(
        explicit_null_auth.__class__.__name__
    )
    assert str(test_auth) == '<{}>'.format(test_auth.__class__.__name__)
    assert isinstance(explicit_null_auth, AuthBase)

# Generated at 2022-06-21 15:00:21.168601
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    t = time.time() - 10

# Generated at 2022-06-21 15:00:28.575738
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'