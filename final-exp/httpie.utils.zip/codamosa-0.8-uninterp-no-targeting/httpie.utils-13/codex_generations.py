

# Generated at 2022-06-21 14:55:27.913544
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    pass # TODO


# Generated at 2022-06-21 14:55:35.595904
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(2) == "2 B", "2 B"
    assert humanize_bytes(2 ** 10) == "1.0 kB", "1.0 kB"
    assert humanize_bytes(2 ** 20, 1) == "1.0 MB", "1.0 MB"
    assert humanize_bytes(2 ** 30, 2) == "1.07 GB", "1.07 GB"


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', '--tb=native', '-x', __file__])

# Generated at 2022-06-21 14:55:40.139342
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b', 'c': 'd'}) == "{'a': 'b', 'c': 'd'}"
    assert repr_dict({'a': 'b', 'c': 'd', 'e': {'f': 'g', 'h': 'i'}}) == \
        "{'a': 'b', 'c': 'd', 'e': {'f': 'g', 'h': 'i'}}"



# Generated at 2022-06-21 14:55:42.410089
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/home/user/darpa.png') == 'image/png'
    assert not get_content_type('/home/user/.bashrc')

# Generated at 2022-06-21 14:55:53.326071
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # from: https://code.activestate.com/recipes/577081/
    # License: MIT
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-21 14:55:54.185378
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()



# Generated at 2022-06-21 14:55:58.188765
# Unit test for function get_content_type
def test_get_content_type():
    from pytest import approx

    assert get_content_type('test_get_content_type.py') == 'text/x-python'
    assert get_content_type('test_get_content_type.py.gz') == \
        'application/x-gzip'
    assert get_content_type('test_get_content_type.py.zip') == \
        'application/zip'



# Generated at 2022-06-21 14:56:02.278192
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": "b"}') == OrderedDict([('a', 'b')])
    assert load_json_preserve_order('{"b": "b", "a": "a"}') == OrderedDict([('b', 'b'), ('a', 'a')])



# Generated at 2022-06-21 14:56:11.543914
# Unit test for function repr_dict
def test_repr_dict():
    from unittest import TestCase
    from textwrap import dedent

    class ReprDictTestCase(TestCase):
        def test_repr_dict(self):
            self.assertMultiLineEqual(
                repr_dict({'foo': 'bar', 'baz': 'quux'}),
                dedent('''\
                {'baz': 'quux',
                 'foo': 'bar'}''')
            )

    test_repr_dict = ReprDictTestCase('test_repr_dict')
    test_repr_dict.test_repr_dict()
    del test_repr_dict
    del ReprDictTestCase

# Generated at 2022-06-21 14:56:17.275018
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    header = (
        'Set-Cookie',
        'foo=bar; expires=Fri, 21 Oct 2016 07:28:00 GMT;'
        ' Max-Age=600; path=/; secure'
    )
    cookies = get_expired_cookies([header], now=time.time())
    assert cookies == []



# Generated at 2022-06-21 14:56:21.003764
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()


# Generated at 2022-06-21 14:56:25.973667
# Unit test for function repr_dict
def test_repr_dict():
    def assert_repr(expected, value):
        assert expected == repr_dict(value)

    assert_repr("{}", {})
    assert_repr("{'a': 1}", {'a': 1})
    assert_repr("{'a': {'b': 1}}", {'a': {'b': 1}})

# Generated at 2022-06-21 14:56:28.808744
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(None) == None



# Generated at 2022-06-21 14:56:37.696064
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = (
        ('Set-Cookie', 'foo=bar'),
        ('Set-Cookie', 'name=value; '
                       'expires=Wed, 09-Jun-2021 10:18:14 GMT'),
        ('Set-Cookie', 'name=value; '
                       'max-age=14400; '
                       'path=/'),
        ('set-cookie', 'name=value; '
                       'max-age=14400; '
                       'path=/'),
    )
    assert get_expired_cookies(headers) == [
        {
            'name': 'foo',
            'path': '/',
        }
    ]

# Generated at 2022-06-21 14:56:44.420784
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """Test ExplicitNullAuth() does not set ''Authorization'' header."""
    import unittest
    from http.cookies import SimpleCookie

    from . import ExplicitNullAuth

    class TestExplicitNullAuth(unittest.TestCase):
        def setUp(self):
            class MockResponse:
                def __init__(self):
                    self.headers = {}

            self.mock_req = SimpleCookie()
            self.mock_resp = MockResponse()
            self.auth = ExplicitNullAuth()

        def test_ExplicitNullAuth___call__(self):
            self.mock_req['Authorization'] = 'foo'
            self.assertTrue(self.mock_req.output())
            self.auth(self.mock_resp)
            self.assertTrue(self.mock_req.output())

# Generated at 2022-06-21 14:56:46.212316
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # No exceptions should be raised during the call.
    ExplicitNullAuth()(None)

# Generated at 2022-06-21 14:56:50.502130
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = """{"c":3,"a":1,"b":2}"""
    assert load_json_preserve_order(json_string) == {"a": 1, "b": 2, "c": 3}



# Generated at 2022-06-21 14:56:57.980258
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest
    from datetime import datetime, timedelta

    # The date format in a cookie is:
    # Wed, 03 Jan 2018 14:59:00 GMT
    date_fmt = "%a, %d %b %Y %H:%M:%S GMT"

    headers = [
        ('Set-Cookie', 'a=1'),
        ('Set-Cookie', 'b=2; Max-Age=60; Path=/foo/bar'),
        ('Set-Cookie', 'c=3; Expires={}'.format(
            (datetime.utcnow() + timedelta(seconds=60)).strftime(date_fmt))),
        ('Set-Cookie', 'd=4; Expires=Wed, 03 Jan 2018 14:59:00 GMT'),
    ]


# Generated at 2022-06-21 14:57:01.393234
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'foo': 'bar', 'bat': 'baz'}) == (
        "{\n"
        "    'bat': 'baz',\n"
        "    'foo': 'bar'\n"
        "}"
    )

# Generated at 2022-06-21 14:57:11.013573
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        (
            'Set-Cookie',
            'sessionid=example; domain=site.example.com; path=/; secure'
        ),
        (
            'Set-Cookie',
            'max-age-only=example; Max-Age=86400; Path=/'
        ),
        (
            'Set-Cookie',
            'expires-only=example; Expires=Wed, 13 Jan 2021 22:23:01 GMT; Path=/'
        ),
        (
            'Set-Cookie',
            'always-expired=example; Max-Age=1; Path=/'
        )
    ]
    now = int(time.time())
    expired_cookies = get_expired_cookies(headers=headers, now=now - 10)

# Generated at 2022-06-21 14:57:13.330556
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth

# Generated at 2022-06-21 14:57:16.143439
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 2, "b": 3, "c": 4}') == OrderedDict([('a', 2), ('b', 3), ('c', 4)])

# Generated at 2022-06-21 14:57:22.589754
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from http.cookies import SimpleCookie
    from wsgiref.util import request_uri

    def get_expired_cookies_from_headers(
        headers: List[Tuple[str, str]],
        now: float = None
    ) -> List[dict]:
        now = now or time.time()

        def is_expired(expires: Optional[float]) -> bool:
            return expires is not None and expires <= now

        attr_sets: List[Tuple[str, str]] = parse_ns_headers(
            value for name, value in headers
            if name.lower() == 'set-cookie'
        )

# Generated at 2022-06-21 14:57:26.023461
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth().__call__('a')
    ExplicitNullAuth().__call__(b'f')
    ExplicitNullAuth().__call__(1)
    ExplicitNullAuth().__call__(None)

# Generated at 2022-06-21 14:57:28.194038
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    response = auth('DUMMY')
    assert response == 'DUMMY'

# Generated at 2022-06-21 14:57:29.053378
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ...

# Generated at 2022-06-21 14:57:40.224775
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1549597939.206965
    headers = [
        ('Set-Cookie', 'foo=bar; Expires=Tue, 01 Jan 2019 00:00:00 GMT'),
        ('Set-Cookie', 'bar=baz; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Expires=Thu, 01 Jan 2021 00:00:00 GMT'),
        ('Set-Cookie', 'qux=quux; Expires=Tue, 01 Jan 2022 00:00:00 GMT'),
    ]

# Generated at 2022-06-21 14:57:42.338874
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({
        'foo': 42,
        'bar': 'spam'
    }) == "{'bar': 'spam', 'foo': 42}"

# Generated at 2022-06-21 14:57:43.444040
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import doctest
    doctest.testmod(verbose=False)


# Generated at 2022-06-21 14:57:44.918713
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import AuthBase

    assert issubclass(ExplicitNullAuth, AuthBase)

