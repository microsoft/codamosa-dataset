

# Generated at 2022-06-21 14:55:32.409889
# Unit test for function get_content_type
def test_get_content_type():

    assert get_content_type("foo.bar") is None
    assert get_content_type("foo.txt") == "text/plain"
    assert get_content_type("foo.rst") == "text/x-rst"
    assert get_content_type("foo.svg") == "image/svg+xml"
    assert get_content_type("foo.csv") == "text/csv"
    assert get_content_type("foo.xlsx") == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

# Generated at 2022-06-21 14:55:37.169006
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    Unit test for function load_json_preserve_order
    """
    test_string = '''{"a": 123, "b": 456}'''
    test_result = load_json_preserve_order(test_string)
    assert 123 == test_result['a']
    assert 456 == test_result['b']

# Generated at 2022-06-21 14:55:42.286601
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(None) == 'None'
    assert repr_dict(1) == "1"
    assert repr_dict({}) == "{}"
    assert repr_dict(dict(name='foo')) == "{'name': 'foo'}"
    assert repr_dict(dict(name='foo',num=1)) == "{'name': 'foo', 'num': 1}"
    assert repr_dict(('a','b')) == "('a', 'b')"
    assert repr_dict(('a',('b','c'))) == "('a', ('b', 'c'))"

# Generated at 2022-06-21 14:55:47.561002
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # noinspection PyUnresolvedReferences
    from .form.test_form import headers
    expired = get_expired_cookies(
        headers=headers,
        now=time.time() + 1
    )
    cookie = expired[0]
    assert cookie['name'] == 'csrftoken'
    assert cookie['path'] == '/'

# Generated at 2022-06-21 14:55:49.937672
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    class Request(object):
        auth = True

    instance = ExplicitNullAuth()
    assert instance(Request()) == Request()



# Generated at 2022-06-21 14:55:57.802184
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    # This assert will fail in the year 2017
    assert get_expired_cookies(
        headers=[b'Set-Cookie: session=7fd1d07e1ed7c52e54d3b769c3e9f1a9']
    ) == [
        {'name': 'session', 'path': '/'}
    ]


# Generated at 2022-06-21 14:55:58.336349
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 14:55:59.874452
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    a = ExplicitNullAuth()
    r = a('test')
    assert r == 'test'

# Generated at 2022-06-21 14:56:06.263199
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import io
    from http.cookies import SimpleCookie

    # Test cookie without expiration.
    set_cookie_headers = [
        ('host', 'foo.com'),
        ('set-cookie', 'sessionToken=abc123; Secure; HttpOnly'),
    ]
    expired_cookies = get_expired_cookies(set_cookie_headers)
    assert expired_cookies == []

    # Test cookies with expiration.
    set_cookie_headers = [
        ('host', 'foo.com'),
        ('set-cookie', 'sessionToken=foo; Secure; HttpOnly'),
        ('set-cookie', 'foo=bar; Expires=Sun, 04 Jan 2038 07:28:07 GMT'),
    ]
    expired_cookies = get_expired_cookies(set_cookie_headers)
    assert expired_cookies

# Generated at 2022-06-21 14:56:10.217802
# Unit test for function repr_dict
def test_repr_dict():
    from pprint import pformat
    from collections import OrderedDict

    d = OrderedDict([('2', 2), ('1', 1)], my_attr='value')
    result = repr_dict(d)
    assert result == pformat(d)

# Generated at 2022-06-21 14:56:13.253716
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo/bar.txt') == 'text/plain'

# Generated at 2022-06-21 14:56:15.032893
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth(None) is None

# Generated at 2022-06-21 14:56:17.125222
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)



# Generated at 2022-06-21 14:56:27.727212
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

    def assert_expired(headers, count=1):
        assert len(get_expired_cookies(headers=headers, now=now)) == count

    assert_expired([
        (
            'Set-Cookie',
            'foo=bar; Expires=Mon, 1 Jan 2018 13:37:00 GMT; Path=/'
        )
    ])

    assert_expired([
        (
            'Set-Cookie',
            'foo=bar; Max-Age=1; Path=/'
        )
    ], 0)

    assert_expired([
        (
            'Set-Cookie',
            'foo=bar; Max-Age=1; Path=/'
        )
    ], 0)
    # No Max-Age, no Expires.

# Generated at 2022-06-21 14:56:29.206317
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth is not None



# Generated at 2022-06-21 14:56:35.852839
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('.py') == 'text/x-python'
    assert get_content_type('README.md') == 'text/markdown'
    assert get_content_type('foo') == None
    assert get_content_type('/a/b/c.txt') == 'text/plain'
    assert get_content_type('c:\\a\\b\\c.txt') == 'text/plain'

# Generated at 2022-06-21 14:56:45.935882
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:56:55.854915
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import requests
    from freezegun import freeze_time
    from datetime import datetime, timedelta

    def get_cookie_dicts(resp) -> List[dict]:
        return get_expired_cookies(
            headers=resp.headers._store.items(),
            now=datetime_to_timestamp(datetime.utcnow())
        )

    @freeze_time('2020-09-10 00:00')
    def test():
        resp = requests.get('https://github.com')
        expired_cookies = get_cookie_dicts(resp)
        assert len(expired_cookies) == 0
        assert expired_cookies == []

        resp = requests.get('http://httpbin.org/cookies/set?expired=true')
        expired_cookies = get_cookie_dicts

# Generated at 2022-06-21 14:57:01.206961
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(
        dict(a=1, b=2)
    ) == "{'a': 1, 'b': 2}"

    assert repr_dict(
        dict(a=1, b=2, c=dict(d=4, e=5))
    ) == "{'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}"

# Generated at 2022-06-21 14:57:03.407388
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    session = requests.Session()
    session.auth = ExplicitNullAuth()
    r = session.get('http://example.com')
    assert r.status_code == 200

# Generated at 2022-06-21 14:57:06.970214
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # noinspection PyUnresolvedReferences
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 14:57:09.706286
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order("{\"ab\": 1, \"c\": 2, \"d\": 3}") == {
        'ab': 1,
        'c': 2,
        'd': 3
    }

# Generated at 2022-06-21 14:57:19.792392
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '''
{
    "first_name": "Guido",
    "last_name": "Rossum",
    "titles": [
        "BDFL",
        "Developer"
    ]
}
    '''

    json_dict = load_json_preserve_order(json_string)

    first_name = json_dict.get('first_name', None)
    assert first_name is not None and first_name == 'Guido'

    last_name = json_dict.get('last_name', None)
    assert last_name is not None and last_name == 'Rossum'

    titles = json_dict.get('titles', None)
    assert titles is not None and isinstance(titles, list)

    json_string_1 = json.dumps(json_dict)
   

# Generated at 2022-06-21 14:57:31.510902
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    from six.moves.urllib.parse import urljoin

    now = datetime.now()


# Generated at 2022-06-21 14:57:37.133992
# Unit test for function repr_dict
def test_repr_dict():
    class Dummy(object):
        def __repr__(self):
            return '42'
    assert repr_dict({'a': Dummy(), 'b': {'c': 'd'}}) == "OrderedDict([('a', 42), ('b', {'c': 'd'})])"

# Generated at 2022-06-21 14:57:45.993526
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert (
        humanize_bytes(1024 * 1234 * 1111, precision=2)
        == '1.31 GB'
    )

# Generated at 2022-06-21 14:57:57.908776
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/etc/passwd') == 'text/plain'
    assert get_content_type('/tmp/ab.txt') == 'text/plain'
    assert get_content_type('/tmp/ab.pdf') == 'application/pdf'
    assert get_content_type('/tmp/ab.ttf') == 'application/x-font-ttf'


if __name__ == '__main__':
    import pprint
    print(repr_dict(
        load_json_preserve_order(
            """[{"a": "b"}, {"c": {"d": "e"}}]"""
        )
    ))
    print(
        humanize_bytes(
            1024 * 1234,
            precision=2
        )
    )


# Generated at 2022-06-21 14:58:08.580324
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([]) == []
    assert get_expired_cookies(
        [('Set-Cookie', 'foo=bar; path=/; HttpOnly; Secure; SameSite=strict')]
    ) == []
    assert get_expired_cookies(
        [
            (
                'Set-Cookie',
                'foo=bar; path=/; expires=Wed, 31 Jul 2019 08:00:00 GMT;'
                ' HttpOnly; Secure; SameSite=strict'
            )
        ],
        now=1564566800.0
    ) == []

# Generated at 2022-06-21 14:58:17.361595
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type(None) is None
    assert get_content_type('filename') is None
    assert get_content_type('./tests/data/test') is None
    assert get_content_type('./') is None
    assert get_content_type('./tests/data/test.html') == 'text/html'
    assert get_content_type('./tests/data/test.json') == 'application/json'
    assert get_content_type('./tests/data/test.xml') == 'application/xml'
    assert get_content_type('./tests/data/test.csv') == 'text/csv'
    assert get_content_type('./tests/data/test.jpg') == 'image/jpeg'
   

# Generated at 2022-06-21 14:58:28.391989
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:58:30.801946
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:58:41.038446
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert (humanize_bytes(1024 * 1234 * 1111, precision=2)
            == '1.31 GB')
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:58:51.926881
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({'a': ['b', 'c']}) == "{'a': ['b', 'c']}"
    assert repr_dict({'a': ['b', 'c', {'d': 'e'}]}) == "{'a': ['b', 'c', {'d': 'e'}]}"

    d = OrderedDict()
    d['b'] = 2
    d['a'] = 1
    assert repr_dict(d) == "{'b': 2, 'a': 1}"

    d = OrderedDict()
    d['b'] = 2
    d['a'] = OrderedDict()
    d['a']['c'] = 3


# Generated at 2022-06-21 14:58:52.924693
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    x = ExplicitNullAuth()
    assert x == x

# Generated at 2022-06-21 14:59:00.538672
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time() - 10

    assert get_expired_cookies([
        ('Set-Cookie',
         ('__Host-f1=; Expires=Thu, 01 Jan 1970 00:00:01 GMT; '
          'Max-Age=0; Path=/; Domain=.dom; Secure'))
    ], now=now) == [
        {'name': '__Host-f1', 'path': '/'}
    ]

    assert get_expired_cookies([
        ('Set-Cookie',
         ('__Host-f1=; Max-Age=0; Path=/; Domain=.dom; Secure'))
    ], now=now) == [
        {'name': '__Host-f1', 'path': '/'}
    ]

# Generated at 2022-06-21 14:59:03.733701
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from unittest.mock import Mock

    auth = ExplicitNullAuth()
    request = Mock()
    request.__class__ = type('Request', (object,), {})
    request.prepare_auth.return_value = None

    assert auth(request) is None



# Generated at 2022-06-21 14:59:04.964762
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth._wrapped == None



# Generated at 2022-06-21 14:59:07.360876
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    try:
        auth = ExplicitNullAuth()
        return True
    except ValueError:
        return False


# Generated at 2022-06-21 14:59:10.044613
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == '<ExplicitNullAuth()>'
    assert auth.__call__('test') == 'test'



# Generated at 2022-06-21 14:59:19.285368
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.auth import HTTPDigestAuth, HTTPBasicAuth

    def _get_auth(s):
        return s.auth

    timeout = 10
    s = Session()
    assert not _get_auth(s)

    s.auth = HTTPDigestAuth('username', 'password')
    assert isinstance(_get_auth(s), HTTPDigestAuth)

    s.auth = ExplicitNullAuth()
    assert not _get_auth(s)

    s.auth = HTTPBasicAuth('username', 'password')
    assert isinstance(_get_auth(s), HTTPBasicAuth)

    s.auth = ExplicitNullAuth()
    assert not _get_auth(s)

    s.auth = (HTTPDigestAuth('username', 'password'), ExplicitNullAuth())
    assert not _get

# Generated at 2022-06-21 14:59:28.732135
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024 * 123) == '123.0 kB'
    assert humanize_bytes(1024 * 12342) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-21 14:59:30.433433
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    x = ExplicitNullAuth()
    r = requests.Request('GET')
    r = x(r)
    pass

# Generated at 2022-06-21 14:59:31.413482
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()({})

# Generated at 2022-06-21 14:59:36.654852
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from pprint import pprint
    import requests

    r = requests.head(url='http://example.com',
                      headers={'Accept-Language': 'en'})
    pprint(r.headers)
    pprint(get_expired_cookies(r.headers))

# Generated at 2022-06-21 14:59:38.832924
# Unit test for function get_content_type
def test_get_content_type():
    """
    Test that the content type is correctly determined.

    """
    filename = 'foo.tar.gz'
    assert get_content_type(filename) == 'application/x-gtar'

# Generated at 2022-06-21 14:59:47.345489
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 14:59:47.841111
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:59:58.730460
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1515764800.0
    header_text = (
        'foo=bar; Path=/; Expires=Mon, 15 Jan 2018 19:00:00 GMT,'
        ' foo=baz; Path=/foo/; Expires=Mon, 15 Jan 2018 09:00:00 GMT,'
        ' foo=buzz; Path=/; Max-Age=60,'
        ' foo=bird; Path=/; Max-Age=500,'
        ' foo=barry; Path=/; Expires=Tue, 16 Jan 2018 17:00:00 GMT,'
        ' foo=baron; Path=/; Expires=Tue, 16 Jan 2018 17:00:00 GMT; Secure,'
        ' foo=barbert; Path=/; Expires=Tue, 16 Jan 2018 17:00:00 GMT; HttpOnly'
    )

# Generated at 2022-06-21 15:00:00.804486
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-21 15:00:06.923540
# Unit test for function get_content_type
def test_get_content_type():
    """
    >>> test_get_content_type()
    """
    assert get_content_type(filename='README.md') == \
        get_content_type(filename='README.md; charset=utf8') == \
        'text/plain'

    assert get_content_type(filename='requests_test.py') == \
        get_content_type(filename='requests_test.py; charset=utf8') == \
        'text/x-python'

    assert get_content_type(filename='math_toq_pt.png') == \
        'image/png'

    assert get_content_type(filename='math_toq_pt.png; charset=utf8') == \
        'image/png; charset=utf8'

# Generated at 2022-06-21 15:00:10.825331
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo') == 'text/plain'



# Generated at 2022-06-21 15:00:11.947280
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)

# Generated at 2022-06-21 15:00:21.838824
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from .cookie import CookieJar
    from .request import Request
    from .response import Response
    from .responses import Headers

    request = Request(
        method='GET',
        url='http://httpbin.org/cookies/set?foo=bar',
    )

# Generated at 2022-06-21 15:00:26.321283
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'name': 'Alice',
        'age': '42',
        'address': {
            'street': 'Wonderland',
            'number': '123'
        }
    }
    assert repr_dict(d) == r"""{
    'name': 'Alice',
    'age': '42',
    'address': {
        'street': 'Wonderland',
        'number': '123'
    }
}"""

# Generated at 2022-06-21 15:00:27.994216
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth_obj = ExplicitNullAuth()
    assert auth_obj is not None


# Generated at 2022-06-21 15:00:29.102406
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None


# Generated at 2022-06-21 15:00:33.552081
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from .session import MockSession

    mock_session = MockSession()
    mock_session.set_cookie('/', 'fruit', 'banana')
    mock_session.set_cookie('/', 'vegetable', 'carrot', expires=None)


# Generated at 2022-06-21 15:00:44.864654
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:00:53.504688
# Unit test for function humanize_bytes
def test_humanize_bytes():
    """
    >>> test_humanize_bytes()
    1 B
    1.0 kB
    123.0 kB
    12.1 MB
    12.05 MB
    1.21 MB
    1.31 GB
    1.3 GB
    """
    tests = [
        (1, "1 B"),
        (1024, "1.0 kB"),
        (1024*123, "123.0 kB"),
        (1024*12342, "12.1 MB"),
        (1024*12342, "12.05 MB", 2),
        (1024*1234, "1.21 MB", 2),
        (1024*1234*1111, "1.31 GB", 2),
        (1024*1234*1111, "1.3 GB", 1),
    ]

# Generated at 2022-06-21 15:01:03.742630
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:01:09.743631
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert a



# Generated at 2022-06-21 15:01:11.321963
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': ' b ', 'c': 2}) == "{'a': 'b', 'c': 2}"

# Generated at 2022-06-21 15:01:13.309665
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'foo': 'bar'}) == (
        "{\n"
        "    'foo': 'bar'\n"
        "}"
    )



# Generated at 2022-06-21 15:01:22.215905
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 15:01:28.977014
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'a': 1,
        'b': (1, 2, 3),
        'c': {'a': 1, 'b': 2},
        'd': (3, (1, 2), {'a': 1, 'b': 2})
    }
    assert repr_dict(d) == """{
    'a': 1,
    'b': (1, 2, 3),
    'c': {'a': 1, 'b': 2},
    'd': (3, (1, 2), {'a': 1, 'b': 2})
}"""



# Generated at 2022-06-21 15:01:34.222289
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """\
{
    "z": 3,
    "y": 2,
    "x": 1
}
"""
    assert load_json_preserve_order(s) == OrderedDict([('z', 3), ('y', 2), ('x', 1)])

# Generated at 2022-06-21 15:01:42.706598
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:01:46.108031
# Unit test for function repr_dict
def test_repr_dict():
    expected = """{
  'b': 2,
  'a': 1,
}"""
    assert repr_dict(dict(a=1, b=2)) == expected
    assert repr_dict(OrderedDict([('a', 1), ('b', 2)])) == expected
    assert repr_dict({'b': 2, 'a': 1}) == expected

# Generated at 2022-06-21 15:01:50.423075
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    d = load_json_preserve_order('{"a": 1, "b": {"c": 2}, "d": [3, 4]}')
    assert d == OrderedDict([('a', 1), ('b', OrderedDict([('c', 2)])), ('d', [3, 4])])


# Generated at 2022-06-21 15:01:54.897686
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'text/plain'
    assert get_content_type('foo.text') == 'text/plain'
    assert get_content_type('foo.py') == 'text/x-python'
    assert get_content_type('foo.pyc') == None
    assert get_content_type('foo.tar.gz') == 'application/x-tar'
    assert get_content_type('foo.tar') == 'application/x-tar'
    assert get_content_type('foo.tea') == None

# Generated at 2022-06-21 15:02:08.621619
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': [1, 2], 'b': {'c': [1, 2], 'd': 3}}) == \
        "{'a': [1, 2], 'b': {'c': [1, 2], 'd': 3}}"

# Generated at 2022-06-21 15:02:11.890423
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"foo": [1,2,3], "bar": {"a": 2, "b": 4}}'
    res = load_json_preserve_order(s)
    assert res == {'foo': [1, 2, 3], 'bar': {'a': 2, 'b': 4}}


# Unit tests for function get_content_type

# Generated at 2022-06-21 15:02:18.731531
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    test1 = [('a', 'b'), ('set-cookie', 'foo=bar; path=/'), ('c', 'd')]
    test2 = [('set-cookie', 'foo=bar; path=/; expires=Fri, 31-Dec-1999 23:59:59 GMT')]
    test3 = [('set-cookie', 'foo=bar; path=/; max-age=1')]
    assert get_expired_cookies(test1) == []
    assert get_expired_cookies(test2) == [{'name': 'foo', 'path': '/'}]
    assert get_expired_coo

# Generated at 2022-06-21 15:02:27.290209
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.exceptions import MissingSchema
    from requests.models import Request
    from requests.hooks import default_hooks
    from requests.models import PreparedRequest
    from requests.sessions import DEFAULT_REDIRECT_LIMIT

    headers = {'header1': 'value1'}
    session = Session()
    url = "http://user:password@test.com"
    req = Request('GET', url, headers, hooks=default_hooks)
    prep = PreparedRequest()
    prep.prepare_headers(headers)

    assert session.prepare_request(req) == req
    assert session.prepare_request(req, 'GET', 'http://test.com') == prep

# Generated at 2022-06-21 15:02:31.075846
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file') is None
    assert get_content_type('/path/to/file') is None
    assert get_content_type('file.py') == 'text/x-python'
    assert get_content_type('file.html') == 'text/html'

# Generated at 2022-06-21 15:02:36.977913
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.xml') == 'text/xml'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_type('foo.bar') is None
    assert get_content_type('foo.pdf') is None

# Generated at 2022-06-21 15:02:38.254586
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None



# Generated at 2022-06-21 15:02:42.716180
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    data = '''
    {
        "bar": "bar",
        "foo": "foo"
    }
    '''
    expected = {
        "bar": "bar",
        "foo": "foo"
    }

    assert load_json_preserve_order(data) == expected

# Generated at 2022-06-21 15:02:50.694533
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()  # Mon, 08 Feb 2010 20:45:16 GMT
    headers = [
        ('set-Cookie', 'session_token=abcdef; Path=/; Expires=Wed, 21 Oct 2015 '
                    '07:28:00 GMT; Secure; HttpOnly'),
        ('set-Cookie', 'session_token=123456; Path=/; Max-Age=60; Secure; '
                    'HttpOnly'),
        ('Set-Cookie', 'session_token=abcdef; Path=/; Expires=Wed, 21 Oct 2030 '
                    '07:28:00 GMT; Secure; HttpOnly'),
        ('Set-Cookie', 'session_token=123456; Path=/; Max-Age=60; Secure; '
                    'HttpOnly'),
        ('Other-Header', 'Other-Value')
    ] * 2



# Generated at 2022-06-21 15:02:56.122347
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookie_str_1 = 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'
    cookie_str_2 = 'foo=bar; Path=/; Expires=Wed, 21 Oct 2016 07:28:00 GMT'
    cookie_str_3 = 'foo=bar; Path=/; Expires=Wed, 21 Oct 2017 07:28:00 GMT'
    cookie_str_4 = 'foo=bar; Path=/; Max-Age=0'
    header = [('Set-Cookie', cookie_str_1),
              ('Set-Cookie', cookie_str_2),
              ('Set-Cookie', cookie_str_3),
              ('Set-Cookie', cookie_str_4)
              ]

    cookies = get_expired_cookies(headers=header)

# Generated at 2022-06-21 15:03:11.603552
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:03:18.062602
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    from io import StringIO

    from pytest import approx


# Generated at 2022-06-21 15:03:20.088860
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth  # Needed to avoid "unused variable" warning

# Generated at 2022-06-21 15:03:29.476392
# Unit test for function get_content_type
def test_get_content_type():
    """Test get_content_type()."""
    # Test a few common file types.
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/x-javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.md') == 'text/markdown'

    # Test a file type not known to mimetypes.
    assert get_content_type('foo.baz') is None

# Generated at 2022-06-21 15:03:35.295479
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert("1.0 kB" == humanize_bytes(1024, precision=1))
    assert("123.0 kB" == humanize_bytes(1024 * 123, precision=1))
    assert("12.1 MB" == humanize_bytes(1024 * 12342, precision=1))
    assert("12.05 MB" == humanize_bytes(1024 * 12342, precision=2))
    assert("1.21 MB" == humanize_bytes(1024 * 1234, precision=2))
    assert("1.31 GB" == humanize_bytes(1024 * 1234 * 1111, precision=2))
    assert("1.3 GB" == humanize_bytes(1024 * 1234 * 1111, precision=1))
    assert("1 B" == humanize_bytes(1))



# Generated at 2022-06-21 15:03:40.798479
# Unit test for function humanize_bytes
def test_humanize_bytes():
    pairs = (
        (1023, '1023 B'),
        (1024, '1.0 kB'),
        (1536, '1.5 kB'),
        (2048, '2.0 kB'),
        (1 << 20, '1.0 MB'),
        (1 << 30, '1.0 GB'),
        (1 << 40, '1.0 TB'),
    )

    for n, expected in pairs:
        assert humanize_bytes(n) == expected

# Generated at 2022-06-21 15:03:49.387566
# Unit test for function humanize_bytes
def test_humanize_bytes():
    one_b = humanize_bytes(1)
    assert one_b == '1 B'
    one_kb_precision_1 = humanize_bytes(1024, precision=1)
    assert one_kb_precision_1 == '1.0 kB'
    one_hundred_and_twenty_three_kb_precision_1 = humanize_bytes(1024 * 123, precision=1)
    assert one_hundred_and_twenty_three_kb_precision_1 == '123.0 kB'
    twelve_point_one_mb = humanize_bytes(1024 * 12342, precision=1)
    assert twelve_point_one_mb == '12.1 MB'
    twelve_point_zero_five_mb = humanize_bytes(1024 * 12342, precision=2)
    assert twelve_

# Generated at 2022-06-21 15:03:55.675533
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 15:04:01.565998
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # simple test that the dictionary keys still exist in the original order
    json_string = """
    {
        "x": "hello",
        "y": "world",
        "z": "foo"
    }
    """
    d = load_json_preserve_order(json_string)
    assert list(d.keys()) == ["x", "y", "z"]

# Generated at 2022-06-21 15:04:11.056930
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.csv') == 'text/csv'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'