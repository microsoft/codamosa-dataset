

# Generated at 2022-06-21 14:55:33.913381
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    if auth is None:
        assert False
    else:
        assert True


# Generated at 2022-06-21 14:55:35.926814
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({"a": 1, "b&": "b&c"}) == "{'a': 1, 'b&': 'b&c'}"

# Generated at 2022-06-21 14:55:39.894757
# Unit test for function repr_dict
def test_repr_dict():
    """Test for function repr_dict"""
    from pprint import pprint
    d = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    expected = "{\n'a': 1,\n'b': 2,\n'c': 3,\n'd': 4\n}"
    assert repr_dict(d) == expected
    pprint(d)

# Generated at 2022-06-21 14:55:50.765439
# Unit test for function humanize_bytes
def test_humanize_bytes():
    """Tests for function ``humanize_bytes()``."""
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-21 14:55:52.397964
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 14:55:53.602729
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth.__call__

# Generated at 2022-06-21 14:56:00.995383
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'a': 1,
        'b': 'b',
        'c': {
            'c1': 'c1',
            'c2': 'c2',
        },
        'd': ['d1', 'd2', 'd3'],
    }

    r = repr_dict(d)

    assert r == """\
{'a': 1,
 'b': 'b',
 'c': {'c1': 'c1', 'c2': 'c2'},
 'd': ['d1', 'd2', 'd3']}"""

# Generated at 2022-06-21 14:56:11.634283
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 14:56:15.075414
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    input_string = '{"a": 1, "b": 2}'
    output = load_json_preserve_order(input_string)
    expect = {"a": 1, "b": 2}
    assert output == expect

# Generated at 2022-06-21 14:56:26.158831
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('_installed.txt') == 'text/plain'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.tar.gz') == 'application/x-gzip'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.whl') == 'application/zip'
    assert get_content_type('requirements.in') == 'text/plain'
    assert get_content_type('requirements.txt') == 'text/plain'
    assert get_content_type('setup.cfg') == 'text/plain'
    assert get_content_type('setup.py') == 'text/x-python'

# Generated at 2022-06-21 14:56:36.040685
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1024) == "1.00 kB"
    assert humanize_bytes(1024*1024) == "1.00 MB"
    assert humanize_bytes(1024*1024*1024) == "1.00 GB"
    assert humanize_bytes(1024*1024*1024*1024*1024) == "1.00 PB"

    print("All tests passed")


# Generated at 2022-06-21 14:56:43.633779
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise Exception('ERROR:', 1)
    if humanize_bytes(1024, precision=1) != '1.0 kB':
        raise Exception('ERROR:', 1024)
    if humanize_bytes(1024 * 123, precision=1) != '123.0 kB':
        raise Exception('ERROR:', 1024 * 123)
    if humanize_bytes(1024 * 12342, precision=1) != '12.1 MB':
        raise Exception('ERROR:', 1024 * 12342)
    if humanize_bytes(1024 * 12342, precision=2) != '12.05 MB':
        raise Exception('ERROR:', 1024 * 12342)

# Generated at 2022-06-21 14:56:44.632553
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth is requests.auth.HTTPBasicAuth

# Generated at 2022-06-21 14:56:55.043321
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

    expired_cookie = {
        'name': 'foo',
        'value': 'bar',
        'path': '/',
        'max-age': '0',
    }
    expired_cookie_values = [
        as_header_value(expired_cookie, now),
    ]

    not_expired_cookie = {
        'name': 'foo',
        'value': 'bar',
        'path': '/',
        'max-age': '100',
    }
    not_expired_cookie_values = [
        as_header_value(not_expired_cookie, now),
    ]

    expired_and_not_expired_cookie_values = expired_cookie_values + not_expired_cookie_values


# Generated at 2022-06-21 14:57:00.266147
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 3, "b": 1, "c": 2}'
    d = load_json_preserve_order(s)
    items = list(d.items())
    assert items[0] == ('a', 3)
    assert items[1] == ('b', 1)
    assert items[2] == ('c', 2)

# Generated at 2022-06-21 14:57:04.276283
# Unit test for function repr_dict
def test_repr_dict():
    d = {}
    assert repr_dict(d) == pformat(d)
    d = {'a': 1}
    assert repr_dict(d) == pformat(d)
    d = {'a': {'b': {'c': {'d': {'e': {'f': {'g': {'h': 1}}}}}}}}
    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-21 14:57:08.470578
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert str(load_json_preserve_order('{"a":1, "b":2}')) \
        == str(OrderedDict([('a', 1), ('b', 2)]))
    assert str(load_json_preserve_order('{"a":1}')) \
        == str(OrderedDict([('a', 1)]))
    assert str(load_json_preserve_order('{}')) == str(OrderedDict())



# Generated at 2022-06-21 14:57:18.781349
# Unit test for function humanize_bytes
def test_humanize_bytes():
    from pytest import approx

    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    assert humanize_

# Generated at 2022-06-21 14:57:30.894814
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    class InnerMockRequest:
        def __init__(self, cookies):
            self.cookies = cookies

    def mock_get_expired_cookies(headers, now):
        assert headers == [(
            'set-cookie',
            'cookie1=value1; Expires=Mon, 01 Mar 2021 03:24:00 GMT; Path=/'
        )]
        assert now == 1234567890.123456
        return [{
            'name': 'cookie1',
            'path': '/'
        }]

    request_with_cookies = InnerMockRequest({
        'cookie1': 'value1',
        'cookie2': 'value2',
    })

    auth = ExplicitNullAuth()


# Generated at 2022-06-21 14:57:42.172016
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime

    now = time.time()

    # Test all of the different date formats that cookies can be in.

# Generated at 2022-06-21 14:57:48.449452
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"key1": "value1", "key2": "value2"}'
    assert load_json_preserve_order(s) == OrderedDict([("key1", "value1"), ("key2", "value2")])

# Generated at 2022-06-21 14:57:56.664304
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(-1) == '-1 B'
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(10) == '10 B'
    assert humanize_bytes(999) == '999 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024 * 123) == '123.0 kB'
    assert humanize_bytes(1024 * 12342) == '12.1 MB'

# Generated at 2022-06-21 14:58:05.289311
# Unit test for function get_content_type
def test_get_content_type():
    from tempfile import NamedTemporaryFile
    import os.path

    with NamedTemporaryFile(suffix='.zip') as f:
        content_type = get_content_type(os.path.basename(f.name))
        assert content_type == 'application/zip'

    with NamedTemporaryFile(suffix='.png') as f:
        content_type = get_content_type(os.path.basename(f.name))
        assert content_type == 'image/png'

# Generated at 2022-06-21 14:58:15.642933
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest


# Generated at 2022-06-21 14:58:26.798813
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from unittest import TestCase

    class TC(TestCase):
        def setUp(self):
            self.now = time.time()


# Generated at 2022-06-21 14:58:33.058172
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    sets = [('Set-Cookie', 'foo=bar; Path=/abc')]
    assert get_expired_cookies(sets) == [
        {
            'name': 'foo',
            'path': '/abc'
        }
    ]

    now = time.time()

    sets = [('Set-Cookie', 'foo=bar; Path=/abc; Max-Age=5')]
    assert get_expired_cookies(sets, now=now) == []

    sets = [('Set-Cookie', 'foo=bar; Path=/abc; Max-Age=5')]
    assert get_expired_cookies(sets, now=now + 5.1) == [
        {
            'name': 'foo',
            'path': '/abc'
        }
    ]

# Generated at 2022-06-21 14:58:42.061037
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # TODO: These tests will surely break on a different time zone. Make these tests zone-independent.
    headers = [('Set-Cookie', 'foo=baz')]
    assert get_expired_cookies(headers) == []

    headers = [('Set-Cookie', 'foo=baz; max-age=5')]
    assert get_expired_cookies(headers, now=10) == [{'name': 'foo', 'path': '/'}]

    headers = [('Set-Cookie', 'foo=baz; expires=20')]
    assert get_expired_cookies(headers, now=10) == []
    assert get_expired_cookies(headers, now=30) == [{'name': 'foo', 'path': '/'}]


# Generated at 2022-06-21 14:58:46.037062
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(x=1, y=2)) == "{'x': 1, 'y': 2}"
    assert repr_dict(dict(x=1, y=2, z=3)) == "{'x': 1, 'y': 2, 'z': 3}"



# Generated at 2022-06-21 14:58:47.595676
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    a = ExplicitNullAuth()
    assert repr(a) == "<ExplicitNullAuth>"

# Generated at 2022-06-21 14:58:51.492551
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 14:58:55.778867
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict)

# Generated at 2022-06-21 14:58:57.904692
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({
        'a': 'aaa',
        'b': 'bbb'
    }) == "{'a': 'aaa', 'b': 'bbb'}"

# Generated at 2022-06-21 14:59:04.768205
# Unit test for function repr_dict
def test_repr_dict():
    d = {'foo': 'value', 'bar': 1}
    assert repr_dict(d) == "{'bar': 1, 'foo': 'value'}"
    assert repr_dict(OrderedDict([('foo', 'value'), ('bar', 1)])) \
        == "{'bar': 1, 'foo': 'value'}"
    assert repr_dict(OrderedDict([('bar', 1), ('foo', 'value')])) \
        == "{'bar': 1, 'foo': 'value'}"

# Generated at 2022-06-21 14:59:13.915690
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('my_file.png') == 'image/png'
    assert get_content_type('my_file.json') == 'application/json'
    assert get_content_type('my_file.mp4') == 'video/mp4'
    assert get_content_type('my_file.jpg') == 'image/jpeg'
    assert get_content_type('my_file.gif') == 'image/gif'
    assert get_content_type('my_file.pdf') == 'application/pdf'
    assert get_content_type('my_file.txt') == 'text/plain'

# Generated at 2022-06-21 14:59:16.828524
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    req = requests.Request('GET', 'http://www.example.com/')
    req.auth = ExplicitNullAuth()
    prepared_request = req.prepare()
    assert prepared_request.headers.get('Authorization') == None


# Generated at 2022-06-21 14:59:17.662508
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-21 14:59:24.850898
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/etc/services') is None
    assert get_content_type('/etc/services') is None

    assert (
        get_content_type(
            '/etc/resolv.conf'
        ) == 'text/plain; charset=us-ascii'
    )

    assert get_content_type('/bin/ls') is None
    assert get_content_type('/bin/ls') is None

    assert get_content_type('/dev/null') is None
    assert get_content_type('/dev/null') is None

    assert get_content_type('/dev/null.txt') is None
    assert get_content_type('/dev/null.txt') is None

# Generated at 2022-06-21 14:59:30.474250
# Unit test for function repr_dict
def test_repr_dict():
    d = OrderedDict()
    d['a'] = 'foo'
    d['b'] = 'bar'
    re = repr_dict(d)
    # noinspection PyChainedComparisons
    assert re == "{'a': 'foo', 'b': 'bar'}" or re == "{'b': 'bar', 'a': 'foo'}"

if __name__ == "__main__":
    test_repr_dict()

# Generated at 2022-06-21 14:59:39.540127
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from .http import Session
    from .web import URL
    from requests.auth import HTTPBasicAuth

    class UserPassAuth(HTTPBasicAuth):
        def __init__(self, username, password):
            self.username = username
            self.password = password

        def __call__(self, r):
            r.prepare_auth(auth=self)
            return r
    # -------------------------------------------------------------------------
    url = URL('https://localhost:8000/netrc')

    session = Session(auth=UserPassAuth('user', 'pass'))
    response = session.get(url=url)
    assert bool(response.content)

    session = Session(auth=ExplicitNullAuth())
    response = session.get(url=url)
    assert bool(response.content)

# Generated at 2022-06-21 14:59:44.154135
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr_dict(d) == "{'a': 1, 'b': 2}"

    d = {'a': {'b': {'c': 1}}}
    expected = "{\n    'a': {\n        'b': {\n            'c': 1\n        }\n    }\n}"
    assert repr_dict(d) == expected

# Generated at 2022-06-21 14:59:49.316774
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    test_session = requests.Session()
    test_session.auth = ExplicitNullAuth()
    assert test_session.auth.__call__ is not None


# Generated at 2022-06-21 14:59:59.657049
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def hb(n, precision=2):
        return humanize_bytes(n, precision=precision)

    assert hb(1) == '1 B'
    assert hb(1024, precision=1) == '1.0 kB'
    assert hb(1024 * 123, precision=1) == '123.0 kB'
    assert hb(1024 * 12342, precision=1) == '12.1 MB'
    assert hb(1024 * 12342, precision=2) == '12.05 MB'
    assert hb(1024 * 1234, precision=2) == '1.21 MB'
    assert hb(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert hb(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 15:00:01.985555
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    class ExplicitNullAuth():
        def __call__(self, r):
            return r
    assert ExplicitNullAuth().__call__( 'r') == 'r'


# Generated at 2022-06-21 15:00:07.697561
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 15:00:17.079538
# Unit test for function humanize_bytes

# Generated at 2022-06-21 15:00:20.636511
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests

    resp = requests.get(
        'http://httpbin.org/basic-auth/user/passwd',
        auth=ExplicitNullAuth()
    )
    assert resp.status_code == 401

# Generated at 2022-06-21 15:00:28.420534
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from testfixtures import compare

    cookies = get_expired_cookies(
        [
            ('set-cookie',
             'foo=bar; path=/baz; expires=Tue, 19 Jan 2038 03:14:07 GMT'),
            ('set-cookie',
             'bar=baz; path=/baz; expires=Tue, 19 Jan 2038 03:14:07 GMT'),
            ('set-cookie',
             'baz=qux; path=/qux; expires=Tue, 19 Jan 2025 03:14:07 GMT'),
            ('set-cookie',
             'qux=quux; path=/quux; expires=Tue, 19 Jan 2025 03:14:07 GMT'),
        ],
        now=0.0
    )

# Generated at 2022-06-21 15:00:34.153187
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Test for preserving order:
    assert load_json_preserve_order('[1, 2, 3]') == [1, 2, 3]

    # Test for preserving order with objects:
    json_str = '{"1": "a", "2": "b", "3": "c"}'
    assert load_json_preserve_order(json_str) == {
        "1": "a", "2": "b", "3": "c"
    }



# Generated at 2022-06-21 15:00:35.483709
# Unit test for function repr_dict
def test_repr_dict():
    if __name__ == '__main__':
        import doctest
        doctest.testmod()

# Generated at 2022-06-21 15:00:41.844941
# Unit test for function repr_dict
def test_repr_dict():
    print(repr_dict({'a': 1, 'b': 2, 'c': 3}))
    # expect:
    # OrderedDict([('a', 1), ('b', 2), ('c', 3)])

if __name__ == '__main__':
    test_repr_dict()

# Generated at 2022-06-21 15:00:49.232511
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 'foo'}) == pformat({'a': 1, 'b': 'foo'})



# Generated at 2022-06-21 15:00:50.436408
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None


# Generated at 2022-06-21 15:01:00.597631
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert (humanize_bytes(100) == '100 B')
    assert (humanize_bytes(1024) == '1.0 kB')
    assert (humanize_bytes(1024 * 1024) == '1.0 MB')
    assert (humanize_bytes(1024 * 1024 * 1024) == '1.0 GB')
    assert (humanize_bytes(1024 * 1024 * 1024 * 1024) == '1.0 TB')
    assert (humanize_bytes(1024 * 1024 * 1024 * 1024 * 1024) == '1.0 PB')
    assert (humanize_bytes(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1024.0 PB')
    assert (humanize_bytes(1024, 1) == '1.0 kB')
    assert (humanize_bytes(1024 * 1024, 2) == '1.00 MB')
   

# Generated at 2022-06-21 15:01:05.929240
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr_dict(d) == "{'a': 1, 'b': 2}"

    d = {'a': 1}
    assert repr_dict(d) == "{'a': 1}"

    d = {'a': 1, 'b': 2, 'c': 3}
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-21 15:01:13.125569
# Unit test for method __call__ of class ExplicitNullAuth

# Generated at 2022-06-21 15:01:13.618636
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 15:01:22.543862
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 15:01:30.305016
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([
        ('Set-Cookie', 'a=b; path=/; expires=Sat, 08 Dec 2018 16:13:54 GMT')
    ]) == [
        {
            'name': 'a',
            'path': '/'
        }
    ]
    now = time.time()
    assert get_expired_cookies([
        ('Set-Cookie', 'b=c; path=/; max-age=60')
    ], now=now) == []
    assert get_expired_cookies([
        ('Set-Cookie', 'b=c; path=/; max-age=60')
    ], now=now + 120) == [
        {
            'name': 'b',
            'path': '/'
        }
    ]



# Generated at 2022-06-21 15:01:35.858360
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert repr_dict(load_json_preserve_order('{"b": 2, "a": 1}')) == "{'b': 2, 'a': 1}"
    assert repr_dict(load_json_preserve_order('{"a": 1, "b": 2}')) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 15:01:43.649194
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'CSRF_TOKEN=abc123; Path=/; Max-Age=1000'),
        ('Set-Cookie', 'SESSION_ID=123abc; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT; Secure; HttpOnly'),
        ('Set-Cookie', 'SESSION_ID2=123abc; Path=/; Expires=Wed, 21 Oct 15 07:28:00 GMT; Secure; HttpOnly'),
        ('Set-Cookie', 'SESSION_ID3=123abc; Path=/; Expires=Wed, 21 Oct 2023 07:28:00 GMT; Secure; HttpOnly'),
    ]
    expected_output = [{'name': 'CSRF_TOKEN', 'path': '/'}]