

# Generated at 2022-06-21 14:55:42.777507
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise AssertionError("1 B != %s" % humanize_bytes(1))
    if humanize_bytes(1024, precision=1) != '1.0 kB':
        raise AssertionError("1.0 kB != %s" % humanize_bytes(1024, precision=1))
    if humanize_bytes(1024 * 123, precision=1) != '123.0 kB':
        raise AssertionError("123.0 kB != %s" % humanize_bytes(1024 * 123, precision=1))
    if humanize_bytes(1024 * 12342, precision=1) != '12.1 MB':
        raise AssertionError("12.1 MB != %s" % humanize_bytes(1024 * 12342, precision=1))
   

# Generated at 2022-06-21 14:55:48.839211
# Unit test for function get_content_type
def test_get_content_type():
    from os import path

    assert get_content_type('image.jpg') == 'image/jpeg'
    assert get_content_type('image.png') == 'image/png'
    assert get_content_type(path.join('foo', 'image.png')) == 'image/png'
    assert get_content_type(path.join('foo', 'bar', 'image.png')) == 'image/png'

# Generated at 2022-06-21 14:55:49.986020
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth().__call__({})


# Generated at 2022-06-21 14:55:56.219209
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/'),
        ('Set-Cookie', 'baz=qux; Expires=Tue, 08-Sep-2020 09:15:19 GMT; path=/; HttpOnly'),
    ]
    cookies = get_expired_cookies(headers, now=1599546319)
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'baz'
    assert cookies[0]['path'] == '/'

# Generated at 2022-06-21 14:55:57.160395
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()



# Generated at 2022-06-21 14:56:04.908057
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.csv') == 'text/csv'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.mp4') == 'video/mp4'
    assert get_content_type('foo.mkv') == 'video/x-matroska'
    assert get_content_type('foo.avi') == 'video/x-msvideo'
    assert get_content_type('foo.flv') == 'video/x-flv'
    assert get_content_type('foo.mov') == 'video/quicktime'

# Generated at 2022-06-21 14:56:05.520609
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 14:56:12.109007
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # this JSON string has an unordered dict
    s = '{"content": {"time": 1, "f1": 4, "f2": 5, "f3": 6}, "id": 2}'
    expected = 'OrderedDict([(\'content\', OrderedDict([(\'time\', 1), (\'f1\', 4), (\'f2\', 5), (\'f3\', 6)])), (\'id\', 2)])'
    assert repr(load_json_preserve_order(s)) == expected

# Generated at 2022-06-21 14:56:15.477547
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    import requests
    auth = ExplicitNullAuth()
    req = requests.Request('GET', 'http://example.org')
    prep = req.prepare()
    assert prep.headers == {}



# Generated at 2022-06-21 14:56:16.602644
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:56:22.008679
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
{
    "foo": "bar",
    "baz": "qux"
}
"""
    assert load_json_preserve_order(s) == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-21 14:56:31.775454
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:56:41.624312
# Unit test for function humanize_bytes
def test_humanize_bytes():
    pairs = (
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB', 2),
        (1024 * 1234, '1.21 MB', 2),
        (1024 * 1234 * 1111, '1.31 GB', 2),
        (1024 * 1234 * 1111, '1.3 GB', 1),
    )
    for pair in pairs:
        bytes = pair[0]
        expected_res = pair[1]
        if len(pair) == 3:
            precision = pair[2]
        else:
            precision = 2
        res = humanize_bytes(bytes, precision)
        assert res == expected_res

# Generated at 2022-06-21 14:56:48.122064
# Unit test for function repr_dict
def test_repr_dict():
    d = {'str': 'str', 'list': ['a', 1], 'dict': {'foo': 'bar', 'baz': None}}
    result = repr_dict(d)
    assert result == """{'list': ['a', 1], 'str': 'str', 'dict': {'foo': 'bar', 'baz': None}}"""

# Generated at 2022-06-21 14:56:52.757785
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.bin') == 'application/octet-stream'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.unknown') == None

# Generated at 2022-06-21 14:56:59.440307
# Unit test for function repr_dict
def test_repr_dict():
    for s in [
        "a = 1",
        "a = 1, b = 2",
        "a = 1, b = 2, c = 3",
        "d = {'a': 1}",
        "e = {'a': 1, 'b': 2}",
        "f = {'a': 1, 'b': 2, 'c': 3}",
    ]:
        eval(s)

# Generated at 2022-06-21 14:57:01.338951
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth('request') == 'request'


# Generated at 2022-06-21 14:57:10.929725
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    future = now + 3600
    past = now - 3600
    cookies = get_expired_cookies([
        (
            'Set-Cookie',
            'foo=bar; path=/; expires=%s' % time.strftime(
                '%a, %d %b %Y %H:%M:%S GMT', time.gmtime(future)
            )
        ),
        (
            'Set-Cookie',
            'baz=bat; path=/; expires=%s' % time.strftime(
                '%a, %d %b %Y %H:%M:%S GMT', time.gmtime(past)
            )
        )
    ], now=now)

# Generated at 2022-06-21 14:57:13.634428
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # method argument
    r = object()

    # LBYL test
    assert ExplicitNullAuth()(r) is r

# Generated at 2022-06-21 14:57:16.763708
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert {'a': 1} == load_json_preserve_order('{"a": 1}')
    assert {'a': 1, 'b': 2} == load_json_preserve_order('{"a": 1, "b": 2}')

# Generated at 2022-06-21 14:57:22.910250
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'b': 'a'}) == "{'b': 'a'}"
    assert repr_dict({'b': {'a': 1}}) == "{'b': {'a': 1}}"

# Generated at 2022-06-21 14:57:25.075371
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 'b', 'c': 2}
    return repr_dict(d) == "{'a': 'b', 'c': 2}"

# Generated at 2022-06-21 14:57:27.509230
# Unit test for function repr_dict
def test_repr_dict():
    d = {'ab': 123}
    assert repr_dict(d) == "{'ab': 123}"

# Generated at 2022-06-21 14:57:33.380143
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    loaded = load_json_preserve_order('''{"d": {
        "a": 1,
        "b": {"b1": 1},
        "c": {"c1": 2, "c2": 3}
    }}''')
    expected = OrderedDict([
        ('d', OrderedDict([
            ('a', 1),
            ('b', OrderedDict([('b1', 1)])),
            ('c', OrderedDict([
                ('c1', 2),
                ('c2', 3),
            ])),
        ])),
    ])
    assert loaded == expected

# Generated at 2022-06-21 14:57:37.322016
# Unit test for function repr_dict
def test_repr_dict():
    d = {'A': 1, 'B': 2}
    assert repr_dict(d) == "{'A': 1, 'B': 2}"

test_repr_dict()

# Generated at 2022-06-21 14:57:39.312684
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    request = requests.Request()
    request = auth(request)
    assert request is not None

# Generated at 2022-06-21 14:57:43.742595
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # type: () -> None
    import json

    ordered_json = '{"a": 1, "b": 2}'
    unordered_json = '{"b": 2, "a": 1}'
    assert load_json_preserve_order(ordered_json) == json.loads(ordered_json)
    assert load_json_preserve_order(unordered_json) == json.loads(ordered_json)

# Generated at 2022-06-21 14:57:55.244998
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:57:58.035344
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2, 'c': 3}
    assert repr_dict(d) == "{\n    'a': 1,\n    'b': 2,\n    'c': 3\n}"

# Generated at 2022-06-21 14:58:00.791295
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    raise NotImplementedError()

# Generated at 2022-06-21 14:58:06.738122
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1000) == '1000 B'
    assert humanize_bytes(1000000) == '977 kB'
    assert humanize_bytes(1000000000) == '953 MB'
    assert humanize_bytes(1000000000000) == '931 GB'
    assert humanize_bytes(1000000000000000) == '909 TB'

# Generated at 2022-06-21 14:58:09.553778
# Unit test for function get_content_type
def test_get_content_type():
    import mimetypes
    mimetypes.init()

    assert get_content_type('bla.html') == "text/html"
    assert get_content_type('bla.js') == "application/javascript"
    assert get_content_type('bla.css') == "text/css"

# Generated at 2022-06-21 14:58:17.760195
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Test valid JSON
    source_json = "{\n    \"foo\": 1,\n    \"bar\": 2,\n    \"baz\": 3\n}\n"
    result_dict = load_json_preserve_order(s=source_json)
    assert(isinstance(result_dict, OrderedDict))
    assert(result_dict['foo'] == 1)
    assert(result_dict['bar'] == 2)
    assert(result_dict['baz'] == 3)
    # Test invalid JSON
    source_json = '{"foo": 1,\n    "bar": 2,\n    "baz": 3\n}\n'

# Generated at 2022-06-21 14:58:20.414553
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('README.md') == 'text/markdown'
    assert get_content_type('some-non-existing-file.foobar') is None

# Generated at 2022-06-21 14:58:21.024650
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:58:27.035471
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict({'key1': None}) == "{'key1': None}"
    assert repr_dict({'key1': 1}) == "{'key1': 1}"
    assert repr_dict({'key1': 'value1'}) == "{'key1': 'value1'}"

# Generated at 2022-06-21 14:58:32.979268
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    lib_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(lib_dir, 'test/resources/cookie.txt')) as f:
        cookie = f.read()
    expired_cookies = get_expired_cookies([
        ('Set-Cookie', cookie),
    ], now=time.strptime('Tue, 18 Jul 2017 09:08:00 GMT',
                         '%a, %d %b %Y %H:%M:%S %Z'))

    assert type(expired_cookies) == list
    assert expired_cookies == [{
        'name': 'sessionid',
        'path': '/'
    }]

# Generated at 2022-06-21 14:58:38.264470
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.sessions import Session
    from requests.models import PreparedRequest

    auth = ExplicitNullAuth()
    session = Session()
    session.auth = auth
    req = PreparedRequest()
    req.prepare_auth(auth)
    assert not hasattr(req, 'netrc')
    assert not req.headers
    req.prepare_auth(auth, {})
    assert not req.headers

# Generated at 2022-06-21 14:58:39.213839
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-21 14:58:45.121368
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # This is an example of an HTTP response with two Set-Cookie headers,
    # one of which will not expire because it doesn't contain the `expires`
    # or `max-age` cookie attributes.
    headers = [
        ('set-cookie', 'foo=bar'),
        ('set-cookie', 'baz=quux; expires=Sat, 21-Sep-2019 20:00:00 GMT'),
        ('etag', '1234'),  # Some non-Set-Cookie header
    ]
    now = 1594000000  # Must be the same as in `expires` above.
    cookies = get_expired_cookies(headers, now=now)
    assert cookies == [{'name': 'foo', 'path': '/'}]

# Generated at 2022-06-21 14:58:46.883013
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(),
                      requests.auth.AuthBase)

# Generated at 2022-06-21 14:58:51.690553
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_str = '{"first": [1, 2], "second": [3, 4]}'

    actual_result = load_json_preserve_order(test_str)
    expected_result = {'first': [1, 2], 'second': [3, 4]}

    assert actual_result == expected_result

# Generated at 2022-06-21 14:59:00.236234
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    header_value = """
        key1=val1; Path=/; HttpOnly; Expires=Tue, 16 May 2017 15:15:25 UTC
        key2=val2; Path=/; HttpOnly; Max-Age=0; Expires=Tue, 16 May 2017 15:15:25 UTC
        key3=val3; Path=/; HttpOnly; Max-Age=30;
        key4=val4; Path=/; HttpOnly;
    """
    header_value = header_value.strip()
    now = time.time()
    # Time 15:15:25 UTC
    now = int(now - (now % 86400) + 13.0*60*60 + 15*60 + 25)

    headers = [(
        'Set-Cookie',
        header_value
    )]
    cookies = get_expired_

# Generated at 2022-06-21 14:59:01.256211
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 14:59:10.971903
# Unit test for function repr_dict
def test_repr_dict():
    def rd(d: dict) -> str:
        return repr_dict(d)

    assert (rd({"a": [1, 2]}) == r'{\n    "a": [\n        1, \n        2\n    ]\n}')
    assert (rd({"a": [1, 2], "b": [3, 4]}) == r'{\n    "a": [\n        1, \n        2\n    ], \n    "b": [\n        3, \n        4\n    ]\n}')
    assert (rd({"a": {"b": 1}}) == r'{\n    "a": {\n        "b": 1\n    }\n}')



# Generated at 2022-06-21 14:59:19.835723
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import re

    now = time.time()
    assert get_expired_cookies([]) == []

    #
    # Cookies from <https://www.python.org>
    #
    # This is a simple, one-attribute cookie.
    cookies = get_expired_cookies([
        ('Set-Cookie', 'foo=bar;')
    ])
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'foo'
    assert cookies[0]['path'] == '/'

    # This is a cookie with several attributes.
    cookies = get_expired_cookies([
        ('Set-Cookie', 'foo=bar;path=/;domain=python.org')
    ])
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'foo'

# Generated at 2022-06-21 14:59:25.890229
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.json') != 'text/json'
    assert get_content_type('foo.csv') == 'text/csv; charset=utf-8'
    # This is a bit hard to test without having a file
    # of that type on disk, but it is at least an
    # extensive test:
    assert get_content_type('foo.mp4') == 'video/mp4'

# Generated at 2022-06-21 14:59:35.805386
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def test(b, p, r):
        assert humanize_bytes(b, p) == r, '%d bytes with precision %d => %s' % (b, p, r)
    test(1, 2, '1 B')
    test(1024, 2, '1.00 kB')
    test(1024 * 123, 1, '123.0 kB')
    test(1024 * 12343, 2, '12.05 MB')
    test(1024 * 1234, 2, '1.21 MB')
    test(1024 * 1234 * 1111, 2, '1.31 GB')
    test(1024 * 1234 * 1111, 1, '1.3 GB')

# Generated at 2022-06-21 14:59:37.277217
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()({}) == {}


# Generated at 2022-06-21 14:59:45.852541
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    print("test_humanize_bytes() passed")

# Generated at 2022-06-21 14:59:51.129174
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(
        'test.txt'
    ) == 'text/plain'
    assert get_content_type(
        'test.tHalley'
    ) is None



# Generated at 2022-06-21 14:59:52.092356
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:59:56.927699
# Unit test for function get_content_type
def test_get_content_type():
    values = [
        (None, None),
        ('.ext', 'application/octet-stream'),
        ('.mp3', 'audio/mpeg'),
        ('.txt', 'text/plain'),
    ]
    for filename, expected_content_type in values:
        assert get_content_type(filename) == expected_content_type

# Generated at 2022-06-21 15:00:01.364182
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': ['b', 'c']}) == "{'a': ['b', 'c']}"
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({'a': {'b': 'c'}}) == "{'a': {'b': 'c'}}"

# Generated at 2022-06-21 15:00:04.870990
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        "a": 1,
        "b": 2,
        "c": 3,
    }
    assert repr_dict(d) == pformat(d)

    d = OrderedDict([
        ("a", 1),
        ("b", 2),
        ("c", 3),
    ])
    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-21 15:00:09.305221
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    value = load_json_preserve_order(r'{"a": "b", "c": {"d": "e"}}')
    assert isinstance(value, dict)
    assert list(value.keys()) == ['a', 'c']
    assert list(value['c'].keys()) == ['d']



# Generated at 2022-06-21 15:00:19.693603
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:00:24.167379
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order(
        '{"foo": "bar", "baz": "qux"}'
    ) == {'foo': 'bar', 'baz': 'qux'}
    assert load_json_preserve_order(
        '["foo", "bar", "baz", "qux"]'
    ) == ['foo', 'bar', 'baz', 'qux']

# Generated at 2022-06-21 15:00:24.636949
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)

# Generated at 2022-06-21 15:00:28.215142
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.doc') == 'application/msword'

# Generated at 2022-06-21 15:00:33.400338
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-21 15:00:35.340847
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr(d) != repr_dict(d)
    assert pformat(d) == repr_dict(d)

# Generated at 2022-06-21 15:00:42.652429
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("file.txt", strict=False) == "text/plain"
    assert get_content_type("file.html", strict=False) == "text/html"
    assert get_content_type("file.html.hbs", strict=False) is None
    assert get_content_type("file.html.hbs", strict=True) == "text/html"


# Generated at 2022-06-21 15:00:43.772052
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('a.pdf') == 'application/pdf'

# Generated at 2022-06-21 15:00:48.157128
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        1: 2,
        'foo': 'bar',
        'baz': {
            'qux': 2
        },
        'quux': [
            'corge',
            1,
            {'grault': 'garply'}
        ],
        'waldo': 'fred',
        'fred': 'waldo'
    }
    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-21 15:00:50.760468
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(a=1, b=2, c=3)
    assert repr_dict(d) == "{\n    'a': 1,\n    'b': 2,\n    'c': 3\n}"

# Generated at 2022-06-21 15:00:57.104960
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import PreparedRequest
    from requests.auth import HTTPBasicAuth
    url = 'https://example.com/'
    auth = ExplicitNullAuth()
    prepared_request = PreparedRequest()
    auth.__call__(prepared_request)
    assert prepared_request.url == url
    auth = HTTPBasicAuth('jsmith', 'p4ssw0rd')
    prepared_request = PreparedRequest()
    auth.__call__(prepared_request)
    assert prepared_request.url == url

# Generated at 2022-06-21 15:01:06.343763
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('abc.xlsx') is None
    assert get_content_type('/path/to/abc.xlsx') is None
    assert get_content_type('/path/to/abc.pdf') is None
    assert get_content_type('.xlsx') is None
    assert get_content_type('.pdf') is None
    assert get_content_type('xlsx') == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    assert get_content_type('xlsx.xlsx') is None
    assert get_content_type('xlsx.pdf') is None
    assert get_content_type('xlsx.exe') is None

# Generated at 2022-06-21 15:01:07.302048
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-21 15:01:08.290631
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 15:01:21.166587
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import os
    import shutil
    from tempfile import NamedTemporaryFile, TemporaryDirectory

    def _save_netrc(entries):
        with NamedTemporaryFile('wt') as f:
            f.write('.netrc entries')
            f.write('machine hostname-in-netrc login netrc-user password netrc-pw')
            f.flush()
            return f.name

    def _rm_netrc(path):
        if os.path.isfile(path):
            os.remove(path)

    with TemporaryDirectory() as tmpdir:
        netrc_file = _save_netrc('.netrc entries')
        auth = ExplicitNullAuth()
        request = requests.Request('GET', 'http://www.google.com').prepare()

# Generated at 2022-06-21 15:01:22.099293
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 15:01:23.115160
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    pair = ExplicitNullAuth, ()  # noqa

# Generated at 2022-06-21 15:01:30.155479
# Unit test for function repr_dict
def test_repr_dict():
    d = OrderedDict([
        ('a', OrderedDict([('b', OrderedDict([('c', 1)])), ('d', 2)])),
        ('e', OrderedDict([('f', OrderedDict([('g', 3)])), ('h', 4)]))
    ])
    assert repr_dict(d).strip() == """\
OrderedDict([
    ('a', OrderedDict([
        ('b', OrderedDict([
            ('c', 1)
        ])),
        ('d', 2)
    ])),
    ('e', OrderedDict([
        ('f', OrderedDict([
            ('g', 3)
        ])),
        ('h', 4)
    ]))
])"""

# Generated at 2022-06-21 15:01:41.096995
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    def assert_preserve(input, expected):
        result = load_json_preserve_order(input)
        assert result == expected, "Result\n{}\nExpected\n{}".format(result, expected)

    assert_preserve(
        "{}",
        {}
    )

    assert_preserve(
        '{"foo": "bar"}',
        {'foo': 'bar'}
    )

    assert_preserve(
        '{"foo": "bar", "abc": 123}',
        {'foo': 'bar', "abc": 123}
    )

    assert_preserve(
        '{"foo": "bar", "abc": {"nested": "value"}}',
        {'foo': 'bar', "abc": {'nested': 'value'}}
    )


# Generated at 2022-06-21 15:01:49.271547
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # noinspection PyUnresolvedReferences
    assert humanize_bytes(1) == '1 B'
    # noinspection PyUnresolvedReferences
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    # noinspection PyUnresolvedReferences
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    # noinspection PyUnresolvedReferences
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    # noinspection PyUnresolvedReferences
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    # noinspection PyUnresolvedReferences
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'


# Generated at 2022-06-21 15:01:50.245003
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth() is not None

# Generated at 2022-06-21 15:01:51.275233
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert a is not None


# Generated at 2022-06-21 15:02:01.275959
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:02:01.777787
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth

# Generated at 2022-06-21 15:02:12.693608
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime
    import time

    now = time.time()

    # There is no cookie age in the Set-Cookie header
    cookies = get_expired_cookies([
        ('Set-Cookie', 'a=b')])
    assert cookies == []

    # Cookie has expired
    cookies = get_expired_cookies([
        ('Set-Cookie', 'a=b; expires=%s' %
         datetime.datetime.fromtimestamp(now - 1).strftime('%a, %d-%b-%Y %H:%M:%S GMT'))],
        now=now)
    assert cookies == [{'name': 'a', 'path': '/'}]

    # Cookie has not expired

# Generated at 2022-06-21 15:02:21.063918
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar'),
        ('Set-Cookie', 'baz=bar'),
        ('Set-Cookie', 'baz=bar; domain=example.com'),
        ('Set-Cookie', 'baz=bar; domain=example.com; path=/foo'),
        ('Set-Cookie', 'baz=bar; domain=example.com; path=/'),
        ('Set-Cookie', 'baz=bar; domain=example.com; path=/foo/; expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=bar; domain=example.com; path=/; max-age=10'),
        ('Set-Cookie', 'baz=bar; domain=example.com; path=/; max-age=10000'),
    ]


# Generated at 2022-06-21 15:02:23.569983
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/a/b/c/d.gif') == 'image/gif'
    assert get_content_type('/a/b/c/d.HTML') == 'text/html'

# Generated at 2022-06-21 15:02:27.639888
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert type(d) is OrderedDict
    assert list(d.keys()) == ['a', 'b', 'c']

# Generated at 2022-06-21 15:02:35.448460
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    sessionid = 'sessionid=f4a4f28a-68d4-4caa-9fd6-d8e0989fea4e; expires=Tue, 26-Nov-2019 16:30:55 GMT; httponly; Max-Age=1209600; Path=/'
    headers = [('Set-Cookie', sessionid)]
    expired_cookies = get_expired_cookies(headers)
    assert len(expired_cookies) == 0
    headers = [('Set-Cookie', 'some_key=some_value; expires=Sat, 01-Jan-2000 00:00:00 GMT;')]
    expired_cookies = get_expired_cookies(headers)
    assert len(expired_cookies) == 1
    assert expired_cookies[0]['name'] == 'some_key'

# Generated at 2022-06-21 15:02:46.170216
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise AssertionError
    if humanize_bytes(1024, 1) != '1.0 kB':
        raise AssertionError
    if humanize_bytes(1024 * 123, 1) != '123.0 kB':
        raise AssertionError
    if humanize_bytes(1024 * 12342, 1) != '12.1 MB':
        raise AssertionError
    if humanize_bytes(1024 * 12342, 2) != '12.05 MB':
        raise AssertionError
    if humanize_bytes(1024 * 1234, 2) != '1.21 MB':
        raise AssertionError
    if humanize_bytes(1024 * 1234 * 1111, 2) != '1.31 GB':
        raise AssertionError

# Generated at 2022-06-21 15:02:48.780756
# Unit test for function repr_dict
def test_repr_dict():
    x = {'a': 1, 'b': 2}
    x_repr = "{\n    'a': 1,\n    'b': 2\n}"
    assert repr_dict(x) == x_repr



# Generated at 2022-06-21 15:02:55.199320
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1234) == '1234 B'
    assert humanize_bytes(11 * 1024) == '11 kB'
    assert humanize_bytes(1234 * 1024) == '1.21 MB'
    assert humanize_bytes(1234 * 1024, 1) == '1.2 MB'
    assert humanize_bytes(1234 * 1024, 0) == '1 MB'
    assert humanize_bytes(1235 * 1024) == '1.21 MB'
    assert humanize_bytes(1235 * 1024, 1) == '1.2 MB'
    assert humanize_bytes(1235 * 1024, 0) == '1 MB'

"""

"""

# Generated at 2022-06-21 15:02:55.933336
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 15:03:03.524001
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from app_common.crawler.tests import test_utils
    from .utils.cookies import COOKIES_TXT_PATH
    with test_utils.with_mocked_requests(cookie_file_path=COOKIES_TXT_PATH):
        headers = test_utils.mimic_response.headers.items()
    now = 1479308309
    cookies = get_expired_cookies(headers, now=now)
    assert cookies == [{'name': '_pulse2data_session', 'path': '/'}]

# Generated at 2022-06-21 15:03:12.936188
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    auth()
    return True

# Generated at 2022-06-21 15:03:18.753711
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    """
    Test :func:`~plaster.tools.utils.get_expired_cookies`
    """

    from json import loads
    from os.path import dirname, join
    from unittest import TestCase
    from urllib.parse import urlparse

    from plaster.tools.utils import get_expired_cookies

    class ExpectedResult:
        def __init__(self, params):
            self.request_url = params['request_url']
            self.request_method = params['request_method']
            self.expired = set(path for path, name in params['expired'])


# Generated at 2022-06-21 15:03:28.729044
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('bundle.tar.gz') == 'application/gzip'
    assert get_content_type('bundle.zip') == 'application/zip'
    assert get_content_type('bundle.json') == 'application/json'
    assert get_content_type('bundle.mp4') == 'video/mp4'
    assert get_content_type('bundle.mp4?foo=bar') == 'video/mp4'
    assert get_content_type('bundle.mp4?foo=bar&a=b') == 'video/mp4'
    assert get_content_type('bundle.mp4?foo=%3Cb%3E') == 'video/mp4'

# Generated at 2022-06-21 15:03:32.370218
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = """
        {"id": 1, "name": "some", "children": [{"id": 2, "name": "child"}]}
    """
    json_obj = load_json_preserve_order(json_str)
    assert json_obj['name'] == 'some'
    assert json_obj['id'] == 1
    assert len(json_obj['children']) > 0



# Generated at 2022-06-21 15:03:34.068166
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-21 15:03:36.151479
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({
        'one': 1,
        'two': 2,
        'three': 3,
    }) == """\
{'one': 1, 'three': 3, 'two': 2}"""

# Generated at 2022-06-21 15:03:36.973835
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()



# Generated at 2022-06-21 15:03:46.413008
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'A=B'),
        ('Set-Cookie', 'X=Y; Path=/path; expires=Mon, 10 Apr 2017 17:05:00 GMT'),
        ('Set-Cookie', 'C=D; Path=/path; expires=Mon, 10 Apr 2017 17:05:00 GMT'),
        ('Set-Cookie', 'E=F; Path=/path; Max-Age=100'),
        ('Set-Cookie', 'G=H'),
    ]
    cookies = get_expired_cookies(headers, now=1491827946.149878)
    assert cookies == [
        {'name': 'X', 'path': '/path'},
        {'name': 'C', 'path': '/path'},
    ]

# Generated at 2022-06-21 15:03:47.501684
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    testData = ExplicitNullAuth()
    assert testData is not None

# Generated at 2022-06-21 15:03:49.065487
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(
        'mydir/myfile.txt'
    ) == 'text/plain'

