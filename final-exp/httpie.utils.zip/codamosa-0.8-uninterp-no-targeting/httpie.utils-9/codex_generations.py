

# Generated at 2022-06-21 14:55:45.327082
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 14:55:52.654660
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo/bar.txt') == 'text/plain'
    assert get_content_type('foo.exe') == 'application/octet-stream'
    assert get_content_type('foo.cab') == None
    assert get_content_type('foo.tar.gz') == 'application/gzip'
    assert get_content_type('foo.tar.bz2') == 'application/x-bzip2'

# Generated at 2022-06-21 14:55:58.855101
# Unit test for function humanize_bytes
def test_humanize_bytes():
    for i, o in [
            (1, '1 B'),
            (1024, '1.0 kB'),
            (1024 * 123, '123.0 kB'),
            (1024 * 12342, '12.1 MB'),
            (1024 * 12342, '12.05 MB'),
            (1024 * 1234, '1.21 MB'),
            (1024 * 1234 * 1111, '1.31 GB'),
            (1024 * 1234 * 1111, '1.3 GB')
    ]:
        assert o == humanize_bytes(i)

# Generated at 2022-06-21 14:56:09.525432
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    def get_test_cases():
        class Request:
            def __init__(self, url, data, headers):
                self.url = url
                self.data = data
                self.headers = headers

            def __str__(self) -> str:
                return repr(self.__dict__)


# Generated at 2022-06-21 14:56:21.561181
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:56:24.935019
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({
        'asdf': 1,
        'jkl': {
            'a': 2
        }
    }) == '{\'asdf\': 1, \'jkl\': {\'a\': 2}}'

# Generated at 2022-06-21 14:56:35.414623
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime
    response_headers = (
        ('Set-Cookie', 'ee=1; expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'de=1; max-age=10')
    )
    now = time.mktime(datetime.datetime(2020, 1, 2).timetuple())
    expected_cookies = [
        {'name': 'de', 'path': '/'}
    ]
    assert get_expired_cookies(response_headers, now) == expected_cookies

# Generated at 2022-06-21 14:56:36.411225
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 14:56:42.397288
# Unit test for function get_content_type
def test_get_content_type():
    assert (
        get_content_type('/tmp/picture.jpg') ==
        'image/jpeg'
    )
    assert (
        get_content_type('/tmp/101.pdf') ==
        'application/pdf'
    )
    assert (
        get_content_type('/tmp/readme.txt') ==
        'text/plain'
    )
    assert (
        get_content_type('/tmp/program.py') ==
        'text/x-python'
    )
    assert get_content_type('/tmp/foo') is None

# Generated at 2022-06-21 14:56:45.211314
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"foo": [1, 2]}') == {"foo": [1, 2]}

# Generated at 2022-06-21 14:56:51.607603
# Unit test for function get_content_type
def test_get_content_type():
    from pytest import approx
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.json') == 'application/json'

# Unit tests for functions get_expired_cookies and _max_age_to_expires

# Generated at 2022-06-21 14:56:58.489170
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict({'a': '1', 'b': '2'}) == "{'a': '1', 'b': '2'}"
    assert repr_dict({'a': '1', 'b': '2', 'c': '2'}) \
        == "{'a': '1', 'b': '2', 'c': '2'}"
    assert repr_dict({'a': '1', 'b': '2', 'c': '2', 'd': '2'}) \
        == "{'a': '1', 'b': '2', 'c': '2', 'd': '2'}"

# Generated at 2022-06-21 14:57:04.203513
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('a.txt') == 'text/plain'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.html') == 'text/html'

# Generated at 2022-06-21 14:57:10.407673
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # Author: L. C. Rees
    # URL: http://lcrees.co.uk/2012/06/27/humanize-bytes-python/
    # Licence: MIT
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 12342) == '12.05 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'
    assert humanize_bytes(1024 * 1234 * 1111) == '1.31 GB'

# Generated at 2022-06-21 14:57:20.053683
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def humanize(bytes, *args, **kwargs):
        return humanize_bytes(bytes, *args, **kwargs)

    def assert_humanize(bytes, s):
        s2 = humanize(bytes)
        assert s2 == s, 'expected %r, got %r' % (s, s2)

    assert_humanize(1, '1 B')
    assert_humanize(1024, '1.0 kB')
    assert_humanize(1024 * 123, '123.0 kB')
    assert_humanize(1024 * 12342, '12.1 MB')
    assert_humanize(1024 * 12342, '12.05 MB', precision=2)
    assert_humanize(1024 * 1234, '1.21 MB', precision=2)

# Generated at 2022-06-21 14:57:31.573070
# Unit test for function get_content_type
def test_get_content_type():
    import unittest

    class GetContentTypeTestCase(unittest.TestCase):
        def test_with_typical_file_extension(self):
            ct = get_content_type("file.html")
            self.assertEqual(ct, "text/html")

        def test_without_file_extension(self):
            ct = get_content_type("file")
            self.assertEqual(ct, None)

        def test_with_unknown_file_extension(self):
            ct = get_content_type("file.x-unknown-ext")
            self.assertEqual(ct, None)

        def test_with_one_less_typical_file_extension(self):
            ct = get_content_type("file.htm")

# Generated at 2022-06-21 14:57:42.406921
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # pylint: disable=protected-access
    from .util import get_expired_cookies

    assert get_expired_cookies(headers=[]) == []

    now = time.time()


# Generated at 2022-06-21 14:57:46.203766
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('/test.csv')
    assert content_type == 'text/csv'
    content_type = get_content_type('/test.csv.gpg')
    assert content_type == 'application/octet-stream'
    content_type = get_content_type('/test/')
    assert content_type is None

# Generated at 2022-06-21 14:57:50.951801
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'four=4; Max-Age=60'),
        ('Set-Cookie', 'two=2; Max-Age=120; Path=/'),
        ('Set-Cookie', 'three=3; Expires=Tue, 01 Jan 2030 00:00:00 GMT; Path=/; Secure; HttpOnly'),
        ('Set-Cookie', 'one=1; Expires=Tue, 01 Jan 1980 00:00:00 GMT; Path=/'),
    ]
    expired_cookies = get_expired_cookies(headers, now=1500000000)
    expected = [{'name': 'one', 'path': '/'}]
    assert expired_cookies == expected

# Generated at 2022-06-21 14:57:52.386432
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    obj = ExplicitNullAuth()
    assert obj('') == ''



# Generated at 2022-06-21 14:57:58.433793
# Unit test for function humanize_bytes
def test_humanize_bytes():
    for n, expected in (
        (1, '1 B'),
        (1024, '1.00 kB'),
        (1024 * 123, '123.00 kB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
    ):
        assert humanize_bytes(n) == expected

# Generated at 2022-06-21 14:58:04.495942
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('b.txt') == 'text/plain'
    assert get_content_type('b.png') == 'image/png'
    assert get_content_type('b.pdf') == 'application/pdf'
    assert get_content_type('b.non-existent-extension-for-sure') is None

# Generated at 2022-06-21 14:58:09.315309
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
    {
        "z": "z",
        "y": "y",
        "x": "x"
    }
    """
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict)
    assert list(d.keys()) == ['z', 'y', 'x']

# Generated at 2022-06-21 14:58:17.514876
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:58:22.592850
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():

    s = '{"one": "two", "three": "four"}'
    assert load_json_preserve_order(s) == {
        'one': 'two',
        'three': 'four'
    }
    assert load_json_preserve_order(s) == OrderedDict([
        ('one', 'two'),
        ('three', 'four')
    ])

# Generated at 2022-06-21 14:58:30.061061
# Unit test for function repr_dict
def test_repr_dict():

    expected_values = [
        ("{}", "{}"),
        ("{'a': None}", "{'a': None}"),
        (
            "{'a': 'b', 'c': {'d': 'e', 'f': 'g'}}",
            "{'a': 'b', 'c': {'d': 'e', 'f': 'g'}}",
        )
    ]

    for given_value, expected_value in expected_values:
        assert repr_dict(eval(given_value)) == expected_value

# Generated at 2022-06-21 14:58:32.117545
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth

# Generated at 2022-06-21 14:58:36.969784
# Unit test for function repr_dict
def test_repr_dict():
    example = {'a': {'b': {'c': 'd'}, 'e': [1, 2, 3]}}
    assert repr_dict(example) == pformat(example)
    example = {'a': {'b': {'c': 'd'}, 'e': [1, 2, 3]}}
    assert repr_dict(example) == pformat(example)

# Generated at 2022-06-21 14:58:40.046936
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = r'{"c": 3, "b": [2, 2], "a": 1}'
    assert load_json_preserve_order(s) == {"c": 3, "b": [2, 2], "a": 1}

# Generated at 2022-06-21 14:58:41.063473
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is ExplicitNullAuth()