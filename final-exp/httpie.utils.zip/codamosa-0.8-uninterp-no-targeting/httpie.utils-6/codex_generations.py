

# Generated at 2022-06-21 14:55:35.728436
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    # noinspection PyProtectedMember
    assert ExplicitNullAuth()(requests.models.Request())

# Generated at 2022-06-21 14:55:42.812264
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

    headers = [
        ('Set-Cookie', 'name1=value1; Domain=.example.com'),
        ('Set-Cookie', 'name2=value2; Domain=.example.com; Path=/foo'),
        ('Set-Cookie', 'name3=value3; Domain=.example.com; Path=/foo; Expires=Wed, 09 June 2021 10:18:14 GMT'),
        ('Set-Cookie', 'name4=value4; Domain=.example.com; Path=/foo; Expires=Wed, 09 June 2020 10:18:14 GMT')
    ]

    result = get_expired_cookies(headers, now=now)

    assert result == [
        {'name': 'name4', 'path': '/foo'},
    ]

# Generated at 2022-06-21 14:55:52.696332
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024*123, 1) == '123.0 kB'
    assert humanize_bytes(1024*12342, 1) == '12.1 MB'
    assert humanize_bytes(1024*12342, 2) == '12.05 MB'
    assert humanize_bytes(1024*1234, 2) == '1.21 MB'
    assert humanize_bytes(1024*1234*1111, 2) == '1.31 GB'
    assert humanize_bytes(1024*1234*1111, 1) == '1.3 GB'

# Generated at 2022-06-21 14:56:01.476261
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:56:08.176112
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.0 kB'


if __name__ == '__main__':
    test_humanize_bytes()
    print('Passed unit tests')

# Generated at 2022-06-21 14:56:10.656034
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import AuthBase

    args = (AuthBase, )
    rest = {}

    obj = ExplicitNullAuth(**rest)
    assert isinstance(obj, args)



# Generated at 2022-06-21 14:56:12.569984
# Unit test for function humanize_bytes
def test_humanize_bytes():
    result = humanize_bytes(1024, precision=1)
    assert result == '1.0 kB'

# Generated at 2022-06-21 14:56:19.735876
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Try it with httpbin.org as it has no auth.
    auth = ExplicitNullAuth()
    resp = requests.get(
        # `auth` arg is not required, but being explicit to prevent
        # `requests` from trying to fall back to `.netrc`.
        'http://httpbin.org/get',
        auth=auth,
        allow_redirects=False
    )
    assert resp.status_code == 200

# Generated at 2022-06-21 14:56:30.021809
# Unit test for function get_content_type
def test_get_content_type():
    from mock import patch

    # A default OS X install has the following entries in the map
    # built from the system mime.types file
    assert (
        get_content_type('foo.html')
        == 'text/html; charset=us-ascii'
    )
    assert (
        get_content_type('foo.ics')
        == 'text/calendar; charset=us-ascii'
    )
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert (
        get_content_type('foo.jpg')
        == 'image/jpeg'
    )
    assert (
        get_content_type('foo.rtf')
        == 'application/rtf; charset=us-ascii'
    )

# Generated at 2022-06-21 14:56:40.488480
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == (
        "{\n"
        "    'a': 1,\n"
        "    'b': 2,\n"
        "    'c': 3\n"
        "}"
    )
    dict_list = {
        'a': 1,
        'b': ['one', 'two', 'three'],
        'c': {'one': 1, 'two': 2, 'three': 3}
    }

# Generated at 2022-06-21 14:56:54.202790
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('set-cookie', 'sessionToken=""; expires=Tue, 01-Jan-1980 00:00:10 GMT; Max-Age=0; path=/'),
        ('set-cookie', 'qwerty=1; Max-Age=-42; path=/; expires=Tue, 01-Jan-1980 00:00:08 GMT'),
        ('set-cookie', 'foo=bar; Max-Age=1; path=/'),
        ('set-cookie', 'asdfgh=123456; Max-Age=2; path=/')
    ]
    expected = [
        {'name': 'sessionToken', 'path': '/'},
        {'name': 'qwerty', 'path': '/'}
    ]

    expired = get_expired_cookies(headers, now=10)

    assert expired == expected

# Generated at 2022-06-21 14:56:57.440346
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    class Response(object):
        request = 'fake-request'

    auth = ExplicitNullAuth()
    response = auth(Response())
    assert response == 'fake-request'

# Generated at 2022-06-21 14:56:59.807417
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"



# Generated at 2022-06-21 14:57:01.697803
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():  # TODO move it to a test module
    e = ExplicitNullAuth()
    assert e

# Generated at 2022-06-21 14:57:06.616985
# Unit test for function humanize_bytes
def test_humanize_bytes():
    cases = (
        (1000,          '1.00 kB'),
        (1234,          '1.23 kB'),
        (1234000,       '1.23 MB'),
        (1234000000,    '1.23 GB'),
        (1234000000000, '1.23 TB'),
        (None,          '0.00 B'),
    )
    for n, expected in cases:
        actual = humanize_bytes(n)
        assert actual == expected

# Generated at 2022-06-21 14:57:07.980982
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 14:57:18.079073
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:57:30.282607
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import HTTPBasicAuth
    from .cookiejar import RequestsCookieJar

    class FauxAuthRegistry(requests.auth.AuthBase):
        _registry = {}

        def __call__(self, r):
            for auth in self._registry.get(r.url, []):
                r = auth(r)
            return r

    class MockRequest:
        def __init__(self, url, auth):
            self.url = url
            self.auth = auth

    auth = ExplicitNullAuth()
    auth_registry = FauxAuthRegistry()
    jar = RequestsCookieJar()

    url = 'https://example.com/a'
    auth_registry._registry[url] = [HTTPBasicAuth('a', 'b')]

    req = MockRequest(url, auth)


# Generated at 2022-06-21 14:57:33.772182
# Unit test for function repr_dict
def test_repr_dict():
    test_dict = {'one': 1, 'two': 2, 'three': 3}
    assert repr_dict(test_dict) == "{'one': 1, 'two': 2, 'three': 3}"

# Generated at 2022-06-21 14:57:38.379517
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict(OrderedDict([('a', 1), ('b', 2)])) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 14:57:42.696215
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('image.png') == 'image/png'
    assert get_content_type('image.jpg') == 'image/jpeg'
    assert get_content_type('image.pdf') == 'application/pdf'

# Generated at 2022-06-21 14:57:44.188943
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(foo='bar', baz=42)
    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-21 14:57:47.651534
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': [1, 2, 3]}) == "{'a': [1, 2, 3]}"
    assert repr_dict({'a': {'b': 1}}) == "{'a': {'b': 1}}"


# Generated at 2022-06-21 14:57:50.015275
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    obj = ExplicitNullAuth()
    r = object()
    actual = obj(r)
    assert r is actual



# Generated at 2022-06-21 14:57:55.001348
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from unittest.mock import Mock
    r = Mock()
    # noinspection PyCallingNonCallable
    auth = ExplicitNullAuth()
    # noinspection PyTypeChecker
    assert auth(r) is r
    assert not r.prepare_auth.called

# Generated at 2022-06-21 14:58:06.299123
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:58:08.414972
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': ['one', 'two', 'three'], 'b': None, 'c': set([1, 2, 3])}
    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-21 14:58:11.140862
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('dog.jpg') == 'image/jpeg'
    assert get_content_type('cat.pdf') == 'application/pdf'

# Generated at 2022-06-21 14:58:17.993665
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:58:19.489504
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(x=1)) == "{'x': 1}"



# Generated at 2022-06-21 14:58:31.339514
# Unit test for function get_content_type

# Generated at 2022-06-21 14:58:36.533617
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    >>> d = load_json_preserve_order('''{"c": 1, "b": 2, "a": 3}''')
    >>> d == OrderedDict([('c', 1), ('b', 2), ('a', 3)])
    True
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 14:58:39.964506
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    result = load_json_preserve_order(s)
    expected = OrderedDict([("a", 1), ("b", 2), ("c", 3)])

    assert(result == expected)

# Generated at 2022-06-21 14:58:45.828444
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1, precision=3) == "1.000 B"
    assert humanize_bytes(1024, precision=1) == "1.0 kB"
    assert humanize_bytes(1024 * 123, precision=1) == "123.0 kB"
    assert humanize_bytes(1024 * 12342, precision=1) == "12.1 MB"
    assert humanize_bytes(1024 * 12342, precision=2) == "12.05 MB"
    assert humanize_bytes(1024 * 1234, precision=2) == "1.21 MB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == "1.31 GB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == "1.3 GB"
    assert humanize_bytes

# Generated at 2022-06-21 14:58:56.655473
# Unit test for function humanize_bytes
def test_humanize_bytes():
    #  fmt: off
    assert humanize_bytes(0) == "0 B"
    assert humanize_bytes(1) == "1 B"
    assert humanize_bytes(1, precision=1) == "1.0 B"
    assert humanize_bytes(1000, precision=1) == "1000.0 B"
    assert humanize_bytes(1000, precision=2) == "1000.00 B"
    assert humanize_bytes(1023, precision=1) == "1023.0 B"
    assert humanize_bytes(1023, precision=2) == "1023.00 B"
    assert humanize_bytes(1024, precision=1) == "1.0 kB"
    assert humanize_bytes(1024, precision=2) == "1.00 kB"

# Generated at 2022-06-21 14:58:57.534690
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    return auth()

# Generated at 2022-06-21 14:58:58.872246
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 14:59:00.354691
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:59:07.602726
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json
    json_file = open('H:\\Projects\\PycharmProjects\\MSTC-WebTool-API-Debugger\\tests\\data\\mstc.postman_collection.json', 'r', encoding='utf-8')
    dict = load_json_preserve_order(json_file.read())
    #print(dict)
    print(type(dict))
    print(dict['info']['name'], dict['item'][0]['name'])


if __name__ == '__main__':
    test_load_json_preserve_order()

# Generated at 2022-06-21 14:59:17.169705
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    test_cookies = [
        ('set-cookie', 'session=123; path=/; domain=.test.com; secure; HttpOnly'),
        ('set-cookie', 'session2=123; path=/; domain=.test.com; secure; HttpOnly; Expires=Wed, 15 Oct 2014 05:07:09 GMT'),
        ('set-cookie', 'session3=123; path=/; domain=.test.com; secure; HttpOnly; Max-Age=60'),
        ('set-cookie', 'session4=123; path=/; domain=.test.com; secure; HttpOnly; Max-Age=120'),
    ]

    assert get_expired_cookies(test_cookies, now=0) == [{'name': 'session2', 'path': '/'}]

# Generated at 2022-06-21 14:59:20.497088
# Unit test for function repr_dict
def test_repr_dict():
    d = {"foo": ["bar", "baz"], "bar": [1, 2, 3]}

    assert repr_dict(d) == pformat(d)



# Generated at 2022-06-21 14:59:24.195387
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.Json') == 'application/json'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.bar.json') == 'application/json'
    assert get_content_type('foo') is None

# Generated at 2022-06-21 14:59:35.037189
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': (1, 2, 3)}) == "{'a': (1, 2, 3)}"
    assert repr_dict({'a': {'b': {'c': 1}}}) == (
        "{\n"
        "    'a': {\n"
        "        'b': {'c': 1}\n"
        "    }\n"
        "}"
    )
    assert repr_dict({'a': {'b': {'c': {}}}}) == (
        "{\n"
        "    'a': {\n"
        "        'b': {\n"
        "            'c': {}\n"
        "        }\n"
        "    }\n"
        "}"
    )


#

# Generated at 2022-06-21 14:59:38.635633
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (512, '512.0 B'),
        (1024 * 512, '512.0 kB')
    ]
    for value, expected_result in tests:
        assert humanize_bytes(value) == expected_result

# Generated at 2022-06-21 14:59:41.969960
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Unit test for method ``__call__`` of class ``ExplicitNullAuth``
    """
    from . import requests

    ua = ExplicitNullAuth()
    req = requests.Request('GET', 'http://example.com')
    req = ua(req)
    req.prepare()
    assert not req.body  # noqa



# Generated at 2022-06-21 14:59:51.914210
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

if __name__ == '__main__':
    import unittest

    class Test_get_expired_cookies(unittest.TestCase):
        def test_adds_path_and_name(self):
            headers = [
                (
                    'Set-Cookie',
                    'foo=bar; max-age=1; path=/foo'
                ),
                (
                    'Set-Cookie',
                    'baz=quux; max-age=1; path=/'
                ),
                (
                    'Set-Cookie',
                    'baz=quux; max-age=1; path=/; expires=Wed, 21 Oct 2015'
                        ' 07:28:00 GMT'
                ),
            ]
            now = 1000

# Generated at 2022-06-21 15:00:00.131729
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(
        id=1,
        name='foo',
        payer=dict(id=2, name='bar'),
        stuff=dict(
            id=3,
            name='stuff',
            payer=dict(id=4, name='payee'),
        ),
    )
    assert repr_dict(d) == '''\
{'id': 1,
 'name': 'foo',
 'payer': {'id': 2, 'name': 'bar'},
 'stuff': {'id': 3,
           'name': 'stuff',
           'payer': {'id': 4, 'name': 'payee'}}}'''

# Generated at 2022-06-21 15:00:06.859258
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    def assert_dict_str_equals(dict_str_1, dict_str_2):
        return OrderedDict(load_json_preserve_order(dict_str_1)) == OrderedDict(load_json_preserve_order(dict_str_2))

    assert_dict_str_equals(
        '{"a": 1, "b": 2}',
        '{"a": 1, "b": 2}'
    )
    assert_dict_str_equals(
        '{"a": 1, "b": 2, "c": 3}',
        '{"a": 1, "b": 2, "c": 3}'
    )

# Generated at 2022-06-21 15:00:16.237049
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import request
    from requests.exceptions import HTTPError
    from pipewrench.exceptions import (
        PipewrenchReturnCodeError,
        PipewrenchRuntimeError,
    )

    def test(
        *args,
        expected_rc,
        expected_output,
        expected_exception=PipewrenchReturnCodeError,
        expected_cause=None,
        url='https://example.com',
        **kwargs
    ):
        auth = ExplicitNullAuth()

        try:
            request(*args, auth=auth, **kwargs)
        except PipewrenchReturnCodeError as e:
            if e.rc != expected_rc:
                raise AssertionError(
                    f'Unexpected return code: {e.rc} != {expected_rc}'
                )

# Generated at 2022-06-21 15:00:25.549116
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    from geojson import dumps
    from geomet import wkt

    json_str = '[{"a": "1", "b": "2", "c": "3"}, {"a": "4", "b": "5", "c": "6"}]'
    json_str_with_order = '[{"b": "2", "a": "1", "c": "3"}, {"c": "6", "b": "5", "a": "4"}]'
    json_dict_with_order = [OrderedDict([("b", "2"), ("a", "1"), ("c", "3")]), OrderedDict([("c", "6"), ("b", "5"), ("a", "4")])]

# Generated at 2022-06-21 15:00:27.524137
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()


# Generated at 2022-06-21 15:00:37.540260
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.htm') == 'text/html'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.text') == 'text/plain'
    assert get_content_type('test.js') == 'application/javascript'
    assert get_content_type('test.mjs') == 'application/javascript'
    assert get_content_type('test.json') == 'application/json'
    assert get_content_type('test.gif') == 'image/gif'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.jpeg') == 'image/jpeg'
    assert get_content

# Generated at 2022-06-21 15:00:47.296645
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 15:00:47.812376
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 15:00:53.505172
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('image.gif') == 'image/gif'
    assert get_content_type('text/html') is None
    assert get_content_type('file with space.pdf') == (
        'application/pdf'
    )
    assert get_content_type('file_with_dot.no_extension') is None
    assert get_content_type('file.html') == 'text/html'
# End of unit test for function get_content_type

# Generated at 2022-06-21 15:01:03.741310
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:01:12.642337
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # noinspection PyUnresolvedReferences
    from tracim_backend.models.data import User

    # noinspection PyUnresolvedReferences
    from tracim_backend.config import CFG
    from tracim_backend.lib.core.user import UserApi

    app_config = CFG.get_instance()

    app_config.EMAIL_NOTIFICATION_ACTIVATED = False

    uapi = UserApi(
        current_user=None,  # User needs to be logged to send emails
        session=None,
        config=None,
        show_deleted=False,
        show_active=True,
        show_pending=False,
    )

# Generated at 2022-06-21 15:01:16.944233
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('index.html') == 'text/html'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('/some/path/test.css') == 'text/css'
    assert get_content_type('/some/path/test.png') == 'image/png'



# Generated at 2022-06-21 15:01:26.992096
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024*123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024*12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024*12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024*1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024*1234*1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024*1234*1111, precision=1) == '1.3 GB'


if __name__ == '__main__':
    test

# Generated at 2022-06-21 15:01:28.478758
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"foo": "bar"}') == {"foo": "bar"}



# Generated at 2022-06-21 15:01:41.154182
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:01:49.370339
# Unit test for function repr_dict
def test_repr_dict():
    import unittest

    class TestReprDict(unittest.TestCase):

        def test_one_level(self):
            self.assertEqual(repr_dict(dict(a=1, b='bbb', c=None)),
                             "{'a': 1, 'b': 'bbb', 'c': None}")

        def test_two_levels(self):
            self.assertEqual(repr_dict(dict(a=1, b='bbb', c=dict(d=11))),
                             "{'a': 1, 'b': 'bbb', 'c': {'d': 11}}")

        def test_three_levels(self):
            d = dict(a=1, b='bbb', c=dict(d=11, e=dict(f=111)))

# Generated at 2022-06-21 15:01:54.242090
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # type: () -> None

    def dict_to_str(d):
        return repr_dict(d)

    j_str = '{"b": {"b1":1, "b2":2}, "a": {"a1":1, "a2":2}}'
    assert dict_to_str(load_json_preserve_order(j_str)) == dict_to_str(json.loads(j_str))
    assert dict_to_str(load_json_preserve_order(j_str)) != dict_to_str(json.loads(j_str, object_pairs_hook=OrderedDict))

# Generated at 2022-06-21 15:01:58.774581
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': {'c': 2, 'd': 3}}
    assert repr_dict(d) == "{\n    'a': 1, \n    'b': {\n        'c': 2, \n        'd': 3\n    }\n}"



# Generated at 2022-06-21 15:02:04.098804
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # We have to check the string without formatting because it may have
    # non-ascii characters and we're not sure how pprint will format it.
    assert str(load_json_preserve_order('{"A": 1, "B": 2, "C": 3}')) == str(
        OrderedDict([("A", 1), ("B", 2), ("C", 3)]))


if __name__ == "__main__":
    test_load_json_preserve_order()

# Generated at 2022-06-21 15:02:10.663690
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-21 15:02:13.084042
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    o = load_json_preserve_order("{'a':1, 'b':2, 'c':3}")
    assert type(o) == OrderedDict
    assert o == {'a':1, 'b':2, 'c':3}


# Generated at 2022-06-21 15:02:15.677359
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    request = requests.Request('GET', 'https://example.com/')
    prepared = auth.__call__(request)
    assert prepared != request



# Generated at 2022-06-21 15:02:16.844813
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(None) is None

# Generated at 2022-06-21 15:02:19.611146
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('filename.html') == 'text/html'
    assert get_content_type('filename.OTHER_EXTENSION') is None

# Generated at 2022-06-21 15:02:28.767693
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
    {
        "a": 1,
        "b": 2,
        "c": 3
    }
    """
    expected = OrderedDict((('a', 1), ('b', 2), ('c', 3)))
    assert load_json_preserve_order(s) == expected



# Generated at 2022-06-21 15:02:35.805948
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 15:02:46.275997
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from pprint import pprint
    from requests.models import Request

    def remove_authorization(d):
        if 'Authorization' in d:
            del d['Authorization']
        return d

    auth = ExplicitNullAuth()

    req = Request(
        method='GET',
        url='http://httpbin.org/basic-auth/user/passwd',
        auth=('user', 'passwd')
    )
    pprint(remove_authorization(req.headers))
    auth(req)
    pprint(remove_authorization(req.headers))

    req = Request(
        method='GET',
        url='http://httpbin.org/headers',
        headers={'custom-header': 'value'}
    )
    pprint(req.headers)
    auth(req)

# Generated at 2022-06-21 15:02:50.890356
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    from requests.auth import HTTPBasicAuth

    username, password = 'foo', 'bar'

    auth_callable_1 = ExplicitNullAuth()
    assert isinstance(auth_callable_1, ExplicitNullAuth)

    auth_callable_2 = ExplicitNullAuth('foo', 'bar')
    assert isinstance(auth_callable_2, HTTPBasicAuth)

    assert auth_callable_2.username == username
    assert auth_callable_2.password == password



# Generated at 2022-06-21 15:02:53.736702
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth_object = ExplicitNullAuth()
    request_object = requests.Request(method='GET', url='https://example.com/')
    prepped_request_object = auth_object(prepare=request_object.prepare())

    assert prepped_request_object is request_object



# Generated at 2022-06-21 15:03:04.200530
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1 << 50, precision=1) == '1.0 PB'
    assert humanize_bytes(1 << 40) == '1.0 TB'
    assert humanize_bytes(1 << 30) == '1.0 GB'
    assert humanize_bytes(1 << 20) == '1.0 MB'
    assert humanize_bytes(1 << 10) == '1.0 kB'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1, '3') == '1 B'

    assert humanize_bytes(1 << 40, precision=1) == '1.0 TB'
    assert humanize_bytes(1 << 40, precision=1) == '1.0 TB'

# Generated at 2022-06-21 15:03:12.024262
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    today = time.strftime('%a, %d %b %Y %H:%M:%S %Z', time.gmtime(now))
    cookies_raw_headers = [
        "Set-Cookie: csrftoken=Rh0oVtnFbRoulhRVtYJPpkYnV7jsqNh8; expires=Sat, 15-Aug-2020 07:30:29 GMT; Max-Age=31449600; Path=/",  # noqa
        "Set-Cookie: sessionid=2jh0d8lgw0nyzapfjvbx4s4s4k4s9s4s; expires={}; Max-Age=1209600; Path=/".format(today),  # noqa
    ]

# Generated at 2022-06-21 15:03:12.585300
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth

# Generated at 2022-06-21 15:03:17.093646
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"c":3,"a":1,"b":2}'
    d = load_json_preserve_order(s)
    assert d == {'c': 3, 'a': 1, 'b': 2}
    assert list(d.keys()) == ['c', 'a', 'b']
    s = '{"foo":1}'
    d = load_json_preserve_order(s)
    assert d == {'foo': 1}
    assert list(d.keys()) == ['foo']

# Generated at 2022-06-21 15:03:25.384883
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'b': 1, 'a': 2}) == "{'b': 1, 'a': 2}"
    assert repr_dict({'a': {'x': 1, 'y': 2}, 'b': 2}) == \
        "{'a': {'x': 1, 'y': 2}, 'b': 2}"
    assert repr_dict({'b': 1, 'a': {'x': 1, 'y': 2}}) == \
        "{'b': 1, 'a': {'x': 1, 'y': 2}}"



# Generated at 2022-06-21 15:03:43.915247
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:03:47.739594
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.exceptions import RequestException

    sess = Session()
    sess.auth = ExplicitNullAuth()
    try:
        sess.get('https://httpbin.org/robots.txt')
    except RequestException as exc:
        assert exc.response.url == 'https://httpbin.org/robots.txt'



# Generated at 2022-06-21 15:03:54.494437
# Unit test for function humanize_bytes

# Generated at 2022-06-21 15:03:58.912782
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        (0, '0 B', ),
        (1, '1 B', ),
        (1024, '1.0 kB', ),
        (1024 * 123, '123.0 kB', ),
        (1024 * 12342, '12.1 MB', ),
        (1024 * 12342, '12.05 MB', 2),
        (1024 * 1234, '1.21 MB', 2),
        (1024 * 1234 * 1111, '1.31 GB', 2),
        (1024 * 1234 * 1111, '1.3 GB', 1),
        (1024 * 1234 * 1111, '1.3 GB', 1),
    ]

    for kbytes, expected_humanized, precision in tests:
        humanized = humanize_bytes(kbytes * 1024, precision=precision)
        assert humanized

# Generated at 2022-06-21 15:04:04.801533
# Unit test for function get_content_type
def test_get_content_type():
    def _test(filename, expected):
        content_type = get_content_type(filename)
        assert content_type == expected, (
            f'{filename} has content type {content_type}, expected {expected}'
        )

    _test('test_har.py', 'text/x-python')
    _test('test_har.sh', 'text/x-shellscript')
    _test('README.md', 'text/markdown')

# Generated at 2022-06-21 15:04:10.667187
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def h(n, r):
        assert humanize_bytes(n) == r
    h(0, '0 B')
    h(1, '1 B')
    h(1024, '1.0 kB')
    h(1024 * 1024, '1.0 MB')
    h(1024**3, '1.0 GB')
    h(1024**4, '1.0 TB')
    h(1024**5, '1024.0 TB')

# Generated at 2022-06-21 15:04:11.471933
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-21 15:04:13.685681
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.bin') == 'application/octet-stream'

# Generated at 2022-06-21 15:04:20.695397
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == "1 B"
    assert humanize_bytes(1024) == "1.00 kB"
    assert humanize_bytes(1024*123) == "123.00 kB"
    assert humanize_bytes(1024*12342) == "12.05 MB"
    assert humanize_bytes(1024*1234*1111,1) == "1.3 GB"
    assert humanize_bytes(1024*1234*1111,2) == "1.31 GB"


if __name__ == '__main__':
    test_humanize_bytes()

# Generated at 2022-06-21 15:04:30.952894
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:04:56.105700
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    cookie = dict(name='foo', value='bar', path='/', expires=now - 10)

    pairs = [
        ('Set-Cookie', 'foo=bar; expires=Fri, 31 Dec 1999 23:59:59 GMT; '
         'path=/; HttpOnly'),
    ]
    cookies = get_expired_cookies(pairs)
    assert len(cookies) == 1
    assert cookies[0] == cookie

    pairs = [
        ('Set-Cookie', 'foo=bar; max-age=60; path=/; HttpOnly'),
    ]
    cookies = get_expired_cookies(pairs, now=now + 100)
    assert len(cookies) == 0
    cookies = get_expired_cookies(pairs, now=now - 100)
   

# Generated at 2022-06-21 15:04:57.060353
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

    assert not auth


# Unit tests for function get_content_type

# Generated at 2022-06-21 15:04:59.164806
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"



# Generated at 2022-06-21 15:05:02.992830
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('text.html') == 'text/html'
    assert get_content_type('image.jpeg') == 'image/jpeg'
    assert get_content_type('text.csv') == 'text/csv'
    assert get_content_type('text.csv') != 'text/x-csv'

# Generated at 2022-06-21 15:05:05.226160
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth).startswith('<__main__.ExplicitNullAuth object at')


# Generated at 2022-06-21 15:05:12.405004
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') == 'text/plain'
    assert get_content_type('.txt') == 'text/plain'
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.mp4') == 'video/mp4'
    assert get_content_type('data:text/plain,foo') == 'text/plain'

# Generated at 2022-06-21 15:05:15.178845
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.js') == 'text/javascript'
    assert get_content_type('test.mp3') == 'audio/mpeg'

# Generated at 2022-06-21 15:05:15.876614
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-21 15:05:23.596131
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from pprint import pprint
    # sample expired cookies from a real browser

# Generated at 2022-06-21 15:05:27.289486
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename='some_file.txt') == 'text/plain'
    assert get_content_type(filename='some_file.xml') == 'text/xml'
    assert get_content_type(filename='some_file.jpeg') == 'image/jpeg'