

# Generated at 2022-06-21 14:55:41.128148
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies((
        ('Set-Cookie', 'a=b'),
    )) == [{'name': 'a', 'path': '/'}]

    assert get_expired_cookies((
        ('Set-Cookie', 'a=b; Domain=example.com'),
    )) == [{'name': 'a', 'path': '/'}]

    assert get_expired_cookies((
        ('Set-Cookie', 'a=b; Domain=example.com; Path=/foo'),
    )) == [{'name': 'a', 'path': '/foo'}]


# Generated at 2022-06-21 14:55:51.871134
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:56:00.942744
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 14:56:08.666378
# Unit test for function get_content_type
def test_get_content_type():
    # .txt files
    assert get_content_type('.txt') == 'text/plain'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo/bar.txt') == 'text/plain'
    assert get_content_type('/home/user/foo.txt') == 'text/plain'

    # .png files
    assert get_content_type('/home/user/foo.png') == 'image/png'

# Generated at 2022-06-21 14:56:10.757138
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"



# Generated at 2022-06-21 14:56:13.047433
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr_dict(d) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 14:56:18.374148
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    import requests_testadapter

    adapter = requests_testadapter.RespondWithContent(
        requests.Response(
            url='https://localhost',
            request=requests.Request(method='GET', url='https://localhost'),
            status_code=200,
            content=b'',
            headers={},
        )
    )

    session = requests.Session()
    session.mount('https://localhost', adapter)
    session.auth = ExplicitNullAuth()

    response = session.get('https://localhost')
    response.raise_for_status()



# Generated at 2022-06-21 14:56:24.758783
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/path/to/file.js') == 'application/javascript; charset=UTF-8'
    assert get_content_type('/path/to/image.jpeg') == 'image/jpeg; charset=UTF-8'
    assert get_content_type('/path/to/doc.pdf') == 'application/pdf; charset=UTF-8'
    assert get_content_type('/path/to/file.unknown') is None

# Generated at 2022-06-21 14:56:25.698503
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-21 14:56:34.747457
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    print(get_expired_cookies([
        # expired
        ('Set-Cookie', 'session=; expires=Wed, 13-Jan-2021 22:23:01 GMT;'),
        # expired
        ('Set-Cookie', 'session=; max-age=0'),
        # non-expired
        ('Set-Cookie', 'session=; expires=Wed, 13-Jan-2020 22:23:01 GMT;')
    ], now=2000000000))

# Generated at 2022-06-21 14:56:38.590101
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    obj = ExplicitNullAuth()
    assert obj.__call__(None) is None

# Generated at 2022-06-21 14:56:42.700447
# Unit test for function get_content_type
def test_get_content_type():
    from .test import assert_equal
    assert_equal(get_content_type('index.html'), 'text/html')
    assert_equal(get_content_type('logo.png'), 'image/png')

# Unit tests get_expired_cookies

# Generated at 2022-06-21 14:56:44.078765
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 14:56:47.200615
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('myfile.txt') == 'text/plain'
    assert get_content_type('myfile.txt.gz') == 'application/x-gzip'

# Generated at 2022-06-21 14:56:50.923558
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.png') == 'image/png'


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 14:57:01.339358
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.tar.gz') == 'application/gzip'
    assert get_content_type('foo.xz') == 'application/x-xz'
    assert get_content_type('foo.ogv') == 'video/ogg'
    assert get_content_type('foo.ogg') == 'audio/ogg'
    assert get_content_type('foo.mkv') == 'video/x-matroska'
    assert get_content_type('foo.mka') == 'audio/x-matroska'
    assert get_content_type('foo.mp4') == 'video/mp4'

# Generated at 2022-06-21 14:57:03.295079
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests

    # case of success
    auth = ExplicitNullAuth()
    request = requests.Request()
    assert(auth(request) == request)

# Generated at 2022-06-21 14:57:09.978762
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 14:57:12.178027
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    t = ExplicitNullAuth()
    assert t is not None



# Generated at 2022-06-21 14:57:14.870354
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"foo": 1, "bar": 2}') == {
        "foo": 1,
        "bar": 2
    }



# Generated at 2022-06-21 14:57:16.763756
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() == ExplicitNullAuth()

# Generated at 2022-06-21 14:57:29.515564
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([]) == []
    assert get_expired_cookies([
        ('Set-Cookie', 'foo=bar; Path=/')
    ]) == []
    assert get_expired_cookies([
        ('Set-Cookie', 'foo=bar; Expires=Mon, 28 Jan 2024 01:02:03 GMT;'
                      ' path=/'),
        ('Set-Cookie', 'foo=bar; Expires=Thu, 01 Jan 1970 00:00:00 GMT;'
                      ' path=/')
    ]) == [
        {'name': 'foo', 'path': '/'}
    ]

# Generated at 2022-06-21 14:57:37.064407
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = (
        (0.98, '98.00 B'),
        (1024, '1.00 kB'),
        (1024 * 123, '123.00 kB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
    )
    for num, expected in tests:
        assert humanize_bytes(num) == expected

# Generated at 2022-06-21 14:57:42.749797
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/foo/bar/test.csv') == 'text/csv'
    assert get_content_type('/foo/test.csv.xz') == 'application/x-xz'
    assert get_content_type('/foo/test.csv.txt') == 'text/plain'
    assert get_content_type('/foo/test.txt') == 'text/plain'
    assert get_content_type(None) is None



# Generated at 2022-06-21 14:57:53.949382
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:57:54.663016
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:58:05.611608
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    >>> test_load_json_preserve_order()
    """
    import json
    import pprint

    d = {"a": 1, "b": 2, "c": 3}
    s = json.dumps(d)
    assert d == json.loads(s)
    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(load_json_preserve_order(s))

    # s = '[{"a":1}, {"b":1}, {"b":2}, {"b":3}]'
    # assert s == json.dumps(load_json_preserve_order(s))


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 14:58:12.945762
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{"c": 8, "a": 2, "b": 3, "d": "A", "e": "B", "f": "C"}"""
    assert repr_dict(load_json_preserve_order(s)) == repr_dict(
        OrderedDict(
            [
                ('c', 8),
                ('a', 2),
                ('b', 3),
                ('d', 'A'),
                ('e', 'B'),
                ('f', 'C')
            ]
        )
    )

# Generated at 2022-06-21 14:58:23.094915
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime,timedelta

    def to_annotation_tuples(tuple_of_tuples):
        return [(t1[-1], t2[-1]) for t1, t2 in tuple_of_tuples]

    past = datetime.now() - timedelta(days=1)
    future = datetime.now() + timedelta(days=1)
    now = datetime.now()


# Generated at 2022-06-21 14:58:31.963011
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # get_expired_cookies("""
    #     Set-Cookie: foo=bar
    #     Set-Cookie: foo2=bar2; Max-Age=0""", now=time.time())
    headers = """
        Set-Cookie: foo=bar
        Set-Cookie: foo2=bar2; Max-Age=0
        Set-Cookie: foo3=bar3; Max-Age=10
    """
    headers = [
        h.strip().split(': ')
        for h in headers.splitlines()
        if h.strip()
    ]
    now = time.time()
    cookies = get_expired_cookies(headers=headers, now=now)
    expected = [
        {'name': 'foo2', 'path': '/'},
    ]
    assert cookies == expected

# Generated at 2022-06-21 14:58:36.532708
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Unit test for class ExplicitNullAuth instance.
    """
    assert ExplicitNullAuth()(None) == None  # noqa: E711


# Generated at 2022-06-21 14:58:42.740679
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
        (1024 * 1234 * 1111, '1.3 GB')
    ]
    for n, expected in tests:
        assert humanize_bytes(n, precision=2) == expected

# Generated at 2022-06-21 14:58:47.852384
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = """{
        "k1": "v1",
        "k2": "v2",
        "k3": "v3"
    }"""
    json_dict = load_json_preserve_order(json_string)
    for k in json_dict:
        assert json_dict[k] == 'v' + k

# Generated at 2022-06-21 14:58:58.182887
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    #test1
    input1 = '{"name":"Tanmay", "age":20, "avg":82.3, "active":true, "country":null, "skills":["Python", "Java", "C++"], "Big_data": {"topic":"spark", "domain":"Hadoop"}}'
    actual_output1 = {"name": "Tanmay", "age": 20, "avg": 82.3, "active": True, "country": None, "skills": ["Python", "Java", "C++"], "Big_data": {"topic": "spark", "domain": "Hadoop"}}
    output1 = load_json_preserve_order(input1)
    assert output1 == actual_output1

    #test2

# Generated at 2022-06-21 14:59:01.380437
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(
        a='a',
        b='b',
    )
    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-21 14:59:02.478387
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"

# Generated at 2022-06-21 14:59:13.348412
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 14:59:21.398664
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:59:24.803163
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    >>> class MockResponse:
    ...     def __init__(self):
    ...         self.history = []
    ...         self.cookies = {}
    >>> response = MockResponse()
    >>> ExplicitNullAuth()(response)
    >>> response.history
    []
    >>> response.cookies
    {}
    """

# Generated at 2022-06-21 14:59:26.193202
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    >>> ExplicitNullAuth()(None) is None
    True

    """
