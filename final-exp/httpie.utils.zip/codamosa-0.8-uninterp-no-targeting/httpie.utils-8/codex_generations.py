

# Generated at 2022-06-21 14:55:29.092856
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Test that ``__call__`` returns the request object unchanged.
    """
    req = object()
    auth = ExplicitNullAuth()
    req1 = auth(req)
    assert req1 is req

# Generated at 2022-06-21 14:55:30.211635
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), requests.auth.AuthBase)


# Generated at 2022-06-21 14:55:33.914669
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    method = ExplicitNullAuth().__call__
    r = requests.request('get', 'http://example.com/')
    result = method(r)
    assert result is r



# Generated at 2022-06-21 14:55:35.968153
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    req = requests.Request('GET', 'http://httpbin.org').prepare()
    req = auth(req)

# Generated at 2022-06-21 14:55:41.986152
# Unit test for function repr_dict
def test_repr_dict():
    from subprocess import Popen, PIPE

    d = dict(foo='bar', baz=['qux'])
    print(repr_dict(d))
    expected = 'dict(foo=\'bar\', baz=[\'qux\'])'
    p = Popen(['diff', '-u', '-', '-'], stdin=PIPE)
    p.communicate(input=repr_dict(d).encode('UTF-8'))
    p.communicate(input=expected.encode('UTF-8'))
    assert p.wait() == 0

# Generated at 2022-06-21 14:55:43.458409
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('path/to/image.png') == 'image/png'

# Generated at 2022-06-21 14:55:51.529866
# Unit test for function get_content_type
def test_get_content_type():
    from .conftest import HERE

    assert get_content_type('requirements.txt') == 'text/plain'
    assert get_content_type('requirements.py') == 'text/x-python'
    assert get_content_type(HERE.joinpath('data/bootstrap.min.css')) == \
        'text/css'
    assert get_content_type('not_a_real_file.txt') == 'text/plain'
    assert get_content_type('not_a_real_file') is None

# Generated at 2022-06-21 14:55:55.700733
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # This test is not as robust as I'd like, but it's a start.
    assert load_json_preserve_order(
        '{"age": 26, "name": "Alice", "height": 5.8}') == OrderedDict([
            ('age', 26),
            ('name', 'Alice'),
            ('height', 5.8),
        ])

# Generated at 2022-06-21 14:55:58.972625
# Unit test for function repr_dict
def test_repr_dict():
    input_dict = {'key1': 'value1', 'key2': 'value2'}
    expected = "OrderedDict([('key1', 'value1'), ('key2', 'value2')])"
    actual = repr_dict(input_dict)
    assert expected == actual

# Generated at 2022-06-21 14:56:05.870211
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=2) == '1.00 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    # Some negative tests.
    assert humanize_

# Generated at 2022-06-21 14:56:14.899561
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(2.5) == '2.5 B'
    assert humanize_bytes(2.5, precision=0) == '3 B'
    assert humanize_bytes(1000) == '1000 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'

# Generated at 2022-06-21 14:56:23.554898
# Unit test for function humanize_bytes
def test_humanize_bytes():
    pairs = (
        (1, '1 B'),
        (10, '10 B'),
        (1024, '1.0 kB'),
        (1234, '1.21 kB'),
        (12345678, '11.77 MB'),
        (123456789012, '1.14 TB'),
        (123456789012345, '1.1 PB'),

    )

    for i, o in pairs:
        assert humanize_bytes(i) == o, '%s != %s' % (humanize_bytes(i), o)

# Generated at 2022-06-21 14:56:29.333640
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:56:30.784823
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(a=1)
    repr_dict(d) == repr(d)

# Generated at 2022-06-21 14:56:35.774256
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr_dict(d) == "{'a': 1, 'b': 2}"
    d['c'] = 3
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'c': 3}"



# Generated at 2022-06-21 14:56:38.049656
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.html') != None



# Generated at 2022-06-21 14:56:50.547558
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo/bar.txt') == 'text/plain'
    assert get_content_type('foo/bar.TXT') == 'text/plain'
    assert get_content_type('foo.TXT') == 'text/plain'
    assert get_content_type('foo.txt.py') == 'text/plain'
    assert get_content_type('foo.txt.in') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'text/plain'
    assert get_content_type('foo.txt.bz2') == 'text/plain'
    assert get_content_type('foo.txt.xz') == 'text/plain'

# Generated at 2022-06-21 14:56:52.843707
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    null_auth = ExplicitNullAuth()
    assert null_auth == ExplicitNullAuth()
    assert null_auth != requests.auth.NullAuth()

# Generated at 2022-06-21 14:57:03.123071
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert(humanize_bytes(1) == '1 B')
    assert(humanize_bytes(1024) == '1.0 kB')
    assert(humanize_bytes(1024 * 123) == '123.0 kB')
    assert(humanize_bytes(1024 * 12342) == '12.1 MB')
    assert(humanize_bytes(1024 * 12342, precision=2) == '12.05 MB')
    assert(humanize_bytes(1024 * 1234, precision=2) == '1.21 MB')
    assert(humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB')
    assert(humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB')

# Generated at 2022-06-21 14:57:09.909333
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.svgz') == 'image/svg+xml'
    assert get_content_type('foo.bmp') == 'image/bmp'

# Generated at 2022-06-21 14:57:20.440115
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookie_str = 'a=b; Path=/; Domain=example.com; Expires=Tue, 15 Jan 2019 21:47:38 GMT; ' \
                 'Secure; HttpOnly'
    http_date = 'Tue, 15 Jan 2019 21:47:38 GMT'
    headers = [('server', 'nginx'),
               ('content-type', 'text/html; charset=UTF-8'),
               ('transfer-encoding', 'chunked'),
               ('connection', 'keep-alive'),
               ('vary', 'Accept-Encoding'),
               ('set-cookie', cookie_str),
               ('date', http_date)]
    expected = [{'name': 'a', 'path': '/'}]
    assert get_expired_cookies(headers, now=0) == expected

# Generated at 2022-06-21 14:57:31.752229
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({"foo": "bar"}) == "{'foo': 'bar'}"

# Generated at 2022-06-21 14:57:42.551664
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = [
        {'name': 'foo'},
        {'name': 'bar'},
        {'name': 'baz'},
    ]
    assert get_expired_cookies([], now=0) == []
    assert get_expired_cookies(
        [('Set-Cookie', 'foo=bar')], now=0
    ) == cookies[:-2]
    assert get_expired_cookies(
        [('Set-Cookie', 'bar=baz')], now=0
    ) == cookies[:-1]
    assert get_expired_cookies(
        [('Set-Cookie', 'baz=foo')], now=0
    ) == cookies[:]


# Generated at 2022-06-21 14:57:43.367771
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)

# Generated at 2022-06-21 14:57:44.506328
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    e = ExplicitNullAuth()
    assert isinstance(e, requests.auth.AuthBase)

# Generated at 2022-06-21 14:57:45.461518
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-21 14:57:51.041527
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert '1 B' == humanize_bytes(1)
    assert '1.0 kB' == humanize_bytes(1 << 10)
    assert '1.0 kB' == humanize_bytes(1024)
    assert '123.0 kB' == humanize_bytes(123 << 10)
    assert '12.1 MB' == humanize_bytes(12342 << 10)
    assert '12.05 MB' == humanize_bytes(12342 << 10, precision=2)
    assert '1.21 MB' == humanize_bytes(1234 << 10, precision=2)
    assert '1.31 GB' == humanize_bytes(1234 << 20, precision=2)
    assert '1.3 GB' == humanize_bytes(1234 << 20, precision=1)

# Generated at 2022-06-21 14:57:56.551134
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('text.txt') == 'text/plain'

    assert get_content_type('image.jpg') == 'image/jpeg'

    assert get_content_type('image.gif') == 'image/gif'

    assert get_content_type('image.png') == 'image/png'

# Generated at 2022-06-21 14:58:07.929967
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('image.svg') == 'image/svg+xml'
    assert get_content_type('image.JPEG') == 'image/jpeg'
    assert get_content_type('image.jpeg') == 'image/jpeg'
    assert get_content_type('image.jpeg;foo=bar') == \
        'image/jpeg; charset=foo=bar'
    # Test cases from <https://github.com/psf/requests/issues/2773>
    assert (get_content_type('url.swf') ==
            'application/x-shockwave-flash')
    assert (get_content_type('url.doc') ==
            'application/msword')
    assert get_content_type('url.exe') is None

# Generated at 2022-06-21 14:58:16.967620
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:58:25.873341
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    session_set_cookie = 'sessionid=a; Max-Age=1234; Path=/; Expires=Thu, 01-Jan-1970 00:00:00 GMT; HttpOnly; SameSite=Lax'
    now = time.time()
    cookies = get_expired_cookies(headers=[('Set-Cookie', session_set_cookie)], now=now)
    expected = [{'name': 'sessionid', 'path': '/'}]
    assert cookies == expected

# Generated at 2022-06-21 14:58:26.747690
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 14:58:32.337040
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    assert OrderedDict([('a', 1), ('b', 2), ('c', 3)]) == load_json_preserve_order(s)

# Generated at 2022-06-21 14:58:33.626742
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert 0 == auth.__call__(0)

# Generated at 2022-06-21 14:58:42.445475
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json

    class OrderedSuperDict(OrderedDict):
        def __repr__(self):
            return 'OrderedSuperDict(%s)' % OrderedDict.__repr__(self)

    test_json_input = '{"foo": "bar", "fizz": "buzz"}'
    assert json.loads(test_json_input) == load_json_preserve_order(test_json_input)
    assert json.loads(test_json_input) == json.loads(test_json_input)

    test_json_input = '{"foo": "bar", "fizz": {"nested-dict": {"foo": "bar"}}}'
    assert json.loads(test_json_input) == load_json_preserve_order(test_json_input)

    test_json_input

# Generated at 2022-06-21 14:58:46.652384
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"z": 1, "y": 2, "x": 3}'
    d = load_json_preserve_order(s)
    expected = OrderedDict( (('z', 1), ('y', 2), ('x', 3)) )
    assert d == expected

# Generated at 2022-06-21 14:58:48.070193
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    e = ExplicitNullAuth()
    e.__call__(None)

# Generated at 2022-06-21 14:58:58.360955
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if not (
        humanize_bytes(1) == '1 B' and
        humanize_bytes(1024, precision=1) == '1.0 kB' and
        humanize_bytes(1024 * 123, precision=1) == '123.0 kB' and
        humanize_bytes(1024 * 12342, precision=1) == '12.1 MB' and
        humanize_bytes(1024 * 12342, precision=2) == '12.05 MB' and
        humanize_bytes(1024 * 1234, precision=2) == '1.21 MB' and
        humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB' and
        humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    ):
        raise Assertion

# Generated at 2022-06-21 14:59:09.213798
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    """
    Test parsing of Set-Cookie headers, maximum age and expires.
    """

    def parse_cookies(
        headers: List[Tuple[str, str]],
        now: float = None
    ) -> List[dict]:

        cookies = get_expired_cookies(headers=headers, now=now)
        return [
            {
                'name': cookie['name'],
                'path': cookie.get('path', '/')
            }
            for cookie in cookies
        ]


# Generated at 2022-06-21 14:59:11.309517
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    session = requests.session()
    session.auth = ExplicitNullAuth()


# Generated at 2022-06-21 14:59:18.008644
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1)) == "{'a': 1}"
    assert repr_dict(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert repr_dict(OrderedDict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert repr_dict(OrderedDict(b=2, a=1)) == "{'b': 2, 'a': 1}"

# Generated at 2022-06-21 14:59:21.651273
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Test that __call__() of class ExplicitNullAuth is implemented
    correctly.

    """
    class Mock(object):
        """Mock class with a ``prepare_auth`` attribute."""

    mock = Mock()
    auth = ExplicitNullAuth()
    auth(mock)
    assert mock.prepare_auth is None

# Generated at 2022-06-21 14:59:22.176570
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 14:59:31.016842
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 12342) == '12.05 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 1234) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'

# Generated at 2022-06-21 14:59:40.144656
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 12342) == '12.05 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 1234, precision=1) == '1.2 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert human

# Generated at 2022-06-21 14:59:43.641188
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    >>> test_load_json_preserve_order()
    """
    test_str = r'{"b":2,"a":1}'
    assert load_json_preserve_order(test_str) == {'b': 2, 'a': 1}

# Generated at 2022-06-21 14:59:52.087443
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 0.
    headers = [
        (
            'Set-Cookie',
            'session_id=12345; Path=/; Max-Age=3600; Secure; HttpOnly; SameSite=Lax'
        ),
        (
            'Set-Cookie',
            'user_id=john; Path=/; Expires=Fri, 12 May 2017 18:42:23 GMT; Secure; HttpOnly'
        )
    ]

    expected = [
        # We do not care about exact expiration time, just about its presence.
        {'name': 'user_id', 'path': '/'}
    ]
    cookies = get_expired_cookies(headers, now)
    assert cookies == expected

# Generated at 2022-06-21 15:00:02.099720
# Unit test for function get_expired_cookies

# Generated at 2022-06-21 15:00:11.828666
# Unit test for function humanize_bytes
def test_humanize_bytes():
    from pytest import approx

    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    assert humanize_

# Generated at 2022-06-21 15:00:17.036931
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    data = {u'key1': 1, u'key2': 2, u'key3': 3}
    assert load_json_preserve_order(json.dumps(data)) == data

    data = OrderedDict((
        ('key1', 1),
        ('key2', 2),
        ('key3', 3)
    ))
    assert load_json_preserve_order(json.dumps(data)) == data

# Generated at 2022-06-21 15:00:20.803896
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 15:00:24.841022
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.p16a') is None
    assert get_content_type('foo.rar') is None

# Generated at 2022-06-21 15:00:27.424025
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.jpg') == 'image/jpeg'
    assert get_content_type('filename.html') == 'text/html'
    assert get_content_type('filename.txt') == 'text/plain'

# Generated at 2022-06-21 15:00:32.785211
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 15:00:33.587226
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()({})

# Generated at 2022-06-21 15:00:36.332221
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    in_ = '[{"a": 1}, {"b": 2}]'
    assert load_json_preserve_order(in_) == [
        OrderedDict([('a', 1)]),
        OrderedDict([('b', 2)])
    ]

# Generated at 2022-06-21 15:00:41.512451
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    d = load_json_preserve_order(
        '{"a": 1, "b": 2, "c": 3}',
    )
    assert d == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-21 15:00:48.915308
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # noinspection SpellCheckingInspection
    test_values = (
        (0, '0 B'),
        (1, '1 B'),
        (1023, '1023 B'),
        (1024, '1.0 kB'),
        (10 * 1024, '10.0 kB'),
        (12.34 * 1024, '12.3 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
        (1024**2, '1.0 MB'),
        (1024**3, '1.0 GB'),
        (1024**4, '1.0 TB'),
    )

# Generated at 2022-06-21 15:00:58.891593
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise RuntimeError('1 B != {}'.format(humanize_bytes(1)))
    if humanize_bytes(1024, precision=1) != '1.0 kB':
        raise RuntimeError('1.0 kB != {}'.format(humanize_bytes(1024, precision=1)))
    if humanize_bytes(1024 * 123, precision=1) != '123.0 kB':
        raise RuntimeError('123.0 kB != {}'.format(humanize_bytes(1024 * 123, precision=1)))
    if humanize_bytes(1024 * 12342, precision=1) != '12.1 MB':
        raise RuntimeError('12.1 MB != {}'.format(humanize_bytes(1024 * 12342, precision=1)))

# Generated at 2022-06-21 15:01:04.664761
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({1: 'a', 2: 'b'}) == "{1: 'a', 2: 'b'}"
    assert repr_dict({'a': {'b': 1}}) == "{'a': {'b': 1}}"