

# Generated at 2022-06-21 14:55:37.167840
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.jpg") == 'image/jpeg'
    assert get_content_type("test.png") == 'image/png'
    assert get_content_type("test.gif") == 'image/gif'
    assert get_content_type("test.txt") == 'text/plain'

# Generated at 2022-06-21 14:55:42.871619
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar'),
        ('Set-Cookie', 'baz=quux'),
    ]
    now = time.time()
    cookies = get_expired_cookies(headers, now)
    assert len(cookies) == 2
    assert cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]

# vim:sw=4:ts=4:et:

# Generated at 2022-06-21 14:55:51.655248
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict({"foo": 42}) == "{'foo': 42}"
    assert repr_dict({"foo": 42, "bar": [1, 2]}) == "{'foo': 42, 'bar': [1, 2]}"
    assert repr_dict({"foo": 42, "bar": [1, 2], "baz": OrderedDict((("a", 1), ("b", 2)))}) == \
           "{'foo': 42, 'bar': [1, 2], 'baz': OrderedDict([('a', 1), ('b', 2)])}"



# Generated at 2022-06-21 14:55:52.995727
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # pylint: disable=unused-variable
    auth = ExplicitNullAuth()

# Generated at 2022-06-21 14:55:53.921267
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()



# Generated at 2022-06-21 14:56:03.116636
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.md') == 'text/markdown'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.csv') == 'text/csv'
    assert get_content_type('foo.gif') == 'image/gif'

# Generated at 2022-06-21 14:56:12.442334
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 14:56:23.417222
# Unit test for function repr_dict
def test_repr_dict():
    class A(object):
        pass

    a = A()
    a.b = 2
    a.c = {
        "b": 'hahaha'
    }
    d = {
        'a': a,
        (1, 2): 'asdf'
    }

    assert repr_dict(d) == \
        '{\n' \
        '    (1, 2): "asdf",\n' \
        '    "a": {\n' \
        '        "c": {\n' \
        '            "b": "hahaha"\n' \
        '        },\n' \
        '        "b": 2\n' \
        '    }\n' \
        '}'

# Generated at 2022-06-21 14:56:25.078574
# Unit test for function repr_dict
def test_repr_dict():
    data = {"a": 1, "b": 'hello', "c": {"d": 2}}
    assert repr_dict(data) == pformat(data)



# Generated at 2022-06-21 14:56:29.309418
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Unit tests for function get_content_type

# Generated at 2022-06-21 14:56:40.488862
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'



# Generated at 2022-06-21 14:56:52.539776
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('filename.css') == 'text/css'
    assert get_content_type('filename.tar.gz') == 'application/x-tar'
    assert get_content_type('filename.tar.xz') == 'application/x-tbz'
    assert get_content_type('filename.jpeg') == 'image/jpeg'
    assert get_content_type('filename.png') == 'image/png'
    assert get_content_type('filename.yaml') == 'application/x-yaml'
    assert get_content_type('filename.zip') == 'application/zip'
    #assert get_content_type('filename.pdf') == 'application/pdf'

# Generated at 2022-06-21 14:57:03.164610
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 14:57:13.828382
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from nose.tools import (
        assert_equal,
        assert_is_instance,
        assert_is_not_none
    )

    # no cookie
    response_headers = [('foo', 'bar'), ('bar', 'baz')]
    assert_equal(get_expired_cookies(response_headers), [])

    # not expired
    response_headers = [('Set-Cookie', 'foo=bar; Max-Age=3600;')]
    assert_equal(get_expired_cookies(response_headers), [])

    # expired
    response_headers = [('Set-Cookie', 'foo=bar; Max-Age=0;')]
    expired_cookies = get_expired_cookies(response_headers)
    assert_is_instance(expired_cookies, list)

# Generated at 2022-06-21 14:57:16.282023
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': [1, 2, 3], 'b': 'string'}
    assert repr_dict(d) == pformat(d)


# Generated at 2022-06-21 14:57:19.579152
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from .base_test_case import BaseTestCase

    class _Test(BaseTestCase):
        def test(self):
            null_auth = ExplicitNullAuth()
            request = object()
            self.assertEqual(request, null_auth(request))

    _Test().run()


# Generated at 2022-06-21 14:57:27.230163
# Unit test for function get_content_type
def test_get_content_type():
    test_cases = {
        'test_file.txt': 'text/plain',
        'test_file.jpg': 'image/jpeg',
        'test_file.zip': 'application/zip',
        'test_file.js': 'application/javascript',
        'test_file.html': 'text/html',
    }
    for case in test_cases:
        assert get_content_type(case) == test_cases[case]

# Generated at 2022-06-21 14:57:31.279464
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert load_json_preserve_order('{"b": 2, "a": 1}') == {'b': 2, 'a': 1}

# Generated at 2022-06-21 14:57:39.944378
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # source: PEP 446
    example_json = '{"a": 1, "b": 2, "c": {"d": 3, "e": 4}, "f": {"g": 5}, "h": 6, "i": 7, "j": 8}'
    expected_output = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': {'g': 5}, 'h': 6, 'i': 7, 'j': 8}
    output = load_json_preserve_order(example_json)
    assert output == expected_output

# Generated at 2022-06-21 14:57:41.839462
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('file.txt')
    assert not get_content_type('file.UNKNOWN')

# Generated at 2022-06-21 14:57:47.645009
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 1, 'b': '2'}) == "{'a': 1, 'b': '2'}"
    assert repr_dict({'a': 1, 'b': '2'}) == "{'a': 1, 'b': '2'}"

# Generated at 2022-06-21 14:57:58.031142
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    cases = [
        (
            '{"b":5, "a": {"c": [{"d":1, "e":2}, {"e":3, "d":4}]}}',
            '{"b": 5, "a": {"c": [{"d": 1, "e": 2}, {"e": 3, "d": 4}]}}'
        ),
        ('{"a": [3,2,1], "b": 4}', '{"a": [3, 2, 1], "b": 4}'),
        ('{"a": {}, "b": 4}', '{"a": {}, "b": 4}'),
    ]
    for inp, outp in cases:
        assert repr_dict(load_json_preserve_order(inp)) == outp

# Generated at 2022-06-21 14:58:02.537569
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == """{'a': 1, 'b': 2, 'c': 3}"""

# Generated at 2022-06-21 14:58:09.836374
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:58:17.700841
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert '1 B' == humanize_bytes(1)
    assert '1.0 kB' == humanize_bytes(1024, precision=1)
    assert '123.0 kB' == humanize_bytes(1024 * 123, precision=1)
    assert '12.1 MB' == humanize_bytes(1024 * 12342, precision=1)
    assert '12.05 MB' == humanize_bytes(1024 * 12342, precision=2)
    assert '1.21 MB' == humanize_bytes(1024 * 1234, precision=2)
    assert '1.31 GB' == humanize_bytes(1024 * 1234 * 1111, precision=2)
    assert '1.3 GB' == humanize_bytes(1024 * 1234 * 1111, precision=1)

# Generated at 2022-06-21 14:58:28.692122
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 14:58:34.932790
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"c": 3, "b": 2, "a": 1}'
    assert load_json_preserve_order(json_string) == OrderedDict(
        [('c', 3),
         ('b', 2),
         ('a', 1)])


if __name__ == '__main__':
    test_load_json_preserve_order()

# Generated at 2022-06-21 14:58:43.254187
# Unit test for function get_content_type
def test_get_content_type():
    # test with empty string
    assert get_content_type(filename='') is None

    # test with an unrecognized file extension
    assert get_content_type(filename='foobar.xyzzy') is None

    # test with a recognized file extension
    assert (
        get_content_type(filename='foobar.txt')
        == 'text/plain'
    )

    # test with a recognized file extension and known encoding
    # FYI: The `mimetypes` module uses a whitelist of common encodings.
    # See <https://github.com/python/cpython/blob/master/Lib/mimetypes.py#L299>
    assert (
        get_content_type(filename='foobar.json')
        == 'application/json; charset=utf-8'
    )

    # test

# Generated at 2022-06-21 14:58:45.391112
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == '<ExplicitNullAuth>'

# Generated at 2022-06-21 14:58:48.207952
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == OrderedDict([('a', 1), ('b', 2)])

# Generated at 2022-06-21 14:58:59.618492
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def do_test(result, expected, now=None):
        expected = [
            {
                'name': name,
                'path': path,
            }
            for name, path in expected
        ]
        assert result == expected

    now = 1502640000.0  # 2017-08-10T17:00:00 UTC
    now = time.time()


# Generated at 2022-06-21 14:59:07.391174
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "OrderedDict()"
    assert repr_dict({"a": 1}) == "OrderedDict([('a', 1)])"
    assert repr_dict({"a": {"b": {"c": 1}}}) in (
        "OrderedDict([('a', OrderedDict([('b', OrderedDict([('c', 1)]))]))])",
        "OrderedDict([('a', OrderedDict([('b', OrderedDict([('c', 1)])), ('c', 1)]))])",
    )



# Generated at 2022-06-21 14:59:17.283870
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:59:18.779368
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("image.jpg") == "image/jpeg"


# Generated at 2022-06-21 14:59:26.064223
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 14:59:37.576872
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime

    # Example from RFC 6265, section 5.4
    # <https://tools.ietf.org/html/rfc6265#section-5.4>
    cookie = ('Set-Cookie: SID=31d4d96e407aad42; '
              'Path=/; '
              'Domain=example.com; '
              'Expires=Wed, '
              '09-Jun-2021 10:18:14 GMT')
    _, headers = parse_ns_headers(cookie)

    assert len(headers) == 1
    exp_cookie = {'name': 'SID', 'max-age': '', 'path': '/',
                  'domain': 'example.com',
                  'expires': datetime.datetime(2021, 6, 9, 10, 18, 14)}

# Generated at 2022-06-21 14:59:46.046163
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from io import StringIO
    import datetime
    import time

    now = time.time()
    # HttpOnly and Secure attributes are not important for this test

# Generated at 2022-06-21 14:59:47.197487
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth().__call__(None)


# Generated at 2022-06-21 14:59:48.796407
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    null_auth = ExplicitNullAuth()
    assert null_auth is not None
    return

# Generated at 2022-06-21 14:59:59.153895
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# EOF

# Generated at 2022-06-21 15:00:13.351848
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise AssertionError
    if humanize_bytes(1024, precision=1) != '1.0 kB':
        raise AssertionError
    if humanize_bytes(1024 * 123, precision=1) != '123.0 kB':
        raise AssertionError
    if humanize_bytes(1024 * 12342, precision=1) != '12.1 MB':
        raise AssertionError
    if humanize_bytes(1024 * 12342, precision=2) != '12.05 MB':
        raise AssertionError
    if humanize_bytes(1024 * 1234, precision=2) != '1.21 MB':
        raise AssertionError

# Generated at 2022-06-21 15:00:16.026223
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    session = requests.Session()

    req = requests.Request(method='HEAD', url='https://www.github.com')
    assert auth(req) == req



# Generated at 2022-06-21 15:00:22.878549
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == \
        OrderedDict([('a', 1), ('b', 2)])
    assert load_json_preserve_order('{"b": 2, "a": 1}') != \
        OrderedDict([('a', 1), ('b', 2)])
    assert load_json_preserve_order('{"b": 2, "a": 1}') == \
        OrderedDict([('b', 2), ('a', 1)])

# Generated at 2022-06-21 15:00:23.680686
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__


# Generated at 2022-06-21 15:00:28.619283
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    fake_now = 1493093595.546715
    headers = [
        ('Set-Cookie', 'a=b; Path=/; Expires=Tue, 28 Apr 2020 17:35:45 GMT'),
        (
            'Set-Cookie',
            'c=d; Path=/; Max-Age=3600; '
            'Expires=Tue, 28 Apr 2020 18:35:45 GMT'
        ),
        (
            'Set-Cookie',
            'e=f; Path=/; Max-Age=3600; '
            'Expires=Tue, 28 Apr 2020 18:35:45 GMT'
        )
    ]
    expected = [
        {'name': 'a', 'path': '/'},
        {'name': 'e', 'path': '/'}
    ]
    assert get_expired_cook

# Generated at 2022-06-21 15:00:34.333850
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    >>> test_load_json_preserve_order()
    pass
    """
    json_str = """
    {
        "foo": "bar",
        "baz": {
            "a": "b",
            "c": "d"
        }
    }
    """
    first_key = list(load_json_preserve_order(json_str).keys())[0]
    assert first_key == 'foo', "JSON load should have preserved order."

# Generated at 2022-06-21 15:00:36.504783
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '[{"a": 1}, {"b": 1}]'
    assert isinstance(load_json_preserve_order(s), OrderedDict) is True

# Generated at 2022-06-21 15:00:44.903062
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(10) == '10 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1 << 20) == '1.0 MB'
    assert humanize_bytes(1 << 30) == '1.0 GB'
    assert humanize_bytes(1 << 40) == '1.0 TB'
    assert humanize_bytes(1 << 50) == '1.0 PB'

# Generated at 2022-06-21 15:00:48.434198
# Unit test for function repr_dict
def test_repr_dict():
    class Foo:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    f = Foo(1, 2)
    d = {'foo': f}
    assert repr_dict(d) == "{'foo': <fixtures.Foo object at 0x109e8d7f0>}"

# Generated at 2022-06-21 15:00:50.399612
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr_dict(d) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-21 15:01:00.341323
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 'aaa'}) == "{'a': 1, 'b': 2, 'c': 'aaa'}"



# Generated at 2022-06-21 15:01:02.843208
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    url = 'http://www.example.com'
    auth = ExplicitNullAuth()
    auth(requests.Request('GET', url=url).prepare())

# Generated at 2022-06-21 15:01:04.222341
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(None) is None



# Generated at 2022-06-21 15:01:13.126124
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    import time

    def test_fn(expected_cookies, headers):
        expired_cookies = get_expired_cookies(headers)
        assert expected_cookies == expired_cookies

    valid_until = datetime.utcnow() + timedelta(days=10)
    valid_until_ts = time.mktime(valid_until.timetuple())

# Generated at 2022-06-21 15:01:13.958044
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert a is not None

# Generated at 2022-06-21 15:01:23.402851
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from pyfakefs.fake_filesystem import FakeFilesystem
    from requests.cookies import RequestsCookieJar
    from time import time

    filesystem = FakeFilesystem()
    fd = filesystem.open('/etc/netrc', 'w')
    fd.write('machine foo.bar.com\n\tlogin john\n\tpassword doe')
    fd.close()
    filesystem.create_file(
        '/etc/hosts',
        contents='\n'.join([
            '127.0.0.1       localhost',
            '10.0.0.1        ubuntu'
        ])
    )

    cookies = RequestsCookieJar()
    cookies.set('foo', 'bar', path='/', expires=0)

# Generated at 2022-06-21 15:01:23.948885
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None

# Generated at 2022-06-21 15:01:24.787397
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth

# Generated at 2022-06-21 15:01:27.652999
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(r'tests\files\test_file.txt') == 'text/plain'
    assert get_content_type(r'tests\files\test_favicon.ico') == 'image/x-icon'

# Generated at 2022-06-21 15:01:37.916899
# Unit test for function get_content_type
def test_get_content_type():
    for content_type, encoding in (
        ('application/pdf', None),
        ('text/plain', None),
        ('text/plain; charset=utf8', 'utf8'),
        ('text/plain; charset=UTF-8', 'UTF-8'),
    ):
        assert get_content_type(filename='/var/tmp/foo.pdf') == \
            content_type
        assert get_content_type(filename='/var/tmp/foo.txt') == \
            content_type
        assert get_content_type(filename='/var/tmp/foo.txt' +
            '; charset=' + encoding) == content_type

# Generated at 2022-06-21 15:01:48.214565
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    c = ExplicitNullAuth()
    assert c

# Generated at 2022-06-21 15:01:51.810689
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = """{"de": {"berlin": ["fred", "marie", "juergen"], "hamburg": "horst"}}"""
    json_dict = load_json_preserve_order(json_string)
    assert list(json_dict.keys()) == ['de']
    assert list(json_dict['de'].keys()) == ['berlin', 'hamburg']

# Generated at 2022-06-21 15:02:01.312614
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 15:02:06.005254
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """Ensure that ``load_json_preserve_order`` preserve the order."""
    json_string = "{'c': 1, 'a': 2, 'b': 3}"
    expected = OrderedDict([('c', 1), ('a', 2), ('b', 3)])
    result = load_json_preserve_order(json_string)
    assert result == expected


# Generated at 2022-06-21 15:02:09.803992
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
        {"a": 1,
         "z": 26,
         "c": 3}
        """
    j = load_json_preserve_order(s)
    assert 'a' in j
    assert 'z' in j
    assert 'c' in j

    assert len(j.keys()) == 3
    assert j['a'] == 1
    assert j['z'] == 26
    assert j['c'] == 3



# Generated at 2022-06-21 15:02:17.634285
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-21 15:02:25.393109
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest
    from .cgi_wrapper import CGIWrapper

    headers = [('Set-Cookie', 'key=value')]
    expired_cookies = get_expired_cookies(headers, now=0)
    assert not expired_cookies

    headers = [('Set-Cookie', 'key=value; Max-Age=600')]
    expired_cookies = get_expired_cookies(headers, now=300)
    assert not expired_cookies

    headers = [('Set-Cookie', 'key=value; Max-Age=600')]
    expired_cookies = get_expired_cookies(headers, now=3000)
    assert len(expired_cookies) == 1
    assert expired_cookies[0]['path'] == '/'
    assert expired_cookies[0]['name']

# Generated at 2022-06-21 15:02:34.646014
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('missing.ext') is None
    assert get_content_type('it_is_a_txt') == 'text/plain'
    assert get_content_type('it_is_a_txt.txt') == 'text/plain'
    assert get_content_type('it_is_a_txt.txt.') == 'text/plain'
    assert get_content_type('.txt') == 'text/plain'
    assert get_content_type('.') is None

    assert get_content_type('html.doc') == 'text/html'
    assert get_content_type('html.doc.txt') == 'text/html'
    assert get_content_type('html.txt') == 'text/html'
    assert get_content_type

# Generated at 2022-06-21 15:02:35.760899
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

# Generated at 2022-06-21 15:02:46.276794
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from hypothesis import given
    from hypothesis.strategies import dictionaries, just, text

# Generated at 2022-06-21 15:03:11.141995
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookie_string = """login=x%2Cx; path=/; expires=Tue, 01-Jan-2019 00:00:00 GMT; Max-Age=31536000, 
        previous_login=x%2C%2Cx; path=/; expires=Fri, 01-Feb-2019 00:00:00 GMT; Max-Age=2678400, 
        csrftoken=x; path=/; expires=Tue, 01-Jan-2019 00:00:00 GMT; Max-Age=31536000, 
        sessionid=x; path=/; expires=Tue, 01-Jan-2019 00:00:00 GMT; Max-Age=31536000, 
        next=https%3A//moz.com/; path=/; expires=Tue, 01-Jan-2019 00:00:00 GMT; Max-Age=31536000"""

# Generated at 2022-06-21 15:03:17.757756
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-21 15:03:20.122767
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    import requests
    import requests.auth

    if not isinstance(ExplicitNullAuth(), requests.auth.AuthBase):
        raise AssertionError()

# Generated at 2022-06-21 15:03:22.764501
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order(
        '{"foo": "bar", "baz": "qux"}'
    ) == {"foo": "bar", "baz": "qux"}



# Generated at 2022-06-21 15:03:26.656754
# Unit test for function repr_dict
def test_repr_dict():
    test_dict = {'test_key1': 1, 'test_key2': 'test_val2'}
    assert repr_dict(test_dict) == "{'test_key1': 1, 'test_key2': 'test_val2'}"



# Generated at 2022-06-21 15:03:32.428569
# Unit test for function get_content_type
def test_get_content_type():
    # type: () -> None
    assert get_content_type('test.css') == 'text/css'
    assert get_content_type('test.js') == 'application/javascript'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.gif') == 'image/gif'
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.jpg') == 'image/jpeg'

# Generated at 2022-06-21 15:03:37.676419
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.unknown_type') is None

# Generated at 2022-06-21 15:03:41.454556
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"c": 3, "a": 1, "b": 2}'
    assert load_json_preserve_order(json_str) == {u'a': 1, u'b': 2, u'c': 3}

# Generated at 2022-06-21 15:03:49.733850
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('some_text_file.txt')
    assert 'text/plain' == get_content_type('some_text_file.TXT')
    assert 'text/plain; charset=iso-8859-1' == \
        get_content_type('some_text_file.txt', strict=False)
    assert 'application/octet-stream' == get_content_type('some_file.bin')
    assert 'application/octet-stream' == get_content_type('some_file.BIN')
    assert None is get_content_type('some_file.bin', strict=True)
    assert 'text/x-python' == get_content_type('snippet.py')

# Generated at 2022-06-21 15:03:50.702284
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # pylint: disable=protected-access,unused-variable
    ExplicitNullAuth()

# Generated at 2022-06-21 15:04:26.765169
# Unit test for function repr_dict
def test_repr_dict():
    ordered = OrderedDict((
        ('first', 'foo'),
        ('second', 'bar')
    ))
    assert repr_dict(ordered) == '{}'.format(ordered)

# Generated at 2022-06-21 15:04:29.603439
# Unit test for function repr_dict
def test_repr_dict():
  d = {'foo': 'bar', 'baz': 'qux'}
  assert repr_dict(d) == "{'foo': 'bar', 'baz': 'qux'}"

# Generated at 2022-06-21 15:04:34.603352
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # TODO(dwilkie): Set up a mock object to verify that
    # ExplicitNullAuth.__call__() works as intended.
    #
    # Since the method actually returns the input, I think that the
    # simplest way to test it is to create a mock instance of a
    # requests.Request object, pass that mock object to
    # ExplicitNullAuth.__call__(), then verify that the mock object
    # was unchanged by using
    # https://docs.python.org/3.6/library/unittest.mock.html#unittest.mock.Mock.assert_not_called
    pass

# Generated at 2022-06-21 15:04:42.756741
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=b; Expires=Thu, 01 Jan 1970 00:00:00 GMT;'),
        ('Set-Cookie',
         'b=c; Max-Age=1; Expires=Thu, 01 Jan 1970 00:00:01 GMT;'),
        ('Set-Cookie', 'd=e; Max-Age=2;')
    ]
    now = 0
    expected = [
        {'name': 'a', 'path': '/'},
        {'name': 'b', 'path': '/'}
    ]
    actual = get_expired_cookies(headers=headers, now=now)
    assert actual == expected

# Generated at 2022-06-21 15:04:45.183754
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a':1, 'b':2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({}) == "{}"

# Generated at 2022-06-21 15:04:52.529354
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    Unit test function for ``load_json_preserve_order``
    """
    json_str = (
        '{"expected": {"result": "passed"},'
        ' "should": {"fail": false}}'
    )
    json_dict = load_json_preserve_order(json_str)
    assert 'expected' in json_dict
    assert 'should' in json_dict
    assert 'result' in json_dict['expected']
    assert 'fail' in json_dict['should']


if __name__ == '__main__':
    test_load_json_preserve_order()

# Generated at 2022-06-21 15:04:57.016119
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cases = [
        [
            ('Set-Cookie', 'ID=1; expires=Wed, 13 Jan 2021 22:23:01 GMT'),
            ('Set-Cookie', 'ID=2; Max-Age=86400'),
            ('Set-Cookie', 'ID=3'),
        ],
        [
            ('Set-Cookie', 'ID=1; expires=Wed, 13 Jan 2021 22:23:01 GMT'),
            ('Set-Cookie', 'ID=2; Max-Age=86400'),
            ('Set-Cookie', 'ID=3'),
            ('Set-Cookie', 'ID=4; Max-Age=0'),
        ],
    ]
    for case in cases:
        cookies = get_expired_cookies(
            headers=case,
            now=1610595781,
        )

# Generated at 2022-06-21 15:04:57.461932
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-21 15:05:05.998057
# Unit test for function repr_dict
def test_repr_dict():
    print(repr_dict({'a':1}))
    assert repr_dict({'a':1}) == "{'a': 1}"
    assert repr_dict({'a':1, 'b':[1,2,3]}) == "{'a': 1, 'b': [1, 2, 3]}"
    assert repr_dict({'a':1, 'b':{'b1':1, 'b2':2}}) == "{'a': 1, 'b': {'b1': 1, 'b2': 2}}"
    assert repr_dict({'a':1, 'b':{'b1':1, 'b2':{'c':2}}}) == "{'a': 1, 'b': {'b1': 1, 'b2': {'c': 2}}}"


# Generated at 2022-06-21 15:05:07.308403
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert repr(ExplicitNullAuth()) == '<ExplicitNullAuth>'