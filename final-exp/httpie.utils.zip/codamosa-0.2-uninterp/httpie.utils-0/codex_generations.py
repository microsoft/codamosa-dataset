

# Generated at 2022-06-17 21:17:10.930694
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:20.792683
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:31.066153
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tzutc())

# Generated at 2022-06-17 21:17:43.900629
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:17:50.663927
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=10'),
    ]
    now = 1443029280.0
    expired_cookies = get_expired_cookies(headers, now)
    assert expired_cookies == [
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:18:01.965928
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:18:12.886586
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Fri, 31 Dec 9999 23:59:59 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=60'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=60'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=60'),
        ('Set-Cookie', 'waldo=fred; Path=/; Max-Age=60'),
        ('Set-Cookie', 'plugh=xyzzy; Path=/; Max-Age=60'),
        ('Set-Cookie', 'thud=foo; Path=/; Max-Age=60'),
    ]
    now = time.time()
    expired_cookies = get_ex

# Generated at 2022-06-17 21:18:23.522309
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.svgz') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:31.892156
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.doc') == 'application/msword'
    assert get_content_type('foo.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    assert get_content_type('foo.xls') == 'application/vnd.ms-excel'
    assert get_content_type('foo.xlsx') == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'

# Generated at 2022-06-17 21:18:42.590695
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tzutc())

# Generated at 2022-06-17 21:18:52.550660
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=0'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    expected = [
        {'name': 'quux', 'path': '/'},
    ]
    assert get_expired_cookies(headers, now) == expected

# Generated at 2022-06-17 21:19:03.229855
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.now()
    headers = [
        ('Set-Cookie', 'foo=bar; max-age=60; path=/'),
        ('Set-Cookie', 'baz=qux; expires={}; path=/'.format(
            (now + timedelta(seconds=60)).strftime('%a, %d %b %Y %H:%M:%S GMT')
        )),
        ('Set-Cookie', 'quux=corge; expires={}; path=/'.format(
            (now - timedelta(seconds=60)).strftime('%a, %d %b %Y %H:%M:%S GMT')
        )),
    ]
    cookies = get_expired_cookies(headers, now=now.timestamp())

# Generated at 2022-06-17 21:19:12.880660
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Expires=Wed, 13-Jan-2021 22:23:01 GMT;'),
        ('Set-Cookie', 'baz=qux; Max-Age=3600;'),
        ('Set-Cookie', 'quux=corge; Expires=Wed, 13-Jan-2021 22:23:01 GMT;'),
        ('Set-Cookie', 'grault=garply; Max-Age=3600;'),
    ]
    now = 1578937781.0
    expected = [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]
    assert get_expired_cookies(headers, now) == expected

# Generated at 2022-06-17 21:19:18.369697
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.utcnow()

# Generated at 2022-06-17 21:19:26.149416
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=0'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=%s' % (now - 1)),
    ]
    assert get_expired_cookies(headers=headers, now=now) == [
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:37.695602
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=1'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=2'),
        ('Set-Cookie', 'garply=waldo; Path=/; Max-Age=3'),
        ('Set-Cookie', 'fred=plugh; Path=/; Max-Age=4'),
        ('Set-Cookie', 'thud=xyzzy; Path=/; Max-Age=5'),
    ]
    now = time.time()

# Generated at 2022-06-17 21:19:45.549510
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:56.043826
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:20:03.318028
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:20:12.785919
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime
    from dateutil.tz import tzutc

    now = datetime(2020, 1, 1, tzinfo=tzutc()).timestamp()

# Generated at 2022-06-17 21:20:16.955050
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-17 21:20:25.979676
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:20:28.596432
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 1), ('b', 2)])

# Generated at 2022-06-17 21:20:39.922457
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({"a": 1, "b": 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({"a": 1, "b": 2, "c": 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({"a": 1, "b": 2, "c": 3, "d": 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:20:46.753779
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': {'c': 2}}) == "{'a': 1, 'b': {'c': 2}}"
    assert repr_dict({'a': 1, 'b': {'c': {'d': 2}}}) == "{'a': 1, 'b': {'c': {'d': 2}}}"

# Generated at 2022-06-17 21:20:54.269935
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:02.196183
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:21:12.531251
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:21:22.775367
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:21:30.464274
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import HTTPBasicAuth
    from requests.auth import HTTPDigestAuth
    from requests.auth import HTTPProxyAuth
    from requests.auth import AuthBase

    auth = ExplicitNullAuth()
    assert isinstance(auth, AuthBase)

    assert auth(HTTPBasicAuth('user', 'pass')) is None
    assert auth(HTTPDigestAuth('user', 'pass')) is None
    assert auth(HTTPProxyAuth('user', 'pass')) is None