

# Generated at 2022-06-17 21:17:18.795239
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:28.969685
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_

# Generated at 2022-06-17 21:17:34.858641
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:17:46.884006
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:57.556668
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.svgz') == 'image/svg+xml'
    assert get_content_type('foo.pdf') == 'application/pdf'

# Generated at 2022-06-17 21:18:07.275945
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:17.123101
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'text/plain'
    assert get_content_type('foo.txt.bz2') == 'text/plain'
    assert get_content_type('foo.txt.xz') == 'text/plain'
    assert get_content_type('foo.txt.Z') == 'text/plain'
    assert get_content_type('foo.txt.zip') == 'text/plain'
    assert get_content_type('foo.txt.tar') == 'text/plain'
    assert get_content_type('foo.txt.tar.gz') == 'text/plain'
    assert get_content_type('foo.txt.tar.bz2') == 'text/plain'
    assert get

# Generated at 2022-06-17 21:18:27.126833
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:18:34.361279
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:18:42.042008
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ], now=1445383680) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]

# Generated at 2022-06-17 21:18:51.034665
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'foo', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:02.642962
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from time import mktime

    now = mktime(datetime.now().timetuple())
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

    # Test that

# Generated at 2022-06-17 21:19:12.736332
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:18.284094
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:19:28.322542
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:38.771209
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from time import mktime

    now = mktime(datetime.now().timetuple())
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=3600'),
    ]
    assert get_expired_cookies(headers=headers, now=now) == []

    now = mktime((datetime.now() + timedelta(seconds=3600)).timetuple())

# Generated at 2022-06-17 21:19:46.638470
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from time import mktime

    now = mktime(datetime.utcnow().timetuple())
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=3600'),
        ('Set-Cookie', 'quux=quuz; path=/; max-age=0'),
    ]
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'quux', 'path': '/'}
    ]

    now = mktime((datetime.utcnow() + timedelta(hours=1)).timetuple())

# Generated at 2022-06-17 21:19:56.909674
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:20:07.865209
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=60'),
        ('Set-Cookie', 'quux=corge; path=/; max-age=0'),
    ]
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'quux', 'path': '/'}
    ]
    assert get_expired_cookies(headers, now=now + 61) == [
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'}
    ]

# Generated at 2022-06-17 21:20:18.071357
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:20:27.733543
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie
    from time import mktime

    def get_expired_cookies_test(
        cookie_str: str,
        now: datetime = None,
        expected: List[dict] = None
    ) -> None:
        now = now or datetime.utcnow()
        headers = [
            ('Set-Cookie', cookie_str)
        ]
        actual = get_expired_cookies(headers=headers, now=mktime(now.timetuple()))
        assert actual == expected

    # Test that a cookie with no expiration is not expired
    get_expired_cookies_test(
        cookie_str='foo=bar',
        expected=[]
    )

    # Test that a cookie with an expiration in the future is not

# Generated at 2022-06-17 21:20:39.438256
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=0'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=3600; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))

# Generated at 2022-06-17 21:20:50.053917
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime
    import pytest
    from http.cookies import SimpleCookie

    def _parse_cookie(cookie_str):
        cookie = SimpleCookie()
        cookie.load(cookie_str)
        return cookie

    def _cookie_to_dict(cookie):
        return {
            'name': cookie.key,
            'value': cookie.value,
            'path': cookie['path'],
            'expires': cookie['expires'],
            'max-age': cookie['max-age'],
        }

    def _cookie_to_header(cookie):
        return 'Set-Cookie: %s' % cookie.output(header='')

    def _cookie_to_header_list(cookie):
        return [('Set-Cookie', cookie.output(header=''))]


# Generated at 2022-06-17 21:21:02.362366
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:12.569669
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=0'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=0'),
        ('Set-Cookie', 'waldo=fred; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'plugh=xyzzy; Path=/; Max-Age=0'),
    ]
    now = time.time()

# Generated at 2022-06-17 21:21:20.203113
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=60'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=120'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]

# Generated at 2022-06-17 21:21:27.412981
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:36.399698
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest

    def assert_cookies(
        headers: List[Tuple[str, str]],
        expected: List[dict],
        now: float = None
    ):
        assert get_expired_cookies(headers, now=now) == expected


# Generated at 2022-06-17 21:21:41.546038
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'bar=baz; path=/; max-age=3600'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=0'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now)
    assert expired_cookies == [
        {'name': 'baz', 'path': '/'},
    ]

# Generated at 2022-06-17 21:21:46.203389
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=60'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=60; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))

# Generated at 2022-06-17 21:22:02.332079
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:22:09.560538
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'

# Generated at 2022-06-17 21:22:11.630731
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-17 21:22:22.848014
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:22:29.234094
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:22:30.168475
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-17 21:22:33.082024
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    assert load_json_preserve_order(s) == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-17 21:22:35.227938
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import AuthBase
    assert issubclass(ExplicitNullAuth, AuthBase)
    assert ExplicitNullAuth().__call__(None) is None

# Generated at 2022-06-17 21:22:40.287013
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"a": 1, "b": 2, "c": 3}'
    assert load_json_preserve_order(json_str) == {'a': 1, 'b': 2, 'c': 3}
    assert load_json_preserve_order(json_str) != {'c': 3, 'b': 2, 'a': 1}

# Generated at 2022-06-17 21:22:49.077923
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    >>> from requests.auth import HTTPBasicAuth
    >>> from requests.models import Request
    >>> req = Request(
    ...     method='GET',
    ...     url='http://example.com',
    ...     auth=HTTPBasicAuth('user', 'pass'),
    ... )
    >>> req.headers['Authorization']
    'Basic dXNlcjpwYXNz'
    >>> req = Request(
    ...     method='GET',
    ...     url='http://example.com',
    ...     auth=ExplicitNullAuth(),
    ... )
    >>> req.headers.get('Authorization') is None
    True

    """
    pass

# Generated at 2022-06-17 21:23:32.743455
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth(None) is None

# Generated at 2022-06-17 21:23:41.784901
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:23:49.186165
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:24:00.425678
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=3600'),
        ('Set-Cookie', 'quux=corge; path=/; max-age=3600; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = 1445381280.0
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:24:09.331459
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:24:15.730641
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=1'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=1; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))

# Generated at 2022-06-17 21:24:19.770678
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"a": 1, "b": 2, "c": 3}'
    assert load_json_preserve_order(json_string) == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-17 21:24:20.455442
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:24:32.827519
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import HTTPBasicAuth
    from requests.models import Request
    from requests.structures import CaseInsensitiveDict

    auth = ExplicitNullAuth()
    request = Request(
        method='GET',
        url='http://example.com',
        headers=CaseInsensitiveDict({'Authorization': 'Basic dXNlcjpwYXNzd29yZA=='})
    )
    request = auth(request)
    assert request.headers['Authorization'] == 'Basic dXNlcjpwYXNzd29yZA=='

    auth = HTTPBasicAuth('user', 'password')

# Generated at 2022-06-17 21:24:44.196845
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'