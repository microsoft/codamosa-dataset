

# Generated at 2022-06-17 21:17:15.469553
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:17:26.057037
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:35.241799
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:47.339793
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from freezegun import freeze_time

    now = datetime.now()

# Generated at 2022-06-17 21:18:00.390880
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.now()

# Generated at 2022-06-17 21:18:10.561933
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Test with a cookie that has expired
    headers = [
        ('Set-Cookie', 'foo=bar; expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; expires=Wed, 13 Jan 2021 22:23:01 GMT'),
    ]
    now = 1605624000  # Wed, 13 Jan 2021 22:00:00 GMT
    assert get_expired_cookies(headers, now) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]

    # Test with a cookie that has not expired

# Generated at 2022-06-17 21:18:20.142696
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.now()

# Generated at 2022-06-17 21:18:29.359230
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:41.671009
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil import tz

    def get_utc_now():
        return datetime.now(tz.tzutc())

    def get_utc_now_plus_seconds(seconds):
        return get_utc_now() + timedelta(seconds=seconds)

    def get_utc_now_plus_minutes(minutes):
        return get_utc_now() + timedelta(minutes=minutes)

    def get_utc_now_plus_hours(hours):
        return get_utc_now() + timedelta(hours=hours)

    def get_utc_now_plus_days(days):
        return get_utc_now() + timedelta(days=days)


# Generated at 2022-06-17 21:18:51.255394
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:03.811567
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:08.929645
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.ico') == 'image/x-icon'

# Generated at 2022-06-17 21:19:15.959347
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_

# Generated at 2022-06-17 21:19:26.328010
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:19:37.821890
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'grault=garply; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT; Max-Age=3600'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    expired_cookies = get_expired_cookies(headers, now)

# Generated at 2022-06-17 21:19:44.929639
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:55.296535
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=0'),
        ('Set-Cookie', 'grault=garply; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = 1445386880.0
    expired = get_expired_cookies(headers, now=now)

# Generated at 2022-06-17 21:20:03.151279
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_

# Generated at 2022-06-17 21:20:12.418967
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.zip') == 'application/zip'

# Generated at 2022-06-17 21:20:17.895185
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:20:30.132955
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:20:40.392460
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:20:50.165365
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:21:02.379058
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:21:12.587456
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:21:23.161929
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:21:29.713730
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_

# Generated at 2022-06-17 21:21:34.787666
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_type('foo.tar.gz') == 'application/x-gzip'
    assert get_content_type('foo.tar.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.tar.xz') == 'application/x-xz'
    assert get_content_type('foo.tar.Z') == 'application/x-compress'
    assert get_

# Generated at 2022-06-17 21:21:42.028859
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:21:49.367554
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_

# Generated at 2022-06-17 21:22:00.494483
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:22:11.026427
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=0'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    assert get_expired_cookies(headers, now) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:22:11.718631
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-17 21:22:22.959471
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:22:29.096613
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:22:34.351827
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.auth import HTTPBasicAuth

    s = Session()
    s.auth = ExplicitNullAuth()
    r = s.get('https://httpbin.org/basic-auth/user/passwd', auth=HTTPBasicAuth('user', 'passwd'))
    assert r.status_code == 401
    assert r.json() == {'authenticated': False, 'user': 'user'}

# Generated at 2022-06-17 21:22:37.844361
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.auth import HTTPBasicAuth

    session = Session()
    session.auth = ExplicitNullAuth()

    # This should not raise an exception
    session.get('https://httpbin.org/basic-auth/user/passwd', auth=HTTPBasicAuth('user', 'passwd'))

# Generated at 2022-06-17 21:22:42.529565
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.auth import HTTPBasicAuth

    session = Session()
    session.auth = ExplicitNullAuth()
    session.auth = HTTPBasicAuth('user', 'pass')
    assert session.auth is not None
    assert session.auth.username == 'user'
    assert session.auth.password == 'pass'

# Generated at 2022-06-17 21:22:53.466892
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:23:01.621549
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.doc') == 'application/msword'
    assert get_content_type('foo.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    assert get_content_type

# Generated at 2022-06-17 21:23:11.189212
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:23:21.196357
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:23:24.495247
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-17 21:23:31.808800
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:23:41.240809
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:23:44.687005
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict)
    assert list(d.keys()) == ['a', 'b', 'c']

# Generated at 2022-06-17 21:23:48.035801
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-17 21:23:49.561867
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()({}) == {}

# Generated at 2022-06-17 21:23:50.980955
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()({}) == {}

# Generated at 2022-06-17 21:24:01.736921
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'