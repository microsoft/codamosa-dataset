

# Generated at 2022-06-17 21:17:20.818666
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=0'),
        ('Set-Cookie', 'garply=waldo; Path=/; Max-Age=60'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))

# Generated at 2022-06-17 21:17:31.064889
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:43.904826
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:17:51.644043
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:18:02.575946
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:18:13.759291
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=0'),
        ('Set-Cookie', 'corge=grault; Path=/; Max-Age=0'),
        ('Set-Cookie', 'garply=waldo; Path=/; Max-Age=0'),
        ('Set-Cookie', 'fred=plugh; Path=/; Max-Age=0'),
        ('Set-Cookie', 'xyzzy=thud; Path=/; Max-Age=0'),
    ]
    now = time.time()


# Generated at 2022-06-17 21:18:23.927059
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_

# Generated at 2022-06-17 21:18:32.193790
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:18:42.887618
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'application/x-gzip'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.txt.xz') == 'application/x-xz'
    assert get_content_type('foo.txt.lzma') == 'application/x-lzma'
    assert get_content_type('foo.txt.Z') == 'application/x-compress'
    assert get_content_type('foo.txt.zip') == 'application/zip'
    assert get_content_type('foo.txt.tar') == 'application/x-tar'

# Generated at 2022-06-17 21:18:52.181320
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'a=b; path=/; expires=Fri, 01 Jan 2100 00:00:00 GMT'),
        ('Set-Cookie', 'c=d; path=/; max-age=3600'),
        ('Set-Cookie', 'e=f; path=/; max-age=0'),
        ('Set-Cookie', 'g=h; path=/; max-age=3600'),
        ('Set-Cookie', 'i=j; path=/; expires=Fri, 01 Jan 1970 00:00:00 GMT'),
    ]
    cookies = get_expired_cookies(headers, now)
    assert len(cookies) == 2
    assert cookies[0]['name'] == 'e'
    assert cookies[0]['path'] == '/'

# Generated at 2022-06-17 21:19:03.421315
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Fri, 01 Jan 2100 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=86400'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=0'),
    ]
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'quux', 'path': '/'},
        {'name': 'grault', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:10.461549
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
    ]
    now = 1443027280.0  # Wed, 21 Oct 2015 07:28:00 GMT
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'foo', 'path': '/'}
    ]

# Generated at 2022-06-17 21:19:20.780500
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:30.166949
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Max-Age=60'),
        ('Set-Cookie', 'baz=qux; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=quuz; Max-Age=120'),
        ('Set-Cookie', 'corge=grault; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    expired_cookies = get_expired_cookies(headers, now)

# Generated at 2022-06-17 21:19:40.184308
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tzutc())

# Generated at 2022-06-17 21:19:47.876182
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    def cookie_header(cookie):
        return 'Set-Cookie: %s' % cookie.output(header='').lstrip()

    def cookie_headers(cookies):
        return [cookie_header(c) for c in cookies]

    def cookie_dict(cookie):
        return {
            'name': cookie.key,
            'path': cookie['path'],
        }

    def cookie_dicts(cookies):
        return [cookie_dict(c) for c in cookies]

    def test(
        cookies: List[SimpleCookie],
        now: float,
        expected: List[dict]
    ):
        headers = cookie_headers(cookies)
        actual = get_expired_cookies(headers, now)

# Generated at 2022-06-17 21:20:01.051621
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:20:10.393187
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Tue, 01 Jan 2030 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=60'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=120'),
        ('Set-Cookie', 'corge=grault; Path=/; Max-Age=180'),
    ]
    now = time.time()
    assert get_expired_cookies(headers, now=now) == []
    assert get_expired_cookies(headers, now=now + 60) == [
        {'name': 'baz', 'path': '/'}
    ]

# Generated at 2022-06-17 21:20:17.471410
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzlocal

    now = datetime.now(tzlocal()).timestamp()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=10'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=10; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers=headers, now=now)
    assert len(expired_cookies) == 1
    assert expired_cookies[0]['name'] == 'baz'
    assert expired_cook

# Generated at 2022-06-17 21:20:26.392526
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.now()

# Generated at 2022-06-17 21:20:35.726612
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'corge=grault; Path=/; Max-Age=3600'),
    ]
    now = 1445386080.0
    expected = [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]
    assert get_expired_cookies(headers, now) == expected

# Generated at 2022-06-17 21:20:43.464403
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie
    from wsgiref.handlers import format_date_time

    now = time.time()
    now_str = format_date_time(now)
    future = now + timedelta(days=1).total_seconds()
    future_str = format_date_time(future)

    def cookie_str(name, value, **kwargs):
        cookie = SimpleCookie()
        cookie[name] = value
        for k, v in kwargs.items():
            cookie[name][k] = v
        return cookie[name].OutputString()

    def cookie_str_expires(name, value, expires):
        return cookie_str(name=name, value=value, expires=expires)


# Generated at 2022-06-17 21:20:52.102020
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie
    from io import StringIO

    now = datetime.utcnow()
    expires = now + timedelta(seconds=10)
    cookie = SimpleCookie()
    cookie['foo'] = 'bar'
    cookie['foo']['expires'] = expires.strftime('%a, %d %b %Y %H:%M:%S GMT')
    cookie['foo']['path'] = '/'
    cookie['foo']['domain'] = 'example.com'
    cookie['foo']['secure'] = True
    cookie['foo']['httponly'] = True
    cookie['foo']['samesite'] = 'strict'
    cookie_str = cookie.output(header='', sep=';').strip()
    headers

# Generated at 2022-06-17 21:21:02.691547
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from time import mktime

    now = mktime(datetime.now().timetuple())
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=0'),
    ]
    expired_cookies = get_expired_cookies(headers, now=now)

# Generated at 2022-06-17 21:21:11.195292
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=3600'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    assert get_expired_cookies(headers, now) == [
        {'name': 'baz', 'path': '/'},
    ]

# Generated at 2022-06-17 21:21:15.822716
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.now()

# Generated at 2022-06-17 21:21:24.996413
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:35.448020
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:42.423891
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:21:49.679260
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from time import mktime

    now = mktime(datetime.utcnow().timetuple())

# Generated at 2022-06-17 21:22:03.147039
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=0'),
        ('Set-Cookie', 'grault=garply; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = 1445365680.0
    expected = [
        {'name': 'quux', 'path': '/'},
        {'name': 'grault', 'path': '/'},
    ]
    assert get_expired_cookies(headers, now) == expected

# Generated at 2022-06-17 21:22:10.099509
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'grault=garply; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT; Max-Age=3600'),
    ]
    now = 1445392880.0  # Wed, 21 Oct 2015 07:28:00 GMT

# Generated at 2022-06-17 21:22:21.262071
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from time import mktime

    now = mktime(datetime.now().timetuple())

# Generated at 2022-06-17 21:22:31.241223
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:22:41.550424
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'bar=baz; path=/; max-age=3600'),
        ('Set-Cookie', 'baz=qux; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = 1445387680.0
    expected = [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]
    assert get_expired_cookies(headers, now) == expected

# Generated at 2022-06-17 21:22:52.812575
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime
    from dateutil.parser import parse as parse_date

    now = datetime.utcnow()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=%s' % (
            parse_date('Sat, 01 Jan 2000 00:00:00 GMT').strftime('%a, %d %b %Y %H:%M:%S GMT')
        )),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=0'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=1'),
    ]
    expired_cookies = get_expired_cookies(headers=headers, now=now.timestamp())

# Generated at 2022-06-17 21:23:03.440982
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:23:09.957610
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Tue, 01 Jan 2030 00:00:00 GMT'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=60'),
    ]
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:23:21.371675
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:23:29.372581
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.now()
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=%s' % (now + timedelta(days=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')),
        ('Set-Cookie', 'bar=baz; path=/; max-age=3600'),
        ('Set-Cookie', 'baz=qux; path=/; expires=%s' % (now - timedelta(days=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')),
        ('Set-Cookie', 'qux=quux; path=/; max-age=0'),
    ]
