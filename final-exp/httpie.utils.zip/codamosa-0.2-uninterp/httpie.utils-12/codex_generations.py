

# Generated at 2022-06-17 21:17:21.286236
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    assert get_expired_cookies(headers, now) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:17:25.568791
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:33.423886
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.svgz') == 'image/svg+xml'

# Generated at 2022-06-17 21:17:45.393005
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:17:57.110328
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:06.969385
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.doc') == 'application/msword'
    assert get_content_type('foo.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    assert get_content_type

# Generated at 2022-06-17 21:18:16.894150
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:26.742221
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.now()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=%s' % (now + timedelta(days=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=3600'),
    ]
    cookies = get_expired_cookies(headers, now=now.timestamp())
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'foo'
    assert cookies[0]['path'] == '/'

    # Test

# Generated at 2022-06-17 21:18:33.990118
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers, now=1605272981.0)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'bar', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]

# Generated at 2022-06-17 21:18:44.355006
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:18:59.973157
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=3600'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))

# Generated at 2022-06-17 21:19:05.122090
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = 1445383680.0
    expected = [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]
    assert get_expired_cookies(headers, now) == expected

# Generated at 2022-06-17 21:19:13.656211
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/'),
        ('Set-Cookie', 'baz=qux; path=/; expires=Sun, 06 Nov 1994 08:49:37 GMT'),
        ('Set-Cookie', 'quux=corge; path=/; max-age=60'),
        ('Set-Cookie', 'grault=garply; path=/; max-age=120'),
    ]
    now = time.mktime(time.strptime('Sun, 06 Nov 1994 08:49:37 GMT', '%a, %d %b %Y %H:%M:%S GMT'))
    expired_cookies = get_expired_cookies(headers, now=now)

# Generated at 2022-06-17 21:19:24.614908
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.now()

# Generated at 2022-06-17 21:19:32.216172
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'bar=baz; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=0'),
        ('Set-Cookie', 'qux=quux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))

# Generated at 2022-06-17 21:19:41.737398
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.now()

# Generated at 2022-06-17 21:19:48.949380
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:59.916180
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=86400'),
        ('Set-Cookie', 'quux=quuz; path=/; max-age=0'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers=headers, now=now)
    assert expired_cookies == [
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:20:09.362408
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:20:16.756115
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:20:21.178309
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import HTTPBasicAuth
    from requests.models import Request

    auth = ExplicitNullAuth()
    request = Request('GET', 'http://example.com/')
    request = auth(request)
    assert request.auth is None

    auth = HTTPBasicAuth('user', 'pass')
    request = Request('GET', 'http://example.com/')
    request = auth(request)
    assert request.auth == auth

# Generated at 2022-06-17 21:20:31.785725
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:20:36.493860
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"

# Generated at 2022-06-17 21:20:43.968126
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_

# Generated at 2022-06-17 21:20:44.557123
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:20:47.797047
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-17 21:20:53.650369
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-17 21:20:59.709481
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import HTTPBasicAuth
    from requests.models import Request

    auth = ExplicitNullAuth()
    req = Request(
        method='GET',
        url='http://example.com/',
        auth=HTTPBasicAuth('user', 'pass')
    )
    req = auth(req)
    assert req.auth is None



# Generated at 2022-06-17 21:21:02.930888
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': {'c': 3, 'd': 4}}) == \
        "{'a': 1, 'b': {'c': 3, 'd': 4}}"

# Generated at 2022-06-17 21:21:08.166218
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    from requests.auth import AuthBase

    class DummyAuth(AuthBase):
        def __call__(self, r):
            return r

    dummy_auth = DummyAuth()
    explicit_null_auth = ExplicitNullAuth()

    r = requests.Request('GET', 'http://example.com')
    r = r.prepare()

    assert r.auth is None
    assert r.headers.get('Authorization') is None

    r.auth = dummy_auth
    r = r.prepare()

    assert r.auth is dummy_auth
    assert r.headers.get('Authorization') is None

    r.auth = explicit_null_auth
    r = r.prepare()

    assert r.auth is explicit_null_auth
    assert r.headers.get('Authorization') is None