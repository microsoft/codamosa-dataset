

# Generated at 2022-06-17 21:17:10.525075
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:20.491027
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_

# Generated at 2022-06-17 21:17:30.921434
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_

# Generated at 2022-06-17 21:17:36.500591
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.now()

# Generated at 2022-06-17 21:17:48.305515
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_

# Generated at 2022-06-17 21:17:59.198530
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from time import mktime

    now = mktime(datetime.now().timetuple())
    headers = [
        ('Set-Cookie', 'foo=bar; expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'baz=qux; max-age=3600'),
        ('Set-Cookie', 'quux=corge; expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'grault=garply; max-age=3600'),
        ('Set-Cookie', 'waldo=fred; expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'plugh=xyzzy; max-age=3600'),
    ]
    expired_cookies = get

# Generated at 2022-06-17 21:18:07.728976
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'application/x-gzip'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.txt.xz') == 'application/x-xz'
    assert get_content_type('foo.txt.lzma') == 'application/x-lzma'
    assert get_content_type('foo.txt.Z') == 'application/x-compress'
    assert get_content_type('foo.txt.zip') == 'application/zip'
    assert get_content_type('foo.txt.tar') == 'application/x-tar'

# Generated at 2022-06-17 21:18:17.451416
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.doc') == 'application/msword'
    assert get_content_type('foo.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    assert get_content_type

# Generated at 2022-06-17 21:18:27.323873
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:18:34.480668
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:45.464247
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=3600'),
        ('Set-Cookie', 'quux=corge; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'grault=garply; path=/; max-age=3600'),
        ('Set-Cookie', 'garply=waldo; path=/; max-age=3600'),
        ('Set-Cookie', 'fred=plugh; path=/; max-age=3600'),
        ('Set-Cookie', 'xyzzy=thud; path=/; max-age=3600'),
    ]

# Generated at 2022-06-17 21:18:53.413829
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:00.154792
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers, now=1577836800)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:05.447469
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=0'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=10'),
    ]
    now = time.time()
    expired = get_expired_cookies(headers=headers, now=now)
    assert expired == [
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:09.999380
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'corge=grault; Path=/; Max-Age=3600; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'baz', 'path': '/'},
        {'name': 'corge', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:16.579690
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=10'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=10; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:28:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    expired_cookies = get_expired_cookies(headers, now)

# Generated at 2022-06-17 21:19:26.564606
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=60'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=0'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'quux', 'path': '/'},
        {'name': 'grault', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:37.856634
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:45.696896
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from pytz import utc

    now = datetime.now(utc)
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=%s' % (now + timedelta(days=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=%s' % (now - timedelta(days=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=86400'),
    ]

# Generated at 2022-06-17 21:19:56.224079
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:20:08.398684
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.utcnow()

# Generated at 2022-06-17 21:20:18.148711
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:20:26.465783
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:20:36.967624
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.auth import HTTPBasicAuth
    from requests.exceptions import HTTPError

    session = Session()
    session.auth = ExplicitNullAuth()

    # The following request should fail with HTTPError 401
    # because the server requires authentication, but we
    # are not providing any.
    try:
        session.get('http://httpbin.org/basic-auth/user/passwd')
    except HTTPError:
        pass
    else:
        assert False, 'HTTPError 401 expected'

    # The following request should succeed because we are
    # providing authentication credentials.
    session.auth = HTTPBasicAuth('user', 'passwd')
    response = session.get('http://httpbin.org/basic-auth/user/passwd')
    assert response.status_code == 200

# Generated at 2022-06-17 21:20:37.516214
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:20:44.334864
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:20:52.608465
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:20:57.640565
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"a": 1, "b": 2, "c": 3}'
    assert load_json_preserve_order(json_str) == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-17 21:21:04.475063
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:21:14.183921
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:25.188931
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:21:30.764673
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    import requests.auth
    import requests_toolbelt.utils.auth

    auth = requests_toolbelt.utils.auth.ExplicitNullAuth()
    assert isinstance(auth, requests.auth.AuthBase)
    assert isinstance(auth, requests_toolbelt.utils.auth.ExplicitNullAuth)



# Generated at 2022-06-17 21:21:39.049730
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"
    assert repr_

# Generated at 2022-06-17 21:21:42.945398
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': {'c': 2}}) == "{'a': 1, 'b': {'c': 2}}"

# Generated at 2022-06-17 21:21:49.913059
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:21:55.583009
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    assert load_json_preserve_order(s) == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-17 21:22:04.200786
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.now()

# Generated at 2022-06-17 21:22:09.552922
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.auth import HTTPBasicAuth

    s = Session()
    s.auth = ExplicitNullAuth()
    assert s.auth.__call__(None) is None

    s = Session()
    s.auth = HTTPBasicAuth('user', 'pass')
    assert s.auth.__call__(None) is not None



# Generated at 2022-06-17 21:22:11.113572
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    auth = ExplicitNullAuth()
    r = requests.Request('GET', 'http://example.com/')
    r = auth(r)
    assert r.headers == {}

# Generated at 2022-06-17 21:22:11.812252
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-17 21:22:16.738703
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:22:17.311017
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:22:26.989222
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:22:27.882096
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-17 21:22:31.746311
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-17 21:22:34.129500
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session

    session = Session()
    session.auth = ExplicitNullAuth()
    session.get('https://httpbin.org/get')

# Generated at 2022-06-17 21:22:37.400859
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    s = Session()
    s.auth = ExplicitNullAuth()
    r = s.get('http://httpbin.org/get')
    assert r.status_code == 200
    assert r.json()['url'] == 'http://httpbin.org/get'

# Generated at 2022-06-17 21:22:45.048273
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:22:57.582903
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_

# Generated at 2022-06-17 21:23:07.766170
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:23:25.328044
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'qux=quux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now)

# Generated at 2022-06-17 21:23:27.034340
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr_dict(d) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-17 21:23:30.572989
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import AuthBase

    class MockAuth(AuthBase):
        def __call__(self, r):
            r.called = True
            return r

    auth = ExplicitNullAuth()
    r = requests.Request('GET', 'http://example.com')
    r.auth = MockAuth()
    r = auth(r)
    assert r.called

# Generated at 2022-06-17 21:23:32.914889
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert load_json_preserve_order('{"b": 2, "a": 1}') == {'b': 2, 'a': 1}

# Generated at 2022-06-17 21:23:42.283592
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_

# Generated at 2022-06-17 21:23:45.561147
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 1), ('b', 2), ('c', 3)])



# Generated at 2022-06-17 21:23:48.313733
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert load_json_preserve_order('{"a": 1, "b": 2}') != {'b': 2, 'a': 1}

# Generated at 2022-06-17 21:23:49.979963
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:24:01.474651
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:24:09.826113
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:24:28.778112
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-17 21:24:40.178103
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:24:48.631285
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:25:01.777985
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:25:03.786456
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-17 21:25:04.450504
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:25:13.308082
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'foo2=bar2; Path=/; Max-Age=0'),
        ('Set-Cookie', 'foo3=bar3; Path=/; Max-Age=1'),
        ('Set-Cookie', 'foo4=bar4; Path=/; Max-Age=1; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers, now)
    assert len(expired_cookies) == 2
    assert expired_cookies[0]['name'] == 'foo2'

# Generated at 2022-06-17 21:25:23.722116
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:25:31.278103
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.pdf') == 'application/pdf'

# Generated at 2022-06-17 21:25:36.890938
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:26:13.559722
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-17 21:26:15.092136
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    >>> ExplicitNullAuth()(None) is None
    True
    """


# Generated at 2022-06-17 21:26:16.881383
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import AuthBase
    assert issubclass(ExplicitNullAuth, AuthBase)
    assert ExplicitNullAuth().__call__(None) is None



# Generated at 2022-06-17 21:26:25.664107
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:26:27.534500
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-17 21:26:28.010881
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:26:33.748511
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:26:44.320867
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:26:44.756584
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:26:54.680766
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=3600'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    expired_cookies = get_expired_cookies(headers, now)