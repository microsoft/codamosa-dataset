

# Generated at 2022-06-17 21:17:21.285771
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    import pytz

    now = datetime.now(tz=pytz.utc)
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=%s' % (now + timedelta(days=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=%s' % (now - timedelta(days=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=3600'),
    ]

# Generated at 2022-06-17 21:17:25.551163
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:35.061086
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:47.165871
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:00.324665
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:18:08.066042
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_

# Generated at 2022-06-17 21:18:17.646166
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_

# Generated at 2022-06-17 21:18:27.361897
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:18:34.100781
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = 1443047280.0
    assert get_expired_cookies(headers, now) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:18:44.452786
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:53.698522
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:03.624365
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:13.238130
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:23.824924
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:31.998678
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:35.274554
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.bin') is None

# Generated at 2022-06-17 21:19:43.596520
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:53.059874
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'grault=garply; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT; Max-Age=3600'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)

# Generated at 2022-06-17 21:19:58.893518
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from time import mktime

    now = mktime(datetime.now().timetuple())

# Generated at 2022-06-17 21:20:08.549871
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.utcnow()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=%s' % (now + timedelta(days=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=%s' % (now - timedelta(days=1)).strftime('%a, %d %b %Y %H:%M:%S GMT')),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=3600'),
    ]

# Generated at 2022-06-17 21:20:17.324575
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:20:26.261387
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie
    from http.cookies import Morsel

    def _get_expired_cookies(
        headers: List[Tuple[str, str]],
        now: float = None
    ) -> List[dict]:
        return get_expired_cookies(headers=headers, now=now)

    def _get_cookie_header(cookie: Morsel) -> str:
        return '%s=%s' % (cookie.key, cookie.coded_value)

    def _get_cookie_headers(cookies: List[Morsel]) -> List[str]:
        return [_get_cookie_header(cookie) for cookie in cookies]


# Generated at 2022-06-17 21:20:36.883783
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:20:44.180035
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:20:52.491512
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:21:02.785743
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:09.225036
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:21:13.294830
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'a=b; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'c=d; Max-Age=60'),
        ('Set-Cookie', 'e=f; Max-Age=60; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'g=h; Max-Age=60; Path=/foo'),
        ('Set-Cookie', 'i=j; Max-Age=60; Path=/foo; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]

# Generated at 2022-06-17 21:21:20.317427
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=1'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=%s' % (now + 1)),
    ]
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:21:26.783130
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:21:37.549624
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Domain=example.com; Path=/'),
        ('Set-Cookie', 'baz=qux; Domain=example.com; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=quuz; Domain=example.com; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers=headers, now=now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:21:46.050146
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:21:54.737820
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:22:03.914564
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'a=b; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'c=d; Max-Age=60'),
        ('Set-Cookie', 'e=f; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'g=h; Max-Age=60'),
    ]
    cookies = get_expired_cookies(headers, now=now)
    assert len(cookies) == 2
    assert cookies[0]['name'] == 'a'
    assert cookies[0]['path'] == '/'
    assert cookies[1]['name'] == 'c'
    assert cookies[1]['path'] == '/'

# Generated at 2022-06-17 21:22:13.056454
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 13 Jan 2021 22:23:01 GMT', '%a, %d %b %Y %H:%M:%S %Z'))

# Generated at 2022-06-17 21:22:23.511512
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:22:34.281119
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=%s' % (now + 10)),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=10'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=%s' % (now - 10)),
        ('Set-Cookie', 'corge=grault; Path=/; Max-Age=10'),
    ]
    expired_cookies = get_expired_cookies(headers, now=now)
    assert len(expired_cookies) == 2
    assert expired_cookies[0]['name'] == 'quux'
    assert expired_cookies[1]['name'] == 'corge'

# Generated at 2022-06-17 21:22:43.198109
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:22:54.366485
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:23:01.895260
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:23:12.533394
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.now()
    now_ts = time.mktime(now.timetuple())

    def make_cookie(
        name: str,
        value: str,
        expires: Optional[datetime] = None,
        path: Optional[str] = None
    ) -> Tuple[str, str]:
        cookie = SimpleCookie()
        cookie[name] = value
        if expires:
            cookie[name]['expires'] = expires.strftime('%a, %d-%b-%Y %H:%M:%S %Z')
        if path:
            cookie[name]['path'] = path
        return 'Set-Cookie', cookie[name].OutputString()


# Generated at 2022-06-17 21:23:22.588455
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'application/x-gzip'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.txt.xz') == 'application/x-xz'
    assert get_content_type('foo.txt.Z') == 'application/x-compress'
    assert get_content_type('foo.txt.zip') == 'application/zip'
    assert get_content_type('foo.txt.tar') == 'application/x-tar'
    assert get_content_type('foo.txt.tar.gz') == 'application/x-tar'

# Generated at 2022-06-17 21:23:31.532780
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=0'),
        ('Set-Cookie', 'corge=grault; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'garply=waldo; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers, now=now)

# Generated at 2022-06-17 21:23:40.972958
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_

# Generated at 2022-06-17 21:23:48.971578
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:24:01.163971
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:24:09.540888
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:24:15.873135
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_

# Generated at 2022-06-17 21:24:23.763043
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:24:34.004773
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'qux=quux; Path=/; Max-Age=3600; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers, now=1445386480)
    assert expired_cookies == [
        {'name': 'bar', 'path': '/'},
        {'name': 'qux', 'path': '/'},
    ]