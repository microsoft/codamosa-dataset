

# Generated at 2022-06-17 21:17:21.304695
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:25.584180
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.zip') == 'application/zip'

# Generated at 2022-06-17 21:17:35.093093
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'application/x-gzip'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.txt.xz') == 'application/x-xz'
    assert get_content_type('foo.txt.lzma') == 'application/x-lzma'
    assert get_content_type('foo.txt.Z') == 'application/x-compress'
    assert get_content_type('foo.txt.zip') == 'application/zip'
    assert get_content_type('foo.txt.tar') == 'application/x-tar'

# Generated at 2022-06-17 21:17:47.210767
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=Tue, 01 Jan 2030 00:00:00 GMT'),
        ('Set-Cookie', 'corge=grault; Path=/; Max-Age=0'),
        ('Set-Cookie', 'garply=waldo; Path=/; Expires=Tue, 01 Jan 1970 00:00:00 GMT'),
    ]
    expired_cookies = get_expired_cookies(headers, now=now)

# Generated at 2022-06-17 21:18:00.369643
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:18:08.087816
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:18:17.710854
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.svgz') == 'image/svg+xml'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.zip') == 'application/zip'

# Generated at 2022-06-17 21:18:27.405473
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:18:34.523309
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:44.660542
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:18:58.592618
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=60'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now)
    assert expired_cookies == [
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:05.446671
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:12.357073
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=10'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=10; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = 1445383680.0
    expected = [
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
        {'name': 'grault', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:22.682522
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:31.273318
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tzutc()).timestamp()

# Generated at 2022-06-17 21:19:41.084303
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Tue, 01 Jan 2030 00:00:00 GMT'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=Tue, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'qux=quux; Path=/; Max-Age=0'),
    ]
    cookies = get_expired_cookies(headers=headers, now=now)
    assert len(cookies) == 2
    assert cookies[0]['name'] == 'bar'
    assert cookies[0]['path'] == '/'
    assert cookies[1]['name'] == 'qux'

# Generated at 2022-06-17 21:19:48.533003
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=1'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=0'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))

# Generated at 2022-06-17 21:20:01.241282
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:20:10.639714
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:20:17.618983
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/'),
        ('Set-Cookie', 'baz=qux; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; path=/; max-age=60'),
        ('Set-Cookie', 'grault=garply; path=/; max-age=60; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    expired_cookies = get_expired_cookies(headers, now)
    assert len(expired_cookies) == 2


# Generated at 2022-06-17 21:20:29.983978
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=0'),
        ('Set-Cookie', 'corge=grault; Path=/; Max-Age=1'),
    ]
    assert get_expired_cookies(headers=headers, now=now) == [
        {'name': 'quux', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]

# Generated at 2022-06-17 21:20:39.988301
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=3600'),
        ('Set-Cookie', 'quux=quuz; path=/; max-age=0'),
        ('Set-Cookie', 'corge=grault; path=/; max-age=3600'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers=headers, now=now)
    assert expired_cookies == [
        {'name': 'quux', 'path': '/'},
        {'name': 'corge', 'path': '/'},
    ]

# Generated at 2022-06-17 21:20:50.129514
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=3600'),
        ('Set-Cookie', 'quux=corge; path=/; max-age=3600'),
        ('Set-Cookie', 'grault=garply; path=/; max-age=3600'),
        ('Set-Cookie', 'waldo=fred; path=/; max-age=3600'),
        ('Set-Cookie', 'plugh=xyzzy; path=/; max-age=3600'),
        ('Set-Cookie', 'thud=foo; path=/; max-age=3600'),
    ]
    cookies = get_

# Generated at 2022-06-17 21:21:02.350657
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:21:11.420596
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import unittest

    class TestGetExpiredCookies(unittest.TestCase):
        def test_get_expired_cookies(self):
            headers = [
                ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
                ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
            ]
            now = 1445383680.0
            self.assertEqual(
                get_expired_cookies(headers=headers, now=now),
                [
                    {'name': 'foo', 'path': '/'},
                ]
            )

    unittest.main()

# Generated at 2022-06-17 21:21:16.012443
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:25.169340
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:21:35.606355
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:42.527047
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.now()

    def _get_expired_cookies(
        headers: List[Tuple[str, str]],
        now: float = None
    ) -> List[dict]:
        return get_expired_cookies(
            headers=headers,
            now=now.timestamp()
        )

    assert _get_expired_cookies([]) == []

    assert _get_expired_cookies([
        ('Set-Cookie', 'foo=bar; Path=/'),
    ]) == []


# Generated at 2022-06-17 21:21:49.783692
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tzutc())

# Generated at 2022-06-17 21:22:02.675346
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers=headers, now=now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:22:09.958260
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'qux=quux; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now)

# Generated at 2022-06-17 21:22:21.017635
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.now()
    expired_cookie = SimpleCookie()
    expired_cookie['foo'] = 'bar'
    expired_cookie['foo']['expires'] = now - timedelta(days=1)
    expired_cookie['foo']['path'] = '/'
    expired_cookie['foo']['domain'] = 'example.com'

    not_expired_cookie = SimpleCookie()
    not_expired_cookie['foo'] = 'bar'
    not_expired_cookie['foo']['expires'] = now + timedelta(days=1)
    not_expired_cookie['foo']['path'] = '/'

# Generated at 2022-06-17 21:22:30.955595
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'qux=quux; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
    ]
    now = time.time()
    cookies = get_expired_cookies(headers, now=now)
    assert len(cookies) == 4
    assert cookies[0]['name'] == 'foo'
    assert cookies[0]['path'] == '/'

# Generated at 2022-06-17 21:22:38.492612
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=0'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=3600; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    expected = [
        {'name': 'quux', 'path': '/'},
        {'name': 'foo', 'path': '/'},
    ]
    assert get_expired_cookies(headers, now=now) == expected

# Generated at 2022-06-17 21:22:46.588683
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
    ]
    now = 1445378880.0  # Wed, 21 Oct 2015 07:28:00 GMT
    assert get_expired_cookies(headers, now) == [
        {'name': 'foo', 'path': '/'},
    ]

# Generated at 2022-06-17 21:22:59.613273
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:23:09.014160
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie
    from io import StringIO

    now = datetime.now()
    expired_cookies = [
        'foo=bar; Path=/; Expires=%s' % (now - timedelta(days=1)).strftime(
            '%a, %d %b %Y %H:%M:%S GMT'
        ),
        'baz=qux; Path=/; Max-Age=0'
    ]
    expired_cookies_headers = [
        ('Set-Cookie', cookie)
        for cookie in expired_cookies
    ]

# Generated at 2022-06-17 21:23:20.369225
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=0'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)
    assert len(expired_cookies) == 2
    assert expired_cookies[0] == {'name': 'quux', 'path': '/'}
    assert expired_cookies[1]['name'] == 'baz'
    assert expired_cookies[1]['path'] == '/'

# Generated at 2022-06-17 21:23:28.001457
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=60'),
        ('Set-Cookie', 'corge=grault; Path=/; Max-Age=120'),
    ]
    expired_cookies = get_expired_cookies(headers, now=now)
    assert len(expired_cookies) == 1
    assert expired_cookies[0]['name'] == 'baz'
    assert expired_cookies[0]['path'] == '/'