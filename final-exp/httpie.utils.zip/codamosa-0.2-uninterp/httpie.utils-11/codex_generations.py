

# Generated at 2022-06-17 21:17:07.249562
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
    ]
    now = 1445381280.0
    expired_cookies = get_expired_cookies(headers, now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]

# Generated at 2022-06-17 21:17:12.867849
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:21.264334
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.utcnow()

# Generated at 2022-06-17 21:17:25.549710
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_

# Generated at 2022-06-17 21:17:33.395838
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:38.358552
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:17:48.669582
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:17:59.737565
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:18:09.692587
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:18:18.075752
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.now()

# Generated at 2022-06-17 21:18:24.152177
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:18:34.538071
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:18:43.036820
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Tue, 01 Jan 2030 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=Tue, 01 Jan 1970 00:00:00 GMT'),
    ]
    cookies = get_expired_cookies(headers, now=now)
    assert cookies == [{'name': 'quux', 'path': '/'}]

# Generated at 2022-06-17 21:18:52.344158
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=60'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=120'),
    ]
    assert get_expired_cookies(headers, now=now) == []
    assert get_expired_cookies(headers, now=now + 60) == [
        {'name': 'foo', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:03.143692
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:19:12.880854
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
    ]
    now = time.time()
    cookies = get_expired_cookies(headers, now=now)
    assert cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:19:23.350641
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:31.684660
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from pytz import utc

    now = datetime.now(utc)

# Generated at 2022-06-17 21:19:41.381559
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_

# Generated at 2022-06-17 21:19:48.724647
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:58.599510
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:20:08.511595
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from http.cookies import SimpleCookie

    now = datetime.utcnow()

# Generated at 2022-06-17 21:20:16.015763
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:20:25.112608
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:20:32.699678
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = 1445363680.0
    assert get_expired_cookies(headers, now) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:20:41.586172
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=1'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=1; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    expired_cookies = get_expired_cookies(headers, now=now)

# Generated at 2022-06-17 21:20:50.716545
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:21:02.513285
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:21:12.569625
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:21:23.123572
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:21:35.914320
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tzutc())

# Generated at 2022-06-17 21:21:43.530291
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Tue, 01 Jan 2030 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=86400'),
        ('Set-Cookie', 'quux=quuz; Path=/; Expires=Tue, 01 Jan 1970 00:00:00 GMT'),
    ]
    cookies = get_expired_cookies(headers, now=0)
    assert cookies == [
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:21:50.595053
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:22:02.656666
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.doc') == 'application/msword'
    assert get_content_type('foo.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    assert get_content_type

# Generated at 2022-06-17 21:22:09.957948
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:22:21.016927
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=3600; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'corge=grault; Path=/; Max-Age=3600; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)

# Generated at 2022-06-17 21:22:27.971666
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:22:37.102739
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:22:45.027642
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:22:55.327706
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:23:08.252912
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_

# Generated at 2022-06-17 21:23:20.051133
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:23:28.338296
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_

# Generated at 2022-06-17 21:23:38.453856
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_

# Generated at 2022-06-17 21:23:46.854978
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'application/x-gzip'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.txt.xz') == 'application/x-xz'
    assert get_content_type('foo.txt.lzma') == 'application/x-lzma'
    assert get_content_type('foo.txt.Z') == 'application/x-compress'
    assert get_content_type('foo.txt.zip') == 'application/zip'
    assert get_content_type('foo.txt.tar') == 'application/x-tar'

# Generated at 2022-06-17 21:24:00.249687
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:24:09.278720
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:24:20.839519
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:24:32.874652
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_type('foo.gz') == 'application/gzip'
    assert get_content_type('foo.bz2') == 'application/x-bzip2'

# Generated at 2022-06-17 21:24:44.232336
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'

# Generated at 2022-06-17 21:24:53.248286
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:25:03.167681
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}"

# Generated at 2022-06-17 21:25:04.030028
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-17 21:25:05.673537
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-17 21:25:10.401212
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    s = Session()
    s.auth = ExplicitNullAuth()
    r = s.get('https://httpbin.org/get')
    assert r.status_code == 200
    assert r.json()['url'] == 'https://httpbin.org/get'

# Generated at 2022-06-17 21:25:15.154168
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 1), ('b', 2)])
    assert repr(d) == "OrderedDict([('a', 1), ('b', 2)])"

# Generated at 2022-06-17 21:25:17.891781
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 1), ('b', 2)])

# Generated at 2022-06-17 21:25:26.406672
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.css') == 'text/css'
    assert get_content_type('test.js') == 'application/javascript'
    assert get_content_type('test.json') == 'application/json'
    assert get_content_type('test.xml') == 'application/xml'
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.jpeg') == 'image/jpeg'
    assert get_content_

# Generated at 2022-06-17 21:25:33.254321
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-17 21:25:42.290753
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'bar=baz; path=/; max-age=0'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=1'),
        ('Set-Cookie', 'qux=quux; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'quux=quuz; path=/; max-age=0'),
    ]
    now = time.time()
    cookies = get_expired_cookies(headers, now)