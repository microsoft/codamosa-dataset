

# Generated at 2022-06-17 21:17:11.772978
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=3600; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    assert get_expired_cookies(headers, now) == [
        {'name': 'foo', 'path': '/'},
    ]

# Generated at 2022-06-17 21:17:20.844402
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:17:31.064961
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_

# Generated at 2022-06-17 21:17:43.906849
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:17:48.270392
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:17:56.327940
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Max-Age=10'),
    ]
    now = 1445381280.0
    assert get_expired_cookies(headers, now) == [
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:18:06.368199
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.doc') == 'application/msword'
    assert get_content_type('foo.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    assert get_content_type

# Generated at 2022-06-17 21:18:16.495513
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.doc') == 'application/msword'

# Generated at 2022-06-17 21:18:25.725949
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/'),
        ('Set-Cookie', 'baz=qux; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'quux=quuz; path=/; max-age=60'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    assert get_expired_cookies(headers, now) == [
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:18:33.550832
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.doc') == 'application/msword'
    assert get_content

# Generated at 2022-06-17 21:18:39.618118
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_

# Generated at 2022-06-17 21:18:50.035110
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:18:56.094460
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:03.396379
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:19:13.166921
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'application/x-gzip'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.txt.xz') == 'application/x-xz'
    assert get_content_type('foo.txt.lzma') == 'application/x-lzma'
    assert get_content_type('foo.txt.Z') == 'application/x-compress'
    assert get_content_type('foo.txt.zip') == 'application/zip'
    assert get_content_type('foo.txt.tar') == 'application/x-tar'

# Generated at 2022-06-17 21:19:23.733960
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:19:31.946448
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'qux=quux; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
    ]
    now = time.time()
    cookies = get_expired_cookies(headers, now=now)
    assert cookies

# Generated at 2022-06-17 21:19:41.571787
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'application/x-gzip'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.txt.xz') == 'application/x-xz'
    assert get_content_type('foo.txt.Z') == 'application/x-compress'
    assert get_content_type('foo.txt.zip') == 'application/zip'
    assert get_content_type('foo.txt.tar') == 'application/x-tar'
    assert get_content_type('foo.txt.tar.gz') == 'application/x-tar'

# Generated at 2022-06-17 21:19:48.835954
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-17 21:20:01.371963
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tzutc())

# Generated at 2022-06-17 21:20:11.815821
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tz=tzutc())
    now_timestamp = now.timestamp()

    def _get_expired_cookies(
        headers: List[Tuple[str, str]],
        now: float = None
    ) -> List[dict]:
        return get_expired_cookies(headers=headers, now=now)

    def _assert_expired_cookies(
        headers: List[Tuple[str, str]],
        expected_cookies: List[dict],
        now: float = None
    ):
        assert _get_expired_cookies(headers=headers, now=now) == expected_cookies


# Generated at 2022-06-17 21:20:17.389353
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Max-Age=3600; Path=/'),
        ('Set-Cookie', 'baz=qux; Expires=Wed, 21 Oct 2015 07:28:00 GMT; Path=/'),
        ('Set-Cookie', 'quux=quuz; Max-Age=0; Path=/'),
        ('Set-Cookie', 'corge=grault; Expires=Wed, 21 Oct 2015 07:28:00 GMT; Path=/'),
        ('Set-Cookie', 'garply=waldo; Max-Age=3600; Path=/'),
    ]
    now = time.time()
    expired = get_expired_cookies(headers, now=now)

# Generated at 2022-06-17 21:20:26.314889
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:20:36.965918
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:20:44.218816
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:20:52.271155
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=0'),
        ('Set-Cookie', 'quux=quuz; Path=/; Max-Age=3600'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]

# Generated at 2022-06-17 21:21:02.742021
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from time import mktime

    now = mktime(datetime.now().timetuple())
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=3600'),
    ]
    cookies = get_expired_cookies(headers, now=now)
    assert len(cookies) == 2
    assert cookies[0]['name'] == 'foo'
   

# Generated at 2022-06-17 21:21:10.575926
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 07:27:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    assert get_expired_cookies(headers, now) == [{'name': 'foo', 'path': '/'}]

# Generated at 2022-06-17 21:21:19.864624
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=3600'),
        ('Set-Cookie', 'quux=corge; path=/; max-age=3600; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 21 Oct 2015 06:28:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    expired_cookies = get_expired_cookies(headers, now)

# Generated at 2022-06-17 21:21:24.466605
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=3600'),
    ]
    now = 1445382880.0
    assert get_expired_cookies(headers, now) == [
        {'name': 'foo', 'path': '/'}
    ]

# Generated at 2022-06-17 21:21:35.615962
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:21:42.551622
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'quux=corge; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'grault=garply; Path=/; Max-Age=3600'),
    ]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)
    assert expired_cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:21:47.711509
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=3600'),
        ('Set-Cookie', 'quux=quuz; path=/; max-age=0'),
    ]
    assert get_expired_cookies(headers, now=1577836800) == [
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:22:01.415567
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:22:12.155877
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tzutc()).timestamp()
    expires = now + timedelta(days=1).total_seconds()


# Generated at 2022-06-17 21:22:23.405747
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzutc

    now = datetime.now(tzutc()).timestamp()

# Generated at 2022-06-17 21:22:34.130186
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-17 21:22:43.120478
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; path=/; expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; max-age=3600'),
        ('Set-Cookie', 'quux=quuz; path=/; expires=Wed, 01 Jan 2020 00:00:00 GMT'),
    ]
    now = time.mktime(time.strptime('Wed, 01 Jan 2020 00:00:00 GMT', '%a, %d %b %Y %H:%M:%S %Z'))
    assert get_expired_cookies(headers, now) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-17 21:22:54.249530
# Unit test for function get_expired_cookies

# Generated at 2022-06-17 21:23:05.212557
# Unit test for function get_expired_cookies