

# Generated at 2022-06-23 20:11:56.645329
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import HTTPBasicAuth
    a = ExplicitNullAuth()
    r1 = a(r=None)
    r2 = HTTPBasicAuth('user', 'pass')(r=None)
    assert type(r1) is type(r2)

# Generated at 2022-06-23 20:12:01.388727
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'a': 1,
        'b': 'b',
        'c': [1, 2, {
            'd': 4,
            'e': 5
        }]
    }

    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-23 20:12:03.187851
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('wordpress_remote.php') == 'application/octet-stream'
    assert get_content_type('wordpress_remote') is None

# Generated at 2022-06-23 20:12:06.466567
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"s1":1, "s2":2, "s3":3}'

    d = load_json_preserve_order(s)
    assert d['s1'] == 1
    assert d['s2'] == 2
    assert d['s3'] == 3
    assert list(d.keys()) == ['s1', 's2', 's3']


# Generated at 2022-06-23 20:12:07.237718
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:12:15.600669
# Unit test for function humanize_bytes
def test_humanize_bytes():
    print(humanize_bytes(1))
    print(humanize_bytes(1024, precision=1))
    print(humanize_bytes(1024 * 123, precision=1))
    print(humanize_bytes(1024 * 12342, precision=1))
    print(humanize_bytes(1024 * 12342, precision=2))
    print(humanize_bytes(1024 * 1234, precision=2))
    print(humanize_bytes(1024 * 1234 * 1111, precision=2))
    print(humanize_bytes(1024 * 1234 * 1111, precision=1))
    print(humanize_bytes(91234 * 1024, precision=2))


# == run unit tests ==
if __name__ == "__main__":
    test_humanize_bytes()

# Generated at 2022-06-23 20:12:19.195000
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 0, "b": 1, "c": 2}'
    o = load_json_preserve_order(s)
    assert o == OrderedDict([('a', 0), ('b', 1), ('c', 2)])

# Generated at 2022-06-23 20:12:22.428155
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.gz') is None

# Generated at 2022-06-23 20:12:27.355572
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # -- SETUP
    # Testee
    t = ExplicitNullAuth()
    # Test request
    r = requests.Request('GET', 'http://example.com/foo')
    # Modify the request
    r = t(r)
    # Expected value
    expected = r
    # -- EXEC
    # Observed value
    observed = r
    # -- ASSERT
    assert observed == expected
    return



# Generated at 2022-06-23 20:12:34.155379
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('myfile.txt') == 'text/plain'
    assert get_content_type('myfile.html') == 'text/html'
    assert get_content_type('myfile.css') == 'text/css'
    assert get_content_type('myfile.js') == 'application/javascript'
    assert get_content_type('myfile.jpg') == 'image/jpeg'
    assert get_content_type('myfile.png') == 'image/png'
    assert get_content_type('myfile.gif') == 'image/gif'

    assert get_content_type('myfile.bin') is None
    assert get_content_type('myfile.exe') is None
    assert get_content_type('myfile.so') is None

# Generated at 2022-06-23 20:12:41.981674
# Unit test for function humanize_bytes
def test_humanize_bytes():
    print('test_humanize_bytes: ', end='')

    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-23 20:12:48.022667
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.png') == 'image/png'
    # Return None for unkown type
    assert get_content_type('foo.qtx') is None



# Generated at 2022-06-23 20:12:55.789905
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:12:58.978250
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    d = load_json_preserve_order('{"c": 3, "b": 2, "a": 1}')
    assert d == OrderedDict([('c', 3), ('b', 2), ('a', 1)])

# Generated at 2022-06-23 20:13:01.376942
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:13:07.168381
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'

# Generated at 2022-06-23 20:13:09.990582
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("/tmp/foo.txt") == "text/plain"
    assert get_content_type("/tmp/foo.bin") is None

# Generated at 2022-06-23 20:13:11.533253
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth.__class__.__name__ == 'ExplicitNullAuth'



# Generated at 2022-06-23 20:13:14.343292
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b', 'c': [1, 2, 3]}) == "{'a': 'b', 'c': [1, 2, 3]}"



# Generated at 2022-06-23 20:13:19.954666
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # basic test
    assert load_json_preserve_order('{"a": 1, "b": 2}') == {"a": 1, "b": 2}

    # order is preserved
    assert load_json_preserve_order('{"a": 1, "b": 2}') == OrderedDict( (('a', 1), ('b', 2)) )

    # nested dicts are preserved
    assert load_json_preserve_order('{"a": 1, "b": { "x": "hello", "y": "world"}}') == OrderedDict( (('a', 1), ('b', OrderedDict( (('x', "hello"), ('y', "world")) ) ) ) )

# Generated at 2022-06-23 20:13:25.325657
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert list(d.keys()) == ['a', 'b', 'c']

if __name__ == '__main__':
    test_load_json_preserve_order()

# Generated at 2022-06-23 20:13:33.324352
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test = '{"a": 1, "b": 2}'
    result = load_json_preserve_order(test)
    assert result == OrderedDict([('a', 1), ('b', 2)])


if __name__ == '__main__':
    print(humanize_bytes(1))
    print(humanize_bytes(1023))
    print(humanize_bytes(1024))
    print(humanize_bytes(123456789))
    print(humanize_bytes(1000000000000))

    print(humanize_bytes(1, precision=0))
    print(humanize_bytes(1023, precision=0))
    print(humanize_bytes(1024, precision=0))
    print(humanize_bytes(123456789, precision=0))

# Generated at 2022-06-23 20:13:39.598089
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:13:45.675227
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """Unit test for method __call__ of class ExplicitNullAuth."""
    import pytest
    import requests

    # Test with different requests.models.Request objects
    for request in (
        requests.Request(),
        requests.Request(method='get'),
        requests.Request(url='http://localhost'),
        requests.Request(method='get', url='http://localhost'),
    ):

        # Test calls with different requests.models.Request objects
        auth = ExplicitNullAuth()
        result = auth(request)
        assert result is request



# Generated at 2022-06-23 20:13:54.370667
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'session=123; Path=/; Expires=Wed, 31 Oct 2018 20:07:56 GMT; HttpOnly; Secure'),
        ('Set-Cookie', 'SERVERID=toto; Path=/; Expires=Wed, 31 Oct 2018 20:07:56 GMT'),
        ('Set-Cookie', 'SERVERID=toto; Path=/; Expires=Wed, 31 Oct 2018 20:07:56 GMT'),
        ('Set-Cookie', 'ID=123; Path=/; Expires=Wed, 31 Oct 2018 20:07:56 GMT'),
    ]

# Generated at 2022-06-23 20:13:55.866827
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert isinstance(auth, requests.auth.AuthBase)

# Generated at 2022-06-23 20:14:02.764346
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'x': 'y',
        'a': {
            'b': 'c',
            'd': [
                'e',
                'f'
            ],
            'g': {
                'h': 'i'
            }
        }
    }

# Generated at 2022-06-23 20:14:09.560624
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:14:10.313410
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:14:15.933682
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    for s, expected in (
        ('{}', {}),
        ('{"a": 42}', OrderedDict([("a", 42)])),
        ('{"a": 42, "b": 43}', OrderedDict([("a", 42), ("b", 43)])),
    ):
        result = load_json_preserve_order(s)
        assert result == expected



# Generated at 2022-06-23 20:14:28.101699
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from hypothesis import given, settings  # type: ignore
    from hypothesis.strategies import sampled_from  # type: ignore
    from pprint import pprint
    from time import time


# Generated at 2022-06-23 20:14:31.152816
# Unit test for function get_content_type
def test_get_content_type():
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".txt") as f:
        content_type = get_content_type(f.name)
        assert content_type == 'text/plain'

# Generated at 2022-06-23 20:14:40.622667
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:14:44.574499
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': {'c': 3}}) == "{'a': 1, 'b': {'c': 3}}"



# Generated at 2022-06-23 20:14:52.415381
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = """
        {  "key1": "value1",
           "key2": "value2",
           "key3": "value3",
           "key4": "value4",
           "key5": "value5"
        }"""
    assert json.loads(json_string) == {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3",
        "key4": "value4",
        "key5": "value5",
    }

# Generated at 2022-06-23 20:15:00.399713
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:03.555114
# Unit test for function repr_dict
def test_repr_dict():
    d = OrderedDict([("key1", 1), ("key2", 2)])
    assert repr_dict(d) == "{'key1': 1, 'key2': 2}"


# Generated at 2022-06-23 20:15:08.248334
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_json = '{"c": 3, "b": 2, "a": 1}'
    result = load_json_preserve_order(test_json)
    expected_result = OrderedDict([('c', 3), ('b', 2), ('a', 1)])
    assert result == expected_result


# Generated at 2022-06-23 20:15:15.909688
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:19.275594
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:15:28.619220
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import timedelta
    from string import hexdigits

    def format_set_cookie_headers(expired_cookies):
        return [
            'Set-Cookie: %s' % '; '.join(
                f'{name}={value}'
                for name, value in cookie.items()
            )
            for cookie in expired_cookies
        ]

    def get_expired_cookies_samples(expired_cookies):
        def get_expired_cookies(sample):
            now = time.time()
            return [
                cookie['name']
                for cookie in sample['cookies']
                if (
                    cookie.get('max-age') is None
                    and cookie.get('expires') is None
                    or now >= cookie.get('expires')
                )
            ]

       

# Generated at 2022-06-23 20:15:32.576479
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.a.b') is None

# Generated at 2022-06-23 20:15:34.453578
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()

    # This is a no-op
    auth(None)


# Generated at 2022-06-23 20:15:37.889900
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b', 'c': {'d': [1, 2, 3]}}) == "{'a': 'b', 'c': {'d': [1, 2, 3]}}"

# Generated at 2022-06-23 20:15:38.776040
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:15:41.243855
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    class MockRequest: pass
    request = MockRequest()
    auth = ExplicitNullAuth()
    assert auth(request) == request

# Generated at 2022-06-23 20:15:47.686243
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import json

    def set_cookies_header(stale_cookies):
        return [
            ('Set-Cookie', '{name}=deleted; expires=Thu, 01-Jan-1970 '
                           '00:00:01 GMT; Max-Age=0; path={path}; secure'
                           .format(**cookie))
            for cookie in stale_cookies
        ]

    def set_cookies_header_with_domain(stale_cookies):
        return [
            ('Set-Cookie', '{name}=deleted; expires=Thu, 01-Jan-1970 '
                           '00:00:01 GMT; Max-Age=0; path={path}; secure;'
                           ' domain=httpbin.org'
                           .format(**cookie))
            for cookie in stale_cookies
        ]

# Generated at 2022-06-23 20:15:48.812829
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    _ = ExplicitNullAuth()

# Generated at 2022-06-23 20:15:50.727330
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None


# Generated at 2022-06-23 20:16:00.524215
# Unit test for function humanize_bytes

# Generated at 2022-06-23 20:16:06.468358
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-23 20:16:18.793219
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:16:20.002690
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.txt") == 'text/plain'



# Generated at 2022-06-23 20:16:23.533932
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests

    auth = ExplicitNullAuth()
    r = requests.Request(
        method='GET',
        url='http://httpbin.org/response-headers',
        auth=auth
    ).prepare()

    assert r.headers['Authorization'] is None, repr(r.headers)

# Generated at 2022-06-23 20:16:32.680784
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1024) != '1.0 kB':
        print("No")
    if humanize_bytes(1024*123) != '123.0 kB':
        print("No")
    if humanize_bytes(1024*12342) != '12.1 MB':
        print("No")
    if humanize_bytes(1024*12342,2) != '12.05 MB':
        print("No")
    if humanize_bytes(1024*1234,2) != '1.21 MB':
        print("No")
    if humanize_bytes(1024*1234*1111,2) != '1.31 GB':
        print("No")
    if humanize_bytes(1024*1234*1111,1) != '1.3 GB':
        print("No")

# Generated at 2022-06-23 20:16:40.646384
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def case1_factory(now: float) -> List[dict]:
        return get_expired_cookies(headers=[
            ('Set-Cookie', 'a=b; max-age=0'),
            ('Set-Cookie', 'c=d; Expires=Mon, 01-Jul-2029 00:00:00 GMT'),
        ], now=now)

    assert case1_factory(now=1e12) == [{'name': 'a', 'path': '/'}]
    assert case1_factory(now=1e15) == [
        {'name': 'a', 'path': '/'},
        {'name': 'c', 'path': '/'}
    ]


# vim:sw=4:ts=4:et:

# Generated at 2022-06-23 20:16:41.583057
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth



# Generated at 2022-06-23 20:16:48.854713
# Unit test for function get_content_type
def test_get_content_type():
    types = {
        'txt': 'text/plain',
        'text.html': 'text/html',
        'foo.jpeg': 'image/jpeg',
        'image.png': 'image/png',
        'picture.svg': 'image/svg+xml',
        'image.gif': 'image/gif',
        'image.bmp': 'image/bmp',
        'image.jpg': 'image/jpeg',
        'image.tif': 'image/tiff',
    }
    for fname in types:
        mimetype = types[fname]
        assert get_content_type(fname) == mimetype

    assert get_content_type('unknown.unknown') is None
    # assert get_content_type('image.jpeg; charset=UTF-8')

# Generated at 2022-06-23 20:16:55.008587
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    past_time = time.time() - 5
    future_time = time.time() + 5
    not_expired = [
        {
            'name': 'foo1',
            'path': '/',
            'expires': future_time
        }
    ]
    expired_exact = [
        {
            'name': 'foo2',
            'path': '/',
            'expires': past_time
        }
    ]
    expired_max_age = [
        {
            'name': 'foo3',
            'path': '/',
            'expires': past_time,
            'max-age': '5'
        }
    ]

# Generated at 2022-06-23 20:17:05.992509
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:17:13.124028
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:17:13.881841
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth

# Generated at 2022-06-23 20:17:21.384961
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(5) == '5 B'
    assert humanize_bytes(5 + 1) == '6 B'
    assert humanize_bytes(5 * 1024) == '5.0 kB'
    assert humanize_bytes(5 * 1024 + 1 * 1024 * 1024 * 1024 * 1024 * 1024) == '5.0 kB'
    assert humanize_bytes(5 * 1024 + 1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '5.0 PB'

# Generated at 2022-06-23 20:17:24.827558
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': [1]}) == "{'a': [1]}"
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"


# Generated at 2022-06-23 20:17:28.346619
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{"c": 3, "a": 1, "b": 2}"""
    d = load_json_preserve_order(s)
    assert repr(d) == "OrderedDict([('c', 3), ('a', 1), ('b', 2)])"



# Generated at 2022-06-23 20:17:33.298294
# Unit test for function repr_dict
def test_repr_dict():
    """
    >>> expected = "{" + "\n".join([
    ...     "    'a': 1,",
    ...     "    'b': 2,",
    ...     "    'c': 3,",
    ...     "}"
    ... ])
    >>> repr_dict({"a": 1, "b": 2, "c": 3})  # doctest: +NORMALIZE_WHITESPACE
    '{\\n    '
    '\\'
    'a\\'
    "': 1,\\n    'b': 2,\\n    'c': 3,\\n}'
    """
    pass

# Generated at 2022-06-23 20:17:34.351683
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()



# Generated at 2022-06-23 20:17:36.525556
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    result = auth.__call__(None)
    assert result is None

# Generated at 2022-06-23 20:17:38.047708
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth


# Generated at 2022-06-23 20:17:45.971124
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies(
        [
            ('Set-Cookie', 'foo=bar; Expires=Wed, 13-Jan-2021 22:23:01 GMT; Path=/'),
            ('Set-Cookie', 'baz=qux; Max-Age=500; Path=/'),
            ('Set-Cookie', 'quux=quuz;'),
        ],
        now=0
    ) == [
        {'name': 'baz', 'path': '/'},
        {'name': 'quux', 'path': '/'},
    ]

# Generated at 2022-06-23 20:17:48.850971
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(None) is None

# Generated at 2022-06-23 20:17:55.316582
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:17:57.445116
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({0: 'zero', 1: 'one'}) == "{0: 'zero', 1: 'one'}"

# Generated at 2022-06-23 20:17:59.183927
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    response = requests.get('https://httpbin.org/get', auth=a)
    assert response.status_code == 200

# Generated at 2022-06-23 20:18:07.737685
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import base64
    import random
    import string

    # Generate a valid pair of username and password
    def gen_creds() -> Tuple[str, str]:
        return (
            ''.join(
                random.choice(string.ascii_letters)
                for _ in range(random.randint(0, 10))
            ),
            ''.join(
                random.choice(
                    string.ascii_letters + string.digits
                ) for _ in range(random.randint(0, 10))
            )
        )

    # Generate a valid pair of credentials and a hostname

# Generated at 2022-06-23 20:18:08.352960
# Unit test for function repr_dict
def test_repr_dict():
    impor

# Generated at 2022-06-23 20:18:18.488253
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:18:20.696492
# Unit test for function repr_dict
def test_repr_dict():
    assert repr(repr_dict({"a":1,"b":2,"c":3})) == '{\'a\': 1, \'b\': 2, \'c\': 3}'

# Generated at 2022-06-23 20:18:27.206758
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from pprint import pprint


# Generated at 2022-06-23 20:18:32.664378
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()


_TestData = List[Tuple[str, str]]


# Generated at 2022-06-23 20:18:38.983556
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.pdf') == 'application/pdf'

# Generated at 2022-06-23 20:18:39.621049
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:18:40.257407
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:18:43.830338
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([
        ('set-cookie', 'CSRF=XsrfToken; HttpOnly; Path=/'),
        ('set-cookie', 'foo=bar'),
        ('set-cookie', 'expires=Thu, 01-Jan-1970 00:00:01 GMT'),
        ('set-cookie', 'max-age=0; HttpOnly; Path=/'),
        ('set-cookie', 'a=b; Max-Age=1'),
        ('set-cookie', 'a=b; Max-Age=1; Secure'),
    ], now=1000)


# Generated at 2022-06-23 20:18:46.833446
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.html') == 'text/html'

# Generated at 2022-06-23 20:18:50.985365
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"foo": 1 , "bar": 2}'
    assert load_json_preserve_order(json_str) == OrderedDict([
        ("foo", 1), ("bar", 2)
    ])

# Generated at 2022-06-23 20:18:56.192220
# Unit test for function get_content_type
def test_get_content_type():
    """Test get_content_type function"""
    assert get_content_type("/some/path/png/image.png") == "image/png"
    assert get_content_type("image.png") == "image/png"
    assert get_content_type("image") is None


if __name__ == "__main__":
    test_get_content_type()

# Generated at 2022-06-23 20:18:59.801523
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{}') == OrderedDict()
    assert load_json_preserve_order('{"a":42}') == OrderedDict([('a', 42)])
    assert load_json_preserve_order('{"a":42,"b":43}') == OrderedDict([('a', 42), ('b', 43)])
    assert load_json_preserve_order('{"b":43,"a":42}') == OrderedDict([('b', 43), ('a', 42)])

# Generated at 2022-06-23 20:19:01.461857
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'c': 1, 'a': 2, 'b': 3}) == "{'c': 1, 'a': 2, 'b': 3}"

# Generated at 2022-06-23 20:19:07.227209
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/tmp/foo.txt') is None
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.htm') == 'text/html'
    assert get_content_type('foo.gif') == 'image/gif'

# Generated at 2022-06-23 20:19:15.437635
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(2) == "2 B"
    assert humanize_bytes(2 ** 10) == "1.0 kB"
    assert humanize_bytes(2 ** 20) == "1.0 MB"
    assert humanize_bytes(2 ** 30) == "1.0 GB"
    assert humanize_bytes(2 ** 40) == "1.0 TB"
    assert humanize_bytes(2 ** 50) == "1.0 PB"
    assert humanize_bytes(2 ** 60) == "1024.0 PB"
    assert humanize_bytes(2 ** 70) == "1048576.0 PB"
    assert humanize_bytes(2 ** 80) == "1073741824.0 PB"
    assert humanize_bytes(2 ** 90) == "1099511627776.0 PB"
    assert human

# Generated at 2022-06-23 20:19:23.576565
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise AssertionError('humanize_bytes(1) should return "1 B"')
    if humanize_bytes(1024, precision=1) != '1.0 kB':
        raise AssertionError('humanize_bytes(1024, precision=1) should return "1.0 kB"')
    if humanize_bytes(1024 * 123, precision=1) != '123.0 kB':
        raise AssertionError('humanize_bytes(1024 * 123, precision=1) should return "123.0 kB"')
    if humanize_bytes(1024 * 12342, precision=1) != '12.1 MB':
        raise AssertionError('humanize_bytes(1024 * 12342, precision=1) should return "12.1 MB"')
   

# Generated at 2022-06-23 20:19:30.190261
# Unit test for function get_content_type
def test_get_content_type():
    # We have to have a real file to test this.
    from os.path import join, dirname, realpath
    from filecmp import cmp
    from tempfile import gettempdir
    from shutil import copy

    here = dirname(realpath(__file__))
    src_path = join(here, 'test_get_content_type.txt')
    dst_path = join(gettempdir(), 'test_get_content_type.txt')

    copy(src_path, dst_path)  # python2.7 lacks copy2()

    content_type = get_content_type(dst_path)
    assert content_type == 'text/plain'
    assert cmp(src_path, dst_path)

# Generated at 2022-06-23 20:19:30.678131
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:19:40.219337
# Unit test for function humanize_bytes
def test_humanize_bytes():

    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(10) == '10 B'
    assert humanize_bytes(100) == '100 B'
    assert humanize_bytes(1000) == '1000 B'
    assert humanize_bytes(10000) == '9.8 kB'
    assert humanize_bytes(100000) == '97.7 kB'
    assert humanize_bytes(1000000) == '976.6 kB'
    assert humanize_bytes(10000000) == '9.5 MB'
    assert humanize_bytes(100000000) == '95.4 MB'
    assert humanize_bytes(1000000000) == '953.7 MB'

# Generated at 2022-06-23 20:19:51.463694
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:19:55.268149
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests

    url = 'https://api.github.com/users/psf/repos'
    r = requests.get(url, auth=ExplicitNullAuth())
    assert r.status_code == 200
    assert r.json()


# Generated at 2022-06-23 20:19:58.767024
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"a": 1, "b": 2, "c": 3}'
    json_dict = load_json_preserve_order(json_str)
    assert repr_dict(json_dict) == json_str

# Generated at 2022-06-23 20:20:04.330355
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('README.md') == 'text/plain'
    assert get_content_type('requirements.txt') == 'text/plain'
    assert get_content_type('__init__.py') == 'text/x-python'
    assert get_content_type('blah.zip') == 'application/zip'
    assert get_content_type('image.png') == 'image/png'
    assert get_content_type('1.2.3.4') is None

# Generated at 2022-06-23 20:20:07.994932
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('a.txt') == 'text/plain'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.tar.gz') == 'application/x-tar'
    assert get_content_type('a.csv') == 'text/plain'
    assert get_content_type('a.svg') == 'image/svg+xml'

# Generated at 2022-06-23 20:20:16.680161
# Unit test for function humanize_bytes
def test_humanize_bytes():
    pairs = (
        (1, '1 B'),
        (1000, '1000 B'),
        (1024, '1.00 kB'),
        (1024*1024, '1.00 MB'),
        (1024 * 1024 * 1024 * 2, '2.00 GB'),
        (1024 * 1024 * 1024 * 1024 * 2, '2.00 TB'),
        (1024 * 1024 * 1024 * 1024 * 1024 * 2, '2.00 PB'),
    )
    for n, expected in pairs:
        assert humanize_bytes(n) == expected


# Unit tests for function get_content_type()

# Generated at 2022-06-23 20:20:21.790551
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert '1 B' == humanize_bytes(1)
    assert '1.0 kB' == humanize_bytes(1024, precision=1)
    assert '123.0 kB' == humanize_bytes(1024 * 123, precision=1)
    assert '12.1 MB' == humanize_bytes(1024 * 12342, precision=1)
    assert '12.05 MB' == humanize_bytes(1024 * 12342, precision=2)
    assert '1.21 MB' == humanize_bytes(1024 * 1234, precision=2)
    assert '1.31 GB' == humanize_bytes(1024 * 1234 * 1111, precision=2)
    assert '1.3 GB' == humanize_bytes(1024 * 1234 * 1111, precision=1)

# Generated at 2022-06-23 20:20:26.348388
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)  # type: dict
    assert d == {'a': 1, 'b': 2, 'c': 3}
    assert list(d.keys()) == ['a', 'b', 'c']

# Generated at 2022-06-23 20:20:30.816297
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"key": "value", "number": 2, "array": [1, 2, 3]}'
    d = load_json_preserve_order(s)

    assert type(d) == OrderedDict
    assert list(d) == ['key', 'number', 'array']


# Unit tests for humanize_bytes

# Generated at 2022-06-23 20:20:34.210335
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    def _test(auth, expected_auth):
        assert auth.__call__(None) == expected_auth

    auth = ExplicitNullAuth()
    expected_auth = None
    yield _test, auth, expected_auth



# Generated at 2022-06-23 20:20:39.561453
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/example.html') == 'text/html'
    assert get_content_type('/example.gif') == 'image/gif'
    assert get_content_type('/example.py') == 'text/x-python'
    assert get_content_type('/example.dvi') == 'application/x-dvi'
    assert get_content_type('/example.zip') == 'application/zip'

# Generated at 2022-06-23 20:20:44.561607
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.py') == 'text/x-python'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.htm') == 'text/html'
    assert get_content_type('foo.pyc') is None

# Generated at 2022-06-23 20:20:47.433550
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"c": "orange", "a": "green", "b": "yellow"}') == \
           OrderedDict([('c', 'orange'), ('a', 'green'), ('b', 'yellow')])



# Generated at 2022-06-23 20:20:55.003321
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:20:59.302681
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"foo": "bar", "baz": "qux"}') == OrderedDict([('foo', 'bar'), ('baz', 'qux')])


if __name__ == '__main__':
    print(humanize_bytes(123456789))

# Generated at 2022-06-23 20:21:01.339858
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename="test_file.txt") == "text/plain"



# Generated at 2022-06-23 20:21:05.590508
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 'hello'}) == "{'a': 1, 'b': 'hello'}"
    assert repr_dict({'a': 1, 'b': {'c': 2}}) == "{'a': 1, 'b': {'c': 2}}"

# Generated at 2022-06-23 20:21:12.774005
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '''
        {
            "a": 1,
            "b": 2,
            "c": 3,
            "d": 4,
            "e": 5
        }
    '''

    assert load_json_preserve_order(json_str) == {
        "a": 1,
        "b": 2,
        "c": 3,
        "d": 4,
        "e": 5
    }

# Generated at 2022-06-23 20:21:13.855828
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    return auth

# Generated at 2022-06-23 20:21:15.498422
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth.__call__("") is ""

# Generated at 2022-06-23 20:21:23.506764
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
        (1024 * 1234 * 1111, '1.3 GB')
    ]
    for test, expected in tests:
        assert humanize_bytes(test) == expected

# Generated at 2022-06-23 20:21:25.281315
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    try:
        ExplicitNullAuth()
        print(True)
    except:
        print(False)


# Generated at 2022-06-23 20:21:32.659501
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Our dict
    x = {"p1": {"s1": 1, "s2": 2}, "p2": {"s3": 3, "s4": 4}}
    # Dump it
    x_json = json.dumps(x)
    # Load it
    y = json.loads(x_json)
    # Test it
    assert x == y
    # Load it
    z = load_json_preserve_order(x_json)
    # Test it
    assert z == y
    assert list(x.keys()) == list(z.keys())
    assert list(x["p1"].keys()) == list(z["p1"].keys())
    assert list(x["p2"].keys()) == list(z["p2"].keys())


# Generated at 2022-06-23 20:21:38.815786
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import HTTPBasicAuth

    class FakeRequest(object):
        auth = HTTPBasicAuth('foo', 'bar')
        url = 'http://localhost/foo'

    req = FakeRequest()
    auth = ExplicitNullAuth()
    req = auth(req)

    assert req.auth is None
    assert req.url == 'http://localhost/foo'



# Generated at 2022-06-23 20:21:43.153651
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict)
    assert list(d.keys()) == ['a', 'b']
    assert list(d.values()) == [1, 2]

# Generated at 2022-06-23 20:21:51.710070
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def assert_expired_cookies_equal(
        expected: List[dict],
        actual: List[dict],
    ):
        assert sorted(expected, key=lambda x: x['name']) == (
            sorted(actual, key=lambda x: x['name'])
        )

    assert_expired_cookies_equal(
        expected=[
            {
                'name': 'abc',
                'path': '/'
            },
            {
                'name': 'cab',
                'path': '/'
            },
        ],
        actual=get_expired_cookies([
            ('Set-Cookie', 'abc=123; Max-Age=0'),
            ('Set-Cookie', 'cab=xyz; Max-Age=0; Path=/foo/bar'),
        ]),
    )


# Generated at 2022-06-23 20:22:02.045320
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024 * 123) == '123.0 kB'
    assert humanize_bytes(1024 * 12342) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'
    assert humanize_bytes(1, 1) == '1.0 B'