

# Generated at 2022-06-23 20:12:01.754792
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar'),
        ('Set-Cookie', 'fizz=buzz; Path=/; Expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'poo=dar; Path=/; Max-Age=123; Expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'pan=bam; Path=/; Max-Age=123'),  # No "Expires" set, use Max-Age to set "Expires" instead.
    ]
    expected_cookies = [
        {
            'name': 'foo',
            'path': '/'
        },
    ]

# Generated at 2022-06-23 20:12:08.326559
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    '''
    Test Force requests to ignore the ``.netrc``.
    '''
    from requests import Request
    from requests.packages.urllib3.response import HTTPResponse
    from requests.packages.urllib3.util import BytesIO
    from threading import Lock

    url = 'https://www.google.com'
    method = 'GET'
    body = ''
    headers = {
        "Accept-Encoding": "gzip, deflate",
        "Accept": "*/*",
        "User-Agent": "python-requests/2.6.0 CPython/3.6.0",
    }
    files = {}
    auth = ExplicitNullAuth()

    # build request object

# Generated at 2022-06-23 20:12:08.988523
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth

# Generated at 2022-06-23 20:12:09.619058
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:12:12.733334
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.ts') is None

# Generated at 2022-06-23 20:12:13.157429
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:12:17.447165
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.models import Request
    from requests.sessions import Session
    from urllib.parse import urlparse

    session = Session()
    request = Request('GET', 'https://httpbin.org/')
    auth = ExplicitNullAuth()
    response = session.send(request=request, auth=auth)
    url = urlparse(response.url)
    assert url.scheme == 'https'
    assert url.netloc == 'httpbin.org'

# Generated at 2022-06-23 20:12:22.880181
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('set-cookie', (
            'sage_cookie_id=58a36c75; Expires=Thu, 01 Jan 1970 00:00:00 GMT;'
            ' Path=/scratch/home/'
        )),
        ('set-cookie', (
            'sage_login_version=cookie; Path=/scratch/home/'
        )),
    ]

    cookies = get_expired_cookies(headers=headers, now=time.time())
    assert cookies == [
        {'name': 'sage_cookie_id', 'path': '/scratch/home/'}
    ]

# Generated at 2022-06-23 20:12:30.945166
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # <= 1 B
    assert humanize_bytes(1) == '1 B'
    # 1 B < n <= 1024 B
    assert humanize_bytes(10) == '10 B'
    # 1024 B < n <= 1048576 B
    assert humanize_bytes(2048) == '2.00 kB'
    # 1048576 B < n <= 1073741824 B
    assert humanize_bytes(2097152) == '2.00 MB'
    # 1073741824 B < n <= 1099511627776 B
    assert humanize_bytes(2147483648) == '2.00 GB'
    # 1099511627776 B < n <= 1125899906842624 B
    assert humanize_bytes(2199023255552) == '2.00 TB'
    # 11258999068426

# Generated at 2022-06-23 20:12:36.231461
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"a":1, "b":2, "c":3}'
    json = load_json_preserve_order(json_str)
    json_list = list(json.items())
    assert(json_list[0][0] == 'a')
    assert(json_list[0][1] == 1)

# Generated at 2022-06-23 20:12:38.347223
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()(1) == 1

# Generated at 2022-06-23 20:12:39.972294
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert isinstance(auth, ExplicitNullAuth)

# Generated at 2022-06-23 20:12:41.697735
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    orig = {'1key': '1value', '2key': '2value'}
    s = json.dumps(orig)
    loaded = load_json_preserve_order(s)
    assert orig == loaded

# Generated at 2022-06-23 20:12:45.960598
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:12:50.486220
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"c": 3, "a": 1, "b": 2}'
    json_loaded = load_json_preserve_order(json_string)

    # assert isinstance(json_loaded, OrderedDict)
    assert json_loaded.items() == [("c", 3), ("a", 1), ("b", 2)]

# Generated at 2022-06-23 20:12:54.425927
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"foo":1, "bar":2, "baz":3}'
    od = load_json_preserve_order(s)
    assert od == {"foo": 1, "bar": 2, "baz": 3}

# Generated at 2022-06-23 20:12:56.397633
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-23 20:12:57.832120
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    e = ExplicitNullAuth()
    o = e(None)
    assert o is None

# Generated at 2022-06-23 20:12:58.978717
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:13:08.054564
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:13:14.541531
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
        (1024 * 1234 * 1111, '1.3 GB'),
    ]
    for n, expected in tests:
        assert humanize_bytes(n=n) == expected

# Generated at 2022-06-23 20:13:24.278555
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    response_headers = [
        ('Content-Type', 'text/plain; charset=utf-8'),
        ('Content-Length', '1'),
        ('Server', 'Webserver'),
        ('Set-Cookie', 'language=en-US; Max-Age=31536000; Path=/'),
        ('Set-Cookie', 'noname=example; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/'),
        ('Set-Cookie', 'number=123; Expires=Wed, 21 Oct 2035 07:28:00 GMT; Path=/'),
        ('Set-Cookie', 'python=rocks; Max-Age=-1; Path=/'),
        ('Set-Cookie', 'python=rocks; Max-Age=1; Path=/'),
    ]

# Generated at 2022-06-23 20:13:32.439409
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [(
        'Set-Cookie',
        'foo=bar; '
        'expires=Fri, 31-Dec-99 23:59:59 GMT; '
        'path=/; '
        'domain=.example.com'
    )]
    assert get_expired_cookies(headers=headers, now=0) == [
        {
            'name': 'foo',
            'path': '/'
        }
    ]


# Generated at 2022-06-23 20:13:41.889035
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [('Set-Cookie', 'foo=bar; Max-Age=300')]
    cookies = get_expired_cookies(headers)
    assert not cookies
    cookies = get_expired_cookies(headers, now=time.time() + 350)
    assert not cookies
    cookies = get_expired_cookies(headers, now=time.time() + 400)
    assert cookies == [{'name': 'foo', 'path': '/'}]


# Generated at 2022-06-23 20:13:52.833341
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


# Generated at 2022-06-23 20:14:02.587984
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=12345'),
        ('Set-Cookie', 'b=23456; Domain=domain; Path=/; Expires=Wed, 29-Apr-2020 08:07:12 GMT; Max-Age=3600; Secure; HttpOnly'),
        ('Set-Cookie', 'c=45678; Domain=.domain; Path=/; Expires=Wed, 29-Apr-2020 08:12:12 GMT; Max-Age=3600; Secure; HttpOnly'),
        ('Set-Cookie', 'd=54321; Domain=.domain; Path=/; Expires=Wed, 29-Apr-2020 08:12:12 GMT; Max-Age=3600; Secure; HttpOnly')
    ]
    cookies = get_expired_cookies(headers)
    assert len(cookies)

# Generated at 2022-06-23 20:14:05.707225
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
        {
            "abc": 1,
            "def": 2,
            "xyz": 3
        }
    """
    x = load_json_preserve_order(s)
    assert x.keys() == list(x.keys())

# Generated at 2022-06-23 20:14:16.940977
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1.00 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:14:28.266455
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests

# Generated at 2022-06-23 20:14:30.601909
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Ensure that ExplicitNullAuth().__call__(r) works
    auth = ExplicitNullAuth()
    assert auth.__call__({}) == {}


# Generated at 2022-06-23 20:14:31.204102
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:14:40.692929
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert (humanize_bytes(1) == '1 B')
    assert (humanize_bytes(1024, precision=1) == '1.0 kB')
    assert (humanize_bytes(1024 * 123, precision=1) == '123.0 kB')
    assert (humanize_bytes(1024 * 12342, precision=1) == '12.1 MB')
    assert (humanize_bytes(1024 * 12342, precision=2) == '12.05 MB')
    assert (humanize_bytes(1024 * 1234, precision=2) == '1.21 MB')
    assert (humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB')
    assert (humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB')

# Generated at 2022-06-23 20:14:51.671825
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest
    from datetime import timedelta
    from freezegun import freeze_time
    now = time.time()
    with freeze_time(datetime=now):
        # no expired cookies
        headers = (
            ('Set-Cookie', 'JSESSIONID=123; path=/'),
            ('Set-Cookie', 'foo=bar; Max-Age=3600; path=/'),
            ('Set-Cookie', 'bar=baz; Expires=Fri, 31 Dec 9999 23:59:59 GMT; path=/'),
        )
        cookies = get_expired_cookies(headers=headers)
        assert cookies == []

        # all cookies have expired

# Generated at 2022-06-23 20:15:00.149126
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # set-cookie: csrftoken=Bp0pEfbFES1hZLATg8W0a
    # set-cookie: sessionid=h8yhg5r5r3qb3cq5vk2w2
    headers = [
        ('Set-Cookie', 'csrftoken=Bp0pEfbFES1hZLATg8W0a'),
        ('Set-Cookie', 'sessionid=h8yhg5r5r3qb3cq5vk2w2'),
    ]
    assert get_expired_cookies(headers, now=1564607620) == []


# Generated at 2022-06-23 20:15:00.999732
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # from doctest import testmod
    # testmod()
    pass

# Generated at 2022-06-23 20:15:01.771365
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:15:04.674097
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    requests.auth.HTTPDigestAuth = ExplicitNullAuth
    # No exception is acceptable
    requests.get("http://httpbin.org/digest-auth/auth/user/passwd")

# Generated at 2022-06-23 20:15:13.728276
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:24.761432
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:27.604265
# Unit test for function get_content_type
def test_get_content_type():
    print(get_content_type('/path/to/test_data/test_simple.pdf'))
    # application/pdf


if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-23 20:15:38.361488
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    src = """[
    {
        "values": {
            "obj1": 1,
            "obj2": 2,
            "obj3": 3
        }
    },
    {
        "values": {
            "obj1": 1,
            "obj2": 2,
            "obj3": 3
        }
    }
]
"""
    actual = load_json_preserve_order(src)
    expect_dict = OrderedDict([
        ("obj1", 1),
        ("obj2", 2),
        ("obj3", 3),
    ])
    expect = [{"values": expect_dict}, {"values": expect_dict}]
    assert actual == expect

# Generated at 2022-06-23 20:15:42.443272
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_json_dictionary = "{\"first\": 1, \"second\": 2}"
    assert load_json_preserve_order(test_json_dictionary) == OrderedDict([('first', 1), ('second', 2)])



# Generated at 2022-06-23 20:15:43.035832
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:15:50.619563
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():

    import unittest.mock
    import requests.auth

    m = unittest.mock.Mock(spec=requests.auth.AuthBase)
    m.__call__.return_value = 'some_return_value'
    assert ExplicitNullAuth().__call__(m) == 'some_return_value'
    assert m.__call__.called_once_with(m)


# Generated at 2022-06-23 20:15:54.184671
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({'1': 'a', '2': 'b'}) == "{'1': 'a', '2': 'b'}"
    assert repr_dict({}) == '{}'


# Generated at 2022-06-23 20:15:55.330758
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:16:00.438386
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'a': {'b': {'c': {'d': {'e': {'f': {'g': {'h': {'i': {'j': {'k': {'l': {}}}}}}}}}}}}},

# Generated at 2022-06-23 20:16:02.770508
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert True

# Generated at 2022-06-23 20:16:06.101318
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    result = load_json_preserve_order(s)
    assert result == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-23 20:16:11.403149
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/foo.c') == 'text/x-c'
    assert get_content_type('/foo.c.txt') == 'text/plain; charset=us-ascii'
    assert get_content_type('/foo.js') == 'application/javascript'
    assert get_content_type('/foo.js.gz') == 'application/javascript'
    assert get_content_type('/foo.js.br') == 'application/javascript'
    assert get_content_type('/foo.json') == 'application/json'
    assert get_content_type('/foo.json.gz') == 'application/json'
    assert get_content_type('/foo.json.br') == 'application/json'

# Generated at 2022-06-23 20:16:18.511210
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'

# Generated at 2022-06-23 20:16:21.340433
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({
        'a': 'b',
        'c': {
            'd': 'e'
        }
    }) == "{'a': 'b', 'c': {'d': 'e'}}"

# Generated at 2022-06-23 20:16:24.800512
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """Test function ``load_json_preserve_order``."""
    json_str = '{"z": 1, "a": 0}'
    expected = OrderedDict((('z', 1), ('a', 0)))
    actual = load_json_preserve_order(json_str)
    assert expected == actual



# Generated at 2022-06-23 20:16:29.866345
# Unit test for function repr_dict
def test_repr_dict():
    d1 = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {
            'e': 'test_e'
        }
    }
    d2 = 'a=1, b=2, c=3, d={\n    "e": "test_e"\n}'
    assert repr_dict(d1) == d2



# Generated at 2022-06-23 20:16:32.160114
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert type(auth) is ExplicitNullAuth

# Generated at 2022-06-23 20:16:41.203179
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:16:42.320050
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

# Generated at 2022-06-23 20:16:46.087761
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 1, 'b': 2}) == "{\n    'a': 1,\n    'b': 2\n}"
    assert repr_dict({'m': {'t': 'twenty dollar bill'}}) == "\n" \
        "{\n    'm': {\n        't': 'twenty dollar bill'\n    }\n}"

# Generated at 2022-06-23 20:16:49.730073
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert json.dumps(load_json_preserve_order('{"a": 1, "b": 2}')) \
        == json.dumps({"a": 1, "b": 2})

# Generated at 2022-06-23 20:16:53.266436
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    req = requests.Request('GET', 'http://example.com')
    req_with_auth: requests.PreparedRequest = ExplicitNullAuth()(req)
    assert req_with_auth.auth is None

# Generated at 2022-06-23 20:16:56.299875
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('/tmp/test-file.txt')
    assert content_type == 'text/plain'


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 20:17:03.780512
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({
        'a': 2,
        'b': 3.4,
        'c': u'hello',
        'd': [
            {'e': 1},
            {'f': 2}
        ]
    }) == """\
{'a': 2,
 'b': 3.4,
 'c': 'hello',
 'd': [{'e': 1}, {'f': 2}]}"""

# Generated at 2022-06-23 20:17:05.926139
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a":1,"b":2}') == {'a': 1, 'b': 2}

# Generated at 2022-06-23 20:17:06.500896
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:17:08.427831
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Unit test for method __call__ of class ExplicitNullAuth.
    """
    auth = ExplicitNullAuth()
    request = None
    assert auth(request) is request

# Generated at 2022-06-23 20:17:09.196061
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-23 20:17:11.677552
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"z": 1, "a": 2}'
    d = load_json_preserve_order(s)
    assert d == {'z': 1, 'a': 2}



# Generated at 2022-06-23 20:17:22.871045
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024*123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024*12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024*12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024*1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024*1234*1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024*1234*1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:17:29.344577
# Unit test for function load_json_preserve_order

# Generated at 2022-06-23 20:17:31.489285
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    >>> obj = ExplicitNullAuth()
    >>> obj({})
    {}

    """

# Generated at 2022-06-23 20:17:40.993608
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Request
    from requests import Session
    from requests.auth import HTTPBasicAuth
    from .utils import ExplicitNullAuth

    session = Session()
    session.auth = ExplicitNullAuth()

    uname = 'user'
    passwd = 'password'
    url = 'http://httpbin.org/basic-auth/{}/{}'.format(uname, passwd)

    session.get(url=url)  # NB! Fails without ExplicitNullAuth()

    session.auth = HTTPBasicAuth(uname, passwd)
    session.get(url=url)

    req = Request(
        method='GET',
        url=url,
        auth=ExplicitNullAuth(),
    )

    session.send(prepared_request=req)  # NB! Fails without ExplicitNullAuth()


# Generated at 2022-06-23 20:17:49.611227
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.htm') == 'text/html'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.PDF') == 'application/pdf'
    assert get_content_type('foo.xlsx') == 'application/vnd.openxmlformats-' +\
        'officedocument.spreadsheetml.sheet'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.PNG') == 'image/png'
    assert get_

# Generated at 2022-06-23 20:17:50.339399
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:18:00.102349
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict(dict(a=1)) == "{'a': 1}"
    assert repr_dict(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert repr_dict(dict(a=1, b=2, c=3)) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict(dict(c=3, b=2, a=1)) == "{'c': 3, 'b': 2, 'a': 1}"
    assert repr_dict(dict(a=1, b=2, c=3, d=4)) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"

# Generated at 2022-06-23 20:18:07.168953
# Unit test for function repr_dict
def test_repr_dict():
    from pprint import pformat
    from random import randint, shuffle
    from string import digits, ascii_letters

    def random_key():
        return ''.join([digits, ascii_letters][randint(0, 1)]
                       for i in range(8))

    def make_dict():
        n = randint(0, 10)
        d = {}
        for i in range(n):
            key = random_key()
            if key in d:
                continue
            d[key] = random_key()
        return d

    for i in range(100):
        d = make_dict()
        keys = list(d.keys())
        shuffle(keys)
        d_ = {k: d[k] for k in keys}
        assert pformat(d) == repr_dict(d_)

# Generated at 2022-06-23 20:18:11.765337
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Since the method ExplicitNullAuth.__call__() of the class
    ExplicitNullAuth has no effect, when it's executed it can't
    return an error. So, this method should return True as long
    as it doesn't raise an exception.

    """
    auth = ExplicitNullAuth()
    assert auth.__call__(None) is None # pylint: disable=no-value-for-parameter

# Generated at 2022-06-23 20:18:16.098375
# Unit test for function repr_dict
def test_repr_dict():
    # given
    mydict = {'a': 1, 'b': 2, 'c': 3}
    # when
    result = repr_dict(mydict)
    # then
    assert result == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-23 20:18:16.467721
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    return ExplicitNullAuth()

# Generated at 2022-06-23 20:18:20.211260
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.htm') == 'text/html'
    assert get_content_type('test.js') == 'application/javascript'

# Generated at 2022-06-23 20:18:21.624597
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'foo': 'bar'}) == "{\n    'foo': 'bar'\n}"

# Generated at 2022-06-23 20:18:23.240653
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(a=1, b=2, c=3)
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-23 20:18:29.050298
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:18:33.411036
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = """[{"a": "b", "c": "d"}, {"e": "f", "g": "h"}]"""
    result = [{"a": "b", "c": "d"}, {"e": "f", "g": "h"}]
    assert load_json_preserve_order(json_str) == result

# Generated at 2022-06-23 20:18:36.681829
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2, 'c': 3}
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'c': 3}"



# Generated at 2022-06-23 20:18:46.747268
# Unit test for function repr_dict
def test_repr_dict():
    def _check(d, expected):
        # noinspection PyUnresolvedReferences
        assert repr_dict(d) == expected

    _check({}, '{}')

    _check({'a': 'b'}, """\
{
    'a': 'b'
}""")

    _check({'a': 'b', 'c': 'd'}, """\
{
    'a': 'b',
    'c': 'd'
}""")

    _check({'a': {'b': 'c'}}, """\
{
    'a': {
        'b': 'c'
    }
}""")


# Generated at 2022-06-23 20:18:50.984275
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    input_json='{"a": 1, "b": 2}'
    output_dict={"a": 1, "b": 2}
    assert load_json_preserve_order(input_json)==output_dict

# Generated at 2022-06-23 20:18:55.740368
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({'a': [1, 2, 3]}) == "{'a': [1, 2, 3]}"
    assert repr_dict({'a': {'b': 3}}) == "{'a': {'b': 3}}"

# Generated at 2022-06-23 20:18:59.016211
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"c": 3, "b": [2, 1], "a": "test"}'
    d = load_json_preserve_order(json_str)
    assert list(d.keys()) == ['c', 'b', 'a']

# Generated at 2022-06-23 20:19:09.920519
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_dict = OrderedDict(
        [(x, 'key{0}'.format(x)) for x in range(1, 11)]
    )

    test_json = json.dumps(test_dict)
    print('Test dictionary:')
    print(repr_dict(test_dict))
    print('\nTest json:')
    print(test_json)

    result_dict = load_json_preserve_order(test_json)

    print('\nResult dict:')
    print(repr_dict(result_dict))
    print('\nResult json:')
    print(json.dumps(result_dict))

    assert result_dict == test_dict
    assert repr_dict(result_dict) == repr_dict(test_dict)


# if __name__ == '__main__':

# Generated at 2022-06-23 20:19:19.961171
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise AssertionError('No result')
    if humanize_bytes(1024, precision=1) != '1.0 kB':
        raise AssertionError('No result')
    if humanize_bytes(1024 * 123, precision=1) != '123.0 kB':
        raise AssertionError('No result')
    if humanize_bytes(1024 * 12342, precision=1) != '12.1 MB':
        raise AssertionError('No result')
    if humanize_bytes(1024 * 12342, precision=2) != '12.05 MB':
        raise AssertionError('No result')
    if humanize_bytes(1024 * 1234, precision=2) != '1.21 MB':
        raise AssertionError('No result')


# Generated at 2022-06-23 20:19:21.984754
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # This method is called in a script that runs the following commands,
    # so this is enough to make sure it is defined.
    requests.auth.AuthBase.__call__


# Generated at 2022-06-23 20:19:25.344539
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(key1='value1', key2='value2')
    assert repr_dict(d) == "{'key1': 'value1', 'key2': 'value2'}"

# Generated at 2022-06-23 20:19:28.088684
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"key1": "value1", "key2": "value2"}'
    assert repr(load_json_preserve_order(json_str)) == \
        "OrderedDict([('key1', 'value1'), ('key2', 'value2')])"


test_load_json_preserve_order()

# Generated at 2022-06-23 20:19:37.478710
# Unit test for function get_content_type
def test_get_content_type():
    """
    >>> get_content_type('foo.txt')
    'text/plain'
    >>> get_content_type('foo.html')
    'text/html'
    >>> get_content_type('foo.js')  # JavaScript files get an extra charset
    'text/javascript; charset=UTF-8'
    >>> get_content_type('foo.png')
    'image/png'
    >>> get_content_type('foo.json')
    'application/json'
    >>> get_content_type('foo.txt.gz')  # mimetypes also handles compression
    'text/plain'
    >>> get_content_type('foo.tar.gz')  # and file extensions
    'application/gzip'
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:19:45.836435
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest
    from io import StringIO
    from http.cookies import SimpleCookie
    from urllib.parse import urlparse

    from .alembic_extra import load_stamp_head_revision
    from .alembic_extra import load_stamp_revision
    from .alembic_extra import parse_args
    from .alembic_extra import success


    @pytest.fixture(scope='session', autouse=True)
    def prepare_test_database(tmpdir_factory):
        dbpath = str(tmpdir_factory.mktemp('test_databases').join('test.sqlite'))
        connection = 'sqlite:///' + dbpath
        config_params = parse_args(
            ['--connection', connection, '--autogenerate'])

        # Create

# Generated at 2022-06-23 20:19:49.030804
# Unit test for function repr_dict
def test_repr_dict():
    a = {'a': 1, 'b': 2}
    assert(repr_dict(a) == "{'a': 1, 'b': 2}")
    a = {'b': 2, 'a': 1}
    assert(repr_dict(a) == "{'b': 2, 'a': 1}")

# Generated at 2022-06-23 20:19:56.106442
# Unit test for function humanize_bytes
def test_humanize_bytes():

    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:20:01.890818
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # test load_json_preserve_order()
    # as a side effect this tests that OrderedDict is available
    import json
    from collections import OrderedDict
    s = '[["foo", 1], ["bar", 2]]'
    # The order should be preserved
    assert load_json_preserve_order(s) == OrderedDict([('foo', 1), ('bar', 2)])
    # Load into normal dict
    assert json.loads(s) == {'foo': 1, 'bar': 2}

# Generated at 2022-06-23 20:20:08.777847
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    expired_cookies_1 = [
        {'name': 'test', 'path': '/'},
        {'name': 'test2', 'path': '/'},
    ]
    expired_cookies_2 = [
        {'name': 'test', 'path': '/'},
    ]
    expired_cookies_3 = [
        {'name': 'test2', 'path': '/'},
    ]
    expired_cookies_4 = [
        {'name': 'test3', 'path': '/'}
    ]

# Generated at 2022-06-23 20:20:13.627572
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_content_type('/some/path/file.pdf') == 'application/pdf'
    assert get_content_type('/some/path/file.jpg') == 'image/jpeg'


if __name__ == "__main__":
    test_get_expired_cookies()

# Generated at 2022-06-23 20:20:18.536415
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import timedelta, datetime
    import dateutil.parser
    from dateutil.tz import tzutc

    time_now = time.time()
    time_future = time_now + 3600

    utc_now = datetime.utcfromtimestamp(time_now).replace(tzinfo=tzutc())
    utc_future = datetime.utcfromtimestamp(time_future).replace(tzinfo=tzutc())


# Generated at 2022-06-23 20:20:26.897399
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:20:31.370112
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_s = '{"id": "foo", "size": "bar"}'
    assert {'id': 'foo', 'size': 'bar'} \
           == load_json_preserve_order(json_s)
    assert {'foo': 'bar'} == load_json_preserve_order('{"foo": "bar"}')

# Generated at 2022-06-23 20:20:35.129096
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": [0, 1, 2]}'
    d = OrderedDict([
        ('a', 1),
        ('b', [0, 1, 2])
    ])
    actual_d = load_json_preserve_order(s=s)
    assert(actual_d == d)

# Generated at 2022-06-23 20:20:39.913930
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({
        'a': 1,
        'b': 2,
        'c': [1, 2, 3]
    }) == '{\'a\': 1, \'b\': 2, \'c\': [1, 2, 3]}'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:20:45.992716
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:20:48.227765
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    req = requests.Request('GET', 'http://example.com')
    result = auth(req)
    assert result is req

# Generated at 2022-06-23 20:20:55.789072
# Unit test for function humanize_bytes
def test_humanize_bytes():
    result = humanize_bytes(1)
    assert result == '1 B'
    result = humanize_bytes(1024, precision=1)
    assert result == '1.0 kB'
    result = humanize_bytes(1024 * 123, precision=1)
    assert result == '123.0 kB'
    result = humanize_bytes(1024 * 12342, precision=1)
    assert result == '12.1 MB'
    result = humanize_bytes(1024 * 12342, precision=2)
    assert result == '12.05 MB'
    result = humanize_bytes(1024 * 1234, precision=2)
    assert result == '1.21 MB'
    result = humanize_bytes(1024 * 1234 * 1111, precision=2)
    assert result == '1.31 GB'
    result = human

# Generated at 2022-06-23 20:21:04.103487
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    cookies = get_expired_cookies([
        ('Set-Cookie', 'foo=bar; Expires=Mon, 02-Apr-2018 21:20:27 GMT'),
        ('Set-Cookie', 'baz=quux; Expires=Fri, 01-Jan-9999 00:00:00 GMT; Path=/'),
        ('Set-Cookie', 'quuuux=quuuuux; Max-Age=0; Path=/'),
        ('Set-Cookie', 'quuuuuux=quuuuuux; Max-Age=9999999999999; Path=/'),
    ], now=now)
    assert cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'quuuux', 'path': '/'},
    ]

# Generated at 2022-06-23 20:21:05.486154
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('some.txt') == 'text/plain'
    assert get_content_type('some.nonexistent') is None

# Generated at 2022-06-23 20:21:05.866277
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:21:07.308691
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.txt') == 'text/plain'

# Generated at 2022-06-23 20:21:13.542619
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html.gz') == 'text/html; charset=gzip'
    # A non-existent file name is still unknown.
    assert get_content_type('not-a-file.whatever') is None

# Generated at 2022-06-23 20:21:17.287498
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    # noinspection PyTypeChecker
    assert repr(auth) == '<requests.auth.ExplicitNullAuth>'
    assert repr(auth(None)) == '<requests.auth.ExplicitNullAuth>'

# Generated at 2022-06-23 20:21:18.348432
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()


# Generated at 2022-06-23 20:21:21.616105
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"foo":"bar", "spam":"eggs"}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict)
    assert d == {'foo': 'bar', 'spam': 'eggs'}


# Generated at 2022-06-23 20:21:23.266752
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('some.txt') == 'text/plain'
    assert get_content_type('some.foo') == None

# Generated at 2022-06-23 20:21:24.325678
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()(None) is None

# Generated at 2022-06-23 20:21:32.304394
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from dateutil.tz import tzoffset

    utc = tzoffset(None, timedelta(0))
    now = datetime(2020, 3, 1, 18, tzinfo=utc).timestamp()
    # 1. Headers with different combinations of `expires` / `max-age` values

# Generated at 2022-06-23 20:21:36.063146
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1}
    d_repr = repr_dict(d)
    assert d_repr == "{'a': 1}", f'Got {d_repr}'
    print('Success')

# Generated at 2022-06-23 20:21:46.361720
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    session = Session()
    session.auth = ExplicitNullAuth()
    response = session.get('https://httpbin.org/get')

# Generated at 2022-06-23 20:21:48.198628
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.json') == 'application/json'

# Generated at 2022-06-23 20:21:54.134367
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.json') == 'application/json'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.pdf') == 'application/pdf'
    assert not get_content_type('test.doc')
    assert not get_content_type('test.xls')