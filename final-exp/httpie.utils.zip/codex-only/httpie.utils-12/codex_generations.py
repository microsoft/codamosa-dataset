

# Generated at 2022-06-23 20:12:01.682902
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-23 20:12:08.287959
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'A1=B1; Domain=.example.com; Path=/; Expires=Sun, 30 Sep 2018 20:21:33 GMT; Secure; HttpOnly'),
        ('Set-Cookie', 'A2=B2; Domain=.example.com; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'A3=B3; Domain=.example.com; Path=/; Max-Age=1'),
        ('Set-Cookie', 'A4=B4; Domain=.example.com; Path=/; Secure; HttpOnly'),
    ]
    now = 1538248893
    cookies = get_expired_cookies(headers, now)
    assert 'A1' in [c['name'] for c in cookies]

# Generated at 2022-06-23 20:12:11.461444
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.png') == 'image/png'
    assert (
        get_content_type('foo.png') ==
        get_content_type('foo.png; charset=UTF-8')
    )

# Generated at 2022-06-23 20:12:18.727210
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:12:28.710723
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    example_headers = [
        ('Set-Cookie', 'session=1; expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie',
         'session2=2; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/path'),
        ('Set-Cookie',
         'session3=3; '
         'expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/path; domain=domain'),
    ]

# Generated at 2022-06-23 20:12:39.630281
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:12:41.919000
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert isinstance(auth, ExplicitNullAuth)


# Generated at 2022-06-23 20:12:53.459586
# Unit test for function get_content_type
def test_get_content_type():
    assert 'image/jpeg' == get_content_type('IMG_4505.JPG')
    assert 'image/jpeg' == get_content_type('IMG_4505.jpeg')
    assert 'image/jpeg' == get_content_type('IMG_4505.JPeG')
    assert 'video/quicktime' == get_content_type('VID_20200409_074801.mp4')
    assert 'video/quicktime' == get_content_type('VID_20200409_074801.mov')
    assert 'video/quicktime' == get_content_type('VID_20200409_074801.MOV')
    assert 'video/quicktime' == get_content_type('VID_20200409_074801.m4v')

# Generated at 2022-06-23 20:13:01.157493
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(100) == '100 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 1024) == '1.00 MB'
    assert humanize_bytes(1024 * 1024 * 1024) == '1.00 GB'
    assert humanize_bytes(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    assert humanize_bytes(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    assert humanize_bytes(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1024.00 PB'


if __name__ == '__main__':
    print(test_humanize_bytes())

# Generated at 2022-06-23 20:13:08.322342
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:13:10.212755
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert (
        ExplicitNullAuth().__call__({'auth': None}) ==
        {'auth': None}
    )

# Generated at 2022-06-23 20:13:14.047667
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{ "a": 1, "b": 2, "c": 3 }"""
    r = load_json_preserve_order(s)
    assert isinstance(r, OrderedDict)
    assert list(r.items()) == [("a", 1), ("b", 2), ("c", 3)]



# Generated at 2022-06-23 20:13:17.602643
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    order = [('x', 'first'), ('y', 'second')]
    s = '{' + ', '.join(('"%s": "%s"' % (k, v)) for k, v in order) + '}'
    assert load_json_preserve_order(s) == dict(order)

# Generated at 2022-06-23 20:13:21.280748
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    req = requests.Request('GET', 'http://httpbin.org/get')
    prepped = req.prepare()
    assert prepped.body is None
    assert prepped.headers == {
        'User-Agent': 'python-requests/%s' % requests.__version__
    }



# Generated at 2022-06-23 20:13:24.418241
# Unit test for function repr_dict
def test_repr_dict():
  d = {'a': 'b', 'c': {'d': 'e'}}
  assert repr_dict(d) == "{'a': 'b', 'c': {'d': 'e'}}"


# Generated at 2022-06-23 20:13:32.060607
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    expires = now - 100
    headers = [
        (
            'Set-Cookie',
            "session=djn0oea6y8g7yjp1zo77j0hvn0"
            "; expires=Tue, {expires} GMT; HttpOnly; Max-Age=86400".format(
                expires=time.strftime('%a, %d %b %Y %H:%M:%S', time.gmtime(expires))
            )
        )
    ]

    assert get_expired_cookies(headers, now=now) == [
        {
            'name': 'session',
            'path': '/'
        }
    ]


# Generated at 2022-06-23 20:13:36.223003
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{
    "x": 123,
    "y": 456,
    "z": 789
}"""
    expected = OrderedDict([('x', 123), ('y', 456), ('z', 789)])
    assert load_json_preserve_order(s) == expected

# Generated at 2022-06-23 20:13:37.571617
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert repr(a) == repr(a)

# Generated at 2022-06-23 20:13:41.283357
# Unit test for function get_content_type
def test_get_content_type():
    filename = "test.txt"
    assert get_content_type(filename) == "text/plain"
    filename = "test.png"
    assert get_content_type(filename) == "image/png"
    filename = "test"
    assert get_content_type(filename) is None

# Generated at 2022-06-23 20:13:52.092219
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def hb(n, p, s=None):
        r = humanize_bytes(n, precision=p)
        assert r == s or (s is None and r == '{} B'.format(n)), r

    hb(1, 0, '1 B')
    hb(1000, 0, '1000 B')
    hb(1024, 0, '1 kB')
    hb(1024, 1, '1.0 kB')
    hb(2048, 1, '2.0 kB')
    hb(2048, 1, '2.0 kB')
    hb(2048, 2, '2.00 kB')
    hb(10 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024, 7)

# Generated at 2022-06-23 20:14:02.178044
# Unit test for function repr_dict
def test_repr_dict():
    rd = repr_dict
    assert rd({}) == '{}'
    assert rd({'a': None}) == "{'a': None}"
    assert rd({'a': 1}) == "{'a': 1}"
    assert rd({'b': [1, 2, 3]}) == "{'b': [1, 2, 3]}"
    assert rd({'c': (1, 2, 3)}) == "{'c': (1, 2, 3)}"
    assert rd({'d': {1: 2, 3: 4}}) == "{'d': {1: 2, 3: 4}}"

# Generated at 2022-06-23 20:14:11.981166
# Unit test for function humanize_bytes
def test_humanize_bytes():
    bytes_decreasing_order = [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
        (1024 * 1234 * 1111, '1.3 GB'),
    ]
    bytes_increasing_order = [(b, s) for b, s in bytes_decreasing_order[::-1]]

# Generated at 2022-06-23 20:14:17.421744
# Unit test for function get_content_type
def test_get_content_type():
    for (filename, expected_content_type) in [
        ('mimetypes_test.txt', 'text/plain'),
        ('mimetypes_test.in_', 'text/plain'),
        ('mimetypes_test.in.in_', 'text/plain'),
        ('mimetypes_test.in.in', 'application/octet-stream'),
        ('mimetypes_test.pem', 'application/x-pem-file'),
        (
            'mimetypes_test.svg',
            'image/svg+xml; charset=iso-8859-1'
        ),
    ]:
        assert expected_content_type == get_content_type(filename)

# Generated at 2022-06-23 20:14:23.930729
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    d = dict(a=1)
    assert repr_dict(d) == '{\n    "a": 1\n}'
    d['b'] = [1, 2]
    assert repr_dict(d) == '{\n    "a": 1,\n    "b": [\n        1,\n        2\n    ]\n}'
    d['c'] = {1: 2}
    d['d'] = {1, 2}

# Generated at 2022-06-23 20:14:26.953116
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert repr_dict(auth.__call__({})) == "{}"

# Generated at 2022-06-23 20:14:28.338237
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None

# Generated at 2022-06-23 20:14:29.273040
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    x = ExplicitNullAuth()
    assert x is not None

# Generated at 2022-06-23 20:14:39.048152
# Unit test for function get_content_type
def test_get_content_type():
    """
    Test get_content_type().
    """
    # pylint: disable=no-self-use
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.doc') == 'application/msword'
    assert get_content_type('file.xls') == 'application/vnd.ms-excel'
    assert get_content_type('file.mp3') == 'audio/mpeg'
    assert get_content_type('file.gif') == 'image/gif'
    assert get_content_type('file.png') == 'image/png'
    assert get_content_type('file.jpg') == 'image/jpeg'
    assert get_content_type('file.jpeg') == 'image/jpeg'
    assert get_content_

# Generated at 2022-06-23 20:14:41.075674
# Unit test for function repr_dict
def test_repr_dict():
    result = repr_dict({'foo': 'bar'})
    assert result == "{'foo': 'bar'}"

# Generated at 2022-06-23 20:14:43.405852
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(OrderedDict([('a', 1), ('b', 2)])) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:14:48.451053
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # type: () -> bool
    """
    Unit test for method __call__ of class ExplicitNullAuth

    Returns
    -------
    bool
        True if unit test passes else False

    """
    auth = ExplicitNullAuth()
    request = auth(requests.Request('GET', 'http://example.com').prepare())

    assert request.headers.get('Authorization') is None, \
        repr_dict(request.headers)

    return True

# Generated at 2022-06-23 20:14:51.031393
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    o = load_json_preserve_order(r'{"a":1,"b":2,"c":3}')
    assert isinstance(o, OrderedDict)
    assert o.keys() == ['a', 'b', 'c']

# Generated at 2022-06-23 20:14:57.040212
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar1; Max-Age=100; Path=/; Secure; HttpOnly')
    ]
    now = time.time()
    cookies = get_expired_cookies(headers=headers, now=now)
    expected = [
        {
            'name': 'foo',
            'path': '/'
        }
    ]
    assert cookies == expected, pformat(cookies)
    headers = [
        ('Set-Cookie', 'foo=bar1; Max-Age=100;'),
        ('Set-Cookie', 'foo=bar2; Max-Age=100; Path=/; Secure; HttpOnly')
    ]
    now = time.time()
    cookies = get_expired_cookies(headers=headers, now=now)

# Generated at 2022-06-23 20:14:58.246677
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Tested in test_ExplicitNullAuth_class_with_netrc_and_auth_headers.py

    pass



# Generated at 2022-06-23 20:14:59.557039
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    au = ExplicitNullAuth()
    au.__call__(None)
    pass

# Generated at 2022-06-23 20:15:06.470202
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookie = 'session=1; Domain=.example.net; Path=/; Expires=' \
             'Sun, 24-Sep-2017 07:33:22 GMT; httponly'
    result = get_expired_cookies([(1, cookie)])
    assert result == [{'name': 'session', 'path': '/'}]

    result = get_expired_cookies([(1, cookie)], now=1037137603.351656)
    assert result == [{'name': 'session', 'path': '/'}]

    result = get_expired_cookies([(1, cookie)], now=1506342802.351656)
    assert result == []

# Generated at 2022-06-23 20:15:13.248207
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024,1) == '1.0 kB'
    assert humanize_bytes(1024 * 123,1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342,1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342,2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234,2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111,2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111,1) == '1.3 GB'
    print('Tests passed!')

# Generated at 2022-06-23 20:15:17.887552
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert [1, 2, 3] == load_json_preserve_order('[1,2,3]')
    assert {'age': 12, 'name': 'John'} == load_json_preserve_order('{"name":"John", "age":12}')

# Generated at 2022-06-23 20:15:27.531714
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:15:30.448617
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # noinspection PyUnusedLocal
    auth = ExplicitNullAuth()

# Generated at 2022-06-23 20:15:32.526280
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert a is not None


# Generated at 2022-06-23 20:15:34.730876
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'bb': [2, 3]}) == "{'a': 1, 'bb': [2, 3]}"

# Generated at 2022-06-23 20:15:36.932736
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert hasattr(auth, '__call__')




# Generated at 2022-06-23 20:15:39.126425
# Unit test for function repr_dict
def test_repr_dict():
    d = {'bing': 'bong'}
    assert repr_dict(d) == "{'bing': 'bong'}"

# Generated at 2022-06-23 20:15:42.993215
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('foo.txt')
    assert 'image/png' == get_content_type('bar.png')
    assert 'application/octet-stream' == get_content_type('baz.bin')


if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-23 20:15:50.619907
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    >>> load_json_preserve_order('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}
    True
    >>> load_json_preserve_order('{"foo": "bar", "baz": "qux"}') == {'baz': 'qux', 'foo': 'bar'}
    False
    """



# Generated at 2022-06-23 20:15:56.832927
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024*123) == '123.00 kB'
    assert humanize_bytes(1024*12342) == '12.05 MB'
    assert humanize_bytes(1024*1234*1111, 2) == '1.31 GB'
    assert humanize_bytes(1024*1234*1111, 1) == '1.3 GB'



# Generated at 2022-06-23 20:16:04.499022
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"a": 1, "b": 2, "c": 3, "d": 4, "e": 5}'

    # Testing with a string
    expected_dict = OrderedDict([("a", 1), ("b", 2), ("c", 3), ("d", 4), ("e", 5)])
    assert load_json_preserve_order(json_string) == expected_dict

    # Testin with a file
    with open('test_load_json_preserve_order.txt', 'w') as f:
        f.write(json_string)

    with open('test_load_json_preserve_order.txt') as f:
        assert load_json_preserve_order(f) == expected_dict

# Generated at 2022-06-23 20:16:08.780651
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 ** 4, precision=1) == '1.0 TB'

# Generated at 2022-06-23 20:16:10.988598
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json1 = """{"a": "a value", "z": "z value"}"""
    json2 = """{"z": "z value", "a": "a value"}"""
    assert load_json_preserve_order(json1) == load_json_preserve_order(json2)

# Generated at 2022-06-23 20:16:12.603895
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    try:
        ExplicitNullAuth()
    except Exception as e:
        assert False, "{}".format(e)


# Generated at 2022-06-23 20:16:22.678524
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    header_lines = []
    header_lines.append(
        'Set-Cookie: _foobar_session=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2'
        'lkIjozLCJleHAiOiIxNTA4ODc2MzQ2In0.-yD1iKjSR6oYV7pI4kH7Ri_T0yYiYGtsjQ2'
        'mdn-Zzg; domain=.example.com; path=/; expires=Mon, 11-Sep-2017 10:29:06 '
        'GMT; secure; HttpOnly; SameSite=None'
    )

# Generated at 2022-06-23 20:16:32.385133
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1522164580

# Generated at 2022-06-23 20:16:34.440297
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({1: 3}) == '{1: 3}'



# Generated at 2022-06-23 20:16:38.175158
# Unit test for function get_content_type
def test_get_content_type():
    import os.path
    assert get_content_type(__file__) == 'text/x-python'
    assert get_content_type(os.path.join(__file__, '..', '..', 'LICENSE')) == 'text/plain'

# Generated at 2022-06-23 20:16:38.746948
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:16:41.192183
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 'b'}) == "{\n    'a': 'b'\n}"

# Generated at 2022-06-23 20:16:45.973066
# Unit test for function repr_dict
def test_repr_dict():
    # type: () -> None
    sample = {'a': {"b": [1, 2, {'c': True}]}}
    expected = "{\'a\': {\'b\': [1, 2, {\'c\': True}]}}"
    assert repr_dict(sample) == expected

# Generated at 2022-06-23 20:16:51.515135
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('path/to/my/file.jpg') == 'image/jpeg'
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.no-extension') is None
    assert get_content_type('file.x-unknown-extension') is None

# Generated at 2022-06-23 20:16:54.328407
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(
        'test_crawlera_session.py'
    ) == 'text/x-python; charset=us-ascii'

# Generated at 2022-06-23 20:16:59.711712
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; max-age=60; path=/; HttpOnly; SameSite=Strict'),
        ('Set-Cookie', 'foo=bar; max-age=60; path=/; HttpOnly; SameSite=Strict'),
        ('Set-Cookie', 'foo=bar; max-age=60; path=/; HttpOnly; SameSite=Strict'),
        ('Set-Cookie', 'foo=bar; max-age=60; path=/; HttpOnly; SameSite=Strict'),
    ]
    expired_cookies = get_expired_cookies(headers=headers, now=time.time())
    assert len(expired_cookies) == 4

# Generated at 2022-06-23 20:17:04.941534
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """\
{
    "price": 70,
    "stock": "3 items",
    "name": "Pentium PC"
}
"""
    assert load_json_preserve_order(s) == OrderedDict([
        ('price', 70),
        ('stock', '3 items'),
        ('name', 'Pentium PC'),
    ])

# Generated at 2022-06-23 20:17:12.963228
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict(OrderedDict()) == 'OrderedDict()'
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == '{\'a\': 1, \'b\': 2, \'c\': 3}'
    assert repr_dict(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == 'OrderedDict([(\'a\', 1), (\'b\', 2), (\'c\', 3)])'
    assert repr_dict({'a': [1, 2, 3, 4]}) == '{\'a\': [1, 2, 3, 4]}'
    assert repr_dict({'a': 1, 'b': 2, 'c': [3, 4, 5]})

# Generated at 2022-06-23 20:17:24.217522
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from .test import assert_equal, assert_true

    now = time.time()
    fresh_cookie = {
        'name': 'fresh',
        'value': 'fresh',
        'path': '/',
        'expires': now + 86400  # 1 day in future
    }
    expired_cookie = {
        'name': 'expired',
        'value': 'expired',
        'path': '/',
        'expires': now - 86400  # 1 day in past
    }
    cookies = [fresh_cookie, expired_cookie]
    _max_age_to_expires(cookies=cookies, now=now)

    headers = [
        ('Set-Cookie', '%s=%s' % (c['name'], c['value']))
        for c in cookies
    ]


# Generated at 2022-06-23 20:17:27.972327
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    data = (
        b'{"c": [{"a": 123, "b": ["A", "B"]}, 1, 2, 3], "d": {"a": "abc"}}'
    )
    expected = {
        "c": [{"a": 123, "b": ["A", "B"]}, 1, 2, 3],
        "d": {"a": "abc"},
    }
    assert load_json_preserve_order(data) == expected

# Generated at 2022-06-23 20:17:28.986850
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:17:30.337171
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    _ = ExplicitNullAuth() # noqa: F841

# Generated at 2022-06-23 20:17:35.457540
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1000) == '1000 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 10) == '10.0 kB'


if __name__ == '__main__':
    test_humanize_bytes()

# Generated at 2022-06-23 20:17:39.428812
# Unit test for function repr_dict
def test_repr_dict():
    """
    Tests a function for comparaison

    :return: None
    """
    test_dict = {'website': {'google': {'www': 'www.google.com', 'email': 'mail.google.com'}}}
    assert repr_dict(test_dict) == pformat(test_dict)

# Generated at 2022-06-23 20:17:46.781249
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'cookiename=cookievalue'),
        ('Set-Cookie', 'cookiename2=cookievalue2'),
        ('Set-Cookie', 'cookiename3=cookievalue3; HttpOnly; expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'cookiename4=cookievalue4; HttpOnly; max-age=0'),
    ]

    cookies = get_expired_cookies(headers)

    assert len(cookies) == 2
    assert cookies[0]['name'] == 'cookiename3'
    assert cookies[0]['path'] == '/'
    assert cookies[1]['name'] == 'cookiename4'
    assert cookies[1]['path'] == '/'

# Generated at 2022-06-23 20:17:50.781505
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.json') == 'application/json'
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.txt') == 'text/plain'


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-23 20:17:57.213593
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"key1": [{"inner_key1": "value1"}], "key2": {"inner_key2": "value2"}}'
    expected = OrderedDict([("key1", [OrderedDict([("inner_key1", "value1")])]), ("key2", OrderedDict([("inner_key2", "value2")]))])
    actual = load_json_preserve_order(s)
    assert actual == expected



# Generated at 2022-06-23 20:18:01.187317
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    source = "{'x':1, 'y':[10,20,30]}"
    result = load_json_preserve_order(s=source)
    assert len(result) == 2, (
        "Function load_json_preserve_order() must load JSON preserving "
        "the key order"
    )
    assert list(result.keys()) == ['x', 'y'], (
        "Function load_json_preserve_order() must load JSON preserving "
        "the key order"
    )

# Generated at 2022-06-23 20:18:02.444919
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.txt') == 'text/plain'
    assert get_content_type('example.doc') is None

# Generated at 2022-06-23 20:18:05.374503
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    obj = load_json_preserve_order(b'{"key": "value"}')
    assert (isinstance(obj, OrderedDict))


# Generated at 2022-06-23 20:18:13.753852
# Unit test for function get_content_type
def test_get_content_type():
    import os

    def do_test(filename, expected_content_type):
        print('do_test(%r, %r)' % (filename, expected_content_type))
        got = get_content_type(filename)
        assert got == expected_content_type, (
            '\n'.join(
                (
                    '%r != %r' % (got, expected_content_type),
                    ''.join(
                        ' %r: %r\n' % (key, value)
                        for key, value in mimetypes.types_map.items()
                        if got in value
                    )
                )
            )
        )

    mimetypes.init()

    do_test('test.txt', 'text/plain')
    do_test('svideo.txt', 'text/plain')

# Generated at 2022-06-23 20:18:20.211204
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.adapters import HTTPAdapter

    auth = ExplicitNullAuth()
    session = Session()
    adapter = HTTPAdapter()
    session.mount('http://', adapter)
    response = session.get(
        'http://echo.jsontest.com/cookies/no',
        auth=auth
    )
    response.raise_for_status()
    assert response.json() == {'cookies': 'no'}

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:18:29.776251
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([
        ('Set-Cookie', 'x=y; path=/; domain=example.com'),
        ('Set-Cookie', ('t=z; expires=Sun, 1 Jan 2017 00:00:00 GMT; '
                        'path=/; domain=example.com')),
    ], now=time.mktime((2016, 1, 1, 0, 0, 0, 0, 0, -1))) == [
        {'name': 'x', 'path': '/'},
    ]


# Generated at 2022-06-23 20:18:31.383864
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth.__call__(None) is None

# Generated at 2022-06-23 20:18:35.741779
# Unit test for function repr_dict
def test_repr_dict():
    from pprint import pprint
    from textwrap import dedent
    import unittest

    class TestReprDict(unittest.TestCase):
        def test_dict(self):
            d = {'a': 1, 'b': 2}
            s = repr_dict(d)
            self.assertEqual(s, pformat(d))


    unittest.main()

# Generated at 2022-06-23 20:18:37.265676
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.pdf') == 'application/pdf'



# Generated at 2022-06-23 20:18:44.551949
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    from io import StringIO
    io = StringIO('[1, 2, 3]')
    assert json.load(io) == [1, 2, 3]
    assert type(json.load(io)) == list

    io = StringIO('[1, 2, 3]')
    assert load_json_preserve_order(io.read()) == OrderedDict([(0, 1), (1, 2), (2, 3)])
    assert type(load_json_preserve_order(io.read())) == OrderedDict



# Generated at 2022-06-23 20:18:46.433824
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2, 'cc': 3}
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'cc': 3}"

# Generated at 2022-06-23 20:18:55.076522
# Unit test for function get_content_type
def test_get_content_type():
    test_cases = {
        'file.txt': 'text/plain',
        'file.html': 'text/html',
        'file.gif': 'image/gif',
        'file.jpg': 'image/jpeg',
        'file.png': 'image/png',
        # other type
        'file.foo': 'application/octet-stream',
        # no extension
        'file': 'application/octet-stream',
    }
    for filename, expect in test_cases.items():
        assert get_content_type(filename) == expect

# Generated at 2022-06-23 20:18:59.719114
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('some.txt') == 'text/plain'
    assert get_content_type('some.json') == 'application/json'
    assert get_content_type('some.xml') == 'text/xml'
    # TODO: mimetypes does not work with django template files.
    # assert get_content_type('some.foo') is None

# Generated at 2022-06-23 20:19:10.305207
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import datetime

    now = time.mktime(datetime.datetime(2017, 1, 1).timetuple())
    headers = [
        ('Set-Cookie', 'CSRF-TOKEN=zu8n73pr; Path=/'),
        ('Set-Cookie', 'session=eyJfcGVybWFuZW50Ijp0cnVlfQ.DnFjk.Sfh9Eq3f8WJ1z; Path=/; Expires=Sun, 08-Jan-2017 23:48:20 GMT; HttpOnly'),
        ('Set-Cookie', 'session.sig=VgGkYxaY7Vvyc5fCiZG6pF8WTL0; Path=/; Expires=Sun, 08-Jan-2017 23:48:20 GMT; HttpOnly')
    ]



# Generated at 2022-06-23 20:19:13.013480
# Unit test for function repr_dict
def test_repr_dict():
    """
    Checking repr_dict() function returns string
    """
    d = {'foo': 'bar'}
    assert isinstance(repr_dict(d), str)

# Generated at 2022-06-23 20:19:14.804623
# Unit test for function repr_dict
def test_repr_dict():
    output = repr_dict({'a': 1, 'b': 2})
    assert output == "{'a': 1, 'b': 2}"



# Generated at 2022-06-23 20:19:22.072821
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == "1 B"
    assert humanize_bytes(1024, precision=1) == "1.0 kB"
    assert humanize_bytes(1024 * 123, precision=1) == "123.0 kB"
    assert humanize_bytes(1024 * 12342, precision=1) == "12.1 MB"
    assert humanize_bytes(1024 * 12342, precision=2) == "12.05 MB"
    assert humanize_bytes(1024 * 1234, precision=2) == "1.21 MB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == "1.31 GB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == "1.3 GB"

# Generated at 2022-06-23 20:19:23.603278
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import pytest

    with pytest.raises(Exception):
        ExplicitNullAuth.__call__(None)



# Generated at 2022-06-23 20:19:26.894217
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a":1, "b":2, "c":3}'
    d = load_json_preserve_order(s)
    assert len(d) == 3
    assert list(d.keys()) == ['a', 'b', 'c']

# Generated at 2022-06-23 20:19:28.465626
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-23 20:19:31.161648
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    assert load_json_preserve_order(s) == OrderedDict([("a", 1), ("b", 2), ("c", 3)])

# Generated at 2022-06-23 20:19:41.350564
# Unit test for function repr_dict

# Generated at 2022-06-23 20:19:49.488249
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        [1, '1 B'],
        [1024, '1.00 kB'],
        [1024 * 123, '123.00 kB'],
        [1024 * 12342, '12.05 MB'],
        [1024 * 12342 * 1111, '1.31 GB'],
        [1024 * 1234, '1.21 MB'],
        [1024 * 1234 * 1111, '1.31 GB'],
    ]

    for bytes, humanized in tests:
        assert humanize_bytes(bytes) == humanized

# Generated at 2022-06-23 20:19:53.353205
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(
        {'bla': True, 'other': {'list': [5, 6]}, 'toto': 'titi'}) == "{'bla': True,\n " + \
        "'other': {'list': [5, 6]},\n 'toto': 'titi'}"


# Unit tests for function repr_dict

# Generated at 2022-06-23 20:19:54.599677
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    """Test for Constructor of Class ExplicitNullAuth"""
    a = ExplicitNullAuth()
    assert a is not None

# Generated at 2022-06-23 20:20:03.056786
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1525044750.8932291

# Generated at 2022-06-23 20:20:03.544148
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert True

# Generated at 2022-06-23 20:20:05.350043
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('hello.json') == 'application/json'
    assert get_content_type('hello.txt') == 'text/plain'

# Generated at 2022-06-23 20:20:06.318087
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:20:10.106231
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('x') is None
    assert get_content_type('x.txt') == 'text/plain'
    assert get_content_type('x.html') == 'text/html'
    assert get_content_type('x.csv') == 'text/csv'

# Generated at 2022-06-23 20:20:19.164934
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    # Get requests cookies into the right format
    class MockResponse:
        headers = {
            'Set-Cookie': (
                'foo=bar; Path=/; expires=Thu, 22-Jun-2017 08:15:57 GMT, '
                'baz=biz; Path=/; expires=Thu, 22-Jun-2017 08:15:58 GMT'
            )
        }

    response = MockResponse()

    cookies = get_expired_cookies(
        headers=response.headers.items(),
        now=time.time()
    )
    assert cookies == [{'name': 'foo', 'path': '/'}, {'name': 'baz', 'path': '/'}]

# Generated at 2022-06-23 20:20:19.723804
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:20:22.296786
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('README.md') == 'text/plain'
    assert get_content_type('README.odt') == 'application/vnd.oasis.opendocument.text'
    assert get_content_type('README') is None

# Generated at 2022-06-23 20:20:32.212173
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    def _set_netrc_file(filepath):
        # noinspection PyPackageRequirements
        import netrc
        import os
        import tempfile
        import unittest

        with tempfile.NamedTemporaryFile(dir=os.getcwd()) as fp:
            netrc.netrc(open(filepath)).save(fp.name)
            with open(fp.name) as src:
                with open(filepath, 'w') as dst:
                    dst.write(src.read())

    # Single host
    with netrc_file(
        'machine example.com login username password password'
    ):
        pass
    # Two hosts

# Generated at 2022-06-23 20:20:33.598558
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Test with no arguments
    assert ExplicitNullAuth() is None



# Generated at 2022-06-23 20:20:34.740302
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(object())



# Generated at 2022-06-23 20:20:38.494354
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '[{"a": 1, "b":2}, 3]'

    # Without preserving the order, the output would be "[{'a': 1, 'b': 2}, 3]".
    assert repr_dict(load_json_preserve_order(s)) == '[(b, 2), (a, 1), 3]'

# Generated at 2022-06-23 20:20:48.068538
# Unit test for function humanize_bytes

# Generated at 2022-06-23 20:20:55.132181
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def hb(n, p, result):
        """helper function hb."""
        r = humanize_bytes(n, precision=p)
        if r != result:
            print("Error in humanize_bytes: %s != %s" % (r, result))
    hb(1, 1, "1 B")
    hb(1, 2, "1 B")
    hb(1, 3, "1 B")
    hb(1024, 0, "1 kB")
    hb(1024, 1, "1.0 kB")
    hb(1024 * 123, 1, "123.0 kB")
    hb(1024 * 12342, 1, "12.1 MB")
    hb(1024 * 12342, 2, "12.05 MB")

# Generated at 2022-06-23 20:21:05.061428
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime
    from email.utils import formatdate
    now = datetime(year=2019, month=8, day=12, hour=15, minute=48, second=54)
    now_as_string = formatdate(timeval=now.timestamp(), localtime=True)

# Generated at 2022-06-23 20:21:09.376837
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def _test(n, expected):
        actual = humanize_bytes(n)
        assert expected == actual
    _test(0, '0 B')
    _test(1, '1 B')
    _test(1024, '1.0 kB')
    _test(45678, '44.5 kB')
    _test(1234567, '1.2 MB')
    _test(4567890123, '4.3 GB')
    _test(1234567890123, '1.1 TB')
    _test(45678901234567890, '4.0 PB')

# Generated at 2022-06-23 20:21:17.128680
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '''
        {
            "first": 1,
            "second": 2,
            "third": 3
        }
    '''
    print("original json string:")
    print(json_string)
    d = load_json_preserve_order(json_string)
    print("preserved order version: ", d)
    assert d.keys() == ['first', 'second', 'third']
    assert list(d.values()) == [1, 2, 3]

# Generated at 2022-06-23 20:21:27.200055
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:21:32.271337
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
    {
        "a": 1,
        "b": 2,
        "d": 2,
        "c": 3
    }
    """
    d = load_json_preserve_order(s)
    assert d.keys() == ['a', 'b', 'd', 'c']

# Generated at 2022-06-23 20:21:33.656050
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth

# Generated at 2022-06-23 20:21:39.327406
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = """
    {
        "one": 1,
        "two": 2,
        "three": 3
    }
    """
    json = load_json_preserve_order(json_str)
    assert json['one'] == 1
    assert json['two'] == 2
    assert json['three'] == 3

# Generated at 2022-06-23 20:21:40.339917
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:21:44.891419
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2, 'c': 3}
    assert repr_dict(d) == "{\n    'a': 1,\n    'b': 2,\n    'c': 3\n}"

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 20:21:46.925590
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()

    assert isinstance(a, requests.auth.AuthBase)


# Generated at 2022-06-23 20:21:50.269986
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    A Method object's ``__call__`` method returns the object
    <https://docs.python.org/3/reference/datamodel.html#object.__call__>.

    """
    expected = ExplicitNullAuth()
    assert ExplicitNullAuth.__call__(expected) is expected



# Generated at 2022-06-23 20:21:53.134578
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.html") == "text/html"
    assert get_content_type("test.png") == "image/png"
    assert get_content_type("test") is None

# Generated at 2022-06-23 20:22:00.836008
# Unit test for function get_expired_cookies