

# Generated at 2022-06-23 20:11:56.576129
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert '12.1 MB' == humanize_bytes(1024*12342, precision=1)

# Generated at 2022-06-23 20:11:57.367444
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()({})

# Generated at 2022-06-23 20:12:06.325720
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:12:12.082636
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Test for a regular json string
    test_str = '[{"a": 1, "b": 2}]'
    test_dict = load_json_preserve_order(test_str)
    assert test_dict == [{'a': 1, 'b': 2}]

    # Test for a json string with different order
    test_str2 = '[{"b": 2, "a": 1}]'
    test_dict2 = load_json_preserve_order(test_str2)
    assert test_dict2 == [{'a': 1, 'b': 2}]

    # Test for a regular json string
    test_str3 = '{"a": 1, "b": 2}'
    test_dict3 = load_json_preserve_order(test_str3)

# Generated at 2022-06-23 20:12:19.392229
# Unit test for function get_content_type
def test_get_content_type():
    from pytest import raises

    with raises(TypeError):
        get_content_type('application/json', 'image/png')
    with raises(TypeError):
        get_content_type(42, 24)

    assert get_content_type('/usr/share/pixmaps/debian-logo.png') == 'image/png'
    assert get_content_type('/etc/passwd') == 'text/plain'
    assert get_content_type('/etc/issue') == 'text/plain'
    assert get_content_type('/usr/share/man/man1/perl.1.gz') == 'application/x-gzip'
    assert get_content_type('/usr/share/man/man1/perl.1.gz', strict=True) is None



# Generated at 2022-06-23 20:12:23.056208
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({"key1": ["value1"], "key2": ["value2", "value3"]}) == \
           "{\'key1\': [\'value1\'], \'key2\': [\'value2\', \'value3\']}"

# Generated at 2022-06-23 20:12:31.767192
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise AssertionError
    if humanize_bytes(1024, precision=1) != '1.0 kB':
        raise AssertionError
    if humanize_bytes(1024 * 123, precision=1) != '123.0 kB':
        raise AssertionError
    if humanize_bytes(1024 * 12342, precision=1) != '12.1 MB':
        raise AssertionError
    if humanize_bytes(1024 * 12342, precision=2) != '12.05 MB':
        raise AssertionError
    if humanize_bytes(1024 * 1234, precision=2) != '1.21 MB':
        raise AssertionError

# Generated at 2022-06-23 20:12:37.865339
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    >>> test_load_json_preserve_order()
    """
    json_str = '{"1":2,"3":4}'
    assert load_json_preserve_order(json_str) == {'1': 2, '3': 4}

    json_str = '{"3":4,"1":2}'
    assert load_json_preserve_order(json_str) == OrderedDict([('3', 4), ('1', 2)])



# Generated at 2022-06-23 20:12:42.500640
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a":1, "b":2}'
    d = load_json_preserve_order(s)
    assert 'a' in d.keys()
    assert 'b' in d.keys()
    assert d['a'] == 1
    assert d['b'] == 2

# Generated at 2022-06-23 20:12:45.290829
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth

# Generated at 2022-06-23 20:12:46.204878
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:12:48.452901
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    src = """
    {"a": 1, "b": 2, "c": 3}
    """
    expected = OrderedDict([("a", 1), ("b", 2), ("c", 3)])
    result = load_json_preserve_order(src)
    assert result == expected

# Generated at 2022-06-23 20:12:55.976651
# Unit test for function humanize_bytes

# Generated at 2022-06-23 20:12:59.087422
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict({1: 2}) == "{1: 2}"
    assert repr_dict({1: {1: 2}}) == "{1: {1: 2}}"

# Generated at 2022-06-23 20:13:07.255407
# Unit test for function repr_dict
def test_repr_dict():
    """Test for ``repr_dict()``."""
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({'a': None}) == "{'a': None}"
    assert repr_dict({'a': [1, 2, 3]}) == "{'a': [1, 2, 3]}"
    assert repr_dict({'a': ['b', 'c']}) == "{'a': ['b', 'c']}"
    assert repr_dict({'a': {'b': 'c'}}) == "{'a': {'b': 'c'}}"


# Generated at 2022-06-23 20:13:15.960159
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    from datetime import datetime, timedelta
    from time import mktime
    from http.cookiejar import CookieJar

    now = time.time()

# Generated at 2022-06-23 20:13:17.693176
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1)) == "{'a': 1}"

# Generated at 2022-06-23 20:13:21.783278
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"b": 2, "a": 1}'
    assert list(load_json_preserve_order(s)) == ['b', 'a']

# Generated at 2022-06-23 20:13:24.464547
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Arrange
    :return:
    """
    return ExplicitNullAuth()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:13:27.938913
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    data=load_json_preserve_order('{"foo": 1, "bar": 2, "baz": 3}')
    assert(data["foo"] == 1)
    assert(data["bar"] == 2)
    assert(data["baz"] == 3)

# Generated at 2022-06-23 20:13:39.155902
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies(
        [
            ('Set-Cookie',
             'foo=bar; '
             'expires=Thu, 29 Mar 2018 18:00:05 GMT; '
             'Max-Age=3600; '
             'samesite=strict; '
             'httponly'),
            ('Set-Cookie',
             'foo2=bar2; '
             'expires=Thu, 29 Mar 2018 18:00:05 GMT; '
             'Max-Age=3600; '
             'samesite=strict; '
             'httponly')
        ],
        now=time.time(),
    )
    assert cookies == [
        {'name': 'foo', 'path': '/'},
        {'name': 'foo2', 'path': '/'}
    ]

# Generated at 2022-06-23 20:13:42.343462
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    >>> auth = ExplicitNullAuth()
    >>> request = requests.Request('GET', 'http://test.test')
    >>> prep_request = auth(request)

    >>> prep_request.prepare()
    >>> prep_request.url
    'http://test.test'

    """

# Generated at 2022-06-23 20:13:47.720167
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"b": 1, "a": 2}') == {"b": 1, "a": 2}
    assert load_json_preserve_order('{"b": 1, "a": 2}') != {"a": 2, "b": 1}

# Generated at 2022-06-23 20:13:50.183822
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import types

    a = ExplicitNullAuth()
    r = object()
    r2 = a(r)
    assert isinstance(r2, types.GeneratorType)

# Generated at 2022-06-23 20:14:00.688485
# Unit test for method __call__ of class ExplicitNullAuth

# Generated at 2022-06-23 20:14:03.144034
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1, b=1)) == "{'a': 1, 'b': 1}"



# Generated at 2022-06-23 20:14:05.987208
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_obj = OrderedDict()
    test_obj['name'] = 'test_obj'
    test_obj['age'] = 45
    test_obj['sex'] = 'F'
    test_str = json.dumps(test_obj)
    loaded_obj = load_json_preserve_order(test_str)
    assert test_obj == loaded_obj

# Generated at 2022-06-23 20:14:10.886835
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({1: 2}) == '{1: 2}'
    od = OrderedDict([(1, 2), (3, 4)])
    assert repr_dict(od) == 'OrderedDict([(1, 2), (3, 4)])'

# Generated at 2022-06-23 20:14:16.257989
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import PreparedRequest

    class MockPreparedRequest(PreparedRequest):
        def __init__(self, *args, **kwargs):
            super(MockPreparedRequest, self).__init__(*args, **kwargs)
            self.prepare_auth = lambda: self

    req = MockPreparedRequest()

    obj = ExplicitNullAuth()
    value = obj(req)

    assert value is req

# Generated at 2022-06-23 20:14:27.467476
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json
    import random
    random.seed(0)
    src = {
        'a': 'a', 
        'c': 'c', 
        'e': 'e', 
        'b': 'b', 
        'd': 'd', 
        'f': 'f'
    }
    src_key_list = list(src.keys())
    random.shuffle(src_key_list)
    shuffled = {k: src[k] for k in src_key_list}
    dumped = json.dumps(shuffled)
    restored = load_json_preserve_order(dumped)
    assert len(restored) == len(src)
    assert all(x in restored for x in src)

# Generated at 2022-06-23 20:14:30.601574
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        "foo": {"bar": "baz"},
        "baz": "foo",
    }

    assert repr_dict(d) == "{'foo': {'bar': 'baz'}, 'baz': 'foo'}"

# Generated at 2022-06-23 20:14:40.192087
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timezone
    from http.cookies import CookieError, SimpleCookie
    from time import time

    tz = timezone.utc
    now = datetime.now(tz)
    now_timestamp = time()

    cookie_factory = SimpleCookie()


# Generated at 2022-06-23 20:14:40.727582
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:14:41.383323
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:14:50.336211
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    f = get_expired_cookies

    now = time.time()
    cookie_name = 'mycookie'
    cookie_value = 'mycookievalue'


# Generated at 2022-06-23 20:14:56.347608
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:01.110510
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.srt') == 'text/plain'
    assert get_content_type('foo.roq') == 'video/x-roq'
    assert get_content_type('foo.flac') == 'audio/flac'

# Generated at 2022-06-23 20:15:04.022622
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    >>> requests.get('https://httpbin.org/get',
    ...     auth=ExplicitNullAuth()).text  # doctest: +ELLIPSIS
    '{...}\\n'
    """

# Generated at 2022-06-23 20:15:08.375608
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    d = load_json_preserve_order('{"foo": "bar", "baz": "qux"}')
    assert d.get('foo') == 'bar'
    assert d.get('baz') == 'qux'
    assert list(d.keys()) == ['foo', 'baz']



# Generated at 2022-06-23 20:15:09.956850
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert 'a' == list(load_json_preserve_order('{"b": "c", "a": "d"}').keys())[0]

# Generated at 2022-06-23 20:15:13.485919
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    def assert_auth_does_nothing(auth: requests.auth.AuthBase, r):
        r2 = auth(r)
        assert r2 is r, f"{r!r} v {r2!r} should be the same"

    # Test that the `auth` does nothing
    assert_auth_does_nothing(None, None)
    assert_auth_does_nothing(ExplicitNullAuth(), None)

# Generated at 2022-06-23 20:15:20.046085
# Unit test for function repr_dict
def test_repr_dict():
    # Given an empty dict
    d = {}
    # When repr_dict is called
    # Then it returns an empty string
    assert repr_dict(d) == '{}'

    # Given a dict with an entry 'a' to 1
    d = {'a': 1}
    # When repr_dict is called
    # Then it returns the correct string representation
    assert repr_dict(d) == "{'a': 1}"

# Generated at 2022-06-23 20:15:23.903552
# Unit test for function repr_dict
def test_repr_dict():
    from pprint import pformat
    assert repr_dict(dict(a=1, b=2)) == pformat(dict(a=1, b=2))
    assert repr_dict(dict(b=2, a=1)) == pformat(dict(a=1, b=2))

# Generated at 2022-06-23 20:15:25.277433
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('some/path.txt') == 'text/plain'

# Generated at 2022-06-23 20:15:31.774632
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'session-cookie=123; path=/'),
        ('Set-Cookie', 'login-token=abc; expires=Fri, 13-Jan-2021 22:23:01 GMT'),
        ('Set-Cookie', 'logged-in=1; max-age=2678400; path=/'),
        ('Set-Cookie', 'logged-out=1; expires=Thu, 01-Jan-1970 00:00:00 GMT'),
    ]

    assert get_expired_cookies(headers, now=time.mktime(time.strptime('2020-01-10', '%Y-%m-%d'))) == [
        {
            'name': 'logged-out',
            'path': '/'
        }
    ]


# Generated at 2022-06-23 20:15:35.837537
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    unordered_json_string = '{"b": "2", "a": "1"}'
    ordered_json_string = '{"a": "1", "b": "2"}'
    assert load_json_preserve_order(unordered_json_string) == json.loads(ordered_json_string)

# Generated at 2022-06-23 20:15:38.845458
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({
        'a': 1,
        'b': 2,
        'c': [],
    }) == "{'a': 1, 'b': 2, 'c': []}"

# Generated at 2022-06-23 20:15:39.429260
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:15:41.145533
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__({}) is None

# Generated at 2022-06-23 20:15:44.654659
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    from os.path import dirname, join
    s = open(join(dirname(__file__), 'test_data', 'covid_sample_request.json')).read()
    d = load_json_preserve_order(s)
    assert d['headers']['Content-Type'] == 'application/json'

# Generated at 2022-06-23 20:15:55.813144
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1486056851.345286
    headers = [
        ('Set-Cookie', 'sessionid=abc; expires=Sat, 28-Jan-2017 '
                       ' 09:55:55 GMT'),
        ('Set-Cookie', 'sessionid_persistent=abc; expires=Sat, 28-Jan-2017 '
                       ' 09:55:55 GMT'),
        ('Set-Cookie', 'csrftoken=abc; max-age=604800; expires=Sat, 04-Feb-2017 '
                       ' 09:55:51 GMT; Path=/'),
    ]
    expired = [
        {'name': 'sessionid', 'path': '/'},
        {'name': 'sessionid_persistent', 'path': '/'},
    ]
    assert get_expired_cookies(headers) == expired

# Generated at 2022-06-23 20:16:04.434571
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    from copy import deepcopy

    json_data = {
        'hi': 'bye',
        'a': 1,
        'b': 1,
        'c': 3,
    }
    json_data_preserved_order = deepcopy(json_data)
    # Make sure original json doesn't change
    json_data_orders_changed = json_data

    # Check that order is preserved
    assert load_json_preserve_order(json_data_preserved_order) == json_data_preserved_order

    # Change the order
    json_data_orders_changed['d'] = 'hello'
    json_data_orders_changed['e'] = 'world'

    # Check that order is preserved
    assert load_json_preserve_order(json_data_orders_changed) == json_data

# Generated at 2022-06-23 20:16:09.745788
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.models import Request

    request = Request(
        url='http://arxiv.org',
        headers={'X-Any-Header': 'xyz'},
    )
    auth = ExplicitNullAuth()
    request = auth(request)

    assert request.headers['X-Any-Header'] == 'xyz'


if __name__ == '__main__':
    import pytest

    pytest.main(['-v', __file__])

# Generated at 2022-06-23 20:16:14.504008
# Unit test for function repr_dict
def test_repr_dict():
    d = {'b': 'y\\u1234',
         'a': [1, 2, 3, {'c': 3, 'd': 4}]
         }
    assert repr_dict(d) == "{'b': 'y\\\\u1234', 'a': [1, 2, 3, {'c': 3, 'd': 4}]}"

# Generated at 2022-06-23 20:16:17.453473
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    ExplicitNullAuth: ``__call__`` returns ``r``

    """
    obj = ExplicitNullAuth()
    r = object()
    assert obj.__call__(r) is r

# Generated at 2022-06-23 20:16:21.805316
# Unit test for function repr_dict
def test_repr_dict():
    T = {}
    assert repr_dict(T) == '{}'
    T.update(a=1)
    assert repr_dict(T) == "{'a': 1}"
    T.update(b=2)
    assert repr_dict(T) == "{'a': 1, 'b': 2}"


# Generated at 2022-06-23 20:16:28.436556
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo') is None
    assert get_content_type('foo.txt.zip')

# Generated at 2022-06-23 20:16:30.606323
# Unit test for function repr_dict
def test_repr_dict():
    data = {'a': 1, 'b': 'hello'}
    assert repr_dict(data) == "{'a': 1, 'b': 'hello'}"

# Generated at 2022-06-23 20:16:31.125614
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:16:36.504007
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo/bar/baz.html') == 'text/html'
    assert get_content_type('foo/bar/baz.txt') == 'text/plain'
    assert get_content_type('foo/bar/baz.xml') == \
        'application/xml; charset=us-ascii'
    assert get_content_type('foo/bar/baz.css') == 'text/css; charset=us-ascii'
    assert not get_content_type('foo/bar/baz.foobar')


# Test the extension is picked up by pytest

# Generated at 2022-06-23 20:16:42.357435
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'name="value"; Max-Age=1; Secure; HttpOnly; Path=/'),
        ('Set-Cookie', 'foo=bar; Expires=Fri, 28 Jul 2017 07:16:14 GMT; SameSite=None; Secure; HttpOnly; Path=/'),
        ('Set-Cookie', 'foo2=bar2; Expires=Fri, 28 Jul 2017 07:16:14 GMT; SameSite=None; Secure; HttpOnly; Path=/'),
    ]
    cookies = get_expired_cookies(headers=headers, now=time.time())
    assert len(cookies) == 2
    assert cookies[0].get('name') == 'foo'
    assert cookies[0].get('path') == '/'
    assert cookies[1].get('name') == 'foo2'


# Generated at 2022-06-23 20:16:42.855848
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:16:54.970510
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'cookie01=value01; Max-Age=5; Path=/'),
        ('Set-Cookie', 'cookie02=value02; Path=/'),
        ('Set-Cookie', 'cookie03=value03; Max-Age=5; Path=/'),
        ('Set-Cookie', 'cookie04=value04; Max-Age=0; Path=/'),
        ('Set-Cookie', 'cookie05=value05; Expires=Wed, 23 Jan 2019 17:14:43 GMT; Max-Age=5; Path=/'),
    ]

    cookies = get_expired_cookies(headers=[])
    assert len(cookies) == 0

    cookies = get_expired_cookies(headers=headers)
    assert len(cookies) == 1

# Generated at 2022-06-23 20:16:58.618416
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'foo': 'bar', 'baz': 'qux'}) == "{'foo': 'bar', 'baz': 'qux'}"

# Generated at 2022-06-23 20:17:07.348013
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now_expires_test = time.time()
    header = [
        ('Set-Cookie', 'test1=foo; Domain=.test.com; Path=/'),
        ('Set-Cookie', 'test2=bar; Domain=.test.com; Max-Age=5; Path=/'),
        ('Set-Cookie', 'test3=baz; Domain=.test.com; Expires=Wed, 21 Oct 2015 07:28:00 GMT; Path=/')
    ]

    expired_cookies = get_expired_cookies(header, now_expires_test)
    expired_cookies_expected = [{'name': 'test2', 'path': '/'}]
    assert expired_cookies == expired_cookies_expected

# Generated at 2022-06-23 20:17:14.301749
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:17:24.827360
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=b; Max-Age=10; Path=/'),
        ('Set-Cookie', 'c=d; Expires=Sun, 10 Mar 2019 12:06:54 GMT; Path=/'),
        ('Set-Cookie', 'e=f; Expires=Sun, 10 Mar 2019 12:06:40 GMT; Path=/')
    ]
    now = time.mktime(time.strptime('Sun, 10 Mar 2019 12:06:50 GMT', '%a, %d %b %Y %H:%M:%S %Z'))   # NOQA
    result = get_expired_cookies(headers, now)
    assert result == [{'name': 'e', 'path': '/'}]



# Generated at 2022-06-23 20:17:27.473984
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth_class = ExplicitNullAuth()
    assert auth_class.__class__.__name__ == 'ExplicitNullAuth'


# Generated at 2022-06-23 20:17:32.598074
# Unit test for function get_content_type
def test_get_content_type():
    """
    >>> get_content_type('file.jpg')
    'image/jpeg'

    >>> get_content_type('file.unknown') is None
    True

    >>> get_content_type('file.json')
    'application/json; charset=utf-8'

    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:17:42.691189
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:17:45.373696
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.jpg') == 'image/jpeg'
    assert get_content_type('file.foo') is None

# Generated at 2022-06-23 20:17:57.445683
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:18:05.472622
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    expired_cookie = 'cookiename=value; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT'
    non_expired_cookie = 'cookiename2=value2; Path=/; Expires=Tue, 01 Jan 2030 00:00:00 GMT'
    expired_cookie_without_expires = 'cookiename3=value3; Path=/; Max-Age=0'
    non_expired_cookie_without_expires = 'cookiename4=value4; Path=/; Max-Age=3000000'


# Generated at 2022-06-23 20:18:12.409598
# Unit test for function humanize_bytes
def test_humanize_bytes():
    test_cases = [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
        (1024 * 1234 * 1111, '1.3 GB'),
    ]
    for i, expected in test_cases:
        result = humanize_bytes(i)
        assert result == expected

# Generated at 2022-06-23 20:18:21.959263
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.bar') is None
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt; charset=ASCII') == 'text/plain; charset=ASCII'
    assert get_content_type('foo.txt; other=ASCII') == 'text/plain; other=ASCII'
    assert get_content_type('foo.txt; charset=ASCII; other=ASCII') == 'text/plain; charset=ASCII; other=ASCII'


__all__ = [
    'ExplicitNullAuth',
    'humanize_bytes',
    'load_json_preserve_order',
    'repr_dict',
]

# Generated at 2022-06-23 20:18:30.242070
# Unit test for function repr_dict
def test_repr_dict():
    d1 = {'a': 1, 'b': 2, 'c': 3}
    assert repr_dict(d1) == "{'a': 1, 'b': 2, 'c': 3}"

    d2 = {'a': 1}
    assert repr_dict(d2) == "{'a': 1}"

    d3 = {'c': 3}
    assert repr_dict(d3) == "{'c': 3}"

    d4 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert repr_dict(d4) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"

    d5 = dict()
    assert repr_dict(d5) == "{}"

# Generated at 2022-06-23 20:18:35.428897
# Unit test for function get_content_type
def test_get_content_type():
    assert (get_content_type('/tmp/image.jpg') ==
            'image/jpeg')
    assert (get_content_type('/tmp/image.jpeg') ==
            'image/jpeg')
    assert (get_content_type('/tmp/image.bmp') ==
            'image/bmp')
    assert (get_content_type('/tmp/image.gif') ==
            'image/gif')
    assert (get_content_type('/tmp/image.png') ==
            'image/png')
    assert (get_content_type('/tmp/image.tif') ==
            'image/tiff')
    assert (get_content_type('/tmp/image.tiff') ==
            'image/tiff')


# Generated at 2022-06-23 20:18:36.482885
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(None) is None

# Generated at 2022-06-23 20:18:37.992276
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert callable(auth)

# Generated at 2022-06-23 20:18:47.648041
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('shopping.pdf') == 'application/pdf'
    assert get_content_type('image.png') == 'image/png'
    assert get_content_type('doc.gz') == 'application/x-gzip'
    assert get_content_type('doc.tar.gz') == 'application/x-gzip'
    assert get_content_type('doc.tgz') == 'application/x-gzip'
    assert get_content_type('doc.tar.xz') == 'application/x-xz'
    assert get_content_type('doc.zip') == 'application/zip'
    assert get_content_type('doc.mp3') == 'audio/mpeg'
    assert get_content_type('doc.jpeg') == 'image/jpeg'

# Generated at 2022-06-23 20:18:52.193267
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = ('{"a": 12, "b": 34, "c": 56, "d": 78, "e": 90, "f": 123, "g": 456, '
         '"h": 789}')
    d = load_json_preserve_order(s)
    assert list(d.keys()) == ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
    assert list(d.values()) == [12, 34, 56, 78, 90, 123, 456, 789]



# Generated at 2022-06-23 20:19:01.079512
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:19:10.900100
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:19:13.878463
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order("""{"a": 1, "b": 2}""") == {"a": 1, "b": 2}

# Generated at 2022-06-23 20:19:19.875802
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; expires=Tue, 28 May 2019 18:58:51 GMT'),
        ('Set-Cookie', 'foo=baz; max-age=31536000; Path=/'),
    ]

    expected = [
        {'name': 'foo', 'path': '/'},
    ]
    assert get_expired_cookies(headers, now=time.time() + 100) == expected
    assert get_expired_cookies(headers, now=time.time()) == []

# Generated at 2022-06-23 20:19:21.697788
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(a=1, b=2, c=3)
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-23 20:19:23.472869
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2, "c": 3}'
    assert load_json_preserve_order(s) == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-23 20:19:27.112957
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('something.txt') == 'text/plain'
    assert get_content_type('something.TXT') == 'text/plain'
    assert get_content_type('something.tar.gz') == 'application/x-compressed-tar'
    assert get_content_type('something.json') == 'application/json'



# Generated at 2022-06-23 20:19:36.105870
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-23 20:19:44.873717
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now_ts = 1575464391.2260165

# Generated at 2022-06-23 20:19:48.819118
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Request's ``parse_ns_headers`` does a poor job parsing cookies, but
    # should be sufficient for simple cases like this.
    assert get_expired_cookies([
        ('Set-Cookie', 'foo=bar; Max-Age=0; Path=/'),
        ('Set-Cookie', 'baz=qux; Max-Age=100; Path=/'),
    ]) == [
        {'name': 'foo', 'path': '/'}
    ]



# Generated at 2022-06-23 20:19:50.356743
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 2, 'b': 3}) == "{'a': 2, 'b': 3}"

# Generated at 2022-06-23 20:19:59.968533
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:20:06.873231
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([
        ('set-cookie', 'a=1'),
        ('set-cookie', 'b=2; max-age=60; expires=Fri, 06-Jul-2018 18:20:02 GMT'),
        ('set-cookie', 'c=3; max-age=0; expires=Fri, 06-Jul-2018 18:20:10 GMT'),
        ('set-cookie', 'd=4; max-age=-60; expires=Fri, 06-Jul-2018 18:20:20 GMT'),
        ('set-cookie', 'e=5; max-age=60; expires=Fri, 06-Jul-2098 18:20:30 GMT'),
    ], now=1530955200)

# Generated at 2022-06-23 20:20:18.344267
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest

    # noinspection PyUnresolvedReferences
    from . import test_data

    def cookie_names(cookies) -> List[str]:
        return [cookie['name'] for cookie in cookies]

    cookiedata1 = test_data.COOKIEJAR_TESTS[0]
    cookies1 = get_expired_cookies(cookiedata1['headers'])
    assert cookie_names(cookies1) == ['csrftoken']

    cookiedata2 = test_data.COOKIEJAR_TESTS[1]
    cookies2 = get_expired_cookies(cookiedata2['headers'])
    assert cookie_names(cookies2) == ['csrftoken']


# Generated at 2022-06-23 20:20:26.874303
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from os import getenv
    from os.path import expanduser

    from requests.auth import HTTPDigestAuth, HTTPBasicAuth
    from requests.cookies import RequestsCookieJar
    from requests import Request

    from requests_mock import Adapter

    def implicitly_authenticate(Request: Request):
        Request.prepare()
        Request.prepare_auth(implicitly_authenticate)
        Request.prepare_cookies(ImplicitlyRequestsCookieJar())
        Request.prepare_hooks(response=None)

        # At this point, these properties should have a value.
        assert Request.auth

    def ExplicitNullAuth_works_as_expected(Request: Request):
        Request.prepare()
        Request.prepare_auth()

# Generated at 2022-06-23 20:20:27.711193
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not ExplicitNullAuth()

# Generated at 2022-06-23 20:20:36.000362
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == "1 B"
    assert humanize_bytes(0) == "0 B"
    assert humanize_bytes(1024) == "1.0 kB"
    assert humanize_bytes(1024*123) == "123.0 kB"
    assert humanize_bytes(1024*12342) == "12.1 MB"
    assert humanize_bytes(1024*12342,2) == "12.05 MB"
    assert humanize_bytes(1024*1234,2) == "1.21 MB"
    assert humanize_bytes(1024*1234*1111,2) == "1.31 GB"
    assert humanize_bytes(1024*1234*1111,1) == "1.3 GB"

# Generated at 2022-06-23 20:20:45.892442
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(2) == '2 B'
    assert humanize_bytes(2, precision=1) == '2.0 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-23 20:20:47.917124
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "{}"
    assert repr_dict({"a": "b"}) == "{'a': 'b'}"



# Generated at 2022-06-23 20:20:52.051809
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    r = requests.Request(
        method='GET',
        url='https://httpbin.org/get'
    )
    r.prepare()
    r = requests.Session().send(
        r,
        auth=ExplicitNullAuth()
    )
    assert r.status_code == 200
    assert r.json()['headers']['Authorization'] is None

# Generated at 2022-06-23 20:20:53.930833
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert isinstance(a, ExplicitNullAuth)

# Generated at 2022-06-23 20:21:01.438575
# Unit test for function humanize_bytes
def test_humanize_bytes():
    print(humanize_bytes(1))
    print(humanize_bytes(1024, precision=1))
    print(humanize_bytes(1024 * 123, precision=1))
    print(humanize_bytes(1024 * 12342, precision=1))
    print(humanize_bytes(1024 * 12342, precision=2))
    print(humanize_bytes(1024 * 1234, precision=2))
    print(humanize_bytes(1024 * 1234 * 1111, precision=2))
    print(humanize_bytes(1024 * 1234 * 1111, precision=1))


# Generated at 2022-06-23 20:21:09.169720
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('my/file.txt') == 'text/plain'
    assert get_content_type('my/file.html') == 'text/html'
    assert get_content_type('my/file.json') == 'application/json'
    assert get_content_type('my/file.pdf') == 'application/pdf'
    assert get_content_type('my/file.zip') == 'application/zip'
    assert get_content_type('my/file.doc') == 'application/msword'
    assert get_content_type('my/file.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    assert get_content_type('my/file.xls') == 'application/vnd.ms-excel'
    assert get_content_

# Generated at 2022-06-23 20:21:14.439741
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 0.1, 'aa': True, 'aaa': '0.1', 'aaaa': None}
    assert repr_dict(d) == "{'a': 0.1, 'aa': True, 'aaa': '0.1', 'aaaa': None}"

# Generated at 2022-06-23 20:21:25.418367
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def cookie_from_attrs(attrs):
        # attrs is a list of tuples
        return dict(attrs, name=attrs[0][0])


# Generated at 2022-06-23 20:21:32.140756
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import unittest.mock

# Generated at 2022-06-23 20:21:34.735719
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('text.txt') == 'text/plain'
    assert get_content_type('text.xyz') is None

# Generated at 2022-06-23 20:21:39.691428
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 42, 'c': [1, 3]}
    r = repr_dict(d)
    assert isinstance(r, str)
    assert r == "{'a': 1, 'b': 42, 'c': [1, 3]}"

# Generated at 2022-06-23 20:21:47.996037
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


test_humanize_bytes()

# Generated at 2022-06-23 20:21:49.684991
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth_instance = ExplicitNullAuth()
    assert auth_instance is not None

# Generated at 2022-06-23 20:21:52.842543
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():  # pragma: no cover
    from requests.auth import NullAuth

    auth = ExplicitNullAuth()
    assert type(auth) == ExplicitNullAuth
    assert auth._auth == NullAuth()
    assert auth == NullAuth()

# Generated at 2022-06-23 20:21:54.138266
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.html') == 'text/html'



# Generated at 2022-06-23 20:21:56.891805
# Unit test for function repr_dict
def test_repr_dict():
    a = {'some': 'dict'}
    assert (repr_dict(a) == '{\'some\': \'dict\'}')

