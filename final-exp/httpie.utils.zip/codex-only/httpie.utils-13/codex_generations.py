

# Generated at 2022-06-23 20:11:51.086887
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.json') == 'application/json'

# Generated at 2022-06-23 20:11:53.665261
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"foo": [1,2,3]}') == \
           OrderedDict([("foo", [1, 2, 3])])

# Generated at 2022-06-23 20:11:56.095448
# Unit test for function get_content_type
def test_get_content_type():
    filename = './tests/data/example.json'
    ctype = get_content_type(filename)
    assert ctype == 'application/json'


# Generated at 2022-06-23 20:11:57.583109
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('requirements.txt') == 'text/plain'
    assert get_content_type('non_existent_file.txt') is None

# Generated at 2022-06-23 20:12:00.368401
# Unit test for function repr_dict
def test_repr_dict():
    input_ = {'a': 1, 'b': 2}
    expected = "{\n    'a': 1,\n    'b': 2\n}"
    result = repr_dict(input_)
    assert result == expected

# Generated at 2022-06-23 20:12:02.839869
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:12:05.216536
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/path/to/file.txt') == 'text/plain'

    assert (
        get_content_type('/path/to/file.txt;charset=utf-8') ==
        'text/plain; charset=utf-8'
    )

# Generated at 2022-06-23 20:12:14.200487
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # noinspection PyUnusedLocal
    def hb(n, result):
        return result == humanize_bytes(n)

    assert hb(1, '1 B')
    assert hb(10, '10 B')
    assert hb(100, '100 B')
    assert hb(1000, '1000 B')
    assert hb(2000, '2000 B')
    assert hb(10000, '9.77 kB')
    assert hb(20000, '19.5 kB')
    assert hb(100000, '97.7 kB')
    assert hb(200000, '195 kB')
    assert hb(1000000, '976.6 kB')
    assert hb(2000000, '1.95 MB')
    assert hb(10000000, '9.54 MB')


# Generated at 2022-06-23 20:12:15.076034
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert a is not None


# Generated at 2022-06-23 20:12:16.639452
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename='test.txt') == 'text/plain'
    assert get_content_type(filename='test.html') == 'text/html'

# Generated at 2022-06-23 20:12:23.754948
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        "Str": "Yes",
        "Int": 1,
        "Float": 1.1,
        "Bool": True,
        "Nested": {
            "Str": "Yes",
            "Int": 1,
            "Float": 1.1,
            "Bool": True,
        }
    }
    r = repr_dict(d)

# Generated at 2022-06-23 20:12:32.910464
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """This is the code originally used to test the function.
    assert load_json_preserve_order('[1, 2, 3]') == [1, 2, 3]
    assert load_json_preserve_order('{"a": "b"}') == {'a': 'b'}
    assert load_json_preserve_order('{"a": "b", "c": "d"}') == {'a': 'b', 'c': 'd'}
    assert load_json_preserve_order('{"a": "b", "c": "d", "e": ["f", "g"]}') == {
        'a': 'b',
        'c': 'd',
        'e': ['f', 'g']
    }
    """
    assert load_json_preserve_order('[1, 2, 3]')

# Generated at 2022-06-23 20:12:35.642295
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str1 = '{"one": 2, "two": 3}'
    json_str2 = '{"two": 3, "one": 2}'

    assert load_json_preserve_order(json_str1) == load_json_preserve_order(json_str2), 'Loaded JSON should not differ due to order of keys'

# Generated at 2022-06-23 20:12:37.281292
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:12:40.883457
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([('Set-Cookie', 'foo=bar; max-age=60')])
    assert cookies == [{'name': 'foo', 'path': '/'}]

# Generated at 2022-06-23 20:12:42.692124
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:12:46.873802
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    data = load_json_preserve_order('{"b": 2, "a": 1}')
    assert list(data.keys()) == ['b', 'a']

# Generated at 2022-06-23 20:12:52.347962
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict(OrderedDict()) == '{}'
    assert repr_dict(OrderedDict([('a', 1), ('b', 2)])) == \
        "OrderedDict([('a', 1), ('b', 2)])"
    assert repr_dict({'a': {1, 2}, 'b': 'zzz'}) == \
        "{'a': {1, 2}, 'b': 'zzz'}"

# Generated at 2022-06-23 20:12:54.146980
# Unit test for function get_content_type
def test_get_content_type():

    result = get_content_type('./test_get_content_type.test')
    assert result == 'application/x-test'

# Generated at 2022-06-23 20:13:02.261722
# Unit test for function repr_dict

# Generated at 2022-06-23 20:13:13.605853
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import timedelta
    from time import time

    my_now = time()
    headers = [
        ('Set-cookie', 'a=1; Path=/; expires=Sun, 20 Jan 2019 20:11:13 GMT'),
        ('Set-cookie', 'b=1; Path=/; expires=Tue, 22 Jan 2019 20:11:13 GMT')
    ]
    assert get_expired_cookies(headers, now=my_now) == []
    my_now += timedelta(days=1).total_seconds()
    assert get_expired_cookies(headers, now=my_now) == [
        {'name': 'a', 'path': '/'}
    ]
    my_now += timedelta(days=2).total_seconds()

# Generated at 2022-06-23 20:13:15.899165
# Unit test for function repr_dict
def test_repr_dict():
    assert repr({"a": 1, "b": "2"}) == "{'a': 1, 'b': '2'}"
    assert repr_dict({"a": 1, "b": "2"}) == "{'a': 1, 'b': '2'}"

# Generated at 2022-06-23 20:13:18.095737
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename='foo') is None
    assert get_content_type(filename='foo.txt') == 'text/plain'
    assert get_content_type(filename='foo.txt.gz') == \
        'application/x-gzip'

# Generated at 2022-06-23 20:13:21.498470
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    assert repr_dict(d) == '{\n    \'a\': 1,\n    \'b\': 2,\n    \'c\': 3\n}'

# Generated at 2022-06-23 20:13:26.074750
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # noinspection PyArgumentList
    http_proxy = ExplicitNullAuth()

    # noinspection PyTypeChecker
    assert http_proxy is not None


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', '--tb=native', '--pyargs', 'headhunter.util'])

# Generated at 2022-06-23 20:13:28.213651
# Unit test for function repr_dict
def test_repr_dict():
    d = OrderedDict([('a', 'b'), ('c', 'd')])
    assert repr_dict(d) == "{'a': 'b', 'c': 'd'}"

# Generated at 2022-06-23 20:13:39.453185
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:13:42.461232
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': '1', 2: 3}
    exp = '{\'a\': \'1\', 2: 3}'
    actu = repr_dict(d)
    assert exp == actu


# Generated at 2022-06-23 20:13:49.970286
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import unittest

    import requests.auth


    class ExplicitNullAuthTestCase(unittest.TestCase):
        def test___call__(self):
            # Arrange
            instance = ExplicitNullAuth()

            # Act
            result = instance.__call__(None)

            # Assert
            self.assertIsInstance(result, requests.auth.AuthBase)
            self.assertIsNone(result.__self__)


    unittest.main()



# Generated at 2022-06-23 20:14:00.528688
# Unit test for function load_json_preserve_order

# Generated at 2022-06-23 20:14:05.940455
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = u'{"number": 46.2, "object": {"foo": "bar"}, "array": [1, 2, 3]}'
    obj = load_json_preserve_order(json_str)
    assert obj == OrderedDict([
        ('number', 46.2),
        ('object', OrderedDict([('foo', 'bar')])),
        ('array', [1, 2, 3]),
    ])

# Generated at 2022-06-23 20:14:17.013540
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:14:28.265018
# Unit test for function humanize_bytes
def test_humanize_bytes():

    # These tests come from the following page:
    # https://en.wikipedia.org/wiki/Kilobyte
    assert humanize_bytes(1000) == '1.00 kB'
    assert humanize_bytes(1023) == '1.02 kB'
    assert humanize_bytes(1024) == '1.02 kB'
    assert humanize_bytes(1025) == '1.02 kB'
    assert humanize_bytes(1048575) == '1023.99 kB'
    assert humanize_bytes(1048576) == '1.00 MB'
    assert humanize_bytes(1073741824) == '1.00 GB'
    assert humanize_bytes(1099511627776) == '1.00 TB'

# Generated at 2022-06-23 20:14:28.820359
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:14:38.641535
# Unit test for function repr_dict
def test_repr_dict():
    import unittest
    # TODO: Replace assertions by actual unit tests.
    json1 = {
        'a': 'hi',
        'b': 'there',
        'c': [1, 2, 3]
    }
    print(repr_dict(json1))
    assert repr_dict(json1) == "{'a': 'hi', 'b': 'there', 'c': [1, 2, 3]}"
    json2 = {'a': 'hi', 'b': [1, 2, 3], 'c': {'d': 'there'}}
    print(repr_dict(json2))
    assert repr_dict(json2) == "{'a': 'hi', 'b': [1, 2, 3], 'c': {'d': 'there'}}"

# Generated at 2022-06-23 20:14:41.958563
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    r = requests.get("http://httpbin.org/basic-auth/user/passwd",
                     auth=explicit_null_auth)
    assert r.status_code == 200


# Generated at 2022-06-23 20:14:47.036343
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json = '[{"k2" : "v2", "k1" : "v1"},{"k4" : "v4", "k3" : "v3"}]'
    expected = [{"k2" : "v2", "k1" : "v1"},{"k4" : "v4", "k3" : "v3"}]
    assert load_json_preserve_order(json) == expected

# Generated at 2022-06-23 20:14:49.707554
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == OrderedDict([('a', 1), ('b', 2)])
    assert load_json_preserve_order('1') == 1

# Generated at 2022-06-23 20:14:55.679545
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    r = requests.Request('GET', 'http://localhost/')
    x = ExplicitNullAuth()
    assert isinstance(x, requests.auth.AuthBase)
    _ = x(r)
    r = requests.Request('GET', 'http://localhost/')
    _ = x(r)
    assert not hasattr(x, 'host')
    assert not hasattr(x, 'request')
    assert not hasattr(x, 'response')



# Generated at 2022-06-23 20:14:58.595708
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    _ = ExplicitNullAuth()

# Generated at 2022-06-23 20:15:02.648371
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"a": 1, "b": 2}'
    dict = load_json_preserve_order(json_string)
    assert [item[0] for item in dict.items()] == ["a", "b"]
    assert [item[1] for item in dict.items()] == [1, 2]

# Generated at 2022-06-23 20:15:07.684350
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Example of input and output from this function
    s = '[{"b": 2, "a": 1}, {"b": 4, "a": 3}]'
    assert load_json_preserve_order(s) == [
        OrderedDict([("b", 2), ("a", 1)]),
        OrderedDict([("b", 4), ("a", 3)])
    ]

# Generated at 2022-06-23 20:15:11.152978
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    class MyRequest(object):
        def __init__(self, auth=None):
            self.auth = auth

    my_request_with_auth = MyRequest(auth=ExplicitNullAuth())
    assert my_request_with_auth.auth is not None



# Generated at 2022-06-23 20:15:11.687890
# Unit test for function humanize_bytes
def test_humanize_bytes():
    from doctest import testmod
    testmod()

# Generated at 2022-06-23 20:15:12.639538
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    e = ExplicitNullAuth()

# Generated at 2022-06-23 20:15:13.464105
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()({}) == {}

# Generated at 2022-06-23 20:15:19.522069
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(100) == '100 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-23 20:15:22.178207
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    if ExplicitNullAuth():
        print("test_ExplicitNullAuth: Authenication Passed")
    else:
        print("test_ExplicitNullAuth: Authenication Failed")

# Generated at 2022-06-23 20:15:23.596869
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    None
# vim: set expandtab shiftwidth=4 softtabstop=4:

# Generated at 2022-06-23 20:15:29.640988
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_data = [
        (b'"a"', b'a'),
        (b'{"a": 0, "b": 1}', b'{"a": 0, "b": 1}'),
        (b'{"b": 1, "a": 0}', b'{"a": 0, "b": 1}'),
    ]
    for d, expected in test_data:
        result = load_json_preserve_order(d)
        if not isinstance(result, OrderedDict):
            raise AssertionError(
                "Expected OrderedDict, got {result!r}".format(
                    result=result,
                )
            )
        result = json.dumps(result)

# Generated at 2022-06-23 20:15:40.427785
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    header = [
        ('Set-Cookie', 'foo=bar; Expires=Wed, 01 Jan 2020 00:00:00 GMT'),
        ('Set-Cookie', 'bar=foo; Expires=Wed, 01 Jan 2019 00:00:00 GMT')
    ]
    assert get_expired_cookies(header, now=time.mktime(time.strptime(
        'Wed, 01 Jan 2020 00:00:00 GMT', '%a, %d %b %Y %H:%M:%S GMT'))) == [
            {'name': 'bar', 'path': '/'}]

# Generated at 2022-06-23 20:15:43.934568
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"a": 1, "b": 2, "c": 3}'
    expected = OrderedDict(a=1, b=2, c=3)
    assert load_json_preserve_order(json_string) == expected



# Generated at 2022-06-23 20:15:50.757346
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from io import StringIO
    from requests import Request, Session

    class DummyResponse:
        request = Request(
            'GET', 'http://example.com',
            auth=ExplicitNullAuth()
        )
        headers = {
            'Content-Type': 'text/plain; charset=utf-8',
            'Content-Length': '6'
        }

        def iter_content(self, chunk_size=None):
            yield b'123456'

    class DummySession:

        def send(self, req, **kwargs):
            return DummyResponse()

    session = DummySession()
    req = Request(
        'GET', 'http://example.com',
        data='123456',
        auth=ExplicitNullAuth(),
        headers={'Content-Length': '6'}
    )

# Generated at 2022-06-23 20:15:52.152442
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    # No exception should be raised
    assert auth

# Generated at 2022-06-23 20:15:57.986263
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """Test for function load_json_preserve_order"""
    test_input = '[{"a":1}, {"b":2}]'
    expected_result = [{"a": 1}, {"b": 2}]
    real_result = load_json_preserve_order(test_input)
    assert real_result == expected_result

# Generated at 2022-06-23 20:15:59.392649
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    request = requests.PreparedRequest()
    auth = ExplicitNullAuth()
    auth(request)

# Generated at 2022-06-23 20:16:08.881097
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': '2'}
    assert repr_dict(d) == '{' + "'a': 1, 'b': '2'" + '}'
    assert repr_dict(d) == pformat(d)

    # To ensure we use the custom function for repr, not pformat
    class Foo():
        def __repr__(self):
            return '<Foo>'

    d = {'a': 1, 'b': Foo()}
    assert repr_dict(d) == '{' + "'a': 1, 'b': <Foo>" + '}'
    assert repr_dict(d) != pformat(d)

# Generated at 2022-06-23 20:16:11.507516
# Unit test for function repr_dict
def test_repr_dict():
    d = {(1, 2): 'a', (3, 4): 'b'}
    assert repr_dict(d) == "{(1, 2): 'a', (3, 4): 'b'}"

# Generated at 2022-06-23 20:16:15.494886
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert load_json_preserve_order('{"b": 2, "a": 1}') == {'a': 1, 'b': 2}

# Generated at 2022-06-23 20:16:19.369792
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    request = requests.Request(
        'GET',
        url='https://httpbin.org/cookies/set?test=test_value',
        auth=auth,
    ).prepare()
    assert request.body is None
    assert request.headers['Authorization'] == ''

# Generated at 2022-06-23 20:16:26.954947
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:16:37.692241
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.py') == 'text/x-python'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.tar.gz') == 'application/x-tar'
    assert get_content_type('foo.tar.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.zip') == 'application/zip'

    # with not known extension:
    assert get_content_type('foo.unknown') is None

# Generated at 2022-06-23 20:16:39.045908
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth = ExplicitNullAuth()
    request = requests.Request()
    result = explicit_null_auth(request)

    assert result == request

# Generated at 2022-06-23 20:16:42.274618
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """Test ExplicitNullAuth.__call__()
    """

    # Arrange
    class DummyRequest(object):
        pass

    dummy_request = DummyRequest()
    auth = ExplicitNullAuth()

    # Act
    auth(dummy_request)

    # Assert
    # Nothing to do.

# Generated at 2022-06-23 20:16:42.739878
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:16:48.653639
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    now = datetime.utcnow()
    now = now.replace(year=now.year+2)
    now = now.replace(microsecond=0)

# Generated at 2022-06-23 20:16:54.486094
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.foo') is None

# Generated at 2022-06-23 20:16:56.337857
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1, b=2)) == '{\n    "a": 1,\n    "b": 2\n}'

# Generated at 2022-06-23 20:16:57.851179
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:16:59.874455
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json
    a = load_json_preserve_order("""{"i": 1, "j": 2}""")
    b = json.loads("""{"i": 1, "j": 2}""")
    assert a == b

# Generated at 2022-06-23 20:17:02.329805
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    requests.auth.AuthBase.__call__.__self__
    ExplicitNullAuth.__call__.__self__


# Generated at 2022-06-23 20:17:06.705650
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [('Set-Cookie', 'sessionid=1; expires=Mon, 01-Jan-2018 16:20:00 GMT')]
    cookies = get_expired_cookies(headers=headers, now=1514858850)
    assert cookies == [{'name': 'sessionid', 'path': '/'}]



# Generated at 2022-06-23 20:17:09.435061
# Unit test for function repr_dict
def test_repr_dict():
    d = {'foo': 'bar', 'x': 'y'}
    repr_d = repr_dict(d)
    assert repr_d == repr(d)


if __name__ == '__main__':
    test_repr_dict()

# Generated at 2022-06-23 20:17:13.751377
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('abc.txt') == 'text/plain'
    assert get_content_type('abc.html') == 'text/html'
    assert get_content_type('abc.css') == 'text/css'
    assert get_content_type('abc.js') == 'application/javascript'
    assert get_content_type('abc.json') == 'application/json'
    assert get_content_type('abc.xml') == 'application/xml'

# Generated at 2022-06-23 20:17:19.967179
# Unit test for function get_content_type
def test_get_content_type():
    test_cases = (
        ('image.png', 'image/png'),
        ('image.PNG', 'image/png'),
        ('image.im4', 'application/octet-stream'),
        ('image.', None),
        ('', None),
    )
    for filename, expected in test_cases:
        assert get_content_type(filename) == expected

# Generated at 2022-06-23 20:17:21.798918
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == '<ExplicitNullAuth()>'

# Generated at 2022-06-23 20:17:29.949681
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:17:40.215707
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():

    # Arrange:
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    r = requests.Request()

    # Act:
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    res = ExplicitNullAuth()(r)

    # Assert:
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    assert res.url == r.url
    assert res.method == r.method
    assert res.headers == r.headers
    assert res.files == r.files
    assert res.params == r.params

# Generated at 2022-06-23 20:17:49.177906
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:17:50.465683
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 20:17:52.242777
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"


# Generated at 2022-06-23 20:17:59.733038
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    dict_string = """
    {
        "age": 32,
        "birth_place": "Ha Noi",
        "gender": "M",
        "name": "Anh Tran Dang Khoa"
    }
    """

    dict_output = {
        'name': "Anh Tran Dang Khoa",
        'age': 32,
        'birth_place': "Ha Noi",
        "gender": "M"
    }

    assert dict_output == load_json_preserve_order(dict_string)


# Generated at 2022-06-23 20:18:05.739420
# Unit test for function repr_dict
def test_repr_dict():
    # Test: OrderedDict
    d = OrderedDict()
    d['b'] = 2
    d['c'] = 3
    d['a'] = 1
    s = repr_dict(d)
    assert s == "OrderedDict([('b', 2), ('c', 3), ('a', 1)])", repr(s)

    # Test: normal dict
    d = {'b': 2, 'c': 3, 'a': 1}
    s = repr_dict(d)
    assert s == "{'b': 2, 'c': 3, 'a': 1}", repr(s)

# Generated at 2022-06-23 20:18:07.693419
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:18:09.034797
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"

# Generated at 2022-06-23 20:18:13.824351
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    import pytest

    auth = ExplicitNullAuth()
    r = requests.Request('get', 'https://httpbin.org')
    p = r.prepare()
    p = auth(p)

    assert 'authorization' not in p.headers



# Generated at 2022-06-23 20:18:22.656665
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.xml') == 'text/xml'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.tar.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_

# Generated at 2022-06-23 20:18:23.980218
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()(None)



# Generated at 2022-06-23 20:18:28.296318
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    "Test for load_json_preserve_order"

    ex = {"c": [3, 4], "a": 1, "b": 2}

    s = json.dumps(ex)

    res = load_json_preserve_order(s)

    assert res == ex
    assert res.keys() == ["a", "b", "c"]

# Generated at 2022-06-23 20:18:36.623172
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:18:40.201264
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.now()
    expired_cookie = [
        'cookie_name=cookie_val; expires={}; path=/'.format(
            (now - timedelta(days=1)).strftime("%a, %d-%b-%Y %H:%M:%S GMT")
        )
    ]
    headers = [('Set-Cookie', v) for v in expired_cookie]

    assert get_expired_cookies(headers=headers, now=(now + timedelta(0)).timestamp()) == [
        {
            'name': 'cookie_name', 'path': '/'
        }
    ]

# Generated at 2022-06-23 20:18:49.304372
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    future = now + 100
    past = now - 100

    headers = [
        ('Set-cookie', 'not_expired_cookie=value'),
        ('Set-cookie', 'valid=value; max-age=300'),
        ('Set-cookie', 'expired=value; expires={:.0f}'.format(past)),
        ('Set-cookie', 'max-age=value; max-age=0'),
    ]
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'expired', 'path': '/'},
        {'name': 'max-age', 'path': '/'},
    ]


# Generated at 2022-06-23 20:18:59.396561
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from urllib.parse import urlparse
    import time

    def is_expired(expires_str, now):
        # Convert timestamp below to Python's standard time.struct_time.
        expires = time.strptime(expires_str + ' UTC', '%a, %d %b %Y %H:%M:%S %Z')

        # Convert time.struct_time to timestamp.
        timestamp = time.mktime(expires)

        return timestamp <= now

    url = urlparse('https://httpbin.org/cookies/set?foo=bar')

    # Make a mock response that is the response from HTTPBin after setting
    # cookies for this URL.
    now = 1527836827.92289
    response = requests.Response()

# Generated at 2022-06-23 20:19:01.818330
# Unit test for function repr_dict
def test_repr_dict():
    from nose.tools import assert_equal
    assert_equal(repr_dict({1: 2}), '{1: 2}')

# Generated at 2022-06-23 20:19:07.338951
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import requests
    import xmlrpc.client

    r = requests.get(
        'https://httpbin.org/cookies/set?my_cookie=my_value&my_other_cookie=my_other_value'
    )
    expected = [
        # session cookies, expires=None
        {'name': 'my_cookie', 'path': '/'},
        {'name': 'my_other_cookie', 'path': '/'},
    ]
    assert get_expired_cookies(r.request.headers) == expected

    r = requests.get(
        'https://httpbin.org/cookies/set?my_cookie=my_value&my_other_cookie=my_other_value',
        cookies={'some_other_cookie': 'some_other_value'}
    )

# Generated at 2022-06-23 20:19:07.793171
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:19:10.642653
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order(
        '{"key1": "value1", "key2": "value2"}'
    ) == {'key1': 'value1', 'key2': 'value2'}



# Generated at 2022-06-23 20:19:16.957782
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 12342) == '12.05 MB'
    assert humanize_bytes(1024 * 1234 * 1111) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:19:20.986957
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(__file__) == 'text/x-python'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('bar.baz') is None
    assert get_content_type('.htaccess') is None

# Generated at 2022-06-23 20:19:29.449467
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:19:38.560461
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if not (humanize_bytes(1) == '1 B'): raise AssertionError
    if not (humanize_bytes(1024,1) == '1.0 kB'): raise AssertionError
    if not (humanize_bytes(1024*123,1) == '123.0 kB'): raise AssertionError
    if not (humanize_bytes(1024*12342,1) == '12.1 MB'): raise AssertionError
    if not (humanize_bytes(1024*12342,2) == '12.05 MB'): raise AssertionError
    if not (humanize_bytes(1024*1234,2) == '1.21 MB'): raise AssertionError
    if not (humanize_bytes(1024*1234*1111,2) == '1.31 GB'): raise Ass

# Generated at 2022-06-23 20:19:39.133081
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:19:41.344544
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({}) == '{}'

# Generated at 2022-06-23 20:19:51.840619
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def check_humanize_bytes(input: int, expected: str):
        res = humanize_bytes(input)
        if res != expected:
            print('fail at: ', input, expected)
            assert res == expected

    check_humanize_bytes(0, '0 B')
    check_humanize_bytes(1, '1 B')
    check_humanize_bytes(1024, '1.0 kB')
    check_humanize_bytes(1024 * 123, '123.0 kB')
    check_humanize_bytes(1024 * 12342, '12.1 MB')
    check_humanize_bytes(1024 * 12342, '12.05 MB')
    check_humanize_bytes(1024 * 1234, '1.21 MB')

# Generated at 2022-06-23 20:19:54.101712
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    fake_session = requests.Session()
    fake_session.auth = ExplicitNullAuth()
    fake_session.get('http://www.example.com/')
    assert fake_session.auth is not None

# Generated at 2022-06-23 20:20:02.639893
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:20:09.132209
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:20:19.955009
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import json


# Generated at 2022-06-23 20:20:29.290979
# Unit test for function get_content_type
def test_get_content_type():
    tests = {
        'text.txt': 'text/plain',
        'foo.xml': 'application/xml',
        'foo.html': 'text/html',
        'foo.html.bak': 'text/html',
        'foo.htm': 'text/html',
        'foo.png': 'image/png',
        'foo.tar.gz': 'application/x-gzip',
        'foo.tar.bz2': 'application/x-bzip2',
        'foo.pdf': 'application/pdf',
        'foo.jpeg': 'image/jpeg',
        'foo.gz': 'application/x-gzip',
        'foo.exe': None,
        'foo': None,
        '': None,
    }
    for filename, expected in tests.items():
        assert get_content

# Generated at 2022-06-23 20:20:37.361114
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest
    expired = get_expired_cookies(
        [
            ('Set-Cookie', 'a=b; Path=/'),
            ('Set-Cookie', 'c=d; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
            ('Set-Cookie', 'e=f; Path=/; Max-Age=10'),
        ],
        now=100000000
    )
    assert expired == [
        {'name': 'c', 'path': '/'},
        {'name': 'e', 'path': '/'},
    ]


# Generated at 2022-06-23 20:20:44.773186
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('hello.txt') == 'text/plain'
    assert get_content_type('hello.png') == 'image/png'
    assert get_content_type('hello.png') == 'image/png'
    assert get_content_type('ttt.jpeg') == 'image/jpeg'
    assert get_content_type('ttt.jpeg') == 'image/jpeg'
    assert get_content_type('ttt.doc') == 'application/msword'
    assert get_content_type('ttt.doc') == 'application/msword'

# Generated at 2022-06-23 20:20:52.246057
# Unit test for function humanize_bytes
def test_humanize_bytes():
    """   assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024*123) == '123.0 kB'
    assert humanize_bytes(1024*12342) == '12.1 MB'
    assert humanize_bytes(1024*12342,2) == '12.05 MB'
    assert humanize_bytes(1024*1234,2) == '1.21 MB'
    assert humanize_bytes(1024*1234*1111,2) == '1.31 GB'
    assert humanize_bytes(1024*1234*1111,1) == '1.3 GB'"""
    pass


# Generated at 2022-06-23 20:20:54.952277
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Given
    import requests

    # When
    auth = ExplicitNullAuth()

    # Then
    assert not auth(requests.PreparedRequest())

# Generated at 2022-06-23 20:20:57.100971
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import os
    os.unlink = lambda p: None
    ExplicitNullAuth()({})

# Generated at 2022-06-23 20:20:57.812052
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:21:01.601520
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo/bar.html') == 'text/html'
    assert get_content_type('/etc/hosts') == 'text/plain'


if __name__ == '__main__':
    raise RuntimeError

# Generated at 2022-06-23 20:21:06.305313
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # The first cookie is expired, the second isn't
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Domain=example.com; Expires=Wed, 22 Jul 1998 07:28:00 GMT'),
        ('Set-Cookie', 'foobar=foobar; Path=/; Domain=example.com; Max-Age=31536000')
    ]
    cookies = get_expired_cookies(headers)
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'foo'
    assert cookies[0]['path'] == '/'

# Generated at 2022-06-23 20:21:18.343490
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # noinspection PyUnresolvedReferences
    from humanize import naturalsize

    assert humanize_bytes(1) == naturalsize(1)
    assert humanize_bytes(1024, precision=1) == naturalsize(1024, gnu=True)
    assert humanize_bytes(1024 * 123, precision=1) == naturalsize(1024 * 123, gnu=True)

    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'

# Generated at 2022-06-23 20:21:20.009261
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Testing a class which has no methods is not posible
    pass

# Generated at 2022-06-23 20:21:23.313129
# Unit test for function repr_dict
def test_repr_dict():
    d = {'x': 1, 'z': 2, 'y': 'foo'}
    assert repr_dict(d) == "{'x': 1, 'z': 2, 'y': 'foo'}"



# Generated at 2022-06-23 20:21:24.758977
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    repr(a)


# Generated at 2022-06-23 20:21:32.568747
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    print('humanize_bytes unit tests done')



# Generated at 2022-06-23 20:21:44.231884
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from pytest import raises

    now = 1234567890

    # Empty headers
    with raises(ValueError):
        get_expired_cookies(headers=[], now=now)

    # Missing `expires` or `max-age`
    with raises(ValueError):
        get_expired_cookies(
            headers=[('Set-Cookie', 'foo=bar')],
            now=now
        )

    cookies = get_expired_cookies(
        headers=[
            ('Set-Cookie', 'foo=bar'),
            ('Set-Cookie', 'baz=qux; expires=1234567891')],
        now=now
    )
    assert len(cookies) == 1
    assert cookies == [{'path': '/', 'name': 'foo'}]

    cookies = get_expired

# Generated at 2022-06-23 20:21:52.265192
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
