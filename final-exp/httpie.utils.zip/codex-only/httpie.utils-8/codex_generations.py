

# Generated at 2022-06-23 20:12:01.858930
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-23 20:12:04.015746
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('foo.txt')
    assert 'image/jpeg' == get_content_type('bar.jpg')

# Generated at 2022-06-23 20:12:07.178221
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.bar') is None

# Generated at 2022-06-23 20:12:15.563513
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:12:21.144613
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/path/to/file') is None
    assert get_content_type('/path/to/file.zip') == 'application/zip'
    assert get_content_type('/path/to/file.json') == 'application/json'
    assert get_content_type('/path/to/file.txt') == 'text/plain'
    assert get_content_type('/path/to/file.html') == 'text/html'

# Generated at 2022-06-23 20:12:24.854807
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_object = load_json_preserve_order('{"foo": 1, "bar": 2}')
    assert OrderedDict([("foo", 1), ("bar", 2)]) == json_object

# Generated at 2022-06-23 20:12:33.444858
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('image.png') == 'image/png'
    assert get_content_type('image.txt') == 'text/plain'
    assert get_content_type('image.gif') == 'image/gif'
    assert get_content_type('image.jpg') == 'image/jpeg'
    assert get_content_type('image.jpeg') == 'image/jpeg'
    assert get_content_type('image') is None
    assert get_content_type('image.txt.gif') == 'text/plain'
    assert get_content_type('image.txt.jpeg') == 'text/plain'
    assert get_content_type('gif.txt') == 'text/plain'
    assert get_content_type('jpeg.txt') == 'text/plain'

# Generated at 2022-06-23 20:12:41.620455
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"a":2,"b":3,"c":4}'
    assert load_json_preserve_order(json_str) == load_json_preserve_order(json_str)

    # order of the attributes should be preserved
    assert (load_json_preserve_order(json_str)) == (json.loads(json_str, object_pairs_hook=OrderedDict))
    json_str = '{"a":2,"b":3,"c":4,"a":5}'
    assert load_json_preserve_order(json_str) == json.loads(json_str)
    # Keys are unique
    json_str = '{"a":2,"b":3,"c":4,"a":5}'

# Generated at 2022-06-23 20:12:45.864693
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == '<ExplicitNullAuth>'

# Generated at 2022-06-23 20:12:54.685734
# Unit test for function get_content_type
def test_get_content_type():
    cases = (
        ('filename.html', 'text/html'),
        ('filename.txt', 'text/plain'),
        ('filename.jpg', 'image/jpeg'),
        ('filename.jpeg', 'image/jpeg'),
        ('filename.gif', 'image/gif'),
        ('filename.png', 'image/png'),
        ('filename.tif', 'image/tiff'),
        ('filename.tiff', 'image/tiff'),
        ('filename.mp3', 'audio/mpeg'),
        ('filename.ogg', 'audio/ogg'),
        ('filename.exe', 'application/octet-stream'),
        ('filename.zip', 'application/zip'),
        ('filename.tgz', 'application/x-compressed'),
        ('filename.gz', 'application/x-gzip'),
    )

# Generated at 2022-06-23 20:12:55.652655
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-23 20:13:00.919741
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('image.jpg') == 'image/jpeg'
    assert get_content_type('file.mp4') == 'video/mp4'
    assert get_content_type('document.doc') == 'application/msword'
    assert get_content_type('text.pdf') == 'application/pdf'
    assert get_content_type('empty') is None

# Generated at 2022-06-23 20:13:03.785129
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({'a': 'b', 'c': 'b'}) == "{'a': 'b', 'c': 'b'}"

# Generated at 2022-06-23 20:13:08.878510
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{"c": 3, "a": 1, "b": 2}"""
    j = load_json_preserve_order(s)
    assert isinstance(j, dict)
    assert list(j.items()) == [('c', 3), ('a', 1), ('b', 2)]

# Generated at 2022-06-23 20:13:16.419154
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([
        ('set-cookie', 'foo=bar; expires=Wed, 06 Feb 2019 21:22:36 GMT; '
                       'Max-Age=100; path=/; domain=expired.com'),
        ('set-cookie', 'baz=qux; max-age=500; path=/; domain=expired.com'),
        ('set-cookie', 'quux=corge; max-age=500; path=/; domain=expired.com'),
    ], now=4e+8)
    assert cookies == [{'name': 'foo', 'path': '/'},
                       {'name': 'baz', 'path': '/'},
                       {'name': 'quux', 'path': '/'}]

# Generated at 2022-06-23 20:13:24.858069
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.csv') == 'text/csv'
    assert get_content_type('foo.zip') == 'application/zip'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.xlsx') == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    assert get_content_type

# Generated at 2022-06-23 20:13:31.842051
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict), "d is an OrderedDict"
    assert d.keys() == ["a", "b"], "d keys match the input"

    s = '{"a": 1, "b": 2, "c": 3}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict), "d is an OrderedDict"
    assert list(d.keys()) == ["a", "b", "c"], "d keys match the input"



# Generated at 2022-06-23 20:13:33.290156
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth.__call__(None, None) == None


# Generated at 2022-06-23 20:13:43.131192
# Unit test for function humanize_bytes
def test_humanize_bytes():
    for n, expected in [
        (0, '0 B'),
        (1, '1 B'),
        (1023, '1023 B'),
        (1024, '1.0 kB'),
        (1023 ** 2, '1023.0 kB'),
        (1024 ** 2, '1.0 MB'),
        (1023 ** 3, '1023.0 MB'),
        (1024 ** 3, '1.0 GB'),
        (1023 ** 4, '1023.0 GB'),
        (1024 ** 4, '1.0 TB'),
        (1023 ** 5, '1023.0 TB'),
        (1024 ** 5, '1.0 PB'),
        (1023 ** 6, '1023.0 PB')
    ]:
        assert humanize_bytes(n) == expected

# Generated at 2022-06-23 20:13:46.598727
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('tmp.html') == 'text/html'
    assert get_content_type('tmp.txt') == 'text/plain'
    assert get_content_type('tmp.png') == 'image/png'
    assert get_content_type('tmp.jpeg') == 'image/jpeg'



# Generated at 2022-06-23 20:13:50.183280
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    ordered_dict = load_json_preserve_order('{"b":1,"a":2}')
    assert list(ordered_dict.keys()) == ['b', 'a']
    assert ordered_dict['a'] == 2
    assert ordered_dict['b'] == 1



# Generated at 2022-06-23 20:13:56.322695
# Unit test for function get_content_type
def test_get_content_type():
    # Doctest doesn't work.
    assert get_content_type("foo.jpeg") == "image/jpeg"
    assert get_content_type("foo.js") == "application/javascript"
    assert get_content_type("foo.json") == "application/json"
    assert get_content_type("foo.txt") == "text/plain"


test_get_content_type.__test__ = False

# Generated at 2022-06-23 20:14:01.773074
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import unittest

    class TestCase(unittest.TestCase):
        def test_non_netrc(self):
            import requests
            from requests.auth import AuthBase

            class DummyRequest(object):
                url = 'https://example.com/'
                netrc_auth = None

            r = DummyRequest()
            auth = ExplicitNullAuth()
            self.assertIsInstance(auth, AuthBase)
            r = auth(r)
            self.assertIsInstance(r, DummyRequest)

    import doctest
    doctest.testmod()

    unittest.main()

# Generated at 2022-06-23 20:14:04.715026
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.png') == 'image/png'

# Generated at 2022-06-23 20:14:05.805297
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None

# Generated at 2022-06-23 20:14:10.889498
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"c": 3, "a": 1, "b": 2}'
    result = load_json_preserve_order(json_str)
    expected = OrderedDict([('c', 3), ('a', 1), ('b', 2)])
    assert result == expected

# Generated at 2022-06-23 20:14:11.694968
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:14:12.746158
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

# Generated at 2022-06-23 20:14:21.638650
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from unittest import main
    from .test_helpers import MockRequest, MockResponse

    class TestGetExpiredCookies(object):
        def test(self):
            req = MockRequest(MockResponse(
                headers=[
                    ('Set-Cookie', 'a=1; Expires=Thu, 01-Jan-1970 00:00:00 GMT'),
                    ('Set-Cookie', 'b=2'),
                    ('Set-Cookie', 'c=3; Max-Age=10'),
                ],
            ))
            expired_cookies = get_expired_cookies(headers=req.response.headers)
            assert expired_cookies == [
                {'name': 'a', 'path': '/'},
                {'name': 'b', 'path': '/'},
            ]

    main()

# Generated at 2022-06-23 20:14:30.383453
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.tar') == 'application/x-tar'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.xpg') is None

# Generated at 2022-06-23 20:14:32.690390
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth = ExplicitNullAuth()
    assert isinstance(explicit_null_auth, requests.auth.AuthBase)

# Generated at 2022-06-23 20:14:35.787513
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2, "c": 3}') == OrderedDict([('a', 1), ('b', 2), ('c', 3)])



# Generated at 2022-06-23 20:14:46.707380
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    expire_RE = r'(?x)\d+[MD]|[01]\d/[0123]\d/\d+'


# Generated at 2022-06-23 20:14:53.862970
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/path/to/file.html') == 'text/html'
    assert get_content_type('/path/to/file.html.txt') == 'text/html'
    assert get_content_type('/path/to/file.txt') == 'text/plain'
    assert get_content_type('/path/to/file.png') == 'image/png'
    assert get_content_type('/path/to/file.jpg') == 'image/jpeg'
    assert get_content_type('/path/to/file.gif') == 'image/gif'
    assert get_content_type('/path/to/file.bmp') == 'image/bmp'
    assert get_content_type('/path/to/file.ico') == 'image/x-icon'


# Generated at 2022-06-23 20:14:56.793493
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_payload=OrderedDict([('z', 'z'), ('y', 'y'), ('x', 'x')])
    assert json_payload == load_json_preserve_order(json.dumps(json_payload))


# Generated at 2022-06-23 20:14:58.683781
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()  # should not raise an exception

# Generated at 2022-06-23 20:15:04.522685
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('aaa.gif') == 'image/gif'
    assert get_content_type('aaa.txt') == 'text/plain'
    assert get_content_type('aaa.xlsx') == \
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    assert get_content_type('aaa.doc') == 'application/msword'
    assert get_content_type('aaa.mp4') == 'video/mp4'
    assert get_content_type('aaa.exe') is None

# Generated at 2022-06-23 20:15:11.995149
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from requests.cookies import create_cookie
    from http.cookies import SimpleCookie
    from urllib.parse import urljoin

    now = 1000000

    def add_cookies(response, source_domain, cookies):
        if isinstance(cookies, dict):
            cookies = [cookies]

        for cookie in cookies:
            _cookie = create_cookie(
                name=cookie['name'],
                value=cookie.get('value', ''),
                domain=cookie.get('domain', source_domain),
                path=cookie.get('path', '/'),
                expires=cookie.get('expires', None),
                discard=cookie.get('discard', False),
                secure=cookie.get('secure', False),
            )
            response.cookies.set_cookie(_cookie)


# Generated at 2022-06-23 20:15:22.943409
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:30.705761
# Unit test for function get_content_type
def test_get_content_type():
    """Unit test for function get_content_type"""
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.pdf') == 'application/pdf'

# Generated at 2022-06-23 20:15:34.391958
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"


if __name__ == '__main__':
    from pytest import main
    main(['-v', __file__])

# Generated at 2022-06-23 20:15:38.648312
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('README.txt') == 'text/plain'
    assert get_content_type('x.y') is None
    assert get_content_type('x.y.z') is None

# Generated at 2022-06-23 20:15:43.389324
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = """{"z": 1, "a": 1, "c": 1, "b": 1}"""
    data = load_json_preserve_order(json_str)
    assert data == OrderedDict([('z', 1), ('a', 1), ('c', 1), ('b', 1)])

# Generated at 2022-06-23 20:15:55.287996
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = [
        'foo=bar; Path=/; Expires=Sun, 15 Jul 2018 21:30:00 GMT',
        'session_id=abc123; Path=/; Expires=Sun, 15 Jul 2018 21:30:00 GMT',
        'xsrf_token=xyz987; Path=/; Expires=Sun, 15 Jul 2018 21:30:00 GMT',
    ]
    now = 0
    now_plus_one = now + 1
    now_plus_three = now + 3
    assert get_expired_cookies([], now=now) == []

# Generated at 2022-06-23 20:16:03.919148
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:16:04.514953
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:16:13.119789
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from .call import Call
    from .responses import Response
    from .request import Request
    from .url import URL
    from .time import Timer

    session = requests.Session()
    auth = ExplicitNullAuth()
    session.auth = auth
    timer = Timer()
    url = URL('https://www.w3.org/Protocols/rfc2616/rfc2616.html')
    request = Request(url=url, method='GET', headers={},
                      body=None, auth=auth, session=session)
    response = Response(timer=timer, request=request)
    call = Call(request=request, response=response, timer=timer)


# Generated at 2022-06-23 20:16:14.205251
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    from contextlib import redirect_stdout
    from io import StringIO

    with redirect_stdout(StringIO()):
        print(ExplicitNullAuth())

# Generated at 2022-06-23 20:16:16.374608
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    response = auth.__call__(None)
    assert response == None

# Generated at 2022-06-23 20:16:19.013008
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(foo=1, bar=2, fizz=3)) == "{'foo': 1, 'bar': 2, 'fizz': 3}"

# Generated at 2022-06-23 20:16:25.905215
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = [
        ('Set-Cookie', 'foo=bar;Path=/;Domain=.example.com'),
        ('Set-Cookie', 'baz=qux;Path=/;Expires=Wed, 13 Jan 2021 22:23:01 GMT'),
        ('Set-Cookie', 'boing=hiss;Path=/;Max-Age=0'),
    ]
    assert get_expired_cookies(
        headers=cookies,
        now=1605135581  # Wed, 13 Jan 2021 22:23:01 GMT
    ) == [{'name': 'baz', 'path': '/'}, {'name': 'foo', 'path': '/'}]

# Generated at 2022-06-23 20:16:34.255241
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1.6) == '2 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024 * 123) == '123.0 kB'
    assert humanize_bytes(1024 * 12342) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-23 20:16:42.816727
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1).strip() == '1 B'
    assert humanize_bytes(1024, precision=1).strip() == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1).strip() == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1).strip() == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2).strip() == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2).strip() == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2).strip() == '1.31 GB'

# Generated at 2022-06-23 20:16:43.624979
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

# Generated at 2022-06-23 20:16:45.408580
# Unit test for function get_content_type
def test_get_content_type():
    mime, encoding = mimetypes.guess_type('foo.html', strict=False)
    assert get_content_type('foo.html') == mime
    assert get_content_type('foo.html') == 'text/html'

# Generated at 2022-06-23 20:16:56.339699
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 12342) == '12.05 MB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:17:05.070762
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:17:10.036726
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    input_string = '[{"a": 1, "b": 2, "c": 3}]'
    expected = [OrderedDict([('a', 1), ('b', 2), ('c', 3)])]
    assert load_json_preserve_order(input_string) == expected

    # Make sure the output is ordered
    assert list(load_json_preserve_order(input_string)[0].keys()) == ['a', 'b', 'c']

# Generated at 2022-06-23 20:17:11.458258
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 2, 'b': 1}) == "{'a': 2, 'b': 1}"

# Generated at 2022-06-23 20:17:13.385969
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """__call__ should return the request."""
    from requests.models import Request
    r = Request()
    auth = ExplicitNullAuth()
    p = auth(r)
    assert p is r


# Generated at 2022-06-23 20:17:20.355380
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """Test for ExplicitNullAuth.__call__.
    """
    from requests.auth import HTTPBasicAuth
    auth = ExplicitNullAuth()
    test_cases = [
        [None, True],
        [HTTPBasicAuth('user', 'pass'), True],
        [ExplicitNullAuth(), False],
    ]
    for auth_, expected in test_cases:
        assert (auth(auth_) is not auth_) == expected

# Generated at 2022-06-23 20:17:21.843985
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.pdf') == 'application/pdf'



# Generated at 2022-06-23 20:17:30.245223
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=b; Domain=example.com; Expires=Wed, 13-Jan-2021 22:23:01 GMT; HttpOnly; Path=/; secure; SameSite=Lax'),
        ('Set-Cookie', 'c=d; Domain=example.com; HttpOnly; Path=/; secure; SameSite=Lax'),
        ('set-cookie', 'max-age=0; expires=Wed, 13-Jan-2021 22:23:01 GMT; HttpOnly; Path=/; secure; SameSite=Lax'),
        ('set-cookie', 'max-age=60; HttpOnly; Path=/; secure; SameSite=Lax'),
    ]
    now = time.time()

    cookies = get_expired_cookies(headers=headers, now=now)

# Generated at 2022-06-23 20:17:30.926083
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:17:33.796534
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    auth = ExplicitNullAuth()
    r = requests.get(url='http://www.google.com', auth=auth)
    assert r.status_code == 200

# Generated at 2022-06-23 20:17:38.020701
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({"a": 1}) == "{'a': 1}"
    assert repr_dict({"c": 3, "b": 2, "a": 1}) == "{'c': 3, 'b': 2, 'a': 1}"

# Generated at 2022-06-23 20:17:39.454600
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    _ = ExplicitNullAuth()

# Generated at 2022-06-23 20:17:41.271994
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    e = ExplicitNullAuth()
    assert e(object())

# Generated at 2022-06-23 20:17:46.464263
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"xyz": "abc", "123": "def"}') == \
        OrderedDict([('xyz', 'abc'), ('123', 'def')])
    assert load_json_preserve_order('{"xyz": "abc", "123": "def", "a": 1}') == \
        OrderedDict([('xyz', 'abc'), ('123', 'def'), ('a', 1)])

# Generated at 2022-06-23 20:17:50.684016
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.json') == 'application/json'
    assert get_content_type('file.exe') is None

# Generated at 2022-06-23 20:17:56.368460
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # noinspection PyUnresolvedReferences
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024*123) == '123.00 kB'
    assert humanize_bytes(1024*12342) == '12.05 MB'
    assert humanize_bytes(1024*1234*1111,2) == '1.31 GB'
    assert humanize_bytes(1024*1234*1111,1) == '1.3 GB'


if __name__ == "__main__":
    test_humanize_bytes()

# Generated at 2022-06-23 20:18:05.273501
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from hypothesis import given
    from hypothesis import strategies as st
    import requests
    from test.utils import fake_headers

    auth = ExplicitNullAuth()
    r = requests.Request(method='GET', url='https://example.com/')
    prep = auth(r)

    assert prep.url == r.url
    assert prep.method == r.method
    assert prep.headers == {}

    # Hypothesis: Provide a fake set of headers,
    # and ensure the headers pass through untouched.

    @given(st.lists(fake_headers()))
    def test(headers: List[Tuple[str, str]]):
        r = requests.Request(method='GET', url='https://example.com/')
        r.headers = dict(headers)

        prep = auth(r)
        assert prep.url == r.url
       

# Generated at 2022-06-23 20:18:09.214287
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    from pprint import pprint as pp
    auth = ExplicitNullAuth()
    print(type(auth), auth)
    pp(dir(auth))
    print(auth.__repr__())
    print(auth.__call__)
    print('DONE')


# Generated at 2022-06-23 20:18:14.500406
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """ test load_json_preserve_order """

    data = load_json_preserve_order('{"a": "b", "c": "d"}')
    assert {"a": "b", "c": "d"} == data
    assert list(data.keys()) == ["a", "c"]

# Generated at 2022-06-23 20:18:21.706320
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1460913188.979978
    expire_set_cookie_headers = [
        ('Set-Cookie', 'nocache=1; path=/'),
        ('Set-Cookie', 'no_external_referer=deleted; expires=Thu, 01 Jan 1970 00:00:01 GMT; Max-Age=0; path=/'),
    ]
    assert get_expired_cookies(headers=expire_set_cookie_headers, now=now) == [
        {'name': 'nocache', 'path': '/'},
        {'name': 'no_external_referer', 'path': '/'},
    ]

    nocache_set_cookie_headers = [
        ('Set-Cookie', 'nocache=1; path=/'),
    ]

# Generated at 2022-06-23 20:18:25.626404
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '[{"a":1},{"b":2}]'
    expected = [{"a": 1}, {"b": 2}]
    assert load_json_preserve_order(json_str) == expected


# Generated at 2022-06-23 20:18:26.546475
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()



# Generated at 2022-06-23 20:18:30.578331
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests.auth
    import requests.models

    auth = ExplicitNullAuth()
    assert isinstance(auth, requests.auth.AuthBase)
    assert isinstance(auth, requests.models.AuthBase)
    assert isinstance(auth, ExplicitNullAuth)
    assert len(dir(auth)) == 0
    assert repr(auth) == "<ExplicitNullAuth>"
    assert str(auth) == "<ExplicitNullAuth>"

# Generated at 2022-06-23 20:18:33.159836
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    from requests import Session

    ExplicitNullAuth()

    session = Session()
    session.auth = ExplicitNullAuth()

    assert session.auth == ExplicitNullAuth()

# Unit tests for get_content_type

# Generated at 2022-06-23 20:18:35.633950
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.jpeg') == 'image/jpeg'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.other') is None

# Generated at 2022-06-23 20:18:45.993168
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:18:47.442239
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    s = Session()
    s.auth = ExplicitNullAuth()
    assert s.get('https://httpbin.org/anything').ok

# Generated at 2022-06-23 20:18:53.459868
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    expected = OrderedDict([('b', 2), ('a', 1)])
    actual = load_json_preserve_order('{"b": 2, "a": 1}')
    message = 'Actual dict %s does not equal expected dict %s' % (
        pformat(actual),
        pformat(expected)
    )
    assert actual == expected, message

# Generated at 2022-06-23 20:19:02.113190
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

    # https://tools.ietf.org/html/rfc6265#section-5.2.2
    # Set-Cookie: SID=31d4d96e407aad42; Path=/; Secure; HttpOnly
    set_cookie_headers = [
        ('Set-Cookie', 'SID=31d4d96e407aad42; Path=/; Secure; HttpOnly'),
    ]
    assert get_expired_cookies(set_cookie_headers, now) == []

    # https://tools.ietf.org/html/rfc6265#section-5.2.3
    # Set-Cookie: SID=31d4d96e407aad42; Path=/; Domain=example.com; Secure; HttpOnly

# Generated at 2022-06-23 20:19:03.888803
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    x = ExplicitNullAuth()
    assert x(None) is None

# Generated at 2022-06-23 20:19:06.456611
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = b'{"b": 2, "c": 3, "a": 1}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict)
    assert list(d.keys()) == ['b', 'c', 'a']

# Generated at 2022-06-23 20:19:16.118883
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == "1 B"
    assert humanize_bytes(5) == "5 B"
    assert humanize_bytes(1024) == "1.0 kB"
    assert humanize_bytes(1024*1024) == "1.0 MB"
    assert humanize_bytes(1024*1024*1024) == "1.0 GB"
    assert humanize_bytes(1024*1024*1024*1024) == "1.0 TB"
    assert humanize_bytes(1024*1024*1024*1024*1024) == "1.0 PB"
    assert humanize_bytes(1024,1) == "1.0 kB"
    assert humanize_bytes(1024*123,2) == "123.00 kB"
    assert humanize_bytes(1024*12342,2) == "12.05 MB"

# Generated at 2022-06-23 20:19:20.329574
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_text = '{"b":100, "c":200, "a":300}'
    d = load_json_preserve_order(json_text)
    assert d == {'b': 100, 'c': 200, 'a': 300}
    assert d.keys() == ['b', 'c', 'a']
    # Done test_load_json_preserve_order

# Generated at 2022-06-23 20:19:24.794974
# Unit test for function get_content_type
def test_get_content_type():
    test_values = [
        ('foo', None),
        ('foo.jpeg', 'image/jpeg'),
        ('foo.JPEG', 'image/jpeg'),
        ('foo.JPEG;manifest=bla', 'image/jpeg'),
        ('foo.JPEG;charset=UTF-8', 'image/jpeg; charset=UTF-8'),
        ('foo.JPEG;charset=UTF-8;manifest=bla', 'image/jpeg; charset=UTF-8'),
    ]
    for filename, expected in test_values:
        actual = get_content_type(filename)
        assert actual == expected, filename

# Generated at 2022-06-23 20:19:26.751050
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    d = load_json_preserve_order('{"a": 2, "b": 1}')
    assert list(d.keys()) == ['a', 'b']

# Generated at 2022-06-23 20:19:32.587088
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:19:42.315118
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:19:51.924517
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Test for cookies with same path ('/')
    # Cookie does not have 'path':
    assert get_expired_cookies(
        headers=[
            ('Set-Cookie', 'foo=bar; Expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ],
        now=1.3245654326e9
    ) == [
        {'name': 'foo', 'path': '/'},
    ]
    # Cookie with 'path':
    assert get_expired_cookies(
        headers=[
            ('Set-Cookie', 'foo=bar; Path=/foo; Expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ],
        now=1.3245654326e9
    ) == [
        {'name': 'foo', 'path': '/foo'},
    ]



# Generated at 2022-06-23 20:19:54.444394
# Unit test for function get_content_type
def test_get_content_type():
    # Test content types of some common image files
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.jpeg') == 'image/jpeg'
    assert get_content_type('test.gif') == 'image/gif'

# Generated at 2022-06-23 20:20:00.053642
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # Given any instance of requests.auth.AuthBase
    auth = requests.auth.HTTPBasicAuth('user', 'password')
    # And an instance of class ExplicitNullAuth
    explicit_null_auth = ExplicitNullAuth()
    # Then the result of this call should be the same
    # as the result of the former.
    # Note that this is not true for the opposite order.
    assert explicit_null_auth(auth) == auth



# Generated at 2022-06-23 20:20:07.710607
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:20:11.655808
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type(__file__)
    assert content_type == 'text/x-python; charset=us-ascii'


if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-23 20:20:17.057356
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import pytest
    s = '{"foo": 1, "bar": 2, "baz": 3}'
    result = load_json_preserve_order(s)
    assert result.keys() == ["foo", "bar", "baz"]
    with pytest.raises(ValueError):
        load_json_preserve_order("[1,2,3]")

# Generated at 2022-06-23 20:20:17.985684
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()()


# Generated at 2022-06-23 20:20:18.552729
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:20:23.861924
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('.txt') == 'text/plain'
    assert get_content_type('index.html') == 'text/html'
    assert get_content_type('image.jpeg') == 'image/jpeg'
    assert get_content_type('song.mp3') == 'audio/mpeg'
    assert get_content_type('logo.svg') == 'image/svg+xml'
    assert get_content_type('missing_extension') is None

# Generated at 2022-06-23 20:20:26.226817
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'k': 5}) == "{'k': 5}"
    assert repr_dict({'k': 5}) == "{'k': 5}"



# Generated at 2022-06-23 20:20:29.248783
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"c": "a", "b": "a"}') == OrderedDict([('c', 'a'), ('b', 'a')])


# Generated at 2022-06-23 20:20:37.334109
# Unit test for function get_content_type
def test_get_content_type():

    def assert_content_type(filename, expected):
        content_type = get_content_type(filename)
        assert content_type == expected, (
            'for filename=%r, expected: %r, got: %r' % (
                filename, expected, content_type
            )
        )

    assert_content_type('text.txt', 'text/plain')
    assert_content_type('image.jpeg', 'image/jpeg')
    assert_content_type('image.jpg', 'image/jpeg')
    assert_content_type('image.JPG', 'image/jpeg')
    assert_content_type('image.webp', 'image/webp')
    assert_content_type('image.png', 'image/png')
    assert_content_type('image.PNG', 'image/png')

# Generated at 2022-06-23 20:20:47.122510
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie',
         'PHPSESSID=ldoe6pvk1i8urn01papr1ceb; path=/; expires=Thu, 19-May-2022 '
         '00:28:15 GMT; HttpOnly'),
        ('Set-Cookie',
         '_pk_id.1.e4dc=4e4b4b5895b5c7d9.1463880095.1.1463881095.1463880095.; '
         'path=/; expires=Wed, 19-Apr-2017 00:28:15 GMT'),
        ('Set-Cookie',
         '_pk_ses.2.e4dc=*; path=/; expires=Thu, 19-May-2022 00:28:15 GMT')
    ]

# Generated at 2022-06-23 20:20:55.003212
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest


# Generated at 2022-06-23 20:20:59.966055
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'abc=xyz; Expires=Fri, 31 Dec 1999 23:59:59 GMT'),
        ('Set-Cookie', 'foo=bar; Expires=Mon, 13 Aug 2018 10:11:12 GMT; Path=/'),
        ('Set-Cookie', 'bar=baz; Expires=Mon, 13 Aug 2018 10:11:12 GMT; Path=/'),
        ('Set-Cookie', 'baz=qux; Expires=Tue, 15 Aug 2028 12:13:14 GMT; Path=/'),
    ]
    # https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Date

# Generated at 2022-06-23 20:21:00.548895
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:21:08.575825
# Unit test for function humanize_bytes
def test_humanize_bytes():
    s = humanize_bytes(1)
    assert s == '1 B'

    s = humanize_bytes(1024, precision=1)
    assert s == '1.0 kB'

    s = humanize_bytes(1024 * 123, precision=1)
    assert s == '123.0 kB'

    s = humanize_bytes(1024 * 12342, precision=1)
    assert s == '12.1 MB'

    s = humanize_bytes(1024 * 12342, precision=2)
    assert s == '12.05 MB'

    s = humanize_bytes(1024 * 1234, precision=2)
    assert s == '1.21 MB'

    s = humanize_bytes(1024 * 1234 * 1111, precision=2)
    assert s == '1.31 GB'

    s = human

# Generated at 2022-06-23 20:21:20.754683
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:21:27.264499
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from collections import Counter

    expiring_cookie = 'Test=value; Max-Age=1'
    expired_cookie = 'Test=value; Max-Age=0'
    non_expiring_cookie = 'Test=value'
    headers = []
    for header in [expiring_cookie, expired_cookie, non_expiring_cookie]:
        headers.append(("Set-Cookie", header))
    # We should get one expired cookie, and one non-expired one
    expired_cookies = get_expired_cookies(headers)
    assert len(expired_cookies) == 1
    assert Counter(expired_cookies[0]['name'] for expired_cookies in expired_cookies)['Test'] == 1

# Generated at 2022-06-23 20:21:29.140880
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None

# Generated at 2022-06-23 20:21:29.915199
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None


# Generated at 2022-06-23 20:21:31.588342
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)


# Generated at 2022-06-23 20:21:37.708395
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    __ts_call = ExplicitNullAuth()
    __r = test_ExplicitNullAuth___call__.__r = requests.Request()
    if __ts_call(__r) is not __r:
        raise AssertionError("if __ts_call(__r) is not __r:")
test_ExplicitNullAuth___call__()


# Generated at 2022-06-23 20:21:47.157308
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(None) == 'application/octet-stream'
    assert get_content_type('') == 'application/octet-stream'
    assert get_content_type('.txt') == 'text/plain'
    assert get_content_type('a/file.txt') == 'text/plain'
    assert get_content_type('a.file.txt') == 'text/plain'
    assert get_content_type('a.file.txt.bz2') == 'application/x-bzip2'
    assert get_content_type('a.file.TXT.BZ2') == 'application/x-bzip2'
    assert get_content_type('a.file.txt.bz2.other') == 'application/octet-stream'

# Generated at 2022-06-23 20:21:51.699521
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a":1, "b":2}'
    # Before:
    assert json.loads(s) == {"a": 1, "b": 2}
    d = load_json_preserve_order(s)
    # After:
    assert list(d.keys()) == ["a", "b"]

# Generated at 2022-06-23 20:21:55.483516
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(None) is None
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.html.gz') == 'text/html; charset=gzip'