

# Generated at 2022-06-23 20:11:49.152969
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None



# Generated at 2022-06-23 20:11:58.559421
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # Copied from humanize_bytes docstring
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


# Generated at 2022-06-23 20:12:06.705685
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # RFC 6265, Section 4.2.1: Set-Cookie
    cookie_set_headers = [
        "foo=bar",
        "baz=qux; Domain=example.com; Path=/; Expires=Sun, 06 Nov 1994 08:49:37 GMT; Secure; HttpOnly",
        "foo=asdf; Path=/; Domain=example.com; Max-Age=500",
        "foo=; Expires=Sun, 06 Nov 1994 08:49:37 GMT; Domain=example.com; Path=/"
    ]

    cookies = get_expired_cookies(
        headers=[(name, value) for name, value in (
            ("Set-Cookie", set_header) for set_header in cookie_set_headers
        )]
    )
    assert len(cookies) == 2

# Generated at 2022-06-23 20:12:10.506462
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    in_string = """{"a":0,"b":1,"c":2,"d":3}"""
    expected = OrderedDict([ ("a", 0), ("b", 1), ("c", 2), ("d", 3) ])
    actual = load_json_preserve_order(in_string)
    assert expected == actual

# Generated at 2022-06-23 20:12:15.925870
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_with_order = '{"foo": "bar", "baz": "qux"}'
    json_without_order = '{"baz": "qux", "foo": "bar"}'

    assert len(load_json_preserve_order(json_with_order)) > 0
    assert len(load_json_preserve_order(json_without_order)) > 0
    assert load_json_preserve_order(json_without_order) == load_json_preserve_order(json_with_order)

# Generated at 2022-06-23 20:12:21.258296
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:12:26.151053
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    Test if the order of a json object is preserved after using load_json_preserve_order
    """
    s = json.dumps([1,2,3], sort_keys=True)
    assert(load_json_preserve_order(s) == OrderedDict([(0,1), (1,2), (2,3)]))

# Generated at 2022-06-23 20:12:33.232028
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:12:35.033717
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    import requests
    requests.get('http://httpbin.org/get', auth=ExplicitNullAuth())

# Generated at 2022-06-23 20:12:38.367287
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{
        "water": "wet",
        "fire": "hot",
        "grass": "green"
      }"""
    d = load_json_preserve_order(s)
    assert(d.keys() == ['water', 'fire', 'grass'])

# Generated at 2022-06-23 20:12:47.560860
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


# Unit tests for function get_expired_cook

# Generated at 2022-06-23 20:12:48.818914
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None


# Generated at 2022-06-23 20:12:50.018580
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == "<ExplicitNullAuth()>"

# Generated at 2022-06-23 20:13:01.726013
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json
    import doctest


# Generated at 2022-06-23 20:13:04.476911
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    """
    Ensure that the constructor of ExplicitNullAuth is correct
    and doesn't raise an exception.
    """
    ExplicitNullAuth()


# Generated at 2022-06-23 20:13:14.644619
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    from datetime import timedelta
    from freezegun import freeze_time


# Generated at 2022-06-23 20:13:19.573036
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        (1, '1 B'),
        (1024, '1.00 kB'),
        (1024*123, '123.00 kB'),
        (1024*12342, '12.05 MB'),
        (1024*1234, '1.21 MB'),
        (1024*1234*1111, '1.31 GB'),
        (1024*1234*1111, '1.3 GB', 1),
    ]

    for n, expected, precision in tests:
        actual = humanize_bytes(n, precision)
        assert actual == expected, \
            "humanize_bytes({0}, {1}) expected {2}, got {3}".format(
                n, precision, expected, actual)

# Generated at 2022-06-23 20:13:25.461132
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(3) == '3 B'
    assert humanize_bytes(1026) == '1.00 kB'
    assert humanize_bytes(1204) == '1.18 kB'
    assert humanize_bytes(1234) == '1.21 kB'
    assert humanize_bytes(1204, precision=1) == '1.2 kB'

# Generated at 2022-06-23 20:13:25.991082
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:13:32.880964
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    from freezegun import freeze_time


# Generated at 2022-06-23 20:13:34.257494
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

    assert auth is not None


# Generated at 2022-06-23 20:13:40.058775
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"name":"john", "age":"12"}'
    # {'name': 'john', 'age': '12'}
    json_dict = load_json_preserve_order(json_str)

    assert(type(json_dict) is OrderedDict)
    assert(list(json_dict.keys())[0] == 'name')

if __name__ == "__main__":
    test_load_json_preserve_order()

# Generated at 2022-06-23 20:13:41.281739
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/foo/bar.txt') == 'text/plain'

# Generated at 2022-06-23 20:13:43.498047
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"

# Generated at 2022-06-23 20:13:46.655943
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    try:
        auth = ExplicitNullAuth()
        assert auth
    except AssertionError as e:
        print("Error in ExplicitNullAuth(): ", e)



# Generated at 2022-06-23 20:13:52.712481
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:14:02.522130
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from requests.cookies import RequestsCookieJar

    # Test cookie was created at 2014-01-09T15:53:49.000Z.
    # Test cookie expires at 2014-05-19T13:30:00.000Z.
    # Test cookie expired at 2015-01-09T15:53:49.000Z.
    now = datetime(2015, 1, 10)  # next day, so it will be expired
    current_time = now.timestamp()

    # noinspection SpellCheckingInspection

# Generated at 2022-06-23 20:14:10.551201
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:14:17.771969
# Unit test for function get_content_type
def test_get_content_type():

    assert get_content_type('spam.txt') == 'text/plain'
    assert get_content_type('spam.py') == 'text/x-python'
    assert get_content_type('spam.css') == 'text/css'
    assert get_content_type('spam.xlsx') == \
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    assert get_content_type('spam.png') == 'image/png'
    assert get_content_type('spam.bmp') == 'image/bmp'

# Generated at 2022-06-23 20:14:25.257730
# Unit test for function repr_dict
def test_repr_dict():
    assert 'None' == repr_dict({})
    assert '{0: None}' == repr_dict({0: {}})
    assert 'None' == repr_dict({'a': None})
    assert 'None' == repr_dict({1: {2: 3}, 'a': 1, 'b': None, 'c': {'d': 1}})
    assert 'None' == repr_dict({1: {None: None}})
    assert 'None' == repr_dict({None: None})

# Generated at 2022-06-23 20:14:33.211135
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'foo2=bar2; Expires=Wed, 09 Jun 2021 10:18:14 GMT')
    ]
    now = time.time()
    assert get_expired_cookies(headers=headers, now=now) == []
    assert get_expired_cookies(
        headers=headers,
        now=now + (30 * 24 * 60 * 60)
    ) == [{'name': 'foo', 'path': '/'}]

# Generated at 2022-06-23 20:14:33.859578
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:14:34.915619
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:14:37.483145
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None


# Generated at 2022-06-23 20:14:40.972278
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"


# Generated at 2022-06-23 20:14:50.045893
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # str 형식으로 받아서 json 형식으로 정렬한다.
    json_data = '{"name":"jisumi","age":20}'
    # json_data의 형식을 보여준다.
    print(json_data)
    # str(json_data)의 형식을 보여준다.
    print(str(json_data))
    # json.dumps(json_data)의 형식을 보여준다.
    print(json.dumps(json_data))
    #

# Generated at 2022-06-23 20:14:54.975145
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{"foo": [1, 2], "bar": {"hello": "world"}}"""
    expected_dict = OrderedDict([('foo', [1, 2]), ('bar', OrderedDict([('hello', 'world')]))])
    actual_dict = load_json_preserve_order(s)
    assert expected_dict == actual_dict

# Generated at 2022-06-23 20:14:55.884319
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 20:15:06.101865
# Unit test for function get_content_type
def test_get_content_type():
    assert (get_content_type('foo.html') == 'text/html')
    assert (get_content_type('foo.css') == 'text/css')
    assert (get_content_type('foo.svg') == 'image/svg+xml')
    assert (get_content_type('foo.svgz') == 'image/svg+xml')
    assert (get_content_type('foo.css.map') == 'text/plain')
    assert (get_content_type('foo.js') == 'application/javascript')
    assert (get_content_type('foo.json') == 'application/json')
    assert (get_content_type('foo.txt') == 'text/plain')
    assert (get_content_type('foo.svgz') == 'image/svg+xml')

# Generated at 2022-06-23 20:15:09.189483
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 3, "b": 2, "c": 1}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('a', 3), ('b', 2), ('c', 1)])



# Generated at 2022-06-23 20:15:12.576902
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/a/b/c.txt') == 'text/plain'
    assert get_content_type('/a/b/c.txt.gz') == 'application/x-gzip'
    assert get_content_type('/a/b/c.tar.xz') == 'application/x-xz'



# Generated at 2022-06-23 20:15:14.879155
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{"price": 3, "name": "Donald", "species": "duck"}"""
    j = load_json_preserve_order(s)
    assert list(j.items()) == [("price", 3), ("name", "Donald"), ("species", "duck")]

# Generated at 2022-06-23 20:15:21.269645
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from .contextmanagers import responses

    auth = ExplicitNullAuth()
    with responses.RequestsMock() as rsps:
        rsps.add('GET', 'http://www.example.com', body='<html></html>')
        resp = requests.get('http://www.example.com', auth=auth)
        assert resp.content == b'<html></html>'

# Generated at 2022-06-23 20:15:27.413969
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'id': 'spam',
        'attributes': {
            'spam': 'egg',
            'spam spam spam spam spam spam': 'spam spam spam spam spam spam',
        },
    }
    r = repr_dict(d)
    assert r == """\
{'id': 'spam',
 'attributes': {'spam': 'egg',
                'spam spam spam spam spam spam': 'spam spam spam spam spam spam'}}"""



# Generated at 2022-06-23 20:15:39.422909
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.csv') == 'text/csv'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.tar.gz') == 'application/x-gzip'
    assert get_content_type('foo.xml') == 'application/xml'
    assert get_content_type('foo.tar.bz2') == 'application/x-bzip2'
    assert get_content_type('foo.tar.xz') == 'application/x-xz'
    assert get_content_

# Generated at 2022-06-23 20:15:45.004019
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import io
    s = """{
    "foo": "bar",
    "baz": 1,
    "qux": [
        "quux",
        "corge"
        ]
    }"""
    o = load_json_preserve_order(s)

    f = io.StringIO()
    json.dump(o, f, sort_keys=True)
    assert f.getvalue() == s


# Generated at 2022-06-23 20:15:47.087000
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/dev/null') == 'text/plain'
    assert get_content_type('/dev/null.txt') == 'text/plain'
    assert get_content_type('/dev/null.pdf') == 'application/pdf'

# Generated at 2022-06-23 20:15:51.233140
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('https://www.youtube.com/watch?v=PwMZPmDFHs8')
    assert content_type == 'application/x-quicktimeplayer'


# Generated at 2022-06-23 20:15:52.982884
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    param_r = None

    return ExplicitNullAuth().__call__(param_r)



# Generated at 2022-06-23 20:15:56.752158
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert repr_dict(OrderedDict((('a', 1), ('b', 2)))) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:16:04.957828
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Expires=Tue, 26 Jul 2026 14:24:44 GMT'),
        ('Set-Cookie', 'baz=qux; Max-Age=3600'),
        ('Set-Cookie', 'baz=quux; Max-Age=3600'),
    ]

    assert len(get_expired_cookies(headers=headers, now=time.time())) == 0

    assert get_expired_cookies(headers=headers, now=2444444444444444) == [
        {'name': 'foo', 'path': '/'},
        {'name': 'baz', 'path': '/'},
        {'name': 'baz', 'path': '/'},
    ]

if __name__ == '__main__':
    test

# Generated at 2022-06-23 20:16:06.338493
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth(None) is None

# Generated at 2022-06-23 20:16:18.793793
# Unit test for function get_content_type
def test_get_content_type():
    base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    csv_file_name = os.path.join(base_path, 'tests', 'fixtures', 'test.csv')
    csv_content_type = "text/csv"

    def test_file_exists(file_name):
        assert os.path.isfile(file_name)

    test_file_exists(csv_file_name)

    assert get_content_type(csv_file_name) == csv_content_type

import json
import os
import time
from collections import OrderedDict
import httpretty
import requests
from requests.models import Response
from typing import List, Optional, Tuple

import pytest
from requests.exceptions import Request

# Generated at 2022-06-23 20:16:25.868075
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # This function should be tested with as many types of JSON data as you can.
    for json_data in [
        """{"1": "2", "3": "4", "5": "6"}""",
        """[["1", "2"], ["3", "4"], ["5", "6"]]""",
        """{"1": {"2": "3"}, "4": {"5": "6"}}""",
        """[{"1": "2", "3": "4"}, {"5": "6", "7": "8"}]""",
    ]:
        l = load_json_preserve_order(json_data)
        assert isinstance(l, OrderedDict)
        print(l)

# Generated at 2022-06-23 20:16:29.662006
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    loaded = load_json_preserve_order("""
    ["foo", {"bar":["baz", null, 1.0, 2]}]
    """)
    assert repr(loaded) == repr(["foo", OrderedDict([('bar', ['baz', None, 1.0, 2])])])

# Generated at 2022-06-23 20:16:33.546686
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1}') \
           == load_json_preserve_order('{"a": 1, "b": 2}') == {"a": 1}
    assert load_json_preserve_order('{"b": 2, "a": 1}') \
               == OrderedDict([("b", 2), ("a", 1)])


# Generated at 2022-06-23 20:16:34.179856
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth

# Generated at 2022-06-23 20:16:42.422815
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:16:46.384938
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('a.jpg') == 'image/jpeg'
    assert get_content_type('a.txt') == 'text/plain'
    assert get_content_type('a.zip') == 'application/zip'

# Generated at 2022-06-23 20:16:50.771471
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.models import Request
    a = ExplicitNullAuth()
    r = Request('GET', 'http://httpbin.org')
    r = a(r)
    assert r.headers.get('Authorization') == 'None'

# Generated at 2022-06-23 20:16:51.434609
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()


# Generated at 2022-06-23 20:16:52.420237
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    token = ExplicitNullAuth()

# Generated at 2022-06-23 20:16:59.541307
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Now is in the past, but cookies are not expired, so nothing is returned.
    headers = [
        ('Set-Cookie', 'alpha=bravo; Path=/'),
        ('Set-Cookie', 'charlie=delta; Path=/; Max-Age=172800')
    ]
    cookies = get_expired_cookies(
        headers=headers, now=1194090881.761462
    )
    assert cookies == []

    # Now is in the future, and cookies are expired, so they are returned.
    headers = [
        ('Set-Cookie', 'alpha=bravo; Path=/'),
        ('Set-Cookie', 'charlie=delta; Path=/; Max-Age=172800')
    ]

# Generated at 2022-06-23 20:17:07.384753
# Unit test for function humanize_bytes
def test_humanize_bytes():
    selftest_args = [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB', 2),
        (1024 * 1234, '1.21 MB', 2),
        (1024 * 1234 * 1111, '1.31 GB', 2),
        (1024 * 1234 * 1111, '1.3 GB', 1)
    ]
    for args, expected in selftest_args:
        assert humanize_bytes(*args) == expected



# Generated at 2022-06-23 20:17:09.455462
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth1 = ExplicitNullAuth()
    auth2 = ExplicitNullAuth()
    assert auth1 == auth2
    assert auth1.__dict__ == auth2.__dict__



# Generated at 2022-06-23 20:17:17.150827
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from unittest import TestCase
    from unittest.mock import Mock
    from urllib.parse import urlunsplit

    # noinspection PyMethodParameters
    class request(Mock):
        """
        A mock which mocks ``request.prepare_url`` and
        ``request.prepare_headers``.

        """

        def __init__(self, url):
            super().__init__()
            self.url = url

        def prepare_url(self, url, params):
            del params
            return url

        def prepare_headers(self, headers):
            return dict(headers)


# Generated at 2022-06-23 20:17:18.606346
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None


# Generated at 2022-06-23 20:17:23.479947
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import unittest


    class ExplicitNullAuth___call__Test(unittest.TestCase):
        def test_it(self):
            auth = ExplicitNullAuth()
            req = requests.Request('GET', 'http://example.com')
            prepped = auth(req)
            self.assertTrue(req is prepped)


    unittest.main()

# Generated at 2022-06-23 20:17:25.439285
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    doc = load_json_preserve_order('{"a":"b"}')
    assert doc == {'a': 'b'}

# Generated at 2022-06-23 20:17:36.501971
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    When ExplicitNullAuth is used as ``auth`` parameter to ``requests.get``,
    then ``requests`` doesn't try to load credentials from ``.netrc``.
    """
    # noinspection PyUnresolvedReferences
    from tests.conftest import netrc_path

    import requests

    import os
    try:
        with open(netrc_path, 'r') as f:
            old_netrc_content = f.read()
    except FileNotFoundError:
        old_netrc_content = None

    # Wipe out the .netrc

# Generated at 2022-06-23 20:17:43.461478
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import _basic_auth_str
    sys.modules['netrc'] = None
    username = 'test'
    password = 'test'
    auth = ExplicitNullAuth()
    response = requests.Response()
    response.url = 'https://example.com'
    request = requests.Request()
    request.headers['Authorization'] = _basic_auth_str(username, password)
    request = request.prepare()
    request = auth(request)
    assert request.headers.get('Authorization') == _basic_auth_str(username, password)

# Generated at 2022-06-23 20:17:48.843851
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Test of ordered load
    s = '{"1": "things", "2": "stuff"}'
    data = json.loads(s)
    assert data == {'1': 'things', '2': 'stuff'}
    data = load_json_preserve_order(s)
    assert data == OrderedDict([('1', 'things'), ('2', 'stuff')])

    # Test of float load
    s = '{"1": 1.0, "2": "stuff"}'
    data = json.loads(s)
    assert data == {'1': 1.0, '2': 'stuff'}
    data = load_json_preserve_order(s)
    assert data == OrderedDict([('1', 1.0), ('2', 'stuff')])

# Generated at 2022-06-23 20:17:50.511421
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():

    # Pass

    auth = ExplicitNullAuth()
    response = auth(None)
    assert response is None



# Generated at 2022-06-23 20:17:51.901150
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth is not None



# Generated at 2022-06-23 20:17:58.409657
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'



# Generated at 2022-06-23 20:18:02.682198
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Check that the order of keys is preserved
    assert repr_dict(load_json_preserve_order("""{"c": 1, "a": 2, "b": 3}""")) == (
        'OrderedDict([("c", 1), ("a", 2), ("b", 3)])'
    )

# Generated at 2022-06-23 20:18:08.344041
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    >>> test_load_json_preserve_order()
    {'k1': {'k2': 'v2'}, 'k3': 'v3'}
    """
    s = '{"k3": "v3", "k1": {"k2": "v2"}}'
    return load_json_preserve_order(s)


# Generated at 2022-06-23 20:18:18.829168
# Unit test for function humanize_bytes
def test_humanize_bytes():

    HumanizeBytesTestCase = namedtuple('HumanizeBytesTestCase',
                                       ['n', 'expected'])


# Generated at 2022-06-23 20:18:19.388533
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:18:23.895199
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    def dump_json(d) -> str:
        return json.dumps(d, sort_keys=True)

    d = OrderedDict(
        [('foo', 'bar'), ('pi', 3.14), ('t', True), ('f', False)]
    )
    assert load_json_preserve_order(dump_json(d)) == d
    assert load_json_preserve_order(json.dumps(d)) == d



# Generated at 2022-06-23 20:18:29.585643
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookie_header = [
        ('Set-Cookie', 'Session_ID=qi5x5q1qj1zevvol; Domain=.nwz.at; Path=/; Expires=Tue, 01-Oct-2019 08:39:59 GMT; Secure; HttpOnly')]
    expired_cookie = {
        'path': '/',
        'name': 'Session_ID'
    }
    assert get_expired_cookies(headers=cookie_header, now=100000000000000) == [expired_cookie]

# Generated at 2022-06-23 20:18:36.845780
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime

    now = datetime.utcnow().timestamp()
    assert get_expired_cookies([
        ('Set-Cookie', 'expires=1; Max-Age=0'),
        ('Set-Cookie', 'expires=2; Max-Age=-1'),
        ('Set-Cookie', 'max_age=3; Expires=%s' % (now + 1)),
        ('Set-Cookie', 'max_age=4;')
    ], now=now) == [
        {
            'name': 'expires',
            'path': '/'
        },
        {
            'name': 'expires',
            'path': '/'
        }
    ]

# Generated at 2022-06-23 20:18:40.489146
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"z": 3, "y": 2, "x": 1}'
    d = load_json_preserve_order(json_string)
    assert ['z', 'y', 'x'] == list(d.keys())

# Generated at 2022-06-23 20:18:45.757703
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    m = {"a": 1, "b": 2, "c": 3}
    s = json.dumps(m)
    assert load_json_preserve_order(s) == {"a": 1, "b": 2, "c": 3}
    assert load_json_preserve_order(s) == OrderedDict([("a", 1), ("b", 2), ("c", 3)])

# Generated at 2022-06-23 20:18:46.504030
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:18:50.540838
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'a': '1',
        'b': '2'
    }
    output = repr_dict(d)
    assert output == pformat(d)

# Generated at 2022-06-23 20:18:52.638291
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo/bar.jpg') == 'image/jpeg'



# Generated at 2022-06-23 20:18:58.975596
# Unit test for function get_content_type
def test_get_content_type():
    import pytest

    @pytest.mark.parametrize(
        'filename, content_type', [
            ('test.txt', 'text/plain; charset=us-ascii'),
            ('test.html', 'text/html; charset=us-ascii'),
            ('test.pdf', 'application/pdf'),
            ('test.foo', None)
        ]
    )
    def test(filename, content_type):
        assert get_content_type(filename) == content_type

    test()

# Generated at 2022-06-23 20:19:04.835333
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    req = requests.Request(
        'GET',
        'http://127.0.0.1:8000/some-api/',
        auth=ExplicitNullAuth()
    )
    assert req.__dict__['_auth'] == ExplicitNullAuth()
    assert isinstance(req.__dict__['_auth'], ExplicitNullAuth)



# Generated at 2022-06-23 20:19:10.340888
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"
    assert repr_dict({'a': 'b', 'c': 'd'}) == "{'a': 'b', 'c': 'd'}"
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': {'b': {'c': 'd'}}}) == "{'a': {'b': {'c': 'd'}}}"



# Generated at 2022-06-23 20:19:19.975559
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:19:20.578803
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # there is nothing to test with
    assert True

# Generated at 2022-06-23 20:19:27.580815
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    input1='{"foo": "bar", "baz": "quux"}'
    expected1=OrderedDict([('foo','bar'),('baz','quux')])
    assert load_json_preserve_order(input1) == expected1, "load_json_preserve_order fails when JSON is dictionary."
    input2='{"foo": ["bar", "quux"]}'
    expected2=OrderedDict([('foo',['bar', 'quux'])])
    assert load_json_preserve_order(input2) == expected2, "load_json_preserve_order fails when value is a list."
    input3='{"foo": {"bar": "baz", "quux": "corge"}}'

# Generated at 2022-06-23 20:19:29.200075
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from . import test_ExplicitNullAuth
    test_ExplicitNullAuth.test_ExplicitNullAuth___call__()


# Generated at 2022-06-23 20:19:35.275165
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{
      "a": 1,
      "c": 3,
      "b": 2,
      "d": 4
   }"""
    od = load_json_preserve_order(s)
    assert od.popitem(last=False) == ('a', 1)
    assert od.popitem(last=False) == ('c', 3)
    assert od.popitem(last=False) == ('b', 2)
    assert od.popitem(last=False) == ('d', 4)

# Generated at 2022-06-23 20:19:44.238624
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # Test some normal cases
    assert humanize_bytes(1) == '1 B', \
        'Something wrong with 1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB', \
        'Something wrong with 1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB', \
        'Something wrong with 123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB', \
        'Something wrong with 12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB', \
        'Something wrong with 12.05 MB'

# Generated at 2022-06-23 20:19:52.892261
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # tests that the function returns the correct item (and is the only item)
    # if the cookie has an expiry time less than the time of the test
    cookies = [{"path": "/", "name": "name", "max-age": "0"}]
    now = time.time()
    cookie_list = get_expired_cookies(cookies, now)
    assert len(cookie_list) == 1
    assert cookie_list[0] == {'path': '/', 'name': 'name'}
    # tests that the function returns the correct item (and is the only item)
    # if the cookie has an explicit expiry time less than the time of the test
    cookies = [{"path": "/", "name": "name", "expires": str(now-1)}]

# Generated at 2022-06-23 20:19:59.090475
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1234) == '1.23 kB'
    assert humanize_bytes(1234567) == '1.18 MB'
    assert humanize_bytes(1234567890) == '1.15 GB'
    assert humanize_bytes(1234567890123) == '1.12 TB'
    assert humanize_bytes(1234567890123456) == '1.10 PB'
    assert humanize_bytes(1234567, precision=0) == '1 MB'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(12342, precision=1) == '12.1 kB'


# Generated at 2022-06-23 20:20:05.875607
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_str_1 = '{"test_key": "test_value"}'
    test_str_2 = '{"test_key": "test_value", "test_key2": "test_value2"}'
    result_1 = load_json_preserve_order(test_str_1)
    result_2 = load_json_preserve_order(test_str_2)

    assert result_1 == OrderedDict([('test_key', "test_value")])
    assert result_2 == OrderedDict([('test_key', "test_value"), ('test_key2', "test_value2")])

# Generated at 2022-06-23 20:20:07.604979
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    c = ExplicitNullAuth()

    assert c(None) is None



# Generated at 2022-06-23 20:20:10.610678
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"b":2,"a":1}') == OrderedDict([('b', 2), ('a', 1)])


# Generated at 2022-06-23 20:20:11.760287
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is auth

# Generated at 2022-06-23 20:20:17.542704
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Stub
    class StubResponse(object, ):

        @classmethod
        def raise_for_status(cls): pass

    # Assume
    class Assume(object, ):

        r = StubResponse

    # Action
    # noinspection PyUnboundLocalVariable
    r = ExplicitNullAuth.__call__(Assume)

    # Assert
    assert r is Assume.r



# Generated at 2022-06-23 20:20:19.763720
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict()) == '{}'
    assert repr_dict({'foo': 'bar'}) == "{'foo': 'bar'}"

# Generated at 2022-06-23 20:20:28.923020
# Unit test for function get_content_type
def test_get_content_type():
    # These tests require a stable version of `mimetypes`
    assert get_content_type('index.html') == 'text/html'
    assert get_content_type('README.txt') == 'text/plain'
    assert get_content_type('README.TXT') == 'text/plain'
    assert get_content_type('README.md') == 'text/x-markdown'
    assert get_content_type('README.MD') == 'text/x-markdown'
    assert get_content_type('README.MD.bz2') == 'application/x-bzip2'
    assert get_content_type('README.MD.gz') == 'application/gzip'
    assert get_content_type('README.MD.xz') == 'application/x-xz'


# Generated at 2022-06-23 20:20:37.137359
# Unit test for function humanize_bytes

# Generated at 2022-06-23 20:20:39.863385
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2}'
    assert load_json_preserve_order(s) == {"a": 1, "b": 2}

# Generated at 2022-06-23 20:20:44.374446
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_input = '{"a":1, "b":2, "c":3}'
    assert load_json_preserve_order(json_input) == {"a":1, "b":2, "c":3}

if __name__ == '__main__':
    test_load_json_preserve_order()

# Generated at 2022-06-23 20:20:44.943630
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:20:47.542050
# Unit test for function get_content_type
def test_get_content_type():
    filename = 'tests/data/foo.html'
    assert get_content_type(filename) == 'text/html'

if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-23 20:20:49.243895
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == '<ExplicitNullAuth>'

# Generated at 2022-06-23 20:20:55.938441
# Unit test for function get_content_type
def test_get_content_type():
    for filename, content_type in (
        ('foo.html', 'text/html'),
        ('foo.pdf', 'application/pdf'),
        ('foo.css', 'text/css'),
        ('foo.js', 'application/javascript'),
        ('foo.json', 'application/json'),
        ('foo.jpg', 'image/jpeg'),
        ('foo.gif', 'image/gif'),
        ('foo.png', 'image/png'),
        ('foo.ttf', 'application/x-font-ttf'),
        ('foo.woff', 'application/font-woff'),
        ('foo.woff2', 'font/woff2'),
        ('foo.eot', 'application/vnd.ms-fontobject'),
        ('foo.svg', 'image/svg+xml'),
    ):
        assert get_

# Generated at 2022-06-23 20:21:05.368770
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:21:07.088546
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"b": 2, "a": 1}'
    d = load_json_preserve_order(s)
    assert d == OrderedDict([('b', 2), ('a', 1)])

# Generated at 2022-06-23 20:21:07.779555
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"

# Generated at 2022-06-23 20:21:20.244102
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:21:27.106135
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Session
    from requests.auth import AuthBase
    from requests.compat import urljoin

    class DummyAuth(AuthBase):
        def __call__(self, r):
            r.headers['X-Dummy'] = 'foo'
            return r

    s = Session()
    s.auth = DummyAuth()
    resp = s.get(urljoin(__location__, 'fixtures/basic.txt'))
    assert resp.headers.get('X-Dummy') == 'foo'

    s.auth = ExplicitNullAuth()
    resp = s.get(urljoin(__location__, 'fixtures/basic.txt'))
    assert resp.headers.get('X-Dummy') is None



# Generated at 2022-06-23 20:21:36.803841
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    SAMPLE_COOKIES = [
        'foo=bar; Max-Age=50; Path=/; HttpOnly',
        'bar=baz; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/; HttpOnly',
        'baz=bat; Expires=Tue, 01 Jan 2030 00:00:00 GMT; Path=/; HttpOnly',
        'bat=bap; Max-Age=60; Expires=Sat, 01 Jan 2022 01:01:01 GMT; Path=/; HttpOnly',
    ]
    EXPIRED_COOKIES = get_expired_cookies([('Set-Cookie', cookie) for cookie in SAMPLE_COOKIES],
                                          now=time.time()+100)

# Generated at 2022-06-23 20:21:41.096803
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(a=1, b=2)
    assert repr_dict(d) == "{'a': 1, 'b': 2}"
    d = dict(b=2, a=1)
    assert repr_dict(d) == "{'b': 2, 'a': 1}"

# Generated at 2022-06-23 20:21:43.886057
# Unit test for function repr_dict
def test_repr_dict():
    orig = {'a': 1, 'b': 2}
    result = repr_dict(orig)
    assert result == '{\'a\': 1, \'b\': 2}'

# Generated at 2022-06-23 20:21:45.723668
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)

test_ExplicitNullAuth()

# Generated at 2022-06-23 20:21:51.330295
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('image.jpeg') == 'image/jpeg'
    assert get_content_type('image.unknown') is None


if __name__ == '__main__':
    import logging
    import sys
    from logzero import setup_logger

    setup_logger(name=__name__, level=logging.DEBUG)
    from downloader import Downloader

    Downloader(
        url=sys.argv[1],
        filename=sys.argv[2],
        auth=ExplicitNullAuth()
    ).download()