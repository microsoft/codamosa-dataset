

# Generated at 2022-06-23 20:12:01.065314
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('test.jpg')
    assert content_type == 'image/jpeg'

    content_type = get_content_type('test.jpeg')
    assert content_type == 'image/jpeg'

    content_type = get_content_type('test.gif')
    assert content_type == 'image/gif'

    content_type = get_content_type('test.png')
    assert content_type == 'image/png'

    content_type = get_content_type('test.pdf')
    assert content_type == 'application/pdf'

    content_type = get_content_type('test.txt')
    assert content_type == 'text/plain'

    content_type = get_content_type('test.html')
    assert content_type == 'text/html'



# Generated at 2022-06-23 20:12:05.517668
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    from io import StringIO
    from json import dump

    s = StringIO()
    dump({"b": 2, "a": 1}, s)
    s.seek(0)
    assert [("a", 1), ("b", 2)] == [
        tuple(item) for item in load_json_preserve_order(s.read()).items()
    ]

# Generated at 2022-06-23 20:12:14.440442
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:12:15.750629
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    if not a:
        raise AssertionError("object is not truthy")


# Generated at 2022-06-23 20:12:23.217717
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:12:31.210740
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([]) == []

    now = 0

# Generated at 2022-06-23 20:12:33.779455
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # pylint: disable=unused-variable
    auth = ExplicitNullAuth()
    assert True

# Generated at 2022-06-23 20:12:41.563752
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:12:50.101173
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo') is None
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.bin') == 'application/octet-stream'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.jp2') == 'image/jp2'

# Generated at 2022-06-23 20:12:55.440957
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import random

    # random.Random provides the methods of random.Random and in
    # addition a `getrandbits` method with signature
    # (self, k: int) -> int:
    # Return a Python integer with k random bits.
    random = random.Random()

    for _ in range(10):
        x = random.getrandbits(32)

        # XXX: This only passes because `int` can store any
        # `np.int64_t` value.
        assert ExplicitNullAuth()(x) == x



# Generated at 2022-06-23 20:13:01.787769
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    from requests import Session
    from requests.packages.urllib3.contrib.appengine import AppEngineManager
    auth = ExplicitNullAuth()
    session = Session()
    session.auth = ExplicitNullAuth()
    manager = AppEngineManager(session)
    r = session.get("https://www.google.com")
    print("====status_code===",r.status_code,"=====text====",r.text)
    assert r.status_code == 200

# Generated at 2022-06-23 20:13:09.989189
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{
"1": 1,
"0": 0,
"2": 2,
"3": {
"31": 31,
"32": 32,
"30": 30
}
}"""
    assert load_json_preserve_order(s) == {
        "1": 1,
        "0": 0,
        "2": 2,
        "3": {
            "31": 31,
            "32": 32,
            "30": 30
        }
    }

# Generated at 2022-06-23 20:13:14.836301
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2, "c": 3}')==OrderedDict([('a', 1), ('b', 2), ('c', 3)])


if __name__ == '__main__':
    import nose

    nose.runmodule()

# Generated at 2022-06-23 20:13:24.352933
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:13:32.241994
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:13:32.918982
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:13:42.195296
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('set-cookie', 'foo=some-value; max-age=5; path=/some-path; secure'),
        ('set-cookie', 'bar=some-value; HttpOnly; expires=Tue, 19 Jan 2038 03:14:07 GMT; max-age=5; path=/bar-path; secure'),
        ('set-cookie', 'baz=some-value; secure; httponly; expires=Fri, 01-Jan-2038 00:00:00 GMT; path=/; domain=.example.com'),  # noqa: E501
        ('set-cookie', 'qux=some-value; Expires=Fri, 01-Jan-2038 00:00:00 GMT; Path=/; Domain=.example.com'),
    ]

    # Case 1: Expires is not set
    now = time.time()


# Generated at 2022-06-23 20:13:46.513028
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    input_arg = 'input arg'
    output_arg = ExplicitNullAuth()(input_arg)
    assert input_arg == output_arg



# Generated at 2022-06-23 20:13:55.017659
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024*123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024*12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024*12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024*1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024*1234*1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024*1234*1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:14:00.646487
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.jpeg') == 'image/jpeg'
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.gif') == 'image/gif'
    assert get_content_type('test.tar') == 'application/x-tar'
    assert get_content_type('test.tar.gz') == 'application/gzip'
    assert get_content_type('test.exe') is None

# Generated at 2022-06-23 20:14:02.098702
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert type(auth(None)) is ExplicitNullAuth

# Generated at 2022-06-23 20:14:07.969908
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # HACK: PoC until we have an actual unit test framework.

    # Given that ExplicitNullAuth is instantiated as an instance
    auth = ExplicitNullAuth()

    # When it's called on a response
    response = auth(None)

    # Then the response is passed through
    assert response is None  # because the response sent is None

# Generated at 2022-06-23 20:14:10.305838
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert repr(auth(None)) == '<PreparedRequest []>'

# Generated at 2022-06-23 20:14:14.451830
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(40) == '40 B'
    assert humanize_bytes(4096) == '4.0 kB'
    assert humanize_bytes(4096 * 4096) == '16.0 MB'

# Generated at 2022-06-23 20:14:22.493202
# Unit test for function get_content_type
def test_get_content_type():
    file_name_text_html = 'hello.html'
    file_name_image_jpeg = 'abc.jpeg'
    file_name_image_png = 'abc.png'
    file_name_application_pdf = 'abc.pdf'
    file_name_application_zip = 'abc.zip'
    file_name_application_octetstream = 'abc.bin'
    file_name_audio_mpeg = 'abc.mpeg'
    file_name_audio_ogg = 'abc.ogg'
    file_name_audio_wav = 'abc.wav'
    file_name_video_mp4 = 'abc.mp4'

    mime_type_text_html = 'text/html'
    mime_type_image_jpeg = 'image/jpeg'
    mime_type_image_png

# Generated at 2022-06-23 20:14:30.486649
# Unit test for function get_content_type
def test_get_content_type():
    tests = [
        (('test_file.mp4', 'video/mp4'),),
        (('test_file.py', 'text/x-python'),),
        (('test_file.jpeg', 'image/jpeg'),),
        (('test_file.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),),

    ]
    for test in tests:
        assert get_content_type(test[0][0]) == test[0][1]


if __name__ == '__main__':
    print(get_expired_cookies([('Set-Cookie', 'foo=bar; expires=Wed, 01-Jan-1970 00:00:00 GMT; Max-Age=0')]))

# Generated at 2022-06-23 20:14:32.244551
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.xls') == 'application/vnd.ms-excel'

# Generated at 2022-06-23 20:14:41.285536
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # Test cases from the comments
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    # Other random

# Generated at 2022-06-23 20:14:51.909203
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from urllib.parse import urlparse
    from datetime import datetime, timedelta
    from requests_toolbelt.utils import cookiejar_from_dict

    def get_cookie_expiry(cookie_d, now_dt):
        t = cookie_d.get('expires', '-')
        if t is not None:
            if t == '-':
                return
            exp_dt = datetime.strptime(t, '%a, %d-%b-%Y %H:%M:%S GMT')
            return now_dt - exp_dt

    now = datetime.utcnow()
    for i in range(3):
        now = now + timedelta(days=i)

# Generated at 2022-06-23 20:14:54.354026
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"b": 1, "a": 2}') == OrderedDict([('b', 1), ('a', 2)])

# Generated at 2022-06-23 20:14:59.208146
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    d = dict(a=1, b=2)
    d['c'] = d
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'c': [Circular]}"
    assert repr_dict({}) == "{}"
    assert repr_dict(dict(a=1, b=2, c=3, d=4, e=5, f=6)) == (
        "{'a': 1, 'b': 2, "
        "'c': 3,\n"
        " 'd': 4,\n"
        " 'e': 5,\n"
        " 'f': 6}"
    )

# Generated at 2022-06-23 20:15:04.347104
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # import unittest
    now = time.time()

# Generated at 2022-06-23 20:15:13.838817
# Unit test for function get_content_type
def test_get_content_type():
    class TestCase:
        def __init__(self, filename, expected):
            self.filename = filename
            self.expected = expected


# Generated at 2022-06-23 20:15:19.628951
# Unit test for function repr_dict
def test_repr_dict():
    input_ = {'b': 2, 'a': 1}
    target = "{\n    'a': 1,\n    'b': 2\n}"
    actual = repr_dict(d=input_)
    if target != actual:
        print('target != actual', repr(target), repr(actual))


# Generated at 2022-06-23 20:15:28.320409
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1, 1) == '1.0 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-23 20:15:39.800849
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest
    from datetime import datetime, timezone

    now = datetime.utcnow().replace(tzinfo=timezone.utc).timestamp()

    def expired_cookies_for(headers, now=None) -> List[dict]:
        return get_expired_cookies(headers=headers, now=now or now)

    with pytest.raises(TypeError):
        expired_cookies_for(1)

    with pytest.raises(ValueError):
        expired_cookies_for([])

    with pytest.raises(ValueError):
        expired_cookies_for([(1, 2)])

    with pytest.raises(ValueError):
        expired_cookies_for(['foo', 'bar'])

    with pytest.raises(AssertionError):
        expired

# Generated at 2022-06-23 20:15:45.742278
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    now = datetime.utcnow()
    expired_header = ['{}; Expires={}; Path=/'.format('foo', (now + timedelta(hours=1)).strftime("%a, %d %b %Y %H:%M:%S GMT"))]
    not_expired_header = ['{}; Expires={}; Path=/'.format('foo', (now + timedelta(hours=10)).strftime("%a, %d %b %Y %H:%M:%S GMT"))]
    expired_cookie = get_expired_cookies([('Set-Cookie', x) for x in expired_header], now.timestamp())
    assert expired_cookie == [{
        'name': 'foo',
        'path': '/'
    }]
    not_expired_

# Generated at 2022-06-23 20:15:50.360206
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'application/x-gzip'
    assert get_content_type('foo.txt.bz2') == 'application/x-bzip2'

# Generated at 2022-06-23 20:15:56.614713
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Unit test for method __call__ of class ExplicitNullAuth.

    See https://github.com/michael-lazar/rtv/issues/329.

    """

    # If the test fails, the requests session will not close. The test
    # will fail with a timeout ("expected done, got not done").

    def do_something():
        with requests.Session() as session:
            session.auth = ExplicitNullAuth()
            session.get('http://reddit.com')

    do_something()

# Generated at 2022-06-23 20:15:58.215711
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

    assert isinstance(auth, requests.auth.AuthBase)

# Generated at 2022-06-23 20:16:04.567731
# Unit test for function repr_dict
def test_repr_dict():
    # Test 1
    dictionary = {'a': 1, 'b': 2, 'c': 3}
    expected = "{'a': 1, 'b': 2, 'c': 3}"
    actual = repr_dict(dictionary)
    assert actual == expected

    # Test 2
    dictionary = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    expected = "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"
    actual = repr_dict(dictionary)
    assert actual == expected

    # Test 3
    dictionary = {}
    expected = '{}'
    actual = repr_dict(dictionary)
    assert actual == expected

# Generated at 2022-06-23 20:16:13.146881
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-23 20:16:15.062627
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/tmp/foobar.txt') == 'text/plain'
    ct = get_content_type('/tmp/abc/xyz.png')
    assert ct == 'image/png'


if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-23 20:16:23.779348
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest
    now = 1575109383.6298605
    assert get_expired_cookies(headers=[
        ('Set-Cookie', 'foo=bar; max-age=3; path=/'),
        ('Set-Cookie', 'baz=quux; path=/'),
        ('Set-Cookie', 'hello=world; Expires=Wed, 21 Oct 2050 12:00:00 GMT'),
        ('Set-Cookie', 'wuwuwuwuwuwuwuwu; Expires=Wed, 21 Oct 2010 12:00:00 GMT'),
    ], now=now) == [
        {'name': 'wuwuwuwuwuwuwuwu', 'path': '/'},
    ]



# Generated at 2022-06-23 20:16:31.895262
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024,1) == '1.0 kB'
    assert humanize_bytes(1024*123, 1) == '123.0 kB'
    assert humanize_bytes(1024*12342, 1) == '12.1 MB'
    assert humanize_bytes(1024*12342, 2) == '12.05 MB'
    assert humanize_bytes(1024*1234, 2) == '1.21 MB'
    assert humanize_bytes(1024*1234*1111, 2) == '1.31 GB'
    assert humanize_bytes(1024*1234*1111, 1) == '1.3 GB'

# Generated at 2022-06-23 20:16:33.420566
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert isinstance(auth, ExplicitNullAuth)

# Generated at 2022-06-23 20:16:39.699037
# Unit test for function get_content_type

# Generated at 2022-06-23 20:16:45.459417
# Unit test for function get_content_type
def test_get_content_type():
    from unittest import TestCase
    from unittest.case import TestCase
    from unittest.mock import patch

    class GetContentTypeTest(TestCase):
        @patch('mimetypes.guess_type')
        def test_get_content_type(self, mock_guess_type):
            mock_guess_type.return_value = ('text/plain', 'utf-8')
            filename = 'something.txt'
            result = get_content_type(filename=filename)
            assert result == 'text/plain; charset=utf-8'

    GetContentTypeTest().test_get_content_type()

# Generated at 2022-06-23 20:16:47.058279
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth(None) is None

# Generated at 2022-06-23 20:16:56.999439
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=b; Expires=Tue, 16 Jan 2029 18:59:55 GMT; Path=/'),
        ('Set-Cookie', 'c=d; Expires=Tue, 16 Jan 2019 18:59:55 GMT; Path=/'),
        ('Set-Cookie', 'e=f; Expires=Tue, 16 Jan 2019 18:59:55 GMT; Path=/'),
    ]

    cookies = get_expired_cookies(
        headers,
        now=time.mktime((2019, 1, 16, 19, 0, 0, 0, 0, 0)),
    )

    assert cookies == [
        {'name': 'e', 'path': '/'},
        {'name': 'c', 'path': '/'},
    ]

# Generated at 2022-06-23 20:16:59.596643
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    with pytest.raises(AttributeError):
        ExplicitNullAuth().__call__()



# Generated at 2022-06-23 20:17:08.980025
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:17:18.655538
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1, precision=0) == '1 B'
    assert humanize_bytes(1024, precision=0) == '1 kB'
    assert humanize_bytes(1024 * 1024, precision=0) == '1 MB'
    assert humanize_bytes(1024 * 1024 * 1024, precision=0) == '1 GB'
    assert humanize_bytes(1024 * 1024 * 1024, precision=0) == '1 GB'
    assert humanize_bytes(1234567890, precision=1) == '1.2 GB'
    assert humanize_bytes(1234567890, precision=2) == '1.15 GB'
    assert humanize_bytes(1234567890, precision=3) == '1.147 GB'

# Generated at 2022-06-23 20:17:20.451603
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert requests.get(
        'http://www.google.com',
        auth=ExplicitNullAuth()
    ).text

# Generated at 2022-06-23 20:17:25.088959
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    This function tests function load_json_preserve_order.
    """
    json_object = load_json_preserve_order(
        '{"first":1, "second":2, "third":3}'
    )
    expected = OrderedDict([("first", 1), ("second", 2), ("third", 3)])
    assert json_object == expected

# Generated at 2022-06-23 20:17:27.785799
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'



# Generated at 2022-06-23 20:17:33.586569
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    """When ``.netrc`` exists, requests should not use it."""
    httpbin = 'https://httpbin.org'
    auth = ExplicitNullAuth()
    resp = requests.get(
        httpbin + '/basic-auth/user/passwd',
        auth=auth,
    )
    resp.raise_for_status()
    assert resp.status_code == 401

# Generated at 2022-06-23 20:17:39.758897
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert '1.34 KB' == humanize_bytes(1340, precision=2)
    assert '1.4 KB' == humanize_bytes(1340, precision=1)

    assert '1.34 MB' == humanize_bytes(1340 * 1024, precision=2)
    assert '1.36 MB' == humanize_bytes(1361 * 1024, precision=2)

if __name__ == '__main__':
    test_humanize_bytes()

# Generated at 2022-06-23 20:17:42.321855
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 3, "b": "foo"}') == {"a": 3, "b": "foo"}

# Generated at 2022-06-23 20:17:45.373454
# Unit test for function repr_dict
def test_repr_dict():
    test_dict = {'test': '1', 'test2': '2'}
    test_string = repr_dict(test_dict)
    assert test_string == "{'test': '1', 'test2': '2'}"

# Generated at 2022-06-23 20:17:52.066246
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/html' == get_content_type('index.html')
    assert 'image/jpeg' == get_content_type('image.jpeg')
    # FIXME: The following assertion fails.
    # assert 'image/jpeg; charset=ISO-8859-1' == get_content_type('image.jpg')



# Generated at 2022-06-23 20:17:59.098687
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        [0, '0 B'],
        [1, '1 B'],
        [1023, '1023 B'],
        [1024, '1.00 kB'],
        [1024 * 1024, '1.00 MB'],
        [1024 * 1024 * 1024, '1.00 GB'],
        [1024 * 1024 * 1024 * 1024, '1.00 TB'],
    ]
    for n, expected in tests:
        assert humanize_bytes(n) == expected



# Generated at 2022-06-23 20:18:07.666776
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    def fn(**kwargs):
        return {}
    for k, v in list(globals().items()):
        globals()['__old' + k] = v
        globals()[k] = fn

# Generated at 2022-06-23 20:18:10.970401
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = """{"a": "b", "c": {"d": [1, 2, 3]}}"""
    json_obj = load_json_preserve_order(json_string)
    assert list(json_obj.keys()) == ["a", "c"]

# Generated at 2022-06-23 20:18:21.033952
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:18:21.517229
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:18:22.676226
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-23 20:18:31.457867
# Unit test for function repr_dict
def test_repr_dict():
    d = {"a": 1,
         "b": 2,
         "c": [1, 2, 3]}
    repr_d = repr_dict(d)
    assert repr_d == "{'a': 1, 'b': 2, 'c': [1, 2, 3]}"
    d2 = {"a": 1,
          "b": 2,
          "c": [1, 2, 3],
          "d": {"a": 1,
                "b": 2,
                "c": [1, 2, 3]}}
    repr_d2 = repr_dict(d2)
    assert repr_d2 == "{'a': 1, 'b': 2, 'c': [1, 2, 3], 'd': {'a': 1, 'b': 2, 'c': [1, 2, 3]}}"

# Generated at 2022-06-23 20:18:39.425236
# Unit test for function get_content_type
def test_get_content_type():
    import unittest

    class TestGetContentType(unittest.TestCase):
        def test_python_script(self):
            self.assertEqual(
                'text/plain; charset=us-ascii',
                get_content_type('/path/to/some/file.py')
            )

        def test_html_file(self):
            self.assertEqual(
                'text/html; charset=utf-8',
                get_content_type('/path/to/some/file.html')
            )

    unittest.main(module=__name__, exit=False)

# Generated at 2022-06-23 20:18:48.625055
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = """{"glossary": {"title": "example glossary", "GlossDiv": {"title": "S", "GlossList": {"GlossEntry": {"ID": "SGML", "SortAs": "SGML", "GlossTerm": "Standard Generalized Markup Language", "Acronym": "SGML", "Abbrev": "ISO 8879:1986", "GlossDef": {"para": "A meta-markup language, used to create markup languages such as DocBook.", "GlossSeeAlso": ["GML", "XML"]}, "GlossSee": "markup"}}}}}"""
    ret = load_json_preserve_order(json_string)
    print(ret)

# Generated at 2022-06-23 20:18:59.205525
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from math import isclose
    from random import randrange
    from textwrap import dedent

    # Generate a list of cookies with timestamp `now`
    now = round(time.time())
    cookies = [
        (f'name{num}', {
            'value': f'value{num}',
            'path': '/',
            'expires': now + randrange(60 * 60, 60 * 60 * 24 * 2)
        })
        for num in range(randrange(5, 10))
    ]

# Generated at 2022-06-23 20:19:02.703415
# Unit test for function repr_dict
def test_repr_dict():
    test_dict = dict()

    test_dict['key1'] = 1
    test_dict['key2'] = 2
    test_dict['key3'] = 3

    result = repr_dict(test_dict)
    assert isinstance(result, str)
    assert result == "{'key1': 1, 'key2': 2, 'key3': 3}"

# Generated at 2022-06-23 20:19:06.199957
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():  # noqa: D103
    assert load_json_preserve_order('{"a": 1, "b": 2}') == {
        "a": 1,
        "b": 2
    }



# Generated at 2022-06-23 20:19:11.439078
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest


# Generated at 2022-06-23 20:19:15.473658
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '[{"b": 2, "a": 1}, {"d": 4, "c": 3}]'
    o = load_json_preserve_order(s)
    assert o == [{'b': 2, 'a': 1}, {'d': 4, 'c': 3}]

# Generated at 2022-06-23 20:19:16.135763
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:19:23.949183
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == '{\'a\': 1, \'b\': 2}'
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == '{\'a\': 1, \'b\': 2, \'c\': 3, \'d\': 4}'
    assert repr_dict({'a': 1, 'b': [2, 3]}) == '{\'a\': 1, \'b\': [2, 3]}'
    assert repr_dict({'a': 1, 'b': {'c': 'hi', 'd': 'hello'}}) == '{\'a\': 1, \'b\': {\'c\': \'hi\', \'d\': \'hello\'}}'

# Generated at 2022-06-23 20:19:27.508523
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = r'''{"a":"haha",
    "b":"haha",
    "c":[{"a":"b","c":"d"},
    "e":"f"},
    "d":"hehe",
    "e":"hehe"}'''
    assert s == json.dumps(load_json_preserve_order(s))

# Generated at 2022-06-23 20:19:32.407104
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order(s='''{"foo": "bar"}''') == \
        OrderedDict([('foo', 'bar')])
    assert load_json_preserve_order(s='''{"baz": "buzz", "foo": "bar"}''') == \
        OrderedDict([('baz', 'buzz'), ('foo', 'bar')])

# Generated at 2022-06-23 20:19:36.438553
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    >>> from requests.auth import HTTPDigestAuth
    >>> auth = ExplicitNullAuth()
    >>> auth = auth(HTTPDigestAuth('user', 'pass'))
    >>> auth.username, auth.password
    ('user', 'pass')
    """



# Generated at 2022-06-23 20:19:37.396511
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)

# Generated at 2022-06-23 20:19:45.013838
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-23 20:19:47.288607
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    expected = "{\n'a': 1,\n'b': 2\n}"

    assert repr_dict(d) == expected



# Generated at 2022-06-23 20:19:54.582052
# Unit test for function humanize_bytes
def test_humanize_bytes():
    def hb(n, expected):
        assert humanize_bytes(n) == expected

    hb(1, '1 B')
    hb(1024, '1.0 kB')
    hb(1024 * 123, '123.0 kB')
    hb(1024 * 12342, '12.1 MB')
    hb(1024 * 12342, '12.05 MB', precision=2)
    hb(1024 * 1234, '1.21 MB', precision=2)
    hb(1024 * 1234 * 1111, '1.31 GB', precision=2)
    hb(1024 * 1234 * 1111, '1.3 GB', precision=1)

# Generated at 2022-06-23 20:19:56.778506
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert hasattr(ExplicitNullAuth(), '__call__')


# Generated at 2022-06-23 20:19:58.836582
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    request = requests.Request('GET', 'http://localhost')
    assert auth(request) == request

# Generated at 2022-06-23 20:20:07.022307
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import unittest


# Generated at 2022-06-23 20:20:08.197137
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:20:19.034315
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from .test_util import eq_

    now = time.time() + 5

# Generated at 2022-06-23 20:20:24.732577
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{\'a\': \'b\'}"
    assert repr_dict({'a': 'b', 'c': 'd'}) == "{\'a\': \'b\', \'c\': \'d\'}"


__all__ = ['load_json_preserve_order', 'repr_dict', 'humanize_bytes',
           'test_repr_dict', 'get_expired_cookies', 'ExplicitNullAuth',
           'get_content_type']

# Generated at 2022-06-23 20:20:28.073345
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/path/file.txt') == 'text/plain'
    assert get_content_type('/path/image.jpg') == 'image/jpeg'
    assert get_content_type('nonexistent.txt') is None



# Generated at 2022-06-23 20:20:35.442820
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([
        ('Set-Cookie', 'a=1; Max-Age=1000'),
        ('Set-Cookie', 'b=2; Path=/foo; Max-Age=2000'),
        ('Set-Cookie', 'c=3; Domain=example.org; Max-Age=3000'),
        ('Set-Cookie', 'd=4; Path=/foo; Domain=example.org; Max-Age=4000'),
        ('Set-Cookie', 'e=5; Expires=Thu, 01 Jan 1970 00:00:00 GMT')
    ], now=500) == [{'name': 'e', 'path': '/'}]

# Generated at 2022-06-23 20:20:36.346221
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:20:38.447210
# Unit test for function repr_dict
def test_repr_dict():
    actual = repr_dict({'a': 1, 'b': 2})
    expected = "{'a': 1, 'b': 2}"
    assert actual == expected

# Generated at 2022-06-23 20:20:48.026722
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # case 1 - random number
    assert humanize_bytes(666) == '666 B'
    # case 2 - 1 kb
    assert humanize_bytes(1024) == '1.00 kB'
    # case 3 - 1 mb
    assert humanize_bytes(1024 * 1024) == '1.00 MB'
    # case 4 - 1 gb
    assert humanize_bytes(1024 * 1024 * 1024) == '1.00 GB'
    # case 5 - 1 tb
    assert humanize_bytes(1024 * 1024 * 1024 * 1024) == '1.00 TB'
    # case 6 - 1 pb
    assert humanize_bytes(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB'
    # case 7 - 1000 pb

# Generated at 2022-06-23 20:20:52.089023
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__(): # noqa: D103
    import requests

    # This is required as we're testing that our subclass doesn't
    # raise any exceptions.
    # noinspection PyUnresolvedReferences
    requests.netrc = None
    netrc_instance = requests.auth.netrc.netrc()
    auth = ExplicitNullAuth()
    assert auth(netrc_instance) is netrc_instance

# Generated at 2022-06-23 20:21:01.862350
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:21:04.819822
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_text = """
    {
        "b": 1,
        "a": 1
    }
    """
    result = load_json_preserve_order(json_text)
    assert list(result.keys()) == ['b', 'a']

# Generated at 2022-06-23 20:21:05.710363
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth('dummy') == 'dummy'

# Generated at 2022-06-23 20:21:08.494029
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if (humanize_bytes(1) != '1 B'):
        raise AssertionError
    if (humanize_bytes(1024) != '1.0 kB'):
        raise AssertionError
    if (humanize_bytes(1024 * 1024) != '1.0 MB'):
        raise AssertionError


test_humanize_bytes()

# Generated at 2022-06-23 20:21:16.085638
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # Test if the order of map keys is preserved
    input = '{"a":1,"b":2,"c":3,"d":4}'
    result = load_json_preserve_order(input)
    expected = OrderedDict([('a', 1), ('b', 2), ('c', 3), ('d', 4)])
    assert result == expected, "Loaded JSON is not in correct order"

# Generated at 2022-06-23 20:21:19.768808
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1, "b": 2}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict)
    assert d.keys() == ['a', 'b']

# Generated at 2022-06-23 20:21:21.146204
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Testing method __call__ of class ExplicitNullAuth
    # on instance
    ExplicitNullAuth()()
    return None

# Generated at 2022-06-23 20:21:27.105542
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB', 2),
        (1024 * 1234, '1.21 MB', 2),
        (1024 * 1234 * 1111, '1.31 GB', 2),
        (1024 * 1234 * 1111, '1.3 GB', 1),
    ]
    for (n, expected, precision) in tests:
        assert humanize_bytes(n, precision) == expected

# Generated at 2022-06-23 20:21:28.337240
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)


# Generated at 2022-06-23 20:21:34.375034
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = int(time.time())
    headers = [
        ('Set-Cookie', "session=a_session; path=/; expires=%s" % str(now + 10 * 60 * 60 * 24 * 365)),
        ('Set-Cookie', "sid=123; path=/; expires=%s" % str(now + 5 * 60 * 60 * 24 * 365)),
        ('Set-Cookie', "max-age=a_cookie; path=/; max-age=1"),
        ('Set-Cookie', "no-expire=a_cookie; path=/"),
    ]
    expired_cookies = [
        {'name': "max-age", 'path': '/'},
        {'name': "no-expire", 'path': '/'},
    ]

# Generated at 2022-06-23 20:21:45.524686
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


# Generated at 2022-06-23 20:21:52.869816
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # 1. Test with OrderedDict and dict (validation)
    dict = OrderedDict([("x", 5), ("y", 6)])
    dict2 = {("x", 5), ("y", 6)}
    json_dict = json.dumps(dict)
    assert load_json_preserve_order(json_dict) == dict
    json_dict = json.dumps(dict2)
    assert load_json_preserve_order(json_dict) == dict2

    # 2. Test with dict and OrderedDict
    dict = dict({("x", 5), ("y", 6)})
    dict2 = OrderedDict({("x", 5), ("y", 6)})
    json_dict = json.dumps(dict)
    assert load_json_preserve_order(json_dict) == dict2