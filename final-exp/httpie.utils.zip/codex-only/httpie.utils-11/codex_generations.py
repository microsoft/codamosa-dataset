

# Generated at 2022-06-23 20:11:56.876159
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies(
        [
            ('set-cookie', 'foo=bar'),
            (
                'set-cookie',
                'baz=qux; '
                'expires=Fri, 31 Dec 9999 23:59:59 GMT; '
                'HttpOnly'
            ),
            (
                'set-cookie',
                'quux=corge; '
                'max-age=555555; '
                'HttpOnly'
            )
        ],
        now=time.time() + 600
    )
    expected = [
        {
            'name': 'quux',
            'path': '/'
        }
    ]
    assert sorted(cookies, key=lambda c: c['name']) == expected

# Generated at 2022-06-23 20:12:06.509022
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'c': 3, 'b': 2, 'a': 1}) == "{'c': 3, 'b': 2, 'a': 1}"
    assert repr_dict({'c': 3, 'a': 1, 'b': 2}) == "{'c': 3, 'a': 1, 'b': 2}"
    assert repr_dict({'b': 2, 'c': 3, 'a': 1})

# Generated at 2022-06-23 20:12:15.518305
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from io import StringIO


# Generated at 2022-06-23 20:12:21.078268
# Unit test for function repr_dict
def test_repr_dict():
    d1 = dict(a='a', b='b')
    assert repr_dict(d1) == "{'a': 'a', 'b': 'b'}"

    d2 = dict(z='z', y='y')
    d3 = dict(d2)
    d3.update(d1)
    assert repr_dict(d3) == "{'y': 'y', 'z': 'z', 'a': 'a', 'b': 'b'}"

# Generated at 2022-06-23 20:12:29.688915
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.txt.bz2') is None
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.pdf') == 'application/pdf'

# Generated at 2022-06-23 20:12:33.538246
# Unit test for function repr_dict
def test_repr_dict():
    test_dict = dict()
    test_dict['key1'] = 'value1'
    assert repr_dict(test_dict) == "{'key1': 'value1'}"

# Generated at 2022-06-23 20:12:40.984123
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert(humanize_bytes(0) == '0 B')
    assert(humanize_bytes(1) == '1 B')
    assert(humanize_bytes(1024) == '1.00 kB')
    assert(humanize_bytes(1024 * 1024) == '1.00 MB')
    assert(humanize_bytes(1024 * 1024 * 1024) == '1.00 GB')
    assert(humanize_bytes(1024 * 1024 * 1024 * 1024) == '1.00 TB')
    assert(humanize_bytes(1024 * 1024 * 1024 * 1024 * 1024) == '1.00 PB')
    assert(humanize_bytes(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == '1024.00 PB')

# Generated at 2022-06-23 20:12:47.119161
# Unit test for function repr_dict
def test_repr_dict():
    actual = repr_dict({'a': 1, 'b': 2})
    expected = '{\n    "a": 1,\n    "b": 2\n}'
    assert actual == expected

# Generated at 2022-06-23 20:12:52.274141
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({1: 'one', 2: 'two'}) == "{1: 'one', 2: 'two'}"
    assert repr_dict(dict(x=1, y=2)) == "{'x': 1, 'y': 2}"
    assert repr_dict(dict([('x', 1), ('y', 2), ('z', 3)])) == \
           "{'x': 1, 'y': 2, 'z': 3}"

# Generated at 2022-06-23 20:12:52.965386
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()



# Generated at 2022-06-23 20:13:02.122336
# Unit test for function get_content_type

# Generated at 2022-06-23 20:13:02.663242
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:13:13.643205
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.htm') == 'text/html'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.jsonp') is None
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'

# Generated at 2022-06-23 20:13:18.987440
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order("""
        {
          "d": 3,
          "a": 1,
          "b": 2,
          "c": {
            "e": 5,
            "f": 6
          }
        }
    """) == OrderedDict([
        ('d', 3),
        ('a', 1),
        ('b', 2),
        ('c', OrderedDict([
            ('e', 5),
            ('f', 6)
        ])),
    ])



# Generated at 2022-06-23 20:13:25.142622
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    from collections import OrderedDict
    json_str = '{"one": 1, "two": 2, "three": 3}'
    d = load_json_preserve_order(json_str)
    assert isinstance(d, OrderedDict)
    assert d == OrderedDict([
        ("one", 1), ("two", 2), ("three", 3)
    ])

# Generated at 2022-06-23 20:13:33.217197
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json

    def _assert_same(a, b):
        assert a == b
        assert json.dumps(a) == json.dumps(b)
        assert type(a) == type(b)

    s = '[{"a": 1, "b": 2}, {"a": 3, "b": 4}]'
    _assert_same(load_json_preserve_order(s), json.loads(s))
    _assert_same(load_json_preserve_order(s), [{"a": 1, "b": 2}, {"a": 3, "b": 4}])
    _assert_same(load_json_preserve_order(s), [({"a": 1, "b": 2}), ({"a": 3, "b": 4})])

# Generated at 2022-06-23 20:13:39.301785
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:13:46.162600
# Unit test for function get_content_type
def test_get_content_type():

    def assert_equal(path, expected):
        content_type = get_content_type(path)
        assert content_type == expected, \
            f'{path!r} content-type is {content_type!r} (expected {expected!r})'

    assert_equal('foo.bar', None)
    assert_equal('foo.txt', 'text/plain')
    assert_equal('foo.html', 'text/html')
    assert_equal('foo.htm', 'text/html')
    assert_equal('foo.js', 'application/javascript')
    assert_equal('foo.css', 'text/css')
    assert_equal('foo.png', 'image/png')
    assert_equal('foo.jpg', 'image/jpeg')
    assert_equal('foo.gif', 'image/gif')



# Generated at 2022-06-23 20:13:51.366270
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([
        ('Set-Cookie',
         'A=A; Max-Age=0.001; Path=/'),
        ('Set-Cookie',
         'B=B; Max-Age=0.002; Path=/'),
        ('Set-Cookie',
         'C=C; Max-Age=0; Path=/'),
    ], now=0)
    assert cookies == [
        {'name': 'A', 'path': '/'},
        {'name': 'B', 'path': '/'},
        {'name': 'C', 'path': '/'},
    ]



# Generated at 2022-06-23 20:13:55.706231
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '[{"hello": "world"}, {"foo": "bar"}]'
    expected = [OrderedDict([('hello', 'world')]), OrderedDict([('foo', 'bar')])]
    assert load_json_preserve_order(s) == expected

# Generated at 2022-06-23 20:13:56.325964
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:14:07.522982
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    time1=time.time()
    time2=time.time()+3600
    assert get_expired_cookies([('Set-Cookie', 'SID=31d4d96e407aad42; Path=/; Expires=Tue, 22 Aug 2017 13:31:05 UTC; Secure')],[('Set-Cookie', 'SID=31d4d96e407aad42; Path=/; Expires=Tue, 22 Aug 2017 13:31:05 UTC; Secure')])==[]


# Generated at 2022-06-23 20:14:12.226697
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': {'a': 1, 'b': 2}}) == "{'a': {'a': 1, 'b': 2}}"

# Generated at 2022-06-23 20:14:21.341038
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:14:23.771448
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Arrange
    a = ExplicitNullAuth()
    # Act
    r = a(r=None)
    # Assert
    assert r is None

# Generated at 2022-06-23 20:14:35.596685
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('test.txt')
    assert 'text/plain; charset=UTF-8' == get_content_type('test.txt.utf8')
    assert 'text/plain; charset=cp1250' == get_content_type('test.txt.cp1250')
    assert 'application/zip' == get_content_type('test.zip')
    assert 'application/zip' == get_content_type('test.ZIP')
    assert 'application/zip' == get_content_type('test.Zip')
    assert 'application/java-archive' == get_content_type('test.jar')
    assert 'application/java-archive' == get_content_type('test.JAR')
    assert 'application/java-archive' == get_content_type('test.Jar')

# Generated at 2022-06-23 20:14:36.915077
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(None) is None



# Generated at 2022-06-23 20:14:47.077023
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1546081954.8288035

# Generated at 2022-06-23 20:14:48.529502
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    response = auth('some request')
    assert response == 'some request'

# Generated at 2022-06-23 20:14:54.338605
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=123; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'bar=456; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'baz=789; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'qux=abc; Path=/; Max-Age=3600'),
    ]
    now = 1445368080
    assert get_expired_cookies(headers, now) \
        == [{'path': '/', 'name': 'foo'}, {'path': '/', 'name': 'baz'}]

# Generated at 2022-06-23 20:15:00.459466
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '''{
      "key": "value",
      "key2": "value2"
    }'''
    d = load_json_preserve_order(s)
    assert d == json.loads(s)
    assert list(d.items()) == [('key', 'value'), ('key2', 'value2')]
    assert repr(d) == repr_dict(d)
    assert repr_dict(d) == repr_dict(json.loads(s))
    assert repr_dict(d) != repr_dict(OrderedDict(json.loads(s).items()))

# Generated at 2022-06-23 20:15:06.382799
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # This is a simple test for now, just to make sure the
    # function will work, without checking for the order
    # that the keys are in.
    orig = {
        'favorite_color': 'blue',
        'favorite_shape': 'square',
        'favorite_number': 42,
    }
    s = json.dumps(orig)
    d = load_json_preserve_order(s)
    assert d == orig

# Generated at 2022-06-23 20:15:08.104605
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({1: "a", 2: "b"}) == "{1: 'a', 2: 'b'}"

# Generated at 2022-06-23 20:15:14.708318
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1, 1) == '1.0 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-23 20:15:15.886796
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:15:26.610570
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:28.536203
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert isinstance(auth, ExplicitNullAuth)


# Generated at 2022-06-23 20:15:29.178378
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth

# Generated at 2022-06-23 20:15:40.092849
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:44.812066
# Unit test for function humanize_bytes
def test_humanize_bytes():  # noqa: D401
    assert humanize_bytes(2 ** 10) == '1.0 kB'
    assert humanize_bytes(2 ** 11) == '2.0 kB'
    assert humanize_bytes(2 ** 20) == '1.0 MB'
    assert humanize_bytes(2 ** 30) == '1.0 GB'
    assert humanize_bytes(2 ** 40) == '1.0 TB'
    assert humanize_bytes(2 ** 50) == '1.0 PB'
    assert humanize_bytes(2 ** 60) == '1024.00 PB'



# Generated at 2022-06-23 20:15:50.204841
# Unit test for function get_content_type
def test_get_content_type():
    from pprint import pprint
    mimetypes.init()
    pprint(mimetypes.encodings_map)
    for filename in ('test.html', 'test.css', 'test.js', 'test.map', 'test.ts'):
        print(filename, get_content_type(filename))

# Generated at 2022-06-23 20:15:51.616651
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1024) == '1.00 kB'

# Generated at 2022-06-23 20:15:56.208866
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('sample.png') == 'image/png'
    assert get_content_type('sample.css') == 'text/css'
    assert get_content_type('sample.html') == 'text/html'
    assert get_content_type('Sample.TXT') == 'text/plain'
    assert get_content_type('sample.foo') is None

# Generated at 2022-06-23 20:15:56.955559
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:16:05.077418
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def assert_cookies_equal(
        cookies_expected: List[dict],
        cookies_actual: List[dict]
    ):
        assert len(cookies_expected) == len(cookies_actual)
        for c_exp, c_act in zip(cookies_expected, cookies_actual):
            assert c_exp == c_act

    def assert_expired_cookies(
        cookies: List[dict],
        expired_cookies_expected: List[dict],
        now: float = None
    ):
        expired_cookies_actual = get_expired_cookies(cookies=cookies, now=now)
        assert_cookies_equal(
            cookies_expected=expired_cookies_expected,
            cookies_actual=expired_cookies_actual
        )

    now = time.time()


# Generated at 2022-06-23 20:16:13.564755
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from . import http_utils


# Generated at 2022-06-23 20:16:16.518171
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 'b'}
    assert repr_dict(d) == "{'a': 'b'}\n"

# Generated at 2022-06-23 20:16:25.026742
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:16:26.208610
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()(None) is None

# Generated at 2022-06-23 20:16:34.493434
# Unit test for function humanize_bytes
def test_humanize_bytes():

    test_cases = (
        # (input, output)
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024*123, '123.0 kB'),
        (1024*12342, '12.1 MB'),
        (1024*12342, '12.05 MB'),
        (1024*1234, '1.21 MB'),
        (1024*1234*1111, '1.31 GB'),
        (1024*1234*1111, '1.3 GB'),
    )

    for bytes_input, expected_output in test_cases:
        for precision in range(4):
            output = humanize_bytes(bytes_input, precision=precision)

# Generated at 2022-06-23 20:16:40.724044
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_input = """
{
"key1": "value1",
"key2": "value2",
"key3": "value3",
"key4": {
"key5": "value5",
"key6": "value6"
}
}
"""
    json_output = load_json_preserve_order(json_input)
    assert json_output.keys() == ['key1', 'key2', 'key3', 'key4']
    assert json_output['key4'].keys() == ['key5', 'key6']

# Generated at 2022-06-23 20:16:41.152643
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:16:42.029951
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None

# Generated at 2022-06-23 20:16:45.588967
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    from collections import OrderedDict
    from pprint import pformat

    s = '{"a": 1, "b": 2, "c": 3}'
    expected = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    result = load_json_preserve_order(s)
    assert expected == result

# Generated at 2022-06-23 20:16:51.467761
# Unit test for function repr_dict
def test_repr_dict():
    # Test double quotes
    assert repr_dict({'a': '"b"', 'c': '"d"'}) == "{'a': '\"b\"', 'c': '\"d\"'}"

    # Test single quotes
    assert repr_dict({'a': "'b'", 'c': "'d'"}) == "{'a': \"'b'\", 'c': \"'d'\"}"

# Generated at 2022-06-23 20:16:58.902121
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:17:02.238605
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Check that calls to __call__ return the passed-in request object
    req = 'request1'
    auth = ExplicitNullAuth()
    assert auth.__call__(req) == req



# Generated at 2022-06-23 20:17:04.414862
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests

    assert not isinstance(
        ExplicitNullAuth()(requests.Request()),
        requests.Request
    )



# Generated at 2022-06-23 20:17:09.474218
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    input_text = """{
        "zoo": "valuez",
        "foo": "valuef",
        "bar": "valueb"
    }"""

    expected_result = OrderedDict([
        ("zoo", "valuez"),
        ("foo", "valuef"),
        ("bar", "valueb"),
    ])

    output_text = load_json_preserve_order(input_text)
    assert expected_result == output_text

# Generated at 2022-06-23 20:17:11.953173
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # First we test a case where everything goes right
    auth = ExplicitNullAuth()
    r = requests.get('http://defunkt.io', auth=auth)
    assert r.status_code == 200

# Generated at 2022-06-23 20:17:23.194140
# Unit test for function humanize_bytes
def test_humanize_bytes():  # pragma: no cover
    def hb(n, result, msg=None):
        r = humanize_bytes(n)
        assert r == result, msg or '%s == %s, expected %s' % (n, r, result)

    hb(1, '1 B')
    hb(10, '10 B')
    hb(100, '100 B')
    hb(1024, '1.0 kB')
    hb(1024 * 123, '123.0 kB')
    hb(1024 * 12342, '12.1 MB')
    hb(1024 * 12342, '12.05 MB', precision=2)
    hb(1024 * 1234, '1.21 MB')
    hb(1024 * 1234, '1.21 MB', precision=3)

# Generated at 2022-06-23 20:17:31.221252
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/tmp/abc.txt') == 'text/plain'
    assert get_content_type('/tmp/abc.html') == 'text/html'
    assert get_content_type('/tmp/abc.py') == 'text/x-python'
    assert get_content_type('/tmp/abc.jpg') == 'image/jpeg'
    assert get_content_type('/tmp/abc.jpeg') == 'image/jpeg'
    assert get_content_type('/tmp/abc.gif') == 'image/gif'
    assert get_content_type('/tmp/abc.png') == 'image/png'
    assert get_content_type('/tmp/abc.tif') == 'image/tiff'

# Generated at 2022-06-23 20:17:32.347623
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()(None) is None

# Generated at 2022-06-23 20:17:41.313461
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:17:48.192007
# Unit test for function get_content_type
def test_get_content_type():
    from requests.utils import guess_json_utf
    from .compat import is_py2_utf8
    filename = 'test.json'
    content_type = get_content_type(filename)
    assert content_type == "application/json"
    content_type = guess_json_utf(content_type)
    assert content_type == "application/json"
    if is_py2_utf8():
        assert content_type == "application/json; charset=UTF-8"
    filename = 'test.txt'
    content_type = get_content_type(filename)
    assert content_type is None

# Generated at 2022-06-23 20:17:51.390338
# Unit test for function repr_dict
def test_repr_dict():
    import json

    d = {'a': 1, 'b': {'c': 2, 'd': [3, 4, 5]}}
    j = json.dumps(d)
    assert repr_dict(d) == j

# Generated at 2022-06-23 20:17:53.481845
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('image.jpg')
    assert content_type == 'image/jpeg'

# Generated at 2022-06-23 20:17:54.520306
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth(), ExplicitNullAuth

# Generated at 2022-06-23 20:17:59.693021
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    This test checks if ExplicitNulAuth returns a requests.models.PreparedRequest that has no authentication.
    
    Returns:
        Returns True if the returned requests.models.PreparedRequest has no authentication.
    """
    import requests

    ena = ExplicitNullAuth()
    pr = ena(requests.models.PreparedRequest())
    assert not pr.auth

# Generated at 2022-06-23 20:18:02.850549
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({"a": 1}) == "{'a': 1}"
    assert repr_dict({"a": 1, "b": "b"}) == "{'a': 1, 'b': 'b'}"

# Generated at 2022-06-23 20:18:12.598311
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from io import StringIO

    # Note: .netrc is not checked by get_expired_cookies
    #       It also doesn't work on Windows, so let's just ignore it
    # from .netrc import netrc

    # hostname = 'example.com'
    # auth = netrc(
    #     host=hostname,
    #     port=443,
    #     login='username',
    #     account='password',
    #     password='password',
    # )

    now = datetime.now().timestamp()
    timestamp = datetime.now() - timedelta(days=365)
    timestamp = timestamp.timestamp()

# Generated at 2022-06-23 20:18:15.192659
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    r = requests.Request("GET", "http://example.com")
    r.prepare()
    assert ExplicitNullAuth()(r) is r

# Generated at 2022-06-23 20:18:19.754066
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'key': 'value'}) == "{'key': 'value'}"
    assert repr_dict({'key': 'value', 'other': {'pewpew': 'bebebe'}}) == \
        "{'key': 'value', 'other': {'pewpew': 'bebebe'}}"

# Generated at 2022-06-23 20:18:21.513278
# Unit test for function get_content_type
def test_get_content_type():
    filename = "somefile.txt"
    result = get_content_type(filename)
    assert result == 'text/plain'

# Generated at 2022-06-23 20:18:25.038820
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1024 * 1) == '1.00 kB'
    assert humanize_bytes(1024 * 12) == '12.00 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 1234) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111) == '1.31 GB'

# Generated at 2022-06-23 20:18:27.893113
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"c": 3, "b": 2, "a": 1}') == \
        OrderedDict([('c', 3), ('b', 2), ('a', 1)])

# Generated at 2022-06-23 20:18:36.621752
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    # Now - 4hrs
    _now = now - 4*60*60
    # Now - 5hrs
    _now_5hrs = now - 6*60*60

    # Create a cookie
    cookie_string = 'cookie1=value1; domain=.example.com; ' \
                    'Path=/; expires={}; HttpOnly'. \
        format(_now)

    # Create another cookie
    cookie_string2 = 'cookie2=value2; domain=.example.com; ' \
                     'Path=/; expires={}; HttpOnly'. \
        format(_now_5hrs)

    # Create headers

# Generated at 2022-06-23 20:18:41.302947
# Unit test for function get_content_type
def test_get_content_type():
    """
    >>> get_content_type('foo.txt')
    >>> get_content_type('foo.txt.gz') == 'application/x-gzip'
    True
    >>> get_content_type('changelog.txt') == 'text/plain'
    True

    """
    pass



# Generated at 2022-06-23 20:18:42.996379
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None

# Generated at 2022-06-23 20:18:44.242128
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    authobj = ExplicitNullAuth()
    assert authobj is not None

# Generated at 2022-06-23 20:18:46.786030
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=[1, 2, 3], b=[2, 3, 4])) == "{'a': [1, 2, 3], 'b': [2, 3, 4]}"

# Generated at 2022-06-23 20:18:51.410268
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert (json.dumps({ 'a': 1, 'b': 2 }, sort_keys=True) ==
            json.dumps(load_json_preserve_order('{"b": 2, "a": 1}'), sort_keys=True))

# Generated at 2022-06-23 20:18:57.588360
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """Unit test for function load_json_preserve_order"""
    assert load_json_preserve_order('{"a":1, "b":2}') == {"a": 1, "b": 2}
    assert load_json_preserve_order('{"b":2, "a":1}') != {"a": 1, "b": 2}
    assert load_json_preserve_order('{"b":2, "a":1}') == {"b": 2, "a": 1}

# Generated at 2022-06-23 20:19:03.863663
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(123) == '123 B'
    assert humanize_bytes(1234) == '1.21 kB'
    assert humanize_bytes(1234, precision=1) == '1.2 kB'
    assert humanize_bytes(1234 * 1111, precision=1) == '1.4 MB'

# Generated at 2022-06-23 20:19:05.751869
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    auth('')  # no exception thrown


# Generated at 2022-06-23 20:19:08.137949
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"b": 1, "a": 2}') \
        == OrderedDict([('b', 1), ('a', 2)])



# Generated at 2022-06-23 20:19:12.923008
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = u"""{"a": "A", "b": "B", "c": "C"}"""
    assert json.loads(json_str) == load_json_preserve_order(json_str)
    assert json.loads(json_str) == load_json_preserve_order(
        json_str, object_pairs_hook=OrderedDict
    )

# Generated at 2022-06-23 20:19:21.316071
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from .cookies import get_expired_cookies
    from .util import get_current_url

    now = int(time.time())

    url = 'https://github.com/'

# Generated at 2022-06-23 20:19:30.308872
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime
    from datetime import timedelta

    def _get_session_cookie_expired(
        delta_minutes: int,
        now: float,
        cookie_name: str,
        cookie_path: str
    ):
        return {
            'name': cookie_name,
            'path': cookie_path,
            'expires': now + timedelta(minutes=delta_minutes).total_seconds()
        }

    def _get_session_cookie(
        delta_minutes: int,
        now: float,
        cookie_name: str,
        cookie_path: str
    ):
        return {
            'name': cookie_name,
            'path': cookie_path,
            'max-age': delta_minutes * 60
        }

    now = datetime.now

# Generated at 2022-06-23 20:19:33.521630
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/a/b/c.some-extention') is None
    assert get_content_type('a.py') == 'text/x-python'

# Generated at 2022-06-23 20:19:43.074095
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-23 20:19:51.292010
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-23 20:19:52.983027
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr_dict(d) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:19:58.209923
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import unittest

    class CheckCall(unittest.TestCase):
        def test_returns_request(self):
            import requests
            auth = ExplicitNullAuth()
            request = requests.Request('GET')
            returned_value = auth(request)
            self.assertEqual(returned_value, request)

    CheckCall('test_returns_request').test_returns_request()



# Generated at 2022-06-23 20:20:05.559438
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:20:07.440741
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    pass # TODO: write a unit test for method __call__ of class ExplicitNullAuth

# Generated at 2022-06-23 20:20:18.205616
# Unit test for function humanize_bytes
def test_humanize_bytes():
    """
    >>> print(humanize_bytes(1))
    1 B
    >>> print(humanize_bytes(1024))
    1.00 kB
    >>> print(humanize_bytes(1024*123))
    123.00 kB
    >>> print(humanize_bytes(1024*12342))
    12.05 MB
    >>> print(humanize_bytes(1024*1234*1111,))
    1.31 GB
    >>> print(humanize_bytes(1024*1234*1111,2))
    1.31 GB
    >>> print(humanize_bytes(1024*1234*1111,1))
    1.3 GB
    """


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 20:20:19.428914
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    obj = ExplicitNullAuth()
    assert isinstance(obj, requests.auth.AuthBase)

# Generated at 2022-06-23 20:20:27.944804
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import pytest
    from textwrap import dedent

    s = dedent("""\
        {
        "foo": "bar",
        "baz": ["1", "2", "3", "4"],
        "aaa": "111"
        }
    """)
    d = load_json_preserve_order(s)
    d_keys = [x for x in d.keys()]
    assert d_keys[0] == 'foo'
    assert d_keys[1] == 'baz'
    assert d_keys[2] == 'aaa'

    assert d['foo'] == 'bar'
    assert d['baz'] == ['1', '2', '3', '4']
    assert d['aaa'] == '111'


# Generated at 2022-06-23 20:20:30.174317
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    NullAuth()(req) always returns req

    """
    import requests
    from requests.models import PreparedRequest

    auth = ExplicitNullAuth()
    req = PreparedRequest()

    assert auth(req) is req



# Generated at 2022-06-23 20:20:31.842000
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"



# Generated at 2022-06-23 20:20:38.689428
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Request
    from requests import Session

    auth = ExplicitNullAuth()
    session = Session()
    req = Request(
        method='GET', url='https://www.example.com', auth=auth,
        headers={'x-example': 'value'}
    )
    prep_req = req.prepare()
    assert prep_req.url == req.url
    assert prep_req.method == req.method
    assert prep_req.headers['x-example'] == 'value'
    assert prep_req.cookies == {}



# Generated at 2022-06-23 20:20:42.204564
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    txt = '{"name":"john", "age":30}'
    json_struct = load_json_preserve_order(txt)

    assert str(json_struct) == "{'name': 'john', 'age': 30}"


# Generated at 2022-06-23 20:20:49.195900
# Unit test for function humanize_bytes
def test_humanize_bytes():
    tests = (
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB', 2),
        (1024 * 1234, '1.21 MB', 2),
        (1024 * 1234 * 1111, '1.31 GB', 2),
        (1024 * 1234 * 1111, '1.3 GB', 1),
    )
    for arg, expected, precision in tests:
        assert humanize_bytes(arg, precision) == expected

# Generated at 2022-06-23 20:20:56.941274
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Now is 2018-08-10
    now = time.mktime(time.strptime("Fri Aug 10 00:00:00 2018", "%a %b %d %H:%M:%S %Y"))

    # Session cookie with no expiration
    cookie1 = [('Set-Cookie', 'name1=value1; Path=/example')]
    assert(get_expired_cookies(cookie1, now) == [])

    # Expired cookie, the lack of a value here is intentional and tests that
    # our parsing isn't messed up by a lack of value

# Generated at 2022-06-23 20:20:57.765570
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:20:59.827414
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a-key': 'a-value'}) == "{'a-key': 'a-value'}"

# Generated at 2022-06-23 20:21:02.442629
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json
    from collections import OrderedDict
    assert OrderedDict([('a', 1), ('b', 2), ('c', 3)]) == load_json_preserve_order('{"a": 1, "b": 2, "c": 3}')

# Generated at 2022-06-23 20:21:06.593143
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1, b=2)) == "{'a': 1, 'b': 2}"
    assert repr_dict(dict(a=1, b=2, c={'d': 3, 'e': 4})) \
           == "{'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}"

# Generated at 2022-06-23 20:21:18.778684
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import timedelta
    from hypothesis import given
    from hypothesis import strategies as st

    from .content_headers import make_date_header_name, make_cookie_header

    # Time is passed as parameter to get_expired_cookies so we can
    # predict exactly what cookies are considered expired.
    now = time.time()
    week = now + timedelta(days=7).total_seconds()
    month = now + timedelta(days=30).total_seconds()
    year = now + timedelta(days=365).total_seconds()
    header_name = make_date_header_name('Set-Cookie')


# Generated at 2022-06-23 20:21:22.281213
# Unit test for function repr_dict
def test_repr_dict():
    input = {'a': 'bc', 'de': 'fghi'}
    assert repr_dict(input) == "{'a': 'bc', 'de': 'fghi'}"


# Generated at 2022-06-23 20:21:31.047074
# Unit test for function humanize_bytes

# Generated at 2022-06-23 20:21:43.112228
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:21:51.676032
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json

    # Test the correctness of the output
    assert load_json_preserve_order(
        json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}],
                   indent=2, separators=(',', ':'))
    ) == [
        'foo',
        {
            "bar": [
                "baz",
                None,
                1.0,
                2
            ]
        }
    ]

    # Test the order of the output
    json_str = json.dumps(
        OrderedDict([
            ('foo', 'bar'),
            ('alpha', 'beta'),
            ('baz', 'qux'),
        ]),
        indent=2,
        separators=(',', ':'),
    )
    assert load_json_preserve_order