

# Generated at 2022-06-23 20:11:51.332977
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Unit tests for the functions in this file

# Generated at 2022-06-23 20:11:52.203200
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth

# Generated at 2022-06-23 20:11:58.347972
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests.auth import AuthBase, HTTPBasicAuth

    assert ExplicitNullAuth().__call__ is AuthBase.__call__

    r = dict()
    r['authorization'] = 'basic'
    r['url'] = 'http://example.net/api/v1'
    r['auth'] = ExplicitNullAuth()

    r = dict()
    r['authorization'] = 'basic'
    r['url'] = 'http://example.net/api/v1'
    r['auth'] = ExplicitNullAuth()
    r['auth'] = HTTPBasicAuth('user', 'password')

# Generated at 2022-06-23 20:12:06.609118
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from hypothesis import given, strategies as st

    # ====
    # Setup
    # ====
    #
    # The following covers about 90% of all cookies, I think.
    @st.composite
    def cookies(draw):
        common_attrs = {
            'max-age': st.integers(min_value=1),
            'expires': st.integers().map(lambda n: n % 60000),
            'path': st.text()
        }
        cookie_name = st.text()

        attrs = draw(st.permutations(common_attrs.keys()))
        attr_values = [common_attrs[attr] for attr in attrs]
        attrs.insert(0, cookie_name)
        attr_values.insert(0, cookie_name)

        return

# Generated at 2022-06-23 20:12:15.452696
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    set_cookie_header_values = [
        'foo=bar',
        'bar=baz; Path=/',
        'baz=qux; Domain=localhost; Path=/; Expires=Wed, 01 Jan 2020 00:00:00 GMT',
        'qux=quux; Domain=localhost; Path=/; Max-Age=60',
        'quux=quuux; Max-Age=60',
        'quuux=quuuux; Max-Age=86400',
    ]
    cookies = get_expired_cookies(headers=[('Set-Cookie', v) for v in set_cookie_header_values], now=time.time() + 60)

# Generated at 2022-06-23 20:12:18.297020
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"a": [{"b": 1, "c": 2}, {"b": 3, "c": 4}]}'
    json_obj = load_json_preserve_order(json_str)
    assert repr(json_obj) == "{'a': [{'b': 1, 'c': 2}, {'b': 3, 'c': 4}]}"



# Generated at 2022-06-23 20:12:23.602615
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json
    test_data = '{"b": 2, "a": 1}'
    json_obj = json.loads(test_data)
    if type(json_obj) != OrderedDict:
        print("JSON object is not type OrderedDict")
        return -1
    else:
        print("JSON object is type OrderedDict")
        return 0

test_load_json_preserve_order()

# Generated at 2022-06-23 20:12:28.342275
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    a = b'{"a": "b"}'
    a1 = load_json_preserve_order(a)
    a2 = load_json_preserve_order(a)
    assert a1.keys() == a2.keys()

# Generated at 2022-06-23 20:12:36.539341
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """Test function load_json_preserve_order()."""
    # Arrange
    json_ordered = '{"b": 1, "a": 2}'
    json_unordered = '{"a": 2, "b": 1}'

    # Act
    loaded_ordered = load_json_preserve_order(json_ordered)
    loaded_unordered = load_json_preserve_order(json_unordered)

    # Assert
    assert loaded_ordered == loaded_unordered

# Generated at 2022-06-23 20:12:40.782330
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"f": "v", "a": "z"}'
    assert load_json_preserve_order(s) == OrderedDict([('f', 'v'), ('a', 'z')])



# Generated at 2022-06-23 20:12:42.076703
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:12:50.910162
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Mock module requests.auth.
    import sys
    from unittest.mock import MagicMock
    sys.modules['requests.auth'] = MagicMock()

    # Test function ExplicitNullAuth.__call__.
    import requests.auth

    class MockResponse:
        request = MagicMock()

    auth_obj = ExplicitNullAuth()
    assert auth_obj(MockResponse) is MockResponse.request

    # Ensure that there are no external dependencies.
    assert requests.auth.AuthBase is object



# Generated at 2022-06-23 20:12:57.782788
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"e": 1, "a": {"b": 4, "c": 1}, "d": 2, "c": 3}'
    assert load_json_preserve_order(json_string) == {'e': 1, 'a': {'b': 4, 'c': 1}, 'd': 2, 'c': 3}


# Generated at 2022-06-23 20:13:06.360475
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:13:15.381344
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:13:21.701515
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_in = """
        {
            "g": {
                "e": [
                    "11",
                    "22"
                ]
            },
            "k": "v",
            "kk": "vv"
        }
    """
    json_out = {'g': {'e': ['11', '22']}, 'k': 'v', 'kk': 'vv'}
    assert load_json_preserve_order(json_in) == json_out

# Generated at 2022-06-23 20:13:22.824344
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    _ = ExplicitNullAuth()

# Generated at 2022-06-23 20:13:31.524395
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    from tests.utils import generate_url
    from httpmocker import HttpMocker

    httpmocker = HttpMocker(
        base_path='tests/testdata',
        host=generate_url()
    )

    with httpmocker:
        session = requests.Session()
        url = httpmocker.get_url('/')
        response = session.get(url)

    assert response.url == url
    assert response.ok

    assert not response.cookies
    assert not get_expired_cookies([
        (header_name, header_value)
        for header_name, header_value
        in response.headers.items()
    ])

    with httpmocker:
        session = requests.Session()

# Generated at 2022-06-23 20:13:32.176195
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:13:33.384691
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():

    explicit_null_auth = ExplicitNullAuth()

    response = explicit_null_auth(None)

    assert response is None

# Generated at 2022-06-23 20:13:37.092910
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('dir/file.html') == 'text/html'
    assert get_content_type('dir/file.jpg') == 'image/jpeg'

# Generated at 2022-06-23 20:13:44.207479
# Unit test for function get_content_type
def test_get_content_type():

    for filename in (
        'ben-kiki.org',
        'foo.txt',
        'foo.txt.gz',
        'foo.tgz',
        'bar.json',
        'foo.doc',
        'foo.jpg',
        'foo.jpeg',
        'foo.png',
        'foo.txt.tar',
        'foo.txt.tar.gz',
        'foo.txt.tar.bz2',
    ):
        assert get_content_type(filename) is not None

# Generated at 2022-06-23 20:13:53.586463
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta
    from email.utils import formatdate

    now = formatdate(datetime.now().timestamp())
    headers = [
        ('set-cookie', 'a=1; path=/; expires=Wed, 31-Dec-1997 23:59:59 GMT'),
        ('set-cookie', 'b=2; path=/; max-age=0'),
        ('set-cookie', 'c=3; path=/; max-age=10'),
        ('set-cookie', 'd=4; path=/'),
        ('set-cookie', 'e=5; path=/; expires={}'.format(now)),
    ]
    expired_cookies = get_expired_cookies(headers)
    assert len(expired_cookies) == 2

# Generated at 2022-06-23 20:13:54.042913
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    pass

# Generated at 2022-06-23 20:14:00.036742
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{
    "name": "value",
    "numbers": [
        3,
        1,
        2
    ],
    "pet": "dog"
}""".replace('\n', '')

    expected = {
        'name': 'value',
        'numbers': [
            3,
            1,
            2
        ],
        'pet': 'dog'
    }

    assert load_json_preserve_order(s) == expected

# Generated at 2022-06-23 20:14:11.804705
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = """{
        "order": {
            "data": [{
                "value": "order"
            }]
        },
        "items": {
            "data": [{
                "value": "items"
            }, {
                "value": "items2"
            }],
            "meta": {
                "total": 2
            }
        }
    }"""
    d = load_json_preserve_order(json_str)

# Generated at 2022-06-23 20:14:15.850294
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    d = load_json_preserve_order('''{"f": 1, "a": 1, "e": 1, "b": 1, "c": 1, "d": 1}''')
    assert d.keys() == ['f', 'a', 'e', 'b', 'c', 'd']



# Generated at 2022-06-23 20:14:20.310988
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "OrderedDict([('a', 1), ('b', 2)])"

# Generated at 2022-06-23 20:14:22.607233
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:14:26.952568
# Unit test for function repr_dict
def test_repr_dict():
    d = {"d": ["a", "b", "c"], "z": "d", "as": "d", "sd": "a"}
    assert repr_dict(d) == pformat(d)

# Generated at 2022-06-23 20:14:31.199468
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    obj = {
        'key': 'value',
        'items': [
            'one',
            'two',
        ]
    }
    s = json.dumps(obj)
    assert s == json.dumps(load_json_preserve_order(s))



# Generated at 2022-06-23 20:14:40.693119
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():

    def compare_dicts(d1, d2):
        if len(d1) != len(d2): return False
        for k in d1:
            if k not in d2: return False
            if d1[k] != d2[k]: return False
        return True

    assert compare_dicts({'b': 1, 'a': 2}, {'a': 2, 'b': 1})
    assert not compare_dicts({'a': 2, 'b': 1}, {'b': 1, 'c': 2})

    example = '{"b":1,"a":2}'
    jold = json.loads(example)
    jnew = load_json_preserve_order(example)
    assert jold == jnew
    assert compare_dicts(jold, jnew)

# Generated at 2022-06-23 20:14:41.331134
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:14:50.340880
# Unit test for function get_content_type
def test_get_content_type():
    """Test function :func:`get_content_type`.

    The test cases in this function are meant to cover a wide range of
    filetypes, including those known to ``mimetypes``, unknown filetypes,
    and files with ``.gz`` in their name.

    """

# Generated at 2022-06-23 20:14:51.123102
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth().__call__(None) is None

# Generated at 2022-06-23 20:14:59.744570
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([
        ('Set-Cookie', 'foo=bar; path=/; Expires=Fri, 31 Dec 9999 23:59:59 GMT'),
        ('Set-Cookie', 'baz=bat; path=/; Max-Age=900; HttpOnly'),
        ('Set-Cookie', 'snif=snaf; path=/; Expires=Fri, 20 Dec 2019 00:00:01 GMT'),
        ('Set-Cookie', 'burf=burp; path=/; Expires=Fri, 20 Dec 2019 00:00:00 GMT'),
    ], now=time.mktime(time.strptime('Fri, 20 Dec 2019 00:00:00 GMT', '%a, %d %b %Y %H:%M:%S %Z')))

# Generated at 2022-06-23 20:15:00.661951
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()() is None

# Generated at 2022-06-23 20:15:02.276366
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    requests.get(
        url = "http://localhost",
        auth = ExplicitNullAuth()
    )

# Generated at 2022-06-23 20:15:03.160669
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:15:11.785731
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo/bar.png') == 'image/png'
    assert get_content_type('foo/bar.txt') == 'text/plain'
    assert get_content_type('foo/bar.html') == 'text/html'
    assert get_content_type('foo/bar.css') == 'text/css'
    assert get_content_type('foo/bar.js') == 'application/javascript'
    assert get_content_type('foo/bar.gif') == 'image/gif'
    assert get_content_type('foo/bar.bmp') == 'image/bmp'
    assert get_content_type('foo/bar.ico') == 'image/x-icon'

# Generated at 2022-06-23 20:15:13.747506
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"a": 1}'
    assert isinstance(load_json_preserve_order(s), OrderedDict)

# Generated at 2022-06-23 20:15:19.891621
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    data_string = '{"name":"Bob","family":{"spouse":"Eve","children": ["Alice","John"]}}'
    assert load_json_preserve_order(data_string)
    # FIXME: Do we want to check the output?
    # assert {'name': 'Bob', 'family': {'spouse': 'Eve', 'children': ['Alice', 'John']}}

# Generated at 2022-06-23 20:15:23.338149
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    o = load_json_preserve_order('{"eine": 1, "zwei":2, "drei":3}')
    assert o == {'eine': 1, 'zwei': 2, 'drei': 3}

# Generated at 2022-06-23 20:15:23.959124
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:15:28.492798
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": "b", "c": "d"}') == \
        OrderedDict([('a', 'b'), ('c', 'd')])
    assert load_json_preserve_order('{"c": "d", "a": "b"}') == \
        OrderedDict([('c', 'd'), ('a', 'b')])

# Generated at 2022-06-23 20:15:33.249210
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.TXT') == 'text/plain'
    assert get_content_type('foo.bar') is None

# Generated at 2022-06-23 20:15:41.643082
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:45.357299
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 1, 'b': 'xyz'}) == "{'a': 1, 'b': 'xyz'}"
    assert repr_dict({'a': 1, 'b': {'c': 2}}) == "{\n    'a': 1,\n    'b': {'c': 2}\n}"

# Generated at 2022-06-23 20:15:52.064060
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.css') == 'text/css'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.xml') == 'text/xml'
    assert get_content_type('foo.csv') == 'text/csv'
    assert get_content_type('foo.svg') == 'image/svg+xml'
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_

# Generated at 2022-06-23 20:15:56.407101
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"z": 1, "a": 3, "b": 1}'
    d = load_json_preserve_order(s)
    assert next(iter(d)) == 'z'
    assert d['z'] == 1

# Generated at 2022-06-23 20:15:58.830207
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    assert repr_dict(d) == """{'a': 1, 'b': 2}"""

# Generated at 2022-06-23 20:16:08.399956
# Unit test for function humanize_bytes

# Generated at 2022-06-23 20:16:10.321815
# Unit test for function get_content_type
def test_get_content_type():
    # pylint: disable=unused-argument
    assert get_content_type('myfile.txt') == 'text/plain'

# Generated at 2022-06-23 20:16:12.954954
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(a=42, b=dict(c=23))
    assert repr_dict(d) == "{'a': 42, 'b': {'c': 23}}"

# Generated at 2022-06-23 20:16:18.899978
# Unit test for function get_content_type

# Generated at 2022-06-23 20:16:20.601378
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    # Just constructs an object.
    a

# Generated at 2022-06-23 20:16:21.539231
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None

# Generated at 2022-06-23 20:16:23.053863
# Unit test for function repr_dict
def test_repr_dict():
    d = {1: 1, 2: 2, 3: 3}
    return repr_dict(d)

# Generated at 2022-06-23 20:16:32.494995
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:16:34.455250
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(a=dict(c='foo', d='bar'), b=2,
             c=[1, 2, (3, 4, 'abc')])
    assert repr_dict(d) == repr(d)

# Generated at 2022-06-23 20:16:43.031547
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:16:55.185713
# Unit test for function get_content_type
def test_get_content_type():

    import unittest
    import tempfile

    class TestGetContentType(unittest.TestCase):

        def assertContentType(self, filename, expected):
            self.assertEqual(get_content_type(filename), expected)

        def test_text_plain(self):
            self.assertContentType('README.md', 'text/plain')

        def test_text_csv(self):
            self.assertContentType('foo.csv', 'text/csv')

        def test_image_png(self):
            self.assertContentType('logo.png', 'image/png')

        def test_application_x_gzip(self):
            self.assertContentType('foo.gz', 'application/x-gzip')


# Generated at 2022-06-23 20:17:02.964599
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': {'c': 3}}) == "{'a': 1, 'b': {'c': 3}}"
    assert repr_dict({'a': 9, 'b': [1, 2, 3]}) == "{'a': 9, 'b': [1, 2, 3]}"



# Generated at 2022-06-23 20:17:11.539846
# Unit test for function humanize_bytes
def test_humanize_bytes():  # pragma: no cover
    def test_exact(n, base, expected):
        result = humanize_bytes(n, precision=base)
        if result != expected:
            raise AssertionError(
                "Expected %d B to humanize as %s, not %s" % (n, expected, result)
            )

    test_exact(1, 0, "1 B")
    test_exact(1024, 0, "1 kB")
    test_exact(1024, 1, "1.0 kB")
    test_exact(1024, 2, "1.00 kB")
    test_exact(1024, 3, "1.000 kB")
    test_exact(1024, 4, "1.0000 kB")

# Generated at 2022-06-23 20:17:22.392113
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:17:29.053142
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json0 = '{"a": 0, "b": 1}'
    print('json0:', json0, sep='\n')
    assert load_json_preserve_order(json0) == dict(a=0, b=1)
    assert load_json_preserve_order(json0) != dict(b=1, a=0)
    assert repr(load_json_preserve_order(json0)) == 'OrderedDict([(\'a\', 0), (\'b\', 1)])'
    print()

    json1 = '{"b": 1, "a": 0}'
    print('json1:', json1, sep='\n')
    assert load_json_preserve_order(json1) == dict(b=1, a=0)

# Generated at 2022-06-23 20:17:30.441974
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    s = ExplicitNullAuth()
    assert s is not None

# Generated at 2022-06-23 20:17:31.409014
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == "<ExplicitNullAuth>"

# Generated at 2022-06-23 20:17:35.338803
# Unit test for function repr_dict
def test_repr_dict():
    d = OrderedDict()
    d['one'] = 'first'
    d['two'] = 'second'
    d['three'] = 'third'
    assert repr_dict(d) == "{'one': 'first', 'two': 'second', 'three': 'third'}"

# Generated at 2022-06-23 20:17:41.865715
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('foo.txt')
    assert 'image/jpeg; charset=binary' == \
        get_content_type('foo.jpg')
    assert 'image/jpeg; charset=binary' == \
        get_content_type('foo.jpeg')
    assert get_content_type('foo.png') == \
        'image/png'
    assert get_content_type('foo.nonexistent') == \
        None

# Generated at 2022-06-23 20:17:46.722918
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"c": 3, "b": 2, "a": 1}'
    assert load_json_preserve_order(json_str) == OrderedDict([("c", 3), ("b", 2), ("a", 1)])
    assert repr(load_json_preserve_order(json_str)) == repr(OrderedDict([("c", 3), ("b", 2), ("a", 1)]))
    assert repr(load_json_preserve_order(json_str)) == 'OrderedDict([(\'c\', 3), (\'b\', 2), (\'a\', 1)])'

# Generated at 2022-06-23 20:17:51.317050
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.txt') is None
    assert get_content_type('.htaccess') is None
    assert get_content_type('filename.csv') == 'text/csv'
    assert get_content_type('filename.json') == 'application/json'
    assert get_content_type('filename.gif') == 'image/gif'
    assert get_content_type('filename.zip') == 'application/zip'



# Generated at 2022-06-23 20:18:01.365729
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:18:09.358233
# Unit test for function humanize_bytes

# Generated at 2022-06-23 20:18:10.321268
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

# Generated at 2022-06-23 20:18:16.095705
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = """{"x": 1, "y": 2}"""
    assert load_json_preserve_order(json_str) == {'x': 1, 'y': 2}
    assert repr_dict(load_json_preserve_order(json_str)) == '{u\'x\': 1, u\'y\': 2}'

# Generated at 2022-06-23 20:18:17.530810
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert repr(auth) == '<ExplicitNullAuth>'

# Generated at 2022-06-23 20:18:18.573040
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # This should not raise AssertionError.
    ExplicitNullAuth()

# Generated at 2022-06-23 20:18:27.816825
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_data = """{
                "name": "Deen",
                "age": 30,
                "affiliation": "Self"
                 }
              """
    d = load_json_preserve_order(json_data)
    assert isinstance(d, OrderedDict)
    assert len(d) == 3
    assert 'name' in d
    assert d['name'] == 'Deen'
    assert 'age' in d
    assert d['age'] == 30
    assert 'affiliation' in d
    assert d['affiliation'] == "Self"

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 20:18:35.642262
# Unit test for function humanize_bytes
def test_humanize_bytes():
    for n, expected in [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
        (1024 * 1234 * 1111, '1.3 GB'),
        (1 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000 * 1000,
         '1.0 EB'),
    ]:
        assert humanize_bytes(n) == expected



# Generated at 2022-06-23 20:18:42.105230
# Unit test for function repr_dict
def test_repr_dict():
    dic = {'a': {'b': 1, 'c': 2}, 'd': [1, 2, 3], 'e': 1}
    assert repr_dict(dic).replace(' ', '').replace('\n', '') == \
            """{'a': {'b': 1, 'c': 2}, 'd': [1, 2, 3], 'e': 1}""".replace(
                ' ', '').replace('\n', '')

# Generated at 2022-06-23 20:18:43.073441
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:18:50.914155
# Unit test for function get_content_type
def test_get_content_type():
    import mock

    with mock.patch('mimetypes.guess_type') as mock_guess_type:
        mock_guess_type.return_value = ('text/plain', None)
        content_type = get_content_type('filename')
        assert content_type == 'text/plain'

        mock_guess_type.return_value = ('text/plain', 'utf-8')
        content_type = get_content_type('filename')
        assert content_type == 'text/plain; charset=utf-8'

        # 'mimetypes.guess_type' can return `None` for unknown mime type
        mock_guess_type.return_value = (None, None)
        content_type = get_content_type('filename')
        assert content_type is None


# Generated at 2022-06-23 20:19:00.656896
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    input = [
        (
            'set-cookie',
            'session_id=abc; Domain=.example.com; Path=/; Expires=Fri, '
            '01 Jan 2100 00:00:00 GMT; HttpOnly'
        ),
        (
            'set-cookie',
            'session_id=abc; Domain=.example.com; Path=/; Max-Age=1000000; '
            'HttpOnly'
        ),
        (
            'set-cookie',
            'session_id=abc; Domain=.example.com; Path=/; Max-Age=1000000; '
            'HttpOnly'
        ),
    ]


# Generated at 2022-06-23 20:19:05.592408
# Unit test for function get_content_type
def test_get_content_type():
    # Test known content types
    assert get_content_type('image.png') == 'image/png'
    assert get_content_type('image.jpg') == 'image/jpeg'

    # Test unknown content types
    assert get_content_type('image.foo') is None

# Generated at 2022-06-23 20:19:06.700325
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()

    assert auth, "auth object is null"



# Generated at 2022-06-23 20:19:16.190862
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert (
        humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    )
    assert (
        humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    )
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert (
        humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    )

# Generated at 2022-06-23 20:19:24.669994
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = [
        [
            ('Set-Cookie', 'name_1=value_1; expires=Fri, 28-Apr-2019 22:53:52 GMT'),
            ('Set-Cookie', 'name_2=value_2; max-age=90'),
            ('Set-Cookie', 'name_3=value_3; path=/'),
            ('Set-Cookie', 'name_3=value_3; path=/; secure'),
            ('Set-Cookie', 'name_4=value_4; path=/SomePath/; domain=.example.com'),
            ('Set-Cookie', 'name_5=value_5; expires=Sun, 28-Apr-2019 22:53:52 GMT'),
        ]
    ]


# Generated at 2022-06-23 20:19:30.602993
# Unit test for function get_content_type
def test_get_content_type():
    from base64 import b64encode

    # Test content types for files ending with known suffixes.

    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.bin') == 'application/octet-stream'
    assert get_content_type('foo.xml') == 'application/xml'

    # Test content types for files not ending with known suffixes.
    # The Content-Type header value should be application/octet-stream
    # unless the file starts with an XML declaration, in which case the
    # header value should be application/xml.

    non_suffix_files = [
        'foo.bar',  # unknown suffix
        'foo',  # no suffix
        'foo.',  # file name ends with dot
        '',  # empty string
    ]

# Generated at 2022-06-23 20:19:34.552774
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    def _check(req):
        return isinstance(req.auth, ExplicitNullAuth)
    assert _check(requests.get('http://example.com', auth=ExplicitNullAuth()))


# Generated at 2022-06-23 20:19:43.663252
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:19:50.820904
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import mock
    import pytest

    m = mock.mock_open()
    with mock.patch(
            'os.path.exists',
            new=mock.Mock(return_value=False)
    ):
        auth_object = ExplicitNullAuth()
        req = mock.Mock()
        req.prepare = m
        req.send = m
        return_value = auth_object(req)
        req.prepare.assert_called_once()
        if return_value != req:
            raise AssertionError
        # req.send.assert_not_called()



# Generated at 2022-06-23 20:19:51.650462
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert isinstance(ExplicitNullAuth(), ExplicitNullAuth)

# Generated at 2022-06-23 20:19:53.645396
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    """
    ExplicitNullAuth() should return an object of type ExplicitNullAuth.
    """
    ena = ExplicitNullAuth()

    assert type(ena) == ExplicitNullAuth

# Generated at 2022-06-23 20:20:00.781570
# Unit test for function repr_dict
def test_repr_dict():
    for inp, exp in [
        ('foo', "OrderedDict([('foo', None)])"),
        ('foo: bar', "OrderedDict([('foo', 'bar')])"),
        ('foo: bar, baz', "OrderedDict([('foo', 'bar'), ('baz', None)])"),
        ('foo: bar, baz: quux', "OrderedDict([('foo', 'bar'), ('baz', 'quux')])")
    ]:
        assert repr_dict(dict(s.split(': ', 1) for s in inp.split(', '))) == exp

# Generated at 2022-06-23 20:20:02.216311
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert repr(auth) == '<ExplicitNullAuth()>'
    assert auth(None) is None



# Generated at 2022-06-23 20:20:08.952171
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies(headers=[('Set-Cookie', 'foo=2;')]) == [
        {'name': 'foo', 'path': '/'}
    ]


if __name__ == '__main__':
    import os
    import sys

    def p(s: str) -> None:
        sys.stdout.buffer.write(s.encode('UTF-8', 'surrogateescape') + b'\n')

    p(repr_dict({'foo': 'bar'}))
    p(repr_dict({'foo': 'bar', 'baz': 'wibble'}))
    p(load_json_preserve_order(json.dumps({'foo': 'bar'})))
    p(humanize_bytes(1))
    p(humanize_bytes(1024))

# Generated at 2022-06-23 20:20:16.317638
# Unit test for function get_content_type
def test_get_content_type():
    def assert_content_type(filename, expected):
        actual = get_content_type(filename)
        # print(filename, expected, actual)
        assert actual == expected

    assert_content_type(filename='index.html', expected='text/html')
    assert_content_type(filename='index.htm', expected='text/html')
    assert_content_type(filename='index.txt', expected='text/plain')
    assert_content_type(filename='index.json', expected='application/json')

# Generated at 2022-06-23 20:20:18.930054
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': True}
    expected = "{'a': 1, 'b': True}"
    actual = repr_dict(d)
    assert actual == expected

# Generated at 2022-06-23 20:20:19.695908
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:20:24.226070
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    httpbin_url = 'https://httpbin.org/anything'

    r = requests.get(httpbin_url, auth=auth)
    assert r.status_code == 401

    r_with_auth = requests.get(
        httpbin_url,
        auth=('user', 'pass'),
    )
    assert r_with_auth.status_code == 200

# Generated at 2022-06-23 20:20:25.113933
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None


# Generated at 2022-06-23 20:20:34.389046
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    # https://github.com/jakubroztocil/httpie/issues/171
    input = u'''{
        "args": {},
        "data": "",
        "files": {},
        "form": {
            "a": [
                "b",
                "c"
            ]
        },
        "headers": {
            "Accept": "*/*",
            "Content-Length": "7",
            "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
            "Host": "httpbin.org"
        },
        "json": null,
        "origin": "86.96.226.82",
        "url": "http://httpbin.org/post"
    }'''

# Generated at 2022-06-23 20:20:44.151430
# Unit test for function repr_dict
def test_repr_dict():
    s = repr_dict({
        'a': 1,
        'b': {
            'foo': 2,
            'bar': ['a', 'b']
        },
        'c': ['c', {'d': 'e'}, [], {}]
    })
    assert s == '''\
{'a': 1,
 'b': {'bar': ['a', 'b'], 'foo': 2},
 'c': ['c', {'d': 'e'}, [], {}]}'''
    # Test that dict stays ordered

# Generated at 2022-06-23 20:20:46.458793
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1234) == '1.21 kB'
    assert humanize_bytes(1234, precision=0) == '1 kB'

# Generated at 2022-06-23 20:20:54.003033
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    headers = [
        ('Set-Cookie', 'c1=v1; expires=Fri, 17-Dec-2037 14:43:00 GMT'),
        ('Set-Cookie', 'c2=v2; Max-Age=3600'),
        ('Set-Cookie', 'c3=v3; expires=Fri, 17-Dec-2037 14:43:00 GMT'),
    ]
    now = datetime(2037, 12, 17, 13, 42, 59).timestamp()
    expired_cookies = get_expired_cookies(headers, now)
    assert expired_cookies == []

    now = datetime(2037, 12, 17, 13, 43, 00).timestamp()
    expired_cookies = get_expired_cookies(headers, now)
   

# Generated at 2022-06-23 20:21:03.204412
# Unit test for function humanize_bytes
def test_humanize_bytes():
    """Test the output of humanize_bytes."""
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:21:08.974688
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import freezegun

    assert get_expired_cookies([
        ('Set-Cookie', 'a=b; Path=/')
    ]) == []

    now = time.time()

    with freezegun.freeze_time(now):
        assert get_expired_cookies([
            ('Set-Cookie', 'a=b; Expires=Thu, 01 Jan 1970 00:00:00 GMT')
        ]) == [{'name': 'a', 'path': '/'}]


# Generated at 2022-06-23 20:21:11.301039
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    _ = ExplicitNullAuth()

# Generated at 2022-06-23 20:21:15.183285
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from .session import Session
    from . import methods

    request_method = methods.get
    session = Session()
    response = session.request(method=request_method)

    assert 'Authorization' not in response.request.headers



# Generated at 2022-06-23 20:21:25.921170
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

    # Set-Cookie headers from one request

# Generated at 2022-06-23 20:21:27.199978
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == "{'a': 1}"

# Generated at 2022-06-23 20:21:31.930208
# Unit test for function repr_dict
def test_repr_dict():
    d = {'x': 42, 'y': [1, 2, 3]}
    assert repr_dict(d) == "{'x': 42, 'y': [1, 2, 3]}"


if __name__ == '__main__':
    test_repr_dict()

# Generated at 2022-06-23 20:21:34.538827
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.asdf') is None

# Generated at 2022-06-23 20:21:36.423229
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename='foo.txt') == 'text/plain'

# Generated at 2022-06-23 20:21:37.118392
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert True

# Generated at 2022-06-23 20:21:46.605053
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:21:51.025012
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.csv') == 'text/csv'
    assert get_content_type('test.js') == 'application/javascript'
    assert get_content_type('test.json') == 'application/json'
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.doc') == 'application/msword'
    assert get_content_type('test.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'