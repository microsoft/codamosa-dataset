

# Generated at 2022-06-23 20:12:02.105616
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    obj_1 = {'a': 1, 'b': 2}
    obj_2 = {'b': 2, 'a': 1}
    obj_3 = {'a': 1, 'b': 2, 'c': 3}
    obj_4 = {'b': 2, 'a': 1, 'c': 3}
    obj_5 = {'b': 2, 'a': 1, 'c': 3, 'd': 4}

    assert load_json_preserve_order(json.dumps(obj_1)) == obj_2
    assert load_json_preserve_order(json.dumps(obj_1)) == obj_2
    assert load_json_preserve_order(json.dumps(obj_3)) != obj_4

# Generated at 2022-06-23 20:12:08.336905
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('data.txt') == 'text/plain'
    assert get_content_type('data.html') == 'text/html'
    assert get_content_type('data.html') == 'text/html'
    assert get_content_type('data.html') == 'text/html'
    assert get_content_type('data.json') == 'application/json'
    assert get_content_type('data.json') == 'application/json'
    assert get_content_type('data.png') == 'image/png'
    assert get_content_type('data.png') == 'image/png'
    assert get_content_type('data.gif') == 'image/gif'
    assert get_content_type('data.gif') == 'image/gif'

# Generated at 2022-06-23 20:12:08.868236
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:12:09.962656
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth() # succeed or raise

# Generated at 2022-06-23 20:12:11.254797
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'

# Generated at 2022-06-23 20:12:18.791579
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import sys

    py2 = sys.version_info[0] == 2
    if py2:
        from urllib import quote as url_quote
    else:
        from urllib.request import quote as url_quote

    def _test(now: float):
        uri = 'http://example.invalid/foo.html'

        # Add some expired cookies.
        headers = [
            ('Set-Cookie', 'a=123; path=/; expires="06-Jul-2018 18:33:00 GMT"'),
            ('Set-Cookie', 'b=456; path=/; expires="02-Jan-2023 17:16:21 GMT"'),
        ]

        # Add some non-expired cookies.

# Generated at 2022-06-23 20:12:23.051675
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    requests.get('https://httpbin.org/cookies/set',
                 auth=ExplicitNullAuth(),
                 cookies={'foo': 'bar'})


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:12:31.128605
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([
        ('Set-Cookie', 'sessionid=0d5c5ea1-07de-4cd9-b8e0-91aec0c20e52; '
         'expires=Sat, 23-Mar-2019 17:44:17 GMT; httponly; Max-Age=1209600; '
         'Path=/'),
        ('Set-Cookie', 'csrftoken=q3kx71zUCA1HyUwVyKjURQBdHY9X4c4p; '
         'expires=Sat, 23-Mar-2019 17:44:17 GMT; Max-Age=31449600; '
         'Path=/')],
        1553396457.5801792)

# Generated at 2022-06-23 20:12:37.703080
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"key1": "123", "key2": "4.5", "key3": {"key4": "abc"}}'
    ordered_dict = load_json_preserve_order(json_string)
    assert ordered_dict == OrderedDict([
        ('key1', '123'),
        ('key2', '4.5'),
        ('key3', OrderedDict([
            ('key4', 'abc')
        ]))
    ])

# Generated at 2022-06-23 20:12:47.056516
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:12:55.353896
# Unit test for function load_json_preserve_order

# Generated at 2022-06-23 20:12:57.226294
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    request = object()
    result = ExplicitNullAuth().__call__(request)
    assert result is request

# Generated at 2022-06-23 20:12:57.752927
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:12:58.346872
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:13:01.098902
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:13:03.940757
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert(humanize_bytes(2**10) == '1.00 kB')
    assert(humanize_bytes(2**20) == '1.00 MB')
    assert(humanize_bytes(2**30) == '1.00 GB')

# Generated at 2022-06-23 20:13:05.928605
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    r = requests.Request(method='GET', url='http://example.com/')

    r2 = ExplicitNullAuth().__call__(r)

    assert r2 is r

# Generated at 2022-06-23 20:13:12.266929
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:13:17.551156
# Unit test for function humanize_bytes
def test_humanize_bytes():
    values = (
        (0, '0 B'),
        (1, '1 B'),
        (2 ** 10, '1.0 kB'),
        (2 ** 20, '1.0 MB'),
        (2 ** 30, '1.0 GB'),
        (2 ** 40, '1.0 TB'),
        (2 ** 50, '1.0 PB'),
        (2 ** 60, '1024.0 PB'),
    )
    for num, expected_result in values:
        result = humanize_bytes(num)
        print(result)
        assert result == expected_result


if __name__ == '__main__':
    test_humanize_bytes()

# Generated at 2022-06-23 20:13:21.669527
# Unit test for function repr_dict
def test_repr_dict():
    d = {'key': 'value'}
    assert repr_dict(d) == "{'key': 'value'}"


# Generated at 2022-06-23 20:13:26.200535
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    _r = requests.Request(
        'GET',
        'https://httpbin.org/basic-auth/asvira/secret',
        auth=ExplicitNullAuth()
    )
    _p = _r.prepare()
    # HTTP Authorization header must be empty
    assert _p.headers.get('authorization') is None

# Generated at 2022-06-23 20:13:30.760402
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    x = load_json_preserve_order("{'a': 3, 'b': 5}")
    assert x == OrderedDict([('a', 3), ('b', 5)])
    x = load_json_preserve_order("{'b': 5, 'a': 3}")
    assert x == OrderedDict([('b', 5), ('a', 3)])
    print("* Test finished *")


if __name__ == '__main__':
    test_load_json_preserve_order()

# Generated at 2022-06-23 20:13:33.008398
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('somefile.txt') == 'text/plain'
    assert get_content_type('somefile.pdf') == 'application/pdf'
    assert get_content_type('somefile.unknown_extension') is None



# Generated at 2022-06-23 20:13:42.308335
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # import calendar
    import datetime
    import time
    # import pprint
    #
    # t_epoch = 1485030557
    # pprint.pprint(parse_ns_headers(ns_headers))
    # exit()

    n_seconds_in_a_day = 3600 * 24


# Generated at 2022-06-23 20:13:47.672465
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = '{"key1": 1, "key2": 2}'
    d = load_json_preserve_order(s)
    assert isinstance(d, OrderedDict)
    assert d.keys() == [u'key1', u'key2']


# Generated at 2022-06-23 20:13:50.141324
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    import unittest.mock
    auth = ExplicitNullAuth()
    r = unittest.mock.Mock()
    assert auth(r) is r



# Generated at 2022-06-23 20:13:54.586948
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') == 'text/plain'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.bar') is None

# Generated at 2022-06-23 20:14:03.456015
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Cookie', 'foo=bar; path=/; expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'sessionid=123; path=/; expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'preferences=%7B%22night_mode%22%3Afalse%7D; path=/; expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'csrftoken=abc; path=/; expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'userid=213; path=/; expires=Wed, 09 Jun 2021 10:18:14 GMT')
    ]

    cookies = get_expired_cookies(headers, 1592109694)
   

# Generated at 2022-06-23 20:14:10.424252
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from requests.structures import CaseInsensitiveDict

    headers = CaseInsensitiveDict({
        'Set-Cookie': 'SESSION=abc123'
    })
    assert get_expired_cookies(headers.items(), now=0.0) == []

    headers = CaseInsensitiveDict({
        'Set-Cookie': 'SESSION=abc123; max-age=0'
    })
    assert get_expired_cookies(headers.items(), now=0.0) == [
        {'name': 'SESSION', 'path': '/'}
    ]

    headers = CaseInsensitiveDict({
        'Set-Cookie': 'SESSION=abc123; max-age-100'
    })
    assert get_expired_cookies(headers.items(), now=0.0) == []

    headers

# Generated at 2022-06-23 20:14:18.831750
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'
    assert repr_dict({'a': {'a': 1, 'b': 2}}) == '{\n    "a": {\n        "a": 1,\n        "b": 2\n    }\n}'
    assert repr_dict({'a': [1, 2, 3]}) == '{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}'

# Generated at 2022-06-23 20:14:28.732206
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import unittest
    import unittest.mock
    from http.cookies import SimpleCookie

    class TestCase(unittest.TestCase):
        def test_get_expired_cookies_one_cookie_expires_parsed(self):
            cookie = SimpleCookie(
                '__cfduid=dceb383d26ed8adcc1ffc3f402abcf6ec1523385825;'
                ' expires=Wed, 23-May-18 16:17:05 GMT; path=/;'
                ' domain=.daskeyboard.com; HttpOnly; Secure'
            )

# Generated at 2022-06-23 20:14:30.730957
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'foo': 'bar', 'key': 'value'}) == "{'foo': 'bar', 'key': 'value'}"



# Generated at 2022-06-23 20:14:37.382902
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    src_json = '{"b": "bbb", "a": "aaa", "c": "ccc"}'
    json_object = load_json_preserve_order(src_json)

    assert type(json_object).__name__ == "OrderedDict"
    keys = list()
    for key in json_object.keys():
        keys.append(key)
    assert keys[0] == "b"
    assert keys[1] == "a"
    assert keys[2] == "c"

# Generated at 2022-06-23 20:14:43.812009
# Unit test for function repr_dict
def test_repr_dict():
    d = {'foo': 'bar', 'a': 1, 'b': 2, 'c': 3}
    assert repr_dict(d) == "{'foo': 'bar', 'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({"a": 1, "b": 2, "c": 3, "foo": "bar"}) == \
        "{'a': 1, 'b': 2, 'c': 3, 'foo': 'bar'}"

# Generated at 2022-06-23 20:14:51.943096
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = r'{"menu": { "id": "file",' \
                  r'"value": "File","popup": { "menuitem": [' \
                  r'{"value": "New", "onclick": "CreateNewDoc()"},' \
                  r'{"value": "Open", "onclick": "OpenDoc()"},' \
                  r'{"value": "Close", "onclick": "CloseDoc()"} ] } }}'
    obj = load_json_preserve_order(json_string)

# Generated at 2022-06-23 20:14:57.757056
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import datetime, timedelta

    def now_plus_delta_secs(delta_secs) -> float:
        time_stamp = datetime.utcnow() + timedelta(seconds=delta_secs)
        return time.mktime(time_stamp.timetuple())

    cookies_with_expires = [
        {
            'name': 'one',
            'value': '1',
            'path': 'root',
            'expires': now_plus_delta_secs(60)
        },
        {
            'name': 'two',
            'value': '2',
            'path': 'root',
            'expires': now_plus_delta_secs(-60)
        },
    ]

# Generated at 2022-06-23 20:15:02.276087
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'foo': 'bar'}) == "{'foo': 'bar'}"
    assert repr_dict({'foo': 3}) == "{'foo': 3}"
    assert repr_dict({'foo': 'bar', 'bla': 3}) == "{'foo': 'bar', 'bla': 3}"

# Generated at 2022-06-23 20:15:05.974854
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(
        {'a':[1,2,3], 'c':['a','b','c']}
    ) == "OrderedDict([('a', [1, 2, 3]), ('c', ['a', 'b', 'c'])])"

# Generated at 2022-06-23 20:15:07.647602
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    request = object()
    auth = ExplicitNullAuth()
    assert auth(request) is request



# Generated at 2022-06-23 20:15:11.443915
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    j1 = '{"key1":"value1", "key2":"value2"}'
    j2 = '{"key2":"value2", "key1":"value1"}'
    jstr = load_json_preserve_order(j1)
    print(repr_dict(jstr))
    assert repr_dict(jstr) == j2
    print("load_json_preserve_order OK")

# Generated at 2022-06-23 20:15:15.059873
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"a": 1, "b": 2}'
    js = load_json_preserve_order(json_str)
    assert len(js) == 2
    assert isinstance(js, OrderedDict)
    assert js['a'] == 1
    assert js['b'] == 2

# Generated at 2022-06-23 20:15:20.198534
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    Test load_json_preserve_order.
    """
    s = '{"a":1,"b":2,"c":3}'

    assert load_json_preserve_order(s) == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-23 20:15:29.161258
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    def _assert_expires(
        *args,
        expected_cookies=None,
        expected_exception=None
    ):
        headers = [(k, v) for k, v in args]

        # Simulate a past was stored in cache.
        now = time.time()
        yesterday = now - 24 * 3600

# Generated at 2022-06-23 20:15:36.227441
# Unit test for function get_content_type
def test_get_content_type():
    """Test ``get_content_type``."""
    assert get_content_type(filename='foo') == 'text/plain'
    assert get_content_type(filename='foo.txt') == 'text/plain'
    assert get_content_type(filename='foo.json') == 'application/json'
    assert get_content_type(filename='foo.tar.gz') == 'application/x-gzip'

# Generated at 2022-06-23 20:15:40.571638
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = """
    {
        "foo": "bar",
        "key": "value",
        "key2": "value2"
    }"""
    assert load_json_preserve_order(json_str) == OrderedDict([
        ('foo', 'bar'),
        ('key', 'value'),
        ('key2', 'value2')
    ])

# Generated at 2022-06-23 20:15:47.210861
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:57.479086
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1520354291.616984

    # Test whether 'expires' is properly taken into account.
    assert get_expired_cookies([('Set-Cookie', 'foo=bar; expires=1520354282')]) == [
        {'name': 'foo', 'path': '/'}
    ]
    assert get_expired_cookies([('Set-Cookie', 'foo=bar; expires=1520354291')]) == []
    assert get_expired_cookies([('Set-Cookie', 'foo=bar; expires=1520354292')]) == []

    # Test whether 'max-age' is properly taken into account.

# Generated at 2022-06-23 20:15:58.244551
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert ExplicitNullAuth()(None) is None



# Generated at 2022-06-23 20:16:00.589664
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.txt') == 'text/plain'

# Generated at 2022-06-23 20:16:08.612561
# Unit test for function get_content_type
def test_get_content_type():

    eq = assert_equal

    eq(get_content_type('foo.txt'), 'text/plain')
    eq(get_content_type('foo.txt.gz'), 'application/x-gzip')
    eq(get_content_type('foo.html'), 'text/html')
    eq(get_content_type('foo.html.template'), 'text/plain')


if __name__ == '__main__':
    import nose
    nose.runmodule(argv=[__file__, '-vvs', '-x', '--pdb', '--pdb-failure'],
                   exit=False)

# Generated at 2022-06-23 20:16:14.119318
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookie_headers = [
        ('Set-Cookie', 'session_id=foo; Path=/'),
        ('Set-Cookie', 'path=/foo/bar; Max-Age=300'),
        ('Set-Cookie', 'path=/foo/bar; Max-Age=300.0'),
        ('Set-Cookie', 'path=/foo; Expires=Mon, 13 Apr 2020 15:11:17 GMT'),
    ]
    expired_cookies = get_expired_cookies(cookie_headers, now=3600)
    assert expired_cookies[0]['name'] == 'session_id'

# Generated at 2022-06-23 20:16:22.880645
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'foo': 'bar'}) == "{'foo': 'bar'}"
    # Test that dict order is preserved by function
    d = OrderedDict([('foo', 'bar'), ('baz', 'quux')])
    assert repr_dict(d) == "{'foo': 'bar', 'baz': 'quux'}"
    assert repr_dict(d) == "{'foo': 'bar', 'baz': 'quux'}"
    # Test that repr preserves unicode
    d = {'Š': 'Ž'}
    assert repr_dict(d) == "{'Š': 'Ž'}"



# Generated at 2022-06-23 20:16:32.123259
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:16:38.235608
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([('Set-Cookie', 'foo=bar')]) == []
    assert get_expired_cookies([('Set-Cookie', 'foo=bar; expires=1')], now=2) == [{'name': 'foo', 'path': '/'}]
    assert get_expired_cookies([('Set-Cookie', 'foo=bar; max-age=1')], now=2) == [{'name': 'foo', 'path': '/'}]

# Generated at 2022-06-23 20:16:42.999027
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("text.txt") == "text/plain"
    assert get_content_type("image.jpeg") == "image/jpeg"
    assert get_content_type("image.jpg") == "image/jpeg"
    assert get_content_type("image.png") == "image/png"
    assert get_content_type("file.doesntexists") is None

# Generated at 2022-06-23 20:16:48.302939
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    for jsn_str in [
        '{"x": "y", "z": "why"}',
        '{"x": {"y":0, "z":1}}',
    ]:
        assert load_json_preserve_order(jsn_str) == json.loads(jsn_str)


# Generated at 2022-06-23 20:16:57.906240
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=b; expires=Tue, 19 Jan 2038 03:14:07 GMT'),
        ('set-cookie', 'x=y; Max-Age=0; Path='),
        ('set-cookie', 'z=1'),
    ]
    assert get_expired_cookies(headers) == [
        {'name': 'x', 'path': '/'},
        {'name': 'z', 'path': '/'},
    ]

    cookies = [
        {'name': 'a', 'expires': '12345'},
        {'name': 'b', 'Max-Age': '0'},
    ]
    _max_age_to_expires(cookies, 0)

# Generated at 2022-06-23 20:16:59.703567
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert callable(auth)

# Generated at 2022-06-23 20:17:08.593590
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=Wed, 21 Oct 2015 07:28:00 GMT'),
        ('Set-Cookie', 'baz=bar; Path=/; Max-Age=3600')
    ]
    # Get expired cookies after 1970-01-01 00:00:00 UTC
    now = 0
    expired_cookies = get_expired_cookies(headers=headers, now=now)
    assert expired_cookies == [
        {'name': 'bar', 'path': '/'},
    ]
    # Get expired cookies after 2015-10-21 07:28:00 UTC
    now = 1445378080

# Generated at 2022-06-23 20:17:18.008657
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import textwrap


# Generated at 2022-06-23 20:17:19.016303
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    ExplicitNullAuth()



# Generated at 2022-06-23 20:17:21.127728
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth('request') == 'request'

# Generated at 2022-06-23 20:17:25.944528
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_doc = """
      {
        "name": "charlie",
        "friend": [
          "alice", "bob"
        ]
      }
    """

    order = [
        ('name', 'charlie'),
        ('friend', ['alice', 'bob'])
    ]

    assert load_json_preserve_order(json_doc) == OrderedDict(order)

# Generated at 2022-06-23 20:17:28.427042
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    request = requests.Request('GET', url='http://example.com')
    prepared = auth(request)
    assert prepared.url == 'http://example.com'



# Generated at 2022-06-23 20:17:31.078687
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(10000) == '9.8 kB'
    assert humanize_bytes(100001221) == '95.4 MB'

# Generated at 2022-06-23 20:17:40.830765
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    from requests import Request, Session
    from requests.models import Response
    session = Session()
    req = Request('POST', 'http://example.com/', auth=auth,
                  data={"foo": "bar"}, files={'baz': open('does.not.exist', 'rb')})
    prepped = req.prepare()
    resp = Response()
    resp.request = prepped
    resp.headers = {
        'set-cookie': 'some_cookie=some_value; expires=Wed, 21 Oct 2015 07:28:00 GMT; secure; httponly',
        'set-cookie': 'some_other_cookie=some_value; expires=Wed, 21 Oct 2015 07:28:00 GMT; secure; httponly'
    }

    cookies = session.extract_cookies(resp)
   

# Generated at 2022-06-23 20:17:49.903723
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:17:50.472177
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__(): pass


# Generated at 2022-06-23 20:17:52.242289
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert isinstance(auth, ExplicitNullAuth)


# Generated at 2022-06-23 20:17:55.977697
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    req = requests.get(url="https://httpbin.org/_get", auth=ExplicitNullAuth())
    assert req.status_code == 200
    assert req.json().get("url") == "https://httpbin.org/_get"

# Generated at 2022-06-23 20:18:00.332562
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("report.pdf") == 'application/pdf'
    assert get_content_type("report.doc") == 'application/msword'
    assert get_content_type("report.docx") == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'

# Generated at 2022-06-23 20:18:05.307720
# Unit test for function repr_dict
def test_repr_dict():
    import textwrap

    result = repr_dict({'a': 'b', 'c': 1, 'd': {'e': 'f', 'g': 2}, 'h': True})
    expected = textwrap.dedent('''\
    {'a': 'b',
     'c': 1,
     'd': {'e': 'f', 'g': 2},
     'h': True}''')
    assert result == expected

# Generated at 2022-06-23 20:18:08.093027
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    method_name = 'ExplicitNullAuth.__call__'
    assert ExplicitNullAuth().__call__(None) is None, method_name


# Generated at 2022-06-23 20:18:13.596134
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    from requests import Request, Session

    url = 'http://httpbin.org/basic-auth/foo/bar'
    headers = {'Authorization': 'Basic Zm9vOmJhcg=='}
    s = Session()
    s.auth = ExplicitNullAuth()
    r = Request('GET', url=url, headers=headers)
    prepped_request = s.prepare_request(request=r)

    assert prepped_request.method == 'GET'
    assert prepped_request.url == url
    assert prepped_request.headers == headers

# Generated at 2022-06-23 20:18:20.416392
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """{
        "c": 3,
        "b": 2,
        "a": 1
    }"""
    d = json.loads(s)
    assert d == {"c": 3, "b": 2, "a": 1}
    assert list(d.keys()) == ["c", "b", "a"]

    d = load_json_preserve_order(s)
    assert d == OrderedDict([("c", 3), ("b", 2), ("a", 1)])
    assert list(d.keys()) == ["c", "b", "a"]

# Generated at 2022-06-23 20:18:29.864234
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise AssertionError(
            'Failed result: %s != %s' % (humanize_bytes(1), '1 B'))
    if humanize_bytes(1024, precision=1) != '1.0 kB':
        raise AssertionError(
            'Failed result: %s != %s' % (humanize_bytes(1024, precision=1),
                                         '1.0 kB'))
    if humanize_bytes(1024 * 123, precision=1) != '123.0 kB':
        raise AssertionError(
            'Failed result: %s != %s' % (
                humanize_bytes(1024 * 123, precision=1),
                '123.0 kB'
            )
        )

# Generated at 2022-06-23 20:18:32.176972
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    request = type('Request', (), {})()
    ret = auth(request)
    assert ret == request

# Generated at 2022-06-23 20:18:34.867378
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    from requests.models import PreparedRequest
    req = PreparedRequest()
    return auth(req) is req

# Generated at 2022-06-23 20:18:41.650798
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.html.gz') == 'application/x-gzip'
    assert get_content_type('/home/me/test.html') == 'text/html'
    assert get_content_type('/home/me/test.html.gz') == 'application/x-gzip'
    assert get_content_type('test.html.gz.pdf') is None

# Generated at 2022-06-23 20:18:47.648827
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Request
    from requests.sessions import Session
    from requests.models import Response
    url = 'https://www.example.org/'
    req = Request('GET', url)
    s = Session()
    res = Response()
    res.status_code = 200
    res.url = url
    s.proxies.update({})
    req.prepare()
    prepared_request = req
    req = s.send(prepared_request,
                 stream=False,
                 timeout=None,
                 verify=True,
                 cert=None,
                 proxies=None)

# Generated at 2022-06-23 20:18:49.816739
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth



# Generated at 2022-06-23 20:18:51.221552
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth_cls = ExplicitNullAuth()
    assert auth_cls is not None

# Generated at 2022-06-23 20:18:51.911279
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:18:56.924933
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from .test_app import app
    from .test_app import Browser, BrowserTestCase

    class TestCookies(BrowserTestCase):
        def test_get_expired_cookies(self):
            # A cookie "expires" in about 86400 seconds.
            browser = Browser(app, cookie_expires_in=86400)

            # Get the list of expired set-cookie headers from the response.
            browser.visit(app.url_path_for('dummy_view'))
            expired_cookies = get_expired_cookies(
                headers=browser.headers,
                now=time.time() - 86400
            )

            # Test expired cookies
            expired_names = {c['name'] for c in expired_cookies}

# Generated at 2022-06-23 20:18:59.999215
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'x': 1,
        'y': 2,
    }
    assert repr_dict(d) == repr(d)

# Generated at 2022-06-23 20:19:10.227959
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:19:14.582339
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    myjson = """{"a": 1, "b": 2, "c": 3, "d": 4}"""
    # Check that the order is preserved
    assert list(load_json_preserve_order(myjson).keys()) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-23 20:19:16.815965
# Unit test for function repr_dict
def test_repr_dict():
    """
    >>> test_repr_dict()
    "{'name': 'cookie1', 'path': '/'}"
    """
    print(repr_dict(dict(name='cookie1', path='/')))

# Generated at 2022-06-23 20:19:17.906737
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:19:19.098755
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'foo': 'bar'}) == "{'foo': 'bar'}"

# Generated at 2022-06-23 20:19:20.911081
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    a = auth(None)
    # assert a is None
    assert a is not None


# Generated at 2022-06-23 20:19:27.837766
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.unrecognized') is None
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.zip') == 'application/zip'
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.css') == 'text/css'
    assert get_content_type('test.gif') == 'image/gif'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.htm') == 'text/html'


# Unit tests for function `get_expired_cookies`

# Generated at 2022-06-23 20:19:29.814828
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('some.jpg') == 'image/jpeg'
    assert get_content_type('some.pdf') == 'application/pdf'

# Generated at 2022-06-23 20:19:33.566696
# Unit test for function repr_dict
def test_repr_dict():
    d = {
        'alpha': 1,
        'beta': 2,
        'gamma': 3,
    }
    assert repr_dict(d) == "{'alpha': 1, 'beta': 2, 'gamma': 3}"

# Generated at 2022-06-23 20:19:36.806399
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_input = '{"a":1,"b":2}\n'
    assert load_json_preserve_order(test_input) == {"a":1,"b":2}

# Generated at 2022-06-23 20:19:45.373765
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'PHPSESSID=asdf; path=/'),
        ('Set-Cookie', 'other=asdf; path=/'),
        ('Set-Cookie', 'short=other; Max-Age=2; expires=999; path=/'),
        ('Set-Cookie', 'keep=other; Path=/'),
    ]
    cookies = get_expired_cookies(headers, now=1001)
    assert cookies == [
        {
            'name': 'other',
            'path': '/'
        },
        # 'short' matches because it has `max-age` and we assume it's
        # expired, even though the `expires` time is in the future.
        {
            'name': 'short',
            'path': '/'
        },
    ]

# Generated at 2022-06-23 20:19:52.285219
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    from vcr.stubs import VCRHTTPSConnection
    from vcr.request import Request
    from vcr.util import local_path

    ExplicitNullAuth()

    request = Request(
        method='GET',
        uri='http://localhost:5000/',
        body=None,
        headers=None
    )

    connection = VCRHTTPSConnection(
        host='localhost',
        port=5000,
        key_file=None,
        cert_file=None
    )

    connection.make_request(
        method=request.method,
        url=local_path(request.uri),
        body=request.body,
        headers=request.headers
    )

# Generated at 2022-06-23 20:19:53.134031
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth(None) == None

# Generated at 2022-06-23 20:20:01.730693
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'banana'),
        ('Set-Cookie', 'strawberry=19; Path=/some/path/'),
        ('Set-Cookie', 'peach=1; expires=Mon, 05-Nov-2018 14:42:39 GMT'),
        ('Set-Cookie', 'lime=1; expires=Mon, 05-Feb-2019 14:42:39 GMT'),
        ('Set-Cookie', 'lemon=1; max-age=10'),
        ('Set-Cookie', 'orange=1; max-age=100'),
    ]
    now = time.time()
    results = get_expired_cookies(headers, now)
    assert len(results) == 3

# Generated at 2022-06-23 20:20:07.422991
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    expired_cookies = get_expired_cookies(headers=[
        ('Set-Cookie', 'JSESSIONID=abc; expires={}; path=/; HttpOnly'.format(
            now - 1
        )),
        ('Set-Cookie', 'SC=a; expires={}; path=/; HttpOnly'.format(
            now + 10
        ))
    ],
        now=now
    )
    assert expired_cookies == [{
        'name': 'JSESSIONID',
        'path': '/'
    }]

# Generated at 2022-06-23 20:20:18.549931
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.jpeg') == 'image/jpeg'
    assert get_content_type('foo.JPEG') == 'image/jpeg'
    assert get_content_type('foo.jpeg; charset=utf-8') == 'image/jpeg; charset=utf-8'
    assert get_content_type('foo.JPEG; charset=utf-8') == 'image/jpeg; charset=utf-8'
    assert get_content_type('foo.svg?v=4') == 'image/svg+xml'
    assert get_content_type('') is None
    assert get_content_type('.') is None
    assert get_content_type('..') is None
    assert get_content_type('foo') is None

# Generated at 2022-06-23 20:20:21.379198
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    req = requests.request('GET', 'http://fake.server.example.com/', auth=ExplicitNullAuth())
    assert req.url == 'http://fake.server.example.com/'

# Generated at 2022-06-23 20:20:22.097807
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is ExplicitNullAuth()

# Generated at 2022-06-23 20:20:26.571954
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests
    import requests_mock

    with requests_mock.Mocker() as m:
        m.get('http://example.com/')
        r = requests.Request(
            'GET',
            url='http://example.com/',
            auth=ExplicitNullAuth()
        )
        p = r.prepare()
        m.send(p)
        assert m.call_count == 1



# Generated at 2022-06-23 20:20:28.074110
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests.auth
    a = ExplicitNullAuth()
    r = requests.Request('get')
    a(r)

# Generated at 2022-06-23 20:20:36.868872
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = [
        ('Set-Cookie', 'TEST=123;'),
        ('Set-cookie', 'TEST2=abc; Expires=Fri, 02 Oct 2020 11:42:42 GMT'),
        ('Set-Cookie', 'TEST3=def; Max-Age=100'),
        ('X-Test', 'TEST'),
        ('Set-Cookie', 'TEST4=ghi; Expires=Mon, 01 Oct 1990 11:42:42 GMT'),
        ('Set-Cookie', 'TEST5=jkl; Max-Age=100'),
    ]

    expired = get_expired_cookies(cookies)

# Generated at 2022-06-23 20:20:46.718250
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:20:48.272906
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    from requests.auth import AuthBase
    assert isinstance(ExplicitNullAuth(), AuthBase) #type: ignore

# Generated at 2022-06-23 20:20:51.330991
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """
    Method ``__call__`` of our custom class ``ExplicitNullAuth``
    shall be accepted by ``requests.Session``
    as an authentication method.

    """
    session = requests.Session()
    session.auth = ExplicitNullAuth()

# Generated at 2022-06-23 20:20:58.335021
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo/bar.txt') == 'text/plain'
    assert get_content_type('.netrc') == 'text/plain'
    assert get_content_type('foo/bar/baz/netrc') == 'text/plain'
    assert get_content_type('') is None
    assert get_content_type('foo/bar.xyzzy') is None

# Generated at 2022-06-23 20:20:59.016589
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:21:01.330610
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"c": 3, "a": 1, "b": 2}') == OrderedDict([('c', 3), ('a', 1), ('b', 2)])

# Generated at 2022-06-23 20:21:05.593743
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order("{}") == {}
    assert load_json_preserve_order("{}") != dict()
    assert load_json_preserve_order("{\"a\": 1}") == {"a": 1}
    assert load_json_preserve_order("{\"a\": 1}") != dict(a=1)


# Generated at 2022-06-23 20:21:17.591412
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    expired = [
        ('Set-Cookie: foo=bar; Max-Age=0; expires=Wed, 21 Oct 2015 07:28:00 GMT', {}),
        ('Set-Cookie: foo=bar; Max-Age=0; Expires=Wed, 21 Oct 2015 07:28:00 GMT', {}),
        ('Set-Cookie: foo=bar; Max-Age=0; expires=Wed, 21 Oct 2015 07:28:00 GMT\n', {}),
        ('Set-Cookie: foo=bar; Max-Age=0; Expires=Wed, 21 Oct 2015 07:28:00 GMT\n', {}),
        ('Set-Cookie: foo=bar; Max-Age=0', {}),
        ('Set-Cookie: foo=bar; Max-Age=0\n', {}),
    ]

# Generated at 2022-06-23 20:21:23.566157
# Unit test for function humanize_bytes
def test_humanize_bytes():
    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_humanize_bytes()
    print(get_content_type('/tmp/nun.txt'))
    print(get_content_type('/tmp/nun.pdf'))
    print(get_content_type('/tmp/nun.jpg'))

# Generated at 2022-06-23 20:21:31.818332
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:21:36.644339
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b'}) == "{'a': 'b'}"

    o = OrderedDict()
    o['a'] = 1
    o['b'] = 2
    assert repr_dict(o) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:21:40.348947
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import pytest

    d = load_json_preserve_order('''{"a": "A", "c": "C", "b": "B"}''')
    assert d == OrderedDict([('a', 'A'), ('c', 'C'), ('b', 'B')])


if __name__ == '__main__':
    test_load_json_preserve_order()

# Generated at 2022-06-23 20:21:44.319023
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': (2, 3)}) == "{'a': 1, 'b': (2, 3)}"

# Generated at 2022-06-23 20:21:47.072905
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == \
        OrderedDict([('a', 1), ('b', 2)])

# Generated at 2022-06-23 20:21:53.437847
# Unit test for function humanize_bytes

# Generated at 2022-06-23 20:22:03.708700
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    past = now - 100
    future = now + 100
    exp_header = "expires=%s" % past
    max_age_header = "max-age=100"

    headers = {
        "Set-Cookie": [
            "foo=bar; path=/; expires=%s; max-age=100" % past,
            "baz=quux; path=/foo; %s" % max_age_header,
            "spam=eggs; %s" % exp_header,
            "foo=bar; path=/; %s" % max_age_header,
            "bar=baz; path=/foo; %s" % exp_header
        ]
    }