

# Generated at 2022-06-23 20:11:51.016453
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json
    d = {'foo': 'bar', 'baz': 'qux'}
    assert load_json_preserve_order(json.dumps(d)) == d

# Generated at 2022-06-23 20:11:54.188775
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 'b', 'c': ['d', {'e': 'f'}]}) == """\
{'a': 'b', 'c': ['d', {'e': 'f'}]}"""



# Generated at 2022-06-23 20:11:56.838022
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Test that ExplicitNullAuth overrides the method __call__ of requests.auth.AuthBase
    auth = ExplicitNullAuth()
    req = requests.Request('get', 'http://example.com')
    auth(req)
    assert req.auth == auth

# Generated at 2022-06-23 20:11:57.661397
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    # returns the request itself

# Generated at 2022-06-23 20:11:59.552707
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

    assert isinstance(auth, ExplicitNullAuth)

# Generated at 2022-06-23 20:12:01.647149
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == '{\n    "a": 1,\n    "b": 2\n}'


# Generated at 2022-06-23 20:12:03.651751
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.gz') == 'application/gzip'
    assert get_content_type('test') == None

# Generated at 2022-06-23 20:12:13.448393
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise AssertionError
    if humanize_bytes(1024, precision=1) != '1.0 kB':
        raise AssertionError
    if humanize_bytes(1024 * 123, precision=1) != '123.0 kB':
        raise AssertionError
    if humanize_bytes(1024 * 12342, precision=1) != '12.1 MB':
        raise AssertionError
    if humanize_bytes(1024 * 12342, precision=2) != '12.05 MB':
        raise AssertionError
    if humanize_bytes(1024 * 1234, precision=2) != '1.21 MB':
        raise AssertionError

# Generated at 2022-06-23 20:12:14.590470
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth



# Generated at 2022-06-23 20:12:15.087569
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:12:19.544352
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    """
    Simple unit test for function load_json_preserve_order.
    """
    inp_str = '{"a":1,"b":3,"c":3,"d":4,"e":5}'
    res = json.loads(inp_str)
    assert res == {'a': 1, 'b': 3, 'c': 3, 'd': 4, 'e': 5}
    res = load_json_preserve_order(inp_str)
    assert res == OrderedDict([('a', 1), ('b', 3), ('c', 3), ('d', 4), ('e', 5)])


# Generated at 2022-06-23 20:12:24.775156
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order("""{"A": "a", "B": "b"}""") == {
        'A': 'a',
        'B': 'b'
    }
    assert load_json_preserve_order("""{"A": "a", "B": "b"}""") == OrderedDict([
        ('A', 'a'),
        ('B', 'b')
    ])

# Generated at 2022-06-23 20:12:28.088637
# Unit test for function get_content_type
def test_get_content_type():
    """
    >>> get_content_type('test_httpclient.py')
    'text/x-python'
    >>> get_content_type('tmp.html')
    'text/html'
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:12:33.140004
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2}
    s = repr_dict(d)
    assert s == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:12:38.549086
# Unit test for function humanize_bytes
def test_humanize_bytes():
    """
    Test the humanize_bytes function in the helper module.
    """
    assert humanize_bytes(1) == "1 B"
    assert humanize_bytes(1024) == "1.00 kB"
    assert humanize_bytes(1024*123) == "123.00 kB"
    assert humanize_bytes(1024*12342) == "12.05 MB"
    assert humanize_bytes(1024*12342,2) == "12.05 MB"
    assert humanize_bytes(1024*1234*1111,2) == "1.31 GB"
    assert humanize_bytes(1024*1234*1111,1) == "1.3 GB"
    print("test_humanize_bytes: ok")

# Generated at 2022-06-23 20:12:45.500543
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') is None
    assert get_content_type('file.html') == 'text/html'
    assert get_content_type('file.css') == 'text/css'
    assert get_content_type('file.png') == 'image/png'
    assert get_content_type('file.jpg') == 'image/jpeg'
    assert get_content_type('file.jpeg') == 'image/jpeg'
    assert get_content_type('file.gif') == 'image/gif'

# Generated at 2022-06-23 20:12:54.147473
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:12:55.870267
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({"a": 1, "b": 2}) == "{'a': 1, 'b': 2}"

# Generated at 2022-06-23 20:12:56.594661
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:12:59.683110
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    d = {"a": 1, "b": 2, "c": 3}
    assert load_json_preserve_order(json.dumps(d)) == d


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:13:01.680457
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth is not None

# Generated at 2022-06-23 20:13:08.148729
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 'A', 'b': 'B'}
    assert repr_dict(d) == "{'a': 'A', 'b': 'B'}"

    d = {'a': 'A', 'b': 'B', 'n': None}
    assert repr_dict(d) == "{'a': 'A', 'b': 'B', 'n': None}"

# Generated at 2022-06-23 20:13:08.795914
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:13:16.830179
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    filename = 'test_file.txt'
    file_content = 'hello world'

    with open(filename, 'w') as f:
        f.write(file_content)

    import requests
    import requests.auth
    from .get_content_type import get_content_type

    auth = ExplicitNullAuth()
    s = requests.Session()
    s.auth = auth
    filename = 'test_file.txt'
    content_type = get_content_type(filename)

# Generated at 2022-06-23 20:13:22.286330
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    class Hook:
        def __init__(self):
            self.method_called = None

        def __call__(self, *args, **kwargs):
            self.method_called = True
            return True

    class DummyRequest:
        def __init__(self):
            self.hook = Hook()

    dummy_request = DummyRequest()
    explicit_null_auth = ExplicitNullAuth()

    assert explicit_null_auth.__call__(dummy_request)



# Generated at 2022-06-23 20:13:24.515995
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.png') == 'image/png'
    assert get_content_type('foo.bar') is None

# Generated at 2022-06-23 20:13:27.119427
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Test __call__() is a no-op.
    request = object()
    auth = ExplicitNullAuth()
    assert auth(request) is request



# Generated at 2022-06-23 20:13:29.364630
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{\n    'a': 1,\n    'b': 2\n}"

# Generated at 2022-06-23 20:13:30.719346
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    cookie_jar = ExplicitNullAuth()

# Generated at 2022-06-23 20:13:37.072621
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:13:38.069366
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()


# Generated at 2022-06-23 20:13:45.493456
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
    {
        "a": 1,
        "b": 2,
        "c": 3,
        "n": {
            "a": 1,
            "b": 2,
            "c": 3
        }
    }
    """

    res_py2 = {
        u"a": 1,
        u"b": 2,
        u"c": 3,
        u"n": {
            u"a": 1,
            u"b": 2,
            u"c": 3
        }
    }
    res_py3 = {
        "a": 1,
        "b": 2,
        "c": 3,
        "n": {
            "a": 1,
            "b": 2,
            "c": 3
        }
    }
    res = load_json

# Generated at 2022-06-23 20:13:47.249768
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    null_auth = ExplicitNullAuth()
    assert null_auth.__call__(None) is None

# Generated at 2022-06-23 20:13:52.092702
# Unit test for function get_content_type
def test_get_content_type():
    # Basic test
    assert get_content_type('file.txt') == 'text/plain'

    # Test null file name
    assert get_content_type('') is None

    # Test non-ASCII file name
    # https://stackoverflow.com/questions/35746470
    assert get_content_type('plik-ąśćżź.txt') == 'text/plain'

# Generated at 2022-06-23 20:13:56.131236
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert load_json_preserve_order('[1, 2, 3]') == [1, 2, 3]

# Generated at 2022-06-23 20:13:57.590355
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    assert isinstance(ExplicitNullAuth()(None), requests.Request)

# Generated at 2022-06-23 20:14:06.689301
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from requests import Request, Session
    from unittest import TestCase

    class ExplicitNullAuthTestCase(TestCase):
        class SessionStub(Session):
            @property
            def auth(self):
                return ExplicitNullAuth()

        def test_request_with_null_auth(self):
            session = ExplicitNullAuthTestCase.SessionStub()
            request = Request('GET', 'http://httpbin.org/headers')
            prep = session.prepare_request(request)
            self.assertEqual(prep.headers, None)

    tc = ExplicitNullAuthTestCase('test_request_with_null_auth')
    tc.test_request_with_null_auth()

# Generated at 2022-06-23 20:14:10.732149
# Unit test for function get_content_type
def test_get_content_type():
    tests = [
        ('test.jpg', 'image/jpeg'),
        ('test.jpg.gz', 'image/jpeg; charset=gzip'),
        ('test.jpg.br', 'image/jpeg; charset=br'),
        ('test.jpg.z', None),
    ]
    for filename, expected in tests:
        assert get_content_type(filename) == expected

# Generated at 2022-06-23 20:14:18.892509
# Unit test for function get_content_type
def test_get_content_type():
    from unittest import TestCase

    class Test(TestCase):
        def test_return_type(self):
            self.assertTrue(get_content_type('test.png') is not None)
            self.assertTrue(get_content_type('test.txt') is not None)
            self.assertTrue(get_content_type('test.txta') is None)
            self.assertTrue(get_content_type('test.txt.png') is not None)
            self.assertTrue(get_content_type('test.png.txt') is not None)
            self.assertTrue(get_content_type('test.png.t') is None)

    Test()
    print('Test for get_content_type is OK')



# Generated at 2022-06-23 20:14:20.359405
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert hasattr(auth, '__call__')

# Generated at 2022-06-23 20:14:22.646945
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    """ExplicitNullAuth(None) must return None."""
    assert ExplicitNullAuth(None) is None



# Generated at 2022-06-23 20:14:31.149655
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = [
        {
            'name': 'first',
            'value': 'one',
            'path': '/'
        },
        {
            'name': 'second',
            'value': 'two',
            'path': '/',
            'expires': time.time() + 10
        },
        {
            'name': 'third',
            'value': 'three',
            'path': '/',
            'expires': time.time() - 10
        },
    ]
    assert get_expired_cookies(headers=[]) == []
    assert get_expired_cookies(headers=[('Set-Cookie', 'first=one; path=/')]) == [
        {
            'name': 'first',
            'path': '/'
        }
    ]

# Generated at 2022-06-23 20:14:34.460879
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 'A', 'b': 'B'}) == "{'a': 'A', 'b': 'B'}"

# Generated at 2022-06-23 20:14:36.200286
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    a = ExplicitNullAuth()
    assert isinstance(a, ExplicitNullAuth)
    assert callable(a)

# Generated at 2022-06-23 20:14:45.329520
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    for input, expected_output in [
        ("{}", {}),
        ("{'a': 1}", {'a': 1}),
        ("{'a': 1, 'b': 2}", {'a': 1, 'b': 2}),
        ("{'a': 1, 'b': 2, 'c': 3}", {'a': 1, 'b': 2, 'c': 3}),
        ("{'a': 1, 'b': 2, 'c': {'d': 3}}", {'a': 1, 'b': 2, 'c': {'d': 3}}),
    ]:
        assert load_json_preserve_order(input) == expected_output

# Generated at 2022-06-23 20:14:50.013375
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.png') == 'image/png'
    assert get_content_type('file.jpg') == 'image/jpeg'
    assert get_content_type('file.html') == 'text/html'
    assert get_content_type('file.html') == 'text/html'
    assert get_content_type('file.json') == 'application/json'
    assert get_content_type('file.json.gz') is None
    assert get_content_type('file.gz') is None

# Generated at 2022-06-23 20:14:59.463624
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-23 20:15:06.134960
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 1, 'b': 2, 'c': 3}
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'c': 3}"
    d = OrderedDict(sorted(d.items()))
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'c': 3}"
    d['d'] = OrderedDict([('d1', 4), ('d2', 5)])
    assert repr_dict(d) == "{'a': 1, 'b': 2, 'c': 3, 'd': {'d1': 4, 'd2': 5}}"

# Generated at 2022-06-23 20:15:13.398214
# Unit test for function get_expired_cookies

# Generated at 2022-06-23 20:15:16.148525
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    try:
        ExplicitNullAuth()
    except Exception as error:
        print('Exception on ExplicitNullAuth creation: ', error)
        assert error is None, 'constructor of ExplicitNullAuth raised an exception'
    else:
        print('No exception on ExplicitNullAuth creation')
        assert True

if __name__ == '__main__':
    test_ExplicitNullAuth()

# Generated at 2022-06-23 20:15:26.806475
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:15:38.806259
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from dpf import __file__ as dpf_module_filename
    with open(dpf_module_filename) as f:
        data = f.read()
    assert data  # sanity check
    now = 33.33

# Generated at 2022-06-23 20:15:45.136306
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from pprint import pprint

    def print_diff(d1, d2):
        for k, v in d1.items():
            if k not in d2 or d2[k] != v:
                print(f'{k}: {v}')

    def format_expires(expires):
        return time.strftime('%a, %d %b %Y %H:%M:%S', time.gmtime(expires))

    next_year = time.time() + 365 * 24 * 60 * 60


# Generated at 2022-06-23 20:15:53.795305
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    line1 = '{"a": 1}'

    loaded_dict1 = load_json_preserve_order(line1)
    # Check output is a dict
    assert isinstance(loaded_dict1, dict)

    line2 = '''
    {
        "b": 2,
        "a": 1
    }
    '''
    loaded_dict2 = load_json_preserve_order(line2)
    # Check output is a dict
    assert isinstance(loaded_dict2, dict)

    # Check loaded_dict1 == loaded_dict2
    assert loaded_dict1 == loaded_dict2

# Generated at 2022-06-23 20:15:57.872133
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"a": 1, "b": 2, "c": 3}'
    assert load_json_preserve_order(json_str) == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-23 20:16:05.481346
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    a_second_ago = time.time() - 1
    in_a_year = time.time() + (60 * 60 * 24 * 365)


# Generated at 2022-06-23 20:16:06.908332
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    auth(None)

# Generated at 2022-06-23 20:16:07.835593
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()
    assert auth

# Generated at 2022-06-23 20:16:14.504501
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo') is None
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.ics') == 'text/calendar'
    assert get_content_type('foo.jpeg') == 'image/jpeg'

# Generated at 2022-06-23 20:16:21.178072
# Unit test for function repr_dict
def test_repr_dict():
    data = {
        'str': 'bla',
        'nested_dict': {
            'str': 'bla',
            'int': 1,
            'float': 1.001,
            'bool': True,
            'none': None
        },
        'int': 1,
        'float': 1.001,
        'bool': True,
        'none': None
    }

    repr_data = repr_dict(data)
    assert repr_data == pformat(data)

# Generated at 2022-06-23 20:16:22.122658
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None

# Generated at 2022-06-23 20:16:24.862834
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    result = load_json_preserve_order('{ "descending": false, "keys": [] }')
    assert result == {
        'descending': False,
        'keys': []
    }
# END Unit test for function load_json_preserve_order

# Generated at 2022-06-23 20:16:33.618245
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # This is a list of [bytes, precision, expected]
    test_data = [
        [1, 0, '1 B'],
        [1, 1, '1.0 B'],
        [1024, 1, '1.0 kB'],
        [1024, 2, '1.00 kB'],
        [1024 * 123, 1, '123.0 kB'],
        [1024 * 12342, 1, '12.1 MB'],
        [1024 * 12342, 2, '12.05 MB'],
        [1024 * 1234, 2, '1.21 MB'],
        [1024 * 1234 * 1111, 2, '1.31 GB'],
        [1024 * 1234 * 1111, 1, '1.3 GB']
    ]

# Generated at 2022-06-23 20:16:41.759170
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:16:47.816870
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:16:49.222553
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    auth = ExplicitNullAuth()
    assert auth is auth('any_requests_object') # pylint: disable=comparison-with-itself

# Generated at 2022-06-23 20:16:51.524971
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    rv = load_json_preserve_order('{"a": 1, "b": 2, "c": 3}')
    assert isinstance(rv, OrderedDict)
    assert list(rv.keys()) == ['a', 'b', 'c']

# Generated at 2022-06-23 20:16:54.394408
# Unit test for function repr_dict
def test_repr_dict():
    d = {"a": "b", "c": "d", "a": "e"}
    assert repr_dict(d) == "{'a': 'e', 'c': 'd'}"

# Generated at 2022-06-23 20:16:57.251627
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert load_json_preserve_order('{"b": 2, "a": 1}') == {'b': 2, 'a': 1}

# Generated at 2022-06-23 20:17:07.386627
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    import pytest
    from requests.structures import CaseInsensitiveDict

    now = time.time()
    not_now = now - 100

# Generated at 2022-06-23 20:17:12.522234
# Unit test for function humanize_bytes
def test_humanize_bytes():
    for n, s in [
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 12342, '12.05 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
    ]:
        assert humanize_bytes(n, precision=2) == s

# Generated at 2022-06-23 20:17:16.228515
# Unit test for function repr_dict
def test_repr_dict():
    d1 = dict(x=1, y=2)
    s = repr_dict(d1)
    d2 = eval(s)
    assert d1 == d2

# Generated at 2022-06-23 20:17:17.800667
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('.gitignore') == 'text/plain'

# Generated at 2022-06-23 20:17:19.218718
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    t = ExplicitNullAuth()
    assert t is not None


# Generated at 2022-06-23 20:17:28.390587
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # For example:
    # JavaScript code:
    #   document.cookie = "theme=light"
    #
    # Translates to:
    #   Set-Cookie: theme=light
    assert get_expired_cookies([
        ('Set-Cookie', 'theme=light'),
    ]) == []

    # JavaScript code:
    #   document.cookie = "theme=light; expires=Wed, 21 Oct 2015 07:28:00 GMT"
    #
    # Translates to:
    #   Set-Cookie: theme=light; expires=Wed, 21 Oct 2015 07:28:00 GMT
    assert get_expired_cookies([
        ('Set-Cookie', 'theme=light; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
    ]) == []

    # For example:
    # JavaScript

# Generated at 2022-06-23 20:17:39.137333
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:17:48.825251
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024 * 123) == '123.0 kB'
    assert humanize_bytes(1024 * 12342) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'
    assert humanize_bytes(0) == '0 B'
    # test for issue #949

# Generated at 2022-06-23 20:17:59.228367
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():

    # Test 1 #
    j1 = '{}'
    j_result = load_json_preserve_order(j1)
    assert type(j_result) is OrderedDict
    assert len(j_result) == 0

    # Test 2 #
    j1 = '{"name": "value"}'
    j_result = load_json_preserve_order(j1)
    assert type(j_result) is OrderedDict
    assert len(j_result) == 1
    assert j_result["name"] == "value"

    # Test 3 #
    j1 = '{"name1": "value1", "name2": "value2"}'
    j_result = load_json_preserve_order(j1)
    assert type(j_result) is OrderedDict

# Generated at 2022-06-23 20:18:03.069399
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.unknown') is None
    assert get_content_type('..') is None
    assert get_content_type('test.unknown') is None
    assert get_content_type('test') is None

# Generated at 2022-06-23 20:18:12.628637
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    future = now + 10
    past = now - 20

    def mk_cookie(expires=None, max_age=None, **kwargs):
        cookie = {'name': 'foo'}
        if expires is not None:
            cookie['expires'] = expires
        if max_age is not None:
            cookie['max-age'] = max_age
        cookie.update(kwargs)
        headers = (('Set-Cookie', '; '.join('%s=%s' % x for x in cookie.items())))
        return headers

    assert get_expired_cookies([mk_cookie(expires=now)], now) == [{'name': 'foo', 'path': '/'}]

# Generated at 2022-06-23 20:18:22.105960
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_json_1 = "{\"a\":1,\"b\":2,\"c\":3,\"d\":4}"
    test_json_2 = "{\"b\":2,\"d\":4,\"c\":3,\"a\":1}"
    test_json_3 = "{\"d\":4,\"b\":2,\"a\":1,\"c\":3}"

    json_1 = json.loads(test_json_1)
    json_2 = json.loads(test_json_2)
    json_3 = json.loads(test_json_3)
    json_4 = load_json_preserve_order(test_json_1)
    json_5 = load_json_preserve_order(test_json_2)
    json_6 = load_json_preserve_order(test_json_3)

   

# Generated at 2022-06-23 20:18:24.357766
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    """Test ExplicitNullAuth"""
    explicit_null_auth = ExplicitNullAuth()
    assert explicit_null_auth is not None

# Generated at 2022-06-23 20:18:24.928501
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    ExplicitNullAuth()

# Generated at 2022-06-23 20:18:32.102047
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'foo=bar; Path=/; Max-Age=3600'),
        ('Set-Cookie', 'bar=baz; Path=/; Expires=Wed, 13-Jan-2021 22:23:01 GMT'),
        ('Set-Cookie', 'baz=qux; Path=/; Expires=Wed, 13-Jan-2021 22:23:01 GMT'),
    ]

    result = get_expired_cookies(headers, now=time.time() + 3700)
    assert result == [
        {'name': 'foo', 'path': '/'}
    ]

get_expired_cookies.__test__ = False  # We don't want to test this by default

# Generated at 2022-06-23 20:18:38.406955
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:18:41.650485
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('blah.pdf') == 'application/pdf'
    assert get_content_type('blah.txt') == 'text/plain'
    assert get_content_type('blah') is None

# Generated at 2022-06-23 20:18:47.648650
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    source = """\
{
    "a": [
        1,
        2,
        {
            "b": 1
        }
    ],
    "c": 1
}"""
    # Run
    result = load_json_preserve_order(source)
    # Verify
    expect_keys = [
        'a',
        'c'
    ]
    assert result.keys() == expect_keys
    expect_a_keys = [
        'b'
    ]
    assert list(result['a'][2].keys()) == expect_a_keys
    print(result)

# Generated at 2022-06-23 20:18:53.259345
# Unit test for function humanize_bytes
def test_humanize_bytes():
    n = 1
    assert humanize_bytes(n) == '1 B'

    n = 1024
    assert humanize_bytes(n, precision=1) == '1.0 kB'

    n = 1024 * 123
    assert humanize_bytes(n, precision=1) == '123.0 kB'

    n = 1024 * 12342
    assert humanize_bytes(n, precision=1) == '12.1 MB'

    n = 1024 * 12342
    assert humanize_bytes(n, precision=2) == '12.05 MB'

    n = 1024 * 1234
    assert humanize_bytes(n, precision=2) == '1.21 MB'

    n = 1024 * 1234 * 1111
    assert humanize_bytes(n, precision=2) == '1.31 GB'

    n = 1024

# Generated at 2022-06-23 20:18:57.991368
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:19:09.344145
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    def assert_cookies(
        now: float,
        max_age: Optional[int],
        expires: Optional[int],
        expected: List[dict]
    ) -> None:
        headers = [
            ('Set-Cookie', 'name=value'),
        ]
        if max_age:
            headers.append(('Set-Cookie', 'max-age=%s' % max_age))
        if expires:
            headers.append(('Set-Cookie', 'expires=%s' % expires))
        got = get_expired_cookies(headers=headers, now=now)
        assert got == expected


# Generated at 2022-06-23 20:19:15.020890
# Unit test for function repr_dict
def test_repr_dict():
    d = {"a": "A", "b": "    B"}
    assert repr_dict(d) == "{\n    'a': 'A',\n    'b': '    B'\n}"
    assert repr_dict(d).replace('\n', '') == "    {    'a': 'A',    'b': '    B'    }"

# Generated at 2022-06-23 20:19:16.434268
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    explicit_null_auth = ExplicitNullAuth()
    assert explicit_null_auth is not None


# Generated at 2022-06-23 20:19:24.110075
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from http.cookies import SimpleCookie
    from io import StringIO
    from tempfile import mkdtemp
    import os

    def cookiestr(cookie):
        io = StringIO()
        cookie.output(file=io)
        return io.getvalue().lstrip()

    # make a temporary cookie jar file
    tmpdir = mkdtemp()
    cj_file = os.path.join(tmpdir, "expired_cookies.txt")
    cj = requests.cookies.RequestsCookieJar(policy=requests.cookies.DefaultCookiePolicy())
    cj.set('sessionid', 'qwerty=uiop', path='/hello/man')
    cj.set('expires', 'qwerty=uiop', path='/hello/man', expires='2050-01-01')


# Generated at 2022-06-23 20:19:25.624275
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({"foo": "bar"}) == "{\n    'foo': 'bar'\n}"

# Generated at 2022-06-23 20:19:27.681062
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"



# Generated at 2022-06-23 20:19:37.253984
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'
    print('test_humanize_bytes passed')



# Generated at 2022-06-23 20:19:38.589658
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.png') == 'image/png'

# Generated at 2022-06-23 20:19:41.945057
# Unit test for function humanize_bytes
def test_humanize_bytes():
    number = int(1e6)
    assert humanize_bytes(number, precision=2) == '1.00 MB'

# Generated at 2022-06-23 20:19:48.812619
# Unit test for function get_content_type
def test_get_content_type():
    filename = "README.rst"
    assert get_content_type(filename) == "text/x-rst"
    filename = "README.md"
    assert get_content_type(filename) == "text/markdown"
    filename = "filename.txt"
    assert get_content_type(filename) == "text/plain"
    filename = "filename.exe"
    assert get_content_type(filename) == "application/octet-stream"

# Generated at 2022-06-23 20:19:50.984989
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    import requests

    auth = ExplicitNullAuth()

    r = requests.Request('GET', 'https://github.com/')
    request = auth(r)

    assert request is r

# Generated at 2022-06-23 20:19:57.769839
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-23 20:20:04.912113
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from datetime import timedelta
    from http.cookiejar import Cookie
    from collections.abc import Mapping

    def _to_jar(cookies):
        from http.cookiejar import CookieJar
        jar = CookieJar()
        now = time.time()

# Generated at 2022-06-23 20:20:09.134570
# Unit test for function get_content_type
def test_get_content_type():
    """
    Test the function ``get_content_type``.

    """
    binary_filename = '/etc/passwd'
    assert get_content_type(binary_filename) is None

    text_filename = '/etc/hosts'
    assert get_content_type(text_filename) == 'text/plain'

    image_filename = '/usr/share/icons/gnome/256x256/devices/drive-harddisk.png'
    assert get_content_type(image_filename) == 'image/png'

# Generated at 2022-06-23 20:20:11.977518
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == "OrderedDict()"
    assert repr_dict({"a": 1, "b": 2}) == "OrderedDict([('a', 1), ('b', 2)])"

# Generated at 2022-06-23 20:20:21.720756
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.pdf; charset=UTF-8') == 'application/pdf'
    assert get_content_type('test.pdf; charset=UTF-8') == 'application/pdf'
    assert get_content_type('test.PDF') == 'application/pdf'
    assert get_content_type('test.PDf') == 'application/pdf'
    assert get_content_type('test.Pdf') == 'application/pdf'
    assert get_content_type('test.pDf') == 'application/pdf'
    assert get_content_type('test.pDF') == 'application/pdf'
    assert get_content_type('test.pdF') == 'application/pdf'

# Generated at 2022-06-23 20:20:31.201403
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-23 20:20:34.975558
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    s = """
    [
        {"a":"1", "b":"2"},
        {"c": "c", "d": "d"}
    ]
    """
    assert [{"a": "1", "b": "2"}, {"c": "c", "d": "d"}] == load_json_preserve_order(s)

# Generated at 2022-06-23 20:20:36.363224
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    e = ExplicitNullAuth()
    assert (type(e) == ExplicitNullAuth)


# Generated at 2022-06-23 20:20:46.228834
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    from io import BytesIO

    from requests.auth import AuthBase
    from requests.models import Request
    from requests.structures import CaseInsensitiveDict
    from requests.utils import parse_dict_header

    class MockRequest(Request):
        def __init__(self, *args, **kwargs):
            super(MockRequest, self).__init__(*args, **kwargs)
            self.headers = CaseInsensitiveDict()

    netrc_mock = {'machine': {'user': 'foo', 'password': 'bar'}}
    auth_instance = ExplicitNullAuth()
    request_instance = MockRequest('test://test')
    auth_instance(request_instance)
    # python 2 and 3 compatible
    auth_header = request_instance.headers.get('Authorization', '')

# Generated at 2022-06-23 20:20:47.024503
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()

# Generated at 2022-06-23 20:20:54.903165
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

# Generated at 2022-06-23 20:20:56.177315
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'a': 1}) == '{\'a\': 1}'


# Generated at 2022-06-23 20:20:58.916167
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'


# vim: et:sw=4:syntax=python:ts=4:

# Generated at 2022-06-23 20:21:05.848583
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth = ExplicitNullAuth()
    request1 = requests.Request(method='post', url='http://example.com', auth=explicit_null_auth)
    prepared = request1.prepare()
    assert prepared.headers.get('Authorization') is None
    request2 = requests.Request(method='post', url='http://example.com', auth=requests.auth.HTTPDigestAuth('alice', 'password'))
    prepared = request2.prepare()

# Generated at 2022-06-23 20:21:06.590860
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(a=1)) == "{'a': 1}"

# Generated at 2022-06-23 20:21:17.180980
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    expired_cookies = get_expired_cookies(
        headers=[
            ('Content-Type', 'text/html'),
            ('Set-Cookie', 'foo=bar'),
            ('Set-Cookie', 'path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT'),
            ('Set-Cookie', 'path=/; max-age=2'),
        ],
        now=now + 1,
    )
    assert expired_cookies == [
        {
            'name': 'foo',
            'path': '/',
        },
        {
            'name': 'path',
            'path': '/',
        }
    ]

# Generated at 2022-06-23 20:21:23.937684
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.txt") == "text/plain"
    assert get_content_type("test.html") == "text/html"
    assert get_content_type("test.csv") == "text/csv"
    assert get_content_type("test.js") == "application/javascript"
    assert get_content_type("test.pdf") == "application/pdf"
    assert get_content_type("test.png") == "image/png"

# Generated at 2022-06-23 20:21:25.052187
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    _var = ExplicitNullAuth()
    _var.__call__()
    assert True




# Generated at 2022-06-23 20:21:29.195709
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.xml') == 'application/xml'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.htm') == 'text/html'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.png') == 'image/png'



# Generated at 2022-06-23 20:21:37.635411
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    """
    >>> test_get_expired_cookies()
    """
    def test(headers: List[Tuple[str, str]], now: float = None) -> List[Tuple[str, str]]:
        now = now or time.time()
        headers = list(headers)
        cookies_in = get_expired_cookies(headers, now=now)
        headers_out = [
            (name, value)
            for name, value in headers
            if name.lower() != 'set-cookie'
        ]

# Generated at 2022-06-23 20:21:41.861876
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{ "abc": 1234, "def": 4321 }'
    expected = OrderedDict((("abc", 1234), ("def", 4321)))
    returned = load_json_preserve_order(json_str)
    assert expected == returned

# Generated at 2022-06-23 20:21:43.981479
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    obj = ExplicitNullAuth()
    assert obj() is None



# Generated at 2022-06-23 20:21:50.269281
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('example.png') == 'image/png'
    assert get_content_type('example.txt') == 'text/plain'
    assert get_content_type('example.html') == 'text/html'
    assert get_content_type('example.js') == 'application/javascript'
    assert get_content_type('example.css') == 'text/css'
    assert get_content_type('example.jpg') == 'image/jpeg'
    assert get_content_type('example') is None