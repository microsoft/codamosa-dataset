

# Generated at 2022-06-25 19:31:22.641180
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    del get_expired_cookies

# Generated at 2022-06-25 19:31:27.299718
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    test_headers_0 = [
        ('Set-Cookie', 'foo=bar; expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'baz=quux; expires=Tue, 01 Jan 2030 00:00:00 GMT'),
    ]
    test_expired_cookies_0 = get_expired_cookies(test_headers_0)
    assert test_expired_cookies_0 == [
        {
            'name': 'foo',
            'path': '/',
        },
    ]


# Generated at 2022-06-25 19:31:33.106608
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    headers = [
        ('Set-Cookie', 'echo-cookie=yes; Path=/; expires=Wed, 22 Mar 2023 18:19:22 GMT; Secure; HttpOnly; SameSite=Strict'),
        ('Set-Cookie', 'nope-cookie=no; Path=/; expires=Tue, 21 Mar 2017 18:19:22 GMT; Secure; HttpOnly; SameSite=Strict'),
        ('Set-Cookie', 'hello-cookie=world; Path=/; Max-Age=86400; Secure; HttpOnly; SameSite=Strict')
    ]

    cookies = get_expired_cookies(headers=headers, now=1521716637)

    assert cookies == [{'name': 'nope-cookie', 'path': '/'}]

# Generated at 2022-06-25 19:31:41.151150
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    asserted_expired_cookies = get_expired_cookies([
        ('Set-Cookie', 'foo=bar; expires=Sun, 18-Aug-2019 22:00:00 GMT'),
        ('Set-Cookie', 'baz=qux; Max-Age=604800; Path=/'),  # 1 week
        ('Set-Cookie', 'quux=grault; Path=/')  # Shouldn't expire
    ], now=time.time())
    assert asserted_expired_cookies == [{
        'name': 'foo',
        'path': '/'
    }], asserted_expired_cookies

# Generated at 2022-06-25 19:31:45.467361
# Unit test for function get_content_type
def test_get_content_type():
    # png
    assert get_content_type('test.png') == 'image/png'
    # png lowercase
    assert get_content_type('test.PNG') == 'image/png'
    # pdf
    assert get_content_type('test.PDF') == 'application/pdf'
    # html
    assert get_content_type('test.html') == 'text/html'



# Generated at 2022-06-25 19:31:56.553896
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # no cookies
    assert get_expired_cookies([('', '')]) == []

    # no expired cookies
    assert get_expired_cookies([
        ('Set-Cookie', 'a=1; Max-Age=10'),
        ('Set-Cookie', 'b=2; Expires=0; Domain=.mydomain.com; Path=/'),
    ]) == []

    # expires are not taken into account by Requests:
    # <https://github.com/psf/requests/issues/5743>

# Generated at 2022-06-25 19:31:59.540518
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test_filename.txt') == 'text/plain'


# Generated at 2022-06-25 19:32:06.036275
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.html'), 'text/html'
    assert get_content_type('test.css'), 'text/css'
    assert get_content_type('test.json'), 'application/json'
    assert get_content_type('test.js'), 'application/javascript'
    assert get_content_type('test.jpg'), 'image/jpeg'
    assert get_content_type('test.jpeg'), 'image/jpeg'
    assert get_content_type('test.png'), 'image/png'
    assert get_content_type('test.gif'), 'image/gif'
    assert get_content_type('test.svg'), 'image/svg+xml'
    assert get_content_type('test.webp'), 'image/webp'

# Generated at 2022-06-25 19:32:16.346710
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.gif') == 'image/gif'
    assert get_content_type('foo.jpg') == 'image/jpeg'
    assert get_content_type('foo.pdf') == 'application/pdf'
    assert get_content_type('foo.json') == 'application/json'
    assert get_content_type('foo.doc') == 'application/msword'
    assert get_content_type('foo.docx') == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.ppt') == 'application/vnd.ms-powerpoint'

# Generated at 2022-06-25 19:32:21.561809
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('.') is None
    assert get_content_type('./') is None
    assert get_content_type('.txt') is None
    assert get_content_type('./foo.txt') == 'text/plain'

# Generated at 2022-06-25 19:32:31.698217
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.md') == 'text/markdown'
    assert get_content_type('test.py') == 'text/x-python'
    assert get_content_type('test.js') == 'application/javascript'

# Generated at 2022-06-25 19:32:42.246187
# Unit test for function get_content_type
def test_get_content_type():
    dict_0 = {}
    dict_0["filename"] = "test.txt"
    dict_1 = {}
    dict_1["encoding"] = "utf-8"
    dict_1["filename"] = "test.txt"
    dict_2 = {}
    dict_2["filename"] = "test.txt"
    dict_2["encoding"] = "utf-8"
    dict_list = [dict_0, dict_1, dict_2]

    for dict in dict_list:
        try:
            res = get_content_type(**dict)
        except Exception as e:
            print("Exception caught when running get_content_type test case. Exception:\n{0}".format(str(e)))



# Generated at 2022-06-25 19:32:49.509531
# Unit test for function get_content_type
def test_get_content_type():
    print("\n\n")
    print("In unit test for function get_content_type()")
    # Test case 0
    filename = ""
    content_type = get_content_type(filename)
    print("\nTest case summary:\n    Input: ", filename, "\n    Output: ", content_type)
    assert content_type == None

    # Test case 1
    filename = "bravo.txt"
    content_type = get_content_type(filename)
    print("\nTest case summary:\n    Input: ", filename, "\n    Output: ", content_type)
    assert content_type == "text/plain"

    # Test case 2
    filename = "charlie.png"
    content_type = get_content_type(filename)

# Generated at 2022-06-25 19:32:57.238332
# Unit test for function get_content_type
def test_get_content_type():
    # mimetypes should guess HTML content types
    assert get_content_type('file.html') == 'text/html'
    assert get_content_type('file.htm') == 'text/html'
    # And multiple content types should be concatenated
    assert get_content_type('file.html.gz') == 'text/html; charset=gzip'
    # But not for empty extensions
    assert get_content_type('file.') == None
    # The extension is case-insensitive
    assert get_content_type('file.HTML') == 'text/html'
    # But mimetypes gives no guarantee about case
    assert get_content_type('file.HtML') == 'text/html'



# Generated at 2022-06-25 19:32:58.135953
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('hello.txt') == 'text/plain'



# Generated at 2022-06-25 19:33:04.405205
# Unit test for function get_content_type
def test_get_content_type():
    filename1 = 'filename1.html'
    filename2 = 'filename2.JpG'
    filename3 = 'filename3.pdf'
    filename4 = 'filename4'

    assert get_content_type(filename1) == 'text/html'
    assert get_content_type(filename2) == 'image/jpeg'
    assert get_content_type(filename3) == 'application/pdf'
    assert get_content_type(filename4) == None

# Generated at 2022-06-25 19:33:07.025958
# Unit test for function get_content_type
def test_get_content_type():
    try:
        assert get_content_type('archive.tar') == 'application/x-tar'
    except Exception:
        print("Exception in test_get_content_type")
        raise

# Generated at 2022-06-25 19:33:11.051144
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('a.txt') == 'text/plain'
    assert get_content_type('b.js') == 'application/javascript'
    assert get_content_type('c.unknown_ext') is None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 19:33:15.474556
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('filename.mp4') == 'video/mp4'
    assert get_content_type('filename.png') == 'image/png'
    assert get_content_type('filename.none') is None

# Generated at 2022-06-25 19:33:21.600795
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('blah.txt') == 'text/plain'
    assert get_content_type('blah.html') == 'text/html'
    assert get_content_type('blah.xhtml') == 'application/xhtml+xml'
    assert get_content_type('blah.svg') == 'image/svg+xml'
    assert get_content_type('blah.blah') is None

# Generated at 2022-06-25 19:33:29.768236
# Unit test for function repr_dict
def test_repr_dict():
    print('Calling function repr_dict with parameter [ {"key_0": "value_0"} ]')
    expected_result_0 = "{'key_0': 'value_0'}"
    actual_result_0 = repr_dict({"key_0": "value_0"})
    if actual_result_0 != expected_result_0:
        print('Test Failed')
    else:
        print('Test Passed')


# Generated at 2022-06-25 19:33:34.288762
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.text') is None
    assert get_content_type('test.jpg') == 'image/jpeg'



# Generated at 2022-06-25 19:33:37.480142
# Unit test for function get_content_type
def test_get_content_type():
    # Set up local variables
    file_name = "test_get_content_type.txt"
    result = get_content_type(file_name)
    print(result)
    assert(result == "text/plain")

# Generated at 2022-06-25 19:33:42.555343
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    input_str = '{"test1":1, "test2":2}'
    expected_output = OrderedDict([("test1", 1),("test2", 2)])
    output = load_json_preserve_order(input_str)
    assert expected_output == output


# Generated at 2022-06-25 19:33:46.767830
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict(OrderedDict([('a', 1), ('b', 2), ('c', 3)])) == \
        "OrderedDict([('a', 1), ('b', 2), ('c', 3)])"



# Generated at 2022-06-25 19:33:49.731176
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    exception_raised = False
    try:
        var = ExplicitNullAuth()
    except Exception:
        exception_raised = True
    assert not exception_raised
    assert var is not None


# Generated at 2022-06-25 19:33:51.658497
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    i = ExplicitNullAuth()


# Generated at 2022-06-25 19:33:56.298561
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert '1 MB' == humanize_bytes(1024 * 1024)
    assert '1.1 MB' == humanize_bytes(1024 * 1024 * 1.1)
    assert '1.0 kB' == humanize_bytes(1024, precision=1)
    assert '123.0 B' == humanize_bytes(123, precision=1)

# Generated at 2022-06-25 19:33:59.189868
# Unit test for function repr_dict
def test_repr_dict():
    # cases
    assert repr_dict({}) == "OrderedDict()"
    assert repr_dict({'a': 1, 'b': 2}) == "OrderedDict([('a', 1), ('b', 2)])"



# Generated at 2022-06-25 19:34:09.138321
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.TXT') == 'text/plain'
    assert get_content_type('foo.txt.gz') == 'text/plain'
    assert get_content_type('foo.txt.GZ') == 'text/plain'
    assert get_content_type('foo.txt.gzip') is None
    assert get_content_type('foo.txt.GZIP') is None
    assert get_content_type('foo.txt.GZIP', strict=True) is None
    assert get_content_type('foo.txt.GZIP', strict=True) is None
    assert get_content_type('foo.txt.gz', strict=True) == 'text/plain; charset=gzip'
    assert get