

# Generated at 2022-06-25 19:31:20.004200
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'PHPSESSID=test1; expires=Wed, 13-Feb-2019 01:30:00 GMT; path=/'),
        ('Set-Cookie', 'PHPSESSID=test2; expires=Wed, 13-Feb-2019 01:30:00 GMT; path=/'),
        ('Set-Cookie', 'PHPSESSID=test3; expires=Wed, 13-Feb-2019 01:30:00 GMT; path=/')
    ]
    expired_cookies = get_expired_cookies(headers=headers)

# Generated at 2022-06-25 19:31:22.697542
# Unit test for function get_content_type
def test_get_content_type():
    name = 'text.txt'
    assert get_content_type(name) == 'text/plain', 'get_content_type assert error'


if __name__ == '__main__':
    test_case_0()
    test_get_content_type()

# Generated at 2022-06-25 19:31:28.207476
# Unit test for function get_content_type
def test_get_content_type():
    for filename, content_type in [
        ('test_file.txt', 'text/plain'),
        ('test_file.foo', 'application/x-foo-compressed'),
        ('image.png', 'image/png'),
        ('image.jpeg', 'image/jpeg'),
        ('image', None),
    ]:
        assert get_content_type(
            filename
        ) == content_type

# Generated at 2022-06-25 19:31:31.932841
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # given
    test_expired_cookie_as_ns_value = "name=value; Expires=Wed, 21 Oct 2015 07:28:00 GMT"
    test_expired_cookie = {'name': 'name', 'expires': 1445496080.0, 'path': '/'}

    # when
    test_expired_cookies = get_expired_cookies(
        headers=[('set-cookie', test_expired_cookie_as_ns_value)],
        now=1445496080.0  # Wed, 21 Oct 2015 07:28:00 GMT
    )

    # then
    assert test_expired_cookies == [test_expired_cookie]

# Generated at 2022-06-25 19:31:42.537996
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:31:45.565817
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(__file__) == 'text/x-python'
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test') is None



# Generated at 2022-06-25 19:31:51.140678
# Unit test for function get_content_type
def test_get_content_type():
    mime, encoding = mimetypes.guess_type('todolist.txt', strict=False)
    assert mime == 'text/plain'
    assert encoding == None
    assert get_content_type('todolist.txt') == 'text/plain'

if __name__=='__main__':
    test_case_0()
    test_get_content_type()

# Generated at 2022-06-25 19:32:01.489419
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    # First test case
    headers = [('Set-Cookie', 'foo=bar; Expires=Sat, 31-Dec-2039 23:59:59 GMT')]

    # No cookie should be expired
    assert(get_expired_cookies(headers, now) == [])

    # Second test case
    headers = [('Set-Cookie', 'foo=bar; Expires=Sat, 31-Dec-1999 23:59:59 GMT')]
    # The cookie foo should be expired
    assert(get_expired_cookies(headers, now) == [{'name': 'foo', 'path': '/'}])

    # Third test case
    headers = [('Set-Cookie', 'foo=bar; path=/; max-age=0')]
    # HACK/FIXME: <https

# Generated at 2022-06-25 19:32:09.727695
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename='filename.txt') == 'text/plain'

    assert (
        get_content_type(filename='filename.txt; charset=utf-8')
        == 'text/plain; charset=utf-8'
        )

    assert get_content_type(filename='filename.txt; charset=utf-8') != 'text/plain'

    assert get_content_type(filename='filename.txt; charset=utf-8') != 'text/plain; charset=utf-8'

    assert get_content_type(filename='filename.txt') != 'text/plain; charset=utf-8'



# Generated at 2022-06-25 19:32:21.084395
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [('Set-Cookie', 'session_id=c3A7d9190e9b142722f03; expires=Tue, 14-Apr-20 12:00:00 GMT; path=/')]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now)
    assert expired_cookies == []

    headers = [('Set-Cookie', 'session_id=c3A7d9190e9b142722f03; expires=Tue, 17-Apr-19 12:00:00 GMT; path=/')]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now)
    assert expired_cookies == [{'name': 'session_id', 'path': '/'}]


# Generated at 2022-06-25 19:32:35.285110
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('a.txt') == 'text/plain'
    assert get_content_type('a.csv') == 'text/csv'
    assert get_content_type('a.json') == 'application/json'
    assert get_content_type('a.js') == 'text/javascript'
    assert get_content_type('a.xlsx') == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    assert get_content_type('a.mp3') == 'audio/mpeg'
    assert get_content_type('a.mp4') == 'video/mp4'
    assert get_content_type('a.avi') == 'video/x-msvideo'
    assert get_content_type('a.avi') == 'video/x-msvideo'
   

# Generated at 2022-06-25 19:32:46.330362
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.txt") == 'text/plain'
    test_1 = get_content_type("test.cpp")
    test_2 = get_content_type("test.html")
    assert test_1 == 'text/x-c'
    assert test_2 == 'text/html'
    assert get_content_type("test.css") == 'text/css'
    assert get_content_type("test.js") == 'application/javascript'
    assert get_content_type("test.c") == 'text/plain'
    assert get_content_type("test.py") == 'text/x-python'
    assert get_content_type("test.java") == 'text/x-java'
    assert get_content_type("test.go") == 'text/x-go'

# Generated at 2022-06-25 19:32:55.454137
# Unit test for function get_content_type
def test_get_content_type():
    filename = "test.mp4"
    assert get_content_type(filename) == "video/mp4"

    filename = "test.jpg"
    assert get_content_type(filename) == "image/jpeg"

    filename = "test.jpeg"
    assert get_content_type(filename) == "image/jpeg"

    filename = "test.png"
    assert get_content_type(filename) == "image/png"

    filename = "test.txt"
    assert get_content_type(filename) == "text/plain"


# Generated at 2022-06-25 19:32:57.760983
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('tmp/foo') is None



# Generated at 2022-06-25 19:33:00.181766
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('text.txt') == 'text/plain'


# Generated at 2022-06-25 19:33:10.127072
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("foo.txt") == "text/plain"
    assert get_content_type("foo.html") == "text/html"
    assert get_content_type("foo.css") == "text/css"
    assert get_content_type("foo.js") == "application/javascript"
    assert get_content_type("foo.json") == "application/json"
    assert get_content_type("foo.example") is None
    assert get_content_type("foo.EXAMPLE") is None
    assert get_content_type("foo.EXAMPLE") is None
    assert get_content_type("foo.md") == "text/markdown"
    assert get_content_type("foo.mdx") == "text/x-markdown"

# Generated at 2022-06-25 19:33:14.869433
# Unit test for function get_content_type
def test_get_content_type():
    # assert get_content_type('file.txt') == 'text/plain'
    # assert get_content_type('file.bin') == 'application/octet-stream'
    # assert get_content_type('file.bin.tar.gz') == 'application/x-tar'
    # assert get_content_type('') is None
    pass

# Generated at 2022-06-25 19:33:17.779925
# Unit test for function get_content_type
def test_get_content_type():
    pass


if __name__ == '__main__':
    print(test_case_0())

    # Tests for function get_content_type
    print(test_get_content_type())

# Generated at 2022-06-25 19:33:19.839286
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('./testfolder/get_content_type.txt') == 'text/plain'

# Generated at 2022-06-25 19:33:22.797743
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.html") == "text/html"
    assert get_content_type("test.pdf") == "application/pdf"
    assert get_content_type("test.css") == "text/css"


# Generated at 2022-06-25 19:33:27.424932
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('get-content-type_test.py') == 'text/x-python'
    assert get_content_type('This file does not exist.') is None

# Generated at 2022-06-25 19:33:29.884234
# Unit test for function get_content_type
def test_get_content_type():
    file_name = 'test.txt'
    content_type = get_content_type(file_name)
    assert content_type == 'text/plain'

# Generated at 2022-06-25 19:33:32.019474
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.png') is None
    assert get_content_type('filename.txt') == 'text/plain'

# Generated at 2022-06-25 19:33:41.894612
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('C:\\fakepath\\image.jpeg') == 'image/jpeg'
    assert get_content_type('C:\\fakepath\\image.JPEG') == 'image/jpeg'
    assert get_content_type('C:\\fakepath\\image.PNG') == 'image/png'
    assert get_content_type('C:\\fakepath\\image.png') == 'image/png'
    assert not get_content_type('C:\\fakepath\\image.xyz')
    assert get_content_type('C:\\fakepath\\image.jpeg; charset=utf-8') == 'image/jpeg; charset=utf-8'

# Generated at 2022-06-25 19:33:47.818251
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.html; charset=utf-8') == 'text/html; charset=utf-8'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.pdf') == 'application/pdf'
    assert get_content_type('test.gz') == 'application/gzip'


# Generated at 2022-06-25 19:33:52.794047
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.csv') == 'text/csv'
    assert get_content_type('test.csv.gz') == 'application/x-gzip'
    assert get_content_type('test.csv.bz2') == 'application/x-bzip2'


# Generated at 2022-06-25 19:34:02.754791
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/plain' == get_content_type('foo.txt')
    assert 'image/x-portable-pixmap' == get_content_type('foo.ppm')
    assert 'application/octet-stream' == get_content_type('foo.ppm.bz2')
    assert 'image/png' == get_content_type('foo.PNG')
    assert 'video/x-flv' == get_content_type('foo.flv')
    assert 'text/html' == get_content_type('foo.HTML')
    assert 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' == get_content_type('foo.xlsx')
    assert 'text/javascript' == get_content_type('foo.js')

# Generated at 2022-06-25 19:34:04.245211
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'

# Generated at 2022-06-25 19:34:09.111002
# Unit test for function get_content_type
def test_get_content_type():
    assert '\n<BLANKLINE>' in """
        {
            "foo": "bar"
        }
    """
    assert '<BLANKLINE>    "foo": "bar"<BLANKLINE>}' in """
        {
            "foo": "bar"
        }
    """
    assert '<BLANKLINE>}' in """
        {
            "foo": "bar"
        }
    """

# Generated at 2022-06-25 19:34:14.151495
# Unit test for function get_content_type
def test_get_content_type():
    ext_to_ctype = [
        ('README.txt', 'text/plain'),
        ('README.md', 'text/x-markdown'),
        ('LICENSE', 'text/plain'),
        ('setup.cfg', 'text/x-ini'),
        ('pip_directive_gen.py', 'text/x-python'),
    ]

    for filename, ctype in ext_to_ctype:
        assert get_content_type(filename) == ctype

# Generated at 2022-06-25 19:34:16.417730
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    auth = ExplicitNullAuth()

# Generated at 2022-06-25 19:34:19.719111
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('bob.txt') == 'text/plain'
    assert get_content_type('bob.jpeg') == "image/jpeg"
    assert get_content_type('bob') == None
    assert get_content_type('bob.pdf') == "application/pdf"

# Generated at 2022-06-25 19:34:27.433334
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1, 1) == '1.0 B'
    assert humanize_bytes(1024, 1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, 1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, 1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, 2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, 2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, 2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, 1) == '1.3 GB'

# Generated at 2022-06-25 19:34:30.043577
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    dict_0 = {}
    s = json.dumps(dict_0)
    dict_1 = load_json_preserve_order(s)
    assert dict_0 == dict_1



# Generated at 2022-06-25 19:34:34.882643
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    '''
    unit testing for ExplicitNullAuth.py
    '''
    # test_ExplicitNullAuth_instance = ExplicitNullAuth()
    # print(test_ExplicitNullAuth_instance)
# test_case_1

# Generated at 2022-06-25 19:34:43.269927
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-25 19:34:46.178598
# Unit test for function repr_dict
def test_repr_dict():
    dict_1 = {"a":"abc","b":"bcd"}
    assert repr_dict(dict_1) == "OrderedDict([('a', 'abc'), ('b', 'bcd')])"


# Generated at 2022-06-25 19:34:47.579389
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() != None


# Generated at 2022-06-25 19:34:51.463810
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()
    requests_request_0 = requests.Request()
    requests_request_0.prepare()
    requests_request_0.headers = {}
    explicit_null_auth_0(requests_request_0)



# Generated at 2022-06-25 19:35:02.262404
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert(humanize_bytes(0) == '0 B')
    assert(humanize_bytes(1) == '1 B')
    assert(humanize_bytes(1, precision=0) == '1 B')
    assert(humanize_bytes(1024, precision=0) == '1 kB')
    assert(humanize_bytes(1024 * 123, precision=0) == '123 kB')
    assert(humanize_bytes(1024 * 12342, precision=0) == '12 kB')
    assert(humanize_bytes(1024 * 12342, precision=1) == '12.0 kB')
    assert(humanize_bytes(1024 * 1234, precision=2) == '1.21 kB')
    assert(humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 MB')

# Generated at 2022-06-25 19:35:12.862760
# Unit test for function repr_dict
def test_repr_dict():
    # Creation of test case data
    dict_0 = {'foo': [3, 'a', 'b'], 'bar': 6, 'baz': 'Y', 'qux': ('aa', 'x')}
    dict_1 = {'foo': [3, 'a', 'b'], 'bar': 6, 'baz': 'Y', 'qux': ('aa', 'x')}
    assert(repr_dict(dict_0) == repr_dict(dict_1))

    assert(not repr_dict(dict_0) == repr_dict({}))



# Generated at 2022-06-25 19:35:25.004120
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    d = {"foo": "bar", "baz": "qux"}
    assert load_json_preserve_order(json.dumps(d)) == d

    d_ordered = OrderedDict([('foo', 'bar'), ('baz', 'qux')])
    assert load_json_preserve_order(json.dumps(d_ordered)) == d_ordered
    assert load_json_preserve_order(json.dumps(d_ordered)) is not d_ordered

    d = {"foo": [1, 2, 3], "baz": {"quux": "qux"}}
    assert load_json_preserve_order(json.dumps(d)) == d


# Generated at 2022-06-25 19:35:31.918602
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', '_gat=1; expires=Sat, 01 Jan 2033 00:00:00 GMT; path=/; domain=.example.com'),
        ('Set-Cookie', '_ga=GA1.2.269856687.1430688843; expires=Sat, 01 Jan 2033 00:00:00 GMT; path=/; domain=.example.com')
    ]
    cookies = get_expired_cookies(headers)
    # print(cookies)


if __name__ == '__main__':
    test_get_expired_cookies()

# Generated at 2022-06-25 19:35:41.353985
# Unit test for function get_content_type
def test_get_content_type():
    # Test 1
    content_type = get_content_type('test.json')
    assert content_type == 'application/json', "Content-Type should be application/json."

    # Test 2
    content_type = get_content_type('test.pdf')
    assert content_type == 'application/pdf', "Content-Type should be application/pdf."

    # Test 3
    content_type = get_content_type('test.rtf')
    assert content_type == 'application/rtf', "Content-Type should be application/rtf."

    # Test 4
    content_type = get_content_type('test.html')

# Generated at 2022-06-25 19:35:48.081862
# Unit test for function get_content_type
def test_get_content_type():
    # Should take into account the encoding.
    assert get_content_type('/some/path.txt') == 'text/plain'
    # Should handle unknown mime types.
    assert get_content_type('/some/path') is None
    # Should add the string 'charset=<encoding>' to the content-type.
    assert get_content_type('/some/path.txt') == 'text/plain; charset=us-ascii'
    # Should take into account the extension.
    assert get_content_type('/some/path.css') == 'text/css'



# Generated at 2022-06-25 19:35:49.763497
# Unit test for function repr_dict
def test_repr_dict():
    dict_0 = {}
    str_0 = repr_dict(dict_0)
    assert (str_0=="{}")
    

# Generated at 2022-06-25 19:35:50.879336
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    try:
        ExplicitNullAuth()
    except Exception as e:
        raise e

if __name__ == '__main__':
    test_case_0()
    test_ExplicitNullAuth()

# Generated at 2022-06-25 19:35:51.749025
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    pass



# Generated at 2022-06-25 19:35:54.905177
# Unit test for function get_content_type
def test_get_content_type():
    # Test getting the content type
    filename = "requests_tests.py"
    content_type = get_content_type(filename)
    assert "text/x-python" in content_type
    # Test getting the content type after changing the file name
    filename = "requests_tests"
    content_type = get_content_type(filename)
    assert content_type is None

# Generated at 2022-06-25 19:36:05.396333
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers: List[Tuple[str, str]] = [
        ('Set-Cookie', 'a=1; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; max-age=0'),
        ('Set-Cookie', 'b=2; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; max-age=0'),
        ('Set-Cookie', 'c=3; path=/; expires=Sun, 01 Jan 2017 00:00:00 GMT; max-age=31536000')
    ]
    cookies: List[dict] = get_expired_cookies(
        headers=headers,
        now=2147483650
    )

# Generated at 2022-06-25 19:36:10.736627
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicitnullauth_instance = ExplicitNullAuth()
    import requests
    response = requests.Response()
    explicitnullauth_instance(response)


# Generated at 2022-06-25 19:36:11.376524
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    explicitNullAuth = ExplicitNullAuth()

# Generated at 2022-06-25 19:36:12.500283
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename='foo.txt') == 'text/plain'



# Generated at 2022-06-25 19:36:22.097111
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    order = ['one', 'two', 'three', 'four']

    def _build_json():
        json = '{'
        for item in order:
            json += '"' + item + '": ' + '"' + item + '", '
        json = json[:-2]
        json += '}'
        return json

    json_str_0 = _build_json()

    result = load_json_preserve_order(json_str_0)
    assert list(result.keys()) == order
    assert list(result.values()) == order
    assert result['one'] == 'one'
    assert result['two'] == 'two'
    assert result['three'] == 'three'
    assert result['four'] == 'four'

# Generated at 2022-06-25 19:36:24.943935
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    __instance: ExplicitNullAuth = ExplicitNullAuth()
    __in: requests.models.PreparedRequest = requests.models.PreparedRequest()
    __out: requests.models.PreparedRequest = __instance(__in)


# Generated at 2022-06-25 19:36:27.335330
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicitNullAuth = ExplicitNullAuth()
    explicitNullAuth___call__ = ExplicitNullAuth.__call__
    request = None
    explicitNullAuth___call__(explicitNullAuth, request)

# Generated at 2022-06-25 19:36:28.571253
# Unit test for function get_content_type
def test_get_content_type():
    ct = get_content_type('this could be a filename')
    assert ct == 'application/octet-stream'

# Generated at 2022-06-25 19:36:33.859360
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


# Generated at 2022-06-25 19:36:34.658935
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth() is not None


# Generated at 2022-06-25 19:36:42.992174
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert '1 B' == humanize_bytes(1)
    assert '1.0 kB' == humanize_bytes(1024, precision=1)
    assert '123.0 kB' == humanize_bytes(1024 * 123, precision=1)
    assert '12.1 MB' == humanize_bytes(1024 * 12342, precision=1)
    assert '12.05 MB' == humanize_bytes(1024 * 12342, precision=2)
    assert '1.21 MB' == humanize_bytes(1024 * 1234, precision=2)
    assert '1.31 GB' == humanize_bytes(1024 * 1234 * 1111, precision=2)
    assert '1.3 GB' == humanize_bytes(1024 * 1234 * 1111, precision=1)

# Generated at 2022-06-25 19:37:02.060564
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 1}) == "{'a': 1}"
    assert repr_dict({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3}) == "{'a': 1, 'b': 2, 'c': 3}"
    assert repr_dict({'a': 1, 'b': 2, 'c': 3, 'd': 4}) == "{'a': 1, 'b': 2, 'c': 3, 'd': 4}"

# Generated at 2022-06-25 19:37:04.370966
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('.txt') == 'text/plain'
    assert get_content_type('../xyz') is None

# Generated at 2022-06-25 19:37:06.552105
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    obj_0 = ExplicitNullAuth()
    pass


# Generated at 2022-06-25 19:37:08.556333
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    test = ExplicitNullAuth()
    test



# Generated at 2022-06-25 19:37:15.345125
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    text = '''
        {
            "A": 1,
            "B": [1, 2, 3],
            "C": {"a": 1, "b": 2, "c": 3},
            "D": {"cc": {"a": 1, "b": 2, "c": 3}}
        }
    '''
    assert load_json_preserve_order(text) == json.loads(text, object_pairs_hook=OrderedDict)

# Generated at 2022-06-25 19:37:16.405016
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # Test Case 1
    obj = ExplicitNullAuth()
    assert True



# Generated at 2022-06-25 19:37:18.161309
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a key': 'a value'}) == "{'a key': 'a value'}"



# Generated at 2022-06-25 19:37:22.949205
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.py') == 'text/x-python'
    assert get_content_type('foo.js') == 'application/javascript'
    assert get_content_type(__file__) == 'text/x-python'
    assert get_content_type('foo.bin') == 'application/octet-stream'



# Generated at 2022-06-25 19:37:28.329640
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    dict_0 = {}
    dict_0['a'] = 'b'
    dict_0['c'] = 'd'
    dict_0['e'] = 'f'
    str_0 = json.dumps(dict_0) # dict_0 -> string
    dict_1 = load_json_preserve_order(str_0)
    assert dict_0 == dict_1

# Generated at 2022-06-25 19:37:36.574692
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # sample headers
    headers = [('Set-Cookie', 'session_id=xyz; max-age=100; domain=.example.com'),
               ('Set-Cookie', 'cookie1=value1; expires=Mon, 01 Jan 2018 15:17:12 GMT'),
               ('Set-Cookie', 'cookie2=value2; expires=Tue, 01 Jan 2019 15:17:12 GMT')]

    # since we can't set the system time, we define our own time
    now = 1549925945.137064
    assert get_expired_cookies(headers=headers, now=now) == [
        {'name': 'cookie1', 'path': '/'}
    ]


if __name__ == "__main__":
    test_case_0()