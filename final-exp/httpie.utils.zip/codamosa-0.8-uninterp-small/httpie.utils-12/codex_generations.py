

# Generated at 2022-06-25 19:31:16.349700
# Unit test for function get_content_type
def test_get_content_type():
    import os

    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type(__file__) == 'text/x-python'

    assert get_content_type('test') is None
    assert get_content_type(os.devnull) is None



# Generated at 2022-06-25 19:31:20.510678
# Unit test for function get_content_type
def test_get_content_type():
    mime_type = get_content_type('test.mp4')
    assert mime_type == 'video/mp4'


if __name__ == '__main__':
    print('Running %s...' % __file__)

    test_case_0()
    print('OK')

# Generated at 2022-06-25 19:31:25.043748
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('ayy_lmao.txt') == 'text/plain'



# Generated at 2022-06-25 19:31:28.084693
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.bin') == 'application/octet-stream'
    assert get_content_type('file.foo') is None

# Generated at 2022-06-25 19:31:31.878899
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.png') == 'image/png'
    assert get_content_type('test.py') == 'text/x-python'
    assert get_content_type('test.unknow') == None

# Generated at 2022-06-25 19:31:42.500033
# Unit test for function humanize_bytes

# Generated at 2022-06-25 19:31:48.773471
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # Test case 1:
    cookie_string = "apikey=abc; expires=Tue, 01 Jan 2030 23:59:59 GMT; Max-Age=315360000"
    headers_1 = [(b'Set-Cookie', cookie_string.encode())]
    assert get_expired_cookies(headers_1) == []

    # Test case 2:
    cookie_string = "apikey=abc; expires=Mon, 17 May 1999 23:59:59 GMT; Max-Age=315360000"
    headers_2 = [(b'Set-Cookie', cookie_string.encode())]
    assert get_expired_cookies(headers_2) == [{'name': 'apikey', 'path': '/'}]

    # Test case 3:

# Generated at 2022-06-25 19:31:51.655129
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('index.html') == 'text/html'
    assert get_content_type('myfile.tar.gz') == 'application/x-gzip'



# Generated at 2022-06-25 19:32:00.646287
# Unit test for function get_content_type
def test_get_content_type():
    json_type = "application/json"
    jpeg_type = "image/jpeg"
    txt_type = "text/plain"

    json_result = get_content_type("sample.json")
    jpeg_result = get_content_type("sample.jpeg")
    png_result = get_content_type("sample.png")
    txt_result = get_content_type("sample.txt")

    assert json_result == json_type
    assert jpeg_result == jpeg_type
    assert png_result is None
    assert txt_result == txt_type



# Generated at 2022-06-25 19:32:08.854041
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    name = 'sessionid'
    value = 'deadbeefdeadbeefdeadbeefdeadbeef'
    max_age = '31415926535'
    path = '/'
    headers = [
        (
            'Set-Cookie',
            f'{name}={value}; Path={path}; HttpOnly; Max-Age={max_age}; '
            'Secure; SameSite=Lax; '
        )
    ]

    expired_cookies = get_expired_cookies(headers=headers)
    assert expired_cookies == [{'name': name, 'path': path}]



# Generated at 2022-06-25 19:32:22.543885
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    test_headers = (
        ('Set-Cookie', 'Bar=Baz; Max-Age=0; Expires=Wed, 19-Apr-2017 10:21:39 GMT'),
        ('Set-Cookie', 'Foo=Bar; Max-Age=0; Expires=Wed, 19-Apr-2017 10:21:39 GMT'),
        ('Set-Cookie', 'Hello=World; Max-Age=0; Expires=Wed, 19-Apr-2017 10:21:39 GMT'),
    )
    # These were obtained from a real response to a request to <https://httpbin.org/cookies/set?Foo=Bar&Hello=World>
    # on 2017-04-19 at 10:21:38 UTC.

# Generated at 2022-06-25 19:32:34.703017
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:32:45.225350
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers: List[Tuple[str, str]] = [
        ('Set-Cookie', 'session_id=abc; Max-Age=3600; Path=/'),
        ('Set-Cookie', 'session_id=abc; Expires=Wed, 09 Jun 2021 10:18:14 GMT; Path=/'),
    ]
    now: float = 1602390694
    cookies: List[dict] = get_expired_cookies(headers=headers, now=now)
    cookies_expected: List[dict] = [{'name': 'session_id', 'path': '/'}]
    assert cookies == cookies_expected


if __name__ == '__main__':
    test_case_0()
    test_get_expired_cookies()

# Generated at 2022-06-25 19:32:56.383617
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    # get_expired_cookies(, now = None)
    # test 1
    headers_1 = [('Set-Cookie', 'a=b; expires=Thu, 01-Jan-1970 00:00:01 GMT; Max-Age=0; path=/')
                , ('Set-Cookie', 'c=d; path=/')]
    now_1 = 0
    res_1 = get_expired_cookies(headers_1, now_1)
    assert res_1 == [{'name': 'a', 'path': '/'}]

    # get_expired_cookies(, now = None)
    # test 2

# Generated at 2022-06-25 19:33:05.948525
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'PHPSESSID=l8k0b9ka205d4mfjohrgnd4mq3;'),
        ('Set-Cookie', 'foo=bar; path=/; expires=Thu, 07 May 2020 00:22:11 GMT'),
        ('Set-Cookie', 'baz=qux; path=/; expires=Thu, 07 May 2020 00:22:13 GMT'),
        ('Set-Cookie', 'quux=quuz; path=/; expires=Thu, 07 May 2020 00:22:14 GMT'),
    ]
    cookies = get_expired_cookies(headers, now=time.time() + 1000000)


# Generated at 2022-06-25 19:33:11.714240
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    expired_headers = [
        ('Set-Cookie', 'foo=bar; max-age=1'),  # Will expire later
        ('Set-Cookie', 'baz=qux; expires=%s' % int(now - 1))
    ]
    expired_cookies = [
        {'name': 'baz', 'path': '/'},
    ]

    assert expired_cookies == get_expired_cookies(expired_headers, now=now)



# Generated at 2022-06-25 19:33:22.107752
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    from typing import List, Tuple
    from http.cookiejar import parse_ns_headers

    headers: List[Tuple[str, str]] = [
        ('set-cookie', "PHPSESSID=atjh6md536q3qk9g5mspis1ud5"),
        ('set-cookie', "path=/"),
        ('set-cookie', "max-age=3600;"),
        ('set-cookie', "expires=Wed, 05-Feb-2020 04:57:53 GMT"),
        ('other-header', "other-value"),
    ]

    attr_sets: List[Tuple[str, str]] = parse_ns_headers(
        value for name, value in headers
        if name.lower() == 'set-cookie'
    )

# Generated at 2022-06-25 19:33:33.762726
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()

    # Just `expires`
    cookies1 = [
        {
            'name': 'Zero',
            'value': 'one',
            'path': '/',
            'expires': now - 1
        },
        {
            'name': 'Two',
            'value': 'three',
            'path': '/',
            'expires': now + 1
        }
    ]
    expired_cookies1 = get_expired_cookies(cookies1, now=now)
    assert expired_cookies1 == [{'name': 'Zero', 'path': '/'}]

    # Just `max-age`

# Generated at 2022-06-25 19:33:44.785265
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    print('\33[43m\33[1m Unit testing \33[0m')
    print('\33[0m Function \33[0m')
    print('\33[0m get_expired_cookies \33[0m')

# Generated at 2022-06-25 19:33:50.350910
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookie_name = 'test_cookie'
    headers = [
        ('Set-Cookie', 'test_cookie=test_value'),
        ('Set-Cookie', 'test_cookie1=test_value1'),
        ('Set-Cookie', 'test_cookie2=test_value2; path=/foo; expires=Thu, 01 Jan 1970 00:00:00 GMT'),
        ('Set-Cookie', 'test_cookie3=test_value3; path=/foo; max-age=0'),
    ]
    res = get_expired_cookies(headers)

    assert {'name': cookie_name, 'path': '/'} in res



# Generated at 2022-06-25 19:33:56.256360
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('Image.png') == 'image/png'
    assert get_content_type('/home/test/test.pdf') == 'application/pdf'


if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-25 19:34:01.194679
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    with open('./test/test_load_json_preserve_order.json', 'r', encoding='utf-8') as f:
        json_d = load_json_preserve_order(f.read())
        assert json_d['name'] == 'fangel'
        assert json_d['stats']['age'] == '29'


# Generated at 2022-06-25 19:34:02.049594
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()



# Generated at 2022-06-25 19:34:09.176314
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies(headers=[
        ('Set-Cookie', 'one=1; path=/'),
        ('Set-Cookie', 'two=2; path=/; expires=Wed, 09 Jun 2021 10:18:14 GMT'),
        ('Set-Cookie', 'three=3; path=/; max-age=60'),
    ])
    assert len(cookies) == 1
    assert cookies[0]['name'] == 'three'
    assert cookies[0]['path'] == '/'


if __name__ == '__main__':
    import doctest; doctest.testmod()

# Generated at 2022-06-25 19:34:11.810572
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({}) == '{}'
    assert repr_dict({'a': 'aa', 'b': 'bb'}) == "{\'a\': \'aa\', \'b\': \'bb\'}"

# Generated at 2022-06-25 19:34:21.804242
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    header_pairs = [
        ('Set-Cookie', 'a=1; expires=Wed, 01 Jan 2038 00:00:00 GMT'),
        ('Set-Cookie', 'b=2; Max-age=60'),
        ('Set-Cookie', 'c=3'),
    ]
    assert get_expired_cookies(header_pairs, now=0) == []
    assert get_expired_cookies(header_pairs, now=300000000) == [
        {'name': 'a', 'path': '/'},
        {'name': 'b', 'path': '/'},
        {'name': 'c', 'path': '/'},
    ]

# Generated at 2022-06-25 19:34:28.420923
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Create an instance of class ExplicitNullAuth
    ENA = ExplicitNullAuth()
    # Attempt to call __call__ without setting any attributes
    try:
        ENA.__call__(r=None)
    except:
        assert False
    # Assign a dummy value to the attribute r
    ENA.r = None
    # Verify that the value of the attribute r has changed
    assert ENA.r == None
    # Attempt to call __call__
    try:
        ENA.__call__(r=None)
    except:
        assert False
    # Verify that the value of the attribute r has changed again
    assert ENA.r == None


# Generated at 2022-06-25 19:34:37.901212
# Unit test for function repr_dict
def test_repr_dict():
    dict_0 = dict(a=dict(aa=dict(aaa=dict(aaaa=0))))
    dict_1 = dict(a=dict(aa=dict(aaa=dict(aaaa=0))))
    assert repr_dict(dict_0) == repr_dict(dict_1)
    
    dict_2 = dict(a=dict(aa=dict(aaa=dict(aaaa=dict(aaaaa=0)))))
    dict_3 = dict(a=dict(aa=dict(aaa=dict(aaaa=dict(a=0)))))
    assert repr_dict(dict_2) != repr_dict(dict_3)



# Generated at 2022-06-25 19:34:42.134748
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    test_json_dict = OrderedDict([(u'fruit', u'pear'), (u'color', u'green')])
    test_json = json.dumps(test_json_dict)
    test_json_str = load_json_preserve_order(test_json)
    assert isinstance(test_json_str, OrderedDict)


# Generated at 2022-06-25 19:34:44.583184
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.jpg') == 'image/jpeg'
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('filename.unknown') is None

# Generated at 2022-06-25 19:34:55.073062
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"key1": "value1", "key2": "value2"}'
    json_str_reversed = '{"key2": "value2", "key1": "value1"}'
    
    # Load a JSON string with an order of keys
    value_1 = load_json_preserve_order(json_str)
    assert(value_1 == {"key1": "value1", "key2": "value2"})

    # Set object_pairs_hook to OrderedDict
    assert(load_json_preserve_order(json_str) == load_json_preserve_order(json_str_reversed))


# Generated at 2022-06-25 19:35:03.732199
# Unit test for function get_content_type
def test_get_content_type():
    assert (get_content_type('image.jpg') == 'image/jpeg')
    assert (get_content_type('image.png') == 'image/png')
    assert (get_content_type('image.gif') == 'image/gif')
    assert (get_content_type('image.svg') == 'image/svg+xml')
    assert (get_content_type('image.svgz') == 'image/svg+xml')
    assert (get_content_type('image.webp') == 'image/webp')
    assert (get_content_type('image') is None)
    assert (get_content_type('image.unknown') is None)
    assert (get_content_type('image.jpg.bak') == 'image/jpeg')

# Generated at 2022-06-25 19:35:13.974831
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:35:22.342230
# Unit test for function repr_dict
def test_repr_dict():
    dict_0 = None
    print(repr_dict(dict_0))

    dict_1 = OrderedDict()
    print(repr_dict(dict_1))

    dict_2 = OrderedDict([('a', 'A'), ('b', 'B'), ('c', 'C')])
    print(repr_dict(dict_2))

    dict_3 = OrderedDict([('b', 'B'), ('c', 'C'), ('a', 'A')])
    print(repr_dict(dict_3))

# Generated at 2022-06-25 19:35:24.517031
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # Test no args
    assert ExplicitNullAuth().__call__() is None


# Generated at 2022-06-25 19:35:28.772885
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order(
        '[{"a": 1, "b": 2}, '
        '{"c": 3, "d": 4}]') == [{"a": 1, "b": 2}, {"c": 3, "d": 4}]



# Generated at 2022-06-25 19:35:35.242498
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=1;expires=Wed, 01 Jan 2030 00:00:00 GMT'),
        ('Set-Cookie', 'b=2;Max-Age=0;expires=Wed, 01 Jan 2000 00:00:00'),
    ]
    now = time.time()
    expired_cookies_list = get_expired_cookies(headers, now)
    assert expired_cookies_list == [
        {
            'name': 'b',
            'path': '/',
        }
    ]

# Generated at 2022-06-25 19:35:36.679221
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    test_ExplicitNullAuth = ExplicitNullAuth()
    assert test_ExplicitNullAuth is not None



# Generated at 2022-06-25 19:35:45.302296
# Unit test for function repr_dict
def test_repr_dict():
    dict_0 = {}
    dict_1 = {
        'a': 1
    }
    dict_2 = {
        'a': 1,
        'b': {
            'c': 2
        },
        'd': OrderedDict([
            ('d', 3),
            ('e', {
                'f': 4,
                'g': OrderedDict([
                    ('h', 5),
                    ('i', 6)
                ])
            })
        ])
    }
    repr_dict(dict_0)
    repr_dict(dict_1)
    repr_dict(dict_2)

if __name__ == '__main__':
    test_case_0()
    test_repr_dict()

# Generated at 2022-06-25 19:35:47.387296
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    """test_ExplicitNullAuth()"""
    auth = ExplicitNullAuth()
    assert isinstance(auth, ExplicitNullAuth)
