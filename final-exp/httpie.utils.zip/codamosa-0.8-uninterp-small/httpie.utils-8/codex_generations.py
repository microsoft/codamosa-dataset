

# Generated at 2022-06-25 19:31:16.515560
# Unit test for function get_content_type
def test_get_content_type():
    abs_path_var_0 = 'C:\\Users\\py_Al\\AppData\\Local\\Temp\\pycharm_project_569\\tests\\requests2_tests\\data\\file_1'
    var_0 = get_content_type(abs_path_var_0)
    print(var_0)

if __name__ == '__main__':
    test_case_0()
    test_get_content_type()

# Generated at 2022-06-25 19:31:24.669174
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    """
    important key is time.time()
    """
    now = time.time()
    headers = [
        ('Set-Cookie', 'a=1; path=/'),
        ('Set-Cookie', 'b=2; path=/; max-age=50'),
        ('Set-Cookie', 'c=3; path=/; max-age=50; expires=%d' % (now + 50)),
        ('Set-Cookie', 'd=4; path=/; max-age=50; expires=%d' % (now + 1))
    ]
    res = get_expired_cookies(headers, now=now)
    assert len(res) == 2
    assert res[0] == {'name': 'd', 'path': '/'}

# Generated at 2022-06-25 19:31:26.761514
# Unit test for function get_content_type
def test_get_content_type():
    filename = "foo.jpg"
    assert get_content_type(filename) == "image/jpeg"



# Generated at 2022-06-25 19:31:32.910814
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.jpg") == "image/jpeg"
    assert get_content_type("test.html") == "text/html"
    assert get_content_type("test.pdf") == "application/pdf"
    assert get_content_type("test.jpeg") == "image/jpeg"
    assert get_content_type("test.gif") == "image/gif"
    assert get_content_type("test.txt") == "text/plain"
    assert get_content_type("test.rar") == None
    assert get_content_type("test.zip") == None
    assert get_content_type("test.exe") == None
    assert get_content_type("test.bmp") == "image/bmp"

# Generated at 2022-06-25 19:31:43.065776
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:31:49.195731
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookie_header = (
        'Set-Cookie: SESSION_ID=2_1_0_0_2_2_0_0_1_1_0_0_0_0_0_0_0_0_0_0; '
        'path=/; secure; HttpOnly'
    )
    assert get_expired_cookies([(cookie_header, '')]) == [{
        'name': 'SESSION_ID',
        'path': '/'
    }]

# Generated at 2022-06-25 19:31:59.371196
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('set-cookie', 'a=1; path=/'),
        ('set-cookie', 'b=2; path=/'),
        ('set-cookie', 'c=3; path=/; expires=Wed, 31 Jan 2100 23:59:59 GMT'),
    ]

    now = time.mktime((2099, 12, 31, 0, 0, 0, -1, -1, -1))

    actual = get_expired_cookies(headers, now=now)
    expected = [
        {'name': 'a', 'path': '/'},
        {'name': 'b', 'path': '/'},
    ]
    assert expected == actual, actual

# Generated at 2022-06-25 19:32:02.638701
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('makepkg.conf') == 'text/x-pascal'

# Generated at 2022-06-25 19:32:07.291264
# Unit test for function get_content_type
def test_get_content_type():
    file_name = '/movies/jane.mp4'
    content_type = get_content_type(file_name)
    content_type2 = mimetypes.guess_type(file_name)
    return content_type, content_type2


if __name__ == '__main__':
    print(test_get_content_type())

# Generated at 2022-06-25 19:32:19.361901
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    assert get_expired_cookies([]) == []
    assert get_expired_cookies([('a', 'b')]) == []

    assert get_expired_cookies(
        headers=[
            (
                'set-cookie',
                'foo=Bar; Domain=httpbin.org; '
                'expires=Thu, 01 Jan 1970 00:00:00 GMT;'
            )
        ],
        now=0
    ) == [{'name': 'foo', 'path': '/'}]


# Generated at 2022-06-25 19:32:29.736401
# Unit test for function get_content_type
def test_get_content_type():
    filename = 'example.py'
    assert get_content_type(filename) == 'text/x-python'

if __name__ == '__main__':

    test_case_0()
    test_get_content_type()

    print('\n' + '*' * 32 + '\n')
    print('All tests pass.')
    print('\n' + '*' * 32 + '\n')

# Copyright (c) 2016-2018 Alexander Bluhm <bluhm@genua.de>

# Generated at 2022-06-25 19:32:31.831042
# Unit test for function get_content_type
def test_get_content_type():
    filename = 'this-file-has-no-extension'
    assert get_content_type(filename) is None



# Generated at 2022-06-25 19:32:39.832345
# Unit test for function get_content_type
def test_get_content_type():
    assert 'application/octet-stream' == get_content_type('example.bin')
    assert 'text/plain' == get_content_type('example.txt')
    assert 'image/png' == get_content_type('example.png')
    assert 'image/png' == get_content_type('.png')
    assert 'application/xhtml+xml' == get_content_type('example.html')
    assert 'application/xhtml+xml' == get_content_type('example.htm')
    assert 'application/xml' == get_content_type('example.xml')
    assert 'image/svg+xml' == get_content_type('example.svg')
    assert 'image/svg+xml' == get_content_type('example.svgz')
    assert 'application/json' == get_content_

# Generated at 2022-06-25 19:32:42.556665
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('asdf.txt') == "text/plain"
    assert get_content_type('asdf.png') == "image/png"


# Generated at 2022-06-25 19:32:47.093629
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('image.png') == 'image/png'
    assert get_content_type('image.xcf') == 'image/x-xcf'
    assert get_content_type('script.sh') == 'application/x-sh'


# Generated at 2022-06-25 19:32:56.411438
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(
        filename='LICENSE'
    ) == 'text/plain; charset=us-ascii'
    assert get_content_type(
        filename='test.json'
    ) == 'application/json'
    assert get_content_type(
        filename='test.png'
    ) == 'image/png'
    assert get_content_type(
        filename='test.txt'
    ) == 'text/plain'
    assert get_content_type(
        filename='test.xml'
    ) == 'text/xml'
    assert get_content_type(
        filename='test.yml'
    ) == 'text/yaml'



# Generated at 2022-06-25 19:32:59.627193
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.json') == 'application/json'
    assert get_content_type('nonextant.ext') is None

# Generated at 2022-06-25 19:33:06.999835
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test_data/test.html') == 'text/html'
    assert get_content_type('test_data/test.json') == 'application/json'
    assert get_content_type('test_data/test.pdf') == 'application/pdf'
    assert get_content_type('test_data/test.gif') == 'image/gif'
    assert get_content_type('test_data/test.jpg') == 'image/jpeg'
    assert get_content_type('test_data/test.png') == 'image/png'
    assert get_content_type('test_data/test.txt') == 'text/plain'
    assert get_content_type('test_data/test.zip') == 'application/zip'

# Generated at 2022-06-25 19:33:08.834707
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txtx') is None

# Generated at 2022-06-25 19:33:13.133495
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('data/sample.json') == 'application/json'
    assert get_content_type('data/sample.txt') is None
    assert get_content_type('data/sample.pdf') == 'application/pdf'
    assert get_content_type('data/sample.csv') == 'text/csv'

# Generated at 2022-06-25 19:33:21.686506
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [('set-cookie', 'sessionid=12345678; Path=/; Max-Age=3600'),
               ('set-cookie', 'expires=Tue, 19 Jan 2038 03:14:07 GMT; '
                'Max-Age=2147483647; Path=/')]
    expected = [{'name': 'sessionid', 'path': '/'},
                {'name': 'expires', 'path': '/'}]
    assert get_expired_cookies(headers=headers, now=2147483648) == expected

# Generated at 2022-06-25 19:33:27.262177
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == "1 B"
    assert humanize_bytes(1024, precision=1) == "1.0 kB"
    assert humanize_bytes(1024 * 123, precision=1) == "123.0 kB"
    assert humanize_bytes(1024 * 12342, precision=1) == "12.1 MB"
    assert humanize_bytes(1024 * 12342, precision=2) == "12.05 MB"
    assert humanize_bytes(1024 * 1234, precision=2) == "1.21 MB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == "1.31 GB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == "1.3 GB"



# Generated at 2022-06-25 19:33:37.429023
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    headers = (
        ('Set-Cookie', 'foo=bar; Max-Age=30'),
        ('Set-Cookie', 'bar=baz; Expires=Tue, 21 Jan 2020 01:01:01 GMT')
    )
    assert get_expired_cookies(headers, now) == []

    now = time.time()
    headers = (
        ('Set-Cookie', 'foo=bar; Max-Age=30'),
        ('Set-Cookie', 'bar=baz; Expires=Tue, 21 Jan 2020 01:01:01 GMT')
    )
    assert get_expired_cookies(headers, now + 100) == [{'name': 'bar', 'path': '/'}]

# Generated at 2022-06-25 19:33:45.959390
# Unit test for function humanize_bytes
def test_humanize_bytes():
    test_pairs = [
        (0, '0 B'),
        (1, '1 B'),
        (1024, '1.0 kB'),
        (1024 * 123, '123.0 kB'),
        (1024 * 12342, '12.1 MB'),
        (1024 * 1234, '1.21 MB'),
        (1024 * 1234 * 1111, '1.31 GB'),
    ]
    for test_pair_0 in test_pairs:
        humanize_bytes_0 = humanize_bytes(test_pair_0[0], 2)
        assert humanize_bytes_0 == test_pair_0[1]

# Generated at 2022-06-25 19:33:46.767627
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    test_case_0()

# Generated at 2022-06-25 19:33:48.886467
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    # try to construct an ExplicitNullAuth object
    explicit_null_auth_0 = ExplicitNullAuth()
    assert isinstance(explicit_null_auth_0, ExplicitNullAuth)


# Generated at 2022-06-25 19:33:59.035364
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-25 19:34:01.284839
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    explicit_null_auth = ExplicitNullAuth()
    assert explicit_null_auth is not None


# Generated at 2022-06-25 19:34:10.725567
# Unit test for function humanize_bytes
def test_humanize_bytes():
    if humanize_bytes(1) != '1 B':
        raise Exception("humanize_bytes 1")
    if humanize_bytes(1 << 10) != '1.0 kB':
        raise Exception("humanize_bytes 1 << 10")
    if humanize_bytes(1 << 10, 1) != '1.0 kB':
        raise Exception("humanize_bytes 1 << 10, 1")
    if humanize_bytes(1 << 10 * 123, 1) != '123.0 kB':
        raise Exception("humanize_bytes 1 << 10 * 123, 1")
    if humanize_bytes(1 << 10 * 12342, 1) != '12.1 MB':
        raise Exception("humanize_bytes 1 << 10 * 12342, 1")

# Generated at 2022-06-25 19:34:16.418710
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()
    request_0 = None
    explicit_null_auth_0.__call__(request_0)
