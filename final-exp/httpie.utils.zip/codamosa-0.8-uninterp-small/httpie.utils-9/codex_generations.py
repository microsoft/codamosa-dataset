

# Generated at 2022-06-25 19:31:19.169906
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'a=1; Max-Age=2'),
        ('Set-Cookie', 'b=1; Max-Age=2'),
        ('Set-Cookie', 'c=1; Max-Age=2'),
    ]
    assert get_expired_cookies(headers=headers, now=time.time()) == []



# Generated at 2022-06-25 19:31:26.106472
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 1548028800

# Generated at 2022-06-25 19:31:27.381234
# Unit test for function get_content_type
def test_get_content_type():
    filename = 'asn1pepa.pdf'
    assert get_content_type(filename) == 'application/pdf'

# Generated at 2022-06-25 19:31:31.051227
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('filename.tar.gz') == 'application/x-gzip'
    assert get_content_type('filename.doc') == 'application/msword'
    assert get_content_type('filename.txt.gz') == 'application/x-gzip'
    assert get_content_type('filename.unknown') is None



# Generated at 2022-06-25 19:31:33.672721
# Unit test for function get_content_type
def test_get_content_type():
    assert(get_content_type('foo.txt') == 'text/plain')
    assert(get_content_type('foo.jpg') == 'image/jpeg')


# Generated at 2022-06-25 19:31:37.983492
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename='file.pdf') == 'application/pdf'
    assert get_content_type(filename='file.gif') == 'image/gif'
    assert get_content_type(filename='file.foo') is None



# Generated at 2022-06-25 19:31:42.612572
# Unit test for function get_content_type
def test_get_content_type():
    print(get_content_type('foo.jpg'))
    print(get_content_type('foo.txt'))
    print(get_content_type('foo.foo'))


if __name__ == '__main__':
    test_case_0()
    from pprint import pprint
    test_get_content_type()

# Generated at 2022-06-25 19:31:43.689291
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(__file__) == 'text/x-python'

# Generated at 2022-06-25 19:31:54.658011
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # test data
    SET_COOKIE_FIELD_0 = 'foo=bar;'
    SET_COOKIE_FIELD_1 = 'baz=qux; Max-Age=0'
    SET_COOKIE_FIELD_2 = 'quux=corge; Max-Age=3600; Path=/'
    NOW = 1580866911.8697372

    cookies = get_expired_cookies(
        headers=[
            ('Set-Cookie', SET_COOKIE_FIELD_0),
            ('Set-Cookie', SET_COOKIE_FIELD_1),
            ('Set-Cookie', SET_COOKIE_FIELD_2),
        ],
        now=NOW
    )

# Generated at 2022-06-25 19:32:02.339240
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type("test.txt") == "text/plain"
    assert get_content_type("test.png") == "image/png"
    assert get_content_type("test.jpg") == "image/jpeg"
    assert get_content_type("test.pdf") == "application/pdf"
    assert get_content_type("test.html") == "text/html"
    assert get_content_type("test.zip") == "application/zip"
    assert get_content_type("test.exe") is None
    assert get_content_type("") is None



# Generated at 2022-06-25 19:32:07.209346
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0, precision=2) == '0.00 B'


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-25 19:32:09.953858
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.yaml') == 'application/x-yaml'
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.dat') is None

# Generated at 2022-06-25 19:32:15.083416
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:32:25.859682
# Unit test for function repr_dict
def test_repr_dict():
    # Test with simple dictionary.
    d_0 = {
        None: None,
        1: True,
        'a': 'alpha',
        'b': (1, 'beta'),
        'c': ('gamma',)
    }
    r_0 = repr_dict(d_0)
    print('r_0: {}'.format(r_0))

    # Test with dictionary containing dictionary.
    d_1 = {
        'a': 'alpha',
        'b': (1, 'beta'),
        'c': {
            None: None,
            1: True,
            'a': 'alpha',
            'b': (1, 'beta'),
            'c': ('gamma',)
        }
    }
    r_1 = repr_dict(d_1)

# Generated at 2022-06-25 19:32:29.885522
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('foo.txt')
    assert content_type == 'text/plain'

    content_type = get_content_type('foo.png')
    assert content_type == 'image/png'

# Generated at 2022-06-25 19:32:33.040095
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    instance = ExplicitNullAuth()
    r = None
    # r (type: <class 'NoneType'>) is a stub
    # No args
    # No return type
    instance.__call__(r)


# Generated at 2022-06-25 19:32:34.989896
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()
    r = None
    explicit_null_auth_0.__call__(r)

# Generated at 2022-06-25 19:32:45.793226
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == "1 B"
    assert humanize_bytes(1024, precision=1) == "1.0 kB"
    assert humanize_bytes(1024 * 123, precision=1) == "123.0 kB"
    assert humanize_bytes(1024 * 12342, precision=1) == "12.1 MB"
    assert humanize_bytes(1024 * 12342, precision=2) == "12.05 MB"
    assert humanize_bytes(1024 * 1234, precision=2) == "1.21 MB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == "1.31 GB"
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == "1.3 GB"



# Generated at 2022-06-25 19:32:50.422427
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()
    r_0 = None  # type: http.client.HTTPMessage
    explicit_null_auth_0.__call__(r_0)

# Generated at 2022-06-25 19:32:53.099101
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('tmp.txt')
    assert content_type == 'text/plain'



# Generated at 2022-06-25 19:33:05.989783
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


# Generated at 2022-06-25 19:33:15.877690
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(10240) == '10.0 kB'
    assert humanize_bytes(1_000_000) == '976.56 kB'
    assert humanize_bytes(1_000_000, precision=3) == '976.563 kB'
    assert humanize_bytes(1.5 * 1 << 30) == '1.50 GB'
    assert humanize_bytes(4 * 1 << 40) == '4.00 TB'
    assert humanize_bytes(1.3 * 1 << 50) == '1.27 PB'
    assert humanize_bytes(1.3 * 1 << 50, precision=3) == '1.265 PB'

# Generated at 2022-06-25 19:33:20.476435
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():

    json_string = """{"key1" : "value1", "key2" : "value2"}"""

    expected_string = """OrderedDict([(\'key1\', \'value1\'), (\'key2\', \'value2\')])"""

    assert repr_dict(load_json_preserve_order(json_string)) == expected_string

# Generated at 2022-06-25 19:33:24.394632
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    import json

    s = '{"a": "b", "c": "d"}'
    assert load_json_preserve_order(s) == json.loads(s, object_pairs_hook=OrderedDict)
    assert load_json_preserve_order(s) == {'a': 'b', 'c': 'd'}



# Generated at 2022-06-25 19:33:35.565579
# Unit test for function repr_dict
def test_repr_dict():
    # is it a function?
    assert callable(repr_dict)

    # does it work for a regular dict?
    d = {
        'a': 'aa',
        'b': 'bb',
        'c': 'cc',
    }
    rd = repr_dict(d)
    assert rd == (
        "{\n"
        "    'a': 'aa',\n"
        "    'b': 'bb',\n"
        "    'c': 'cc',\n"
        "}")

    # does it work for an ordered dict?
    od = OrderedDict(a='aa', b='bb', c='cc')
    rod = repr_dict(od)

# Generated at 2022-06-25 19:33:46.301259
# Unit test for function humanize_bytes

# Generated at 2022-06-25 19:33:49.226079
# Unit test for function repr_dict
def test_repr_dict():
    d = OrderedDict(a=1, b=2, c=[4, 5, 6], d=[7, 8, 9])
    assert repr_dict(d) == pformat(d)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 19:33:51.355748
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'

# Generated at 2022-06-25 19:33:53.293975
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict({'x': 123, 'y': 234}) == "{'x': 123, 'y': 234}"

# Generated at 2022-06-25 19:33:56.733151
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    my_json = {'a': 2, 'b': 3}
    assert repr_dict(load_json_preserve_order(json.dumps(my_json))) == repr_dict(my_json)


# Generated at 2022-06-25 19:34:09.800529
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    print('Function: test_get_expired_cookies')
    now = time.time()
    start_time = now
    end_time = now + 3600*24
    headers = []
    headers.append(('Set-Cookie', 'name=value; path=/; max-age=3600;'))
    headers.append(('Set-Cookie', 'name=value; path=/; expires=' + time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime(end_time))))
    expired_cookies = get_expired_cookies(headers, now=start_time)
    if expired_cookies[0]['name'] == 'name' and expired_cookies[0]['path'] == '/':
        print('PASSED')

# Generated at 2022-06-25 19:34:16.695107
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(10) == '10 B'
    assert humanize_bytes(100) == '100 B'
    assert humanize_bytes(1000) == '1000 B'
    assert humanize_bytes(10000) == '9.77 kB'
    assert humanize_bytes(100000) == '97.7 kB'
    assert humanize_bytes(1000000) == '977 kB'
    assert humanize_bytes(10000000) == '9.54 MB'
    assert humanize_bytes(100000000) == '95.37 MB'
    assert humanize_bytes(1000000000) == '953.67 MB'
    assert humanize_bytes(10000000000) == '9.31 GB'

# Generated at 2022-06-25 19:34:24.693690
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    print("Test cases for function: load_json_preserve_order")
    print("    Case 0")
    print("        Input")
    print("            s:")
    s = '{"foo": "bar", "bar": "baz", "baz": "qux"}'
    print(s)
    print("        Output")
    ret = load_json_preserve_order(s)
    print(repr(ret))
    print("    Case 1")
    print("        Input")
    print("            s:")
    s = '{"bar": "baz", "baz": "qux", "foo": "bar"}'
    print(s)
    print("        Output")
    ret = load_json_preserve_order(s)
    print(repr(ret))


# Generated at 2022-06-25 19:34:34.739162
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('file.txt') == 'text/plain'
    assert get_content_type('file.html') == 'text/html'
    assert get_content_type('file.css') == 'text/css'
    assert get_content_type('file.js') == 'text/javascript'
    assert get_content_type('file.py') == 'text/x-python'
    assert get_content_type('file.jpg') == 'image/jpeg'
    assert get_content_type('file.png') == 'image/png'
    assert get_content_type('file.svg') == 'image/svg+xml'
    assert get_content_type('file.bmp') == 'image/bmp'

# Generated at 2022-06-25 19:34:43.418579
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.0 kB'
    assert humanize_bytes(1024 * 1.23) == '1.23 kB'
    assert humanize_bytes(1024 * 1024) == '1.0 MB'
    assert humanize_bytes(1024 * 1024 * 1.23) == '1.23 MB'
    assert humanize_bytes(1024 * 1024 * 1024) == '1.0 GB'
    assert humanize_bytes(1024 * 1024 * 1024 * 1.23) == '1.23 GB'
    assert humanize_bytes(1024 * 1024 * 1024 * 1024) == '1.0 TB'

# Generated at 2022-06-25 19:34:53.286173
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-25 19:35:02.131657
# Unit test for function humanize_bytes
def test_humanize_bytes():
    print (humanize_bytes(1))
    print (humanize_bytes(1024, precision=1))
    print (humanize_bytes(1024 * 123, precision=1))
    print (humanize_bytes(1024 * 12342, precision=1))
    print (humanize_bytes(1024 * 12342, precision=2))
    print (humanize_bytes(1024 * 1234, precision=2))
    print (humanize_bytes(1024 * 1234 * 1111, precision=2))
    print (humanize_bytes(1024 * 1234 * 1111, precision=1))



# Generated at 2022-06-25 19:35:05.774937
# Unit test for function repr_dict
def test_repr_dict():
    d1 = {'a': 1, 'b': 2, 'c': 3}
    assert repr_dict(d1) == "{'a': 1, 'b': 2, 'c': 3}"

# Generated at 2022-06-25 19:35:14.756396
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    assert get_expired_cookies(
        headers=[('cookie', 'foo=bar; max-age=1')],
        now=2,
    ) == [{'name': 'foo', 'path': '/'}]

    assert get_expired_cookies(
        headers=[('cookie', 'foo=bar; max-age=1')],
        now=0,
    ) == []

    assert get_expired_cookies(
        headers=[('cookie', 'foo=bar; max-age=30; path=/')],
        now=60,
    ) == [{'name': 'foo', 'path': '/'}]

    assert get_expired_cookies(
        headers=[('cookie', 'foo=bar; max-age=30; path=/')],
        now=15,
    ) == []

# Generated at 2022-06-25 19:35:15.858886
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    test_case_0()


# Generated at 2022-06-25 19:35:28.186804
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    explicit_null_auth_0 = ExplicitNullAuth()
    assert explicit_null_auth_0 is not None
    assert isinstance(explicit_null_auth_0, ExplicitNullAuth)


# Generated at 2022-06-25 19:35:28.926952
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert ExplicitNullAuth()


# Generated at 2022-06-25 19:35:30.078013
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()



# Generated at 2022-06-25 19:35:38.460844
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    """
    Test case:

    For more information, see RFC 6265.

    """

    # no cookie at all
    headers = []
    assert [] == get_expired_cookies(headers=headers)

    # cookie that is not expired
    now = 0.0
    headers = [
        ('Set-Cookie', 'foo=bar; Max-Age=1'),
        ('Set-Cookie', 'foo2=bar2; Max-Age=1'),
    ]
    assert [] == get_expired_cookies(headers=headers, now=now)

    # cookie that is expired
    now = 2.0
    headers = [
        ('Set-Cookie', 'foo=bar; Max-Age=1'),
        ('Set-Cookie', 'foo2=bar2; Max-Age=1'),
    ]

# Generated at 2022-06-25 19:35:39.507296
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    test_case_0()


# Generated at 2022-06-25 19:35:42.981128
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()
    request_0 = requests.Request('GET', 'http://www.example.com/')
    request_0 = explicit_null_auth_0.__call__(request_0)


# Generated at 2022-06-25 19:35:51.578891
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()

###
assert humanize_bytes(1023) == '1023 B'
assert humanize_bytes(1024) == '1.0 kB'
assert humanize_bytes(1024 * 1024) == '1.0 MB'
assert humanize_bytes(1024 * 1024 * 1024) == '1.0 GB'
assert humanize_bytes(1024 * 1024 * 1024 * 1024) == '1.0 TB'
###

###
assert humanize_bytes(1023, 0) == '1023 B'
assert humanize_bytes(1024, 0) == '1 kB'
assert humanize_bytes(1024 * 1024, 0) == '1 MB'
assert humanize_bytes(1024 * 1024 * 1024, 0) == '1 GB'

# Generated at 2022-06-25 19:35:53.069346
# Unit test for function humanize_bytes
def test_humanize_bytes():
    test_0 = humanize_bytes(1024000, precision=1)
    assert test_0 == "1000.0 kB"


# Generated at 2022-06-25 19:35:56.619732
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(OrderedDict([
        ('a', 1),
        ('b', OrderedDict([
            ('c', 2),
            ('d', 3),
        ])),
    ])) == 'OrderedDict([(\'a\', 1), (\'b\', OrderedDict([(\'c\', 2), (\'d\', 3)]))])'

if __name__ == '__main__':
    test_case_0()
    test_repr_dict()

# Generated at 2022-06-25 19:36:02.289361
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(dict(
        a=dict(b=1),
        c=2,
    )) == "{\n    'a': {\n        'b': 1\n    },\n    'c': 2\n}"

# Generated at 2022-06-25 19:36:26.765232
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:36:28.852499
# Unit test for function repr_dict
def test_repr_dict():
    d = dict(a=1, b=2)
    s = repr_dict(d)
    print(s)
    assert s == "{'a': 1, 'b': 2}"
    return s


# Generated at 2022-06-25 19:36:29.512993
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()


# Generated at 2022-06-25 19:36:32.271448
# Unit test for function repr_dict
def test_repr_dict():
    assert repr_dict(OrderedDict(foo='bar', status='a')) == 'OrderedDict([(\'foo\', \'bar\'), (\'status\', \'a\')])'
    assert repr_dict(dict(foo='bar', status='a')) == "{\'foo\': \'bar\', \'status\': \'a\'}"


# Generated at 2022-06-25 19:36:37.129314
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '[{"a": 5, "b": 6}, {"b": 4, "a": 7}]'
    dict_list = [{"a": 5, "b": 6}, {"a": 7, "b": 4}]

    result = load_json_preserve_order(json_string)
    assert result == dict_list


# Generated at 2022-06-25 19:36:44.123125
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'

# Generated at 2022-06-25 19:36:48.541160
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    explicit_null_auth_1 = ExplicitNullAuth()


# Generated at 2022-06-25 19:36:58.452069
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # These values I have obtained from debugging a session that
    # the requests library makes for a real web service.
    now = 1510159244.497627
    max_age_header_0 = (
        'max-age=86400; expires=Sat, 02-Dec-2017 18:01:10 GMT; HttpOnly; '
        'Secure'
    )
    max_age_header_1 = (
        'max-age=315360000; expires=Wed, 30-Nov-2027 18:01:10 GMT; '
        'HttpOnly; Secure'
    )
    sessionid_header_0 = 'SessionId=Rt9X1tbFs1ybd_p_bYYC; HttpOnly; Path=/'

# Generated at 2022-06-25 19:37:03.890980
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()
    request_0 = None
    try:
        explicit_null_auth_0.__call__(request_0)

    except TypeError as e:
        error_message_0 = e.args[0]
        assert error_message_0 == 'request must not be None'



# Generated at 2022-06-25 19:37:05.880953
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert hasattr(ExplicitNullAuth, '__init__')
    assert False


# Generated at 2022-06-25 19:37:25.333944
# Unit test for function repr_dict
def test_repr_dict():
    try:
        assert repr_dict({'a': 'b', 'foo': 'bar'}) == "OrderedDict([('a', 'b'), ('foo', 'bar')])"
    except:
        assert repr_dict({'a': 'b', 'foo': 'bar'}) == "{'a': 'b', 'foo': 'bar'}"



# Generated at 2022-06-25 19:37:29.611697
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('filename.txt') == 'text/plain'
    assert get_content_type('filename.jpg') == 'image/jpeg'
    assert get_content_type('filename.JPG') == 'image/jpeg'



# Generated at 2022-06-25 19:37:31.955078
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    arg0 = ExplicitNullAuth()
    arg1 = None
    actual = arg0.__call__(arg1)
    assert actual is None


# Generated at 2022-06-25 19:37:39.481545
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    cookiejar = requests.cookies.RequestsCookieJar()

    # HACK: If there's no cookie in the cookie jar, cookiejar.make__cookie
    # will raise KeyError
    cookiejar.set('COOKIE-NAME', 'COOKIE-VALUE')

    for scheme in ('http://', 'https://'):
        for key in cookiejar:
            for value in cookiejar[key]:
                cookie = cookiejar.make_cookies(
                    f'{scheme}{key}={value}',
                    response_url=f'{scheme}test.example.com',
                )
                assert len(cookie) == 1

    # CookieJar.make_cookies wants a string
    assert type(f'{scheme}{key}={value}') is str

    # CookieJar.make_cookies wants a string, but

# Generated at 2022-06-25 19:37:41.975741
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    req0 = requests.Request(method='GET', url='https://www.python.org/')
    actual = explicit_null_auth_0(req0)
    assert actual == req0


# Generated at 2022-06-25 19:37:49.548449
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"key_x": "hello"}') == {'key_x': 'hello'}
    assert load_json_preserve_order('{"key_x": "hello", "key_y": 5}') == {'key_x': 'hello',
                                                                          'key_y': 5}
    assert load_json_preserve_order('{"key_x": "hello", "key_y": 5, "key_z": true}') == {'key_x': 'hello', 'key_y': 5,
                                                                                          'key_z': True}



# Generated at 2022-06-25 19:37:58.485421
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # case 1
    headers = [('Set-Cookie', 'a=b')]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)
    assert len(expired_cookies) == 0

    # case 2
    headers = [('Set-Cookie', 'a=b;Max-Age=0')]
    now = time.time()
    expired_cookies = get_expired_cookies(headers, now=now)
    assert len(expired_cookies) == 1
    assert expired_cookies[0]['name'] == 'a'
    assert expired_cookies[0]['path'] == '/'

    # case 3
    headers = [('Set-Cookie', 'a=b;Max-Age=0')]
    now = 0

# Generated at 2022-06-25 19:37:59.950683
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert load_json_preserve_order('{"a": 1}') == {"a": 1}


# Generated at 2022-06-25 19:38:02.154498
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_str = '{"foo": "bar", "baz": "qux"}'
    json_obj = load_json_preserve_order(json_str)
    assert list(json_obj.keys()) == ['foo', 'baz']

# Generated at 2022-06-25 19:38:06.946772
# Unit test for function humanize_bytes
def test_humanize_bytes():
    s = humanize_bytes(1)
    assert s == '1 B'

    s = humanize_bytes(1024, precision=1)
    assert s == '1.0 kB'

    s = humanize_bytes(1024 * 123, precision=1)
    assert s == '123.0 kB'

    s = humanize_bytes(1024 * 12342, precision=1)
    assert s == '12.1 MB'

    s = humanize_bytes(1024 * 12342, precision=2)
    assert s == '12.05 MB'

    s = humanize_bytes(1024 * 1234, precision=2)
    assert s == '1.21 MB'

    s = humanize_bytes(1024 * 1234 * 1111, precision=2)
    assert s == '1.31 GB'

    s = human

# Generated at 2022-06-25 19:38:39.817743
# Unit test for constructor of class ExplicitNullAuth
def test_ExplicitNullAuth():
    assert not ExplicitNullAuth.__dict__['__init__'].__defaults__
    assert ExplicitNullAuth.__dict__['__init__'].__code__.co_argcount == 2
    assert ExplicitNullAuth.__dict__['__init__'].__code__.co_varnames == ('self', 'host')


# Generated at 2022-06-25 19:38:40.772444
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.txt') == 'text/plain'

# Generated at 2022-06-25 19:38:46.142640
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    json_string = '{"bar": 1, "foo": 2}'
    result = load_json_preserve_order(json_string)
    if result != {'bar': 1, 'foo': 2}:
        raise AssertionError()



# Generated at 2022-06-25 19:38:50.965202
# Unit test for function repr_dict
def test_repr_dict():
    assert ('{}' == repr_dict({}))
    assert ('{}' == repr_dict(OrderedDict()))
    assert ('{}' == repr_dict({'key': 'value'}))
    assert ('{}' == repr_dict(OrderedDict(key='value')))
    assert ('{}' == repr_dict(key='value'))


# Generated at 2022-06-25 19:38:55.029323
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(0) == '0 B'
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024 * 123) == '123.00 kB'
    assert humanize_bytes(1024 * 12342) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=1) == '1.2 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-25 19:38:57.684763
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    # ExplicitNullAuth.__call__()
    init_arg_types = []
    init_args = []
    # Function returns instance of class requests.auth.AuthBase
    return_type = requests.auth.AuthBase
    init_arg_values = []
    return_value = ExplicitNullAuth()
    assert isinstance(return_value, return_type)


# Generated at 2022-06-25 19:39:00.231944
# Unit test for function repr_dict
def test_repr_dict():
    d = {'a': 'b'}
    assert repr_dict(d) == "{'a': 'b'}"



# Generated at 2022-06-25 19:39:05.902147
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    a_bit_ago = now - 3600

# Generated at 2022-06-25 19:39:08.739702
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    try:
        assert False
        assert False
    except AssertionError:
        print('unit test failure: test_ExplicitNullAuth___call__')
        # raise


# Generated at 2022-06-25 19:39:15.884588
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    assert (
        load_json_preserve_order("{\"foo\": 1, \"bar\": 2}")
        == OrderedDict([("foo", 1), ("bar", 2)])
    )
    assert (
        load_json_preserve_order("{\"foo\": 1, \"bar\": 2}", )
        == OrderedDict([("foo", 1), ("bar", 2)])
    )
    assert load_json_preserve_order("{\"foo\": 1, \"bar\": 2}", ) == \
        OrderedDict([("foo", 1), ("bar", 2)])
    # assert load_json_preserve_order("{\"foo\": 1, \"bar\": 2}", ) == \
    #    OrderedDict([("foo", 1), ("bar", 2)])
    # assert load_json_

# Generated at 2022-06-25 19:39:47.760737
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(100) == '100 B'
    assert humanize_bytes(1024) == '1.00 kB'
    assert humanize_bytes(1024*123) == '123.00 kB'
    assert humanize_bytes(1024*12342) == '12.05 MB'
    assert humanize_bytes(1024*1234*1111,precision=2) == '1.31 GB'
    assert humanize_bytes(1024*1234*1111,precision=1) == '1.3 GB'


# Generated at 2022-06-25 19:39:53.956268
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:39:55.046333
# Unit test for function get_content_type
def test_get_content_type():
    str_0 = 'asn1pepa.pdf'
    assert get_content_type(str_0) == 'application/pdf'



# Generated at 2022-06-25 19:39:56.359295
# Unit test for function load_json_preserve_order
def test_load_json_preserve_order():
    str_0 = '{"foo":"bar"}'
    dict_0 = load_json_preserve_order(str_0)
    assert dict_0 == {'foo': 'bar'}


# Generated at 2022-06-25 19:39:57.435722
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    obj_0 = ExplicitNullAuth()
    var_0 = repr(obj_0)
    repr(obj_0)


# Generated at 2022-06-25 19:40:02.838233
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1, precision=1) == '1.0 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'

# Generated at 2022-06-25 19:40:04.540083
# Unit test for function repr_dict
def test_repr_dict():
    d_0 = {'color': 'green', 'fruit': 'apple', 'name': 'john'}
    str_0 = repr_dict(d_0)

# Generated at 2022-06-25 19:40:09.105859
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # Representation of 1.0mb in bytes
    int_0 = 1048576
    var_0 = humanize_bytes(int_0)
    assert var_0 == '1.00 MB'
    # Representation of 1.0mb in bytes with different precision
    var_1 = humanize_bytes(int_0, precision=1)
    assert var_1 == '1.0 MB'
    # Representation of 1.0mb in bytes with different precision
    var_2 = humanize_bytes(int_0, precision=2)
    assert var_2 == '1.00 MB'



# Generated at 2022-06-25 19:40:10.133632
# Unit test for function get_content_type
def test_get_content_type():
    test_case_0()

if __name__ == '__main__':
    test_get_content_type()

# Generated at 2022-06-25 19:40:17.675351
# Unit test for function get_expired_cookies