

# Generated at 2022-06-25 19:31:16.349723
# Unit test for function get_content_type
def test_get_content_type():
    content_type = get_content_type('dummy.txt')
    assert content_type == 'text/plain'



# Generated at 2022-06-25 19:31:18.569618
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('') is None
    assert get_content_type('foo.png') == 'image/png'

# Generated at 2022-06-25 19:31:23.570533
# Unit test for function get_content_type
def test_get_content_type():
    assert 'text/html' == get_content_type('index.html')
    assert 'text/html' == get_content_type('foo/index.html')
    assert 'text/plain' == get_content_type('foo/index.txt')
    assert 'image/jpeg' == get_content_type('bar.jpeg')
    assert 'image/jpeg' == get_content_type('foo/bar.jpeg')
    assert None is get_content_type('foo/bar')

# Generated at 2022-06-25 19:31:31.201846
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:31:33.113081
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('text.txt') == 'text/plain'


# Generated at 2022-06-25 19:31:43.286879
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:31:53.991883
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:32:02.692089
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    plus_10_sec = now + 10
    plus_11_sec = now + 11

# Generated at 2022-06-25 19:32:08.021411
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.html') == 'text/html'
    assert get_content_type('a.html') == 'text/html'


# Generated at 2022-06-25 19:32:13.283251
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.pcap') == 'application/vnd.tcpdump.pcap'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.foo') is None



# Generated at 2022-06-25 19:32:24.670260
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    # empty input
    assert get_expired_cookies([]) == []

    # no-path cookies
    assert get_expired_cookies([
        ('Set-Cookie', 'bar=baz; Expires=Wed, 09 Jun 2021 10:18:14 GMT;'),
    ]) == [{
        'name': 'bar',
        'path': '/'
    }]

    # DELETE cookie
    assert get_expired_cookies([
        ('Set-Cookie', 'bar=; Expires=Wed, 09 Jun 2021 10:18:14 GMT;'),
    ]) == [{
        'name': 'bar',
        'path': '/'
    }]

    # with path

# Generated at 2022-06-25 19:32:35.903783
# Unit test for function get_expired_cookies

# Generated at 2022-06-25 19:32:41.822439
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename='requirements.txt') == 'text/plain'
    assert get_content_type(filename='requirements.py') is None
    assert get_content_type(filename='does-not-exist.x') is None
    assert get_content_type(filename='') is None

# Generated at 2022-06-25 19:32:49.306798
# Unit test for function get_content_type
def test_get_content_type():
    def test_get_content_type_0():
        content_type = get_content_type('teapot.txt')
        assert content_type == 'text/plain'

    def test_get_content_type_1():
        content_type = get_content_type('teapot.html')
        assert content_type == 'text/html'

    def test_get_content_type_2():
        content_type = get_content_type('teapot.css')
        assert content_type == 'text/css'

    def test_get_content_type_3():
        content_type = get_content_type('teapot.png')
        assert content_type == 'image/png'


# Generated at 2022-06-25 19:32:57.547743
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('test.txt') == 'text/plain'
    assert get_content_type('test.bin') == 'application/octet-stream'
    assert get_content_type('test.m4a') == 'audio/mp4'
    assert get_content_type('test.jpg') == 'image/jpeg'
    assert get_content_type('test.html') == 'text/html'
    assert get_content_type('test.html.gz') == 'text/html; charset=gzip'
    assert get_content_type('test.html.bz2') == 'text/html; charset=bzip2'
    assert get_content_type('test.dmg') == 'application/x-apple-diskimage'



# Generated at 2022-06-25 19:33:05.325275
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    headers = [
        ('Set-Cookie', 'CookieName=CookieValue; path=/'),
        ('Set-Cookie', 'CookieNameExpires=CookieValue; path=/; Expires=Sat, 28-Nov-2015 00:15:26 GMT'),
        ('Set-Cookie', 'CookieNameMaxAge=CookieValue; path=/; Max-Age=1234'),
    ]
    expired = get_expired_cookies(headers=headers, now=time.time())
    assert len(expired) == 1
    assert expired[0]['path'] == '/'
    assert expired[0]['name'] == 'CookieNameExpires'

# Generated at 2022-06-25 19:33:09.012814
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type(filename='example-0.py') == 'text/x-python'
    assert get_content_type(filename='example-0.py.txt') == 'text/plain; charset=utf-8'
    assert get_content_type(filename='example-0') is None

# Generated at 2022-06-25 19:33:18.350916
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = 0
    resp = {'headers':
                [('Set-Cookie', 'cookie1=value1; Path=/; Domain=example.com; '
                                'Expires=Wed, 13-Jan-2021 22:23:01 GMT; '
                                'Secure; HttpOnly'),
                 ('Set-Cookie', 'cookie2=value2; Path=/; Domain=example.com; '
                                'Max-Age=3600'),
                 ('Content-Type', 'text/html; charset=utf8')]}
    expected_result = [{'name': 'cookie1', 'path': '/'}]
    cookies = get_expired_cookies(resp.get('headers'), now=now)
    assert cookies == expected_result


# Generated at 2022-06-25 19:33:25.984254
# Unit test for function get_expired_cookies
def test_get_expired_cookies():

    import datetime
    from functools import partial

    from hypothesis import given
    from hypothesis.strategies import sampled_from, builds, timedeltas

    ############################################################################
    # Act
    ############################################################################

    utcnow = partial(datetime.datetime.utcnow)


# Generated at 2022-06-25 19:33:29.928273
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    cookies = get_expired_cookies([('Set-Cookie', 'foo=bar; max-age=3600; HttpOnly'), ('Set-Cookie', 'spam=egg; max-age=60; HttpOnly')])
    assert cookies[0]['name'] == 'foo'

# Generated at 2022-06-25 19:33:42.644836
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'



# Generated at 2022-06-25 19:33:46.839943
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('foo.html') == 'text/html'
    assert get_content_type('foo.txt') == 'text/plain'
    assert get_content_type('foo.txt', strict=True) == 'text/plain'
    assert get_content_type('foo.txt', strict=False) == 'text/html'



# Generated at 2022-06-25 19:33:53.829978
# Unit test for function repr_dict
def test_repr_dict():
    import json

    # Acceptance case
    assert repr_dict({'a': 'b'}) == json.dumps({'a': 'b'})

    # Acceptance case
    assert repr_dict({'a': {'b': 'c'}}) == json.dumps({'a': {'b': 'c'}})

    # Acceptance case
    assert repr_dict({'a': 1}) == json.dumps({'a': 1})



# Generated at 2022-06-25 19:34:03.947172
# Unit test for function get_content_type
def test_get_content_type():
    content_type_0 = get_content_type('README.md')
    content_type_1 = get_content_type('README.md~')
    content_type_2 = get_content_type('revisions/README.md')
    content_type_3 = get_content_type('not-a-file.xyz')
    content_type_4 = get_content_type('README.md.gz')
    content_type_5 = get_content_type('README.html')
    assert None == content_type_3
    assert None == content_type_2
    assert 'text/plain' == content_type_0
    assert 'text/plain' == content_type_1
    assert 'application/x-gzip' == content_type_4
    assert 'text/html' == content_

# Generated at 2022-06-25 19:34:09.137661
# Unit test for function get_content_type
def test_get_content_type():
    assert get_content_type('/path/to/foo.txt') == 'text/plain'
    assert get_content_type('/path/to/foo.txt.md') == 'text/plain; charset=utf-8'  # noqa: E501
    assert get_content_type('./foo.txt') == 'text/plain'
    assert get_content_type('foo.txt') == 'text/plain'



# Generated at 2022-06-25 19:34:20.436791
# Unit test for function get_expired_cookies
def test_get_expired_cookies():
    now = time.time()
    now_expires = now + 3600e3
    later_expires = now_expires + 3600e3
    headers = [
        ('Set-Cookie', 'expires=%s; expires=%s' % (now_expires, later_expires)),
        ('Set-Cookie', 'no_expires=no_expires'),
        ('Set-Cookie', 'max_age=3600e3; max-age=3600e3'),
        ('Set-Cookie', 'no_max_age=no_max_age'),
    ]
    assert get_expired_cookies(headers, now=now) == [
        {'name': 'expires', 'path': '/'},
        {'name': 'max_age', 'path': '/'},
    ]



# Generated at 2022-06-25 19:34:22.677490
# Unit test for method __call__ of class ExplicitNullAuth
def test_ExplicitNullAuth___call__():
    explicit_null_auth_0 = ExplicitNullAuth()
    r_0 = None
    explicit_null_auth_0.__call__(r_0)



# Generated at 2022-06-25 19:34:30.232473
# Unit test for function humanize_bytes
def test_humanize_bytes():
    assert humanize_bytes(1) == '1 B'
    assert humanize_bytes(1024, precision=1) == '1.0 kB'
    assert humanize_bytes(1024 * 123, precision=1) == '123.0 kB'
    assert humanize_bytes(1024 * 12342, precision=1) == '12.1 MB'
    assert humanize_bytes(1024 * 12342, precision=2) == '12.05 MB'
    assert humanize_bytes(1024 * 1234, precision=2) == '1.21 MB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=2) == '1.31 GB'
    assert humanize_bytes(1024 * 1234 * 1111, precision=1) == '1.3 GB'


# Generated at 2022-06-25 19:34:39.464795
# Unit test for function humanize_bytes
def test_humanize_bytes():
    humanize_bytes(1)
    humanize_bytes(1024, precision=1)
    humanize_bytes(1024 * 123, precision=1)
    humanize_bytes(1024 * 12342, precision=1)
    humanize_bytes(1024 * 12342, precision=2)
    humanize_bytes(1024 * 1234, precision=2)
    humanize_bytes(1024 * 1234 * 1111, precision=2)
    humanize_bytes(1024 * 1234 * 1111, precision=1)
    return True


if __name__ == '__main__':
    test_case_0()
    test_humanize_bytes()

# Generated at 2022-06-25 19:34:45.826802
# Unit test for function humanize_bytes
def test_humanize_bytes():
    # These are just some sample test cases.
    # Note that because of the randomness, it's unrealistic to test for the
    # exact string value for the output. We only check for the general format
    # of the output, with some expected values.
    import random
    for i in range(100):
        size = random.randint(0, 10000)
        assert humanize_bytes(size) == '{} B'.format(size)

        size = random.randint(10000, 1000000)
        assert humanize_bytes(size, 1) == '{:.1f} kB'.format(size/1024)

        size = random.randint(10000, 1000000)
        assert humanize_bytes(size, 2) == '{:.2f} kB'.format(size/1024)
