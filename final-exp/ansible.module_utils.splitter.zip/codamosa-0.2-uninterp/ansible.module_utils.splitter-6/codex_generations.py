

# Generated at 2022-06-17 03:39:41.862018
# Unit test for function split_args

# Generated at 2022-06-17 03:39:50.093335
# Unit test for function split_args
def test_split_args():
    # test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    # test case with escaped quotes
    assert split_args('a=b c="foo\"bar"') == ['a=b', 'c="foo\"bar"']
    # test case with escaped backslash
    assert split_args('a=b c="foo\\\\bar"') == ['a=b', 'c="foo\\\\bar"']
    # test case with escaped backslash and escaped quotes
    assert split_args('a=b c="foo\\\\"bar"') == ['a=b', 'c="foo\\\\"bar"']
    # test case with escaped backslash and escaped quotes

# Generated at 2022-06-17 03:40:00.222564
# Unit test for function split_args
def test_split_args():
    # Test simple case
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test case with line continuation
    args = 'a=b \\\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test case with line continuation and newline
    args = 'a=b \\\n\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test case with line continuation and newline
    args = 'a=b \\\n\nc="foo bar"'
    params = split_args(args)

# Generated at 2022-06-17 03:40:11.965587
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-17 03:40:23.324796
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=""') == ['a=b', 'c="foo bar"', 'd=""'], split_args('a=b c="foo bar" d=""')
    assert split_args('a=b c="foo bar" d="\\"foo bar\\""') == ['a=b', 'c="foo bar"', 'd="\\"foo bar\\""']

# Generated at 2022-06-17 03:40:31.920983
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=""') == ['a=b', 'c="foo bar"', 'd=""']
    assert split_args('a=b c="foo bar" d="\\"foo bar\\""') == ['a=b', 'c="foo bar"', 'd="\\"foo bar\\""']

# Generated at 2022-06-17 03:40:38.273372
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('foo')


# Generated at 2022-06-17 03:40:49.875938
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for function split_args
    '''
    # Test 1: simple case
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: simple case with newlines
    args = 'a=b\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar"']

    # Test 3: simple case with newlines and line continuation
    args = 'a=b\nc="foo bar" \\'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar" \\']

    # Test 4: simple case with newlines and line continuation with more args

# Generated at 2022-06-17 03:40:56.977902
# Unit test for function split_args

# Generated at 2022-06-17 03:41:07.569060
# Unit test for function split_args

# Generated at 2022-06-17 03:41:34.644407
# Unit test for function split_args
def test_split_args():
    # Test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test case with escaped quotes
    assert split_args('a=b c="foo \"bar\""') == ['a=b', 'c="foo \"bar\""']

    # Test case with escaped backslash
    assert split_args('a=b c="foo \\\\bar"') == ['a=b', 'c="foo \\\\bar"']

    # Test case with escaped backslash and quotes
    assert split_args('a=b c="foo \\\"bar\\""') == ['a=b', 'c="foo \\\"bar\\""']

    # Test case with escaped backslash and quotes and newline

# Generated at 2022-06-17 03:41:39.937547
# Unit test for function split_args

# Generated at 2022-06-17 03:41:49.630810
# Unit test for function split_args

# Generated at 2022-06-17 03:42:00.971594
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\"") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']

# Generated at 2022-06-17 03:42:12.092824
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\"") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\" f='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]

# Generated at 2022-06-17 03:42:20.092645
# Unit test for function split_args
def test_split_args():
    # Test 1:
    # Test simple case with no quotes or jinja2 blocks
    args = "a=b c=d"
    params = split_args(args)
    assert params == ['a=b', 'c=d']

    # Test 2:
    # Test simple case with no quotes or jinja2 blocks, with spaces
    args = "a=b c=d "
    params = split_args(args)
    assert params == ['a=b', 'c=d']

    # Test 3:
    # Test simple case with no quotes or jinja2 blocks, with newlines
    args = "a=b\nc=d"
    params = split_args(args)
    assert params == ['a=b\n', 'c=d']

    # Test 4:
    # Test simple case with no quotes or

# Generated at 2022-06-17 03:42:31.295683
# Unit test for function split_args
def test_split_args():
    # Test with a simple string
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test with a string containing a newline
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']

    # Test with a string containing a backslash
    assert split_args('a=b c="foo\\bar"') == ['a=b', 'c="foo\\bar"']

    # Test with a string containing a backslash and a newline
    assert split_args('a=b c="foo\\\nbar"') == ['a=b', 'c="foo\\\nbar"']

    # Test with a string containing a backslash, a newline and a space
    assert split_args

# Generated at 2022-06-17 03:42:43.175229
# Unit test for function split_args
def test_split_args():
    # Test 1: simple case
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: simple case with newlines
    args = 'a=b\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar"']

    # Test 3: simple case with newlines and line continuation
    args = 'a=b\nc="foo bar" \\\nd=e'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar" \\\n', 'd=e']

    # Test 4: simple case with newlines and line continuation

# Generated at 2022-06-17 03:42:53.211689
# Unit test for function split_args
def test_split_args():
    '''
    This test function is used to test the split_args function.
    '''
    # Test 1: Test a simple string
    test_string = "Hello World"
    result = split_args(test_string)
    assert result == ['Hello', 'World']

    # Test 2: Test a string with quotes
    test_string = 'Hello "World"'
    result = split_args(test_string)
    assert result == ['Hello', '"World"']

    # Test 3: Test a string with quotes and spaces
    test_string = 'Hello "World" how are you?'
    result = split_args(test_string)
    assert result == ['Hello', '"World"', 'how', 'are', 'you?']

    # Test 4: Test a string with quotes and spaces

# Generated at 2022-06-17 03:43:00.214235
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d=\"foo bar\"") == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args("a=b c=\"foo bar\" d=\"foo bar\" e=\"foo bar\"") == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']
    assert split_args("a=b c=\"foo bar\" d=\"foo bar\" e=\"foo bar\" f=\"foo bar\"") == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"', 'f="foo bar"']

# Generated at 2022-06-17 03:43:33.482081
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test case 2
    args = 'a=b c="foo bar" d="a=b c=d"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd="a=b c=d"']

    # Test case 3
    args = 'a=b c="foo bar" d="a=b c=d" e="a=b c=d e=f"'
    params = split_args(args)

# Generated at 2022-06-17 03:43:45.157146
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function by comparing the output
    of split_args to the expected output for a variety of inputs.
    '''
    import sys
    import os
    import re

    # This is the list of test cases to run.
    # Each test case is a tuple of the form (input, expected_output)

# Generated at 2022-06-17 03:43:55.590578
# Unit test for function split_args
def test_split_args():
    # Test 1: Simple test
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: Test with jinja2 blocks
    args = 'a=b c="foo {{bar}}"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo {{bar}}"']

    # Test 3: Test with jinja2 blocks and quotes
    args = 'a=b c="foo {{bar}}" d="{{foo}} bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo {{bar}}"', 'd="{{foo}} bar"']

    # Test 4: Test with jinja2 blocks and quotes and line continuation
   

# Generated at 2022-06-17 03:44:00.754879
# Unit test for function split_args
def test_split_args():
    # Test for a simple command
    args = 'ls -l'
    assert split_args(args) == ['ls', '-l']

    # Test for a command with quoted arguments
    args = 'ls -l "foo bar"'
    assert split_args(args) == ['ls', '-l', '"foo bar"']

    # Test for a command with quoted arguments and escaped quotes
    args = 'ls -l "foo\"bar"'
    assert split_args(args) == ['ls', '-l', '"foo\"bar"']

    # Test for a command with quoted arguments and escaped quotes
    args = 'ls -l "foo\"bar"'
    assert split_args(args) == ['ls', '-l', '"foo\"bar"']

    # Test for a command with quoted arguments and escaped quotes

# Generated at 2022-06-17 03:44:11.475001
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar" d="foo bar" e=f g="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f', 'g="foo bar"']

# Generated at 2022-06-17 03:44:21.188793
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    assert split_args("a=b c=d") == ['a=b', 'c=d']

    # Test basic functionality with spaces in the values
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]

    # Test basic functionality with spaces in the values and spaces in the keys
    assert split_args("a = b c = 'foo bar'") == ['a = b', "c = 'foo bar'"]

    # Test basic functionality with spaces in the values and spaces in the keys and spaces in the values
    assert split_args("a = b c = 'foo bar baz'") == ['a = b', "c = 'foo bar baz'"]

    # Test basic functionality with spaces in the values and spaces in the keys and spaces in the values and spaces in the keys

# Generated at 2022-06-17 03:44:31.733610
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the split_args function.
    '''

    # Test 1: Basic test
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: Test with newlines
    args = 'a=b\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar"']

    # Test 3: Test with line continuation
    args = 'a=b \\\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 4: Test with line continuation and newline

# Generated at 2022-06-17 03:44:42.244064
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar" d="foo bar') == ['a=b', 'c="foo bar"', 'd="foo bar']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('a=b c="foo bar" d="foo bar" e=f') == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']

# Generated at 2022-06-17 03:44:50.602071
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function.
    '''
    # Test 1: simple test
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: test with newlines
    args = 'a=b\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar"']

    # Test 3: test with newlines and line continuation
    args = 'a=b\nc="foo bar" \\\nd=e'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar" \\\n', 'd=e']

    # Test 4: test with newlines

# Generated at 2022-06-17 03:45:02.311679
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test case 2
    args = 'a=b c="foo bar" d=\'{"a": 1, "b": 2}\''
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd=\'{"a": 1, "b": 2}\'']

    # Test case 3
    args = 'a=b c="foo bar" d=\'{"a": 1, "b": 2}\' e=\'{"a": 1, "b": 2}\' f=\'{"a": 1, "b": 2}\' g=\'{"a": 1, "b": 2}\''
    params

# Generated at 2022-06-17 03:45:46.110640
# Unit test for function split_args

# Generated at 2022-06-17 03:45:55.173406
# Unit test for function split_args
def test_split_args():
    # Test with simple args
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test with args containing quotes
    args = 'a=b c="foo bar" d="foo \'bar\'" e="foo \"bar\""'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd="foo \'bar\'"', 'e="foo \"bar\""']

    # Test with args containing escaped quotes
    args = 'a=b c="foo bar" d="foo \\\'bar\\\'" e="foo \\"bar\\""'
    params = split_args(args)

# Generated at 2022-06-17 03:46:06.536997
# Unit test for function split_args
def test_split_args():
    # Test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test case with escaped quotes
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']

    # Test case with escaped quotes and spaces
    assert split_args('a=b c="foo \\"bar \\" baz\\""') == ['a=b', 'c="foo \\"bar \\" baz\\""']

    # Test case with escaped quotes and spaces
    assert split_args('a=b c="foo \\"bar \\" baz\\""') == ['a=b', 'c="foo \\"bar \\" baz\\""']

    # Test case with escaped quotes and spaces
    assert split_args

# Generated at 2022-06-17 03:46:17.352881
# Unit test for function split_args
def test_split_args():
    '''
    This function runs a series of tests on the split_args function
    to ensure that it is working as expected.
    '''
    # test simple case
    test_args = "foo=bar baz=qux"
    result = split_args(test_args)
    assert result == ['foo=bar', 'baz=qux']

    # test simple case with newlines
    test_args = "foo=bar\nbaz=qux"
    result = split_args(test_args)
    assert result == ['foo=bar\n', 'baz=qux']

    # test simple case with newlines and line continuation
    test_args = "foo=bar\nbaz=qux\\\nquux=corge"
    result = split_args(test_args)

# Generated at 2022-06-17 03:46:28.742085
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function.
    '''
    # Test 1: Test with a simple string
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: Test with a string that contains a newline
    args = 'a=b\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar"']

    # Test 3: Test with a string that contains a newline and a backslash
    args = 'a=b\nc="foo bar"\\'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar"\\']

    # Test 4:

# Generated at 2022-06-17 03:46:33.757662
# Unit test for function split_args
def test_split_args():
    # Test with no args
    assert split_args('') == []

    # Test with no args, but with whitespace
    assert split_args(' ') == []
    assert split_args('\n') == []
    assert split_args(' \n ') == []

    # Test with one arg
    assert split_args('foo') == ['foo']

    # Test with one arg, but with whitespace
    assert split_args(' foo') == ['foo']
    assert split_args('foo ') == ['foo']
    assert split_args(' foo ') == ['foo']
    assert split_args('\nfoo') == ['foo']
    assert split_args('foo\n') == ['foo']
    assert split_args('\nfoo\n') == ['foo']

    # Test with multiple args

# Generated at 2022-06-17 03:46:44.117910
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function.
    '''
    # Test 1: Simple test
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: Test with spaces in quotes
    args = 'a=b c="foo bar" d="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd="foo bar"']

    # Test 3: Test with spaces in quotes and escaped quotes
    args = 'a=b c="foo bar" d="foo \\"bar\\""'
    params = split_args(args)

# Generated at 2022-06-17 03:46:52.455302
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function.
    '''

    # Test 1:
    # Test a simple string with no quotes or jinja2 blocks
    test_string = "foo bar baz"
    result = split_args(test_string)
    assert result == ['foo', 'bar', 'baz']

    # Test 2:
    # Test a string with a single quoted string
    test_string = "foo bar 'baz qux'"
    result = split_args(test_string)
    assert result == ['foo', 'bar', "'baz qux'"]

    # Test 3:
    # Test a string with a double quoted string
    test_string = 'foo bar "baz qux"'
    result = split_args(test_string)

# Generated at 2022-06-17 03:47:00.870616
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for function split_args
    '''
    # Test 1: simple args
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: simple args with newlines
    args = 'a=b\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar"']

    # Test 3: simple args with line continuation
    args = 'a=b \\\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 4: simple args with line continuation and newlines

# Generated at 2022-06-17 03:47:07.789653
# Unit test for function split_args
def test_split_args():
    '''
    This function is used to test the split_args function.
    '''
    # Test 1: Test a simple string
    test_string = "test"
    result = split_args(test_string)
    assert result == ['test']

    # Test 2: Test a string with spaces
    test_string = "test test"
    result = split_args(test_string)
    assert result == ['test', 'test']

    # Test 3: Test a string with quotes
    test_string = "test 'test test'"
    result = split_args(test_string)
    assert result == ['test', "'test test'"]

    # Test 4: Test a string with quotes and spaces
    test_string = "test 'test test' test"
    result = split_args(test_string)

# Generated at 2022-06-17 03:48:05.443740
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\"") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\" f='foo bar'") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e="foo bar"', "f='foo bar'"]

# Generated at 2022-06-17 03:48:18.506940
# Unit test for function split_args
def test_split_args():
    '''
    This test case is used to verify the split_args function
    '''
    # Test case 1
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test case 2
    args = 'a=b c="foo bar" d="a=b c=d"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd="a=b c=d"']

    # Test case 3
    args = 'a=b c="foo bar" d="a=b c=d" e="a=b c=d e=f"'
    params = split_args(args)

# Generated at 2022-06-17 03:48:23.592705
# Unit test for function split_args
def test_split_args():
    # Test 1: simple args
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: args with newlines
    args = 'a=b\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b\n', 'c="foo bar"']

    # Test 3: args with line continuation
    args = 'a=b \\\nc="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 4: args with line continuation and newlines
    args = 'a=b \\\n c="foo bar"'
    params = split_args(args)

# Generated at 2022-06-17 03:48:30.910095
# Unit test for function split_args
def test_split_args():
    # Test case 1
    args = 'a=b c="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test case 2
    args = 'a=b c="foo bar" d="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', 'd="foo bar"']

    # Test case 3
    args = 'a=b c="foo bar" d="foo bar" e="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e="foo bar"']

    # Test case 4

# Generated at 2022-06-17 03:48:40.948746
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function.
    '''
    # Test 1: Test with a simple string
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2: Test with a string that has a newline in it
    args = 'a=b c="foo\nbar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo\nbar"']

    # Test 3: Test with a string that has a newline in it, and a jinja2 block
    args = 'a=b c="foo\nbar" d={{ foo }}'
    params = split_args(args)

# Generated at 2022-06-17 03:48:51.213615
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function with a variety of inputs
    and compares the output to the expected output.
    '''

    # test data is a list of tuples, where each tuple is a test case
    # the first element in the tuple is the input string
    # the second element in the tuple is the expected output

# Generated at 2022-06-17 03:48:57.007803
# Unit test for function split_args

# Generated at 2022-06-17 03:49:06.513343
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function.
    '''
    # Test 1: Test that a simple string is split correctly
    test1 = "a=b c=d"
    result1 = split_args(test1)
    assert result1 == ['a=b', 'c=d']

    # Test 2: Test that a string with quotes is split correctly
    test2 = "a=b c='foo bar'"
    result2 = split_args(test2)
    assert result2 == ['a=b', "c='foo bar'"]

    # Test 3: Test that a string with quotes and a newline is split correctly
    test3 = "a=b c='foo\nbar'"
    result3 = split_args(test3)
    assert result3 == ['a=b', "c='foo\nbar'"]

# Generated at 2022-06-17 03:49:13.132249
# Unit test for function split_args