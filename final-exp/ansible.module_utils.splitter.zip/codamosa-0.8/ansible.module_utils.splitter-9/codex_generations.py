

# Generated at 2022-06-11 06:18:22.759341
# Unit test for function split_args

# Generated at 2022-06-11 06:18:34.540776
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo \nbar\"") == ['a=b', 'c="foo \nbar"']
    assert split_args("a=b c=\"foo \\\nbar\"") == ['a=b', 'c="foo \nbar"']
    assert split_args("a=b c='foo \\\nbar'") == ['a=b', "c='foo \nbar'"]
    assert split_args("a=b c='foo \nbar'") == ['a=b', "c='foo \nbar'"]

# Generated at 2022-06-11 06:18:38.977165
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foo') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo\'"') == False


# Generated at 2022-06-11 06:18:46.437128
# Unit test for function split_args

# Generated at 2022-06-11 06:18:57.440809
# Unit test for function split_args

# Generated at 2022-06-11 06:19:09.698413
# Unit test for function split_args
def test_split_args():
    def _format_result(result):
        return ', '.join("'%s'" % item for item in result)


# Generated at 2022-06-11 06:19:16.990049
# Unit test for function split_args
def test_split_args():
    '''
    Tests the following argument splitting cases
    '''

# Generated at 2022-06-11 06:19:28.578956
# Unit test for function split_args

# Generated at 2022-06-11 06:19:38.069774
# Unit test for function split_args
def test_split_args():
    args = '''a=b c="foo bar" d='{{f}} {{g}}' e=\\
'''
    params = ['a=b', 'c="foo bar"', "d='{{f}} {{g}}'", 'e=\\\n']
    assert split_args(args) == params

    args = '''{{ foo }}{% bar %}a="b c"
'''
    params = [u'{{ foo }}', u'{% bar %}', u'a="b c"\n']
    assert split_args(args) == params

    args = u'''\\
a=b c="foo bar"
'''
    params = ['a=b', 'c="foo bar"\n']
    assert split_args(args) == params


# Generated at 2022-06-11 06:19:47.792857
# Unit test for function split_args
def test_split_args():
    '''
    Test function split_args with many different edge cases
    '''

    # Test the base case where there is a simple command with quoted args
    tokens = split_args('ls -l "foo bar"')
    assert tokens == ['ls', '-l', '"foo bar"'], tokens

    # Test a command with newlines in it
    input = '''
    ls -l
    /tmp
    '''
    tokens = split_args(input)
    assert tokens == ['ls', '-l\n/tmp'], tokens

    # Test command with single quote args
    tokens = split_args("ls -l 'foo bar'")
    assert tokens == ['ls', '-l', "'foo bar'"], tokens

    # Test command with args that have quotes embedded in them

# Generated at 2022-06-11 06:20:06.804244
# Unit test for function split_args
def test_split_args():
    import unittest


# Generated at 2022-06-11 06:20:14.617411
# Unit test for function split_args
def test_split_args():

    # simple tests that should return the same thing
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b 'c d'") == ['a=b', 'c d']
    assert split_args("a=b \"c d\"") == ['a=b', 'c d']
    assert split_args("a=b 'c d' e='f g'") == ['a=b', 'c d', "e='f g'"]
    assert split_args("a=b \"c d\" e=\"f g\"") == ['a=b', 'c d', 'e="f g"']

# Generated at 2022-06-11 06:20:25.184709
# Unit test for function split_args
def test_split_args():
    assert split_args('ls "foo bar" /tmp') == ['ls', '"foo bar"', '/tmp']
    assert split_args('ls "a \\"b\\" c" d') == ['ls', '"a \\"b\\" c"', 'd']
    assert split_args('ls "foo bar"') == ['ls', '"foo bar"']
    assert split_args('ls "foo bar"') == ['ls', '"foo bar"']
    assert split_args('ls \'a "b" c\' d') == ['ls', '\'a "b" c\'', 'd']
    assert split_args('ls "a \'b\' c" d') == ['ls', '"a \'b\' c"', 'd']

# Generated at 2022-06-11 06:20:36.179462
# Unit test for function split_args
def test_split_args():
    ''' Unit test for function split_args '''
    expected_output = ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == expected_output
    assert split_args('a=b c="foo bar') != expected_output

    expected_output = ['a=b', 'c="foo bar="foo bar</p>', '"']
    assert split_args('a=b c="foo bar="foo bar</p>"') == expected_output
    assert split_args('a=b c="foo bar="foo bar</p>""') != expected_output

    expected_output = ['a=b', 'c="foo bar="foo bar</p>', '"']
    assert split_args('a=b c="foo bar="foo bar</p>"') == expected_output
   

# Generated at 2022-06-11 06:20:46.807954
# Unit test for function split_args
def test_split_args():
    # Test 1
    myargs = '''
a=b
c=d e="foo bar"
f="nginx
is a web server"
'''
    exp = ['a=b\nc=d', 'e="foo bar"', 'f="nginx\nis a web server"']
    res = split_args(myargs)
    assert res == exp

    # Test 2
    myargs = '''
a=b
c=d e="foo
bar"
f="nginx
is a web server"
'''
    exp = ['a=b\nc=d', 'e="foo\nbar"', 'f="nginx\nis a web server"']
    res = split_args(myargs)
    assert res == exp

    # Test 3

# Generated at 2022-06-11 06:20:57.374999
# Unit test for function split_args

# Generated at 2022-06-11 06:21:06.030750
# Unit test for function split_args
def test_split_args():
    # there is a zero-depth case where the quotes just don't
    # match up.  This causes the current split_args to fail
    # this tests for that
    args = u"a='b c' d='e f'"
    result = split_args(args)
    assert result == [u"a='b c'", u"d='e f'"]

    # test that we can split on newlines
    args = u"a=b c=\"foo bar\"\nd=e f=g"
    result = split_args(args)
    assert result == [u"a=b", u"c=\"foo bar\"\n", u"d=e", u"f=g"]

    # now let's make sure line continuations work
    args = u"a=b \\\nc=d e=f"
    result = split_

# Generated at 2022-06-11 06:21:16.254328
# Unit test for function split_args

# Generated at 2022-06-11 06:21:24.817709
# Unit test for function split_args
def test_split_args():

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b c') == ['a="b c']
    assert split_args('a={{foo}} b="{{bar}}" c={{baz}}') == ['a={{foo}}', 'b="{{bar}}"', 'c={{baz}}']
    assert split_args('a="{{foo}}') == ['a="{{foo}}']
    assert split_args('a="{{foo}}"') == ['a="{{foo}}"']
    assert split_args('a={%foo%}') == ['a={%foo%}']

# Generated at 2022-06-11 06:21:30.434192
# Unit test for function split_args
def test_split_args():
    # empty string
    assert split_args('') == []
    assert split_args('  ') == []
    assert split_args('  \n   \n   ') == []

    # single token, normal case
    assert split_args('foo') == ['foo']
    assert split_args('  foo  ') == ['foo']
    assert split_args('  foo\n  ') == ['foo']
    assert split_args('\n  \nfoo\n  \n') == ['foo']

    # multiple tokens, normal case
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args(' foo bar ') == ['foo', 'bar']
    assert split_args(' foo   bar ') == ['foo', 'bar']
    assert split_args(' foo   \nbar ')

# Generated at 2022-06-11 06:21:48.349220
# Unit test for function split_args
def test_split_args():
    # Single word, no quotes
    assert split_args("test") == ['test']
    # Single word, double quotes
    assert split_args('"test"') == ['test']
    # Single word, single quotes
    assert split_args("'test'") == ['test']
    # Simple quoted --key value
    assert split_args("--key 'test value'") == ['--key', 'test value']
    # Simple quoted --key value
    assert split_args("--key 'test value' --key2 'test value2'") == ['--key', 'test value', '--key2', 'test value2']
    # Simple quoted --key value
    assert split_args("--key 'test value' --key2 \"test value2\"") == ['--key', 'test value', '--key2', 'test value2']
    # Simple

# Generated at 2022-06-11 06:21:59.596447
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="foo bar" b=c') == ['a="foo bar"', 'b=c']
    assert split_args('a=b c="foo"\'bar" d=e') == ['a=b', 'c="foo\'bar"', 'd=e']
    assert split_args('a="foo bar') == ['a="foo bar']  # unclosed quote
    assert split_args('a="foo bar\'"') == ['a="foo bar\'"']  # escaped quote
    assert split_args('a=b c="foo bar\\" d="e f') == ['a=b', 'c="foo bar\\"', 'd="e', 'f']  # escaped quote
    assert split

# Generated at 2022-06-11 06:22:08.920241
# Unit test for function split_args

# Generated at 2022-06-11 06:22:19.241542
# Unit test for function split_args

# Generated at 2022-06-11 06:22:29.698771
# Unit test for function split_args
def test_split_args():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO
    stream = StringIO()
    def assertEq(a, b):
        if a != b:
            stream.write("%r != %r\n" % (a, b))
    assertEq(split_args("foo bar"), ['foo', 'bar'])
    assertEq(split_args("foo bar baz"), ['foo', 'bar', 'baz'])
    assertEq(split_args("foo 'bar baz'"), ['foo', "'bar baz'"])
    assertEq(split_args("foo 'bar baz' 'blah'"), ['foo', "'bar baz'", "'blah'"])

# Generated at 2022-06-11 06:22:39.251132
# Unit test for function split_args

# Generated at 2022-06-11 06:22:48.860158
# Unit test for function split_args
def test_split_args():

    # Test cases for split_args have been borrowed from
    # source: https://github.com/ansible/ansible/blob/devel/lib/ansible/utils/shlex.py

    assert split_args('echo "foo bar"') == ['echo', '"foo bar"']
    assert split_args('foo="bar bar"') == ['foo=bar bar']
    assert split_args('foo="bar bar" baz="abc cde"') == ['foo=bar bar', 'baz=abc cde']
    assert split_args('" "') == ['""']
    assert split_args('"\\" "') == ['"""']
    assert split_args('"foo "') == ['"foo "']
    assert split_args('" foo"') == ['foo']

# Generated at 2022-06-11 06:22:53.454636
# Unit test for function split_args
def test_split_args():
    # just basic sanity test, the module code should have unit tests with more coverage
    out = split_args("foo=bar baz='hello world'")
    assert len(out) == 2, out
    assert out[0] == "foo=bar", out
    assert out[1] == "baz='hello world'", out



# Generated at 2022-06-11 06:23:03.283741
# Unit test for function split_args
def test_split_args():

    # This function tests the function split_args with a variety of different
    # kinds of inputs, ensuring that it does the right thing when splitting
    # arguments on spaces and reassembling them if they are inside quotes
    # or jinja2 blocks

    def test_split(args, expected):
        ''' this is actually a single unit test, which runs split_args on the args list, and
        verifies that the result matches the expected list, this is basically a single
        data point for the test, and is called by the loop below to actually create the test cases
        This is basically a 1:1 conversion of the yaml data at the bottom of the file
        '''
        result = split_args(args)

# Generated at 2022-06-11 06:23:10.810019
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=\"foo bar\""]
    assert split_args("a=b c=\"foo bar\"\nd=\"foo baz\"") == ["a=b c=\"foo bar\"", "d=\"foo baz\""]
    assert split_args("a=b c=\"foo bar\"\\\nd=\"foo baz\"") == ["a=b c=\"foo bar\"d=\"foo baz\""]
    assert split_args("a=b c=\"foo bar\"\\") == ["a=b c=\"foo bar\""]
    assert split_args("a=b c={% if foo %}foo{% else %}bar{% endif %}") == ["a=b", "c={% if foo %}foo{% else %}bar{% endif %}"]

# Generated at 2022-06-11 06:23:48.767836
# Unit test for function split_args
def test_split_args():
    from ansible import constants as C

    errors = 0

# Generated at 2022-06-11 06:23:59.189121
# Unit test for function split_args
def test_split_args():
    args = '''
        foo=bar
        "foo bar" baz
        key1=val1 key2=val2
        "foo\"bar\""
        'foo\'bar\''
        multi_line_item
        another_multi_line_item
        {"a":1}
        {% if True %}
        {% endif %}
        {# foo #}
        {{ foo }}
        {{ { 'foo': 'bar' } }}
        {{{ 'foo': 'bar' }}}
        '''

    params = split_args(args)
    assert len(params) == 15
    assert params[0] == 'foo=bar'
    assert params[1] == '"foo bar" baz'
    assert params[2] == 'key1=val1 key2=val2'
    assert params[3]

# Generated at 2022-06-11 06:24:09.765892
# Unit test for function split_args
def test_split_args():
    '''
    Test basic splitting and reassembling of args after space splitting
    '''
    assert split_args('a b "c d"') == ['a', 'b', '"c d"']

    '''
    Test splitting and reassembling of args listed in a file, where we expect to
    parse the args (in this case after newline splitting)
    '''
    assert split_args('a \n b "c d"') == ['a\nb', '"c d"']

    '''
    Test reading lines on a file with a backslash, but not inside quotes,
    and verify that backslashes aren't treated as line continuation
    '''
    assert split_args('a \\b "c d"') == ['a \\b', '"c d"']


# Generated at 2022-06-11 06:24:16.395775
# Unit test for function split_args
def test_split_args():

    def test_string(line, ansible_args):
        args = split_args(line)
        assert args == ansible_args

    line = 'a=b c="foo bar" d=\'{"a":1}\' e=\'[1,2]\''
    ansible_args = ['a=b', 'c="foo bar"', 'd=\'{"a":1}\'', 'e=\'[1,2]\'']
    test_string(line, ansible_args)

    line = 'a=b c="foo bar" d=\'{"a":1}\' e=\'[1,2]\' f={{foo}}'

# Generated at 2022-06-11 06:24:26.075946
# Unit test for function split_args
def test_split_args():
    # Positive cases
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b 'c=foo bar'") == ['a=b', 'c=foo bar']
    assert split_args("a=b {{c=foo bar}}") == ['a=b', '{{c=foo bar}}']
    assert split_args("a=b {{c=foo}}{{d=bar}}") == ['a=b', '{{c=foo}}{{d=bar}}']
    assert split_args("a=b c=foo\\\nbar") == ['a=b', 'c=foo\nbar\n']

# Generated at 2022-06-11 06:24:35.607442
# Unit test for function split_args
def test_split_args():

    # test the happy path, no jinja2 blocks and no quotes
    happy_path = split_args("foo bar baz")
    assert len(happy_path) == 3
    assert happy_path == ['foo', 'bar', 'baz']

    # test that quotes are ignored if they are not closed by the end of the input
    unclosed_quotes = split_args("foo bar 'baz quxx")
    assert len(unclosed_quotes) == 3
    assert unclosed_quotes == ['foo', 'bar', "'baz quxx"]

    # test that a space in quotes will stay together and not split
    quotes_happy_path = split_args("foo 'bar baz' quxx")
    assert len(quotes_happy_path) == 3

# Generated at 2022-06-11 06:24:45.634764
# Unit test for function split_args
def test_split_args():
    assert split_args("ls -l") == ['ls', '-l']
    assert split_args("ls 'a b'") == ['ls', 'a b']
    assert split_args("ls \"a b\"") == ['ls', 'a b']
    assert split_args("ls \"a \\'b\\'\"") == ['ls', "a \\'b\\'"]
    assert split_args("ls \"a \\\"b\\\"\"") == ['ls', "a \\\"b\\\""]
    assert split_args("\"a \\\"b\\\"\"") == ["a \\\"b\\\""]
    assert split_args("\"a \\\"b\\\"") == ["a \\\"b\\\""]
    assert split_args("a \\\"b\\\"") == ["a \\\"b\\\""]


# Generated at 2022-06-11 06:24:49.212925
# Unit test for function split_args
def test_split_args():
    import sys
    if sys.version_info[0] > 2:
        # Python 3 renamed raw_input to input
        input_func = input
    else:
        input_func = raw_input
    while True:
        test_args = input_func("Test args: ")
        if test_args:
            print(split_args(test_args))
        else:
            print("Please provide test args")


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-11 06:24:58.362341
# Unit test for function split_args
def test_split_args():
    ''' basic test for split_args '''

    # our test input and expected output

# Generated at 2022-06-11 06:25:08.272776
# Unit test for function split_args
def test_split_args():
    myargs = "wibble thing=\"this is a test\" another={{whatsit}} \\\n"
    myargs += "  foo='{{whatsit}}' bar=\"{{whatsit}}\""
    myargs_split = split_args(myargs)
    assert myargs_split == [
        'wibble',
        'thing="this is a test"',
        'another={{whatsit}}',
        'foo=\'{{whatsit}}\'',
        'bar="{{whatsit}}"\n'
    ]

    # split args handles rstrings
    myargs = "{{ rstring | replace('@USER@', 'sally') }}"
    assert split_args(myargs) == ['{{ rstring | replace(\'@USER@\', \'sally\') }}']

    # split args handles rstrings

# Generated at 2022-06-11 06:26:23.943892
# Unit test for function split_args

# Generated at 2022-06-11 06:26:30.202348
# Unit test for function split_args
def test_split_args():
    # test that we can split on a jinja2 {{ }} block
    assert split_args('ansible {{inventory_hostname}} -m ping') == ['ansible', '{{inventory_hostname}}', '-m', 'ping']

    # test that we can split on a jinja2 {% %} block
    assert split_args('ansible {% if foo %} bar') == ['ansible', '{% if foo %}', 'bar']

    # test that we can split on a jinja2 {# #} block
    assert split_args('ansible {# this is a comment #}') == ['ansible', '{# this is a comment #}']

    # test that we can split on a jinja2 {{ }} or {% %} blocks at the same time

# Generated at 2022-06-11 06:26:39.139277
# Unit test for function split_args
def test_split_args():

    # quoted args
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # unquoted args
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']

    # quoted args with newline
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']

    # unquoted args with newline
    assert split_args('a=b c="foo\nbar" d=') == ['a=b', 'c="foo\nbar"', 'd=']

    # unbalanced quoted args with newline

# Generated at 2022-06-11 06:26:44.709727
# Unit test for function split_args
def test_split_args():
    '''
    test cases for split_args
    '''
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']

# Generated at 2022-06-11 06:26:52.221922
# Unit test for function split_args

# Generated at 2022-06-11 06:27:00.398862
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    def test(input, expected_output):
        module = AnsibleModule(argument_spec={'args': {'required': True, 'type': 'str'}})
        # parse the input
        module.params['args'] = input
        result = split_args(module.params['args'])
        if result != expected_output:
            print("FAILED: split_args('%s') returned incorrect value, got '%s' expected '%s'" % (input, result, expected_output))
            sys.exit(1)
    print("Testing split_args...")
    # empty args
    test('', [])
    # just a simple arg
    test('foo', ['foo'])
    # two simple args

# Generated at 2022-06-11 06:27:02.274902
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']


# Generated at 2022-06-11 06:27:10.156547
# Unit test for function split_args
def test_split_args():
    tests = [
        'a=b c="foo bar"',
        'a=b c="foo bar"\n d="hello world"',
        'a=b c="foo bar"\n d="hello \\\\ world"',
        'a=b c="foo bar" d="hello world" e="new\nline"',
        'a=b c="foo bar" d="hello world" e="new\nline" f=\'{"a":1, "b":"s", "c":[1,2,3]}\'',
        'a=b c="foo bar" d=\'hello world\' e="new\nline" f=\'{"a":1, "b":"s", "c":[1,2,3]}\'',
       ]

# Generated at 2022-06-11 06:27:19.224475
# Unit test for function split_args

# Generated at 2022-06-11 06:27:27.380224
# Unit test for function split_args