

# Generated at 2022-06-11 06:18:19.132993
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert is_quoted(split_args('foo "bar"')[1])
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert is_quoted(split_args('foo "bar baz"')[1])
    assert split_args('foo "bar \\"baz\\""') == ['foo', '"bar \\"baz\\""']
    assert split_args("foo 'bar \\\'baz\\\''") == ["foo", "'bar \\\'baz\\\''"]
    assert split_args("foo \"{# bar #} baz\"") == ['foo', '"{# bar #} baz"']
    assert split_

# Generated at 2022-06-11 06:18:30.017932
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar"') == ['foo', '"bar"']
    assert split_args('foo "bar baz') == ['foo', '"bar', 'baz']
    assert split_args('foo "bar baz') == ['foo', '"bar', 'baz']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar \\"baz\\""') == ['foo', '"bar \\"baz\\""']
    assert split_args('foo "bar \\"baz') == ['foo', '"bar', '\\"baz']
    assert split_args("foo 'bar baz'")

# Generated at 2022-06-11 06:18:40.631193
# Unit test for function split_args
def test_split_args():
    # quote_char should be None, inside_quotes should be False, print_depth and block_depth should be 0
    quote_char = None
    inside_quotes = False
    print_depth = 0  # used to count nested jinja2 {{ }} blocks
    block_depth = 0  # used to count nested jinja2 {% %} blocks
    comment_depth = 0  # used to count nested jinja2 {# #} blocks

    # Test 1

# Generated at 2022-06-11 06:18:52.693919
# Unit test for function split_args
def test_split_args():

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']
    assert split_args('a=b c="foo \\"bar"') == ['a=b', 'c="foo \\"bar']
    assert split_args('a=b c="foo \\"bar\\"" d=e') == ['a=b', 'c="foo \\"bar\\""', 'd=e']
    assert split_args('a=b c="foo \\"bar\\"" d=e f="g h"') == ['a=b', 'c="foo \\"bar\\""', 'd=e', 'f="g h"']
    assert split_args

# Generated at 2022-06-11 06:18:59.963931
# Unit test for function split_args
def test_split_args():
    # test quoting
    assert split_args('"a b" c d') == ['a b', 'c', 'd']
    assert split_args("'a b' c d") == ['a b', 'c', 'd']
    assert split_args('"a b"c d') == ['a bc', 'd']
    assert split_args('"a b" "c d"') == ['a b', 'c d']
    assert split_args('a="b c" d') == ['a=b c', 'd']
    assert split_args('a="b c"d') == ['a=b cd']
    assert split_args('a=b\nc d') == ['a=b', 'c', 'd']
    assert split_args('a=b\\nc d') == ['a=bc', 'd']
    assert split

# Generated at 2022-06-11 06:19:11.624596
# Unit test for function unquote
def test_unquote():
    assert unquote("'ab'") == 'ab'
    assert unquote("\"ab\"") == 'ab'
    assert unquote("'a'") == "a"
    assert unquote("\"a\"") == "a"
    assert unquote("'a'b") == "'a'b"
    assert unquote("\"a\"b") == "\"a\"b"
    assert unquote("'a\"b'") == "a\"b"
    assert unquote("\"a'b\"") == "a'b"
    assert unquote("a'b'") == "a'b'"
    assert unquote("a\"b\"") == "a\"b\""
    assert unquote("ab") == "ab"
    assert unquote("\"a") == "\"a"

# Generated at 2022-06-11 06:19:22.342894
# Unit test for function split_args
def test_split_args():
    ''' this is a test function for the split_args function'''
    # basic tests
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b') == ['a=b']
    assert split_args('"a=b c" "foo bar"') == ['a=b c', 'foo bar']
    assert split_args('"a=b') == ['"a=b']
    assert split_args('"a=b c"d" "foo bar"') == ['a=b cd', 'foo bar']
    assert split_args('"a=b\" cd" "foo bar"') == ['a=b" cd', 'foo bar']
    assert split_args('') == ['']
    assert split_args('""')

# Generated at 2022-06-11 06:19:28.579777
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('"test') != 'test'
    assert unquote("'test") != 'test'
    assert unquote('test"') != 'test'
    assert unquote('test"') != 'test'
    assert unquote('test') == 'test'
    assert unquote('"test"a') == '"test"a'


# Generated at 2022-06-11 06:19:38.053897
# Unit test for function split_args
def test_split_args():
    # test 1: Single items, with and without quotes
    result = split_args('/usr/bin/foo')
    assert ['usr', 'bin', 'foo'] == result, "test 1.1 failed"
    result = split_args('"/usr/bin/foo"')
    assert ['/usr/bin/foo'] == result, "test 1.2 failed"
    result = split_args("'/usr/bin/foo'")
    assert ["'/usr/bin/foo'"] == result, "test 1.3 failed"

    # test 2: items in quotes, containing spaces
    result = split_args('/usr/bin/foo /usr/bin/bar /usr/bin/baz')

# Generated at 2022-06-11 06:19:47.800527
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar \\"baz\\""') == ['foo', '"bar \\"baz\\""']
    assert split_args('foo "bar \'baz\'"') == ['foo', '"bar \'baz\'"']
    assert split_args('foo\nbar') == ['foo\nbar']
    assert split_args('"foo bar" "baz ding"') == ['"foo bar"', '"baz ding"']
    assert split_args('foo {{ bar }}') == ['foo', '{{', 'bar', '}}']

# Generated at 2022-06-11 06:20:07.222731
# Unit test for function split_args
def test_split_args():
    print_depth = 0
    block_depth = 0
    comment_depth = 0
    quote_char = None
    inside_quotes = False

    assert [x for x in split_args('')] == []
    assert split_args('"') == ['"']
    assert split_args('"a b') == ['"a b']
    assert [x for x in split_args(r'"a\"b')] == [r'"a\"b']
    assert [x for x in split_args(r'"a\"b"')] == [r'"a\"b"']
    assert [x for x in split_args('a=b c="foo bar"')] == ['a=b', 'c="foo bar"']

# Generated at 2022-06-11 06:20:14.935374
# Unit test for function split_args
def test_split_args():
    ''' This test is for testing the split_arg function '''
    # Test case for issue-19192, where a backslash at end of line
    # caused the next line to be treated as part of the previous line,
    # which in turn failed because that line was supposed to be a variable name,
    # which was invalid.
    assert split_args("""
    foo=bar
    baz=qux \\
    quux=corge
    grault=garply
    waldo=fred
    """) == [
        'foo=bar',
        'baz=qux \n',
        'quux=corge',
        'grault=garply',
        'waldo=fred',
    ]

    # Test case for issue-14512, where a line that started with a backslash
    # but nothing else caused

# Generated at 2022-06-11 06:20:25.539714
# Unit test for function split_args

# Generated at 2022-06-11 06:20:36.506951
# Unit test for function split_args
def test_split_args():
    '''
    This is a proof of concept, but should serve as a good place to start adding
    actual unit tests implemented with pytest or something similar to ensure
    that corner cases are handled correctly in the function.
    '''


# Generated at 2022-06-11 06:20:47.010993
# Unit test for function split_args
def test_split_args():

    def assert_split_args(input, expected_output):
        output = split_args(input)
        assert output == expected_output, "could not split args: %s\n\noutput: %s" % (input, output)

    # Test simple scenarios
    assert_split_args("a=b c='foo bar'", ['a=b', "c='foo bar'"])
    assert_split_args("a=b c=\"foo bar\"", ['a=b', "c=\"foo bar\""])
    assert_split_args("a=b c=foo\\ bar", ['a=b', "c=foo bar"])
    assert_split_args("a=b c=foo\\\nbar", ['a=b', "c=foo\nbar"])

# Generated at 2022-06-11 06:20:57.551289
# Unit test for function split_args
def test_split_args():
    ''' test for function "split_args" '''
    from ansible.module_utils import basic

    basic._ANSIBLE_ARGS = None

    # test 1:
    # simple case test.
    # This is the case that does not have any quote and jinja2 blocks
    in_str = 'a=b c="foo bar"'
    out_args = split_args(in_str)
    assert out_args == ['a=b', 'c="foo bar"']

    # test 2:
    # test with newline characters
    in_str = 'a=b \\\n c="foo bar"'
    out_args = split_args(in_str)
    assert out_args == ['a=b', 'c="foo bar"']

    # test 3:
    # test without newline characters
    in_str

# Generated at 2022-06-11 06:21:06.153215
# Unit test for function split_args

# Generated at 2022-06-11 06:21:16.402420
# Unit test for function split_args

# Generated at 2022-06-11 06:21:24.905067
# Unit test for function split_args
def test_split_args():
    '''
    :arg split_args: A function which splits arguments on spaces
    :returns: Passes if the function works correctly, fails and raises an exception otherwise
    '''
    import sys
    import os
    import shutil
    import tempfile
    import subprocess
    import glob
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Save the current directory
    curdir = os.getcwd()

    # Create a temporary ansible.cfg file
    old_ansible_cfg = None
    ansible_cfg = os.path.join(tmpdir, 'ansible.cfg')


# Generated at 2022-06-11 06:21:30.628643
# Unit test for function split_args
def test_split_args():
    import sys
    args = '''a=b c="foo bar" "quoted arg with spaces" 'quoted "" arg with spaces and quotes' arg_d=e 'arg_f="g h"' arg_i="j'k\"l" m="n\\no\\"p" q="\"" '""' "''" '''
    params = [
        'a=b',
        'c="foo bar"',
        '"quoted arg with spaces"',
        '\'quoted "" arg with spaces and quotes\'',
        'arg_d=e',
        '\'arg_f="g h"\'',
        'arg_i="j\'k"l"',
        'm="n\\no"p"',
        'q="\\""',
        '\'""\'',
        '"\'\'\"',
    ]


# Generated at 2022-06-11 06:21:48.176052
# Unit test for function split_args
def test_split_args():

    def normalize_params(params):
        '''
        normalize params to how they are stored, so that we can do string comparisons
        '''
        return [unquote(p.strip()) for p in params]

    # this list should be a list of tuples
    # the first item in the tuple is the args which we
    # split and the second item is the expected result

# Generated at 2022-06-11 06:21:59.449874
# Unit test for function split_args
def test_split_args():
    assert split_args(u"foo bar baz") == [u"foo", u"bar", u"baz"]
    assert split_args(u"foo bar baz\\") == [u"foo", u"bar", u"baz"]
    assert split_args(u"foo bar baz \\\n") == [u"foo", u"bar", u"baz", u"\n"]
    assert split_args(u"foo bar baz \\\nqux") == [u"foo", u"bar", u"baz", u"\nqux"]
    assert split_args(u"  foo  ") == [u"foo"]
    assert split_args(u"foo=bar baz") == [u"foo=bar", u"baz"]

# Generated at 2022-06-11 06:22:08.813771
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 06:22:19.092564
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar \\"baz\\""') == ['foo', '"bar \\"baz\\""']
    assert split_args('foo "bar \\"baz' + '\\\\"' + '"') == ['foo', '"bar \\"baz\\\\""']
    assert split_args('foo "bar \\"baz\""') == ['foo', '"bar \\"baz\""']
    assert split_args('foo "bar \\"baz\\\\""') == ['foo', '"bar \\"baz\\\\""']

# Generated at 2022-06-11 06:22:29.566133
# Unit test for function split_args

# Generated at 2022-06-11 06:22:39.139258
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=""') == ['a=b', 'c="foo bar"', 'd=""']
    assert split_args('a=b c=foo\\ bar') == ['a=b', 'c=foo bar']
    assert split_args('a=b c=foo\\\\bar') == ['a=b', 'c=foo\\bar']
    assert split_args('a=b c=foobar d=\\') == ['a=b', 'c=foobar', 'd=\\']

# Generated at 2022-06-11 06:22:48.643806
# Unit test for function split_args

# Generated at 2022-06-11 06:22:58.721943
# Unit test for function split_args
def test_split_args():
    ''' test the split_args function '''
    import sys

    # tests is a list of tuples where
    #       test[0] is the input string
    #       test[1] is the expected list
    #       test[2] is the name of the test
    tests = []

    tests.append(("", [], "no args"))
    tests.append(("a=b c=\"foo bar\"", ['a=b', 'c="foo bar"'], "simple"))
    tests.append(("\"foo bar\"", ['\"foo bar\"'], "quote only"))
    tests.append(("a='foo bar'", ["a='foo bar'"], "single quote only"))
    tests.append(("a=b 'c d'", ['a=b', "'c", "d'"], "quote in middle"))
    tests.append

# Generated at 2022-06-11 06:23:08.020683
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c=foo bar']
    assert split_args("a=b c=foo\\ bar") == ['a=b', 'c=foo bar']
    assert split_args("a=b c='foo bar'") == ['a=b', 'c=foo bar']
    assert split_args("a=b c='foo\\ bar'") == ['a=b', 'c=foo\\ bar']
    assert split_args("a=b c=\"'foo bar'\"") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=foo\\\nbar") == ['a=b', 'c=foo\\', 'bar']

# Generated at 2022-06-11 06:23:16.966635
# Unit test for function split_args

# Generated at 2022-06-11 06:23:36.761253
# Unit test for function split_args
def test_split_args():

    # These tests first use split_args and then manually split the string to
    # determine if they should match, ie they are split correctly
    test1 = "git clone 'http://foo.com/repo.git' /home/myapp"
    test2 = """git clone "http://foo.com/repo.git" /home/myapp"""
    test3 = "git clone {{ repo_url }} /home/myapp"
    test4 = "git clone {{ repo_url }} {{ repo_dest }}"
    test5 = """git clone "{{ repo_url }}" /home/myapp"""
    test6 = """git clone "{{ repo_url }}" "{{ repo_dest }}" """
    test7 = """git clone "{{ repo_url }}" {{ repo_dest }}"""

# Generated at 2022-06-11 06:23:44.174597
# Unit test for function split_args
def test_split_args():
    ''' unit test for function split_args '''
    assert split_args('') == []
    assert split_args('"quoted"') == ['quoted']
    assert split_args('a="b c"') == ['a=b c']
    assert split_args('"a=b c"') == ['a=b c']
    assert split_args('a=b\\ c') == ['a=b c']
    assert split_args('a="b\\ c"') == ['a=b\\ c']
    assert split_args('a=b\\ c d') == ['a=b c', 'd']
    assert split_args('a=b\\ c"d e"f') == ['a=b c', 'd e', 'f']
    assert split_args(r'a=b\ c"d e"f')

# Generated at 2022-06-11 06:23:54.481168
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar \\') == ['foo', 'bar', '\\']
    assert split_args('a\\ b') == ['a\\', 'b']
    assert split_args('a\\\nb') == ['a\\\nb']
    assert split_args('a="foo bar"') == ['a="foo bar"']
    assert split_args('a=\'foo bar\'') == ['a=\'foo bar\'']
    assert split_args('a={% foo %}') == ['a={%', 'foo', '%}']
    assert split_args('a={{ foo }}') == ['a={{', 'foo', '}}']

# Generated at 2022-06-11 06:24:04.655996
# Unit test for function split_args
def test_split_args():
    test_data = [
        ('a=b c="foo bar"', ['a=b', 'c="foo bar"']),
        ('a="foo bar"', ['a="foo bar"']),
        ('a="foo bar', ['a="foo bar']),
        ('a=\'foo bar\'', ['a=\'foo bar\'']),
        ('a=\'foo bar', ['a=\'foo bar']),
        ('a=b c="foo bar', ['a=b', 'c="foo bar']),
        ('a=b c="foo bar"', ['a=b', 'c="foo bar"']),
        ('a=\'foo bar\' c=d e=\'foo bar\'', ['a=\'foo bar\'', 'c=d', 'e=\'foo bar\''])
    ]


# Generated at 2022-06-11 06:24:13.726947
# Unit test for function split_args

# Generated at 2022-06-11 06:24:24.878501
# Unit test for function split_args

# Generated at 2022-06-11 06:24:34.186402
# Unit test for function split_args
def test_split_args():
    assert split_args("1") == ["1"]
    assert split_args("'1'") == ['"1"']
    assert split_args("\"1\"") == ['"1"']
    assert split_args(" \"1\"") == ['"1"']
    assert split_args("\"1\" ") == ['"1"']
    assert split_args(" foo=bar") == ["foo=bar"]
    assert split_args("foo=bar ") == ["foo=bar"]
    assert split_args("foo=bar ") == ["foo=bar"]
    assert split_args("foo=bar baz=quux") == ["foo=bar", "baz=quux"]
    assert split_args("foo=bar baz=quux ") == ["foo=bar", "baz=quux"]
    assert split_args

# Generated at 2022-06-11 06:24:38.387617
# Unit test for function split_args
def test_split_args():
    ''' split_args should return ['a=b', 'c="foo bar"'] for input a=b c="foo bar" '''
    test_result = split_args('a=b c="foo bar"')
    if test_result != ['a=b', 'c="foo bar"']:
        raise Exception("split_args test failed")



# Generated at 2022-06-11 06:24:48.478505
# Unit test for function split_args

# Generated at 2022-06-11 06:24:57.667344
# Unit test for function split_args
def test_split_args():
    assert split_args('this is just a test') == ['this', 'is', 'just', 'a', 'test']
    assert split_args('this is "just a test"') == ['this', 'is', '"just a test"']
    assert split_args('this is "just a \\"test\\""') == ['this', 'is', '"just a \\"test\\""']
    assert split_args('this is "just a test" abc="one two" fix=\'three four\'') == ['this', 'is', '"just a test"', 'abc="one two"', "fix='three four'"]
    assert split_args('prefix="{{ item }}"') == ['prefix="{{ item }}"']

# Generated at 2022-06-11 06:25:30.869687
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo=\"bar baz\"") == ["foo=bar baz"]
    assert split_args("foo=\"bar baz\" one=two") == ["foo=bar baz", "one=two"]
    assert split_args("foo=\"bar \\\"baz\\\"\" one=two") == ["foo=bar \"baz\"", "one=two"]
    assert split_args("foo=\"bar's baz\" one=two") == ["foo=bar's baz", "one=two"]
    assert split_args("foo='bar\"s baz' one=two") == ["foo=bar\"s", "baz", "one=two"]

# Generated at 2022-06-11 06:25:40.165701
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" ') == ['a=b', 'c="foo bar"']
    assert split_args(' a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(' a=b c="foo bar" ') == ['a=b', 'c="foo bar"']
    assert split_args(' a=b c="foo bar" ') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']

# Generated at 2022-06-11 06:25:49.379866
# Unit test for function split_args

# Generated at 2022-06-11 06:25:56.747782
# Unit test for function split_args
def test_split_args():
    '''
    Tests various cases to ensure that split_args works as expected
    '''

# Generated at 2022-06-11 06:26:05.277066
# Unit test for function split_args

# Generated at 2022-06-11 06:26:13.141465
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="foo') == ['a="foo']
    assert split_args('a=b c={{ foo }}') == ['a=b', 'c={{ foo }}']
    assert split_args('a=b c={{ foo }}}') == ['a=b', 'c={{ foo }}}']

# Generated at 2022-06-11 06:26:21.927034
# Unit test for function split_args
def test_split_args():
    '''
    we don't use the python unit test module here because this
    function is not used in any core ansible code and instead
    we want to keep the complexity to a minimum

    instead, we call this method directly and output the results
    here in this docstring
    '''

    # these are the test strings we will be testing, the tuples
    # contain the original string and the expected list of tokens

# Generated at 2022-06-11 06:26:28.641927
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo \\\"bar\"") == ['a=b', 'c="foo \\\"bar"']
    assert split_args("a=b c=\"foo \\\"bar\" d=\"foo 'bar'\"") == ['a=b', 'c="foo \\\"bar"', 'd="foo \'bar\'"']
    assert split_args("a=b c={{foo}} d=\"{{bar}}\"") == ['a=b', 'c={{foo}}', 'd="{{bar}}"']

# Generated at 2022-06-11 06:26:37.529332
# Unit test for function split_args
def test_split_args():
    e = Exception("failed to split args")


# Generated at 2022-06-11 06:26:46.681034
# Unit test for function split_args
def test_split_args():
    data = split_args('''a=b c="foo bar"''')
    assert data == ["a=b", 'c="foo bar"']

    data = split_args('''a=b c="foo bar" 'd e' "f\'g" h=\'i j\' k="l m"''')
    assert data == ["a=b", 'c="foo bar"', "d e", "f\'g", "h=\'i j\'", 'k="l m"']

    data = split_args('''a=b c="foo bar" 'd e' "f\'g" h=\'i j\' k="l m"''')
    assert data == ["a=b", 'c="foo bar"', "d e", "f\'g", "h=\'i j\'", 'k="l m"']



# Generated at 2022-06-11 06:27:52.310960
# Unit test for function split_args