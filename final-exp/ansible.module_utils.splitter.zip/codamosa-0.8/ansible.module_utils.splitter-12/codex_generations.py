

# Generated at 2022-06-11 06:18:04.230920
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("hello") == False
    assert is_quoted("'hello'") == True
    assert is_quoted('"hello"') == True
    assert is_quoted('"hel\'lo"') == True


# Generated at 2022-06-11 06:18:14.517171
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c='foo \\'bar\\''") == ['a=b', "c='foo \\'bar\\''"]
    assert split_args("a=b c=foo\\ bar") == ['a=b', 'c=foo bar']
    assert split_args("a=b c='foobar'") == ['a=b', "c='foobar'"]

# Generated at 2022-06-11 06:18:22.571489
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for function split_args
    '''
    import sys
    import difflib
    import textwrap
    import unittest


# Generated at 2022-06-11 06:18:34.328261
# Unit test for function is_quoted
def test_is_quoted():
    fail_list = ['quoted string',
        '"quoted string"',
        '"quoted" "string"',
        '\\"quoted" "string"\\"',
        '"-f foo.txt"',
        '"-f',
        'foo.txt"',
        '"-f foo.txt'
    ]
    success_list = [
        '"quoted string"',
        '"quoted\" \"string"',
        '"quoted \\\" string"',
        '""',
        '"\""',
        '"\\""',
        '"\" \\\\"'
    ]
    for test_string in success_list:
        assert test_string == unquote(unquote(test_string))


# Generated at 2022-06-11 06:18:38.737369
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert not is_quoted("'bar")
    assert not is_quoted("bar'")
    assert not is_quoted("foo")
    assert not is_quoted(None)



# Generated at 2022-06-11 06:18:46.304330
# Unit test for function split_args
def test_split_args():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestUtils(unittest.TestCase):

        def test_split_args(self):
            self.assertEqual(split_args('a=b c="foo bar"'), ['a=b', 'c="foo bar"'])
            self.assertEqual(split_args('a=b c="foo      bar"'), ['a=b', 'c="foo      bar"'])
            self.assertEqual(split_args('a=b c=\'foo bar\''), ['a=b', 'c=\'foo bar\'', ''])
            self.assertEqual(split_args('a=b "c=foo bar"'), ['a=b', '"c=foo bar"'])
            self.assertEqual

# Generated at 2022-06-11 06:18:51.218710
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"') == False
    assert is_quoted('') == False
    assert is_quoted('foo') == False



# Generated at 2022-06-11 06:18:59.447784
# Unit test for function split_args

# Generated at 2022-06-11 06:19:11.164021
# Unit test for function split_args

# Generated at 2022-06-11 06:19:21.645435
# Unit test for function split_args
def test_split_args():
    ''' Test that the split_args function breaks commandsline args into tokens correctly '''
    import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO


# Generated at 2022-06-11 06:19:40.442310
# Unit test for function split_args

# Generated at 2022-06-11 06:19:48.681059
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo bar"') == "foo bar"
    assert unquote("'foo bar'") == "foo bar"
    assert unquote('foo bar') == 'foo bar'
    assert unquote('"foo bar') == '"foo bar'
    assert unquote('foo bar"') == 'foo bar"'
    assert unquote('"foo bar "foo bar" "foo bar"') == '"foo bar "foo bar" "foo bar"'
    assert unquote('"foo bar "foo "bar" "foo bar"') == '"foo bar "foo "bar" "foo bar"'
    assert unquote('"foo bar "foo "bar "foo bar"') == '"foo bar "foo "bar "foo bar"'

# Generated at 2022-06-11 06:19:57.271565
# Unit test for function split_args
def test_split_args():
    args1 = '"Now I am become Death, the destroyer of worlds" -- Oppenheimer (1943)'
    assert split_args(args1) == ['"Now I am become Death, the destroyer of worlds"', '--', 'Oppenheimer', '(1943)']
    args2 = '''{% if foo %}foo was found{% else %}foo was not found{% endif %}'''
    assert split_args(args2) == ['{% if foo %}foo was found{% else %}foo was not found{% endif %}']
    args3 = '''a=b c="foo bar"'''
    assert split_args(args3) == ['a=b', 'c="foo bar"']

# Generated at 2022-06-11 06:20:00.623053
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'



# Generated at 2022-06-11 06:20:08.727073
# Unit test for function split_args
def test_split_args():
    assert split_args('a=3 c="foo bar"') == ['a=3', 'c="foo bar"']
    assert split_args('  a=3 c="foo bar"  d="   bar  foo  "  ') == ['a=3', 'c="foo bar"', 'd="   bar  foo  "']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('  a=b c=\'foo bar\'  d=\'   bar  foo  \'  ') == ['a=b', 'c=\'foo bar\'', 'd=\'   bar  foo  \'']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split

# Generated at 2022-06-11 06:20:15.750525
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('""') == ''
    assert unquote('"\\""') == '"'
    assert unquote('"\\""') == '"'
    assert unquote('"""') == '"'
    assert unquote('"""') == '"'
    assert unquote('"a"') == 'a'
    assert unquote('"a"') == 'a'
    assert unquote('"a\\"a"') == 'a"a'
    assert unquote('"a\\"a"') == 'a"a'
    assert unquote('"a\\"a\\"') == 'a"a"'
    assert unquote('"a\\"a\\"') == 'a"a"'

# Generated at 2022-06-11 06:20:20.455715
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a"bc"') == '"a"bc"'
    assert unquote("'a'bc'") == "'a'bc'"
    assert unquote('abc') == 'abc'

# Generated at 2022-06-11 06:20:31.384660
# Unit test for function split_args
def test_split_args():

    # quotes
    testargs = "a='foo bar'"
    test_result = split_args(testargs)
    assert test_result == ['a=\'foo bar\'']

    testargs = 'a="foo bar"'
    test_result = split_args(testargs)
    assert test_result == ['a="foo bar"']

    testargs = 'a=b c="foo bar"'
    test_result = split_args(testargs)
    assert test_result == ['a=b', 'c="foo bar"']

    testargs = 'a=b c="foo bar"'
    test_result = split_args(testargs)
    assert test_result == ['a=b', 'c="foo bar"']

    testargs = 'a=b c="foo bar" d=\'foo bar\''
    test_result

# Generated at 2022-06-11 06:20:39.598246
# Unit test for function split_args

# Generated at 2022-06-11 06:20:50.202969
# Unit test for function split_args
def test_split_args():
    inp = 'akjsdhf=foo a=b "c=d e=f" "g=h i=j" \'k=l m=n\' o=p "q=r\\n s=t" u=\'v w=x\''
    expected = ['akjsdhf=foo', 'a=b', 'c=d e=f', 'g=h i=j', 'k=l m=n', 'o=p', 'q=r\\n s=t', 'u=v w=x']
    result = split_args(inp)
    assert result == expected
    inp = 'a=b "c=d e=f" "g=h i=j" \'k=l m=n\' o=p "q=r\\n s=t" "u=v w=x"'

# Generated at 2022-06-11 06:21:07.817548
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for function split_args
    '''

    # test basic functionality
    assert split_args('foo=bar') == ['foo=bar']
    assert split_args('foo=bar ') == ['foo=bar']  # should not be ['foo=bar ', '']
    assert split_args(' foo=bar') == ['foo=bar']
    assert split_args(' foo = bar') == ['foo', '=', 'bar']
    assert split_args(' foo arg1 arg2 arg3') == ['foo', 'arg1', 'arg2', 'arg3']
    assert split_args('\nfoo=bar\n') == ['foo=bar']
    assert split_args('\nfoo=bar\n') == ['foo=bar']

    # test that quotes in the middle of a string are preserved
    assert split_

# Generated at 2022-06-11 06:21:18.093719
# Unit test for function split_args
def test_split_args():
    # python 2.6 / 2.7
    try:
        from StringIO import StringIO
    except ImportError:
        # python 3.x
        from io import StringIO

    import sys
    import textwrap

    def show(title, arg):
        sys.stdout.write(title)
        sys.stdout.write('\n')
        sys.stdout.write('Args:\n')
        sys.stdout.write(textwrap.indent(arg, '  '))
        sys.stdout.write('\n')
        sys.stdout.write('Result:\n')
        sys.stdout.write(textwrap.indent(str(split_args(arg)), '  '))
        sys.stdout.write('\n\n')


# Generated at 2022-06-11 06:21:25.876807
# Unit test for function split_args
def test_split_args():
    '''
    tests to make sure split args is selecting a value
    '''
    #Normal cases
    assert split_args('"a=b c=d"') == ['a=b', 'c=d']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a="b c=d"') == ['a="b c=d"']
    assert split_args('a=b c="d e" f') == ['a=b', 'c="d e"', 'f']
    assert split_args('a') == ['a']
    assert split_args('') == []

    #Complex cases
    assert split_args('a="b \"c=d\" e"') == ['a="b \"c=d\" e"']
    assert split

# Generated at 2022-06-11 06:21:31.415701
# Unit test for function split_args
def test_split_args():

    args = """a="1 2 3" b={{c}} {% if d %}d{% endif %}"""
    assert split_args(args) == ['a="1 2 3"', 'b={{c}}', '{% if d %}d{% endif %}']

    args = "a=b c=d e=\"foo bar\""
    assert split_args(args) == ['a=b', 'c=d', 'e="foo bar"']

    args = "a=b"
    assert split_args(args) == ['a=b']

    args = "a=b c='foo bar'"
    assert split_args(args) == ['a=b', "c='foo bar'"]

    args = "a=b c='foo bar' d='\"echo hooray\"'"

# Generated at 2022-06-11 06:21:41.128322
# Unit test for function split_args
def test_split_args():
    def _test_split_args(data, expected):
        results = split_args(data)
        if results != expected:
            raise ValueError("Expected: %s Got: %s" % (expected, results))

    _test_split_args(u"a=1", [u'a=1'])
    _test_split_args(u"a={{ b }}", [u'a={{ b }}'])
    _test_split_args(u"a={{ b }} c=3", [u'a={{ b }}', u'c=3'])
    _test_split_args(u"a={{ b }} c='f o o'", [u'a={{ b }}', u"c='f o o'"])

# Generated at 2022-06-11 06:21:48.397077
# Unit test for function split_args
def test_split_args():
    def _check_args(s, expected):
        r = split_args(s)
        if r != expected:
            print("%s\n%s\n%s" % (s, r, expected))
            assert False

    # empty arg string should return empty list
    _check_args('', [])

    # simple arg strings
    _check_args('two words', ['two', 'words'])
    _check_args('two words, three words', ['two', 'words,', 'three', 'words'])

    # Check that escaped quotes are ignored
    _check_args('foo "this string is escaped \"bar\"" end', ['foo', '"this string is escaped \\"bar\\""', 'end'])

# Generated at 2022-06-11 06:21:59.708521
# Unit test for function split_args

# Generated at 2022-06-11 06:22:08.991012
# Unit test for function split_args
def test_split_args():
    def _helper(input, expected):
        result = split_args(input)
        assert result == expected, "%s != %s (%s)" % (result, expected, input)

    _helper('a=b c=d e=f', ['a=b', 'c=d', 'e=f'])
    _helper('  a=b  c=d   e=f', ['a=b', 'c=d', 'e=f'])
    _helper('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _helper('a=b c="foo bar" d="foo \\" bar"', ['a=b', 'c="foo bar"', 'd="foo \\" bar"'])

# Generated at 2022-06-11 06:22:19.288460
# Unit test for function split_args
def test_split_args():
    assert split_args('this is a test') == ['this', 'is', 'a', 'test']
    assert split_args('this is "a test"') == ['this', 'is', 'a test']
    assert split_args('this is \'a test\'') == ['this', 'is', 'a test']
    assert split_args('this is {{a test}}') == ['this', 'is', '{{a test}}']
    assert split_args('this is {%a test%}') == ['this', 'is', '{%a test%}']
    assert split_args('this is "{{a test}}"') == ['this', 'is', '{{a test}}']

# Generated at 2022-06-11 06:22:29.743087
# Unit test for function split_args

# Generated at 2022-06-11 06:22:51.285944
# Unit test for function split_args
def test_split_args():
    t1 = "echo 'some string' and 'another string' and \"foo bar\""
    e1 = ['echo', "'some string' and 'another string' and \"foo bar\""]

    t2 = "echo 'some string' \\\nand 'another string' \\\nand \"foo bar\""
    e2 = ['echo', "'some string' and 'another string' and \"foo bar\""]

    t3 = "echo 'some string' \\\nand 'another string' \\\nand \"foo bar\""
    e3 = ['echo', "'some string' and 'another string' and \"foo bar\""]

    t4 = "echo 'some string' and 'another string' and \"foo bar\" \\\n"
    e4 = ['echo', "'some string' and 'another string' and \"foo bar\""]


# Generated at 2022-06-11 06:23:01.113491
# Unit test for function split_args
def test_split_args():
    ''' Unit test for function split_args '''

    # Positive Tests
    # test with args like dict and list

# Generated at 2022-06-11 06:23:09.579573
# Unit test for function split_args

# Generated at 2022-06-11 06:23:18.942394
# Unit test for function split_args
def test_split_args():
    # if any of these test cases fail, the function split_args() needs to be fixed
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('a="foo bar" c=\'foo bar\'') == ['a="foo bar"', 'c=\'foo bar\'']
    assert split_args('a="foo bar" c=\'foo bar\'') == ['a="foo bar"', 'c=\'foo bar\'']

# Generated at 2022-06-11 06:23:28.540323
# Unit test for function split_args
def test_split_args():
    '''
    This is a basic unit test for the function split_args.
    There are four types of test data:

    1) simple split - this is what the original code used to do
    2) quotes - this is a standard case of having a quoted string
    3) jinja2 block - this is a case of having a jinja2 expression with spaces
    4) jinja2 block inside quotes - this is a case of having a jinja2 expression with spaces within quotes

    Note that there are also a few cases of jinja2 blocks with quotes within them,
    but this is left as a test for the higher level functions that use split_args (not implemented yet)
    '''

    # the test data for the unit tests

# Generated at 2022-06-11 06:23:38.887507
# Unit test for function split_args
def test_split_args():
    def _assert_split_args(args, expected):
        actual = split_args(args)
        assert expected == actual, "expected %s, got %s" % (expected, actual)

    _assert_split_args("""a=b c="foo bar" """, ['a=b', 'c="foo bar"'])
    _assert_split_args("""a=b c="foo bar" """, ['a=b', 'c="foo bar"'])
    _assert_split_args("""a={{ b }} c="foo bar" """, ["a={{ b }}", 'c="foo bar"'])
    _assert_split_args("""a={{ b }} c='foo bar' """, ["a={{ b }}", "c='foo bar'"])

# Generated at 2022-06-11 06:23:44.995707
# Unit test for function split_args
def test_split_args():
    import json


# Generated at 2022-06-11 06:23:55.449728
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    def _test_ok(args, expected_result):
        actual_result = split_args(args)
        module.assertEqual(
            expected_result,
            actual_result,
            msg='Expected args "%s" to be split "%s" but got "%s".'
                % (args, expected_result, actual_result)
        )

    def _test_fail(args):
        try:
            split_args(args)
        except Exception:
            pass
        else:
            module.fail_json(
                msg='Expected args "%s" to fail being split but it succeeded.'
                    % args
            )

    _test

# Generated at 2022-06-11 06:24:05.802753
# Unit test for function split_args
def test_split_args():
    '''
    Simple unit test for split_args.  Outputs
    the got vs. expected for each test case,
    and fails if any are incorrect.
    '''
    import sys

# Generated at 2022-06-11 06:24:14.411440
# Unit test for function split_args

# Generated at 2022-06-11 06:24:46.633319
# Unit test for function split_args

# Generated at 2022-06-11 06:24:55.873541
# Unit test for function split_args

# Generated at 2022-06-11 06:25:05.566068
# Unit test for function split_args

# Generated at 2022-06-11 06:25:07.803183
# Unit test for function split_args
def test_split_args():
    # Test split args
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])



# Generated at 2022-06-11 06:25:13.820301
# Unit test for function split_args
def test_split_args():
    c1 = "a=b c='foo bar'"
    c2 = "a=b c='foo bar' \\ \n d=c"
    c3 = "a=b c='foo bar' \\ \n {% foo %} \n d=c"
    c4 = "a=b c='foo bar' \\ \n {% foo %} \n d='c {{ foo }}'"
    c5 = "a=b c='foo bar' \\ \n {% foo %} \n d='c {{ foo }}' e=f \\ \n g=h i=3"
    c6 = "a=b c='foo bar' \\ \n {% foo %} \n d='c {{ foo }}' e=f \\ \n g=h i=3 {% bar %}"

# Generated at 2022-06-11 06:25:22.326045
# Unit test for function split_args
def test_split_args():
    args = '''  w/ spaces="foo bar" alist='[1,2,3]' ahash='{"foo":"bar","bam":"baz"}' baz=1 abc="123" 
               foobar="test 1" alist2='[1,2,3,4]' baz2=2
               test3 abc=\"456\"
               foobar2="test 2"
               baz3=3 abc=\'789\' '''

    params = split_args(args)

# Generated at 2022-06-11 06:25:30.735953
# Unit test for function split_args
def test_split_args():
    args = 'foo bar bam=foobar "one two three"'
    expected = ['foo', 'bar', 'bam=foobar', '"one two three"']
    (result, _) = split_args(args)
    assert result == expected

    args = '''\"a\" b=c 'foo bar' "bam "\"baz"
    fizz buzz
    \"test \"\"test\"\"test\" one two
    \"foo\" three\"
    '''
    expected = ['b=c', '"a"', "'foo bar'", '"bam "', '"baz"', 'fizz buzz', '"test "', '"test"', '"test"', '"foo"', 'three"']
    (result, _) = split_args(args)
    assert result == expected


# Generated at 2022-06-11 06:25:39.952254
# Unit test for function split_args

# Generated at 2022-06-11 06:25:49.177296
# Unit test for function split_args
def test_split_args():
    assert split_args('foo=1 name="a b c"') == ['foo=1', 'name="a b c"']
    assert split_args('foo={{ bar }}') == ['foo={{ bar }}']
    assert split_args('foo="{{ bar }}"') == ['foo="{{ bar }}"']
    assert split_args('foo="{{ bar }}" baz={{ zap }}') == ['foo="{{ bar }}"', 'baz={{ zap }}']
    assert split_args('foo="{{ bar }}\n') == ['foo="{{ bar }}\n']
    assert split_args('foo="{{ bar }}\nbar={{ foo }}') == ['foo="{{ bar }}\nbar={{ foo }}']

# Generated at 2022-06-11 06:25:56.647358
# Unit test for function split_args

# Generated at 2022-06-11 06:26:50.268664
# Unit test for function split_args
def test_split_args():
    target = ['a=b', 'c="foo bar"']
    result = split_args(target[0] + ' ' + target[1])
    assert result == target
    result = split_args(target[0] + '\n' + target[1])
    assert result == target

    target = ['a="b c"']
    result = split_args(target[0])
    assert result == target
    target = ['a="b\'c"']
    result = split_args(target[0])
    assert result == target

    target = ['a=\'b"c\'']
    result = split_args(target[0])
    assert result == target

    target = ['a=\'b\\\'c\'']
    result = split_args(target[0])
    assert result == target


# Generated at 2022-06-11 06:26:58.662194
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestSplitArgs(unittest.TestCase):

        @patch('ansible.module_utils.basic.split_args._get_quote_state')
        @patch('ansible.module_utils.basic.split_args._count_jinja2_blocks')
        def test_simple_arg(self, mock_block_count, mock_quote_state):

            # Set up mocked return values
            mock_quote_state.return_value = None  # Not inside a quoted string
            mock_block_count.return_value = 0

            # This is the argument we're going to test
            args = 'foo=bar'

            # Call the function
            result = split_args(args)

           

# Generated at 2022-06-11 06:27:06.687845
# Unit test for function split_args

# Generated at 2022-06-11 06:27:14.695565
# Unit test for function split_args
def test_split_args():
    ''' test for function split_args '''


# Generated at 2022-06-11 06:27:23.453718
# Unit test for function split_args

# Generated at 2022-06-11 06:27:32.736656
# Unit test for function split_args
def test_split_args():
    """
    Unit tests for function split_args
    """
    import sys

    # a list of test cases and their expected result

# Generated at 2022-06-11 06:27:41.146157
# Unit test for function split_args
def test_split_args():
    params = split_args(r"a=1 b='foo bar' c='foo\"bar' d='foo\\'bar' e=foo\\\"bar f=\"foo'bar\" g=\"foo\\\"bar\" h=\"foo\\\\\"bar\"")

    assert(len(params) == 8)
    assert(params[0] == "a=1")
    assert(params[1] == "b='foo bar'")
    assert(params[2] == r"c='foo\"bar'")
    assert(params[3] == r"d='foo\'bar'")
    assert(params[4] == "e=foo\"bar")
    assert(params[5] == r"f=\"foo'bar\"")
    assert(params[6] == r"g=\"foo\\\"bar\"")

# Generated at 2022-06-11 06:27:50.690823
# Unit test for function split_args
def test_split_args():
    print("Testing split_args:")
    passed = True
    def _try(args, expect):
        result = split_args(args)
        if result != expect:
            print(" split_args('%s') != '%s'" % (args, expect))
            return False
        return True

    passed = _try('a=b', ['a=b']) and passed
    passed = _try('a=b ', ['a=b']) and passed
    passed = _try('a=b c=d', ['a=b', 'c=d']) and passed
    passed = _try('a=b c=d ', ['a=b', 'c=d']) and passed
    passed = _try(' a=b c=d', ['a=b', 'c=d']) and passed