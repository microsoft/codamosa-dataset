

# Generated at 2022-06-11 06:18:28.173677
# Unit test for function split_args

# Generated at 2022-06-11 06:18:39.076330
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('') is False)
    assert(is_quoted('""') is True)
    assert(is_quoted('"a"') is True)
    assert(is_quoted('"" ') is False)
    assert(is_quoted('""""') is False)
    assert(is_quoted('"a') is False)
    assert(is_quoted('a"') is False)
    assert(is_quoted('a') is False)
    assert(is_quoted('"" "') is False)
    assert(is_quoted('"a" "b"') is False)
    assert(is_quoted('"""a"""') is True)



# Generated at 2022-06-11 06:18:46.490730
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import unittest

    class TestSplitArgs(unittest.TestCase):

        def test_simple(self):
            self.assertEqual(split_args('a=b c="foo bar"'), ['a=b', 'c="foo bar"'])

        def test_quotes(self):
            self.assertEqual(split_args('a=b c="foo bar"'), ['a=b', 'c="foo bar"'])
            self.assertEqual(split_args('a=b c=\'foo bar\''), ['a=b', 'c=\'foo bar\''])
            self.assertEqual(split_args('a=b c="foo bar'), ['a=b', 'c="foo bar'])

# Generated at 2022-06-11 06:18:57.442542
# Unit test for function split_args
def test_split_args():

    # test the function split_args

    # Testing the function split_args with simple args
    args = 'command arg1 arg2'
    split = split_args(args)
    assert len(split) == 3, 'The function split_args failed to split on spaces'

    # Testing the function split_args with spaces in the args
    args = 'command " some spaces "'
    split = split_args(args)
    assert len(split) == 2, 'The function split_args failed to split on spaces inside quotes'
    assert split[1] == 'some spaces', 'The function split_args failed to remove quotes'

    # Testing the function split_args with quotes and spaces
    args = 'command "some spaces" other'
    split = split_args(args)

# Generated at 2022-06-11 06:19:09.695184
# Unit test for function split_args
def test_split_args():
    '''
    simple test of the split args class
    '''
    assert split_args('''a=b c="foo bar"''') == ['a=b', 'c="foo bar"']
    assert split_args('''a=b "c='foo bar'"''') == ['a=b', '''"c='foo bar'"''']
    assert split_args('''a=b c='foo bar' "d=\'foo bar\'"''') == ['a=b', "c='foo bar'", "d=\'foo bar\'"]
    assert split_args('''a=b c="foo 'bar'" "d=\'foo bar\'"''') == ['a=b', "c=\"foo 'bar'\"", "d=\'foo bar\'"]

# Generated at 2022-06-11 06:19:16.989084
# Unit test for function split_args
def test_split_args():
    # splits args appropriately
    assert split_args('') == ['']
    assert split_args('arg1=value1') == ['arg1=value1']
    assert split_args('arg1=value1 arg2=value2') == ['arg1=value1', 'arg2=value2']
    assert split_args('arg1=value1\narg2=value2') == ['arg1=value1', 'arg2=value2']

    # reassembles split jinja2 blocks
    assert split_args('arg1="{{ foo }}"') == ['arg1="{{ foo }}"']
    assert split_args('arg1="{{ foo }}') == ['arg1="{{ foo }}']
    assert split_args('arg1="{{') == ['arg1="{{']

# Generated at 2022-06-11 06:19:28.534432
# Unit test for function split_args
def test_split_args():
    # Test normal arguments
    args1 = "a=b c=\"foo bar\" d={{foo}} e='{{foo}}' f=\"{{foo}}\" x=foo\\ bar y=\"{{foo|d({'a':'b'})}}\" z={{foo|d({\\'a\\':\\'b\\'})}}"
    result1 = split_args(args1)
    if result1 != ['a=b', 'c="foo bar"', "d={{foo}}", "e='{{foo}}'", 'f="{{foo}}"', 'x=foo bar', "y=\"{{foo|d({'a':'b'})}}\"", "z={{foo|d({'a':'b'})}}"]:
        raise Exception("split_args failed to parse: %s" % args1)

    # Test arguments split over lines

# Generated at 2022-06-11 06:19:38.054401
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.parsing.convert_bool import boolean

    # test boolean conversion of parsed tokens

# Generated at 2022-06-11 06:19:47.788835
# Unit test for function unquote

# Generated at 2022-06-11 06:19:56.581333
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.collections import is_iterable

# Generated at 2022-06-11 06:20:22.906855
# Unit test for function split_args

# Generated at 2022-06-11 06:20:34.072061
# Unit test for function split_args
def test_split_args():
    from random import choice
    from string import ascii_letters, digits

    def random_string(n):
        return ''.join(choice(ascii_letters + digits) for _ in range(n))

    for _ in range(1000):
        n = choice(range(-10, 10))
        params = []
        for _ in range(n):
            params.append(random_string(choice(range(10))))
        params = ' '.join(params)

        quotes = choice(range(3))
        if quotes == 1:
            params = '"{0}"'.format(params)
        elif quotes == 2:
            params = "'{0}'".format(params)

        params_split = split_args(params)
        assert(' '.join(params_split) == params)


# Generated at 2022-06-11 06:20:44.101039
# Unit test for function split_args
def test_split_args():
    ''' parameters to split_args and result list '''

# Generated at 2022-06-11 06:20:53.192059
# Unit test for function unquote
def test_unquote():
    s = '"a string"'
    assert unquote(s) == 'a string'

    s = 'a string'
    assert unquote(s) == 'a string'

    s = "'a string'"
    assert unquote(s) == 'a string'

    s = '""'
    assert unquote(s) == ''

    s = "''"
    assert unquote(s) == ''

    s = "'''"
    assert unquote(s) == "'''"

    s = '"""'
    assert unquote(s) == '"""'

    s = '"a string'
    assert unquote(s) == '"a string'



# Generated at 2022-06-11 06:21:02.903952
# Unit test for function split_args
def test_split_args():

    def _test_one(test_data, expected_output):
        test_output = split_args(test_data)
        if test_output != expected_output:
            raise AssertionError("extracted args from test data do not match expected results:\n\nTest Data: %s\n\nExpected: %s\n\nActual: %s" % (test_data, expected_output, test_output))

    _test_one('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _test_one('my_key1=my_value1 my_key2=my_value2', ['my_key1=my_value1', 'my_key2=my_value2'])

# Generated at 2022-06-11 06:21:12.576824
# Unit test for function unquote
def test_unquote():
    data = "lalla"
    if unquote(data) != data:
        raise AssertionError()
    data = "\"lallala\""
    if unquote(data) != "lallala":
        raise AssertionError()
    data = "'lallala'"
    if unquote(data) != "lallala":
        raise AssertionError()
    data = "\"lallala"
    if unquote(data) != "\"lallala":
        raise AssertionError()
    data = "lallala\""
    if unquote(data) != "lallala\"":
        raise AssertionError()
    data = "''"
    if unquote(data) != "":
        raise AssertionError()
    data = '""'

# Generated at 2022-06-11 06:21:15.258328
# Unit test for function unquote
def test_unquote():
    assert 'hello' == unquote('"hello"')
    assert 'hello' == unquote("'hello'")
    assert 'hello' == unquote('hello')
    return True


# Generated at 2022-06-11 06:21:24.217741
# Unit test for function split_args

# Generated at 2022-06-11 06:21:29.829115
# Unit test for function split_args
def test_split_args():

    def _check_parsed_args(parsed_args, expected_args):
        assert len(parsed_args) == len(expected_args)
        for idx, parsed_arg in enumerate(parsed_args):
            assert parsed_arg == expected_args[idx]


# Generated at 2022-06-11 06:21:32.341687
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'


# Generated at 2022-06-11 06:21:56.825234
# Unit test for function split_args

# Generated at 2022-06-11 06:22:06.592956
# Unit test for function split_args
def test_split_args():
    assert split_args("A=1 b=2") == ["A=1", "b=2"]
    assert split_args("A=1\nb=2") == ["A=1\n", "b=2"]
    assert split_args("foo='bar baz'") == ["foo='bar baz'"]
    assert split_args("foo=\"bar baz\"") == ["foo=\"bar baz\""]
    assert split_args("foo=1 bar=2") == ["foo=1", "bar=2"]
    assert split_args("foo=1 'bar baz'") == ["foo=1", "'bar baz'"]
    assert split_args("foo=1\n 'bar baz'") == ["foo=1\n", "'bar baz'"]

# Generated at 2022-06-11 06:22:12.678275
# Unit test for function split_args

# Generated at 2022-06-11 06:22:23.389557
# Unit test for function split_args
def test_split_args():
    # This method is called from unit tests.

    # Assert the boolean result is true.
    assert(split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'])
    assert(split_args('c="foo bar" a=b') == ['c="foo bar"', 'a=b'])
    assert(split_args('a=b c="foo bar" d="x') == ['a=b', 'c="foo bar"', 'd="x'])
    assert(split_args('a=b c="foo bar" d="x"') == ['a=b', 'c="foo bar"', 'd="x"'])
    assert(split_args('a=b c="foo bar d="x"') == ['a=b', 'c="foo bar d="x"'])
   

# Generated at 2022-06-11 06:22:33.766911
# Unit test for function split_args
def test_split_args():
    ''' unit test will try to execute split_args with a lot of different cases '''

    # test data is a list of tuples with first value the input string and second value the expected output list

# Generated at 2022-06-11 06:22:40.169247
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("a=1 b=2") == ['a=1', 'b=2']
    assert split_args("a={{foo}} b=2") == ['a={{foo}}', 'b=2']
    assert split_args("a={{foo}}\nb=2") == ['a={{foo}}\n', 'b=2']
    assert split_args("a={{foo}}\\\nb=2") == ['a={{foo}}\\\n', 'b=2']
    assert split_args("a={{foo}}\\\nb={{bar}}") == ['a={{foo}}\\\n', 'b={{bar}}']

# Generated at 2022-06-11 06:22:50.175505
# Unit test for function split_args
def test_split_args():
    # set of test cases that should pass, these are just examples
    assert split_args('') == []
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=') == ['a=b', 'c=']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a=b c="foo\\\\bar"') == ['a=b', 'c="foo\\\\bar"']
    assert split_args('a=b c="foo\\"bar"') == ['a=b', 'c="foo\\"bar"']
    assert split_args('a=b c="{% foo %}"') == ['a=b', 'c="{% foo %}"']
    assert split

# Generated at 2022-06-11 06:23:00.139019
# Unit test for function split_args
def test_split_args():
    def _test_helper(args, exp):
        res = split_args(args)
        assert res == exp, "input %s, expected %s, received %s" % (args, exp, res)
        print("input %s, expected %s, received %s" % (args, exp, res))

    _test_helper('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _test_helper('a=b c="foo bar"\nd=e', ['a=b', 'c="foo bar"\nd=e'])
    _test_helper('a=b c="foo bar"\nd=e\nf=g', ['a=b', 'c="foo bar"\nd=e', 'f=g'])

# Generated at 2022-06-11 06:23:08.932995
# Unit test for function split_args

# Generated at 2022-06-11 06:23:18.275011
# Unit test for function split_args
def test_split_args():
    '''
    basic tests of the split_args function
    '''
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(u"a=b c=u'foo bar'") == ['a=b', "c=u'foo bar'"]
    assert split_args('''a=b c="foo\nbar"''') == ['a=b', 'c="foo\nbar"']
    assert split_args('''a=b c="foo\nbar"\nd=e''') == ['a=b', 'c="foo\nbar"\nd=e']
    assert split

# Generated at 2022-06-11 06:23:56.974804
# Unit test for function split_args
def test_split_args():
    ''' tests for the split_args function '''
    import json


# Generated at 2022-06-11 06:24:07.243387
# Unit test for function split_args
def test_split_args():
    args = '''a=1 b=2 c="foo bar" "d=3 e=4" "f\\"g\\"h=5" 'i=j k=6' 'm="n\\"o"' "p={{foo}}" {% for x in y %} q=7 r={{bar}} {% endfor %} "s={{qux}}" {# t=8 #} u=9'''

# Generated at 2022-06-11 06:24:15.186300
# Unit test for function split_args
def test_split_args():
    # test the basic functionality
    assert split_args("a=1") == ['a=1']
    assert split_args("a=1 b=2 c=3") == ['a=1', 'b=2', 'c=3']
    assert split_args("a='1' b=\"2\" c=3") == ['a=\'1\'', 'b="2"', 'c=3']
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=1 b=foo") == ['a=1', 'b=foo']
    assert split_args("a=1\nb=foo\nc=bar") == ['a=1\n', 'b=foo\n', 'c=bar']

    # test whitespace preservation

# Generated at 2022-06-11 06:24:25.456287
# Unit test for function split_args
def test_split_args():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestSplitArgs(unittest.TestCase):

        def test_simple_args(self):
            '''args that don't contain jinja2 template markers'''

            args = 'foo=bar'
            result = split_args(args)
            self.assertEqual(result, ['foo=bar'])

            args = 'foo=bar baz="qux"'
            result = split_args(args)
            self.assertEqual(result, ['foo=bar', 'baz="qux"'])

            args = 'foo=bar baz="qux" quux=corge'
            result = split_args(args)
            self.assertEqual

# Generated at 2022-06-11 06:24:31.476380
# Unit test for function split_args
def test_split_args():
    input = 'a=b c="foo bar" d="foo \'bar\' baz" e="\\"foo \\"bar\\"" f=1 g="1 2 3"'
    output = [
        'a=b',
        'c="foo bar"',
        "d=\"foo 'bar' baz\"",
        'e="\\"foo \\"bar\\""',
        'f=1',
        'g="1 2 3"'
    ]
    assert(split_args(input) == output)



# Generated at 2022-06-11 06:24:41.109983
# Unit test for function split_args
def test_split_args():
    '''
    Verify function split_args behaves properly
    '''

    # first test with a simple string that has no quoting or jinja2 vars
    args1 = split_args("foo bar baz")
    assert args1 == ['foo', 'bar', 'baz']

    # try it with a very large number of args
    args2 = split_args(" ".join(["foo%s" % i for i in xrange(0, 10000)]))
    assert args2 == ["foo%s" % i for i in xrange(0, 10000)]

    # assert that we can split on newlines
    # also assert that we can pass in a list and not just a string
    args3 = split_args(["foo bar", "foo bar2", "foo bar3"])

# Generated at 2022-06-11 06:24:50.957531
# Unit test for function split_args
def test_split_args():
    assert split_args('  foo  ') == ['foo']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"\ne="foo bar"') == ['a=b c="foo bar"', 'e="foo bar"']
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']
    assert split_args('a=b c="foo\\"bar"') == ['a=b', 'c="foo"bar"']
    assert split_args('a=b c="foo"\\\nbar"') == ['a=b', 'c="foo"bar"']

# Generated at 2022-06-11 06:25:00.097747
# Unit test for function split_args
def test_split_args():
    '''
    Will not raise an exception if the tests run successfully.
    '''
    class do_nothing:
        def __init__(self, *args, **kwargs):
            self.kwargs = kwargs

    params = split_args('a=b c="foo bar"')
    assert params == ['a=b', 'c="foo bar"'], params

    params = split_args('a={{foo}}')
    assert params == ['a={{foo}}'], params

    params = split_args('a={{ foo }}')
    assert params == ['a={{ foo }}'], params

    params = split_args('a={{foo.bar}}')
    assert params == ['a={{foo.bar}}'], params

    params = split_args('a={{ foo.bar }}')

# Generated at 2022-06-11 06:25:09.765777
# Unit test for function split_args
def test_split_args():
    '''
    AnsibleModule argument parsing test
    '''
    result = split_args('a=b "c d"')
    expected = ['a=b', '"c d"']
    assert result == expected, "failed to parse simple list of args with quotes"

    result = split_args("a=b c='d e'")
    expected = ['a=b', "c='d e'"]
    assert result == expected, "failed to parse simple list of args with a mix of quotes"

    result = split_args("a=b 'c d'")
    expected = ['a=b', "'c d'"]
    assert result == expected, "failed to parse simple list of args with single quotes"

    result = split_args("a=b 'c\"d e' f=g")

# Generated at 2022-06-11 06:25:17.934485
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def _assert(res, exp):
        if res != exp:
            raise AssertionError("%s != %s" % (str(res), str(exp)))

    args = 'foo "bar baz" blah'
    _assert(split_args(args), ['foo', 'bar baz', 'blah'])

    args = "{{ lookup('template', './templates/foo.j2') }}:{{ foo }}"

# Generated at 2022-06-11 06:26:38.492257
# Unit test for function split_args
def test_split_args():
    ''' unit test for module function split_args '''

    ################################################
    # testing string with no jinja blocks
    ################################################
    args = "foo bar"
    params = split_args(args)
    assert params == ['foo', 'bar']

    ################################################
    # testing string with jinja2 blocks in it
    ################################################
    args = "{{ foo }}"
    params = split_args(args)
    assert params == ['{{', 'foo', '}}']

    args = "{{ foo }} {{ bar }}"
    params = split_args(args)
    assert params == ['{{', 'foo', '}}', '{{', 'bar', '}}']

    args = "{{ foo }}{{ bar }}"
    params = split_args(args)
    assert params

# Generated at 2022-06-11 06:26:47.384309
# Unit test for function split_args
def test_split_args():
    assert(split_args('a=1 b=2 \"foo bar\"') == ['a=1', 'b=2', 'foo bar'])
    assert(split_args('a=1 b=2 \"foo\\\"bar\\\"zzz\"') == ['a=1', 'b=2', '"foo\"bar\"zzz"'])
    assert(split_args('a=1 b=2 \"foo bar') == ['a=1', 'b=2', 'foo bar'])
    assert(split_args('a=1 b=2 \"foo') == ['a=1', 'b=2', 'foo'])
    assert(split_args('a=1 b=2 foo') == ['a=1', 'b=2', 'foo'])

# Generated at 2022-06-11 06:26:55.426547
# Unit test for function split_args
def test_split_args():
    assert split_args('c="foo bar"') == ['c=foo bar']
    assert split_args('c="foo bar" d="foo"') == ['c=foo bar', 'd=foo']
    assert split_args('c="foo bar') == ['c=foo bar']
    assert split_args(r"1 c=\'foo bar\' d=\'foo\'") == ['1', "c=foo bar", "d=foo"]
    assert split_args(r"1 c=\"foo bar\" d=\"foo\"") == ['1', "c=foo bar", "d=foo"]

# Generated at 2022-06-11 06:27:03.718448
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the split_args function
    '''


# Generated at 2022-06-11 06:27:11.527038
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo \\\nbar\"") == ['a=b', 'c="foo \nbar"']
    assert split_args("a=b c=\"foo \\'bar\"") == ['a=b', 'c="foo \'bar"']
    assert split_args("a=b c=\"foo 'bar\"") == ['a=b', 'c="foo \'bar"']
    assert split_args("a=b c=\"foo \\\n\nbar\"") == ['a=b', 'c="foo \n\nbar"']

# Generated at 2022-06-11 06:27:20.349604
# Unit test for function split_args
def test_split_args():
    # put test params in a dict for easier management
    tests = dict()
    tests['simple'] = dict(
        argstr='a=b c="foo bar"',
        result=['a=b', 'c="foo bar"'],
    )

# Generated at 2022-06-11 06:27:24.764012
# Unit test for function split_args
def test_split_args():
    test_input = """a=b c='foo bar'
    d="a'''b"
    a=b c=\\
    d\\
    """
    expected_output = ['a=b', "c='foo bar'", "d=\"a'''b\"", 'a=b', 'c=d']
    output = split_args(test_input)
    assert output == expected_output

# Generated at 2022-06-11 06:27:34.183380
# Unit test for function split_args
def test_split_args():
    assert split_args('"foo bar"') == ['foo bar']
    assert split_args("'foo bar'") == ['foo bar']
    assert split_args("\"foo bar'") == ["foo bar'"]
    assert split_args("'foo bar\"") == ["'foo", 'bar"']
    assert split_args("'foo bar\" test'") == ["'foo bar\" test'"]
    assert split_args("{{foo}} 'bar test'") == ['{{foo}}', 'bar test']
    assert split_args("{{foo}} \"bar test\"") == ['{{foo}}', 'bar test']
    assert split_args("\"{{foo}}\" 'bar test'") == ['{{foo}}', 'bar test']
    assert split_args("\"{{foo}}\" \"bar test\"") == ['{{foo}}', 'bar test']

# Generated at 2022-06-11 06:27:42.947102
# Unit test for function split_args
def test_split_args():
    args = """a='b c' d="1 2" e=3"""
    tokens = split_args(args)
    assert tokens == ["a='b c'", 'd="1 2"', 'e=3'], tokens

    args = """a='b c' d="1 2" e=3"""
    tokens = split_args(args)
    assert tokens == ["a='b c'", 'd="1 2"', 'e=3'], tokens

    args = '''a='b c' "d e" "f'g" h'''
    tokens = split_args(args)
    assert tokens == ["a='b c'", '"d e"', '"f\'g"', 'h'], tokens

    args = '''a="b c" 'd e' "f'g" h'''

# Generated at 2022-06-11 06:27:51.720916
# Unit test for function split_args