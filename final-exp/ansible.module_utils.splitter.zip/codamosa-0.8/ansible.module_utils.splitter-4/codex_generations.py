

# Generated at 2022-06-11 06:18:09.544103
# Unit test for function is_quoted
def test_is_quoted():
  assert is_quoted('""')
  assert is_quoted("''")
  assert is_quoted('"a"')
  assert is_quoted("'b'")
  assert not is_quoted('')
  assert not is_quoted('"')
  assert not is_quoted("'")
  assert not is_quoted('a')
  assert not is_quoted('"b')
  assert not is_quoted("'c")


# Generated at 2022-06-11 06:18:15.206636
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello world'")
    assert is_quoted('"hello world"')
    assert not is_quoted("'hello world")
    assert not is_quoted('"hello world')
    assert not is_quoted("hello world'")
    assert not is_quoted('hello world"')
    assert not is_quoted("")


# Generated at 2022-06-11 06:18:20.392529
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"abc""') == '"abc""'
    assert unquote("'abc''") == "'abc''"
    assert unquote('"""abc"""') == '"""abc"""'
    assert unquote("'''abc'''") == "'''abc'''"

# Generated at 2022-06-11 06:18:31.832677
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar" d=\'{"a": 1}\''
    expected = ['a=b', 'c="foo bar"', 'd=\'{"a": 1}\'']
    assert split_args(args) == expected

    args = 'a=b c={{ foo }} d="{{ bar }}"'
    expected = ['a=b', 'c={{ foo }}', 'd="{{ bar }}"']
    assert split_args(args) == expected

    args = 'a=b c="{{ foo }} echo hi" d=\'{{ bar }}\''
    expected = ['a=b', 'c="{{ foo }} echo hi"', "d='{{ bar }}'"]
    assert split_args(args) == expected


# Generated at 2022-06-11 06:18:42.064282
# Unit test for function split_args
def test_split_args():
    values = [('a=b', [u'a=b']),
              ('a=b c=d', [u'a=b', u'c=d']),
              ('a=b "foo bar"', [u'a=b', u'"foo bar"']),
              ("a=b 'foo bar'", [u'a=b', u"'foo bar'"]),
              ('a=b "foo bar', [u'a=b', u'"foo bar']),
              ("a=b 'foo bar", [u'a=b', u"'foo bar"]),
              ('a=b """foo bar"""', [u'a=b', u'"""foo bar"""'])]

    for value in values:
        assert split_args(value[0]) == value[1]


# Generated at 2022-06-11 06:18:54.763010
# Unit test for function split_args
def test_split_args():

    assert split_args(u'') == []
    assert split_args(u'"foo"') == [u'"foo"']
    assert split_args(u"''") == [u"''"]
    assert split_args(u'a="foo"') == [u'a="foo"']
    assert split_args(u'a="foo bar"') == [u'a="foo bar"']
    assert split_args(u'a="foo bar" baz') == [u'a="foo bar"', u'baz']
    assert split_args(u'a="foo bar baz"') == [u'a="foo bar baz"']
    assert split_args(u'a="foo bar"baz') == [u'a="foo bar"baz']

# Generated at 2022-06-11 06:19:05.433441
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('"a=b"') == ['a=b']
    assert split_args("'a=b'") == ['a=b']
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="foo bar" \'b c\'') == ['a="foo bar"', 'b c']
    assert split_args("a=b 'c d' \"e f\"") == ['a=b', 'c d', 'e f']

# Generated at 2022-06-11 06:19:15.172166
# Unit test for function split_args
def test_split_args():
    '''
    Test function for split_args
    '''
    from ansible.compat.tests import unittest
    import ansible.utils as utils

    class TestSplitArgs(unittest.TestCase):
        '''
        a simple test class for testing split_args
        '''

        def _run_check(self, args, expected, msg=None):

            params = split_args(args)
            self.assertEqual(len(expected), len(params), msg)
            for idx, entry in enumerate(expected):
                self.assertEqual(entry, params[idx], msg)

        def test_split_args_simple(self):
            '''
            Test with some basic values
            '''

# Generated at 2022-06-11 06:19:26.666833
# Unit test for function split_args
def test_split_args():
    # tests for valid input
    print('testcase 1')
    print('INPUT: ${file}')
    tokens = split_args('${file}')
    print(tokens)
    print()

    print('testcase 2')
    print('INPUT: ${file} /tmp')
    tokens = split_args('${file} /tmp')
    print(tokens)
    print()

    print('testcase 3')
    print('INPUT: "hello world" "foo bar"')
    tokens = split_args('"hello world" "foo bar"')
    print(tokens)
    print()

    print('testcase 4')
    print('INPUT: "hello world" "foo \\"bar\\"" "baz"')

# Generated at 2022-06-11 06:19:31.131913
# Unit test for function is_quoted
def test_is_quoted():
    test_data = [('test', False), ('"test"', True), ('\'test\'', True), ('["test"]', False), ('test"', False), ('test\\"', False), ('"test', False)]
    result = True
    for (str, expected) in test_data:
        if is_quoted(str) != expected:
            result = False
    return result


# Generated at 2022-06-11 06:19:51.261830
# Unit test for function split_args
def test_split_args():
    # Test case for unbalanced quote
    try:
        split_args("a=1 c='foo bar")
        assert False, "Exception is expected"
    except Exception as e:
        assert "unbalanced quotes" in str(e), "Split args should fail when quote is not balanced"

    # Test case for unbalanced jinja2 block
    try:
        split_args("a=1 c={{ foo bar }}")
        assert False, "Exception is expected"
    except Exception as e:
        assert "unbalanced jinja2 block" in str(e), "Split args should fail when jinja2 block is not balanced"


# Generated at 2022-06-11 06:19:58.983918
# Unit test for function split_args

# Generated at 2022-06-11 06:20:07.646947
# Unit test for function split_args
def test_split_args():
    testargs = "a=b c=\"foo bar\""
    params = split_args(testargs)
    assert params[0] == "a=b"
    assert params[1] == "c=\"foo bar\""

    testargs = "a={{ foo }} b={{ baz }} c={{ bar }}\n d={{ bar }}"
    params = split_args(testargs)
    assert params[0] == 'a={{ foo }}'
    assert params[1] == 'b={{ baz }}'
    assert params[2] == 'c={{ bar }}\n d={{ bar }}'

    testargs = "a={{ foo }} b={{ baz }} c={{ bar }}\\\n d={{ bar }}"
    params = split_args(testargs)

# Generated at 2022-06-11 06:20:15.126015
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d e=f") == ['a=b', 'c=d', 'e=f']
    assert split_args("a=b 'c=d e=f'") == ['a=b', 'c=d e=f']
    assert split_args('a=b "c=d e=f"') == ['a=b', 'c=d e=f']
    assert split_args('a=b "c=d e=f"\n g=h') == ['a=b', 'c=d e=f\n', 'g=h']
    assert split_args('a=b "c=d e=f"\n g=h') == ['a=b', 'c=d e=f\n', 'g=h']

# Generated at 2022-06-11 06:20:25.713653
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.pycompat24 import PY2
    import sys

    def to_text(text, encoding='utf-8', errors='strict'):
        """Return the unicode representation of text in the given encoding. """
        if isinstance(text, str):
            return text
        if not isinstance(text, bytes):
            raise TypeError('to_bytes must receive a unicode, str or bytes '
                            'object, got %s' % type(text).__name__)
        return text.decode(encoding, errors)

    def to_bytes(text, encoding='utf-8', errors='strict'):
        """Return the binary representation of text. """
        if isinstance(text, bytes):
            return text

# Generated at 2022-06-11 06:20:36.706557
# Unit test for function split_args
def test_split_args():
    for args, expected_params in _TEST_ARGS:
        params = split_args(args)
        assert params == expected_params, "args: %s, params: %s, expected: %s" % (args, params, expected_params)



# Generated at 2022-06-11 06:20:47.216471
# Unit test for function split_args
def test_split_args():
    # the goal of this test is to ensure that split_args works for a variety of scenarios, including those
    # where a parameter is split over multiple lines
    arg_strings = {
        "complex   arg": ["complex", "arg"],
        "arg with spaces": ["arg", "with", "spaces"],
        "var=complex   arg": ["var=complex", "arg"],
        "var=arg with spaces": ["var=arg", "with", "spaces"],
        "var=complex   arg key=val": ["var=complex", "arg", "key=val"],
        "var=arg with spaces key=val": ["var=arg", "with", "spaces", "key=val"],
    }
    for arg_string, expected_result in arg_strings.iteritems():
        result = split_args(arg_string)

# Generated at 2022-06-11 06:20:57.733186
# Unit test for function split_args
def test_split_args():
    # Test all normal cases
    assert split_args('"a=1 b=2"') == ['"a=1 b=2"']
    assert split_args('a=1 b=2') == ['a=1', 'b=2']
    assert split_args('a="b c" d=e') == ['a="b c"', 'd=e']
    assert split_args('a="b c" d=\'e f\'') == ['a="b c"', 'd=\'e f\'']
    assert split_args('a="b c" d="e \'f\'"') == ['a="b c"', 'd="e \'f\'"']

# Generated at 2022-06-11 06:21:06.273571
# Unit test for function split_args
def test_split_args():
    '''
    The following test_* functions run split_args against input strings and check the output
    against correct output strings.  So for example, if the input is 'a=b c="foo bar"', the output
    string would be 'a=b\nc="foo bar"'.

    These test functions are expected to run during normal CI process, and should be
    updated when code changes to the split_args function are made.
    '''


# Generated at 2022-06-11 06:21:16.507933
# Unit test for function split_args
def test_split_args():
    def assert_splits_correctly(input, expected_output):
        actual_output = split_args(input)
        assert actual_output == expected_output

    assert_splits_correctly("a=1", ['a=1'])
    assert_splits_correctly("a=1 b=2", ['a=1', 'b=2'])
    assert_splits_correctly("a=1 \n b=2", ['a=1', 'b=2'])
    assert_splits_correctly("a=1 \n b=2 \n c=3", ['a=1', 'b=2', 'c=3'])

# Generated at 2022-06-11 06:21:32.317645
# Unit test for function split_args
def test_split_args():

    base = '''
    a=b c="foo bar"            d="{{ foo }}" e='{{ bar }}' f='{{"""
}}""" }' g="{% if foo %}bar{% endif %}"  h="{# foo #}bar"
    '''
    expected_result = [
        'a=b', 'c="foo bar"', 'd="{{ foo }}"', "e='{{ bar }}'",
        "f='{{" '""' "\n" '}}""' " }'", "g=bar", 'h="{# foo #}"',
    ]

    result = split_args(base)
    assert result == expected_result, '\nexpected:\n%s\ngot:\n%s' % (expected_result, result)
    # test that we can re-encode it and get the original

# Generated at 2022-06-11 06:21:42.002355
# Unit test for function split_args

# Generated at 2022-06-11 06:21:48.805048
# Unit test for function split_args
def test_split_args():
    '''
    run tests against the split_args function
    '''
    import unittest
    import os
    import sys

    class TestSplitArgs(unittest.TestCase):

        def test_split_args(self):
            args = 'a=b c="foo bar"'
            res = split_args(args)
            self.assertEqual(res, ['a=b', 'c="foo bar"'])

            args = "a={{ b.c }} d='foo bar'"
            res = split_args(args)
            self.assertEqual(res, ['a={{ b.c }}', "d='foo bar'"])

            args = "a={{ b.c }} d='foo bar' e='foo'\\\n'bar'"
            res = split_args(args)
            self.assertEqual

# Generated at 2022-06-11 06:22:00.030908
# Unit test for function split_args

# Generated at 2022-06-11 06:22:09.207391
# Unit test for function split_args
def test_split_args():
    import sys
    import types
    import unittest

    class SplitArgsTester(unittest.TestCase):
        def test_args_split_simple(self):
            self.assertEqual(split_args("a=b c='d e' f=g"), ['a=b', "c='d e'", 'f=g'])

        def test_args_split_whitespace(self):

            self.assertEqual(split_args("a=b c='d e'\nf=g"), ['a=b', "c='d e'\nf=g"])
            self.assertEqual(split_args("a=b c='d e'\n\nf=g"), ['a=b', "c='d e'\n\nf=g"])

# Generated at 2022-06-11 06:22:19.548213
# Unit test for function split_args
def test_split_args():
    '''
    ###############################################################################
    #
    # Tests for the subroutine "split_args" in vars_plugins/yaml.py
    #
    ###############################################################################
    #
    # The subroutine will accept a string and break it into individual arguments
    #
    # It recognizes quotes, jinja2 blocks, and line continuation characters.
    #
    # It will reassemble strings that were split across quotes or blocks
    #
    # It will strip quotes from a string argument unless the string is split
    # across quotes or blocks.
    #
    # It will return a list of strings
    #
    ###############################################################################
    '''

    from collections import namedtuple
    from ansible.compat.tests import unittest
    from ansible.release import __version__ as ans

# Generated at 2022-06-11 06:22:29.921886
# Unit test for function split_args
def test_split_args():
    # some basic tests
    assert split_args("foo=bar key=value") == ['foo=bar', 'key=value']
    assert split_args("a=1 b=2") == ['a=1', 'b=2']
    assert split_args("foo=bar key='fizzy wizzle'") == ['foo=bar', "key='fizzy wizzle'"]
    assert split_args("foo=bar key=\"fizzy wizzle\"") == ['foo=bar', 'key="fizzy wizzle"']
    assert split_args("foo=bar key='fizzy \"wizzle\"'") == ['foo=bar', 'key=\'fizzy "wizzle"\'']
    assert split_args("foo=bar key=\"fizzy 'wizzle'\"") == ['foo=bar', 'key="fizzy \'wizzle\'"']
   

# Generated at 2022-06-11 06:22:39.433241
# Unit test for function split_args
def test_split_args():
    # Test basic use, with no nested quotes or jinja blocks
    argstring = '''a=b c="foo bar"'''
    result = split_args(argstring)
    if result != ['a=b', 'c="foo bar"']:
        raise Exception("incorrect basic split_args result")

    # Test that extra whitespace is removed
    argstring = '''
a=b   c="foo bar"
d="foo bar"  e=f
'''
    result = split_args(argstring)
    if result != ['a=b', 'c="foo bar"\nd="foo bar"', 'e=f']:
        raise Exception("incorrect whitespace split_args result")

    # Test that a split on space within quotes is reassembled
    argstring = '''a=b c="foo  bar"'''

# Generated at 2022-06-11 06:22:49.168356
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='blah'") == ['a=b', 'c="foo bar"', "d='blah'"]
    assert split_args("a=b 'c=foo bar'") == ['a=b', "'c=foo bar'"]
    assert split_args("a=b 'c=foo bar' d=\"blah\"") == ['a=b', "'c=foo bar'", 'd="blah"']

# Generated at 2022-06-11 06:22:59.203542
# Unit test for function split_args
def test_split_args():
    ''' test split_args function '''
    from ansible.errors import AnsibleError
    import random

    #
    # Test each of the nested control structures recognized by split_args
    #

    # test each nesting level of a single structure
    for block_type in ['{{', '{%', '{#']:
        for level in range(1, 10):
            args = '%sfoo%s ' * level % tuple([block_type] * level + ['}}'] * level)
            params = split_args(args)
            assert len(params) == 1

    # test multiple control structures intermixed
    args = '%sfoo%s %sbar%s %sbaz%s %sbing%s' % tuple(('{{', '}}', '{%', '%}', '{#', '#}') * 2)

# Generated at 2022-06-11 06:23:29.660572
# Unit test for function split_args
def test_split_args():
    # Test simple args
    assert ['foo'] == split_args('foo')
    assert ['foo', 'bar'] == split_args('foo bar')
    assert ['foo', '--foo-bar'] == split_args('foo --foo-bar')
    # Args containing new lines
    assert ['foo', 'bar'] == split_args('foo \n bar')
    assert ['foo', 'bar'] == split_args('foo \n \n bar')
    assert ['foo', '\n', 'bar'] == split_args('foo  \n bar')
    # Args containing quotes
    assert ['foo', 'bar'] == split_args('foo "bar"')
    assert ['foo', 'bar'] == split_args("foo 'bar'")
    # Test args with jinja2 blocks
    assert ['foo', 'bar'] == split_args

# Generated at 2022-06-11 06:23:40.011988
# Unit test for function split_args
def test_split_args():
    def _split_args(args):
        '''
        helper function to split arguments and return the list of parameters that are found
        '''
        return split_args(args)

    import sys

    assert _split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert _split_args('a="b c"') == ['a="b c"']
    assert _split_args('a=b "foo bar"') == ['a=b', '"foo bar"']
    assert _split_args('a=b \'foo bar\'') == ['a=b', "'foo bar'"]
    assert _split_args('a="b\'c"') == ['a="b\'c"']

# Generated at 2022-06-11 06:23:49.524274
# Unit test for function split_args
def test_split_args():
    # Test for a simple command with no args
    assert split_args("ls") == ['ls']
    # Test for a command with multiple args
    assert split_args("ls -a -l") == ['ls', '-a', '-l']
    # Test for a command with args containing spaces
    assert split_args("ls -a 'this is file'") == ['ls', '-a', "'this is file'"]
    assert split_args("ls -a \"this is file\"") == ['ls', '-a', "\"this is file\""]
    # Test for a command with an escaped double quote inside an unescaped single quote
    assert split_args("ls -a '\\\"this is file\\\"'") == ['ls', '-a', "'\\\"this is file\\\"'"]
    # Test for a command with an escaped single quote

# Generated at 2022-06-11 06:23:59.916489
# Unit test for function split_args
def test_split_args():
    params = {
        'a': 'b',
        'c': 'd',
        'e': 'f',
        'g': 'h',
        'i': 'j',
        'k': '"l',
        'n': 'o',
        'p': 'q',
        'r': 's',
        't': 'u',
        'x': 'y ',
        'z': 'a',
    }

    keys = []
    values = []

    for (k, v) in params.iteritems():
        keys.append('%s' % k)
        values.append('%s' % v)


# Generated at 2022-06-11 06:24:10.406341
# Unit test for function split_args

# Generated at 2022-06-11 06:24:16.751688
# Unit test for function split_args
def test_split_args():
    ''' unit test for function split_args '''

    def _split_args(inputstring):
        ''' helper function to exercise split_args '''
        print(inputstring)
        print(split_args(inputstring))

    _split_args('''a='1 2 3' b="1 2 3" c="{{ foo }}"''')
    _split_args('''a='1 2 3' "b=1 2 3" c="{{ foo }}"''')
    _split_args('''a='1 2 3' b="{{ foo }}"''')
    _split_args('''a="{{ foo }}" b="1 2 3"''')
    _split_args('''a="{{ foo }}" b="1 2 3"''')

# Generated at 2022-06-11 06:24:26.289205
# Unit test for function split_args
def test_split_args():
    test_string = 'a=b c="foo bar" d=\'{"foo": "bar bar"}\''
    test_result = ['a=b', 'c="foo bar"', 'd=\'{"foo": "bar bar"}\'']
    result = split_args(test_string)
    assert result == test_result, "%s != %s" % (result, test_result)
    test_string = 'a=b c={% if True %} {% endif %}'
    test_result = ['a=b', 'c={% if True %} {% endif %}']
    result = split_args(test_string)
    assert result == test_result, "%s != %s" % (result, test_result)
    test_string = 'a=b c="{{" d=\'}}\''
    test

# Generated at 2022-06-11 06:24:35.854781
# Unit test for function split_args
def test_split_args():
    # Some basic tests and example of how to use

    # Simple string with no jinja2 or quotes
    assert split_args("a=b c=d") == ['a=b', 'c=d']

    # String with jinja2 blocks
    assert split_args("a={{ foo }} b={{ bar }}") == ['a={{ foo }}', 'b={{ bar }}']

    # String with mixed quotes and jinja2
    assert split_args("a='{{ foo }}' b=\"{{ bar }}\"") == ['a=\'{{ foo }}\'', 'b="{{ bar }}"']

    # String with mixed quotes and escaped quotes
    assert split_args("a='\\'foo\\'' b=\"\\\"bar\\\"\"") == ['a=\'\\\'foo\\\'\'', 'b="\\"bar\\""']

   

# Generated at 2022-06-11 06:24:45.931861
# Unit test for function split_args
def test_split_args():
    '''
    unittest for function split_args
    '''

# Generated at 2022-06-11 06:24:51.497287
# Unit test for function split_args

# Generated at 2022-06-11 06:25:49.826321
# Unit test for function split_args
def test_split_args():
    '''
    Unittest for split_args, which is used in the module
    code to split command line arguments from play content
    '''
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" \"\"") == ['a=b', 'c="foo bar"', '""']
    assert split_args("a=b c=\"foo bar\" \"\" d=''") == ['a=b', 'c="foo bar"', '""', "d=''"]

# Generated at 2022-06-11 06:25:57.101258
# Unit test for function split_args

# Generated at 2022-06-11 06:26:05.452228
# Unit test for function split_args
def test_split_args():

    def __compare_result_to_expectation(testname, result, expectation):
        if len(result) != len(expectation):
            raise Exception("testcase '%s' failed, result length %d not same as expectation %d" % (testname, len(result), len(expectation)))
        for idx, expect in enumerate(expectation):
            if result[idx] != expect:
                raise Exception("testcase '%s' failed, result item %d did not match expectation at same index (%s != %s)" % (testname, idx, result[idx], expect))


# Generated at 2022-06-11 06:26:13.344576
# Unit test for function split_args
def test_split_args():
    assert split_args("this is a test") == ["this", "is", "a", "test"]
    assert split_args("'this is a test'") == ["'this is a test'"]
    assert split_args("'this is a test' 'this is also a test'") == ["'this is a test'", "'this is also a test'"]
    assert split_args("'this is a test' \"this is also a test\"") == ["'this is a test'", "\"this is also a test\""]
    assert split_args("'this is a test\"") == ["'this", "is", "a", "test\""]
    assert split_args("\"this is a test'") == ["\"this", "is", "a", "test'"]

# Generated at 2022-06-11 06:26:22.102934
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils._text import to_bytes, to_text

    # we define a list of expected results, each item is a tuple, with the first item being the
    # original list of params and the second item being the split params
    # ansible modules that frequently use complex args are tested, yum, copy and fetch

    # if the expected result is a string, we assume it is an error

# Generated at 2022-06-11 06:26:28.753589
# Unit test for function split_args
def test_split_args():
    ''' test_split_args

    test the split_args function by checking the expected output
    of many different cases and then counting the number of arguments
    in the result and making sure it matches the expected value.
    '''

    # first, a simple case
    simple_args = 'ansible all -m ping'
    simple_count = 3
    simple_params = split_args(simple_args)
    assert(len(simple_params) == simple_count)

    # now let's pass it some args with jinja2 templating
    print_args = 'ansible all -m systemd -a "name={{ foo }} state=restarted"'
    print_count = 4
    print_params = split_args(print_args)
    assert(len(print_params) == print_count)

    # now some args with a complex

# Generated at 2022-06-11 06:26:37.654695
# Unit test for function split_args
def test_split_args():

    def assert_split_args(input_str, output_str):
        assert ' '.join(split_args(input_str)) == output_str

    assert_split_args("foo bar", 'foo bar')
    assert_split_args("foo bar baz", 'foo bar baz')
    assert_split_args("foo 'bar baz'", "foo 'bar baz'")
    assert_split_args("foo 'bar baz", "foo 'bar baz")
    assert_split_args("foo '{{ bar }", "foo '{{ bar }")
    assert_split_args("foo '{{ bar }}'", "foo '{{ bar }}'")
    assert_split_args("foo '{{ bar }}' baz", "foo '{{ bar }}' baz")

# Generated at 2022-06-11 06:26:46.784051
# Unit test for function split_args
def test_split_args():
    # Test a single arg
    assert split_args("a=b") == ["a=b"]

    # Test multiple args
    assert split_args("a=b c=d") == ["a=b", "c=d"]

    # Test an arg with whitespace
    assert split_args("a=b c='foo bar'") == ["a=b", "c='foo bar'"]

    # Test an arg with a quote
    assert split_args("a=b c='foo bar'") == ["a=b", "c='foo bar'"]

    # Test an arg with a backslash-escaped quote
    assert split_args("a=b c='foo \"bar\"'") == ["a=b", "c='foo \"bar\"'"]

    # Test an arg with a backslash at the end

# Generated at 2022-06-11 06:26:54.740894
# Unit test for function split_args
def test_split_args():
    ''' tests to make sure that we parse arguments as we expect '''

    class ArgTester(object):
        def __init__(self, test_name, input_args, expected):
            self.test_name = test_name
            self.input_args = input_args
            self.expected = expected
            self.output = None

        def assertEqual(self, a, b, msg=None):
            if a != b:
                print("ERROR: %s: '%s' != '%s' %s" % (self.test_name, a, b, msg or ''))

        def assertTrue(self, a, msg=None):
            if not a:
                print("ERROR: %s: '%s' is not True %s" % (self.test_name, a, msg or ''))


# Generated at 2022-06-11 06:27:03.068982
# Unit test for function split_args