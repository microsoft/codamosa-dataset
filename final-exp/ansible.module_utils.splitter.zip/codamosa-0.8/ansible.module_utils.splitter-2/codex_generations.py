

# Generated at 2022-06-11 06:18:09.504370
# Unit test for function unquote
def test_unquote():
    assert 'abc' == unquote('abc')
    assert 'abc' == unquote('"abc"')
    assert 'ab"c' == unquote('"ab"c"')
    assert 'ab\'c' == unquote('"ab\'c"')
    assert 'ab\'c' == unquote('\'ab\\\'c\'')

# make the test module discoverable
test_unquote.__module__ = __name__


# Generated at 2022-06-11 06:18:19.932264
# Unit test for function unquote
def test_unquote():

    # check if unquote(data) returns data if:
    # string is empty
    # string length is 1
    # string doesn't start/end with the same quote
    # string doesn't start/end with quote

    assert unquote("") == ""
    assert unquote("'") == "'"
    assert unquote("\"") == "\""
    assert unquote("abcd") == "abcd"
    assert unquote("''abcd''") == "''abcd''"
    assert unquote("\"abcd\"") == "\"abcd\""
    assert unquote("'\"abcd\"'") == "'\"abcd\"'"

    # check if unquote(data) removes first and last quotes from a string if:
    # string starts and ends with a single quote
    # string starts and ends with a double quote
    # string starts

# Generated at 2022-06-11 06:18:31.243467
# Unit test for function split_args
def test_split_args():

    # given a list of input strings and the correct output
    # strings, make sure we get the right output when we
    # use the split_args function on the input
    tests = dict()

    tests['simple_args'] = dict(
        given="a=b c=d",
        expects=['a=b', 'c=d']
    )

    tests['quoted_space'] = dict(
        given='a=b c="foo bar"',
        expects=['a=b', 'c="foo bar"']
    )

    tests['nested_jinja'] = dict(
        given="a=b c='foo {{ bar }}'",
        expects=["a=b", "c='foo {{ bar }}'"]
    )


# Generated at 2022-06-11 06:18:41.675442
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("'a=b c=d'") == ['a=b c=d']
    assert split_args("a='b c=d'") == ['a=b c=d']
    assert split_args("a=b c='d e=f'") == ['a=b', 'c=d e=f']
    assert split_args("a=b c='d e=f' g=h") == ['a=b', 'c=d e=f', 'g=h']
    assert split_args("a={{ x }} b={{ y }}") == ['a={{ x }}', 'b={{ y }}']

# Generated at 2022-06-11 06:18:54.275916
# Unit test for function split_args
def test_split_args():
    args = "a=b c='foo bar' d='foo bar'{{baz}}' e={foo} f={{ foo }} g={{foo}} h=foo{{ bar }}baz i=foo{{bar}}baz j={{foo}}{{bar}} k={{foo}} l=foo{{bar}} m='foo{{bar}}' n=foo\\\n{{bar}}"

# Generated at 2022-06-11 06:18:58.658127
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted("\"hello\"")
    assert not is_quoted("'hello")
    assert not is_quoted("\"hello")
    assert not is_quoted("hello\"")
    assert not is_quoted("hello'")
    assert not is_quoted("hello")


# Generated at 2022-06-11 06:19:11.070943
# Unit test for function split_args
def test_split_args():
    # Run the split_args function through its paces to make sure
    # all edge cases are handled properly

    # test simple case
    result = split_args('foo bar baz')
    assert result == ['foo', 'bar', 'baz']

    # test quoted arg
    result = split_args('foo="bar baz"')
    assert result == ['foo="bar baz"']

    # test quoted arg with trailing quote
    result = split_args('foo="bar baz')
    assert result == ['foo="bar', 'baz']

    # test nested quotes
    result = split_args('foo="bar \'baz\' boo"')
    assert result == ['foo="bar \'baz\' boo"']

    # test nested quotes with trailing quotes
    result = split_args('foo="bar \'baz"')

# Generated at 2022-06-11 06:19:20.942010
# Unit test for function split_args
def test_split_args():
    import pytest


# Generated at 2022-06-11 06:19:30.950595
# Unit test for function split_args
def test_split_args():
    '''
    # TODO: add more tests for bad data
    '''

    def t(i, o):
        assert split_args(i) == o

    t('a=b c="foo    bar"', ['a=b', 'c="foo    bar"'])
    t('a=b c="foo\\ bar"', ['a=b', 'c="foo bar"'])
    t('a=b c="foo\\\\ bar"', ['a=b', 'c="foo\\\\ bar"'])
    t('a=b c=\\"foo bar\\"', ['a=b', 'c="foo bar"'])
    t('a=b c=\\"foo bar\\\\\\"', ['a=b', 'c="foo bar\\'])

# Generated at 2022-06-11 06:19:35.632650
# Unit test for function unquote
def test_unquote():
    assert None == None
    assert "abc" == unquote(unquote("abc"))
    assert "'abc'" == unquote("'abc'")
    assert "\"abc\"" == unquote("\"abc\"")
    assert "a'b\"c" == unquote("a'b\"c")
    assert "a\"b'c" == unquote("a\"b'c")


# Generated at 2022-06-11 06:19:54.467997
# Unit test for function split_args
def test_split_args():

    def assert_args(args, expected):
        got = split_args(args)
        assert got == expected, "split_args('%s') got: %s expected: %s" % (args, got, expected)

    assert_args("", [])
    assert_args("a", ["a"])
    assert_args(" 'a'", ["'a'"])
    assert_args(" 'a' ", ["'a'"])
    assert_args(" 'a'\t", ["'a'"])
    assert_args(" 'a'\t  ", ["'a'"])
    assert_args("a=b c=d", ['a=b', 'c=d'])
    assert_args("a=b 'c d'", ['a=b', "'c d'"])

# Generated at 2022-06-11 06:20:02.868408
# Unit test for function split_args

# Generated at 2022-06-11 06:20:10.014913
# Unit test for function split_args

# Generated at 2022-06-11 06:20:19.367451
# Unit test for function split_args
def test_split_args():
    '''
    unit tests for the split_args function
    '''


# Generated at 2022-06-11 06:20:30.547234
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', "c=\"foo bar\""]
    assert split_args(' a=b c="foo bar" ') == ['a=b', "c=\"foo bar\""]
    assert split_args('a=b c="foo bar"\nd=e f="hi \"quoted string\" there"') == ['a=b', "c=\"foo bar\"", 'd=e', 'f="hi \"quoted string\" there"']
    assert split_args('a=b c="foo\nbar"') == ['a=b', "c=\"foo\nbar\""]

# Generated at 2022-06-11 06:20:39.106776
# Unit test for function split_args
def test_split_args():
    # simple test of passing in a string and returning a list of args
    # args are split on whitespace currently
    assert split_args("a=b c=d e=f") == ['a=b', 'c=d', 'e=f']

    # this test ensures that we can split on spaces inside quotes
    assert split_args("a=b c='foo bar' e=f") == ['a=b', "c='foo bar'", 'e=f']

    # one more for the road, ensure we can do double quotes too
    assert split_args("a=b c=\"foo bar\" e=f") == ['a=b', 'c="foo bar"', 'e=f']

    # make sure we can handle string args that are jinja2 blocks
    assert split_args("a=b c='{{ foo }}' e=f")

# Generated at 2022-06-11 06:20:49.771491
# Unit test for function split_args
def test_split_args():
    import sys
    import os
    path = os.path.dirname(sys.modules[__name__].__file__)
    path = path + "/unittests/files/test_split_args.txt"
    # read in test file
    f = open(path, 'r')
    lines = f.read().splitlines()
    f.close()

    # first line is the raw input string
    raw_input = lines[0]
    # second line is the expected result
    expected_result = lines[1].split(' ')
    # third line is the expected result after being unquoted
    expected_unquote = lines[2].split(' ')

    # run the function and split that result on spaces
    result = split_args(raw_input)
    # assert that the results match the expected result

# Generated at 2022-06-11 06:21:00.046401
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='d e'") == ['a=b', "c='d e'"]
    assert split_args("a=b c=\"d e\"") == ['a=b', 'c="d e"']
    assert split_args("cmd 'this is a single arg'") == ["cmd", "this is a single arg"]
    assert split_args("cmd \"this is a single arg\"") == ["cmd", "this is a single arg"]
    assert split_args("cmd \"this is \\\"a single\\\" arg\"") == ['cmd', '"this is \\\"a single\\\" arg"']
    assert split_args("cmd 'this is \\'a single\\' arg'") == ["cmd", "'this is \\'a single\\' arg'"]

# Generated at 2022-06-11 06:21:07.766953
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar\\" d="blah blah"') == ['a=b', 'c="foo bar"', 'd="blah blah"']

# Generated at 2022-06-11 06:21:18.053127
# Unit test for function split_args
def test_split_args():
    """
    [ Split args tests ]
    """

# Generated at 2022-06-11 06:21:44.891824
# Unit test for function split_args

# Generated at 2022-06-11 06:21:56.008081
# Unit test for function split_args
def test_split_args():
    # Test simple args
    args = 'a=b c=d'
    params = split_args(args)
    assert params == ['a=b', 'c=d']

    # Test args split over multiple lines and spaces
    args = 'a=b\nc = d'
    params = split_args(args)
    assert params == ['a=b\n', 'c', '=', 'd']

    # Test args containing quotes
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test args containing quotes and split across multiple lines
    args = "a=b \\\nc='foo bar'"
    params = split_args(args)

# Generated at 2022-06-11 06:22:03.554313
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']


if __name__ == "__main__":
    import sys
    import unittest
    import warnings

    testloader = unittest.TestLoader()
    all_tests = testloader.discover('tests', pattern='test_*.py')
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(all_tests)
    if result.wasSuccessful():
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-11 06:22:11.325476
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar "spam eggs"') == ['foo', 'bar', '"spam eggs"']
    assert split_args('foo="bar bar" baz=\'spam spam\'') == ['foo="bar bar"', "baz='spam spam'"]
    assert split_args('{{ foo }}') == ['{{ foo }}']
    assert split_args('{{ foo }}\n{{ bar }}') == ['{{ foo }}\n', '{{ bar }}']
    assert split_args('{{ foo }}{{ bar }}') == ['{{ foo }}{{ bar }}']

# Generated at 2022-06-11 06:22:21.966005
# Unit test for function split_args
def test_split_args():
    '''
    The goal of these tests is to make sure that we generate the same
    list of parameters for various arg strings, regardless of how much
    white space is used or if a new line is added.
    '''

    # each tuple is an arg string, followed by an expected list


# Generated at 2022-06-11 06:22:25.911515
# Unit test for function split_args
def test_split_args():
    # Basic normal quoting
    assert split_args('"foo bar" baz') == ['foo bar', 'baz']
    assert split_args("'foo bar' baz") == ['foo bar', 'baz']
    assert split_args("foo='bar baz'") == ["foo='bar baz'"]

    # Extra quoting should be stripped
    assert split_args('"foo bar" baz') == ["foo bar", "baz"]
    assert split_args("'foo bar' baz") == ["foo bar", "baz"]

    # Other tokens should be preserved
    assert split_args('foo bar=baz') == ['foo', 'bar=baz']
    assert split_args('foo bar="baz bang"') == ['foo', 'bar="baz bang"']

    # Quotes in the middle of a token should be

# Generated at 2022-06-11 06:22:36.078194
# Unit test for function split_args
def test_split_args():
    '''
    split_args unit test
    '''
    import sys
    from difflib import unified_diff

    # strips ansi color codes from output strings
    ansi_escape = re.compile(r'\x1b[^m]*m')

    def do_test(test_case):
        # each test case is a tuple containing:
        #   test data,
        #   whether test is expected to raise an exception,
        #   expected result,
        #   expected stderr (if exception is not expected)
        test_data, should_raise, expected_result, expected_stderr = test_case

        # redirect sys.stderr since we want to test it too
        old_stderr = sys.stderr
        sys.stderr = temp_err = tempfile.TemporaryFile()



# Generated at 2022-06-11 06:22:43.388972
# Unit test for function split_args
def test_split_args():

    # Test single bare word
    assert split_args('foo') == [u"foo"]

    # Test quoting for single arg
    assert split_args('"foo"') == [u'foo']
    assert split_args("'foo'") == [u'foo']

    # Test multiple args
    assert split_args('foo bar') == [u'foo', u'bar']
    assert split_args('"foo" bar') == [u'foo', u'bar']
    assert split_args('foo "bar"') == [u'foo', u'bar']
    assert split_args('foo "bar" baz') == [u'foo', u'bar', u'baz']
    assert split_args('foo "bar baz"') == [u'foo', u'bar baz']

# Generated at 2022-06-11 06:22:53.651945
# Unit test for function split_args
def test_split_args():
    result = split_args('a="b c" d="e f"')
    assert result == ['a="b c"', 'd="e f"']
    result = split_args("a='b c' d='e f'")
    assert result == ["a='b c'", "d='e f'"]
    result = split_args('a="b\"c" d="e\'f"')
    assert result == ['a="b\"c"', "d=\"e'f\""]
    result = split_args("a='b\"c' d='e\'f'")
    assert result == ['a=\'b"c\'', "d='e\\'f'"]
    result = split_args("a='b\"c' d='e\\'f'")

# Generated at 2022-06-11 06:23:03.451908
# Unit test for function split_args
def test_split_args():
    import pytest


# Generated at 2022-06-11 06:24:00.505241
# Unit test for function split_args
def test_split_args():
    ''' test for split_args '''

# Generated at 2022-06-11 06:24:10.898338
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import unittest
    import sys
    import ntpath

    class TestSplitArgs(unittest.TestCase):

        def test_quotes(self):
            self.assertEqual(split_args("a=b c='foo bar'"), ['a=b', "c='foo bar'"])

        def test_newlines(self):
            if sys.version_info < (3, 0):
                self.assertEqual(split_args("a=b\nc='foo bar'"), ['a=b\n', "c='foo bar'"])
            else:
                self.assertEqual(split_args("a=b\nc='foo bar'"), ['a=b', "c='foo bar'"])

        def test_line_continuation(self):
            self.assertE

# Generated at 2022-06-11 06:24:21.363121
# Unit test for function split_args
def test_split_args():
    ''' unit tests for the split_args function '''

    inputs = dict()
    inputs['a=b c="foo bar"'] = ['a=b', 'c="foo bar"']
    inputs['a=b c=foo\\ bar'] = ['a=b', 'c=foo bar']
    inputs['a=b c=\\"foo bar\\"'] = ['a=b', 'c="foo bar"']
    inputs['a=b c=\\"foo bar\"'] = ['a=b', 'c="foo bar"']
    inputs['a=b c=\\\'foo bar\\\''] = ['a=b', 'c=\'foo bar\'']
    inputs['a=b c=\\\'foo bar\\\''] = ['a=b', 'c=\'foo bar\'']

# Generated at 2022-06-11 06:24:28.340881
# Unit test for function split_args
def test_split_args():
    ''' Unit test for function split_args '''
    import sys
    import traceback
    import jinja2
    from ansible import constants as C
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Make a meta-test. We're going to test a bunch of tests, and
    # catch any unexpected exceptions. If we get one, we'll dump
    # the test info, so the problem can be fixed.

# Generated at 2022-06-11 06:24:37.924808
# Unit test for function split_args
def test_split_args():
    # Test regular arguments
    assert split_args("foo bar") == ['foo', 'bar']
    # Test equal sign, nested quotes and backslash
    assert split_args("foo='bar baz' \\") == ["foo='bar baz' \\"]
    # Test backslash and quotes
    assert split_args("foo\\\\'bar\\'baz'") == ["foo\\\\'bar\\'baz'"]
    # Test nested quotes, and equal sign
    assert split_args("foo='bar \" baz'") == ["foo='bar \" baz'"]
    # Test single quotes, backslashes and equal signs
    assert split_args("foo='bar baz' \\'") == ["foo='bar baz' \\'"]
    # Test double quotes, nested single quotes and equal signs

# Generated at 2022-06-11 06:24:48.088272
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']
    args = 'a=b c="foo \n bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo', '', 'bar"']
    args = 'a=b c="foo \n bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo', '', 'bar"']
    args = '''a=b c="foo
            bar"'''
    params = split_args(args)
    assert params == ['a=b', 'c="foo', '', 'bar"']
    args = '''a=b c="foo
            bar"'''


# Generated at 2022-06-11 06:24:57.284396
# Unit test for function split_args

# Generated at 2022-06-11 06:25:07.223852
# Unit test for function split_args
def test_split_args():
    ''' unit test for parser split args'''
    # '''

# Generated at 2022-06-11 06:25:13.549322
# Unit test for function split_args
def test_split_args():

    # first test, make sure we correctly handle no argument case
    try:
        split_args("")
        raise Exception("error handling no argument case")
    except:
        pass

    # second test, make sure we correctly handle simple case
    argv = split_args("foo=bar baz=jazz")
    if argv != ['foo=bar', 'baz=jazz']:
        raise Exception("Failed to handle simple case")

    # third test, make sure we correctly handle quoted case
    argv = split_args("foo='bar baz'")
    if argv != ['foo=\'bar baz\'']:
        raise Exception("Failed to handle quoted case")

    # forth test, make sure we correctly handle quoted case with spaces
    argv = split_args("foo='bar baz' bar='foo baz'")


# Generated at 2022-06-11 06:25:21.979453
# Unit test for function split_args

# Generated at 2022-06-11 06:27:48.967035
# Unit test for function split_args

# Generated at 2022-06-11 06:27:57.056681
# Unit test for function split_args