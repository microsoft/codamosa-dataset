

# Generated at 2022-06-11 06:18:09.502703
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'hello world'") == True)
    assert(is_quoted('"hello world"') == True)
    assert(is_quoted("'hello world") == False)
    assert(is_quoted("hello world'") == False)
    assert(is_quoted("hello world") == False)


# Generated at 2022-06-11 06:18:16.433474
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"fo\'o"') == 'fo\'o'
    assert unquote('\'fo"o\'') == 'fo"o'
    assert unquote('"foo') == 'foo'
    assert unquote('foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('') == ''

# Generated at 2022-06-11 06:18:23.406095
# Unit test for function split_args

# Generated at 2022-06-11 06:18:31.350795
# Unit test for function is_quoted
def test_is_quoted():
    print("test_is_quoted:")
    assert not is_quoted("")
    assert not is_quoted(" ")
    assert not is_quoted("r")
    assert is_quoted("'r'")
    assert is_quoted("\"r\"")
    assert not is_quoted("'r")
    assert not is_quoted("r'")
    assert not is_quoted("\"r")
    assert not is_quoted("r\"")



# Generated at 2022-06-11 06:18:41.701662
# Unit test for function split_args

# Generated at 2022-06-11 06:18:47.569075
# Unit test for function is_quoted
def test_is_quoted():
    assert(not is_quoted("')"))
    assert(not is_quoted("'"))
    assert(is_quoted("'string'"))
    assert(is_quoted('"string"'))
    assert(is_quoted('"string'))
    assert(not is_quoted('string'))


# Generated at 2022-06-11 06:18:57.940701
# Unit test for function split_args
def test_split_args():
    '''
    Basic test for the split args function
    '''

    def test(input_string, expected_output):
        output = split_args(input_string)
        if output != expected_output:
            raise Exception("split_args() test failed. expected output=%s, actual output=%s" % (expected_output, output))

    test("{{ foo }}\n{{ foo }}", ["{{ foo }}\n{{ foo }}"])
    test("{{ foo }}\n\n{{ foo }}", ["{{ foo }}\n", "\n", "{{ foo }}"])
    test("{{ foo }}\\\n{{ foo }}", ["{{ foo }}\n", "{{ foo }}"])
    test("{{ foo }} \\\n{{ foo }}", ["{{ foo }} \n", "{{ foo }}"])

# Generated at 2022-06-11 06:19:02.580804
# Unit test for function unquote
def test_unquote():
    assert (unquote('"abc"') == 'abc')
    assert (unquote('abc') == 'abc')
    assert (unquote("'abc'") == 'abc')
    assert (unquote("'a'bc'") == "'a'bc'")



# Generated at 2022-06-11 06:19:13.754294
# Unit test for function split_args
def test_split_args():
    assert len(split_args("")) == 0
    assert split_args("") == []
    assert split_args(" ") == []
    assert split_args("a") == ["a"]
    assert split_args(" a ") == ["a"]
    assert split_args("a=") == ["a="]
    assert split_args("a= ") == ["a="]
    assert split_args("a =") == ["a"]
    assert split_args("a = ") == ["a"]
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b ") == ["a=b"]
    assert split_args(" a=b") == ["a=b"]
    assert split_args("a=b c") == ["a=b", "c"]

# Generated at 2022-06-11 06:19:24.963253
# Unit test for function split_args

# Generated at 2022-06-11 06:19:45.180650
# Unit test for function split_args
def test_split_args():
    
    assert split_args('') == []
    assert split_args('a=1') == ['a=1']
    assert split_args('a=1 b=2') == ['a=1', 'b=2']
    assert split_args('a=1 b=2 c="foo bar"') == ['a=1', 'b=2', 'c="foo bar"']
    assert split_args('a=1 b=2 c="foo bar" d="foo\\"bar" e=\'foo\\\'bar\'') == ['a=1', 'b=2', 'c="foo bar"', 'd="foo\\"bar"', "e='foo\\'bar'"]
    assert split_args("a=1 b='1 2'") == ['a=1', "b='1 2'"]

# Generated at 2022-06-11 06:19:51.262160
# Unit test for function split_args
def test_split_args():
    test_string = "foo=bar baz=\"{{ foo }}\""
    result = split_args(test_string)
    assert result == ['foo=bar', 'baz="{{', 'foo', '}}"'], "result was: %s" % result

    test_string = "foo=bar baz=\"{{ foo }\""
    try:
        split_args(test_string)
    except Exception:
        pass
    else:
        assert False, "split_args did not raise an exception"

# Generated at 2022-06-11 06:19:57.750129
# Unit test for function split_args
def test_split_args():
    raises = False
    try:
        split_args("{{foo}}")
    except:
        raises = True
    assert raises == True

    test1 = split_args("a=b c='foo bar'")
    assert test1 == ['a=b', "c='foo bar'"]

    test2 = split_args("a='foo bar'")
    assert test2 == ["a='foo bar'"]

    test3 = split_args("a='foo bar' b='foo bar'")
    assert test3 == ["a='foo bar'", "b='foo bar'"]

    test4 = split_args("a=b c='foo bar'")
    assert test4 == ['a=b', "c='foo bar'"]

    test5 = split_args("a=b c=\"foo bar\"")

# Generated at 2022-06-11 06:20:04.068733
# Unit test for function split_args
def test_split_args():
    # expected result
    expected = ['module:', 'name:', 'foo', 'arg1=true', 'arg2={{var.value}}', 'arg3={{ lookup("pipe", "echo foo") }}']
    # test input
    test_input = 'module: name: foo arg1=true arg2={{var.value}} arg3={{ lookup("pipe", "echo foo") }}'
    # run the test
    result = split_args(test_input)
    # assert that the result is as expected
    assert result == expected



# Generated at 2022-06-11 06:20:12.043199
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']
    assert split_args('a=b c="foo\n\nbar"') == ['a=b', 'c="foo\n\nbar"']
    assert split_args('a=b c="foo\\n\\nbar"') == ['a=b', 'c="foo\\n\\nbar"']
    assert split_args('a=b c="foo\n\\\nbar"') == ['a=b', 'c="foo\n\\\nbar"']
    assert split_args('a=b c="foo\n\\\nbar"\nd=1')

# Generated at 2022-06-11 06:20:22.119216
# Unit test for function split_args
def test_split_args():
    """test_split_args"""

    data = 'first=1 second=2 third="3d" fourth={foo : \'bar\'}'
    tokens = ['first=1', 'second=2', 'third="3d"', "fourth={foo : 'bar'}"]
    assert split_args(data) == tokens

    data = "{{ ansible_managed }} name=test\n foo=4 bar=\"3d\"\n"
    tokens = ['{{', 'ansible_managed', '}} name=test\n', 'foo=4', 'bar="3d"\n']
    assert split_args(data) == tokens

    data = "{{ ansible_managed }} name=test\n foo=4 bar=\"3d\"\\\n"

# Generated at 2022-06-11 06:20:33.355746
# Unit test for function split_args
def test_split_args():
    # Use the `assert` keyword to write tests
    # All code under the assert is executed, if it throws an exception then the test fails

    t = False
    try:
        params = split_args("a=b c={{ foo }}")
        t = True
    except Exception as e:
        print("unexpected failure in split_args for simple test: %s" % e)

    assert t, "expected test to succeed"

    t = False
    try:
        params = split_args("a=b c=\"{{ foo }}\"")
        t = True
    except Exception as e:
        print("unexpected failure in split_args for simple test: %s" % e)

    assert t, "expected test to succeed"

    t = False

# Generated at 2022-06-11 06:20:40.499935
# Unit test for function split_args
def test_split_args():
    '''unit test for ansible.utils.split_args'''
    from ansible.compat.tests import unittest

    class TestSplitArgs(unittest.TestCase):

        # Basic tests
        def test_basic_A(self):
            ''' args is just a string, split on space '''
            args = 'foo bar'
            split_args(args)

        def test_basic_B(self):
            ''' args is a string with quotes and spaces '''
            args = 'foo bar "foo bar" "foo bar"'
            split_args(args)

        def test_basic_C(self):
            ''' args is a string with multiple jinja2 blocks '''
            args = 'foo bar {{ foo }} {{ bar }}'
            split_args(args)


# Generated at 2022-06-11 06:20:51.111933
# Unit test for function split_args

# Generated at 2022-06-11 06:21:01.172431
# Unit test for function split_args
def test_split_args():
    test_string = ""
    assert split_args(test_string) == []
    test_string = "  "
    assert split_args(test_string) == []
    test_string = "test"
    assert split_args(test_string) == ['test']
    test_string = "test test"
    assert split_args(test_string) == ['test', 'test']
    test_string = "test \"test\" test"
    assert split_args(test_string) == ['test', '"test"', 'test']
    test_string = "\"test test\""
    assert split_args(test_string) == ['"test test"']
    test_string = "'test test'"
    assert split_args(test_string) == ["'test test'"]
    test_string = "\"test test"


# Generated at 2022-06-11 06:21:26.230113
# Unit test for function split_args

# Generated at 2022-06-11 06:21:31.700659
# Unit test for function split_args

# Generated at 2022-06-11 06:21:41.383183
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule

    def test_args(args, expected, test_run=False):
        module = AnsibleModule(argument_spec=dict())
        result = {}
        try:
            result['split_args'] = split_args(args)
            result['rc'] = 0
        except Exception as e:
            result['msg'] = str(e)
            result['rc'] = 1

        result['changed'] = False
        if expected != result['split_args']:
            result['failed'] = True
            expected_string = ','.join(expected)
            result['msg'] = "expected " + expected_string + " got " + ','.join(result['split_args']) + \
                            " for input: " + str(args)

# Generated at 2022-06-11 06:21:48.529986
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('"') == ['"']
    assert split_args('" "') == ['" "']
    assert split_args('abc') == ['abc']
    assert split_args('"a b c"') == ['"a b c"']
    assert split_args('"a b c') == ['"a', 'b', 'c']
    assert split_args('a b c"') == ['a', 'b', 'c"']
    assert split_args('"a" "b" "c"') == ['"a"', '"b"', '"c"']
    assert split_args('a "b b" c') == ['a', '"b b"', 'c']

# Generated at 2022-06-11 06:21:59.789908
# Unit test for function split_args

# Generated at 2022-06-11 06:22:09.053132
# Unit test for function split_args

# Generated at 2022-06-11 06:22:19.340170
# Unit test for function split_args
def test_split_args():
    assert split_args('''a=b c="foo bar"''') == ['a=b', 'c="foo bar"']
    assert split_args('''a=b c="foo bar" ''') == ['a=b', 'c="foo bar"']
    assert split_args('''a=b c="foo bar" ''') == ['a=b', 'c="foo bar"']
    assert split_args('''a=b c="foo bar"''') == ['a=b', 'c="foo bar"']
    assert split_args('''a=b \\\nc="foo bar"''') == ['a=b', 'c="foo bar"']
    assert split_args('''a=b \
c="foo bar"''') == ['a=b', 'c="foo bar"']
   

# Generated at 2022-06-11 06:22:29.742126
# Unit test for function split_args
def test_split_args():
    '''
    Test spliting arguments by spaces and by nested jinja2 blocks
    '''

    # define the list of tests and their expected results

# Generated at 2022-06-11 06:22:39.288496
# Unit test for function split_args

# Generated at 2022-06-11 06:22:48.910408
# Unit test for function split_args
def test_split_args():
    # Tests for split_args
    #simple args
    s = "a b c d e"
    assert split_args(s) == ["a","b","c","d","e"]
    #assignments
    s = "a=b c=d e=f"
    assert split_args(s) == ["a=b","c=d","e=f"]
    #assignments with spaces
    s = "a = b c = d e = f"
    assert split_args(s) == ["a = b","c = d","e = f"]
    #assignments with quotes
    s = "a='b c' d='e f'"
    assert split_args(s) == ["a='b c'","d='e f'"]
    #assignments with double quotes

# Generated at 2022-06-11 06:23:29.476131
# Unit test for function split_args
def test_split_args():
    # Test 1
    test_args = 'key1=value1 key2=value2'
    result = split_args(test_args)

    assert result[0] == 'key1=value1'
    assert result[1] == 'key2=value2'
    print("Test 1 passed")

    # Test 2
    test_args = '''key1=value1 'key2=value2' "key3=value3" '''
    result = split_args(test_args)

    assert result[0] == 'key1=value1'
    assert result[1] == "'key2=value2'"
    assert result[2] == '"key3=value3"'
    print("Test 2 passed")

    # Test 3

# Generated at 2022-06-11 06:23:39.842679
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == split_args("a=b c='foo bar'")
    #assert split_args('a=b c="foo bar" d="a=b c=\'foo bar\' e=\\"foobar\\"') == ['a=b', 'c=\'foo bar\'', 'e=\\"foobar\\"']
    assert split_args('a=b c="foo bar" d="a=b c=\'foo bar\' \e=\\"foobar\\"') == ['a=b', 'c="foo bar"', 'd="a=b', "c='foo bar'", 'e=\\"foobar\\"']

# Generated at 2022-06-11 06:23:49.284008
# Unit test for function split_args
def test_split_args():
    # assemble a list of tests
    test_data = []
    test_data.append((
        "foo=bar baz='hello world'",
        ['foo=bar', "baz='hello world'"],
    ))

    test_data.append((
        "foo=bar 'hello world' baz=quux",
        ['foo=bar', "'hello world'", "baz=quux"],
    ))

    test_data.append((
        "foo=bar \"hello world\" baz=quux",
        ['foo=bar', '"hello world"', "baz=quux"],
    ))

    test_data.append((
        "foo=bar 'hello world baz=quux",
        ['foo=bar', "'hello world baz=quux"],
    ))


# Generated at 2022-06-11 06:23:59.668397
# Unit test for function split_args

# Generated at 2022-06-11 06:24:10.208906
# Unit test for function split_args

# Generated at 2022-06-11 06:24:19.612301
# Unit test for function split_args

# Generated at 2022-06-11 06:24:27.638654
# Unit test for function split_args
def test_split_args():
    s = '''a=1 b="foo bar" "c d"="e f"'''
    assert split_args(s) == ['a=1', 'b="foo bar"', '"c d"="e f"']

    s = "a=1 b='foo bar' 'c d'='e f'"
    assert split_args(s) == ['a=1', "b='foo bar'", "'c d'='e f'"]

    s = '''a=1 b="foo bar" 'c d'="e f"'''
    assert split_args(s) == ['a=1', 'b="foo bar"', '\'c d\'="e f"']


# Generated at 2022-06-11 06:24:37.192860
# Unit test for function split_args

# Generated at 2022-06-11 06:24:47.389946
# Unit test for function split_args

# Generated at 2022-06-11 06:24:56.615091
# Unit test for function split_args

# Generated at 2022-06-11 06:26:35.932548
# Unit test for function split_args
def test_split_args():
    assert split_args("foo=bar biz={{ ansible_hostname }}") == ['foo=bar', 'biz={{ ansible_hostname }}']
    assert split_args("foo=bar biz={{ ansible_hostname }}\nboo=baz") == ['foo=bar', 'biz={{ ansible_hostname }}', 'boo=baz']
    assert split_args("foo='bar biz' baz={{{ {% if 1 == 2 %}hai{% endif %} }}}") == ['foo=\'bar biz\'', 'baz={{{ {% if 1 == 2 %}hai{% endif %} }}}']

# Generated at 2022-06-11 06:26:45.288542
# Unit test for function split_args
def test_split_args():
    # Use cases for split args:
    # Parameters broken on whitespace
    # Parameters with quotes and whitespace
    # Parameters with whitespace with single (') and double (") quotes
    # Parameters with whitespace with single and double quotes with jinja2

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']


# Generated at 2022-06-11 06:26:52.982285
# Unit test for function split_args
def test_split_args():
    # split_args should ignore line continuation character
    assert split_args('''a=b \
c=d''') == ['a=b', 'c=d']

    # split_args should ignore line continuation character when inside quotes
    assert split_args('''a=b \
"c=d"''') == ['a=b', '"c=d"']

    # split_args should put single quotes inside double quotes back together
    assert split_args('a="foo\'bar"') == ['a="foo\'bar"']

    # split_args should put double quotes inside single quotes back together
    assert split_args("a='foo\"bar'") == ["a='foo\"bar'"]

    # split_args should put single quotes inside single quotes back together

# Generated at 2022-06-11 06:27:01.093278
# Unit test for function split_args
def test_split_args():
    import sys
    import os
    import json

    test_file = os.getenv('ANSIBLE_MODULE_TEST')
    if test_file:
        with open(os.getenv('ANSIBLE_MODULE_TEST'), 'r') as test:
            results = json.load(test)
    else:
        print("No test file specified. Set ANSIBLE_MODULE_TEST to point to the test file you want to verify.")
        sys.exit(1)

    for line in results:
        output = split_args(line['input'])
        if output != line['output']:
            print("Failure on input: %s" % line['input'])
            print("Expected output: %s" % line['output'])
            print("Actual output: %s" % output)

# Generated at 2022-06-11 06:27:09.152634
# Unit test for function split_args

# Generated at 2022-06-11 06:27:17.816389
# Unit test for function split_args

# Generated at 2022-06-11 06:27:25.995016
# Unit test for function split_args
def test_split_args():
    # Basic checks
    args = ""
    assert split_args(args) == []

    args = "foo bar baz"
    assert split_args(args) == ["foo", "bar", "baz"]

    # Quotes
    args = "foo='bar baz'"
    assert split_args(args) == ["foo='bar baz'"]

    args = "foo=\"bar baz\""
    assert split_args(args) == ["foo=\"bar baz\""]

    args = 'foo="bar baz"'
    assert split_args(args) == ["foo=\"bar baz\""]

    args = "foo=\"bar 'baz'\""
    assert split_args(args) == ["foo=\"bar 'baz'\""]

    args = "foo=\"bar \"\"baz\"\"\""
    assert split_args

# Generated at 2022-06-11 06:27:35.559271
# Unit test for function split_args
def test_split_args():
    if not split_args("a='b c'"):
        raise Exception("Simple single-quoted param failed")
    if not split_args("a='b c'"):
        raise Exception("Simple double-quoted param failed")
    if not split_args("a='{{b}} c'"):
        raise Exception("Single-quote jinja2 template failed")
    if not split_args('a="{{b}} c"'):
        raise Exception("Double-quote jinja2 template failed")
    if not split_args('a="{{b}} c" "d {{foo}} e" f'):
        raise Exception("Nested double-quotes/jinja2 template failed")

# Generated at 2022-06-11 06:27:44.266115
# Unit test for function split_args
def test_split_args():
    # Test evaluation of unquoted values
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar "foo bar"') == ['foo', 'bar', '"foo bar"']
    assert split_args('foo bar "foo bar') == ['foo', 'bar', '"foo bar']
    assert split_args('"foo bar') == ['"foo', 'bar']
    assert split_args('"foo bar" "foo bar') == ['"foo bar"', '"foo bar']
    # Test evaluation of quoted values
    assert split_args("'foo bar'") == ['foo bar']
    assert split_args("foo 'foo bar'") == ['foo', 'foo bar']
    assert split_args("'foo bar' foo") == ['foo bar', 'foo']

# Generated at 2022-06-11 06:27:52.512489
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo     bar') == ['foo', 'bar']
    assert split_args('foo\nbar') == ['foo\n', 'bar']
    assert split_args('foo\nbar baz') == ['foo\n', 'bar', 'baz']
    assert split_args('foo bar\nbaz daz') == ['foo', 'bar\n', 'baz', 'daz']
    assert split_args('foo bar\n\\\nbaz daz') == ['foo', 'bar\n', '\\\n', 'baz', 'daz']
    assert split_args("foo  'bar baz'") == ['foo', "'bar baz'"]