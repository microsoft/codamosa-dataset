

# Generated at 2022-06-11 06:18:23.386389
# Unit test for function split_args
def test_split_args():

    # some normal values
    a = split_args("foo=foo")
    assert a == ["foo=foo"], a

    a = split_args("foo =  foo")
    assert a == ["foo=foo"], a

    a = split_args("foo=foo bar=bar")
    assert a == ["foo=foo", "bar=bar"], a

    a = split_args("foo='foo bar'")
    assert a == ["foo='foo bar'"], a

    a = split_args("foo=\"foo bar\"")
    assert a == ["foo=\"foo bar\""], a

    a = split_args("foo=\"foo bar\" bar='foo bar'")
    assert a == ["foo=\"foo bar\"", "bar='foo bar'"], a


# Generated at 2022-06-11 06:18:27.432376
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello')
    assert not is_quoted("hello")



# Generated at 2022-06-11 06:18:38.395304
# Unit test for function split_args

# Generated at 2022-06-11 06:18:46.097423
# Unit test for function split_args
def test_split_args():
    """ return a function to a unit test for function split_args """
    from ansible import errors
    import sys

    try:
        from test.support import cmp
    except ImportError:
        from commands import getstatusoutput        # module deprecated since Python 3.0

    allowable_exceptions = (errors.AnsibleParserError,)
    if sys.version_info[0] > 2:
        allowable_exceptions += (TypeError,)

    # start of unit test
    def test_split_args(self):
        """ unit test for function split_args """

        # Tests that don't throw errors and produce the expected output

# Generated at 2022-06-11 06:18:57.249052
# Unit test for function split_args
def test_split_args():
    params = {}
    params['str_spaces_only'] = ['\"a b c\"']
    params['str_spaces_only_2'] = ['"a b c"', '"def ghi"']
    params['str_spaces_only_3'] = ['"a b c"', '"def', 'ghi"']
    params['str_spaces_and_equals'] = ['"a b c"', 'foo=bar']
    params['str_spaces_and_equals_2'] = ['foo=bar', '"a b c"']
    params['str_spaces_and_equals_3'] = ['foo=bar', '"a b c"', 'bar=foo']

# Generated at 2022-06-11 06:19:03.254191
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("hello") == False
    assert is_quoted("'hello") == False
    assert is_quoted("'hello'") == True
    assert is_quoted('"hello"') == True
    assert is_quoted("'hel\"lo'") == True
    assert is_quoted("\"hel'lo\"") == True


# Generated at 2022-06-11 06:19:07.797056
# Unit test for function split_args
def test_split_args():

    def run_args(args):
        items = split_args(args)
        return " ".join(items)

    # test simple cases
    assert run_args("a b") == "a b"
    assert run_args("a") == "a"

    # test quotes inside args
    assert run_args("a b='foo bar'") == "a b='foo bar'"
    assert run_args('a b="foo bar"') == 'a b="foo bar"'
    assert run_args("a b=\"foo bar\"") == 'a b="foo bar"'
    assert run_args('a b="foo bar" c') == 'a b="foo bar" c'

    # test that quotes cannot be nested
    try:
        run_args('a b="foo "bar"')
        assert False
    except Exception:
        pass



# Generated at 2022-06-11 06:19:16.248874
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import unittest

    def check(args, expected_params):
        # ensure the args string specifies the expected params
        params = split_args(args)
        assert params == expected_params, "error splitting args: %s" % args

        # ensure the params can be concatentated back together to create the original args
        assert ' '.join(params) == args, "error splitting args: %s" % args

    class TestSplitArgs(unittest.TestCase):
        def test_split_args(self):
            check('"foo bar"', ['foo bar'])
            check('foo bar', ['foo', 'bar'])
            check('foo=bar', ['foo=bar'])
            check('foo=bar bam=baz', ['foo=bar', 'bam=baz'])


# Generated at 2022-06-11 06:19:27.842203
# Unit test for function split_args

# Generated at 2022-06-11 06:19:34.351282
# Unit test for function split_args
def test_split_args():
    '''
    example:

    input of:

    this is 'a test'

    should yield

    ['"this"', '"is"', '"a test"']
    '''

    args = "this is 'a test'"
    params = split_args(args)

    assert params[0] == '"this"'
    assert params[1] == '"is"'
    assert params[2] == '"a test"'

    args = "this 'is a tr'icky one"
    params = split_args(args)

    assert params[0] == '"this"'

# Generated at 2022-06-11 06:19:55.411527
# Unit test for function split_args

# Generated at 2022-06-11 06:20:04.238110
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.parsing.convert_bool import boolean

    # Ensure that the function is able to split args correctly
    # in some basic cases

# Generated at 2022-06-11 06:20:12.218699
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import ansible.constants as C

    u = AnsibleUnsafeText
    C.DEFAULT_HASH_BEHAVIOUR='replace'

    # Just make sure that the function itself runs through
    # If a test fails here, add it to the list
    def run_test(test):
        try:
            split_args(test[0])
        except Exception as e:
            print("Exception while running '%s'" % test[0])
            raise e


# Generated at 2022-06-11 06:20:22.300550
# Unit test for function split_args

# Generated at 2022-06-11 06:20:33.530041
# Unit test for function split_args
def test_split_args():
    ''' test split_args function '''
    # This test data is a list of pairs of input and output,
    # where the input is a string (usually a command line as
    # it would be typed by a user) and the output is a list
    # of params (as they might appear in sys.argv in python)

# Generated at 2022-06-11 06:20:43.601783
# Unit test for function split_args

# Generated at 2022-06-11 06:20:54.387273
# Unit test for function split_args
def test_split_args():
    from nose.tools import assert_equal

    args_string = "a=b c='foo bar' '\"a' 'd'"
    assert_equal(split_args(args_string), ['a=b', "c='foo bar'", '"a', 'd'])

    # test with a combination of spaces, tabs, and newlines
    args_string = "a=b c='foo bar' '\"a'\n'd'"
    assert_equal(split_args(args_string), ['a=b', "c='foo bar'", '"a\nd'])

    # trailing space after k=v pair
    args_string = "a=b c='foo bar' '\"a'\n'd' "

# Generated at 2022-06-11 06:21:03.820870
# Unit test for function split_args
def test_split_args():
    print("TESTING split_args")
    import json
    import pprint
    import sys

    input_data = '''
    a=1 b="foo bar" c={{ 3 }} d="o'neill" \\
    e="'e" f="e'" g="\\"" h=\\"\\" i="{{ foo }}" j=''{{ foo }}'' k=''{{ foo '''
    expected_data = [u'a=1', u'b="foo bar"', u'c={{ 3 }}', u"d=o'neill", u'e="\'e"', u"f=e'", u'g=\\""', u'h=\\"\\"', u'i="{{ foo }}"', u"j=''{{ foo }}", u"k=''{{ foo"]
    actual_data = split_args

# Generated at 2022-06-11 06:21:13.842604
# Unit test for function split_args
def test_split_args():
    ''' returns a list of tuples indicating success or failure for various args '''
    res = []

# Generated at 2022-06-11 06:21:23.369303
# Unit test for function split_args
def test_split_args():
    args = "a=b c='foo bar'"
    params = split_args(args)
    assert(params == ['a=b', "c='foo bar'"])

    args = "a=b\nc='foo bar'"
    params = split_args(args)
    assert(params == ['a=b\n', "c='foo bar'"])

    args = "a=b c='foo\nbar'"
    params = split_args(args)
    assert(params == ['a=b', "c='foo\nbar'"])

    args = "a=b c='foo\nbar' d=e"
    params = split_args(args)
    assert(params == ['a=b', "c='foo\nbar'", "d=e"])


# Generated at 2022-06-11 06:21:44.424631
# Unit test for function split_args
def test_split_args():
    import pprint


# Generated at 2022-06-11 06:21:55.383070
# Unit test for function split_args
def test_split_args():

    # assert is a Python built-in that compares 2 values and throws an error if they are different
    # msg is an optional message to show what assert is testing, if the test fails
    def assert_split(args, result, msg=None):
        assert split_args(args) == result, msg

    assert_split("a=1 b=2 'c d'", ['a=1', 'b=2', "'c d'"], "simple normal args")
    assert_split("a=1\nb=2 'c d'", ['a=1\n', 'b=2', "'c d'"], "simple args w/ newlines")
    assert_split("a=1 b=2 {{c}}", ['a=1', 'b=2', '{{c}}'], "args containing a j2 block")

# Generated at 2022-06-11 06:22:05.336804
# Unit test for function split_args

# Generated at 2022-06-11 06:22:12.150735
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import unittest


# Generated at 2022-06-11 06:22:22.886744
# Unit test for function split_args

# Generated at 2022-06-11 06:22:33.268188
# Unit test for function split_args
def test_split_args():
    args = ('foo bar=baz key="with spaces" key2=\'also spaces\' '
            'key3="escape \"this\"" key4=\'escape "this" too\' '
            'trailing-key=value trailing-key2="value 2"')
    expected = ['foo', 'bar=baz', 'key="with spaces"', 'key2=\'also spaces\'',
                'key3="escape \"this\""', 'key4=\'escape "this" too\'',
                'trailing-key=value', 'trailing-key2="value 2"']
    results = split_args(args)
    assert results == expected

    args = "{ foo }"
    expected = ["{ foo }"]
    results = split_args(args)
    assert results == expected

    args = "{{ foo }}"

# Generated at 2022-06-11 06:22:41.556141
# Unit test for function split_args
def test_split_args():
    '''Unit test for function split_args'''

    def test_args(input_args, expected_output):
        '''Test single args'''
        params = split_args(input_args)
        assert(params == expected_output)

    def test_arg_list(input_args, expected_output):
        '''Test list of args'''
        for input_arg, expected_arg in zip(input_args, expected_output):
            test_args(input_arg, expected_arg)


# Generated at 2022-06-11 06:22:51.718539
# Unit test for function split_args
def test_split_args():
    # Complex test case
    print('Original: a=b c="foo bar" d="{{ foo }}" e="{{ \'foo bar\' }}" f="{% foo %}" g="{# foo #}" h=\'{{ "foo" }} bar \' i=\\{{ foo }}')
    print('Result:   %s' % split_args('a=b c="foo bar" d="{{ foo }}" e="{{ \'foo bar\' }}" f="{% foo %}" g="{# foo #}" h=\'{{ "foo" }} bar \' i=\\{{ foo }}'))

    # Test case from the original unit test
    print('Original: a=b "c d" \'e f\' "g\'h" i={{ j }} z')

# Generated at 2022-06-11 06:23:01.582278
# Unit test for function split_args
def test_split_args():
    """
    Test the implementation of the split_args function
    """
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestSplitArgs(unittest.TestCase):
        """
        A collection of tests to assert the correct operation of the
        split_args function
        """
        def test_trivial(self):
            """
            Assert the simplest case returns a single-element list containing
            the argument.
            """
            args = "foo"
            result = split_args(args)
            self.assertEqual(result, ["foo"])

        def test_equals(self):
            """
            Assert that an argument containing an equal-sign will be split
            at the equal sign.
            """
            args = "foo=bar"


# Generated at 2022-06-11 06:23:09.860114
# Unit test for function split_args
def test_split_args():
    from unit_tests.test_base import AnsibleTestCase

    class TestSplitArgs(AnsibleTestCase):
        def setUp(self):
            super(TestSplitArgs, self).setUp()

        def test_unbalanced_quotes(self):

            cmd = u'''ansible all -m copy -a "src=/foo/bar.txt dest=/baz/qux.txt"'''

            if not PY3:
                cmd = cmd.encode('utf-8')

            else:
                # no need to encode
                pass

            self.assertRaises(Exception, split_args, cmd)

        def test_unbalanced_block(self):

            cmd = u'''ansible all -m copy -a "src=/foo/bar.txt dest={{ inventory_hostname }}"'''


# Generated at 2022-06-11 06:23:41.735948
# Unit test for function split_args
def test_split_args():
    print(split_args('a=b'))
    print(split_args('a="b c"'))
    print(split_args('a="b c"')[0])
    print(unquote(split_args('a="b c"')[0]))
    print(split_args('a="b c"')[1])
    print(unquote(split_args('a="b c"')[1]))
    assert split_args('a="b c"')[0] == 'a=b c'
    assert split_args('a="b c"')[1] == 'a=b c'
    assert split_args('a="b c"')[1] == 'a=b c'


test_split_args()

# Generated at 2022-06-11 06:23:51.727604
# Unit test for function split_args
def test_split_args():
    # Test that the function split args correctly splits the args according to the following rules:
    # - args that are in quotes with no whitespace inside the quotes remain in quotes
    # - args containing jinja2 blocks remain together
    # - args containing nested blocks remain together
    # - args that are in quotes with whitespace inside the quotes remain in quotes
    # - args with a backslash at the end of the line remain in one line
    # - args with a backslash at the end of the line in quotes remain in one line
    # - args following a backslash at the end of the line are appended to the previous line
    # - args that are in quotes following a backslash at the end of the line are appended to the previous line
    assert split_args('"quoted"') == ['quoted']

# Generated at 2022-06-11 06:24:01.676448
# Unit test for function split_args
def test_split_args():
    teststr = "a='b c' 'd e' f='g h' {{ i }}\"j k\" 'l m'"
    result = ['a=\'b c\'', "'d e'", "f='g h'", '{{ i }}"j k"', "'l m'"]
    assert split_args(teststr) == result

    teststr = "one=two three=four"
    result = ['one=two', 'three=four']
    assert split_args(teststr) == result

    teststr = "one='two three' four='five six'"
    result = ['one=\'two three\'', 'four=\'five six\'']
    assert split_args(teststr) == result

    teststr = "one='two three' four='five six' seven='eight nine'"

# Generated at 2022-06-11 06:24:11.816448
# Unit test for function split_args

# Generated at 2022-06-11 06:24:23.443456
# Unit test for function split_args
def test_split_args():
    '''
    Return True if split_args() is working properly, False if it is not.
    '''

    try:
        from ansible.module_utils.basic import AnsibleModule
        HAS_ANSIBLE_TEST = True
    except ImportError:
        HAS_ANSIBLE_TEST = False

    if not HAS_ANSIBLE_TEST:
        return False

    module = AnsibleModule(argument_spec=dict())

    tests = []

    # Place args to be tested inside tests

# Generated at 2022-06-11 06:24:31.765538
# Unit test for function split_args
def test_split_args():
    assert split_args("foo=bar") == ["foo=bar"]
    assert split_args("foo=bar baz=\"{{blip blop}}\"") == ["foo=bar", "baz=\"{{blip blop}}\""]
    assert split_args("foo=bar baz=\"{{blip blop}}{{blip blop}}\"") == ["foo=bar", "baz=\"{{blip blop}}{{blip blop}}\""]
    assert split_args("foo=bar baz=\"{{blip blop}}\"\nboop=\"{{blip blop}}\"") == ["foo=bar", "baz=\"{{blip blop}}\"\nboop=\"{{blip blop}}\""]

test_split_args()

# Generated at 2022-06-11 06:24:41.416380
# Unit test for function split_args
def test_split_args():
    '''
    run python -m lib.core.parser test_split_args
    '''

    import sys
    from ansible.utils import module_docs

    module = sys.modules[__name__]
    examples = module_docs.get_docstring(module).get('examples', None)

    if examples:
        # examples is a list of tuples (args, error)
        # if error is None, then test the argument splitting.
        # if error is not None, then it should be an exception class, and the args should raise that exception
        for args, error in examples:
            if error is None:
                split = split_args(args)
                if split != []:
                    print("splitting arg string '%s' produces result '%s'" % (args, split))

# Generated at 2022-06-11 06:24:51.272601
# Unit test for function split_args
def test_split_args():
    '''
      Test for function split_args
    '''

    # Create a set of test strings and the expected
    # split result from the string.

# Generated at 2022-06-11 06:25:00.424559
# Unit test for function split_args

# Generated at 2022-06-11 06:25:10.036932
# Unit test for function split_args
def test_split_args():

    # using the test cases from the original function split_args()
    a = "foo=bar bam={{baz}}"
    assert split_args(a) == ['foo=bar', 'bam={{baz}}']
    a = "foo=bar \\\nbam={{baz}}"
    assert split_args(a) == ['foo=bar \\\nbam={{baz}}']
    a = "foo=bar bam={{baz}} \\\n"
    assert split_args(a) == ['foo=bar', 'bam={{baz}} \\\n']
    a = "foo=bar bam={{ baz }}"
    assert split_args(a) == ['foo=bar', 'bam={{ baz }}']
    a = "foo=bar bam={{ '}}' }}"

# Generated at 2022-06-11 06:26:15.502230
# Unit test for function split_args

# Generated at 2022-06-11 06:26:23.795023
# Unit test for function split_args
def test_split_args():

    # test splitting on a simple set of args that don't use quotes or blocks
    params = split_args("a=b c=d")
    assert params[0] == "a=b"
    assert params[1] == "c=d"

    # test a more complex example with quotes and split lines
    params = split_args("a=b c='foo bar' \\\nd='foo bar'")
    assert params[0] == "a=b"
    assert params[1] == "c='foo bar'"
    assert params[2] == "d='foo bar'"

    # test a split line with a quoted string that is not closed
    # this should result in an error
    try:
        params = split_args("a=b c='foo bar")
    except:
        pass
    else:
        assert False

    # test

# Generated at 2022-06-11 06:26:30.139080
# Unit test for function split_args

# Generated at 2022-06-11 06:26:39.096540
# Unit test for function split_args
def test_split_args():
    result = ['foo', 'bar', '=', '"foo bar"', 'baz="foo bar"', 'q=\"a b\"', 'q=\'a b\'', 'q="a b"', 'baz=foo', 'bar']
    assert split_args('foo bar "foo bar" baz="foo bar" q=\"a b\" q=\'a b\' q="a b" baz=foo bar') == result
    assert split_args("foo bar 'foo bar' baz='foo bar' q='a b' q='a b' q='a b' baz=foo bar") == result

    # Test escaping of quotes
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]

# Generated at 2022-06-11 06:26:47.752911
# Unit test for function split_args
def test_split_args():
    args = "a=1 'b c' d=\"1 2 3\""
    params = split_args(args)
    assert params == ["a=1", "'b c'", 'd="1 2 3"']

    args = u"a=1 'b c' d=\"1 2 3\""
    params = split_args(args)
    assert params == ["a=1", "'b c'", 'd="1 2 3"']

    args = "a=b c={{foo}} d='{{foo}} {{bar}}'"
    params = split_args(args)
    assert params == ["a=b", "c={{foo}}", "d='{{foo}} {{bar}}'"]

    args = "a=b c={{foo}} d='{{foo}} {{bar}}'"
    params = split_args(args)

# Generated at 2022-06-11 06:26:55.822777
# Unit test for function split_args
def test_split_args():
    '''
    run unit test on split_args function
    '''
    # test case 1
    # simple unquoted args
    test_string = 'a=1 b="foo bar" c=\'foo bar\''
    test = split_args(test_string)
    result = ['a=1', 'b="foo bar"', "c='foo bar'"]
    assert test == result

    # test case 2
    # quoted args with jinja2
    test_string = 'a="{{ b }}" c="foo bar" d="foo \\" bar \\" baz" e=\'foo \\\' bar \\\' baz\''
    test = split_args(test_string)

# Generated at 2022-06-11 06:27:04.281701
# Unit test for function split_args
def test_split_args():
    '''
    the goal of this is to test out the splitter to make sure it works
    in all cases, given that it was written from scratch because shlex
    was lacking the flexibility
    '''

    # a dictionary of input and expected output
    # the input is a string to pass to the split_args() func
    # the output is a list of strings which should result when split_args() is called
    tests = dict()

    # a list of tests that should fail
    # if they raise an exception, no problem
    badtests = []

    # add a new test by adding to the dictionary or list above
    # the key will be used in the error messages, so make it something good

    # simple tests with no quoting
    tests['simple1'] = 'this is a test of the split args function'

# Generated at 2022-06-11 06:27:11.974078
# Unit test for function split_args
def test_split_args():
    # Example args.
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    args = "a=\"foo' bar\""
    params = split_args(args)
    assert params == ['a="foo\' bar"']

    args = "a='foo\" bar'"
    params = split_args(args)
    assert params == ['a=\'foo" bar\'']

    args = "a=b c='foo bar'"
    params = split_args(args)
    assert params == ['a=b', 'c=\'foo bar\'']

    args = "a=b c=\"foo bar\" d='foo bar'"
    params = split_args(args)

# Generated at 2022-06-11 06:27:20.758914
# Unit test for function split_args
def test_split_args():
    def check_split(args, expected):
        result = split_args(args)
        if result != expected:
            print("######################################################################")
            print("# test_split_args unit test failure: args:%s" % (args,))
            print("#")
            print("# Expected:")
            print("#   %s" % (expected,))
            print("# Got:")
            print("#   %s" % (result,))
            print("######################################################################")
            assert result == expected

    # Test empty string
    check_split("", [])

    # No jinja2, just some quoted words.
    check_split('tag="foobar"', ['tag="foobar"'])

    # Test whitespace quoting in the middle of a word.

# Generated at 2022-06-11 06:27:29.272931
# Unit test for function split_args