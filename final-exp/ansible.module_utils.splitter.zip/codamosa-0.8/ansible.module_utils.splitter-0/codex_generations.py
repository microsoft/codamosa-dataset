

# Generated at 2022-06-11 06:18:30.604828
# Unit test for function split_args
def test_split_args():
    # test basic splitting of args

    # test basic splitting
    assert split_args("a=1") == ["a=1"]

    # test quoted args
    assert split_args("a='1 2'") == ["a='1 2'"]

    # test args with quotes, jinja2 blocks
    assert split_args("a=\"{{foo}}\" c='{{foo}}'") == ['a="{{foo}}"', "c='{{foo}}'"]

    #test nested jinja2 blocks
    assert split_args("a=\"{{foo {{bar}}\" c='{{foo}}'") == ['a="{{foo {{bar}}"', "c='{{foo}}'"]

    # test split args
    assert split_args("a=b c=d") == ["a=b", "c=d"]

    # test quotes after a jinja

# Generated at 2022-06-11 06:18:41.150365
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('abc"def') == False
    assert is_quoted('"abc') == False
    assert is_quoted('abc""def') == False
    assert is_quoted('""') == True
    assert is_quoted('"""') == True
    assert is_quoted('"abc"') == True
    assert is_quoted('""abc"') == True
    assert is_quoted('"abc""') == True
    assert is_quoted('"abc"def') == True
    assert is_quoted("abc'def") == False
    assert is_quoted("'abc") == False
    assert is_quoted("abc''def") == False
    assert is_quoted("''") == True
    assert is_quoted("'''") == True

# Generated at 2022-06-11 06:18:53.536678
# Unit test for function split_args
def test_split_args():
    print("\nRunning split_args unittests\n")
    # The tests themselves

# Generated at 2022-06-11 06:19:00.298272
# Unit test for function split_args
def test_split_args():
    ''' Test the split_args function '''
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements

    # Test no args
    args_input = ''
    args_output = ['', ]

    if split_args(args_input) != args_output:
        raise Exception()

    # Test space
    args_input = ' '
    args_output = ['', ]

    if split_args(args_input) != args_output:
        raise Exception()

    # Test one arg
    args_input = 'a'
    args_output = ['a', ]

    if split_args(args_input) != args_output:
        raise Exception()

    # Test two args
    args_input = 'a b'

# Generated at 2022-06-11 06:19:08.373999
# Unit test for function unquote
def test_unquote():
    assert unquote('"a b c"') == 'a b c'
    assert unquote("'a b c'") == 'a b c'
    assert unquote("'a b c' d e") == "'a b c' d e"
    assert unquote("a b c") == "a b c"
    assert unquote("'a b c") == "'a b c"
    assert unquote("a b c'") == "a b c'"
    assert unquote("a b \"c'") == "a b \"c'"



# Generated at 2022-06-11 06:19:16.497068
# Unit test for function split_args
def test_split_args():

    def _test_split_args(args_string, expected, expected_warnings=[]):
        warnings = []
        params = split_args(args_string)

        for idx, entry in enumerate(params):
            if entry != expected[idx]:
                warnings.append("key: %s result: %s expected: %s" % (idx, entry, expected[idx]))

        for warning in expected_warnings:
            if warning not in warnings:
                warnings.append("expected warning not found: %s" % warning)

        if warnings:
            print("warnings:")
            print("\t%s" % "\n\t".join(warnings))

        # if something went wrong, fail the test
        assert warnings == []

    # Test for issue #13403

# Generated at 2022-06-11 06:19:28.078480
# Unit test for function split_args

# Generated at 2022-06-11 06:19:37.930497
# Unit test for function split_args
def test_split_args():
    # These tests are copied from the original shlex_split, but modified for the new split_args
    test_cases = ['a b c', 'a "b c"', 'a "b c" d', 'a "b c" "d e" f', 'a "b \\" c"']
    for test_case in test_cases:
        print("test_case=%s" % test_case)
        print("split_args=%s" % split_args(test_case))
        assert [] == [x for x in split_args(test_case) if x != '']
    assert ['a', 'b "c " d', 'e'] == split_args('a "b \\" c " d" e')


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-11 06:19:40.246796
# Unit test for function split_args
def test_split_args():
    assert ['a=b', 'c="foo bar"'] == split_args('a=b c="foo bar"')

test_split_args()

# Generated at 2022-06-11 06:19:49.573210
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b c=d \'e=f\' g=h") == ['a=b', 'c=d', '\'e=f\'', 'g=h']
    assert split_args("a=b c=d \'e=f\' g=h 'i=j'") == ['a=b', 'c=d', '\'e=f\'', 'g=h', '\'i=j\'']
    assert split_args("a=b 'c=d' e=\"f g\" h='i j'") == ['a=b', '\'c=d\'', 'e=\"f g\"', 'h=\'i j\'']

# Generated at 2022-06-11 06:20:12.045456
# Unit test for function split_args

# Generated at 2022-06-11 06:20:22.167420
# Unit test for function split_args
def test_split_args():
    '''
    test_split_args: unit tests for function `split_args`
    '''
    #pylint: disable=bare-except

    def _assert_args(args, expected):
        '''
        run split_args on args, and verify that the results match expected
        '''
        actual = split_args(args)
        assert actual == expected, "%s != %s" % (actual, expected)

    _assert_args('', [])
    _assert_args('foo', ['foo'])
    _assert_args('foo bar', ['foo', 'bar'])
    _assert_args('foo "bar baz"', ['foo', '"bar baz"'])
    _assert_args("foo 'bar baz'", ['foo', "'bar baz'"])

# Generated at 2022-06-11 06:20:33.393287
# Unit test for function split_args
def test_split_args():
    import sys
    import textwrap


# Generated at 2022-06-11 06:20:43.292863
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo\\"bar"') == ['a=b', 'c="foo\\"bar"']
    assert split_args('a=b c="foo\"bar"') == ['a=b', 'c="foo\"bar"']
    assert split_args('a=b c="{{ foo }}"') == ['a=b', 'c="{{ foo }}"']
    assert split_args('k="{{foo}}"') == ['k="{{foo}}"']

# Generated at 2022-06-11 06:20:54.027914
# Unit test for function split_args
def test_split_args():
    # This case is for the function of split_args
    import sys
    import jinja2
    from ansible.module_utils._text import to_bytes, to_native, to_text

    # Create the module utilities

# Generated at 2022-06-11 06:21:03.532106
# Unit test for function split_args
def test_split_args():
    # example input args
    # args = a=b c="foo bar" d='{"a": "b"}' e="{{ foo }}"

    # example output of split_args on those args
    # ['a=b', 'c="foo bar"', "d='{\"a\": \"b\"}'", 'e="{{ foo }}"']

    # raw strings here are so we don't need to escape all of the quotes
    a = r'a=b'
    b = r'c="foo bar"'
    c = r"d='{\"a\": \"b\"}'"
    d = r'e="{{ foo }}"'

    # run split args and assert that we got the output we expect
    args = split_args(a + ' ' + b + ' ' + c + ' ' + d)
    assert args[0] == a


# Generated at 2022-06-11 06:21:13.455602
# Unit test for function split_args
def test_split_args():
    '''
    Test cases for function split_args().

    NOTE: This function is considered an internal implementation detail, so these tests
    will break if the implementation ever changes.

    :return: None
    '''

# Generated at 2022-06-11 06:21:23.057192
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', 'c=\'foo bar\'']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b 'c=foo bar'") == ['a=b', "'c=foo bar'"]
    assert split_args("a=b \"c=foo bar\"") == ['a=b', '"c=foo bar"']
    assert split_args("a={{ b }}") == ['a={{ b }}']
    assert split_args("a={{ b }} c={{ d }}") == ['a={{ b }}', 'c={{ d }}']

# Generated at 2022-06-11 06:21:28.500985
# Unit test for function split_args
def test_split_args():
    '''
    Tests split_args to ensure it is providing us with the values that we
    expect.
    '''

    # Simple test to make sure the function returns what we expect.
    # This would be the one that would break if we change the function.
    assert split_args("foo") == ['foo']

    # Using quotes inside the string to make sure they are respected.
    assert split_args("foo 'bar baz'") == ['foo', "'bar baz'"]

    # If we have an unclosed quote, we should get back a list as if the
    # quotes were not there.
    assert split_args("foo \"bar baz") == ['foo', '"bar', 'baz']

    # Make sure a quoted string (even one with spaces) is a single element

# Generated at 2022-06-11 06:21:38.273084
# Unit test for function split_args

# Generated at 2022-06-11 06:22:03.012609
# Unit test for function split_args
def test_split_args():
    ''' The following tests must pass for function "split_args" '''

    #  Simple unquoted string
    test_input1 = 'string'
    assert split_args(test_input1) == ['string']

    # Unquoted string with spaces
    test_input2 = 'string with spaces'
    assert split_args(test_input2) == ['string', 'with', 'spaces']

    # Unquoted string with multiple spaces
    test_input3 = 'string   with multiple   spaces'
    assert split_args(test_input3) == ['string', 'with', 'multiple', 'spaces']

    # Unquoted string ending with a space
    test_input4 = 'string ending with space '
    assert split_args(test_input4) == ['string', 'ending', 'with', 'space']

    #

# Generated at 2022-06-11 06:22:11.028685
# Unit test for function split_args
def test_split_args():
    '''
    Testcases for function split_args.
    Every Testcase consists of folowing data:
        example input: a=b c="foo bar"
        example output: ['a=b', 'c="foo bar"']
    '''

    # Testcase: No quotes no jinja.
    # In this testcase quotes and jinja are not used at all.
    # example input: a=b c="foo bar"
    # example output: ['a=b', 'c="foo bar"']
    test_no_quotes_no_jinja = {
        'input': "a=b c=foo",
        'expected': ['a=b', 'c=foo'],
        'description': "No quotes no jinja"
    }

# Generated at 2022-06-11 06:22:21.607753
# Unit test for function split_args
def test_split_args():

    # No quotes, no spaces
    input = 'foo=bar'
    output = split_args(input)
    assert output == ['foo=bar']

    # No quotes, one space
    input = 'foo=bar baz=qux'
    output = split_args(input)
    assert output == ['foo=bar', 'baz=qux']

    # No quotes, two spaces
    input = 'foo=bar  baz=qux'
    output = split_args(input)
    assert output == ['foo=bar', 'baz=qux']

    # No quotes, two spaces with escape
    input = 'foo=bar \\  baz=qux'
    output = split_args(input)
    assert output == ['foo=bar', 'baz=qux']

    # No quotes, one newline
   

# Generated at 2022-06-11 06:22:32.135747
# Unit test for function split_args
def test_split_args():
    class TestInput(object):
        def __init__(self, args, expected_output, should_pass=True):
            self.args = args
            self.expected_output = expected_output
            self.should_pass = should_pass


# Generated at 2022-06-11 06:22:37.760283
# Unit test for function split_args

# Generated at 2022-06-11 06:22:44.326488
# Unit test for function split_args

# Generated at 2022-06-11 06:22:53.896743
# Unit test for function split_args
def test_split_args():
    '''
    test cases for function split_args
    '''
    #basic use
    assert split_args('a b c') == ['a', 'b', 'c']
    # unbalanced quotes
    try:
        split_args('a "')
        assert False, "unbalanced quotes should raise an exception"
    except:
        pass
    # pipes inside block correctly preserved
    assert split_args('a "{{ foo | bar }}"') == ['a', '"{{ foo | bar }}"']
    # quotes inside block correctly preserved
    assert split_args('a "{{ foo "bar" }}"') == ['a', '"{{ foo "bar" }}"']
    # empty args
    assert split_args('') == []

test_split_args()

# Generated at 2022-06-11 06:23:03.581444
# Unit test for function split_args

# Generated at 2022-06-11 06:23:10.981563
# Unit test for function split_args
def test_split_args():
    ''' test the functionality of split_args '''


# Generated at 2022-06-11 06:23:20.548114
# Unit test for function split_args
def test_split_args():
    '''
    Test for function split_args
    '''

    # Test 1
    if split_args("a=b c=d") != ['a=b', 'c=d']:
        print("Split args Test 1 failed")
        return False

    # Test 2
    if split_args("a='b b' c='d d'") != ['a=\'b b\'', 'c=\'d d\'']:
        print("Split args Test 2 failed")
        return False

    # Test 3
    if split_args("a='b b' c=\"d d\"") != ['a=\'b b\'', 'c="d d"']:
        print("Split args Test 3 failed")
        return False

    # Test 4

# Generated at 2022-06-11 06:23:59.105695
# Unit test for function split_args
def test_split_args():
    assert split_args('one') == ['one']
    assert split_args('one "two three"') == ['one', '"two three"']
    assert split_args('one "two three') == ['one', '"two', 'three']
    assert split_args('one "two three" four') == ['one', '"two three"', 'four']
    assert split_args('"one two" three') == ['"one two"', 'three']
    assert split_args('one \'two three\'') == ['one', "'two three'"]
    assert split_args('one \'two three') == ['one', "'two", 'three']
    assert split_args('one \'two three\' four') == ['one', "'two three'", 'four']

# Generated at 2022-06-11 06:24:09.721660
# Unit test for function split_args
def test_split_args():

    # Ugly, but this is what you get when you have special cases
    assert split_args("foo=\"bar baz\"") == ["foo=bar baz"]
    assert split_args("foo=\"bar baz") == ["foo=bar baz"]
    assert split_args("foo=\"bar baz\" x") == ["foo=bar baz", "x"]
    assert split_args("foo=\"bar baz\" \\where=here") == ["foo=bar baz", "where=here"]

    assert split_args("foo=\"bar baz\" \\\nwhere=here") == ["foo=bar baz", "where=here"]
    assert split_args("foo=\"bar baz\" \\\n#comment\nwhere=here") == ["foo=bar baz", "where=here"]

# Generated at 2022-06-11 06:24:18.385004
# Unit test for function split_args
def test_split_args():
    def assert_argssplit(args, expected):
        params = split_args(args)
        assert params == expected, params

    assert_argssplit("test1 test2", ["test1", "test2"])
    assert_argssplit("key1=val1 key2=val2", ["key1=val1", "key2=val2"])
    assert_argssplit("key1='val1 val2'", ["key1='val1 val2'"])
    assert_argssplit("key1=\"val1 val2\"", ["key1=\"val1 val2\""])

# Generated at 2022-06-11 06:24:27.107985
# Unit test for function split_args
def test_split_args():
    '''
        Run the split_args function through its paces

        These may look overly complicated but they're designed to verify that
        the function works as expected with a wide variety of situations.
    '''

    # These are the test cases

# Generated at 2022-06-11 06:24:36.611940
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-11 06:24:46.766695
# Unit test for function split_args
def test_split_args():
    '''
    very basic test for the split_args function, this needs to be expanded
    much further
    '''
    args = "a=b c=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    args = "a=b c=\"foo bar\" d='foo bar'"
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', 'd=\'foo bar\'']

    args = "a=b c='foo bar' d=\"foo bar\""
    result = split_args(args)
    assert result == ['a=b', 'c=\'foo bar\'', 'd="foo bar"']

    args = "a=b c=\"foo bar'"

# Generated at 2022-06-11 06:24:56.018786
# Unit test for function split_args
def test_split_args():
    # test some basic argument splitting
    assert split_args('') == []
    assert split_args('"foo"') == ['"foo"']
    assert split_args('foo') == ['foo']
    assert split_args('"foo bar"') == ['"foo bar"']
    assert split_args('"foo bar" "baz qux"') == ['"foo bar"', '"baz qux"']

    # test argument splitting inside quotes
    assert split_args('"foo "bar qux"') == ['"foo "bar qux"']
    assert split_args('"foo "bar qux" baz') == ['"foo "bar qux"', 'baz']

    # test argument splitting inside jinja2 blocks
    assert split_args('"foo {{ bar }}"') == ['"foo {{ bar }}"']

# Generated at 2022-06-11 06:25:05.757008
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar' d=\"foo bar baz\" e='foo \\'bar\\' baz'") == \
        ['a=b', "c='foo bar'", 'd="foo bar baz"', "e='foo \\'bar\\' baz'"]

    # test {{ }} blocks
    assert split_args("a={{ foo }}") == \
        ['a={{ foo }}']
    assert split_args("a={{ foo }} \\ b=") == \
        ['a={{ foo }}\nb=']
    assert split_args("a={{ foo }}\nb='foo bar'") == \
        ['a={{ foo }}', "b='foo bar'"]

    # test {% %} blocks

# Generated at 2022-06-11 06:25:12.879122
# Unit test for function split_args

# Generated at 2022-06-11 06:25:21.419379
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import unittest
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.six import string_types

    class TestSplitArgs(unittest.TestCase):

        def test_split_args(self):
            ''' test split_args() '''
            args = split_args("a=3 c='foo bar' d=\"I'm\"")
            self.assertEqual(args, ['a=3', 'c=\'foo bar\'', 'd="I\'m"'])

            args = split_args("a=3")
            self.assertEqual(args, ['a=3'])

            args = split_args("a='3'")
            self.assertEqual(args, ['a=\'3\''])

            args = split_

# Generated at 2022-06-11 06:26:37.366924
# Unit test for function split_args
def test_split_args():
    ''' For this test to work, the unittest for this file has to be run from the root of the source tree
    since the tests are located in test/units'''
    result = split_args("foo")
    assert_equal(result, ['foo'])

    result = split_args("foo bar")
    assert_equal(result, ['foo', 'bar'])

    result = split_args("foo 'bar baz'")
    assert_equal(result, ['foo', 'bar baz'])

    result = split_args("foo 'bar baz' foz baz")
    assert_equal(result, ['foo', 'bar baz', 'foz', 'baz'])

    # test with quoted newlines
    result = split_args("foo\nbar")

# Generated at 2022-06-11 06:26:44.599359
# Unit test for function split_args
def test_split_args():
    args = """a=b c="foo bar" d='foo bar' e={{foo}} f={{ foo }} g={{foo.bar}} h="{{ foo }}" 'i'='bar'"""
    params = split_args(args)
    print("PARAMS: %s" % params)
    my_params = ['a=b', 'c="foo bar"', 'd=\'foo bar\'', 'e={{foo}}', 'f={{ foo }}', 'g={{foo.bar}}', 'h="{{ foo }}"', '\'i\'=\'bar\'']
    assert params == my_params

# Generated at 2022-06-11 06:26:50.502787
# Unit test for function split_args
def test_split_args():
    assert split_args("foo bar") == ['foo', 'bar']
    assert split_args("foo 'bar baz'") == ['foo', 'bar baz']
    assert split_args("foo \"bar baz\"") == ['foo', 'bar baz']
    assert split_args('foo "bar baz"') == ['foo', 'bar baz']
    assert split_args("foo \"bar b'a'z\"") == ['foo', "bar b'a'z"]
    assert split_args('foo "bar b\'a\'z"') == ['foo', "bar b'a'z"]
    assert split_args('foo "bar ba\'z"') == ['foo', 'bar ba\'z']
    assert split_args('foo "bar ba\\"z"') == ['foo', 'bar ba"z']
    assert split_

# Generated at 2022-06-11 06:26:58.938441
# Unit test for function split_args
def test_split_args():
    # test unbalanced quotes
    try:
        split_args("a=\"b\" c=\"d")
        assert False, "Failed to raise exception on unclosed quotes"
    except Exception as e:
        pass

    # test an unbalanced jinja2 block, but with a quote at the end
    try:
        split_args("a={{ b }}\" c=\"d")
        assert False, "Failed to raise exception on unclosed quotes"
    except Exception as e:
        pass

    # test an unbalanced jinja2 block, but with a quote at the end
    try:
        split_args("a=\"b\" c={{ d }}")
        assert False, "Failed to raise exception on unclosed jinja2 block"
    except Exception as e:
        pass

    # test a balanced set of args

# Generated at 2022-06-11 06:27:07.045684
# Unit test for function split_args
def test_split_args():
    qa = split_args
    assert qa('') == []
    assert qa('"a=b"') == ['a=b']
    assert qa('"a=b c=d"') == ['a=b c=d']
    assert qa('"a=b c=d" e=f') == ['a=b c=d', 'e=f']
    assert qa('a=b "c=d e=f"') == ['a=b', 'c=d e=f']
    assert qa('a=b "c=d" e=f') == ['a=b', 'c=d', 'e=f']
    assert qa('a=b "c=d e=f" g=h') == ['a=b', 'c=d e=f', 'g=h']
   

# Generated at 2022-06-11 06:27:14.997777
# Unit test for function split_args

# Generated at 2022-06-11 06:27:23.854415
# Unit test for function split_args
def test_split_args():
    '''
    These are all the variations I could think of that might need to be supported
    TODO: better coverage
    '''


# Generated at 2022-06-11 06:27:33.168633
# Unit test for function split_args

# Generated at 2022-06-11 06:27:41.522799
# Unit test for function split_args

# Generated at 2022-06-11 06:27:51.028592
# Unit test for function split_args
def test_split_args():
    input_data = """
        {
          "foo": {
            "id": 1,
            "type": "bar",
            "value": "baz",
            "value2": "baz\nbaz"
          }
        }
    """
    expected_output = [input_data]
    real_output = split_args(input_data)
    if real_output != expected_output:
        raise Exception("Input: %s\nOutput: %s\nExpected: %s\n" % (input_data, real_output, expected_output))

    input_data = """
        [
          {
            "key": "value"
          },
          {
            "key": "value"
          }
        ]
    """
    expected_output = [input_data]
    real_output = split_