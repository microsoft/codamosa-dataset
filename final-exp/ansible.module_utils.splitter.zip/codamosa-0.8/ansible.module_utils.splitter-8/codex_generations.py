

# Generated at 2022-06-11 06:18:18.027908
# Unit test for function split_args
def test_split_args():
    assert split_args("") == [u""]
    assert split_args("   ") == [u""]
    assert split_args("one two") == [u"one", u"two"]
    assert split_args(" one two ") == [u"one", u"two"]
    assert split_args(" one\ntwo ") == [u"one\ntwo"]
    assert split_args("'one two'") == [u"'one two'"]
    assert split_args('"one two"') == [u'"one two"']
    assert split_args("foo='one two'") == [u"foo='one two'"]
    assert split_args("foo=\"one two\"") == [u'foo="one two"']

# Generated at 2022-06-11 06:18:22.505890
# Unit test for function is_quoted
def test_is_quoted():
    "test_is_quoted"
    if is_quoted('"abc"'):
        assert True
    if is_quoted("'abc'"):
        assert True
    if not is_quoted("'abc"):
        assert True
    if not is_quoted("abc'"):
        assert True
    if not is_quoted("'abc"):
        assert True


# Generated at 2022-06-11 06:18:34.220443
# Unit test for function split_args
def test_split_args():
    # Regular test cases
    assert split_args("foo=bar") == ["foo=bar"]
    assert split_args("foo=bar num=42") == ["foo=bar", "num=42"]
    assert split_args("foo='bar num'") == ["foo='bar num'"]
    assert split_args("foo='bar num' num=42") == ["foo='bar num'", "num=42"]
    assert split_args("foo=\"bar num\" num=42") == ["foo=\"bar num\"", "num=42"]
    assert split_args("foo=\"bar num=\" num=42") == ["foo=\"bar num=\"", "num=42"]
    assert split_args("foo=\"bar num=\" num=42") == ["foo=\"bar num=\"", "num=42"]

# Generated at 2022-06-11 06:18:43.672219
# Unit test for function split_args
def test_split_args():
    # Test split quotes"
    test_string = 'a=b c="foo bar"'
    assert split_args(test_string) == ['a=b', 'c="foo bar"']

    # Test split quotes'
    test_string = "a=b c='foo bar'"
    assert split_args(test_string) == ['a=b', "c='foo bar'"]

    # Test split jinja2 blocks
    test_string = 'a=b c="{{ foo bar }}"'
    assert split_args(test_string) == ['a=b', 'c="{{ foo bar }}"']

    # Test split line continuation
    test_string = "a=b c='foo \\\nbar'"
    assert split_args(test_string) == ["a=b", "c='foo \\", "bar'"]

    #

# Generated at 2022-06-11 06:18:47.680831
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("foo") == False
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True


# Generated at 2022-06-11 06:18:57.998223
# Unit test for function split_args
def test_split_args():

    def _test(args, expected):
        splitted = split_args(args)
        assert splitted == expected, '%s was not split as expected, was %s instead' % (args, splitted)

    _test('ls', ['ls'])
    _test('ls -l', ['ls', '-l'])
    _test('ls {{ foo }}', ['ls', '{{ foo }}'])
    _test('ls "foo bar"', ['ls', '"foo bar"'])
    _test('ls "foo bar" baz', ['ls', '"foo bar"', 'baz'])
    _test('ls "foo bar" baz qux', ['ls', '"foo bar"', 'baz', 'qux'])

# Generated at 2022-06-11 06:19:10.360405
# Unit test for function split_args

# Generated at 2022-06-11 06:19:19.564650
# Unit test for function split_args
def test_split_args():

    assert split_args('foo="bar baz" one') == ['foo="bar baz"', 'one']
    # the next test will fail because split args doesn't work on templates, but it's a real
    # example that has to be fixed
    #assert split_args('{{ foo }} command="foo bar"') == ['{{ foo }}', 'command="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('a=b c=\\"foo bar\\"') == ['a=b', 'c="foo bar"']
    assert split_args('a="b bar" c="foo bar"')

# Generated at 2022-06-11 06:19:30.352618
# Unit test for function split_args
def test_split_args():

    assert split_args('a=b') == ['a=b']
    assert split_args('a=b "foo bar"') == ['a=b', '"foo bar"']
    assert split_args("a=b 'foo bar'") == ['a=b', "'foo bar'"]
    assert split_args("a=b 'foo \nbar'") == ['a=b', "'foo \nbar'"]
    assert split_args("a=b 'foo \nbar\\\nbaz' quz=thud") == ['a=b', "'foo \nbar\nbaz' quz=thud"]
    assert split_args("a=\"b c\"") == ['a="b c"']
    assert split_args("a=\"b\\\"c\"") == ['a="b"c"']

# Generated at 2022-06-11 06:19:39.466130
# Unit test for function split_args
def test_split_args():
    ''' Ensure that split_args parses arguments correctly '''

    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json

    TEST_DIR = tempfile.mkdtemp()
    NAMESPACE = 'ansible_test_split_args'
    ENV = {'ANSIBLE_NOCOLOR':'true', 'ANSIBLE_FORCE_COLOR':'false'}
    ARGS = [
        'test.yml',
        '-i', 'localhost,'
    ]
    EXECUTABLE = os.path.normpath(sys.executable)
    LIBDIR = os.path.join(os.path.dirname(__file__), '..', '..', 'lib')

# Generated at 2022-06-11 06:19:55.064909
# Unit test for function is_quoted
def test_is_quoted():
    if not is_quoted('"foo"'):
        raise AssertionError('Expected to be able to determine string is quoted')
    if is_quoted('foo'):
        raise AssertionError('Expected to not be able to determine quoted string, because there is no quote')
    if not is_quoted("'foo'"):
        raise AssertionError('Expected to be able to determine string is quoted')


# Generated at 2022-06-11 06:20:01.219945
# Unit test for function is_quoted
def test_is_quoted():
    test_examples = [
        # built-in examples
        "",
        "Hello World",
        "Hello World\"",
        "\"Hello World\"",
        "\"Hello World",
        "Hello World'",
        "'Hello World'",
        "'Hello World",
        # added by myself
        "'Hello World\"",
        "\"Hello World'",
    ]

    for test_example in test_examples:
        print("{0} is_quoted={1}".format(test_example, is_quoted(test_example)))



# Generated at 2022-06-11 06:20:09.114088
# Unit test for function split_args

# Generated at 2022-06-11 06:20:15.954834
# Unit test for function split_args
def test_split_args():
    import datetime
    import re
    import os

    if not os.path.exists('/tmp/ansible-split-args_test-%s' % os.getpid()):
        os.makedirs('/tmp/ansible-split-args_test-%s' % os.getpid())


# Generated at 2022-06-11 06:20:26.321331
# Unit test for function split_args
def test_split_args():
    yaml_quote_string = '"{a: b}"'
    non_yaml_string = '{a: b}'
    assert split_args(yaml_quote_string) == [yaml_quote_string]
    assert split_args(non_yaml_string) == [non_yaml_string]
    # This triggers a key error for PyYAML < 3.10, so we check for that version
    try:
        import yaml
        if hasattr(yaml, '__version__') and yaml.__version__ < '3.10':
            return
    except ImportError:
        pass
    assert split_args(yaml_quote_string + " extra") == [yaml_quote_string, "extra"]

# Generated at 2022-06-11 06:20:37.114981
# Unit test for function split_args
def test_split_args():
    '''
    test_split_args: test the split_args function from the utils
    module

    This runs a variety of tests to determine if the split_args function
    is behaving as it should. The function is told to split on spaces and
    should intelligently recognize if it is inside quotes or jinja2 blocks.
    '''

    # simple test case
    args = "foo=bar"
    params = split_args(args)
    assert(len(params) == 1)
    assert(params[0] == "foo=bar")

    # a more complicated test case
    args = """  "foo bar"={{baz}}
    this='should work'
    '''{{and even if it has three quote characters at the end}}'''

    "and if it spans
    multiple lines"=yep
    """

    params

# Generated at 2022-06-11 06:20:47.796473
# Unit test for function split_args

# Generated at 2022-06-11 06:20:58.238633
# Unit test for function split_args
def test_split_args():
    """
    Ensures that split_args works for different inputs
    """

    # case 0: no args
    data = split_args('')
    assert data == []

    # case 1: simple case
    data = split_args('a=b name=fred  garage="car truck"')
    assert data == ['a=b', 'name=fred', 'garage="car truck"']

    # case 2: embedded quotes
    data = split_args('name="john ""jacky"" doe"')
    assert data == ['name="john ""jacky"" doe"']

    # case 3: escaped quotes
    data = split_args('name="joe \\"jack\\" smith"')
    assert data == ['name="joe \\"jack\\" smith"']

    # case 4: quoted quotechars

# Generated at 2022-06-11 06:21:06.562023
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='d e' f=\"g h\"") == ['a=b', "c='d e'", 'f="g h"']
    assert split_args("a='b \"c\" d' e=f") == ["a='b \"c\" d'", 'e=f']
    assert split_args("a='b \"c d' e=f") == ["a='b \"c d'", 'e=f']
    assert split_args("a='b \"c\" d' e=\"f") == ["a='b \"c\" d'", 'e="f']
    assert split_args("a=b c='d e f' g=h") == ['a=b', "c='d e f'", 'g=h']

# Generated at 2022-06-11 06:21:16.860740
# Unit test for function split_args

# Generated at 2022-06-11 06:21:46.310485
# Unit test for function split_args
def test_split_args():
    r = split_args("baz='foo bar'")
    assert len(r) == 1
    assert r[0] == "baz='foo bar'"
    r = split_args("baz='foo bar' 'foo bar'")
    assert len(r) == 2
    assert r[0] == "baz='foo bar'"
    assert r[1] == "foo bar"
    r = split_args("baz='foo bar'\n'foo bar'")
    assert len(r) == 2
    assert r[0] == "baz='foo bar'"
    assert r[1] == "'foo bar'"
    r = split_args("baz='foo bar'\n'foo bar'", 1)
    assert len(r) == 3
    assert r[0] == "baz='foo bar'"
   

# Generated at 2022-06-11 06:21:57.748199
# Unit test for function split_args
def test_split_args():
    test_cases = {
        "a=b c=d": ['a=b', 'c=d'],
        "a='b c' d=e": ['a=\'b c\'', 'd=e'],
        "a=\"b c\" d=e": ['a="b c"', 'd=e'],
        "a=\"b c\": d=e": ['a="b c":', 'd=e'],
        "a=\"b c\" \\: d=e": ['a="b c"', ':', 'd=e'],

        # check unquoting
        "'foo'": ['foo'],
        "\"foo\"": ['foo']
    }
    for args, expected in test_cases.items():
        result = split_args(args)

# Generated at 2022-06-11 06:22:07.413026
# Unit test for function split_args
def test_split_args():
    ''' Some simple tests split_args. '''
    # Simple args lists
    assert split_args("") == []
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b c=d e=f") == ["a=b", "c=d", "e=f"]
    # Args lists with quoted strings
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=\"foo bar\""]
    assert split_args("a=b c=\"foo\nbar\"") == ["a=b", "c=\"foo\nbar\""]

# Generated at 2022-06-11 06:22:17.388000
# Unit test for function split_args
def test_split_args():
    ''' test the behavior of split_args '''
    # this list of args will be split and then the split tokens
    # will be reassembled and compared with the original list
    # to make sure they match

# Generated at 2022-06-11 06:22:28.066239
# Unit test for function split_args

# Generated at 2022-06-11 06:22:37.816459
# Unit test for function split_args
def test_split_args():
    assert split_args('"a b c"\nd e f') == ['a b c\n', 'd', 'e', 'f']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="{{ foo }}"') == ['a=b', 'c="{{ foo }}"']
    assert split_args('a=b c="{{ foo }} bar"') == ['a=b', 'c="{{ foo }} bar"']
    assert split_args('a=b c="{{ foo }}bar"') == ['a=b', 'c="{{ foo }}bar"']
    assert split_args('a=b c="\\\n"') == ['a=b', 'c="\n"']

# Generated at 2022-06-11 06:22:44.375803
# Unit test for function split_args

# Generated at 2022-06-11 06:22:54.926718
# Unit test for function split_args

# Generated at 2022-06-11 06:23:04.507237
# Unit test for function split_args
def test_split_args():
    '''
    Tests the split_args function against a bunch of sample arguments
    '''

# Generated at 2022-06-11 06:23:11.432121
# Unit test for function split_args
def test_split_args():
    # Test with no args
    assert split_args('') == []

    # Test with simple args
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=1234') == ['a=b', 'c="foo bar"', 'd=1234']

    # Test with multiple quotes in a single arg
    assert split_args('a=b c="foo \'bar\'"') == ['a=b', 'c="foo \'bar\'"']
    assert split_args('a=b c="foo \'bar\' baz"') == ['a=b', 'c="foo \'bar\' baz"']

# Generated at 2022-06-11 06:23:31.368801
# Unit test for function split_args

# Generated at 2022-06-11 06:23:41.431232
# Unit test for function split_args

# Generated at 2022-06-11 06:23:51.330432
# Unit test for function split_args
def test_split_args():
    def test(args, expected_params):
        params = split_args(args)
        if params != expected_params:
            raise AssertionError('%s resulted in %s, expected %s' % (args, params, expected_params))
    test('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    test('a=b c="foo bar" "d e f"', ['a=b', 'c="foo bar"', '"d e f"'])
    test('a=b c="foo bar" "d e f"{#blah#}', ['a=b', 'c="foo bar"', '"d e f"{#blah#}'])

# Generated at 2022-06-11 06:24:01.294521
# Unit test for function split_args
def test_split_args():

    def _compare(args, expected):
        result = split_args(args)
        if result != expected:
            print(result)
            print(expected)
        assert result == expected

    _compare("a=b c=d", ['a=b', 'c=d'])
    _compare("a=b c=d\ne=f", ['a=b', 'c=d\ne=f'])
    _compare('''a=b c=d e="f g"''', ['a=b', 'c=d', 'e="f g"'])
    _compare('''a=b c=d e="f
                g"''', ['a=b', 'c=d', 'e="f\ng"'])

# Generated at 2022-06-11 06:24:11.516998
# Unit test for function split_args

# Generated at 2022-06-11 06:24:22.960965
# Unit test for function split_args
def test_split_args():

    if split_args("a=b") != ["a=b"]:
        raise Exception("failed simple test on split args")

    if split_args("a='b c'") != ["a='b c'"]:
        raise Exception("failed simple test on split args with single quotes")

    if split_args("a=\"b c\"") != ["a=\"b c\""]:
        raise Exception("failed simple test on split args with double quotes")

    if split_args('a=foo\nb=bar') != ["a=foo", "b=bar"]:
        raise Exception("failed simple test on split args with newlines")

    if split_args('a=foo\nb="bar bang"') != ["a=foo", 'b="bar bang"']:
        raise Exception("failed simple test on split args with newlines and quotes")


# Generated at 2022-06-11 06:24:31.809058
# Unit test for function split_args

# Generated at 2022-06-11 06:24:41.414324
# Unit test for function split_args
def test_split_args():
    # These tests should return the original args
    original_args = ['a=test', 'b=foo', 'c=bar', 'd="foo bar"', 'e="foo \'bar\'"', 'f="foo "bar" baz"',
                     'g="a=b c=d"', 'h="a=b c=d\\"', 'i=foo j=\\"bar\\"']
    for test_args in original_args:
        result = split_args(test_args)
        assert len(result) == 1 and result[0] == test_args, \
            "Incorrectly split args %s, expected [%s], got %s" % (test_args, test_args, result)

    # These tests should split on the spaces between args
    result = split_args('a=test b=foo c=bar')

# Generated at 2022-06-11 06:24:51.273395
# Unit test for function split_args

# Generated at 2022-06-11 06:25:00.424553
# Unit test for function split_args
def test_split_args():
    result = split_args("a=b c=\"foo bar\"")
    assert result == ['a=b', 'c="foo bar"']

    result = split_args("a=b c=\"foo bar\" d='foo \"bar'")
    assert result == ['a=b', 'c="foo bar"', "d='foo \"bar'"]

    result = split_args("a=b c=\"foo bar\" d='foo \"bar' e=\"foo'bar\"")
    assert result == ['a=b', 'c="foo bar"', "d='foo \"bar'", "e=\"foo'bar\""]

    result = split_args("a=b c=\"foo bar\" d='foo \"bar' e=\"foo'bar\" f='foo bar'")

# Generated at 2022-06-11 06:25:39.268209
# Unit test for function split_args
def test_split_args():
    # Verify a simple command-line can be split without issues
    args = "git status"
    params = split_args(args)
    assert params == ["git", "status"]

    # Verify a bash command-line can be split without issues
    args = "ls -alF /tmp/ | grep --color=auto '^d' | sort -k1,1 -k2,2n -k3,3 | tail -n 1"
    params = split_args(args)
    assert params == ["ls", "-alF", "/tmp/", "|", "grep", "--color=auto", "'^d'", "|", "sort", "-k1,1", "-k2,2n", "-k3,3", "|", "tail", "-n", "1"]

    # Verify a bash command-line with a quoted string can be split

# Generated at 2022-06-11 06:25:48.604682
# Unit test for function split_args

# Generated at 2022-06-11 06:25:56.171952
# Unit test for function split_args
def test_split_args():
    # Test regular arguments
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar "baz fuz"') == ['foo', 'bar', '"baz fuz"']
    assert split_args('foo bar "baz fuz') == ['foo', 'bar', '"baz', 'fuz']
    assert split_args('foo bar "baz\ fuz') == ['foo', 'bar', '"baz\ fuz']
    assert split_args('foo bar "baz\nfuz') == ['foo', 'bar', '"baz\nfuz']

    # Test using line continuation
    assert split_args('foo bar \\\nbaz fuz') == ['foo', 'bar', '\\\nbaz', 'fuz']

# Generated at 2022-06-11 06:26:04.681050
# Unit test for function split_args
def test_split_args():
    import pytest

    args = '''
    module: shell
    args:
      chdir: '"/foo bar"'
      creates: '"/tmp/bar bar"'
      executable: /path/to/executable
      removes: '/tmp/baz baz'
    '''

    params = split_args(args)
    assert params[0] == 'module: shell'
    assert params[1].strip() == 'args:'
    arg_data = params[2].strip()
    arg_params = split_args(arg_data)
    assert len(arg_params) == 4
    assert arg_params[0] == 'chdir: "/foo bar"'
    assert arg_params[1] == 'creates: "/tmp/bar bar"'

# Generated at 2022-06-11 06:26:12.434595
# Unit test for function split_args
def test_split_args():
    # quote types
    single_quote = "'"
    double_quote = '"'
    backslash = "\\"
    quotes = [single_quote, double_quote, backslash]

    # types of jinja block tag
    jinja_block_start = "{{"
    jinja_block_end = "}}"
    jinja_variable_start = "{{"
    jinja_variable_end = "}}"
    jinja_comment_start = "{#"
    jinja_comment_end = "#}"
    jinja_logic_start = "{%"
    jinja_logic_end = "%}"

# Generated at 2022-06-11 06:26:21.351250
# Unit test for function split_args
def test_split_args():
    from ansible.callbacks import vvv

    # test 1
    result = split_args('a=b c="foo bar"')
    assert result == ['a=b', 'c="foo bar"']

    # test 2
    result = split_args('no args')
    assert result == ['no args']

    # test 3
    result = split_args('no args\n')
    assert result == ['no args']

    # test 4
    result = split_args('no args \n')
    assert result == ['no args']

    # test 5
    result = split_args('no args \n more args')
    assert result == ['no args', 'more args']

    # test 6
    result = split_args('no args \n more args \n third arg\n')

# Generated at 2022-06-11 06:26:28.145126
# Unit test for function split_args
def test_split_args():
    '''
    Tests
    '''
    assert split_args('a=1 a=2 a=3') == ['a=1', 'a=2', 'a=3']
    assert split_args('a=1 \\\na=2 \\\na=3') == ['a=1', 'a=2', 'a=3']
    assert split_args('a=1 a=2 a=3 \\\n') == ['a=1', 'a=2', 'a=3']
    assert split_args('a=1 a=2 a=3 ') == ['a=1', 'a=2', 'a=3']
    assert split_args("a=1 a='1 2' a=3") == ['a=1', "a='1 2'", 'a=3']

# Generated at 2022-06-11 06:26:37.114521
# Unit test for function split_args
def test_split_args():
    try:
        import pytest
    except ImportError:
        pytest = None
    if pytest:
        # Quotes
        assert split_args("echo 'hello world'") == ['echo', "'hello world'"]
        assert split_args("echo 'hello world' 'foo bar'") == ['echo', "'hello world'", "'foo bar'"]
        assert split_args("echo 'hello world' 'foo bar' {% if foo %} baz {% endif %}") == ['echo', "'hello world'", "'foo bar'", '{% if foo %} baz {% endif %}']

# Generated at 2022-06-11 06:26:46.334678
# Unit test for function split_args
def test_split_args():

    # no args
    assert split_args('') == ['']

    # some simple args
    assert split_args('a=1 b=2') == ['a=1', 'b=2']

    # some args with quotes
    assert split_args('a=1 b="foo bar"') == ['a=1', 'b="foo bar"']
    assert split_args('a=1 b=\'foo bar\'') == ['a=1', 'b=\'foo bar\'']

    # some args with one pair of quotes inside another
    assert split_args('a=1 b="foo \'bar\'"') == ['a=1', 'b="foo \'bar\'\"']

    # some args with an escaped quote inside the quoted arg

# Generated at 2022-06-11 06:26:54.171030
# Unit test for function split_args
def test_split_args():
    # Test splitting with no args
    assert split_args('') == []

    # Test splitting basic args
    assert split_args('foo') == ['foo']
    assert split_args(' foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args(' foo bar ') == ['foo', 'bar']
    assert split_args('foo bar\n') == ['foo', 'bar\n']

    # Test splitting args with quotes
    assert split_args('"foo bar"') == ['"foo bar"']
    assert split_args("'foo bar'") == ["'foo bar'"]
    assert split_args("'foo bar") == ["'foo bar"]
    assert split_args("foo bar'") == ["foo bar'"]