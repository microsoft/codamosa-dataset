

# Generated at 2022-06-11 06:18:18.424522
# Unit test for function split_args
def test_split_args():
    # Positive tests
    assert split_args('') == [''], "Expected [''] got {}".format(split_args(''))
    assert split_args('ab cd') == ['ab', 'cd'], "Expected ['ab', 'cd'] got {}".format(split_args('ab cd'))
    assert split_args('a=b c=d') == ['a=b', 'c=d'], "Expected ['a=b', 'c=d'] got {}".format(split_args('a=b c=d'))

# Generated at 2022-06-11 06:18:29.002967
# Unit test for function split_args
def test_split_args():
    FAI = {
        "--test 'foo bar'": ['--test', 'foo bar'],
        '--test "foo bar"': ['--test', 'foo bar'],
        '--test "foo bar': ['--test', '"foo bar'],
        '--test "foo bar\\"': ['--test', '"foo bar"'],
        "--test 'foo bar\\'": ['--test', "'foo bar'"],
        "--test 'foo bar' ": ['--test', 'foo bar'],
        "--test 'foo bar''": ['--test', "'foo bar'"],
        "--test 'foo \nbar' ": ['--test', 'foo \nbar'],
    }

    for t in FAI:
        assert split_args(t) == FAI[t]


# Generated at 2022-06-11 06:18:35.279701
# Unit test for function is_quoted
def test_is_quoted():
    assert True == is_quoted('"hello"')
    assert True == is_quoted("'hello'")
    assert False == is_quoted('"hello')
    assert False == is_quoted('hello"')
    assert False == is_quoted('"hello\'')
    assert True == is_quoted('"hello\\""')
    assert True == is_quoted("'hello\\''")


# Generated at 2022-06-11 06:18:44.306357
# Unit test for function split_args
def test_split_args():
    '''
    checks to ensure that the args are split-reassembled correctly
    '''

    # basic split
    args = "one two three"
    expected = ["one", "two", "three"]
    result = split_args(args)
    if result != expected:
        raise Exception("error with basic split")

    # quoted text split
    args = ' "one two three" four'
    expected = [' "one two three"', "four"]
    result = split_args(args)
    if result != expected:
        raise Exception("error with quoted text split")

    # quoted text with embedded newline
    args = ' "one two\nthree" four'
    expected = [' "one two\nthree"', "four"]
    result = split_args(args)

# Generated at 2022-06-11 06:18:55.200583
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted string"') == True
    assert is_quoted("'quoted string'") == True
    assert is_quoted("'single quotes with \"nested double quotes\"'") == True
    assert is_quoted('"nested single quotes: \'hello\'"') == True
    assert is_quoted("'single quoted string'") == True
    assert is_quoted('"single quoted string"') == True
    assert is_quoted('"quoted string with escaped quote \\\" inside"') == True
    assert is_quoted("not quoted") == False
    assert is_quoted("'not quoted") == False
    assert is_quoted("not quoted'") == False


# Generated at 2022-06-11 06:19:06.206589
# Unit test for function split_args
def test_split_args():
    """
    Test function split_args
    """
    # simple string with space
    assert split_args("simple string")[0] == "simple string"

    # quoted string with space
    assert split_args("'quoted string'")[0] == "'quoted string'"

    # quoted string with escaped quote
    assert split_args(r"'quoted \"string'")[0] == "'quoted \\\"string'"

    # complex string with space
    assert split_args(r"foo=bar one=two\ three=four 'quoted string' five=six")[0] == "foo=bar"
    assert split_args(r"foo=bar one=two\ three=four 'quoted string' five=six")[1] == "one=two three=four"

# Generated at 2022-06-11 06:19:15.487552
# Unit test for function split_args
def test_split_args():
    # Basic test
    params = split_args('foo="bar baz"')
    assert params == [u'foo="bar baz"']

    # Test handling of escaped quotes
    params = split_args('foo="bar \\"baz\\""')
    assert params == [u'foo="bar \\"baz\\""']

    # Test handling of escaped quotes and escaped escape
    params = split_args('foo="bar \\\\"baz\\\\"')
    assert params == [u'foo="bar \\\\"baz\\\\"']

    # Test basic quotes
    params = split_args('foo="bar baz" baz="foo bar"')
    assert params == [u'foo="bar baz"', u'baz="foo bar"']

    # Test handling of escaped quotes with spaces

# Generated at 2022-06-11 06:19:26.990000
# Unit test for function split_args
def test_split_args():
    '''
    split_args handles a number of cases that shlex does not.
    '''
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=\"b c\" d=e") == ['a="b c"', 'd=e']
    assert split_args("a='b c' d=e") == ["a='b c'", 'd=e']
    assert split_args("a='b c' d=\"e f\"") == ["a='b c'", 'd="e f"']
    assert split_args("a=b c=\"{{d}}\"") == ['a=b', 'c="{{d}}"']

# Generated at 2022-06-11 06:19:33.964063
# Unit test for function split_args
def test_split_args():
    '''
    Run a number of test cases through the split_args
    utility function to ensure that it works as expected
    in all of the cases.
    '''

# Generated at 2022-06-11 06:19:37.415264
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted("foo")


# Generated at 2022-06-11 06:19:58.216587
# Unit test for function split_args
def test_split_args():
    pairs = dict()

    # This should be a simple split
    pairs['a=1 b=2 c=3'] = ['a=1', 'b=2', 'c=3']

    # This should also be a simple split
    pairs['a=1\nb=2\nc=3'] = ['a=1\n', 'b=2\n', 'c=3']

    # ensure we handle escaped quotation marks in quoted strings
    pairs['a=1 b="foo \" bar" c=3'] = ['a=1', 'b="foo \" bar"', 'c=3']
    pairs['a=1 b="foo \' bar" c=3'] = ['a=1', 'b="foo \' bar"', 'c=3']

# Generated at 2022-06-11 06:20:07.050403
# Unit test for function split_args

# Generated at 2022-06-11 06:20:14.793216
# Unit test for function split_args
def test_split_args():
    '''
    Ensure that arguments split correctly, including:
    - Escaped spaces (`foo\ bar`)
    - Unquoted single space (`foo bar`)
    - Single quotes (`'foo'`)
    - Double quotes (`"foo"`)
    - Jinja2 blocks with spaces (`{{ foo }}`)
    - Jinja2 blocks with quoted text (`{% foo 'bar' %}`)
    - Jinja2 blocks with unquoted text (`{% foo bar %}`)
    '''
    try:
        split_args('echo foo')
    except:
        assert False
    assert split_args('echo foo') == ['echo', 'foo']
    assert split_args('echo "foo bar"') == ['echo', '"foo bar"']

# Generated at 2022-06-11 06:20:25.357804
# Unit test for function split_args

# Generated at 2022-06-11 06:20:36.344765
# Unit test for function split_args

# Generated at 2022-06-11 06:20:46.964334
# Unit test for function split_args
def test_split_args():

    # Test decoding
    args = 'foo bar baz'
    ret = split_args(args)
    assert ret == ['foo', 'bar', 'baz']

    args = u'foo bar baz'
    ret = split_args(args)
    assert ret == ['foo', 'bar', 'baz']

    args = 'foo bar utf8_\xc3\xa9baz'
    ret = split_args(args)
    assert ret == ['foo', 'bar', u'utf8_\xe9baz']

    args = u'foo bar utf8_\xc3\xa9baz'
    ret = split_args(args)
    assert ret == ['foo', 'bar', u'utf8_\xe9baz']

    # test splitting on a newline

# Generated at 2022-06-11 06:20:57.506652
# Unit test for function split_args
def test_split_args():
    result = split_args('a=b c="foo bar"')
    assert result == ['a=b', 'c="foo bar"'], result
    result = split_args('a=b c="foo \\"bar\\""')
    assert result == ['a=b', 'c="foo \\"bar\\""'], result
    result = split_args('a=b c="foo \\"bar\\"" d=\'foo bar\'')
    assert result == ['a=b', 'c="foo \\"bar\\""', "d='foo bar'"], result
    result = split_args('a=b c="foo \\"bar \\\'foo\\\' \\" baz=\\"blah\\"" d=\'foo bar\'')

# Generated at 2022-06-11 06:21:06.124239
# Unit test for function split_args

# Generated at 2022-06-11 06:21:16.353019
# Unit test for function split_args
def test_split_args():
    """
    This function is called when the module is loaded.
    """
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d={{ e=f }}") == ['a=b', 'c="foo bar"', 'd={{ e=f }}']
    assert split_args("a=b c=\"foo bar\" d={{ e=f }} g=h i=\"foo\"") == ['a=b', 'c="foo bar"', 'd={{ e=f }}', 'g=h', 'i="foo"']

# Generated at 2022-06-11 06:21:24.876595
# Unit test for function split_args

# Generated at 2022-06-11 06:21:58.969598
# Unit test for function split_args
def test_split_args():
    assert split_args(r'a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(r'a=b c="foo\\ bar"') == ['a=b', 'c="foo\\ bar"']
    assert split_args(r'a=b c="foo\\" bar"') == ['a=b', 'c="foo\\" bar"']
    assert split_args(r'a=b c="foo\\"" bar"') == ['a=b', 'c="foo\\"" bar"']
    assert split_args(r'a=b c="foo\ bar"') == ['a=b', 'c="foo\ bar"']

# Generated at 2022-06-11 06:22:08.488092
# Unit test for function split_args

# Generated at 2022-06-11 06:22:18.713077
# Unit test for function split_args

# Generated at 2022-06-11 06:22:29.167535
# Unit test for function split_args

# Generated at 2022-06-11 06:22:38.792675
# Unit test for function split_args
def test_split_args():

    def _check_arg_list(args, expected):
        if expected != split_args(args):
            print("Error testing arguments %s" % args)
            print("  result:      %s" % split_args(args))
            print("  expected:    %s" % expected)

    _check_arg_list("a=b c=d", ['a=b', 'c=d'])
    _check_arg_list("a=b 'c=d e=f' g=\"h i=j\" k=\"l=m\"", ['a=b', "c=d e=f", 'g="h i=j"', 'k="l=m"'])


# Generated at 2022-06-11 06:22:48.019175
# Unit test for function split_args
def test_split_args():
    import sys

    # python2 and python3 have different argv encoding,
    # so we need to check for both
    argv1 = "a=b"
    argv2 = "a='b c'"
    argv3 = 'a="b c"'
    argv4 = "a='b\" c'"
    argv5 = 'a="b\' c"'
    argv6 = "a='b c'"
    argv7 = 'a="b c"'
    argv8 = u'a="b c"'
    argv9 = "a={{ foo }}"
    argv10 = "a=bar {{ foo }}"
    argv11 = "a='bar {{ foo }}'"
    argv12 = 'a="bar {{ foo }}"'
    argv13 = u'a="bar {{ foo }}"'
    argv

# Generated at 2022-06-11 06:22:58.183577
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo \nbar\"") == ['a=b', 'c="foo \nbar"']
    assert split_args("a=b c=\"foo \n\nbar\"") == ['a=b', 'c="foo \n\nbar"']
    assert split_args("a=b c=\"foo \\nbar\"") == ['a=b', 'c="foo \nbar"']
    assert split_args("a=b c=\"{{ foo }}\"") == ['a=b', 'c="{{ foo }}"']
    assert split_args("a=b c=\"{{ foo }}bar\"") == ['a=b', 'c="{{ foo }}bar"']
    assert split

# Generated at 2022-06-11 06:23:07.595566
# Unit test for function split_args

# Generated at 2022-06-11 06:23:16.398029
# Unit test for function split_args
def test_split_args():
    def test_split_args_with_input(task_vars, args_to_parse):
        '''
        This function tests the split_args() function.  It is intended to be used in other
        tests to confirm that split_args() returns the expected list of args.

        args_to_parse should be a list of the individual args that are expected in the result.
        '''
        # args_to_parse will be converted to a long string and passed to our split_args().
        # The test will pass if the output of split_args() matches args_to_parse
        result = split_args(" ".join(args_to_parse))
        assert result == args_to_parse

    # The test requires the "task_vars" variable, but we don't use it here.
    # So, we'll just use an empty dict.


# Generated at 2022-06-11 06:23:26.437075
# Unit test for function split_args

# Generated at 2022-06-11 06:24:23.686680
# Unit test for function split_args
def test_split_args():
    ''' split_args() unit tests '''
    import sys

    def compare(expected, actual, tests_run=None):
        ''' compares expected and actual and reports on differences '''
        result = (actual == expected)
        if tests_run is not None:
            tests_run[0] += 1
        if not result:
            print(u"expected: ")
            print(u"%s" % expected)
            print(u"got: ")
            print(u"%s" % actual)
        return result

    def run_test(test_string, expected, tests_run=None):
        ''' runs one test and returns results of the test '''
        actual = split_args(test_string)
        return compare(expected, actual, tests_run)

    # test_string, expected result
    test_

# Generated at 2022-06-11 06:24:32.726526
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("echo 'foo bar'") == ["echo 'foo bar'"]
    assert split_args("/bin/foo \"bar baz\"") == ['/bin/foo "bar baz"']
    assert split_args("/bin/foo 'bar baz'") == ['/bin/foo \'bar baz\'']
    assert split_args("/usr/bin/python ./relative/path/to/file.txt") == ['/usr/bin/python', './relative/path/to/file.txt']

# Generated at 2022-06-11 06:24:42.270991
# Unit test for function split_args
def test_split_args():

    # passing in a simple arg with no spaces, no jinja2, and not quoted
    params = split_args("foo=bar")
    assert len(params) == 1
    assert params[0] == "foo=bar"

    # passing in a simple arg with no spaces, no jinja2, and quoted
    params = split_args("foo='bar baz'")
    assert len(params) == 1
    assert params[0] == "foo='bar baz'"

    # this should split into two args
    params = split_args("foo=bar baz=bam")
    assert len(params) == 2
    assert params[0] == "foo=bar"
    assert params[1] == "baz=bam"

    # this should split into two args, but the second should be joined due to the quotes
    params

# Generated at 2022-06-11 06:24:52.193357
# Unit test for function split_args
def test_split_args():
    assert split_args("cmd") == ['cmd']
    assert split_args("cmd a=b c='foo bar'") == ['cmd', 'a=b', "c='foo bar'"]
    assert split_args("cmd a={{b}} c='foo bar'") == ['cmd', 'a={{b}}', "c='foo bar'"]
    assert split_args("cmd a={{b}} c='foo bar' {# comments #}") == ['cmd', 'a={{b}}', "c='foo bar' {# comments #}"]
    assert split_args('cmd "a=b" c="foo bar"') == ['cmd', '"a=b"', 'c="foo bar"']

# Generated at 2022-06-11 06:25:01.407224
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u"a='foo bar'") == [u"a='foo bar'"]
    assert split_args(u"a='foo bar' b='foo bar'") == [u"a='foo bar'", u"b='foo bar'"]
    assert split_args(u"a='foo bar' b=c d=hello") == [u"a='foo bar'", u"b=c", u"d=hello"]
    assert split_args(u"a=b 'foo bar'") == [u"a=b", u"'foo bar'"]

# Generated at 2022-06-11 06:25:10.675639
# Unit test for function split_args
def test_split_args():
    ''' test split_args
    '''
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    args = "a=b c='foo bar' d='hello world'"
    params = split_args(args)
    assert len(params) == 3, "first argument should have 3 params"
    assert params[0] == 'a=b', "first argument should be a=b"
    assert params[1] == "c='foo bar'", "second argument should be c='foo bar'"
    assert params[2] == "d='hello world'", "second argument should be d='hello world'"


# Generated at 2022-06-11 06:25:18.923812
# Unit test for function split_args
def test_split_args():
    import os

    # test direct quotes
    assert split_args("foo='bar'") == ["foo='bar'"]
    assert split_args("foo=\"bar\"") == ["foo=\"bar\""]
    assert split_args("foo=\"bar\" baz=\"quux\"") == ["foo=\"bar\"", "baz=\"quux\""]
    assert split_args("foo='bar' baz='quux'") == ["foo='bar'", "baz='quux'"]
    assert split_args("foo=\"bar baz\"") == ["foo=\"bar baz\""]
    assert split_args("foo=\"bar baz\" quux") == ["foo=\"bar baz\"", "quux"]

# Generated at 2022-06-11 06:25:27.361487
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []

    assert split_args("a=b c=d") == [ "a=b", "c=d" ]

    assert split_args("a=b 'c d'") == [ "a=b", "c d" ]
    assert split_args('a=b "c d"') == [ "a=b", "c d" ]

    assert split_args("a=b 'c d' e=f") == [ "a=b", "c d", "e=f" ]
    assert split_args('a=b "c d" e=f') == [ "a=b", "c d", "e=f" ]

    assert split_args("a=b 'c \" d' e=f") == [ "a=b", "c \" d", "e=f" ]
   

# Generated at 2022-06-11 06:25:35.982354
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b "c=d"') == [u'a=b', u'"c=d"']
    assert split_args(u'a=b "c=d" e=f "g=h"') == [u'a=b', u'"c=d"', u'e=f', u'"g=h"']
    assert split_args(u'a=b "c=d" e=f "g=h" i=j "k=l"') == [u'a=b', u'"c=d"', u'e=f', u'"g=h"', u'i=j', u'"k=l"']
    assert split

# Generated at 2022-06-11 06:25:45.821704
# Unit test for function split_args

# Generated at 2022-06-11 06:26:47.485005
# Unit test for function split_args

# Generated at 2022-06-11 06:26:55.536123
# Unit test for function split_args
def test_split_args():

    # test none value
    assert split_args(None) == []

    # test quotes
    assert split_args('foo="bar baz"') == ['foo=bar baz']
    assert split_args("foo='bar baz'") == ['foo=bar baz']
    assert split_args('foo=\'bar baz"') == ['foo=\'bar baz"']
    assert split_args('foo="bar \'baz"') == ['foo=bar \'baz']

# Generated at 2022-06-11 06:27:03.841156
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []

    #test for single bareword
    assert split_args('test') == ['test']

    #test for multiple barewords
    assert split_args('test1 test2') == ['test1', 'test2']

    #test for leading and trailing whitespace
    assert split_args('   test   ') == ['test']

    #test for single quoted string
    assert split_args('"test"') == ['test']

    #test for single quoted string with whitespace
    assert split_args('"te st"') == ['te st']

    #test for multiple quoted strings
    assert split_args('"test1" "test2"') == ['test1', 'test2']

    #test for single quoted string with single quote inside

# Generated at 2022-06-11 06:27:11.627056
# Unit test for function split_args
def test_split_args():
    result = split_args("key=val")
    assert result == ["key=val"]

    result = split_args("key='val'")
    assert result == ["key='val'"]

    result = split_args("key=val val2")
    assert result == ["key=val", "val2"]

    result = split_args("key val val2")
    assert result == ["key", "val", "val2"]

    result = split_args("key=\"val\" val2")
    assert result == ["key=\"val\"", "val2"]

    result = split_args("key=\"value with spaces\" val2")
    assert result == ["key=\"value with spaces\"", "val2"]

    result = split_args("key=\"value with spaces\" val2 val3=\"something else\"")

# Generated at 2022-06-11 06:27:20.465646
# Unit test for function split_args
def test_split_args():
    def cmp(args1, args2):
        return set(split_args(args1)) == set(split_args(args2))
    assert cmp("a=b", "a=b")
    assert cmp("a=b 'c d'", "a=b c\\ d")
    assert cmp("a=b {{foo}}", "a=b {{ foo }}")
    assert cmp("a=b {{foo}}", 'a=b {{foo\n}}')
    assert cmp("a=b {{foo}}", 'a=b {{\nfoo\n}}')
    assert cmp("a=b {{foo}}", 'a=b {{\nfoo}}')
    assert cmp("a=b {{foo}}", "a=b {{ foo\n}}")

# Generated at 2022-06-11 06:27:28.941095
# Unit test for function split_args
def test_split_args():

    # assert if the result of split_args is equal to a list of expected items
    def assert_split_args(args, expected_results):

        actual_results = split_args(args)
        assert actual_results == expected_results, "result of split_args of '%s' is %s, expected %s" % (args, actual_results, expected_results)

    assert_split_args("a=1", ['a=1'])
    assert_split_args("a=1 b=2", ['a=1', 'b=2'])
    assert_split_args("a=1 'b c'", ['a=1', "'b c'"])
    assert_split_args("a=1 \\\"b c\\\"", ['a=1', '"b c"'])

# Generated at 2022-06-11 06:27:38.262745
# Unit test for function split_args

# Generated at 2022-06-11 06:27:39.097460
# Unit test for function split_args
def test_split_args():
    # TODO: Write this.
    pass



# Generated at 2022-06-11 06:27:48.325094
# Unit test for function split_args

# Generated at 2022-06-11 06:27:54.404191
# Unit test for function split_args
def test_split_args():
    import os
    import sys
    import traceback
    import ansible.module_utils.basic
    assert sys.argv[0] == '<stdin>'
    my_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})

    # Below is the result of 'ansible-doc -t module ping'