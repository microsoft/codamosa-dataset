

# Generated at 2022-06-11 06:18:20.067198
# Unit test for function is_quoted
def test_is_quoted():
    # Strings that should be quoted
    assert is_quoted("'this'")
    assert is_quoted("'this \'should\' work'")
    assert is_quoted('"this \"should\" work"')
    # Strings that should not be quoted
    assert not is_quoted("'\"this\"'")
    assert not is_quoted("'\\this\\'")
    assert not is_quoted("'this")
    assert not is_quoted("this'")
    assert not is_quoted('"this"')
    assert not is_quoted('\\"this\\"')
    assert not is_quoted('\\"this')
    assert not is_quoted('this\\"')


# Generated at 2022-06-11 06:18:24.659739
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'a\"b\"c'") == 'a"b"c'
    assert unquote("'a'") == "a"
    assert unquote("''") == ""
    assert unquote("") == ""

# Generated at 2022-06-11 06:18:31.617134
# Unit test for function unquote
def test_unquote():
    assert unquote('foobar') == 'foobar'
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('"foo\'bar"') == "foo\'bar"
    assert unquote("'foo\"bar'") == 'foo"bar'
    assert unquote('"foo\'bar"') == "foo\'bar"


# Generated at 2022-06-11 06:18:33.555196
# Unit test for function unquote
def test_unquote():
    string = '"unquoted"'
    assert unquote(string) == 'unquoted'


# Generated at 2022-06-11 06:18:41.064100
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted('""') == True
    assert is_quoted("''") == True
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted('ab"cd"') == False
    assert is_quoted("ab'cd'") == False
    assert is_quoted('a"b"c') == False
    assert is_quoted("a'b'c") == False


# Generated at 2022-06-11 06:18:46.286659
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"') == True
    assert is_quoted("'foobar'") == True
    assert is_quoted("foobar") == False
    assert is_quoted("'foo'bar'") == False
    assert is_quoted('"foo"bar"') == False



# Generated at 2022-06-11 06:18:49.615902
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote("'foo'") == 'foo'


# Generated at 2022-06-11 06:18:58.833497
# Unit test for function split_args

# Generated at 2022-06-11 06:19:11.070943
# Unit test for function split_args

# Generated at 2022-06-11 06:19:20.942159
# Unit test for function split_args
def test_split_args():
    # Simple args with no quoting
    assert split_args("foo bar") == ["foo", "bar"]

    # Simple args with no quoting
    assert split_args("foo bar baz=\"foo bar baz\"") == ["foo", "bar", "baz=\"foo bar baz\""]

    # Simple args with quotes inside a quoted string
    assert split_args("foo bar baz=\"foo bar baz\" qux='foo bar baz'") == ["foo", "bar", "baz=\"foo bar baz\"", "qux='foo bar baz'"]

    # Simple args with newlines
    assert split_args("foo\nbar\nbaz=foo bar baz") == ["foo\n", "bar\n", "baz=foo bar baz"]

    # Simple args with backslashes

# Generated at 2022-06-11 06:19:44.850829
# Unit test for function split_args
def test_split_args():
    import unittest


# Generated at 2022-06-11 06:19:54.187503
# Unit test for function split_args
def test_split_args():

    def same_split(args, expected):
        ''' ensure that the args split into the same thing with whitespace as a delimeter '''
        expected.sort()
        actual = split_args(args)
        actual.sort()
        assert expected == actual, "expected[%s] != actual[%s] for args[%s]" % (expected, actual, args)

    def same_split_with_nl(args, expected):
        ''' ensure that both spliting on whitespace and on newlines give the same results '''
        expected.sort()
        actual = split_args(args.replace(' ', '\n'))
        actual.sort()
        assert expected == actual, "expected[%s] != actual[%s] for args[%s]" % (expected, actual, args)


# Generated at 2022-06-11 06:20:00.633581
# Unit test for function split_args

# Generated at 2022-06-11 06:20:08.727362
# Unit test for function split_args
def test_split_args():
    import pytest

    # Test with multiple lines and line continuation
    def test_result_line_continuation_1(args, output):
        assert split_args(args) == output
    test_result_line_continuation_1.parametrize = [
        ('a=b c="foo bar" d="123\\\n456" \\\ne="foo\nbar"', ['a=b', 'c="foo bar"', 'd="123\n456" \ne="foo', 'bar"']),
        ('a=b c="foo\\', ' bar" d="123\\\n456" \\\ne="foo\nbar"', ['a=b c="foo bar"', 'd="123\n456" \ne="foo\nbar"']),
    ]
    pytest.main()

    # Test with multiple lines and

# Generated at 2022-06-11 06:20:15.750844
# Unit test for function split_args
def test_split_args():
    """
    Test that the function split_args can properly split
    the args into params.
    """

# Generated at 2022-06-11 06:20:26.227192
# Unit test for function split_args

# Generated at 2022-06-11 06:20:37.077795
# Unit test for function split_args
def test_split_args():
    assert split_args(u"") == [u""]
    assert split_args(u"a=b") == [u"a=b"]
    assert split_args(u"a=\\") == [u"a=\\"]
    assert split_args(u"a=\\\n") == [u"a=\\\n"]
    assert split_args(u"foo") == [u"foo"]
    assert split_args(u"foo bar") == [u"foo", u"bar"]
    assert split_args(u"foo bar baz") == [u"foo", u"bar", u"baz"]
    assert split_args(u"foo 'bar baz'") == [u"foo", u"'bar baz'"]

# Generated at 2022-06-11 06:20:47.753448
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("     ") == []
    assert split_args("    hello   world   ") == ['hello', 'world']
    assert split_args("    hello   'world world'   ") == ['hello', "'world world'"]
    assert split_args("    hello   'multiple words inside single quotes'   ") == ['hello', "'multiple words inside single quotes'"]
    assert split_args("    hello   \"multiple words inside double quotes\"   ") == ['hello', '"multiple words inside double quotes"']
    assert split_args("    {% if foo %}   ") == ['{%', 'if', 'foo', '%}']

# Generated at 2022-06-11 06:20:58.186094
# Unit test for function split_args
def test_split_args():
    data = "a=b c=\"foo bar\""
    params = split_args(data)
    assert params == ['a=b', 'c="foo bar"']
    data = "a=b 'c=foo bar'"
    params = split_args(data)
    assert params == ['a=b', "'c=foo bar'"]
    data = "a=b C='foo bar'"
    params = split_args(data)
    assert params == ['a=b', 'C=\'foo bar\'']
    data = "a=b c='foo bar'"
    params = split_args(data)
    assert params == ['a=b', "c='foo bar'"]
    data = "a=b c='foo bar'"
    params = split_args(data)

# Generated at 2022-06-11 06:21:06.531596
# Unit test for function split_args
def test_split_args():
    all_input_and_results = (
        ('foo', ['foo']),
        ('foo bar', ['foo', 'bar']),
        ('foo=bar', ['foo=bar']),
        ('foo bar=baz', ['foo', 'bar=baz']),
        ('foo=bar baz=quux', ['foo=bar', 'baz=quux']),
        ('foo="bar baz"', ['foo="bar baz"']),
        ('foo="bar baz" quux="foo bar"', ['foo="bar baz"', 'quux="foo bar"']),
    )

    for input_data, expected_result in all_input_and_results:
        result = split_args(input_data)

# Generated at 2022-06-11 06:21:24.847512
# Unit test for function split_args

# Generated at 2022-06-11 06:21:30.458269
# Unit test for function split_args
def test_split_args():
    '''
    runs split_args over all the basic test cases
    '''

    # this list of tuples makes up the test cases
    # the first item in the tuples is the args string that we test
    # the second item is the expected results after we call split_args on it

# Generated at 2022-06-11 06:21:40.190547
# Unit test for function split_args
def test_split_args():
    ''' Unit test for function split_args '''

    assert split_args('') == []


# Generated at 2022-06-11 06:21:47.839212
# Unit test for function split_args
def test_split_args():
    # simple test cases of single-word arguments
    assert split_args('a=1') == ['a=1']
    assert split_args('a="1"') == ['a="1"']
    assert split_args('a="{{ foo }}"') == ['a="{{ foo }}"']
    assert split_args('a="{{ foo }} {{ bar }}"') == ['a="{{ foo }} {{ bar }}"']
    assert split_args('a="{{ foo }} {{ bar }} {{ bam }}"') == ['a="{{ foo }} {{ bar }} {{ bam }}"']

    # multiple single-word arguments
    assert split_args('a=1 b=2') == ['a=1', 'b=2']

# Generated at 2022-06-11 06:21:59.056947
# Unit test for function split_args

# Generated at 2022-06-11 06:22:08.524427
# Unit test for function split_args
def test_split_args():
    '''
    These examples are particularly difficult to parse,
    as they would require white space between the quotes
    when they are sent over the wire, which would make
    the parser fail, as the equal sign is not quoted.
    '''

    # one arg with no special symbols
    assert split_args('foo') == ['foo']

    # one arg with quotes
    assert split_args('"foo"') == ['foo']

    # simple arg with equal and quotes
    assert split_args('a="b c"') == ['a="b c"']

    # multiple args with equal and quotes
    assert split_args('a="b c" e="f g"') == ['a="b c"', 'e="f g"']

    # multiple args with equal and quotes, two args on one line

# Generated at 2022-06-11 06:22:18.713556
# Unit test for function split_args
def test_split_args():
    # Test single quote
    assert split_args("foo='bar baz'") == ["foo='bar baz'"]
    # Test empty string
    assert split_args('') == []
    # Test no args
    assert split_args(' ') == []
    # Test jinja2 block
    assert split_args('foo="{{ bar }}"') == ['foo="{{ bar }}"']
    # Test jinja2 block with args
    assert split_args('foo="{{ bar }}" baz=quux') == ['foo="{{ bar }}"', 'baz=quux']
    # Test jinja2 block with args with quotes
    assert split_args('foo="{{ bar }}" baz="blah blah"') == ['foo="{{ bar }}"', 'baz="blah blah"']
    # Test jinja

# Generated at 2022-06-11 06:22:29.168704
# Unit test for function split_args
def test_split_args():
    assert split_args(r'a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(r'a=b c="foo bar\"baz\"blam"') == ['a=b', 'c="foo bar\\"baz\\"blam"']
    assert split_args(r'foo="bar \n baz"') == [r'foo="bar \n baz"']
    assert split_args(r'foo="bar \n baz\"') == [r'foo="bar \n baz\\"']
    assert split_args(r'foo="bar \n baz\ "') == [r'foo="bar \n baz\ ']

# Generated at 2022-06-11 06:22:38.830952
# Unit test for function split_args

# Generated at 2022-06-11 06:22:48.070198
# Unit test for function split_args

# Generated at 2022-06-11 06:23:14.536366
# Unit test for function split_args
def test_split_args():

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\'') == ['a=b', 'c="foo bar\'']
    assert split_args('c="foo bar\' d=e') == ['c="foo', 'bar\'', 'd=e']
    assert split_args('c="\\\\" d=e') == ['c="\\\\"', 'd=e']
    assert split_args('c="\\" d=e') == ['c="\\" d=e']


# Generated at 2022-06-11 06:23:24.093412
# Unit test for function split_args
def test_split_args():
    args = '''a=b "c d" 'foo bar' "{{ ansible_env.HOME }}"  "{% if foo %}yes{% else %}no{% endif %}" {# this is a comment #}'''
    split = split_args(args)
    assert split == ['a=b', '"c d"', "'foo bar'", '"{{ ansible_env.HOME }}"', '"{% if foo %}yes{% else %}no{% endif %}"', '{# this is a comment #}']
    print("SUCCESS split_args on {0}".format(args))


# Generated at 2022-06-11 06:23:31.324763
# Unit test for function split_args

# Generated at 2022-06-11 06:23:41.400656
# Unit test for function split_args

# Generated at 2022-06-11 06:23:51.330113
# Unit test for function split_args
def test_split_args():
    '''
    This is a simple sanity check for the split_args function.
    '''


# Generated at 2022-06-11 06:24:01.293557
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("foo") == ['foo']
    assert split_args("foo bar") == ['foo', 'bar']
    assert split_args("foo bar baz") == ['foo', 'bar', 'baz']
    assert split_args("foo=bar") == ['foo=bar']
    assert split_args("foo=\"bar\"") == ['foo="bar"']
    assert split_args("foo='bar'") == ["foo='bar'"]
    assert split_args("foo=\"bar\" baz=\"qux\"") == ['foo="bar"', 'baz="qux"']
    assert split_args("foo='bar' baz='qux'") == ["foo='bar'", "baz='qux'"]
    assert split_args("foo=bar baz=qux")

# Generated at 2022-06-11 06:24:11.517176
# Unit test for function split_args
def test_split_args():
    '''
    split_args test harness
    '''
    teststr1 = 'a=b c="foo bar"'
    expresult1 = ['a=b', 'c="foo bar"']

    teststr2 = 'a="foo bar" c=d'
    expresult2 = ['a="foo bar"', 'c=d']

    teststr3 = 'a="foo bar" c="one two"'
    expresult3 = ['a="foo bar"', 'c="one two"']

    teststr4 = 'a=b c="foo bar" d=e'
    expresult4 = ['a=b', 'c="foo bar"', 'd=e']

    teststr5 = 'a={{ b }} c="{{ d }}"'
    expresult5 = ['a={{ b }}', 'c="{{ d }}"']

# Generated at 2022-06-11 06:24:22.949830
# Unit test for function split_args

# Generated at 2022-06-11 06:24:31.765559
# Unit test for function split_args

# Generated at 2022-06-11 06:24:41.364489
# Unit test for function split_args
def test_split_args():
    items = []

    items.append(("foo=bar baz=\"hello world\"", ['foo=bar', 'baz="hello world"']))
    items.append(("foo=bar baz='hello world'", ['foo=bar', "baz='hello world'"]))
    items.append(("foo=bar baz=\"hello world", ['foo=bar', 'baz="hello world']))
    items.append(("foo=bar baz='hello world", ['foo=bar', "baz='hello world"]))
    items.append(("foo=bar 'baz=hello world'", ['foo=bar', "'baz=hello world'"]))
    items.append(("foo=bar 'baz=hello world", ['foo=bar', "'baz=hello world"]))

# Generated at 2022-06-11 06:25:31.209927
# Unit test for function split_args
def test_split_args():

    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args(' a=b c=d ') == ['a=b', 'c=d']
    assert split_args(' a=b c=d ') == ['a=b', 'c=d']
    assert split_args('a=b "c d"') == ['a=b', '"c d"']
    assert split_args('a=b "c d=e f"') == ['a=b', '"c d=e f"']
    assert split_args('a=b "c d=e \'f g\'"') == ['a=b', '"c d=e \'f g\'"']

# Generated at 2022-06-11 06:25:40.524351
# Unit test for function split_args
def test_split_args():

    split_args_testcases = (
        # Testcase
        # 1  -> Args to split
        # 2  -> Expected output
        (["a=b c=\"foo bar\""], [u'a=b', u'c="foo bar"']),
        (["a=b c={{ foo }}"], [u'a=b', u'c={{ foo }}']),
        (["a=b c={{ foo }}"], [u'a=b', u'c={{ foo }}']),
        (["a=\"b c={{ foo }}\""], [u'a="b c={{ foo }}"'])
    )

    for testcase in split_args_testcases:
        inp, expected = testcase
        output = split_args(inp[0])

# Generated at 2022-06-11 06:25:49.784132
# Unit test for function split_args
def test_split_args():
    # tests based on examples from the docstring above
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"\nd=e f="foo bar"') == ['a=b c="foo bar"\n', 'd=e f="foo bar"']
    assert split_args('a=b c="foo bar"\nd=e f="foo bar"\n') == ['a=b c="foo bar"\n', 'd=e f="foo bar"\n']

    # tests based on examples from the description above

# Generated at 2022-06-11 06:25:57.067789
# Unit test for function split_args
def test_split_args():
    result = split_args("foo='{{ bar }}' baz=\"{{ blah.something }}\"")
    assert result == ['foo=\'{{ bar }}\'', 'baz="{{ blah.something }}"']
    result = split_args("foo=\"{{ '\"{' }}\"\"\"")
    assert result == ['foo="{{ \'"{\' }}"""']
    result = split_args("foo=\"{{ '\"' }}\" bar='{{ \"' }}'")
    assert result == ["foo=\"{{ '\"' }}\"", 'bar=\'{{ "\'" }}\'']
    result = split_args("foo=\"{{ '\"{' }}\"\"\"")
    assert result == ['foo="{{ \'"{\' }}"""']
    result = split_args("foo=\"{{ \\\" }}\"")

# Generated at 2022-06-11 06:26:05.485293
# Unit test for function split_args
def test_split_args():

    def _test(input, expected):
        actual = split_args(input)
        assert actual == expected, "'%s' != '%s'" % (actual, expected)



# Generated at 2022-06-11 06:26:13.384221
# Unit test for function split_args
def test_split_args():
    ''' tests unquoted args '''
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    ''' tests quoted args '''
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar baz" x') == ['foo', '"bar baz"', 'x']
    assert split_args('"bar baz" x') == ['"bar baz"', 'x']
    assert split_args('"bar baz"') == ['"bar baz"']
    assert split_args('x "bar baz"') == ['x', '"bar baz"']
    assert split_args('"bar baz" x') == ['"bar baz"', 'x']

# Generated at 2022-06-11 06:26:22.173391
# Unit test for function split_args
def test_split_args():

    def _test(argstring, expected):
        result = split_args(argstring)

        # make sure the result is the expected length
        if len(result) != len(expected):
            return "split_args did not return the correct number of elements"

        # make sure the values in the result are correct
        for idx, val in enumerate(expected):
            if val != result[idx]:
                print("result: %s" % result)
                print("expected: %s" % expected)
                return "split_args did not return the correct values"

        # if we got this far, the test was successful
        return

    # run all the tests

# Generated at 2022-06-11 06:26:28.794354
# Unit test for function split_args

# Generated at 2022-06-11 06:26:37.694991
# Unit test for function split_args
def test_split_args():

    # args is empty
    assert(split_args('') == [])

    # args is only whitespace
    assert(split_args('\n') == [''])
    assert(split_args(' \t \n \t ') == ['', '', ''])

    # args is a single word
    assert(split_args('foo') == ['foo'])
    assert(split_args(' foo') == ['foo'])
    assert(split_args('foo ') == ['foo'])
    assert(split_args(' foo ') == ['foo'])
    assert(split_args(' foo bar ') == ['foo', 'bar'])

    # args is a quoted string
    assert(split_args('"foo bar"') == ['"foo bar"'])

# Generated at 2022-06-11 06:26:46.810043
# Unit test for function split_args
def test_split_args():
    '''
    Basic unit test for function split_args

    NOTE:
    - It uses predefined test_table data
    - The test_table data contains: input, expected result
    - If the test fails, the following will happen:
      - We print the input arg
      - We print the output of split_args(input)
      - We print the expected output (from test_table data)
    '''