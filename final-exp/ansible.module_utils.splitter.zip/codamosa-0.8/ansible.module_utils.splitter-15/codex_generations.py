

# Generated at 2022-06-11 06:18:20.552935
# Unit test for function split_args
def test_split_args():
    # basic tests
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo bar baz "blah foo"') == ['foo', 'bar', 'baz', '"blah foo"']
    assert split_args('foo "bar baz') == ['foo', '"bar', 'baz']

    # we don't support using single quotes, but this will happen
    # until smart parsing is added
    assert split_args("foo 'bar baz'") == ['foo', "'bar", "baz'"]

    # make sure we can split on newlines, and preserve newlines

# Generated at 2022-06-11 06:18:32.047506
# Unit test for function split_args
def test_split_args():
    # test normal case
    params = split_args("a=b c=\"foo bar\"")
    assert params == ['a=b', 'c="foo bar"']

    # same as above, but test spaces in quotes
    params = split_args('a=b c="foo bar"')
    assert params == ['a=b', 'c="foo bar"']

    # same as above, but test with short syntax for quoting
    params = split_args("a=b c='foo bar'")
    assert params == ['a=b', "c='foo bar'"]

    # same as above, but test with short syntax for quoting
    params = split_args('a=b c=\'foo bar\'')
    assert params == ['a=b', "c='foo bar'"]

    # test with jinja2 and short syntax quotes
    params

# Generated at 2022-06-11 06:18:42.220432
# Unit test for function split_args

# Generated at 2022-06-11 06:18:54.896426
# Unit test for function split_args

# Generated at 2022-06-11 06:19:05.485724
# Unit test for function split_args

# Generated at 2022-06-11 06:19:10.374690
# Unit test for function split_args
def test_split_args():
    import pytest

    # Test unbalanced quotes
    args = [("a=b c='foo", "malformed string"),
            ("a=b c='foo bar", "malformed string"),
            ("a=b c='foo bar' d=e 'foo bar' f=g", "malformed string"),
            ("a=b c='foo bar' d=e 'foo bar f=g", "malformed string")]

    for arg, expected in args:
        with pytest.raises(Exception):
            split_args(arg)

    # Test unbalanced jinja2

# Generated at 2022-06-11 06:19:19.616099
# Unit test for function split_args
def test_split_args():
    # test empty string
    inp = ""
    out = []
    res = split_args(inp)
    assert res == out, "Got: %s, expected: %s" % (res, out)
    #test a simple string
    inp = "foo bar baz"
    out = ["foo", "bar", "baz"]
    res = split_args(inp)
    assert res == out, "Got: %s, expected: %s" % (res, out)
    # quote-delimited strings should be parsed as a single token
    inp = "a=\"foo bar\" b=\"baz\""
    out = ["a=foo bar", "b=baz"]
    res = split_args(inp)

# Generated at 2022-06-11 06:19:30.400450
# Unit test for function split_args
def test_split_args():
    print("### Testing split_args ###")
    import shlex

    # This list of args is taken from the unix command "find".
    # In the standard
    #
    # The format of list is:
    # arg, arg_with_j2, posix_split_list, split_list
    # where
    #   arg: the arg as it would be given to the cli
    #   arg_with_j2: a version of the arg with jinja2 {{}} blocks inserted
    #   posix_split_list: the list that the arg would be split into using the shlex.split
    #   split_list: the list that the arg would be split into using this split_args function

# Generated at 2022-06-11 06:19:39.508681
# Unit test for function split_args
def test_split_args():
    import json


# Generated at 2022-06-11 06:19:44.935738
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("''") is True
    assert is_quoted("'foo'") is True
    assert is_quoted('""') is True
    assert is_quoted('"foo"') is True
    assert is_quoted("") is False
    assert is_quoted("foo") is False
    assert is_quoted("'foo") is False
    assert is_quoted("foo'") is False


# Generated at 2022-06-11 06:20:09.220299
# Unit test for function split_args
def test_split_args():
    ''' Unit test for function split_args '''

    # test args with no quotes and no jinja2
    test_string = "one two three"
    test_list = split_args(test_string)
    assert test_list == ['one', 'two', 'three']

    # test args with no quotes and simple jinja2
    test_string = "one two {{ foo }} three"
    test_list = split_args(test_string)
    assert test_list == ['one', 'two', '{{ foo }}', 'three']

    # test args with double quotes and no quotes
    test_string = "one two \"foo bar\" three"
    test_list = split_args(test_string)
    assert test_list == ['one', 'two', '"foo bar"', 'three']

    # test args with single

# Generated at 2022-06-11 06:20:18.554904
# Unit test for function split_args
def test_split_args():
    '''Test cases for the split_args function'''


# Generated at 2022-06-11 06:20:29.445141
# Unit test for function split_args
def test_split_args():
    t1 = '''a=b c='foo bar' "foo bar" d="A
B" e='A
B' f="A
B" 'A
B' g="A B" h='A B' i=A\\ B j="A
B
C" k='A
B
C' l="A
B
C" 'A
B
C' m="A B C" n='A B C' o=A\\ B\\ C'''

# Generated at 2022-06-11 06:20:38.637983
# Unit test for function split_args

# Generated at 2022-06-11 06:20:49.323178
# Unit test for function split_args

# Generated at 2022-06-11 06:20:59.638089
# Unit test for function split_args
def test_split_args():

    raw = 'a=b c="foo bar" d=\'{ "a":"{{ a_var }}" }\''
    parsed = split_args(raw)
    assert parsed == ['a=b', 'c="foo bar"', 'd=\'{ "a":"{{ a_var }}" }\''], parsed

    raw = 'a=b c="foo bar" d=\'{ "a":"{{ a_var }}" }\' e=\\\nf'
    parsed = split_args(raw)
    assert parsed == ['a=b', 'c="foo bar"', 'd=\'{ "a":"{{ a_var }}" }\'', 'e=f'], parsed

    raw = 'a=b c="foo bar" d=\'[ "a","{{ a_var }}" ]\''
    parsed = split_args(raw)

# Generated at 2022-06-11 06:21:03.363894
# Unit test for function split_args
def test_split_args():
    result = split_args("a=b c='d e' f=\"g h\"")
    assert result == ['a=b', "c='d e'", 'f="g h"']

    result = split_args("a=b 'c d'")
    assert result == ['a=b', "'c d'"]

# Generated at 2022-06-11 06:21:09.271977
# Unit test for function split_args
def test_split_args():
    # Test a single quoted string
    assert split_args('c="foo bar"') == ['c="foo bar"']
    assert split_args('c="foo bar') == ['c="foo bar']
    assert split_args('c="foo bar\'"') == ['c="foo bar\'"']
    assert split_args('c="foo bar\'" d') == ['c="foo bar\'"', 'd']
    assert split_args('"foo bar"') == ['"foo bar"']
    assert split_args('"foo bar') == ['"foo bar']
    assert split_args('"foo bar\'"') == ['"foo bar\'"']
    assert split_args('"foo bar\'" d') == ['"foo bar\'"', 'd']

    # Test a single quoted string with escaped quotes inside

# Generated at 2022-06-11 06:21:19.307007
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import text_type

    # Test for string
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test for AnsibleUnsafeText
    if not PY3:
        args = AnsibleUnsafeText(u'a=b c="foo bar"')
    else:
        args = AnsibleUnsafeText('a=b c="foo bar"')
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test for text_type
    args = text_type('a=b c="foo bar"')

# Generated at 2022-06-11 06:21:26.585083
# Unit test for function split_args

# Generated at 2022-06-11 06:22:01.100010
# Unit test for function split_args
def test_split_args():

    def _test(string, result):
        assert split_args(string) == result

    # this is a simple test that is not jinja2, or quote related at all
    _test('ls sda', ['ls', 'sda'])

    # test a simple string that is in quotes
    _test('ls "hello world"', ['ls', '"hello world"'])

    # here we test that a quote can appear in a string that
    # is in quotes, since the quote is inside a quoted string
    # it does not terminate the string
    _test('ls "hello \\"world\\""', ['ls', '"hello \\"world\\""'])

    # here we test that an escaped jinja2 block that is not closed
    # can appear in a string, because the backslash is inside the
    # quotes and so it will not

# Generated at 2022-06-11 06:22:09.863670
# Unit test for function split_args
def test_split_args():
    assert split_args('a=1') == ['a=1']
    assert split_args('a=1 b=2 c=3') == ['a=1', 'b=2', 'c=3']
    assert split_args('a=1\nb=2\nc=3') == ['a=1\n', 'b=2\n', 'c=3']
    assert split_args('a=1\nb=2\nc=3\n') == ['a=1\n', 'b=2\n', 'c=3\n']
    assert split_args('a=1\n \nb=2\nc=3\n') == ['a=1\n', 'b=2\n', 'c=3\n']

# Generated at 2022-06-11 06:22:20.418001
# Unit test for function split_args

# Generated at 2022-06-11 06:22:30.826535
# Unit test for function split_args

# Generated at 2022-06-11 06:22:39.997811
# Unit test for function split_args

# Generated at 2022-06-11 06:22:49.888075
# Unit test for function split_args

# Generated at 2022-06-11 06:22:59.871934
# Unit test for function split_args

# Generated at 2022-06-11 06:23:08.750054
# Unit test for function split_args
def test_split_args():
    cases = dict()

    # test cases for tokens inside jinja2 blocks
    cases['jinja2_print_string'] = ('"{{ foo }}"', ['{{ foo }}'])
    cases['jinja2_print_block'] = ('"{{ foo }} bar {{ bam }}"', ['{{ foo }} bar {{ bam }}'])
    cases['jinja2_print_string_quote_split'] = ('"{{ fo\'o }}"', ['{{ "\'"', 'fo\'o }}"'])
    cases['jinja2_print_string_quote_split_2'] = ('"{{ \'fo\'o }}"', ['{{ "\'"', 'fo\'o }}"'])

# Generated at 2022-06-11 06:23:18.039700
# Unit test for function split_args
def test_split_args():
    #Unit test for function split_args
    input = "a=b"
    output = ["a=b"]
    assert split_args(input) == output

    input = "a=b c=d"
    output = ['a=b', 'c=d']
    assert split_args(input) == output

    input = "a=b c=\"foo bar\""
    output = ['a=b', 'c="foo bar"']
    assert split_args(input) == output

    input = "a=\"{{ foo.bar }}\""
    output = ['a="{{ foo.bar }}"']
    assert split_args(input) == output

    input = "a=\"{{ foo.bar }}\" b=\"{{ foo.bar + foo.bar }}\""

# Generated at 2022-06-11 06:23:27.886453
# Unit test for function split_args
def test_split_args():
    from ansible.executor.module_common import _load_params

    tests_that_should_fail = (
        'foo="bar', # unterminated quoted arg
        "{#",       # unterminated comment block
        "{%",       # unterminated jinja2 block
        "{{",       # unterminated jinja2 print block
        "{{ foo",   # unterminated jinja2 print block
        "{{ foo }", # unterminated jinja2 print block
        "{{ foo }} bar {# } #}", # unterminated comment
        "{% foo }", # unterminated jinja2 block
        "{% foo %} bar {{ } }}", # unterminated jinja2 print block
    )


# Generated at 2022-06-11 06:24:24.356427
# Unit test for function split_args
def test_split_args():
    import json


# Generated at 2022-06-11 06:24:32.415470
# Unit test for function split_args
def test_split_args():
    args = "foo=bar biz={{ foo }} baz={{ 'foo' if foo == 'bar' else 'biz' }} buzz='{{ foo if foo == 'bar' else 'biz' }}' doo=dah 'doo doo' \"dah dah\""
    params = split_args(args)
    assert params == ['foo=bar', 'biz={{', 'foo', '}}', 'baz={{', "'foo' if foo == 'bar' else 'biz'", '}}', 'buzz=\'{{', "foo if foo == 'bar' else 'biz'", "}}'", 'doo=dah', "'doo doo'", '"dah dah"']


# Generated at 2022-06-11 06:24:41.976151
# Unit test for function split_args
def test_split_args():
    args = u'key1=value1 key2="value2 value2"'
    args = split_args(args)
    assert args == ['key1=value1', 'key2="value2 value2"']

    args = u'key1=value1 key2="value2\\nvalue2"'
    args = split_args(args)
    assert args == ['key1=value1', 'key2="value2\\nvalue2"']

    args = u'key1=value1 key2="value2\\nvalue2" key3="value3\\nvalue3\\n" key4=value4'
    args = split_args(args)
    assert args == ['key1=value1', 'key2="value2\\nvalue2"', 'key3="value3\\nvalue3\\n"', 'key4=value4']

# Generated at 2022-06-11 06:24:51.854998
# Unit test for function split_args
def test_split_args():
    # Test splitting arguments at white spaces
    assert(split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'])

    # Test splitting arguments at newlines
    assert(split_args('a=b \nc="foo bar"') == ['a=b', 'c="foo bar"'])

    # Test splitting arguments with continuation
    assert(split_args('a=b \\c="foo bar"') == ['a=b', 'c="foo bar"'])

    # Test splitting arguments at white spaces within quotes
    assert(split_args('a="foo bar"') == ['a="foo bar"'])

    # Test splitting arguments at white spaces within single quotes
    assert(split_args("a='foo bar'") == ["a='foo bar'"])

    # Test splitting arguments at white spaces within backticks


# Generated at 2022-06-11 06:25:00.975999
# Unit test for function split_args
def test_split_args():
    # single jinja2 block
    assert split_args("{{ foo }}") == ["{{ foo }}"]

    # multiple jinja2 blocks
    assert split_args("{{ foo }} {{ bar }}") == ["{{ foo }}", "{{ bar }}"]

    # nested blocks
    assert split_args("{{ foo }} {% if bar %} {{ baz }} {% endif %}") == ["{{ foo }}", "{% if bar %}", "{{ baz }}", "{% endif %}"]

    # jinja2 blocks with quotes
    assert split_args('{{ "foo" }}') == ["{{ \"foo\" }}"]

    # jinja2 blocks in quotes
    assert split_args('"{{ code }}"') == ["\"{{ code }}\""]

    # quotes

# Generated at 2022-06-11 06:25:10.439571
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='d e'") == ['a=b', "c='d e'"]
    assert split_args("a=b c=\"d e\"") == ['a=b', 'c="d e"']
    assert split_args("a=b c=\"d e\" f=g") == ['a=b', 'c="d e"', 'f=g']
    assert split_args("a=b c=\"{{ d }} e\" f=g") == ['a=b', 'c="{{ d }} e"', 'f=g']
    assert split_args("a=b c=\"{{ d }} e\" f=g {{ h }}") == ['a=b', 'c="{{ d }} e"', 'f=g {{ h }}']

# Generated at 2022-06-11 06:25:18.708646
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar" d=\'{"a": "b", "b": "c"}\'') == ['a=b', 'c="foo bar"', 'd=\'{"a": "b", "b": "c"}\'']
    assert split_args('a=b "c=\\"foo bar\\""') == ['a=b', '"c=\\"foo bar\\""']
    assert split_args('a=b c=\\"foo bar\\""') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']
    assert split_args('a=b c="foo\\nbar"') == ['a=b', 'c="foo\nbar"']

# Generated at 2022-06-11 06:25:27.116524
# Unit test for function split_args

# Generated at 2022-06-11 06:25:35.593363
# Unit test for function split_args
def test_split_args():
    ''' Unit test for function split_args '''
    assert split_args('"echo hello" world') == ['"echo hello"', 'world']
    assert split_args('hello world "it is" "a ""beautiful"" day"') == ['hello', 'world', '"it is"', '"a ""beautiful"" day"']
    assert split_args('echo "{{ foo.split(\' \') | join(\'_\') }}"') == ['echo', '"{{ foo.split(\' \') | join(\'_\') }}"']
    assert split_args('echo "{{ foo.split(\' \') | join(\'_\') }}"') == ['echo', '"{{ foo.split(\' \') | join(\'_\') }}"']
    assert split_args('echo "{{ foo[0] }}"')

# Generated at 2022-06-11 06:25:45.502595
# Unit test for function split_args
def test_split_args():
    # Basic tests
    assert split_args('') == ['']
    assert split_args('a') == ['a']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a=b') == ['a=b']
    assert split_args('a="b"') == ['a="b"']
    assert split_args('a="b" c') == ['a="b"', 'c']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b c" d') == ['a="b c"', 'd']
    assert split_args('a b="c d"') == ['a', 'b="c d"']

# Generated at 2022-06-11 06:27:51.528832
# Unit test for function split_args
def test_split_args():
    ''' Test to ensure that arguments are properly split even in the presence of jinja2 markers and quotes '''

    params = split_args("a=b c='foo bar' d=\"baz zab\" e=\"{{ foo }}\" f=\"{{# foo #}}{{ bar }}{{/ foo }}\" g=\"foo\nbar\" h=\"a b c\"")
    assert params == ['a=b', "c='foo bar'", 'd="baz zab"', 'e="{{ foo }}"', 'f="{{# foo #}}{{ bar }}{{/ foo }}"', 'g="foo\nbar"', 'h="a b c"']

    params = split_args("'a' 'b' \"c\"")
    assert params == ["'a'", "'b'", '"c"']


# Generated at 2022-06-11 06:27:59.607585
# Unit test for function split_args
def test_split_args():

    # FIXME: a bunch of this is written using unittest, but we need
    # to move to pytest, so I didn't change the code to match that style

    #test basic simple cases
    raw = "a=1 b=2\nc=3"
    result = split_args(raw)
    assert len(result) == 3
    assert result[0] == "a=1"
    assert result[1] == "b=2\nc=3"

    #test a bunch of single quoting cases
    raw = "a='b c'"
    result = split_args(raw)
    assert len(result) == 1
    assert result[0] == "a='b c'"

    #test a bunch of double quoting cases
    raw = 'a="b c"'
    result = split_args(raw)