

# Generated at 2022-06-11 06:18:17.845095
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("foo\"")
    assert not is_quoted("'foo\"")
    assert not is_quoted("\"foo'")
    assert not is_quoted("'")
    assert not is_quoted("\"")
    assert not is_quoted("")


# Generated at 2022-06-11 06:18:28.226936
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Hello"')
    assert is_quoted('"foo"')
    assert is_quoted("'Hello'")
    assert is_quoted("'foo'")
    assert not is_quoted('"Hello')
    assert not is_quoted("'foo")
    assert not is_quoted('Hello"')
    assert not is_quoted("foo'")
    assert not is_quoted('"Hello" "World"')

if __name__ == '__main__':
    args = "  a=b  c=\"foo bar\" d='hello world' e='foo \"bar' f='foo '\"'\n\"bar' 'g'h"
    params = split_args(args)
    assert len(params) == 7

# Generated at 2022-06-11 06:18:39.123247
# Unit test for function split_args
def test_split_args():
    '''
    test_split_args verifies that the args are being split properly by split_args
    This test is designed to exercise all of the code flow cases and is
    split into sections for each code flow path.
    '''

    # Section: test regular args
    test = 'foo="bar baz"'
    result = split_args(test)
    assert len(result) == 1
    assert result[0] == 'foo="bar baz"'

    # Section: test a single open jinja2 token
    test = 'foo="bar baz {{ a" b={1,2,3}'
    result = split_args(test)
    assert len(result) == 3
    assert result[0] == 'foo="bar baz {{ a"'
    assert result[1] == 'b={1,2,3}'

   

# Generated at 2022-06-11 06:18:46.515750
# Unit test for function split_args
def test_split_args():
    # Simple args
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # With a ;
    assert split_args('a=b c="foo bar";') == ['a=b', 'c="foo bar"', ';']

    # With a newline
    assert split_args('a=b\nc="foo bar"') == ['a=b', '\nc="foo bar"']

    # With a \
    assert split_args('a=b c="foo\\"bar"') == ['a=b', 'c="foo\\"bar"']

    # With a '
    assert split_args('a=b c="foo\'bar"') == ['a=b', 'c="foo\'bar"']

    # With a \

# Generated at 2022-06-11 06:18:57.440914
# Unit test for function split_args
def test_split_args():

    # Test case 1
    test_args = '"echo hello" "echo world"'
    assert(split_args(test_args) == ['"echo hello"', '"echo world"'])

    # Test case 2
    test_args = '''{{ item }} "echo hello" "echo world"'''
    assert(split_args(test_args) == ['{{ item }}', '"echo hello"', '"echo world"'])

    # Test case 3
    test_args = '''{{ item }} "echo hello" {{ another_item }} "echo world"'''
    assert(split_args(test_args) == ['{{ item }}', '"echo hello"', '{{ another_item }}', '"echo world"'])

    # Test case 4

# Generated at 2022-06-11 06:19:09.695750
# Unit test for function split_args
def test_split_args():
    from nose.tools import assert_equal
    assert_equal(split_args('a=1'), ['a=1'])
    assert_equal(split_args('a=1\nb=2'), ['a=1\nb=2'])
    assert_equal(split_args('a=1\nb=2\\\nc=3'), ['a=1\nb=2\nc=3'])
    assert_equal(split_args('"a=1  b=2"'), ['a=1  b=2'])
    assert_equal(split_args("./a.sh a=1\n./b.sh b=2"), ["./a.sh a=1\n./b.sh b=2"])

# Generated at 2022-06-11 06:19:18.044114
# Unit test for function split_args

# Generated at 2022-06-11 06:19:29.261596
# Unit test for function split_args
def test_split_args():

    # Test basic functionality
    # Test that functions by splitting on spaces, except when within quotes.
    test_arg_1 = "a b c"
    assert split_args(test_arg_1) == ["a", "b", "c"]

    test_arg_2 = "a 'b c' d"
    assert split_args(test_arg_2) == ["a", "'b c'", "d"]

    test_arg_3 = "a \"b c\" d"
    assert split_args(test_arg_3) == ["a", "\"b c\"", "d"]

    # Test that quotes can be nested.
    test_arg_4 = 'a "b \'c" d'
    assert split_args(test_arg_4) == ["a", "\"b \'c\"", "d"]

    test_arg

# Generated at 2022-06-11 06:19:38.399314
# Unit test for function split_args
def test_split_args():
    # Basic test
    assert split_args("a=b c='foo bar' d=\"foo bar\"") == ['a=b', "c='foo bar'", 'd="foo bar"']

    # Test various combinations of jinja2 blocks with quotes, verify that nested blocks and quotes are not broken apart
    assert split_args("a=b c='{% foo %}' d=\"{{ foo }}\"") == ['a=b', "c='{% foo %}'", 'd="{{ foo }}"']

# Generated at 2022-06-11 06:19:48.107257
# Unit test for function split_args
def test_split_args():
    # TODO: add unit test for parameters without spaces

    # Test 01: check if parameters are correctly splitted by whitespaces
    args = 'foo=bar a=b cd=efgh'
    result = split_args(args)
    assert result == ['foo=bar', 'a=b', 'cd=efgh']

    # Test 02: check if parameters are correctly splitted by whitespaces
    # although they are separated by newlines
    args = 'foo=bar\na=b\ncd=efgh'
    result = split_args(args)
    assert result == ['foo=bar', 'a=b', 'cd=efgh']

    # Test 03: check if parameters are correctly splitted by whitespaces
    # although they are separated by newlines and spaces
    args = 'foo=bar\n a=b\n cd=efgh'

# Generated at 2022-06-11 06:20:08.189893
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('a=b') == ['a=b']
    assert split_args('   a=b c="foo bar" ') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="g \'h i" j=k') == ['a=b', 'c="foo bar"', 'd="g \'h i"', 'j=k']
    assert split_args('a=b c="foo bar" d="g \"h i" j=k') == ['a=b', 'c="foo bar"', 'd="g \\"h i"', 'j=k']

# Generated at 2022-06-11 06:20:15.425786
# Unit test for function split_args
def test_split_args():
    ''' test for the split_args function '''
    import sys

    args = "user={{ lookup('env', 'SUDO_USER') or lookup('env', 'USER') }}"
    argsl = split_args(args)
    print("%r" % argsl)
    if len(argsl) != 1:
        print("error splitting args: got %d, expected 1" % len(argsl))
        sys.exit(1)

    args = "user={{ lookup('env','SUDO_USER') or lookup('env','USER') }}"
    argsl = split_args(args)
    print("%r" % argsl)
    if len(argsl) != 1:
        print("error splitting args: got %d, expected 1" % len(argsl))
        sys.exit(1)

    args

# Generated at 2022-06-11 06:20:25.980929
# Unit test for function split_args
def test_split_args():

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    assert split_args('a=b c="foo bar" d="a")') == ['a=b', 'c="foo bar"', 'd="a"]']

    assert split_args('a=b c="foo bar" d="a") e="\\"') == ['a=b', 'c="foo bar"', 'd="a"]', 'e="\\"']

    assert split_args('a=b c="foo bar" d="a") e="\\""') == ['a=b', 'c="foo bar"', 'd="a"]', 'e="\\""']

    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']



# Generated at 2022-06-11 06:20:36.893707
# Unit test for function split_args
def test_split_args():
    test = 'a=b c="foo bar d=1"'
    result = ['a=b', 'c="foo bar d=1"']

    assert split_args(test) == result

    test = 'a=b c="foo bar d=1'
    result = ['a=b', 'c="foo bar d=1']

    assert split_args(test) == result

    test = 'a=b c="foo bar d=1" f'
    result = ['a=b', 'c="foo bar d=1"', 'f']

    assert split_args(test) == result

    test = 'a=b c="foo bar d=1" f e="foo bar'
    result = ['a=b', 'c="foo bar d=1"', 'f', 'e="foo bar']


# Generated at 2022-06-11 06:20:47.479428
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests.mock import patch

    # Test simple splitting at white space level
    test_case = 'a string'
    result = split_args(test_case)
    assert result == ['a', 'string']

    # Test splitting at white space level when white space is not there
    test_case = 'a,string'
    result = split_args(test_case)
    assert result == ['a,string']

    # Test white space inside quotes
    test_case = 'a string with "white space" inside quotes'
    result = split_args(test_case)
    assert result == ['a', 'string', 'with', '"white space"', 'inside', 'quotes']

    # Test white space inside quotes even if space is

# Generated at 2022-06-11 06:20:57.962512
# Unit test for function split_args

# Generated at 2022-06-11 06:21:06.418821
# Unit test for function split_args

# Generated at 2022-06-11 06:21:16.721943
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    result = split_args(args)
    assert result == expected, "split_args('%s') should return %s but returned %s" % (args, expected, result)

    args = 'a=b c="foo bar'
    expected = ['a=b', 'c="foo', 'bar']
    result = split_args(args)
    assert result == expected, "split_args('%s') should return %s but returned %s" % (args, expected, result)


# Generated at 2022-06-11 06:21:25.076701
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function

    NOTE: It is intended to be run as a standalone program, but it needs to
    be run from the parent directory of this file (lib/ansible) as:

    PYTHONPATH=. python lib/ansible/utils/__init__.py

    You will also need to comment out the "#!/usr/bin/python" line at the top,
    as well as the "if __name__ == '__main__':" line at the bottom.
    '''

    errors = 0

    def expect(s, result):
        global errors

        split = split_args(s)
        if split != result:
            print("result mismatch for:  %s\nexpected: %s\n     got: %s" % (s, result, split))
            errors += 1

# Generated at 2022-06-11 06:21:30.766049
# Unit test for function split_args

# Generated at 2022-06-11 06:21:51.994851
# Unit test for function split_args
def test_split_args():
    # test basic parsing
    params = ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == params

    # test for newline preservation
    assert split_args('a=b\nc="foo bar"') == ['a=b\n', 'c="foo bar"']

    # test for line continuation
    assert split_args('a=b \\\nc="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b\\\nc="foo bar"') == ['a=b\\\n', 'c="foo bar"']
    assert split_args('a=b \\\nc="foo \\\nbar"') == ['a=b', 'c="foo \\\nbar"']

# Generated at 2022-06-11 06:22:02.489029
# Unit test for function split_args
def test_split_args():
    ''' test to make sure the splitting mechanism works as expected '''


# Generated at 2022-06-11 06:22:10.713289
# Unit test for function split_args

# Generated at 2022-06-11 06:22:21.308982
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("echo hello world") == ['echo', 'hello', 'world']
    assert split_args("-c bob") == ['-c', 'bob']
    assert split_args("-c 'bob smith'") == ['-c', "'bob smith'"]
    assert split_args("-c \"bob smith\"") == ['-c', '"bob smith"']
    assert split_args("-c \"bob \\\"smi\\\" th\"") == ['-c', '"bob \\\"smi\\\" th"']
    assert split_args("-c 'bob \\\'smi\\\' th'") == ['-c', "'bob \\\'smi\\\' th'"]

# Generated at 2022-06-11 06:22:31.856454
# Unit test for function split_args
def test_split_args():
    # test simple
    args = "foo=bar baz=foobar"
    params = split_args(args)
    assert params == ['foo=bar', 'baz=foobar']

    # test simple - no spaces
    args = "foo=bar baz=foobar"
    params = split_args(args)
    assert params == ['foo=bar', 'baz=foobar']

    # test simple with quotes
    args = "foo=bar baz='foobar'"
    params = split_args(args)
    assert params == ['foo=bar', "baz='foobar'"]

    # test simple with quotes around key
    args = "foo='bar' baz='foobar'"
    params = split_args(args)
    assert params == ["foo='bar'", "baz='foobar'"]

    #

# Generated at 2022-06-11 06:22:37.383321
# Unit test for function split_args

# Generated at 2022-06-11 06:22:44.099097
# Unit test for function split_args
def test_split_args():
    import os
    import sys
    import tempfile
    import shlex


# Generated at 2022-06-11 06:22:54.585716
# Unit test for function split_args
def test_split_args():
    def _test_split_args(test_args, expected):
        params = split_args(test_args)
        assert params == expected, params


# Generated at 2022-06-11 06:23:04.201718
# Unit test for function split_args
def test_split_args():
    import unittest


# Generated at 2022-06-11 06:23:11.288276
# Unit test for function split_args
def test_split_args():
    ''' test split_args function '''
    assert split_args(' a=b c="foo bar" ') == ['a=b', 'c="foo bar"']
#     #assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(' a=b c=') == ['a=b', 'c=']
    assert split_args(' a=b c= ') == ['a=b', 'c=']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']

# Generated at 2022-06-11 06:23:31.395495
# Unit test for function split_args
def test_split_args():
    assert split_args('src=/my/path/on/control/machine dest=/my/path/on/managed/machine') == ['src=/my/path/on/control/machine', 'dest=/my/path/on/managed/machine']
    assert split_args('src=/my/path/on/control/machine  dest=/my/path/on/managed/machine') == ['src=/my/path/on/control/machine', 'dest=/my/path/on/managed/machine']
    assert split_args('src=/my/path/on/control/machine\ndest=/my/path/on/managed/machine') == ['src=/my/path/on/control/machine\ndest=/my/path/on/managed/machine']

# Generated at 2022-06-11 06:23:41.463486
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('"') == ['"']
    assert split_args('""') == ['']
    assert split_args('""""') == ['"']
    assert split_args('"""foo"""') == ['foo']
    assert split_args('"foo bar"') == ['foo bar']
    assert split_args('"foo \'bar\'"') == ['foo \'bar\'']
    assert split_args('"foo \'bar\'" "baz qux" \'here there\'') == ['foo \'bar\'', 'baz qux', 'here there']

# Generated at 2022-06-11 06:23:51.383277
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo \\"bar\\"') == ['a=b', 'c="foo \\"bar\\"']
    assert split_args('a=b c="foo \\bar') == ['a=b', 'c="foo \\bar']
    assert split_args('a=b c="foo \\\\"bar\\\\"') == ['a=b', 'c="foo \\"bar\\"']
    assert split_args('a=b c="foo \\bar"') == ['a=b', 'c="foo \\bar"']

# Generated at 2022-06-11 06:23:56.033490
# Unit test for function split_args
def test_split_args():
    actual = split_args("a=b c='foo bar'")
    assert [u'a=b', u"c='foo bar'"] == actual, "%s != %s" % (actual, [u'a=b', u"c='foo bar'"])

# vim: set expandtab ts=4 sw=4 ai :

# Generated at 2022-06-11 06:24:06.356980
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar'], 'failed basic split_args test'
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'], 'failed quotes split_args test'
    assert split_args('a={{foo}} b="{{bar}}"') == ['a={{foo}}', 'b="{{bar}}"'], 'failed jinja2 split_args test'
    assert split_args('a=\n b') == ['a=', 'b'], 'failed newline in split_args test'
    assert split_args('"a=\\"b c\\\\ d"') == ['"a=\\"b c\\\\ d"'], 'failed double quote escaping test'

# Generated at 2022-06-11 06:24:14.701036
# Unit test for function split_args
def test_split_args():
    ''' Test cases to split args and verify jinja2 syntax with quotes '''
    text1 = '''
    {{ foo }} \\
    a="b c" d="e f" g='h i'
    '''
    text2 = '''
    {{ foo }} {{ [ 'bar' ] }}
    a="b c" d="e f" g=\'h i\'
    '''
    text3 = '''
    {{ foo }} bar="\\{{ baz }}"
    '''
    text4 = '''
    {{ foo }} bar="\\{{ baz }}"
    '''
    text5 = '''
    {{ foo }}
    '''
    text6 = '''
    {{ foo }}
    '''

# Generated at 2022-06-11 06:24:25.296664
# Unit test for function split_args
def test_split_args():

    import sys
    import json

    def test_split_args_internal(test_name, arg_string, desired_output, no_quote_string=False):
        test_description = "Testing split_args - " + test_name
        output = split_args(arg_string)
        if len(output) == len(desired_output):
            for i in range(0, len(desired_output)):
                if no_quote_string:
                    if output[i] != desired_output[i]:
                        print("[FAILED] " + test_description)
                        print(" Desired Output: " + " ".join(desired_output))
                        print(" Output: " + " ".join(output))
                        sys.exit(1)

# Generated at 2022-06-11 06:24:34.632632
# Unit test for function split_args

# Generated at 2022-06-11 06:24:44.481502
# Unit test for function split_args

# Generated at 2022-06-11 06:24:53.996395
# Unit test for function split_args
def test_split_args():
    '''
    This is not a real unit test. This code is used to run the function split_args
    with a variety of different inputs and outputs to ensure that the code doesn't
    get messed up. This code can also be used as an example for how to use the function
    '''
    import sys
    import json

    # A list of tuples (input, expected_output)
    cases = []
    # Standard input
    cases.append(('foo=bar name="baz qux"', ['foo=bar', 'name="baz qux"']))
    # The last line should end in a trailing newline
    cases.append(('foo=bar\nname="baz qux"', ['foo=bar\n', 'name="baz qux"']))
    # The last line should end in a trailing newline

# Generated at 2022-06-11 06:25:28.367287
# Unit test for function split_args
def test_split_args():
    '''
    Split args tests, output should match input
    '''

# Generated at 2022-06-11 06:25:37.124722
# Unit test for function split_args
def test_split_args():
    test_success = True

# Generated at 2022-06-11 06:25:46.921719
# Unit test for function split_args

# Generated at 2022-06-11 06:25:54.807369
# Unit test for function split_args
def test_split_args():
    class _Module(object):
        def _fail(self, msg):
            raise AssertionError(msg)

    module = _Module()
    def test_result(input, expected):
        if split_args(input) != expected:
            module._fail("split_args(%r) should return %r but returned %r" % (input, expected, split_args(input)))

    # test basic splits
    test_result("command arg1 arg2 arg3", ["command", "arg1", "arg2", "arg3"])

    test_result(
        "command\narg1\narg2\narg3",
        ["command", "arg1", "arg2", "arg3"]
    )


# Generated at 2022-06-11 06:25:59.765153
# Unit test for function split_args
def test_split_args():

    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("c=\"\\\"foo bar\\\"\"") == ['c="\\"foo bar\\""']
    assert split_args("c='\\'foo bar\\''") == ["c='\\'foo bar\\''"]
    assert split_args("c='\"foo bar\"'") == ['c=\'"foo bar"\'']
    assert split_args("c=\"'foo bar'\"") == ['c="\'foo bar\'"']
    assert split_args("c=\"foo bar\" \\") == ['c="foo bar" \\']
    assert split_args("c=\"foo bar\" d") == ['c="foo bar"', 'd']

# Generated at 2022-06-11 06:26:07.184110
# Unit test for function split_args
def test_split_args():

    def compare_args(test_string, expected):
        result = split_args(test_string)
        assert result == expected

    # simple tests
    compare_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    compare_args("a=b c={{foo}}", ['a=b', 'c={{foo}}'])
    compare_args("a=b c='{{foo}}'", ['a=b', "c='{{foo}}'"])
    compare_args('a=b c=""', ['a=b', 'c=""'])
    compare_args('a=b c=', ['a=b', 'c='])
    compare_args('a=b c="foo bar', ['a=b', 'c="foo bar'])

# Generated at 2022-06-11 06:26:15.503896
# Unit test for function split_args

# Generated at 2022-06-11 06:26:23.795526
# Unit test for function split_args
def test_split_args():
    '''
    Tests split_args function. Returns True when tests are successfull and False on failure.
    '''

    # String to test split_args function.
    #
    # Notes:
    #   This string is used for test_split_args_simple and test_split_args_complex.
    #   The following args will not be 'coalesced':
    #   - a=b c="foo bar"
    #   These args are not coalesced because c="foo bar" can be easily splitted into two args: c and "foo bar".
    #   So splitting on whitespace, and then reassembling quoted strings is not required.
    #
    #   The following args will be 'coalesced':
    #   - a="b c"
    #   This arg is coalesced because the quotes around the whole arg must be kept.


# Generated at 2022-06-11 06:26:30.139714
# Unit test for function split_args

# Generated at 2022-06-11 06:26:39.096449
# Unit test for function split_args
def test_split_args():
    given = u'''a=b c="foo bar \n foo bar" "d=e" 'f=g' "h={{i}}"{%if j%}k=l{% endif %}{# m #}n="o"'''
    expected = [u'a=b', u'c="foo bar \n foo bar"', u"d=e", u"f=g", u'h={{i}}', u'k=l', u'n="o"']
    results = split_args(given)
    assert results == expected, u"Split args test failed, got %s, expected %s" % (results, expected)

    given = u'''a b "c" 'd' "f 'g'" {%h%} {# i #} {{j}}'''

# Generated at 2022-06-11 06:27:48.060227
# Unit test for function split_args
def test_split_args():
    # simple test for a parameter
    params = split_args("foo=bar")
    assert params[0] == "foo=bar", "parameter foo=bar not found"

    # test quoted values
    params = split_args("'foo'='bar baz'")
    assert params[0] == "'foo'='bar baz'", "single quoted value foo not found"
    params = split_args("\"foo\"=\"bar baz\"")
    assert params[0] == "\"foo\"=\"bar baz\"", "double quoted value foo not found"

    # test quotes inside of quotes
    params = split_args("'foo \"bar\" baz'")
    assert params[0] == "'foo \"bar\" baz'", "single quoted value foo \"bar\" baz not found"

# Generated at 2022-06-11 06:27:54.328737
# Unit test for function split_args
def test_split_args():
    def run_split_args_test(args, expected_result):
        params = split_args(args)
        if params != expected_result:
            print("Expected: %s" % (expected_result))
            print("Got:      %s" % (params))
            raise Exception("Params did not match expected result")

    run_split_args_test("a=1 b=c d={{foo}}", ["a=1", "b=c", "d={{foo}}"])
    run_split_args_test("a=1\nb=c d={{foo}}", ["a=1", "b=c d={{foo}}"])
    run_split_args_test("a=1\nb=c\rd={{foo}}", ["a=1", "b=c", "d={{foo}}"])