

# Generated at 2022-06-11 06:18:18.117790
# Unit test for function split_args
def test_split_args():
    '''
    This function runs a series of assertions against the split_args function, to ensure that
    it handles a variety of input and returns the expected params

    TODO: more comprehensive test cases
    '''

    # simple case, we're just testing that we split on spaces
    params = split_args('a b c d')
    assert len(params) == 4
    assert params[0] == 'a'
    assert params[1] == 'b'
    assert params[2] == 'c'
    assert params[3] == 'd'

    # here we test that we properly count jinja2 print blocks and quote characters
    params = split_args('a="{{foo}}" b="bar {{foo}}" c="{{foo}} bar" {{foo}}')
    assert len(params) == 4

# Generated at 2022-06-11 06:18:21.520345
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"asdf"') == True
    assert is_quoted('"asdf') == False
    assert is_quoted('asdf"') == False
    assert is_quoted('"asdf' + '"') == False
    assert is_quoted('') == False



# Generated at 2022-06-11 06:18:33.124611
# Unit test for function is_quoted

# Generated at 2022-06-11 06:18:42.966278
# Unit test for function split_args
def test_split_args():
    '''

    :return:
    '''
    # Test Simple case
    #assert split_args('a b c') == ['a', 'b', 'c']
    assert split_args('a b c') == ['a b c']

    # Test case with quotes
    assert split_args('a "b c"') == ['a', '"b c"']

    # Test case with quotes
    assert split_args('a "b c" d') == ['a', '"b c"', 'd']

    # Test case with single quote
    assert split_args("a 'b c'") == ['a', "'b c'"]

    # Test case with single quote
    assert split_args("a 'b c' d") == ['a', "'b c'", 'd']

    # Test case with equal sign
    assert split_args

# Generated at 2022-06-11 06:18:49.848071
# Unit test for function unquote
def test_unquote():
    ''' test unquote'''
    assert unquote('test') == 'test'
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('""""') == '""'


# Generated at 2022-06-11 06:18:58.938365
# Unit test for function split_args

# Generated at 2022-06-11 06:19:11.118984
# Unit test for function split_args
def test_split_args():
    assert split_args('foo=bar name="foo bar"') == ['foo=bar', 'name="foo bar"']
    assert split_args('foo=bar name=\'foo bar\'') == ['foo=bar', 'name=\'foo bar\'']
    assert split_args('foo={{foo}}') == ['foo={{foo}}']
    assert split_args('foo=bar "name={{foo}}"') == ['foo=bar', '"name={{foo}}"']
    assert split_args('foo=bar "name={{foo}}"') == ['foo=bar', '"name={{foo}}"']
    assert split_args('foo=bar "name={% if foo %}foo{% endif %}"') == ['foo=bar', '"name={% if foo %}foo{% endif %}"']
    assert split

# Generated at 2022-06-11 06:19:16.055146
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"') is True
    assert is_quoted("'foobar'") is True
    assert is_quoted('foobar') is False
    assert is_quoted('"foobar') is False
    assert is_quoted("'foobar") is False
    assert is_quoted('foobar"') is False
    assert is_quoted("foobar'") is False


# Generated at 2022-06-11 06:19:27.659080
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted('"a"') == True
    assert is_quoted('"abc"def') == False
    assert is_quoted('"abc') == False
    assert is_quoted('"\\"') == True
    assert is_quoted('"\\a"') == True
    assert is_quoted('"\\"a"') == True
    assert is_quoted('"\\a\\"') == True

    assert is_quoted("'abc'") == True
    assert is_quoted("'a'") == True
    assert is_quoted("'abc'def") == False
    assert is_quoted("'abc") == False
    assert is_quoted("'\\'") == True
    assert is_quoted("'\\a'")

# Generated at 2022-06-11 06:19:32.639348
# Unit test for function split_args
def test_split_args():
    test_str = '''
foo=bar baz="foo bar"
- name: "test"
  debug:
    a: "{{ foo }}"
    b: "{{ baz }}"
'''

    test_arr = split_args(test_str)
    assert test_arr == [
        'foo=bar',
        'baz="foo bar"',
        '- name: "test"\n  debug:\n    a: "{{ foo }}"\n    b: "{{ baz }}"\n'
    ]

# Generated at 2022-06-11 06:19:53.526139
# Unit test for function split_args
def test_split_args():
    '''
    sanity check for the split_args function
    '''
    # Example args for a module that takes multiple options
    # in a combination of quoted and unquoted forms.

# Generated at 2022-06-11 06:20:01.354167
# Unit test for function split_args
def test_split_args():

    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a='b c=\"foo bar\"'") == ["a='b c=\"foo bar\"'"]
    assert split_args("a=\"b c='foo bar'\"") == ['a="b c=\'foo bar\'"']
    assert split_args("a=b c=foo\\ bar") == ["a=b", "c=foo\\ bar"]
    assert split_args("a=b c=foo\\\nbar") == ["a=b", "c=foo bar"]

# Generated at 2022-06-11 06:20:09.194458
# Unit test for function split_args
def test_split_args():
    '''
    Basic test to validate the split_args function
    '''

    import sys
    import os
    import tempfile
    fd, test_file = tempfile.mkstemp()

# Generated at 2022-06-11 06:20:18.460134
# Unit test for function split_args
def test_split_args():

    def check_args(args, expected):
        result = split_args(args)
        if result != expected:
            raise AssertionError("%s != %s" % (result, expected))

    # check_args(args, expected)
    check_args("a=b c=d", ['a=b', 'c=d'])
    check_args(" a=b c=d ", ['a=b', 'c=d'])
    check_args("a='b c' d=e", ['a=\'b c\'', 'd=e'])
    check_args("a=\"b c\" d=e", ['a="b c"', 'd=e'])
    check_args(" a=b c=d\n", ['a=b', "c=d\n"])

# Generated at 2022-06-11 06:20:29.370285
# Unit test for function split_args

# Generated at 2022-06-11 06:20:38.609381
# Unit test for function split_args
def test_split_args():
    # expected: ['a=b', 'foo bar']
    assert split_args("a=b foo bar") == ['a=b', 'foo bar']

    # expected: ['a=b c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b c="foo bar"']

    # expected: ['a=b foo bar']
    assert split_args("a=b \"foo\" \"bar\"") == ['a=b foo bar']

    # expected: ['foo bar']
    assert split_args("\"foo bar\"") == ["foo bar"]

    # expected: ['foo bar']
    assert split_args("'foo bar'") == ["foo bar"]

    # expected: ['a=b', 'c="foo bar"']

# Generated at 2022-06-11 06:20:49.278848
# Unit test for function split_args
def test_split_args():
    import sys
    def _test(args, expected):
        result = split_args(args)
        if expected != result:
            print("FAILED: args=%r\n  expected=%r\n       got=%r" % (args, expected, result), file=sys.stderr)
            return 1
        return 0
    failed = 0
    failed += _test(u'', [])
    failed += _test(u'foo', [u'foo'])
    failed += _test(u'foo bar', [u'foo', u'bar'])
    failed += _test(u'foo "bar baz"', [u'foo', u'"bar baz"'])

# Generated at 2022-06-11 06:20:59.593007
# Unit test for function split_args
def test_split_args():
    def _test(input_args, expected):
        if split_args(input_args) != expected:
            raise AssertionError("split_args() did not work as expected: %s" % input_args)

    _test("a=b c='foo bar' d=\"foo bar\" e=\"foo bar baz\"", ['a=b', "c='foo bar'", 'd="foo bar"', 'e="foo bar baz"'])
    _test("a=\"foo bar baz\" c=\"foobarbaz\"", ['a="foo bar baz"', 'c="foobarbaz"'])
    _test("a='foo bar baz' c='foobarbaz'", ["a='foo bar baz'", "c='foobarbaz'"])

# Generated at 2022-06-11 06:21:07.276768
# Unit test for function split_args
def test_split_args():
    # Test no splitting
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo bar"]

    # Test simple arg splitting
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]

    # Test quotes
    assert split_args("foo bar \"baz 'blah'\"") == ["foo", "bar", "\"baz 'blah'\""]
    assert split_args("foo bar 'baz \"blah\"'") == ["foo", "bar", "'baz \"blah\"'"]

    # Test jinja2 blocks (single line)
    assert split_args("foo bar {% baz %}") == ["foo", "bar", "{% baz %}"]

# Generated at 2022-06-11 06:21:17.561984
# Unit test for function split_args
def test_split_args():
    assert split_args("1") == ['1']
    assert split_args("foo=bar") == ['foo=bar']
    assert split_args("foo='bar baz'") == ["foo='bar baz'"]
    assert split_args("foo=bar baz=foo") == ['foo=bar', 'baz=foo']
    assert split_args("foo='bar baz' a=b") == ["foo='bar baz'", 'a=b']
    assert split_args("foo=' bar baz ' a=b") == ["foo=' bar baz '", 'a=b']
    assert split_args("foo='bar baz' a=b 'foo=bar baz'") == ["foo='bar baz'", 'a=b', "'foo=bar baz'"]

# Generated at 2022-06-11 06:21:37.936813
# Unit test for function split_args

# Generated at 2022-06-11 06:21:46.592017
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('one') == ['one']
    assert split_args('one two') == ['one', 'two']
    assert split_args('one \\\ntwo') == ['one', 'two']
    assert split_args('one "two three"') == ['one', '"two three"']
    assert split_args('one "two three" four') == ['one', '"two three"', 'four']
    assert split_args('one "two \\\nthree" four') == ['one', '"two \nthree"', 'four']
    assert split_args('one "two three" four "five six"') == ['one', '"two three"', 'four', '"five six"']

# Generated at 2022-06-11 06:21:57.881007
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("/bin/foo bar='{{ foo }}'") == ['/bin/foo', "bar='{{ foo }}'"]
    assert split_args("/bin/foo\\\nbar='{{ foo }}'") == ['/bin/foo', 'bar=\'{{ foo }}\'']


# Make sure this is called from the Ansible module directory
# because it uses data_template.
if __name__ == '__main__':

    import sys
    import os
    basedir = os.path.dirname(sys.argv[0])

    if len(sys.argv) < 2:
        print("usage: %s data_template [var=value ...]" % sys.argv[0])


# Generated at 2022-06-11 06:22:07.541570
# Unit test for function split_args
def test_split_args():
    assert split_args("foo=bar") == ["foo=bar"]
    assert split_args("foo=\"bar baz\"") == ["foo=bar baz"]
    assert split_args("foo=\"bar {{baz}}\"") == ["foo=bar {{baz}}"]
    assert split_args("foo=bar {{baz}}") == ["foo=bar", "{{baz}}"]
    assert split_args("foo=bar '{'baz'}'") == ["foo=bar", "'{'baz'}'"]
    assert split_args("foo=bar \"{\"baz\"}\"") == ["foo=bar", "\"{\"baz\"}\""]
    assert split_args("foo=bar \"{baz}\"") == ["foo=bar", "\"{baz}\""]

# Generated at 2022-06-11 06:22:17.559247
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('') == []
    assert split_args('a=1 b="2 3"') == ['a=1', 'b="2 3"']
    assert split_args('"foo" "bar"') == ['foo', 'bar']
    assert split_args('"foo bar" baz') == ['foo bar', 'baz']
    assert split_args('a="foo bar" baz') == ['a="foo bar"', 'baz']
    assert split_args('a="foo bar" baz \\') == ['a="foo bar"', 'baz']
    assert split_args('a="foo bar" \\') == ['a="foo bar"']

# Generated at 2022-06-11 06:22:28.166753
# Unit test for function split_args
def test_split_args():

    # Single word, no quotes
    assert split_args("foo") == ['foo']

    # Single word, quotes
    assert split_args("'foo'") == ["'foo'"]
    assert split_args('"foo"') == ['"foo"']

    # Multiple words, no quotes
    assert split_args("foo bar") == ['foo', 'bar']

    # Multiple words, quotes
    assert split_args("'foo bar'") == ["'foo bar'"]
    assert split_args('"foo bar"') == ['"foo bar"']

    # Test quotes inside of quotes
    assert split_args("\"foo 'bar'\"") == ['"foo \'bar\'"']
    assert split_args("'foo \"bar\"'") == ["'foo \"bar\"'"]

    # Test quotes with spaces inside
    assert split_args

# Generated at 2022-06-11 06:22:37.892461
# Unit test for function split_args
def test_split_args():
    # basic test
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    # basic test with newline instead of space
    assert split_args('a=b\nc="foo bar"') == ['a=b\n', 'c="foo bar"']
    # test with newline and line continuation
    assert split_args('a=b \\\nc="foo bar"') == ['a=b \\\n', 'c="foo bar"']
    # test with two consecutive newlines
    assert split_args('a="foo \n bar" \n\nc=d') == ['a="foo \n bar" \n\n', 'c=d']
    # test with a line continuation after an unquoted value

# Generated at 2022-06-11 06:22:44.396550
# Unit test for function split_args
def test_split_args():
    args = '''a=b 'c d' "e f" g="h i" j='k l' "{{ m }}" n='{% o %}' 'p q'\nr s'''
    result = split_args(args)
    assert len(result) == 8, 'unexpected number of arguments: %s' % result
    assert result[0] == 'a=b', 'argument 1 does not match: %s' % result[0]
    assert result[1] == 'c d', 'argument 2 does not match: %s' % result[1]
    assert result[2] == 'e f', 'argument 3 does not match: %s' % result[2]
    assert result[3] == 'g="h i"', 'argument 4 does not match: %s' % result[3]
    assert result[4]

# Generated at 2022-06-11 06:22:54.927014
# Unit test for function split_args
def test_split_args():
    test_string = "module: yum name=httpd state=present"
    test_params = [u"module:", u"yum", u"name=httpd", u"state=present"]
    assert split_args(test_string) == test_params

    test_string = "module: yum name=httpd state=present"
    test_params = [u"module:", u"yum", u"name=httpd", u"state=present"]
    assert split_args(test_string) == test_params

    test_string = "module: yum name=httpd state=present"
    test_params = [u"module:", u"yum", u"name=httpd", u"state=present"]
    assert split_args(test_string) == test_params


# Generated at 2022-06-11 06:23:04.502196
# Unit test for function split_args
def test_split_args():
    def _test(input, expected):
        result = split_args(input)
        if result != expected:
            raise AssertionError("split_args failed to split %s. Expected: %s, got %s" % (input, expected, result))
    _test('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _test('a={{ b }}', ['a={{ b }}'])
    _test('a="b {{ c }} d"', ['a="b {{ c }} d"'])
    _test('a="b {{ c }} d {{ e }}"', ['a="b {{ c }} d {{ e }}"'])
    _test('a="b {{ c }} d {{ e }} f"', ['a="b {{ c }} d {{ e }} f"'])

# Generated at 2022-06-11 06:23:35.958345
# Unit test for function split_args
def test_split_args():
    # test single string with quotes
    assert split_args('"foo bar"') == ['foo bar']

    # test list of strings with quotes
    assert split_args('"foo bar" "baz bux"') == ['foo bar', 'baz bux']

    # test list of strings with quotes and whitespace
    assert split_args('"foo bar"     "baz bux"') == ['foo bar', 'baz bux']

    # test list of strings with quotes and newline
    assert split_args('"foo bar"\n"baz bux"') == ['foo bar\n', 'baz bux']

    # test list of strings with quotes and newline and whitespace
    assert split_args('"foo bar"    \n"baz bux"') == ['foo bar\n', 'baz bux']



# Generated at 2022-06-11 06:23:43.795308
# Unit test for function split_args
def test_split_args():
    def cmp_args(full_args, correct_params):
        params = split_args(full_args)
        if params != correct_params:
            raise AssertionError("Expected %r, got %r" % (correct_params, params))
    cmp_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    cmp_args('a=b c=\'foo bar\'', ['a=b', 'c=\'foo bar\''])
    cmp_args('a={{ foo }} b="{{ bar }}"', ['a={{ foo }}', 'b="{{ bar }}"'])
    cmp_args('a={{ foo }} b="{{ bar }}', ['a={{ foo }}', 'b="{{ bar }}'])

# Generated at 2022-06-11 06:23:54.022170
# Unit test for function split_args
def test_split_args():
    assert split_args('--timeout=5') == ['--timeout=5']
    assert split_args('--timeout=5 a=b') == ['--timeout=5', 'a=b']
    assert split_args('--timeout=5 a=b c="foo bar"') == ['--timeout=5', 'a=b', 'c="foo bar"']
    assert split_args('--timeout="{{foo}}"') == ['--timeout="{{foo}}"']
    assert split_args('--timeout="{{foo}}" a="{{bar}}"') == ['--timeout="{{foo}}"', 'a="{{bar}}"']

# Generated at 2022-06-11 06:24:04.208844
# Unit test for function split_args
def test_split_args():
    # Test 1
    arg_string = 'foo bar bam'
    arg_list = ['foo', 'bar', 'bam']
    assert split_args(arg_string) == arg_list
    # Test 2
    arg_string = 'foo=bar bam=bat'
    arg_list = ['foo=bar', 'bam=bat']
    assert split_args(arg_string) == arg_list
    # Test 3
    arg_string = 'foo=bar bam={{bat}}'
    arg_list = ['foo=bar', 'bam={{bat}}']
    assert split_args(arg_string) == arg_list
    # Test 4
    arg_string = 'foo=bar bam={{bat}} boom={{bat}}'

# Generated at 2022-06-11 06:24:13.451660
# Unit test for function split_args
def test_split_args():
    assert split_args('a=1 b="2 3"') == ['a=1', 'b="2 3"']
    assert split_args('foo="bar baz"') == ['foo="bar baz"']
    assert split_args('foo="bar baz" foo2=bar2') == ['foo="bar baz"', 'foo2=bar2']
    assert split_args('foo="bar \\"baz\\""') == ['foo="bar \\"baz\\""']
    assert split_args('foo="bar \\"baz\\"" bar2="foo2 bar2"') == ['foo="bar \\"baz\\""', 'bar2="foo2 bar2"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-11 06:24:24.805487
# Unit test for function split_args

# Generated at 2022-06-11 06:24:34.086272
# Unit test for function split_args
def test_split_args():
    import pytest
    from ansible.utils.unsafe_proxy import to_unsafe_text

    # test cases

# Generated at 2022-06-11 06:24:43.839948
# Unit test for function split_args
def test_split_args():
    import pytest

    def verify(args, expected):
        result = split_args(args)
        assert result == expected, "%s != %s" % (result, expected)

    verify("a=b c='foo bar'", ['a=b', "c='foo bar'"])
    verify("foo=bar d='{\"foo\": \"bar\"}'", ['foo=bar', 'd=\'{"foo": "bar"}\''])
    verify('foo=bar d="{\\"foo\\": \\"bar\\"}"', ['foo=bar', 'd="{\\"foo\\": \\"bar\\"}"'])

# Generated at 2022-06-11 06:24:53.415875
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=\"foo bar\""]
    assert split_args("a=b c={{foo}}") == ["a=b", "c={{foo}}"]
    assert split_args("a=b c=foo\\") == ["a=b", "c=foo"]
    assert split_args("a=b c=foo\\\ndef") == ["a=b", "c=foo", "def"]
    assert split_args("/usr/bin/foo bar=baz \\ \n/usr/bin/bar baz=foo") == ['/usr/bin/foo', 'bar=baz', '/usr/bin/bar', 'baz=foo']

# Generated at 2022-06-11 06:25:02.765428
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for split args, which is a modified version of shlex
    '''

    # when this test is run, we invoke it from the current directory
    # instead of from the ansible directory, so we need to change directories
    # to find the test files
    import os
    import subprocess
    os.chdir('test/units/modules/utils')
    p = subprocess.Popen(['../../../../hacking/test-module', '-m', 'debug', '-a', '"show_args=yes"', '-a', '"arg1=this is a test"'], stdout=subprocess.PIPE)
    p.wait()
    output = p.stdout.read()

# Generated at 2022-06-11 06:25:40.165583
# Unit test for function split_args
def test_split_args():
    # The goal of this test is to make sure that complex strings are split
    # properly and can be reassembled to exactly match the original
    # input string.
    #
    # Note that this is not a unit test of jinja2 templating, but rather
    # making sure that a string is split properly into tokens in the various
    # use cases that ansible needs.
    #
    # The strings for testing are stored in a dict, with the keys being a text
    # description of what's being tested and the value being the string to be
    # tested.
    #
    # The result of each test is a list of correctly split tokens that exactly
    # match the original input string when joined together.

    strings = dict()
    strings['plain'] = "this is a plain string"

# Generated at 2022-06-11 06:25:49.380356
# Unit test for function split_args

# Generated at 2022-06-11 06:25:56.787362
# Unit test for function split_args

# Generated at 2022-06-11 06:26:05.242096
# Unit test for function split_args

# Generated at 2022-06-11 06:26:13.100768
# Unit test for function split_args
def test_split_args():

    assert split_args('') == []
    assert split_args('  ') == []
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('  a=b  c="foo bar"  ') == ['a=b', 'c="foo bar"']
    assert split_args('/usr/bin/foo --bar="baz qux"') == ['/usr/bin/foo', '--bar="baz qux"']
    assert split_args('/usr/bin/foo') == ['/usr/bin/foo']
    assert split_args('/usr/bin/foo bar="foo bar"') == ['/usr/bin/foo', 'bar="foo bar"']

# Generated at 2022-06-11 06:26:21.891819
# Unit test for function split_args
def test_split_args():
    print("Testing split_args...")
    assert split_args("a=b c='foo bar'") == ['a=b', 'c=\'foo bar\'']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']
    assert split_args('a=b c="foo\n\nbar"') == ['a=b', 'c="foo\n\nbar"']
    assert split_args("a=b c='foo\nbar'") == ['a=b', 'c=\'foo\nbar\'']

# Generated at 2022-06-11 06:26:28.618155
# Unit test for function split_args

# Generated at 2022-06-11 06:26:37.490010
# Unit test for function split_args
def test_split_args():
    # test basic splitting
    args = 'a=2 b=3'
    res = split_args(args)
    assert len(res) == 2
    assert res[0] == 'a=2'
    assert res[1] == 'b=3'

    # test basic split with trailing whitespace
    args = 'a=2 b=3  '
    res = split_args(args)
    assert len(res) == 2
    assert res[0] == 'a=2'
    assert res[1] == 'b=3'

    # test basic split with leading whitespace
    args = '  a=2 b=3'
    res = split_args(args)
    assert len(res) == 2
    assert res[0] == 'a=2'
    assert res[1] == 'b=3'



# Generated at 2022-06-11 06:26:46.647180
# Unit test for function split_args
def test_split_args():

    # Test examples found in module documentation
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']

    args = 'a={{ b }}'
    assert split_args(args) == ['a={{ b }}']

    args = 'a={{ b }} c="{{ d }}"'
    assert split_args(args) == ['a={{ b }}', 'c="{{ d }}"']

    args = 'a="{{ b }}" c="{{ d }}"'
    assert split_args(args) == ['a="{{ b }}"', 'c="{{ d }}"']

    args = 'a={{ b }} c="{{ d }}"'
    assert split_args(args) == ['a={{ b }}', 'c="{{ d }}"']

    args

# Generated at 2022-06-11 06:26:54.556025
# Unit test for function split_args
def test_split_args():

    assert split_args("foo=bar") == ['foo=bar']
    assert split_args("foo='bar baz'") == ["foo='bar baz'"]
    assert split_args("foo=\"bar baz\"") == ['foo="bar baz"']
    assert split_args("foo=\"ba'r baz\"") == ["foo=\"ba'r baz\""]