

# Generated at 2022-06-25 01:39:08.531968
# Unit test for function is_quoted
def test_is_quoted():
    str_0 = 'm{?mV+'
    str_1 = '"m{?mV+"'
    str_2 = "foo'bar''"
    var_0 = is_quoted(str_0)
    var_1 = is_quoted(str_1)
    var_2 = is_quoted(str_2)
    assert var_0 == False
    assert var_1 == True
    assert var_2 == True
    # Test if the string is quoted
    # Test unquote function
    test_case_0()

if __name__ == '__main__':
    test_is_quoted()

# Generated at 2022-06-25 01:39:10.278758
# Unit test for function split_args
def test_split_args():
    arg_0 = 'a=b c="foo bar"'
    params_0 = split_args(arg_0)
    dict_0 = dict(params_0)
    print(dict_0)


# Generated at 2022-06-25 01:39:21.385401
# Unit test for function split_args
def test_split_args():
    str_0 = 'a="b" c="d"'
    var_0 = split_args(str_0)
    assert var_0 == ['a=b', 'c=d']

    str_0 = 'foo'
    var_0 = split_args(str_0)
    assert var_0 == ['foo']

    str_0 = 'foo bar'
    var_0 = split_args(str_0)
    assert var_0 == ['foo', 'bar']

    str_0 = '{{ foo }}'
    var_0 = split_args(str_0)
    assert var_0 == ['{{ foo }}']

    str_0 = '{{ foo }} bar'
    var_0 = split_args(str_0)
    assert var_0 == ['{{ foo }}', 'bar']


# Generated at 2022-06-25 01:39:26.154005
# Unit test for function split_args
def test_split_args():
    # Test case 0
    str_0 = 'm{?mV+'
    var_0 = split_args(str_0)

    assert var_0 == ['m{?mV+']

    # Test case 1
    str_0 = 'uw|@C'
    var_0 = split_args(str_0)

    assert var_0 == ['uw|@C']

    # Test case 2
    str_0 = 'Q\"'
    var_0 = split_args(str_0)

    assert var_0 == ['Q"']

    # Test case 3
    str_0 = '%F(%]n'
    var_0 = split_args(str_0)

    assert var_0 == ['%F(%]n']

    # Test case 4

# Generated at 2022-06-25 01:39:29.577534
# Unit test for function is_quoted
def test_is_quoted():

    test_case_0()
    test_case_1()


# Generated at 2022-06-25 01:39:34.279454
# Unit test for function split_args
def test_split_args():
    print('Inside function test_split_args')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()

    print('End of function test_split_args')


# Generated at 2022-06-25 01:39:37.274127
# Unit test for function split_args
def test_split_args():
    test_str_0 = 'git -C ${CODE_DIR} pull'
    var_0 = split_args(test_str_0)
    print(var_0)


# Generated at 2022-06-25 01:39:43.605998
# Unit test for function is_quoted
def test_is_quoted():
    str_0 = 'm{?mV+'
    var_0 = is_quoted(str_0)
    assert not var_0

    str_1 = '"'
    var_1 = is_quoted(str_1)
    assert var_1

    str_2 = '"'
    var_2 = is_quoted(str_2)
    assert var_2

    str_3 = '"'
    var_3 = is_quoted(str_3)
    assert var_3

    str_4 = '"'
    var_4 = is_quoted(str_4)
    assert not var_4

    str_5 = '"'
    var_5 = is_quoted(str_5)
    assert var_5

    str_6 = '"'
    var_6 = is_quoted

# Generated at 2022-06-25 01:39:52.789481
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz'], 'Should return a list of the arguments'

    assert split_args('foo="bar baz"') == ['foo="bar baz"'], 'Should return a list of the arguments'

    assert split_args('foo=\"bar baz\"') == ['foo="bar baz"'], 'Should return a list of the arguments'

    assert split_args('foo=\"bar \\\'baz\\\'\"') == ['foo="bar \'baz\'"'], 'Should return a list of the arguments'

    assert split_args('foo=bar \'baz') == ['foo=bar', '\'baz'], 'Should return a list of the arguments'

    assert split_args('foo=bar \\') == ['foo=bar'], 'Should return a list of the arguments'

# Generated at 2022-06-25 01:39:57.289280
# Unit test for function is_quoted
def test_is_quoted():
    str1 = 'm{?mV+'
    str2 = '"m{?mV+"'
    str3 = "'m{?mV+'"

    if is_quoted(str1) or not is_quoted(str2) or not is_quoted(str3):
        print("Unit test failed test_is_quoted")
        exit(1)


# Generated at 2022-06-25 01:40:33.227523
# Unit test for function split_args
def test_split_args():
    assert is_quoted('"foobar"')
    assert split_args('"foobar"') == ['foobar']
    assert split_args('foo="foobar"') == ['foo=foobar']
    assert split_args('"foo bar=baz"') == ['foo bar=baz']
    assert split_args('"foo" "bar=baz"') == ['foo', 'bar=baz']
    assert split_args('"foo" "bar"="baz"') == ['foo', 'bar=baz']
    assert split_args('"foo" "bar"="baz"') == ['foo', 'bar=baz']
    assert split_args('"foo" "bar"="baz"') == ['foo', 'bar=baz']

# Generated at 2022-06-25 01:40:39.889038
# Unit test for function split_args
def test_split_args():
    str_0 = 'm{?mV+'
    str_1 = 'a=b c="foo bar"'
    str_2 = 'a=b c="foo\nbar"'
    str_3 = '''a=b c="foo bar"'''
    str_4 = '''a=b c="foo bar"\n d={{ foo }}'''
    str_5 = 'a=b c="foo\nbar"'
    str_6 = 'a="b c" d="e f"'
    str_7 = '''\n---\n#!/usr/bin/python\nprint "hello"'''

# Generated at 2022-06-25 01:40:47.889356
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar" d="foo\nbar" e="foo\\"bar" f=\'foo bar\'') == ['a=b', 'c="foo bar"', 'd="foo\nbar"', 'e="foo\\"bar"', 'f=\'foo bar\'']
    assert split_args('a=b c="foo bar" d="foo\nbar" e="foo\\"bar" f=\'foo bar\'') != ['a=b', 'c="foo', 'bar"', 'd="foo\nbar"', 'e="foo\\"bar"', 'f=\'foo bar\'']
    #assert is_quoted(str_0)==var_0


# Generated at 2022-06-25 01:40:54.899312
# Unit test for function split_args
def test_split_args():
    if debugging:
        print("=== test_split_args() ===")


# Generated at 2022-06-25 01:40:59.568641
# Unit test for function split_args
def test_split_args():
    print ("Testing for function split_args")
    str_0 = 'm{?mV+'
    list_0 = split_args(str_0)
    list_1 = split_args('"{?V"m{?mV+"+' + ' ' + 'm{?mV+')
    assert (list_0 == list_1)


# Generated at 2022-06-25 01:41:00.925623
# Unit test for function split_args
def test_split_args():
    str_0 = 'm{?mV+'
    var_0 = split_args(str_0)
    assert var_0[0] == 'm{?mV+'


# Generated at 2022-06-25 01:41:06.204851
# Unit test for function split_args
def test_split_args():
    # Test if call to function split_args returns expected result
    str_0 = " 'a=b' c=\"foo bar\""
    var_0 = split_args(str_0)
    if var_0 != ['a=b', 'c="foo bar"']:
        raise AssertionError(var_0)

    str_1 = "{% if a%c %}"
    var_1 = split_args(str_1)
    if var_1 != ['{%', 'if', 'a%c', '%}']:
        raise AssertionError(var_1)

    str_2 = "a=1 b=2"
    var_2 = split_args(str_2)
    if var_2 != ['a=1', 'b=2']:
        raise AssertionError(var_2)



# Generated at 2022-06-25 01:41:14.241663
# Unit test for function split_args
def test_split_args():
    # Expected return value
    ret_0 = ['a=b', 'c="foo bar"']
    # Call function
    ret_val_0 = split_args('a=b c="foo bar"')
    # Evaluate results
    assert ret_val_0 == ret_0

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:41:17.023075
# Unit test for function split_args
def test_split_args():
    str_0 = ' a=v b="c d" '
    var_0 = split_args(str_0)
    assert var_0 == ['a=v', 'b="c d"']


# Generated at 2022-06-25 01:41:24.769306
# Unit test for function split_args
def test_split_args():
    string1 = 'A=B\nC="D\nE"'
    string2 = 'ssh -vvv -C -i /tmp/mykey.pem -o ControlMaster=auto -o ControlPersist=60s -o ControlPath=/tmp/ansible-ssh-%h-%p-%r -o Port=22 -o KbdInteractiveAuthentication=no -o PreferredAuthentications=gssapi-with-mic,gssapi-keyex,hostbased,publickey -o PasswordAuthentication=no -o ConnectTimeout=10 ec2-user@54.69.208.232'

    print(split_args(string1))
    print(split_args(string2))



# Generated at 2022-06-25 01:41:37.923483
# Unit test for function split_args
def test_split_args():

    # Test case 0
    test_case_0()


# Generated at 2022-06-25 01:41:42.903758
# Unit test for function split_args
def test_split_args():
    str_1 = 'm{?mV+'
    str_2 = '^]QY6'
    str_3 = 'JSH$'
    var_1 = split_args(str_1)
    var_2 = split_args(str_2)
    var_3 = split_args(str_3)


# run unit tests
if __name__ == '__main__':
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:41:50.399225
# Unit test for function split_args

# Generated at 2022-06-25 01:41:56.075317
# Unit test for function split_args
def test_split_args():
    str_0 = 'f{o\'o\'o}'
    var_0 = split_args(str_0)
    str_1 = 'a=b c="foo \"bar\" baz"'
    var_1 = split_args(str_1)


# Generated at 2022-06-25 01:42:02.591393
# Unit test for function split_args

# Generated at 2022-06-25 01:42:09.920808
# Unit test for function split_args
def test_split_args():
    # Test 0: Test simple argument
    str_0 = 'foo'
    expected_0 = ['foo']
    params_0 = split_args(str_0)
    assert expected_0 == params_0

    # Test 1: Test multi word argument
    str_1 = 'foo bar'
    expected_1 = ['foo', 'bar']
    params_1 = split_args(str_1)
    assert expected_1 == params_1

    # Test 2: Test multi word argument in quotes
    str_2 = 'foo "bar baz"'
    expected_2 = ['foo', '"bar', 'baz"']
    params_2 = split_args(str_2)
    assert expected_2 == params_2

    # Test 3: Test multi word argument in quotes with trailing quotes

# Generated at 2022-06-25 01:42:13.132323
# Unit test for function split_args
def test_split_args():
    cwd = os.path.dirname(os.path.realpath(__file__))
    with open(cwd + '/split_args_test_cases.json', 'r') as test_cases_json:
        test_cases = json.load(test_cases_json)

        for test_case in test_cases:
            params = split_args(test_case['args'])
            assert params == test_case['expected']


# Generated at 2022-06-25 01:42:16.964025
# Unit test for function split_args
def test_split_args():
    args=""" -e 'foo bar'"""
    params = split_args(args)


# Generated at 2022-06-25 01:42:22.554549
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="foo bar"'
    ret = split_args(str_0)
    assert ret == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 01:42:29.493277
# Unit test for function split_args
def test_split_args():
    str_0 = "{% foo bar baz %} {{ 'hello' }}"
    var_0 = split_args(str_0)
    assert var_0 == ['{% foo bar baz %}', '{{ \'hello\' }}']
    str_1 = "{% foo bar baz %}\n {{ 'hello' }}"
    var_1 = split_args(str_1)
    assert var_1 == ['{% foo bar baz %}\n', '{{ \'hello\' }}']
    str_2 = "{% foo bar baz %}\n {{ 'hel\nlo' }}"
    var_2 = split_args(str_2)
    assert var_2 == ['{% foo bar baz %}\n', '{{ \'hel\nlo\' }}']

# Generated at 2022-06-25 01:42:50.736117
# Unit test for function split_args
def test_split_args():
    str_0 = 'args'
    params_0 = split_args(str_0)

    str_1 = 'args=test'
    params_1 = split_args(str_1)

    str_2 = 'md5sum="md5sum /etc/passwd"'
    params_2 = split_args(str_2)

    str_3 = '| tee -a {{ logfile }}'
    params_3 = split_args(str_3)

    str_4 = '| tee -a {{ logfile }}'
    params_4 = split_args(str_4)

    str_5 = '"{{ ansible_managed }}"'
    params_5 = split_args(str_5)

    str_6 = '# vim: "{{ vim_syntax }}"'

# Generated at 2022-06-25 01:43:00.081977
# Unit test for function split_args
def test_split_args():
    # test case 0
    str_0 = 'ssss'
    assert(split_args(str_0) == ['ssss'])

    # test case 1
    str_1 = 'a=b c="foo bar"'
    assert(split_args(str_1) == ['a=b', 'c="foo bar"'])

    # test case 2
    str_2 = 'a=b c="foo bar"'
    assert(split_args(str_2) == ['a=b', 'c="foo bar"'])

    # test case 3
    str_3 = 'a=b {% if x %} c="foo bar" {% endif %}'
    assert(split_args(str_3) == ['a=b', '{% if x %} c="foo bar" {% endif %}'])

    # test

# Generated at 2022-06-25 01:43:10.383879
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b c" d=e') == ['a="b c"', 'd=e']
    assert split_args('a="b c d"') == ['a="b c d"']
    assert split_args("a='b c d'") == ["a='b c d'"]
    assert split_args("a='b c d' e=f") == ["a='b c d'", 'e=f']

# Generated at 2022-06-25 01:43:20.410867
# Unit test for function split_args
def test_split_args():
    ################################################################################
    # Test cases
    ################################################################################
    # str_0 = ' '
    str_0 = ' args '
    str_1 = 'echo "Hello World"'
    str_2 = 'echo "Hello World"  '
    str_3 = 'echo "Hello World"  args'
    str_4 = 'echo "Hello World"  args '
    str_5 = 'echo "Hello World"  " args"'
    str_6 = 'echo "Hello World"  " args" '
    str_7 = 'echo "Hello \'World"  " args"'
    str_8 = 'echo \'Hello "World\'  " args"'
    str_9 = '''{% if xxx -%}
{% endif -%}'''

# Generated at 2022-06-25 01:43:23.770855
# Unit test for function split_args
def test_split_args():
    print('Unit test for function split_args')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 01:43:30.416725
# Unit test for function split_args
def test_split_args():
    # call the function, split_args
    # use split_args to test different input
    str_0 = 'args'
    str_1 = 'a=b c="foo bar" d="foo\"bar\"" e=\\'
    print(split_args(str_0))
    print(split_args(str_1))


# unit test

# Generated at 2022-06-25 01:43:33.969619
# Unit test for function split_args
def test_split_args():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 01:43:35.628810
# Unit test for function split_args
def test_split_args():
    assert split_args('args') == ['args']


# Generated at 2022-06-25 01:43:37.478422
# Unit test for function split_args
def test_split_args():
    # Test case for split_args
    # Test a simple arg
    # Input:
    #   args = 'args'
    # Output:
    #   ['args']
    assert split_args('args') == ['args']



# Generated at 2022-06-25 01:43:44.438614
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == ['a=b']
    assert split_args(u'a=b c="foo bar"') == ['a=b', u'c="foo bar"']
    assert split_args(u'"foo bar" c="foo bar"') == [u'"foo bar"', u'c="foo bar"']


# Generated at 2022-06-25 01:44:20.207281
# Unit test for function split_args
def test_split_args():
    str_1 = 'ansible_host=10.11.12.13 ansible_user=jreminga@okta.com ansible_become_pass=\'password\' ansible_ssh_pass=\'password\' ansible_become_user=jreminga'
    ans_1 = ['ansible_host=10.11.12.13', 'ansible_user=jreminga@okta.com', "ansible_become_pass='password'", "ansible_ssh_pass='password'", 'ansible_become_user=jreminga']
    assert(split_args(str_1) == ans_1)


# Generated at 2022-06-25 01:44:25.386215
# Unit test for function split_args
def test_split_args():
    assert 'a' in split_args('a')
    assert 'b' in split_args('a b')
    assert 'c' in split_args('a b c')
    assert 'a b c' in split_args('a b c')
    assert 'a b' in split_args('"a b" c')
    assert 'c' in split_args('"a b" c')
    assert '"a b"' in split_args('"a b" c')
    assert 'c' in split_args('"a b" c')
    assert 'c' in split_args('"a b" "c"')
    assert '"a b"' in split_args('"a b" "c"')
    assert '"c"' in split_args('"a b" "c"')

    assert 'a' in split_args

# Generated at 2022-06-25 01:44:32.205965
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("one two") == ["one", "two"]
    assert split_args("one two three") == ["one", "two", "three"]
    assert split_args("one 'two three' four") == ["one", "'two three'", "four"]
    assert split_args("one \"two three\" four") == ["one", "\"two three\"", "four"]
    assert split_args("one \"two three") == ["one", "\"two", "three"]
    assert split_args("one \"two three\"") == ["one", "\"two three\""]
    assert split_args("one 'two three") == ["one", "'two", "three"]
    assert split_args("one 'two three'") == ["one", "'two three'"]

# Generated at 2022-06-25 01:44:39.600393
# Unit test for function split_args
def test_split_args():

    # case 0
    str_0 = 'args'
    res_0 = split_args(str_0)
    print(res_0)

    # case 1
    str_1 = 'x=1 y=2 z=3'
    res_1 = split_args(str_1)
    print(res_1)

    # case 2
    str_2 = 'x="1 2 3" y="4 5 6"'
    res_2 = split_args(str_2)
    print(res_2)

    # case 3
    str_3 = "x='1 2 3' y='4 5 6'"
    res_3 = split_args(str_3)
    print(res_3)

    # case 4
    str_4 = 'x="1 \'2 3\'" y="4 5 6"'
   

# Generated at 2022-06-25 01:44:46.272737
# Unit test for function split_args
def test_split_args():
    # Test with a non-quoted parameter and no delimiter
    assert split_args('test_arg') == ['test_arg']
    # Test with a non-quoted parameter ending with a backslash
    assert split_args('test_arg\\') == ['test_arg\\']
    # Test with a non-quoted parameter with a delimiter and no delimiter
    assert split_args('test_arg1,test_arg2') == ['test_arg1', 'test_arg2']
    # Test with a quoted parameter with a delimiter and no delimiter
    assert split_args('"test_arg1","test_arg2"') == ['test_arg1', 'test_arg2']
    # Test with a quoted parameter with a delimiter and no delimiter, with spaces

# Generated at 2022-06-25 01:44:55.815886
# Unit test for function split_args
def test_split_args():
    assert ['args'] == split_args(' args')
    assert ['arg1', 'arg2', 'arg3'] == split_args('arg1 arg2 arg3')
    assert ['arg1', 'arg2', 'arg3', 'arg4'] == split_args('arg1 arg2\narg3\narg4')
    assert ['arg1', 'arg2', 'arg3', 'arg4', 'arg5', 'arg6'] == split_args('arg1 arg2\narg3 arg4\narg5 arg6')
    assert ['arg1', 'arg2 "foo bar"', 'arg3', 'arg4', 'arg5 "foo bar"', 'arg6'] == split_args('arg1 arg2 "foo bar"\narg3 arg4\narg5 "foo bar" arg6')

# Generated at 2022-06-25 01:44:58.524015
# Unit test for function split_args
def test_split_args():
    # Test cases of string args
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:45:04.372639
# Unit test for function split_args
def test_split_args():
    # Test case where the input args are
    str_0 = '''a=b c="foo bar"'''
    str_1 = '''
    c="foo bar"
    '''
    str_2 = '''
    c="foo
    bar"
    '''
    str_3 = '''
    c="foo
    bar"
    a=b
    '''
    str_4 = '''
    c="foo
    bar"
    a=b
    '''
    str_5 = '''
    c="foo
    bar"
    a=b
    '''
    str_6 = '''
    c="foo
    bar"
    a=b
    '''
    str_7 = '''
    c="foo
    bar"
    a=b
    '''
   

# Generated at 2022-06-25 01:45:05.383856
# Unit test for function split_args
def test_split_args():
    assert split_args(test_case_0()) == [test_case_0()]


# Generated at 2022-06-25 01:45:10.550619
# Unit test for function split_args
def test_split_args():
	# Test case 1
	print('Test case 1')
	str_1 = 'a b c'
	print(split_args(str_1))
	# Test case 2
	print('Test case 2')
	str_2 = '"a b c"'
	print(split_args(str_2))
	# Test case 3
	print('Test case 3')
	str_3 = 'foo="a b c"'
	print(split_args(str_3))
	# Test case 4
	print('Test case 4')
	str_4 = 'foo="a b c" bar'
	print(split_args(str_4))
	# Test case 5
	print('Test case 5')
	str_5 = "foo='a b c' bar"
	print(split_args(str_5))
	# Test

# Generated at 2022-06-25 01:46:35.351791
# Unit test for function split_args
def test_split_args():
    print('Testing split_args...', end='')
    res = split_args('a=b c="foo bar"')
    # print(res)
    assert(res == ['a=b', 'c="foo bar"'])
    res = split_args('a=b\ncd=ef\ngh="Ij kl"')
    # print(res)
    assert(res == ['a=b\n', 'cd=ef\n', 'gh="Ij kl"'])
    res = split_args('ls -l\na=b\ncd=ef\ngh="Ij kl"')
    # print(res)
    assert(res == ['ls', '-l\n', 'a=b\n', 'cd=ef\n', 'gh="Ij kl"'])
    res = split_args

# Generated at 2022-06-25 01:46:42.868130
# Unit test for function split_args
def test_split_args():
    str_1 = 'a=b c="foo bar"'
    assert(split_args(str_1) == ['a=b', 'c="foo bar"'])

    str_2 = 'a=b c="foo bar"\ne=f g="foo bar"'
    assert(split_args(str_2) == ['a=b', 'c="foo bar"\ne=f', 'g="foo bar"'])

    str_3 = 'a=b c="foo bar"\ne=f g="foo bar"\ni="{{ foo }}"'
    assert(split_args(str_3) == ['a=b', 'c="foo bar"\ne=f', 'g="foo bar"\ni="{{', 'foo', '}}"'])


# Generated at 2022-06-25 01:46:49.086220
# Unit test for function split_args
def test_split_args():

    # Test case 01
    print("\n### Test case 01")
    str_0 = 'ansible-doc -l'
    args = split_args(str_0)
    print("Parameters: {}".format(args))
    assert args == ['ansible-doc', '-l']

    # Test case 02
    print("\n### Test case 02")
    str_0 = 'ansible-doc -l "module1" "module2" "module3"'
    args = split_args(str_0)
    print("Parameters: {}".format(args))
    assert args == ['ansible-doc', '-l', 'module1', 'module2', 'module3']

    # Test case 03
    print("\n### Test case 03")
    str_0 = 'ansible-doc -h'
    args = split_

# Generated at 2022-06-25 01:46:55.509549
# Unit test for function split_args

# Generated at 2022-06-25 01:47:04.902329
# Unit test for function split_args
def test_split_args():
    str_1 = 'some string'
    ans_1 = ['some', 'string']
    assert ans_1 == split_args(str_1)
    str_2 = 'arg1 arg2 arg3'
    ans_2 = ['arg1', 'arg2', 'arg3']
    assert ans_2 == split_args(str_2)
    str_3 = 'arg1="foo" arg2="bar"'
    ans_3 = ['arg1="foo"', 'arg2="bar"']
    assert ans_3 == split_args(str_3)
    str_4 = 'arg1=\'foo\' arg2=\'bar\''
    ans_4 = ['arg1=\'foo\'', 'arg2=\'bar\'']
    assert ans_4 == split_args(str_4)

# Generated at 2022-06-25 01:47:05.891909
# Unit test for function split_args
def test_split_args():
    args_0 = None
    result = split_args(args_0)
    assert result == 'args'

# Generated at 2022-06-25 01:47:08.744498
# Unit test for function split_args
def test_split_args():
    args = "arg1 arg2='hello world' arg3=hello,world"
    split_args(args)


# Generated at 2022-06-25 01:47:17.211270
# Unit test for function split_args
def test_split_args():
    print('\n' + '=' * 100)
    print('Test for function split_args()')
    print('-' * 100)
    str_0 = 'ansible-playbook test_playbook.yml -i inventory --timeout 25'
    res_0 = split_args(str_0)
    print('INPUT: %s' % str_0)
    print('OUTPUT: %s' % res_0)
    assert res_0 == ['ansible-playbook', 'test_playbook.yml', '-i', 'inventory', '--timeout', '25']


# Generated at 2022-06-25 01:47:18.430602
# Unit test for function split_args
def test_split_args():
    assert split_args(test_case_0()) == ['args'], 'Bad use of split_args'

# Generated at 2022-06-25 01:47:26.452937
# Unit test for function split_args
def test_split_args():
    test_str_0 = '''   {{ some_var }} 'foo' {{ "bar" }} "baz" {% if test %}fizz{{ foo }} {% endif %} buzz'''
    #test_str_0 = '''{{some_var}}'''
    print('[INFO] test_split_args: %s %s %s' % (test_str_0, test_str_0.split(), test_str_0.split('\n')))
    print('[INFO] test_split_args: %d' % (len(test_str_0.split())))
    #print(split_args(test_str_0))

