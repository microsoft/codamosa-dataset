

# Generated at 2022-06-25 01:38:59.105922
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") is True
    assert is_quoted('"hello"') is True
    assert is_quoted('unquoted') is False


# Generated at 2022-06-25 01:39:06.278994
# Unit test for function is_quoted
def test_is_quoted():
    # Data:
    str_1 = '"str"'
    str_2 = "'str'"
    str_3 = 'str'

    # Test:
    assert is_quoted(str_1)
    assert is_quoted(str_2)
    assert is_quoted(str_3) == False



# Generated at 2022-06-25 01:39:08.954610
# Unit test for function unquote
def test_unquote():

    # Zero input data
    data = 0
    result = unquote(data)
    assert result == data, "Unquote test failed with zero input data"

    # Input data is quoted
    data = "'test'"
    result = unquote(data)
    assert result == "test", "Unquote test failed with quoted input data"


# Generated at 2022-06-25 01:39:15.342620
# Unit test for function split_args
def test_split_args():
    # simple test case to check expected result
    test_case_0()
    # TODO add more test cases
    # test_case_1()
    # test_case_2()
    # test_case_3()
    # test_case_4()
    # test_case_5()
    # test_case_6()
    # test_case_7()
    # test_case_8()
    # test_case_9()
    # test_case_10()
    # test_case_11()
    # test_case_12()
    # test_case_13()
    # test_case_14()
    # test_case_15()
    # test_case_16()
    # test_case_17()
    # test_case_18()
    # test_case_19()
   

# Generated at 2022-06-25 01:39:27.064808
# Unit test for function split_args
def test_split_args():
    assert split_args('this is a test') == ['this', 'is', 'a', 'test']
    assert split_args('this "is a" test') == ['this', 'is a', 'test']
    assert split_args('this "is a" \'test\'') == ['this', 'is a', 'test']
    assert split_args('this "is a "test" test"') == ['this', 'is a "test" test']
    assert split_args('this "is a "test" test" foo') == ['this', 'is a "test" test', 'foo']
    assert split_args('"this "is a" "test" test" foo') == ['this "is a" "test" test', 'foo']

# Generated at 2022-06-25 01:39:30.759364
# Unit test for function split_args
def test_split_args():
    test_case_0()


# ------------------------------
# If a module is called in the main scope, run our local tests
if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:39:41.595928
# Unit test for function unquote
def test_unquote():
    assert unquote("\"") == "", "Expected: \"\""
    assert unquote("\'") == "", "Expected: \'\'"
    assert unquote("\"test\"") == "test", "Expected: \"test\""
    assert unquote("\'test\'") == "test", "Expected: \'test\'"
    assert unquote("''") == "", "Expected: \'\'"
    assert unquote("'''") == "\'", "Expected: \'\'"
    assert unquote("\'\'\'") == "'''", "Expected: \'\'\'"
    assert unquote("\'\'\'\'") == "''\'", "Expected: \'\'\'"
    assert unquote("\'\"\'") == "\"", "Expected: \'\"\'"

# Generated at 2022-06-25 01:39:52.314989
# Unit test for function split_args
def test_split_args():
    assert split_args('test') == ['test']
    assert split_args('test "long string"') == ['test', '"long string"']
    assert split_args('test "long string" other') == ['test', '"long string"', 'other']
    assert split_args("test 'another long string'") == ['test', "'another long string'"]
    assert split_args("test nospaces") == ['test', 'nospaces']
    assert split_args("test escaped \\'quote\\'") == ['test', "escaped", "'quote'"]
    assert split_args("test escaped \\\"quote\\\"") == ['test', 'escaped', '"quote"']
    assert split_args("test\\ test") == ['test test']
    assert split_args("test \\\ntest") == ['test', 'test']

# Generated at 2022-06-25 01:39:58.067833
# Unit test for function unquote
def test_unquote():
   assert not is_quoted("Hello world")
   assert is_unquote('"Hello world"') == "Hello world"
   assert is_unquote("'Hello world'") == "Hello world"
   assert is_unquote('"Hello world') == '"Hello world'


# Generated at 2022-06-25 01:40:06.223279
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted({}) is False
    assert is_quoted('') is False
    assert is_quoted('""') is False
    assert is_quoted('"') is False
    assert is_quoted('" "') is False
    assert is_quoted('"a"') is True
    assert is_quoted('"a b"') is True
    assert is_quoted('"a "b""') is True
    assert is_quoted('"a""b"') is True
    assert is_quoted('" "') is True
    assert is_quoted('"#"') is True
    assert is_quoted('""a"') is False
    assert is_quoted('""a""') is False
    assert is_quoted('"""a"') is False

# Generated at 2022-06-25 01:40:18.240052
# Unit test for function split_args
def test_split_args():
    test_case_0()



if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-25 01:40:24.771542
# Unit test for function split_args
def test_split_args():
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo bar 'foo bar'") == ["foo", "bar", "'foo bar'"]
    assert split_args("foo bar \"foo bar\"") == ["foo", "bar", "\"foo bar\""]
    assert split_args("foo bar \"foo bar\" 'foo bar'") == ["foo", "bar", "\"foo bar\"", "'foo bar'"]
    assert split_args("foo bar 'foo bar\"") == ["foo", "bar", "'foo bar\""]
    assert split_args("foo bar \"foo bar'") == ["foo", "bar", "\"foo bar'"]
    assert split_args("foo bar \"foo bar\"'") == ["foo", "bar", "\"foo bar\"'"]

# Generated at 2022-06-25 01:40:29.445495
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"there"') == True
    assert is_quoted('"there') == False
    assert is_quoted('there"') == False
    assert is_quoted('there') == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('"""') == False


# Generated at 2022-06-25 01:40:37.199161
# Unit test for function split_args
def test_split_args():
    test_str = '''a b c "a b c" a=1 b="a b" c='a b' a=1 b="a b" c='a b' {% a b %} {# a b #} {{ a b }}'''
    int_0 = split_args(test_str)
    start_time = time.time()
    test_case_0()
    end_time = time.time()
    print("\nTime taken for function split_args: {} seconds".format(end_time - start_time))
    print("\n\nSPLIT ARGS DEMO OUTPUT\n======================\n")
    print("Input string: {}".format(test_str))
    print("\n")
    print("Output: {}".format(int_0))


# Generated at 2022-06-25 01:40:39.869846
# Unit test for function split_args
def test_split_args():
    print("test 0")
    test_case_0()



# Generated at 2022-06-25 01:40:43.120430
# Unit test for function split_args
def test_split_args():
    arg_str = 'a=b c="foo bar"'
    # FIXME: should this be ['a=b', 'c="foo bar"']
    # or should we strip the quotes from args?
    expected_result = [b'a=b', b'c="foo bar"']
    params = split_args(arg_str)
    assert params == expected_result



# Generated at 2022-06-25 01:40:50.173250
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo "bar baz"') == ['foo', 'bar baz']
    assert split_args('foo "bar baz"') == ['foo', 'bar baz']
    assert split_args('foo "bar baz"') == ['foo', 'bar baz']
    assert split_args('foo "bar baz"') == ['foo', 'bar baz']
    assert split_args('foo="bar baz"') == ['foo=bar baz']
    assert split_args("foo='bar baz'") == ['foo=bar baz']
    assert split_args("foo='bar baz'") == ['foo=bar baz']

# Generated at 2022-06-25 01:41:00.457128
# Unit test for function split_args
def test_split_args():
    assert split_args("one") == ["one"]
    assert split_args("one two") == ["one", "two"]
    assert split_args("one 'two three' four") == ["one", "'two three'", "four"]
    assert split_args("one 'two three' 'four five' six") == ["one", "'two three'", "'four five'", "six"]
    assert split_args("one 'two three' 'four five' six") == ["one", "'two three'", "'four five'", "six"]
    assert split_args("'one two' three") == ["'one two'", "three"]
    assert split_args("'one two' \"three four\" five") == ["'one two'", "\"three four\"", "five"]

# Generated at 2022-06-25 01:41:07.029308
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"foobar"') == True
    assert is_quoted("'foobar'") == True
    assert is_quoted('"foobar"') == True
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False
    assert is_quoted("'foo") == False
    assert is_quoted('foo"') == False
    assert is_quoted("foo'") == False
    assert is_quoted('"foo"bar') == False
    assert is_quoted("'foo'bar") == False

# Generated at 2022-06-25 01:41:09.939129
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 01:41:24.500496
# Unit test for function split_args
def test_split_args():
    assert split_args(False) == False
    assert split_args(None) == None
    assert split_args(True) == True
    assert split_args(2621) == 2621
    assert split_args('') == ''
    assert split_args(0) == 0
    assert split_args(2621) == 2621
    assert split_args('') == ''



# Generated at 2022-06-25 01:41:26.488759
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'], "result not as expected"


# Generated at 2022-06-25 01:41:27.110014
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 01:41:28.745969
# Unit test for function split_args
def test_split_args():
    try:
        test_case_0()
    except Exception as e:
        print("Test Case 0 Failed")
        print(e)
        return -1

    return 0


# Generated at 2022-06-25 01:41:38.004693
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar baz" bork') == ['foo', '"bar baz"', 'bork']
    assert split_args("'foo bar' bork") == ["'foo bar'", 'bork']
    assert split_args("foo bar='{{ foo }}'") == ['foo', "bar='{{ foo }}'"]
    assert split_args("foo bar='{{ foo }}' grault") == ['foo', "bar='{{ foo }}'", 'grault']

# Generated at 2022-06-25 01:41:39.461055
# Unit test for function split_args
def test_split_args():
    # Run some tests
    test_case_0()


# Run unit tests
test_split_args()

# Generated at 2022-06-25 01:41:47.628245
# Unit test for function split_args
def test_split_args():
    assert split_args("test") == ["test"]
    assert split_args(" test") == ["test"]
    assert split_args("test ") == ["test"]
    assert split_args("test with spaces") == ["test", "with", "spaces"]
    assert split_args("test with spaces ") == ["test", "with", "spaces"]
    assert split_args(" test with spaces") == ["test", "with", "spaces"]
    assert split_args(" test with spaces ") == ["test", "with", "spaces"]
    assert split_args("test 'with spaces'") == ["test", "'with spaces'"]
    assert split_args("test 'with spaces' ") == ["test", "'with spaces'"]
    assert split_args(" test 'with spaces'") == ["test", "'with spaces'"]

# Generated at 2022-06-25 01:41:57.093260
# Unit test for function split_args
def test_split_args():
    assert len(split_args("foo bar=baz")) == 2
    assert len(split_args("foo bar=baz key='value'")) == 3
    assert len(split_args("foo bar=baz key='value' a=b key2=val")) == 6
    assert len(split_args("foo {{bar}}=baz key='value' a=b {{key2}}=val")) == 6
    assert len(split_args("foo {{bar}}=baz key='value' a=b {{key2}}=val foo2='{{bar}}'")) == 7
    assert len(split_args("foo {%bar%}=baz key='{%value%}' a=b {%key2%}=val foo2='{%bar%}'")) == 7

# Generated at 2022-06-25 01:42:02.591422
# Unit test for function split_args
def test_split_args():
    # tests are the same as in action plugins
    test_case_0()
    print("Unit test for function 'split_args' in utils.py. Completed successfully!")


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:42:05.797986
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:42:24.620833
# Unit test for function split_args
def test_split_args():
    args = """a=b c="foo bar" d='foo bar'"""
    assert split_args(args) == ['a=b', 'c="foo bar"', "d='foo bar'"]
    assert split_args(args.replace(' ', '\n')) == ['a=b\nc="foo bar"\nd=\'foo bar\'']


# Generated at 2022-06-25 01:42:29.746615
# Unit test for function split_args
def test_split_args():
    cli_args = "a=b c=\"foo bar\""
    # expected result
    expected = ['a=b', 'c=\"foo bar\"']
    actual = split_args(cli_args)
    if actual != expected:
        print("actual:")
        print(actual)
        raise Exception("test_case_0 failed")
    print("test_case_0 passed")



# Generated at 2022-06-25 01:42:36.114326
# Unit test for function split_args
def test_split_args():

    # Split args
    # Split args (case 1)
    params = split_args('a=b c="foo bar"')
    params = split_args('-c config/file/path')
    params = split_args('str1 str2')
    params = split_args('str1="str 2"')
    params = split_args('str1=str2 str3=str4')


# Execution as a script
if __name__ == '__main__':
    test_split_args()
    test_case_0()

# Generated at 2022-06-25 01:42:44.540430
# Unit test for function split_args

# Generated at 2022-06-25 01:42:46.458272
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 01:42:52.233480
# Unit test for function split_args
def test_split_args():

    args = "ansible all -a '/usr/bin/foo \"bar baz\"'"
    # expected output: ['ansible', 'all', '-a', '/usr/bin/foo "bar baz"']
    params = split_args(args)

    assert len(params) == 4
    assert params[0] == 'ansible'
    assert params[1] == 'all'
    assert params[2] == '-a'
    assert params[3] == '/usr/bin/foo "bar baz"'

    args = 'ansible all -a "arg with spaces" -i inventory -u myuser --private-key=/path/to/file --list-hosts'
    # expected output: ['ansible', 'all', '-a', 'arg with spaces', '-i', 'inventory', '-u', 'myuser', '

# Generated at 2022-06-25 01:43:01.499637
# Unit test for function split_args
def test_split_args():
    res = split_args(" key1=value1  key2=value2")
    assert(res == ['key1=value1', 'key2=value2'])
    res = split_args("-a foo -b 'bar lamb' -c")
    assert(res == ['-a', 'foo', '-b', "'bar lamb'", '-c'])
    res = split_args("-a foo -b \"bar lamb\" -c")
    assert(res == ['-a', 'foo', '-b', '"bar lamb"', '-c'])
    res = split_args("-a foo -b \"bar lamb\" -c '{\"foo\": \"bar\"}'")

# Generated at 2022-06-25 01:43:10.942833
# Unit test for function split_args
def test_split_args():

    # Test 0
    test0_args = '''
    foo="some long string"
    bar=42 random=stuff \\
    baz="a test"
    '''

    test0_params = ['foo="some long string"', 'bar=42', 'random=stuff baz="a test"']

    test0_params_split = split_args(test0_args)

    if test0_params_split != test0_params:
        print(test0_params_split)
        test_case_0()

    # Test 1
    test1_args = '''
    foo={{ ansible_eth0.ipv4.address }}
    bar=42 random=stuff \\
    baz="a test"
    '''


# Generated at 2022-06-25 01:43:20.854403
# Unit test for function split_args
def test_split_args():
    test_cases = []
    test_cases.append(("a=b c='foo bar'", ['a=b', "c='foo bar'"]))
    test_cases.append(("a=b c=\"foo bar\"", ['a=b', "c=\"foo bar\""]))
    test_cases.append(("a=b c='foo bar' d=\"foo bar\"", ['a=b', "c='foo bar'", 'd="foo bar"']))
    test_cases.append(("a=b c=\"foo bar\" d='foo bar'", ['a=b', "c=\"foo bar\"", "d='foo bar'"]))
    test_cases.append(("a=b c=\"foo bar\" d=\"foo bar\"", ['a=b', "c=\"foo bar\"", 'd="foo bar"']))
   

# Generated at 2022-06-25 01:43:28.464713
# Unit test for function split_args

# Generated at 2022-06-25 01:44:03.387839
# Unit test for function split_args
def test_split_args():
    # An example of how args are split and re-joined correctly by this function,
    # and the resulting params list is identical to the original args
    print("===== test_split_args =====")
    example_args = "ansible -m ping -i hosts myhost --extra-vars 'foo={{ bar }} and baz={{ bam }}' -u myuser"
    params = split_args(example_args)
    print(params)
    print("")

    # An example of how args are split and re-joined correctly by this function,
    # and the resulting params list is identical to the original args
    print("===== test_split_args =====")

# Generated at 2022-06-25 01:44:12.138111
# Unit test for function split_args
def test_split_args():
    params = split_args("-XX:+UseG1GC -XX:MaxGCPauseMillis=200 -Xms256M -Xmx2G -Dfile.encoding=UTF-8")
    assert params[0] == "-XX:+UseG1GC"
    assert params[1] == "-XX:MaxGCPauseMillis=200"
    assert params[2] == "-Xms256M"
    assert params[3] == "-Xmx2G"
    assert params[4] == "-Dfile.encoding=UTF-8"

# Generated at 2022-06-25 01:44:16.751668
# Unit test for function split_args
def test_split_args():
    # test "desired output" strings
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = 'a=b'
    str_5 = 'c="foo bar"'
    str_6 = 'd="foo bar" e=b'

    # test "input" strings
    str_7 = 'a=b'
    str_8 = 'c="foo bar"'
    str_9 = 'd="foo bar" e=b'
    str_10 = 'd="foo\nbar" e=b'
    str_11 = 'a=b c="foo bar"'
    str_12 = 'a "b" c=\'d e\' f=\'g h\' i=j'

    # tests
    # test empty non-space string

# Generated at 2022-06-25 01:44:23.083364
# Unit test for function split_args
def test_split_args():
    try:
        ans = split_args("")
        assert(ans == [])
    except:
        test_case_0()
    try:
        ans = split_args("foo")
        assert(ans == ['foo'])
    except:
        test_case_0()
    try:
        ans = split_args("foo bar")
        assert(ans == ['foo', 'bar'])
    except:
        test_case_0()
    try:
        ans = split_args("foo bar baz")
        assert(ans == ['foo', 'bar', 'baz'])
    except:
        test_case_0()
    try:
        ans = split_args("foo{#bar}baz")
        assert(ans == ['foo{#bar}baz'])
    except:
        test_case

# Generated at 2022-06-25 01:44:30.802118
# Unit test for function split_args
def test_split_args():
    # Test if splitting simple args
    test_string_0 = "a=b c=\"foo bar\""
    test_result_0 = split_args(test_string_0)
    assert test_result_0 == ['a=b', 'c="foo bar"']

    # Test if splitting args which contains {{}}
    test_string_1 = "a={{var}}"
    test_result_1 = split_args(test_string_1)
    assert test_result_1 == ['a={{var}}']

    # Test if splitting args which contains {%%}
    test_string_2 = "a={%var%}"
    test_result_2 = split_args(test_string_2)
    assert test_result_2 == ['a={%var%}']

    # Test if splitting args which contains {##}


# Generated at 2022-06-25 01:44:37.443023
# Unit test for function split_args
def test_split_args():
    global temp_quote_char, temp_inside_quotes, temp_print_depth, temp_block_depth, temp_comment_depth
    global temp_appended, temp_was_inside_quotes
    temp_quote_char = None
    temp_inside_quotes = False
    temp_print_depth = 0
    temp_block_depth = 0
    temp_comment_depth = 0
    temp_appended = False
    temp_was_inside_quotes = False

    global temp_line_continuation
    temp_line_continuation = False

    # Example 1
    temp_inside_quotes = False
    temp_quote_char = None
    temp_params = []
    temp_idx = 0
    temp_token = "a=b"
    temp_appended = False

    # if we're inside quotes

# Generated at 2022-06-25 01:44:40.194260
# Unit test for function split_args
def test_split_args():
    test_str = "a=b c=\"foo bar\""
    test_result = ['a=b', 'c="foo bar"']
    assert(split_args(test_str) == test_result)

# Generated at 2022-06-25 01:44:41.699279
# Unit test for function split_args
def test_split_args():
    assert( split_args("a=b c='foo bar'") == [ 'a=b', "c='foo bar'" ] )

if __name__ == '__main__':

    test_split_args()

# Generated at 2022-06-25 01:44:48.259787
# Unit test for function split_args
def test_split_args():
    s = "ls -l foo"
    result = split_args(s)
    assert(result[0] == "ls") and (result[1] == "-l") and (result[2] == "foo")

    s = "ls -l \"foo bar\""
    result = split_args(s)
    assert(result[0] == "ls") and (result[1] == "-l") and (result[2] == "foo bar")

    s = "ls -l 'foo bar'"
    result = split_args(s)
    assert(result[0] == "ls") and (result[1] == "-l") and (result[2] == "foo bar")

    s = "ls -l 'foo bar\"'"
    result = split_args(s)

# Generated at 2022-06-25 01:44:53.207413
# Unit test for function split_args
def test_split_args():
    print("Running array_from_string tests")
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:46:20.141413
# Unit test for function split_args

# Generated at 2022-06-25 01:46:29.081012
# Unit test for function split_args
def test_split_args():
    string_0 = "param1 param2='asd' param3=1 param4=2 param5='a b c'"
    list_0 = split_args(string_0)
    assert list_0 == ['param1', 'param2=\'asd\'', 'param3=1', 'param4=2', 'param5=\'a b c\'']

    string_1 = "param1 param2='asd' param3=1 param4=2 param5='a b c"
    try:
        split_args(string_1)
    except Exception as exception_0:
        print(exception_0)
        int_0 = 1
    else:
        int_0 = 0
    assert int_0 == 1


# Generated at 2022-06-25 01:46:33.010696
# Unit test for function split_args
def test_split_args():
    assert (split_args('a=b') == ['a=b'])
    assert (split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'])
    assert (split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""'])
    assert (split_args('a=b c="{{ foo }} bar"') == ['a=b', 'c="{{ foo }} bar"'])
    assert (split_args('a=b c="{{ foo }} \\"bar\\""') == ['a=b', 'c="{{ foo }} \\"bar\\""'])
    assert (split_args('a=b c="{{ foo }}\nbar"') == ['a=b', 'c="{{ foo }}\nbar"'])


# Generated at 2022-06-25 01:46:43.061362
# Unit test for function split_args
def test_split_args():
    assert split_args("  a=b  c='foo bar' ") == ['a=b', "c='foo bar'"]
    assert split_args('a=b "c=1 2 3"') == ['a=b', '"c=1 2 3"']
    assert split_args('"a=1 2" c="foo bar"') == ["a=1 2", 'c="foo bar"']
    assert split_args('  "a=1 2" c="foo bar"  ') == ["a=1 2", 'c="foo bar"']
    assert split_args('  a=b  c="foo bar"  d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']

# Generated at 2022-06-25 01:46:53.208581
# Unit test for function split_args
def test_split_args():
    assert split_args("-a") == ['-a']
    assert split_args("-a -b") == ['-a', '-b']
    assert split_args("-a -b -c") == ['-a', '-b', '-c']
    assert split_args("-a -b -c d") == ['-a', '-b', '-c', 'd']
    assert split_args("-a -a -a d") == ['-a', '-a', '-a', 'd']
    assert split_args("-a -a -a -b") == ['-a', '-a', '-a', '-b']
    assert split_args("-a -b c -c d") == ['-a', '-b', 'c', '-c', 'd']

# Generated at 2022-06-25 01:46:59.787574
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    print(split_args(args))
    args = 'a=b\\\nc="foo bar"'
    print(split_args(args))
    args = 'a=b c="foo\\\nbar"'
    print(split_args(args))
    args = 'a=b c="foo\\\nbar\\\n"'
    print(split_args(args))
    args = 'a=b c="foo\\\nbar" \\\nd=foo'
    print(split_args(args))
    args = 'a=b c="foo\\\nbar" \\\nd=foo\\\n'
    print(split_args(args))
    args = 'a=b c="foo\\\nbar" \\\nd=\nfoo'

# Generated at 2022-06-25 01:47:08.990376
# Unit test for function split_args
def test_split_args():
    #assert split_args("a=b c=d") == [ "a=b", "c=d" ]
    assert split_args("a=b c=\"foo bar\"") == [ "a=b", "c=\"foo bar\"" ]
    assert split_args("a=b c=\"foo bar\" d={{foobar}}") == [ "a=b", "c=\"foo bar\"", "d={{foobar}}" ]
    assert split_args("a=b c=\"foo bar\" d={{foobar}} e={% if foobar %} f=g {% endif %}") == [ "a=b", "c=\"foo bar\"", "d={{foobar}}", "e={% if foobar %}", "f=g", "{% endif %}" ]

# Generated at 2022-06-25 01:47:14.006807
# Unit test for function split_args
def test_split_args():

    # This function tests split_args to see if the correct number of variables
    # were detected in the input string.  This helps ensure the correct number
    # of variables are parsed by the module when arguments are given.
    #
    # Reference: https://stackoverflow.com/questions/1267869/how-can-i-check-if-a-list-is-partially-sorted-i-e-consecutive-elements-are-in
    #
    # The following tests each type of argument in the file

    # Test for single argument, no white space
    arg_string = 'Path=/usr/bin'
    params_list = split_args(arg_string)
    assert(len(params_list) == 1)

    # Test for no arguments
    arg_string = ''

# Generated at 2022-06-25 01:47:21.057834
# Unit test for function split_args
def test_split_args():
    args = "  a=b  c='foo bar' \"foo bar\"  \"a='b c'\""
    res = split_args(args)
    assert len(res) == 4
    assert res[0] == 'a=b'
    assert res[1] == "c='foo bar'"
    assert res[2] == '"foo bar"'
    assert res[3] == '"a=\'b c\'"'
    print("test_case_0 pass.")


# Generated at 2022-06-25 01:47:29.116987
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    assert split_args("foo \"bar\"") == ["foo", "\"bar\""]
    assert split_args("foo \"bar\" baz") == ["foo", "\"bar\"", "baz"]
    assert split_args("\"abc\"") == ["\"abc\""]
    assert split_args("a=\"bc\"") == ["a=\"bc\""]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("foo {%bar%}") == ["foo", "{%bar%}"]
    assert split