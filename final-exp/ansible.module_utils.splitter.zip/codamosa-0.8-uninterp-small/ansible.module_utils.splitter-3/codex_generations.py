

# Generated at 2022-06-25 01:39:11.694875
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"") == True
    assert is_quoted("\'") == True
    assert is_quoted("") == False
    assert is_quoted("\"\"") == True
    assert is_quoted("\'\'") == True
    assert is_quoted("\'\"") == False
    assert is_quoted("\'") == True
    assert is_quoted("\'\'\'") == True
    assert is_quoted("\'\'\'\'") == False
    assert is_quoted("\'\'\'\'\'") == True
    assert is_quoted("\"\"\"\"\"") == True
    assert is_quoted("\"\"\"\"") == False
    assert is_quoted("\"\"\"") == True
    assert is_quoted("\"\"") == True

# Generated at 2022-06-25 01:39:23.409542
# Unit test for function split_args
def test_split_args():
    result = split_args("a=b c='d e'")
    assert result == ["a=b", "c='d e'"]
    result = split_args('a=b c="d e"')
    assert result == ['a=b', 'c="d e"']
    result = split_args("a=b c=\"d e\"")
    assert result == ['a=b', 'c="d e"']
    result = split_args('a=b c="d e" f=')
    assert result == ['a=b', 'c="d e"', 'f=']
    try:
        result = split_args("a=b c='d e")
    except Exception:
        pass
    else:
        raise Exception("Bad quotes did not throw an exception")

# Generated at 2022-06-25 01:39:32.691096
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b 'c=\"foo bar\"'") == ['a=b', 'c=\"foo bar\"']
    assert split_args("a=b c={{ foo }}") == ['a=b', 'c={{ foo }}']
    assert split_args("a=b c={{ foo }} d={{ bar }}") == ['a=b', 'c={{ foo }}', 'd={{ bar }}']
    assert split_args("a=b c={{ foo }} d={% bar %}") == ['a=b', 'c={{ foo }}', 'd={% bar %}']

# Generated at 2022-06-25 01:39:43.109114
# Unit test for function split_args
def test_split_args():

    # Unit Tests with good examples
    template_vars = []
    # Each element of template_vars is a list of two elements.
    #   The first element is a string containing all the arguments
    #     for a single split_args call.
    #   The second element is a list of strings containing the expected
    #     results of the single split_args call.

    # Test 0 - No Arguments
    template_vars.append([
        "",
        []
    ])

    # Test 1 - A single (unquoted) argument
    template_vars.append([
        "arg1",
        ["arg1"]
    ])

    # Test 2 - Two unquoted arguments
    template_vars.append([
        "arg1 arg2",
        ["arg1", "arg2"]
    ])

    # Test 3 -

# Generated at 2022-06-25 01:39:52.516032
# Unit test for function split_args
def test_split_args():
    """Tests split_args function (and related functions)"""
    # Test cases
    test_case_0()
    test_case_1()
    # Test case str_0
    str_0 = """
        this is     a  simple
        test of
        jinja2 syntax{#
        comments
        #}{{
        variables
        }}\n\n
        {%
        logic
        %}with a
        few
        spaces
    """
    param_0 = [
        'this',
        'is',
        'a',
        'simple',
        'test',
        'of',
        'jinja2',
        'syntax',
        '{{ variables }}',
        '']

# Generated at 2022-06-25 01:40:00.714342
# Unit test for function split_args
def test_split_args():
    # Test case 0
    float_0 = -433.64804
    var_0 = is_quoted(float_0)

    # Test case 1
    str_0 = "{{ foo }}"
    var_1 = split_args(str_0)
    print("var_1=", var_1)
    assert var_1[0] == str_0
    assert len(var_1) == 1


main_func_list = [test_split_args]


if __name__ == "__main__":
    for func in main_func_list:
        func()

# Generated at 2022-06-25 01:40:07.783705
# Unit test for function split_args
def test_split_args():

    # testing for quote
    #
    # test for single word
    assert split_args('foo') == ['foo']
    # test for multiple words
    assert split_args('foo bar') == ['foo', 'bar']
    # test for multiple words with quotes
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    # test for multiple words, with quotes, with escape characters
    assert split_args(r'foo "bar \"baz\""') == [r'foo', r'"bar \"baz\""']
    # test for multiple words with single quotes
    assert split_args("foo 'bar baz'") == ['foo', r"'bar baz'"]
    # test for multiple words, with single quotes, with escape characters

# Generated at 2022-06-25 01:40:17.414697
# Unit test for function split_args
def test_split_args():

    assert split_args("foo\nbar\tbaz") == ["foo", "bar", "baz"]
    assert split_args("foo") == ["foo"]
    assert split_args("'foo bar'") == ["'foo bar'"]
    assert split_args('"foo bar"') == ['"foo bar"']
    assert split_args('foo "bar baz"') == ["foo", '"bar baz"']
    assert split_args('foo "bar\nbaz"') == ["foo", '"bar\nbaz"']
    assert split_args('foo "bar\nbaz" lorem ipsum') == ["foo", '"bar\nbaz"', "lorem", "ipsum"]

# Generated at 2022-06-25 01:40:22.527003
# Unit test for function split_args
def test_split_args():
    # Unit test for function split_args without parameter `args`
    args = None
    try:
        split_args(args)
    except Exception as e:
        if "the 'args' parameter is required" in str(e):
            print("Expected failure due to missing parameter `args`")
        else:
            raise e
    else:
        assert False, "Expected failure due to missing parameter `args`"


if __name__ == "__main__":
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:40:33.442980
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    res = split_args(args)
    assert res == ['a=b', 'c="foo bar"']

    args = "a=b c='foo bar'"
    res = split_args(args)
    assert res == ["a=b", "c='foo bar'"]

    args = "a=b c='foo bar'"
    res = split_args(args)
    assert res == ["a=b", "c='foo bar'"]

    args = "a=b c=foo\nbar"
    res = split_args(args)
    assert res == ["a=b", "c=foo\nbar"]
    args = "a=b c=foo\nbar"
    res = split_args(args)

# Generated at 2022-06-25 01:40:51.170071
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b 'c d'") == ['a=b', "'c d'"]
    assert split_args("a={{b}} 'c d' foo='bar baz'") == ['a={{b}}', "'c", 'd\'', 'foo=\'bar baz\'']


# Generated at 2022-06-25 01:40:57.098118
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert(len(params) == 2)
    assert(params[0] == 'a=b')
    assert(params[1] == 'c="foo bar"')



# Generated at 2022-06-25 01:41:06.182686
# Unit test for function split_args

# Generated at 2022-06-25 01:41:16.965810
# Unit test for function split_args
def test_split_args():
    # Check if arg1 is required
    assert split_args.func_code.co_argcount == 1

    params = split_args('/bin/foo --bar="baz zzz" /tmp/file1.txt file3.txt')
    assert params == ['/bin/foo', '--bar=baz zzz', '/tmp/file1.txt', 'file3.txt']

    params = split_args('/bin/foo --bar="baz zzz" "/tmp/file1.txt" file3.txt')
    assert params == ['/bin/foo', '--bar=baz zzz', '/tmp/file1.txt', 'file3.txt']

    params = split_args('/bin/foo --bar="baz zzz" \'file1.txt\' file3.txt')

# Generated at 2022-06-25 01:41:25.611276
# Unit test for function split_args
def test_split_args():
    a = """a=1 b={{c}} c="foo bar"
    """
    params = split_args(a)
    assert params == ['a=1', 'b={{c}}', 'c="foo bar"']

    a = """a=1 b={{c}} c="foo bar" d='bar'
    """
    params = split_args(a)
    assert params == ['a=1', 'b={{c}}', 'c="foo bar"', "d='bar'"]

    a = """a=1 b={{c}} c=\\
    "foo bar" d='bar'
    """
    params = split_args(a)
    assert params == ['a=1', 'b={{c}}', 'c="foo', 'bar"', "d='bar'"]


# Generated at 2022-06-25 01:41:31.588191
# Unit test for function split_args
def test_split_args():

    # Test case with normal arguments
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]

    # Test case with no arguments
    assert split_args("") == []

    # Test case with jinja2 {% %} blocks
    assert split_args("a={{b}} c={{d}}") == ['a={{b}}', "c={{d}}"]

    # Test case with jinja2 {{ }} blocks
    assert split_args("a={%b%} c={%d%}") == ['a={%b%}', "c={%d%}"]

    # Test case with jinja2 {# #} blocks

# Generated at 2022-06-25 01:41:33.788757
# Unit test for function split_args
def test_split_args():
    # Split args using a string as input
    assert split_args('foo bar') == ['foo', 'bar']

# Generated at 2022-06-25 01:41:42.307848
# Unit test for function split_args
def test_split_args():
    if not hasattr(test_split_args, "argv"):
        test_split_args.argv = []

# Generated at 2022-06-25 01:41:49.932298
# Unit test for function split_args
def test_split_args():
    string_0 = "ansible_python_interpreter='/usr/bin/python3'"
    string_1 = "ansible_python_interpreter='/usr/bin/python3' ansible_user=jeff"
    string_2 = "ansible_python_interpreter='/usr/bin/python3'\nansible_user=jeff"
    string_3 = "mytest_test='testme'"
    string_4 = "priv=!vault | $ANSIBLE_VAULT; id=1010"
    string_5 = 'async: 3600 poll: 0 become: yes become_method: sudo become_user: root vars:'
    string_6 = '1st flush_handlers'
    string_7 = 'flush_handlers 2nd'

# Generated at 2022-06-25 01:41:54.129842
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 01:42:14.776215
# Unit test for function split_args
def test_split_args():
    a = 'a=b c="foo bar" d="foo\nbar"'
    b = split_args(a)
    assert b[0] == 'a=b'
    assert b[1] == 'c="foo bar"'
    assert b[2] == 'd="foo\nbar"'

    a = """a=b c='foo bar' d="foo\nbar" """
    b = split_args(a)
    assert b[0] == 'a=b'
    assert b[1] == "c='foo bar'"
    assert b[2] == 'd="foo\nbar"'

    a = 'a=b c="foo bar" d="foo\n{{ d }}"'
    b = split_args(a)
    assert b[0] == 'a=b'

# Generated at 2022-06-25 01:42:16.954344
# Unit test for function split_args
def test_split_args():
    p_list = split_args("git repo='foo'")
    assert len(p_list) == 2
    assert p_list[0] == "git"
    assert p_list[1] == "repo='foo'"

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:42:27.989962
# Unit test for function split_args
def test_split_args():
    # Initialize test fixture data
    value_0 = "foo=\"bar'baz\""
    value_1 = "{# foo #}=bar"
    value_2 = "{{ foo }}=bar"
    value_3 = '{% if foo %}=bar'

    # Test normal case
    result_0 = split_args(value_0)
    assert result_0 == ['foo="bar\'baz"'], "Expected output not received"

    result_1 = split_args(value_1)
    assert result_1 == ['{# foo #}=bar'], "Expected output not received"

    result_2 = split_args(value_2)
    assert result_2 == ['{{ foo }}=bar'], "Expected output not received"

    result_3 = split_args(value_3)

# Generated at 2022-06-25 01:42:38.607974
# Unit test for function split_args
def test_split_args():
    import sys
    import inspect
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule

    # Mock the module
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True
            sys.exit()

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            sys.exit()

    # Mock basic.AnsibleModule
    class AnsibleModuleMock(object):
        def __new__(cls, *args, **kwargs):
            o = MockModule(**kwargs)
            o.params = kwargs

# Generated at 2022-06-25 01:42:47.125018
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="foo bar"') == ['a="foo bar"']
    assert split_args('a="foo bar" b="{{ my_regexp }}" c="{% endraw %}%} endraw"') == ['a="foo bar"', 'b="{{ my_regexp }}"', 'c="{% endraw %}%} endraw"']


# Generated at 2022-06-25 01:42:55.702026
# Unit test for function split_args
def test_split_args():
    source = '''
        foo a=b c="foo bar" d={{an_inventory_variable}} e="abc {{ 123 }} def"
        foo a=b c="foo bar" d={{ an_inventory_variable }} e="abc {{ 123 }} def"
        foo a=b c="foo bar" d={{ an_inventory_variable }} e="abc {{ 123 }} def"
    '''

# Generated at 2022-06-25 01:43:01.717392
# Unit test for function split_args
def test_split_args():
    data = '''a=b c="foo bar" "foo bar"'''
    result = split_args(data)
    assert result == ['a=b', 'c="foo bar"', '"foo bar"']



# Generated at 2022-06-25 01:43:09.414539
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar" d=\'{"a": "b", "c": "d"}\''
    expected = ['a=b', 'c="foo bar"', 'd=\'{"a": "b", "c": "d"}\'']
    actual = split_args(args)
    if actual != expected:
        raise Exception("expected %s != %s" % (expected, actual))

# test the above code
if __name__ == '__main__':
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:43:16.729858
# Unit test for function split_args

# Generated at 2022-06-25 01:43:27.562215
# Unit test for function split_args
def test_split_args():
    f = split_args
    assert f("") == []
    assert f("a") == ['a']
    assert f("foo 'bar'") == ["foo", "'bar'"]
    assert f("foo 'bar baz'") == ["foo", "'bar baz'"]
    assert f('foo "bar baz"') == ["foo", '"bar baz"']
    assert f('foo "bar \' baz"') == ["foo", '"bar \' baz"']
    assert f('foo "bar \' baz"') == ["foo", '"bar \' baz"']
    assert f('foo "bar \' baz \\\" "') == ["foo", '"bar \' baz \\\" "']

# Generated at 2022-06-25 01:43:49.293093
# Unit test for function split_args
def test_split_args():
    # Set up test variables
    some_string = 'a=b c="foo bar"'
    expected_return_value = ['a=b', 'c="foo bar"']

    # Call split_args
    returned_value = split_args(some_string)

    # Is the returned_value equal to the expected return value?
    assert returned_value == expected_return_value


# Generated at 2022-06-25 01:43:59.465176
# Unit test for function split_args
def test_split_args():
    float0 = 1327.8485903469368
    var0 = split_args(float0)
    assert var0 == [
            '1327.8485903469368'
        ], 'incorrect results for split_args(): %s' % var0
    float1 = 100.24104369965119
    var1 = split_args(float1)
    assert var1 == [
            '100.24104369965119'
        ], 'incorrect results for split_args(): %s' % var1
    float2 = 20.893621407176985
    var2 = split_args(float2)
    assert var2 == [
            '20.893621407176985'
        ], 'incorrect results for split_args(): %s' % var2
    float3 = -10.0


# Generated at 2022-06-25 01:44:07.762258
# Unit test for function split_args
def test_split_args():
    data = '''
- name: Test with loops
  vars:
    ntp_config_entries:
      - key: "server {{ ntp_server }}"
        value: "{{ ntp_server }}"
  with_items: "{{ ntp_servers_list }}"
  when: ntp_server != ''
'''

    data2 = '''
---
- name: Test with loops
  vars:
    ntp_config_entries:
      - key: "server {{    ntp_server }}"
        value: "{{ ntp_server }}"
  with_items: "{{ ntp_servers_list }}"
  when: ntp_server != ''
'''


# Generated at 2022-06-25 01:44:10.052864
# Unit test for function split_args
def test_split_args():
    try:
        test_case_0()
    except Exception as e:
        print("Failed test case: {}, {}".format(e, split_args))

test_split_args()

# Generated at 2022-06-25 01:44:20.177191
# Unit test for function split_args
def test_split_args():
    # Test case 0
    #// Build the list of args to use
    float_0 = 1327.8485903469368
    var_0 = split_args(float_0)
    #// Check results
    assert var_0[0] == '1327.8485903469368'
    # Test case 1
    #// Build the list of args to use
    float_0 = 1664.83022604592
    var_0 = split_args(float_0)
    #// Check results
    assert var_0[0] == '1664.83022604592'
    # Test case 2
    #// Build the list of args to use
    float_0 = 1858.8915169527926
    var_0 = split_args(float_0)
    #// Check results
    assert var

# Generated at 2022-06-25 01:44:30.516999
# Unit test for function split_args
def test_split_args():
    print("in test_split_args")
    a = split_args("a=b c=\"d e\"")
    assert a[0] == 'a=b'
    assert a[1] == 'c="d e"'

    a = split_args("a=b 'c d'")
    assert a[0] == 'a=b'
    assert a[1] == "'c d'"

    a = split_args("a=b c='d e'")
    assert a[0] == 'a=b'
    assert a[1] == "c='d e'"

    a = split_args("a=b c=\"'d e'\"")
    assert a[0] == 'a=b'
    assert a[1] == "c=\"'d e'\""


# Generated at 2022-06-25 01:44:37.065485
# Unit test for function split_args
def test_split_args():
    print(split_args('a=b c="foo bar"'))
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', 'c=\'foo bar\'']
    assert split_args("a=b c=\"{{foo}}\"") == ['a=b', 'c="{{foo}}"']
    assert split_args("a=b c=\"{{foo}}\" d=\"{{bar}}\"") == ['a=b', 'c="{{foo}}"', 'd="{{bar}}"']
    assert split_args("a=b c=\"{{foo}} bar\"")

# Generated at 2022-06-25 01:44:39.345249
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Standard call to the main() function.
if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:44:46.026722
# Unit test for function split_args
def test_split_args():
    result = split_args("bar")
    assert result == ["bar"], "split_args(\"bar\") returned %s instead of \"bar\"" % result

    result = split_args("foo bar baz")
    assert result == ["foo", "bar", "baz"], "split_args(\"foo bar baz\") returned %s instead of \"foo bar baz\"" % result

    result = split_args("foo 'bar baz'")
    assert result == ["foo", "'bar baz'"], "split_args(\"foo 'bar baz'\") returned %s instead of \"foo 'bar baz'\"" % result

    result = split_args("foo\nbar\nbaz")

# Generated at 2022-06-25 01:44:55.592886
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo="bar baz"') == ['foo=bar baz']
    assert split_args('foo="bar baz" bar="bam baz"') == ['foo=bar baz', 'bar=bam baz']
    assert split_args('foo="bar baz" bar=bam baz') == ['foo=bar baz', 'bar=bam', 'baz']
    assert split_args('foo="bar baz" bar=bam baz foo="bar bam"') == ['foo=bar baz', 'bar=bam', 'baz', 'foo=bar bam']

# Generated at 2022-06-25 01:45:43.772675
# Unit test for function split_args
def test_split_args():
    assert split_args("foobar") == ["foobar"]
    assert split_args("foo 'bar'") == ["foo", "'bar'"]
    assert split_args("foo \"bar\"") == ["foo", "\"bar\""]
    assert split_args("foo '''bar'''") == ["foo", "'''bar'''"]
    assert split_args("foo \"\"\"bar\"\"\"") == ["foo", "\"\"\"bar\"\"\""]
    assert split_args("foo \"bar' baz\"") == ["foo", "\"bar' baz\""]
    assert split_args("foo 'bar\" baz'") == ["foo", "'bar\" baz'"]
    assert split_args("foo 'bar\" ' baz'") == ["foo", "'bar\" ' baz'"]

# Generated at 2022-06-25 01:45:48.684748
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=\"b c\"") == ['a="b c"']
    assert split_args("a='b c'") == ["a='b c'"]
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b \"foo bar\"") == ['a=b', '"foo bar"']
    assert split_args("a=b 'foo bar'") == ['a=b', "'foo bar'"]
    assert split_args("foo bar") == ['foo', 'bar']
    assert split_args("foo= \"bar\"") == ['foo=', '"bar"']

# Generated at 2022-06-25 01:45:57.727274
# Unit test for function split_args

# Generated at 2022-06-25 01:46:04.065272
# Unit test for function split_args
def test_split_args():
    # First we'll use a literal value for the args, the double quotes should be removed automatically
    var_1 = '-m "foo bar"'
    var_2 = split_args(var_1)
    assert var_2 == ['-m', 'foo bar'], "Failed to parse args, got {0} instead of {1}".format(var_2, ['-m', 'foo bar'])

    # This is a simple arg string with a jinja2 block, spaces should be preserved
    var_1 = '"a1" b="{{ foo }}" c=d'
    var_2 = split_args(var_1)

# Generated at 2022-06-25 01:46:12.462275
# Unit test for function split_args
def test_split_args():

    # Get all of the parameters for the module
    arg_spec = inspect.getargspec(split_args)
    arg_names = arg_spec[0]
    arg_values = arg_spec[3]

    # Re-initialize all of the parameters
    for index, arg_name in enumerate(arg_names):
        param_name = 'param_' + arg_name
        if arg_values[index] is not None:
            if isinstance(arg_values[index], str):
                exec(param_name + '=\'' + arg_values[index] + '\'')
            elif isinstance(arg_values[index], int):
                exec(param_name + '=' + str(arg_values[index]))

# Generated at 2022-06-25 01:46:19.855359
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=b c=\"foo bar\"") == [u"a=b", u"c=\"foo bar\""]
    assert split_args(u"a=b c=\"foo bar\" d='foo bar'") == [u"a=b", u"c=\"foo bar\"", u"d='foo bar'"]
    assert split_args(u"a=b c=\"foo bar\" d='foo bar' e=\"{{ foo }}\"") == [u"a=b", u"c=\"foo bar\"", u"d='foo bar'", u"e=\"{{ foo }}\""]

# Generated at 2022-06-25 01:46:24.534657
# Unit test for function split_args
def test_split_args():
    #doctest.testmod()
    test_case_0()
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 01:46:28.141215
# Unit test for function split_args
def test_split_args():
    float_0 = 1327.8485903469368
    var_0 = split_args(float_0)
    assert var_0 == 1327.8485903469368

# Generated at 2022-06-25 01:46:33.728999
# Unit test for function split_args
def test_split_args():
    
    float_0 = 1327.8485903469368
    var_0 = split_args(float_0)
    assert var_0[0] == '1327.8485903469368'
    assert len(var_0) == 1
    
    float_1 = 1703.3100461270953
    var_1 = split_args(float_1)
    assert var_1[0] == '1703.3100461270953'
    assert len(var_1) == 1
    
    float_2 = 1176.8517396706743
    var_2 = split_args(float_2)
    assert var_2[0] == '1176.8517396706743'
    assert len(var_2) == 1
    
    float_3 = 462.

# Generated at 2022-06-25 01:46:34.920414
# Unit test for function split_args
def test_split_args():
    # print(split_args("--foo \"bar baz\""))
    test_case_0()



# Generated at 2022-06-25 01:47:44.220059
# Unit test for function split_args
def test_split_args():
    assert split_args("foo bar baz") == ['foo', 'bar', 'baz']
    assert split_args("var1=val1 var2=val2") == ['var1=val1', 'var2=val2']
    assert split_args("var1='foo bar'") == ["var1='foo bar'"]
    assert split_args("foo='bar baz'") == ["foo='bar baz'"]
    assert split_args("var1='foo bar' var2=val2") == ["var1='foo bar'", 'var2=val2']
    assert split_args("var1=val1 var2='foo bar'") == ['var1=val1', "var2='foo bar'"]

# Generated at 2022-06-25 01:47:51.198108
# Unit test for function split_args
def test_split_args():
    # empty list as source
    assert split_args("") == []
    # quoted strings
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    # jinja2 variables
    assert split_args("a=1 b={{ c }} d={{ e.f.g }}") == ['a=1', 'b={{ c }}', 'd={{ e.f.g }}']
    # long string
    long_string = """a b \"c d\" 'e f' g {{ h }} i {{ j.k.l }} m {{ n.o.p }} q.r s.t.u v=1 w=2 x=\"y z\""""

# Generated at 2022-06-25 01:48:01.200570
# Unit test for function split_args
def test_split_args():
    a_8 = [ 'a b', 'c d e f g' ]
    var_4 = split_args(a_8)
    var_4 = split_args('')
    a_8 = [ 'a', 'b', 'c', 'd', 'e f' ]
    var_4 = split_args(a_8)
    a_8 = [ 'a', 'b', 'c', 'd', 'e', 'f' ]
    var_4 = split_args(a_8)
    a_8 = [ 'a b', 'c', 'd', 'e f' ]
    var_4 = split_args(a_8)
    a_8 = [ 'a', 'b', 'c', 'd e f' ]
    var_4 = split_args(a_8)
    a_8

# Generated at 2022-06-25 01:48:05.363579
# Unit test for function split_args
def test_split_args():
    '''
    This test shows the expected output of split_args with the input
    provided.  The test relies on the unittest module to fail the test
    if the function call does not return the expected value.
    The function call must provide the same number of arguments as
    documented in the module docstring, otherwise the test fails.
    '''
    var_0 = split_args('')
    assert var_0 == [], "The function call split_args() should have returned the correct value"



# Generated at 2022-06-25 01:48:11.767007
# Unit test for function split_args
def test_split_args():
    test_cases = (
        # test_case_0
        ((1327.8485903469368,), {}),
    )

    for args, kwargs in test_cases:
        try:
            split_args(*args, **kwargs)
        except Exception as ex:
            print('split_args(*{}, **{}) raised {}'.format(args, kwargs, repr(ex)))


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:48:13.354029
# Unit test for function split_args
def test_split_args():
    start_time = time.time();
    test_case_0();
    print("--- %s seconds ---" % (time.time() - start_time));

test_split_args()

# Generated at 2022-06-25 01:48:14.561478
# Unit test for function split_args
def test_split_args():


    # Check case 0:
    test_case_0()

    return

# Generated at 2022-06-25 01:48:24.765075
# Unit test for function split_args
def test_split_args():
    args = """
    test_string = "foo bar"

    test_string_alias = test_string
    """

    params = split_args(args)
    assert params[1] == 'test_string_alias'
    assert params[2] == '= test_string'
    assert params[3] == ''

    # Test that a backslash can be used to escape a space
    params = split_args('foo\ bar')
    assert params[0] == 'foo bar'

    # Test that quotes can be escaped with a backslash
    params = split_args('foo"bar')
    assert params[0] == 'foo"bar'

    # Test that quotes inside of quotes, as well as escaped quotes correctly
    # do not break the quotes outside of the quotes

# Generated at 2022-06-25 01:48:27.043970
# Unit test for function split_args
def test_split_args():
    # Test case 0
    #positive input
    test_case_0()
    #negative input
    #test
    #test
    #test
    #test
    #test
    #test
    #test
    #test
    #test
    #test
    #test
    #test




# Generated at 2022-06-25 01:48:29.667721
# Unit test for function split_args
def test_split_args():
    # Test case 0
    try:
        test_case_0()
    except:
        print("AssertionError")


if __name__ == '__main__':
    test_split_args()