

# Generated at 2022-06-25 01:39:09.456216
# Unit test for function split_args
def test_split_args():
    bytes_0 = b''
    var_0 = split_args(bytes_0)
    assert var_0 == []

    bytes_1 = b'a=b'
    var_1 = split_args(bytes_1)
    assert var_1 == ['a=b']

    bytes_2 = b'a=b c=d'
    var_2 = split_args(bytes_2)
    assert var_2 == ['a=b', 'c=d']

    bytes_3 = b'a=b c="foo bar"'
    var_3 = split_args(bytes_3)
    assert var_3 == ['a=b', 'c="foo bar"']

    bytes_4 = b"a=b c='foo bar'"
    var_4 = split_args(bytes_4)

# Generated at 2022-06-25 01:39:15.026173
# Unit test for function unquote
def test_unquote():
    var_0 = unquote('""')
    assert var_0 == ''
    var_1 = unquote('""')
    assert var_1 == ''
    var_2 = unquote('""')
    assert var_2 == ''
    var_3 = unquote('')
    assert var_3 == ''
    var_4 = unquote('""')
    assert var_4 == ''
    var_5 = unquote('""')
    assert var_5 == ''
    var_6 = unquote('""')
    assert var_6 == ''
    var_7 = unquote('"\\""')
    assert var_7 == '"'
    var_8 = unquote('\\""')
    assert var_8 == '\\"'
    var_9 = unquote('""')
    assert var_9 == ''
    var_

# Generated at 2022-06-25 01:39:26.769927
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'a=b'
    var_0 = split_args(bytes_0)
    assert len(var_0) == 2
    bytes_1 = b'a=b c="foo bar"'
    var_1 = split_args(bytes_1)
    assert len(var_1) == 3
    bytes_2 = b"a=b c='foo bar'"
    var_2 = split_args(bytes_2)
    assert len(var_2) == 3
    bytes_3 = b'a=b c=\'foo bar\''
    var_3 = split_args(bytes_3)
    assert len(var_3) == 3
    bytes_4 = b'a=b c="foo bar'
    var_4 = split_args(bytes_4)

# Generated at 2022-06-25 01:39:31.435021
# Unit test for function split_args
def test_split_args():
    assert split_args('echo "{{ foo.bar() }}"')  == ['echo', '"{{ foo.bar() }}"']
    assert split_args('echo "{{ foo.bar() }}"') != ['echo','"{{ foo.bar() }}']
    assert split_args('echo "{{ foo.bar() }}"') != ['echo', '{{ foo.bar() }}"']


# Generated at 2022-06-25 01:39:37.317747
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('""') == ''
    assert unquote('hello"') == 'hello'
    assert unquote('hello') == 'hello'

# unit test for function is_quoted

# Generated at 2022-06-25 01:39:43.646927
# Unit test for function split_args
def test_split_args():
    assert split_args(b"a=b c=d") == ["a=b", "c=d"], 'split_args(b"a=b c=d") == ["a=b", "c=d"]'
    assert split_args(b"a=b 'c=d'") == ["a=b", "c=d"], 'split_args(b"a=b \'c=d\'") == ["a=b", "c=d"]'
    assert split_args(b"a=b 'c=d'\ne=f") == ["a=b", "c=d\ne=f"], 'split_args(b"a=b \'c=d\'\ne=f") == ["a=b", "c=d\ne=f"]'

# Generated at 2022-06-25 01:39:47.944097
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'a=b c="foo bar"'
    expected_0 = ['a=b', 'c="foo bar"']
    actual_0 = split_args(bytes_0)
    assert actual_0 == expected_0

    bytes_1 = b'd=e f="foo bar"'
    expected_1 = ['d=e', 'f="foo bar"']
    actual_1 = split_args(bytes_1)
    assert actual_1 == expected_1

    bytes_2 = b'g=h i="foo bar"'
    expected_2 = ['g=h', 'i="foo bar"']
    actual_2 = split_args(bytes_2)
    assert actual_2 == expected_2

    bytes_3 = b'j=k l="foo bar"'

# Generated at 2022-06-25 01:39:56.516407
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'a=b c="foo bar"'
    var_0 = b'a=b c="foo bar"'
    assert split_args(bytes_0) == [b'a=b', b'c="foo bar"']
    bytes_1 = b'a=b c="foo bar"'
    assert split_args(bytes_1) == [b'a=b', b'c="foo bar"']
    bytes_2 = b'a=b c="foo bar"'
    var_0 = b'a=b c="foo bar"'
    assert split_args(bytes_2) == [b'a=b', b'c="foo bar"']
    bytes_3 = b'a=b c="foo bar"'
    var_0 = b'a=b c="foo bar"'

# Generated at 2022-06-25 01:40:02.605710
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'a=b c="foo bar"'
    bytes_1 = b'a=b c="foo bar\\" d="yada"'
    bytes_2 = b"a=b c='foo bar\\' d='yada'"
    bytes_3 = b"a=b c='foo bar\\' d='yada' e=\"foo \\\" bar\" f='foo \\\" bar'"
    bytes_4 = b'a=b c="foo bar\\" d="yada" e="1 2 3\n4 5 6"'
    bytes_5 = b'a=b c="{{ foo }} bar\\" d="yada" e="1 2 3\n4 5 6"'

# Generated at 2022-06-25 01:40:03.927258
# Unit test for function split_args
def test_split_args():
    # possible test case: split_args('')
    test_case_0()



# Generated at 2022-06-25 01:40:21.862454
# Unit test for function split_args
def test_split_args():
    func = split_args
    assert func(b'yes') == ['yes']
    assert func(b'yes ') == ['yes']
    assert func(b"yes 'no'") == ['yes', "'no'"]
    assert func(b'yes "no"') == ['yes', '"no"']
    assert func(b"yes 'no' ") == ['yes', "'no'"]
    assert func(b'yes "no" ') == ['yes', '"no"']
    assert func(b'yes "no') == ['yes', '"no']
    assert func(b'yes \'no') == ['yes', '\'no']
    assert func(b'yes "no\'"') == ['yes', '"no\'"']

# Generated at 2022-06-25 01:40:27.067420
# Unit test for function split_args
def test_split_args():
    bytes_1 = b'test.py param1="The first param" param2=\'The second param\''
    var_1 = split_args(bytes_1)



# Generated at 2022-06-25 01:40:34.296467
# Unit test for function split_args
def test_split_args():
    bytes_0 = b"hello 'world' \"foo bar\""
    assert (split_args(bytes_0) == ['hello', "'world'", '"foo bar"'])
    bytes_1 = b"{ { {foo bar} } }"
    assert (split_args(bytes_1) == ["{", "{", "{foo bar}", "}", "}", "}"])
    bytes_2 = b"{foo bar} {foo bar}"
    assert (split_args(bytes_2) == ["{foo", "bar}", "{foo", "bar}"])
    bytes_3 = b"{{foo bar}} {{foo bar}}"
    assert (split_args(bytes_3) == ["{{foo bar}}", "{{foo bar}}"])
    bytes_4 = b"{{ foo bar }} {{ foo bar }}"
   

# Generated at 2022-06-25 01:40:35.410262
# Unit test for function split_args
def test_split_args():
    import doctest
    doctest.testmod()

# Unit test

# Generated at 2022-06-25 01:40:41.960429
# Unit test for function split_args
def test_split_args():

    test_case_0()

# Generated at 2022-06-25 01:40:46.686194
# Unit test for function split_args
def test_split_args():
    assert split_args(b'foo bar') == ['foo', 'bar']
    assert split_args(b'foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args(b'foo=bar') == ['foo=bar']
    assert split_args(b'foo=bar baz=blam') == ['foo=bar', 'baz=blam']
    assert split_args(b'foo=bar\\ baz=blam') == ['foo=bar baz=blam']
    assert split_args(b"foo='bar baz'") == ["foo='bar baz'"]
    assert split_args(b"foo='bar baz' one=two") == ["foo='bar baz'", 'one=two']
    assert split_args(b'foo bar "baz blam"')

# Generated at 2022-06-25 01:40:56.757723
# Unit test for function split_args
def test_split_args():
    module_arg_spec = dict(
        a=dict(),
        b=dict(),
        c=dict(),
        d=dict(),
        e=dict(),
        f=dict(),
        g=dict(),
        h=dict(),
        i=dict(),
        j=dict(),
        k=dict(),
        l=dict(),
        m=dict(),
        n=dict(),
        o=dict(),
        p=dict(),
        q=dict(),
        r=dict(),
        s=dict(),
        t=dict(),
        u=dict(),
        v=dict(),
        w=dict(),
        x=dict(),
        y=dict(),
        z=dict(),
    )

    # test case

# Generated at 2022-06-25 01:41:06.064733
# Unit test for function split_args
def test_split_args():
    # This is the basic usage of the split_args function.
    #
    # We provide the string as an argument and then we can
    # work with the result as a list.
    #
    # As we can see, multiple quoted strings are preserved
    # if they are part of the same token.
    result = split_args("a=b c='foo bar'")
    assert result == ['a=b', "c='foo bar'"]

    # This illustrates how line continuations are parsed.
    # It also shows that line continuation can occur inside
    # a quoted token.
    result = split_args("first=token \\\ns=")
    assert result == ['first=token', 's=']

    # This is a more complex example that shows how the line
    # continuation can occur inside a quoted string. It also
    # shows that a quoted

# Generated at 2022-06-25 01:41:16.964607
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.six import PY3
    global module_args
    module_args = dict()

    def set_default(m=None, **kwargs):
        for (key, value) in kwargs.items():
            module_args[key] = value


    set_default(module_args, foo=["simple"], bar="simple")
    set_default(module_args, foo=["from module_utils param lookup"], bar="from module_utils param lookup")
    set_default(module_args, foo=["from module_utils fallback param lookup"],
                bar="from module_utils fallback param lookup")


# Generated at 2022-06-25 01:41:17.819031
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 01:41:30.162190
# Unit test for function split_args
def test_split_args():
    print("in test_split_args")
    test_case_0()
    print("in test_split_args")

# Generated at 2022-06-25 01:41:40.003584
# Unit test for function split_args
def test_split_args():
    bytes_0 = b"test_case_0()"
    var_0 = split_args(bytes_0)
    assert var_0 == ['test_case_0()']

    bytes_1 = b"test_case_1()  # This is a test case"
    var_1 = split_args(bytes_1)
    assert var_1 == ['test_case_1()', '# This is a test case']

    bytes_2 = b"test_case_2  # This is a test case"
    var_2 = split_args(bytes_2)
    assert var_2 == ['test_case_2', '# This is a test case']

    bytes_3 = b"test_case_3   # This is a test case"
    var_3 = split_args(bytes_3)
    assert var_

# Generated at 2022-06-25 01:41:48.002403
# Unit test for function split_args
def test_split_args():
    for test in [test_case_0]:
        test()

# Generated from ansible/test/units/modules/extras/test_jinja2_filters.py.
# pylint: disable=too-many-lines
#
# (c) 2016 Adam Miller <admiller@redhat.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

ANSIBLE_METADATA = {'metadata_version': '1.1',
                    'status': ['preview'],
                    'supported_by': 'community'}

import jinja2
import os

# Generated at 2022-06-25 01:41:53.914080
# Unit test for function split_args

# Generated at 2022-06-25 01:42:01.368005
# Unit test for function split_args
def test_split_args():
    assert split_args(b"foo=bar name='me myself'") == [b'foo=bar', b"name='me myself'"]
    assert split_args(b"foo=bar name='me myself'") == [b'foo=bar', b'name=\'me myself\'']
    assert split_args("  foo=bar  name=   'me myself'") == ['foo=bar', "name='me myself'"]
    assert split_args("  foo=bar\n  name=   'me myself'") == ['foo=bar\n', "name='me myself'"]
    assert split_args(b"  foo=bar  name=   'me myself'  ") == ['foo=bar', "name='me myself'"]

# Generated at 2022-06-25 01:42:09.461950
# Unit test for function split_args
def test_split_args():
    assert split_args(b'') == [], "The function split_args isn't working properly"
    assert split_args(b"a='b c'") == [b'a=\'b c\''], "The function split_args isn't working properly"
    assert split_args(b'''a='b c' "d e"''') == [b"a='b c'", b'"d e"'], "The function split_args isn't working properly"
    assert split_args(b"a='b c' 'd e'") == [b"a='b c'", b"'d e'"], "The function split_args isn't working properly"

# Generated at 2022-06-25 01:42:16.562629
# Unit test for function split_args

# Generated at 2022-06-25 01:42:18.660441
# Unit test for function split_args
def test_split_args():
    print("IN test_split_args")
    test_case_0()
    print("test_case_0 passed!")

test_split_args()

# Generated at 2022-06-25 01:42:28.141037
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'   -e thing=otherthing   '
    var_0 = split_args(bytes_0)
    assert len(var_0) == 2
    assert var_0[0] == '-e'
    assert var_0[1] == 'thing=otherthing'

    bytes_1 = b'  " -e" "thing=otherthing"  '
    var_1 = split_args(bytes_1)
    assert len(var_1) == 2
    assert var_1[0] == '-e'
    assert var_1[1] == 'thing=otherthing'

    bytes_2 = b' -e "thing=otherthing"   '
    var_2 = split_args(bytes_2)
    assert len(var_2) == 2
    assert var_2[0]

# Generated at 2022-06-25 01:42:38.608098
# Unit test for function split_args
def test_split_args():
    bytes_0 = b''
    var_0 = split_args(bytes_0)
    if var_0[0] != '':
        raise RuntimeError("var_0[0]: %s" % var_0[0])
    bytes_1 = b'a=b'
    var_1 = split_args(bytes_1)
    if var_1[0] != 'a=b':
        raise RuntimeError("var_1[0]: %s" % var_1[0])
    bytes_2 = b"a=b c='d e'"
    var_2 = split_args(bytes_2)
    if var_2[1] != "c='d e'":
        raise RuntimeError("var_2[1]: %s" % var_2[1])

# Generated at 2022-06-25 01:42:59.455536
# Unit test for function split_args
def test_split_args():
    try:
        test_case_0()
    except Exception as e:
        raise Exception("split_args test failed: " + str(e))


# Generated at 2022-06-25 01:43:01.981297
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'a=b c="foo bar"'
    var_0 = split_args(bytes_0)
    assert var_0 == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 01:43:11.358458
# Unit test for function split_args
def test_split_args():
    bytes_0 = b''
    var_0 = split_args(bytes_0)

    bytes_1 = b'  '
    var_1 = split_args(bytes_1)

    bytes_2 = b'a=b c="foo bar"'
    var_2 = split_args(bytes_2)

    bytes_3 = b'  a=b c="foo bar" '
    var_3 = split_args(bytes_3)

    bytes_4 = b'a="foo bar" c=d'
    var_4 = split_args(bytes_4)

    bytes_5 = b'a="foo bar" c="foo bar"'
    var_5 = split_args(bytes_5)

    bytes_6 = b'a=b "c={{foo}}" d=e f=g'
    var_

# Generated at 2022-06-25 01:43:20.880901
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('"foo bar" biz') == ['"foo bar"', 'biz']
    assert split_args('"foo bar" biz boz') == ['"foo bar"', 'biz', 'boz']
    assert split_args('"foo bar" "biz boz"') == ['"foo bar"', '"biz boz"']
    assert split_args('"foo bar" "biz boz" biz buzz') == ['"foo bar"', '"biz boz"', 'biz', 'buzz']
    assert split_args('"foo bar" "biz boz" biz buzz "joe joe"') == ['"foo bar"', '"biz boz"', 'biz', 'buzz', '"joe joe"']

# Generated at 2022-06-25 01:43:28.490180
# Unit test for function split_args
def test_split_args():
    # Test case with valid input
    bytes_0 = b'run_once=true  chdir=/  name=hello'
    var_0 = split_args(bytes_0)
    assert type(var_0) == list
    assert len(var_0) == 3
    assert var_0[0] == 'run_once=true'
    assert var_0[1] == 'chdir=/'
    assert var_0[2] == 'name=hello'
    # Test case with valid input
    bytes_1 = b'foo=bar  one={{ansible_hostname}}'
    var_1 = split_args(bytes_1)
    assert type(var_1) == list
    assert len(var_1) == 2
    assert var_1[0] == 'foo=bar'
    assert var_1

# Generated at 2022-06-25 01:43:36.539023
# Unit test for function split_args
def test_split_args():
    assert split_args(b"a=b c=\"foo bar\"") == [b"a=b", b"c=\"foo bar\""]
    assert split_args(b"a=b c=\"foo bar\" d") == [b"a=b", b"c=\"foo bar\"", b"d"]
    assert split_args(b"a=b c=\"foo bar\" d=\"foo bar\"") == [b"a=b", b"c=\"foo bar\"", b"d=\"foo bar\""]
    assert split_args(b"a=b c=\"foo bar\" d=\"foo bar\" e") == [b"a=b", b"c=\"foo bar\"", b"d=\"foo bar\"", b"e"]

# Generated at 2022-06-25 01:43:47.360038
# Unit test for function split_args
def test_split_args():
    total_cases = 1
    total_passed = 0


# Generated at 2022-06-25 01:43:48.553506
# Unit test for function split_args
def test_split_args():
    pass


# Generated at 2022-06-25 01:43:59.005756
# Unit test for function split_args
def test_split_args():
    print('Running function split_args')
    bytes_0 = b' a=b c="foo bar"'
    var_0 = split_args(bytes_0)
    bytes_1 = b'a=b c="foo bar"'
    var_1 = split_args(bytes_1)
    bytes_2 = b'a=b\\ c="foo bar"'
    var_2 = split_args(bytes_2)
    bytes_3 = b'a=b\\\n c="foo bar"'
    var_3 = split_args(bytes_3)
    bytes_4 = b'a=b\\\n  c="foo bar"'
    var_4 = split_args(bytes_4)
    bytes_5 = b'a=b\\\n   c="foo bar"'

# Generated at 2022-06-25 01:44:03.409583
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'a=b c="foo bar"'
    var_0 = split_args(bytes_0)
    # assert statement for assertion
    assert var_0 == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 01:44:20.045293
# Unit test for function split_args
def test_split_args():
    # might not be a good test, because function
    # split_args doesn't really do anything
    a = 'myvar="foo bar" myvar2=\'bazqux\' myvar3=abc'
    split_args(a)


# Generated at 2022-06-25 01:44:28.164458
# Unit test for function split_args
def test_split_args():
    """
    Test for the function split_args
    """
    try:
        print("Running unit test for function split_args")
        bytes_0 = b' "foo bar" "foo"\'bar\''
        var_0 = split_args(bytes_0)
        print(var_0)
        print("Test passed")
    except Exception:
        print("Test failed")
    print("Test for function split_args finished")

test_split_args()

# Generated at 2022-06-25 01:44:31.286242
# Unit test for function split_args
def test_split_args():
    print("Running test_split_args tests")
    test_case_0()
    print("Completed test_split_args tests")

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:44:33.134630
# Unit test for function split_args
def test_split_args():
    try:
        test_case_0()
    except Exception as e:
        print(e.message)

####################
# End of test_split_args
####################


# Generate a random dictionary

# Generated at 2022-06-25 01:44:35.499101
# Unit test for function split_args
def test_split_args():
    bytes_0 = b"a=b c=\"foo bar\""
    var_0 = split_args(bytes_0)
    assert var_0 == ['a=b', 'c="foo bar"'], 'Test failed'


# Generated at 2022-06-25 01:44:40.112845
# Unit test for function split_args
def test_split_args():
    bytes_0 = b''
    var_0 = split_args(bytes_0)
    print(var_0)
    print(type(var_0))
    bytes_1 = b'asdf'
    var_1 = split_args(bytes_1)
    print(var_1)
    print(type(var_1))
    bytes_2 = b'a=b c="foo bar"'
    var_2 = split_args(bytes_2)
    print(var_2)
    print(type(var_2))
    bytes_3 = b'a="a\n b" c=\'a\n b\''
    var_3 = split_args(bytes_3)
    print(var_3)
    print(type(var_3))

# Generated at 2022-06-25 01:44:40.665547
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 01:44:47.632686
# Unit test for function split_args
def test_split_args():
    assert(split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'])
    assert(split_args('a="foo bar"') == ['a="foo bar"'])
    assert(split_args('a=b "c=d e=f"') == ['a=b', '"c=d e=f"'])
    assert(split_args('a=b "c=d e=f" g="h i" j="k l"') == ['a=b', '"c=d e=f"', 'g="h i"', 'j="k l"'])

# Generated at 2022-06-25 01:44:52.431298
# Unit test for function split_args
def test_split_args():
    # Test case 0
    test_case_0()


if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:44:54.355183
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'a=b c="foo bar"'
    var_0 = split_args(bytes_0)
    assert var_0 == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 01:45:14.956672
# Unit test for function split_args
def test_split_args():
    assert False


# Generated at 2022-06-25 01:45:20.930594
# Unit test for function split_args

# Generated at 2022-06-25 01:45:30.551117
# Unit test for function split_args
def test_split_args():
    # Convert initial unicode argument to bytes
    unicode_0 = u'args.txt'
    bytes_4 = unicode_0.encode('utf-8')

    # Read file
    var_1 = open(bytes_4, 'rb')
    try:
        var_2 = var_1.read()
    finally:
        var_1.close()

    # Convert file data from bytes to unicode
    unicode_1 = var_2.decode('utf-8')

    # Split arguments from file
    var_3 = split_args(unicode_1)

    # Convert expected arguments from bytes to unicode

# Generated at 2022-06-25 01:45:35.363819
# Unit test for function split_args
def test_split_args():
    # Test for function split_args -- basic tests

    # Call function with args
    result = split_args(
        'foo bar baz=BAZ "single quoted" \'double quoted\' a="complex quoted" b=c \\')

    # Assert a few simple cases
    assert result[1] == 'bar'
    assert result[2] == 'baz=BAZ'
    assert result[3] == 'single quoted'
    assert result[4] == 'double quoted'
    assert result[5] == 'a=complex quoted'
    assert result[6] == 'b=c'

    # Test for function split_args -- larger tests

    # Call function with args
    result = split_args(
        """
        first arg
        second arg
        third arg
        """
    )

    # Assert a few simple cases
   

# Generated at 2022-06-25 01:45:42.483962
# Unit test for function split_args
def test_split_args():
    print("BEFORE: " + __name__ + ".test_split_args")
    print("test_case_0()")
    test_case_0()
    print("END: " + __name__ + ".test_split_args")


if __name__ == "__main__":
    print("RUNNING: " + __name__ + ".py")
    test_split_args()
    print("SUCCESS: " + __name__ + ".py")

# Generated at 2022-06-25 01:45:48.483359
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'= "abcd"   \\\'e,f,g\\\' hijk'
    var_0 = split_args(bytes_0)
    print (var_0)
    bytes_1 = b'"\\" abcd"   \\\'e,f,g\\\' hijk'
    var_1 = split_args(bytes_1)
    print (var_1)
    bytes_2 = b' "  abcd"   \'e,f,g\' hijk'
    var_2 = split_args(bytes_2)
    print (var_2)
    bytes_3 = b' "  abcd"   \'e,f,g\' hijk'
    var_3 = split_args(bytes_3)
    print (var_3)

# Generated at 2022-06-25 01:45:57.493416
# Unit test for function split_args
def test_split_args():
    # BytesIO object
    bytes_0 = b'a=b'
    list_0 = split_args(bytes_0)
    list_1 = split_args(bytes_0)
    assert list_0 == list_1

    # BytesIO object
    bytes_1 = b'a="b"'
    list_2 = split_args(bytes_1)
    assert list_2 == ['a=b']

    # BytesIO object
    bytes_2 = b'a="b c"'
    list_3 = split_args(bytes_2)
    assert list_3 == ['a=b c']

    # TODO: strip
    # BytesIO object
    bytes_3 = b'a="b c"'
    # BytesIO object
    bytes_4 = b'a="b c"'
    list_

# Generated at 2022-06-25 01:46:03.868997
# Unit test for function split_args
def test_split_args():
    '''
    Tests the split_args function from the module
    '''

    bytes_0 = b''
    var_0 = split_args(bytes_0)
    assert var_0 == ['']

    bytes_0 = b'foo=bar'
    var_0 = split_args(bytes_0)
    assert var_0 == ['foo=bar']

    bytes_0 = b'foo=bar baz=qux'
    var_0 = split_args(bytes_0)
    assert var_0 == ['foo=bar', 'baz=qux']

    bytes_0 = b'foo=bar \\\nbaz=qux'
    var_0 = split_args(bytes_0)
    assert var_0 == ['foo=bar', 'baz=qux']


# Generated at 2022-06-25 01:46:11.487451
# Unit test for function split_args
def test_split_args():
    bytes_0 = b"a=b c='foo bar'"
    var_0 = split_args(bytes_0)
    assert var_0 == ['a=b', "c='foo bar'"]
    bytes_1 = b"a=b c='foo bar'"
    var_1 = split_args(bytes_1)
    assert var_1 == ['a=b', "c='foo bar'"]
    bytes_2 = b"a=b c='foo bar'"
    var_2 = split_args(bytes_2)
    assert var_2 == ['a=b', "c='foo bar'"]


# Generated at 2022-06-25 01:46:14.762446
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    test_case_0()


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:46:59.728844
# Unit test for function split_args
def test_split_args():
    arg_0 = 'a=b c="foo bar"'
    ret_0 = split_args(arg_0)
    assert ret_0 == ['a=b', 'c="foo bar"']

    arg_1 = 'a=b c="foo bar" baz=\'{{ foo }}\''
    ret_1 = split_args(arg_1)
    assert ret_1 == ['a=b', 'c="foo bar"', "baz='{{ foo }}'"]

    arg_2 = 'a=b c="foo bar" baz=\'{{ foo }}\'\nfoo=\'bar baz\''
    ret_2 = split_args(arg_2)
    assert ret_2 == ['a=b', 'c="foo bar"', "baz='{{ foo }}'\nfoo='bar baz'"]

   

# Generated at 2022-06-25 01:47:01.462204
# Unit test for function split_args
def test_split_args():
    print("Input data:")
    print("output: ", split_args())
    print("expected: ", "")
    assert split_args() == "", "test_split_args failed"
    print("Test passed")


# Generated at 2022-06-25 01:47:08.486385
# Unit test for function split_args
def test_split_args():
    # Input Parameters:
    args = 'a=b c="foo bar"'

    # Expected Parameters:
    expected_params = ['a=b', 'c="foo bar"']

    # Actual Parameters:
    actual_params = split_args(args)

    assert expected_params == actual_params, 'split_args: Expected ' + str(expected_params) + ' Got ' + str(actual_params)


# Generated at 2022-06-25 01:47:18.808690
# Unit test for function split_args
def test_split_args():
    bytes_1 = b'a=b c="foo bar"'
    var_1 = split_args(bytes_1)
    assert var_1 == ['a=b', 'c="foo bar"']

    bytes_2 = b"  a=1 c='foo bar'  "
    var_2 = split_args(bytes_2)
    assert var_2 == ['a=1', "c='foo bar'"]

    bytes_3 = b"  a=1 c='foo bar'  d='\\'foo\\' bar'\n  e=2"
    var_3 = split_args(bytes_3)
    assert var_3 == ['a=1', "c='foo bar'", "d='\\'foo\\' bar'\n", 'e=2']


# Generated at 2022-06-25 01:47:28.129742
# Unit test for function split_args
def test_split_args():
    assert split_args(b"a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args(b"a=b c=\"foo bar\" d=") == ['a=b', 'c="foo bar"', 'd=']
    assert split_args(b"a=b c=\"foo bar\" d=\"\\\"\"") == ['a=b', 'c="foo bar"', 'd="\\"']

# Generated at 2022-06-25 01:47:28.937409
# Unit test for function split_args
def test_split_args():
    test_case_0()



# Generated at 2022-06-25 01:47:37.320943
# Unit test for function split_args
def test_split_args():
    assert split_args(b"foo") == [b"foo"], b"argument parsing failure"
    assert split_args(b"foo=bar") == [b"foo=bar"], b"argument parsing failure"
    assert split_args(b"foo='bar baz'") == [b"foo='bar baz'"], b"argument parsing failure"
    assert split_args(b"foo=\"bar baz\"") == [b"foo=\"bar baz\""], b"argument parsing failure"
    assert split_args(b"foo=\"bar \\\"baz\\\" quux\"") == [b"foo=\"bar \\\"baz\\\" quux\""], b"argument parsing failure"

# Generated at 2022-06-25 01:47:45.815807
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")

# Generated at 2022-06-25 01:47:51.946404
# Unit test for function split_args
def test_split_args():
    # This will fail if the args cannot be split by whitespace.
    bytes_0 = b'abc def'
    var_0 = split_args(bytes_0)
    assert var_0 == ['abc','def']

    # A simple quoted string should not be split by the whitespace, and should end up correctly quoted.
    # This tests that the whitespace splitting does the right thing in quoted strings.
    bytes_1 = b'abc "def" ghi'
    var_1 = split_args(bytes_1)
    assert var_1 == ['abc', '"def"', 'ghi']

    # If a quoted string is unterminated, it should not be split by whitespace, and the quotes should
    # show up as part of the final argument.
    bytes_2 = b'abc "def gh'
    var_2 = split_

# Generated at 2022-06-25 01:48:01.675507
# Unit test for function split_args
def test_split_args():
    bytes_0 = b' arg1 arg2 arg3 '
    list_0 = split_args(bytes_0)
    list_1 = [b'arg1', b'arg2', b'arg3']
    assert list_0 == list_1

    bytes_2 = b'arg1 "arg2" "arg3"'
    list_2 = split_args(bytes_2)
    list_3 = [b'arg1', b'"arg2"', b'"arg3"']
    assert list_2 == list_3

    bytes_4 = b'"arg1" arg2 arg3'
    list_4 = split_args(bytes_4)
    list_5 = [b'"arg1"', b'arg2', b'arg3']
    assert list_4 == list_5
