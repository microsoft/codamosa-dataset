

# Generated at 2022-06-25 01:39:05.989641
# Unit test for function unquote
def test_unquote():
    with open('tst_unquote_input.txt') as f:
        data = f.read()
    int_0 = unquote(data)
    with open('tst_unquote_expected_output.txt') as f:
        assert int_0 == unquote(f.read())


# Generated at 2022-06-25 01:39:07.734359
# Unit test for function split_args
def test_split_args():
    assert split_args(
        "foo=bar bam={{ baz }}"
        ) == ["foo=bar", "bam={{ baz }}"]


# Generated at 2022-06-25 01:39:09.805140
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('foo') == False
    assert is_quoted('') == False


# Generated at 2022-06-25 01:39:14.845495
# Unit test for function split_args
def test_split_args():
    arg = "  '  hello  '  world"
    print(split_args(arg))
    arg = "  '  hello  '  world '  "
    print(split_args(arg))
    arg = '''  {% if item == 1 %}
  '  hello  '  world
  {% endif %}
  '  '''

    print(split_args(arg))
    arg = '''  {% if item == 1 %}
  '  hello  '  world
  {% endif %}
  '  '''
    print(split_args(arg))


# test the function
if __name__ == '__main__':
    print(test_case_0())
    print(test_split_args())

# Generated at 2022-06-25 01:39:18.178321
# Unit test for function split_args
def test_split_args():
    var_0 = 'a=b c="foo bar"'
    var_1 = split_args(var_0)
    assert var_1 == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 01:39:26.423336
# Unit test for function split_args
def test_split_args():
    items = 'a="b c" d=\'e f\' x=g y="h i"'.strip().split(' ')
    expected = ['a="b c"', "d='e f'", 'x=g', 'y="h i"']
    params = split_args(items)
    if not expected == params:
        raise Exception("split_args test did not produce the expected result")
    else:
        print("split_args produces the correct result")


if __name__ == '__main__':
    #test_split_args()
    test_case_0()

# Generated at 2022-06-25 01:39:29.290078
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted('hello') == False
    assert is_quoted(' hello ') == False



# Generated at 2022-06-25 01:39:35.711206
# Unit test for function is_quoted
def test_is_quoted():
    string = '"a string"'
    assert(is_quoted(string)) is True
    string = "'a string'"
    assert(is_quoted(string)) is True
    string = "'quotes in string''s'"
    assert(is_quoted(string)) is True
    string = '"quotes in string""s"'
    assert(is_quoted(string)) is True
    string = '"a string with quotes" but no closing"'
    assert(is_quoted(string)) is False
    string = '"a string with quotes" but no opening"'
    assert(is_quoted(string)) is False
    string = "here's the deal"
    assert(is_quoted(string)) is False
    string = 42.0
    assert(is_quoted(string)) is False


# Generated at 2022-06-25 01:39:44.947163
# Unit test for function split_args

# Generated at 2022-06-25 01:39:46.806213
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 01:40:04.659537
# Unit test for function split_args
def test_split_args():
    args = "'a=b c=\"foo bar\"'"
    result = split_args(args)
    params = ['a=b', 'c="foo bar"']

    assert result == params, "Expected output did not match actual output"



# Generated at 2022-06-25 01:40:10.455359
# Unit test for function split_args
def test_split_args():
    args_0 = 'hello=world foo="bar baz" abc="semi-colon;here"'
    params_0 = split_args(args_0)
    assert params_0 == ['hello=world', 'foo="bar baz"', 'abc="semi-colon;here"']
    args_1 = 'foo="bar \'baz" abc="semi-colon;here"'
    params_1 = split_args(args_1)
    assert params_1 == ['foo="bar \'baz', 'abc="semi-colon;here"']
    args_2 = 'foo="bar baz" abc="semi-colon;here" abc=def ghi=jkl'
    params_2 = split_args(args_2)

# Generated at 2022-06-25 01:40:14.530846
# Unit test for function unquote
def test_unquote():
    assert 'foobar' == unquote('foobar')
    assert 'foo bar' == unquote('"foo bar"')
    assert 'foo bar' == unquote("'foo bar'")
    assert 'foo' == unquote("'foo")
    assert "'foo" == unquote("'foo")
    assert "''foo''" == unquote("''foo''")
    print("Test success: unquote")


# Generated at 2022-06-25 01:40:22.321027
# Unit test for function split_args
def test_split_args():
    # Test #0
    params = split_args('http_port := 8888')
    assert params == ['http_port := 8888']

    # Test #1
    params = split_args('https_port := 8443 ssl_certificate := "{{ "{{ "')
    assert params == ['https_port := 8443', 'ssl_certificate := "{{ "{{ "']

    # Test #2
    params = split_args('http_port := 8888')
    assert params == ['http_port := 8888']

    # Test #3
    params = split_args('http_port := 8888\nssl_key := "{{ "{{ "')
    assert params == ['http_port := 8888\n', 'ssl_key := "{{ "{{ "']

    # Test #4

# Generated at 2022-06-25 01:40:25.859164
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar" d="f\'oo" e=\'bar f\''
    params = split_args(args)
    p1 = 'a=b'
    p2 = 'c="foo bar"'
    p3 = 'd="f\'oo"'
    p4 = 'e=\'bar f\''
    assert(len(params) == 4)
    assert(p1 in params)
    assert(p2 in params)
    assert(p3 in params)
    assert(p4 in params)


# Generated at 2022-06-25 01:40:33.448915
# Unit test for function split_args
def test_split_args():
    # simple one parameter test
    args = "michael"
    params = split_args(args)
    assert params == ["michael"]

    # a more complex test, with multiple params, and spaces inside
    # of quotes
    args = '''-a 'this is a " quotation' "this is a ' quotation"'''
    params = split_args(args)
    assert params == ['-a', 'this is a " quotation', "this is a ' quotation"]

    # test for mixing single and double quotes
    args = '''-a "the dog's ball" 'the cat\'s ball' 'the fox\'s ball' "the mouse's ball"'''
    params = split_args(args)
    assert params == ['-a', "the dog's ball", "the cat's ball", "the fox's ball", "the mouse's ball"]

# Generated at 2022-06-25 01:40:40.042014
# Unit test for function split_args

# Generated at 2022-06-25 01:40:50.014841
# Unit test for function split_args
def test_split_args():

    args = 'a= b="foo bar" c={{ d={{e}} }}'
    assert(split_args(args) == ['a=', 'b="foo bar"', 'c={{ d={{e}} }}'])

    args = 'a=b c="foo bar"'
    assert(split_args(args) == ['a=b', 'c="foo bar"'])

    args = 'a=b c="foo bar" d="\'" e=\'""\''
    assert(split_args(args) == ['a=b', 'c="foo bar"', 'd="\'"', 'e=\'""\''])

    # FIXME: not sure why this fails, claims e is unbalanced, but it seems to be to me
    # args = 'a=b c="foo bar" d=\"\\"\' e=\'\\

# Generated at 2022-06-25 01:40:52.903936
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"asdf"')
    assert not is_quoted('"asdf" "dfg"')
    assert unquote('"asdf"') == 'asdf'
    assert unquote('asdf') == 'asdf'


# Generated at 2022-06-25 01:41:01.807629
# Unit test for function unquote
def test_unquote():
    assert len(unquote(u'"a b c d" e f g h')) == 12
    assert unquote(u'"a b c d" e f g h') == 'a b c d" e f g h'
    assert unquote(u'"a b c d" e f g h') == 'a b c d" e f g h'
    assert len(unquote(u'"a b c d" e f g h')) == 12
    assert unquote(u'"a b c d" e f g h') == 'a b c d" e f g h'
    assert unquote(u'"a b c d" e f g h') == 'a b c d" e f g h'



# Generated at 2022-06-25 01:41:22.697546
# Unit test for function split_args

# Generated at 2022-06-25 01:41:29.786241
# Unit test for function split_args
def test_split_args():
    # 1:
    args_1 = '1st param'
    result_1 = split_args(args_1)
    if result_1 != ['1st param']:
        print('FAILED 1')

    # 2:
    args_2 = '1st param 2nd param'
    result_2 = split_args(args_2)
    if result_2 != ['1st param', '2nd param']:
        print('FAILED 2')

    # 3:
    args_3 = '1st param 2nd="foo bar" param'
    result_3 = split_args(args_3)
    if result_3 != ['1st param', '2nd="foo bar"', 'param']:
        print('FAILED 3')

    # 4:

# Generated at 2022-06-25 01:41:39.376992
# Unit test for function split_args

# Generated at 2022-06-25 01:41:40.408637
# Unit test for function split_args
def test_split_args():
    pass


test_case_0()

# Generated at 2022-06-25 01:41:48.377586
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.compat import quote
    from unittest import TestCase
    from ansible.module_utils.common.compat import unquote

    class TestSplitArgs(TestCase):

        def test_split_args_basic(self):
            res = split_args('a=b c="foo bar"')
            self.assertEqual(res, ['a=b', 'c="foo bar"'])

        def test_split_args_jinja_at_end(self):
            res = split_args('a={{b}}')
            self.assertEqual(res, ['a={{b}}'])

        def test_split_args_jinja_middle(self):
            res = split_args('a={{b}} c=d')

# Generated at 2022-06-25 01:41:57.474827
# Unit test for function split_args
def test_split_args():
    try:
        from ansible import constants as C
        from ansible.utils.unicode import to_unicode
    except ImportError:
        raise Exception("There is no module named ansible.utils.unicode")
    fp = open(r'C:\Users\v-tianyu\Desktop\MyPlaybook\test.yml', 'r')
    raw = fp.read()
    fp.close()

    if raw.startswith(u'#!'):
        raw = raw[raw.index(C.DEFAULT_HASH_BEHAVIOUR) + 2:]

    data = to_unicode(raw, nonstring='passthru')
    test_data = split_args(data)
    print(test_data)

#test_case_0()
test_split_args()

# Generated at 2022-06-25 01:42:08.283191
# Unit test for function split_args
def test_split_args():
    assert split_args('') == ['']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="foo bar" c="{{ foo }} {{ bar | default(foo) }}"') == ['a="foo bar"', 'c="{{ foo }} {{ bar | default(foo) }}"']
    assert split_args('a="foo bar" c="{{ foo }} {{ bar | default(foo) }}') == ['a="foo bar"', 'c="{{ foo }} {{ bar | default(foo) }}']
    assert split_args('a="a=b c=d"') == ['a="a=b c=d"']
    assert split_args('a="a=b c=d') == ['a="a=b c=d']
   

# Generated at 2022-06-25 01:42:13.933231
# Unit test for function split_args
def test_split_args():
    out = split_args("a")
    assert ['a'] == out
    out = split_args("a=b")
    assert ['a=b'] == out
    out = split_args("a=b c")
    assert ['a=b', 'c'] == out
    out = split_args("a=b c=d")
    assert ['a=b', 'c=d'] == out
    out = split_args("a=b c=d e=f")
    assert ['a=b', 'c=d', 'e=f'] == out
    out = split_args("a=b c=d e=f g")
    assert ['a=b', 'c=d', 'e=f', 'g'] == out
    out = split_args("a b=c")
    assert ['a', 'b=c']

# Generated at 2022-06-25 01:42:24.321790
# Unit test for function split_args
def test_split_args():
    args = """
        foo='bar baz'
        something=1
        """

    params = split_args(args)
    assert len(params) == 3
    assert params[0] == "foo='bar baz'"
    assert params[1] == 'something=1'

    args = """
        foo="bar baz\"
        something=1
        """

    params = split_args(args)
    assert len(params) == 3
    assert params[0] == "foo=\"bar baz\""
    assert params[1] == 'something=1'

    args = """
        foo="bar baz\"
        something=1
        """

    params = split_args(args)
    assert len(params) == 3
    assert params[0] == "foo=\"bar baz\""
    assert params[1]

# Generated at 2022-06-25 01:42:34.216564
# Unit test for function split_args
def test_split_args():
    data = 'asdf "foo bar" "foo bar\" baz" \'foo bar\' \'foo bar\\\' baz\''
    # expected result
    result = ['asdf', 'foo bar', 'foo bar" baz', 'foo bar', 'foo bar\\\' baz']
    assert split_args(data) == result

    data = 'asdf \'foo bar'
    # expected result
    result = ['asdf', 'foo bar']
    assert split_args(data) == result

    data = 'asdf \'foo bar\\'
    # expected result
    result = ['asdf', 'foo bar\\']
    assert split_args(data) == result

    data = 'asdf "foo bar'
    # expected result
    result = ['asdf', '"foo', 'bar']
    assert split_args(data) == result

# Generated at 2022-06-25 01:42:55.733296
# Unit test for function split_args
def test_split_args():

    # Test 1 - Quotes and Jinja blocks
    str_1 = '"{{ foo }}" "{{ f"oo }}" """{{ foo }}"""'
    var_1 = split_args(str_1)
    for idx, item in enumerate(var_1):
        if idx == 0:
            assert item == '"{{ foo }}"'
        elif idx == 1:
            assert item == '"{{ f"oo }}"'
        elif idx == 2:
            assert item == '"""{{ foo }}"""'

    # Test 2 - Quotes and Jinja blocks
    str_2 = '''{{ foo }}
"{{ foo }}"
"{{ f"oo }}"
"""{{ foo }}"""
'''
    var_2 = split_args(str_2)

# Generated at 2022-06-25 01:43:04.661039
# Unit test for function split_args
def test_split_args():
    assert split_args('4bfd') == ['4bfd']
    assert split_args('4bfd\n0') == ['4bfd\n0']
    assert split_args('4bfd\n0\n') == ['4bfd\n0\n']
    assert split_args('4bfd 0\n') == ['4bfd', '0\n']
    assert split_args('4bfd 0') == ['4bfd 0']
    assert split_args('"4bfd 0"') == ['"4bfd 0"']
    assert split_args('"4bfd" "0"') == ['"4bfd"', '"0"']
    assert split_args('4bfd "0"') == ['4bfd', '"0"']

# Generated at 2022-06-25 01:43:11.635472
# Unit test for function split_args
def test_split_args():
    # make sure single param with no spaces works
    assert split_args('foo') == ['foo'], 'single param with no spaces did not work'

    # make sure single param with spaces works
    assert split_args('foo bar') == ['foo bar'], 'single param with spaces did not work'

    # make sure multi-line arg works
    assert split_args('foo\nbar') == ['foo\nbar'], 'multi-line arg did not work'

    # make sure multi-line arg with no spaces works
    assert split_args('foo\nbar\nbaz') == ['foo\nbar\nbaz'], 'multi-line arg with no spaces did not work'

    # make sure quoted arg works

# Generated at 2022-06-25 01:43:20.985134
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=1 b=2 c="foo bar" d=\'bar foo\''
    var_0 = split_args(str_0)
    assert var_0 == ['a=1', 'b=2', 'c="foo bar"', "d='bar foo'"]

    str_0 = 'a=1 b=2 "c=foo" \'d=bar\''
    var_0 = split_args(str_0)
    assert var_0 == ['a=1', 'b=2', '"c=foo"', "'d=bar'"]

    str_0 = 'a==1'
    var_0 = split_args(str_0)
    assert var_0 == ['a==1']

    str_0 = 'a=1 b=2 c=\'foo\' d="bar"'
    var

# Generated at 2022-06-25 01:43:28.515539
# Unit test for function split_args
def test_split_args():
    print("Starting tests...")
    print("Test Case 0: ")
    test_case_0()
    print("Test Case 1")
    test_case_1()
    print("Test Case 2")
    test_case_2()
    print("Test Case 3")
    test_case_3()
    print("Test Case 4")
    test_case_4()
    print("Test Case 5")
    test_case_5()
    print("Test Case 6")
    test_case_6()
    print("Test Case 7")
    test_case_7()
    print("Test Case 8")
    test_case_8()
    print("Test Case 9")
    test_case_9()
    print("Test Case 10")
    test_case_10()
    print("Test Case 11")
    test_case_

# Generated at 2022-06-25 01:43:36.539466
# Unit test for function split_args
def test_split_args():
    # Equal
    assert split_args('4bfd') == ['4bfd'], 'Failed to split args to "4bfd"'
    # Equal
    assert split_args('4bfd\n') == ['4bfd'], 'Failed to split args to "4bfd\n"'
    # Equal
    assert split_args('4bfd\n5fd5') == ['4bfd', '5fd5'], 'Failed to split args to "4bfd\n5fd5"'
    # Equal
    assert split_args('4bfd\n5fd5\n4f3d') == ['4bfd', '5fd5', '4f3d'], 'Failed to split args to "4bfd\n5fd5\n4f3d"'
    # Equal

# Generated at 2022-06-25 01:43:47.382240
# Unit test for function split_args
def test_split_args():
    str_0 = '''a=b c="foo bar"'''
    var_0 = split_args(str_0)
    var_1 = [u'a=b', u'c="foo bar"']
    assert var_0 == var_1

    str_1 = '''a=b c="foo bar'''
    var_2 = split_args(str_1)
    var_3 = [u'a=b', u'c=\\"foo bar']
    assert var_2 == var_3

    str_2 = '''a=b c="foo bar\"'''
    
    str_3 = '''a=b c=\\"foo bar\"'''
    var_6 = split_args(str_3)

# Generated at 2022-06-25 01:43:58.244333
# Unit test for function split_args
def test_split_args():
    str_0 = '4bfd'
    var_0 = split_args(str_0)
    assert var_0 == ['4bfd']

    str_1 = '4bfd 6cafb'
    var_1 = split_args(str_1)
    assert var_1 == ['4bfd', '6cafb']

    str_2 = '4bfd 6cafb 5d'
    var_2 = split_args(str_2)
    assert var_2 == ['4bfd', '6cafb', '5d']

    str_3 = '4bfd 6cafb 5d \n c3'
    var_3 = split_args(str_3)
    assert var_3 == ['4bfd', '6cafb', '5d \n c3']

   

# Generated at 2022-06-25 01:44:04.804262
# Unit test for function split_args
def test_split_args():
    str_0 = '4bfd'
    var_0 = split_args(str_0)
    str_1 = '"4bfd"'
    var_1 = split_args(str_1)
    str_2 = "'4bfd'"
    var_2 = split_args(str_2)
    str_3 = '"4bfd"'
    var_3 = split_args(str_3)
    str_4 = "'4bfd'"
    var_4 = split_args(str_4)
    str_5 = '4bfd'
    var_5 = split_args(str_5)
    str_6 = '4bfd'
    var_6 = split_args(str_6)
    str_7 = '4bfd'

# Generated at 2022-06-25 01:44:14.039367
# Unit test for function split_args
def test_split_args():
    str_0 = '4bfd'
    var_0 = split_args(str_0)
    assert var_0[0] == '4bfd'
    str_1 = '""'
    var_1 = split_args(str_1)
    assert var_1[0] == ''
    str_2 = '"ob" "la"'
    var_2 = split_args(str_2)
    assert var_2[0] == 'ob'
    assert var_2[1] == '"la"'
    str_3 = '{# commet #}'
    var_3 = split_args(str_3)
    assert var_3[0] == '{# commet #}'
    str_4 = '{# commet #} # not a comment'
    var_4 = split_

# Generated at 2022-06-25 01:44:52.960915
# Unit test for function split_args

# Generated at 2022-06-25 01:44:55.335203
# Unit test for function split_args
def test_split_args():

    try:
        test_case_0()
    except Exception as e:
        print("Exception in test case 0: {}".format(e))
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(test_split_args())

# Generated at 2022-06-25 01:44:59.465752
# Unit test for function split_args
def test_split_args():
    try:
        test_case_0()
        print("Passed test case 0")
    except Exception as e:
        print("Failed test case 0: " + str(e))

# Call test function
test_split_args()

# Generated at 2022-06-25 01:45:05.020916
# Unit test for function split_args
def test_split_args():
    str_0 = '4bfd'
    str_0_result = ['4bfd']
    str_0_result = [unquote(x) for x in str_0_result]
    str_1 = '4bfd "a7" "f64" 15 12'
    str_1_result = ['4bfd', '"a7"', '"f64"', '15', '12']
    str_1_result = [unquote(x) for x in str_1_result]
    str_2 = '4bfd "a7" "f64" 15 12 "\\"hello\\""'
    str_2_result = ['4bfd', '"a7"', '"f64"', '15', '12', '"\\"hello\\""']

# Generated at 2022-06-25 01:45:13.449972
# Unit test for function split_args
def test_split_args():
    str_0 = '4bfd'
    var_0 = split_args(str_0)

    assert var_0 == ['4bfd'], "Arguments unparsed correctly"

    str_1 = '4bfd "4bfd"'
    var_1 = split_args(str_1)

    assert var_1 == ['4bfd', '4bfd'], "Arguments unparsed correctly"

    str_2 = '4bfd "4bfd 4bfd"'
    var_2 = split_args(str_2)

    assert var_2 == ['4bfd', '4bfd 4bfd'], "Arguments unparsed correctly"

    str_3 = "4bfd '4bfd 4bfd'"
    var_3 = split_args(str_3)

    assert var_3

# Generated at 2022-06-25 01:45:14.699262
# Unit test for function split_args
def test_split_args():
    # testcase_0
    test_case_0()

# Make the module executable.

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:45:19.210049
# Unit test for function split_args
def test_split_args():
    print("=== Test 1 ===")
    str_0 = '4bfd'
    var_0 = split_args(str_0)
    print("params", var_0)

    print("=== Test 2 ===")
    str_1 = '3e23 -u 1 -s "1 2" -s "3 4" -s "5 6" -s "7 8" -s "9 10" -s "11 12"'
    var_1 = split_args(str_1)
    print("params", var_1)

    print("=== Test 3 ===")
    str_2 = 'a=b c="foo bar"  {# comment #}'
    var_2 = split_args(str_2)
    print("params", var_2)

    print("=== Test 4 ===")

# Generated at 2022-06-25 01:45:20.018914
# Unit test for function split_args
def test_split_args():

    # Test case 0
    test_case_0()


test_split_args()

# Generated at 2022-06-25 01:45:29.854943
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    module.params['a'] = 1
    module.params['b'] = 2
    module.params['c'] = 3
    module.params['d'] = 4

    args = "{% for i in range(a, b - c * d) %} {{ i }}\n{% endfor %}"
    params = split_args(args)

    print(params)
    assert(params == ['{%', "for i in range(a, b - c * d)", '%}', '{{', 'i', '}}\n{%', 'endfor', '%}'])
    module.exit_json()


test_split_args()

# Generated at 2022-06-25 01:45:32.017953
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 01:46:46.945458
# Unit test for function split_args
def test_split_args():
  assert split_args('') == [], 'Empty string failed'
  assert split_args('"') == [], 'Empty string with quotes failed'
  assert split_args('\"\"') == [], 'Empty string with escaped quotes failed'
  assert split_args(' ') == [], 'Space failed'
  assert split_args('  ') == [], 'Double space failed'
  assert split_args('   ') == [], 'Triple space failed'
  assert split_args('a') == ['a'], 'Single character failed'
  assert split_args('a ') == ['a'], 'Single character with space failed'
  assert split_args('a  ') == ['a'], 'Single character with double space failed'
  assert split_args(' a') == ['a'], 'Single character with leading space failed'

# Generated at 2022-06-25 01:46:55.046063
# Unit test for function split_args
def test_split_args():
    # 0
    test_case_0()

    # 1
    str_0 = '4bfd=c5a6{\'8e85\': b1d1, \'3ba3\': +3f95, "9d9b": c3b2, "8dce": -3507.10096, "bda7": "8a81", "9d9b": bb93, "8dce": 3974.24173, "bda7": \'8e45\'}'
    var_0 = split_args(str_0)

# Generated at 2022-06-25 01:47:01.016191
# Unit test for function split_args
def test_split_args():

    var_0 = split_args('4bfd')
    assert var_0 == ['4bfd']

    var_1 = split_args('"4bfd"')
    assert var_1 == ['4bfd']

    var_2 = split_args('""')
    assert var_2 == ['']

    var_3 = split_args('" "')
    assert var_3 == [' ']

    var_4 = split_args('" a b "')
    assert var_4 == [' a b ']

    var_5 = split_args('" a b ""')
    assert var_5 == [' a b ']

    var_6 = split_args('" a b " ""')
    assert var_6 == [' a b ', '']

    var_7 = split_args('"" "a b"')
   

# Generated at 2022-06-25 01:47:06.433781
# Unit test for function split_args
def test_split_args():
    str_0 = 'var1=val1 var2=val2'
    str_1 = "var1=val1 var2='val2' var3='val3' var4='val 4' var5='val=5'"
    str_2 = "var1='val1 val2' var2=val2"
    str_3 = 'var1="val1 val2" var2=val2'
    str_4 = 'var1="val1 \'val2\'" var2=val2'
    str_5 = 'var1=\'val1 "val2"\' var2=val2'
    str_6 = "var1='val1 \"val2\"'"
    str_7 = 'var1=val1 var2="val2 var3=val3" var4=\'val4 var5=val5\''
    str

# Generated at 2022-06-25 01:47:13.342634
# Unit test for function split_args
def test_split_args():
    str_0 = '4bfd'
    var_0 = split_args(str_0)
    str_1 = '4bfd'
    var_1 = split_args(str_1)
    str_2 = '4bfd'
    var_2 = split_args(str_2)
    str_3 = '4bfd'
    var_3 = split_args(str_3)
    str_4 = '4bfd'
    var_4 = split_args(str_4)
    str_5 = '4bfd'
    var_5 = split_args(str_5)
    str_6 = '4bfd'
    var_6 = split_args(str_6)
    str_7 = '4bfd'
    var_7 = split_args(str_7)

# Generated at 2022-06-25 01:47:21.856159
# Unit test for function split_args
def test_split_args():
    fd = open("split_args.txt", "r")
    for i, j in zip(xrange(3), fd.readlines()):
        vars()['str_' + str(i)] = j
        vars()['arr_' + str(i)] = split_args(vars()['str_' + str(i)])

    assert arr_0 == ['4bfd']
    assert arr_1 == ['ls', '-l', '|', 'awk', '"{ print $9 }"']

# Generated at 2022-06-25 01:47:30.657701
# Unit test for function split_args
def test_split_args():
    str_0 = '4bfd-d12a-ed38-e2a2'
    var_0 = split_args(str_0)
    if var_0:
        print(var_0)
    str_1 = '4bfd-d12a-ed38-e2a2\n    alicia parr'
    var_1 = split_args(str_1)
    if var_1:
        print(var_1)
    str_2 = '4bfd-d12a-ed38-e2a2\n    alicia parr\n    alicia parr'
    var_2 = split_args(str_2)
    if var_2:
        print(var_2)

# Generated at 2022-06-25 01:47:31.792410
# Unit test for function split_args
def test_split_args():
    test_case_0()



# Generated at 2022-06-25 01:47:35.424384
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="foo bar"'
    var_0 = split_args(str_0)
    assert var_0[0] == 'a=b'
    assert var_0[1] == 'c="foo bar"'


# Generated at 2022-06-25 01:47:44.665121
# Unit test for function split_args
def test_split_args():

    def test_get_quote_state0():
        v0 = 'asdf'
        v0_quotes = _get_quote_state(v0, None)
        assert not v0_quotes, 'single quote 0'
        v1 = v0 + ' asd'
        v1_quotes = _get_quote_state(v1, v0_quotes)
        assert not v1_quotes, 'single quote 1'
        v2 = v1.replace('asd', "'asd'")
        v2_quotes = _get_quote_state(v2, v1_quotes)
        assert v2_quotes == "'", 'single quote 2'
        v0_quotes = _get_quote_state(v0, v2_quotes)