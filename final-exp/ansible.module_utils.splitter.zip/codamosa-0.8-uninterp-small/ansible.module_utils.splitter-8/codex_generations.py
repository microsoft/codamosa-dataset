

# Generated at 2022-06-25 01:39:12.677578
# Unit test for function split_args
def test_split_args():
    args_0 = 'enable secret 0 $1$ZQFO$/x/d0lh/Xc6UYTu6U0var0'
    args_1 = 'enable secret 0 $1$ZQFO$/x/d0lh/Xc6UYTu6U0var0'
    args_2 = 'enable secret 0 $1$ZQFO$/x/d0lh/Xc6UYTu6U0var0'
    args_3 = 'enable secret 0 $1$ZQFO$/x/d0lh/Xc6UYTu6U0var0'
    args_4 = 'enable secret 0 $1$ZQFO$/x/d0lh/Xc6UYTu6U0var0'

# Generated at 2022-06-25 01:39:21.488874
# Unit test for function unquote
def test_unquote():
    data = '"foo"'
    assert unquote(data) == 'foo'

    data = "'foo'"
    assert unquote(data) == 'foo'

    data = "'foo'"
    assert unquote(data) == 'foo'

    data = "'foo bar'"
    assert unquote(data) == 'foo bar'

    data = '"foo bar"'
    assert unquote(data) == 'foo bar'

    data = "'foo bar'"
    assert unquote(data) == 'foo bar'

    data = '"foo'
    assert unquote(data) == '"foo'

    data = '"foo'
    assert unquote(data) == '"foo'

    data = "'foo' bar"
    assert unquote(data) == "'foo' bar"

    data = '"foo" bar'

# Generated at 2022-06-25 01:39:23.748569
# Unit test for function unquote
def test_unquote():
    # test cases
    assert unquote('"hello"') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote(None) is None


# Generated at 2022-06-25 01:39:28.569719
# Unit test for function unquote
def test_unquote():
    print("In test_unquote()")

    # Call function unquote to remove first and last quotes from a string, if the string starts and ends with the same quotes
    c = '"Hello World"'
    print("Complex string : " + c)
    complex_str = unquote(c)
    print("String after removing first and last quotes : " + complex_str)


# Generated at 2022-06-25 01:39:39.139554
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == 0, "The given empty string is not quoted"
    assert is_quoted("test") == 0, "The given string is not quoted"
    assert is_quoted("\"test\"") == 1, "The given string is quoted"
    assert is_quoted("'test'") == 1, "The given string is quoted"
    assert is_quoted("\"test") == 0, "The given string is not quoted"
    assert is_quoted("'test") == 0, "The given string is not quoted"
    assert is_quoted("\"\"") == 1, "The given string is quoted"
    assert is_quoted("''") == 1, "The given string is quoted"
    assert is_quoted("\"") == 0, "The given string is not quoted"

# Generated at 2022-06-25 01:39:42.916359
# Unit test for function split_args
def test_split_args():
    import json
    with open('data/args.json') as data_file:    
        data = json.load(data_file)
    for item in data:
        a = item['args']
        b = item['result']
        s = split_args(a)
        if (s != b):
            raise Exception("Test failed for:(%s) exp (%s) got (%s)" % (a, b, s))

test_split_args()

# Generated at 2022-06-25 01:39:52.453160
# Unit test for function split_args
def test_split_args():
    assert split_args("a=1 b=2 c=3") == ['a=1', 'b=2', 'c=3']
    assert split_args("a=1 b=1 'c=1'") == ['a=1', 'b=1', 'c=1']
    assert split_args('a=1 b=1 "c=1"') == ['a=1', 'b=1', 'c=1']
    assert split_args('a=1 b="foo bar"') == ['a=1', 'b="foo bar"']
    assert split_args("a='foo bar'") == ['a="foo bar"']
    assert split_args('a={{ foo }} b="foo bar"') == ['a={{ foo }}', 'b="foo bar"']

# Generated at 2022-06-25 01:39:55.737249
# Unit test for function split_args
def test_split_args():
    # Input parameters
    args = None

    # Output
    result = split_args(args)
    assert (result is None)



# Generated at 2022-06-25 01:40:02.097231
# Unit test for function split_args
def test_split_args():
    assert split_args(None) == None
    assert split_args('stuff') == ['stuff']
    assert split_args('hello world') == ['hello', 'world']
    assert split_args('foo="bar baz"') == ['foo=bar baz']
    assert split_args('foo="bar \\"baz\\""') == ['foo=bar "baz"']
    assert split_args('foo="bar \'baz\'"') == ['foo=bar \'baz\'']
    assert split_args('foo="bar" baz="foo"') == ['foo=bar', 'baz=foo']
    assert split_args('foo="bar baz" "bar baz"') == ['foo=bar baz', 'bar baz']

# Generated at 2022-06-25 01:40:08.773316
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" echo') == ['a=b', 'c="foo bar"', 'echo']
    assert split_args('a=b c="foo bar" echo \\') == ['a=b', 'c="foo bar"', 'echo']
    assert split_args('a=b c="foo bar" echo \\ ') == ['a=b', 'c="foo bar"', 'echo']
    assert split_args('a=b c="foo bar" echo \\ \n   \\') == ['a=b', 'c="foo bar"', 'echo']

# Generated at 2022-06-25 01:40:24.850823
# Unit test for function split_args
def test_split_args():
    args_0 = 'a=b c="foo bar"'
    expected_result_0 = ['a=b', 'c="foo bar"']

    assert(split_args(args_0) == expected_result_0)

    args_1 = 'a=b c="foo bar" d="hello world"'
    expected_result_1 = ['a=b', 'c="foo bar"', 'd="hello world"']

    assert(split_args(args_1) == expected_result_1)



# Generated at 2022-06-25 01:40:30.615711
# Unit test for function split_args
def test_split_args():
    print('Testing split_args')
    try:
        complex_0 = '''a=b c="foo bar"'''
        var_0 = split_args(complex_0)
        print('  Results: %s' % var_0)
        assert(var_0 == ['a=b', 'c="foo bar"'])
    except Exception as e:
        print('Error: %s' % e)
        assert(False)


# Generated at 2022-06-25 01:40:40.619392
# Unit test for function split_args
def test_split_args():
    assert split_args("") == [""]
    assert split_args("  ") == [""]
    assert split_args("a") == ["a"]
    assert split_args("  a") == ["a"]
    assert split_args("a  ") == ["a"]
    assert split_args("  a  ") == ["a"]
    assert split_args(" a  b  c ") == ["a", "b", "c"]
    assert split_args("a b c") == ["a", "b", "c"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=\"b c\"") == ["a=\"b c\""]

# Generated at 2022-06-25 01:40:49.009319
# Unit test for function split_args
def test_split_args():
    #print("%s" % split_args("a=b c=\"foo bar\"",))
    #print("%s" % split_args("a=b c=\"foo bar"))
    #print("%s" % split_args("a=b c=\"foo bar\" d=\"\"e\""))

    print("%s" % split_args("-i hosts -a test {{ myvar | quote }}"))
    #print("%s" % split_args("a=b \"{{ \" c=\"foo bar\""))
    #print("%s" % split_args("a=b \"{{ \" c=\"foo bar\" d=\"\"e\""))
    #print("%s" % split_args("a=b c=\"foo bar\" d={{ \"\"e\" }}"))
    #print("%s" % split_args("a=b c=\"foo

# Generated at 2022-06-25 01:40:55.526677
# Unit test for function split_args

# Generated at 2022-06-25 01:41:04.983682
# Unit test for function split_args
def test_split_args():
    """
     Test case for split_args
     :return:
     """
    # Test case #1
    print("Running Test Case #1: ")
    test_case_1()

    # Test case #2
    print("Running Test Case #2: ")
    test_case_2()

    # Test case #3
    print("Running Test Case #3: ")
    test_case_3()

    # Test case #4
    print("Running Test Case #4: ")
    test_case_4()

    # Test case #5
    print("Running Test Case #5: ")
    test_case_5()

    # Test case #6
    print("Running Test Case #6: ")
    test_case_6()

    # Test case #7
    print("Running Test Case #7: ")

# Generated at 2022-06-25 01:41:11.688840
# Unit test for function split_args
def test_split_args():
    complex_0 = "a=b c=\"foo bar\""
    var_0 = split_args(complex_0)
    assert var_0 == ['a=b', 'c="foo bar"']
    
    complex_0 = "a=b c=\"foo bar\" d='foo bar'"
    var_0 = split_args(complex_0)
    assert var_0 == ['a=b', 'c="foo bar"', "d='foo bar'"]
    
    complex_0 = "a=b c='foo bar' d=\"foo bar\""
    var_0 = split_args(complex_0)
    assert var_0 == ['a=b', "c='foo bar'", 'd="foo bar"']

    complex_0 = """a=b c="foo bar" d='foo bar'
    """
    var

# Generated at 2022-06-25 01:41:19.902245
# Unit test for function split_args
def test_split_args():
    print("Testing split_args...")
    test_split_args_0()
    test_split_args_1()
    test_split_args_2()
    test_split_args_3()
    test_split_args_4()
    test_split_args_5()
    test_split_args_6()
    test_split_args_7()
    test_split_args_8()
    test_split_args_9()
    test_split_args_10()
    test_split_args_11()
    print("... Done!")


# Generated at 2022-06-25 01:41:29.388354
# Unit test for function split_args
def test_split_args():
    assert split_args("a=1 b=2 c=3") == ['a=1', 'b=2', 'c=3']
    assert split_args("a=1 'b 2' c=3") == ['a=1', "'b 2'", 'c=3']
    assert split_args("a=1 \"b 2\" c=3") == ['a=1', '"b 2"', 'c=3']
    assert split_args("a=1 \"b 2\" c=\"3 4\"") == ['a=1', '"b 2"', 'c="3 4"']
    assert split_args("a=1 \"b 2\" c=\"3 4\" d='5 6'") == ['a=1', '"b 2"', 'c="3 4"', "d='5 6'"]

# Generated at 2022-06-25 01:41:38.931481
# Unit test for function split_args
def test_split_args():
    print("\nUnit test for split_args()")
    print("string: \"a=b c=\\\"foo bar\\\"\"")
    args = "a=b c=\"foo bar\""
    params = split_args(args)
    print("\nresults")
    print(params)
    assert len(params) == 2
    assert params[0] == "a=b"
    assert params[1] == "c=\"foo bar\""

    print("\nstring: \"a=b c=\\\"foo=bar\\\"\"")
    args = "a=b c=\"foo=bar\""
    params = split_args(args)
    print("\nresults")
    print(params)
    assert len(params) == 2
    assert params[0] == "a=b"
    assert params[1]

# Generated at 2022-06-25 01:42:12.215347
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c=\\"foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\" foo') == ['a=b', 'c="foo bar" foo']
    assert split_args('a=b c="foo') == ['a=b', 'c="foo']

# Generated at 2022-06-25 01:42:24.202878
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='d f'") == ['a=b', "c='d f'"]
    assert split_args("a=b c=\"d f\"") == ['a=b', 'c="d f"']
    assert split_args("a=b 'c d' e='f g'") == ['a=b', "'c d'", "e='f g'"]
    assert split_args("a=b \"c d\" e=\"f g\"") == ['a=b', '"c d"', 'e="f g"']
    assert split_args("a=b 'c d' e=\"f g\"") == ['a=b', "'c d'", 'e="f g"']

# Generated at 2022-06-25 01:42:27.164856
# Unit test for function split_args
def test_split_args():
    args = 'echo hi'
    expected = ['echo', 'hi']
    result = split_args(args)
    assert expected == result


# Generated at 2022-06-25 01:42:35.810708
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("one") == ['one']
    assert split_args("one two") == ['one', 'two']
    assert split_args("one two three") == ['one', 'two', 'three']
    assert split_args('one "two" three') == ['one', '"two"', 'three']
    assert split_args('one \'two\' three') == ['one', '\'two\'', 'three']
    assert split_args('"one" "two" "three"') == ['"one"', '"two"', '"three"']
    assert split_args('\'one\' \'two\' \'three\'') == ['\'one\'', '\'two\'', '\'three\'']

# Generated at 2022-06-25 01:42:37.154437
# Unit test for function split_args
def test_split_args():
    assert split_args('echo "hello world"') == ['echo', '"hello world"']


# Generated at 2022-06-25 01:42:41.069085
# Unit test for function split_args
def test_split_args():
    complex_1 = "a=b c=\"foo bar\""
    var_1 = split_args(complex_1)
    assert var_1 == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 01:42:49.521970
# Unit test for function split_args
def test_split_args():
    # get the expected result
    correct_result = ['first=1', 'second=2', 'third=3', 'fourth="value 1 value 2"', 'fifth="value 1 value 2"', 'sixth="value 1 value 2"']

    # assemble the string to pass split_args
    string = 'first=1 second=2 third=3 fourth="value 1 value 2" fifth=\'value 1 value 2\' sixth="value 1 value 2"'

    result = split_args(string)

    assert result == correct_result, 'split_args failed!  {} != {}'.format(result, correct_result)
    print('split_args passed')


test_split_args()

# Generated at 2022-06-25 01:42:55.797727
# Unit test for function split_args
def test_split_args():
    args = 'ansible-pull -U git://github.com/spry-group/ansible-role-mod_ssl.git'
    assert split_args(args) == ['ansible-pull','-U','git://github.com/spry-group/ansible-role-mod_ssl.git']
    args = 'ansible-pull -U "git://github.com/spry-group/ansible-role-mod_ssl.git"'
    assert split_args(args) == ['ansible-pull','-U','git://github.com/spry-group/ansible-role-mod_ssl.git']
    args = 'ansible-pull -U "git://github.com/spry-group/ansible-role-mod_ssl.git" -i "/etc/ansible/hosts"'
    assert split_args

# Generated at 2022-06-25 01:43:04.661791
# Unit test for function split_args
def test_split_args():
    '''
    normal space splitting
    '''
    assert split_args("a b c") == ['a', 'b', 'c']

    '''
    double quoted with spaces
    '''
    assert split_args("a=\"b c\" d") == ["a=b c", "d"]

    '''
    double quoted with spaces and escaped double quotes
    '''
    assert split_args("a=\"b\\\"c\" d") == ["a=b\"c", "d"]

    '''
    double quoted with spaces and escaped backslash in double quotes
    '''
    assert split_args("a=\"b\\\\c\" d") == ["a=b\\c", "d"]

    '''
    double quoted with spaces and escaped quotes and backslash in double quotes
    '''

# Generated at 2022-06-25 01:43:14.718569
# Unit test for function split_args
def test_split_args():
    assert [u"a=b", u"c=\"foo bar\""] == split_args("a=b c=\"foo bar\"")
    assert [u"a=b", u"c=\"foo bar\""] == split_args("a=b c=\"foo bar\"")
    assert [u"a=b", u"c=\"foo bar", u"foo\""] == split_args("a=b c=\"foo bar\nfoo\"")
    assert [u"a=b", u"c=\"foo\nbar\""] == split_args("a=b c=\"foo\nbar\"")
    assert [u"a=b", u"c={{", u"foo", u"}}"] == split_args("a=b c={{ foo }}")

# Generated at 2022-06-25 01:43:53.179260
# Unit test for function split_args
def test_split_args():
    actual = split_args('{{ foo }} {{ bar }} {{ foobar }}')
    expected = ['{{', 'foo', '}}', '{{', 'bar', '}}', '{{', 'foobar', '}}']
    assert actual == expected, \
        "Actual result %s did not match expected result %s" % (actual, expected)

    actual = split_args('{{ foo }')
    expected = ['{{', 'foo', '}']
    assert actual == expected, \
        "Actual result %s did not match expected result %s" % (actual, expected)

    actual = split_args('foo="{{ foo }}" bar="{{ bar }}"')
    expected = ['foo="{{', 'foo', '}}"', 'bar="{{', 'bar', '}}"']

# Generated at 2022-06-25 01:44:01.010350
# Unit test for function split_args
def test_split_args():
    #
    # Function under test for unquoting simple quoted strings
    #
    complex_0 = "'simple'"
    var_0 = unquote(complex_0)
    assert var_0 == 'simple'

    #
    # Function under test for unquoting concatenated quoted strings
    #
    complex_1 = """ 'wow''ow'"""
    var_1 = unquote(complex_1)
    assert var_1 == 'wowow'

    #
    # Function under test for unquoting simple quoted strings with escaped quotes
    #
    complex_2 = ''' "wow\"ow" '''
    var_2 = unquote(complex_2)
    assert var_2 == 'wow"ow'

    #
    # Function under test for verifying that simple unquoted strings are not unquoted
    #
    complex_

# Generated at 2022-06-25 01:44:04.768285
# Unit test for function split_args
def test_split_args():
    # This is a basic test which verifies the function works with some simple data
    params = split_args("""{'msg': '"Hello world"'}""")
    assert params[0] == '{"msg": "Hello world"}'

# Generated at 2022-06-25 01:44:14.038558
# Unit test for function split_args

# Generated at 2022-06-25 01:44:20.949519
# Unit test for function split_args
def test_split_args():
    # check string with spaces and quotes
    result = split_args('a=b c="foo bar"')
    assert result[0] == 'a=b'
    assert result[1] == 'c="foo bar"'

    # check string with spaces and quotes and newlines
    result = split_args('a=b\nc="foo \n bar"')
    assert result[0] == 'a=b\n'
    assert result[1] == 'c="foo \n bar"'

    # check string with spaces and quotes and newlines and backslashes
    result = split_args('a=b\nc="foo \\\n bar"')
    assert result[0] == 'a=b\n'
    assert result[1] == 'c="foo \\\n bar"'

    # check string with spaces and quotes and newlines and escaped double

# Generated at 2022-06-25 01:44:30.571161
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('a=b') == ['a=b']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 01:44:37.162917
# Unit test for function split_args
def test_split_args():

    # Test run 1:
    complex_0 = "ssh -q -o UserKnownHostsFile='/dev/null' -o StrictHostKeyChecking=no foo"
    var_0 = split_args(complex_0)
    assert var_0 == ["ssh", "-q", "-o", "UserKnownHostsFile='/dev/null'", "-o", "StrictHostKeyChecking=no", "foo"]

    # Test run 2:
    complex_0 = "ssh -q -o UserKnownHostsFile='/dev/null' -o StrictHostKeyChecking=no foo"
    var_0 = split_args(complex_0)

# Generated at 2022-06-25 01:44:40.371844
# Unit test for function split_args
def test_split_args():
    test_args = 'foo=bar key="something value" "what'
    split_args_f = split_args(test_args)
    assert split_args_f == ['foo=bar', 'key="something value"', '"what']



# Generated at 2022-06-25 01:44:47.060877
# Unit test for function split_args
def test_split_args():
    test_complex_0 = """a=b c="foo bar" """
    result_complex_0 = split_args(test_complex_0)
    if result_complex_0 != ['a=b', 'c="foo bar"']:
        raise AssertionError("split_args(\"\"\"a=b c=\"foo bar\" \"\"\") returned \"\"\"", result_complex_0, "\"\"\" but expected \"\"\"['a=b', 'c=\"foo bar\"']\"\"\"")

    test_complex_1 = """a=b c="foo bar" """
    result_complex_1 = split_args(test_complex_1)

# Generated at 2022-06-25 01:44:52.770152
# Unit test for function split_args
def test_split_args():
    args = 'foo=bar and foo=bar'
    arg_list = split_args(args)
    assert len(arg_list) == 2
    assert arg_list[0] == 'foo=bar'
    assert arg_list[1] == 'and foo=bar'



# Generated at 2022-06-25 01:45:39.860299
# Unit test for function split_args
def test_split_args():
    test_case_0()


if __name__ == "__main__":
    # test_split_args()

    args = """a="c/d"
b=e
c=f"""
    # args = "a='foo bar' b='{{ foo }}' c='d \" e ' f=2'"
    # args = "a='foo bar' 'b={% foo %}' c='d \" e ' f=2'"
    # args = "a='foo bar' 'b={\"foo\": \"{{ foo }}\"}' c='d \" e ' f=2'"
    # args = "a='foo bar' 'b={\"foo\": \"{{ foo }}\"}' c='d \" e ' f=2' d={{ foo }}"
    # args = "a='foo bar' 'b={\"foo\": \"{{ foo }}

# Generated at 2022-06-25 01:45:48.319632
# Unit test for function split_args
def test_split_args():
    assert split_args("") == [], "Returned value did not match expected value"
    assert split_args("foo bar") == ['foo', 'bar'], "Returned value did not match expected value"
    assert split_args("foo\nbar") == ['foo\nbar'], "Returned value did not match expected value"
    assert split_args("foo \n bar") == ['foo', 'bar'], "Returned value did not match expected value"
    assert split_args("{{ foo }} bar") == ['{{', 'foo', '}} bar'], "Returned value did not match expected value"
    assert split_args("{{ foo }} \n bar") == ['{{ foo }} \n bar'], "Returned value did not match expected value"

# Generated at 2022-06-25 01:45:57.328225
# Unit test for function split_args
def test_split_args():
    complex_0 = "RicardianContracts.sol"
    complex_1 = "/RicardianContracts.sol  -D \"a=b\" "
    complex_2 = "/RicardianContracts.sol  -D 'a=b' "
    complex_3 = "a=b c=\"foo bar\""
    complex_4 = 'a=b c="foo bar"'
    complex_5 = "a=b c='foo bar'"
    complex_6 = 'a=b c="foo bar'
    complex_7 = 'a=b c="foo bar'
    complex_8 = "a=b c='foo bar'"
    complex_9 = "a=b c='foo bar"
    complex_10 = "a=b c=\"foo bar"

# Generated at 2022-06-25 01:46:03.727716
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b\\\nc=d") == ["a=b\nc=d"]
    assert split_args("a=b\\\\c=d") == ["a=b\\c=d"]
    assert split_args("a=b\\ c=d") == ["a=b c=d"]
    assert split_args("a=\"b c\"") == ['a="b c"']
    assert split_args("a=\"b\tc\"") == ['a="b\tc"']
    assert split_args("a=\"b c d\"") == ['a="b c d"']

# Generated at 2022-06-25 01:46:09.150644
# Unit test for function split_args
def test_split_args():
    in_str = 'a=b c="foo bar"'
    out_list = ['a=b', 'c="foo bar"']
    assert set(split_args(in_str)) == set(out_list), 'split_args returned unexpected result'


# Generated at 2022-06-25 01:46:10.437137
# Unit test for function split_args
def test_split_args():
    # assert split_args('ls {{ foo.bar }}') == ['ls', '{{ foo.bar }}']
    pass


# Generated at 2022-06-25 01:46:15.580418
# Unit test for function split_args
def test_split_args():
    # case 0
    test_case_0()

if __name__ == '__main__':
    # Run unittests in __main__
    test_split_args()

# Generated at 2022-06-25 01:46:24.108660
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo \\\nbar\"") == ['a=b', 'c="foo bar"']
    assert split_args(u"a=b c=\"foo \\\nbar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a={{b}} c=\"foo \\\nbar\"") == ['a={{b}}', 'c="foo bar"']
    assert split_args("a=b c=\"foo {{\\\nbar}}\"") == ['a=b', 'c="foo {{bar}}"']

# Generated at 2022-06-25 01:46:33.982466
# Unit test for function split_args
def test_split_args():
    complex_0 = 'a=b c="foo bar"'
    complex_1 = 'a=b c="foo\nbar"'
    complex_2 = 'a=b c="foo \nbar"'
    complex_3 = 'a=b c="foo\\\nbar"'
    complex_4 = 'a=b c="foo\\\nbar" d="{{ foo }}\n{% bar %}"'
    complex_5 = 'a=b c="foo\\\nbar" d="{{ foo }}\n{% bar %}"'
    complex_6 = 'var1=val1 var2=val2 var3="a b c" var4="a b c" var5=a\\ b\\ c'
    complex_7 = 'a=b c="foo \\bar"'

# Generated at 2022-06-25 01:46:35.854637
# Unit test for function split_args
def test_split_args():
    items = 'a=b c="foo bar"'
    result = split_args(items)
    assert result == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 01:47:17.165600
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 01:47:22.019724
# Unit test for function split_args
def test_split_args():
    assert unquote(split_args('V*$ |#z`@V(n4$?]S5S')[0]) == 'V*$'
    assert unquote(split_args('"V*$"|#z`@V(n4$?]S5S')[0]) == '"V*$"'
    assert unquote(split_args('a=b c="foo bar"')[0]) == 'a=b'
    assert unquote(split_args('a=b c="foo bar"')[1]) == 'c="foo bar"'
    assert unquote(split_args('a=b c="foo bar"')[0]) == 'a=b'
    assert unquote(split_args('a=b c={{ foo }}')[0]) == 'a=b'

# Generated at 2022-06-25 01:47:30.000151
# Unit test for function split_args
def test_split_args():
    str_0 = 'V*$ |#z`@V(n4$?]S5S'
    var_0 = split_args(str_0)
    assert var_0 == ['V*$', '|#z`@V(n4$?]S5S']

    str_1 = "\'{{ foo }}\' \'{% if 1 %}2{% endif %}\'"
    var_1 = split_args(str_1)
    assert var_1 == ["'{{ foo }}'", "'{% if 1 %}2{% endif %}'"]

    str_2 = "\'{# foo #}\' \'{# if 1 #}2{# endif #}\'"
    var_2 = split_args(str_2)

# Generated at 2022-06-25 01:47:40.585565
# Unit test for function split_args
def test_split_args():
    import os
    import sys
    import pytest
    if not os.path.exists('/tmp/ansible_test/ansible_modlib.utils.module_docs_fragments.test_split_args.txt'):
        pytest.skip("function test_split_args requires /tmp/ansible_test/ansible_modlib.utils.module_docs_fragments.test_split_args.txt")
    test_str_0 = read_file('/tmp/ansible_test/ansible_modlib.utils.module_docs_fragments.test_split_args.txt')
    test_var_0 = split_args(test_str_0)

# Generated at 2022-06-25 01:47:41.722825
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Main
if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:47:46.340295
# Unit test for function split_args
def test_split_args():
    # Make sure a simple string splits on space
    assert split_args('a b') == ['a', 'b'], "Failed to split on space"
    # Make sure quoted items are grouped
    assert split_args('a "b c"') == ['a', '"b c"'], "Failed to group quoted elements"
    # Make sure a string split on a newline concats back together
    assert split_args('a\nb') == ['a\nb'], "Failed to concat after a newline"
    # Make sure a string split on a newline concats back together (with space)
    assert split_args('a\n b') == ['a\n b'], "Failed to concat after a newline (with space)"
    # Make sure an unclosed quoted string concatenates

# Generated at 2022-06-25 01:47:57.186606
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b "c={{" d="}}"') == ['a=b', '"c={{"', 'd="}}"']
    assert split_args('a=b "c={{ d=}}"') == ['a=b', '"c={{ d=}}"']
    assert split_args('a=b c="{{foo}}"') == ['a=b', 'c="{{foo}}"']
    assert split_args('a=b c="{{foo}} {{bar}}"') == ['a=b', 'c="{{foo}} {{bar}}"']

# Generated at 2022-06-25 01:48:00.623787
# Unit test for function split_args
def test_split_args():
    str_0 = 'V*$ |#z`@V(n4$?]S5S'
    var_0 = split_args(str_0)
    var_1 = ['V*$', '|#z`@V(n4$?]S5S']
    assert var_0 == var_1



# Generated at 2022-06-25 01:48:07.090769
# Unit test for function split_args
def test_split_args():
    assert len(split_args('')) == 0
    assert len(split_args(' ')) == 0
    assert len(split_args('""')) == 1
    assert len(split_args('"foo"')) == 1
    assert len(split_args('"foo" "bar"')) == 2
    assert len(split_args('foo bar')) == 2
    assert len(split_args('foo bar "foo bar"')) == 3
    assert len(split_args('foo bar "foo bar" foo bar')) == 4
    assert len(split_args('foo bar "foo bar" foo bar baz')) == 5
    assert len(split_args('foo bar "foo "bar" bar" foo bar baz')) == 5

# Generated at 2022-06-25 01:48:17.703361
# Unit test for function split_args
def test_split_args():
    str_0 = 'V*$ |#z`@V(n4$?]S5S'
    var_0 = split_args(str_0)
    str_1 = '@['
    var_1 = split_args(str_1)
    str_2 = 'Y!=aR$jK\ncI2;'
    var_2 = split_args(str_2)
    str_3 = 'r8\n'
    var_3 = split_args(str_3)
    str_4 = 'V*$ |#z`@V(n4$?]S5S'
    var_4 = split_args(str_4)
    str_5 = 'V*$ |#z`@V(n4$?]S5S'