

# Generated at 2022-06-25 01:38:57.592456
# Unit test for function split_args
def test_split_args():
    if is_quoted(split_args()):
        raise AssertionError('Expected False, but got True')
    else:
        print('Test 1 passed')


# Generated at 2022-06-25 01:39:00.385633
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'C:\\Users\\zhangji\\Desktop\\MCS\\Testcases\\MCS-618\\mcs-618.py'") == True
    assert is_quoted("'C") == False
    assert is_quoted("this is not a quote") == False


# Generated at 2022-06-25 01:39:07.445022
# Unit test for function split_args
def test_split_args():
    # case 1
    bool_0 = True
    var_0 = split_args(bool_0)
    
    # case 2
    class_0 = Exception
    var_1 = split_args(class_0)
    
    # case 3
    int_0 = 99
    var_2 = split_args(int_0)
    
    # case 4
    float_0 = 9.9
    var_3 = split_args(float_0)


# Generated at 2022-06-25 01:39:11.490272
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") == True
    assert is_quoted("hello''") == False
    assert is_quoted("'hello") == False
    assert is_quoted('"hello"') == True
    assert is_quoted("hello\"") == False
    assert is_quoted('"hello') == False
    assert is_quoted('hello') == False
    assert is_quoted('123') == False


# Generated at 2022-06-25 01:39:17.508857
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Test if the script is called from the command line and that it does not return an error
if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:39:21.345197
# Unit test for function split_args
def test_split_args():

    test_string = 'abc def ghi'
    res_string = split_args(test_string)

    assert res_string == ['abc', 'def', 'ghi']


# Generated at 2022-06-25 01:39:31.100737
# Unit test for function split_args
def test_split_args():
    # bool_0 = False
    # var_0 = split_args(bool_0)
    # assert var_0 == bool_0
    bool_1 = True
    var_1 = split_args(bool_1)
    assert var_1 == bool_1

    test_0 = 'foo={{ foo }}'
    test_1 = "foo='foo bar'"
    test_2 = "foo='foo bar' bar={{ baz }}"
    test_3 = "foo=\"foo bar\" bar={{ baz }}"
    test_4 = "foo=\"foo bar\" bar='{{ baz }}'"
    test_5 = 'foo="foo bar" bar="{% if baz %} {{ baz }} {% endif %}"'

# Generated at 2022-06-25 01:39:37.047960
# Unit test for function split_args
def test_split_args():
    test_args = "a=b c d='e f g'"
    parse = split_args(test_args)
    assert parse == ['a=b', 'c', "d='e f g'"]



# Generated at 2022-06-25 01:39:43.453426
# Unit test for function split_args
def test_split_args():
    assert _get_quote_state("'test''test'", "'") == "'"
    assert _get_quote_state("test'test", None) == "'"
    assert _get_quote_state("test''test'", "'") == "'"
    assert _get_quote_state("test''test'", "'") == "'"
    assert _get_quote_state("test''test'", "'") is None
    assert _get_quote_state("'test''test", "'") is None
    assert _get_quote_state("test''test\"", None) == '"'
    assert _get_quote_state("test\"test", None) == '"'
    assert _get_quote_state("\"test\"test\"", '"') == '"'
    assert _get_quote_state("\"test\"test\"", '"') is None

# Generated at 2022-06-25 01:39:52.731239
# Unit test for function split_args
def test_split_args():
    cmd = "ls -l /a/b/c/d"
    out = split_args(cmd)
    assert out == ['ls', '-l', '/a/b/c/d'], 'basic command without quotes'
    cmd = "ls /a/b/c/d"
    out = split_args(cmd)
    assert out == ['ls', '/a/b/c/d']

    cmd = "ls -l '/a/b/c/d'"
    out = split_args(cmd)
    assert out == ['ls', '-l', "/a/b/c/d"], 'command with quoted strings'
    cmd = "ls -l /a/b/c/d | grep 'c/d'"
    out = split_args(cmd)

# Generated at 2022-06-25 01:40:08.317755
# Unit test for function split_args
def test_split_args():
    func = split_args
    good_string = 'hello world'
    result = func(good_string)
    assert result == ['hello world']

    bad_string = good_string + '"'
    result = func(bad_string)
    assert result == ['hello world"']

    bad_string = good_string + "'"
    result = func(bad_string)
    assert result == ['hello world\'']

    good_string = 'hello "world"'
    result = func(good_string)
    assert result == ['hello "world"']

    good_string = "hello 'world'"
    result = func(good_string)
    assert result == ["hello 'world'"]

    good_string = 'hello \\\'world\\\''
    result = func(good_string)

# Generated at 2022-06-25 01:40:11.626955
# Unit test for function split_args
def test_split_args():
    full_string = "a=b c={{ hello }} d='{{ hello }}'"
    split_args(full_string)


# Generated at 2022-06-25 01:40:19.709717
# Unit test for function split_args
def test_split_args():

    assert split_args("") == []
    assert split_args(" ") == []
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b c=d e=f") == ["a=b", "c=d", "e=f"]
    assert split_args("a=") == ["a="]
    assert split_args("a= b= c=") == ["a=", "b=", "c="]
    assert split_args("a=\"\"") == ["a=\"\""]
    assert split_args("a=''") == ["a=''"]
    assert split_args("a=\"b c\"") == ["a=\"b c\""]

# Generated at 2022-06-25 01:40:25.637241
# Unit test for function split_args
def test_split_args():
    json_test_input='''
    {
        "test_case_0":{
            "input":"test_input_0"
        },
        "test_case_1":{
            "input":"test_input_1"
        },
        "test_case_2":{
            "input":"test_input_2"
        }
    }
    '''

# Generated at 2022-06-25 01:40:32.456457
# Unit test for function unquote
def test_unquote():
    assert(unquote("'hello'") == 'hello')
    assert(unquote("hello") == 'hello')
    assert(unquote("'hello") == "'hello")
    assert(unquote("hello'") == "hello'")
    assert(unquote("\"hello\"") == 'hello')
    assert(unquote("\"hello") == "\"hello")
    assert(unquote("hello\"") == "hello\"")
    assert(unquote("\"he'llo\"") == "he'llo")
    assert(unquote("\"he\\\"llo\"") == "he\\\"llo")

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:40:36.451349
# Unit test for function unquote
def test_unquote():
    # Testcases for unquote
    assert(unquote("") == "")
    assert(unquote("test_string") == "test_string")
    assert(unquote("'test_string'") == "test_string")
    assert(unquote('"test_string"') == "test_string")
    assert(unquote("'''test_string'''") == "'''test_string'''")


# Generated at 2022-06-25 01:40:47.569043
# Unit test for function split_args
def test_split_args():
    assert split_args(True) == ['True'], \
        '''Function split_args must return ['True'] when True is provided'''
    assert split_args(None) == ['None'], \
        '''Function split_args must return ['None'] when None is provided'''
    assert split_args(False) == ['False'], \
        '''Function split_args must return ['False'] when False is provided'''
    assert split_args(0) == ['0'], \
        '''Function split_args must return ['0'] when 0 is provided'''
    assert split_args('') == [''], \
        '''Function split_args must return [''] when '' is provided'''

# Generated at 2022-06-25 01:40:58.114653
# Unit test for function unquote

# Generated at 2022-06-25 01:41:01.894169
# Unit test for function split_args
def test_split_args():
    print('Testing split_args')
    data = "a=b c='foo bar'"
    result = split_args(data)
    expected = ['a=b', "c='foo bar'"]
    if result == expected:
        print('split_args: OK')
    else:
        print('split_args: KO')
        print(">>split_args: expected: %s" % expected)
        print(">>split_args: result: %s" % result)



# Generated at 2022-06-25 01:41:11.361371
# Unit test for function split_args
def test_split_args():
    bool_1 = True
    var_1 = split_args(bool_1)
    assert var_1 == 'True'

    bool_2 = False
    var_2 = split_args(bool_2)
    assert var_2 == 'False'

    str_3 = 'a=b c="foo bar"'
    var_3 = split_args(str_3)
    assert var_3 == ['a=b', 'c="foo bar"']

    str_4 = 'a="b c"'
    var_4 = split_args(str_4)
    assert var_4 == ['a="b c"']

    str_5 = 'a="b\n c"'
    var_5 = split_args(str_5)
    assert var_5 == ['a="b\n c"']


# Generated at 2022-06-25 01:41:29.322341
# Unit test for function split_args
def test_split_args():
    expected = ['a=b', 'c="foo bar"', 'j=1', 'j="{{ foo }}"', 'j=\'{{ foo }}\'', 'j="{% if foo %}bar{% endif %}"',
                'j=\'{% if foo %}bar{% endif %}\'', 'k="foo', 'bar"', 'l="{# this is a comment #}foo"', 'm=\'{# this is a comment #}foo\'']

# Generated at 2022-06-25 01:41:38.856507
# Unit test for function split_args

# Generated at 2022-06-25 01:41:47.131774
# Unit test for function split_args
def test_split_args():
    str_0 = '\n    {\n        "test_case_0":{\n            "input":"test_input_0"\n        },\n        "test_case_1":{\n            "input":"test_input_1"\n        },\n        "test_case_2":{\n            "input":"test_input_2"\n        }\n    }\n    '
    str_1 = '{"arg":"-i "local_host," -u "user"," -m "raw"," -s -k"," -a "ll","" run_cmd_0","" run_cmd_1","" run_cmd_2"}'
    out_0 = split_args(str_0)
    out_1 = split_args(str_1)
    print(out_0)
    print(out_1)


# Generated at 2022-06-25 01:41:57.000280
# Unit test for function split_args
def test_split_args():
    # Test case 0
    str_0 = '\n    {\n        "test_case_0":{\n            "input":"test_input_0"\n        },\n        "test_case_1":{\n            "input":"test_input_1"\n        },\n        "test_case_2":{\n            "input":"test_input_2"\n        }\n    }\n    '
    # Test case 1
    str_1 = '    {\n        "test_case_0":{\n            "input":"test_input_0"\n        },\n        "test_case_1":{\n            "input":"test_input_1"\n        },\n        "test_case_2":{\n            "input":"test_input_2"\n        }\n    }    '

# Generated at 2022-06-25 01:42:07.746097
# Unit test for function split_args
def test_split_args():
    # test case 0
    str_0 = "a=b c=\"foo bar\""
    result = split_args(str_0)
    assert len(result) == 2
    assert result[0] == "a=b"
    assert result[1] == "c=\"foo bar\""

    # test case 1
    str_1 = "a=b\nc=\"foo bar\""
    result = split_args(str_1)
    assert len(result) == 2
    assert result[0] == "a=b"
    assert result[1] == "c=\"foo bar\""

    # test case 2
    str_2 = "a=b c=\"foo\nbar\""
    result = split_args(str_2)
    assert len(result) == 2

# Generated at 2022-06-25 01:42:15.024891
# Unit test for function split_args
def test_split_args():

    # test_case_0
    arg_0 = 'a=b c="foo bar"' 
    params_0 = split_args(arg_0)
    print(params_0)


    # test_case_1

    # test_case_2

    # test_case_3

    # test_case_4

    # test_case_5

    # test_case_6

    # test_case_7

    # test_case_8

    # test_case_9

    # test_case_10

    # test_case_11
    pass



# Generated at 2022-06-25 01:42:24.470058
# Unit test for function split_args
def test_split_args():

    # Test case 0
    args = "{{ foo }}"
    params = split_args(args)
    assert len(params) == 1
    assert params[0] == "{{ foo }}"

    # Test case 1
    args = "foo={{ foo }}"
    params = split_args(args)
    assert len(params) == 1
    assert params[0] == "foo={{ foo }}"

    # Test case 2
    args = "foo={{ foo }} bar=baz"
    params = split_args(args)
    assert len(params) == 2
    assert params[0] == "foo={{ foo }}"
    assert params[1] == "bar=baz"

    # Test case 3
    args = "foo={{ foo }} 'bar=baz'"
    params = split_args(args)


# Generated at 2022-06-25 01:42:30.368507
# Unit test for function split_args
def test_split_args():
    input_string = """
        {
            "test_case_0":{
                "input":"test_input_0"
            },
            "test_case_1":{
                "input":"test_input_1"
            },
            "test_case_2":{
                "input":"test_input_2"
            }
        }
        """

    param_list = split_args(input_string)
    for i in param_list:
        print(i)



# Generated at 2022-06-25 01:42:38.629943
# Unit test for function split_args

# Generated at 2022-06-25 01:42:42.982654
# Unit test for function split_args
def test_split_args():
    # str = '"{\\"test_case_0\\":{\\"input\\":\\"test_input_0\\"},\\"test_case_1\\":{\\"input\\":\\"test_input_1\\"},\\"test_case_2\\":{\\"input\\":\\"test_input_2\\"}}"'
    # result = split_args(str)
    # print(result)

    for i in range(100):
        test_case_0()



# Generated at 2022-06-25 01:43:02.777358
# Unit test for function split_args
def test_split_args():
    # Set up global and nonlocal variables
    global fail_count
    fail_count = 0

    # Test function
    global params, itemidx, idx, line_continuation, inside_quotes, was_inside_quotes
    global quote_char, print_depth, block_depth, comment_depth, prev_print_depth
    global prev_block_depth, prev_comment_depth
    global args
    args = '\n    {\n        "test_case_0":{\n            "input":"test_input_0"\n        },\n        "test_case_1":{\n            "input":"test_input_1"\n        },\n        "test_case_2":{\n            "input":"test_input_2"\n        }\n    }\n    '
    print_depth = 0


# Generated at 2022-06-25 01:43:11.750317
# Unit test for function split_args
def test_split_args():
    # Test split args
    print(split_args(""))
    print(split_args("name='value'"))
    print(split_args("name='value' name2=value2"))
    print(split_args("name='value'\nname2=value2"))
    print(split_args("name='value'\nname2=value2\\"))
    print(split_args("name='value' name2=value2\\\nname2=value2"))
    print(split_args("name=value name2='10 days'"))
    print(split_args("name=value name2='10 days'"))
    print(split_args("name=value name2='10 days'"))
    print(split_args("name=value name2='10 days' name3=value3"))

# Generated at 2022-06-25 01:43:21.068740
# Unit test for function split_args
def test_split_args():
    params = split_args('{{ foo }}')
    assert(len(params) == 1)
    assert(params[0] == '{{ foo }}')

    params = split_args('"{{ "foo }}"')
    assert(len(params) == 1)
    assert(params[0] == '"{{ "foo }}"')

    params = split_args('test\ntest\ntest')
    assert(len(params) == 3)
    assert(params[0] == 'test\n')
    assert(params[1] == 'test\n')
    assert(params[2] == 'test')

    params = split_args('test\\ntest\\ntest')
    assert(len(params) == 3)
    assert(params[0] == 'test\\')
    assert(params[1] == 'test\\')

# Generated at 2022-06-25 01:43:26.409221
# Unit test for function split_args
def test_split_args():
    '''
    Functionality to test the argument splitting function in utils
    '''
    # generate the test cases
    # an array of objects with input and output
    # input is a value to be split into an array
    # output is expected output
    test_cases = []
    for i in range(100):
        test_case = {}

        # generate input
        if i % 5 == 0:
            test_case['input'] = 'a=1 b=2 c="test \\"abc\\"" d=\\"test\\" e="test \\"abc\\""'
        if i % 5 == 1:
            test_case['input'] = '''a=1 b=2 c="test \\"abc\\"" d=\\"test\\" e="test \\"abc\\""'''
        if i % 5 == 2:
            test_

# Generated at 2022-06-25 01:43:35.811243
# Unit test for function split_args
def test_split_args():

    # a bunch quotes and jinja2 blocks
    params = split_args("ansible-playbook test.yml -i hosts --extra-vars \"@user_vars.yml\" -e \"{'imperative': 'yes'}\"")
    assert isinstance(params, list)
    assert params[0] == "ansible-playbook"
    assert params[1] == "test.yml"
    assert params[2] == "-i"
    assert params[3] == "hosts"
    assert params[4] == "--extra-vars"
    assert params[5] == "@user_vars.yml"
    assert params[6] == "-e"
    assert params[7] == "{'imperative': 'yes'}"

# Generated at 2022-06-25 01:43:40.675660
# Unit test for function split_args
def test_split_args():
    in_str = 'a=b c="foo bar"'
    out_list = ['a=b', 'c="foo bar"']
    assert split_args(in_str) == out_list

    in_str = '"this is a test" "foo bar"'
    out_list = ['"this is a test"', '"foo bar"']
    assert split_args(in_str) == out_list

    in_str = '"this is a test with spaces"'
    out_list = ['"this is a test with spaces"']
    assert split_args(in_str) == out_list

    in_str = 'a="this is a test with spaces"'
    out_list = ['a="this is a test with spaces"']
    assert split_args(in_str) == out_list


# Generated at 2022-06-25 01:43:48.756804
# Unit test for function split_args
def test_split_args():
    # Input data - string input to the split_args function
    test_data = [
        'a=b c="foo bar"',
        'a={{ b }} c="foo bar"',
        'a={{ b }} c="foo bar" {{ a }}',
        'a={{ b }} c="foo{{ a }}bar"',
        'a=b c=\'foo bar\'',
        'a={{ b }} c=\'foo bar\'',
        'a={{ b }} c=\'foo bar\' {{ a }}',
        'a={{ b }} c=\'foo{{ a }}bar\'',
    ]

    # Expected output

# Generated at 2022-06-25 01:43:58.285196
# Unit test for function split_args
def test_split_args():
    # print(split_args('"a" "b"'))
    # print(split_args('a=b c="foo bar"'))
    # print(split_args('a=b c="foo bar"'))
    # print(split_args('a=b \\ c="foo bar"'))
    print(split_args('\n    a=b c="foo bar"\n    '))
    print(split_args('\n    a=b c="foo bar"\n    '))
    print(split_args('\n    a=b c="foo bar"\n    '))


if __name__ == '__main__':
    # test_split_args()
    test_case_0()

# Generated at 2022-06-25 01:44:04.864296
# Unit test for function split_args
def test_split_args():
    # Test case 0
    str_0 = '"test" "arg" "with space"'
    result_0 = split_args(str_0)
    assert result_0 == ['test', 'arg', 'with space']

    # Test case 1
    str_1 = '"test" "arg" "with space \\n"'
    result_1 = split_args(str_1)
    print(result_1)
    assert result_1 == ['test', 'arg', 'with space \n']

    # Test case 2
    str_2 = '"test" "arg" "with space"'
    result_2 = split_args(str_2)
    assert result_2 == ['test', 'arg', 'with space']

    # Test case 3
    str_3 = '"test" "arg" "with space \\n"'


# Generated at 2022-06-25 01:44:14.039367
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="foo bar"'
    res_0 = ['a=b', 'c="foo bar"']
    output = split_args(str_0)
    print('Expected: {}'.format(res_0))
    print('Actual: {}'.format(output))
    assert output == res_0, "ERROR: split_args did not match output"

    str_0 = 'a=b c="foo bar" d="foo bar"'
    res_0 = ['a=b', 'c="foo bar"', 'd="foo bar"']
    output = split_args(str_0)
    print('Expected: {}'.format(res_0))
    print('Actual: {}'.format(output))
    assert output == res_0, "ERROR: split_args did not match output"

   

# Generated at 2022-06-25 01:44:57.134828
# Unit test for function split_args

# Generated at 2022-06-25 01:45:04.985523
# Unit test for function split_args
def test_split_args():
    # create the string
    str_0 = '\n    {\n        "test_case_0":{\n            "input":"test_input_0"\n        },\n        "test_case_1":{\n            "input":"test_input_1"\n        },\n        "test_case_2":{\n            "input":"test_input_2"\n        }\n    }\n    '

    # call the function
    print(split_args(str_0))

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:45:12.153863
# Unit test for function split_args
def test_split_args():
    str_0 = '\n    {\n        "test_case_0":{\n            "input":"test_input_0"\n        },\n        "test_case_1":{\n            "input":"test_input_1"\n        },\n        "test_case_2":{\n            "input":"test_input_2"\n        }\n    }\n    '
    params = split_args(str_0)
    print(params)


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:45:19.248600
# Unit test for function split_args
def test_split_args():
    # test case 0
    print("Test case 0:\n")
    str_0 = '\n    {\n        "test_case_0":{\n            "input":"test_input_0"\n        },\n        "test_case_1":{\n            "input":"test_input_1"\n        },\n        "test_case_2":{\n            "input":"test_input_2"\n        }\n    }\n    '
    print("Input: ", str_0)
    print("Output: ", split_args(str_0))

# Generated at 2022-06-25 01:45:20.225614
# Unit test for function split_args
def test_split_args():
    print('Start test_split_args')
    test_case_0()


# The main test logic

# Generated at 2022-06-25 01:45:25.240565
# Unit test for function split_args
def test_split_args():
    print("test_split_args")
    str_1 = 'a=b c="foo bar"'
    str_2 = 'a=b c="foo \n bar"'
    str_3 = 'a=b c="foo \n bar" d=e'
    str_4 = 'a=b c="foo bar" d=e'
    str_5 = 'd=e a=b c="foo bar"'
    str_6 = 'd=e a=b c="foo \n bar"'
    str_7 = 'd=e a=b c="foo \n bar" f=g'

    print("case 1 \n  input: 'a=b c=\"foo bar\"'")
    print("  expected result: ['a=b','c=\"foo bar\"']")

# Generated at 2022-06-25 01:45:33.541632
# Unit test for function split_args
def test_split_args():
    test_case_0()
    assert split_args("foo") == ['foo']
    assert split_args("foo bar baz") == ['foo', 'bar', 'baz']
    assert split_args("foo bar baz 'quoted arg'") == ['foo', 'bar', 'baz', 'quoted arg']
    assert split_args('foo bar baz "quoted arg"') == ['foo', 'bar', 'baz', 'quoted arg']
    assert split_args("foo bar 'mixed \"quoted\" arg'") == ['foo', 'bar', 'mixed "quoted" arg']
    assert split_args("'single quoted arg' bar") == ['single quoted arg', 'bar']

# Generated at 2022-06-25 01:45:39.884743
# Unit test for function split_args
def test_split_args():
    import json
    # Test for unbalanced jinja2 block
    try:
        split_args("foo {{ foo")
    except Exception:
        pass
    else:
        raise Exception("unbalanced jinja2 block test failed")

    # Test for unbalanced quotes
    try:
        split_args("foo 'bar")
    except Exception:
        pass
    else:
        raise Exception("unbalanced quotes test failed")

    # Test for simple args that are split on a space
    test1 = "test1 test2 test3"
    test1_params = split_args(test1)
    if len(test1_params) != 3:
        raise Exception("test for simple args that are split on a space failed")

# Generated at 2022-06-25 01:45:48.320649
# Unit test for function split_args

# Generated at 2022-06-25 01:45:54.162019
# Unit test for function split_args
def test_split_args():
    str_0 = '\n    {\n        "test_case_0":{\n            "input":"test_input_0"\n        },\n        "test_case_1":{\n            "input":"test_input_1"\n        },\n        "test_case_2":{\n            "input":"test_input_2"\n        }\n    }\n    '
    a = split_args(str_0)
    print(a)

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:47:21.896362
# Unit test for function split_args
def test_split_args():
    # Test: no quotes
    inputstr = 'key1=value1 key2=value2'
    result = split_args(inputstr)
    assert result == ['key1=value1', 'key2=value2']

    # Test: single-quote
    inputstr = "key1='value 1' key2=value2"
    result = split_args(inputstr)
    assert result == ["key1='value 1'", 'key2=value2']

    # Test: double quote
    inputstr = 'key1="value 1" key2=value2'
    result = split_args(inputstr)
    assert result == ['key1="value 1"', 'key2=value2']

    # Test: no quotes with newlines
    inputstr = 'key1=value1\nkey2=value2'

# Generated at 2022-06-25 01:47:29.898893
# Unit test for function split_args
def test_split_args():
    print(split_args('echo "this is a test"'))
    print(split_args('echo this is a test'))
    print(split_args('echo {{ foo }}'))
    print(split_args('echo {{ foo }} {{ bar }}'))
    print(split_args('echo {{ foo }} "bar baz"'))
    print(split_args('echo {{ foo }} "bar baz" {{ meh }}'))
    print(split_args('echo {{ foo }} "bar baz" {{ meh }}{{ bleh }}'))
    print(split_args('echo "foo bar" {{ baz }}'))
    print(split_args('echo "foo bar" {{ baz }} "biz baz"'))
    print(split_args('echo \'foo bar\' {{ baz }} "biz baz"'))

# Generated at 2022-06-25 01:47:40.473868
# Unit test for function split_args
def test_split_args():
    input = '''
    {
        "test_case_0":{
            "input":"test_input_0"
        },
        "test_case_1":{
            "input":"test_input_1"
        },
        "test_case_2":{
            "input":"test_input_2"
        }
    }
    '''

# Generated at 2022-06-25 01:47:49.743553
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']
    args = "a=b c='foo bar'"
    params = split_args(args)
    assert params == ['a=b', "c='foo bar'"]
    args = 'a=b c="""foo bar"""'
    params = split_args(args)
    assert params == ['a=b', 'c="""foo bar"""']
    args = 'a=b c="foo\nbar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo\nbar"']
    args = 'a=b c="foo\nbar\\\nspam"'
    params = split_args(args)

# Generated at 2022-06-25 01:48:00.024189
# Unit test for function split_args
def test_split_args():
    # Test case 0
    str_0 = "test_input_0"
    expected_result_0 = ['test_input_0']
    actual_result_0 = split_args(str_0)
    assert actual_result_0 == expected_result_0

    # Test case 1
    str_1 = "test_input_0 test_input_1"
    expected_result_1 = ['test_input_0', 'test_input_1']
    actual_result_1 = split_args(str_1)
    assert actual_result_1 == expected_result_1

    # Test case 2
    str_2 = '''test_input_0 test_input_1 test_input_2'''
    expected_result_2 = ['test_input_0', 'test_input_1', 'test_input_2']

# Generated at 2022-06-25 01:48:07.143758
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b \'c=foo bar\'') == ['a=b', "'c=foo bar'"]
    assert split_args('a=b "c=foo bar"') == ['a=b', '"c=foo bar"']
    assert split_args('a=\'b c="foo" bar\'') == ['a=\'b c="foo" bar\'']
    assert split_args('a=\'b c="foo" bar\'') == ['a=\'b c="foo" bar\'']
    assert split_args('a=\'b c="foo" bar\'') == ['a=\'b c="foo" bar\'']

# Generated at 2022-06-25 01:48:17.728055
# Unit test for function split_args
def test_split_args():
    # Test case 1:
    # This is the test case from the documentation string
    test_case_1_args = 'a=b c="foo bar"'
    test_case_1_expected_output = ['a=b', 'c="foo bar"']
    test_case_1_actual_output = split_args(test_case_1_args)
    assert test_case_1_expected_output == test_case_1_actual_output

    # Test case 2:
    # Test whitespace inside quotes
    test_case_2_args = 'a=b c=\'foo bar\''
    test_case_2_expected_output = ['a=b', 'c=\'foo bar\'']
    test_case_2_actual_output = split_args(test_case_2_args)
    assert test_case

# Generated at 2022-06-25 01:48:22.061462
# Unit test for function split_args
def test_split_args():
    # case 0
    str_0 = 'a=b c="foo bar"'
    args_0 = split_args(str_0)
    assert args_0 == ['a=b', 'c="foo bar"']
    # case 1
    str_1 = '''a=b c="foo bar"'''
    args_1 = split_args(str_1)
    assert args_1 == ['a=b', 'c="foo bar"']
    # case 2
    str_2 = r'''a=b c="foo bar"'''
    args_2 = split_args(str_2)
    assert args_2 == ['a=b', 'c="foo bar"']
    # case 3
    str_3 = '''a=b c="foo bar"'''

# Generated at 2022-06-25 01:48:29.437137
# Unit test for function split_args
def test_split_args():
    params = split_args("a=b c='foo bar' d='foo\" \\\"bar'")
    assert params == ["a=b", "c='foo bar'", 'd=\'foo" "bar\''], params

    params = split_args("a='foo bar' b=\"foo bar\"")
    assert params == ["a='foo bar'", 'b="foo bar"'], params

    params = split_args("a='b c' d='e\" f' g=\"h i\"")
    assert params == ["a='b c'", "d='e\" f'", 'g="h i"'], params

    params = split_args("a='b c' d='e\" f' g=\"h i\"")
    assert params == ["a='b c'", "d='e\" f'", 'g="h i"'], params

# Generated at 2022-06-25 01:48:38.844529
# Unit test for function split_args
def test_split_args():
    # Case 0
    str_0 = '\n    {\n        "test_case_0":{\n            "input":"test_input_0"\n        },\n        "test_case_1":{\n            "input":"test_input_1"\n        },\n        "test_case_2":{\n            "input":"test_input_2"\n        }\n    }\n    '
    expect_0 = '[\'{        "test_case_0":{            "input":"test_input_0"        },        "test_case_1":{            "input":"test_input_1"        },        "test_case_2":{            "input":"test_input_2"        }    }\']'
    assert(str(split_args(str_0)) == expect_0)

    #