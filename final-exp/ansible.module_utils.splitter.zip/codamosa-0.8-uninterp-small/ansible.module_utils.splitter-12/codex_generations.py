

# Generated at 2022-06-25 01:39:15.680217
# Unit test for function split_args
def test_split_args():
    assert split_args("x='foo bar'") == ['x=\'foo bar\''], """Expected [\'x=\\'foo bar\\''], got [%s]""" % split_args("x='foo bar'")
    assert split_args("x=foo bar") == ['x=foo', 'bar'], """Expected [\'x=foo\', \'bar\'], got [%s]""" % split_args("x=foo bar")
    assert split_args("x=\"foo bar\"") == ['x="foo bar"'], """Expected [\'x="foo bar"'], got [%s]""" % split_args("x=\"foo bar\"")

# Generated at 2022-06-25 01:39:23.664045
# Unit test for function split_args
def test_split_args():
    var_0 = split_args(u"git ls-remote...")
    var_1 = split_args(u"user='foo bar' other=1")
    var_2 = split_args(
        u"name: '{{ inventory_hostname }}' state: started listen: 127.0.0.1:{{ item }}")
    var_3 = split_args(u"curl -o new_file.html http://www.google.com/")
    var_4 = split_args(
        u"--name myservice -e constraint:node==myserver --no-resolve-image")
    var_5 = split_args(u"/usr/bin/foo --opt=val --opt2={{ ansible_ssh_host }}")
    var_6 = split_args(u"foo bar baz")
    var_

# Generated at 2022-06-25 01:39:32.921246
# Unit test for function split_args
def test_split_args():
    assert('server' == unquote(split_args('server')[0]))
    assert('server' == unquote(split_args('\'server\'')[0]))
    assert('server' == unquote(split_args('"server"')[0]))
    assert('server=y' == unquote(split_args('server=y')[0]))
    assert('server=y' == unquote(split_args('server="y"')[0]))
    assert('server="s\ny=m" t=po' == unquote(split_args('server="s\ny=m"\n t=po')[0]))
    assert('server="s\ny=m" t=po' == unquote(split_args('server="s\ny=m"\n t="po"')[0]))
   

# Generated at 2022-06-25 01:39:43.303629
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'a=b c="foo bar"'

    var_0 = split_args(bytes_0)
    assert var_0 == ['a=b', 'c="foo bar"']

    bytes_1 = b'\xaa\xf7!\xe3\xc3\x9b\xbc\xd7'
    var_1 = split_args(bytes_1)
    assert var_1 == ['\xaa\xf7!\xe3\xc3\x9b\xbc\xd7']

    bytes_2 = b"test {% if 1 > 2 %}"

    var_2 = split_args(bytes_2)
    assert var_2 == ['test', '{%', 'if', '1', '>', '2', '%}']



# Generated at 2022-06-25 01:39:46.030210
# Unit test for function split_args
def test_split_args():
    input = 'host="abc def" name=foo'
    expected = ['host="abc def"', 'name=foo']
    actual = split_args(input)
    assert actual == expected



# Generated at 2022-06-25 01:39:54.334371
# Unit test for function split_args

# Generated at 2022-06-25 01:40:01.980510
# Unit test for function split_args
def test_split_args():
    test_value = "  "
    result = split_args(test_value)
    assert(result == [])

    test_value = "A=b C=d"
    result = split_args(test_value)
    assert(result == ["A=b", "C=d"])

    test_value = "A=b\nC=d"
    result = split_args(test_value)
    assert(result == ["A=b\n", "C=d"])

    test_value = "A=b C=\"foo bar\""
    result = split_args(test_value)
    assert(result == ["A=b", "C=\"foo bar\""])

    test_value = "A=b C=\"foo bar\" D={{ foo }}"
    result = split_args(test_value)


# Generated at 2022-06-25 01:40:05.069876
# Unit test for function split_args
def test_split_args():
    # Assign input parameters to testcase variables.
    arg_0 = "foo=bar baz=qux"

    # Execute function.
    result_0 = split_args(arg_0)

    # Verify the expected results.
    assert result_0 == ['foo=bar', 'baz=qux']

# Generated at 2022-06-25 01:40:10.687454
# Unit test for function split_args
def test_split_args():
    # The following tests test for certain functionality within split_args
    # For instance, the first test checks if split_args can handle
    # an empty string, and the last tests the '\n' separation character
    # None of these tests are exhaustive, but they check for possible
    # issues and allow the function to be run at least once

    # Test case 0: simple case, no quotes
    bytes_0 = b'a=b c=d'
    var_0 = split_args(bytes_0)

    # Test case 1: no arguments
    bytes_1 = b''
    var_1 = split_args(bytes_1)

    # Test case 2: no arguments, but with the "separating" newline character
    bytes_2 = b'\n'
    var_2 = split_args(bytes_2)

    # Test case 3

# Generated at 2022-06-25 01:40:15.435738
# Unit test for function split_args
def test_split_args():

    # The args string to be parsed
    data = """a=b c="foo bar" d='foo bar' g={{ hi }} i={% jinja2 %} k={# oops #}"""

    # We expect these tokens to result after parsing
    expected = ['a=b', 'c="foo bar"', 'd=\'foo bar\'', 'g={{ hi }}', 'i={% jinja2 %}', 'k={# oops #}']

    # Split the args string using our function and make sure we get what we expect
    result = split_args(data)
    assert result == expected



# Generated at 2022-06-25 01:40:29.943912
# Unit test for function split_args
def test_split_args():
    assert split_args(b'test1\x00test2') == [b'test1\x00test2']


# Generated at 2022-06-25 01:40:32.236342
# Unit test for function split_args
def test_split_args():
    result_0 = split_args('a=b c="foo bar"')
    assert result_0 == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 01:40:33.381756
# Unit test for function split_args
def test_split_args():
    split_args('mkdir -p "{{ app_path }}"')


# Generated at 2022-06-25 01:40:40.017293
# Unit test for function split_args
def test_split_args():
    # Test normal string
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test escaped quotes
    args = 'a=b c="i am \\"a quoted\\" string" d=\'i am also quoted\''
    assert split_args(args) == ['a=b', 'c="i am \\"a quoted\\" string"', "d='i am also quoted'"]

    # Test template with escaped quotes
    args = 'c="{{ i am \\"a quoted\\" string }}"'
    assert split_args(args) == ['c="{{ i am \\"a quoted\\" string }}"']

    # Test template with escaped quotes

# Generated at 2022-06-25 01:40:46.862599
# Unit test for function split_args
def test_split_args():
    assert split_args('a=1 b="foo bar"') == ['a=1', 'b="foo bar"']


import ssl
import urllib.request, urllib.parse, urllib.error
import json

if hasattr(ssl, '_create_unverified_context'):
    ssl._create_default_https_context = ssl._create_unverified_context



# Generated at 2022-06-25 01:40:54.538848
# Unit test for function split_args
def test_split_args():
    result = split_args("a=b c=d")
    assert ['a=b', 'c=d'] == result
    result = split_args("a=b c=\"foo bar\"")
    assert ['a=b', 'c="foo bar"'] == result
    result = split_args("a=b c=\"foo bar\" d=\"{{{ foo bar }}}\"")
    assert ['a=b', 'c="foo bar"', 'd="{{{ foo bar }}}"'] == result
    result = split_args("a=b c='foo bar'")
    assert ['a=b', 'c=\'foo bar\''] == result
    result = split_args("a=b c='foo bar' d='{{{ foo bar }}}'")

# Generated at 2022-06-25 01:41:03.815483
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c={{cheeses}}") == ['a=b', 'c={{cheeses}}']
    assert split_args("a=b c=\"{{cheeses}}\"") == ['a=b', 'c="{{cheeses}}"']
    assert split_args("a=b c=\"foo\\\"{{cheeses}}\\\" bar\"") == ['a=b', 'c="foo\\"{{cheeses}}\\" bar"']
    assert split_args("a=b c=\"foo'{{cheeses}}' bar\"") == ['a=b', 'c="foo\'{{cheeses}}\' bar"']

# Generated at 2022-06-25 01:41:11.491140
# Unit test for function split_args
def test_split_args():
    args_0 = 'name=value'
    result = split_args(args_0)
    assert result == ['name=value']

    args_1 = 'name="value"'
    result = split_args(args_1)
    assert result == ['name="value"']

    args_2 = 'name=\'value\''
    result = split_args(args_2)
    assert result == ['name=\'value\'']

    args_3 = '"name=value'
    result = split_args(args_3)
    assert result == ['"name=value']

    args_4 = '"name"="value"'
    result = split_args(args_4)
    assert result == ['"name"="value"']

    args_5 = 'name="value1 value2"'

# Generated at 2022-06-25 01:41:22.509042
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"\nd=2') == ['a=b', 'c="foo bar"', 'd=2']
    assert split_args('a=b\n c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b\n c="foo bar"\nd=2') == ['a=b', 'c="foo bar"', 'd=2']
    assert split_args('a=b c=\\"foo bar\\"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 01:41:29.655516
# Unit test for function split_args

# Generated at 2022-06-25 01:41:50.509488
# Unit test for function split_args
def test_split_args():
    arg_0 = ''
    ret_0 = split_args(arg_0)
    print(ret_0)
    assert( ret_0 == [])

    arg_1 = 'a=b c="foo bar"'
    ret_1 = split_args(arg_1)
    print(ret_1)
    assert( ret_1 == ['a=b', 'c="foo bar"'])

    arg_2 = 'a=b c="foo bar"\nd=e f="{% if not is_windows %}foo bar{% else %}baz biz{% endif %}"'
    ret_2 = split_args(arg_2)
    print(ret_2)

# Generated at 2022-06-25 01:41:58.800342
# Unit test for function split_args

# Generated at 2022-06-25 01:41:59.996951
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 01:42:08.937189
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo') == ['a=b', 'c="foo']
    assert split_args('a=b c="foo\\') == ['a=b', 'c="foo\\']
    assert split_args('a=b c="foo\\\\') == ['a=b', 'c="foo\\\\']
    assert split_args('a=b c="foo\\"') == ['a=b', 'c="foo\\"']
    assert split_args('a=b c="foo\\"bar"') == ['a=b', 'c="foo\\"bar"']

# Generated at 2022-06-25 01:42:10.063785
# Unit test for function split_args
def test_split_args():
    assert split_args(b'"foo bar"') == [b'"foo bar"']



# Generated at 2022-06-25 01:42:14.426692
# Unit test for function split_args
def test_split_args():
    # These variables hold the test cases.
    split_args_var_0 = b'foo'
    split_args_var_1 = b'one=1 two=2'

    # Call the function to actually run the test.
    split_args(split_args_var_0)

    # Call the function to actually run the test.
    split_args(split_args_var_1)

test_case_0()
test_split_args()

# Generated at 2022-06-25 01:42:19.170110
# Unit test for function split_args
def test_split_args():
    # test case 0
    args_0 = 'a="{{foo" bar={{baz}}'
    var_0 = split_args(args_0)
    assert len(var_0) == 4, "split_args returned wrong number of items: expected 4, got %d" % len(var_0)

    # test case 1
    args_1 = 'a=b\nc="foo bar"'
    var_1 = split_args(args_1)
    assert len(var_1) == 3, "split_args returned wrong number of items: expected 3, got %d" % len(var_1)

    # test case 2
    args_2 = '-a -vvv -b 1 2 3 4'
    var_2 = split_args(args_2)

# Generated at 2022-06-25 01:42:28.346670
# Unit test for function split_args
def test_split_args():
    arguments = """a=b
    c=d
    b={% if 1 %}
    foo
    {% endif %}
    """
    answer = split_args(arguments)
    assert answer == ['a=b', 'c=d', 'b={% if 1 %}\n    foo\n    {% endif %}\n   ']

    arguments = """a=b
    c=d
    b={{ 'foo' | baz }}"""
    answer = split_args(arguments)
    assert answer == ['a=b', 'c=d', 'b={{ \'foo\' | baz }}\n   ']

    arguments = "{% if 1 %}foo{% endif %}"
    answer = split_args(arguments)
    assert answer == ['{% if 1 %}foo{% endif %}']

   

# Generated at 2022-06-25 01:42:36.850985
# Unit test for function split_args
def test_split_args():
    line = '"foo bar" baz="foo bar" "baz bah"'
    params = ['foo bar', 'baz=foo bar', 'baz bah']
    result = split_args(line)
    assert params == result

    line = 'foo bar baz="foo bar" "baz bah"'
    params = ['foo', 'bar', 'baz=foo bar', 'baz bah']
    result = split_args(line)
    assert params == result



# Generated at 2022-06-25 01:42:42.607486
# Unit test for function split_args
def test_split_args():
    print("Testing split_args function")
    test_cases = list()
    test_cases.append(('a=b', ['a=b']))
    test_cases.append(('', []))
    test_cases.append(('a="b', ['a="b']))
    test_cases.append(('a=b c="foo bar"', ['a=b', 'c="foo bar"']))
    test_cases.append(('"', ['"']))
    test_cases.append(("'", ["'"]))
    test_cases.append(("'\"", ["'\""]))
    test_cases.append(("\"'", ["\"'"]))
    test_cases.append(("'\"'", ["'\"'"]))

# Generated at 2022-06-25 01:43:02.230297
# Unit test for function split_args
def test_split_args():
    args_0 = "a=b c=\"foo bar\""
    split_0 = split_args(args_0)

    assert split_0 == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 01:43:11.520048
# Unit test for function split_args
def test_split_args():
    PARAMS_0 = ['foo', 'bar', '"b az"']
    assert split_args('foo bar "b az"') == PARAMS_0

    PARAMS_1 = ['"b az"', 'foo', 'bar']
    assert split_args('"b az" foo bar') == PARAMS_1

    PARAMS_2 = ['foo', 'bar', 'b" az"']
    assert split_args('foo bar b" az"') == PARAMS_2

    PARAMS_3 = ['foo', 'bar', '"b az"']
    assert split_args('foo bar "b az"') == PARAMS_3

    PARAMS_4 = ['foo', 'bar', 'b" az"']
    assert split_args('foo bar b" az"') == PARAMS_4


# Generated at 2022-06-25 01:43:20.879294
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b 'c d'") == ["a=b", "'c d'"]
    assert split_args("a=b 'c d' e='f g' 2>&1") == ["a=b", "'c d'", "e='f g'", "2>&1"]
    assert split_args("a=b '{{ foo }}'") == ["a=b", "'{{ foo }}'"]
    assert split_args("a=b \"{{ foo }}\"") == ['a=b', '"{{ foo }}"']
    assert split_args("a=b 'c d' e=\"f g\"") == ['a=b', "'c d'", 'e="f g"']
    assert split_args

# Generated at 2022-06-25 01:43:26.226384
# Unit test for function split_args
def test_split_args():
    var_0 = split_args(u'a=b c="foo bar"')
    var_1 = split_args(u'a=b c="foo bar"')
    var_2 = split_args(u'')
    var_3 = split_args(u'{# comment #} {#')
    var_4 = split_args(u"{{ '{#' }}")
    var_5 = split_args(u"{{ '{#' }}")
    var_6 = split_args(u'{{ \'{#\' }}')
    var_7 = split_args(u'{{ \'{#\' }}')
    var_8 = split_args(u"{{ '{#' }}")
    var_9 = split_args(u'a=b c="foo bar"')
    var_10 = split_args

# Generated at 2022-06-25 01:43:35.629294
# Unit test for function split_args

# Generated at 2022-06-25 01:43:42.207455
# Unit test for function split_args
def test_split_args():
    # for example, when the args are "a=b c=d" we want ['a=b', 'c=d']
    params = split_args("a=b c=d")
    assert params == ['a=b', 'c=d']

    # when the args are a=b "c d" we want ['a=b', '"c d"']
    params = split_args('a=b "c d"')
    assert params == ['a=b', '"c d"']

    # when the args are "a=b c=d" "foo bar" we want ['a=b c=d', 'foo bar']
    params = split_args('"a=b c=d" "foo bar"')
    assert params == ['a=b c=d', 'foo bar']

    # when the args are a=b

# Generated at 2022-06-25 01:43:52.798461
# Unit test for function split_args
def test_split_args():
    print("test_split_args()")

# Generated at 2022-06-25 01:44:00.775477
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common._collections_compat import Sequence
    assert callable(split_args)
    # Call split_args with correct args
    params = split_args("a=b c=\"foo bar\"")
    assert isinstance(params, list)
    assert params == ['a=b', 'c="foo bar"']

    params = split_args("a=b c=\"foo bar\" ")
    assert isinstance(params, list)
    assert params == ['a=b', 'c="foo bar"']

    params = split_args("")
    assert isinstance(params, list)
    assert params == []

    params = split_args(" ")
    assert isinstance(params, list)
    assert params == []

    params = split_args("a=b c='foo bar'")

# Generated at 2022-06-25 01:44:09.068553
# Unit test for function split_args
def test_split_args():
    # Test cases
    tokens = split_args('a="foo bar"')
    assert tokens == ['a="foo bar"']
    tokens = split_args('a=b c="foo bar"')
    assert tokens == ['a=b', 'c="foo bar"']
    tokens = split_args('a=b c="foo bar" d="foo bar"')
    assert tokens == ['a=b', 'c="foo bar"', 'd="foo bar"']
    tokens = split_args('a=b c="foo bar" d="foo bar" e=f')
    assert tokens == ['a=b', 'c="foo bar"', 'd="foo bar"', 'e=f']
    tokens = split_args('a=b\nc=d')
    assert tokens == ['a=b', '\nc=d']
    tokens

# Generated at 2022-06-25 01:44:14.586538
# Unit test for function split_args
def test_split_args():
    input_str = 'a=b c="foo bar"'
    expected_output = ['a=b', 'c="foo bar"']
    assert split_args(input_str) == expected_output

# Generated at 2022-06-25 01:44:32.787378
# Unit test for function split_args
def test_split_args():
    bytes_0 = b"a=b c=\"foo bar\""
    list_0 = split_args(bytes_0)
    list_1 = ['a=b', 'c="foo bar"']
    assert list_0 == list_1


# Generated at 2022-06-25 01:44:38.689756
# Unit test for function split_args
def test_split_args():
    assert split_args('nmcli connection show') == ['nmcli', 'connection', 'show']
    assert split_args('nmcli connection show --active') == ['nmcli', 'connection', 'show', '--active']
    assert split_args('nmcli connection show -a') == ['nmcli', 'connection', 'show', '-a']
    assert split_args('nmcli connection show --a') == ['nmcli', 'connection', 'show', '--a']
    assert split_args('nmcli connection show --active -a') == ['nmcli', 'connection', 'show', '--active', '-a']

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:44:45.416080
# Unit test for function split_args

# Generated at 2022-06-25 01:44:53.063818
# Unit test for function split_args
def test_split_args():
    bytes_0 = b"rc: CUDaWyBpcyBqdXN0IGEgc21hbGwgdGhpbmcK"
    bytes_1 = b'\xa7\xcf\xf9\x9f\x15\x84\x87\xde\xcb\xb4\xb0\xc4\xa4\x13\x8d\xca\x06\x0e\x0b\x12\xd5\xf1\xed\x14'

# Generated at 2022-06-25 01:45:03.103254
# Unit test for function split_args

# Generated at 2022-06-25 01:45:13.085862
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'"a abc def" abc def'
    bytes_1 = b"abc"
    bytes_2 = b'b1="a abc def" b2="a abc def" b3="a abc def"'
    bytes_3 = b'a1=b1 a2="b2 c2" a3=b3 a4="b4 c4"'
    var_0 = split_args(bytes_0)
    var_1 = split_args(bytes_1)
    var_2 = split_args(bytes_2)
    var_3 = split_args(bytes_3)


if __name__ == '__main__':
    test_split_args()
    test_case_0()

# Generated at 2022-06-25 01:45:22.702408
# Unit test for function split_args
def test_split_args():
    # Testcase1
    var_1 = split_args("a=b c='foo bar' d=\"foo bar\" e='\"' f=\"'\" g=\\h i=j\\\\")
    assert var_1 == ['a=b', "c='foo bar'", 'd="foo bar"', "e='\"'", 'f="\'"', "g=\\h", "i=j\\\\"]

    # Testcase2
    var_2 = split_args("a=b{{a}}c 'foo bar' d=\"foo bar\" e='\"'{{b}}{#c#}f=\"'\"{{d}}h i=j\\\\")

# Generated at 2022-06-25 01:45:30.892891
# Unit test for function split_args
def test_split_args():
    assert unquote("hi") == "hi"
    assert unquote("\"hi\"") == "hi"
    assert unquote("'hi'") == "hi"
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', 'c=\'foo bar\'']
    assert split_args("a=b c=\"foo 'bar'\"") == ['a=b', 'c="foo \'bar\'"']
    assert split_args("a=b c=\"foo 'bar\"") == ['a=b', 'c="foo \'bar"']
    assert split_args("a=b c='foo \"bar'") == ['a=b', 'c=\'foo "bar\'']

# Generated at 2022-06-25 01:45:39.725996
# Unit test for function split_args

# Generated at 2022-06-25 01:45:44.647220
# Unit test for function split_args
def test_split_args():
    myvar = split_args("echo hello world")
    assert(myvar == ['echo', 'hello', 'world'])
    myvar = split_args("echo 'echo hello world'")
    assert(myvar == ["echo 'echo hello world'"])
    myvar = split_args("echo 'echo hello \nworld!'")
    assert(myvar == ["echo 'echo hello \nworld!'"])
    myvar = split_args("echo 'echo hello \nworld!'\n")
    assert(myvar == ["echo 'echo hello \nworld!'\n"])
    myvar = split_args("echo 'echo hello \nworld!'\\\n")
    assert(myvar == ["echo 'echo hello \nworld!'\\\n"])

# Generated at 2022-06-25 01:46:10.001116
# Unit test for function split_args
def test_split_args():
    args = '-f "foo bar baz" --foo bar'
    params = split_args(args)

    if len(params) != 3:
        raise Exception(params)

    if params[0] != '-f':
        raise Exception(params)
    if params[1] != '"foo bar baz"':
        raise Exception(params)
    if params[2] != '--foo bar':
        raise Exception(params)



# Generated at 2022-06-25 01:46:19.689890
# Unit test for function split_args
def test_split_args():
    string_0 = '{\x00"'
    string_1 = 'd>\x7f`0\xdb\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 01:46:23.777545
# Unit test for function split_args
def test_split_args():
    # Testcase 0
    test_case_0()

test_split_args()

# Generated at 2022-06-25 01:46:33.698809
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo = bar') == ['foo = bar']
    assert split_args('foo="bar baz"') == ['foo=bar baz']
    assert split_args(r'foo="bar \"baz\""') == ['foo=bar "baz"']
    assert split_args(r'foo=\'bar \"baz\"\'') == ['foo=bar "baz"']
    assert split_args(r'foo="bar \"baz\" \\\" test"') == ['foo=bar "baz" \\" test']

# Generated at 2022-06-25 01:46:40.462304
# Unit test for function split_args
def test_split_args():
    assert split_args("echo hello") == ["echo", "hello"]
    assert split_args("echo 'hello world'") == ["echo", "'hello world'"]
    assert split_args("echo 'hello world' > /tmp/test") == ["echo", "'hello world'", ">", "/tmp/test"]
    assert split_args("echo 'hello world'|wc -l") == ["echo", "'hello world'", "|", "wc", "-l"]
    assert split_args("echo 'hello world'|wc -l > /tmp/test") == ["echo", "'hello world'", "|", "wc", "-l", ">", "/tmp/test"]

# Generated at 2022-06-25 01:46:47.858113
# Unit test for function split_args
def test_split_args():
    # args = 'git repo:https://server.com/org/project_name.git dest=directory update=no force=yes track_submodules=no'
    args = 'update=no force=yes track_submodules=no'
    params = split_args(args)
    assert len(params) == 3, 'Invalid params length: {}'.format(params)
    assert params[0] == 'update=no', 'Invalid argument: {}'.format(params[0])
    assert params[1] == 'force=yes', 'Invalid argument: {}'.format(params[0])
    assert params[2] == 'track_submodules=no', 'Invalid argument: {}'.format(params[0])

if __name__ == "__main__":
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:46:52.906975
# Unit test for function split_args
def test_split_args():
    assert split_args('/bin/echo "hi there"') == ['/bin/echo', '"hi there"']
    assert split_args('/bin/echo "hi there') == ['/bin/echo', '"hi there']
    assert split_args('/bin/echo hi \nthere') == ['/bin/echo', 'hi', 'there']
    assert split_args('/bin/echo hi \nthere') == ['/bin/echo', 'hi', 'there']
    assert split_args('/bin/echo "hi \nthere"') == ['/bin/echo', '"hi \nthere"']
    assert split_args("/bin/echo 'hi \nthere'") == ['/bin/echo', "'hi \nthere'"]

# Generated at 2022-06-25 01:46:59.773291
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b c="foo bar']
    assert split_args('a=b c="foo\nbar') == ['a=b', 'c="foo\nbar']
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']
    assert split_args('a=b c="foo\\nbar"') == ['a=b', 'c="foo\\nbar"']
    assert split_args('"\\""') == ['\\""']
    assert split_args('"\\"" ') == ['\\"" ']

# Generated at 2022-06-25 01:47:01.325686
# Unit test for function split_args
def test_split_args():
    arg_str = "a=b c=\"foo bar\""
    res_list = split_args(arg_str)
    assert(res_list == ['a=b', 'c="foo bar"'])



# Generated at 2022-06-25 01:47:08.350411
# Unit test for function split_args
def test_split_args():
    # Defining the expected result
    expected_result = ['a=b', 'c="foo bar"']

    # Defining the input data
    data = 'a=b c="foo bar"'

    # Defining the expected result
    actual_result = split_args(data)

    assert actual_result == expected_result, "Actual Result '%' is not equal to Expected Result '%s'" % (actual_result, expected_result)

# Generated at 2022-06-25 01:47:32.434877
# Unit test for function split_args
def test_split_args():
    print('test split_args')
    result = split_args('foo=bar')
    assert len(result) == 1
    assert result[0] == 'foo=bar'

    result = split_args('foo=bar baz=quux')
    assert len(result) == 2
    assert result[0] == 'foo=bar'
    assert result[1] == 'baz=quux'

    result = split_args('foo=bar "baz quux"')
    assert len(result) == 2
    assert result[0] == 'foo=bar'
    assert result[1] == '"baz quux"'

    result = split_args('foo=bar "baz quux"  ')
    assert len(result) == 2
    assert result[0] == 'foo=bar'

# Generated at 2022-06-25 01:47:40.926631
# Unit test for function split_args
def test_split_args():
    # Test parameters
    args = 'a=b c="foo bar" d="a \\"b\\""'
    expected_result = ['a=b', 'c="foo bar"', 'd="a \\"b\\""']
    # Execute the run
    result = split_args(args)
    # Verify the results
    assert(expected_result == result)


if __name__ == '__main__':
    print("Testing split_args...")
    test_split_args()
    print("Success.")

    print("Testing is_quoted...")
    test_case_0()
    print("Success.")

# Generated at 2022-06-25 01:47:47.412745
# Unit test for function split_args
def test_split_args():
    # From ansible module network_cli
    # test_data = '{{lookup(\"template\", \"mytemplate.j2\")}}'
    test_data = 'gateway 192.168.0.254'
    res = split_args(test_data)
    assert res == ['gateway', '192.168.0.254']


if __name__ == '__main__':
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:47:58.217829
# Unit test for function split_args
def test_split_args():
    assert not is_quoted(b'a=b c="foo bar"')
    assert split_args(b'a=b c="foo bar"') == [b'a=b', b'c="foo bar"']
    assert split_args(b'a=b c=foo\\ bar') == [b'a=b', b'c=foo bar']
    assert split_args(b'foo\\ bar') == [b'foo bar']
    assert split_args(b'a=b c="foo\\ bar"') == [b'a=b', b'c="foo\\ bar"']
    assert split_args(b'a=b c="foo\\ bar"') != [b'a=b', b'c="foo bar"']

# Generated at 2022-06-25 01:48:01.833638
# Unit test for function split_args
def test_split_args():
    # Test args
    test_arg = 'a=b c="foo bar"'
    # Expected result
    expected_result = ['a=b', 'c="foo bar"']
    # Actual result
    actual_result = split_args(test_arg)
    print(actual_result)
    print(expected_result)
    assert expected_result == actual_result


# Generated at 2022-06-25 01:48:03.277032
# Unit test for function split_args
def test_split_args():
    arguments = 'echo foo'
    result = split_args(arguments)
    assert result == ['echo', 'foo']


# Generated at 2022-06-25 01:48:11.639269
# Unit test for function split_args
def test_split_args():

    data = """
      --bacon  'foo bar'   /usr/bin/yes  "this is the way"    -u root   -awesome='very much'   c="foo bar"
    """

    params = split_args(data)

    assert len(params) == 8
    assert params[0] == "--bacon"
    assert params[1] == "'foo bar'"
    assert params[2] == "/usr/bin/yes"
    assert params[3] == "\"this is the way\""
    assert params[4] == "-u"
    assert params[5] == "root"
    assert params[6] == "-awesome='very much'"
    assert params[7] == "c=\"foo bar\""



# Generated at 2022-06-25 01:48:18.648729
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=foo\nbar') == ['a=foo\nbar']
    assert split_args('a=foo\nbar b=baz') == ['a=foo\nbar', 'b=baz']
    assert split_args('a=b "c=d" e="foo bar" f=\'g h\'') == ['a=b', 'c=d', 'e="foo bar"', "f='g h'"]

# Generated at 2022-06-25 01:48:27.332819
# Unit test for function split_args
def test_split_args():
    print('Testing function split_args')
    bytes_0 = b'\xaa\xf7!\xe3\xc3\x9b\xbc\xd7'
    bytes_1 = b'\xaa\xf7!\xe3\xc3\x9b\xbc\xd7'
    bytes_2 = b'volume'
    bytes_3 = b'volume'
    bytes_4 = b'\xaa\xf7!\xe3\xc3\x9b\xbc\xd7'
    bytes_5 = b'\xaa\xf7!\xe3\xc3\x9b\xbc\xd7'
    bytes_6 = b'\xaa\xf7!\xe3\xc3\x9b\xbc\xd7'

# Generated at 2022-06-25 01:48:33.723333
# Unit test for function split_args
def test_split_args():
    string_0 = 'key_0=value_0'
    string_1 = 'key_1=value_1'
    params = split_args(string_0) + split_args(string_1)

    # Verify that the number of parameters is correct
    if len(params) != 2:
        raise Exception('Incorrect number of params parsed')

    # Verify all parameters are valid
    if params[0] != string_0 or params[0].count('=') != 1:
        raise Exception('Expected parameter is missing or invalid')
    if params[1] != string_1 or params[1].count('=') != 1:
        raise Exception('Expected parameter is missing or invalid')

