

# Generated at 2022-06-25 01:39:09.274242
# Unit test for function unquote
def test_unquote():
    test_case_0()

test_unquote()



# Generated at 2022-06-25 01:39:11.647850
# Unit test for function unquote
def test_unquote():
    assert True == is_quoted('"123"')
    assert True == is_quoted("'123'")
    assert '123' == unquote('"123"')
    assert '123' == unquote("'123'")


if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-25 01:39:15.784091
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo') == '"foo'
    assert unquote('foo') == 'foo'
    assert unquote('') == ''
    assert unquote(None) is None

# Generated at 2022-06-25 01:39:19.561079
# Unit test for function split_args
def test_split_args():
    # Test function arguments
    args1 = 'a=b c="foo bar"'

    # Call function
    split_args(args1)


# Generated at 2022-06-25 01:39:23.521339
# Unit test for function split_args
def test_split_args():
    args = "a=b c=\"foo bar\""
    expected = ['a=b', 'c="foo bar"']

    result = split_args(args)
    print("result is:", result)
    assert result == expected



# Generated at 2022-06-25 01:39:26.293010
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    res = split_args(args)
    assert res == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 01:39:35.181837
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('a=b c=\\"foo bar\\"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\\\'foo bar\\\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c=\'foo bar') == ['a=b', 'c=\'foo bar']

# Generated at 2022-06-25 01:39:44.804510
# Unit test for function split_args
def test_split_args():
    from unittest import TestCase
    from ansible.module_utils import basic

    basic._ANSIBLE_ARGS = None

# Generated at 2022-06-25 01:39:50.203610
# Unit test for function unquote
def test_unquote():
    var_1 = unquote("'test'")
    assert var_1 == 'test'
    var_2 = unquote("test")
    assert var_2 == 'test'
    var_3 = unquote('"test"')
    assert var_3 == 'test'
    # test case with optional arg
    var_4 = unquote("'test'", "'")
    assert var_4 == "test"



# Generated at 2022-06-25 01:40:00.726665
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    args_0 = "{{ test }}"
    params_0 = split_args(args_0)
    assert params_0[0] == "{{ test }}"
    args_1 = "name=test"
    params_1 = split_args(args_1)
    assert params_1[0] == "name=test"
    args_2 = ""
    params_2 = split_args(args_2)
    assert len(params_2) == 0
    args_3 = "  "
    params_3 = split_args(args_3)
    assert len(params_3) == 0
    args_4 = "name={{ 'test' }}"
    params_4 = split_args(args_4)

# Generated at 2022-06-25 01:40:21.924390
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']
    assert split_args('a=b c="foo\\" bar"') == ['a=b', 'c="foo\\" bar"']

# Generated at 2022-06-25 01:40:33.262206
# Unit test for function split_args
def test_split_args():
    test_var1 = split_args('--debug')
    assert test_var1 == ['--debug']
    test_var2 = split_args('what is "this thing called?"')
    assert test_var2 == ['what', 'is', '"this thing called?"']
    test_var3 = split_args('True is true')
    assert test_var3 == ['True', 'is', 'true']
    test_var4 = split_args('{\'a\': \'hash\'}')
    assert test_var4 == ['{\'a\': \'hash\'}']
    test_var5 = split_args('[1, 2, 3]')
    assert test_var5 == ['[1, 2, 3]']
    test_var6 = split_args('hello')
    assert test_var6 == ['hello']
   

# Generated at 2022-06-25 01:40:36.893737
# Unit test for function split_args
def test_split_args():
    args = "foo bar=baz,foobar='hello world'"
    params = split_args(args)
    assert len(params) == 4, params
    assert params[0] == 'foo'
    assert params[1] == 'bar=baz'
    assert params[2] == 'foobar=hello world'
    assert params[3] == "world'"


# Generated at 2022-06-25 01:40:47.598731
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    assert split_args('"a" "b" "c"') == ['a', 'b', 'c']
    assert split_args("a b c") == ['a', 'b', 'c']
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("'a b' c") == ['a b', 'c']
    assert split_args('"a b" c') == ['a b', 'c']
    assert split_args("\"a b\" 'c d'") == ['a b', 'c d']
    assert split_args("a=\"b\" c='d'") == ['a=b', "c=d"]

# Generated at 2022-06-25 01:40:58.147493
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=foo bar") == ['a=b', 'c=foo bar']
    assert split_args("a=b c=\"foo \\\\bar\"") == ['a=b', 'c="foo \\\\bar"']
    assert split_args("a=b c=foo \\\\bar") == ['a=b', 'c=foo \\\\bar']
    assert split_args("a=b c=\"foo \\\\\\\\bar\"") == ['a=b', 'c="foo \\\\\\\\bar"']
    assert split_args("a=b c=foo \\\\\\\\bar") == ['a=b', 'c=foo \\\\\\\\bar']

    # More

# Generated at 2022-06-25 01:41:04.284186
# Unit test for function split_args
def test_split_args():
    var_0 = 'a=b c="foo bar" ; d=blah'
    var_0 = unquote(var_0)
    var_0 = split_args(var_0)
    assert len(var_0) == 3
    assert unquote(var_0[0]) == 'a=b'
    assert unquote(var_0[1]) == 'c="foo bar"'
    assert unquote(var_0[2]) == 'd=blah'


# Generated at 2022-06-25 01:41:09.057723
# Unit test for function split_args
def test_split_args():
    assert split_args("example input: a=b") == ['example', 'input:', 'a=b']
    assert split_args("example input: a=b c='foo bar'") == ['example', 'input:', 'a=b', 'c=\'foo bar\'']
    assert split_args("example input: a=b c=\"foo bar\"") == ['example', 'input:', 'a=b', 'c="foo bar"']
    assert split_args("example input: a=b c=\"foo bar\" d=e f=\"g h\" i='j k' l=m") == ['example', 'input:', 'a=b', 'c="foo bar"', 'd=e', 'f="g h"', 'i=\'j k\'', 'l=m']

# Generated at 2022-06-25 01:41:13.941092
# Unit test for function split_args
def test_split_args():
    # Testing the following Python code using pytest
    # str_0 = '"foo bar" baz'
    # var_0 = split_args(str_0)
    # print var_0
    assert split_args('"foo bar" baz') == ['foo bar', 'baz']


# Generated at 2022-06-25 01:41:16.985417
# Unit test for function split_args
def test_split_args():
    print("Testing function split_args")
    # Make sure the input arguments were correclty parsed.
    if split_args("") != []:
        # print("TEST CASE_0: fail")
        return -1



# Generated at 2022-06-25 01:41:25.641085
# Unit test for function split_args
def test_split_args():

    expected_1 = split_args("k=v")
    expected_2 = split_args("")
    expected_3 = split_args("a b c")
    expected_4 = split_args("a=b c=d")
    expected_5 = split_args("a={{foo}}")
    expected_6 = split_args("a={{foo}} c=d")
    expected_7 = split_args("a={{foo}} c=\"{{bar}}\"")
    expected_8 = split_args("a={{foo}} c=\"{{bar}}\" g=h")
    expected_9 = split_args("a=b c='d e'")
    expected_10 = split_args("a={{foo}} c='d {{bar}}'")
    expected_11 = split_args("a=b c=\"d e\"")


# Generated at 2022-06-25 01:41:47.864350
# Unit test for function split_args
def test_split_args():
    # Tests here
    print("Testing split_args")
    var0 = "''"
    var1 = '"foo bar"'
    var2 = "'''foo bar'''"
    var3 = '''"foo'bar"'''
    var4 = '''"foobar"'''
    var5 = '''"foo bar' baz"'''
    var6 = '''"foo bar" baz'''
    var7 = '''"foo bar'''
    var8 = '''"foo bar baz"'''
    var9 = '''"foo 'bar' baz' foo"'''
    var10 = "foo='bar' baz='foo'"
    var11 = "foo='bar' baz='foo'"
    var12 = "foo='bar' baz='foo'"

# Generated at 2022-06-25 01:41:56.855016
# Unit test for function split_args
def test_split_args():
    import tempfile
    import os

    # create a temporary file to use for testing
    fd, fn = tempfile.mkstemp()
    outfile = os.fdopen(fd, 'w')
    outfile.write('foo bar\n')
    expected_result = ['foo', 'bar\n']
    outfile.close()

    # open the file in read-only mode for our test
    fd = os.open(fn, os.O_RDONLY)
    infile = os.fdopen(fd, 'r')

    # perform the test
    result = split_args(infile.read())

    # compare the result to the expected value
    assert result == expected_result

    # clean up
    os.unlink(fn)


# Generated at 2022-06-25 01:42:02.316210
# Unit test for function split_args
def test_split_args():
    args = 'user=root password=foo bar'
    result = split_args(args)
    assert result == ['user=root', 'password=foo bar'], "split_args result did not match expected value"


# Generated at 2022-06-25 01:42:09.689980
# Unit test for function split_args
def test_split_args():
    # Here there is a {\n split inside a jinja2 block
    items = ['{', '{', 'a=b', 'c=d', '{', 'f=g', '}', 'h=i', '}}', 'j=k', 'l=m', '}', 'n=o', 'p=q']
    # Here there is a \n split within quotes
    items += ['a=1', 'b=2', 'c="', 'foo', 'bar', '"', 'd="', 'foo', 'bar', '"', 'e=1', 'f=2']
    # Here there is a \n split within quotes that is also within jinja2
    items += ['a="{{', 'foo', '}}"', 'b="{{', 'foo', '}}"', 'c=1', 'd=2']


# Generated at 2022-06-25 01:42:12.858515
# Unit test for function split_args
def test_split_args():
    inputs = ['foo "bar"', 'foo "bar" foo']
    outputs = ['foo "bar"', 'foo "bar" foo']
    for itemidx, item in enumerate(inputs):
        output = outputs[itemidx]
        print("Input: %s" % item)
        print("Desired: %s" % output)
        print("Actual: %s" % str(split_args(item)))
        assert output == str(split_args(item))

# Generated at 2022-06-25 01:42:24.233222
# Unit test for function split_args
def test_split_args():
    bool_0 = split_args("foo")
    assert bool_0 == ['foo']
    bool_0 = split_args("foo bar baz")
    assert bool_0 == ['foo', 'bar', 'baz']
    bool_0 = split_args("foo='bar baz'")
    assert bool_0 == ["foo='bar baz'"]
    bool_0 = split_args("foo=\"bar baz\"")
    assert bool_0 == ['foo="bar baz"']
    bool_0 = split_args("foo=\"bar \\\"baz\\\"\"")
    assert bool_0 == ['foo="bar \\"baz\\""']
    bool_0 = split_args("foo='bar \"baz\"'")
    assert bool_0 == ["foo='bar \"baz\"'"]

# Generated at 2022-06-25 01:42:26.728306
# Unit test for function split_args
def test_split_args():
   if split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']:
       print('test_split_args func passed')
   else:
       print('test_split_args func failed')

# Generated at 2022-06-25 01:42:29.626687
# Unit test for function split_args
def test_split_args():
    var_0 = "a=b c='foo bar'"
    var_1 = split_args(var_0)
    var_3 = "d={% if e %}f{% endif %} g={% if h %} i='{{ j }}'{% endif %} k=l"
    var_2 = split_args(var_3)


# Generated at 2022-06-25 01:42:35.088537
# Unit test for function split_args
def test_split_args():

    # All arguments passed to the split_args method
    args = "a=b c=\"foo bar\""

    # Call the split_args method
    result = split_args(args)
    if result == ['a=b', 'c="foo bar"']:
        print("Unit test success")
    else:
        print("Unit test failure")


if __name__ == '__main__':
    print("Testing")
    test_split_args()

# Generated at 2022-06-25 01:42:41.373490
# Unit test for function split_args
def test_split_args():
    assert split_args("echo hello world") == ['echo', 'hello', 'world']
    assert split_args("  echo hello world") == ['echo', 'hello', 'world']
    assert split_args("echo hello world  ") == ['echo', 'hello', 'world']
    assert split_args("echo hello \\world") == ['echo', 'hello', 'world']
    assert split_args("echo hello\\ world") == ['echo', 'hello world']
    assert split_args("echo hello\\\nworld") == ['echo', 'hello\n', 'world']
    assert split_args("echo hello\\\\\nworld") == ['echo', 'hello\\\\\n', 'world']
    assert split_args("echo 'hello world'") == ['echo', 'hello world']

# Generated at 2022-06-25 01:43:02.874441
# Unit test for function split_args
def test_split_args():
    # Doesn't seem to be called by Ansible,
    # but it's covered by one of the tests.
    #args = "foo bar"
    #split_args(args)
    pass


# Generated at 2022-06-25 01:43:07.863019
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('apt-get install -y python-apt') == ['apt-get', 'install', '-y', 'python-apt']
    assert split_args('a=b c="foo bar" d="{{ foo }}"') == ['a=b', 'c="foo', 'bar"', 'd="{{ foo }}"']
    assert split_args('apt-get install -y python-apt "{{ foo }}"') == ['apt-get', 'install', '-y', 'python-apt', '"{{ foo }}"']

# Generated at 2022-06-25 01:43:16.641120
# Unit test for function split_args
def test_split_args():
    params = split_args('')
    assert len(params) == 0, 'Length of params: %s' % len(params)

    params = split_args('abc')
    assert len(params) == 1, 'Length of params: %s' % len(params)

    params = split_args('abc def')
    assert len(params) == 2, 'Length of params: %s' % len(params)

    params = split_args('abc   def')
    assert len(params) == 2, 'Length of params: %s' % len(params)

    params = split_args('    ')
    assert len(params) == 0, 'Length of params: %s' % len(params)

    params = split_args('abc\ndef')
    assert len(params) == 2, 'Length of params: %s'

# Generated at 2022-06-25 01:43:27.482451
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "'foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', '"foo bar"']
    assert split_args("a=b c=foo\\ bar") == ['a=b', 'c=foo bar']
    assert split_args("echo {{ 'foo bar' }}") == ['echo', "{{ 'foo bar' }}"]
    assert split_args("echo {{ \"foo bar\" }}") == ['echo', '{{ "foo bar" }}']
    assert split_args("a=b c=(1 2 3)") == ['a=b', '(1 2 3)']
    assert split_args("a=b c=$(1 2 3)") == ['a=b', '$(1 2 3)']
   

# Generated at 2022-06-25 01:43:32.711335
# Unit test for function split_args
def test_split_args():
    arg_string = '''-a option1=value1 option2=value2 "option3=longer value"
    option4=another-value option5={{ foo }} option6={{ bar }}'''

    print(arg_string)
    print("")
    result = split_args(arg_string)
    print("")
    print(result)

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:43:43.030529
# Unit test for function split_args
def test_split_args():
    # Test with args: ansible -m ping         -i hosts
    params = split_args('ansible -m ping         -i hosts')
    assert len(params) == 4, "The value should be: 4"
    assert params[0] == 'ansible', "The value should be: 'ansible'"
    assert params[1] == '-m ping', "The value should be: '-m ping'"
    assert params[2] == '-i', "The value should be: '-i'"
    assert params[3] == 'hosts', "The value should be: 'hosts'"
    # Test with args: ansible-playbook ping.yml -i hosts
    params = split_args('ansible-playbook ping.yml -i hosts')
    assert len(params) == 4, "The value should be: 4"

# Generated at 2022-06-25 01:43:53.106234
# Unit test for function split_args
def test_split_args():

    print('\nTesting function split_args')

    import test.test_utils as test_utils
    import copy

    # create an instance of the TestAnsibleModule class
    test_obj = test_utils.TestAnsibleModule()

    # set the return value for invoked method
    test_obj.set_return_value(b'var_0')

    # create a instance of AnsibleModule to be used by module_utils function
    am = AnsibleModule(
        argument_spec = dict(
            bool_arg = dict(required=True, type='bool'),
            int_arg = dict(required=True, type='int'),
            list_arg = dict(required=True, type='list'),
            dict_arg = dict(required=True, type='dict')
        )
    )

    # create variables used by module_utils

# Generated at 2022-06-25 01:43:56.810341
# Unit test for function split_args
def test_split_args():
    arg_str = "--data-binary '{\"name\": \"test\", \"schemes\": [\"https\"], \"upstream_url\": \"http://127.0.0.1:8080\"}' --header \"Content-Type: application/json\""
    split_args(arg_str)



# Generated at 2022-06-25 01:43:59.536634
# Unit test for function split_args
def test_split_args():
    params = split_args('a=b c="foo bar"')
    assert len(params) == 2
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo bar"'


# Generated at 2022-06-25 01:44:07.761109
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b c" d') == ['a="b c"', 'd']
    assert split_args('"a=b c"') == ['a=b c']
    assert split_args('') == ['']
    assert split_args('a') == ['a']
    assert split_args('abc "123 456"') == ['abc', '123 456']
    assert split_args('  "abc def"  ') == ['abc def']
    assert split_args('  "abc def"') == ['abc def']

# Generated at 2022-06-25 01:44:28.599068
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B'
    var_0 = split_args(bytes_0)
    assert var_0 == ['KæÅGŒGË\r„mbØgÎ²‡B']

if __name__ == '__main__':
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:44:34.209830
# Unit test for function split_args
def test_split_args():

    ansible_module_args = {
        'a':  'K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B',
    }
    module_args, _, _, _ =  ansible_module_args
    result = split_args(module_args['a'])

    assert result == ['K\\xe6\\xc3G\\x8cG\\xcb\\r\\x84mb\\xd8g\\xce\\xb2\\x87B']


# Generated at 2022-06-25 01:44:40.285849
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected

    args = 'a=b\nc="foo bar"'
    expected = ['a=b', 'c="foo bar"\n']
    assert split_args(args) == expected

    args = '''a=b
c="foo bar"'''
    expected = ['a=b\n', 'c="foo bar"']
    assert split_args(args) == expected

    args = '''a=b
c='foo bar'
d="{{ foo }}"
e={% if bar %}foo{% endif %}'''

# Generated at 2022-06-25 01:44:44.817451
# Unit test for function split_args
def test_split_args():
    import sys
    import hashlib

    # create a list of parameters from a string using the function
    with open('parameter.txt', 'r') as f:
        param = f.read()
        param_list = split_args(param)

    # create a list of parameters from a string by the manual way
    man_list = []
    i = 0
    while i < len(param):
        str = ''
        if param[i] == ' ' or param[i] == '\t' or param[i] == '\n':
            i += 1
            continue
        if param[i] == "'" or param[i] == '"':
            q = param[i]
            i += 1
            while i < len(param):
                if param[i] == q:
                    break
                str += param[i]

# Generated at 2022-06-25 01:44:53.038605
# Unit test for function split_args
def test_split_args():

    import ansible.utils.args as ansible_args
    ansible_args.split_args('foo=bar')
    ansible_args.split_args('foo=bar baz')
    ansible_args.split_args('foo="bar baz"')
    ansible_args.split_args('foo="bar bar" baz')
    ansible_args.split_args('foo="bar bar" baz fuz')
    ansible_args.split_args('foo="bar bar" baz fuz "foo bar"')
    ansible_args.split_args('foo="bar bar \'foo bar" baz fuz "foo bar"')
    ansible_args.split_args('foo="bar bar" baz fuz "foo bar\' foo"')

# Generated at 2022-06-25 01:45:00.906364
# Unit test for function split_args
def test_split_args():
    # Imports for mocking
    from ansible.module_utils.basic import AnsibleModule as ansible_module_AnsibleModule
    from ansible.module_utils.basic import AnsibleModule as ansible_module_AnsibleModule
    from ansible.module_utils.basic import AnsibleModule as ansible_module_AnsibleModule

    # Test cases for function split_args

    # Call function split_args for test case 0
    test_case_0()


# Generated at 2022-06-25 01:45:06.152165
# Unit test for function split_args
def test_split_args():
    # bytes_0 contains the following bytes (decimal)
    # [75, 230, 195, 71, 140, 71, 203, 13, 132, 109, 98, 216, 103, 206, 178, 135, 66]

    bytes_0 = b'K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B'

# Generated at 2022-06-25 01:45:11.297117
# Unit test for function split_args
def test_split_args():

    # from ansible.parsing.vault import VaultLib
    # from ansible.parsing.vault import VaultSecret
    # from Crypto.Cipher import AES

    import os
    import tempfile
    import shutil
    import stat

    fh, path = tempfile.mkstemp()
    key = 'ansible-vault-test-key'
    secret = 'ansible-vault-test-secret'
    password = 'aRnd0mPa$$w0rd'
    context = {
        'password': password,
    }

    # os.fdopen(fh).close()
    # with open(path, 'wb') as f:
    #     f.write(VaultLib.encrypt(VaultSecret(key, secret), context))

    dirpath = tempfile.mkdtemp()



# Generated at 2022-06-25 01:45:18.809260
# Unit test for function split_args
def test_split_args():
    from nose.tools import assert_equal
    from nose.tools import assert_raises

    args = "a=b c='foo bar'"
    params = ['a=b', "c='foo bar'"]

    args2 = "a=b c='foo bar\\'s'"
    params2 = ['a=b', "c='foo bar\\'s'"]

    args3 = "a=b c=\"foo bar's\""
    params3 = ['a=b', 'c="foo bar\'s"']

    args4 = "a=b c='foo bar\\'s'"
    params4 = ['a=b', "c='foo bar\\'s'"]

    args5 = "a=b c=\"foo bar's\""
    params5 = ['a=b', 'c="foo bar\'s"']


# Generated at 2022-06-25 01:45:24.069826
# Unit test for function split_args
def test_split_args():

    # split_args(args)
    __salt__ = {}

    # Populate the parameters directly
    args = 'K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B'
    print(split_args(args))
    assert split_args(args) == ['KæÄGŒGË\r„mbøgÎ²‡B']

    # Populate the parameters directly
    args = '\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B'
    print(split_args(args))

# Generated at 2022-06-25 01:45:48.483830
# Unit test for function split_args

# Generated at 2022-06-25 01:45:49.175452
# Unit test for function split_args
def test_split_args():
    assert True



# Generated at 2022-06-25 01:45:58.465920
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # testing escaped jinja2 blocks
    assert split_args('test\\"{{test}}') == [r'test\"{{test}}']
    assert split_args('test\\"{{test}}""') == [r'test\"{{test}}""']
    assert split_args(r'test\\\"{{test}}') == [r'test\\\"{{test}}']
    assert split_args(r'test\\\"{{test}}""') == [r'test\\\"{{test}}""']
    assert split_args(r'test\\\"{{test}}\\\"') == [r'test\\\"{{test}}\\\"']

# Generated at 2022-06-25 01:46:04.480609
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') != ['a=b', 'c=foo bar']
    assert split_args('a={% if True %}True{% else %}False{% endif %}') == ['a={% if True %}True{% else %}False{% endif %}']
    assert split_args('a="{% if True %}True{% else %}False{% endif %}"') == ['a="{% if True %}True{% else %}False{% endif %}"']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']

# Generated at 2022-06-25 01:46:12.667851
# Unit test for function split_args
def test_split_args():
    assert split_args('K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B') == [
        'K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B']
    assert split_args('K\xe6\xc3G\x8cG\xcb\n\n\nmb\xd8g\xce\xb2\x87B') == [
        'K\xe6\xc3G\x8cG\xcb', '', '', 'mb\xd8g\xce\xb2\x87B']

# Generated at 2022-06-25 01:46:14.049701
# Unit test for function split_args
def test_split_args():
    args = "a=b c=\"foo bar\""
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 01:46:16.653452
# Unit test for function split_args
def test_split_args():
    # Method Configuration:
    args_0 = 'a="b c" d'

    params = split_args(args_0)
    assert params == ['a="b c"', 'd']



# Generated at 2022-06-25 01:46:24.208485
# Unit test for function split_args
def test_split_args():
    assert split_args('foo=bar') == ['foo=bar']
    assert split_args('foo="bar"') == ['foo="bar"']
    assert split_args('foo="bar bar"') == ['foo="bar bar"']
    assert split_args('foo={{ bar }}') == ['foo={{ bar }}']
    assert split_args('foo={{ "bar bar" }}') == ['foo={{ "bar bar" }}']
    assert split_args('foo={{ "bar bar" }} baz={% qux %}') == ['foo={{ "bar bar" }}', 'baz={% qux %}']
    assert split_args('foo={{ "bar bar" }} baz={% qux %}') == ['foo={{ "bar bar" }}',  'baz={% qux %}']

# Unit

# Generated at 2022-06-25 01:46:30.729564
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == '__main__':
    print("Running unit tests for module /usr/local/lib/python2.7/dist-packages/ansible/module_utils/basic.py")
    test_split_args()

# Generated at 2022-06-25 01:46:38.755875
# Unit test for function split_args
def test_split_args():
    assert split_args(b"ls -la /root") == [b"ls", b"-la", b"/root"]
    assert split_args(b"ls -la /root/ansible.cfg") == [b"ls", b"-la", b"/root/ansible.cfg"]
    assert split_args(b'ls "foo bar"') == [b"ls", b'"foo bar"']
    assert split_args(b'ls "foo bar" /path "foo bar"') == [b"ls", b'"foo bar"', b'/path', b'"foo bar"']
    assert split_args(b'ls "foo bar" /path "foo bar" baz') == [b"ls", b'"foo bar"', b'/path', b'"foo bar"', b"baz"]

# Generated at 2022-06-25 01:47:26.239283
# Unit test for function split_args
def test_split_args():
    print('in test_split_args')
    var_1 = split_args('foo')
    var_2 = split_args('foo\nbar')
    var_3 = split_args('a=b c="foo bar"')
    var_4 = split_args('foo {{ bar }} baz')
    var_5 = split_args('foo{% if bar %}bar{% endif %}baz')
    var_6 = split_args('foo {# bar #} baz')
    var_7 = split_args('foo "bar baz')
    var_8 = split_args('foo "bar \\\'baz')
    var_9 = split_args('foo "bar \\baz')
    var_10 = split_args('foo "bar\\\\baz"')

# Generated at 2022-06-25 01:47:29.081876
# Unit test for function split_args
def test_split_args():
    assert split_args(b'K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B') == [b'K\xc3\xa6\xc3\x83G\x8cG\xcb\rmb\xd8g\xce\xb2B']


# Generated at 2022-06-25 01:47:31.245125
# Unit test for function split_args
def test_split_args():
    var_0 = b"a=b c=\"foo bar\""
    var_1 = split_args(var_0)
    assert var_1 == [b'a=b', b'c="foo bar"']

# Generated at 2022-06-25 01:47:41.581013
# Unit test for function split_args
def test_split_args():
    assert split_args('"foo" "bar"') == ['foo', 'bar']
    assert split_args('''"foo" 'bar' baz''') == ['foo', "bar", 'baz']
    assert split_args('"foo bar"') == ['foo bar']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo=bar') == ['foo=bar']
    assert split_args('foo = bar') == ['foo', '=', 'bar']
    assert split_args('foo="bar"') == ['foo=bar']
    assert split_args('foo="bar" baz=foob') == ['foo=bar', 'baz=foob']
    assert split_args('foo="bar" baz') == ['foo=bar', 'baz']
    assert split_args

# Generated at 2022-06-25 01:47:50.581517
# Unit test for function split_args
def test_split_args():
    assert split_args(b"foo bar") == [b'foo', b'bar']
    assert split_args(b"foo 'bar baz'") == [b'foo', b"'bar baz'"]
    assert split_args(b'foo "bar baz"') == [b'foo', b'"bar baz"']
    assert split_args(b"foo {{ bar }}") == [b'foo', b'{{ bar }}']
    assert split_args(b"foo bar") == [b'foo', b'bar']
    assert split_args(b'foo bar') == [b'foo', b'bar']
    assert split_args(b"foo 'bar baz'") == [b'foo', b"'bar baz'"]

# Generated at 2022-06-25 01:48:00.867099
# Unit test for function split_args
def test_split_args():
    # Testing default-case
    assert split_args(b'a=b c=d e="f g" h="i j" k=\'l m\'') == ['a=b', 'c=d', 'e="f g"', 'h="i j"', 'k=\'l m\'']
    # Testing a specific case
    assert split_args(b"{% for x in y %}{{ x }}\n{% endfor %}") == ['{% for x in y %}', '{{ x }}\n{% endfor %}']
    # Testing a specific case
    assert split_args(b"{% for x in y %}{{ x }}\n") == ['{% for x in y %}', '{{ x }}\n']
    # Testing a specific case

# Generated at 2022-06-25 01:48:07.301119
# Unit test for function split_args
def test_split_args():
    assert split_args(b'K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B') == [b'K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B']
    assert split_args('"K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B"') == [b'K\xe6\xc3G\x8cG\xcb\r\x84mb\xd8g\xce\xb2\x87B']

# Generated at 2022-06-25 01:48:13.601949
# Unit test for function split_args
def test_split_args():
    assert split_args(b"foo bar baz") == ["foo", "bar", "baz"], "foo bar baz"
    assert split_args(b"foo bar baz foo=bar") == ["foo", "bar", "baz", "foo=bar"], "foo bar baz foo=bar"
    assert split_args(b"foo bar 'baz foo=bar'") == ["foo", "bar", "baz foo=bar"], "foo bar 'baz foo=bar'"
    assert split_args(b"foo=\"bar baz\"") == ["foo=\"bar baz\""], "foo=\"bar baz\""
    assert split_args(b"foo=\"bar baz\" 'foo bar'") == ["foo=\"bar baz\"", "foo bar"], "foo=\"bar baz\" 'foo bar'"

# Generated at 2022-06-25 01:48:17.149827
# Unit test for function split_args
def test_split_args():
    print('Testing split_args')
    test_case_0()
    print('Split args test complete')

# Generated at 2022-06-25 01:48:21.943673
# Unit test for function split_args
def test_split_args():
    data = 'Dummy data for the test'

    # Testing the default parameters
    output = split_args(data)
    assert 'Dummy' in output
    assert 'data' in output
    assert 'for' in output
    assert 'the' in output
    assert 'test' in output

