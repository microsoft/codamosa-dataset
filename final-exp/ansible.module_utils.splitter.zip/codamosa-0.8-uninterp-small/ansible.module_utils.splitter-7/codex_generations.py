

# Generated at 2022-06-25 01:39:05.802916
# Unit test for function unquote
def test_unquote():
    str_1 = '5pI\x0c0'
    str_2 = '5pI\x0c0'
    assert unquote(str_1) == str_1
    assert unquote(str_2) == str_2



# Generated at 2022-06-25 01:39:07.562912
# Unit test for function split_args
def test_split_args():
    value = split_args('/bin/foo a="b c" d')
    assert value == ['/bin/foo', 'a="b c"', 'd']



# Generated at 2022-06-25 01:39:13.162917
# Unit test for function unquote
def test_unquote():
    assert unquote('5pI\x0c0') == '5pI\x0c0'
    assert unquote('U\x0e*') == 'U\x0e*'
    assert unquote('wN{\x1d') == 'wN{\x1d'
    assert unquote('\x0c0') == '\x0c0'
    assert unquote('t\x1cg') == 't\x1cg'
    print('TEST: unquote() - OK')



# Generated at 2022-06-25 01:39:15.498428
# Unit test for function split_args
def test_split_args():
#    import doctest
#    doctest.testmod(verbose=True)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 01:39:17.496368
# Unit test for function unquote
def test_unquote():
    print('Testing unquote()')

    test_case_0()


# Generated at 2022-06-25 01:39:28.489410
# Unit test for function split_args
def test_split_args():
    assert split_args("ls -l /var/log") == ['ls', '-l', '/var/log']
    assert split_args("ls -l /var/log 'foo bar'") == ['ls', '-l', '/var/log', 'foo bar']
    assert split_args("ls -l /var/log 'foo bar' baz='hello world'") == ['ls', '-l', '/var/log', 'foo bar', 'baz=hello world']
    assert split_args('ls -l "/var/log/{{inventory_hostname}}.log"') == ['ls', '-l', '/var/log/{{inventory_hostname}}.log']

# Generated at 2022-06-25 01:39:33.355145
# Unit test for function unquote
def test_unquote():
    str_0 = '5pI\x0c0'
    var_0 = unquote(str_0)
    assert var_0 == '5pI\x0c0'
    str_0 = '1\x0c0'
    var_0 = unquote(str_0)
    assert var_0 == '1\x0c0'
    str_0 = ''
    var_0 = unquote(str_0)
    assert var_0 == ''


# Generated at 2022-06-25 01:39:38.773622
# Unit test for function split_args
def test_split_args():
    assert split_args('"a" "b" c="d" e=f') == ['a', 'b', 'c=d', 'e=f']
    assert split_args('a="a b c d"') == ['a=a b c d']
    assert split_args('a="a b c d"') == ['a=a b c d']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c=foo bar']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c=foo bar']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c=foo bar']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c=foo bar']
   

# Generated at 2022-06-25 01:39:45.370171
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []

    assert split_args('-i') == ['-i']
    assert split_args('-i /tmp/foo.pem') == ['-i', '/tmp/foo.pem']
    assert split_args('-i /tmp/foo') == ['-i', '/tmp/foo']
    assert split_args('/tmp/foo.pem') == ['/tmp/foo.pem']
    assert split_args('/tmp/foo') == ['/tmp/foo']
    assert split_args('-f') == ['-f']
    assert split_args('-f test_module') == ['-f', 'test_module']

# Generated at 2022-06-25 01:39:53.927505
# Unit test for function unquote
def test_unquote():
    assert unquote('5pI\x0c0') == '5pI\x0c0'
    assert unquote('a=b c="foo bar"') == 'a=b c="foo bar"'
    assert unquote('false') == 'false'
    assert unquote('') == ''
    assert unquote('\n') == '\n'
    assert unquote('foo') == 'foo'
    assert unquote('"') == ''
    assert unquote('abc') == 'abc'
    assert unquote('- bar') == '- bar'
    assert unquote('\'foo bar\'') == '\'foo bar\''
    assert unquote('bar') == 'bar'
    assert unquote('foo bar') == 'foo bar'
    assert unquote('\'\'') == ''

# Generated at 2022-06-25 01:40:18.611824
# Unit test for function split_args
def test_split_args():
    var_1 = split_args("a=b c='foo bar'")
    assert var_1 == ["a=b", "c='foo bar'"]
    var_2 = split_args("a=b c='foo bar' d={{ foo }}\ne=f g={% foo %}")
    assert var_2 == ["a=b", "c='foo bar'", "d={{ foo }}", "e=f", "g={% foo %}"]
    var_3 = split_args("a=b 'c=d' e=f {# foo #}")
    assert var_3 == ["a=b", "'c=d'", "e=f", "{# foo #}"]
    var_4 = split_args("a=b c='foo bar' d={{ foo }}\\ne=f {# foo #}")

# Generated at 2022-06-25 01:40:25.003726
# Unit test for function split_args
def test_split_args():
    str_0 = 'cd ~/"My Documents"/'
    str_1 = 'ls -la "file 1" "file 2" "file 3"'
    str_2 = '''cd ~/My\ Documents/
    ls -la file\ 1 file\ 2 file\ 3
    '''
    str_3 = 'cd ~/My Documents/ && ls -la file\ 1 file\ 2 file\ 3'
    str_4 = "echo '{{ foo }} and \\'{\\' and \\"
    str_5 = "echo '{{ foo }} and \\'{\\' and \\\""
    str_6 = "echo '{{ foo }} and \\'{\\' and \\\\"""

# Generated at 2022-06-25 01:40:26.013238
# Unit test for function split_args
def test_split_args():
    pass



# Generated at 2022-06-25 01:40:34.228723
# Unit test for function split_args

# Generated at 2022-06-25 01:40:40.549589
# Unit test for function split_args

# Generated at 2022-06-25 01:40:45.832508
# Unit test for function split_args
def test_split_args():
    str_0 = '"123 123"'
    result = split_args(str_0)
    assert len(result) == 1
    assert result[0] == '"123 123"'


# Generated at 2022-06-25 01:40:54.467014
# Unit test for function split_args

# Generated at 2022-06-25 01:41:02.548849
# Unit test for function split_args
def test_split_args():
    # Tests for function split_args

    # Test cases for function split_args
    str_0 = '5pI\x0c0'
    var_0 = unquote(str_0)
    str_1 = 'foo  \tbar'
    var_1 = unquote(str_1)
    str_2 = 'foo  \tbar'
    var_2 = unquote(str_2)
    str_3 = 'a=b c="foo bar"'
    var_3 = split_args(str_3)

    assert 'foo bar' in str_2
    assert 'foo  \tbar' in str_1
    assert 'bar' in str_1
    assert '5pI' in str_0
    assert 'foo' in str_2

# Generated at 2022-06-25 01:41:11.414888
# Unit test for function split_args
def test_split_args():
    var_0 = mock_open('var_0.txt')

    var_1 = mock_open('var_1.txt')

    args = """a=b c="foo bar" f={{ foo }}"""
    params = split_args(args)
    var_2 = params

    params = split_args(args)
    var_3 = params

    var_4 = unquote(params[2])

    var_5 = unquote(params[2])

    var_6 = unquote(params[2])

    var_7 = unquote(params[2])

    var_8 = unquote(params[2])

    var_9 = unquote(params[2])

    var_10 = unquote(params[2])


# Generated at 2022-06-25 01:41:19.901641
# Unit test for function split_args
def test_split_args():
    print("\n\nRunning Test Case 1: args = 'ansible all -m ping -vvvvv'")
    args = 'ansible all -m ping -vvvvv'
    result = split_args(args)
    assert isinstance(result, list)
    assert len(result) == 5
    assert result[0] == 'ansible'
    assert result[1] == 'all'
    assert result[2] == '-m'
    assert result[3] == 'ping'
    assert result[4] == '-vvvvv'



# Generated at 2022-06-25 01:41:42.082378
# Unit test for function split_args
def test_split_args():

    # Get all of the test cases for the function
    test_cases = []

    # Iterate through all of the test cases
    index = 0
    while True:
        # Get the next test case
        test_case = eval('test_case_' + str(index))

        # If the test case does not exist, then we have reached the end of the tests
        if test_case == None:
            break

        # Add the test case to the list
        test_cases.append(test_case)

        # Increment the index
        index += 1

    # Run the test cases
    for test_case in test_cases:
        test_case()


# Run the unit tests
if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:41:49.748630
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo bar"]
    assert split_args("foo \nbar baz") == ["foo \nbar baz"]
    assert split_args("foo \nbar\nbaz") == ["foo \nbar\nbaz"]
    assert split_args("foo bar\nbaz\n") == ["foo bar\nbaz\n"]
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    assert split_args("foo   bar baz") == ["foo   bar baz"]
    assert split_args("foo   bar   baz") == ["foo   bar   baz"]

# Generated at 2022-06-25 01:41:54.225309
# Unit test for function split_args
def test_split_args():
    print_0 = None
    set_0 = split_args(print_0)
    print('print_0:', print_0)
    print('set_0:', set_0)
    print('type(set_0):', type(set_0))
    print('isinstance(set_0, list):', isinstance(set_0, list))
    print('isinstance(set_0, set):', isinstance(set_0, set))
    print('isinstance(set_0, tuple):', isinstance(set_0, tuple))
    assert(isinstance(set_0, list))
    assert(not isinstance(set_0, set))
    assert(not isinstance(set_0, tuple))
    assert(len(set_0) == 2)
    print('split_args: PASS')

test

# Generated at 2022-06-25 01:42:01.611324
# Unit test for function split_args
def test_split_args():
    ansible_0 = split_args('a=b c="foo bar"')
    assert ansible_0 == ['a=b', 'c="foo bar"'], "split_args failed: code1"
    ansible_1 = split_args('ip={{ ansible_default_ipv4.address }} netmask={{ ansible_default_ipv4.netmask }}')
    assert ansible_1 == ['ip={{ ansible_default_ipv4.address }}', 'netmask={{ ansible_default_ipv4.netmask }}'], "split_args failed: code2"
    ansible_2 = split_args('"{{" "}}"')
    assert ansible_2 == ['"{{"', '"}}"']

# Generated at 2022-06-25 01:42:09.639492
# Unit test for function split_args
def test_split_args():
    # Input arguments:
    set_0 = set()
    var_0 = split_args(set_0)
    print(var_0)
    assert var_0 == set()

    # Input arguments:
    str_0 = "    "
    var_1 = split_args(str_0)
    print(var_1)
    assert var_1 == []

    # Input arguments:

# Generated at 2022-06-25 01:42:12.260050
# Unit test for function split_args
def test_split_args():
    # Tests for function split_args
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 01:42:17.850722
# Unit test for function split_args
def test_split_args():
    set_0 = set()
    var_0 = split_args(set_0)
    var_1 = set_0
    assert var_0 is not False


# Generated at 2022-06-25 01:42:28.077863
# Unit test for function split_args
def test_split_args():
    set_0 = 'foo=bar'
    assert(split_args(set_0) == [set_0])
    set_1 = 'foo=bar key=value'
    assert(split_args(set_1) == set_1.split())
    set_2 = 'foo="bar key"'
    assert(split_args(set_2) == set_2.split())
    set_3 = 'foo="bar key" key=value'
    assert(split_args(set_3) == set_3.split())
    set_4 = 'foo=bar key="value value"'
    assert(split_args(set_4) == set_4.split())
    set_5 = 'foo=bar key="value value" key2=value2'

# Generated at 2022-06-25 01:42:34.939304
# Unit test for function split_args
def test_split_args():
    test_set = set()
    test_case_0()
    test_set.add(test_case_0)
    for test in test_set:
        test()

# Generated at 2022-06-25 01:42:41.231052
# Unit test for function split_args
def test_split_args():

    assert split_args(' a=b c="foo bar"') == [u'a=b', 'c="foo bar"']
    assert split_args(' a=b c="foo bar"') == [u'a=b', 'c="foo bar"']

    # jinja2 blocks
    assert split_args('a=b c="foo {{ bar }}"') == [u'a=b', 'c="foo {{ bar }}"']
    assert split_args('a=b c="foo {{ bar }}"') == [u'a=b', 'c="foo {{ bar }}"']
    assert split_args('a=b c="{{ foo }} bar"') == [u'a=b', 'c="{{ foo }} bar"']

# Generated at 2022-06-25 01:43:27.536844
# Unit test for function split_args
def test_split_args():

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 01:43:30.124204
# Unit test for function split_args
def test_split_args():
    set_0 = set()
    var_0=split_args(set_0)
    print(var_0)
    set_1 = set()
    var_1=split_args(set_1)
    print(var_1)
    set_2 = set()
    var_2 = split_args(set_2)
    print(var_2)


# Generated at 2022-06-25 01:43:40.728106
# Unit test for function split_args
def test_split_args():
    assert split_args('"a=b" c="foo bar"') == ['a=b', 'c="foo bar"'], "wrong result"
    assert split_args('"a=b" c="foo bar') == ['a=b', 'c="foo bar'], "wrong result"
    assert split_args('a=b "c=foo bar"') == ['a=b', 'c=foo bar'], "wrong result"
    assert split_args('a=b "c=foo bar') == ['a=b', 'c=foo bar'], "wrong result"
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\''], "wrong result"

# Generated at 2022-06-25 01:43:45.335743
# Unit test for function split_args
def test_split_args():
    assert split_args('--extra-vars "a=1 b=2"') == ['--extra-vars', 'a=1 b=2']
    assert split_args('--extra-vars "a b" "c=1" d=2') == ['--extra-vars', 'a b', 'c=1', 'd=2']
    assert split_args('--extra-vars "{{foo}}"') == ['--extra-vars', '{{foo}}']
    assert split_args('--extra-vars "a=1 b=2" --custom-args "a" "b"') == ['--extra-vars', 'a=1 b=2', '--custom-args', 'a', 'b']

# Generated at 2022-06-25 01:43:48.381008
# Unit test for function split_args

# Generated at 2022-06-25 01:43:58.884092
# Unit test for function split_args

# Generated at 2022-06-25 01:44:05.312013
# Unit test for function split_args
def test_split_args():
    # Check for the 1 case
    set_0 = "a=b c=d"
    var_0 = split_args(set_0)
    assert var_0[0] == 'a=b' and var_0[1] == 'c=d'
    # Check for the 2 case
    set_0 = "a=b 'c d'"
    var_0 = split_args(set_0)
    assert var_0[0] == 'a=b' and var_0[1] == "'c d'"
    # Check for the 3 case
    set_0 = "a=b \"c d\""
    var_0 = split_args(set_0)
    assert var_0[0] == 'a=b' and var_0[1] == "\"c d\""
    # Check for the 4

# Generated at 2022-06-25 01:44:07.249965
# Unit test for function split_args
def test_split_args():
    set_0 = set()
    assert split_args(set_0)[0] == 'a=b'
    assert split_args(set_0)[1] == 'c="foo bar"'


# Generated at 2022-06-25 01:44:08.530770
# Unit test for function split_args
def test_split_args():
    set_0 = set(['abc', 'def', 'ghi'])
    var_0 = split_args(set_0)


# Generated at 2022-06-25 01:44:18.385743
# Unit test for function split_args
def test_split_args():
    args_0 = '"a" "b" c defghijklmnopqrstuvwxyz abcdefghijklmnopqrstuvwxyz _a_a_a_a_a_a_a_a_a_a_a_a_a_a '
    params_0 = split_args(args_0)

# Generated at 2022-06-25 01:45:39.702555
# Unit test for function split_args
def test_split_args():
    assert split_args('') == ['']
    assert split_args('host:port') == ['host:port']
    assert split_args("user=bob password='pw'") == ['user=bob', "password='pw'"]
    assert split_args("user=bob password='pw' extra_param") == ['user=bob', "password='pw'", 'extra_param']
    assert split_args("user=bob password='pw' extra_param=\"{{ foo }}{% if bar %}oops{% endif %}\"") == ['user=bob', "password='pw'", 'extra_param="{{ foo }}{% if bar %}oops{% endif %}"']

# Generated at 2022-06-25 01:45:44.624703
# Unit test for function split_args
def test_split_args():
    # Test raise exception
    try:
        split_args("{{ foo }}")
        assert False
    except:
        pass

    # Test return value
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args('''a=b c='foo bar'\nd='foo bar' e=f''') == ['a=b', "c='foo bar'", "d='foo bar'", 'e=f']
    assert split_args("echo {{ a }} 'foo bar'") == ['echo', '{{ a }}', "'foo bar'"]

# Generated at 2022-06-25 01:45:49.552314
# Unit test for function split_args
def test_split_args():
    args = "a=b c=\"foo bar\""
    assert split_args(args) == ['a=b', 'c="foo bar"']
    # success case for string
    args = "a=b c={{ foo }}"
    assert split_args(args) == ['a=b', 'c={{ foo }}']
    # success case for string
    args = "a=b c={{ foo }}"
    assert split_args(args) == ['a=b', 'c={{ foo }}']
    # success case for string
    args = "a=b c='foo bar'"
    assert split_args(args) == ['a=b', 'c=\'foo bar\'']
    # success case for string
    args = "a=b c=\"foo'bar\""

# Generated at 2022-06-25 01:45:54.039611
# Unit test for function split_args
def test_split_args():
    pass
    d_0=unquote(var_0)


if __name__ == "__main__":
    import sys
    import os
    cmd = "py.test -vv %s" % ' '.join(sys.argv[1:])
    if os.system(cmd) != 0:
        sys.exit(1)

# Generated at 2022-06-25 01:45:59.595113
# Unit test for function split_args
def test_split_args():
    cases = [
        {
            'input': [
                'a=b c="foo bar"',
            ],
            'want': [
                'a=b',
                'c="foo bar"',
            ],
        },
    ]

    for case in cases:
        got = split_args(case['input'][0])
        if got != case['want']:
            raise AssertionError("(result) %s != %s (expected)" % (got, case['want']))


# Generated at 2022-06-25 01:46:00.753924
# Unit test for function split_args
def test_split_args():
    params = split_args("a=b c=\"foo bar\"")
    print(params)



# Generated at 2022-06-25 01:46:10.384563
# Unit test for function split_args
def test_split_args():
    print('Testing function split_args()', end='')
    # Test case 0
    set_0 = set()
    var_0 = split_args(set_0)
    assert var_0 == [set_0]
    print('.', end='')
    # Test case 1
    set_1 = set()
    var_1 = split_args(set_1)
    assert var_1 == [set_1]
    print('.', end='')
    # Test case 2
    set_2 = set()
    var_2 = split_args(set_2)
    assert var_2 == [set_2]
    print('.', end='')
    # Test case 3
    set_3 = set()
    var_3 = split_args(set_3)

# Generated at 2022-06-25 01:46:19.713679
# Unit test for function split_args
def test_split_args():
    assert split_args(set()) == set()
    assert split_args("") == []

    # test if jinja2 works
    assert split_args("{{ 'something' }}") == ["{{"]

    #test if no jinja2
    assert split_args("something") == ["something"]

    #test if jinja2 in the middle
    assert split_args("something {{ 'something' }} something") == ["something", "{{"]

    #test if quotes in the middle jinja2
    assert split_args("\"something {{ 'something' }} something\"") == ["\"something", "{{"]

    #test if quotes in the middle 
    assert split_args("\"something {{ 'something' }}{%thing something\"") == ["\"something", "{{"]

    #test if quotes in the middle jinja2 and quotes
   

# Generated at 2022-06-25 01:46:23.611123
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 01:46:33.560690
# Unit test for function split_args
def test_split_args():
    print("IN test_split_args")
    test_json_map = {
        "test_case_0" : """set_0 = set()
var_0 = split_args(set_0)""",
        "test_case_1" : """set_0 = set('a')
var_0 = split_args(set_0)""",
        "test_case_2" : """set_0 = set('a', 'b')
var_0 = split_args(set_0)""",
        "test_case_3" : """set_0 = set('a', 'b', 'c')
var_0 = split_args(set_0)""",
        "test_case_4" : """set_0 = set()
var_0 = split_args(set_0)""",
    }

   