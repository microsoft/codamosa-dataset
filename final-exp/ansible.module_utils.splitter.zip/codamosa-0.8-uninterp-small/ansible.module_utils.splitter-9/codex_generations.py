

# Generated at 2022-06-25 01:39:05.764751
# Unit test for function split_args
def test_split_args():
    '''Test splitting args'''
    str_0 = '--list-hosts plays/deploy.yml'
    var_0 = split_args(str_0)
    assert len(var_0) == 2



# Generated at 2022-06-25 01:39:07.791084
# Unit test for function split_args
def test_split_args():
    str_0 = 'J3\\d{'
    var_0 = split_args(str_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 01:39:13.179876
# Unit test for function split_args
def test_split_args():
    assert split_args('asd') == ['asd']
    assert split_args('asd "foo bar"') == ['asd', '"foo bar"']
    assert split_args('asd "foo bar') == ['asd', '"foo bar']
    assert split_args("asd 'foo bar'") == ['asd', "'foo bar'"]
    assert split_args("asd 'foo \"bar'") == ['asd', "'foo \"bar'"]
    assert split_args("asd 'foo 'bar'") == ['asd', "'foo 'bar'"]
    assert split_args("asd 'foo 'bar") == ['asd', "'foo 'bar"]
    assert split_args("asd 'foo bar") == ['asd', "'foo bar"]

# Generated at 2022-06-25 01:39:24.757859
# Unit test for function is_quoted
def test_is_quoted():
    # Test empty string
    assert is_quoted('') == False
    # Test single quote
    assert is_quoted('\'') == False
    # Test double quote
    assert is_quoted('"') == False
    # Test single quote with space
    assert is_quoted(' \'\'') == False
    # Test double quote with space
    assert is_quoted('" "') == False
    # Test one character
    assert is_quoted('a') == False
    # Test one character with space
    assert is_quoted(' a') == False
    # Test unquoted string
    assert is_quoted('abcd') == False
    # Test unquoted string with space
    assert is_quoted('abcd ') == False
    # Test quoted string
    assert is_quoted('"abcd"')

# Generated at 2022-06-25 01:39:33.676231
# Unit test for function split_args
def test_split_args():
    # True test

    assert split_args("'foo bar' baz qux") == ["'foo bar'", 'baz', 'qux']
    assert split_args("'foo bar' if a==b") == ["'foo bar'", 'if', 'a==b']
    assert split_args("foo='bar' baz") == ["foo='bar'", 'baz']
    assert split_args("bar baz='foo'") == ['bar', "baz='foo'"]
    assert split_args("bar baz='foo bar'") == ['bar', "baz='foo bar'"]
    assert split_args("'bar baz'") == ["'bar baz'"]
    assert split_args("foo=bar baz='foo'") == ['foo=bar', "baz='foo'"]
    assert split_args

# Generated at 2022-06-25 01:39:42.030628
# Unit test for function split_args
def test_split_args():
    str_0 = 'echo "something" \'if\' \'{$[test]}\\'
    var_0 = split_args(str_0)
    print(var_0)
    print(str_0)
    print(unquote(str_0.strip()))

    # str_1 = 'echo "something" \'if\' \'{$[test]}\\\''
    # var_1 = split_args(str_1)
    # print(var_1)

    str_2 = """echo "something" 'if' '{$[test]}\\
\\' "\\
\\'
\\"
{% if True %}more{{stuff}}{% endif %}
{# a comment #}
"""
    var_2 = split_args(str_2)
    print(var_2)

# Generated at 2022-06-25 01:39:42.628614
# Unit test for function split_args
def test_split_args():
    test_case_0()



# Generated at 2022-06-25 01:39:52.420254
# Unit test for function split_args
def test_split_args():
    assert split_args('foo="one space"') == [u'foo="one space"']

    assert split_args('foo="one space" bar="two  spaces"') == [u'foo="one space"', u'bar="two  spaces"']

    assert split_args('foo="some spaces" bar=" some spaces"') == [u'foo="some spaces"', u'bar=" some spaces"']

    assert split_args('foo="some spaces" \'bar=" some spaces"\'') == [u'foo="some spaces"', u'bar=" some spaces"']

    assert split_args('foo="some spaces" "bar=\' some spaces\'"') == [u'foo="some spaces"', "bar=' some spaces'"]


# Generated at 2022-06-25 01:40:02.761788
# Unit test for function split_args
def test_split_args():
    assert split_args('J3\\d{') == ['J3\\d{']
    assert split_args('J3{') == ['J3{']
    assert split_args('J3{') == ['J3{']
    assert split_args('J3}') == ['J3}']
    assert split_args('J3') == ['J3']
    assert split_args('J3\\') == ['J3\\']
    assert split_args('J3\\d{') == ['J3\\d{']
    assert split_args('J3\\d{\\') == ['J3\\d{\\']
    assert split_args('J3\\d{\\d{') == ['J3\\d{\\d{']

# Generated at 2022-06-25 01:40:12.803494
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"abcd') == '"abcd'
    assert unquote('"abcd"') == 'abcd'
    assert unquote('abcd"') == 'abcd"'
    assert unquote('"abcd""') == '"abcd"'
    assert unquote('"abcd efg"') == 'abcd efg'
    assert unquote('"abcd efg" "hij"') == 'abcd efg "hij"'
    assert unquote('"abcd efg" "hij""') == 'abcd efg "hij"'
    assert unquote('"abcd efg" "hij" "klm"') == 'abcd efg "hij" "klm"'



# Generated at 2022-06-25 01:40:29.060108
# Unit test for function split_args
def test_split_args():
    print("Checking function split_args")
    str_0 = 'J3\\d{'
    var_0 = split_args(str_0)
    assert var_0 == ['J3\\d{']


if __name__ == "__main__":
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:40:29.898787
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 01:40:37.524933
# Unit test for function split_args
def test_split_args():

    # 'foo bar'
    # ['foo', 'bar']
    arg0 = 'foo bar'
    var0 = split_args(arg0)
    assert var0 == ['foo', 'bar']

    # 'foo bar=baz'
    # ['foo', 'bar=baz']
    arg1 = 'foo bar=baz'
    var1 = split_args(arg1)
    assert var1 == ['foo', 'bar=baz']

    # 'foo bar="baz"'
    # ['foo', 'bar="baz"']
    arg2 = 'foo bar="baz"'
    var2 = split_args(arg2)
    assert var2 == ['foo', 'bar="baz"']

    # 'foo bar=\'baz\''
    # ['foo', 'bar=\'baz\'']

# Generated at 2022-06-25 01:40:43.978314
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b  c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args("a=b\n c='foo bar'") == ["a=b", "c='foo bar'"]
    #assert split_args("a='{#' b='#}'") == ["a='{#'", "b='#}'"]
    str_0 = 'a="echo \\"hello world\\""'
    var_0 = split_args(str_0)
    assert var_0 == ['a="echo \\"hello', 'world\\""']
    str_0 = 'a="echo \\"hello world\\""\nfoo="bar baz"'


# Generated at 2022-06-25 01:40:50.683511
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="foo bar"'
    var_0 = split_args(str_0)
    assert var_0 == ['a=b', 'c="foo bar"']

    str_1 = 'a=b c="foo bar\\'
    var_1 = split_args(str_1)
    assert var_1 == ['a=b', 'c="foo bar\\']

    str_2 = 'a=b \\\n c="foo bar\\'
    var_2 = split_args(str_2)
    assert var_2 == ['a=b', 'c="foo bar\\']

    str_3 = 'a=b \\\n c="foo bar"'
    var_3 = split_args(str_3)
    assert var_3 == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 01:40:52.218140
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:41:02.059620
# Unit test for function split_args
def test_split_args():
    str_0 = "foo bar baz"
    var_0 = split_args(str_0)
    print(var_0)
    assert len(var_0) == 3
    assert var_0 == ['foo', 'bar', 'baz']

    str_0 = "foo bar='baz bat' flerb"
    var_0 = split_args(str_0)
    print(var_0)
    assert len(var_0) == 3
    assert var_0 == ['foo', "bar='baz bat'", 'flerb']

    str_0 = "foo bar='baz bat' flerb"
    var_0 = split_args(str_0)
    print(var_0)
    assert len(var_0) == 3

# Generated at 2022-06-25 01:41:11.387755
# Unit test for function split_args
def test_split_args():
    test_case_0()
    # Add your own test cases here.
    str_0 = 'foo bar baz'
    var_0 = split_args(str_0)
    assert var_0 == ['foo', 'bar', 'baz']
    str_1 = 'one "two three"'
    var_1 = split_args(str_1)
    assert var_1 == ['one', '"two three"']
    str_2 = '1 2 "3 4 5"'
    var_2 = split_args(str_2)
    assert var_2 == ['1', '2', '"3 4 5"']
    str_3 = '1 2 "3 4 5" 6'
    var_3 = split_args(str_3)

# Generated at 2022-06-25 01:41:18.612835
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args(' ') == []
    assert split_args('\n') == []
    assert split_args('a') == ['a']
    assert split_args(' a') == ['a']
    assert split_args('a ') == ['a']
    assert split_args(' a ') == ['a']
    assert split_args(' a\n') == ['a\n']
    assert split_args('a\n ') == ['a\n']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a b c') == ['a', 'b', 'c']
    assert split_args(' a b c ') == ['a', 'b', 'c']

# Generated at 2022-06-25 01:41:26.937417
# Unit test for function split_args
def test_split_args():
    # Try posiive cases
    str_0 = 'J3\\d{'
    var_0 = split_args(str_0)
    assert var_0 == ['J3\\d{'], 'Negative test failed, positive case'

    str_1 = 'J3\\d{\\d{'
    var_1= split_args(str_1)
    assert var_1 == ['J3\\d{\\d{'], 'Negative test failed, positive case'

    str_2 = 'J3\\d{\\d{\\'
    var_2 = split_args(str_2)
    assert var_2 == ['J3\\d{\\d{\\'], 'Negative test failed, positive case'

    str_3 = 'J3\\d{\\d{\\\\'
    var_3 = split_

# Generated at 2022-06-25 01:42:00.447501
# Unit test for function split_args
def test_split_args():
    str_0 = 'J3\\d{'
    var_0 = split_args(str_0)
    assert var_0[0] == 'J3\\d{', "failed test_split_args #0"
    str_1 = "J3\\d{"
    var_1 = split_args(str_1)
    assert var_1[0] == "J3\\d{", "failed test_split_args #1"
    str_2 = 'J3d{'
    var_2 = split_args(str_2)
    assert var_2[0] == 'J3d{', "failed test_split_args #2"
    str_3 = 'J3d'
    var_3 = split_args(str_3)

# Generated at 2022-06-25 01:42:08.785456
# Unit test for function split_args
def test_split_args():
    assert split_args("=FOO") == ['=FOO']
    assert split_args("-a=FOO") == ['-a=FOO']
    assert split_args("-a") == ['-a']
    assert split_args("a=b") == ['a=b']
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b c=d e=f g") == ['a=b', 'c=d', 'e=f', 'g']
    assert split_args('a=b "c d"') == ['a=b', '"c d"']
    assert split_args('a=b "c d" e f') == ['a=b', '"c d"', 'e', 'f']
    assert split_args

# Generated at 2022-06-25 01:42:14.337625
# Unit test for function split_args
def test_split_args():
    str_a = '"a=b" c="foo bar"'
    str_b = 'foo bar'
    str_c = '"a=bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar b" c="foo bar"'
    str_d = 'foo "bar"'
    str_f = 'foo "bar'
    str_g = 'foo "ba\\"r'
    str_h = 'foo "ba\\""r'
    str_i = 'foo "ba\\\\"r'
    str_j = 'foo "ba\\\\""r'
    str_k = 'foo bar\\'
    str_l = '"a=bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar bar b" c="foo bar\\'

# Generated at 2022-06-25 01:42:24.350556
# Unit test for function split_args
def test_split_args():
    str_0 = 'a=b c="foo bar"  d="A\\"B\\""'
    var_0 = split_args(str_0)

    print("a=b c=\"foo bar\"  d=\"A\\\"B\\\"\"")
    assert var_0 == ['a=b', 'c="foo bar"', 'd="A\"B\""']

    str_1 = "a=b 'c=\'foo bar\''  d=\"A\\\"B\\\"\""
    var_1 = split_args(str_1)

    print("a=b 'c=\'foo bar\''  d=\"A\\\"B\\\"\"")
    assert var_1 == ['a=b', "c='foo bar'", 'd="A\"B\""']


# Generated at 2022-06-25 01:42:34.204574
# Unit test for function split_args
def test_split_args():
    str_1 = 'ansible_ssh_user=root'
    var_1 = split_args(str_1)
    if var_1 != ['ansible_ssh_user=root']:
        raise Exception("unexpected output from split_args")
    str_2 = ""
    var_2 = split_args(str_2)
    if var_2 != []:
        raise Exception("unexpected output from split_args")
    str_3 = 'ansible_ssh_user=root ansible_ssh_pass=foobar'
    var_3 = split_args(str_3)
    if var_3 != ['ansible_ssh_user=root', 'ansible_ssh_pass=foobar']:
        raise Exception("unexpected output from split_args")

# Generated at 2022-06-25 01:42:40.640216
# Unit test for function split_args
def test_split_args():
    test_cases = []
    test_cases.append('''one''')
    test_cases.append('''one two''')
    test_cases.append('''one two=3 four=five''')
    test_cases.append('''one two="3" four="five"''')
    test_cases.append('''"\\t"''')
    test_cases.append('''one "two \\t"''')
    #test_cases.append('''a "b c" "d f"''')
    #test_cases.append('''a "b c" "d f" g''')
    #test_cases.append('''"b c" "d f" g''')
    #test_cases.append('''a "b c" "d f" g\\''')
    #

# Generated at 2022-06-25 01:42:50.604727
# Unit test for function split_args
def test_split_args():
    str_0 = 'Test string'
    var_0 = split_args(str_0)
    assert var_0 == ['Test', 'string']
    str_1 = 'Test string with \'single quotes\''
    var_1 = split_args(str_1)
    assert var_1 == ["Test", "string", "with", "'single quotes'"]
    str_2 = 'Test string with \"double quotes\"'
    var_2 = split_args(str_2)
    assert var_2 == ["Test", "string", "with", '"double quotes"']

# Generated at 2022-06-25 01:42:59.950196
# Unit test for function split_args
def test_split_args():
    assert split_args('  shell    command    -a  "flag value"  -b  \\\n  value=stuff  ') == ['shell', 'command', '-a', '"flag value"', '-b', 'value=stuff']
    assert split_args('  shell    command    -a  "flag value"  \\\n  -b  value=stuff  ') == ['shell', 'command', '-a', '"flag value"', '-b', 'value=stuff']
    assert split_args('  shell    command    -a  "flag \\\n  value"  -b  value=stuff  ') == ['shell', 'command', '-a', '"flag \\\n  value"', '-b', 'value=stuff']

# Generated at 2022-06-25 01:43:10.301241
# Unit test for function split_args
def test_split_args():
    test_case_0()
    # Other test cases
    assert(len(split_args("")) == 0)
    assert(split_args("a=b") == ['a=b'])
    assert(split_args("a='b'") == ['a=\'b\''])
    assert(split_args("a=\"b\"") == ['a="b"'])
    assert(split_args("a='b c'") == ['a=\'b c\''])
    assert(split_args("a='b c' d=e") == ['a=\'b c\'', 'd=e'])
    assert(split_args("a='b c' d=e f 'g h'") == ['a=\'b c\'', 'd=e', 'f', 'g h'])

# Generated at 2022-06-25 01:43:14.901188
# Unit test for function split_args
def test_split_args():

    assert split_args('1 2') == ['1', '2']
    assert split_args('1 2 3') == ['1', '2', '3']

    assert split_args('1 "2 3"') == ['1', '"2 3"']
    assert split_args('1 "2 \\"3\\""') == ['1', '"2 \\"3\\""']

    assert split_args('1 \'2 3\'') == ['1', '\'2 3\'']
    assert split_args('1 \'2 \\\'3\\\'\'') == ['1', '\'2 \\\'3\\\'\'']

    assert split_args('1 "2 3" 4') == ['1', '"2 3"', '4']

# Generated at 2022-06-25 01:44:07.427289
# Unit test for function split_args
def test_split_args():

    test_0_arg = 'JW8CAw0Dd+s='
    test_0_arg_expected = ['JW8CAw0Dd+s=']
    test_0_params = split_args(test_0_arg)
    assert test_0_arg_expected == test_0_params, "%s != %s" % (test_0_arg_expected, test_0_params)

    test_1_arg = """
    a=1 b=2 c=3
    """
    test_1_arg_expected = ['a=1', 'b=2', 'c=3']
    test_1_params = split_args(test_1_arg)

# Generated at 2022-06-25 01:44:08.451216
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 01:44:13.380299
# Unit test for function split_args
def test_split_args():
    str_0 = "a=b c=d"
    var_0 = split_args(str_0)
    if type(var_0) == list:
        if var_0 == ['a=b', 'c=d']:
            pass # passed the test
        else:
            print("FAILED: expected [\"a=b\", \"c=d\"] but got {}".format(var_0))
    else:
        print("FAILED: expected {} to be a list but got a {}".format(var_0, type(var_0)))

    str_1 = "a=b c=\"foo bar\""
    var_1 = split_args(str_1)
    if type(var_1) == list:
        if var_1 == ['a=b', 'c="foo bar"']:
            pass #

# Generated at 2022-06-25 01:44:20.460871
# Unit test for function split_args
def test_split_args():
    str_0 = '\\J3\\d{'
    var_0 = split_args(str_0)
    print(var_0)
    str_1 = 'J3\\d{'
    var_1 = split_args(str_1)
    print(var_1)
    str_2 = 'J3\'d{'
    var_2 = split_args(str_2)
    print(var_2)
    str_3 = 'J3J3\\d{'
    var_3 = split_args(str_3)
    print(var_3)
    str_4 = 'J3\\d{J3'
    var_4 = split_args(str_4)
    print(var_4)
    str_5 = 'J3J3\\d{J3'
    var

# Generated at 2022-06-25 01:44:24.072860
# Unit test for function split_args
def test_split_args():
    test_case_0()


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:44:29.081909
# Unit test for function split_args
def test_split_args():
    test_case_0()


if __name__ == "__main__":
    # no arguments passed
    if "getopt" not in sys.modules:
        myopt = ["unittest", "-v"]
    else:
        myopt = []
    # unittest.main(module=__name__, argv=["unit-test"] + myopt)
    unittest.main(module=__name__, argv=myopt)

# Generated at 2022-06-25 01:44:35.409464
# Unit test for function split_args
def test_split_args():
    str_0 = 'J3\\d{\\d{\\n'
    var_0 = split_args(str_0)
    assert var_0 == ['J3\\d{\\d{\\n']

    str_0 = 'VAR2="{{ VAR1 }} abc"\x0arhui="{% if VAR1 == \'abc\' %} def {% endif %}"\n test="{{ VAR2 }}"\x0a'
    var_0 = split_args(str_0)
    assert var_0 == ['VAR2="{{ VAR1 }} abc"', 'rhui="{% if VAR1 == \'abc\' %} def {% endif %}"', 'test="{{ VAR2 }}"', '']


# Generated at 2022-06-25 01:44:37.745344
# Unit test for function split_args
def test_split_args():

    # Test case 0 
    try:
        test_case_0()
    except Exception as e:
        print ("AssertionError: " + str(e))

# Call unit test to test the function
test_split_args()

# Generated at 2022-06-25 01:44:42.636193
# Unit test for function split_args
def test_split_args():
    # Test input data
    str_0 = r'a=b c="foo bar" d="goo goo"'
    str_1 = 'a=b c="foo bar" d="goo goo"'
    str_2 = 'a=b c="foo bar" d="goo goo"'
    str_3 = 'a=b c="foo bar" d="goo goo"'
    str_4 = """a=b c="foo bar" d="goo goo" """
    str_5 = ''
    str_6 = ''
    str_7 = 'a=b c="foo bar" d="goo goo" '
    str_8 = 'a=b c="foo bar" d="goo goo" '
    str_9 = """a=b c="foo bar" d="goo goo" """
    str_10 = r

# Generated at 2022-06-25 01:44:47.271689
# Unit test for function split_args
def test_split_args():
    str_0 = 'J3\\d{'
    arg_0 = split_args(str_0)
    assert arg_0 == ['J3\\d{']
    str_0 = 'packetbeat.flows.bytes_in:d'
    arg_0 = split_args(str_0)
    assert arg_0 == ['packetbeat.flows.bytes_in:d']
    str_0 = '"a b'
    arg_0 = split_args(str_0)
    assert arg_0 == ['"a b']


# Generated at 2022-06-25 01:46:57.556919
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()

# Test Case 1
# Inputs:
#   str_1 = '"1" "2" "3"'
# Expectation: ['1', '2', '3']

# Generated at 2022-06-25 01:47:05.502496
# Unit test for function split_args
def test_split_args():
    str_0 = 'The quick brown fox jumps over the lazy dog.'
    var_0 = split_args(str_0)

    str_1 = 'The quick brown fox jumps over the lazy dog.'
    var_1 = split_args(str_1)

    str_2 = 'The quick brown fox jumps over the lazy dog.'
    var_2 = split_args(str_2)

    str_3 = 'The quick brown fox jumps over the lazy dog.'
    var_3 = split_args(str_3)

    str_4 = 'The quick brown fox jumps over the lazy dog.'
    var_4 = split_args(str_4)

    str_5 = 'The quick brown fox jumps over the lazy dog.'
    var_5 = split_args(str_5)


# Generated at 2022-06-25 01:47:09.238134
# Unit test for function split_args
def test_split_args():
    # split_args should take in a string and output a list.
    param_string = 'a=b c="{{ foo | bar }}" d={{ foo }}'
    param_list = split_args(param_string)
    assert isinstance(param_list, list)
    assert param_list == ['a=b', 'c="{{ foo | bar }}"', 'd={{ foo }}']
    
# Unittest for function unquote

# Generated at 2022-06-25 01:47:11.290185
# Unit test for function split_args
def test_split_args():
    res = split_args(u'a=b c="foo bar" d="foobar"')
    assert res == [u'a=b', u'c="foo bar"', u'd="foobar"'], "split_args did not split string properly"



# Generated at 2022-06-25 01:47:13.548665
# Unit test for function split_args
def test_split_args():
    assert True == isinstance(split_args(''), list)

#test_case_0()
test_split_args()

# Generated at 2022-06-25 01:47:23.288609
# Unit test for function split_args
def test_split_args():
    # Test basic quote escaping
    str_0 = '"foo bar"'
    var_0 = split_args(str_0)
    assert len(var_0) == 1 and var_0[0] == 'foo bar'
    str_0 = "'foo bar'"
    var_0 = split_args(str_0)
    assert len(var_0) == 1 and var_0[0] == 'foo bar'
    str_0 = '\"foo bar\"'
    var_0 = split_args(str_0)
    assert len(var_0) == 1 and var_0[0] == '"foo bar"'

# Generated at 2022-06-25 01:47:25.494375
# Unit test for function split_args
def test_split_args():
    #TODO: Fix tests
    #test_case_0()
    pass

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:47:26.412240
# Unit test for function split_args
def test_split_args():
    test_case_0()



# Generated at 2022-06-25 01:47:34.846371
# Unit test for function split_args
def test_split_args():
    str_0 = '"hello" world'
    var_0 = split_args(str_0)
    assert isinstance(var_0, list) and var_0 == ['hello', 'world']

    str_0 = "a=b 'a=b' \"a=b\""
    var_0 = split_args(str_0)
    assert isinstance(var_0, list) and var_0 == ['a=b', 'a=b', 'a=b']

    str_0 = 'a=b c="foo bar"'
    var_0 = split_args(str_0)
    assert isinstance(var_0, list) and var_0 == ['a=b', 'c="foo bar"']

    str_0 = "{% if truck == 'blue' %}blue{% endif %}"
    var_

# Generated at 2022-06-25 01:47:38.986141
# Unit test for function split_args
def test_split_args():
    '''Unit test for function split_args'''
    # TODO: Add test for split_args
    # test = ""
    # str_0 = split_args(test)
    # print(str_0)

