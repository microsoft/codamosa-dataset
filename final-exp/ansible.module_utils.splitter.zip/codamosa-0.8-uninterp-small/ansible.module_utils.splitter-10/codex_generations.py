

# Generated at 2022-06-25 01:39:03.247167
# Unit test for function split_args
def test_split_args():
    # Probably a syntax error, but
    # since this is all static,
    # we'll catch it at compile time
    #
    # raise Exception('demo error')
    assert True

if __name__ == '__main__':
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:39:04.930490
# Unit test for function is_quoted
def test_is_quoted():
    val = is_quoted('"foo"')
    if(val != True):
        raise Exception('test_is_quoted returned false')

# unit test for function unquote

# Generated at 2022-06-25 01:39:07.409307
# Unit test for function is_quoted
def test_is_quoted():
    # test with valid values
    assert(is_quoted("'Hello World'") == True)
    assert(is_quoted("\"Hello World\"") == True)
    # test with invalid values
    assert(is_quoted("Hello World") == False)



# Generated at 2022-06-25 01:39:08.373133
# Unit test for function split_args
def test_split_args():
    print('Testing function split_args')
    assert True


# Generated at 2022-06-25 01:39:10.782359
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'test'
    var_0 = split_args(bytes_0)

    assert var_0 == ['test']
    bytes_1 = b'test test'
    var_1 = split_args(bytes_1)

    assert var_1 == ['test', 'test']


# Generated at 2022-06-25 01:39:13.900241
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'1234'") == True
    assert is_quoted("1234") == False
    assert is_quoted("'1234") == False
    assert is_quoted("1234'") == False
    assert is_quoted("\"1234'") == False
    assert is_quoted("1234\"") == False
    assert is_quoted("'1234\"") == False
    assert is_quoted("\"1234\"") == True


# Generated at 2022-06-25 01:39:17.903097
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'



# Generated at 2022-06-25 01:39:28.691623
# Unit test for function split_args
def test_split_args():
    # Asserts that the given action description returns the correct parameters for its action
    assert split_args(b'ansible_beep=boop') == ['ansible_beep=boop']
    assert split_args(b'yum') == ['yum']
    assert split_args(b'ansible_beep=boop yum') == ['ansible_beep=boop', 'yum']
    assert split_args(b'ansible_beep=boop yum name=foo') == ['ansible_beep=boop', 'yum', 'name=foo']
    assert split_args(b'yum name=foo state=present') == ['yum', 'name=foo', 'state=present']

# Generated at 2022-06-25 01:39:35.337043
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("one\ntwo three\n") == ["one\n", "two", "three\n"]
    assert split_args("one=1") == ["one=1"]
    assert split_args("one=1\ntwo=2\nthree=3") == ["one=1\n", "two=2\n", "three=3"]
    assert split_args("one = 1") == ["one", "=", "1"]
    assert split_args("one=1 two=2") == ["one=1", "two=2"]
    assert split_args("one=1 two=2 three=3") == ["one=1", "two=2", "three=3"]

# Generated at 2022-06-25 01:39:42.752931
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("Hello") == False
    assert is_quoted("'Hello'") == True
    assert is_quoted("'Hello") == False
    assert is_quoted("Hello'") == False
    assert is_quoted('"Hello"') == True
    assert is_quoted('"Hello') == False
    assert is_quoted('Hello"') == False



# Generated at 2022-06-25 01:40:02.051889
# Unit test for function split_args
def test_split_args():
    assert split_args(None) == None, 'Expected None, but got %s' % (split_args(None))
    assert split_args('') == [], 'Expected [], but got %s' % (split_args(''))
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"'], 'Expected [a=b, c="foo bar"], but got %s' % (split_args('a=b c="foo bar"'))
    assert split_args('a=b c="foo bar\\""') == ['a=b', 'c="foo bar""'], 'Expected [a=b, c="foo bar\\""], but got %s' % (split_args('a=b c="foo bar\\""'))

# Generated at 2022-06-25 01:40:08.710851
# Unit test for function split_args
def test_split_args():

    # test case 0
    test_case_0()

    # test case 1
    bytes_2 = "take an arg and do something with it"
    inputs_1 = bytes_2
    expected_output_1 = ["take", "an", "arg", "and", "do", "something", "with", "it"]
    var_5 = split_args(inputs_1)
    assert var_5 == expected_output_1

    # test case 2
    bytes_3 = "take an arg 'blah blah' and do something with it"
    inputs_2 = bytes_3
    expected_output_2 = ["take", "an", "arg", "blah blah", "and", "do", "something", "with", "it"]
    var_6 = split_args(inputs_2)
    assert var_6 == expected

# Generated at 2022-06-25 01:40:15.768889
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar baz" d') == ['a=b', 'c="foo bar baz"', 'd']
    assert split_args('a=b c="foo bar baz" d e=f') == ['a=b', 'c="foo bar baz"', 'd', 'e=f']
    assert split_args('a=b c="foo bar baz" d e=f g') == ['a=b', 'c="foo bar baz"', 'd', 'e=f', 'g']


# Generated at 2022-06-25 01:40:18.425709
# Unit test for function split_args
def test_split_args():
    # Set up test parameters
    params = 'a=b c="foo bar"'
    
    # Invoke the function
    result = split_args(params)
    assert result == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 01:40:22.137585
# Unit test for function split_args
def test_split_args():
    input_0 = b'a=b c="foo bar"'
    expected_0 = ['a=b', 'c="foo bar"']
    try:
        output_0 = split_args(input_0)
    except Exception as e:
        print("Unexpected exception:", e)
    else:
        assert(output_0 == expected_0)


# Generated at 2022-06-25 01:40:27.623556
# Unit test for function split_args
def test_split_args():
    bytes_0 = 'a=b c="foo bar"'
    var_0 = split_args(bytes_0)
    assert var_0 == ['a=b', 'c="foo bar"']



# Generated at 2022-06-25 01:40:34.346245
# Unit test for function split_args
def test_split_args():
    bytes_0 = "\'foo'"
    var_0 = split_args(bytes_0)

    assert (var_0[0] == "'foo'")

    bytes_1 = "\'{{ foo }}'"
    var_1 = split_args(bytes_1)

    assert var_1[0] == "'{{ foo }}'"

    bytes_2 = "\"{{ foo }}\'\' \'{{ bar }}\'\'\""
    var_2 = split_args(bytes_2)

    assert var_2[0] == "\"{{ foo }}\'\' \'{{ bar }}\'\'"

    bytes_3 = "\"{{ foo }}\'\' \'{{ bar }}\'\'\" \"{{ baz }}\'\' \'{{ quux }}\'\'\""
    var_3 = split_args(bytes_3)


# Generated at 2022-06-25 01:40:39.046212
# Unit test for function split_args

# Generated at 2022-06-25 01:40:46.813580
# Unit test for function split_args
def test_split_args():
    assert '\n'.join(split_args('a=b c="foo bar" \\\n')) == 'a=b \nc="foo bar" \\\n'


    # This test is to ensure that split_args is capable of joining quotes that occur over multiple lines
    # and that end with a backslash
    assert '\n'.join(split_args('a="foo \\\nbar" \\\n')) == 'a="foo \\\nbar" \\\n'


    # This test is to ensure that split_args is capable of joining quotes that occur over multiple lines
    # and that do not end with a backslash
    assert '\n'.join(split_args('a="foo \nbar" \n')) == 'a="foo \nbar" \n'

    # This test is to ensure that split_args is

# Generated at 2022-06-25 01:40:48.579820
# Unit test for function split_args
def test_split_args():
    print("Testing split_args ()")
    test_case_0()
    print("Testcase passed")

# Generated at 2022-06-25 01:41:23.634046
# Unit test for function split_args
def test_split_args():

    # Check that the function returns the expected value
    assert split_args("echo hi") == ['echo', 'hi']

    # Check that the function returns the expected value
    assert split_args("echo hi there") == ['echo', 'hi', 'there']

    # Check that the function returns the expected value
    assert split_args('echo "hi there"') == ['echo', '"hi there"']

    # Check that the function returns the expected value
    assert split_args('echo "hi there" sir') == ['echo', '"hi there"', 'sir']

    # Check that the function returns the expected value
    assert split_args('echo "hi there" sir\n') == ['echo', '"hi there"', 'sir\n']

    # Check that the function returns the expected value

# Generated at 2022-06-25 01:41:30.390900
# Unit test for function split_args
def test_split_args():

    # Set up test inputs
    bytes_0 = None
    var_0 = split_args(bytes_0)

    bytes_1 = "a=b \\\nc=d e=f \\\n g=h 'i=j'"
    var_1 = split_args(bytes_1)

    bytes_2 = "a=b \\\nc=d 'e=f g=h' \\\n i=j"
    var_2 = split_args(bytes_2)

    bytes_3 = "a=b \\\nc=d {% e=f g=h %} \\\n i=j"
    var_3 = split_args(bytes_3)

    bytes_4 = "a=b \\\nc=d {{ e=f g=h }} \\\n i=j"
    var_4 = split_args

# Generated at 2022-06-25 01:41:40.263097
# Unit test for function split_args
def test_split_args():

    assert split_args(None) == []
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('key=value key="value value"') == ['key=value', 'key="value value"']
    assert split_args('k1=v1 k2="v2 v2"') == ['k1=v1', 'k2="v2 v2"']
    assert split_args('k1=v1 k2="v2 v2"') == ['k1=v1', 'k2="v2 v2"']
    assert split_args('k1=v1\nk2="v2 v2"') == ['k1=v1', 'k2="v2 v2"']

# Generated at 2022-06-25 01:41:45.920313
# Unit test for function split_args
def test_split_args():
    data = "a=b c=\"foo bar\""
    assert split_args(data) == ['a=b', 'c="foo bar"']
    data = "a=b c=\"foo bar\"\nd=\"foo bar\""
    assert split_args(data) == ['a=b', 'c="foo bar"\nd="foo bar"']
    data = "a=b c=\"foo bar\"\n"
    assert split_args(data) == ['a=b', 'c="foo bar"\n']


# Generated at 2022-06-25 01:41:51.087815
# Unit test for function split_args
def test_split_args():
    a = 'a=b c="foo bar"'
    test_case_0()

# Tests are run in alphabetical order, so give them a name that will ensure
# they are run first
__test__ = {'API_TESTS': """
>>> test_split_args()
"""}

if __name__ == '__main__':
    # When run as a script, do a test
    print(__test__)

# Generated at 2022-06-25 01:42:00.534600
# Unit test for function split_args
def test_split_args():
    # This method tests the cases below

    # Case 0:
    # Test There should be no arguments, we expect an empty list
    bytes_0 = None
    var_0 = split_args(bytes_0)
    assert var_0 == []

    # Case 1:
    # Test This is the expected behavior
    bytes_1 = 'bob=foo'
    var_1 = split_args(bytes_1)
    assert var_1 == ['bob=foo']

    # Case 2:
    # Test This is the expected behavior
    bytes_2 = 'bob=foo bar bar'
    var_2 = split_args(bytes_2)
    assert var_2 == ['bob=foo', 'bar', 'bar']

    # Case 3:
    # Test This is the expected behavior

# Generated at 2022-06-25 01:42:08.839414
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo'], '''Expected ["foo"], got: ''' + str(split_args('foo'))
    assert split_args('foo bar') == ['foo', 'bar'], '''Expected ["foo", "bar"], got: ''' + str(split_args('foo bar'))
    assert split_args('foo"bar') == ['foo"bar'], '''Expected ["foo \"bar"], got: ''' + str(split_args('foo"bar'))
    assert split_args('foo "bar') == ['foo', '"bar'], '''Expected ["foo", "\"bar"], got: ''' + str(split_args('foo "bar'))

# Generated at 2022-06-25 01:42:16.537894
# Unit test for function split_args
def test_split_args():
    assert split_args(b'a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(b'a=1') == ['a=1']
    assert split_args(b'a=foo bar') == ['a=foo bar']
    assert split_args(b'a=b c="foo bar"\nd=e f="foo bar"') == ['a=b', 'c="foo bar"\nd=e f="foo bar"']
    assert split_args(b'a=b c="foo bar\nfoo bar"') == ['a=b', 'c="foo bar\nfoo bar"']

# Generated at 2022-06-25 01:42:24.889390
# Unit test for function split_args
def test_split_args():
    assert isinstance(split_args('arg1 arg2'), list)
    assert split_args('arg1 arg2') == ['arg1', 'arg2']
    assert split_args('arg1 = arg2') == ['arg1 = arg2']
    assert split_args('this = arg1 arg2 arg3') == ['this = arg1', 'arg2', 'arg3']
    assert split_args('arg1 = "a value" arg2=other arg3="{this is # a comment}"') == ['arg1 = "a value"', 'arg2=other', 'arg3="{this is # a comment}"']
    assert split_args('arg1="a value with a quote (") inside"') == ['arg1="a value with a quote (") inside"']

# Generated at 2022-06-25 01:42:27.163632
# Unit test for function split_args
def test_split_args():
    data = None
    var = split_args(data)



# Generated at 2022-06-25 01:43:36.407466
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []

    assert split_args(' ') == ['']
    assert split_args('   ') == ['']

    assert split_args('"a b"') == ['a b']
    assert split_args('\'a b\'') == ['a b']

    assert split_args('"a b ') == ['"a b ']
    assert split_args('"a b \'') == ['"a b \'']

    assert split_args('"a b c') == ['"a b c']
    assert split_args('"a b c ') == ['"a b c ']
    assert split_args('"a b c \'') == ['"a b c \'']

    assert split_args('a   b   c') == ['a', 'b', 'c']


# Generated at 2022-06-25 01:43:47.254319
# Unit test for function split_args
def test_split_args():
    assert split_args(u'echo "foo bar"') == [u'echo', u'"foo bar"']
    # syntax error: unsupported character u'\xa0'
    #assert split_args(u'contains("aâ.txt", "aâ.txt")') == [u'contains("aâ.txt", "aâ.txt")']
    #assert split_args(u'contains("aâ.txt" "aâ.txt")') == [u'contains("aâ.txt" "aâ.txt")']
    assert split_args(u'contains("a.txt" "a.txt")') == [u'contains("a.txt" "a.txt")']

# Generated at 2022-06-25 01:43:58.050485
# Unit test for function split_args
def test_split_args():
    var_0 = split_args('foo')
    assert var_0 == ['foo'], var_0
    var_1 = split_args('foo bar')
    assert var_1 == ['foo', 'bar'], var_1
    var_2 = split_args('foo="bar"')
    assert var_2 == ['foo="bar"'], var_2
    var_3 = split_args('foo="bar bar"')
    assert var_3 == ['foo="bar bar"'], var_3
    var_4 = split_args('foo="bar bar" bar="foo foo"')
    assert var_4 == ['foo="bar bar"', 'bar="foo foo"'], var_4
    var_5 = split_args('foo="bar bar" bar=\'foo foo\'')

# Generated at 2022-06-25 01:44:00.349025
# Unit test for function split_args
def test_split_args():
    # Do not change anything below.
    assert test_case_0() == None

# Execute this file directly or through the unit test
if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:44:04.484395
# Unit test for function split_args
def test_split_args():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()



# Generated at 2022-06-25 01:44:10.225298
# Unit test for function split_args
def test_split_args():
    def check(args, expected):
        result = split_args(args)
        assert result == expected, 'split_args("%s") returned %r, expected %r' % (args, result, expected)

    check("", [])

    check("a=b c='foo bar'", ['a=b', 'c=\'foo bar\''])
    check("a='b c'", ['a=\'b c\''])
    check("a='b c", ['a=\'b', 'c'])
    check("a=b c='foo bar", ['a=b', 'c=\'foo bar'])
    check("a=b c=foo bar", ['a=b', 'c=foo', 'bar'])

# Generated at 2022-06-25 01:44:14.448102
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            args=dict(type='str', required=True),
        )
    )
    args = module.params['args']

    params = split_args(args)

    module.exit_json(changed=False, meta=params)


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:44:19.406503
# Unit test for function split_args
def test_split_args():
    print("start split_args")
    bytes_0 = None
    var_0 = split_args(bytes_0)
    print("var_0 = " + str(var_0))
    print("end split_args")


# Generated at 2022-06-25 01:44:30.463856
# Unit test for function split_args

# Generated at 2022-06-25 01:44:30.930193
# Unit test for function split_args
def test_split_args():
    return True

# Generated at 2022-06-25 01:47:18.976294
# Unit test for function split_args
def test_split_args():
    # test case 0
    bytes_0 = None
    var_0 = split_args(bytes_0)
    assert len(var_0) == 0, 'Expected [], got %s' % var_0
    # test case 1
    bytes_1 = 'foo bar\nbiz baz'
    var_1 = split_args(bytes_1)
    assert len(var_1) == 2, 'Expected len [2], got %s' % len(var_1)
    assert var_1[0] == 'foo bar\nbiz baz' or var_1[1] == 'foo bar\nbiz baz', \
        'Expected \'foo bar\nbiz baz\' or \'foo bar\nbiz baz\', got %s, %s' % (var_1[0], var_1[1])

# Generated at 2022-06-25 01:47:23.775067
# Unit test for function split_args
def test_split_args():
    func_call_0 = "this is a test"
    func_call_1 = None

    result_0 = split_args(func_call_0)
    result_1 = split_args(func_call_1)

    assert result_0 == ['this', 'is', 'a', 'test']
    assert result_1 == []



# Generated at 2022-06-25 01:47:25.061891
# Unit test for function split_args
def test_split_args():
    # First test case
    test_case_0()


# Unit testing

# Generated at 2022-06-25 01:47:33.063297
# Unit test for function split_args
def test_split_args():
    # Test for the function split_args
    assert split_args(b'split_args') == ['split_args']
    assert split_args(b'a=b c=d') == ['a=b', 'c=d']
    assert split_args(b'split_args "a=b c=d"') == ['split_args', 'a=b c=d']
    assert split_args(b'split_args "a=b c=d" e=f') == ['split_args', 'a=b c=d', 'e=f']
    assert split_args(b'split_args "a=b c=d" "e=f g=h"') == ['split_args', 'a=b c=d', 'e=f g=h']

# Generated at 2022-06-25 01:47:35.507771
# Unit test for function split_args
def test_split_args():
    assert split_args(None) == [], (
        "The function 'split_args' failed to split")



# Generated at 2022-06-25 01:47:44.712126
# Unit test for function split_args
def test_split_args():
    # Test case with 0 params, should succeed
    test_case_0()
    # Test case with 1 params, should succeed
    test_case_1()
    # Test case with 2 params, should succeed
    test_case_2()
    # Test case with 3 params, should succeed
    test_case_3()
    # Test case with 4 params, should succeed
    test_case_4()
    # Test case with 5 params, should succeed
    test_case_5()
    # Test case with 6 params, should succeed
    test_case_6()
    # Test case with 7 params, should succeed
    test_case_7()
    # Test case with 8 params, should succeed
    test_case_8()
    # Test case with 9 params, should succeed
    test_case_9()
    # Test case with 10 params, should

# Generated at 2022-06-25 01:47:46.421045
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']



# Generated at 2022-06-25 01:47:57.299037
# Unit test for function split_args
def test_split_args():
    print('Testing function split_args')


# Generated at 2022-06-25 01:48:04.304811
# Unit test for function split_args
def test_split_args():
  print('Test split_args')
  res = split_args('a b c')
  assert res == ['a', 'b', 'c']
  res = split_args('a="b c"')
  assert res == ['a="b c"']
  res = split_args('a="b c" d')
  assert res == ['a="b c"', 'd']
  res = split_args('a b c d')
  assert res == ['a', 'b', 'c', 'd']
  res = split_args('a=b c="d e"')
  assert res == ['a=b', 'c="d e"']
  res = split_args('a="b c" d="e f"')
  assert res == ['a="b c"', 'd="e f"']


# Generated at 2022-06-25 01:48:12.303759
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []

    # basic whitespace split
    assert split_args('a b c') == ['a', 'b', 'c']

    # simple quotes
    assert split_args('a b c d="foo bar" e') == ['a', 'b', 'c', 'd="foo bar"', 'e']

    # simple quotes (apostrophe)
    assert split_args("a b c d='foo bar' e") == ['a', 'b', 'c', "d='foo bar'", 'e']

    # braces in quotes
    assert split_args('a b c d="foo { bar" e') == ['a', 'b', 'c', 'd="foo { bar"', 'e']

    # braces in quotes (apostrophe)