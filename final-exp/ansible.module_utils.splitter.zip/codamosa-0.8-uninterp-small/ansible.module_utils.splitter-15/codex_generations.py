

# Generated at 2022-06-25 01:39:30.834417
# Unit test for function split_args
def test_split_args():
    out_expected = {'foo': 'bar'}
    out_received = split_args('foo=bar')
    success = out_expected == out_received

    msg = "Expected {0}, received {1}".format(out_expected, out_received)
    assert success is True, msg

    out_expected = {'foo': 'bar', 'bam': 'baz'}
    out_received = split_args('foo=bar bam=baz')
    success = out_expected == out_received

    msg = "Expected {0}, received {1}".format(out_expected, out_received)
    assert success is True, msg

    out_expected = {'foo': 'bar', 'bam': 'baz'}
    out_received = split_args('foo=bar\nbam=baz')


# Generated at 2022-06-25 01:39:41.862888
# Unit test for function split_args

# Generated at 2022-06-25 01:39:52.383875
# Unit test for function split_args
def test_split_args():
    dict_0 = "bar baz=foo"
    dict_1 = "bar 'baz foo'"
    dict_2 = "bar \"baz foo\""
    dict_3 = "bar {{baz foo}}"
    dict_4 = "bar {%baz foo%}"
    dict_5 = "bar {#baz foo#}"
    dict_6 = "bar 'baz \"foo\"'"
    dict_7 = "bar \"baz 'foo'\""
    dict_8 = "bar 'baz\nfoo'"
    dict_9 = "bar 'baz\\nfoo'"
    dict_10 = "bar 'baz\\n\nfoo'"
    dict_11 = "bar 'baz\\n\nfoo'"
    dict_12 = "bar 'baz\n\\nfoo'"
    dict_

# Generated at 2022-06-25 01:40:02.759428
# Unit test for function split_args
def test_split_args():
    # these are the sample cases that I've used in pytest tests
    # the ones marked 'nt' are the ones that were taken out because I wasn't sure of how to convert
    # them to tests in the pytest framework (maybe someday!)

    # simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # split over a space in quotes
    assert split_args('a=b c="foo bar" d=e') == ['a=b', 'c="foo bar"', 'd=e']

    # split over a space in quotes and jinja2 blocks

# Generated at 2022-06-25 01:40:09.177604
# Unit test for function split_args
def test_split_args():
    # this is a really simple test, since we can't really
    # test it continuously without a response which we won't have
    # until we know what the module will do in the future.
    # Right now, the only thing we do when a response is passed in
    # is to assume it's json and try to parse it.
    #import sys
    #sys.argv.append('--debug')
    #import pdb
    #pdb.set_trace()
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']

    assert split_args("a b") == ['a', 'b']
    assert split_args("a\nb") == ['a', 'b']
    assert split_args("a\nb\c") == ['a', 'b\c']
    assert split

# Generated at 2022-06-25 01:40:12.583919
# Unit test for function split_args
def test_split_args():
    test_cases = []
    for test_case in test_cases:
        print('Running test case: ' + test_case.__name__)
        test_case()

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:40:20.648083
# Unit test for function split_args
def test_split_args():
    assert split_args('hello world') == ['hello', 'world']
    assert split_args('hello"worl d"') == ['hello"worl d"']
    assert split_args('hello"worl d"foo') == ['hello"worl d"foo']
    assert split_args('hello"worl\'d"foo') == ['hello"worl\'d"foo']
    assert split_args('hello"worl\'d"foo') == ['hello"worl\'d"foo']
    assert split_args('hello "foo bar"') == ['hello', '"foo bar"']
    assert split_args('hello "foo\\" bar"') == ['hello', '"foo\\" bar"']

# Generated at 2022-06-25 01:40:31.668987
# Unit test for function split_args
def test_split_args():
    # these are cases that fail
    #test_case_0()

    # these are cases that pass
    #dict_1 = "should_fail"
    #var_1 = split_args(dict_1)
    dict_2 = ""
    var_2 = split_args(dict_2)
    dict_3 = "one two three"
    var_3 = split_args(dict_3)
    dict_4 = "one 'two three'"
    var_4 = split_args(dict_4)
    dict_5 = "one \"two three\""
    var_5 = split_args(dict_5)
    dict_6 = "one 'two three'"
    var_6 = split_args(dict_6)
    dict_7 = "one \"two three\""

# Generated at 2022-06-25 01:40:40.710457
# Unit test for function split_args
def test_split_args():
    assert split_args("echo ''") == [ 'echo', "''" ]
    assert split_args("this 'is a' test") == [ 'this', "'is a'", 'test' ]
    assert split_args("echo \"foo $PATH bar\"") == [ 'echo', '"foo $PATH bar"' ]
    assert split_args("echo 'foo $PATH bar'") == [ 'echo', "'foo $PATH bar'" ]
    assert split_args("echo '{{ foo.bar }}'") == [ 'echo', "'{{ foo.bar }}'" ], split_args("echo '{{ foo.bar }}'")
    assert split_args("echo '{% if foo %}{{ bar }}{% endif %}'") == [ 'echo', "'{% if foo %}{{ bar }}{% endif %}'" ]

# Generated at 2022-06-25 01:40:50.298994
# Unit test for function split_args
def test_split_args():
    test_case_0()
    # print(split_args(''))
    # print(split_args('a="foo bar"'))
    # print(split_args('a=1'))
    # print(split_args('a=1 b=2'))
    # print(split_args('a={{ foo.bar }}'))
    # print(split_args('a={{ foo.bar }} b={{ foo.baz }}'))
    # print(split_args('a={{ foo.bar }} b="{{ foo.baz }}"'))
    # print(split_args('a="{{ foo.bar }} b=" c={{ foo.baz }}'))
    # print(split_args('a=b c="foo bar"'))
    # print(split_args('a=b c="foo bar" d="

# Generated at 2022-06-25 01:41:11.466254
# Unit test for function split_args
def test_split_args():
    args = "a=b c='d e'   f=\"g h\""
    params = split_args(args)
    assert len(params) == 3
    assert params[0] == 'a=b'
    assert params[1] == "c='d e'"
    assert params[2] == 'f="g h"'

    args = "a=b c='d e'   f=\"g h\""
    params = split_args(args)
    assert len(params) == 3
    assert params[0] == 'a=b'
    assert params[1] == "c='d e'"
    assert params[2] == 'f="g h"'

    # test case that matches the problem in issue #16105

# Generated at 2022-06-25 01:41:22.530130
# Unit test for function split_args
def test_split_args():
    assert split_args("a b   c") ==  ["a", "b", "c"]
    assert split_args("\"a b\" c") ==  ["\"a b\"", "c"]
    assert split_args("\"a b\" c d") ==  ["\"a b\"", "c", "d"]
    assert split_args("\"a b\"\\\n c") ==  ["\"a b\" c"]
    assert split_args("\"a b\"\\\n c") ==  ["\"a b\" c"]
    assert split_args("\"a {{ b \" c") ==  ["\"a {{ b \"", "c"]
    assert split_args("\"a {% b \" c") ==  ["\"a {% b \"", "c"]

# Generated at 2022-06-25 01:41:24.448443
# Unit test for function split_args
def test_split_args():

    print("test_case_0")
    test_case_0()

test_split_args()

# Generated at 2022-06-25 01:41:29.231225
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('c="a=b c=\\"foo bar\\""') == ['c="a=b c=\\"foo bar\\""']
    assert split_args('a="foo bar" c="foo bar"') == ['a="foo bar"', 'c="foo bar"']

# Generated at 2022-06-25 01:41:29.971120
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Generated at 2022-06-25 01:41:39.784219
# Unit test for function split_args
def test_split_args():
    dict_0 = None
    var_1 = split_args(dict_0)
    assert(var_1 == [])

    dict_1 = 'a=b c="foo bar"'
    var_2 = split_args(dict_1)
    assert(var_2 == ['a=b', 'c="foo bar"'])

    dict_2 = 'a=b c="foo bar" d="a \\" b"'
    var_3 = split_args(dict_2)
    assert(var_3 == ['a=b', 'c="foo bar"', 'd="a \\" b"'])

    dict_3 = "a=1 b=\"foo {{ bar }} baz\" c=\"foo\\nbar\" d='foo {{ bar }} baz' e='foo\\nbar'"

# Generated at 2022-06-25 01:41:47.160819
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c={{ foo.bar }} d='foo bar'") == ['a=b', 'c={{ foo.bar }}', "d='foo bar'"]
    assert split_args("a=b c={% foo.bar %} d=\"foo bar\"") == ['a=b', 'c={% foo.bar %}', 'd="foo bar"']
    assert split_args("a=b c={# foo.bar #} d=\"foo bar\"") == ['a=b', 'c={# foo.bar #}', 'd="foo bar"']

# Generated at 2022-06-25 01:41:51.803602
# Unit test for function split_args
def test_split_args():
    assert (split_args("var='a' b='c' d=e f=[[a,b],[c,d],[e]]") == ["var=a", "b=c", "d=e", "f=[[a,b],[c,d],[e]]"])
    assert (split_args("var='a' b='c' d=e f=[[a,b],[c,d],[e]]") == ["var=a", "b=c", "d=e", "f=[[a,b],[c,d],[e]]"])
    assert (split_args("var1='a' var2='b'") == ["var1=a", "var2=b"])

# Generated at 2022-06-25 01:42:00.593326
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo\\\"bar\"") == ['a=b', 'c="foo\\"bar"']
    assert split_args("a=b c='foo\\'bar'") == ['a=b', 'c=\'foo\\\'bar\'']
    assert split_args("a=b c='foo bar'") == ['a=b', 'c=\'foo bar\'']
    assert split_args("a=b c=foo\\ bar") == ['a=b', 'c=foo\\ bar']
    assert split_args("a=b c={foo}") == ['a=b', 'c={foo}']

# Generated at 2022-06-25 01:42:08.894298
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b") == ["a=b"]
    assert split_args("--force") == ["--force"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b \"c d\"") == ["a=b", "\"c d\""]
    assert split_args("a=b c=\"d e\"") == ["a=b", "c=\"d e\""]
    assert split_args("a=b c='d e'") == ["a=b", "c='d e'"]
    assert split_args("a=b \"c\\nd\"") == ["a=b", "\"c\\nd\""]
    assert split_args("a=b \"c\\\\nd\"") == ["a=b", "\"c\\\\nd\""]

# Generated at 2022-06-25 01:42:30.043430
# Unit test for function split_args
def test_split_args():
    dict_0 = '"key1=value1" "key2=value2"'
    var_0 = split_args(dict_0)
    # assert var_0 == ['key1=value1', 'key2=value2']
    #assert var_0 is not None and var_0.__class__.__name__ == 'list'
    if var_0 is not None and var_0.__class__.__name__ == 'list':
        assert var_0 == ['key1=value1', 'key2=value2']
    else:
        assert False


# Generated at 2022-06-25 01:42:38.366994
# Unit test for function split_args
def test_split_args():
    # Test function with single argument
    test_case_0()

    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]
    assert split_args("foo \"bar baz\"") == ["foo", "\"bar baz\""]
    assert split_args("a=\"b c\" d=\"e f\"") == ["a=\"b c\"", "d=\"e f\""]
    assert split_args("a={{foo}} b={{bar}}") == ["a={{foo}}", "b={{bar}}"]
    assert split_args("a={%foo%} b={%bar%}") == ["a={%foo%}", "b={%bar%}"]

# Generated at 2022-06-25 01:42:43.847216
# Unit test for function split_args
def test_split_args():
    dict_0 = 'user@hostname:/tmp/test.txt'
    var_0 = split_args(dict_0)

    assert var_0[0] == 'user@hostname:/tmp/test.txt'

    dict_1 = 'user@hostname'
    var_1 = split_args(dict_1)

    assert var_1[0] == 'user@hostname'

    dict_2 = 'user@hostname /tmp/test.txt'
    var_2 = split_args(dict_2)

    assert var_2[0] == 'user@hostname'
    assert var_2[1] == '/tmp/test.txt'

    dict_3 = 'user@hostname "tmp/test.txt'
    var_3 = split_args(dict_3)


# Generated at 2022-06-25 01:42:50.811062
# Unit test for function split_args
def test_split_args():
    var_0 = split_args("a=b c=\"foo bar\"")
    var_1 = split_args("a=b c=\"foo bar\" d='foo bar'")
    var_2 = split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\"")
    var_3 = split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\" f='foo bar'")
    var_4 = split_args("a=b c=\"\\\"foo\\\" bar\" d='foo bar'")
    var_5 = split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\" f='foo bar' g=\"foo bar\" h='foo bar'")

# Generated at 2022-06-25 01:43:00.138207
# Unit test for function split_args

# Generated at 2022-06-25 01:43:10.436590
# Unit test for function split_args
def test_split_args():

    assert split_args("foo=bar") == ['foo=bar']
    assert split_args("foo='bar baz'") == ['foo=\'bar baz\'']
    assert split_args("foo='bar \'baz'") == ['foo=\'bar \'baz\'']
    assert split_args("foo=\"bar baz\"") == ['foo="bar baz"']
    assert split_args("foo=\"bar \'baz\"") == ['foo="bar \'baz"']
    assert split_args("foo=\"bar \'baz\" jinja2_jinja2_jinja2") == ['foo="bar \'baz" jinja2_jinja2_jinja2']

# Generated at 2022-06-25 01:43:16.508547
# Unit test for function split_args
def test_split_args():
    dict_0 = "a=1 b=2 c=3"
    var_0 = split_args(dict_0)
    assert var_0 == ['a=1', 'b=2', 'c=3']


# Generated at 2022-06-25 01:43:27.285283
# Unit test for function split_args
def test_split_args():
    # Return value should be equal to: []
    dict_0 = ''
    var_0 = split_args(dict_0)
    assert var_0 == []

    # Return value should be equal to: ['one', 'two', 'three']
    dict_1 = 'one two three'
    var_1 = split_args(dict_1)
    assert var_1 == ['one', 'two', 'three']

    # Return value should be equal to: ['a', 'b', 'c']
    dict_2 = 'a b c'
    var_2 = split_args(dict_2)
    assert var_2 == ['a', 'b', 'c']

    # Return value should be equal to: ['a=b', 'c=d']
    dict_3 = 'a=b c=d'

# Generated at 2022-06-25 01:43:36.354027
# Unit test for function split_args
def test_split_args():
    test_case_0()
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('a="foo  bar" c=d') == ['a="foo  bar"', 'c=d']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 01:43:37.522642
# Unit test for function split_args
def test_split_args():
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:44:00.211160
# Unit test for function split_args
def test_split_args():

    # Tests for function 'split_args'
    print("# Testing function split_args")
    print("Test case 0")
    try:
        dict_0 = None
        v_0 = split_args(dict_0)
    except Exception:
        print("Test case 0: Fail\n")
    else:
        if v_0 != []:
            print("Test case 0: Pass\n")
        else:
            print("Test case 0: Fail\n")
    print("Test case 1")
    try:
        dict_1 = ['a=b c="foo bar"']
        v_1 = split_args(dict_1)
    except Exception:
        print("Test case 1: Fail\n")

# Generated at 2022-06-25 01:44:08.658870
# Unit test for function split_args
def test_split_args():
    comp_0 = "ssh-agent bash -c 'ssh-add /opt/local/home/vivek/.ssh/id_rsa'"
    comp_1 = "df -h"
    dict_0 = "command: %s" % comp_0
    dict_1 = "command: %s" % comp_1
    var_0 = split_args(dict_0)
    var_1 = split_args(dict_1)
    if len(var_0) == len(var_1):
        if 'command: ssh-agent bash -c \'ssh-add /opt/local/home/vivek/.ssh/id_rsa\'' == ' '.join(var_0):
            print('SUCCESS')
        else:
            print('FAIL')
    else:
        print('FAIL')



# Generated at 2022-06-25 01:44:16.278483
# Unit test for function split_args
def test_split_args():
    dict_1 = 'a=b c="foo bar"'
    var_1 = split_args(dict_1)
    dict_2 = 'a=b c="foo bar"'
    var_2 = split_args(dict_2)
    dict_3 = 'a=b c="foo bar"'
    var_3 = split_args(dict_3)
    assert var_2 == ['a=b', 'c="foo bar"']
    assert var_1 ==  var_2


# Generated at 2022-06-25 01:44:16.991427
# Unit test for function split_args
def test_split_args():
    assert callable(split_args)


# Generated at 2022-06-25 01:44:17.964848
# Unit test for function split_args
def test_split_args():
    assert split_args('"a b c=d"')



# Generated at 2022-06-25 01:44:21.315788
# Unit test for function split_args
def test_split_args():
    if type(dict_0) == type(None) or type(var_0) == type(None):
        pass
    else:
        assert var_0 == dict_0, "Expected [%s], got [%s]" % (dict_0, var_0)

    dict_0 = ""
    var_0 = split_args(dict_0)


# Generated at 2022-06-25 01:44:24.712442
# Unit test for function split_args
def test_split_args():

    # Test cases to test the split_args function
    # Setup
    test_case_0()


if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:44:31.942854
# Unit test for function split_args
def test_split_args():
    # Testing with a dictionary
    print("Testing with a dictionary...")
    dict_0 = "ansible_ssh_pass='password' ansible_become_pass='password' ansible_ssh_user='root' ansible_ssh_private_key_file='/root/ssh-keys/key1.pem' ansible_become_user='root'"
    var_0 = split_args(dict_0)
    assert var_0 == ['ansible_ssh_pass=\'password\'', 'ansible_become_pass=\'password\'', 'ansible_ssh_user=\'root\'', 'ansible_ssh_private_key_file=\'/root/ssh-keys/key1.pem\'', 'ansible_become_user=\'root\'']



# Generated at 2022-06-25 01:44:32.835168
# Unit test for function split_args
def test_split_args():
    test_case_0()
    print("Test case 0 passed")

# Generated at 2022-06-25 01:44:39.289529
# Unit test for function split_args

# Generated at 2022-06-25 01:44:57.133098
# Unit test for function split_args
def test_split_args():
    dict_0 = "wibble nugget foo bar"
    var_0 = split_args(dict_0)


# Generated at 2022-06-25 01:45:06.389399
# Unit test for function split_args
def test_split_args():
    assert unquote(u"hell\u00F6") == u"hell\u00F6"
    assert split_args(u"a=b c=\"foo bar\"") == [u"a=b", u"c=\"foo bar\""]
    assert split_args(u"a=b c=\"foo bar\"") == [u"a=b", u"c=\"foo bar\""]
    assert split_args(u"a=b c=\"foo bar\" d=\"panic\"") == [u"a=b", u"c=\"foo bar\"", u"d=\"panic\""]
    assert split_args(u"a=b c=\"foo bar\" d=\"{{panic}}\"") == [u"a=b", u"c=\"foo bar\"", u"d=\"{{panic}}\""]

# Generated at 2022-06-25 01:45:15.164314
# Unit test for function split_args
def test_split_args():
    dict_0 = "foo=yes"
    var_0 = split_args(dict_0)
    assert var_0 == ['foo=yes']
    dict_1 = '''spaced string'''
    var_1 = split_args(dict_1)
    assert var_1 == ['spaced string']
    dict_2 = '''key=value key2=value2'''
    var_2 = split_args(dict_2)
    assert var_2 == ['key=value', 'key2=value2']
    dict_3 = '''"quoted key"=value'''
    var_3 = split_args(dict_3)
    assert var_3 == ['"quoted key"=value']
    dict_4 = '''"quoted key"=value key2=value2'''
    var_

# Generated at 2022-06-25 01:45:21.043345
# Unit test for function split_args
def test_split_args():
    dict_0 = 'a=b c="foo bar"'
    assert split_args(dict_0) == ['a=b', 'c="foo bar"']
    dict_0 = 'a=b c="{% if foo %}foo{% else %}bar{% endif %}"'
    assert split_args(dict_0) == ['a=b', 'c="{% if foo %}foo{% else %}bar{% endif %}"']
    dict_0 = 'a=b c="{% if foo %}foo{% else %}bar{# foo #}{% endif %}"'
    assert split_args(dict_0) == ['a=b', 'c="{% if foo %}foo{% else %}bar{# foo #}{% endif %}"']

# Generated at 2022-06-25 01:45:26.093167
# Unit test for function split_args
def test_split_args():
    assert len(split_args("")) == 0
    assert len(split_args("    ")) == 0
    assert len(split_args("a=b")) == 1
    assert len(split_args("a b")) == 2
    assert len(split_args("a=\"b c\"")) == 1
    assert len(split_args("a b c")) == 3
    assert len(split_args("a='b c'")) == 1
    assert len(split_args("a\n b\n c")) == 3
    assert len(split_args("a='b\nc d'")) == 1
    assert len(split_args("a='b\nc\nd'")) == 1
    assert len(split_args("a\n'b\nc\nd'")) == 2

# Generated at 2022-06-25 01:45:29.571329
# Unit test for function split_args
def test_split_args():
    test_case_0()



# Generated at 2022-06-25 01:45:30.186716
# Unit test for function split_args
def test_split_args():
    test_case_0()


# Generated at 2022-06-25 01:45:39.628962
# Unit test for function split_args
def test_split_args():
    assert unquote(split_args("foo bar")[0]) == 'foo'
    assert unquote(split_args("foo bar")[1]) == 'bar'
    assert unquote(split_args("foo bar baz ")[2]) == 'baz'
    assert unquote(split_args("foo=bar")[0]) == 'foo=bar'
    assert unquote(split_args("foo='bar'")[0]) == "foo='bar'"
    assert unquote(split_args("foo=\"bar\"")[0]) == 'foo="bar"'
    assert unquote(split_args("foo=[bar]")[0]) == 'foo=[bar]'
    assert unquote(split_args("foo=[bar]")[0]) == 'foo=[bar]'

# Generated at 2022-06-25 01:45:40.783737
# Unit test for function split_args
def test_split_args():
    # No exception raised
    test_case_0()


# Helper function for test_unquote

# Generated at 2022-06-25 01:45:44.257092
# Unit test for function split_args
def test_split_args():
    assert split_args({}) == None
    assert split_args("") == []


# Generated at 2022-06-25 01:46:09.987459
# Unit test for function split_args
def test_split_args():
    dict_0 = 'a=b c="foo bar"'
    var_0 = split_args(dict_0)

    assert(var_0 == ['a=b', 'c="foo bar"'])



# Generated at 2022-06-25 01:46:19.690374
# Unit test for function split_args
def test_split_args():
    # normal args
    assert split_args("foo bar baz") == ['foo', 'bar', 'baz']

    # quoted strings
    assert split_args("foo='bar' baz=quux") == ["foo='bar'", "baz=quux"]

    # quoted strings with spaces
    assert split_args("foo='bar baz' fuz=fuz") == ["foo='bar baz'", "fuz=fuz"]

    # escaped quotes
    assert split_args("foo='bar\\' baz' fuz=fuz") == ["foo='bar\\' baz'", "fuz=fuz"]

    # jinja2 block

# Generated at 2022-06-25 01:46:29.379260
# Unit test for function split_args
def test_split_args():
    my_args = """name=hello world
            key=value
            foo='bar baz'
            ham=spam
            eggs='bacon spam'
            multiple_words='foo bar baz'
            """

    params = split_args(my_args)
    assert params == ["name=hello world", "key=value", "foo='bar baz'", "ham=spam", "eggs='bacon spam'",
                      "multiple_words='foo bar baz'"]

    params = split_args("name=hello")
    assert params == ["name=hello"]

    params = split_args("name=hello\n")
    assert params == ["name=hello"]

    params = split_args("name=hello\n\n")
    assert params == ["name=hello"]


# Generated at 2022-06-25 01:46:34.899490
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=\"b b\"") == ['a="b b"']
    assert split_args("a=\"b b\" c=\"d d\"") == ['a="b b"', 'c="d d"']
    assert split_args("a=\"\\\"b\\\" b\"") == ['a="\"b\" b"']
    assert split_args("a='\\'b\\' b'") == ["a='\'b\' b'"]
    assert split_args("{{ foo }}") == ["{{ foo }}"]
    assert split_args("{{ foo }} bar") == ["{{ foo }}", "bar"]
    assert split_args("{% foo %}") == ['{% foo %}']

# Generated at 2022-06-25 01:46:39.962022
# Unit test for function split_args
def test_split_args():
    print("\n\nran test_split_args\n\n")
    # Tests
    test_case_0()
    # Test cases that are not unbalanced or mixed quotes
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    # Test cases that are unbalanced
    # test_case_6()
    # test_case_7()
    # test_case_8()
    # test_case_9()
    test_case_10()



# Generated at 2022-06-25 01:46:47.433546
# Unit test for function split_args
def test_split_args():
    dict_0 = '<13>1 2017-04-20T11:51:58+00:00 hostname.domain.com CEF:0|Vendor|Product|Version|1000|Message|10|src=10.1.1.1 act=Accepted dst=1.1.1.1 deviceDirection=0 duser=user dvc=192.168.1.1 in=1 out=1'
    var_0 = split_args(dict_0)

# Generated at 2022-06-25 01:46:49.287396
# Unit test for function split_args
def test_split_args():
    assert test_case_0() is None


# Generated at 2022-06-25 01:46:56.651474
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b \\\nc="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b \\\n c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b \\\n \\\nc="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b \n c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b \n\n c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-25 01:47:01.574924
# Unit test for function split_args
def test_split_args():
    # Handle case where there is no args
    test_case_0()
    # Handle case where there is an invalid ansible type
    pass

if __name__ == "__main__":
    # Unit test for function split_args
    test_split_args()

# Generated at 2022-06-25 01:47:10.651195
# Unit test for function split_args
def test_split_args():
    dict_0 = "a=b c='foo bar'"
    dict_1 = "a=b c=\"foo bar\""
    dict_2 = "a=b c='foo \nbar'"
    dict_3 = "a=b c='foo \nbar'"
    dict_4 = "a=b c=\"foo \nbar\""
    dict_5 = "a=b c='foo \nbar'"
    dict_6 = "a=b c='foo \nbar'"
    dict_7 = "a=b c=\"foo \nbar\""
    dict_8 = "a=b c=\"foo \nbar\""
    dict_9 = "a=b c=\"foo bar\""
    dict_10 = "a=b c=foo"
    dict_11 = "a=b c=\"foo"
    dict

# Generated at 2022-06-25 01:47:34.536816
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('a=b c=\\"foo bar\\"') == ['a=b', 'c=\\"foo bar\\"']
    assert split_args('a=b c=\\\'foo bar\\\'') == ['a=b', 'c=\\\'foo bar\\\'']
    assert split_args('a=b c="foo bar\\nfoo bar\\n"') == ['a=b', 'c="foo bar\\nfoo bar\\n"']

# Generated at 2022-06-25 01:47:37.720684
# Unit test for function split_args
def test_split_args():
    dict_0 = 'a=b c="foo bar"'
    assert split_args(dict_0) == ['a=b', 'c="foo bar"']


# Generated at 2022-06-25 01:47:39.115567
# Unit test for function split_args
def test_split_args():
    assert(unquote("'hello hello'") == 'hello hello')



# Generated at 2022-06-25 01:47:48.499393
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    # Run test cases
    test_case_0()


if __name__ == "__main__":
    test_split_args()


################################################################################
# Documentation
################################################################################


# Generated at 2022-06-25 01:47:50.643557
# Unit test for function split_args
def test_split_args():
    dict_0 = 'a=b c="foo bar"';
    expect_0 = ['a=b', 'c="foo bar"']
    assert split_args(dict_0) == expect_0



# Generated at 2022-06-25 01:47:53.312443
# Unit test for function split_args
def test_split_args():
    test_case_0()


if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:48:02.187327
# Unit test for function split_args
def test_split_args():
    result = split_args('a=b c="foo bar"')
    assert result == ['a=b', 'c="foo bar"']
    result = split_args('a="{{var1}}" b={{var2}}')
    assert result == ['a="{{var1}}"', 'b={{var2}}']
    result = split_args('c="{{var1}}" d={{var2}}')
    assert result == ['c="{{var1}}"', 'd={{var2}}']
    result = split_args('foo="{{ pkg_mgr | default(\'apt-get\') }}"')
    assert result == ['foo="{{ pkg_mgr | default(\'apt-get\') }}"']
    result = split_args('foo="bar baz" "foobar123"')
    assert result

# Generated at 2022-06-25 01:48:11.817018
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args("a={{ b }} c='foo bar'") == ['a={{', 'b', '}}', "c='foo bar'"]
    assert split_args("a={{ b }} c='foo bar'") == ['a={{', 'b', '}}', "c='foo bar'"]
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\') == ['a=b', 'c="foo bar\\']
    assert split_args('a=b c="foo bar\\"') == ['a=b', 'c="foo', 'bar\\"']

# Generated at 2022-06-25 01:48:16.560874
# Unit test for function split_args
def test_split_args():
    _assert_equal(
        split_args(''),
        '')
    _assert_equal(
        split_args('a=b c="foo bar"'),
        'a=b c="foo bar"')
    _assert_equal(
        split_args('b=$var c="foo bar"'),
        'b=$var c="foo bar"')
    _assert_equal(
        split_args('b={{var}} c="foo bar"'),
        'b={{var}} c="foo bar"')
    _assert_equal(
        split_args('b={{ var }} c="foo bar"'),
        'b={{ var }} c="foo bar"')

# Generated at 2022-06-25 01:48:26.905181
# Unit test for function split_args
def test_split_args():
    # set up test cases
    dict_0 = ""
    dict_1 = "a=b c=d"
    dict_2 = "a=b \"c= d\""
    dict_3 = "a=b \"c=''d\""
    dict_4 = "a=b \"c=''d\\\"\""
    dict_5 = "a=b \"c=''d\\\\\\\"\""
    dict_6 = "a=b {{ c='d' }}"
    dict_7 = "a=b {{ \"c='d'\" }}"
    dict_8 = "a=b {{ c='d' }}{{ d='e' }}"
    dict_9 = "a=b {% c='d' %} {% d='e' %}"