

# Generated at 2022-06-25 01:39:01.968316
# Unit test for function split_args
def test_split_args():
    list_0 = ['foo', 'bar']
    var_0 = split_args(list_0)
    list_1 = ['foo', 'bar']
    var_1 = split_args(list_1)
    list_2 = ['foo', 'bar']
    var_2 = split_args(list_2)
    list_3 = ['foo', 'bar']
    var_3 = split_args(list_3)
    list_4 = ['foo', 'bar']
    var_4 = split_args(list_4)
    list_5 = ['foo', 'bar']
    var_5 = split_args(list_5)
    list_6 = ['foo', 'bar']
    var_6 = split_args(list_6)
    list_7 = ['foo', 'bar']

# Generated at 2022-06-25 01:39:11.592013
# Unit test for function split_args
def test_split_args():
    # Check the first test case
    assert split_args('foo') == ['foo']

    # Check the other test cases
    assert split_args('"foo"') == ['"foo"']
    assert split_args("'foo'") == ["'foo'"]
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args("'foo bar'") == ["'foo bar'"]
    assert split_args('"foo bar"') == ['"foo bar"']
    assert split_args('foo "bar blah"') == ['foo', '"bar blah"']
    assert split_args('foo \'bar blah\'') == ['foo', '\'bar blah\'']
    assert split_args("foo 'bar blah'") == ['foo', "'bar blah'"]

# Generated at 2022-06-25 01:39:23.368999
# Unit test for function split_args
def test_split_args():
    list_0 = []
    list_0.append('a=b')
    list_0.append('c="foo bar"')
    var_0 = split_args('a=b c="foo bar"')
    assert var_0 == list_0
    list_1 = []
    list_1.append('a=b')
    list_1.append('c="foo bar"')
    list_1.append('d=\'baz')
    list_1.append('biz\'')
    var_1 = split_args('a=b c="foo bar" d=\'baz\nbiz\'')
    assert var_1 == list_1
    list_2 = []
    list_2.append('a=b')
    list_2.append('c="foo bar"')
    list_2.append

# Generated at 2022-06-25 01:39:32.659324
# Unit test for function is_quoted
def test_is_quoted():
    list_0 = []
    var_0 = is_quoted(list_0)
    assert var_0 == False, 'Expected False, but got {0} for list_0 = {1}'.format(var_0, list_0)

    list_0 = ['foo', 'bar', 'baz']
    var_0 = is_quoted(list_0)
    assert var_0 == False, 'Expected False, but got {0} for list_0 = {1}'.format(var_0, list_0)

    list_0 = ['foo', 'bar']
    var_0 = is_quoted(list_0)
    assert var_0 == False, 'Expected False, but got {0} for list_0 = {1}'.format(var_0, list_0)


# Generated at 2022-06-25 01:39:41.976579
# Unit test for function split_args

# Generated at 2022-06-25 01:39:43.699602
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == "hello"
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("hello") == "hello"


# Generated at 2022-06-25 01:39:52.844368
# Unit test for function split_args
def test_split_args():
    # from ansible.utils.shlex import split as shlex_split
    # Add your own test cases here if you want to
    enc = u'iso8859-1'

# Generated at 2022-06-25 01:39:59.450802
# Unit test for function unquote
def test_unquote():
    print("Unquote - Test 01")
    string_1 = "'test'"
    string_2 = '"test"'
    string_3 = "test"
    print("String 1: " + string_1)
    result = unquote(string_1)
    print("Result: " + result)
    print("String 2: " + string_2)
    result = unquote(string_2)
    print("Result: " + result)
    print("String 3: " + string_3)
    result = unquote(string_3)
    print("Result: " + result)

test_unquote()

# Generated at 2022-06-25 01:40:06.714337
# Unit test for function split_args
def test_split_args():
    # string arg0
    arg0 = "test"
    # list arg1
    arg1 = [arg0]
    # list arg2
    arg2 = [arg1]
    # list arg3
    arg3 = [arg2]
    # list arg4
    arg4 = [arg3]
    # string arg5
    arg5 = "test"
    # list arg6
    arg6 = [arg5]
    # list arg7
    arg7 = [arg6]
    # list arg8
    arg8 = [arg7]
    # list arg9
    arg9 = [arg8]
    # string arg10
    arg10 = "test"
    # list arg11
    arg11 = [arg10]
    # list arg12
    arg12 = [arg11]
    # list arg13
   

# Generated at 2022-06-25 01:40:10.081275
# Unit test for function unquote
def test_unquote():
    # Input parameters for b_quoted...
    params = ['a=b c="foo bar"', 'c="foo bar"', 'a=b c="foo bar"']
    assert split_args(params[0]) == params
    split_args(params[1]) == params
    split_args(params[2]) == params


if __name__ == '__main__':
    test_case_0()

    # Unit test for function unquote
    test_unquote()

# Generated at 2022-06-25 01:40:27.366976
# Unit test for function split_args
def test_split_args():
    # use a list of tuples to test cases
    # first value should be the input
    # second value should be the expected output when split
    test_cases = [
        ('''a=b c="foo bar"''', ['a=b', 'c="foo bar"'])
    ]
    print("testing")
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    import time
    import os
    os.system("echo 'c'")
    time.sleep(2)
    for case in test_cases:
        print(case)
        inp, outp = case
        result = split_args(inp)
        print(result)

# Generated at 2022-06-25 01:40:35.445879
# Unit test for function split_args
def test_split_args():
    print('Test split_args')
    assert split_args('one "two three"') == ['one', '"two three"']
    assert split_args('one "two three') == ['one', '"two three']
    assert split_args('"one two three') == ['"one two three']
    assert split_args('"one two three"') == ['"one two three"']
    assert split_args('one "two \'three\'"') == ['one', '"two \'three\'"']
    assert split_args('one "two \'three"') == ['one', '"two \'three"']
    assert split_args('one "two \\\'three"') == ['one', '"two \'three"']
    assert split_args('"one \"two three"') == ['"one "two three"']
    assert split_

# Generated at 2022-06-25 01:40:37.463525
# Unit test for function split_args
def test_split_args():
    assert(split_args(" 'a=b' c='foo bar' ") == ['a=b', 'c=foo bar'])

test_split_args()
print("passed test case 1")

# Generated at 2022-06-25 01:40:42.791159
# Unit test for function split_args
def test_split_args():
    # Testing with simple args
    assert split_args('a=b c=d') == ['a=b', 'c=d']

    # Testing with quote
    assert split_args('a=b c="d e"') == ['a=b', 'c="d e"']

    # Testing with quoted quote
    assert split_args('a=b c="d \\"e\\""') == ['a=b', 'c="d \"e\""']

    # Testing with quoted multiword quote
    assert split_args('a=b c="d \\"e f\\""') == ['a=b', 'c="d \"e f\""']

    # Testing with quoted dollar sign
    assert split_args('a=b c="d \\$e\\""') == ['a=b', 'c="d $e\""']

    # Testing with

# Generated at 2022-06-25 01:40:49.995788
# Unit test for function split_args
def test_split_args():
    # Test for function split_args. With args
    # Check for function split_args with args
    # Check if the function split_args returns a string
    assert len(split_args('yaml iso8859-1')) == 2
    assert isinstance(split_args('yaml iso8859-1'), list)

    # Check options with a dash
    assert len(split_args('{{a}} key=value with-dash')) == 3
    assert isinstance(split_args('{{a}} key=value with-dash'), list)

    # Check options with an underscore
    assert len(split_args('{{a}} key=value with_dash')) == 3
    assert isinstance(split_args('{{a}} key=value with_dash'), list)

    # Check options with a single-quote

# Generated at 2022-06-25 01:41:00.283029
# Unit test for function split_args
def test_split_args():
    assert split_args('test_0') == ['test_0']
    assert split_args('test_1 test_1.1') == ['test_1', 'test_1.1']
    assert split_args('test_2 test_2.1 test_2.2') == ['test_2', 'test_2.1', 'test_2.2']
    assert split_args('test_3 test_3.1 test_3.2 test_3.3') == ['test_3', 'test_3.1', 'test_3.2', 'test_3.3']

# Generated at 2022-06-25 01:41:04.141338
# Unit test for function split_args
def test_split_args():
    # Test case 0
    str_0 = 'ansible-playbook -i hosts file.yml  -e "a=1 b=2" --extra-vars "{{version}}"'
    result_0 = split_args(str_0)
    assert 'ansible-playbook' in result_0
    assert 'c=3' in result_0
    assert '' not in result_0

if __name__ == "__main__":
    test_split_args()
    test_case_0()

# Generated at 2022-06-25 01:41:11.512928
# Unit test for function split_args
def test_split_args():
    str_0 = 'iso8859-1'
    list_0 = split_args(str_0)
    assert list_0 == ['iso8859-1'], "split_args(str_0): %s" % list_0
    str_0 = 'iso8859-1 iso8859-2'
    list_0 = split_args(str_0)
    assert list_0 == ['iso8859-1', 'iso8859-2'], "split_args(str_0): %s" % list_0
    str_0 = 'iso8859-1 "iso8859-2 iso8859-3" iso8859-4'
    list_0 = split_args(str_0)

# Generated at 2022-06-25 01:41:22.507818
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Tests for functions in module split_args
    print()
    print('Test split_args() function')
    input_string = '"selected=selected" "checked=checked"'
    print('Input is: {}'.format(input_string))
    items = split_args(input_string)
    for item in items:
        print('item: {}'.format(item))
    assert items[0] == 'selected=selected'
    assert items[1] == 'checked=checked'


# Generated at 2022-06-25 01:41:29.658602
# Unit test for function split_args

# Generated at 2022-06-25 01:41:44.986612
# Unit test for function split_args
def test_split_args():
    # Test case 0
    test_data = []
    for test_input, expected_result in test_data:
        actual_result = split_args(test_input)
        print(actual_result)
        assert actual_result == expected_result, \
            "{} != {}".format(actual_result, expected_result)


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:41:56.568360
# Unit test for function split_args

# Generated at 2022-06-25 01:42:02.921143
# Unit test for function split_args
def test_split_args():
    str_1 = '''a=b c="foo bar"'''
    params = split_args(str_1)
    assert len(params) == 2
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo bar"'
    str_2 = '''a=b c="foo bar"'''
    params = split_args(str_2)
    assert len(params) == 2
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo bar"'
    str_3 = '''a=b c="foo bar"'''
    params = split_args(str_3)
    assert len(params) == 2
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo bar"'
   

# Generated at 2022-06-25 01:42:10.588502
# Unit test for function split_args
def test_split_args():
    src_1 = "a=b\"c d\" e='f g'"
    exp_1 = ['a=b"c d"', "e='f g'"]
    assert split_args(src_1) == exp_1

    src_2 = "a=\"{{b + c}}\" d='{{e + f}}' g={%h + i%} j={#k + l#}"
    exp_2 = ['a="{{b + c}}"', "d='{{e + f}}'", "g={%h + i%}", 'j={#k + l#}']
    assert split_args(src_2) == exp_2


# Generated at 2022-06-25 01:42:13.986788
# Unit test for function is_quoted
def test_is_quoted():
    str_0 = '"iso8859-1"'
    result = is_quoted(str_0)
    assert result == True
    str_1 = 'iso8859-1"'
    result = is_quoted(str_1)
    assert result == False
    str_2 = '"iso8859-1'
    result = is_quoted(str_2)
    assert result == False
    str_3 = 'iso8859-1'
    result = is_quoted(str_3)
    assert result == False


# Generated at 2022-06-25 01:42:18.406445
# Unit test for function is_quoted
def test_is_quoted():
    str_0 = 'iso8859-1'
    res = is_quoted(str_0)
    assert res == False

    str_1 = 'en_US.UTF-8'
    res = is_quoted(str_1)
    assert res == False

    str_2 = '"latin-1"'
    res = is_quoted(str_2)
    assert res == True

    str_3 = '''"latin-1"'\\n'''
    res = is_quoted(str_3)
    assert res == False

    str_4 = 'en_US.UTF-8"latin-1"'
    res = is_quoted(str_4)
    assert res == False


# Generated at 2022-06-25 01:42:23.859387
# Unit test for function split_args
def test_split_args():
    # testing str_0
    test_str = "a=b c=\"foo bar\""
    test_result = ['a=b', 'c="foo bar"']
    assert split_args(test_str) == test_result

    test_case_0()


# Generated at 2022-06-25 01:42:32.874908
# Unit test for function split_args
def test_split_args():

    # testcase 0
    args = 'iso8859-1'
    ret_ans = ['iso8859-1']
    retus = split_args(args)

    assert(ret_ans == retus)

    # testcase 1
    args = '''-c iso8859-1 -t xterm'''
    ret_ans = ['-c', 'iso8859-1', '-t', 'xterm']
    retus = split_args(args)

    assert(ret_ans == retus)

    # testcase 2
    args = '''-c "iso8859-1" -t "xterm"'''
    ret_ans = ['-c', '"iso8859-1"', '-t', '"xterm"']
    retus = split_args(args)


# Generated at 2022-06-25 01:42:36.743101
# Unit test for function split_args
def test_split_args():
    # Create a case list
    cases = [
        str_0,
        # str_1,
        # str_2,
        # str_3,
    ]
    for data in cases:
        test_case_0(data)

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:42:44.586006
# Unit test for function split_args
def test_split_args():

    # Test case 0
    # string to test
    str_0 = 'iso8859-1'

    # expected parameter 0
    param_0_expected = ['iso8859-1']

    # param 0
    properties_0 = split_args(str_0)

    for i, prop_0 in enumerate(properties_0):
        assert properties_0[i] == param_0_expected[i]

    # Test case 1
    # string to test
    str_1 = '-L 3 -V -c 4'

    # expected parameter 0
    param_0_expected = ['-L', '3', '-V', '-c', '4']

    # param 0
    properties_0 = split_args(str_1)

    for i, prop_0 in enumerate(properties_0):
        assert properties_0

# Generated at 2022-06-25 01:42:58.189349
# Unit test for function split_args
def test_split_args():
    a = 'a=b c="foo bar"'
    print(split_args(a))

test_split_args()

# Generated at 2022-06-25 01:43:08.391949
# Unit test for function split_args

# Generated at 2022-06-25 01:43:16.692646
# Unit test for function split_args
def test_split_args():
    # Homebrewed unit test for function split_args
    assert split_args("echo a=b c='foo bar'") == ['echo', 'a=b', "c='foo bar'"]
    assert split_args("echo a=b c=foo\\ bar") == ['echo', 'a=b', 'c=foo bar']
    assert split_args("echo a=b c=foo bar") == ['echo', 'a=b', 'c=foo bar']
    assert split_args("echo a=b c=foo\\\nbar") == ['echo', 'a=b', 'c=foo\nbar']
    assert split_args("""echo a=b c='foo\\
bar'""") == ['echo', 'a=b', 'c=\'foo\\\nbar\'']

# Generated at 2022-06-25 01:43:27.536711
# Unit test for function split_args
def test_split_args():
    test_string = 'ansible-playbook -i ./hosts ./simpleplaybook.yml -u root'
    split_args(test_string)

    test_string = '''ansible-playbook -i ./hosts ./simpleplaybook.yml -u root'''
    split_args(test_string)

    test_string = 'ansible-playbook -i "./hosts" ./simpleplaybook.yml -u root'
    split_args(test_string)

    test_string = 'ansible-playbook -i \'./hosts\' ./simpleplaybook.yml -u root'
    split_args(test_string)

    test_string = 'ansible-playbook -i ./hosts ./simpleplaybook.yml -u root -k'
    split_args(test_string)



# Generated at 2022-06-25 01:43:34.315961
# Unit test for function split_args
def test_split_args():
    args = 'echo "{{ foo.bar }}"{% if foo %}{{ foo.bar }}{% else %}{{ foo.foo }}{% endif %}{# foo #}'
    print(split_args(args))
    assert split_args(args) == ['echo', '"{{ foo.bar }}"', '{% if foo %}', '{{ foo.bar }}', '{% else %}', '{{ foo.foo }}', '{% endif %}', '{# foo #}']

# Generated at 2022-06-25 01:43:45.218704
# Unit test for function split_args
def test_split_args():
    str_0 = 'iso8859-1'
    str_1 = 'a b c'
    str_2 = 'a b "foo bar"'
    str_3 = 'a b "foo bar" c'
    str_4 = '"foo bar"'
    str_5 = "'foo'"
    str_6 = 'c="foo bar" d="{{ foo }}"'
    str_7 = '"foo "stop""'
    str_8 = '"foo \\"bar\\" baz"'
    str_9 = 'a=b "foo bar"'
    str_10 = 'a=b "foo bar" c=d'
    str_11 = '"foo\\nbar"'
    str_12 = '"foo\\rbar"'
    str_13 = '"foo\\n\\nbar"'

# Generated at 2022-06-25 01:43:53.435061
# Unit test for function split_args

# Generated at 2022-06-25 01:44:03.648383
# Unit test for function split_args
def test_split_args():

    str_1 = 'test.yml -e "ansible_ssh_user=test" -e "ansible_sudo_pass=test" -e "ansible_connection=ssh"'
    list_1 = split_args(str_1)
    print(str_1)
    print(list_1)
    print('\n')

    str_2 = 'test.yml -e "ansible_ssh_user=test" -e "ansible_sudo_pass=test" -e "ansible_connection=ssh" -u test'
    list_2 = split_args(str_2)
    print(str_2)
    print(list_2)
    print('\n')

    str_3 = '-m ping -f 5 -l test --forks 10'

# Generated at 2022-06-25 01:44:13.900260
# Unit test for function split_args
def test_split_args():
    r = split_args(str_0)
    print(str_0, " = ", r)
    str_1 = '('
    print(str_1, " = ", split_args(str_1))
    str_2 = ')'
    print(str_2, " = ", split_args(str_2))
    str_3 = '*'
    print(str_3, " = ", split_args(str_3))
    str_4 = '**'
    print(str_4, " = ", split_args(str_4))
    str_5 = '+'
    print(str_5, " = ", split_args(str_5))
    str_6 = ','
    print(str_6, " = ", split_args(str_6))
    str_7 = '-'
   

# Generated at 2022-06-25 01:44:14.696274
# Unit test for function split_args
def test_split_args():
    pass


# Generated at 2022-06-25 01:44:30.757724
# Unit test for function split_args
def test_split_args():
    print("Unit test for function split_args")
    test_case_0()

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:44:31.448424
# Unit test for function split_args
def test_split_args():
    test_case_0()
    assert True

# Generated at 2022-06-25 01:44:32.611568
# Unit test for function split_args
def test_split_args():
    test_case_0()


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-25 01:44:35.427052
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'key1=val1 key2=val2 "key 3"=val3'
    str_0 = str(bytes_0)
    var_0 = split_args(str_0)


if __name__ == '__main__':
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:44:36.161575
# Unit test for function split_args
def test_split_args():
    test_case_0()

# Unit test to check if quoting works

# Generated at 2022-06-25 01:44:40.791214
# Unit test for function split_args
def test_split_args():
    split_args('echo "hello world"')
    split_args('--extra-vars \'{foo: "bar"}\'')
    split_args('--extra-vars "{foo: "bar"}"')
    split_args('--extra-vars "{foo: "bar", "baz": "boo"}"')
    split_args('--extra-vars \'{"foo": "bar"}\' -a "bar"')
    split_args('--extra-vars "{foo: {bar: {baz: "boo"}}}" -a')
    split_args('--extra-vars \'{foo: {bar: {baz: "b"a\'z"}}}\'')
    split_args('--extra-vars \'{foo: {bar: {baz: "b\'a"z"}}}\'')

# Generated at 2022-06-25 01:44:47.383538
# Unit test for function split_args
def test_split_args():
    # Test case 0
    bytes_0 = b'l?\x96:\xa0\x8a\xaa\x04&U\xc6\xb3\x19\xf6\xd2/\xe9'
    var_0 = split_args(bytes_0)
    assert var_0[0] == b'l?\x96:\xa0\x8a\xaa\x04&U\xc6\xb3\x19\xf6\xd2/\xe9'

    # Test case 1
    bytes_1 = b'l?\x96:\xa0\x8a\xaa\x04&U\xc6\xb3\x19\xf6\xd2/\xe9'
    var_1 = split_args(bytes_1)

# Generated at 2022-06-25 01:44:56.804502
# Unit test for function split_args
def test_split_args():

    # Simple test of the split_args function

    bytes_0 = b'hello world one="1 2" three="3 4" five="5 6"'
    expected_result = ['hello', 'world', 'one=1 2', 'three=3 4', 'five=5 6']
    var_0 = split_args(bytes_0)
    if var_0 != expected_result:
        raise Exception(
            "Expected %s but received %s" % (str(expected_result), str(var_0)))

    # Simple test of the split_args function, with embedded newlines

    bytes_1 = b'hello world\none=1 2\nthree="3 4"\nfive=\n6'
    expected_result = ['hello', 'world\none=1 2\nthree=3 4\nfive=\n6']
   

# Generated at 2022-06-25 01:44:58.262641
# Unit test for function split_args
def test_split_args():
    test_case_0()


if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:45:03.825508
# Unit test for function split_args
def test_split_args():
    var_0 = split_args("l?\x96:\xa0\x8a\xaa\x04&U\xc6\xb3\x19\xf6\xd2/\xe9")
    print(var_0)

test_case_0()

# Generated at 2022-06-25 01:45:50.467024
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("command chdir=/usr creates=/tmp/somedir") == ["command", "chdir=/usr", "creates=/tmp/somedir"]
    assert split_args("a=b \"foo bar\"") == ["a=b", "\"foo bar\""]
    assert split_args("a=b \"foo bar\" c=d") == ["a=b", "\"foo bar\"", "c=d"]
    assert split_args("a=b \"foo bar\" 'foo bar'") == ["a=b", "\"foo bar\"", "'foo bar'"]
    assert split_args("a=b \"foo \\\nbar\"") == ["a=b", "\"foo \\\nbar\""]
    assert split

# Generated at 2022-06-25 01:45:52.813916
# Unit test for function split_args
def test_split_args():
    case_0()


# Call test methods
test_split_args()

# Generated at 2022-06-25 01:45:59.862872
# Unit test for function split_args
def test_split_args():
    try:
        split_args(b'l?\x96:\xa0\x8a\xaa\x04&U\xc6\xb3\x19\xf6\xd2/\xe9')
    except Exception as e:
        print("Exception in user code:")
        print('-'*60)
        traceback.print_exc(file=sys.stdout)
        print('-'*60)
        raise Exception(str(e) +
                        "\n\nAn exception was raised in the user code while executing this task or"
                        " in a custom module in the same task.\nThe error may have been caused by"
                        " the following exception:\n{}".format(traceback.format_exc()))

# Generated at 2022-06-25 01:46:05.802623
# Unit test for function split_args
def test_split_args():
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote("foo bar") == 'foo bar'
    assert unquote('"foo') == '"foo'
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted("foo") == False
    assert is_quoted('foo"') == False
    #print(split_args(b'[foo=bar]\nblah=yay'))
    #assert split_args(b'[foo=bar]\nblah=yay') == ['[foo=bar]', 'blah=yay']

# Generated at 2022-06-25 01:46:09.436893
# Unit test for function split_args
def test_split_args():
    with pytest.raises(Exception):
        split_args(b'\x81\x80\x1e\x83\xf9\x9f\x90\xcf\x8bW>\xdc\xd7\xca\x8c\x9a\x07\x99\x13{\x1f\x1d?@\x86\xf1')
    split_args(b' \x98\xbd\x8a8\xdb\x02\xc1\xca')

# Generated at 2022-06-25 01:46:14.593539
# Unit test for function split_args
def test_split_args():
    assert split_args("") == [], "Empty string failed"
    assert split_args('"abc def"') == ['abc def'], "Double quotes failed"
    assert split_args('\'abc def\'') == ['abc def'], "Single quotes failed"
    assert split_args('arg1 arg2 arg3') == ['arg1', 'arg2', 'arg3'], "No quotes failed"
    assert split_args('arg1 "arg2 arg3" arg4') == ['arg1', 'arg2 arg3', 'arg4'], "Double quotes failed"
    assert split_args('arg1 \'arg2 arg3\' arg4') == ['arg1', 'arg2 arg3', 'arg4'], "Single quotes failed"

# Generated at 2022-06-25 01:46:20.672233
# Unit test for function split_args
def test_split_args():
    #pylint: disable=no-self-use
    ''' split_args()'''

    args = {
        'unquoted': 'test foo bar',
        'quoted': '"test foo bar baz"',
        'complex': 'foo bar="test one" baz="test two"',
        'j2': 'foo bar={{ baz }}',
        'complex_j2': 'foo bar="test one" baz={{ test }} thing="{{ test }}"',
        'j2_blocks': 'foo bar={{ baz }} thing={{ test }}',
        'complex_j2_blocks': 'foo bar={{ baz }} thing={{ test }} another="{{ test }}"',
        'nl': 'test one\ntest two\n',
    }

    # First, test some simple cases
    results

# Generated at 2022-06-25 01:46:26.864602
# Unit test for function split_args
def test_split_args():
    var_0 = b'l?\x96:\xa0\x8a\xaa\x04&U\xc6\xb3\x19\xf6\xd2/\xe9'
    var_1 = split_args(var_0)
    print(var_1)

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-25 01:46:32.444278
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    assert split_args("\"foo bar baz\"") == ["\"foo bar baz\""]
    assert split_args("'foo bar baz'") == ["'foo bar baz'"]
    assert split_args("foo bar baz 'something else'") == ["foo", "bar", "baz", "'something else'"]
    assert split_args("foo bar baz 'something else' \"another thing\"") == ["foo", "bar", "baz", "'something else'", "\"another thing\""]

# Generated at 2022-06-25 01:46:39.238257
# Unit test for function split_args
def test_split_args():
    with open('/tmp/data_0', 'rb') as file_input:
        with open('/tmp/data_1', 'rb') as file_output:
            assert (file_input.readline() == file_output.readline())
        with open('/tmp/data_1', 'rb') as file_output:
            assert (file_input.readline() == file_output.readline())
    var_return_0 = split_args('--module-name=a -a')
    var_return_1 = split_args('-m "a b" -a')
    var_return_2 = split_args('-m "a" -a')
    var_return_3 = split_args('-m "a" -a')
    var_return_4 = split_args('-m "a" -a')

# Generated at 2022-06-25 01:47:50.632831
# Unit test for function split_args
def test_split_args():
    bytes_0 = b'l?\x96:\xa0\x8a\xaa\x04&U\xc6\xb3\x19\xf6\xd2/\xe9'
    assert(split_args(bytes_0) == [])
    bytes_1 = b'\x8c\xa0\xd2\xae\x8e\xb5\xfb\xec\xb0\xd7\x0e\x88\xa9\x1d:\xc8\x10\xb4-\xaf\xac'
    assert(split_args(bytes_1) == [])

# Generated at 2022-06-25 01:48:00.902182
# Unit test for function split_args
def test_split_args():
    bytes_0 = b''
    var_0 = split_args(bytes_0)
    assert type(var_0) == list
    assert var_0 == []

    bytes_0 = b'xyz'
    var_0 = split_args(bytes_0)
    assert type(var_0) == list
    assert var_0 == [ b'xyz' ]

    bytes_0 = b'abc # test'
    var_0 = split_args(bytes_0)
    assert type(var_0) == list
    assert var_0 == [ b'abc', b'#', b'test' ]

    bytes_0 = b'abc #\\ test'
    var_0 = split_args(bytes_0)
    assert type(var_0) == list

# Generated at 2022-06-25 01:48:05.248085
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("cmd \"a b c\" \"d e\"") == ['cmd', 'a b c', 'd e']
    assert split_args("cmd \"a b c\" \"d\\ e\"") == ['cmd', 'a b c', 'd\\ e']
    assert split_args("cmd \"a b c\" 'd\\ e'") == ['cmd', 'a b c', 'd\\ e']
    assert split_args("cmd \"a b c\" 'd\\ e\\'") == ['cmd', 'a b c', 'd\\ e\\']

# Generated at 2022-06-25 01:48:06.157617
# Unit test for function split_args
def test_split_args():
    for x in range(100):
        test_case_0()

# Generated at 2022-06-25 01:48:07.195321
# Unit test for function split_args
def test_split_args():
    test_case_0()
    assert True


# Generated at 2022-06-25 01:48:17.728150
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # Simple args
    args = 'foo bar'
    assert split_args(args) == args.split()

    # Simple args, quoted
    args = 'foo "bar baz"'
    assert split_args(args) == args.split()

    # args with escaped quotes
    args = 'foo bar "baz \\"qux\\""'
    assert split_args(args) == args.split()

    # args with a newline in the middle of a word
    args = 'foo bar baz\nqux'
    assert split_args(args) == ['foo', 'bar', 'baz\nqux']

    # args with newlines in the middle of a quoted word

# Generated at 2022-06-25 01:48:27.242293
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule
    assert split_args(b'    ') == []
    assert split_args(b'   a') == [b'a']
    assert split_args(b'   a   ') == [b'a']
    assert split_args(b'   a   b') == [b'a', b'b']
    assert split_args(b'   "a b"') == [b'"a b"']
    assert split_args(b'   a"b c"') == [b'a"b c"']
    assert split_args(b'   a"b c" d') == [b'a"b c"', b'd']
    assert split_args(b'   a"b c" d') == [b'a"b c"', b'd']

# Generated at 2022-06-25 01:48:30.241175
# Unit test for function split_args
def test_split_args():
    count = 0
    with open('split_args.bin', 'rb') as f:
        for line in f:
            count += 1
            bytes_0 = line.rstrip(b'\n')
            result = split_args(bytes_0)


# Generated at 2022-06-25 01:48:34.637216
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]


if __name__ == "__main__":
    test_case_0()
    test_split_args()

# Generated at 2022-06-25 01:48:39.120848
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar" \\\n d="{{ foo }}"') == ['a=b', 'c=foo bar', 'd={% foo %}']
