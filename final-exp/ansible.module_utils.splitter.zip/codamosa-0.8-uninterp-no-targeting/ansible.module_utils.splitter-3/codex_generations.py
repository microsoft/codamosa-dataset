

# Generated at 2022-06-20 20:58:43.838609
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('"foo bar') == '"foo bar'
    assert unquote('foo bar"') == 'foo bar"'


# Generated at 2022-06-20 20:58:48.089494
# Unit test for function unquote
def test_unquote():
    ''' unquote should remove first and last quotes from a string, if the string starts and ends with the same quotes '''
    assert unquote("\"blah\"") == "blah"
    assert unquote("'blah'") == "blah"
    assert unquote('"blah') == '"blah'
    assert unquote("'blah") == "'blah"


# Generated at 2022-06-20 20:58:59.915577
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c=\\"foo bar') == ['a=b', 'c="foo bar']
    assert split_args('   a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"   ') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" \nd=e f="g h"') == ['a=b', 'c="foo bar"', 'd=e', 'f="g h"']
    assert split

# Generated at 2022-06-20 20:59:03.715016
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"string"')
    assert is_quoted("'string'")
    assert not is_quoted('"string\'')
    assert not is_quoted("'string\"")
    assert not is_quoted('string"')
    assert not is_quoted("string'")
    assert not is_quoted('string')



# Generated at 2022-06-20 20:59:05.851215
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a\"bc"') == 'a"bc'


# Generated at 2022-06-20 20:59:12.799745
# Unit test for function split_args

# Generated at 2022-06-20 20:59:18.765071
# Unit test for function unquote
def test_unquote():
    ''' test unquote '''
    # pylint: disable=undefined-variable
    if is_quoted("'hello'") is False or is_quoted('"hello"') is False:
        return False
    if unquote("'hello'") != 'hello' or unquote('"hello"') != 'hello':
        return False
    # pylint: enable=undefined-variable
    return True

# Generated at 2022-06-20 20:59:30.482446
# Unit test for function split_args
def test_split_args():
    def _compare_lists(list1, list2):
        if len(list1) != len(list2):
            return False
        else:
            ret = True
            for idx, item in enumerate(list1):
                if item != list2[idx]:
                    return False
            return ret


# Generated at 2022-06-20 20:59:34.029002
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('abc') == False
    assert is_quoted('"abc"') == True
    assert is_quoted('\'abc\'') == True
    assert is_quoted('"abc') == False



# Generated at 2022-06-20 20:59:36.789817
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'") == True
    assert is_quoted('"test"') == True
    assert is_quoted('test') == False
    assert is_quoted('') == False



# Generated at 2022-06-20 20:59:51.449733
# Unit test for function unquote
def test_unquote():
    assert (unquote('foo') == 'foo')
    assert (unquote('"foo"') == 'foo')
    assert (unquote('"foo') == '"foo')
    assert (unquote("'foo'") == 'foo')
    assert (unquote("'foo") == "'foo")


# Generated at 2022-06-20 20:59:57.775850
# Unit test for function is_quoted
def test_is_quoted():
    assert(not is_quoted("hello world"))
    assert(not is_quoted("\""))
    assert(not is_quoted("'"))
    assert(is_quoted("'hello world'"))
    assert(is_quoted("\"hello world\""))


# Generated at 2022-06-20 21:00:07.431624
# Unit test for function split_args

# Generated at 2022-06-20 21:00:12.377356
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted('abc') == False
    assert is_quoted('"abc') == False
    assert is_quoted('abc"') == False


# Generated at 2022-06-20 21:00:16.373452
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('\'\'') == ''
    assert unquote('"a"') == 'a'
    assert unquote('\'a\'') == 'a'
    assert unquote('"a\'b"') == "a'b"
    assert unquote('"a\'b\'c"') == "a'b'c"
    assert unquote('\'a"b"c\'') == 'a"b"c'


# Generated at 2022-06-20 21:00:23.129455
# Unit test for function split_args

# Generated at 2022-06-20 21:00:35.503260
# Unit test for function split_args
def test_split_args():
    # use the test cases from the docs
    tests = {
        'foo': ['foo'],
        '"a b c"': ['a b c'],
        '{{ foo }}': ['{{ foo }}'],
        '{{ foo }} bar': ['{{ foo }} bar'],
        'a={{ foo }} b=\\{{ foo }} c={{ foo }}': ['a={{ foo }}', 'b=\\{{ foo }}', 'c={{ foo }}'],
        '"Foo A"   "Bar B"': ['Foo A', 'Bar B']
    }
    for arg, result in tests.items():
        assert split_args(arg) == result
    # test one that failed during a release

# Generated at 2022-06-20 21:00:40.304588
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote("''") == ''

if __name__ == '__main__':
    import sys
    import doctest
    failed, tried = doctest.testmod()
    sys.exit(failed)

# Generated at 2022-06-20 21:00:47.365633
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo') == False
    assert is_quoted("'foo") == False
    assert is_quoted('foo"') == False
    assert is_quoted("foo'") == False


# Generated at 2022-06-20 21:00:55.693596
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"bar') == 'foo"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"') == '"'
    assert unquote('""') == ''
    assert unquote('\'"foo\'"') == '\'"foo"\''
    assert unquote('"foo\'"') == 'foo\'"'



# Generated at 2022-06-20 21:01:29.642450
# Unit test for function split_args
def test_split_args():

    def assert_same_split(args, expected_split):
        result = split_args(args)
        assert result == expected_split, "args '%s' split to %s instead of %s" % (args, result, expected_split)

    assert_same_split(r"""a=b c="foo bar" """, ["a=b", 'c="foo bar"'])
    assert_same_split(r"""a=b c="foo bar"\
 d=e""", ["a=b", 'c="foo bar"', "d=e"])
    assert_same_split(r"""a=b c="foo bar"\\
 d=e""", ["a=b", 'c="foo bar\\', "d=e"])

# Generated at 2022-06-20 21:01:33.725234
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote('test') == "test"

# Generated at 2022-06-20 21:01:42.117713
# Unit test for function split_args

# Generated at 2022-06-20 21:01:46.216946
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"f\'oo"') == 'f\'oo'
    assert unquote('"f\"oo"') == 'f\"oo'


# Generated at 2022-06-20 21:01:56.592725
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar" d="foo\"bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', 'd="foo\"bar"']

    args = "a=b c='foo bar' d='foo\"bar' e='' f=\"\""
    params = split_args(args)
    assert params == ['a=b', "c='foo bar'", "d='foo\"bar'", "e=''", 'f=""'], params

    args = 'a=b" c=foo\\"bar d="foo\'bar"'
    params = split_args(args)
    assert params == ['a=b"', 'c=foo\\"bar', 'd="foo\'bar"'], params


# Generated at 2022-06-20 21:01:59.851487
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'



# Generated at 2022-06-20 21:02:09.520476
# Unit test for function split_args
def test_split_args():
    # Test unbalanced quotes
    passed = False
    try:
        split_args('a=b c="foo')
    except Exception:
        passed = True
    assert passed, "Unbalanced quotes should fail"

    # Test unbalanced jinja2
    passed = False
    try:
        split_args('a=b c="{{ foo " }}')
    except Exception:
        passed = True
    assert passed, "Unbalanced jinja2 blocks should fail"

    # Test single token in quotes
    params = split_args('"bar"')
    assert params == ['"bar"'], "Two tokens should be returned"

    # Test single token in jinja2
    params = split_args('{{ bar }}')
    assert params == ['{{ bar }}'], "Two tokens should be returned"

    # Test quoted word with no jin

# Generated at 2022-06-20 21:02:18.761706
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"1"') == True
    assert is_quoted("'1'") == True
    assert is_quoted('1') == False
    assert is_quoted('"1') == False
    assert is_quoted("'1") == False
    assert is_quoted('1"') == False
    assert is_quoted('1\'"') == False
    assert is_quoted('') == False
    assert is_quoted('""') == True
    assert is_quoted("''") == True
    assert is_quoted('""""""""') == False


# Generated at 2022-06-20 21:02:24.299177
# Unit test for function unquote
def test_unquote():
    assert unquote("'this is a test'") == 'this is a test'
    assert unquote("\"this is a test\"") == 'this is a test'
    assert unquote("this is a test") == 'this is a test'


# Generated at 2022-06-20 21:02:30.675767
# Unit test for function unquote
def test_unquote():

    assert unquote("") == ""
    assert unquote("a") == "a"
    assert unquote("\"a\"") == "a"
    assert unquote("\"\"") == ""
    assert unquote("\"a") == "\"a"
    assert unquote("a\"") == "a\""
    assert unquote("\"\"\"\"\"") == "\"\""

    assert unquote("''") == ""
    assert unquote("'a'") == "a"
    assert unquote("'a") == "'a"
    assert unquote("a'") == "a'"
    assert unquote("''''") == "''"



# Generated at 2022-06-20 21:03:27.358631
# Unit test for function split_args

# Generated at 2022-06-20 21:03:31.223237
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("\"foo\"") == True)
    assert(is_quoted("'foo'") == True)
    assert(is_quoted("foo") == False)



# Generated at 2022-06-20 21:03:36.049289
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('""')
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")



# Generated at 2022-06-20 21:03:46.591875
# Unit test for function split_args
def test_split_args():
    # A simple test
    params = ['foo "bar baz"']
    assert split_args('foo "bar baz"') == params

    # Test if split_args works with quotes.
    params = ['foo="bar baz"', 'foo="bar baz"']
    assert split_args('foo="bar baz" foo="bar baz"') == params

    # Test if the quote is not on the outside of the string.
    params = ['foo="bar baz"']
    assert split_args('foo="bar baz"') == params

    # Test if split_args works with a mixture of quotes escapes and jinja2 blocks.
    params = ['foo="bar baz"', 'foo=\'bar baz\'']
    assert split_args('foo="bar baz" foo=\'bar baz\'') == params

# Generated at 2022-06-20 21:04:00.933119
# Unit test for function is_quoted
def test_is_quoted():
    tests = (
        # data                     # is quoted?
        ('a string',                       False),
        ('"a quoted string"',              True),
        ('\'a quoted string\'',            True),
        ('"a quoted string with an',       False),
        ('"a quoted string with an" arg',  False),
        ('\\"a quoted string\\"',          True),
        ('\\"a quoted string',             False),
        ('\\"a quoted string\\" arg',      False),
    )

# Generated at 2022-06-20 21:04:07.315627
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'") == False
    assert is_quoted("blah") == False
    assert is_quoted("'blah") == False
    assert is_quoted("blah'") == False
    assert is_quoted("blah'blah") == False
    assert is_quoted("'blah'") == True
    assert is_quoted('"blah"') == True


# Generated at 2022-06-20 21:04:12.343358
# Unit test for function unquote
def test_unquote():
    assert unquote('"123"') == '123'
    assert unquote('"123') == '"123'
    assert unquote('123"') == '123"'
    assert unquote('123') == '123'



# Generated at 2022-06-20 21:04:21.881722
# Unit test for function split_args
def test_split_args():
    args = 'foo "1 2 3" bar baz="ab cd ef" '
    assert split_args(args) == ['foo', '"1 2 3"', 'bar', 'baz="ab cd ef"']

    args = 'foo "1 2 3" bar "baz="ab cd ef""'
    assert split_args(args) == ['foo', '"1 2 3"', 'bar', '"baz="ab cd ef"']

    args = 'foo "1 2 3" {{bar}} "baz="ab cd ef""'
    assert split_args(args) == ['foo', '"1 2 3"', '{{bar}}', '"baz="ab cd ef"']

    args = 'foo "1 2 3" {%bar%} "baz="ab cd ef""'
    assert split

# Generated at 2022-06-20 21:04:32.688636
# Unit test for function unquote
def test_unquote():
    '''Test unquote'''
    assert unquote('"hello"') == "hello"
    assert unquote('hello') == "hello"
    assert unquote('\'"hello\'"') == '\'"hello\'"'
    assert unquote('"\"hello\""') == '"\"hello\""'
    assert unquote("'hello'") == "hello"
    assert unquote('\'\'hello\'\'') == '\'\'hello\'\''
    assert unquote('"\'hello\'"') == '"\'hello\'"'

# Generated at 2022-06-20 21:04:41.664962
# Unit test for function split_args

# Generated at 2022-06-20 21:06:58.557171
# Unit test for function unquote
def test_unquote():
    assert 'foo bar' == unquote("'foo bar'")
    assert 'foo bar' == unquote("\"foo bar\"")
    assert '"foo bar"' == unquote("\"\"\"foo bar\"\"\"")
    assert "'foo bar'" == unquote("'''foo bar'''")
    assert 'foo bar' == unquote("foo bar")
    assert 'foo bar' == unquote("'foo bar")


# Generated at 2022-06-20 21:07:06.190273
# Unit test for function unquote
def test_unquote():
    assert unquote(u"\"foo\"") == u"foo"
    assert unquote(u"\"\"foo\"\"") == u"\"foo\""
    assert unquote(u"'foo'") == u"foo"
    assert unquote(u"''foo''") == u"'foo'"
    assert unquote(u"foo") == u"foo"

# Generated at 2022-06-20 21:07:17.786643
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''                      # Empty string -> empty string
    assert unquote('""') == ''                    # Empty quoted string -> empty string
    assert unquote('foo') == 'foo'                # Simple string -> simple string
    assert unquote('"foo"') == 'foo'              # Quoted string -> string
    assert unquote('"foo') == '"foo'              # Quoted string with no ending quote -> quoted string
    assert unquote('foo"') == 'foo"'              # String with no starting quote -> quoted string
    assert unquote('"f"o"o"') == 'f"o"o'          # Quoted string with quoted substring -> quoted string
    assert unquote('"fo"o') == 'fo"o'             # Quoted string with unended quoted substring -> quoted string
    assert unquote('"f"oo')

# Generated at 2022-06-20 21:07:28.564161
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('c="foo bar" a=b') == ['c="foo bar"', 'a=b']
    assert split_args('a=b c="foo  \nbar"') == ['a=b', 'c="foo  \nbar"']
    assert split_args('a=b c="foo  \nbar\\') == ['a=b', 'c="foo  \nbar\\']
    assert split_args('a=b c="foo  \nbar\\\n"') == ['a=b', 'c="foo  \nbar\\\n"']

# Generated at 2022-06-20 21:07:31.913473
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello world"') == True
    assert is_quoted('"hello world') == False
    assert is_quoted('hello world"') == False
    assert is_quoted('') == False
    assert is_quoted('"') == False


# Generated at 2022-06-20 21:07:38.210616
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('a') == 'a'
    assert unquote('"a"') == 'a'
    assert unquote('"ab"') == 'ab'
    assert unquote("'ab'") == 'ab'



# Generated at 2022-06-20 21:07:47.143702
# Unit test for function is_quoted
def test_is_quoted():
    if is_quoted("'Hello, World'") != True:
        raise AssertionError("'Hello, World' should be recognized as quoted")
    if is_quoted("Hello, World") != False:
        raise AssertionError("Hello, World should not be recognized as quoted")
    if is_quoted("'Hello, World") != False:
        raise AssertionError("'Hello, World should not be recognized as quoted (missing end quote)")


# Generated at 2022-06-20 21:07:51.999625
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('') is False)
    assert (is_quoted('foo') is False)
    assert (is_quoted('"foo"') is True)
    assert (is_quoted('foo"') is False)
    assert (is_quoted('"foo') is False)
    assert (is_quoted('\'foo\'') is True)
    assert (is_quoted('foo\'') is False)
    assert (is_quoted('\'foo') is False)



# Generated at 2022-06-20 21:08:01.961211
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("test") == False
    assert is_quoted("test's") == False
    assert is_quoted("'test'") == True
    assert is_quoted("\"test\"") == True
    assert is_quoted("'test's") == True
    assert is_quoted("\"test's\"") == True
    assert is_quoted("' '") == True
    assert is_quoted("\" \"") == True


# Generated at 2022-06-20 21:08:09.365072
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('\'\'') == ''
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('foo\'') == 'foo\''