

# Generated at 2022-06-20 20:58:43.758366
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') is True
    assert is_quoted("'hello'") is True
    assert is_quoted("hello") is False
    assert is_quoted("'hello") is False
    assert is_quoted("hello'") is False
    assert is_quoted("\"hello") is False
    assert is_quoted("hello\"") is False


# Generated at 2022-06-20 20:58:50.385646
# Unit test for function unquote
def test_unquote():
    test1 = unquote("hello")
    test2 = unquote("''hello'")
    test3 = unquote("'hello'")
    test4 = unquote("'hello''")
    assert test1 == "hello"
    assert test2 == ""
    assert test3 == "hello"
    assert test4 == "hello'"

    # Unit test for function is_quoted
    def test_is_quoted():
        test1 = is_quoted("hello")
        test2 = is_quoted("''hello'")
        test3 = is_quoted("'hello'")
        test4 = is_quoted("'hello''")
        assert test1 == False
        assert test2 == False
        assert test3 == True
        assert test4 == False

# Generated at 2022-06-20 20:58:54.658332
# Unit test for function unquote
def test_unquote():
    assert unquote('"a b"') == 'a b'
    assert unquote("'a b'") == 'a b'
    assert unquote('a b') == 'a b'


# Generated at 2022-06-20 20:58:56.919686
# Unit test for function is_quoted
def test_is_quoted():
    import pytest
    assert is_quoted('""') == True
    #assert is_quoted('"') == False # Not supported by python < 3.5

# Generated at 2022-06-20 20:59:04.870408
# Unit test for function is_quoted
def test_is_quoted():
    ''' unit test for function is_quoted '''
    assert is_quoted('') == False
    assert is_quoted(' ') == False
    assert is_quoted(' test ') == False
    assert is_quoted('"') == False
    assert is_quoted('"test') == False
    assert is_quoted('test"') == False
    assert is_quoted('""') == True
    assert is_quoted('"test"') == True
    assert is_quoted('" test"') == True
    assert is_quoted('"test "') == True
    assert is_quoted('" test "') == True
    assert is_quoted('" test ""') == False
    assert is_quoted('" test " "') == False
    assert is_quoted('" test "" test "')

# Generated at 2022-06-20 20:59:12.183345
# Unit test for function unquote
def test_unquote():
    unquotetest = "quotetest"
    assert unquote(unquotetest) == unquotetest
    singlequotetest = "'quotetest'"
    assert unquote(singlequotetest) == "quotetest"
    doublequotetest = '"quotetest"'
    assert unquote(doublequotetest) == "quotetest"
    singleanddoublequotetest = '"\'quotetest\'"'
    assert unquote(singleanddoublequotetest) == "'quotetest'"
    doubleandsinglequotetest = "'\"quotetest\"'"
    assert unquote(doubleandsinglequotetest) == '"quotetest"'

# Generated at 2022-06-20 20:59:16.999606
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted('test"')


# Generated at 2022-06-20 20:59:28.746973
# Unit test for function is_quoted
def test_is_quoted():
    tests = (
        ('abcde', False),
        ('"abcde"', True),
        ("'abcde'", True),
        ('"abcde', False),
        ("'abcde", False),
        ('abcde"', False),
        ('abcde\'', False),
        ('"a"b""c""d"e"', False),
        ('"a"b""c""d"e"', False),
        ('"a"b""c""d"e"', False),
        ('"a\'b\'c\'d\'e"', True),
        ("'a\"b\"c\"d\"e'", True),
    )

# Generated at 2022-06-20 20:59:38.434433
# Unit test for function split_args
def test_split_args():
    arg_string = "{{ foo }} {{ foo }}"
    expected_results = ["{{ foo }}", "{{ foo }}"]
    results = split_args(arg_string)
    assert results == expected_results

    arg_string = "{{ foo }}{{ foo }}"
    expected_results = ["{{ foo }}{{ foo }}"]
    results = split_args(arg_string)
    assert results == expected_results

    arg_string = "{{ foo \n}}"
    expected_results = ["{{ foo \n}}"]
    results = split_args(arg_string)
    assert results == expected_results

    arg_string = "\n{{ foo }}"
    expected_results = ["\n{{ foo }}"]
    results = split_args(arg_string)
    assert results == expected_results


# Generated at 2022-06-20 20:59:40.288566
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo\'"') == "foo'"
    assert unquote('"foo"') == "foo"
    assert unquote("'bar'") == "bar"



# Generated at 2022-06-20 20:59:58.658200
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo')
    assert not is_quoted('"foo")')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")


# Generated at 2022-06-20 21:00:02.014036
# Unit test for function unquote
def test_unquote():
    assert(unquote('xyz') == 'xyz')
    assert(unquote('"xyz"') == 'xyz')
    assert(unquote('xyz"') == 'xyz"')
    assert(unquote('"xyz') == '"xyz')


# Generated at 2022-06-20 21:00:13.543683
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote("foo'") == "foo'"
    assert unquote("foo'") == "foo'"
    assert unquote("'foo'bar") == "'foo'bar"
    assert unquote("'foo\"bar'") == 'foo"bar'
    assert unquote('"foo\'bar"') == "foo'bar"



# Generated at 2022-06-20 21:00:19.736422
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') == True
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted('"hello"') == True
    assert is_quoted('""') == True

    assert is_quoted("''") == True
    assert is_quoted("'''hello'''") == True
    assert is_quoted("'''hello''") == False
    assert is_quoted("''hello'''") == False
    assert is_quoted("'hello'''") == False



# Generated at 2022-06-20 21:00:23.358338
# Unit test for function unquote
def test_unquote():
    '''
    Tests for unquote function
    '''
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('hel"lo') == 'hel"lo'
    assert unquote('"hel\'lo"') == 'hel\'lo'
    assert unquote('') == ''
    assert unquote('    ') == '    '

# Generated at 2022-06-20 21:00:35.812581
# Unit test for function split_args
def test_split_args():
    '''
    Detect issues with function split_args
    '''

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def test(args, e_params):
        params = split_args(args)
        if params == e_params:
            return True, ''
        else:
            msg = "%s != %s" % (params, e_params)
            return False, msg


# Generated at 2022-06-20 21:00:51.346642
# Unit test for function unquote
def test_unquote():
    # Test case 1: None input
    if unquote(None) is not None:
        raise AssertionError("unquote(None) should return None")

    # Test case 2: Empty string input
    if unquote("") != "":
        raise AssertionError("unquote('') should return ''")

    # Test case 3: No quotes input
    if unquote("hello world") != "hello world":
        raise AssertionError("unquote('hello world') should return 'hello world'")

    # Test case 4: Single quote input
    if unquote("'hello world'") != "hello world":
        raise AssertionError("unquote(''hello world') should return 'hello world'")

    # Test case 5: Double quote input
    if unquote('"hello world"') != "hello world":
        raise Assertion

# Generated at 2022-06-20 21:01:00.175477
# Unit test for function split_args
def test_split_args():
    '''test: split_args function'''
    print("test_split_args()")
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d=\"foo bar\"") == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', 'd=\'foo bar\'']
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=\"foo bar\"") == ['a=b', 'c="foo bar"', 'd=\'foo bar\'', 'e="foo bar"']

# Generated at 2022-06-20 21:01:01.513960
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == "abc"
    assert unquote('abc') == "abc"



# Generated at 2022-06-20 21:01:06.673975
# Unit test for function unquote
def test_unquote():
    assert "foo" == unquote('foo')
    assert "foo" == unquote('"foo"')
    assert "fo'o" == unquote('"fo\'o"')
    assert "foo" == unquote("'foo'")
    assert "fo\"o" == unquote("'fo\"o'")


# Generated at 2022-06-20 21:01:27.198436
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('"') is False
    assert is_quoted('"a') is False
    assert is_quoted('"a"') is True
    assert is_quoted('"a"b') is False
    assert is_quoted('"a""b') is False
    assert is_quoted('"a""b"') is True
    assert is_quoted('\'a\'') is True
    assert is_quoted('\'a\'') is True
    assert is_quoted('\'a\'b') is False
    assert is_quoted('\'a\'\'b\'') is True



# Generated at 2022-06-20 21:01:39.573103
# Unit test for function is_quoted
def test_is_quoted():
    # Test on various quoted strings
    assert is_quoted('"testing"')
    assert is_quoted('"testing') == False
    assert is_quoted('testing"') == False
    assert is_quoted("'testing'")
    assert is_quoted("'testing") == False
    assert is_quoted("testing'") == False
    assert is_quoted("'testin'g'") == False
    assert is_quoted("'testing") == False
    assert is_quoted("testing'") == False
    assert is_quoted("\"testin\"g\"") == False
    assert is_quoted("\"testing") == False
    assert is_quoted("testing\"") == False



# Generated at 2022-06-20 21:01:50.460706
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('"')
    assert not is_quoted('"howdy')
    assert is_quoted('"howdy"')
    assert not is_quoted('"howdy""')
    assert not is_quoted('""howdy""')
    assert not is_quoted('"howdy""')
    assert not is_quoted("'")
    assert not is_quoted("'howdy")
    assert not is_quoted("'howdy'")
    assert not is_quoted("''howdy'")
    assert not is_quoted("'howdy''")
    assert not is_quoted('howdy')
    assert not is_quoted('"howdy"\"')
    assert not is_quoted('\"howdy"')

# Generated at 2022-06-20 21:02:01.387824
# Unit test for function split_args

# Generated at 2022-06-20 21:02:10.969422
# Unit test for function split_args
def test_split_args():
    ''' ansible.module_utils.basic.split_args '''

    # simple, no split tokens
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # test unbalanced quotes
    try:
        split_args('a=b c="foo')
        raise Exception("unbalanced quotes test failed")
    except Exception:
        pass

    try:
        split_args('a=b c=\'foo')
        raise Exception("unbalanced quotes test failed")
    except Exception:
        pass

    # don't split inside jinja2 {{ }} blocks
    assert split_args('a=b c={{ foo }}') == ['a=b', 'c={{ foo }}']

# Generated at 2022-06-20 21:02:21.457266
# Unit test for function unquote
def test_unquote():
    ''' unit test for the unquote function '''

    # Test empty string
    input_data = ''
    expected_result = ''
    result = unquote(input_data)
    assert result == expected_result

    # Test unquoted word
    input_data = 'word'
    expected_result = 'word'
    result = unquote(input_data)
    assert result == expected_result

    # Test quoted word, single quotes
    input_data = "'word'"
    expected_result = 'word'
    result = unquote(input_data)
    assert result == expected_result

    # Test quoted word, double quotes
    input_data = '"word"'
    expected_result = 'word'
    result = unquote(input_data)
    assert result == expected_result

    # Test quoted phrase
    input_

# Generated at 2022-06-20 21:02:29.618662
# Unit test for function is_quoted
def test_is_quoted():
    for data in [
        '',
        'a',
        '"b"',
        'c',
        "d'e'f",
        "'g'h'i",
        '"j"k"l',
    ]:
        if is_quoted(data):
            print(data, 'is quoted')
        else:
            print(data, 'is not quoted')



# Generated at 2022-06-20 21:02:37.911432
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('""') == ''
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo\"bar'") == 'foo"bar'
    assert unquote("'foo\'bar'") == 'foo\'bar'



# Generated at 2022-06-20 21:02:47.172094
# Unit test for function split_args
def test_split_args():
    if not split_args("foo bar bam").index('foo') == 0:
        raise Exception("foo bar bam failed")
    if not split_args("foo bar bam").index('bar') == 1:
        raise Exception("foo bar bam failed")
    if not split_args("foo bar bam").index('bam') == 2:
        raise Exception("foo bar bam failed")
    if not split_args("foo=bar bam=baz").index('foo=bar') == 0:
        raise Exception("foo=bar bam=baz failed")
    if not split_args("foo=bar bam=baz").index('bam=baz') == 1:
        raise Exception("foo=bar bam=baz failed")

# Generated at 2022-06-20 21:02:55.234628
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"This is a quoted string"')
    assert is_quoted("'This is also a quoted string'")
    assert not is_quoted('This is a string')
    assert not is_quoted('This is a "quoted"'
                         'string')
    assert not is_quoted('This is also" a quoted string')



# Generated at 2022-06-20 21:03:24.656583
# Unit test for function split_args

# Generated at 2022-06-20 21:03:41.070702
# Unit test for function split_args

# Generated at 2022-06-20 21:03:43.736245
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == 'abcd'
    assert unquote("'abcd'") == 'abcd'
    assert unquote('abcd') == 'abcd'


# Generated at 2022-06-20 21:03:47.093593
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted("test")
    assert not is_quoted("'test")
    assert not is_quoted('"test')


# Unit tests for function unquote

# Generated at 2022-06-20 21:03:54.764526
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('abc') == 'abc'
    assert is_quoted('abc') == False

    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'a''b'") == "a''b"

    assert unquote('"""abc"""') == '"abc"'
    assert unquote("'''abc'''") == "'abc'"
    assert unquote("'''a'''b'''") == "''b''"

    assert unquote("abc'") == "abc'"
    assert unquote("abc' ") == "abc' "
    assert unquote("'abc") == "'abc"
    assert unquote("'abc ") == "'abc "


# Generated at 2022-06-20 21:04:00.769026
# Unit test for function unquote
def test_unquote():
    in_examples = [
        ('test', 'test'),
        ('test string', 'test string'),
        ('"test string"', 'test string'),
        ("'test string'", 'test string'),
        ('"test', '"test'),
        ("'test", "'test"),
        ('"test"', 'test'),
        ('"test\"', '"test"'),
        ('"test""', '"test""'),
    ]
    failed = False
    for (in_, expected) in in_examples:
        actual = unquote(in_)
        if actual != expected:
            print("fail: in: %s, expected: %s, actual: %s" % (in_, expected, actual))
            failed = True
            return
    if not failed:
        print("all tests passed")



# Generated at 2022-06-20 21:04:05.066331
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('hello')
    assert not is_quoted('"hel"lo"')
    assert not is_quoted("'hel'lo'")


# Generated at 2022-06-20 21:04:09.467583
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") == True
    assert is_quoted("\"hello\"") == True
    assert is_quoted("'hello") == False
    assert is_quoted("hello'") == False
    assert is_quoted("'hello\"") == False
    assert is_quoted("\"hello\'") == False
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False


# Generated at 2022-06-20 21:04:13.989733
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("' \"hello\"'")
    assert not is_quoted("' \"hello\" ")
    assert not is_quoted(" 'hello' ")
    assert not is_quoted("''")
    assert not is_quoted("")
    assert not is_quoted("")


# Generated at 2022-06-20 21:04:20.013606
# Unit test for function split_args
def test_split_args():
    assert split_args("-a 'foo bar'") == ["-a", "'foo bar'"]
    assert split_args("-a 'foo bar'\\") == ["-a", "'foo bar'"]
    assert split_args("-a 'foo bar' baz") == ["-a", "'foo bar' baz"]
    assert split_args("-a -b baz") == ["-a", "-b", "baz"]
    assert split_args("-a 'foo bar' baz qux") == ["-a", "'foo bar' baz qux"]
    assert split_args("-a 'foo bar' baz qux") == ["-a", "'foo bar' baz qux"]
    assert split_args("-a 'foo bar' baz qux") == ["-a", "'foo bar' baz qux"]


# Generated at 2022-06-20 21:05:11.001963
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('') is False)
    assert(is_quoted('""') is False)
    assert(is_quoted('"') is False)
    assert(is_quoted('\'') is False)
    assert(is_quoted('string') is False)
    assert(is_quoted('"string"') is True)
    assert(is_quoted('\'string\'') is True)

# Generated at 2022-06-20 21:05:18.342263
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'fo\"o'") == 'fo\"o'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'foo\"") == "'foo\""
    assert unquote("\"foo'") == "\"foo'"
    assert unquote("foo") == "foo"
    assert unquote("\"foo\" ") == "foo"


# Generated at 2022-06-20 21:05:22.076299
# Unit test for function unquote
def test_unquote():
    '''
    assert unquote() removes quotes from quoted string
    '''
    test_string = "1 2 3 4 5"
    quoted = '"{}"'.format(test_string)
    assert test_string == unquote(quoted)
    assert False == is_quoted(test_string)
    assert True == is_quoted(quoted)


# Generated at 2022-06-20 21:05:37.654289
# Unit test for function split_args
def test_split_args():
    # test helpers
    def test_split(args, expected):
        if expected != split_args(args):
            raise AssertionError(
                "args='%s' expected='%s' actual='%s'" % (args, expected, split_args(args))
            )

    def test_raise(args):
        try:
            split_args(args)
            raise AssertionError("'%s' split_args() expected an exception, but succeeded" % args)
        except Exception:
            pass

    # unit tests
    # TODO: add more
    test_split('', [])
    test_split('"', ['""'])
    test_split('"\\"', ['""\\""'])
    test_split('a b', ['a', 'b'])

# Generated at 2022-06-20 21:05:47.676697
# Unit test for function split_args
def test_split_args():
    ''' test module for splitting arguments '''

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import ansible.module_utils.basic
    import os

    # for testing the code, we need to provide a module_utils path,
    # since this function does not have a module argument
    # the module_utils path is in the same directory as the basic
    # plugin, so we use that

    # noqa because we don't want to worry about this in the test
    _module_utils_path = os.path.join(os.path.dirname(ansible.module_utils.basic.__file__), 'module_utils')  # noqa

# Generated at 2022-06-20 21:05:52.682763
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted('""')
    assert not is_quoted('')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')


# Generated at 2022-06-20 21:06:04.830287
# Unit test for function split_args
def test_split_args():
    # test a basic split on spaces with no special characters
    args = split_args('a b c')
    assert len(args) == 3
    assert 'a' in args
    assert 'b' in args
    assert 'c' in args

    # test a split on quoted string with spaces
    args = split_args('a=b c="foo bar"')
    assert len(args) == 2
    assert 'a=b' in args
    assert 'c="foo bar"' in args

    # test a split on jinja blocks with spaces
    args = split_args('a b {{ foo }} c {{ "foo bar" }}')
    assert len(args) == 4
    assert 'a' in args
    assert 'b' in args
    assert '{{ foo }}' in args
    assert 'c {{ "foo bar" }}' in args



# Generated at 2022-06-20 21:06:07.489896
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("hello") == False
    assert is_quoted("'hello'") == True

# Generated at 2022-06-20 21:06:12.768113
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted('test"')


# Generated at 2022-06-20 21:06:16.813620
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert not is_quoted('hello')
    assert is_quoted('\'"hello\'"')



# Generated at 2022-06-20 21:07:22.804264
# Unit test for function is_quoted
def test_is_quoted():
    assert True == is_quoted('"foo"')
    assert True == is_quoted("'foo'")
    assert False == is_quoted('"foo')
    assert False == is_quoted('foo"')
    assert False == is_quoted('foo')
    assert False == is_quoted('"')
    assert False == is_quoted('"foo""foo"')
    assert False == is_quoted('"""foo"""')
    assert False == is_quoted('')


# Generated at 2022-06-20 21:07:31.310659
# Unit test for function split_args
def test_split_args():
    assert split_args('date') == [ 'date' ]
    assert split_args('date --rfc-3339=seconds') == [ 'date', '--rfc-3339=seconds' ]
    assert split_args('date +"%Y-%m-%dT%H:%M:%SZ"') == [ 'date', '+"%Y-%m-%dT%H:%M:%SZ"' ]
    assert split_args('date +"%Y-%m-%dT%H:%M:%SZ"') == [ 'date', '+"%Y-%m-%dT%H:%M:%SZ"' ]

# Generated at 2022-06-20 21:07:39.235086
# Unit test for function unquote
def test_unquote():
    unquoted_data = 'foo bar " baz"'
    assert unquote(unquoted_data) == unquoted_data
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote("''foo bar''") == "''foo bar''"



# Generated at 2022-06-20 21:07:45.667679
# Unit test for function is_quoted
def test_is_quoted():
    test = '"quoted_string"'
    assert is_quoted(test) == True
    test = "not_a_quoted_string"
    assert is_quoted(test) == False
    test = '"string that ends in slash\\"'
    assert is_quoted(test) == True
    test = "'string that ends in slash\\'"
    assert is_quoted(test) == True


# Generated at 2022-06-20 21:07:53.588196
# Unit test for function split_args
def test_split_args():
    # Basic sanity check
    assert split_args("foo=bar") == ["foo=bar"]

    # Basic sanity check with quotes
    assert split_args("foo='bar'") == ["foo='bar'"]

    # Test for spaces inside quotes
    assert split_args("foo='bar baz'") == ["foo='bar baz'"]
    assert split_args("foo='bar bar'") == ["foo='bar bar'"]

    # Test for multiple spaces outside quotes
    assert split_args("foo=bar   xyz=foo") == ["foo=bar", "xyz=foo"]

    # Test for multiple spaces outside quotes
    assert split_args("foo=bar   xyz=foo") == ["foo=bar", "xyz=foo"]

    # Test for whitespace before and after equals sign

# Generated at 2022-06-20 21:07:58.723801
# Unit test for function split_args
def test_split_args():
    # Testing if split_args splits without jinja2
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="bar baz"') == ['a=b', 'c="bar baz"']
    assert split_args('a=b c="foo bar" d=f') == ['a=b', 'c="foo bar"', 'd=f']
    assert split_args("a=b c='foo bar' d='bar baz'") == ['a=b', "c='foo bar'", "d='bar baz'"]
    assert split_args("a=b c='foo bar' d='bar baz'") == ['a=b', "c='foo bar'", "d='bar baz'"]
    #

# Generated at 2022-06-20 21:08:06.844009
# Unit test for function unquote
def test_unquote():
    assert unquote('nodata') == 'nodata'
    assert unquote('"nodata"') == 'nodata'
    assert unquote('\'nodata\'') == 'nodata'
    assert unquote('\'nodata') == '\'nodata'
    assert unquote('nodata\'') == 'nodata\''

# Generated at 2022-06-20 21:08:15.586266
# Unit test for function split_args
def test_split_args():
    ''' unittest for function split_args '''

    # basic test
    params = split_args('a=b c="foo bar"')
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo bar"'

    # test args split by newline
    params = split_args('a=b \nc="foo bar"')
    assert params[0] == 'a=b\n'
    assert params[1] == 'c="foo bar"'

    # test splitting on escaped newline
    params = split_args('a=b \\n c="foo bar"')
    assert params[0] == "a=b \\n"
    assert params[1] == 'c="foo bar"'

    # test args split by jinja2 block start

# Generated at 2022-06-20 21:08:30.042067
# Unit test for function split_args
def test_split_args():
    assert split_args('foo=bar') == ['foo=bar']
    assert split_args('foo="bar baz"') == ['foo="bar baz"']
    assert split_args('foo="bar baz" spam="ham huey"') == ['foo="bar baz"', 'spam="ham huey"']
    assert split_args('foo="bar baz {{ foo1 }}" spam="ham {{ huey }}"') == ['foo="bar baz {{ foo1 }}"', 'spam="ham {{ huey }}"']
    assert split_args('foo="bar baz {{ foo1 }}" spam="ham {{ huey }}"\\') == ['foo="bar baz {{ foo1 }}"', 'spam="ham {{ huey }}"']