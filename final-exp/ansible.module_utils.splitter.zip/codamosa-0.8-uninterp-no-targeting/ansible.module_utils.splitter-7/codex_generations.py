

# Generated at 2022-06-20 20:58:53.197327
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote("'test'") == 'test'
    assert unquote("'test") == "'test"
    assert unquote("test") == 'test'



# Generated at 2022-06-20 20:59:02.500032
# Unit test for function split_args
def test_split_args():
    assert split_args('a b "c d e f" g') == ['a', 'b', '"c d e f"', 'g']
    assert split_args('a b "c d e f" g') == ['a', 'b', '"c d e f"', 'g']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('a=b c="this string spans=a line"') == ['a=b', 'c="this string spans=a line"']

# Generated at 2022-06-20 20:59:07.224098
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == "abc"
    assert unquote('abc"') == 'abc"'
    assert unquote('"abc') == '"abc'

if __name__ == '__main__':
    import sys
    try:
        func = sys.argv[1]
    except IndexError:
        func = None
    if func == 'split_args':
        print(split_args(' '.join(sys.argv[2:])))
    elif func == 'unquote':
        test_unquote()
    else:
        print('Error: No test specified.')

# Generated at 2022-06-20 20:59:19.528574
# Unit test for function split_args

# Generated at 2022-06-20 20:59:26.804142
# Unit test for function is_quoted
def test_is_quoted():
    quote_char = '"'
    assert is_quoted('"abc"') is True
    assert is_quoted(quote_char) is False
    assert is_quoted('""') is True
    assert is_quoted(quote_char * 3) is False
    assert is_quoted(quote_char * 2 + 'abc') is False


# Generated at 2022-06-20 20:59:34.649042
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b "c=foo bar"') == ['a=b', '"c=foo bar"']
    assert split_args('a="b=c d=e"') == ['a="b=c d=e"']
    assert split_args('a="b=c d=e" f="g h"') == ['a="b=c d=e"', 'f="g h"']
    assert split_args('a="b=c \'d=e\'" f="g h"') == ['a="b=c \'d=e\'"', 'f="g h"']

# Generated at 2022-06-20 20:59:39.387666
# Unit test for function split_args

# Generated at 2022-06-20 20:59:49.004962
# Unit test for function split_args
def test_split_args():

    def _test_one(arg, expected):
        quoted = [is_quoted(x) for x in expected]
        actual = split_args(arg)
        for a, e in zip(actual, expected):
            if a != e:
                print("%s != %s" % (a, e))
            assert a == e
        assert len(actual) == len(expected)

    _test_one("-a", ["-a"])
    _test_one("-a=b", ["-a=b"])
    _test_one("-a='b c'", ["-a='b c'"])
    _test_one("-a=b c", ["-a=b", "c"])
    _test_one("-a b", ["-a", "b"])

# Generated at 2022-06-20 20:59:51.805129
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('""') == True)
    assert(is_quoted('') == False)
    assert(is_quoted('"a"') == True)
    assert(is_quoted('"') == False)
    assert(is_quoted('""a') == False)
    assert(is_quoted('a""') == False)



# Generated at 2022-06-20 20:59:59.302928
# Unit test for function unquote
def test_unquote():
    import pytest

    # test already unquoted strings
    assert unquote('simple unquoted string') == 'simple unquoted string'

    # test strings quoted with simple quotes
    assert unquote("'string quoted with single quote'") == 'string quoted with single quote'
    assert unquote("'string quoted with single quote") == "'string quoted with single quote"
    assert unquote("string quoted with single quote'") == "string quoted with single quote'"

    # test strings quoted with double quotes
    assert unquote('"string quoted with double quotes"') == 'string quoted with double quotes'
    assert unquote('"string quoted with double quotes') == '"string quoted with double quotes'
    assert unquote('string quoted with double quotes"') == 'string quoted with double quotes"'

    # test strings quoted with mixed quotes

# Generated at 2022-06-20 21:00:19.422085
# Unit test for function is_quoted
def test_is_quoted():
    ''' function test_is_quoted will verify the following cases:
    - Empty string should return False
    - Single word string should return False
    - Single quoted string should return True
    - Double quote string should return True
    - String with space inside single quotes should return True
    - String with escaped single quote should return False
    - String with space inside double quotes should return True
    - String with escaped double quote should return False
    '''

    assert is_quoted('') == False
    assert is_quoted('test') == False
    assert is_quoted("'test'") == True
    assert is_quoted('"test"') == True
    assert is_quoted("'test test'") == True
    assert is_quoted("'test\'test'") == False
    assert is_quoted('"test test"') == True

# Generated at 2022-06-20 21:00:25.806143
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("'a'") == True
    assert is_quoted("\"a\"") == True
    assert is_quoted("\"a") == False
    assert is_quoted("a\"") == False
    assert is_quoted("'a") == False
    assert is_quoted("a'") == False

# Generated at 2022-06-20 21:00:36.492494
# Unit test for function split_args
def test_split_args():
    result = split_args("foo bar baz")
    assert result == ["foo", "bar", "baz"]

    result = split_args("foo 'bar baz'")
    assert result == ["foo", "'bar baz'"]

    result = split_args("'foo bar' baz")
    assert result == ["'foo bar'", "baz"]

    result = split_args("foo \"bar baz\"")
    assert result == ["foo", "\"bar baz\""]

    result = split_args("\"foo bar\" baz")
    assert result == ["\"foo bar\"", "baz"]

    result = split_args("foo \"bar\"\\\nbaz")
    assert result == ["foo", "\"bar\"\\\nbaz"]

    result = split_args("foo \"bar\"\\\nbaz qux")

# Generated at 2022-06-20 21:00:52.097092
# Unit test for function is_quoted
def test_is_quoted():
    if is_quoted('"a"'):
        print("is_quoted('\"a\"') -> True")
    else:
        print("is_quoted('\"a\"') -> False (it should be True)")

    if is_quoted('"a'):
        print("is_quoted('\"a') -> True (it should be False)")
    else:
        print("is_quoted('\"a') -> False")

    if is_quoted("'a'"):
        print("is_quoted(\"'a'\") -> True")
    else:
        print("is_quoted(\"'a'\") -> False (it should be True)")

    if is_quoted("'a"):
        print("is_quoted(\"'a\") -> True (it should be False)")


# Generated at 2022-06-20 21:00:55.239593
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('abc') is False
    assert is_quoted('"abc"') is True
    assert is_quoted("'abc'") is True
    assert is_quoted('"a"b"c"') is False


# Generated at 2022-06-20 21:00:57.667184
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert not is_quoted('"foo')
    assert is_quoted('foo"')
    assert not is_quoted('foo')



# Generated at 2022-06-20 21:01:02.037924
# Unit test for function split_args
def test_split_args():
    # test inside quotes
    params = split_args(u"\"a=b c=d\"")
    assert(len(params) == 1)
    assert(params[0] == u"a=b c=d")

    # test quotes containing quotes
    params = split_args(u'"a=b c=\'foo bar\'"')
    assert(len(params) == 1)
    assert(params[0] == u'a=b c=\'foo bar\'')

    params = split_args(u"foo=\'bar \'\"\'\"\' baz=\'bar \'\"\'\"\'")
    assert(len(params) == 1)
    assert(params[0] == u"foo=\'bar \'\"\'\"\' baz=\'bar \'\"\'\"\'")

    # test double quotes
    params = split_args

# Generated at 2022-06-20 21:01:12.406889
# Unit test for function unquote
def test_unquote():
    assert unquote("'test'") == 'test'
    assert unquote("\"test\"") == 'test'
    assert unquote("'test") == "'test"
    assert unquote("test'") == "test'"
    assert unquote("'test\"") == "'test\""
    assert unquote("'test'\"") == "'test'\""
    assert unquote("\"test'\"") == "\"test'\""
    assert unquote("test") == "test"


# Generated at 2022-06-20 21:01:23.024290
# Unit test for function split_args
def test_split_args():
    import sys

    if sys.version_info < (2, 6):
        print("Skipping unit tests for Python %s" % sys.version_info)
        return

    from ansible.compat.tests import unittest

    class ArgumentSpec(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_basic_arg_split(self):
            ''' tests basic argument splitting '''
            args = "foo=bar one=two"
            result = split_args(args)
            self.assertEqual(len(result), 2)
            self.assertEqual(result[0], "foo=bar")
            self.assertEqual(result[1], "one=two")


# Generated at 2022-06-20 21:01:32.635303
# Unit test for function unquote
def test_unquote():
   assert unquote('\'') == '\''
   assert unquote('"') == '"'
   assert unquote('""') == '""'
   assert unquote('"""""""') == '""""""'
   assert unquote('"""""""') == '""""""'
   assert unquote('"""""""hello""') == '""""""hello"'
   assert unquote('a"hello"') == 'a"hello"'
   assert unquote('"hello"a') == '"hello"a'
   assert unquote("'hello'") == 'hello'
   assert unquote("'hello''") == 'hello\''
   assert unquote("'hello\\'") == 'hello\\'
   assert unquote("'hello\\'") == 'hello\\'
   assert unquote("'hello'''") == 'hello'''


# Generated at 2022-06-20 21:01:56.518585
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted("'hello") == False
    assert is_quoted("hello'") == False
    assert is_quoted('"hello"')
    assert is_quoted('"hello') == False
    assert is_quoted("hello\"") == False

# Generated at 2022-06-20 21:01:58.878082
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted('hello') == False
    assert is_quoted("'hello'") == True
    assert is_quoted("") == False


# Generated at 2022-06-20 21:02:01.458446
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote('"a') == '"a'
    assert unquote('a"') == 'a"'
    assert unquote('a') == 'a'
    pass

# Generated at 2022-06-20 21:02:11.025799
# Unit test for function split_args
def test_split_args():
    class Test:
        def assertEqual(self, result, expected):
            if result != expected:
                print("test failed")
                print(" result: %s" % result)
                print("expected: %s" % expected)
                raise Exception("test failed")


# Generated at 2022-06-20 21:02:21.458552
# Unit test for function split_args
def test_split_args():
    tests = dict()
    tests["simple one arg"] = dict(
        input="""/bin/foo""",
        output=['/bin/foo'],
    )
    tests["simple two args"] = dict(
        input="""/bin/foo bar""",
        output=['/bin/foo', 'bar'],
    )

    tests["args with embedded spaces"] = dict(
        input="""/bin/foo 'bar foo' bar""",
        output=['/bin/foo', 'bar foo', 'bar'],
    )

    tests["args with escaped spaces"] = dict(
        input="""/bin/foo "bar\ foo" bar""",
        output=['/bin/foo', 'bar foo', 'bar'],
    )


# Generated at 2022-06-20 21:02:25.041183
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('"foo""foo"') == 'foo"foo'



# Generated at 2022-06-20 21:02:31.899836
# Unit test for function split_args
def test_split_args():

    def assert_args_equal(args, params):
        result = split_args(args)
        assert result == params, "original arguments: '%s', parsed arguments: '%s', should have been '%s'" % (args, result, params)

    assert_args_equal("ls -al", ['ls', '-al'])
    assert_args_equal("ls -al /root", ['ls', '-al', '/root'])
    assert_args_equal("ls -al /root/", ['ls', '-al', '/root/'])
    assert_args_equal("ls -al \"/root/foo bar\"", ['ls', '-al', '"/root/foo bar"'])

# Generated at 2022-06-20 21:02:35.120155
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("hello") == 'hello'


# Generated at 2022-06-20 21:02:45.918942
# Unit test for function split_args

# Generated at 2022-06-20 21:02:48.952976
# Unit test for function is_quoted
def test_is_quoted():
    data = '"foo"'
    result = is_quoted(data)
    assert result is True



# Generated at 2022-06-20 21:03:23.259550
# Unit test for function split_args
def test_split_args():
    args_string = """a=b c="foo bar" "foo bar"="foo bar" """
    args = split_args(args_string)
    assert args == ['a=b', 'c="foo bar"', '"foo bar"="foo bar"'], args

    args_string = """a=b c="foo bar" "foo bar"="foo bar" """
    args = split_args(args_string)
    assert args == ['a=b', 'c="foo bar"', '"foo bar"="foo bar"'], args

    args_string = """a=b c="foo bar" "foo bar"="foo bar" """
    args = split_args(args_string)
    assert args == ['a=b', 'c="foo bar"', '"foo bar"="foo bar"'], args


# Generated at 2022-06-20 21:03:28.796437
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"

# Generated at 2022-06-20 21:03:37.001407
# Unit test for function split_args
def test_split_args():
    def test(result, args):
        args = split_args(args)
        if args != result:
            raise Exception(
                "result (%s) != expected(%s) for input [%s]" % (
                    args, result, args
                )
            )

    test(
        ['foo', 'bar', 'baz'],
        'foo bar baz',
    )

    test(
        ['foo', 'b"ar', 'baz'],
        'foo b"ar baz',
    )

    test(
        ['foo', 'bar baz'],
        'foo bar baz',
    )

    test(
        ['foo "bar baz'],
        'foo "bar baz',
    )


# Generated at 2022-06-20 21:03:48.250231
# Unit test for function split_args
def test_split_args():
    # On Python 2.6 and 2.7, the shlex module does not correctly handle a backslash-newline
    # in conjunction with double-quotes.  That is fixed in Python 3.
    # This is a test to confirm that this function handles that case properly.

    # This tests the case where a backslash-newline has to be split out of a double-quoted string.
    input = '''a="b \
c" d'''
    output = ['a="b c"', 'd']
    assert split_args(input) == output

    # This tests the case where a backslash-newline has to be split out of a double-quoted string
    # and there is an open jinja2 block at the end of the line.
    input = '''a="b \
c" {{ d'''
    output

# Generated at 2022-06-20 21:03:55.989055
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"ab""c"') == 'ab""c'
    assert unquote("'ab''c'") == 'ab''c'
    assert unquote('"ab"c"') == '"ab"c"'
    assert unquote("'ab'c'") == "'ab'c'"
    assert unquote('a"bc') == 'a"bc'
    assert unquote("a'bc") == "a'bc"


# Generated at 2022-06-20 21:04:02.050743
# Unit test for function is_quoted
def test_is_quoted():
    # print ("Testing is_quoted")
    assert is_quoted('"abcd"')
    assert is_quoted('\'abcd\'')
    assert is_quoted('"') is False
    assert is_quoted('abc') is False
    assert is_quoted('"123\'"') is False
    # print ("Test Passed")


# Generated at 2022-06-20 21:04:12.039723
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted("'foo") is False
    assert is_quoted("foo'") is False
    assert is_quoted('"foo"')
    assert is_quoted('"foo') is False
    assert is_quoted('foo"') is False
    assert is_quoted('') is False
    assert is_quoted('"') is False
    assert is_quoted('"""') is False
    assert is_quoted("''") is False



# Generated at 2022-06-20 21:04:21.825760
# Unit test for function split_args

# Generated at 2022-06-20 21:04:37.497452
# Unit test for function split_args

# Generated at 2022-06-20 21:04:47.831316
# Unit test for function split_args

# Generated at 2022-06-20 21:05:39.782708
# Unit test for function unquote
def test_unquote():
    assert 'abc' == unquote('abc')
    assert 'abc' == unquote('"abc"')
    assert "a'b'c" == unquote("'a'b'c'")
    assert 'a"b"c' == unquote("'a\"b\"c'")


# Generated at 2022-06-20 21:05:49.767436
# Unit test for function split_args

# Generated at 2022-06-20 21:05:59.608951
# Unit test for function split_args
def test_split_args():
    '''
    Test the split_args function, which is used for splitting command line arguments
    '''


# Generated at 2022-06-20 21:06:03.165868
# Unit test for function unquote
def test_unquote():
    qstr = '"str"'
    astr = 'str'
    assert unquote(qstr) == astr
    qstr = "'str'"
    assert unquote(qstr) == astr


# Generated at 2022-06-20 21:06:06.611659
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted("abc")


# Generated at 2022-06-20 21:06:19.251864
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("aa")
    assert is_quoted("''")
    assert is_quoted("\"\"")
    assert is_quoted("'a'")
    assert is_quoted("\"a\"")
    assert not is_quoted(" she said 'hello' ")
    assert not is_quoted(" she said \"hello\" ")
    assert is_quoted("'a \"b\" c'")
    assert is_quoted("\"a 'b' c\"")
    assert not is_quoted("\"a 'b' c")
    assert not is_quoted("'a \"b\" c")


# Generated at 2022-06-20 21:06:24.183891
# Unit test for function split_args
def test_split_args():
    ''' test split_args function '''

    def test_split_args_aux(args, expected):
        ''' auxiliary function used by the unit tests '''
        if split_args(args) != expected:
            raise AssertionError("Split args failed, expected: %s, actual: %s" % (expected, split_args(args)))

    # Testcases
    test_split_args_aux(r' foo    bar ', ['foo', 'bar'])
    test_split_args_aux(r"foo    bar", ['foo', 'bar'])
    test_split_args_aux(r"foo   bar ", ['foo', 'bar'])
    test_split_args_aux(r"foo\nbar", ['foo\nbar'])

# Generated at 2022-06-20 21:06:32.940269
# Unit test for function unquote
def test_unquote():
    ''' returns true if unquote function works properly, false otherwise '''

    # Test 1: quoted word
    if unquote('"Hello World"') != 'Hello World':
        return False

    # Test 2: quoted word with spaces
    if unquote('"Hello World Bob"') != 'Hello World Bob':
        return False

    # Test 3: quoted word with escaped quotes
    if unquote('"Hello \"World\" Bob"') != 'Hello \"World\" Bob':
        return False

    # Test 4: quoted word with escaped quotes
    if unquote('"Hello \\\"World\\\" Bob"') != 'Hello \\\"World\\\" Bob':
        return False

    # Test 5: quoted word with escaped quotes
    if unquote('"Hello \\\\\"World\\\\\" Bob"') != 'Hello \\\\\"World\\\\\" Bob':
        return False

# Generated at 2022-06-20 21:06:38.377769
# Unit test for function unquote
def test_unquote():
    test_pairs = {
        '"test"': 'test',
        "'test'": 'test',
        'test': 'test',
        '"test': '"test',
        'test"': 'test"',
    }
    for indata, outdata in test_pairs.items():
        assert unquote(indata) == outdata

# Generated at 2022-06-20 21:06:45.534130
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote("'foo'") == 'foo'


# FIXME: This function is NOT used in any of the modules in the library.
#        The same functionality is provided by the 'parse_kv' function in
#        the ansible.utils.module_docs_fragments module.