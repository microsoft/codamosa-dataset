

# Generated at 2022-06-20 20:58:40.226328
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"


# Generated at 2022-06-20 20:58:41.656960
# Unit test for function unquote
def test_unquote():
    if unquote('"hello"') != 'hello':
        raise ValueError("test for unquote failed")



# Generated at 2022-06-20 20:58:47.285891
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted('"abc\'')
    assert is_quoted('"')
    assert is_quoted('"""')
    assert is_quoted("'''")
    assert is_quoted('"\\""')



# Generated at 2022-06-20 20:58:58.170669
# Unit test for function unquote
def test_unquote():
    assert unquote('abcdef') == 'abcdef'
    assert unquote('"abcdef"') == 'abcdef'
    assert unquote('\'abcdef\'') == 'abcdef'
    assert unquote('"\'abcdef\'"') == '\'abcdef\''
    assert unquote('"\"abcdef\""') == '\"abcdef\"'

    assert is_quoted('abcdef') == False
    assert is_quoted('"abcdef"')
    assert is_quoted('\'abcdef\'')
    assert is_quoted('"abcdef') == False
    assert is_quoted('"\'abcdef\'"')
    assert is_quoted('"\"abcdef\""')

# Generated at 2022-06-20 20:59:05.718441
# Unit test for function split_args
def test_split_args():
    def aeq(a, b):
        if a != b:
            raise AssertionError("%r != %r" % (a, b))
    aeq(split_args('a=b c="foo bar"'), ['a=b', 'c="foo bar"'])
    aeq(split_args('a=b c="foo bar" d'), ['a=b', 'c="foo bar"', 'd'])
    aeq(split_args('a=b c="foo bar"'), ['a=b', 'c="foo bar"'])
    aeq(split_args('a=b c="foo bar"'), ['a=b', 'c="foo bar"'])
    aeq(split_args('a=b c="foo bar"'), ['a=b', 'c="foo bar"'])

# Generated at 2022-06-20 20:59:12.723262
# Unit test for function split_args
def test_split_args():
    class Color:
        GREEN = '\033[92m'
        RED = '\033[91m'
        RESET = '\033[0m'

    def error(test_num, test_case, actual, expected):
        print("%sTest %s: '%s', expected '%s' but got '%s'.%s" % (Color.RED, test_num, test_case, expected, actual, Color.RESET))


# Generated at 2022-06-20 20:59:20.384898
# Unit test for function unquote
def test_unquote():

    s = unquote("")
    assert (s == "")

    s = unquote("a")
    assert (s == "a")

    s = unquote("'a'")
    assert (s == "a")

    s = unquote('"a"')
    assert (s == "a")

    s = unquote("'ab'")
    assert (s == "ab")

    s = unquote('"ab"')
    assert (s == "ab")

    s = unquote("ab")
    assert (s == "ab")



# Generated at 2022-06-20 20:59:25.037035
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('"test"') == True)
    assert (is_quoted("'test'") == True)
    assert (is_quoted("test") == False)


# Generated at 2022-06-20 20:59:33.981837
# Unit test for function split_args
def test_split_args():
    EXAMPLES = {
        'string': 'foo bar="baz qux"',
        'yaml': 'key: {foo: bar, baz: {qux: quux}}',
        'json': '{"key": {"foo": "bar", "baz": {"qux": "quux"}}}',
        'complex': ('{{ foo }}: baz {{ qux }} foo={{ bar }} qux={{ corge }} '
                     'baz={{ grault }} test {{ waldo }}: fred={{ plugh }} '
                     'xyzzy={{ thud }} test2 {{ garply }}: grault={{ waldo }} '
                     'fred={{ plugh }} xyzzy={{ thud }}'),
    }

    #
    # Examples as they should be parsed. The output strings of each example
    # have all

# Generated at 2022-06-20 20:59:37.505190
# Unit test for function unquote
def test_unquote():
    assert(unquote('""') == '')
    assert(unquote('"abc"') == 'abc')
    assert(unquote('abc') == 'abc')
    assert(unquote('"a"b"c"') == 'a"b"c')
    assert(unquote('"\\"') == '"')



# Generated at 2022-06-20 20:59:57.363298
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted('""') == True
    assert is_quoted('') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('\'foo\'') == True
    assert is_quoted('\'foo') == False
    assert is_quoted('foo\'') == False
    assert is_quoted('\'foo"') == False
    assert is_quoted('""foo"') == False
    assert is_quoted('"foo"bar"') == False
    assert is_quoted('"foo""bar"') == False
    assert is_quoted('""foo""') == True
    assert is_quoted('foo') == False

# Generated at 2022-06-20 21:00:02.946514
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('\'"abc"\'') == '"abc"'
    assert unquote("'\"abc\"'") == '"abc"'
    # invalid input
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote("'") == "'"
    assert unquote('"""') == '""'
    assert unquote("'''") == "''"


# Generated at 2022-06-20 21:00:14.764460
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"John Smith"') == True)
    assert(is_quoted("'John Smith'") == True)
    assert(is_quoted('"John\'s Smith"') == True)
    assert(is_quoted("'John's Smith'") == True)
    assert(is_quoted('John\'s Smith') == False)
    assert(is_quoted("John's Smith") == False)
    assert(is_quoted('John Smith') == False)
    assert(is_quoted("'John Smith") == False)
    assert(is_quoted('"John\'s Smith') == False)
    assert(is_quoted("John's Smith'") == False)
    assert(is_quoted("'John's Smith\"") == False)

# Generated at 2022-06-20 21:00:22.085246
# Unit test for function split_args
def test_split_args():
    ''' test split_args with some example argument strings '''
    if '{{' == "{":
        print("SKIPPING split_args tests as jinja2 is not installed")
        return

    # list of strings and expected results
    # expected result is None if it is expected to raise an exception

# Generated at 2022-06-20 21:00:28.256950
# Unit test for function unquote
def test_unquote():
    test_data = [
        # input, result
        ('"abc"', 'abc'),
        ('abc', 'abc'),
        ('"abc', '"abc'),
        ('abc"', 'abc"'),
    ]

    for input, result in test_data:
        assert unquote(input) == result

# Generated at 2022-06-20 21:00:36.283003
# Unit test for function unquote
def test_unquote():
    assert unquote('"This is a quote"') == "This is a quote"
    assert unquote("'This is a quote'") == "This is a quote"
    assert unquote("This is not quoted") == "This is not quoted"
    assert unquote("'This is not quoted") == "'This is not quoted"
    assert unquote('This is not quoted"') == 'This is not quoted"'


# Generated at 2022-06-20 21:00:40.234935
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('hello')



# Generated at 2022-06-20 21:00:43.641585
# Unit test for function unquote
def test_unquote():
    for x in [
        ('"abc"', 'abc'),
        ('\'foo bar\'', 'foo bar'),
        ('"abc\'', '"abc\''),
        ('"abc"def\'', '"abc"def\'')
        ]:
        assert unquote(x[0]) == x[1]



# Generated at 2022-06-20 21:00:48.049249
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == "abcd"
    assert unquote("'abcd'") == "abcd"
    assert unquote("abcd") == "abcd"
    assert unquote('"abcd') == '"abcd'

# Generated at 2022-06-20 21:00:58.730709
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b") == ["a=b"]
    assert split_args("a='b c'") == ["a='b c'"]
    assert split_args("a='b c' d=e") == ["a='b c'", "d=e"]
    assert split_args("a='b c' d='foo bar'") == ["a='b c'", "d='foo bar'"]
    assert split_args("a='b c' d='foo bar' e={{ foo }} f='{{ foo }}'") == ["a='b c'", "d='foo bar'", "e={{ foo }}", "f='{{ foo }}'"]

# Generated at 2022-06-20 21:01:14.847874
# Unit test for function split_args

# Generated at 2022-06-20 21:01:16.868604
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'



# Generated at 2022-06-20 21:01:25.934359
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') != 'foo'
    assert unquote("'foo") != 'foo'
    assert unquote('foo"') != 'foo'
    assert unquote("foo'") != 'foo'
    assert unquote('fo"o') != 'foo'
    assert unquote("fo'o") != 'foo'
    assert unquote('"fo"o"') == 'fo"o'
    assert unquote("'fo'o'") == "fo'o"


# Generated at 2022-06-20 21:01:39.657577
# Unit test for function split_args
def test_split_args():
    """
    Tests for splitting args provided for ansible commands.

    """
    args_list = []
    # Test for parsing a list of quotes,
    # If a command requires arguments in quotes to be passed
    # as args, they are parsed and added to the list.
    args_list.append(
        'a=b c="foo bar" e=\'rishi\'',
        ['a=b', 'c="foo bar"', 'e=\'rishi\'']
    )
    # Test for parsing a list of args
    # If a command requires arguments in quotes to be passed
    # as args, they are parsed and added to the list.
    args_list.append(
        'a=b c=foo d=\'bar\'',
        ['a=b', 'c=foo', 'd=\'bar\'']
    )

# Generated at 2022-06-20 21:01:50.460339
# Unit test for function split_args

# Generated at 2022-06-20 21:01:58.522328
# Unit test for function split_args
def test_split_args():
    import sys

    if sys.version_info < (2, 6):
        print("SKIP: Python version %s.%s.%s too old to run this test." % sys.version_info[:3], file=sys.stderr)
        sys.exit(0)

    import ast
    import doctest


# Generated at 2022-06-20 21:02:04.309060
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('"""') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('""foo""') == True
    assert is_quoted('"f"oo"') == False
    assert is_quoted("'") == False
    assert is_quoted("'''") == False
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("''foo''") == True

# Generated at 2022-06-20 21:02:11.807240
# Unit test for function split_args
def test_split_args():
    # Common data
    tokens = [
        't1',
        't2 t3',
        't4\nt5',
    ]

    # Test the main function
    for test_data in tokens:
        test_data_splitted = split_args(test_data)
        test_data_splitted_joined = " ".join(test_data_splitted)
        assert test_data_splitted_joined == test_data, "%s != %s" % (test_data_splitted_joined, test_data)

    # Test if function works properly with quotes
    test_data = "\"quoted token\""
    data = split_args(test_data)
    assert len(data) == 1 and data[0] == test_data, "%s != %s" % (data[0], test_data)

   

# Generated at 2022-06-20 21:02:21.580963
# Unit test for function split_args

# Generated at 2022-06-20 21:02:29.509007
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted("''") == False
    assert is_quoted("' '") == False
    assert is_quoted("'a'") == True
    assert is_quoted("'''a'''") == True
    assert is_quoted("'a'b'") == False
    assert is_quoted("\"") == False
    assert is_quoted("\"\"") == False
    assert is_quoted("\" \"") == False
    assert is_quoted("\"a\"") == True
    assert is_quoted("\"\"\"a\"\"\"") == True
    assert is_quoted("\"a\"b\"") == False


# Generated at 2022-06-20 21:02:58.501360
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') is True
    assert is_quoted('"test') is False
    assert is_quoted('test"') is False
    assert is_quoted('test') is False
    assert is_quoted("'test'") is True
    assert is_quoted("'test") is False
    assert is_quoted("test'") is False
    assert is_quoted("test") is False


# Generated at 2022-06-20 21:03:09.915764
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b") == ["a=b"]
    # assert split_args("a=b c=d") == ["a=b c=d"]
    assert split_args("a=b \"c=d e=f\"") == ["a=b", "c=d e=f"]
    assert split_args("a=b \"c=d e=f\"") == ["a=b", "c=d e=f"]
    assert split_args("a=b \"c=d e=f\" \"g=h\"") == ["a=b", "c=d e=f", "g=h"]
    assert split_args("a=b \"c=d \\\"e=f\\\" g=h\"") == ["a=b", 'c=d "e=f" g=h']
    assert split

# Generated at 2022-06-20 21:03:14.489578
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted('"abc')
    assert not is_quoted("'abc")
    assert not is_quoted('abc')


# Generated at 2022-06-20 21:03:24.235950
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('"123"') == '123'
    assert unquote('\'123\'') == '123'
    assert unquote('123') == '123'
    assert unquote('"abcdefg"') == 'abcdefg'
    assert unquote('\'abcdefg\'') == 'abcdefg'

# Note: Using "from ansible.module_utils.basic import *" would make all the symbols
# from this module available when the file is imported, which is not what we want.
# The symbols are not needed in the normal use case, only for testing.  SO we import
# the symbols needed for testing in the test file.
#
# TODO: Can we be clever and use the value of __name__ or __main__ to determine if

# Generated at 2022-06-20 21:03:35.309478
# Unit test for function split_args

# Generated at 2022-06-20 21:03:46.166949
# Unit test for function split_args

# Generated at 2022-06-20 21:03:54.102957
# Unit test for function unquote
def test_unquote():
    assert("abc" == unquote("abc"))
    assert("abc" == unquote("'abc'"))
    assert("abc" == unquote("\"abc\""))
    assert("a\"bc" == unquote("a\"bc"))
    assert("\"ab\"c" == unquote("\"ab\"c"))
    assert("ab'c" == unquote("ab'c"))
    assert("ab" == unquote("\"ab\""))
    assert("'ab'" == unquote("'ab'"))
    assert("'\"ab\"'" == unquote("'\"ab\"'"))
    assert("'a\"b\"c'" == unquote("'a\"b\"c'"))
    assert("a\"b\"c" == unquote("a\"b\"c"))

# Generated at 2022-06-20 21:04:04.696544
# Unit test for function is_quoted
def test_is_quoted():
    """is_quoted function test cases"""
    assert(is_quoted("'test1'") == True)
    assert(is_quoted("'test2") == False)
    assert(is_quoted("test3'") == False)
    assert(is_quoted("test4") == False)
    assert(is_quoted('"test5"') == True)
    assert(is_quoted('"test6') == False)

# Generated at 2022-06-20 21:04:19.601969
# Unit test for function split_args
def test_split_args():
    assert split_args('') == ['']
    assert split_args('""') == ['']
    assert split_args('" "') == [' ']
    assert split_args('"" ""') == ['']
    assert split_args('" " " "') == [' ', ' ']
    assert split_args(' " " " " ') == [' ', ' ']
    assert split_args('a="b c"') == ['a=b c']
    assert split_args('  a="b c" ') == ['a=b c']
    assert split_args('a="b c" d') == ['a=b c', 'd']
    assert split_args('  a="b c"   d ') == ['a=b c', 'd']

# Generated at 2022-06-20 21:04:26.884154
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for function `split_args`
    '''

    import pytest
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    args = 'a=b c="foo bar" d="joe\'s place"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"', "d=joe's place"]

    args = 'a="b c" d=e "f g" "h\'i j"'
    params = split_args(args)
    assert params == ['a="b c"', 'd=e', 'f g', "h'i j"]


# Generated at 2022-06-20 21:05:24.108840
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("this is a test") == ["this", "is", "a", "test"]
    assert split_args("this \"is a test\"") == ["this", "\"is a test\""]
    assert split_args("this 'is a test'") == ["this", "'is a test'"]
    assert split_args('this "is \'a test"') == ['this', '"is \'a test"']
    assert split_args('this "is \'a test\"') == ['this', '"is \'a test\"']
    assert split_args('this "is \'a test\" more') == ['this', '"is \'a test\"', 'more']

# Generated at 2022-06-20 21:05:34.275403
# Unit test for function split_args
def test_split_args():

    # split_args() should preserve whitespace
    result = split_args('  foo  bar ')
    assert result == ['foo', 'bar'], result

    # if one of the params has a space, it should be split up into multiple ones
    result = split_args('all    my  single   spaced   parameters')
    assert result == ['all', 'my', 'single', 'spaced', 'parameters'], result

    # if one of the params has quotes around it, it should be treated as one single parameter
    result = split_args('foo bar="baz zug"')
    assert result == ['foo', 'bar="baz zug"'], result

    # same goes for single quotes
    result = split_args("foo bar='baz zug'")
    assert result == ['foo', "bar='baz zug'"], result



# Generated at 2022-06-20 21:05:40.812228
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('foo\'')
    assert not is_quoted('foo"bar"')
    assert is_quoted('"foo"')
    assert is_quoted('\'"foo"\'')


# Generated at 2022-06-20 21:05:43.197255
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('\'"') == True
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('\'"\'"') == True


# Generated at 2022-06-20 21:05:58.366247
# Unit test for function split_args
def test_split_args():
    assert split_args('"{{" "}}"') == ['{{', '}}']
    assert split_args('"{{" "}}" """ }}') == ['{{', '}}', '"}']
    assert split_args('"{{" "}}" "}}"') == ['{{', '}}', '}}']
    assert split_args('"{{ "foo" }}"') == ['{{ "foo" }}']
    assert split_args('"{{" "foo" }}"') == ['{{', '"foo" }}']
    assert split_args('"{{" "foo }}"') == ['{{', '"foo }}']
    assert split_args('"{{ foo" }}"') == ['{{ foo" }}']
    assert split_args(' "{{ foo" }}"') == [' "{{ foo" }}']

# Generated at 2022-06-20 21:06:03.575215
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"fo\'o"') == 'fo\'o'
    assert unquote("'fo\"o'") == 'fo\"o'

# Generated at 2022-06-20 21:06:06.948457
# Unit test for function unquote
def test_unquote():
    '''Unit test for function unquote.'''
    assert unquote('"a b c"') == "a b c"
    assert unquote("'a b c'") == "a b c"



# Generated at 2022-06-20 21:06:15.241877
# Unit test for function is_quoted
def test_is_quoted():
    for test_string in [ '1', 'ab', 'a"b', '"a"b"', '"a', 'a"', '"a""b"']:
        assert not is_quoted(test_string)

    for test_string in [ '"a"', '"ab"', "'a'", "'ab'"]:
        assert is_quoted(test_string)


# Generated at 2022-06-20 21:06:19.259714
# Unit test for function unquote
def test_unquote():
    assert unquote("") == ""
    assert unquote("'") == "'"
    assert unquote("''") == ""
    assert unquote("'''") == "''"
    assert unquote("''''") == ""
    assert unquote("a") == "a"
    assert unquote("'a'") == "a"
    assert unquote("''a") == "'a"
    assert unquote("a'") == "a'"


# Generated at 2022-06-20 21:06:27.666416
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('"foo"') == 'foo'
    assert unquote('""foo"') == '"foo'
    assert unquote('"foo""') == 'foo"'
    assert unquote('""foo""') == '"foo"'
    assert unquote('"foo"bar') == 'foo"bar'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('foo"bar') == 'foo"bar'
    assert unquote("'foo'") == 'foo'
    assert unquote("''foo") == "'foo"
    assert unquote("foo''") == "foo'"
    assert unquote("'foo'bar") == "foo'bar"

