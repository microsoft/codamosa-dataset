

# Generated at 2022-06-20 20:58:56.228680
# Unit test for function split_args
def test_split_args():
    assert split_args('   "foo bar"  baz    ') == ['foo bar', 'baz']
    assert split_args('   "foo bar""baz"    ') == ['foo barbaz']  # this is not going to work, but we don't care
    assert split_args('   "foo bar    "  baz    ') == ['foo bar    ', 'baz']
    assert split_args('''foo "bar baz"''') == ['foo', 'bar baz']
    assert split_args('"a=b c=d" "e=f g=h"') == ['a=b c=d', 'e=f g=h']

# Generated at 2022-06-20 20:59:04.424868
# Unit test for function split_args
def test_split_args():
    def check(args, result):
        ''' helper function to compare args and result '''
        if split_args(args) != result:
            print("\nERROR: args: %s\n  expected: %s\ngot: %s" % (args, result, split_args(args)))

    check("a=b c='foo bar'", ['a=b', "c='foo bar'"])
    check("a=b c=\"foo bar\"", ['a=b', 'c="foo bar"'])
    check("a=b c=\"foo bar\" d='hi there'", ['a=b', 'c="foo bar"', "d='hi there'"])
    check("a=b c='foo bar' d=\"hi there\"", ['a=b', "c='foo bar'", 'd="hi there"'])
   

# Generated at 2022-06-20 20:59:09.524776
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'simple'") == True
    assert is_quoted("'simple") == False
    assert is_quoted("\"simple\"") == True
    assert is_quoted("\"simple") == False
    assert is_quoted("simple") == False
    assert is_quoted("\"\"simple\"\"") == False
    assert is_quoted("''simple''") == False
    assert is_quoted("'\"'") == True



# Generated at 2022-06-20 20:59:20.423501
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for the function split_args.
    '''
    import sys

    # we can't easily test this function on Windows as it is,
    # since shlex doesn't behave the same.  We'd need to write
    # a version of shlex that works the same as on Posix, and
    # wrap this in a unit test
    if sys.platform == 'win32':
        return

    # test for the case of a single arg surrounded by quotes
    given_args = 'foo="bar baz"'
    expected_result = ['foo="bar baz"']
    result = split_args(given_args)
    assert result == expected_result

    # test for the case of a single quoted arg that contains an escaped quote
    given_args = 'foo="bar \\"baz\\""'

# Generated at 2022-06-20 20:59:29.296421
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"fo"o"') == False
    assert is_quoted('"') == False
    assert is_quoted('"""') == False
    assert is_quoted('\'foo\'') == True
    assert is_quoted("'") == False
    assert is_quoted("'''") == False
    assert is_quoted("bar") == False


# Generated at 2022-06-20 20:59:32.576653
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('paul"') == False
    assert is_quoted('"paul"') == True


# Generated at 2022-06-20 20:59:35.435171
# Unit test for function unquote
def test_unquote():
    assert unquote("") == ""
    assert unquote("foo") == "foo"
    assert unquote("\"foo\"") == "foo"
    assert unquote("\"foo") == "\"foo"
    assert unquote("foo\"") == "foo\""

# Generated at 2022-06-20 20:59:46.552425
# Unit test for function unquote
def test_unquote():
    result = unquote('"something"')
    assert result == "something", \
        "unquote (1) is failed. Expected something but got %s" % result

    result = unquote("something")
    assert result == "something", \
        "unquote (2) is failed. Expected something but got %s" % result

    result = unquote("'something'")
    assert result == "something", \
        "unquote (3) is failed. Expected something but got %s" % result

    result = unquote('''" something with space "''')
    assert result == " something with space ", \
        "unquote (4) is failed. Expected  something with space  but got %s" % result



# Generated at 2022-06-20 20:59:52.660480
# Unit test for function unquote
def test_unquote():
    assert unquote("''") == ''
    assert unquote("'a'") == 'a'
    assert unquote("'ab'") == 'ab'
    assert unquote("'abc'") == 'abc'
    assert unquote("'a'b") == ("'a'b")
    assert unquote("abc'") == "abc'"
    assert unquote("'abc") == "'abc"
    assert unquote("'abc'xyz") == "'abc'xyz"
    assert unquote("'''") == "'''"
    assert unquote("''a") == "''a"
    assert unquote("'''a'") == "'''a'"
    assert unquote("a''b") == "a''b"
    assert unquote("''a''b'") == "''a''b'"

# Generated at 2022-06-20 21:00:04.151925
# Unit test for function split_args

# Generated at 2022-06-20 21:00:24.748894
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello"')
    assert not is_quoted("hello'")
    assert not is_quoted('"hello\'')
    assert not is_quoted("'hello\"")
    assert not is_quoted('hello')


# Generated at 2022-06-20 21:00:37.900022
# Unit test for function is_quoted
def test_is_quoted():
    if is_quoted('"abcd"') != True:
        raise AssertionError('test failed')
    if is_quoted("'abcd'") != True:
        raise AssertionError('test failed')
    if is_quoted('"abcd') != False:
        raise AssertionError('test failed')
    if is_quoted("'abcd") != False:
        raise AssertionError('test failed')
    if is_quoted('abcd"') != False:
        raise AssertionError('test failed')
    if is_quoted("abcd'") != False:
        raise AssertionError('test failed')
    if is_quoted('abcd') != False:
        raise AssertionError('test failed')
    if is_quoted('') != False:
        raise Ass

# Generated at 2022-06-20 21:00:53.656515
# Unit test for function split_args
def test_split_args():
    args = "a=b c=\"foo bar\""
    params = ['a=b', 'c="foo bar"']
    assert params == split_args(args), "args: %s\nparams: %s" % (args, split_args(args))

    args = "a=b c='foo bar'"
    params = ['a=b', "c='foo bar'"]
    assert params == split_args(args), "args: %s\nparams: %s" % (args, split_args(args))

    args = "a=b c=\"foo\nbar\""
    params = ['a=b', 'c="foo\nbar"']
    assert params == split_args(args), "args: %s\nparams: %s" % (args, split_args(args))


# Generated at 2022-06-20 21:01:02.115012
# Unit test for function split_args
def test_split_args():
    assert split_args('foo=bar') == ['foo=bar']
    assert split_args('foo="bar baz"') == ['foo="bar baz"']
    assert split_args('foo="{{bar}}"') == ['foo="{{bar}}"']
    assert split_args('foo={{bar}}') == ['foo={{bar}}']
    assert split_args('foo="{{bar}} baz"') == ['foo="{{bar}} baz"']
    assert split_args('foo="{{bar }} baz"') == ['foo="{{bar }} baz"']
    assert split_args('foo="{{bar}}\" baz"') == ['foo="{{bar}}\" baz"']
    assert split_args('foo="{{bar}}\\\" baz"') == ['foo="{{bar}}\\\" baz"']
   

# Generated at 2022-06-20 21:01:17.179741
# Unit test for function split_args
def test_split_args():

    # Variables used by this unit test

    # Quotes used in the test
    quote_char = None
    inside_quotes = False

    # Print depth and block depth used in the test
    print_depth = 0
    block_depth = 0

    # Input and output args used in the test
    tokens_in = None
    params_out = None

    # BEGIN UNIT TEST
    # Testing single parameter
    tokens_in = ['echo', '"hello world"']
    params_out = split_args('echo "hello world"')
    assert tokens_in == params_out

    # Testing multiple parameters
    tokens_in = ['echo', '"hello"', '"world"']
    params_out = split_args('echo "hello"         "world"')
    assert tokens_in == params_out

    # Testing parameters with

# Generated at 2022-06-20 21:01:22.264983
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hel\\"lo"') == 'hel"lo'
    assert unquote('"hel\'lo"') == "hel'lo"
    assert unquote('hello') == 'hello'

# Generated at 2022-06-20 21:01:32.019815
# Unit test for function split_args
def test_split_args():
    '''
    Verify the split_args function keeps quotes and jinja2 blocks in tact properly.
    '''

# Generated at 2022-06-20 21:01:39.566013
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test that when run directly will iterate over a series of
    test strings designed to exercise the behavior of the split_args function.

    It also exercises the unquote function, as they are used together.
    '''


# Generated at 2022-06-20 21:01:50.732479
# Unit test for function split_args
def test_split_args():
    # Because the original code is split into multiple functions,
    # we just test the public interface provided by split_args
    assert split_args('a') == ['a']
    assert split_args('a b="foo   bar"') == ['a', 'b="foo   bar"']
    assert split_args('a "b c"') == ['a', '"b c"']
    assert split_args('a "b c\\" d"') == ['a', '"b c\\" d"']
    assert split_args('a "b c"\\\nd') == ['a', '"b c"', 'd']

# Generated at 2022-06-20 21:01:58.748702
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted('"\'hello\'"')
    assert is_quoted("'\"hello\"'")
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello"')
    assert not is_quoted("hello'")
    assert not is_quoted('"hello"extra')
    assert not is_quoted("'hello'extra")
    assert not is_quoted('extra"hello"')
    assert not is_quoted("extra'hello'")
    assert not is_quoted('')
    assert not is_quoted('""')
    assert not is_quoted("''")
    assert not is_quoted(None)

# Generated at 2022-06-20 21:02:20.376619
# Unit test for function unquote
def test_unquote():
    quoted = '"Hello, World!"'
    unquoted = 'Hello, World!'
    assert unquote(quoted) == unquoted
    assert unquote(unquoted) == unquoted
    assert unquote('') == ''
    assert unquote('"') == ''
    assert unquote('"Hello," World!"') == 'Hello," World!'
    assert unquote('Hello," World!"') == 'Hello," World!'
    assert unquote('"Hello," World!') == 'Hello," World!'
    assert unquote('"Hello," World!') == 'Hello," World!'
    assert unquote('"Hello," World!\\') == 'Hello," World!\\'


# Generated at 2022-06-20 21:02:35.825031
# Unit test for function split_args
def test_split_args():
    '''
    Tests for function split_args.
    If these fail, it's likely that the function needs to be updated
    to preserve the lexing order in the new version of python.
    '''

# Generated at 2022-06-20 21:02:47.131627
# Unit test for function split_args

# Generated at 2022-06-20 21:03:00.863846
# Unit test for function split_args
def test_split_args():
    def _split(args, result):
        assert split_args(args) == result

    _split(
        'a=b c="foo bar"',
        ['a=b', 'c="foo bar"'])

    _split(
        'a=b "a b"=c d=\'f g\'',
        ['a=b', '"a b"=c', 'd=\'f g\''])

    _split(
        'a=b \'a b\'=c d="f g"',
        ['a=b', '\'a b\'=c', 'd="f g"'])

    _split(
        'a="b \'c\'"',
        ['a="b \'c\'"'])


# Generated at 2022-06-20 21:03:11.319925
# Unit test for function split_args
def test_split_args():
    # Tests for all types, nested and unclosed quotes/jinja2
    assert split_args('foo="bar baz"') == ['foo="bar baz"']
    assert split_args('{{ foo }}') == ['{{ foo }}']
    assert split_args('{% foo %}') == ['{% foo %}']
    assert split_args('{# foo #}') == ['{# foo #}']
    assert split_args('foo="bar {{ baz }}') == ['foo="bar {{ baz }}']
    assert split_args('foo="bar {% baz %}') == ['foo="bar {% baz %}']
    assert split_args('foo="bar {# baz #}') == ['foo="bar {# baz #}']
    assert split_args('foo="bar {% baz } %}')

# Generated at 2022-06-20 21:03:20.719614
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests.mock import patch
    from ansible import constants as C
    from ansible.module_utils._text import to_bytes
    from io import StringIO
    import sys

    # simple test with facts=
    assert split_args('facts=yes') == ['facts=yes']

    # test with two quoted args, one with spaces
    assert split_args('foo="bar baz" bar=baz') == ['foo=bar baz', 'bar=baz']

    # test with two quoted args, one with spaces, one with escaped spaces
    assert split_args('foo="bar baz" bar=baz\\ qux') == ['foo=bar baz', 'bar=baz qux']

    # test with quoted arg containing quotes

# Generated at 2022-06-20 21:03:28.393456
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('\'foo\'')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo\'')
    assert not is_quoted('\'foo"')
    assert not is_quoted('foo')
    assert not is_quoted('"foo\'"')
    assert not is_quoted('foo\'')
    assert not is_quoted('foo\'')
    assert is_quoted('"foo\'"')
    assert not is_quoted('"foo\'')
    assert not is_quoted('\'foo"')
    try:
        is_quoted(None)
    except TypeError:
        pass

# Generated at 2022-06-20 21:03:36.808634
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == [str('a=b'), str('c="foo bar"')]
    assert split_args('"  a  "  "  b  "') == [str('  a  '), str('  b  ')]
    assert split_args("'  a  '  '  b  '") == [str('  a  '), str('  b  ')]
    assert split_args("a=b c=d 'foo bar'") == [str('a=b'), str('c=d'), str('foo bar')]
    assert split_args("a=b c=d \"foo bar\"") == [str('a=b'), str('c=d'), str('foo bar')]

# Generated at 2022-06-20 21:03:48.565936
# Unit test for function unquote
def test_unquote():
    from nose.plugins.skip import SkipTest
    from nose.plugins.attrib import attr
    # raise SkipTest("Skipped unquote test")
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'foo bar'") == "foo bar"
    assert unquote("'foo bar'") == "foo bar"
    assert unquote("'foo'bar'") == "'foobar'"
    assert unquote("'foo''bar'") == "foo'bar"
    assert unquote("foo") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("foo'bar'") == "foo'bar'"

# Generated at 2022-06-20 21:04:01.670339
# Unit test for function split_args

# Generated at 2022-06-20 21:04:24.449209
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote("foo bar") == "foo bar"
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote("foo 'bar'") == "foo 'bar'"
    assert unquote("'foo' bar") == "'foo' bar"
    assert unquote("foo") == "foo"
    assert unquote('"foo') == '"foo'
    assert unquote('"foo" bar') == '"foo" bar'
    assert unquote("'foo bar") == "'foo bar"


# Generated at 2022-06-20 21:04:30.326029
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted("'test")
    assert not is_quoted('"test')



# Generated at 2022-06-20 21:04:37.325923
# Unit test for function split_args
def test_split_args():
    '''
    split_args tests
    '''

# Generated at 2022-06-20 21:04:47.800808
# Unit test for function split_args
def test_split_args():
    '''
    Test the split_args function
    '''

    # Test list

# Generated at 2022-06-20 21:04:57.642451
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") is True
    assert is_quoted("'hello''") is False
    assert is_quoted("'hello") is False
    assert is_quoted("hello'") is False
    assert is_quoted("\"hello\"") is True
    assert is_quoted("\"hello\"\"") is False
    assert is_quoted("\"hello") is False
    assert is_quoted("hello\"") is False
    assert is_quoted("hello") is False



# Generated at 2022-06-20 21:05:03.802713
# Unit test for function is_quoted
def test_is_quoted():
    import sys
    try:
        from nose.tools import assert_equal
    except ImportError:
        print('-skipping unit tests, nose not installed')
        sys.exit(0)

    assert_equal(is_quoted('""'), True)
    assert_equal(is_quoted('"a"'), True)
    assert_equal(is_quoted('"a b"'), True)
    assert_equal(is_quoted('""""'), False)
    assert_equal(is_quoted(''), False)
    assert_equal(is_quoted('a'), False)
    print('%s: ok' % __name__)

# Generated at 2022-06-20 21:05:09.011032
# Unit test for function unquote
def test_unquote():
    assert unquote("\"test\"") == "test"
    assert unquote("'test'") == "test"
    assert unquote("\"test") == "\"test"
    assert unquote("'test") == "'test"


# Generated at 2022-06-20 21:05:20.222173
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('""""') == '""'
    assert unquote(' "abcd" ') == ' "abcd" '
    assert unquote('abcd') == 'abcd'
    assert unquote('"abcd"') == 'abcd'
    assert unquote("'abcd'") == 'abcd'
    assert unquote('abcd"xyz"') == 'abcd"xyz"'
    assert unquote('"abcd"xyz') == '"abcd"xyz'
    assert unquote("'abcd'xyz") == "'abcd'xyz"
    assert unquote("abcd'xyz") == "abcd'xyz"

# Generated at 2022-06-20 21:05:26.506176
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('a="b" c="d"')
    assert is_quoted('"b"')
    assert is_quoted("'b'")
    assert is_quoted("'''b'''")
    assert is_quoted('"""b"""')
    assert is_quoted("'''b'''")
    assert is_quoted('"""b"""')
    assert not is_quoted('"""b"""')
    assert not is_quoted('b')



# Generated at 2022-06-20 21:05:31.164431
# Unit test for function unquote
def test_unquote():
    assert unquote('hello') == 'hello'
    assert unquote("hello") == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello"') == 'hello'



# Generated at 2022-06-20 21:05:52.313582
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"a"b"c"') == 'a"b"c'
    assert unquote("'abc'") == 'abc'
    assert unquote("'a'b'c'") == 'a\'b\'c'

# Generated at 2022-06-20 21:05:55.402530
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo\'')


# Generated at 2022-06-20 21:06:05.743944
# Unit test for function split_args
def test_split_args():
    ''' Make sure we get the right answer with a few sample inputs '''
    assert split_args('asdf') == ['asdf']
    assert split_args('asdf "foo bar"') == ['asdf', '"foo bar"']
    assert split_args('ASDF="foo bar"') == ['ASDF="foo bar"']
    assert split_args('ASDF="foo bar') == ['ASDF="foo', 'bar']
    assert split_args('asdf "foo bar') == ['asdf', '"foo bar']
    assert split_args('asdf "foo bar\\"baz') == ['asdf', '"foo bar\\"baz']
    assert split_args('asdf "foo bar\\\\"baz"') == ['asdf', '"foo bar\\\\"baz"']

# Generated at 2022-06-20 21:06:11.589376
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted('\'hello\'')
    assert not is_quoted('"hello')
    assert not is_quoted('hello\'')
    assert not is_quoted('hello')


# Generated at 2022-06-20 21:06:24.710508
# Unit test for function split_args

# Generated at 2022-06-20 21:06:33.650634
# Unit test for function split_args
def test_split_args():
    import sys
    import textwrap
    import json

    if sys.version_info[0] == 3:
        try:
            unicode
        except NameError:
            unicode = str
        uchr = chr
    else:
        uchr = unichr

    def _chr(n):
        if n < 256:
            return chr(n)
        return uchr(n)

    def _json_dumps(s):
        return json.dumps(s, ensure_ascii=False, sort_keys=True, indent=2)

    def _to_repr(s):
        return repr(s.encode('utf8'))

    def _check_arg(expected, arg, test_result):
        if expected != test_result:
            args_str = textwrap.fill

# Generated at 2022-06-20 21:06:44.067113
# Unit test for function split_args

# Generated at 2022-06-20 21:06:54.468544
# Unit test for function is_quoted
def test_is_quoted():
    tests = dict(
        single_quoted_string='foo"bar',
        double_quoted_string="foo'bar",
        single_quote_at_start='"foobar',
        double_quote_at_start="'foobar",
        single_quote_at_end='foobar"',
        double_quote_at_end="foobar'",
        none_quoted_string='foobar',
        empty_string='',
    )
    for (key, value) in tests.items():
        assert not is_quoted(value)
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")


# Generated at 2022-06-20 21:07:07.879559
# Unit test for function split_args
def test_split_args():
    # Basic
    assert split_args('a=b c="d e"') == ['a=b', 'c="d e"']

    # Quotes and spaces
    assert split_args('a="b c" d="e f"') == ['a="b c"', 'd="e f"']

    # Escaped quotes and spaces
    assert split_args('a="b\\" c" d="e f"') == ['a="b" c"', 'd="e f"']

    # Escaped backslashes in quotes
    assert split_args('a="b \\\\\\" c') == ['a="b \\\\"', 'c']

    # unterminated quotes
    try:
        split_args('ab "cd')
    except Exception as e:
        pass
    else:
        raise Exception('should have raised an exception')

# Generated at 2022-06-20 21:07:18.644161
# Unit test for function split_args
def test_split_args():
    def _assert_equal(one, two):
        if one != two:
            raise ValueError("Unexpected mismatch: %s != %s" % (one, two))

    _assert_equal(split_args(""), [])
    _assert_equal(split_args("  "), [])
    _assert_equal(split_args("a=b c=d"), ["a=b", "c=d"])
    _assert_equal(split_args("a=b  c=d"), ["a=b", "c=d"])
    _assert_equal(split_args("a=1 c='test me'"), ["a=1", "c='test me'"])

# Generated at 2022-06-20 21:07:56.629181
# Unit test for function split_args

# Generated at 2022-06-20 21:08:01.152667
# Unit test for function unquote
def test_unquote():
    assert unquote('hello world') == 'hello world'
    assert unquote('"hello world"') == 'hello world'
    assert unquote("'hello world'") == 'hello world'
    assert unquote('\'hello world\"') == '\'hello world"'



# Generated at 2022-06-20 21:08:11.104927
# Unit test for function unquote
def test_unquote():
    if (unquote('Test"')) != 'Test"':
        print(unquote('Test"'))
        raise AssertionError()
    if (unquote('"Test"')) != 'Test':
        print(unquote('"Test"'))
        raise AssertionError()
    if (unquote('"Test')) != '"Test':
        print(unquote('"Test'))
        raise AssertionError()
    if (unquote('Test')) != 'Test':
        print(unquote('Test'))
        raise AssertionError()
    if (unquote('""')) != '':
        print(unquote('""'))
        raise AssertionError()
    if (unquote('"Test')) != '"Test':
        print(unquote('"Test'))
        raise AssertionError()

# Generated at 2022-06-20 21:08:17.962180
# Unit test for function split_args
def test_split_args():
    assert(split_args('') == [])
    assert(split_args('"foo bar" baz') == ['"foo bar"', 'baz'])
    assert(split_args('"foo bar" baz foo="bar baz"') == ['"foo bar"', 'baz', 'foo="bar baz"'])
    assert(split_args('"foo bar" baz foo="bar baz" bar={{ baz }}') == ['"foo bar"', 'baz', 'foo="bar baz"', 'bar={{ baz }}'])
    assert(split_args('"foo bar" baz foo="bar baz" bar={{ baz }}') == ['"foo bar"', 'baz', 'foo="bar baz"', 'bar={{ baz }}'])

# Generated at 2022-06-20 21:08:21.590087
# Unit test for function split_args
def test_split_args():
    D = {'a': 'b', 'c': 'foo bar', 'd': "baz 'junk in here' and more", 'e': "{{ foo }}", 'f': "{{ foo }}{% bar %}", 'g': "{% foo %}{# bar #}", 'h': "{% foo %} {{ bar }}", 'i': "{% foo %} {{ bar }} {# test #}", 'j': u"\u5317\u4EB0"}
    for (arg_string, result) in D.items():
        assert split_args(arg_string) == [result]