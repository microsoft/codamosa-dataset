

# Generated at 2022-06-20 20:58:39.178422
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('foo bar')
    assert not is_quoted('"foo bar')
    assert not is_quoted('foo bar"')
    assert is_quoted('"foo bar"')
    assert is_quoted("'foo bar'")
    assert not is_quoted("'foo bar")
    assert not is_quoted("foo bar'")
    assert not is_quoted("'foo 'bar'")
    assert is_quoted("'foo \"bar'")
    assert is_quoted("\"foo 'bar\"")


# Generated at 2022-06-20 20:58:48.220757
# Unit test for function unquote
def test_unquote():
    print("Testing unquote()")
    pairs = [
        ("'foo'", "foo"),
        ('"foo"', "foo"),
        ('foo', "foo"),
        ("'fo'o'", "'fo'o'"),
        ('"fo"o"', '"fo"o"'),
        ('fo"o', 'fo"o'),
        ("'foo", "'foo"),
        ('"foo', '"foo'),
        ('foo"', 'foo"'),
        ('foo\'', "foo'"),
    ]
    for input_value, expected in pairs:
        actual = unquote(input_value)
        if actual != expected:
            raise AssertionError("Input value: %s, expected: %s, got: %s" % (input_value, expected, actual))
    print("Success")
test_un

# Generated at 2022-06-20 20:58:58.131314
# Unit test for function unquote
def test_unquote():
    assert unquote("'test'") == "test"
    assert unquote('"test"') == "test"
    assert unquote("'test''test'") == "test'test"
    assert unquote('"test""test"') == 'test"test'
    assert unquote('"test""test"""test"""test""test"') == 'test"test"test"test"test'
    assert unquote("") == ""
    assert unquote("test") == "test"
    assert unquote("test\'test") == "test\'test"
    assert unquote("test\"test") == "test\"test"

test_unquote()

# Generated at 2022-06-20 20:59:04.543891
# Unit test for function is_quoted
def test_is_quoted():
    tests = [
        (('""', ), True),
        (("''", ), True),
        (('"a"', ), True),
        (("'a'", ), True),
        (('"a"""', ), False),
        (("'a'''", ), False),
        (('a"a', ), False),
        (("a'a", ), False),
        (('', ), False),
        (('"', ), False),
        (("'", ), False),
        ]
    for test, expected in tests:
        result = is_quoted(*test)
        assert result == expected, result



# Generated at 2022-06-20 20:59:06.273246
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('test') == 'test'

# Generated at 2022-06-20 20:59:13.057571
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'

# Generated at 2022-06-20 20:59:18.841424
# Unit test for function unquote
def test_unquote():
    assert unquote(None) == None
    assert unquote("hello") == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote('"hello"') == "hello"
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'

# Generated at 2022-06-20 20:59:30.545155
# Unit test for function split_args
def test_split_args():   # This should be in unit tests, not in library!

    # test simple case with no quotes or spaces
    r = split_args("foo=bar")
    assert r == ['foo=bar']

    # test equal sign inside quotes
    r = split_args('foo="bar=baz"')
    assert r == ['foo="bar=baz"']

    # test case with whitespace
    r = split_args("foo=bar baz=quux")
    assert r == ['foo=bar', 'baz=quux']

    # test case with escaped whitespace, should reduce to single arg
    r = split_args("foo\\ bar")
    assert r == ['foo bar']

    # test case with escaped escaped whitespace
    r = split_args("foo\\\\ bar")
    assert r == ['foo\\\\', 'bar']

    # test

# Generated at 2022-06-20 20:59:34.437737
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('') == ''


# Generated at 2022-06-20 20:59:37.316440
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("foo bar'") == "foo bar'"
    assert unquote('foo bar"') == 'foo bar"'

# Generated at 2022-06-20 20:59:53.536724
# Unit test for function is_quoted
def test_is_quoted():
    assert True == is_quoted('')
    assert True == is_quoted('""')
    assert True == is_quoted('"a"')
    assert True == is_quoted('"ab"')
    assert True == is_quoted('"a b"')
    assert True == is_quoted('"abcd"')
    assert True == is_quoted('\'"\'')
    assert True == is_quoted('"\'"')
    assert False == is_quoted('\'"')
    assert False == is_quoted('\'"a\'"')
    assert False == is_quoted('\'"ab\'"')
    assert False == is_quoted('\'"a b\'"')
    assert False == is_quoted('\'"abcd\'"')



# Generated at 2022-06-20 20:59:58.188156
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted('') == False
    assert is_quoted('"hello') == False
    assert is_quoted("'hello") == False


# Generated at 2022-06-20 21:00:02.569365
# Unit test for function unquote
def test_unquote():
    assert unquote('foobar') == 'foobar'
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('"""foobar"""') == '"""foobar"""'
    assert unquote("'''foobar'''") == "'''foobar'''"


# Generated at 2022-06-20 21:00:07.469356
# Unit test for function is_quoted
def test_is_quoted():
    a = '"abc"'
    b = 'abc'
    c = '"abc'
    d = 'abc"'
    assert is_quoted(a) == True
    assert is_quoted(b) == False
    assert is_quoted(c) == False
    assert is_quoted(d) == False


# Generated at 2022-06-20 21:00:11.087226
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("foo") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("\"foo\"") == True


# Generated at 2022-06-20 21:00:15.843819
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted("'hello") == False
    assert is_quoted('"hello') == False
    assert is_quoted("hello") == False
    assert is_quoted("'hello\"") == False


# Generated at 2022-06-20 21:00:19.975186
# Unit test for function unquote
def test_unquote():
    assert unquote('"ab"') == 'ab'
    assert unquote("'ab'") == 'ab'
    assert unquote('a') == 'a'
    assert unquote('"\'a\'"') == '\'"a"'
    assert unquote('\'"a\'"') == '\'"a"'
    assert unquote('""') == ''
    assert unquote("''") == ''


# Generated at 2022-06-20 21:00:34.975879
# Unit test for function split_args
def test_split_args():
    test_args = [
        # 'foo=bar',
        # 'foo="bar"',
        'foo=bar bar',
        'foo="bar bar"',
        'foo=bar \\',
        'bar',
        'foo="\'bar bar\'"',
        'foo="bar bar" \\',
        'bar',
        'bar={{',
        'foo }}',
        'bar="{{',
        'foo }}"',
        'bar="{{ foo',
        '}}"',
        'bar="{{ foo }}',
        '"',
        'z="{{foo}}"',
        'a="{% raw %}{{foo}",',
        '"{{bar}}',
        '{% endraw %}"',
        'a="%{foo}Y"',
    ]

# Generated at 2022-06-20 21:00:39.799475
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted("'foo'")
    assert not is_quoted('foo\'')
    assert not is_quoted('\'foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')



# Generated at 2022-06-20 21:00:44.259624
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted('"he\'ll"')
    assert is_quoted('"he"ll"')
    assert is_quoted("'hello'")
    assert is_quoted("'he\'ll'")
    assert is_quoted("'he'll'")
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')
    assert not is_quoted('hello')


# Generated at 2022-06-20 21:01:13.042234
# Unit test for function split_args
def test_split_args():

    '''
    tests the "split args" function used in many places
    '''

    class TestException(Exception):
        pass


# Generated at 2022-06-20 21:01:17.867831
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted('hello') == False
    assert is_quoted('') == False
    assert is_quoted('""') == True
    assert is_quoted("''") == True


# Generated at 2022-06-20 21:01:23.332705
# Unit test for function unquote
def test_unquote():
    assert unquote('"ab cd"') == 'ab cd'
    assert unquote("'ab cd'") == 'ab cd'
    assert unquote('ab cd') == 'ab cd'
    assert unquote('"ab cd') == '"ab cd'
    assert unquote("'ab cd") == "'ab cd"


# Generated at 2022-06-20 21:01:32.798040
# Unit test for function split_args
def test_split_args():
    assert split_args('foo="bar baz"') == ['foo="bar baz"']
    assert split_args('foo="bar baz" one="two three"') == ['foo="bar baz"', 'one="two three"']
    assert split_args('foo="bar \\"baz\\""') == ['foo="bar \\"baz\\""']
    assert split_args('foo=\\"bar baz\\"') == ['foo=\\"bar', 'baz\\"']
    assert split_args('foo="bar \\"baz\\""') == ['foo="bar \\"baz\\""']
    assert split_args('foo="bar \\"baz\\"" one="two three"') == ['foo="bar \\"baz\\""', 'one="two three"']

# Generated at 2022-06-20 21:01:40.123789
# Unit test for function is_quoted
def test_is_quoted():
    import pytest
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted('"abc')
    assert not is_quoted("'abc")
    assert not is_quoted("abc'")
    assert not is_quoted('abc"')
    assert not is_quoted("'a'b'c'")
    with pytest.raises(Exception) as excinfo:
        split_args('a=b{{x}}')
    assert 'unbalanced' in str(excinfo.value)
    with pytest.raises(Exception) as excinfo:
        split_args('a=b{{x')
    assert 'unbalanced' in str(excinfo.value)

# Generated at 2022-06-20 21:01:45.364301
# Unit test for function unquote
def test_unquote():
    s = "\"test\""
    assert unquote(s) == "test"
    s = "'test'"
    assert unquote(s) == "test"
    s = "\"test"
    assert unquote(s) == "test"

# Generated at 2022-06-20 21:02:00.177896
# Unit test for function is_quoted
def test_is_quoted():
    '''
    Test function to ensure inputs match expected values
    Input:
    Output:
    '''
    print('Testing is_quoted')

# Generated at 2022-06-20 21:02:01.810243
# Unit test for function unquote
def test_unquote():
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('foobar') == 'foobar'

# Generated at 2022-06-20 21:02:06.522623
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")

    assert not is_quoted('"quote"t')
    assert not is_quoted("'quote't")



# Generated at 2022-06-20 21:02:12.056564
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('""""') == '""'
    assert unquote('"   "') == '   '
    assert unquote('"\'a\'"') == '\'a\''
    assert unquote('\'a\'') == 'a'

# Generated at 2022-06-20 21:02:34.459196
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'")
    assert not is_quoted('test')


# Generated at 2022-06-20 21:02:45.565545
# Unit test for function split_args
def test_split_args():
    def assert_split_args(given, expected):
        assert expected == split_args(given)

    # simple args, no quoting
    assert_split_args("foo=bar key='value with spaces'", ["foo=bar", "key='value with spaces'"])

    # single quotes in args
    assert_split_args("a='1 2 3'", ["a='1 2 3'"])

    # double quotes in args
    assert_split_args("a=\"1 2 3\"", ["a=\"1 2 3\""])

    # escaped quotes in args
    assert_split_args("a='1 \"2\" 3'", ["a='1 \"2\" 3'"])
    assert_split_args("a=\"1 '2' 3\"", ["a=\"1 '2' 3\""])

    # quotes surrounding command
    assert_split

# Generated at 2022-06-20 21:02:56.933598
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('hello') == False)
    assert(is_quoted('') == False)
    assert(is_quoted('""') == False)
    assert(is_quoted('"hello"') == True)
    assert(is_quoted('\'hello\'') == True)
    assert(is_quoted('"hello\'') == False)
    assert(is_quoted(u'"hello"') == True)
    assert(is_quoted(u'\'hello\'') == True)


# Generated at 2022-06-20 21:03:05.026544
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"bar\"") == True
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted('"bar') == False
    assert is_quoted('"bar') == False
    assert is_quoted('  "bar') == False
    assert is_quoted('bar') == False
    assert is_quoted('') == False
    assert is_quoted('""') == False

# Generated at 2022-06-20 21:03:12.110011
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('"a"') is True
    assert is_quoted('\'a\'') is True
    assert is_quoted('"ab"') is True
    assert is_quoted('\'ab\'') is True
    assert is_quoted('"a"b') is False
    assert is_quoted('\'a\'b') is False
    assert is_quoted('"') is False
    assert is_quoted('\'') is False



# Generated at 2022-06-20 21:03:21.044297
# Unit test for function split_args
def test_split_args():
    your_args = 'a=1 b="foo bar" baz --c="d e f"'
    result = split_args(your_args)
    print("result:")
    for r in result:
        print("    " + r)

    your_args = 'a=1 c="d e f" b={{ stuff }}'
    result = split_args(your_args)

    print("result:")
    for r in result:
        print("    " + r)

    your_args = 'a=1 b="--version" c="d e f" b={{ stuff }}'
    result = split_args(your_args)

    print("result:")
    for r in result:
        print("    " + r)


# Generated at 2022-06-20 21:03:24.273566
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("\"foo\"") == "foo"
    assert unquote("\"\"foo\"\"") == "\"foo\""
    assert unquote("'foo'") == "foo"
    assert unquote("''foo''") == "'foo'"


# Generated at 2022-06-20 21:03:25.972758
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted(' test ')



# Generated at 2022-06-20 21:03:36.425679
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"hello"') == 'hello'
    assert unquote('""') == ''
    assert unquote('""""') == ''
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello" "world') == '"hello" "world'
    assert unquote('"hello" ') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('hell\no') == 'hell\no'
    assert unquote('hel\\lo') == 'hel\\lo'
    assert unquote('hel"lo') == 'hel"lo'
    assert unquote('hello\\') == 'hello\\'
    assert unquote('hello\\\\') == 'hello\\\\'
    assert unquote

# Generated at 2022-06-20 21:03:41.987851
# Unit test for function unquote
def test_unquote():
    data = "test"
    print("test_unquote: unquoted data: %s" % data)
    print("test_unquote: quoted data: %s" % quote(data))
    assert quote(data) == '"test"'
    assert unquote(quote(data)) == data


# Generated at 2022-06-20 21:04:38.824353
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for function split_args
    :return: None
    '''

# Generated at 2022-06-20 21:04:43.899470
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"data"') == True)
    assert(is_quoted("'data2'") == True)
    assert(is_quoted('data') == False)
    assert(is_quoted("'d''ata'") == True)
    assert(is_quoted("'d''a\"ta'") == True)



# Generated at 2022-06-20 21:04:50.533656
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted("'foo'bar'") == False
    assert is_quoted("'foobar") == False
    assert is_quoted('"foobar') == False
    assert is_quoted("foobar'") == False
    assert is_quoted('"foo') == False
    assert is_quoted("foo'") == False
    assert is_quoted("'foo") == False
    assert is_quoted('"foo') == False
    assert is_quoted("'foobar'")


# Generated at 2022-06-20 21:05:02.225085
# Unit test for function split_args
def test_split_args():
    import pytest
    from ansible.utils import _get_quote_state, split_args
    # Each tuple contains:
    # (input, output, print_depth, block_depth, comment_depth, inside_quotes, was_inside_quotes, quote_char)

# Generated at 2022-06-20 21:05:13.731264
# Unit test for function split_args
def test_split_args():
    print('Testing split_args function')

# Generated at 2022-06-20 21:05:20.666772
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('""') == True)
    assert (is_quoted("''") == True)
    assert (is_quoted('"string"') == True)
    assert (is_quoted("'string'") == True)
    assert (is_quoted('string') == False)
    assert (is_quoted('"') == False)
    assert (is_quoted("'") == False)



# Generated at 2022-06-20 21:05:31.071757
# Unit test for function unquote

# Generated at 2022-06-20 21:05:41.233552
# Unit test for function is_quoted
def test_is_quoted():
    # Test unquoted string
    assert not is_quoted('unquoted string')

    # Test quoted string
    assert is_quoted('"quoted string"')

    # Test single quote
    assert is_quoted("'single quote'")

    # Test string with escaped quotes
    assert not is_quoted('"escaped\" quotes"')

    # Test single quote with backslash (invalid)
    assert is_quoted("'single\\' quote'")


# Generated at 2022-06-20 21:05:53.295311
# Unit test for function split_args
def test_split_args():

    import sys
    import json

    if sys.version_info[0] == 2:
        import cStringIO as StringIO
        import cPickle as pickle
    else:
        import io as StringIO
        import pickle
    # first test the _get_quote_state function
    test_str = "'\"'\"'\"'\"'\"'\"'\"'\"'\"'\"'\"'\"'\"'\"'\"'\"'\"'\"'"
    assert _get_quote_state(test_str, None) == "'"
    test_str = '"\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""\\""'
    assert _get_quote_state(test_str, None) == '"'


# Generated at 2022-06-20 21:06:01.777705
# Unit test for function split_args
def test_split_args():
    '''
    Several unit tests for function split_args
    '''
    import sys
    import string
    # Simple test
    assert split_args("ls -l") == ['ls', '-l']

    # Three args, first two with embedded quotes
    assert split_args("""echo "hello world" "hi there" /some/file""") == ['echo', '"hello world"', '"hi there"', '/some/file']

    # Several args, first one with embedded quotes
    assert split_args("""echo "hello world" hi there /some/file""") == ['echo', '"hello world"', 'hi', 'there', '/some/file']

# Generated at 2022-06-20 21:06:59.489861
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote('test') == "test"
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote('"test""') == '"test""'
    assert unquote('"""test"""') == '"test"'


# Generated at 2022-06-20 21:07:09.620988
# Unit test for function split_args
def test_split_args():
    params = split_args('test1 test2 "test 3" "test 4"')
    assert params == ['test1', 'test2', '"test 3"', '"test 4"'], params

    params = split_args('t1 t2 \'t 3\' t4')
    assert params == ['t1', 't2', '\'t 3\'', 't4'], params

    params = split_args('t1 t2 "t 3" t4')
    assert params == ['t1', 't2', '"t 3"', 't4'], params

    params = split_args('t1 t2 "t 3" t4')
    assert params == ['t1', 't2', '"t 3"', 't4'], params

    params = split_args('"t1 t2" t3')
    assert params

# Generated at 2022-06-20 21:07:25.756278
# Unit test for function is_quoted
def test_is_quoted():
    test_cases = (
        ('"matcher"', True),
        ("''", True),
        ("'matcher'", True),
        ('', False),
        ('"', False),
        ("'", False),
        ('"matcher', False),
        ('matcher"', False),
        ('"matcher\'', False),
        ('\'matcher"', False),
        ('\'matcher\'', True),
    )
    for test_case in test_cases:
        test_data, assertion = test_case
        try:
            result = is_quoted(test_data)
        except Exception:
            print("Exception caught when testing is_quoted():")
            raise

# Generated at 2022-06-20 21:07:28.023497
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'



# Generated at 2022-06-20 21:07:31.481793
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('\'hello\'') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('\'hello"') == '\'hello"'
    assert unquote('"hello\'') == '"hello\''

# Generated at 2022-06-20 21:07:47.114884
# Unit test for function split_args
def test_split_args():
    """
    Unit tests for function split_args.
    """

# Generated at 2022-06-20 21:07:52.274701
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hi"')
    assert is_quoted("'hi'")
    assert not is_quoted('hi')
    assert not is_quoted('"hi')
    assert not is_quoted("'hi")


# Generated at 2022-06-20 21:08:07.556250
# Unit test for function split_args
def test_split_args():
    def compare(input, output):
        result = split_args(input)
        if ' '.join(output) != ' '.join(result):
            print("input: '%s'" % input)
            print("output: '%s'" % ' '.join(result))
            print("expected: '%s'" % ' '.join(output))
            print()

    compare(r'a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    compare(r'a=b "c=\'foo bar\'"', ['a=b', '"c=\'foo bar\'"'])
    compare(r'a=b "c=\'foo bar\'" \'d="foo bar"\'', ['a=b', '"c=\'foo bar\'"', '\'d="foo bar"\''])
    compare

# Generated at 2022-06-20 21:08:11.324563
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"this is a string"')
    assert is_quoted("'this is a string'")
    assert not is_quoted('this is a string')
    assert not is_quoted('"this is a string')
    assert not is_quoted('this is a string"')



# Generated at 2022-06-20 21:08:16.220931
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"string"') is True
    assert is_quoted("'string'") is True
    assert is_quoted("'string") is False
    assert is_quoted("string'") is False
    assert is_quoted("'string\"") is False
    assert is_quoted("string") is False
    assert is_quoted("'string\"") is False
    assert is_quoted("'") is False
    assert is_quoted("\"") is False

