

# Generated at 2022-06-20 20:58:48.426960
# Unit test for function unquote
def test_unquote():
    a = "quoted string"
    b = "'quoted string'"
    c = '''\t"quoted string"'''
    d = "not quoted"

    assert unquote(a) == a
    assert unquote(b) == a
    assert unquote(c) == a
    assert unquote(d) == d



# Generated at 2022-06-20 20:58:58.894406
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"'))
    assert(is_quoted("'foo'"))
    assert(is_quoted("'foo")) is False
    assert(is_quoted("foo'")) is False
    assert(is_quoted('"foo')) is False
    assert(is_quoted('foo"')) is False
    assert(is_quoted('foobar')) is False
    assert(is_quoted('foo"bar')) is False
    assert(is_quoted('"foo"bar"')) is False
    assert(is_quoted('foo"bar"baz')) is False
    assert(is_quoted('')) is False



# Generated at 2022-06-20 20:59:03.852572
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"""') is False
    assert is_quoted('"abc"') is True
    assert is_quoted('abc\'') is False
    assert is_quoted('\'\'\'') is False
    assert is_quoted('\'abc\'') is True
    assert is_quoted('"') is False
    assert is_quoted('\'') is False
    assert is_quoted('') is False


# Generated at 2022-06-20 20:59:17.739190
# Unit test for function split_args
def test_split_args():

    def assert_results_equal(args, expected_results):
        results = split_args(args)
        assert results == expected_results, '{0} : {1}'.format(results, expected_results)


    assert_results_equal('''
''', [])
    assert_results_equal('''a
''', ['a'])
    assert_results_equal('''a b
''', ['a', 'b'])
    assert_results_equal('''a b\\
c
''', ['a', 'b c'])
    assert_results_equal('''a "b c"
''', ['a', '"b c"'])

# Generated at 2022-06-20 20:59:21.127869
# Unit test for function unquote
def test_unquote():
    print("unquote('\"foo\"') returned %s" % unquote('"foo"'))
    print("unquote(\"'foo'\") returned %s" % unquote("'foo'"))
    print("unquote('foo') returned %s" % unquote('foo'))


# Generated at 2022-06-20 20:59:28.091968
# Unit test for function is_quoted
def test_is_quoted():
    data = 'this is a string'
    assert False == is_quoted(data)

    data = '"this is a string"'
    assert True == is_quoted(data)

    data = "'this is a string'"
    assert True == is_quoted(data)



# Generated at 2022-06-20 20:59:35.317697
# Unit test for function is_quoted
def test_is_quoted():
    assert(     is_quoted('"string"') == True)
    assert(     is_quoted("'string'") == True)
    assert(     is_quoted("'string\"") == False)
    assert(     is_quoted('"string\'') == False)
    assert(     is_quoted("'string") == False)
    assert(     is_quoted('"string') == False)


# Generated at 2022-06-20 20:59:47.171574
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('""') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('""') == False
    assert is_quoted('""""') == False
    assert is_quoted('""""""') == False
    assert is_quoted('"""foo""""') == False
    assert is_quoted('"""foo"""') == False
    assert is_quoted('foo"""') == False
    assert is_

# Generated at 2022-06-20 20:59:53.009513
# Unit test for function is_quoted
def test_is_quoted():
    assert(False == is_quoted(''))
    assert(False == is_quoted('"'))
    assert(False == is_quoted('\'  '))
    assert(True == is_quoted('"  '))
    assert(True == is_quoted('\'  '))
    assert(True == is_quoted('""'))
    assert(True == is_quoted('""  '))
    assert(False == is_quoted('"""  '))
    assert(True == is_quoted('\'\''))
    assert(True == is_quoted('\'\'  '))
    assert(False == is_quoted('\'\'\'  '))
    assert(False == is_quoted('foo'))
    assert(False == is_quoted('foo bar'))

# Generated at 2022-06-20 21:00:00.016016
# Unit test for function split_args
def test_split_args():
    '''
    Test the arg splitting function that is used by the module to parse arguments.
    '''
    from ansible.compat.tests import unittest
    import ansible.compat.six as six
    import os

    # test parsing of multiple params with no quoted jinja blocks
    args = "ansible all -m raw -a 'foo' -a 'bar'"
    params = split_args(args)
    assert params == ['ansible', 'all', '-m', 'raw', '-a', "'foo'", '-a', "'bar'"], params

    # test parsing of a param with a quoted jinja block
    args = "ansible all -a 'foo {{bar}}'"
    params = split_args(args)

# Generated at 2022-06-20 21:00:19.093955
# Unit test for function split_args
def test_split_args():
    assert split_args("foo") == ['foo']
    assert split_args("foo bar baz") == ['foo', 'bar', 'baz']
    assert split_args("foo=\"bar baz\"") == ['foo=bar baz']
    assert split_args("foo='bar baz'") == ['foo=bar baz']
    assert split_args("foo=bar\\\nbaz") == ['foo=bar\\\n', 'baz']
    assert split_args("foo=\"bar\\\\baz\"") == ['foo=bar\\\\baz']
    assert split_args("foo=\"bar\\\"baz\"") == ['foo=bar\"baz']
    assert split_args("foo=\"bar'baz\"") == ['foo=bar\'baz']

# Generated at 2022-06-20 21:00:26.344249
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"


# Generated at 2022-06-20 21:00:37.573669
# Unit test for function split_args
def test_split_args():
    import sys
    import re
    # python 3 requires double quotes for arg strings

# Generated at 2022-06-20 21:00:49.255196
# Unit test for function split_args
def test_split_args():

    # test we split on whitespace properly
    assert split_args('   foo   bar   ') == ['foo', 'bar']

    # test that we do not split inside quoted strings
    assert split_args('   foo   bar   baz  "hello world"') == ['foo', 'bar', 'baz', '"hello world"']
    assert split_args("   foo   bar   baz  'hello world'") == ['foo', 'bar', 'baz', "'hello world'"]

    # test that we do not split inside jinja2 blocks
    assert split_args('   foo   bar   baz  {{hello world}}') == ['foo', 'bar', 'baz', '{{hello world}}']

# Generated at 2022-06-20 21:00:59.455177
# Unit test for function is_quoted
def test_is_quoted():
    #True cases:
    assert (is_quoted('""') == True)
    assert (is_quoted('"this"') == True)
    assert (is_quoted('"this is a string"') == True)
    assert (is_quoted("'this is a string'") == True)
    assert (is_quoted("'") == True)
    assert (is_quoted('"') == True)
    assert (is_quoted(' ') == False)
    assert (is_quoted('this') == False)
    assert (is_quoted('"this') == False)
    assert (is_quoted('this"') == False)
    assert (is_quoted("'this") == False)
    assert (is_quoted("this'") == False)

# Generated at 2022-06-20 21:01:02.238545
# Unit test for function unquote
def test_unquote():
    # Non quoted strings should not change
    assert unquote('"my_string"') == 'my_string'



# Generated at 2022-06-20 21:01:16.034254
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted('"ab"c"') == False
    assert is_quoted('"a"b"c"') == False
    assert is_quoted('"a""b""c"') == False
    assert is_quoted('""a"""') == False
    assert is_quoted('a') == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('"""') == False
    assert is_quoted('"""abc"""') == False


# Generated at 2022-06-20 21:01:23.896717
# Unit test for function split_args
def test_split_args():
    with open('test/unit/utils/test_split_args.py') as f:
        for line in f:
            if line.startswith('#'):
                continue
            tokens = line.split(' => ')
            expected = eval(tokens[1])
            actual = split_args(tokens[0])
            if expected != actual:
                print("'" + str(expected) + "'")
                print("'" + str(actual) + "'")
                assert False

# Generated at 2022-06-20 21:01:31.062480
# Unit test for function is_quoted
def test_is_quoted():
    ret = is_quoted('r')
    assert ret == False
    ret = is_quoted('"r"')
    assert ret == True
    ret = is_quoted('\'r\'')
    assert ret == True
    ret = is_quoted('')
    assert ret == False
    ret = is_quoted('""')
    assert ret == True
    ret = is_quoted('"')
    assert ret == False
    ret = is_quoted('"sdfsdfsdfsdf"')
    assert ret == True



# Generated at 2022-06-20 21:01:41.353477
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', 'c=\'foo bar\'']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c={{ foo }}") == ['a=b', "c={{ foo }}"]
    assert split_args("a=b c={{ foo }}") == ['a=b', "c={{ foo }}"]
    assert split_args("a=1 b=2 c=3") == ['a=1', 'b=2', 'c=3']

# Generated at 2022-06-20 21:01:55.222383
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("")
    assert not is_quoted("'")
    assert not is_quoted("\"")
    assert is_quoted("'foo'")
    assert is_quoted("\"bar\"")
    assert is_quoted("'foo\"")
    assert is_quoted("bar'")


# Generated at 2022-06-20 21:02:00.029824
# Unit test for function unquote
def test_unquote():
    assert unquote('"baz"') == 'baz'
    assert unquote("'baz'") == 'baz'
    assert unquote('"foo\'bar"') == "foo\'bar"
    assert unquote('"foo" bar') == '"foo" bar'
    assert unquote('') == ''
    assert unquote('     ') == '     '
    assert unquote('"') == '"'
    assert unquote('\'"') == '\'"'
    assert unquote('foo') == 'foo'


# Generated at 2022-06-20 21:02:06.688383
# Unit test for function is_quoted
def test_is_quoted():

    assert not is_quoted('')
    assert is_quoted('""')
    assert is_quoted('"foo bar"')
    assert not is_quoted('foo bar')
    assert is_quoted("''")
    assert is_quoted("'foo bar'")
    assert not is_quoted("foo bar")



# Generated at 2022-06-20 21:02:21.030570
# Unit test for function split_args
def test_split_args():
    # basic test
    check_split_args("/bin/foo bar baz", ['/bin/foo', 'bar', 'baz'])
    # test jinja2 variable
    check_split_args("/bin/foo {{bar}} baz", ['/bin/foo', '{{bar}}', 'baz'])
    #test jinja2 expression
    check_split_args("/bin/foo {{bar|lower}} baz", ['/bin/foo', '{{bar|lower}}', 'baz'])
    # test jinja2 variable over multiple tokens
    check_split_args("/bin/foo {{bar}} baz {{blammo}}", ['/bin/foo', '{{bar}}', 'baz', '{{blammo}}'])
    # test multiple jinja2 expressions
    check_split_args

# Generated at 2022-06-20 21:02:26.782535
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote('"hello') == '"hello'
    assert unquote("hello") == "hello"


# Generated at 2022-06-20 21:02:32.748479
# Unit test for function split_args
def test_split_args():
    # Test one simple command
    assert split_args("ls -la /home") == ['ls', '-la', '/home']
    # Test a complicated command
    assert split_args("ls {{item}}") == ['ls', '{{item}}']
    # Test a command that spans multiple lines
    assert split_args("ls {{var1}}\n{{var2}}") == ['ls', '{{var1}}', '{{var2}}']
    # Test a command that has a quote in a jinja2 block
    assert split_args(r"ls {{item}} \n"
                      r"{{foo.bar|join('\n')}}") == ['ls', '{{item}}', "{{foo.bar|join('\n')}}"]
    # Test a command that has a quote in a jinja2 block, with an escaped newline
   

# Generated at 2022-06-20 21:02:40.430729
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"a"') == True
    assert is_quoted('"ab"') == True
    assert is_quoted('"a b"') == True
    assert is_quoted('""') == True
    assert is_quoted('"a\\"') == True
    assert is_quoted('a') == False
    assert is_quoted('a\\"') == False
    assert is_quoted('"a') == False
    assert is_quoted('a"') == False
    assert is_quoted('ab') == False


# Generated at 2022-06-20 21:02:49.326337
# Unit test for function unquote
def test_unquote():
    '''
    test_unquote - test function unquote to make sure that it works properly
    '''
    data_list = [
        'aiueo',
        '"aiueo"',
        '\'aiueo\'',
        '"aiueo.',
        'aiueo"',
        '\'aiueo.',
        'aiueo\'',
        r'"ai\"ueo"',
        r'\'ai\'ueo\'',
        r'"aiueo',
        r'\'aiueo',
    ]
    for data in data_list:
        if is_quoted(data):
            assert unquote(data) == 'aiueo', "unquote(%s) returns %s, but %s expected" % (data, unquote(data), 'aiueo')

# Generated at 2022-06-20 21:02:57.933895
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"123"')
    assert is_quoted("'123'")
    assert is_quoted('""')
    assert is_quoted("''")
    assert not is_quoted('123')
    assert not is_quoted('"123')
    assert not is_quoted('123"')
    assert not is_quoted('12"3')



# Generated at 2022-06-20 21:03:09.753818
# Unit test for function split_args
def test_split_args():
    #test1
    result = split_args("-a aaa -b bbb")
    assert len(result) == 2
    assert result[0] == '-a aaa'
    assert result[1] == '-b bbb'

    #test2
    result = split_args("")
    assert len(result) == 0

    #test3
    result = split_args("a b")
    assert len(result) == 2
    assert result[0] == "a"
    assert result[1] == "b"

    #test4
    result = split_args("a='b c' d")
    assert len(result) == 2
    assert result[0] == "a='b c'"
    assert result[1] == "d"

    #test5

# Generated at 2022-06-20 21:03:32.719602
# Unit test for function split_args
def test_split_args():
    """Test that split_args works"""


# Generated at 2022-06-20 21:03:45.605054
# Unit test for function split_args
def test_split_args():
    '''
    Test split_args function.
    '''
    def test(args, expected, tokendebug=False):
        '''
        Convenience function to run some test data through split_args
        and verify the output.
        '''
        tokens = split_args(args)
        if tokens != expected:
            if tokendebug:
                print(args)
                print(expected)
                print(tokens)
            raise Exception("split_args() failed to split %s, expected %s and got %s" % (args, expected, tokens))

    test('foo=bar baz="one two"', ['foo=bar', 'baz="one two"'])
    test('foo=""', ['foo=""'])
    test('   ', [])

# Generated at 2022-06-20 21:03:53.732868
# Unit test for function split_args

# Generated at 2022-06-20 21:04:03.259032
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('"x') == '"x'
    assert unquote('x') == 'x'
    assert unquote('x"') == 'x"'
    assert unquote('"x"') == 'x'
    assert unquote("'x") == "'x"
    assert unquote("x'") == "x'"
    assert unquote("'x'") == 'x'
    assert unquote("'x\'x'") == "x\'x"
    assert unquote("\"x'x\"") == "x'x"
    assert unquote("x'x") == "x'x"
    assert unquote("x\"x") == 'x"x'
    assert unquote("'\"x\"'") == '"x"'


# Generated at 2022-06-20 21:04:12.800055
# Unit test for function unquote
def test_unquote():
    ''' unquote should return the same string for all these cases '''
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote('"foo""bar"') == 'foo""bar'
    assert unquote("'foo''bar'") == 'foo''bar'
    assert unquote('"foo\\"bar"') == 'foo\\"bar'
    assert unquote("'foo\\'bar'") == "foo\\'bar"


# Generated at 2022-06-20 21:04:15.297547
# Unit test for function unquote
def test_unquote():
    assert unquote('"example"') == 'example'
    assert unquote("'example'") == 'example'
    assert unquote("example") == 'example'
    assert unquote("'") == "'"
    assert unquote("'''") == "'''"

test_unquote()

# Generated at 2022-06-20 21:04:25.973109
# Unit test for function split_args

# Generated at 2022-06-20 21:04:39.928216
# Unit test for function split_args
def test_split_args():
    # test some simple cases
    if split_args("a=b") != ['a=b']:
        raise Exception("test 1 failed")
    if split_args("a=b c=d") != ['a=b', 'c=d']:
        raise Exception("test 2 failed")
    if split_args("a=b 'c=d e=f'") != ['a=b', "c=d e=f"]:
        raise Exception("test 3 failed")
    if split_args("a=b 'c=d e=f' g=h") != ['a=b', "c=d e=f", 'g=h']:
        raise Exception("test 4 failed")

# Generated at 2022-06-20 21:04:55.067875
# Unit test for function split_args
def test_split_args():
    # test basic cases
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo=bar baz=quix') == ['foo=bar', 'baz=quix']
    assert split_args('foo = bar') == ['foo', '=', 'bar']
    assert split_args('foo="bar quix"') == ['foo="bar quix"']
    assert split_args('foo="bar \\"quix\\""') == ['foo="bar \\"quix\\""']
    assert split_args('foo="bar \\\\"quix\\\\""') == ['foo="bar \\\\"quix\\\\""']

# Generated at 2022-06-20 21:05:01.162348
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("hello") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("'hello'!") == "'hello'!"
    assert unquote("'hello'" + chr(4)) == "'hello'" + chr(4)



# Generated at 2022-06-20 21:05:53.498462
# Unit test for function unquote
def test_unquote():
    ''' unit test for function unquote '''

    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote("'") == "'"
    assert unquote('a"b') == 'a"b'
    assert unquote("a'b") == "a'b"
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"
    assert unquote('abc"') == 'abc"'
    assert unquote("abc'") == "abc'"
    assert unquote('""') == ''
    assert unquote("''") == ''


# Generated at 2022-06-20 21:06:01.903370
# Unit test for function split_args
def test_split_args():
    print("Testing split_args:")
    try:
        split_args('')
    except Exception as e:
        print("ERROR: split_args('') failed, exception: %s" % e)
    try:
        split_args('a=a b=b')
    except Exception as e:
        print("ERROR: split_args('a=a b=b') failed, exception: %s" % e)
    try:
        split_args('a=a b=b c=c')
    except Exception as e:
        print("ERROR: split_args('a=a b=b c=c') failed, exception: %s" % e)

# Generated at 2022-06-20 21:06:04.549856
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abcd') == 'abcd'
    assert unquote('\'abc\'') == 'abc'
    assert unquote('"a""b"c"') == 'a"b"c'

# Generated at 2022-06-20 21:06:19.576340
# Unit test for function is_quoted
def test_is_quoted():
    '''
    Test function is_quoted.
    '''
    assert not is_quoted(''), "Empty string is not quoted."
    assert not is_quoted('foo'), "Regular string is not quoted."
    assert is_quoted('"foo"'), "Double-quoted string is quoted."
    assert is_quoted("'foo'"), "Single-quoted string is quoted."
    assert not is_quoted('"foo'), "String ending with double quote is not quoted."
    assert not is_quoted("'foo"), "String ending with single quote is not quoted."
    assert not is_quoted('foo"'), "String starting with a double quote is not quoted."
    assert not is_quoted("foo'"), "String starting with a single quote is not quoted."



# Generated at 2022-06-20 21:06:25.945872
# Unit test for function is_quoted
def test_is_quoted():
   r'''
>>> is_quoted("")
False
>>> is_quoted('""')
True
>>> is_quoted("''")
True
>>> is_quoted('"foo"')
True
>>> is_quoted("'foo'")
True
>>> is_quoted('"foo" "bar"')
True
>>> is_quoted("'foo' 'bar'")
True
>>> is_quoted("'foo")
False
>>> is_quoted('"foo')
False
   '''


# Generated at 2022-06-20 21:06:33.540833
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'")
    assert is_quoted('"test"')
    assert is_quoted("'test") == False
    assert is_quoted('"test') == False
    assert is_quoted("test'") == False
    assert is_quoted('test"') == False
    assert is_quoted("test") == False
    assert is_quoted("'test''") == False
    assert is_quoted("\"test\"\"") == False
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted('"') == False


# Generated at 2022-06-20 21:06:39.563249
# Unit test for function unquote
def test_unquote():
    result_1 = unquote('"hello world"')
    result_2 = unquote('"hello world')
    result_3 = unquote('hello world"')
    result_4 = unquote('hello world')
    assert result_1 == 'hello world'
    assert result_2 == '"hello world'
    assert result_3 == 'hello world"'
    assert result_4 == 'hello world'



# Generated at 2022-06-20 21:06:47.681578
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('x')
    assert not is_quoted('123')
    assert not is_quoted('"')
    assert not is_quoted('\'')
    assert not is_quoted('"x')
    assert not is_quoted('x"')
    assert not is_quoted('\'x')
    assert not is_quoted('x\'')
    assert is_quoted('"x"')
    assert is_quoted('\'x\'')
    assert is_quoted('"\'"')
    assert is_quoted('"x\'')
    assert is_quoted('\'x"')


# Generated at 2022-06-20 21:06:52.210633
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"this is a string"')
    assert not is_quoted('this is not a string"')
    assert is_quoted("'this is a string'")
    assert not is_quoted("this is not a string'")


# Generated at 2022-06-20 21:06:59.063183
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"ab\\"c"') == 'ab"c'
    assert unquote("'ab'c'") == "ab'c"
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"



# Generated at 2022-06-20 21:08:32.106533
# Unit test for function split_args
def test_split_args():
    # Simple arguments that should work as-is
    assert split_args("one") == ["one"]
    assert split_args("one two three") == ["one", "two three"]
    assert split_args("one two three four") == ["one", "two", "three four"]
    assert split_args("one \"two three\"") == ["one", "\"two three\""]
    assert split_args("one \"two three\" 'four five'") == ["one", "\"two three\"", "'four five'"]

    # Test splitting on line continuation
    assert split_args("one two three \\\nfour") == ["one", "two three \\\nfour"]

    # Test splitting on line continuation that is followed by a space
    assert split_args("one two three \\\n four") == ["one", "two three \\\n four"]

    #