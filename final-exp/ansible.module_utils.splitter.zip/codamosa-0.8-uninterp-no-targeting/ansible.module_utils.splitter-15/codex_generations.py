

# Generated at 2022-06-20 20:58:46.689736
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('')
    assert not is_quoted('""')
    assert not is_quoted('"')
    assert not is_quoted("'")


# Generated at 2022-06-20 20:58:58.632410
# Unit test for function split_args
def test_split_args():
    ''' unit test for function split_args '''

    def _test(input_arg, expected):
        ''' helper function to verify the results of split_args '''
        results = split_args(input_arg)
        error_message = "Expected: %s\nGot: %s" % (expected, results)
        assert results == expected, error_message

    _test("a=b c=\"foo bar\"", ['a=b', 'c="foo bar"'])
    _test("a='b c' d='foo bar'", ['a=b c', 'd=foo bar'])
    _test("a='b c' d=\"foo bar\"", ['a=b c', 'd="foo bar"'])

# Generated at 2022-06-20 20:59:06.036650
# Unit test for function split_args
def test_split_args():
    ''' Unit tests for function split_args '''
    a = "a=b c=\"foo bar\""
    b = split_args(a)
    assert b == ['a=b', 'c="foo bar"']
    a = "a=b\\\nc=d"
    b = split_args(a)
    assert b == ['a=b\nc=d']
    a = 'a=1"b=2"'
    b = split_args(a)
    assert b == ['a=1"b=2"']
    a = "a={{b}} c=\"{{d}}\" e=f"
    b = split_args(a)
    assert b == ['a={{b}}', 'c="{{d}}"', 'e=f']

# Generated at 2022-06-20 20:59:10.533051
# Unit test for function split_args
def test_split_args():
    '''
    Test the splitting of args to make sure our logic is correct
    '''
    from ansible.utils import template

    # Simple variable
    args = "var=simple"
    parsed_args = split_args(args)
    assert parsed_args == ['var=simple']

    # Split on a space within quotes
    args = 'var="this is a test"'
    parsed_args = split_args(args)
    assert parsed_args == ['var="this is a test"']

    # Split on a space within a jinja2 value
    args = 'var={{ test }}'
    parsed_args = split_args(args)
    assert parsed_args == ['var={{ test }}']

    # Split on newlines
    args = 'var=simple\nvar2=simple2'
    parsed_args = split_

# Generated at 2022-06-20 20:59:20.868573
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo"') == 'foo"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('"foo bar') == '"foo bar'
    assert unquote('foo bar"') == 'foo bar"'
    assert unquote('foo bar') == 'foo bar'
    assert unquote('"foo bar" baz') == '"foo bar" baz'
    assert unquote('foo bar "baz"') == 'foo bar "baz"'

# Generated at 2022-06-20 20:59:29.763554
# Unit test for function split_args
def test_split_args():
    data = '''
    - name: '{{ package.name }}'
      version: '{{ package.version }}'

      - name: '{{ package.name }}'
      version: '{{ package.version }}'

      - name: '{{ ' {{ ' }} package.name }}'
      version: '{{ package.version }}'
      - name: x
      - name: x
      - name: x
      - name: x
    '''
    for line in split_args(data):
        print(line)


# Generated at 2022-06-20 20:59:38.035050
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('\'foo\'')
    assert is_quoted('"fo"o"')
    assert is_quoted('"f\'o"o"')
    assert not is_quoted('"fo\'o"')
    assert not is_quoted('"')
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('')


# Generated at 2022-06-20 20:59:40.103707
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"a"')
    assert is_quoted("'a'")
    assert not is_quoted("'a")
    assert not is_quoted('"a')


# Generated at 2022-06-20 20:59:42.944591
# Unit test for function unquote
def test_unquote():
    if unquote('"abc"') != 'abc':
        raise Exception("Failed unquote unit test")



# Generated at 2022-06-20 20:59:53.978538
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"a string"')
    assert is_quoted("'a string'")
    assert is_quoted("''")
    assert is_quoted('""')
    assert is_quoted("'a string''s quotes'")
    assert is_quoted('"a string""s quotes"')

    assert not is_quoted('"a string')
    assert not is_quoted("a string\"")
    assert not is_quoted("'a string")
    assert not is_quoted("a string'")
    assert not is_quoted("a string")
    assert not is_quoted("a string\"")



# Generated at 2022-06-20 21:00:16.640196
# Unit test for function split_args
def test_split_args():
    import pytest
    from collections import namedtuple

    TestCase = namedtuple('TestCase', ['args', 'expected'])

# Generated at 2022-06-20 21:00:19.840203
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted('')



# Generated at 2022-06-20 21:00:31.674947
# Unit test for function unquote
def test_unquote():
    assert unquote("") == ""
    assert unquote("'bar'") == "bar"
    assert unquote("bar") == "bar"
    assert unquote("'bar") == "'bar"
    assert unquote("bar'") == "bar'"
    assert unquote("''bar'") == "'bar"
    assert unquote("'bar''") == "bar'"
    assert unquote("'bar") == "'bar"
    assert unquote("bar'") == "bar'"

# ===========================================
# Main: For testing only
#
# python -m lib.utils.splitter arg1 arg2 arg3
#
# Test Cases:
#
# # Test Case 1
# python -m lib.utils.splitter a=b c="foo bar"
#
# # Test Case 2
# python -m lib.utils.splitter

# Generated at 2022-06-20 21:00:37.278498
# Unit test for function unquote
def test_unquote():
    assert unquote('hello') == 'hello'
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hel'lo'") == "hel'lo"
    assert unquote("''hello''") == "'hello'"
    assert unquote("''hello") == "'hello"



# Generated at 2022-06-20 21:00:45.758862
# Unit test for function unquote
def test_unquote():
    data = '\'abcd\''
    assert unquote(data) == 'abcd'
    data = '"abcd"'
    assert unquote(data) == 'abcd'
    data = 'abcd'
    assert unquote(data) == 'abcd'
    data = '"abcd'
    assert unquote(data) == '"abcd'
    assert is_quoted(data) == False

# Generated at 2022-06-20 21:00:52.024978
# Unit test for function unquote
def test_unquote():
    assert unquote('"mydata"') == 'mydata'
    assert unquote("'mydata'") == 'mydata'
    assert unquote("'mydata") == "'mydata"
    assert unquote('"mydata') == '"mydata'
    assert unquote('mydata') == 'mydata'

# Generated at 2022-06-20 21:00:57.255502
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"') == True
    assert is_quoted("'abcd'") == True
    assert is_quoted('abcd') == False
    assert is_quoted('abc"d') == False
    assert is_quoted('abcd"') == False
    assert is_quoted('"abcd') == False
    assert is_quoted('"abcd"efgh"') == False


# Generated at 2022-06-20 21:01:13.077340
# Unit test for function is_quoted
def test_is_quoted():
    data = '"test"'
    assert is_quoted(data) == True
    data = "'test'"
    assert is_quoted(data) == True
    data = "test "
    assert is_quoted(data) == False
    data = ' '
    assert is_quoted(data) == False
    data = '"'
    assert is_quoted(data) == False
    assert is_quoted('""') == True
    assert is_quoted("''") == True
    assert is_quoted('"\'"') == True
    assert is_quoted("'\"'") == True
    assert is_quoted('"""') == False
    assert is_quoted("'''") == False
    assert is_quoted('"\""') == False
    assert is_quoted("'\''") == False


# Generated at 2022-06-20 21:01:20.627398
# Unit test for function is_quoted

# Generated at 2022-06-20 21:01:29.553130
# Unit test for function unquote
def test_unquote():
    ''' unquote unit test '''
    assert unquote('"this is a string"') == 'this is a string'
    assert unquote('"this is a string')  == '"this is a string'
    assert unquote("'this is a string'") == 'this is a string'
    assert unquote("'this is a string")  == "'this is a string"
    assert unquote('this is a string')   == 'this is a string'
    assert unquote('"this is a string""') == 'this is a string"'
    assert unquote("'this is a string''") == 'this is a string\''



# Generated at 2022-06-20 21:01:59.777293
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert split_args('a=b key="quoted val"') == ['a=b', 'key="quoted val"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="{{ foo }}"') == ['a=b', 'c="{{ foo }}"']
    assert split_args('a=b c="{% if test %}{{ foo }}{% else %}{{ bar }}{% endif %}"') == ['a=b', 'c="{% if test %}{{ foo }}{% else %}{{ bar }}{% endif %}"']

# Generated at 2022-06-20 21:02:04.171509
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'f\"o\"o'") == 'f"o\"o'
    assert unquote("'foo' bar") == "'foo' bar"
    assert unquote("foo bar") == "foo bar"
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("\"foo") == "\"foo"
    assert unquote("foo\"") == "foo\""

# Generated at 2022-06-20 21:02:11.345055
# Unit test for function unquote
def test_unquote():
    ''' unquote: removes first and last quotes from a string, if the string starts and ends with the same quotes '''
    assert unquote('"abcde"') == 'abcde'
    assert unquote("'abcde'") == 'abcde'
    assert unquote('"1234"xyz') == '"1234"xyz'
    assert unquote("'1234'xyz") == "'1234'xyz"
    assert unquote('abcde') == 'abcde'
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote("'") == "'"
    assert unquote('"""') == '"""'
    assert unquote("''''") == "''''"



# Generated at 2022-06-20 21:02:12.692480
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'



# Generated at 2022-06-20 21:02:15.874740
# Unit test for function unquote
def test_unquote():

    assert unquote('"example"') == 'example'
    assert unquote("'ex'ample'") == "ex'ample"
    assert unquote('example') == 'example'


# Generated at 2022-06-20 21:02:21.610616
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"This is a test"') == True
    assert is_quoted("'This is another test'") == True
    assert is_quoted("This isn't a quoted test") == False
    assert is_quoted("'This is") == False
    assert is_quoted('"This is') == False
    assert is_quoted('This is"') == False
    assert is_quoted("This is'") == False


# Generated at 2022-06-20 21:02:29.719752
# Unit test for function split_args
def test_split_args():
    # Test with empty string and simple string (without quotes)
    assert split_args("") == []
    assert split_args("one arg") == ["one", "arg"]

    # Test with quotes and backslash
    assert split_args("a='foo bar' b=\"hello world\" c=`echo \"hello world\"` d=\\ one") == [
        "a='foo bar'", "b=\"hello world\"", "c=`echo \"hello world\"`", "d=\\", "one"]
    assert split_args("a='foo bar' b=\"hello world\" c=`echo \"hello world\"` d=\\\n one") == [
        "a='foo bar'", "b=\"hello world\"", "c=`echo \"hello world\"`", "d=\\", "one"]

    # Test with double quotes
    assert split

# Generated at 2022-06-20 21:02:34.416457
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"

# Generated at 2022-06-20 21:02:45.527849
# Unit test for function split_args
def test_split_args():
    """ Unit test for function split_args """
    args = "a=b c='foo bar' d='A quote is \\"+"'\\"+"', no?'' e='see?'"
    assert split_args(args) == ['a=b', 'c=\'foo bar\'', 'd=\'A quote is \'"\'"\', no?\'\'', "e='see?'"]
    args = "a=b c=\"foo bar\" d=\"A quote is \\\"\", no?\"\" e=\"see?\""
    assert split_args(args) == ['a=b', 'c="foo bar"', 'd="A quote is \\"", no?""', 'e="see?"']

# Generated at 2022-06-20 21:02:51.808548
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"') == True)
    assert(is_quoted("'foo'") == True)
    assert(is_quoted("foo") == False)
    assert(is_quoted("'foo") == False)
    assert(is_quoted('"foo') == False)
    assert(is_quoted("'foo\"") == False)
    assert(is_quoted('"foo\'') == False)
    assert(is_quoted("'\"'") == True)
    assert(is_quoted('\'"\'') == True)
    assert(is_quoted("'") == False)
    assert(is_quoted('"') == False)
    assert(is_quoted("") == False)

# Unit tests for function unquote

# Generated at 2022-06-20 21:03:46.123441
# Unit test for function split_args
def test_split_args():
    result = split_args('a=b c="foo bar"')
    assert result == [u'a=b', u'c="foo bar"']

    result = split_args('a=b c="foo \\"bar\\""')
    assert result == [u'a=b', u'c="foo \\"bar\\""']

    result = split_args('a=b c="foo \"bar\""')
    assert result == [u'a=b', u'c="foo \"bar\""']

    result = split_args('a=b c="foo \\"bar\\""')
    assert result == [u'a=b', u'c="foo \\"bar\\""']

    result = split_args('a=b c="foo \\"bar\\""')

# Generated at 2022-06-20 21:03:56.858277
# Unit test for function split_args

# Generated at 2022-06-20 21:04:07.816962
# Unit test for function split_args

# Generated at 2022-06-20 21:04:13.553303
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")
    assert not is_quoted('"quote"d')
    assert not is_quoted('"quote"')
    assert not is_quoted('quoted"')


# Generated at 2022-06-20 21:04:20.572315
# Unit test for function unquote
def test_unquote():
    assert unquote("\"test\"") == "test"
    assert unquote("'test'") == "test"
    assert unquote("\"test") == "\"test"
    assert unquote("'test") == "'test"
    assert unquote("test\"") == "test\""
    assert unquote("test'") == "test'"
    assert unquote("") == ""

if __name__ == '__main__':
    import sys
    sys.exit(unittest.main())

# Generated at 2022-06-20 21:04:27.989082
# Unit test for function unquote
def test_unquote():
    assert unquote('""foo""') == '"foo"'
    assert unquote("''foo''") == "'foo'"
    assert unquote("'foo'") == 'foo'
    assert unquote("foo") == 'foo'
    assert unquote('') == ''
    assert unquote(' ') == ' '
    assert unquote("'foo") == "'foo"



# Generated at 2022-06-20 21:04:36.895853
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hell""o"') == 'hell""o"'
    assert unquote('""hello""') == 'hello'
    assert unquote('"hello""') == 'hello"'
    assert unquote('""hello"') == '"hello'


# Generated at 2022-06-20 21:04:45.017428
# Unit test for function unquote
def test_unquote():
    assert 'hi' == unquote('hi')
    assert "hi" == unquote('"hi"')
    assert "hi" == unquote("'hi'")
    assert "hi there" == unquote('"hi there"')
    assert "hi there" == unquote("'hi there'")
    assert "hi there" == unquote('hi there')
    assert "hi there" == unquote('"hi\" there"')
    assert "hi ' there" == unquote("'hi ' there'")
    assert 'hi " there' == unquote('"hi \" there"')


# Generated at 2022-06-20 21:04:48.201415
# Unit test for function unquote
def test_unquote():
    assert unquote("'test'") == 'test'
    assert unquote("'test") == "'test"
    assert unquote("test'") == "test'"
    assert unquote("'test") == "'test"

# Utility function for converting a key/value string to a dict.
# E.g. "key1=value1 key2=value2" to {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-20 21:04:50.637648
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == 'abcd'
    assert unquote("'dcba'") == 'dcba'
    assert unquote('abcd') == 'abcd'
    assert unquote('"abcd') == '"abcd'
    assert unquote("'abcd") == "'abcd"
    assert unquote('') == ''



# Generated at 2022-06-20 21:06:44.822431
# Unit test for function split_args
def test_split_args():
    result = split_args("a=b c='foo bar'")
    assert len(result) == 2
    assert result[0] == "a=b"
    assert result[1] == "c='foo bar'"

    result = split_args("a=b c='{{ foo }} bar'")
    assert len(result) == 2
    assert result[0] == "a=b"
    assert result[1] == "c='{{ foo }} bar'"

    result = split_args("a=b c='foo {{ foo }} bar'")
    assert len(result) == 2
    assert result[0] == "a=b"
    assert result[1] == "c='foo {{ foo }} bar'"

    result = split_args("a=b c='{{ foo }} bar {{ foo2 }}'")

# Generated at 2022-06-20 21:06:56.027804
# Unit test for function split_args
def test_split_args():
    args = 'src=/path/to/file dest=/path/to/dest owner=root group=root mode="0644"'
    assert split_args(args) == ['src=/path/to/file', 'dest=/path/to/dest', 'owner=root', 'group=root', 'mode="0644"']

    args = 'src=/path/to/file dest=/path/to/dest owner=root group=root mode="0644" state=directory'
    assert split_args(args) == ['src=/path/to/file', 'dest=/path/to/dest', 'owner=root', 'group=root', 'mode="0644"', 'state=directory']

    args = 'src=/path/to/file dest=/path/to/dest owner=root group=root mode="0644" state=directory'

# Generated at 2022-06-20 21:07:07.817898
# Unit test for function split_args

# Generated at 2022-06-20 21:07:18.583109
# Unit test for function split_args
def test_split_args():

    print("Running main() as a unit test for split_args()")

    def split_and_quote(arg):
        params = split_args(arg)
        return ' '.join(["'%s'" % x for x in params])

    # simple var expansion
    assert split_and_quote("{{ foo }}") == "{{ foo }}"

    # vars with quotes
    assert split_and_quote("{{ foo }} {{ 'bar' }}") == "{{ foo }} 'bar'"

    # string with quote escaping
    assert split_and_quote('a="\""') == 'a="\""'

    # string with escaped backslash
    assert split_and_quote('a=\\"\\') == 'a=\\"\\'

    # string with escaped backslash and quoting

# Generated at 2022-06-20 21:07:25.969017
# Unit test for function unquote
def test_unquote():
    assert unquote('"bar"') == 'bar'
    assert unquote("'foo'") == 'foo'
    assert unquote('"\'"') == '\''
    assert unquote("'\"'") == '"'
    assert unquote('""') == ''
    assert unquote("''") == ''
    assert unquote('"') == '"'
    assert unquote("'") == "'"
    assert unquote('"foo\'"') == 'foo\''
    assert unquote("'foo\"'") == 'foo"'
    assert unquote('bar') == 'bar'


# Generated at 2022-06-20 21:07:33.451555
# Unit test for function split_args
def test_split_args():

    # simple case, no quoting
    test_input = "a=b c=d"
    test_output = ['a=b', 'c=d']
    result = split_args(test_input)
    assert result == test_output

    # quoted param
    test_input = "a=b c='foo bar'"
    test_output = ['a=b', "c='foo bar'"]
    result = split_args(test_input)
    assert result == test_output

    # jinja2 block param
    test_input = "a=b c='foo bar' d='{{ foo }}'"
    test_output = ['a=b', "c='foo bar'", "d='{{ foo }}'"]
    result = split_args(test_input)
    assert result == test_output

    # jinja2 block

# Generated at 2022-06-20 21:07:38.913955
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted("'test")



# Generated at 2022-06-20 21:07:43.703398
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcdef"') == 'abcdef'
    assert unquote("'abcdef'") == 'abcdef'
    assert unquote('abcdef') == 'abcdef'



# Generated at 2022-06-20 21:07:52.698762
# Unit test for function split_args
def test_split_args():
    '''
    split_args function unit test
    '''
    # simple unquoted string
    assert split_args('foo=bar') == ['foo=bar']

    # simple quoted string
    assert split_args('foo="bar"') == ['foo="bar"']

    # simple quoted string containing a space
    assert split_args('foo="bar bar"') == ['foo="bar bar"']

    # multiple quoted strings separated by spaces
    assert split_args('foo="bar bar" bar="foo foo"') == ['foo="bar bar"', 'bar="foo foo"']

    # multiple quoted strings separated by escaped newlines
    assert split_args('foo="bar bar\\\nbar" bar="foo foo\\\nfoo"') == ['foo="bar bar\nbar"', 'bar="foo foo\nfoo"']

    # quoted

# Generated at 2022-06-20 21:08:06.706420
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'abc'")
    assert is_quoted('"abc"')
    assert is_quoted("'a'b'c") is False
    assert is_quoted('"a"b"c') is False
    assert is_quoted("'a''b''c'")
    assert is_quoted('"a""b""c"')
    assert is_quoted("''")
    assert is_quoted('""')
    assert is_quoted("abc") is False
    assert is_quoted("") is False
    assert is_quoted("'") is False
    assert is_quoted('"') is False
