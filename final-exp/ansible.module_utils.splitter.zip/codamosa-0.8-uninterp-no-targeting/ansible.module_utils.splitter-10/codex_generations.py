

# Generated at 2022-06-20 20:58:59.712283
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foo') is False
    assert is_quoted('"foo"') is True
    assert is_quoted('"foo') is False
    assert is_quoted('foo"') is False
    assert is_quoted("'foo'") is True
    assert is_quoted("'foo") is False
    assert is_quoted("foo'") is False
    assert is_quoted('"foo\'') is False
    assert is_quoted('"foo\\""') is True
    assert is_quoted('"""foo"""') is True
    assert is_quoted("'''foo'''") is True


# Generated at 2022-06-20 20:59:05.271900
# Unit test for function is_quoted
def test_is_quoted():
    ''' tests for function is_quoted '''
    assert is_quoted('"test string"')
    assert is_quoted("'test string'")
    assert not is_quoted('test string')
    assert not is_quoted("test string")
    assert is_quoted('"test string')
    assert is_quoted("'test string")
    assert not is_quoted('test string"')
    assert not is_quoted("test string'")
    assert is_quoted('"test "" string"')
    assert is_quoted("'test '' string'")



# Generated at 2022-06-20 20:59:12.457806
# Unit test for function split_args
def test_split_args():
    import sys
    import unittest
    class TestSplitArgs(unittest.TestCase):
        def assert_split(self, args, expected):
            params = split_args(args)
            self.assertEqual(params, expected)

        def test_simple(self):
            self.assert_split('a=1 b=2', ['a=1', 'b=2'])

        def test_quotes(self):
            self.assert_split('a="b c"', ['a="b c"'])
            self.assert_split('a="b c 1"', ['a="b c 1"'])

        def test_simple_nested_j2(self):
            self.assert_split('a="{{ b }}"', ['a="{{ b }}"'])

# Generated at 2022-06-20 20:59:16.555061
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"test\"")
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted("\"test")


# Generated at 2022-06-20 20:59:28.300440
# Unit test for function split_args
def test_split_args():

    assert split_args("foo='bar baz'") == ["foo='bar baz'"]
    assert split_args("foo='bar \n baz'") == ["foo='bar \n baz'"]
    assert split_args("foo='bar \\n baz'") == ["foo='bar \\n baz'"]
    assert split_args("foo='bar\n baz'") == ["foo='bar\n baz'"]
    assert split_args("foo='bar\n\n baz'") == ["foo='bar\n\n baz'"]
    assert split_args("foo='bar\n\n baz' biz='wiz'") == ["foo='bar\n\n baz'", "biz='wiz'"]

# Generated at 2022-06-20 20:59:38.373871
# Unit test for function unquote
def test_unquote():
    assert unquote("''") == ''
    assert unquote("'''a'''") == "'a'"
    assert unquote("'abcd'") == "abcd"
    assert unquote("'\"abcd\"'") == "\"abcd\""
    assert unquote("'abcd'") == "abcd"
    assert unquote("''\"'abcd'\"''") == "\"'abcd'\""
    assert unquote("a") == "a"
    assert unquote("\"a\"") == "a"
    assert unquote("\"a") == "\"a"
    assert unquote("\"a\"\"b\"\"c\"") == "a\"b\"c"
    assert unquote("\"a\"\"b\"\"c\"\"") == "a\"b\"c\""


# Generated at 2022-06-20 20:59:42.980961
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('abc') == 'abc'


# Generated at 2022-06-20 20:59:50.667482
# Unit test for function unquote
def test_unquote():

    # Test for unquoted string
    unquoted = unquote('abcdef')
    assert unquoted == 'abcdef'

    # Test for single quoted string
    single_quoted = unquote("'abcdef'")
    assert single_quoted == 'abcdef'

    # Test for double quoted string
    double_quoted = unquote('"abcdef"')
    assert double_quoted == 'abcdef'

    # Test for double quoted string with embedded single quote
    double_quoted_embedded_single = unquote('"abc\'def"')
    assert double_quoted_embedded_single == 'abc\'def'

    # Test for double quoted string with embedded double quote
    double_quoted_embedded_double = unquote('"abc"def"')

# Generated at 2022-06-20 20:59:58.899061
# Unit test for function split_args
def test_split_args():
    """Test that split_args behaves like expected. Also test unquote
    """
    # test that unquote removes quotes from beginning and end, if these exist
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello') == '"hello'

    # test that split_args splits strings without quotes or jinja2 blocks on whitespace
    assert split_args('a b c') == ['a', 'b', 'c']
    # test that split_args retains whitespace within quotes
    assert split_args('a "b c"') == ['a', '"b c"']
    # test that whitespace is collapsed within quotes

# Generated at 2022-06-20 21:00:14.288505
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("this is a test")) == False
    assert(is_quoted("'this is a test'"))
    assert(is_quoted('"this is a test"'))
    assert(is_quoted("'this is a \"test'")) == False
    assert(is_quoted("'this is a \"test\"'"))
    assert(is_quoted("'this is a 'test'")) == False
    assert(is_quoted("'this is a ''test'''"))
    assert(is_quoted("\"this is a 'test'\""))
    assert(is_quoted("'this is a \"\"test\"\"'"))
    assert(is_quoted("'this is a '\"'test'\"''")) == False


# Generated at 2022-06-20 21:00:30.734458
# Unit test for function split_args
def test_split_args():
    # test various jinja2 case positions
    test_data = '''a=b c="foo bar" "some space" 'some space' "some space\nand newline"'''
    test_data += ''' {{jinja2 "some space" 'some space' "some space\nand newline"'''
    test_data += ''' {{jinja2 "some space" "some space" "some space\nand newline"}}'''
    test_data += ''' {{jinja2 "some space" 'some space' "some space\nand newline"}}'''

    test_data += ''' a=b c="foo bar" "some space" 'some space' "some space\nand newline"'''

# Generated at 2022-06-20 21:00:40.143368
# Unit test for function unquote
def test_unquote():
    if unquote('"text"') == 'text':
        print("Passed test_non_quotes")
    else:
        print("Failed test_non_quotes")

    if unquote('"text') == '"text':
        print("Passed test_non_quotes2")
    else:
        print("Failed test_non_quotes2")

    if unquote('text"') == 'text"':
        print("Passed test_non_quotes3")
    else:
        print("Failed test_non_quotes3")

    if unquote('"') == '"':
        print("Passed test_non_quotes4")
    else:
        print("Failed test_non_quotes4")


# Generated at 2022-06-20 21:00:46.993771
# Unit test for function split_args
def test_split_args():
    class TestCase(object):
        def __init__(self, arg_str):
            self.arg_str = arg_str.replace('\n', '\n ')
            self.args = split_args(arg_str)
            self.rejoined = ' '.join(self.args)

    #
    # test cases
    #

# Generated at 2022-06-20 21:00:51.598141
# Unit test for function unquote
def test_unquote():
    ''' unit test for function unquote '''
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'


# Generated at 2022-06-20 21:00:57.465928
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == 'abcd'
    assert unquote("'abcd'") == 'abcd'
    assert unquote('abcd') == 'abcd'
    assert unquote('123') == '123'
    assert unquote('"') == '"'
    assert unquote("'") == "'"
    assert unquote('"ab"cd"') == '"ab"cd"'
    assert unquote("'ab'cd'") == "'ab'cd'"


# Generated at 2022-06-20 21:01:13.286662
# Unit test for function split_args
def test_split_args():
    assert split_args('"quoted space"') == ['quoted space']
    assert split_args('"quoted space') == ['quoted space']
    assert split_args('"quoted space\\') == ['quoted space\\']
    assert split_args('"quoted space\\"') == ['quoted space"']
    assert split_args('"quoted \\\"quote\\""') == ['quoted \\"quote"']
    assert split_args('"quoted space\\" other"') == ['quoted space" other']
    assert split_args('"a=b c=d" e="f g"') == ['a=b c=d', 'e="f g"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args

# Generated at 2022-06-20 21:01:20.642964
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar baz') == ['a=b', 'c="foo bar baz']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar" d=']
    assert split_args('a=b c="foo bar" d="foo"') == ['a=b', 'c="foo bar"', 'd="foo"']
    assert split_args('a="foo\\"bar"') == ['a="foo\\"bar"']
    assert split_args('a="foo\\"bar"') == ['a="foo\\"bar"']

# Generated at 2022-06-20 21:01:31.133707
# Unit test for function split_args
def test_split_args():
    import os
    import stat
    import tempfile
    import textwrap
    import filecmp
    test_script = '''
#!/usr/bin/python

# The following writes output to stdout (like print) but will not add a newline.
# It can be used for long outputs on multiple lines, without having to concatenate
# strings manually.
sys.stdout.write("This is a long string that goes over multiple lines without having to be concatenated manually.\\n")

# The following writes an error message to stderr and aborts the script using the POSIX exit code for 'abort'
sys.stderr.write("This is an error\\n")
os._exit(os.EX_SOFTWARE)
    '''
    script_file = tempfile.NamedTemporaryFile(mode='w', delete=False)


# Generated at 2022-06-20 21:01:38.928950
# Unit test for function split_args

# Generated at 2022-06-20 21:01:53.528474
# Unit test for function unquote
def test_unquote():
    if unquote('"hello"') != 'hello':
        raise AssertionError('Expected hello, got %s' % unquote('"hello"'))
    if unquote("'hello'") != 'hello':
        raise AssertionError('Expected hello, got %s' % unquote("'hello'"))
    if unquote('hello') != 'hello':
        raise AssertionError('Expected hello, got %s' % unquote('hello'))
    if unquote('"hello') != '"hello':
        raise AssertionError('Expected "hello, got %s' % unquote('"hello'))

if __name__ == '__main__':
    # Unit test
    import sys
    test_unquote()
    print("All tests passed")
    sys.exit(0)

# Generated at 2022-06-20 21:02:21.378091
# Unit test for function unquote
def test_unquote():
    if unquote('"a"') != "a":
        raise Exception("failed unquote_test 1")
    if unquote('"a') != '"a':
        raise Exception("failed unquote_test 2")

    # unquote accepts bytes and unicode strings
    if unquote('"a"'.encode('utf-8')) != "a".encode('utf-8'):
        raise Exception("failed unquote_test 3")
    if unquote(u'"a"') != u"a":
        raise Exception("failed unquote_test 4")
    if unquote(u'"a"'.encode('utf-8')) != u"a":
        raise Exception("failed unquote_test 5")

# Generated at 2022-06-20 21:02:29.657641
# Unit test for function unquote
def test_unquote():
    assert unquote('"test1"')  == 'test1'
    assert unquote('"test2')    == '"test2'
    assert unquote('//test2')   == '//test2'
    assert unquote('"test"")')  == '"test"")'
    assert unquote('""test"')   == '""test"'
    assert unquote('"test""')   == '"test""'
    assert unquote('""')        == ''
    assert unquote('"')         == '"'
    assert unquote('"test1')    == '"test1'
    assert unquote('test1"')    == 'test1"'


if __name__ == '__main__':
     import pytest
     pytest.main([ '-vv', '-s', __file__ ])

# Generated at 2022-06-20 21:02:41.128322
# Unit test for function split_args
def test_split_args():
    # Simple test case with no unusual characters
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]

    # Test cases with unusual characters
    assert split_args("a=b c='foo \n\nbar'") == ['a=b', "c='foo \n\nbar'"]
    assert split_args("a=b c='foo \n\nbar'") == ['a=b', "c='foo \n\nbar'"]
    assert split_args("a=b c='foo bar' \\") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c='foo bar' \\") == ['a=b', "c='foo bar'"]

# Generated at 2022-06-20 21:02:44.938908
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'def'")
    assert not is_quoted('"abc')
    assert not is_quoted("'def")


# Generated at 2022-06-20 21:02:53.473017
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote('"""test"""') == '"test"'
    assert unquote("'''test'''") == "'test'"
    assert unquote('test') == 'test'
    assert unquote('"test') == '"test'
    assert unquote("'test") == "'test"

# Generated at 2022-06-20 21:03:03.033392
# Unit test for function split_args
def test_split_args():
    # regular case, if you wanted to pass a string with a space in it
    _input = 'hello "there you" are'
    _output = [u'hello', u'"there you"', u'are']
    _result = split_args(_input)
    assert _result == _output

    # multiple newlines
    _input = 'hello "there\nyou" are'
    _output = [u'hello', u'"there\nyou"', u'are']
    _result = split_args(_input)
    assert _result == _output

    # line continuation
    _input = 'hello "there\\\nyou" are'
    _output = [u'hello', u'"there\\\nyou"', u'are']
    _result = split_args(_input)
    assert _result == _output

    # newlines

# Generated at 2022-06-20 21:03:07.058753
# Unit test for function unquote
def test_unquote():
    assert unquote('test') == 'test'
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'

# Generated at 2022-06-20 21:03:12.747721
# Unit test for function unquote
def test_unquote():
    ''' unquote should remove enclosing quotes from a quoted string but not from a non-quoted string '''
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'



# Generated at 2022-06-20 21:03:22.565627
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'abc'") == True)
    assert(is_quoted("\"abc\"") == True)
    assert(is_quoted("\"a'bc\"") == False)
    assert(is_quoted("'a\"bc'") == False)
    assert(is_quoted("'a\"bc") == False)
    assert(is_quoted("a\"bc'") == False)
    assert(is_quoted("a\"bc") == False)


# Generated at 2022-06-20 21:03:26.531915
# Unit test for function unquote
def test_unquote():
  assert unquote('foo') == 'foo'
  assert unquote('"foo"') == 'foo'
  assert unquote('"foo') == '"foo'
  assert unquote('foo"') == 'foo"'
  assert unquote('') == ''


# Generated at 2022-06-20 21:03:57.535481
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'test'") == True)
    assert(is_quoted('"test"') == True)
    assert(is_quoted("'test") == False)
    assert(is_quoted("test'") == False)
    assert(is_quoted('"test') == False)
    assert(is_quoted('test"') == False)



# Generated at 2022-06-20 21:04:04.033857
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('""') == ''
    assert unquote('""a') == '"a'
    assert unquote('"a""') == 'a"'
    assert unquote('a"b') == 'a"b'
    assert unquote('"a"b"') == 'ab"'


# Unit tests for function split_args

# Generated at 2022-06-20 21:04:14.399962
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('a=b') == ['a=b']
    assert split_args(' a=b ') == ['a=b']
    assert split_args('a=b ') == ['a=b']
    assert split_args(' a=b') == ['a=b']
    assert split_args(' a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b\nc=d') == ['a=b', 'c=d']
    assert split_args('a=b c=d\n') == ['a=b', 'c=d']
    assert split_args('a=b\n c=d')

# Generated at 2022-06-20 21:04:20.304469
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote('"""test"""') == '"test"'
    assert unquote("'''test'''") == "'test'"
    assert unquote('test') == "test"

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule

    def split_args_test(data):
        return {'arguments': split_args(data), 'changed': True}
    def unquote_test(data):
        return {'unquoted': unquote(data), 'changed': True}



# Generated at 2022-06-20 21:04:25.110369
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo'bar") == "'foo'bar"



# Generated at 2022-06-20 21:04:39.672657
# Unit test for function is_quoted
def test_is_quoted():
    if is_quoted('"foo"'):
        raise Exception("test failed: should not be quoted")
    if is_quoted('"foo'):
        raise Exception("test failed: should not be quoted")
    if is_quoted('foo"'):
        raise Exception("test failed: should not be quoted")
    if not is_quoted('"foobar"'):
        raise Exception("test failed: should be quoted")
    if is_quoted('\'foo\''):
        raise Exception("test failed: should not be quoted")
    if is_quoted('\'foo'):
        raise Exception("test failed: should not be quoted")
    if is_quoted('foo\''):
        raise Exception("test failed: should not be quoted")

# Generated at 2022-06-20 21:04:45.203693
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('""') == True
    assert is_quoted('"foo"') == True
    assert is_quoted('foo') == False
    assert is_quoted('\'foo\'') == True



# Generated at 2022-06-20 21:04:48.764688
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted('"abc\'')
    assert not is_quoted("'abc\"")
    assert not is_quoted("'abc")
    assert not is_quoted('"abc')

# Unit tests for function unquote

# Generated at 2022-06-20 21:04:58.782501
# Unit test for function unquote
def test_unquote():
    assert not is_quoted("Something quoted")
    assert is_quoted("\"Something quoted\"")
    assert is_quoted("'Something quoted'")
    assert not is_quoted("'Something \"quoted\"'")
    assert not is_quoted("'Something 'quoted'\"'")

    assert unquote("'Something quoted'") == 'Something quoted'
    assert unquote("\"Something quoted\"") == 'Something quoted'
    assert unquote("'\"Something quoted\"'") == '"Something quoted"'
    assert unquote("\"'Something quoted'\"") == "'Something quoted'"

# Generated at 2022-06-20 21:05:02.434459
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert is_quoted('"bar bar"')
    assert is_quoted("'bar bar'")
    assert not is_quoted("bar bar")
    assert not is_quoted("")



# Generated at 2022-06-20 21:06:07.824071
# Unit test for function split_args
def test_split_args():
    '''
    Test case for function split_args.

    Use it by running: python lib/ansible/utils/__init__.py
    '''
    import sys

    def test_case(args, nb_params, params):
        real_params = split_args(args)
        if real_params != params:
            print("Error with args: %s" % args)
            sys.exit(1)

    test_case("", 0, [])
    test_case("  ", 0, [])
    test_case("a=b c='d e' f=g", 3, ['a=b', "c='d e'", 'f=g'])
    test_case("a=b c=\"d e\" f=g", 3, ['a=b', 'c="d e"', 'f=g'])

# Generated at 2022-06-20 21:06:14.988543
# Unit test for function is_quoted
def test_is_quoted():
    import pytest

    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")
    assert not is_quoted('"foobar')
    assert not is_quoted("'foobar")
    assert not is_quoted("foobar")
    assert is_quoted('"foobar') is False



# Generated at 2022-06-20 21:06:18.940354
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote("'abc'") == 'abc'



# Generated at 2022-06-20 21:06:24.192766
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")
    assert not is_quoted('no_quotes')
    assert not is_quoted('')
    assert not is_quoted('"double')
    assert not is_quoted("'single")



# Generated at 2022-06-20 21:06:25.348266
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'

# Generated at 2022-06-20 21:06:33.578606
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"foo\"") is True
    assert is_quoted("'foo'") is True
    assert is_quoted("\"foo") is False
    assert is_quoted("foo\"") is False
    assert is_quoted("'foo") is False
    assert is_quoted("foo'") is False
    assert is_quoted("foo") is False
    assert is_quoted("'foo\"") is False
    assert is_quoted("\"\"") is False
    assert is_quoted("''") is False
    assert is_quoted("\"") is False
    assert is_quoted("'") is False
    assert is_quoted("") is False


# Generated at 2022-06-20 21:06:44.002833
# Unit test for function split_args
def test_split_args():
    # variable that will contain all tests to run
    all_tests = []

    # all_tests.append(
    #     [
    #         'a=b c="foo bar"',
    #         ['a=b', 'c="foo bar"']
    #     ]
    # )

    all_tests.append(
        [
            'a=b c="foo bar"',
            ['a=b', 'c="foo bar"']
        ]
    )

    all_tests.append(
        [
            '''a=b c="foo
bar"''',
            ['a=b', 'c="foo\nbar"']
        ]
    )


# Generated at 2022-06-20 21:06:55.877866
# Unit test for function split_args
def test_split_args():
    # Basic argument with key and value
    input_data = k_v = 'key=value'
    expected_result = ['key=value']
    assert split_args(input_data) == expected_result

    # Basic argument with key and value with spaces around them
    input_data = ' \n'.join(['', k_v, ''])
    expected_result = ['key=value']
    assert split_args(input_data) == expected_result

    # Basic argument with key and value with spaces around them and extra space at the start
    input_data = ' \n'.join([' ', k_v, ''])
    expected_result = [' key=value']
    assert split_args(input_data) == expected_result

    # Basic argument with key and value with spaces around them and extra space at the end

# Generated at 2022-06-20 21:07:08.397467
# Unit test for function is_quoted
def test_is_quoted():
    assert len(is_quoted("123")) == 0
    assert len(is_quoted("")) == 0
    assert len(is_quoted("''")) == 2
    assert len(is_quoted("'")) == 0
    assert len(is_quoted("'''")) == 2
    assert len(is_quoted("\"")) == 0
    assert len(is_quoted("\"abc")) == 0
    assert len(is_quoted("abc\"")) == 0
    assert len(is_quoted("\"\"\"")) == 2
    assert len(is_quoted("\"'\"")) == 2
    assert len(is_quoted("\">\"")) == 2
    assert len(is_quoted("''")) == 2
    assert len(is_quoted("\"abc\"")) == 4

# Generated at 2022-06-20 21:07:17.717025
# Unit test for function unquote
def test_unquote():
    cases = [
        # result, data
        (u'foobar', u'"foobar"'),
        (u'foobar', u"'foobar'"),
        (u'foobar', u'foobar'),
        (u'foobar', u'yada foobar yada'),
        (u'foobar', u'y"ad"a foobar yada'),
        (u'"foobar"', u'"foobar"'),
        (u'"foobar"', u'"foobar'),
        (u'"foobar', u'"foobar"'),
    ]
    for res, data in cases:
        assert res == unquote(data)