

# Generated at 2022-06-20 20:58:54.584531
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted('"a b c"')
    assert is_quoted("'a b c'")
    assert not is_quoted('"a b c')
    assert not is_quoted("'a b c")
    assert not is_quoted('a b c"')
    assert not is_quoted('a b c\'')
    assert not is_quoted('ab c')
    assert not is_quoted('"')
    assert not is_quoted("'")
    assert not is_quoted('')


# Generated at 2022-06-20 20:59:03.333061
# Unit test for function split_args
def test_split_args():
    def _test_split_args(text, expected):
        results = split_args(text)
        assert ' '.join(results) == expected, "'%s' != '%s'" % (' '.join(results), expected)
        assert ' '.join(results) == text, "'%s' != '%s'" % (' '.join(results), text)

    _test_split_args('/bin/foo', '/bin/foo')
    _test_split_args('/bin/foo bar=baz', '/bin/foo bar=baz')
    _test_split_args('a=b c="foo bar"', 'a=b c="foo bar"')
    _test_split_args('sudo -s bar=baz', 'sudo -s bar=baz')
    _test_split_args('{{', '{{')
   

# Generated at 2022-06-20 20:59:09.928506
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")
    assert not is_quoted('no quotes')
    assert is_quoted('"quoted with spaces"')
    assert is_quoted("'quoted with spaces'")
    assert not is_quoted("'quotes don't match")
    assert not is_quoted('no quotes')
    assert not is_quoted('"no quotes')
    assert not is_quoted("'no quotes")


# Generated at 2022-06-20 20:59:14.283636
# Unit test for function unquote
def test_unquote():
    ''' unit test for unquote '''

# Generated at 2022-06-20 20:59:20.792284
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted("''")
    assert not is_quoted('"\'"')
    assert not is_quoted("'\"'")
    assert is_quoted('"\'"') == False
    assert is_quoted("'\"'") == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False

# Unit tests for function unquote

# Generated at 2022-06-20 20:59:29.649295
# Unit test for function is_quoted
def test_is_quoted():

    # test valid quotes
    assert True == is_quoted('"quoted"')
    assert True == is_quoted("'quoted'")
    assert True == is_quoted('"quote \' in the middle"')

    # test invalid quotes
    assert False == is_quoted('\'invalid')
    assert False == is_quoted('invalid"')

    # test not quoted strings
    assert False == is_quoted('')
    assert False == is_quoted('not quoted')


# Generated at 2022-06-20 20:59:33.754994
# Unit test for function unquote
def test_unquote():
    test_data = {"a": '"foo"', "b": 'bar', "c": '"foo""bar"', "d": "'zoo'" }
    for k, v in test_data.items():
        assert unquote(v) == k

# Generated at 2022-06-20 20:59:38.186066
# Unit test for function unquote
def test_unquote():
    assert unquote('"asdf"') == "asdf"
    assert unquote("'asdf'") == "asdf"
    assert unquote('"a"b"') == '"a"b"'
    assert unquote("'a'b'") == "'a'b'"
    assert unquote('a"b"') == 'a"b"'
    assert unquote("a'b'") == "a'b'"


# Generated at 2022-06-20 20:59:40.490533
# Unit test for function unquote
def test_unquote():
    """Make sure we remove quotes when we can, but not when we can't """
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc"def') == '"abc"def'

# Generated at 2022-06-20 20:59:50.607213
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"this is quoted"') == True)
    assert(is_quoted('\'this is quoted\'') == True)
    assert(is_quoted('this is not quoted') == False)
    assert(is_quoted('"this is "quoted"') == False)
    assert(is_quoted('"this is quoted') == False)

if __name__ == '__main__':
    test_is_quoted()
    print("Successfully completed 2 tests.")

# Generated at 2022-06-20 21:00:08.272926
# Unit test for function split_args
def test_split_args():
    params = split_args('vim /tmp/hello world')
    assert params == ['vim', '/tmp/hello world']
    params = split_args('vim /tmp/hello world "a b"')
    assert params == ['vim', '/tmp/hello world', '"a b"']
    params = split_args('vim /tmp/hello world "a b" "a \'b"')
    assert params == ['vim', '/tmp/hello world', '"a b"', '"a \'b"']



# Generated at 2022-06-20 21:00:15.394941
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("not quoted")
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")
    assert not is_quoted("'not quoted")
    assert not is_quoted('"not quoted')
    assert not is_quoted('not quoted"')
    assert not is_quoted("not quoted'")
    assert not is_quoted('\'not quoted')
    assert not is_quoted('"not quoted')



# Generated at 2022-06-20 21:00:30.773883
# Unit test for function split_args

# Generated at 2022-06-20 21:00:40.169758
# Unit test for function split_args

# Generated at 2022-06-20 21:00:44.763451
# Unit test for function split_args
def test_split_args():
    # Following are the expected outputs
    expected = [['abc', 'def', 'ghi'], ['abc', 'def', 'ghi', 'jkl']]
    # Following are the inputs to the code
    inputs = ['abc def ghi', 'abc def "ghi jkl"']
    i = 0
    for val in inputs:
        assert split_args(val) == expected[i]
        i = i+1
    print('Test succeeded')

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-20 21:00:51.503159
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"



# Generated at 2022-06-20 21:01:01.159567
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule
    #pylint: disable=unused-variable

# Generated at 2022-06-20 21:01:08.980009
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("\"foo\"")==True)
    assert(is_quoted("'foo'")==True)
    assert(is_quoted("foo")==False)
    assert(is_quoted("'foo")==False)
    assert(is_quoted("foo'")==False)
    assert(is_quoted("'foo\"")==False)



# Generated at 2022-06-20 21:01:19.457399
# Unit test for function split_args
def test_split_args():
    # 1. only spaces
    args = ' \t \t \n \t '
    result = split_args(args)
    assert result == []

    # 2. spaces between two params
    args = 'param1 param2'
    result = split_args(args)
    assert result == ['param1', 'param2']

    # 3. spaces between two params with quotes
    args = 'param1 "param2"'
    result = split_args(args)
    assert result == ['param1', '"param2"']

    # 4. spaces between two params with quotes and backslash
    args = 'param1 "param2\\"xyz \\\\ \\\\\\"'
    result = split_args(args)
    assert result == ['param1', '"param2\\"xyz \\\\ \\\\\\"']

    # 5

# Generated at 2022-06-20 21:01:24.903690
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted('"abc\'')
    assert not is_quoted("'abc\"")
    assert not is_quoted('abc')


# Generated at 2022-06-20 21:01:40.993921
# Unit test for function split_args

# Generated at 2022-06-20 21:01:47.176054
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted('hello') == False
    assert is_quoted('"hello') == False
    assert is_quoted("'hello") == False
    assert is_quoted("''") == True
    assert is_quoted('""') == True
    assert is_quoted('') == False


# Generated at 2022-06-20 21:01:56.665703
# Unit test for function split_args
def test_split_args():
    # check splitting on whitespace
    params = split_args('a=b c="foo bar"')
    assert params == ['a=b', 'c="foo bar"']

    # check inside quotes args
    params = split_args('a="foo bar"')
    assert params == ['a="foo bar"']

    # check mixed args
    params = split_args('a=b c="foo bar" d=\'{"a": "foo bar"}\'')
    assert params == ['a=b', 'c="foo bar"', 'd=\'{"a": "foo bar"}\'']

    # Test some jinja2 block expressions
    # check inside quotes args
    params = split_args("{{ 'foo' }}")
    assert params == ['{{ \'foo\' }}']

    params = split_args("{{ foo }}")

# Generated at 2022-06-20 21:02:07.057938
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("foo") == ['foo']
    assert split_args("foo=bar") == ['foo=bar']
    assert split_args("foo='bar'") == ["foo='bar'"]
    assert split_args("foo='bar bar'") == ["foo='bar bar'"]
    assert split_args("foo=\"bar bar\"") == ['foo="bar bar"']

# Generated at 2022-06-20 21:02:18.868768
# Unit test for function split_args
def test_split_args():
    ''' Unit tests for function split_args '''


# Generated at 2022-06-20 21:02:24.785468
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == 'abcd'
    assert unquote("'abcd'") == 'abcd'
    assert unquote("ab'cd") == "ab'cd"
    assert unquote('ab"cd') == 'ab"cd'


# Generated at 2022-06-20 21:02:33.568593
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("")
    assert not is_quoted(" ")
    assert is_quoted("'test'")
    assert is_quoted("\"test\"")
    assert is_quoted("\"test") == False
    assert is_quoted("test'") == False
    assert is_quoted("\"tes\"t\"") == False
    assert is_quoted("'\"tes\"t\"'") == True


# Generated at 2022-06-20 21:02:46.354572
# Unit test for function split_args
def test_split_args():

    def assert_split_args(args, expected):
        _actual = split_args(args)
        if _actual != expected:
            print("\nExpected:\n", expected)
            print("Actual:\n", _actual)
        assert _actual == expected

    assert_split_args('foo', ['foo'])
    assert_split_args('foo bar', ['foo', 'bar'])
    assert_split_args('foo \'bar baz\'', ['foo', 'bar baz'])
    assert_split_args('  foo   bar   ', ['foo', 'bar'])
    assert_split_args('  foo   bar   baz   ', ['foo', 'bar', 'baz'])
    assert_split_args('"  foo   bar   baz  "', ['  foo   bar   baz  '])


# Generated at 2022-06-20 21:02:53.107351
# Unit test for function unquote
def test_unquote():
    assert unquote('"foobar"') == "foobar"
    assert unquote("'foobar'") == "foobar"
    assert unquote('') == ''
    assert unquote('"\\"') == "\\"
    assert unquote("'foobar") == "foobar"


# Generated at 2022-06-20 21:03:02.923063
# Unit test for function split_args
def test_split_args():
    # This is the condition that is most often seen with modules,
    # a value that is quoted but contains no special characters
    args = 'name=test state=present group="mygroup"'
    tokens = split_args(args)
    assert len(tokens) == 3
    assert tokens[0] == 'name=test'
    assert tokens[1] == 'state=present'
    assert tokens[2] == 'group="mygroup"'

    # This test is similar to the last, but the value has an
    # escaped double quote in it
    args = 'name=test state=present group="my\\"group"'
    tokens = split_args(args)
    assert len(tokens) == 3
    assert tokens[0] == 'name=test'
    assert tokens[1] == 'state=present'

# Generated at 2022-06-20 21:03:26.354717
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('" "') == ' '
    assert unquote('"a"') == 'a'
    assert unquote('\'a\'') == 'a'
    assert unquote('"a"b') == '"a"b'
    assert unquote('""b') == '"b'

# Generated at 2022-06-20 21:03:36.448077
# Unit test for function split_args

# Generated at 2022-06-20 21:03:47.835516
# Unit test for function split_args

# Generated at 2022-06-20 21:03:55.715872
# Unit test for function is_quoted
def test_is_quoted():
    # success cases
    assert(is_quoted('"hello"'))
    assert(is_quoted('"hello world"'))
    assert(is_quoted('"hello world "he said"'))
    assert(is_quoted("'hello world 'he said'"))

    # failure cases
    assert(not is_quoted('"hello'))
    assert(not is_quoted("'hello"))
    assert(not is_quoted("hello"))
    assert(not is_quoted('hello world'))
    assert(not is_quoted('"hello world "he said'))



# Generated at 2022-06-20 21:04:00.774088
# Unit test for function is_quoted
def test_is_quoted():
    data1 = '"Hello"'
    data2 = "'World'"
    data3 = 'Hello'

    assert(is_quoted(data1) == True)
    assert(is_quoted(data2) == True)
    assert(is_quoted(data3) == False)


# Generated at 2022-06-20 21:04:09.488492
# Unit test for function split_args
def test_split_args():
    params = split_args("echo 'this is a \"quoted arg\"'")
    result = ['echo', 'this is a "quoted arg"']
    assert params == result

    params = split_args("echo 'this is a \"quoted {{arg}}\"'")
    result = ['echo', 'this is a "quoted {{arg}}"']
    assert params == result

    params = split_args('echo "this {#is a#} {{quoted {{arg}}}}"')
    result = ['echo', 'this {#is a#} {{quoted {{arg}}}}']
    assert params == result

    params = split_args('echo "this is \"a quoted {{arg}}\""')
    result = ['echo', 'this is "a quoted {{arg}}"']
    assert params == result


# Generated at 2022-06-20 21:04:14.252752
# Unit test for function split_args

# Generated at 2022-06-20 21:04:18.275140
# Unit test for function unquote
def test_unquote():
    ''' unquote should remove first and last quotes from a string
    if the string starts and ends with the same quotes '''
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('""') == ''
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'

# Generated at 2022-06-20 21:04:25.094519
# Unit test for function unquote
def test_unquote():
    # Should return string without quotes
    assert unquote('"abc"') == "abc"
    # Should return string without quotes
    assert unquote("'abc'") == "abc"
    # Should return string without quotes
    assert unquote("'abc") == "'abc"
    # Should return string without quotes
    assert unquote('"abc') == '"abc'
    # Should return string with quotes
    assert unquote('abc') == "abc"
    # Should return empty string
    assert unquote('') == ''
    # Should return string
    assert unquote('abcdef') == "abcdef"


# Generated at 2022-06-20 21:04:32.245253
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"quoted_string\"")
    assert is_quoted("'quoted_string'")
    assert not is_quoted("\"double-quoted string")
    assert not is_quoted("'single-quoted string")
    assert not is_quoted("unquoted")


# Generated at 2022-06-20 21:05:37.810989
# Unit test for function split_args
def test_split_args():
    # Split on quoted strings and jinja2 blocks
    test_string = "{{ foo }} \"bar baz\" quux"
    assert split_args(test_string) == ["{{ foo }}", "\"bar baz\"", "quux"]

    # Split on quoted strings and jinja2 blocks, with multiple spaces
    test_string = " {{ foo }}  \"bar baz\"  quux"
    assert split_args(test_string) == ["{{ foo }}", "\"bar baz\"", "quux"]

    # Split on quoted strings and jinja2 blocks, with multiple newlines
    test_string = "\n {{ foo }} \n\"bar baz\" \nquux\n"

# Generated at 2022-06-20 21:05:42.083707
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'bar'")
    assert is_quoted("\"bar\"")
    assert not is_quoted("'bar\"")
    assert not is_quoted("bar")



# Generated at 2022-06-20 21:05:45.230724
# Unit test for function unquote
def test_unquote():
    test_string = "Hello world"
    assert unquote(test_string) == "Hello world"
    test_string = "\"Hello world\""
    assert unquote(test_string) == "Hello world"
    test_string = "\'Hello world\'"
    assert unquote(test_string) == "Hello world"
    test_string = "\"Hello world"
    assert unquote(test_string) == "\"Hello world"

# Generated at 2022-06-20 21:06:00.861618
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=') == ['a=b', 'c="foo bar"', 'd=']
    assert split_args('a=b c="foo bar" d=""') == ['a=b', 'c="foo bar"', 'd=""']
    assert split_args('a=b c="foo bar" d="" e') == ['a=b', 'c="foo bar"', 'd="" e']
    assert split_args('a=b c="foo bar" d="" e f') == ['a=b', 'c="foo bar"', 'd=""', 'e', 'f']
    assert split_args('a=b c="foo bar" d="" e f g')

# Generated at 2022-06-20 21:06:07.812286
# Unit test for function split_args
def test_split_args():
    """Test whether splitting arguments works as expected"""

# Generated at 2022-06-20 21:06:14.930952
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"helloworld"'))
    assert(is_quoted("'helloworld'"))
    assert(not is_quoted("helloworld"))
    assert(not is_quoted('"helloworld'))
    assert(not is_quoted("'helloworld"))


# Generated at 2022-06-20 21:06:20.099817
# Unit test for function unquote
def test_unquote():
    assert unquote("\"foo\"") == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote("'foo\\''") == "foo'"
    assert unquote("\"foo\\\"\"") == "foo\""

# Generated at 2022-06-20 21:06:24.400594
# Unit test for function unquote
def test_unquote():
    data = '"test"'
    assert unquote(data) == 'test'
    data = "'test'"
    assert unquote(data) == 'test'
    data = '"'
    assert unquote(data) == '"'
    data = "'"
    assert unquote(data) == "'"


# Generated at 2022-06-20 21:06:27.666189
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("foobar")
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")
    assert is_quoted('"""foobar"""')
    assert is_quoted("'''foobar'''")
    assert not is_quoted('"foobar')
    assert not is_quoted("'foobar")


# Generated at 2022-06-20 21:06:43.478121
# Unit test for function is_quoted
def test_is_quoted():
    result = is_quoted('"one"')
    assert result == True, result

    result = is_quoted('"one')
    assert result == False, result

    result = is_quoted('one"')
    assert result == False, result

    result = is_quoted('"one" "two"')
    assert result == True, result

    result = is_quoted('one')
    assert result == False, result

    result = is_quoted('"one"""two"""three"')
    assert result == True, result

    result = is_quoted('"fo\'o"')
    assert result == False, result

    result = is_quoted('"fo\\"o"')
    assert result == True, result

    result = is_quoted('"""foo"""')
    assert result == True, result