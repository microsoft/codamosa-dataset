

# Generated at 2022-06-20 20:58:49.526998
# Unit test for function split_args

# Generated at 2022-06-20 20:58:53.403152
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'

# Generated at 2022-06-20 20:59:02.638271
# Unit test for function split_args

# Generated at 2022-06-20 20:59:08.383063
# Unit test for function split_args

# Generated at 2022-06-20 20:59:19.785029
# Unit test for function split_args

# Generated at 2022-06-20 20:59:25.472394
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hell"o"')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')



# Generated at 2022-06-20 20:59:30.901054
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Hello"')
    assert is_quoted("'Hello'")
    assert is_quoted("\"Hello\"")
    assert is_quoted("'Hello") == False
    assert is_quoted("Hello'") == False
    assert is_quoted("Hel'lo") == False
    assert is_quoted("'Hello\"") == False
    assert is_quoted("Hello") == False


# Generated at 2022-06-20 20:59:35.512562
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("'hello") is False
    assert is_quoted("'hel\"lo'") == is_quoted("'hel\"lo'")
    assert is_quoted("\"hel'lo\"") == is_quoted("\"hel'lo\"")


# Generated at 2022-06-20 20:59:40.193852
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"


# Generated at 2022-06-20 20:59:48.308190
# Unit test for function unquote
def test_unquote():
    assert is_quoted('"hello"')
    assert is_quoted('"hello')
    assert is_quoted("'hello'")
    assert is_quoted("'hello")
    assert not is_quoted('hello')
    assert not is_quoted('')

    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"
    assert unquote('hello') == 'hello'


if __name__ == '__main__':
    test_unquote()



# Generated at 2022-06-20 21:00:14.195581
# Unit test for function split_args
def test_split_args():
    def assert_split_args(args, expected):
        result = split_args(args)
        assert result == expected, "%s != %s" % (result, expected)

    # test whitespace cases
    assert_split_args("a=1", ['a=1'])
    assert_split_args("\na=1", ['a=1'])
    assert_split_args("a=1\n", ['a=1'])
    assert_split_args(" a = 1 ", ['a', '=', '1'])
    assert_split_args(" a = 1\n", ['a', '=', '1'])
    assert_split_args("a=\n1", ['a=', '1'])

# Generated at 2022-06-20 21:00:18.547453
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert not is_quoted(' "foo" ')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('')
    assert is_quoted('""')
    assert is_quoted("''")
    assert is_quoted('"foo"bar"') == False


# Generated at 2022-06-20 21:00:28.750123
# Unit test for function unquote
def test_unquote():
    assert "abcd" == unquote('"abcd"')
    assert '"abcd"' == unquote('"""abcd"""')
    assert 'ab"cd' == unquote('"ab"cd"')
    assert 'abcd' == unquote('abcd')
    assert 'abcd' == unquote('"abcd')
    assert 'abcd' == unquote('abcd"')
    assert 'abcd' == unquote('"abcd"more')
    assert 'abcd' == unquote('more"abcd"')
    assert 'abcd' == unquote('"ab"c"d"')
    

# Generated at 2022-06-20 21:00:39.514732
# Unit test for function split_args
def test_split_args():

    def assert_split_args(args, expected_params):
        params = split_args(args)
        print("\nparams=%s\nexpected_params=%s\n" % (params, expected_params))
        assert params == expected_params, "split_args failed"
        assert isinstance(params, list)

    # Basic test case
    assert_split_args('foo=bar', ['foo=bar'])

    # Test case with quotes
    assert_split_args('foo="bar baz"', ['foo="bar baz"'])

    # Test case with a comment
    assert_split_args('foo=5 #comment', ['foo=5', '#comment'])

    # Test case with multiple lines

# Generated at 2022-06-20 21:00:47.600311
# Unit test for function is_quoted
def test_is_quoted():
    # data is quoted
    assert is_quoted('"data"')
    assert is_quoted("'data'")

    # data is not quoted
    assert not is_quoted("data")
    assert not is_quoted("'data")
    assert not is_quoted("data'")
    assert not is_quoted("'data\"")
    assert not is_quoted("\"data'")
    assert not is_quoted("'data\"")
    assert not is_quoted("\"data\"\"")



# Generated at 2022-06-20 21:00:57.624743
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('a') == 'a'
    assert unquote('"a"') == 'a'
    assert unquote("'a'") == 'a'
    assert unquote('"a""b"') == 'a""b'
    assert unquote("'a''b'") == "a'b"
    assert unquote("'a'b'c'") == "a'b'c"
    assert unquote('abc') == 'abc'
    assert unquote('"""a"""') == '"a"'
    assert unquote("'''a'''") == "'a'"
    assert unquote("'a'''") == "a'''"
    assert unquote("'''a'") == "''a"


# Generated at 2022-06-20 21:01:07.894586
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('""') == True)
    assert(is_quoted("''") == True)
    assert(is_quoted('"foo"') == True)
    assert(is_quoted("'foo'") == True)
    assert(is_quoted('""foo"') == False)
    assert(is_quoted("'foo''") == False)
    assert(is_quoted('foo') == False)
    assert(is_quoted('') == False)


# Generated at 2022-06-20 21:01:13.867019
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote("\"foo\"") == "foo"
    assert unquote("'\"foo\"'") == "\"foo\""
    assert unquote("\"'foo'\"") == "'foo'"
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("\"foo") == "\"foo"
    assert unquote("foo\"") == "foo\""
    assert unquote("foo'bar") == "foo'bar"
    assert unquote("foo\"bar") == "foo\"bar"


# Generated at 2022-06-20 21:01:17.271133
# Unit test for function unquote
def test_unquote():
    assert unquote('"ab cd"') == 'ab cd'
    assert unquote('"ab cd" ef') == '"ab cd" ef'
    assert unquote('ab cd') == 'ab cd'

# Generated at 2022-06-20 21:01:24.968879
# Unit test for function unquote
def test_unquote():
    assert unquote('"this is a test"') == "this is a test"
    assert unquote('this is a test') == "this is a test"
    assert unquote("'this is a test'") == "this is a test"
    assert unquote("'this is a test") == "'this is a test"
    assert unquote('"this is a test') == '"this is a test'

# Generated at 2022-06-20 21:01:56.192592
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc', unquote('"abc"')
    assert unquote("'abc'") == 'abc', unquote("'abc'")
    assert unquote("''") == '', unquote("''")
    assert unquote("'") == '', unquote("'")
    assert unquote("") == '', unquote("")



# Generated at 2022-06-20 21:02:02.741617
# Unit test for function unquote
def test_unquote():
    assert unquote('test') == 'test'
    assert unquote('"test"') == 'test'
    assert unquote('"test') != 'test'
    assert unquote('test"') != 'test'
    assert unquote('"tes"t"') == 'tes"t'
    assert unquote("'test'") == 'test'
    assert unquote("'test") != 'test'
    assert unquote("test'") != 'test'

# Generated at 2022-06-20 21:02:09.786653
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'abc'") == True
    assert is_quoted('"abc"') == True
    assert is_quoted("'a'b'c'") == False
    assert is_quoted('"a"b"c"') == False
    assert is_quoted('a"b"c') == False
    assert is_quoted('a"b"c') == False
    assert is_quoted('"a') == False
    assert is_quoted('a"') == False
    assert is_quoted('abc') == False


# Generated at 2022-06-20 21:02:15.759238
# Unit test for function unquote
def test_unquote():
    if unquote('"abc"') != 'abc':
        raise Exception('unquote test 1 failed')
    if unquote("'abc'") != 'abc':
        raise Exception('unquote test 2 failed')
    if unquote('abc') != 'abc':
        raise Exception('unquote test 3 failed')



# Generated at 2022-06-20 21:02:20.620620
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('a') == 'a'
    assert unquote('"a"') == 'a'
    assert unquote("'a'") == 'a'


# Generated at 2022-06-20 21:02:27.761354
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"test\"")
    assert is_quoted("'test'")
    assert not is_quoted("test")
    assert not is_quoted("\"test")
    assert not is_quoted("\"test\"test")
    assert not is_quoted("test'stuff")


# Generated at 2022-06-20 21:02:42.500062
# Unit test for function split_args

# Generated at 2022-06-20 21:02:48.999525
# Unit test for function is_quoted
def test_is_quoted():

    class TestCase(object):
        def __init__(self, input, expected):
            self.input = input
            self.expected = expected

    tests = []

    # Empty string
    tests.append(TestCase("", False))

    # Single char string
    tests.append(TestCase("a", False))

    # Two char string
    tests.append(TestCase("ab", False))

    # Three char string
    tests.append(TestCase("abc", False))

    # Four char string
    tests.append(TestCase("abcd", False))

    # Single quoted string
    tests.append(TestCase("'", True))
    tests.append(TestCase("'a", True))
    tests.append(TestCase("'ab", True))
    tests.append(TestCase("'abc", True))
    tests.append

# Generated at 2022-06-20 21:03:01.556462
# Unit test for function split_args
def test_split_args():

    def normalize_args(args):
        ''' normalize a string of args '''
        args = args.replace('\n', ' ')
        args = split_args(args)
        args = '\n'.join(args)
        return args

    # Assert that split_args works with a normal list of args
    assert normalize_args('foo=bar baz qux=1') == 'foo=bar\nbaz\nqux=1'

    # Assert that split_args doesn't break args with spaces in them
    assert normalize_args('foo=bar baz="zomg, a=b"') == 'foo=bar\nbaz="zomg, a=b"'

    # Assert that split_args works with '='

# Generated at 2022-06-20 21:03:07.882935
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('"a"') == 'a'
    assert unquote('"a\\\""') == 'a"'
    assert unquote('"\'"') == '\''


# Generated at 2022-06-20 21:03:39.412594
# Unit test for function split_args
def test_split_args():
    # Quoting
    assert split_args(r'''"'"''') == ['''"\'"''']
    assert split_args(r'"a b"') == ['a b']
    assert split_args(r"a='b c'") == ['a=b c']
    assert split_args(r'a="b c" d') == ['a=b c', 'd']
    assert split_args(r"a=\"b c\" d") == ['a="b c"', 'd']
    assert split_args(r"a=\"'b c'\" d") == [r'a="\'b c\'"', 'd']
    assert split_args(r'''a="'"b c"'" d''') == [r'''a="'"b c"'"''', 'd']

# Generated at 2022-06-20 21:03:50.143145
# Unit test for function split_args
def test_split_args():

    def _test_split(args, expected):
        result = split_args(args)
        assert result == expected, "failed to parse %s, expected %s, got %s" % (args, expected, result)


# Generated at 2022-06-20 21:04:02.210553
# Unit test for function split_args

# Generated at 2022-06-20 21:04:17.023149
# Unit test for function split_args
def test_split_args():
    ''' Split args tests '''
    def check(input, output):
        result = split_args(input)
        if result != output:
            print("FAILED")
            print("INPUT: '%s'" % input)
            print("OUTPUT: '%s'" % output)
            print("RESULT: '%s'" % result)
            raise Exception("split_args returned unexpected value for '%s'" % input)

    check("ls somesuch", ['ls', 'somesuch'])
    check("ls somesuch 'with space'", ['ls', 'somesuch', "'with space'"])
    check("/usr/bin/foo --bar=\"baz quux\"", ['/usr/bin/foo', '--bar="baz quux"'])

# Generated at 2022-06-20 21:04:22.247414
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'Hello world!'")
    assert is_quoted('"Hello world!"')
    assert not is_quoted("'Hello world!")
    assert not is_quoted("Hello world!")
    assert not is_quoted("Hello world!'")
    assert not is_quoted("Hello world'!")



# Generated at 2022-06-20 21:04:37.934706
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar\\" d="blah') == ['a=b', 'c="foo bar" d="blah']
    assert split_args('a=b c="foo') == ['a=b', 'c="foo']
    assert split_args('a=1,2,3') == ['a=1,2,3']
    assert split_args('a=1, 2, 3') == ['a=1,', '2,', '3']
    assert split_args('a=1\\, 2, 3') == ['a=1, 2,', '3']

# Generated at 2022-06-20 21:04:47.863684
# Unit test for function split_args
def test_split_args():
    # A few simple cases
    assert split_args('a=b c="foo bar"') == ['a=b', 'c=foo bar']
    assert split_args('a=b c="foo bar" d="foo\\ bar"') == ['a=b', 'c=foo bar', 'd=foo bar']
    assert split_args('a=b c="foo bar" d="foo\\\\ bar"') == ['a=b', 'c=foo bar', 'd=foo\\ bar']

    # Spaces and newlines
    assert split_args('a=b c="foo bar"\nd=bar') == ['a=b', 'c=foo bar\nd=bar']

    # Quotes and newlines

# Generated at 2022-06-20 21:04:57.097754
# Unit test for function unquote
def test_unquote():
    # Test simple unquoting
    assert "string" == unquote("\"string\"")
    # Test unicode unquoting
    assert u"string" == unquote(u"\"string\"")
    assert u"string" == unquote(u"\"string\"")
    # Test unquoting with prefix and postfix
    assert "string" == unquote("prefix\"string\"postfix")
    assert u"string" == unquote(u"prefix\"string\"postfix")


# Generated at 2022-06-20 21:05:04.527291
# Unit test for function is_quoted
def test_is_quoted():
    # Assert that is_quoted returns as True if input data is with double quotes
    assert is_quoted('"foo bar"') == True
    assert is_quoted('"foo bar') == False
    assert is_quoted('foo bar"') == False
    # Assert that is_quoted returns as True if input data is with single quotes
    assert is_quoted("'foo bar'") == True
    assert is_quoted("'foo bar") == False
    assert is_quoted("foo bar'") == False
    # Assert that is_quoted returns as True if input data is with double quotes
    assert is_quoted("'foo bar'") == True
    # Assert that is_quoted returns as False for random data
    assert is_quoted(None) == False

# Generated at 2022-06-20 21:05:20.205519
# Unit test for function is_quoted

# Generated at 2022-06-20 21:06:00.472129
# Unit test for function unquote

# Generated at 2022-06-20 21:06:05.438407
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"fo"o"')
    assert not is_quoted("'fo'o'")



# Generated at 2022-06-20 21:06:21.168986
# Unit test for function split_args

# Generated at 2022-06-20 21:06:28.292929
# Unit test for function split_args
def test_split_args():
    print("test_split_args")

# Generated at 2022-06-20 21:06:31.973629
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo\'')
    assert not is_quoted("'foo\"")
    assert not is_quoted('foo')



# Generated at 2022-06-20 21:06:45.924734
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b 'c=foo bar'") == ['a=b', "c=foo bar"]
    assert split_args("a=b \"c=foo bar\"") == ['a=b', "c=foo bar"]
    assert split_args("a=b c=foo\\ bar") == ['a=b', "c=foo bar"]
    assert split_args("a=b c=foo\\\nbar") == ['a=b', "c=foo\nbar"]
    assert split_args("a=b\nc=\"foo bar\"") == ['a=b', 'c="foo bar"']

# Generated at 2022-06-20 21:06:53.573918
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert not is_quoted('')
    assert not is_quoted('"')
    assert not is_quoted('"" ')
    assert not is_quoted(' "')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo")
    assert not is_quoted('"foo')

# Unit tests for function split_args

# Generated at 2022-06-20 21:07:04.637745
# Unit test for function split_args
def test_split_args():

    # these are the args we will be testing
    test_args = dict()

    # simple spaces and quotes test
    test_args["a=1 b='c d' e=\"f g\" h=i"] = ['a=1', 'b=\'c d\'', 'e="f g"', 'h=i']

    # test \ escaping of quotes
    test_args['a=1 b=\'c d\' e="f g" h=i'] = ['a=1', 'b=\'c d\'', 'e="f g"', 'h=i']
    test_args['a=1 b="c \'d\'" e="f g" h=i'] = ['a=1', 'b="c \'d\'"', 'e="f g"', 'h=i']

# Generated at 2022-06-20 21:07:07.123007
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == 'abcd'
    assert unquote('\'abcd\'') == 'abcd'
    assert unquote('abcd') == 'abcd'

# Generated at 2022-06-20 21:07:14.121674
# Unit test for function unquote
def test_unquote():
    test_values = [
        ('foo', 'foo'),
        ('"foo"', 'foo'),
        ("'foo'", 'foo'),
        ("'foo", "'foo"),
        ('"foo', '"foo'),
        ('\\"foo"', '\\"foo"')
    ]
    for string, expected in test_values:
        result = unquote(string)
        assert result == expected, "unquote(%s) returned %s" % (string, result)

