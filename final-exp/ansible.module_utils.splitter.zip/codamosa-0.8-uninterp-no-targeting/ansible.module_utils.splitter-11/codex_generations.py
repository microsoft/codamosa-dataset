

# Generated at 2022-06-20 20:58:40.554769
# Unit test for function is_quoted
def test_is_quoted():
    tests = [('"foobar"', True),
             ('"foo"bar"', False),
             ("'foobar'", True),
             ("'foobar", False),
             ('foo"bar"', False),
             ("foobar", False),
             ('""', True)]
    for test in tests:
        result = is_quoted(test[0])
        if result != test[1]:
            print("test failed: " + test[0] + " returned " + str(result))


# Generated at 2022-06-20 20:58:49.132785
# Unit test for function split_args

# Generated at 2022-06-20 20:58:56.875852
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Hello"') == True
    assert is_quoted('"Hello') == False
    assert is_quoted('Hello"') == False
    assert is_quoted('"Hello\'') == False
    assert is_quoted('\'"Hello"\'') == False
    assert is_quoted('\'Hello\'') == True
    assert is_quoted('\'Hello') == False
    assert is_quoted('Hello\'') == False



# Generated at 2022-06-20 20:59:12.246906
# Unit test for function is_quoted
def test_is_quoted():
    print(is_quoted(''))
    print(is_quoted('""'))
    print(is_quoted("''"))
    print(is_quoted('"a"'))
    print(is_quoted("'a'"))
    print(is_quoted('a'))
    print(is_quoted('"a'))
    print(is_quoted("'a"))
    print(is_quoted('a"'))
    print(is_quoted("a'"))
    print(is_quoted("a'b'"))
    print(is_quoted("a'b"))
    print(is_quoted("a'b'c"))
    print(is_quoted("'a'b"))
    print(is_quoted("'a'b'c"))

# Generated at 2022-06-20 20:59:22.987180
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("")

    assert is_quoted("''") != is_quoted('""') != is_quoted("''''") != is_quoted('""""')
    assert not is_quoted("'") != is_quoted('"') != is_quoted("'a") != is_quoted('"a')

    assert is_quoted("a'") != is_quoted('a"') != is_quoted("a'a") != is_quoted('a"a')

    assert is_quoted("''a'") != is_quoted('""a"') != is_quoted("''''a'a") != is_quoted('""""a"a')

    assert is_quoted("a''") != is_quoted('a""') != is_quoted("a''a") != is_

# Generated at 2022-06-20 20:59:27.492581
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote("'abc'") == 'abc'



# Generated at 2022-06-20 20:59:33.137828
# Unit test for function unquote
def test_unquote():
    data = '"test"'
    result = unquote(data)
    assert(result == "test")
    data = 'test'
    result = unquote(data)
    assert(result == "test")



# Generated at 2022-06-20 20:59:35.984836
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote("'test") == "'test"
    assert unquote("test") == "test"


# Generated at 2022-06-20 20:59:51.436576
# Unit test for function unquote
def test_unquote():
    data = ["'abcd'", '"abcd"' ,"'abcd","abcd'",'"abcd',"abcd",'"abcd"', "'abcd' ",' "" ',"''",'""','']
    for element in data:
        assert(unquote(element) == "abcd")
    assert(unquote("'abcd' ")=="abcd")
    assert(unquote(' "" ') == "")
    assert(unquote("''") == "")
    assert(unquote('""') == "")
    assert(unquote('') == "")
    try:
        print(unquote('""asdf"'))
        assert(False)
    except AssertionError:
        assert(True)

test_unquote()

# Generated at 2022-06-20 21:00:03.784173
# Unit test for function split_args
def test_split_args():
    # simple args
    assert split_args('a=b') == ['a=b']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b\\ c"') == ['a="b\\ c"']
    assert split_args('a="b c\\"') == ['a="b c\\"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # jinja2 blocks
    assert split_args('a=b {{ c }}') == ['a=b', '{{', 'c', '}}']
    assert split_args('a=b {{ c }} {{ d }}') == ['a=b', '{{', 'c', '}}', '{{', 'd', '}}']
    assert split

# Generated at 2022-06-20 21:00:21.006342
# Unit test for function is_quoted
def test_is_quoted():
    if not is_quoted("'data'"):
        raise AssertionError("Function is_quoted failed on test 1")
    if not is_quoted("\"data\""):
        raise AssertionError("Function is_quoted failed on test 2")
    if not is_quoted("'\"data\"'"):
        raise AssertionError("Function is_quoted failed on test 3")
    if is_quoted("data"):
        raise AssertionError("Function is_quoted failed on test 4")
    if is_quoted("da\"ta\""):
        raise AssertionError("Function is_quoted failed on test 5")
    if is_quoted("da'ta'"):
        raise AssertionError("Function is_quoted failed on test 6")

    print("Function is_quoted tested successfully")

# Generated at 2022-06-20 21:00:26.940711
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted('abc') == False
    assert is_quoted("'abc'") == True
    assert is_quoted("'a'bc'") == False
    assert is_quoted("'a''bc'") == True
    assert is_quoted("'''") == False


# Generated at 2022-06-20 21:00:38.126698
# Unit test for function split_args

# Generated at 2022-06-20 21:00:45.612515
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"asdf"') == True
    assert is_quoted("'asdf'") == True

    assert is_quoted('"asdf') == False
    assert is_quoted("'asdf") == False
    assert is_quoted('asdf"') == False
    assert is_quoted("asdf'") == False

    assert is_quoted('"asdf"asdf') == False
    assert is_quoted('asdf"asdf"') == False


# Generated at 2022-06-20 21:00:51.641087
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")
    assert not is_quoted('"quoted')
    assert not is_quoted("'quoted")
    assert not is_quoted('quoted"')
    assert not is_quoted("quoted'")



# Generated at 2022-06-20 21:00:58.478823
# Unit test for function split_args

# Generated at 2022-06-20 21:01:06.947242
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('foo')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted("'foo\"")
    assert not is_quoted("\"foo'")


# Generated at 2022-06-20 21:01:10.415682
# Unit test for function is_quoted
def test_is_quoted():
    print(is_quoted('"A string"'))
    print(is_quoted('A string"'))
    print(is_quoted('"A string'))
    print(is_quoted('A string'))
    print(is_quoted(''))
    print(is_quoted('""'))
    print(is_quoted('\'\''))


# Generated at 2022-06-20 21:01:14.969393
# Unit test for function unquote
def test_unquote():

    assert(unquote('"foo bar"') == 'foo bar')
    assert(unquote('foo bar') == 'foo bar')
    assert(unquote('"foo bar') == '"foo bar')
    assert(unquote('foo bar"') == 'foo bar"')
    assert(unquote("'foo bar'") == 'foo bar')
    assert(unquote("'foo bar") == "'foo bar")
    assert(unquote("foo bar'") == "foo bar'")


# Generated at 2022-06-20 21:01:18.406701
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == 'abcd'
    assert unquote('abcd') == 'abcd'
    assert unquote('abcd"') == 'abcd"'
    assert unquote('"abcd') == '"abcd'

# Generated at 2022-06-20 21:01:42.665446
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('c=\"foo bar\"') == ['c="foo bar"']
    assert split_args('c=foo\\ bar') == ['c=foo bar']
    assert split_args('''a=b c="foo bar"\n d=w x=y''') == ['''a=b c="foo bar"''', 'd=w x=y']
    assert split_args('''a=b c="foo bar"\nd=w x=y''') == ['''a=b c="foo bar"\n''', 'd=w x=y']

# Generated at 2022-06-20 21:01:49.938146
# Unit test for function unquote
def test_unquote():
    assert unquote('"this is a string"') == 'this is a string'
    assert unquote('"this is a string') == '"this is a string'
    assert unquote('this is a string"') == 'this is a string"'
    assert unquote('"this is a """string') == 'this is a """string'
    assert unquote('"this is a "" string') == 'this is a "" string'
    assert unquote('this is a string') == 'this is a string'
    assert unquote('this is a "st"ri"ng"') == 'this is a "st"ri"ng"'
    assert unquote('') == ''


# Generated at 2022-06-20 21:01:54.812456
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted(None)
    assert not is_quoted('abc')
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert is_quoted('"""abc"""')
    assert is_quoted("'''abc'''")
    assert not is_quoted('"abc\'')
    assert not is_quoted('\'abc"')


# Generated at 2022-06-20 21:01:57.937695
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"string"') == True
    assert is_quoted("'string'") == True
    assert is_quoted('string') == False
    assert is_quoted('"st"ring"') == False
    assert is_quoted("'st'ring'") == False


# Generated at 2022-06-20 21:02:03.909687
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common._collections_compat import OrderedDict
    tests = OrderedDict()

    # plain arguments without any quoting
    tests["arg1 arg2 arg3"] = (["arg1", "arg2", "arg3"], "basic arg list is split properly")
    tests[" arg1 arg2 arg3 "] = (["arg1", "arg2", "arg3"], "basic arg list with padding is split properly")
    tests["\narg1\narg2\narg3\n"] = (["arg1", "arg2", "arg3"], "basic arg list on multiple lines is split properly")
    tests["arg1\narg2\narg3"] = (["arg1", "arg2", "arg3"], "basic arg list with line continuation is split properly")

    # quoted arguments
    tests

# Generated at 2022-06-20 21:02:08.301527
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted('""')
    assert is_quoted("''")
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello"')
    assert not is_quoted("hello'")



# Generated at 2022-06-20 21:02:20.123496
# Unit test for function unquote
def test_unquote():
    test_list = [['"foo"', 'foo'],
                 ["'foo'", 'foo'],
                 ['foo', 'foo'],
                 ['"foo', '"foo'],
                 ["'foo", "'foo"],
                 ['"fo"o"', 'fo"o'],
                 ['"fo\"o"', 'fo"o'],
                 ["'fo'o'", "fo'o"],
                 ["'fo\'o'", "fo'o"],
                 ['"fo\\"o"', 'fo\\"o'],
                 ["'fo\\'o'", "fo\\'o"],
                 ['""', ''],
                 ["''", ''],
                 ['"', '"'],
                 ["'", "'"],
                 ['', '']]


# Generated at 2022-06-20 21:02:24.691887
# Unit test for function unquote
def test_unquote():
    assert unquote("\"test string\"") == "test string"
    assert unquote("abc") == "abc"
    assert unquote(" 'test string' ") == "test string"



# Generated at 2022-06-20 21:02:40.284494
# Unit test for function split_args
def test_split_args():
    "Test module function split_args"

    # Basic test
    data = "a=b"
    result = split_args(data)
    assert len(result) == 1
    assert result[0] == data

    # Nested quotes should not be split
    data = "a='b c'"
    result = split_args(data)
    assert len(result) == 1
    assert result[0] == data

    # Any number of spaces between tokens should be preserved
    data = "a=b  c='foo bar'"
    result = split_args(data)
    assert len(result) == 2
    assert result[0] == "a=b"
    assert result[1] == "c='foo bar'"

    # Jinja2 blocks should not be split on spaces

# Generated at 2022-06-20 21:02:46.406757
# Unit test for function unquote
def test_unquote():
    '''Function to test unquote with assert'''
    # Happy path cases
    assert unquote('"testing"') == "testing"
    assert unquote("'testing'") == "testing"
    assert unquote("'testing") == "'testing"
    assert unquote('"testing') == '"testing'

if __name__ == '__main__':
    import sys
    if sys.argv[1] == '--unittests':
        test_unquote()

# Generated at 2022-06-20 21:03:25.072805
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"a b c"') == 'a b c'
    assert unquote('"a\'bc"') == "a'bc"
    assert unquote('"a\'b c"') == "a'b c"
    assert unquote('\'a"bc\'') == 'a"bc'
    assert unquote('\'a"b c\'') == 'a"b c'

    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'


if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-20 21:03:33.917451
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'") == True
    assert is_quoted('"test"') == True
    assert is_quoted('') == False
    assert is_quoted('test"') == False
    assert is_quoted('"test') == False
    assert is_quoted('"test""') == False
    assert is_quoted('"test\'"') == False


# Generated at 2022-06-20 21:03:46.017812
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('a') == False
    assert is_quoted('a b') == False
    assert is_quoted('"') == False
    assert is_quoted('""') == False
    assert is_quoted('"a b"') == True
    assert is_quoted('""a b"') == False
    assert is_quoted('""a b""') == False
    assert is_quoted('"a b""') == False
    assert is_quoted('"a b" "') == False
    assert is_quoted('"a b" c') == False
    assert is_quoted("'a b'") == True
    assert is_quoted("'a' b'") == False
    assert is_quoted("''") == False

# Generated at 2022-06-20 21:03:52.735139
# Unit test for function is_quoted
def test_is_quoted():
    data = '"foo"'
    assert is_quoted(data)
    data = "'bar'"
    assert is_quoted(data)
    data = '"bar'
    assert not is_quoted(data)
    data = 'bar"'
    assert not is_quoted(data)
    data = '"bar"'
    assert is_quoted(data)


# Generated at 2022-06-20 21:03:59.405452
# Unit test for function split_args

# Generated at 2022-06-20 21:04:09.187152
# Unit test for function split_args
def test_split_args():
    simple_arg = 'foo=bar'
    simple_spaced_arg = 'foo=1 with 2 spaces'
    quoted_arg = 'foo="one two three"'
    unquoted_arg = "foo='one two three'"
    spaced_quoted_arg = 'foo="one two three" bar="four five six"'
    spaced_unquoted_arg = "foo='one two three' bar='four five six'"
    spaced_mixed_arg = "foo='one two three' bar=\"four five six\""
    escaped_quote_arg = "foo='one two three' bar=\\\'four five six\\\'"
    escaped_backslash_arg = "foo='one two three' bar=\\\\"

    # Test basic space-separated args
    assert split_args(simple_arg) == ['foo=bar']

# Generated at 2022-06-20 21:04:14.962570
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"1 2 3"') == True
    assert is_quoted('\'foo\'') == True
    assert is_quoted('\'1 2 3\'') == True
    assert is_quoted('"foo\'') == False
    assert is_quoted('\'foo"') == False
    assert is_quoted('\'foo') == False


# Generated at 2022-06-20 21:04:20.699247
# Unit test for function split_args
def test_split_args():
    # Simple test
    (rc, out, err) = trust_test(split_args, 'a=b c="foo bar"')
    assert rc == 0, "simple split failed"
    assert out == ['a=b', 'c="foo bar"'], "simple split failed"

    # Test with trailing newline
    (rc, out, err) = trust_test(split_args, 'a=b c="foo bar"\n')
    assert rc == 0, "trailing newline failed"
    assert out == ['a=b', 'c="foo bar"\n'], "trailing newline failed"

    # Test with leading newline
    (rc, out, err) = trust_test(split_args, '\na=b c="foo bar"')
    assert rc == 0, "leading newline failed"
    assert out

# Generated at 2022-06-20 21:04:30.019327
# Unit test for function is_quoted
def test_is_quoted():
    for t in [
            ('foo', False),
            ('"foo"', True),
            ('"foo', False),
            ('foo"', False),
            ('\'foo\'', True),
            ('\'foo', False),
            ('foo\'', False),
            ('"foo\'', False),
            ('\'foo"', False),
    ]:
        assert is_quoted(t[0]) == t[1], "Error with %s" % t[0]


# Generated at 2022-06-20 21:04:40.984140
# Unit test for function split_args
def test_split_args():

    # Test normal params
    raw_params = 'a=b c="foo bar" d="abc\\"def" g="abc\\ndef"'
    params = split_args(raw_params)
    assert len(params) == 4
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo bar"'
    assert params[2] == 'd="abc\\"def"'
    assert params[3] == 'g="abc\\ndef"'

    # Test params with line continuations
    raw_params = 'a=b c="foo bar" d="abc\\"def" g="abc\\ndef" \\'
    raw_params += '\na2=b2'
    params = split_args(raw_params)
    assert len(params) == 5

# Generated at 2022-06-20 21:05:43.611790
# Unit test for function is_quoted
def test_is_quoted():
    # Assert positive quotes
    assert is_quoted('"quoted"') == True
    assert is_quoted("'quoted'") == True
    # Assert not quoted
    assert is_quoted("not quoted") == False
    # Assert empty quotes
    assert is_quoted('') == False



# Generated at 2022-06-20 21:05:48.154086
# Unit test for function unquote
def test_unquote():
    assert unquote("\"foo\"") == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("foo") == 'foo'

# Generated at 2022-06-20 21:05:56.568321
# Unit test for function is_quoted
def test_is_quoted():
    test_data = {"foo": "bar",
                 "foobar": "",
                 "foo\"bar": "baz",
                 "\"foobar\"": "baz",
                 "foobar\"": "baz",
                 "foo\"bar\"": "baz",
                 "\"foo\"bar": "baz",
                 "\"foo\"bar\"": "baz"}

    for key, value in test_data.items():
        if is_quoted(key):
            assert(key == value)
        else:
            assert(key != value)



# Generated at 2022-06-20 21:05:57.708249
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'



# Generated at 2022-06-20 21:06:01.714700
# Unit test for function is_quoted
def test_is_quoted():
    test_data = ['''test''', '''"test"''', ''''test' ''', ''''test'\''test' ''']
    result = [False, True, True, True]
    test = map(is_quoted, test_data)
    if result != test:
        raise AssertionError("is_quoted failed with test data: %s" % str(test_data))


# Generated at 2022-06-20 21:06:04.238485
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'



# Generated at 2022-06-20 21:06:12.363535
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"ab""c"') == 'ab""c'
    assert unquote('"abcc""') == '"abcc""'
    assert unquote('ab""cc"') == 'ab""cc"'


# Generated at 2022-06-20 21:06:23.058209
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'a'") == True
    assert is_quoted("'a") == False
    assert is_quoted("a'") == False
    assert is_quoted("'a\"'") == True
    assert is_quoted("'a\"") == False
    assert is_quoted("a\"'") == False
    assert is_quoted("\"a\"") == True
    assert is_quoted("\"a'") == False
    assert is_quoted("a'\"") == False


# Generated at 2022-06-20 21:06:31.404680
# Unit test for function split_args
def test_split_args():

    # Test basic unquoted param passing
    params = split_args("a=b b=c c=d")
    assert len(params) == 3
    assert params[0] == "a=b"
    assert params[1] == "b=c"
    assert params[2] == "c=d"

    # Test basic quoted param passing
    params = split_args("a='b b' c=\"c c\" d='e e'")
    assert len(params) == 3
    assert params[0] == "a='b b'"
    assert params[1] == "c=\"c c\""
    assert params[2] == "d='e e'"

    # Test quoted whitespace in param passing
    params = split_args("a=\"a a\" b='b \n b'")
    assert len(params) == 2

# Generated at 2022-06-20 21:06:36.650804
# Unit test for function unquote
def test_unquote():
    assert unquote('"whats.up"') == 'whats.up'
    assert unquote('whats.up') == 'whats.up'
    assert unquote("whats.up'") == "whats.up'"

