

# Generated at 2022-06-20 20:58:44.407907
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'bar'") == 'bar'
    assert unquote("'baz'") == 'baz'
    assert unquote("") == ''


# Generated at 2022-06-20 20:58:51.048524
# Unit test for function split_args
def test_split_args():
    # verify we can parse with no quoting
    assert split_args("this is a test") == ['this', 'is', 'a', 'test']

    # verify we can parse with spaces in quotes
    assert split_args("this is a \"test foo\"") == ['this', 'is', 'a', '"test foo"']

    # verify we can parse a multiline command
    result = split_args("one \n two \n three")
    assert result == ['one', 'two', 'three']
    assert result[0].endswith('\n') and result[1].endswith('\n')

    # verify we can parse with spaces inside jinja2
    result = split_args("{{ foo }} bar")
    assert result == ['{{', 'foo', '}} bar']
    result = split_args("{{ foo }}bar")

# Generated at 2022-06-20 20:58:59.829329
# Unit test for function unquote
def test_unquote():
    # Tests for unquote
    assert unquote('"This is a test"') == "This is a test"
    assert unquote("'This is a test'") == "This is a test"
    assert unquote('"This is a test\'"') == '"This is a test\'"'
    assert unquote("'This is a test\'") == "This is a test'"
    assert unquote("'This is a test") == "'This is a test"
    assert unquote("This is a test'") == "This is a test'"
    assert unquote("This is a test") == "This is a test"



# Generated at 2022-06-20 20:59:03.610091
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == "abc"
    assert unquote('""') == ""

# Generated at 2022-06-20 20:59:07.209049
# Unit test for function is_quoted
def test_is_quoted():
    assert(not is_quoted('abc'))
    assert(is_quoted('"abc"'))
    assert(not is_quoted('"abc'))
    assert(not is_quoted('abc"'))
    assert(not is_quoted('""'))
    assert(not is_quoted('""""'))
    assert(is_quoted('""""""'))
    assert(not is_quoted('"""""""'))



# Generated at 2022-06-20 20:59:12.150850
# Unit test for function unquote
def test_unquote():
    """ Unit test for function unquote """
    assert unquote("abc") == "abc"
    assert unquote("'abc'") == "abc"
    assert unquote("\"abc\"") == "abc"

# Generated at 2022-06-20 20:59:19.112174
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"'") == True
    assert is_quoted("'\"") == True
    assert is_quoted('"""') == True
    assert is_quoted("'''") == True
    assert is_quoted('""') == True
    assert is_quoted("''") == True
    assert is_quoted("a'") == False
    assert is_quoted("'a") == False
    assert is_quoted("a'a") == False


# Generated at 2022-06-20 20:59:30.774592
# Unit test for function split_args
def test_split_args():
    ''' run unit tests for split_args '''
    def _assert(args, expected):
        result = split_args(args)
        if result != expected:
            raise AssertionError("test failed, result was %s, expected %s" % (result, expected))
    _assert('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _assert('yes', ['yes'])
    _assert('{{ foo }}', ['{{ foo }}'])
    _assert('{{ foo }} and {{ bar }}', ['{{ foo }} and {{ bar }}'])
    _assert('"{{ foo }} and {{ bar }}"', ['"{{ foo }} and {{ bar }}"'])

# Generated at 2022-06-20 20:59:37.054127
# Unit test for function split_args
def test_split_args():
    """ Make sure that split_args function is doing it's job well """

# Generated at 2022-06-20 20:59:50.147466
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted('"abc"')
    assert is_quoted('"\\"abc\\""')
    assert is_quoted("''")
    assert is_quoted("'abc'")
    assert is_quoted("'\\'abc\\''")
    assert not is_quoted('"')
    assert not is_quoted('\'"')
    assert not is_quoted('"\'')
    assert not is_quoted(None)
    assert not is_quoted('')
    assert not is_quoted('abc')
    assert not is_quoted('\'"abc"\'')


# Generated at 2022-06-20 21:00:15.804985
# Unit test for function split_args
def test_split_args():
    args = "a=b c='foo bar' d=\"{{{{}}}}\" e='{{foo}}' f='{{' g=\"}}\""
    params = ['a=b', "c='foo bar'", 'd="{{{{}}}}"', "e='{{foo}}'", "f='{{"]
    assert split_args(args) == params

    args = "a=b c='foo bar' d=\"{{{{}}}}\" e='{{foo}}' f='{{"
    params = ['a=b', "c='foo bar'", 'd="{{{{}}}}"', "e='{{foo}}'", "f='{{"]
    assert split_args(args) == params

    args = "a=b c='foo bar' d=\"{{{{}}}}\" e='{{foo}}' f='{{' g=\"}}\""

# Generated at 2022-06-20 21:00:23.290052
# Unit test for function split_args
def test_split_args():
    args = "a=b c=d e='foo bar' f=\"foo bar\""
    print("Splitting: %s" % args)
    print("Result: %s" % str(split_args(args)))
    args = "ansible-playbook -i /etc/ansible/hosts --user=root --sudo --ask-sudo-pass --verbose --extra-vars=\"@/etc/ansible/group_vars/sysadmins.yml\" site.yml"
    print("Splitting: %s" % args)
    print("Result: %s" % str(split_args(args)))
    args = "{{ foo }}\n{% bar %}\n{# foo #}\n\"foo\"\n'bar'"
    print("Splitting: %s" % args)

# Generated at 2022-06-20 21:00:28.548174
# Unit test for function unquote
def test_unquote():
    data1 = "\"hello world\""
    assert unquote(data1) == "hello world"

    data2 = "'hello world'"
    assert unquote(data2) == "hello world"

    assert unquote(data1 + data2) == "hello worldhello world"



# Generated at 2022-06-20 21:00:35.588160
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('foo')
    assert not is_quoted('"foo"bar')
    assert not is_quoted("'foo'bar")


# Generated at 2022-06-20 21:00:39.504187
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('"foo\'')
    assert not is_quoted('foo')
    assert not is_quoted('')



# Generated at 2022-06-20 21:00:42.828297
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted('test') == False
    assert is_quoted('') == False


# Generated at 2022-06-20 21:00:51.923945
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"') == True)
    assert(is_quoted('"foo') == False)
    assert(is_quoted('foo"') == False)
    assert(is_quoted('foo') == False)
    assert(is_quoted('') == False)
    assert(is_quoted('""') == True)
    assert(is_quoted("''") == True)
    assert(is_quoted('"\'"') == True)

# Unit tests for function unquote

# Generated at 2022-06-20 21:00:56.265538
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == "abcd"
    assert unquote("'abcd'") == "abcd"
    assert unquote("abcd") == "abcd"
    assert unquote('"a"bcd"') == '"a"bcd"'


# Generated at 2022-06-20 21:01:05.573604
# Unit test for function split_args
def test_split_args():
    args = ('a=b c="foo bar"')
    params = split_args(args)
    assert len(params) == 2
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo bar"'

    args = ('a=b c="foo bar"\n d="zap"')
    params = split_args(args)
    assert len(params) == 3
    assert params[0] == 'a=b'
    assert params[1] == 'c="foo bar"'
    assert params[2] == 'd="zap"'

    args = ('a=b c="foo\nbar"\n d="zap"')
    params = split_args(args)
    assert len(params) == 3
    assert params[0] == 'a=b'
    assert params

# Generated at 2022-06-20 21:01:11.540038
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"')
    assert is_quoted("'abcd'")
    assert not is_quoted('"abcd')
    assert not is_quoted("'abcd")
    assert not is_quoted('abcd"')
    assert not is_quoted("abcd'")
    assert not is_quoted('abcd')
    assert not is_quoted("abc'd")
    assert not is_quoted('"abcd\'')
    assert not is_quoted('\'abcd"')


# Generated at 2022-06-20 21:01:50.233777
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") == True
    assert is_quoted("'hel lo'") == True
    assert is_quoted("'hel\"lo'") == True
    assert is_quoted("'hel\\'lo'") == True
    assert is_quoted("'hel\\\\\\'lo'") == True
    assert is_quoted("'hel\\'\\\\\\'lo'") == True
    assert is_quoted("'hel\\\\\\'lo'") == True
    assert is_quoted("'hel\\\\\\\\\\'lo'") == True
    assert is_quoted("'hel\\\\\\\\\\\\\\'lo'") == True
    assert is_quoted("'hello") == False
    assert is_quoted("hello'") == False
    assert is_quoted("hel'lo") == False
    assert is_

# Generated at 2022-06-20 21:02:01.036970
# Unit test for function split_args
def test_split_args():
    ''' shlex.split doesn't work for nested quotes, this tests this function '''

    out = split_args('foo="bar baz"')
    assert out == ['foo="bar baz"']
    out = split_args('foo="bar baz" one')
    assert out == ['foo="bar baz"', 'one']
    out = split_args('foo=bar one')
    assert out == ['foo=bar', 'one']
    out = split_args('"one two"')
    assert out == ['"one two"']
    out = split_args('"one\ntwo"')
    assert out == ['"one\ntwo"']
    out = split_args('foo="bar\nbaz" one')
    assert out == ['foo="bar\nbaz"', 'one']
    out = split_args

# Generated at 2022-06-20 21:02:10.700730
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert not is_quoted('"abc')
    assert not is_quoted('abc"')
    assert is_quoted('"a\'bc"')
    assert is_quoted('\'"abc\'"')
    assert is_quoted("'abc'")
    assert not is_quoted("'abc")
    assert not is_quoted("abc'")
    assert is_quoted("'a\"bc'")
    assert is_quoted("'\"abc'\"")
    assert is_quoted('""')
    assert is_quoted("''")
    assert not is_quoted("")
    assert not is_quoted("a")
    assert is_quoted("'a'")
    assert is_quoted('"a"')


# Generated at 2022-06-20 21:02:17.819078
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"testing\"")
    assert is_quoted("'testing'")
    assert not is_quoted("testing")
    assert not is_quoted("\"testing")
    assert not is_quoted("testing\"")
    assert not is_quoted("\"test'ing\"")


# Generated at 2022-06-20 21:02:21.367116
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'

    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"


# Generated at 2022-06-20 21:02:33.143804
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == "a"
    assert unquote("'a'") == "a"
    assert unquote('"foo bar"') == "foo bar"
    assert unquote("'foo bar'") == "foo bar"
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('"f"o"o"') == '"f"o"o"'
    assert unquote("'f'o'o'") == "'f'o'o'"



# Generated at 2022-06-20 21:02:44.368539
# Unit test for function split_args
def test_split_args():
    print('Running unit tests for split_args')
    failed = 0
    tests = dict()
    #test_line = 'a=b c="foo bar"'
    #tests[test_line] = ['a=b', 'c="foo bar"']

# Generated at 2022-06-20 21:02:59.896342
# Unit test for function split_args

# Generated at 2022-06-20 21:03:11.163161
# Unit test for function split_args
def test_split_args():

    # Test that an empty string returns an empty list
    assert split_args('') == []

    # Test that simple unquoted strings are returned as single-item list
    assert split_args('foo bar') == ['foo', 'bar']

    # Test that quoted strings are returned as a single list item
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo \'bar baz\'') == ['foo', '\'bar baz\'']

    # Test that newlines aren't split
    assert split_args('foo \n bar') == ['foo \n', 'bar']

    # Test that jinja2 blocks are reassembled
    assert split_args('foo {{ bar }} baz') == ['foo ', '{{ bar }}', 'baz']
    assert split_args

# Generated at 2022-06-20 21:03:15.839871
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted('"hello"')
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted('"hello')
    assert not is_quoted("hello")


# Generated at 2022-06-20 21:04:20.729612
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hel\'lo"') == 'hel\'lo'
    assert unquote("'hel\"lo'") == 'hel"lo'
    assert unquote('') == ''
    assert unquote('"') == ''
    assert unquote("'") == ''
    assert unquote('"hello') == 'hello'
    assert unquote("'hello") == 'hello'
    assert unquote('hello"') == 'hello'
    assert unquote("hello'") == 'hello'
    assert unquote('"he""llo"') == 'he""llo'
    assert unquote("'he''llo'") == 'he''llo'


# Generated at 2022-06-20 21:04:36.293023
# Unit test for function split_args

# Generated at 2022-06-20 21:04:44.937374
# Unit test for function unquote
def test_unquote():
    assert not is_quoted('abc')
    assert not is_quoted('')
    assert is_quoted('"abc"')
    assert is_quoted('"')
    assert is_quoted('""')
    assert is_quoted("''")
    assert is_quoted("'abc'")
    assert not is_quoted("'abc")
    assert not is_quoted("abc'")
    assert not is_quoted("'")
    assert unquote('"abc"') == "abc"
    assert unquote("'abc'") == "abc"
    assert unquote('""') == ""

# Generated at 2022-06-20 21:04:50.216568
# Unit test for function split_args
def test_split_args():
    # test basic splitting
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    # test quotes
    assert split_args('foo bar "baz qux"') == ['foo', 'bar', '"baz qux"']
    # test line continuation
    assert split_args('foo bar \\\nbaz') == ['foo', 'bar', 'baz']
    # test jinja blocks
    assert split_args('foo {{bar}}') == ['foo', '{{bar}}']
    assert split_args('foo bar="{{baz}}"') == ['foo', 'bar="{{baz}}"']
    assert split_args('foo bar="{{baz}} qux"') == ['foo', 'bar="{{baz}} qux"']

# Generated at 2022-06-20 21:05:01.910956
# Unit test for function split_args
def test_split_args():
    from ansible.utils import split_args as _split_args

# Generated at 2022-06-20 21:05:06.159443
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('\'hello\'') == 'hello'

# Generated at 2022-06-20 21:05:21.541496
# Unit test for function split_args
def test_split_args():
    """Unit tests for function split_args.
    """

    # Test cases.
    # Each test case is a tuple of (args, expected_params)

# Generated at 2022-06-20 21:05:25.943113
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('hello')
    assert not is_quoted('')



# Generated at 2022-06-20 21:05:31.878030
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello world'")
    assert is_quoted('"hello world"')
    assert not is_quoted("'hello world")
    assert not is_quoted('"hello world')
    assert not is_quoted("hello world")


# Generated at 2022-06-20 21:05:44.027625
# Unit test for function split_args
def test_split_args():
    '''
    Returns a list of tests and expected results for the
    split_args function.
    '''

    tests = dict()

    tests['simple args'] = (['FOO=BAR', 'BAZ=FOO'], 'FOO=BAR BAZ=FOO')
    tests['simple quoted string'] = (['FOO="BAR BAZ"'], 'FOO="BAR BAZ"')
    tests['simple quoted string with space'] = (['FOO="BAR BAZ"'], 'FOO="BAR BAZ" ')
    tests['args with equals in quotes'] = (['FOO="BAR=BAZ"'], 'FOO="BAR=BAZ"')
    tests['quoted string with ='] = (['FOO="BAR=BAZ"'], 'FOO="BAR=BAZ"')

# Generated at 2022-06-20 21:06:56.062359
# Unit test for function is_quoted
def test_is_quoted():
    if not is_quoted(''):
        raise Exception("empty string shouldn't be quoted")

    if is_quoted('""'):
        raise Exception("empty string should not be quoted")

    if is_quoted('"a'):
        raise Exception("unterminated single quote")

    if not is_quoted('"a"'):
        raise Exception("terminated single quote")

    if is_quoted("'a"):
        raise Exception("unterminated double quote")

    if not is_quoted("'a'"):
        raise Exception("terminated double quote")


# Generated at 2022-06-20 21:07:00.344794
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"'))
    assert(is_quoted("'foo'"))
    assert(not is_quoted('foo'))
    assert(not is_quoted('"foo'))
    assert(not is_quoted("'foo"))



# Generated at 2022-06-20 21:07:09.823501
# Unit test for function split_args
def test_split_args():

    # This test is to ensure that quotation marks and
    # Jinja2 block separators are properly handled.

    assert split_args('a=1') == ['a=1']
    assert split_args('a=1 b=2') == ['a=1', 'b=2']
    assert split_args('a=1\nb=2') == ['a=1\n', 'b=2']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b c" d="e f"') == ['a="b c"', 'd="e f"']
    assert split_args('a="{{ b }}"') == ['a="{{ b }}"']

# Generated at 2022-06-20 21:07:15.409071
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('"test') == 'test'
    assert unquote("'test") == 'test'
    assert unquote('test"') == 'test"'
    assert unquote('test"') == 'test"'
    assert unquote('test') == 'test'



# Generated at 2022-06-20 21:07:24.598116
# Unit test for function unquote
def test_unquote():
    assert unquote('abcd') == 'abcd'
    assert unquote('"abcd"') == 'abcd'
    assert unquote("'abcd'") == 'abcd'
    assert unquote('"abcd') == '"abcd'
    assert unquote("abcd'") == "abcd'"

# Unit tests for function split_args
# TODO: Add more tests

# Generated at 2022-06-20 21:07:30.777287
# Unit test for function is_quoted
def test_is_quoted():
    '''
    unit test function for function is_quoted
    '''
    # test ok
    assert( is_quoted("''") == True)
    assert( is_quoted("'test'") == True)
    assert( is_quoted("\"\"") == True)
    assert( is_quoted("\"test\"") == True)

    # test fail
    assert( is_quoted("\"'test'\"") == False)
    assert( is_quoted("'\"test\"'") == False)
    assert( is_quoted("'") == False)
    assert( is_quoted("'''") == False)
    assert( is_quoted("\"") == False)
    assert( is_quoted("\"\"\"") == False)

# Generated at 2022-06-20 21:07:46.846830
# Unit test for function split_args
def test_split_args():
    # No jinja2, no quotes
    args = 'foo bar baz'
    result = ['foo', 'bar', 'baz']
    assert split_args(args) == result

    # Jinja2, no quotes
    args = '{{ foo }} {{ bar }} {{ baz }}'
    result = ['{{ foo }}', '{{ bar }}', '{{ baz }}']
    assert split_args(args) == result

    # quotes, no jinja2
    args = '"foo bar" "bar baz"'
    result = ['"foo bar"', '"bar baz"']
    assert split_args(args) == result

    # Jinja2 and quotes
    args = '{{ "foo bar" }}"bar baz"{{ "baz qux" }}'

# Generated at 2022-06-20 21:07:53.965598
# Unit test for function split_args

# Generated at 2022-06-20 21:08:04.156499
# Unit test for function split_args
def test_split_args():

    def check_rval(rval, expected):
        if rval != expected:
            print(rval)
            print(expected)
            assert False

    def check(args, expected):
        rval = split_args(args)
        check_rval(rval, expected)

    check('echo hi', ['echo', 'hi'])
    check('"echo" "hi"', ['echo', 'hi'])
    check('-a -b -c', ['-a', '-b', '-c'])
    check('-a="foo bar" -b -c', ['-a=foo bar', '-b', '-c'])
    check('-a="foo bar" -b="zap space" -c', ['-a=foo bar', '-b=zap space', '-c'])
    check

# Generated at 2022-06-20 21:08:10.444758
# Unit test for function is_quoted
def test_is_quoted():
    import os
    import sys

    assert(is_quoted('"abc"') is True)
    assert(is_quoted("'abc'") is True)
    assert(is_quoted('abc') is False)
    assert(is_quoted('"abc') is False)
    assert(is_quoted('abc"') is False)
    assert(is_quoted('"') is False)
    assert(is_quoted("'") is False)
    assert(is_quoted('') is False)
