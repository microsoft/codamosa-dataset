

# Generated at 2022-06-20 20:58:39.254547
# Unit test for function unquote
def test_unquote():
    assert unquote('"blah"') == 'blah'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote('foo bar') == 'foo bar'

# Generated at 2022-06-20 20:58:45.669841
# Unit test for function split_args
def test_split_args():
    # Tests for multiple-line arg strings:
    assert split_args('a=b') == ['a=b']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b \\\nc"') == ['a="b \nc"']
    assert split_args('a=b \\\nc') == ['a=b', 'c']
    assert split_args('a=b \\\nc d=e') == ['a=b', 'c', 'd=e']
    assert split_args('a=b \\\nc="d e"') == ['a=b', 'c="d e"']

# Generated at 2022-06-20 20:58:57.735976
# Unit test for function split_args
def test_split_args():

    tests_passed = 0
    tests_failed = 0
    tests_executed = 0

    def run_test(test_name, input_arg_str, expected_arg_list):
        global tests_passed
        global tests_failed
        global tests_executed

        arg_list = split_args(input_arg_str)
        if arg_list == expected_arg_list:
            tests_passed += 1
            print("PASSED: {}".format(test_name))
        else:
            tests_failed += 1
            print("FAILED: {}".format(test_name))
            print("   input_arg_str  = {}".format(input_arg_str))
            print("   arg_list       = {}".format(arg_list))

# Generated at 2022-06-20 20:59:04.763184
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted("foo") == False
    assert is_quoted("'foo\'") == False
    assert is_quoted("\"foo\"")
    assert is_quoted("\"foo") == False
    assert is_quoted("foo\"") == False
    assert is_quoted("foo") == False
    assert is_quoted("\"foo\"\"") == False
    assert is_quoted("\'foo\'\'") == False
    assert is_quoted("\"foo\'") == False



# Generated at 2022-06-20 20:59:12.128375
# Unit test for function is_quoted
def test_is_quoted():
    # Test if data is quoted or not
    assert is_quoted('') is False
    assert is_quoted('"') is False
    assert is_quoted('foo') is False
    assert is_quoted('"foo') is False
    assert is_quoted('foo"') is False
    assert is_quoted('"foo"') is True
    assert is_quoted("'foo'") is True
    assert is_quoted('"foo" "bar"') is False
    assert is_quoted("'foo' 'bar'") is False
    assert is_quoted('"foo bar"') is True
    assert is_quoted('"""hello"""') is False
    assert is_quoted('"hello world"') is True
    assert is_quoted('"foo bar"') is True
    assert is_quoted

# Generated at 2022-06-20 20:59:18.765813
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('"') == ''
    assert unquote('a') == 'a'
    assert unquote('"a"') == 'a'
    assert unquote('""') == ''
    assert unquote('""') == ''
    assert unquote('"a') == 'a'
    assert unquote('"aaa') == 'aaa'
    assert unquote('aa"a') == 'aa"a'


# Generated at 2022-06-20 20:59:30.483537
# Unit test for function split_args

# Generated at 2022-06-20 20:59:33.445422
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('a') == 'a'
    assert unquote('"a') == '"a'
    assert unquote('a"') == 'a"'
    assert unquote('"a"') == 'a'


# Generated at 2022-06-20 20:59:35.985911
# Unit test for function unquote
def test_unquote():
    assert unquote("foobar") == "foobar"
    assert unquote("'foobar'") == "foobar"
    assert unquote('"foobar"') == "foobar"


# Generated at 2022-06-20 20:59:42.256965
# Unit test for function split_args
def test_split_args():
    ''' test module for split_args function '''
    from ansible.utils import module_docs

    inputs = {
        'a=b c="foo bar"': ['a=b', 'c="foo bar"'],
        "a=b c='foo bar'": ['a=b', "c='foo bar'"],
        "a=b c='foo bar' d={{ a }}": ['a=b', "c='foo bar'", 'd={{ a }}'],
        "a=b c='foo bar':": ['a=b', "c='foo bar':"],
        "a=b c='foo bar':':": ['a=b', "c='foo bar':':"],
        "a=b c='foo bar':':':": ['a=b', "c='foo bar':':':"],

    }


# Generated at 2022-06-20 21:00:04.415828
# Unit test for function split_args
def test_split_args():
    ''' test split args function '''
    # just basic ones to make sure it works
    tests = {
        'a=b': ['a=b'],
        'a=b c=d': ['a=b', 'c=d'],
        'a="b c"': ['a="b c"'],
        'a="b c" e=f': ['a="b c"', 'e=f'],
        'a="b c" \'e f\'': ['a="b c"', "'e f'"],
        'a=b c="foo bar"': ['a=b', 'c="foo bar"'],
    }
    for test in tests:
        assert split_args(test) == tests[test]

    # basic tests to make sure it handles blocks of all different types

# Generated at 2022-06-20 21:00:13.387241
# Unit test for function is_quoted
def test_is_quoted():
    test_data = ["\'quoted", "\"quoted", "\"quoted\"", "\'quoted\'", "notquoted"]
    truth = [False, False, True, True, False]

    for t, v in zip(test_data, truth):
        assert v == is_quoted(t), "Expected %s, got %s for %s" % (str(v), str(is_quoted(t)), t)



# Generated at 2022-06-20 21:00:17.306492
# Unit test for function unquote
def test_unquote():
    print('Testing unquote()')
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('abc"def') == 'abc"def'
    print('Pass\n')


# Generated at 2022-06-20 21:00:28.629171
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('test1={{test2}}') == ['test1={{test2}}']
    assert split_args('test1={{test2}} test3={{ test4 }}') == ['test1={{test2}}', 'test3={{ test4 }}']
    assert split_args('test1="{{test2}} test3={{ test4 }}"') == ['test1="{{test2}} test3={{ test4 }}"']
    assert split_args('"{{foo}} {{bar}}"') == ['{{foo}} {{bar}}']
    assert split_args("{{foo}} {{bar}}") == ["{{foo}} {{bar}}"]

# Generated at 2022-06-20 21:00:32.196578
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") == True
    assert is_quoted('"hello"') == True
    assert is_quoted("hello") == False


# Generated at 2022-06-20 21:00:35.544286
# Unit test for function unquote
def test_unquote():
    assert unquote('"ab"') == 'ab'
    assert unquote('\'ab\'') == 'ab'
    assert unquote('"ab') == '"ab'
    assert unquote('\'ab') == '\'ab'

# Generated at 2022-06-20 21:00:40.677051
# Unit test for function unquote
def test_unquote():
    assert (unquote("'test'") == 'test')
    assert (unquote('"test"') == 'test')
    assert (unquote('"test') != 'test')
    assert (unquote("'test") != 'test')
    assert (unquote('') == '')
    assert (unquote('"test\'test"') == "test'test")
    assert (unquote('"test\ntest"') == "test\ntest")
    assert (unquote('') == '')



# Generated at 2022-06-20 21:00:52.346327
# Unit test for function unquote
def test_unquote():
    if unquote('"""abc""""') != 'abc':
        print('Failed unquote test 1')
        return False
    if unquote('"abc"') != 'abc':
        print('Failed unquote test 2')
        return False
    if unquote('"""abc"""') != '"""abc"""':
        print('Failed unquote test 3')
        return False
    if unquote('"""a"""b"""c"""') != '"""a"""b"""c"""':
        print('Failed unquote test 4')
        return False
    if unquote('"""a"""b"""') != '"""a"""b"""':
        print('Failed unquote test 5')
        return False
    if unquote('"""abc') != '"""abc':
        print('Failed unquote test 6')
        return False

# Generated at 2022-06-20 21:00:55.241928
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('') == ''



# Generated at 2022-06-20 21:00:58.476708
# Unit test for function unquote
def test_unquote():
    "unquote"
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('"""abc"""') == '"abc"'
    assert unquote("'''abc'''") == "'abc'"



# Generated at 2022-06-20 21:01:30.184865
# Unit test for function split_args
def test_split_args():
    import unittest

    class TestSplitArgs(unittest.TestCase):
        def test_type(self):
            result = split_args('/some/path')
            self.assertTrue(len(result) == 1)
            self.assertTrue(isinstance(result, list))
            self.assertTrue(isinstance(result[0], str))

        def test_quotes(self):
            result = split_args('"a b c" d')
            self.assertTrue(len(result) == 2)
            self.assertTrue(result[0] == '"a b c"')
            self.assertTrue(result[1] == 'd')

        def test_escaped_quotes(self):
            result = split_args('" \\ " a \\ "b')

# Generated at 2022-06-20 21:01:41.035811
# Unit test for function split_args
def test_split_args():
    '''
    This unit test can be run via nosetests or python split_args.py
    '''
    assert split_args("this is an argument") == ["this", "is", "an", "argument"]
    assert split_args("arg1 arg2") == ["arg1", "arg2"]
    assert split_args("arg1='foo bar' arg2") == ["arg1='foo bar'", "arg2"]
    assert split_args("arg1=\"foo bar\" arg2") == ["arg1=\"foo bar\"", "arg2"]
    assert split_args("arg1=\"foo bar' arg2") == ["arg1=\"foo bar'", "arg2"]
    assert split_args("arg1='foo bar\" arg2") == ["arg1='foo bar\"", "arg2"]

# Generated at 2022-06-20 21:01:42.568359
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("bar") == "bar"

# Generated at 2022-06-20 21:01:48.384166
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('""') is False
    assert is_quoted('"""') is False
    assert is_quoted('"a"') is True
    assert is_quoted('"a') is False
    assert is_quoted('\\"') is False
    assert is_quoted('\\"a') is False
    assert is_quoted('\"') is False
    assert is_quoted('\"a') is False


# Generated at 2022-06-20 21:01:55.319930
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote("'hello world'") == 'hello world'
    assert unquote('"hello world') == '"hello world'
    assert unquote("'hello world") == "'hello world"
    assert unquote('hello world"') == 'hello world"'
    assert unquote('hello world"') == 'hello world"'


# Generated at 2022-06-20 21:02:00.477383
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted("hello")
    assert not is_quoted("'hello")
    assert not is_quoted('"hello')


# Generated at 2022-06-20 21:02:04.659468
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') == True
    assert is_quoted('"s"') == True

    assert is_quoted('s') == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('""a') == False
    assert is_quoted('a') == False
    assert is_quoted('abc"') == False
    assert is_quoted('"abc') == False
    assert is_quoted('ab\"c') == False
    assert is_quoted('"ab\"c"') == False


# Generated at 2022-06-20 21:02:15.884661
# Unit test for function is_quoted
def test_is_quoted():
    test_cases = [
        ("'no quotes in this string'", False),
        ("'single quotes'", True),
        ('"double quotes"', True),
        ('no"double"quotes', False),
        ('no\'single\'quotes', False),
        ("'mixed '\"' quotes'", False),
        ("'mixed '\"' quotes", False),
        ("mixed '\"' quotes'", False),
    ]
    for (item, expected) in test_cases:
        result = is_quoted(item)
        assert result == expected, "%s - Expected %s but got %s" % (item, expected, result)


# Generated at 2022-06-20 21:02:23.368371
# Unit test for function split_args

# Generated at 2022-06-20 21:02:31.321723
# Unit test for function unquote
def test_unquote():
    # First/last are quotes
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('""foo""') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("''") == ''
    assert unquote("''foo''") == 'foo'
    assert unquote("'foo'") == 'foo'
    # First/last are different quotes
    assert unquote("'foo\"") == "'foo\""
    assert unquote("\"foo'") == "\"foo'"
    assert unquote("\"foo") == "\"foo"
    assert unquote("foo'") == "foo'"
    assert unquote("\"'foo'\"") == "'foo'"
    assert unquote("'\"foo\"'") == "\"foo\""
    # First/last

# Generated at 2022-06-20 21:03:02.682429
# Unit test for function split_args

# Generated at 2022-06-20 21:03:15.588198
# Unit test for function is_quoted
def test_is_quoted():
    ''' do some basic testing of the is_quoted function '''
    assert is_quoted('""') is True
    assert is_quoted('"testing"') is True
    assert is_quoted("''") is True
    assert is_quoted("'testing'") is True
    assert is_quoted('"testing') is False
    assert is_quoted('testing"') is False
    assert is_quoted("'testing") is False
    assert is_quoted('testing\'') is False
    assert is_quoted("testing") is False
    assert is_quoted(" ") is False
    assert is_quoted("") is False


# Generated at 2022-06-20 21:03:25.669473
# Unit test for function split_args

# Generated at 2022-06-20 21:03:41.488618
# Unit test for function split_args
def test_split_args():
    # basic normal test
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    # ensure that an empty string doesn't fail parsing
    assert split_args("") == []
    # ensure that unicode input encodes
    assert split_args(u"\xc3\xa1=b c='foo bar'") == ['\xc3\xa1=b', "c='foo bar'"]
    # ensure that tokens that contain spaces can be preserved
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    # ensure that tokens that contain spaces can be preserved
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    # ensure that the new lines are preserved

# Generated at 2022-06-20 21:03:49.900998
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('""') == False)
    assert(is_quoted('"foo"') == True)
    assert(is_quoted('foo') == False)
    assert(is_quoted('') == False)
    assert(is_quoted('""foo') == False)
    assert(is_quoted('"foo""') == False)
    assert(is_quoted('""""') == False)
    assert(is_quoted('"') == False)
    assert(is_quoted('""""') == False)
    assert(is_quoted('""""') == False)

test_is_quoted()

# Generated at 2022-06-20 21:03:58.397241
# Unit test for function is_quoted
def test_is_quoted():
    print("testing is_quoted()")
    tests = [
        ('"foo bar"', True),
        ("'foo bar'", True),
        ("foo bar", False),
        ('"', False),
        ('"a', False),
        ('a"', False),
        ('"a"', True),
        ('a', False),
        ('""', True),
        ("''", True),
        ("'", False),
        ("'a", False),
        ("a'", False),
        ("'a'", True),
    ]

    for data, expected in tests:
        result = is_quoted(data)
        if result != expected:
            print("expected %s for is_quoted('%s'), got %s" % (expected, data, result))


# Generated at 2022-06-20 21:04:03.886041
# Unit test for function unquote
def test_unquote():
    assert unquote('"""a"""') == '"""a"""'
    assert unquote('"abc"') == 'abc'
    assert unquote('"""abc"""') == '"""abc"""'
    assert unquote('"a') == '"a'
    assert unquote("'a") == "'a"



# Generated at 2022-06-20 21:04:14.278811
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar" d="foo \'bar baz"') == ['a=b', 'c="foo bar"', 'd="foo \'bar baz"']
    assert split_args('a=b c="foo bar" d="foo \'bar baz"\\') == ['a=b', 'c="foo bar"', 'd="foo \'bar baz"']
    assert split_args('a=b c="foo bar" d="foo \'bar baz"\\\n') == ['a=b', 'c="foo bar"', 'd="foo \'bar baz"']
    assert split_args('a=b c="foo bar" d="foo \'bar baz"\\\n\\\n') == ['a=b', 'c="foo bar"', 'd="foo \'bar baz"']
   

# Generated at 2022-06-20 21:04:19.900721
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted('"foo"')
    assert is_quoted("''")
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert is_quoted('"foo""')
    assert not is_quoted('"fo""o"')


# Generated at 2022-06-20 21:04:24.761034
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"one"')
    assert not is_quoted('one"')
    assert not is_quoted('"one')
    assert not is_quoted('on"e')



# Generated at 2022-06-20 21:05:23.330687
# Unit test for function split_args
def test_split_args():
    # Basic test
    args = 'a=b c="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']

    # Test jinja2 printing
    args = '{{ foo }}'
    result = split_args(args)
    assert result == ['{{ foo }}']

    args = '{{ foo }} {{ bar }}'
    result = split_args(args)
    assert result == ['{{ foo }} {{ bar }}']

    args = '{{ foo }}{{ bar }}'
    result = split_args(args)
    assert result == ['{{ foo }}{{ bar }}']

    args = '{{ foo }}' + '\n' + '{{ bar }}'
    result = split_args(args)
    assert result == ['{{ foo }}\n{{ bar }}']

# Generated at 2022-06-20 21:05:30.300175
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert is_quoted("test") == False
    assert is_quoted("\"test\"") == True
    assert is_quoted("'test'") == True
    assert unquote("\"test\"") == "test"
    assert unquote("'test'") == "test"



# Generated at 2022-06-20 21:05:40.590432
# Unit test for function unquote
def test_unquote():
    ''' test unquote() function '''
    data = '"quoted string"'
    assert unquote(data) == "quoted string"
    data = '"mixed \'single\' quotes"'
    assert unquote(data) == "mixed \'single\' quotes"
    data = "'mixed \"double\" quotes'"
    assert unquote(data) == 'mixed "double" quotes'
    data = 'abc'
    assert unquote(data) == 'abc'


# Generated at 2022-06-20 21:05:42.863667
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test"')
    assert not is_quoted('test')


# Generated at 2022-06-20 21:05:47.764496
# Unit test for function unquote
def test_unquote():
    assert(unquote('"hello"') == 'hello')
    assert(unquote("'hello'") == 'hello')
    assert(unquote('hello') == 'hello')
    assert(unquote('"hello') == '"hello')



# Generated at 2022-06-20 21:06:02.911309
# Unit test for function split_args
def test_split_args():
    # Test cases include:
    # 1. Strings with no quotes, no newlines, no jinja2 blocks
    # 2. Strings with no quotes, newlines, no jinja2 blocks
    # 3. Strings with quotes, newlines, no jinja2 blocks
    # 4. Strings with no quotes, no newlines, jinja2 blocks
    # 5. Strings with quotes, newlines, jinja2 blocks
    # 6. Strings with quotes and backslashes

    test_string_1 = "a=b c=d"
    test_string_1_expected = ['a=b', 'c=d']
    assert split_args(test_string_1) == test_string_1_expected

    test_string_2 = "a=b\nc=d"
    test_string_2_

# Generated at 2022-06-20 21:06:07.475510
# Unit test for function unquote
def test_unquote():
    assert unquote("hello") == "hello"
    assert unquote("hello'") == "hello'"
    assert unquote("'hello") == "'hello"

    assert unquote("'hello'") == "hello"
    assert unquote("\"hello\"") == "hello"



# Generated at 2022-06-20 21:06:18.410382
# Unit test for function split_args

# Generated at 2022-06-20 21:06:24.646246
# Unit test for function split_args

# Generated at 2022-06-20 21:06:30.069795
# Unit test for function split_args
def test_split_args():
    '''
    Test cases for function split_args
    '''
    input_arg = 'a=b c="foo bar"'
    expected_output = ['a=b', 'c="foo bar"']
    assert split_args(input_arg) == expected_output

    input_arg = 'a=b c\'d="foo bar"'
    expected_output = ['a=b', 'cd="foo bar"']
    assert split_args(input_arg) == expected_output

    input_arg = 'a=b c="foo bar" { { { { { {'
    expected_output = ['a=b', 'c="foo bar"', '{', '{', '{', '{', '{', '{']
    assert split_args(input_arg) == expected_output


# Generated at 2022-06-20 21:07:31.075622
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("foo'") == "foo'"
    assert unquote('"foo') == '"foo'
    assert unquote("'fo\"o") == "'fo\"o"
    assert unquote("fo\"o") == "fo\"o"

# Generated at 2022-06-20 21:07:39.235344
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("hello") == False)
    assert(is_quoted("'hello'") == True)
    assert(is_quoted('"hello"') == True)
    assert(is_quoted("'hello") == False)
    assert(is_quoted('hello"') == False)
    assert(is_quoted("'hello\'") == False)


# Generated at 2022-06-20 21:07:49.074542
# Unit test for function is_quoted
def test_is_quoted():
    unquoted_string = 'hello world'
    assert not is_quoted(unquoted_string)
    single_quoted_string = "'hello world'"
    assert is_quoted(single_quoted_string)
    double_quoted_string = '"hello world"'
    assert is_quoted(double_quoted_string)
    single_quoted_string = "'hello world"
    assert not is_quoted(single_quoted_string)
    single_quoted_string = "hello world'"
    assert not is_quoted(single_quoted_string)


# Generated at 2022-06-20 21:07:55.534261
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']
    args = 'a=b c="foo\nbar"'
    assert split_args(args) == ['a=b', 'c="foo\nbar"']
    args = 'a=b c="foo\nbar\nbaz"'
    assert split_args(args) == ['a=b', 'c="foo\nbar\nbaz"']
    args = 'a=b c="{{ foo }}"'
    assert split_args(args) == ['a=b', 'c="{{ foo }}"']
    args = 'a=b c="{{ foo }}" d="{% bar %}"'

# Generated at 2022-06-20 21:08:00.160811
# Unit test for function split_args

# Generated at 2022-06-20 21:08:10.925013
# Unit test for function split_args
def test_split_args():
    def test_args(args, split_args):
        """
        Check if the args passed in will be split in the same way as split_args
        split_args is a list containing the individual args
        """
        args_split = split_args(args)
        # the result of split_args can either be a list of individual
        # args or a string containing a single arg
        if isinstance(args_split, list):
            if args_split != split_args:
                raise Exception("Test of function split_args on '%s' failed: expected %s, got %s" % (args, repr(split_args), repr(args_split)))

# Generated at 2022-06-20 21:08:17.851342
# Unit test for function split_args

# Generated at 2022-06-20 21:08:29.016532
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("\"") == False
    assert is_quoted("\'") == False
    assert is_quoted("foo") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("\"foo\"") == True
    assert is_quoted("'foo") == False
    assert is_quoted("\"foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted("foo\"") == False
