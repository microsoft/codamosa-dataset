

# Generated at 2022-06-23 02:45:04.953432
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'


# Generated at 2022-06-23 02:45:15.085737
# Unit test for function split_args
def test_split_args():
    import unittest


# Generated at 2022-06-23 02:45:25.536909
# Unit test for function split_args
def test_split_args():
    ''' run a series of tests against split_args to ensure
    that it behaves as expected'''

    # a clean args line should split as expected
    args = "a=b c=\"foo bar\""
    expected = ['a=b', 'c="foo bar"']
    assert split_args(args) == expected, "clean args line failed"

    # a quoted arg with no spaces should split as expected
    args = "a=b c=\"foo\""
    expected = ['a=b', 'c="foo"']
    assert split_args(args) == expected, "quoted arg with no spaces failed"

    # args split over multiple lines should split as expected
    args = '''a=b \
c="foo"'''
    expected = ['a=b', 'c="foo"']
    assert split_args(args) == expected

# Generated at 2022-06-23 02:45:27.159179
# Unit test for function unquote
def test_unquote():
    assert unquote('abcd') == 'abcd'
    assert unquote('"abcd"') == 'abcd'
    assert unquote("'abcd'") == 'abcd'
    assert unquote('"ab"cd"') == '"ab"cd"'


# Generated at 2022-06-23 02:45:36.297252
# Unit test for function split_args

# Generated at 2022-06-23 02:45:39.594488
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') != 'foo'
    assert unquote('foo"') != 'foo'
    assert unquote('foo') == 'foo'



# Generated at 2022-06-23 02:45:46.314891
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"') == False
    assert is_quoted('""')
    assert is_quoted("''")
    assert is_quoted("''''") == False
    assert is_quoted("'abc'")
    assert is_quoted('"""') == False
    assert is_quoted("'''") == False
    assert is_quoted("'a'")
    assert is_quoted("'a'''") == False
    assert is_quoted("''a'") == False



# Generated at 2022-06-23 02:45:54.567420
# Unit test for function split_args
def test_split_args():
    assert split_args('a=1') == ['a=1']
    assert split_args('a=1 b=2') == ['a=1', 'b=2']
    assert split_args('a=1\nb=2') == ['a=1', 'b=2']
    assert split_args('a=1\nb=2\nc=3') == ['a=1\nb=2', 'c=3']
    assert split_args('a=1\n  b=2\n    c=3') == ['a=1', 'b=2', 'c=3']
    assert split_args('a="1"') == ['a="1"']
    assert split_args('a="1 2"') == ['a="1 2"']

# Generated at 2022-06-23 02:46:00.710414
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('foo')) is False
    assert(is_quoted('"foo"')) is True
    assert(is_quoted('""')) is True
    assert(is_quoted('\'foo\'')) is True
    assert(is_quoted('\'\'')) is True
    assert(is_quoted('\'\n\'')) is True
    assert(is_quoted('\'"\n\'')) is True
    assert(is_quoted('"\'"\n\'')) is True
    assert(is_quoted('\'foo')) is False
    assert(is_quoted('foo\'')) is False
    assert(is_quoted('"foo')) is False
    assert(is_quoted('foo"')) is False


# Generated at 2022-06-23 02:46:07.424088
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('')                   == False
    assert is_quoted('""')                 == True
    assert is_quoted('"')                  == False
    assert is_quoted('"a"')                == True

# Generated at 2022-06-23 02:46:16.108285
# Unit test for function split_args

# Generated at 2022-06-23 02:46:20.709384
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"


# Generated at 2022-06-23 02:46:26.130317
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("hello")
    assert not is_quoted("'hello\"")
    assert not is_quoted("\"hello'")



# Generated at 2022-06-23 02:46:36.680118
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote('"foo\'"') == 'foo\''
    assert unquote('"foo\'"bar') == 'foo\'"bar'
    assert unquote('"""foo"""') == 'foo'
    assert unquote('''"foo'"bar"''') == 'foo"bar'
    assert unquote('"""foo""""bar"') == '"foo""bar'

# Generated at 2022-06-23 02:46:51.356883
# Unit test for function split_args
def test_split_args():
    def assert_param_list(expected, to_split):
        assert expected == split_args(to_split)

    assert_param_list(['a=b', 'c="foo bar"'], 'a=b c="foo bar"')
    assert_param_list(['a=b c="foo bar"'], '"a=b c=\\"foo bar\\""')
    assert_param_list(['a=b c="foo bar baz"'], 'a=b c="foo bar baz"')
    assert_param_list(['a=b c="foo \\"bar\\" baz"'], 'a=b c="foo \\"bar\\" baz"')
    assert_param_list(['a="b c" d=e'], 'a="b c" d=e')

# Generated at 2022-06-23 02:46:55.054720
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('\'abc\'') == 'abc'
    assert unquote('a"b\'c') == 'a"b\'c'
    assert unquote('') == ''



# Generated at 2022-06-23 02:47:03.017513
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestSplitArgs(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        @patch.object(builtins, 'open', create=True)
        def run_module_with_fail_json(self, *args, **kwargs):
            self.fail_json(*args, **kwargs)

        def test_split_args_module_utils(self):
            self.assertEqual(split_args("foo"), ['foo'])
            self.assertEqual(split_args("foo bar"), ['foo', 'bar'])
            self.assertEqual(split_args("foo='bar az'"), ["foo='bar az'"])


# Generated at 2022-06-23 02:47:14.600719
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"') == False
    assert is_quoted('""') == True
    assert is_quoted('') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('\'foo\'') == True
    assert is_quoted('\'\'') == True
    assert is_quoted('\'foo') == False
    assert is_quoted('foo\'') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo\'bar"') == True


# Generated at 2022-06-23 02:47:16.166735
# Unit test for function unquote
def test_unquote():
    assert unquote('"foobar"') == 'foobar'



# Generated at 2022-06-23 02:47:26.829501
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('   ') == []
    assert split_args('   a   b  c  ') == ['a', 'b', 'c']
    assert split_args('  "a b"  c ') == ['a b', 'c']
    assert split_args(' "a b" "c d" ') == ['a b', 'c d']
    assert split_args('\'a b\' c ') == ['a b', 'c']
    assert split_args('"a \'b\'" c ') == ['a \'b\'', 'c']
    assert split_args('"a \"b\"" c ') == ['a \"b\"', 'c']

# Generated at 2022-06-23 02:47:33.462191
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted(unquote('"This is a quoted string"')) == True
    assert is_quoted(unquote("'This is a quoted string'")) == True
    assert is_quoted(unquote('This is not quoted string')) == False
    assert is_quoted(unquote('   "')) == False
    assert is_quoted(unquote('  " "  ')) == False


# Generated at 2022-06-23 02:47:45.669579
# Unit test for function split_args
def test_split_args():
    ''' Test split_args() against a bunch of edge cases '''

# Generated at 2022-06-23 02:47:58.262437
# Unit test for function split_args

# Generated at 2022-06-23 02:48:06.683281
# Unit test for function unquote
def test_unquote():
    assert is_quoted("\"1234\"")
    assert not is_quoted("12345\"")
    assert not is_quoted("\"12345")
    assert not is_quoted("12345")
    assert not is_quoted("\"1234\'")

    assert unquote("\"1234\"") == "1234"
    assert unquote("'1234'") == "1234"
    assert unquote("1234") == "1234"
    assert unquote("\"1234\'") == "\"1234\'"



# Generated at 2022-06-23 02:48:17.097614
# Unit test for function split_args
def test_split_args(): # may not work as expected with ansible-playbook and `--extra-vars`
    args = 'a=b c="foo bar" d="foo \\" bar" e=\'foo \'\\\' bar\''
    result = split_args(args)
    assert args == ' '.join(result)
    assert isinstance(result, list)
    assert len(result) == 5

    args = 'a=b c="foo bar" d="foo \\" bar" e=\'foo \'\\\' bar\'\\'
    result = split_args(args)
    assert args == ' '.join(result)
    assert isinstance(result, list)
    assert len(result) == 5

    args = 'a=b c="foo bar" d="foo \\" bar" e=\'foo \'\\\' bar\'\\\nf=d'
    result

# Generated at 2022-06-23 02:48:24.866630
# Unit test for function split_args
def test_split_args():
    '''
    Tests for function split_args

    Will throw an Exception if any test fails
    Returns nothing if all tests succeed
    '''

    def assert_equal(message, expected, result):
        if result != expected:
            raise Exception("Test '%s' FAILED. Expected: '%s', got '%s'." % (message, expected, result))
        print("Test '%s' passed successfully." % message)

    assert_equal("Simple test", ['a=b', 'c=d'], split_args("a=b c=d"))
    assert_equal("Quoted test", ['a=b', 'c="foo bar"'], split_args("a=b c=\"foo bar\""))
    assert_equal("Quoted test with space", ['c="foo bar"'], split_args("c=\"foo bar\""))
   

# Generated at 2022-06-23 02:48:35.984279
# Unit test for function split_args

# Generated at 2022-06-23 02:48:42.679635
# Unit test for function split_args

# Generated at 2022-06-23 02:48:46.917215
# Unit test for function unquote
def test_unquote():
    assert unquote("my string") == "my string"
    assert unquote("'my string'") == "my string"
    assert unquote("\"my string\"") == "my string"
    assert unquote("'my \"quoted\" string'") == "my \"quoted\" string"
    assert unquote("\"my 'quoted' string\"") == "my 'quoted' string"

# Generated at 2022-06-23 02:48:58.470133
# Unit test for function split_args

# Generated at 2022-06-23 02:49:09.672362
# Unit test for function split_args
def test_split_args():
    res = split_args('a="f bar" c="foo bar"')
    assert res == ['a="f bar"', 'c="foo bar"']

    res = split_args('a="foo bar" c="foo bar"')
    assert res == ['a="foo bar"', 'c="foo bar"']

    res = split_args('a="foo bar c="foo bar"')
    assert res == ['a="foo', 'bar', 'c="foo', 'bar"']

    res = split_args('a="foo bar" c="foo bar')
    assert res == ['a="foo bar"', 'c="foo bar']

    res = split_args('a=foo bar c="foo bar"')
    assert res == ['a=foo', 'bar', 'c="foo bar"']


# Generated at 2022-06-23 02:49:14.604074
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted('abc') == False
    assert is_quoted('"ab"c') == False
    assert is_quoted('a"bc') == False



# Generated at 2022-06-23 02:49:26.327513
# Unit test for function split_args
def test_split_args():
    args = u"a=1 c='foo bar' d=\"{% if True %}{% endif %}\" e={{ foo }} f='\"' g='\"' h=\\\n'\"'"

    params = split_args(args)
    print(params)
    assert len(params) == 9
    assert params[0] == u'a=1'
    assert params[1] == u"c='foo bar'"
    assert params[2] == u'd="{% if True %}{% endif %}"'
    assert params[3] == u'e={{ foo }}'
    assert params[4] == u"f='\"'"
    assert params[5] == u"g='\"'"
    assert params[6] == u'h=\\'
    assert params[7] == u'"'
    assert params[8]

# Generated at 2022-06-23 02:49:34.067468
# Unit test for function unquote
def test_unquote():
    assert unquote('"lorem ipsum"') == 'lorem ipsum'
    assert unquote("'lorem ipsum'") == 'lorem ipsum'
    assert unquote('"""lorem ipsum"""') == '"""lorem ipsum"""'
    assert unquote('"lorem ipsum') == '"lorem ipsum'
    assert unquote('lorem ipsum') == 'lorem ipsum'


# Generated at 2022-06-23 02:49:44.688462
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert is_quoted('"test') == False
    assert is_quoted("'test") == False
    assert is_quoted('test"') == False
    assert is_quoted("test'") == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted('""')
    assert is_quoted("''")


# Generated at 2022-06-23 02:49:55.837201
# Unit test for function split_args
def test_split_args():

    class TestCase(object):
        def __init__(self, name, args, expected):
            self.name = name
            self.args = args
            self.expected = expected


# Generated at 2022-06-23 02:50:07.892591
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('') == False)                   # empty string
    assert(is_quoted('"') == False)                  # single quote
    assert(is_quoted('""') == True)                  # double quote
    assert(is_quoted('""1') == False)                # double quote followed by another char
    assert(is_quoted('1""') == False)                # char followed by double quote
    assert(is_quoted('"1"') == True)                 # char inside double quote
    assert(is_quoted('"1') == False)                 # char inside un-finished double quote
    assert(is_quoted('"1" 2') == True)               # char inside double quote followed by a space and another char
    assert(is_quoted('"1"2') == False)               # char inside double quote followed by

# Generated at 2022-06-23 02:50:19.124761
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b 'c=d'") == ['a=b', "'c=d'"]
    assert split_args("a=b \"c=d\"") == ['a=b', '"c=d"']
    assert split_args("/bin/foo bar='a b' 'c d'") == ['/bin/foo', "bar='a b'", "'c d'"]
    assert split_args("a=b 'c=d' e=\"foo bar\"") == ['a=b', "'c=d'", 'e="foo bar"']

# Generated at 2022-06-23 02:50:31.011937
# Unit test for function split_args
def test_split_args():
    '''
        Test function split_args.
        This is a unit test that checks if split_args
        function properly splits a given string according
        to its arguments.
    '''
    # Test 1
    # Test if split_args works as expected when there are
    # no quotes or jinja2 variables in the string
    args = 'a=b c="foo bar"'
    res = split_args(args)
    if res != ['a=b', 'c="foo bar"']:
        return False

    # Test 2
    # Test if split_args properly rejoins a list of arguments when
    # the jinja2 {% %} variables are split across multiple arguments
    args = 'a=b c="foo {% if bar %} bar {% endif %}"'
    res = split_args(args)

# Generated at 2022-06-23 02:50:43.154032
# Unit test for function split_args

# Generated at 2022-06-23 02:50:50.359257
# Unit test for function unquote
def test_unquote():
    # Check to ensure single and double quotes are correctly handled in unquoted strings.
    assert unquote("'This is an unquoted string'") == 'This is an unquoted string'
    assert unquote('"This is an unquoted string"') == 'This is an unquoted string'
    assert unquote("This is an unquoted string") == 'This is an unquoted string'
    assert unquote("This is an unquoted string with 'single' and \"double\" quotes.") == 'This is an unquoted string with \'single\' and "double" quotes.'
    assert unquote("'This is a quoted string'") == 'This is a quoted string'
    assert unquote('"This is a quoted string"') == 'This is a quoted string'

# Generated at 2022-06-23 02:51:02.098645
# Unit test for function split_args

# Generated at 2022-06-23 02:51:11.376377
# Unit test for function split_args
def test_split_args():

    test_strings = dict()

    #
    # No quoting, no jinja2
    #
    test_strings['no_quoting_1'] = dict(input="a=b", output=['a=b'])
    test_strings['no_quoting_2'] = dict(input="a=b c=d", output=['a=b', 'c=d'])
    test_strings['no_quoting_3'] = dict(input="a=b\nc=d", output=['a=b', 'c=d'])
    test_strings['no_quoting_4'] = dict(input="a=b\\\n c=d", output=['a=b c=d'])

# Generated at 2022-06-23 02:51:18.445291
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')
    assert not is_quoted("'\"foo\"'")
    assert not is_quoted('""')
    assert not is_quoted("''")
    assert not is_quoted("''''")
    assert not is_quoted('"""')
    assert not is_quoted("foo")


# Generated at 2022-06-23 02:51:28.255364
# Unit test for function is_quoted
def test_is_quoted():
    quoted = '"quoted string"'
    assert is_quoted(quoted) is True
    assert is_quoted('"') is False
    assert is_quoted('"unclosed') is False
    assert is_quoted('twice"') is False
    assert is_quoted('"twice') is False
    assert is_quoted("'quoted string'") is True
    assert is_quoted("'") is False
    assert is_quoted("'unclosed") is False
    assert is_quoted("twice'") is False
    assert is_quoted("'twice") is False
    assert is_quoted('"double"\'') is False
    assert is_quoted('"1" "" ""') is False
    assert is_quoted('"1" "2"') is False

# Unit

# Generated at 2022-06-23 02:51:36.136651
# Unit test for function unquote
def test_unquote():
    assert unquote('"just_a_string"') == 'just_a_string'
    assert unquote("'just_a_string'") == 'just_a_string'
    assert unquote('just_a_string') == 'just_a_string'
    assert unquote('"just_a_string') == '"just_a_string'


# Generated at 2022-06-23 02:51:44.768249
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote("'hello") == "'hello"
    assert unquote('"hello') == '"hello'
    assert unquote("hello") == "hello"
    assert unquote("'hello, world'") == "hello, world"
    assert unquote('"hello, world"') == "hello, world"


# Generated at 2022-06-23 02:51:57.366690
# Unit test for function is_quoted
def test_is_quoted():
    print("TEST: is_quoted")

# Generated at 2022-06-23 02:52:10.534325
# Unit test for function split_args
def test_split_args():
    '''
    This test routine is based on the Ansible 2.9.10 test routine
    test_split_args (test/units/utils/test_module_utils.py).
    '''

    print('--- start unit test_split_args ---\n')


# Generated at 2022-06-23 02:52:22.569805
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('"string"') == True)
    assert (is_quoted('"string') == False)
    assert (is_quoted('"string\'"') == False)
    assert (is_quoted('string"') == False)
    assert (is_quoted('string') == False)
    assert (is_quoted('') == False)
    assert (is_quoted('""') == True)
    assert (is_quoted('\'string\'') == True)
    assert (is_quoted('\'string') == False)
    assert (is_quoted('"string"') == True)
    assert (is_quoted('"string""') == False)
    assert (is_quoted('string\'"') == False)
    assert (is_quoted('string') == False)


# Generated at 2022-06-23 02:52:33.202511
# Unit test for function split_args
def test_split_args():
    """
    Test to make sure the split_args works as expected
    """
    from ansible.module_utils.common._collections_compat import Sequence
    #
    # Test to make sure split_args returns the correct type
    #
    assert isinstance(split_args('a=b c="foo bar"'), Sequence)
    #
    # Test to make sure split_args splits on spaces, but keeps quotes intact
    #
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    #
    # Test to make sure split_args separates, but keeps intact args split over multiple lines
    #
    assert split_args("a=b \\\nc='foo bar'") == ['a=b', "c='foo bar'"]
    #
    # Test to make sure split

# Generated at 2022-06-23 02:52:42.503985
# Unit test for function split_args
def test_split_args():
    ''' tests for function split_args '''

    import re

    # Enclose one or more digits in braces
    brace_expand = lambda x: re.sub(r'(\d+)', r'{\1}', x)

    # Enclose one or more chars in braces
    brace_expand_chars = lambda x: re.sub(r'(\D+)', r'{\1}', x)

    # FIXME: tighten up the tests for quotes

    # Test single argument
    arg = '"foobar"'
    result = split_args(arg)
    assert(len(result) == 1 and result[0] == arg)

    # Test single argument - complex
    arg = 'foo = bar'
    result = split_args(arg)
    assert(len(result) == 1 and result[0] == arg)

    #

# Generated at 2022-06-23 02:52:50.837562
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("test")
    assert not is_quoted("'test")
    assert not is_quoted("test'")
    assert not is_quoted("'test'")
    assert is_quoted("'test'")
    assert is_quoted("'test")
    assert is_quoted("'test''")
    assert is_quoted("\"test")
    assert is_quoted("\"test\"\"")
    assert not is_quoted("\"test")
    assert not is_quoted("\"test\"")
    assert not is_quoted("\"test")
    assert is_quoted("\"test\"")


# Generated at 2022-06-23 02:52:55.569506
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello world"')
    assert is_quoted("'hello world'")
    assert not is_quoted('hello world')


# Generated at 2022-06-23 02:53:04.405096
# Unit test for function split_args
def test_split_args():
    def do_test(test_input, expected_result):
        actual_result = split_args(test_input)

        assert actual_result == expected_result, 'test_input: %s' % test_input

    do_test('a=b  c="foo bar"', ['a=b', 'c="foo bar"'])
    do_test('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    do_test('a=b c="foo bar"    d=3', ['a=b', 'c="foo bar"', 'd=3'])
    do_test('a=b c="foo bar" d="{{ foo }}"', ['a=b', 'c="foo bar"', 'd="{{ foo }}"'])

# Generated at 2022-06-23 02:53:11.883385
# Unit test for function split_args

# Generated at 2022-06-23 02:53:20.702702
# Unit test for function split_args
def test_split_args():
    # Test with jinja2 tags and quotes
    args = "a=b c=\"foo bar\" d='baz qux'"
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"', "d='baz qux'"]

    result = split_args("a=b c='foo bar'")
    assert result == ['a=b', "c='foo bar'"]

    result = split_args("a=b c='foo bar' d=\"baz qux\"")
    assert result == ['a=b', "c='foo bar'", 'd="baz qux"']

    result = split_args("a=b c='foo bar' d=\"baz qux\" e=f")

# Generated at 2022-06-23 02:53:26.183366
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote("'a'") == 'a'
    assert unquote('"a\'') == 'a\''
    assert unquote("'a\"") == 'a"'
    assert unquote('a') == 'a'


# Generated at 2022-06-23 02:53:31.441366
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted("hello")
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("'hello\"")
    assert not is_quoted('"hello\'')



# Generated at 2022-06-23 02:53:41.564068
# Unit test for function split_args
def test_split_args():
    '''
    The test cases for split_args were taken from
    https://github.com/ansible/ansible/pull/3629#issuecomment-47731788
    '''
    assert split_args('a=1 b=2') == ['a=1', 'b=2']
    assert split_args('a={{ foo }}') == ['a={{ foo }}']
    assert split_args('a="{{ foo }}"') == ['a="{{ foo }}"']
    assert split_args('a="foo\n{{ foo }}"') == ['a="foo\n{{ foo }}"']
    assert split_args('a="foo\n{{ foo }} bar"') == ['a="foo\n{{ foo }} bar"']

# Generated at 2022-06-23 02:53:44.906728
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'quoted string'") == True)
    assert(is_quoted("'quoted string") == False)
    assert(is_quoted("quoted string'") == False)
    assert(is_quoted("quoted string") == False)



# Generated at 2022-06-23 02:53:57.159700
# Unit test for function split_args
def test_split_args():
    '''
    This is the test suite for split_args to ensure that it
    is properly handling edge cases
    '''
    # simple test cases, should generally work

# Generated at 2022-06-23 02:54:05.852081
# Unit test for function split_args
def test_split_args():
    '''
    run some tests on the split_args() utility function to ensure it is operating correctly
    '''

    # test basic quoting and escaping
    assert split_args("foo=\"a \\\"b\\\" c\"") == ['foo="a \\"b\\" c"']
    assert split_args("foo='a \"b\" c'") == ["foo='a \"b\" c'"]
    assert split_args("--extra-vars='foo=1 bar=2'") == ["--extra-vars='foo=1 bar=2'"]

    # test simple jinja2 blocks
    assert split_args("{% if foo %}") == ["{%", "if", "foo", "%}"]

# Generated at 2022-06-23 02:54:15.759309
# Unit test for function split_args

# Generated at 2022-06-23 02:54:28.076062
# Unit test for function split_args
def test_split_args():

    # Helper function to compare two lists
    def assert_list_equal(list_arg1, list_arg2):
        assert len(list_arg1) == len(list_arg2)
        for elem_arg1, elem_arg2 in zip(list_arg1, list_arg2):
            assert elem_arg1 == elem_arg2

    # Basic test
    args = "a=b c='foo bar'"
    expected_result = ['a=b', "c='foo bar'"]
    result = split_args(args)
    assert_list_equal(expected_result, result)

    # Test for {{var}} containing a ' ' <space> character
    args = "a=b c='{{var}}'"
    expected_result = ['a=b', "c='{{var}}'"]
    result

# Generated at 2022-06-23 02:54:34.598496
# Unit test for function is_quoted
def test_is_quoted():
    try:
        from q import q
    except ImportError:
        from nose import SkipTest
        raise SkipTest("q module not found. skipping is_quoted() test")


# Generated at 2022-06-23 02:54:40.338690
# Unit test for function is_quoted
def test_is_quoted():
    tests = [
        ("str", False),
        ("'str'", True),
        ('"str"', True),
        ('"st"r"', False),
        ('"str', False),
    ]
    passed = 0
    for t in tests:
        if is_quoted(t[0]) != t[1]:
            print("test for is_quoted({!r}) failed".format(t[0]))
        else:
            passed += 1
    print("test_is_quoted: %d/%d tests passed" % (passed, len(tests)))


# Generated at 2022-06-23 02:54:47.311326
# Unit test for function unquote
def test_unquote():
    assert "foo" == unquote("foo")
    assert "foo" == unquote("'foo'")
    assert "foo" == unquote('"foo"')
    assert "foo bar" == unquote('"foo bar"')
    assert "foo" == unquote("'foo")
    assert "foo" == unquote('"foo')


# Generated at 2022-06-23 02:54:51.891306
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"/path"')
    assert is_quoted("'/path'")
    assert is_quoted("\"/path\"")
    assert not is_quoted("'/path\"")
    assert not is_quoted("\"/path'")
    assert not is_quoted("/path")



# Generated at 2022-06-23 02:54:58.498363
# Unit test for function is_quoted
def test_is_quoted():
    #test with valid quotes
    assert is_quoted('"hello, world"') == True
    assert is_quoted("'hello, world'") == True

    #test with invalid quotes
    assert is_quoted('"hello, world\'') == False
    assert is_quoted("'hello, world\"") == False

    #test with quotes but not at the ends
    assert is_quoted('"hello, world\'') == False
    assert is_quoted("'hello, world\"") == False
    assert is_quoted('hello, world\'') == False
    assert is_quoted("hello, world\"") == False


# Generated at 2022-06-23 02:55:11.494196
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='d e'") == ['a=b', "c='d e'"]
    assert split_args("a={{b}} c={{d e}}") == ['a={{b}}', "c={{d e}}"]
    assert split_args('a={{b}} c="{{d e}}" f="g h"') == ['a={{b}}', 'c="{{d e}}"', 'f="g h"']
    assert split_args('a=b c="d e" f=\'g h\'') == ['a=b', 'c="d e"', "f='g h'"]
    assert split_args("a=b c='d e' f=\"g h\"") == ['a=b', "c='d e'", 'f="g h"']
    #