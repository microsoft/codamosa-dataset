

# Generated at 2022-06-23 02:45:10.110447
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted('"test') == False
    assert is_quoted('test"') == False
    assert is_quoted('""test""')
    assert is_quoted('"""test"""')
    assert is_quoted('\'test\'')
    assert is_quoted('\'test') == False
    assert is_quoted('test\'') == False
    assert is_quoted('\'\'test\'\'')
    assert is_quoted('\'\'\'test\'\'\'')
    assert is_quoted('\'test\"') == False
    assert is_quoted('\"test\'') == False
    assert is_quoted('') == False



# Generated at 2022-06-23 02:45:15.694542
# Unit test for function is_quoted
def test_is_quoted():
    if is_quoted("' quoted string taken from command output '") != True:
        print("Unit test for is_quoted(' quoted string taken from command output ') failed")
    elif is_quoted(" ' quoted string taken from command output '") != False:
        print("Unit test for is_quoted(' quoted string taken from command output ') failed")


# Generated at 2022-06-23 02:45:19.574179
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")


# Generated at 2022-06-23 02:45:21.823115
# Unit test for function is_quoted
def test_is_quoted():
    # Should return True
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    # Should return False
    assert is_quoted('foo') == False
    assert is_quoted('"foo\'"') == False
    assert is_quoted("'foo\"") == False



# Generated at 2022-06-23 02:45:30.213830
# Unit test for function split_args

# Generated at 2022-06-23 02:45:34.746162
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"ab\\\\"') == 'ab\\'



# Generated at 2022-06-23 02:45:39.689687
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"fo\'o"') == "fo\'o"
    assert unquote('\'fo"o\'') == 'fo"o'



# Generated at 2022-06-23 02:45:41.132080
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == "hello world"

# Generated at 2022-06-23 02:45:44.994998
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("\"asdf\""))
    assert(is_quoted("'asdf'"))
    assert(not is_quoted("asdf\""))
    assert(not is_quoted("asdf'"))
    assert(not is_quoted("asdf"))

# Generated at 2022-06-23 02:45:53.543071
# Unit test for function split_args
def test_split_args():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-23 02:46:03.687849
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'a'") == True)
    assert(is_quoted("'a") == False)
    assert(is_quoted("a'") == False)
    assert(is_quoted("\"a\"") == True)
    assert(is_quoted("\"a") == False)
    assert(is_quoted("a\"") == False)
    assert(is_quoted("'abc'") == True)
    assert(is_quoted("\"abc\"") == True)
    assert(is_quoted("'ab'c'") == False)
    assert(is_quoted("\"ab\"c\"") == False)
    assert(is_quoted("ab\"c") == False)
    assert(is_quoted("ab'c") == False)



# Generated at 2022-06-23 02:46:12.358825
# Unit test for function unquote
def test_unquote():
    test_values = {
        'abc': 'abc',
        '"abc"': 'abc',
        '"a bc"': 'a bc',
        "abc'": "abc'",
        "abc'xyz": "abc'xyz",
        '"a bc\"xyz"': 'a bc"xyz',
        '"a bc\"xyz"': 'a bc"xyz',
        "a\\ bc\"xyz": "a\\ bc\"xyz",
        "a \\\" bc\"xyz": 'a \\" bc"xyz'
    }

    for t in test_values:
        assert unquote(t) == test_values[t], "unquote failed on input " + t



# Generated at 2022-06-23 02:46:24.703997
# Unit test for function split_args
def test_split_args():
    # Simple test for a single command
    args_str = "foo bar"
    arg_list = split_args(args_str)
    assert arg_list == ["foo", "bar"]

    # Testing comment_depth with a single line
    args_str = "foo {# this is a 'single' #} bar"
    arg_list = split_args(args_str)
    assert arg_list == ["foo", '{# this is a \'single\' #}', "bar"]

    # Testing block_depth with a single line
    args_str = "foo {% if x %} bar"
    arg_list = split_args(args_str)
    assert arg_list == ["foo", '{% if x %}', "bar"]

    # Testing print_depth with a single line

# Generated at 2022-06-23 02:46:33.887402
# Unit test for function unquote
def test_unquote():
    assert unquote('hello') == 'hello'
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('"hello" world') == '"hello" world'
    assert unquote('"hello"world') == '"hello"world'
    assert unquote("'hello'") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("'hello' world") == "'hello' world"
    assert unquote("'hello'world") == "'hello'world"



# Generated at 2022-06-23 02:46:42.452472
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted('"test') == False
    assert is_quoted('test"') == False
    assert is_quoted('"test""test"') == False
    assert is_quoted('""test""test"') == False
    assert is_quoted('""test""test""') == True
    assert is_quoted('""test""test""""') == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('"test"test') == False
    assert is_quoted('"test"test""') == False
    assert is_quoted('""test"test"') == False
    assert is_quoted('a"test"') == False

# Generated at 2022-06-23 02:46:51.460439
# Unit test for function unquote
def test_unquote():
    input_output = ( [['blah', 'blah'], ['blah blah']],
                     [['blah "blah"'], ['blah "blah"']],
                     [['"blah" blah'], ['blah blah']],
                     [['blah \'blah\''], ['blah \'blah\'']],
                     [['\'blah\' blah'], ['blah blah']],
                     [['blah "blah \'blah\'"'], ['blah "blah \'blah\'"']]
                   )
    for case in input_output:
        assert unquote(' '.join(case[0])) == ' '.join(case[1])



# Generated at 2022-06-23 02:47:06.691151
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('a') == 'a'
    assert unquote('"a"') == 'a'
    assert unquote('\'a\'') == 'a'
    assert unquote('"\'"') == '\''
    assert unquote('"\\""') == '"'
    assert unquote('"\\"\'"') == '"\''
    assert unquote('\'foo bar\'') == 'foo bar'
    assert unquote('foo bar') == 'foo bar'
    assert unquote('foo \'bar\'') == 'foo \'bar\''
    assert unquote('foo "bar"') == 'foo "bar"'

# Generated at 2022-06-23 02:47:11.879515
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test string"')
    assert is_quoted("'test string'")
    assert not is_quoted('test string"')
    assert not is_quoted("test string'")
    assert not is_quoted('test string')
    assert not is_quoted('')



# Generated at 2022-06-23 02:47:23.242158
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted('"a"')
    assert is_quoted('"a b"')
    assert is_quoted('\'\'')
    assert is_quoted('\'a\'')
    assert is_quoted('\'a b\'')

    assert not is_quoted('""a"')
    assert not is_quoted('"a""')
    assert not is_quoted('"a"b')
    assert not is_quoted('a""')
    assert not is_quoted('""a')

    assert not is_quoted('')
    assert not is_quoted('"')

    assert not is_quoted('\'\'')
    assert not is_quoted('\'a\'')

# Generated at 2022-06-23 02:47:34.915077
# Unit test for function split_args
def test_split_args():
    '''
    These are a series of tests, each with a small description in comments.
    If a test fails, it will print the test number and description and then raise an exception.
    '''

    # test 0: verify that single param is split properly
    params = split_args("foo")
    if len(params) != 1:
        raise Exception("Param length is %d instead of 1" % len(params))
    if params[0] != "foo":
        raise Exception("Param %s does not equal foo" % params[0])

    # test 1: verify that two params are split properly
    params = split_args("foo bar")
    if len(params) != 2:
        raise Exception("Param length is %d instead of 2" % len(params))

# Generated at 2022-06-23 02:47:43.292265
# Unit test for function unquote
def test_unquote():
    # True tests
    assert unquote('"hello"') == "hello"
    assert unquote("'Hello'") == "Hello"
    assert unquote('"Hello world"') == "Hello world"
    assert unquote("'Hello world'") == "Hello world"
    assert unquote('"Hello\tworld"') == "Hello\tworld"
    assert unquote("'Hello\tworld'") == "Hello\tworld"

    # False tests
    assert unquote('hello') == "hello"
    assert unquote('"Hello "') == '"Hello "'
    assert unquote("'Hello") == "'Hello"

# Generated at 2022-06-23 02:47:51.642153
# Unit test for function unquote
def test_unquote():
    ''' unit test for function unquote'''
    test_cases = dict(
        test_quoted_string="""this is a 'quoted string'""",
        test_quoted_string_with_backslash="""this is a 'quoted string with \'some backslash\''""",
        test_multiline_string='''this is a "multiline
            string"""'''
    )
    for test_name, value in test_cases.items():
        result = unquote(value)
        assert not is_quoted(result), "unquote failed for test case: %s, result: %s" % (test_name, result)



# Generated at 2022-06-23 02:48:02.510568
# Unit test for function is_quoted
def test_is_quoted():
    # Test case where argument is empty
    assert False == is_quoted('')
    # Test case where argument is quoted
    assert True == is_quoted('"test_string"')
    assert True == is_quoted('"\\"test_string\\""')
    # Test case where argument is not quoted
    assert False == is_quoted('test_string')
    assert False == is_quoted('"test_string')
    assert False == is_quoted('test_string"')
    # Test case where argument contains backslash characters
    assert False == is_quoted('"\\test_string"')
    assert False == is_quoted('"test_string\\"')
    assert False == is_quoted('"test_string\\test_string"')



# Generated at 2022-06-23 02:48:12.442341
# Unit test for function unquote
def test_unquote():
    ''' unit test for function unquote '''
    cases = (
        ('"abc"', 'abc'),
        ("'a b c'", 'a b c'),
        ('"a', '"a'),
        ('a"', 'a"'),
        ('"a"b"', '"a"b"'),
        ('"a"b"c"', '"a"b"c"'),
        ('abc', 'abc'),
    )
    for data, expected in cases:
        res = unquote(data)
        if res != expected:
            raise AssertionError("unquote(%r) gave %r, expected %r" % (data, res, expected))

if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-23 02:48:17.613875
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'a'b'c'") == "'a'b'c'"


# Generated at 2022-06-23 02:48:33.506781
# Unit test for function is_quoted
def test_is_quoted():
    ''' test unquote() '''
    assert is_quoted('"""') is True
    assert is_quoted('"foo"') is True
    assert is_quoted('"foo') is False
    assert is_quoted('foo"') is False
    assert is_quoted('"foo""') is False
    assert is_quoted('"""foo"""') is True
    assert is_quoted('"""foo\\""') is False
    assert is_quoted('"""foo\\\\""') is True
    assert is_quoted('\'"') is False
    assert is_quoted('"\'"') is False
    assert is_quoted('"\\\'"') is False
    assert is_quoted('"\\"\'"') is False
    assert is_quoted('"\\\\"\'"') is True
    assert is_qu

# Generated at 2022-06-23 02:48:36.713570
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote('test"') == 'test"'
    assert unquote('test') == 'test'



# Generated at 2022-06-23 02:48:44.386482
# Unit test for function split_args
def test_split_args():
    def _test_split_args(args, result):
        if split_args(args) != result:
            print("ERROR: %s != %s\n" % (split_args(args), result))
            raise Exception("split_args(%s) != %s" % (args, result))

    _test_split_args('foo={{ foo }} baz={{ baz }}', ['foo={{ foo }}', 'baz={{ baz }}'])
    _test_split_args('foo="bar baz" fuu="bii bii"', ['foo="bar baz"', 'fuu="bii bii"'])
    _test_split_args('foo="bar baz" fuu="bii bii"', ['foo="bar baz"', 'fuu="bii bii"'])
    _test_

# Generated at 2022-06-23 02:48:55.470937
# Unit test for function split_args
def test_split_args():
    assert split_args('"a b c" d e') == ['a b c', 'd', 'e']
    assert split_args('"a b c\\" d e" f g') == ['a b c" d e', 'f', 'g']
    assert split_args('a=1 b="2 3" c="4 5"') == ['a=1', 'b="2 3"', 'c="4 5"']
    assert split_args('a=1 "b=2 3" c="4 5"') == ['a=1', 'b=2 3', 'c="4 5"']
    assert split_args('a=1 "b=2 3" c="4_5"') == ['a=1', 'b=2 3', 'c="4_5"']

# Generated at 2022-06-23 02:48:57.619710
# Unit test for function unquote
def test_unquote():
    ''' unquote should remove the quotes from a string '''
    assert unquote('"quoted"') == 'quoted'


# Generated at 2022-06-23 02:49:09.644649
# Unit test for function split_args
def test_split_args():

    # test a simple case, a single param
    args = "foo"
    params = split_args(args)
    assert len(params) == 1
    assert params[0] == "foo"

    # test a param with an = symbol
    args = "foo=bar"
    params = split_args(args)
    assert len(params) == 1
    assert params[0] == "foo=bar"

    # test multiple params
    args = "foo=bar baz='bam boom'"
    params = split_args(args)
    assert len(params) == 2
    assert params[0] == "foo=bar"
    assert params[1] == "baz='bam boom'"

    # test params with "=" inside quotes

# Generated at 2022-06-23 02:49:16.312636
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"""')
    assert is_quoted('""')
    assert not is_quoted('""""')
    assert not is_quoted('""abc')
    assert is_quoted('"abc"')
    assert not is_quoted('abc"')
    assert is_quoted("'abc'")
    assert is_quoted('""""')
    assert is_quoted("'\"'")
    assert is_quoted("'\"\"'")
    assert not is_quoted('"abc')


# Generated at 2022-06-23 02:49:18.350660
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'

# Generated at 2022-06-23 02:49:21.814843
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("test") == False)
    assert(is_quoted("\"test\"") == True)
    assert(is_quoted("'test2'") == True)


# Generated at 2022-06-23 02:49:31.735231
# Unit test for function split_args

# Generated at 2022-06-23 02:49:39.820098
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foo') == False
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo') == False
    assert is_quoted("'foo") == False
    assert is_quoted('foo"') == False
    assert is_quoted("foo'") == False
    assert is_quoted('') == False
    assert is_quoted('""') == False
    assert is_quoted("''") == False


# Generated at 2022-06-23 02:49:52.138277
# Unit test for function split_args

# Generated at 2022-06-23 02:49:59.662325
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("foobar") is False
    assert is_quoted("'foobar'") is True
    assert is_quoted("\"foobar\"") is True
    assert is_quoted("\"") is False
    assert is_quoted("'") is False
    assert is_quoted("") is False
    assert is_quoted("''") is False
    assert is_quoted("\"\"") is False


# Generated at 2022-06-23 02:50:03.982403
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("foo") == "foo"

# Generated at 2022-06-23 02:50:16.003114
# Unit test for function is_quoted
def test_is_quoted():
    failed = False
    try:
        if is_quoted('foo'):
            print ("FAIL: Plain unquoted string")
            failed = True
        if is_quoted('"foo'):
            print ("FAIL: Unmatched left quote")
            failed = True
        if is_quoted('foo"'):
            print ("FAIL: Unmatched right quote")
            failed = True
        if is_quoted('"foo"'):
            print ("PASS: Matched quotes")
        else:
            print ("FAIL: Matched quotes")
            failed = True
        if is_quoted("'foo'"):
            print ("PASS: Matched quotes")
        else:
            print ("FAIL: Matched quotes")
            failed = True
    except:
        print ("FAIL: Exception in is_quoted()")
       

# Generated at 2022-06-23 02:50:21.980590
# Unit test for function unquote
def test_unquote():
  assert unquote('"hello"') == 'hello', "unquote('\"hello\"') should be 'hello'"
  assert unquote('"hello') == '"hello', "unquote('\"hello') should be '\"hello'"
  assert unquote('hello"') == 'hello"', "unquote('hello\"') should be 'hello\"'"
  assert unquote('hello') == 'hello', "unquote('hello') should be 'hello'"
  assert unquote('"hello world"') == 'hello world', "unquote('\"hello world\"') should be 'hello world'"


# Generated at 2022-06-23 02:50:29.440624
# Unit test for function unquote

# Generated at 2022-06-23 02:50:32.665407
# Unit test for function unquote
def test_unquote():
    assert unquote('testing') == 'testing'
    assert unquote('"testing"') == 'testing'

# Generated at 2022-06-23 02:50:41.676994
# Unit test for function split_args

# Generated at 2022-06-23 02:50:50.136494
# Unit test for function split_args

# Generated at 2022-06-23 02:50:57.036373
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'a'")
    assert is_quoted("'a") == False
    assert is_quoted("'a\'") == False
    assert is_quoted("\"a\"")
    assert is_quoted("\"a") == False
    assert is_quoted("\"a\\\"") == False


# Generated at 2022-06-23 02:51:03.861033
# Unit test for function is_quoted
def test_is_quoted():
    # Testing of positive cases
    assert(is_quoted("'test'") == True)
    assert(is_quoted('"test"') == True)
    # Testing of negative cases
    assert(is_quoted("test") == False)
    assert(is_quoted('test"') == False)
    assert(is_quoted("'test") == False)
    assert(is_quoted('"test') == False)


# Generated at 2022-06-23 02:51:10.379053
# Unit test for function unquote
def test_unquote():
    assert unquote("\"hello\"") == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote("hello") == "hello"
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("''hello'") == "''hello'"
    assert unquote("'he'llo'") == "'he'llo'"
    assert unquote("'he\"llo'") == "'he\"llo'"


# Generated at 2022-06-23 02:51:17.721343
# Unit test for function split_args
def test_split_args():
    # Note: This unit test is a placeholder for a full unit test for function split_args.
    #       The first test case has been implemented as an example.
    #       Please add additional test cases as necessary.
    #
    # Test Set #1: named arguments and comma-delimited items in a string
    #
    # This test set validates the following:
    #
    # 1) named arguments are not split on quotes
    # 2) named arguments with spaces can be quoted
    # 3) comma-delimited items in a string are not split on quotes
    # 4) comma-delimited items can contain spaces if quoted

    # Test case #1: named arguments are not split on quotes
    test_case_description = "Named arguments are not split on quotes"

# Generated at 2022-06-23 02:51:28.149379
# Unit test for function split_args
def test_split_args():
    assert split_args("") is not None
    assert split_args("a b c") == ["a", "b", "c"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=\"b c\" d=\"e f\"") == ["a=\"b c\"", "d=\"e f\""]
    assert split_args("a=b c=d e={{ foo }}") == ["a=b", "c=d", "e={{ foo }}"]
    assert split_args("a=b c=\"d e\" f={{ g h }}") == ["a=b", "c=\"d e\"", "f={{ g h }}"]

# Generated at 2022-06-23 02:51:35.466034
# Unit test for function unquote
def test_unquote():
    ''' run some test for function unquote '''
    assert unquote('"example"') == "example"
    assert unquote(u'"example"') == u"example"
    assert unquote("'example'") == "example"
    assert unquote(u"'example'") == u"example"



# Generated at 2022-06-23 02:51:48.173423
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args(' "  " ') == ['""']
    assert split_args('"  " ') == ['""']
    assert split_args(' " " ') == ['" "']
    assert split_args('" " ') == ['" "']
    assert split_args(' " " ') == ['" "']
    assert split_args('" " ') == ['" "']
    assert split_args(' a "b" ') == ['a', '"b"']
    assert split_args('"a" b ') == ['"a"', 'b']
    assert split_args('"a" "b" ') == ['"a"', '"b"']

# Generated at 2022-06-23 02:51:53.899244
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('') == False)
    assert(is_quoted('"""') == False)
    assert(is_quoted('A') == False)
    assert(is_quoted('"A"') == True)
    assert(is_quoted('\'A\'') == True)


# Generated at 2022-06-23 02:51:58.557329
# Unit test for function is_quoted
def test_is_quoted():
    print("test_is_quoted")
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted("'abc'") == True
    assert is_quoted("\"abc\"") == True
    print("test_is_quoted OK")



# Generated at 2022-06-23 02:52:03.559851
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"quoted\"")
    assert is_quoted("\'quoted\'")
    assert not is_quoted("\"quoted")
    assert not is_quoted("\'quoted")
    assert not is_quoted("\"")
    assert is_quoted("") == False



# Generated at 2022-06-23 02:52:12.028272
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"hello"'))
    assert(is_quoted('"world"'))
    assert(not is_quoted('hello"'))
    assert(not is_quoted('world"'))
    assert(not is_quoted('"hello'))
    assert(not is_quoted('"world'))
    assert(not is_quoted('"hello'))
    assert(not is_quoted('"world'))
    assert(not is_quoted('hello'))
    assert(not is_quoted('world'))


# Generated at 2022-06-23 02:52:23.490213
# Unit test for function split_args
def test_split_args():

    assert split_args('foo="bar baz"') == ['foo="bar baz"']
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('  foo  bar  ') == ['foo', 'bar']
    assert split_args('foo="bar baz" fie=fum') == ['foo="bar baz"', 'fie=fum']
    assert split_args('foo="bar baz" \\\n fie=fum') == ['foo="bar baz"', 'fie=fum']
    assert split_args('foo="bar \\\nbaz" \\\n fie=fum') == ['foo="bar \\\nbaz"', 'fie=fum']

# Generated at 2022-06-23 02:52:33.927809
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('""foo bar"') == '"foo bar'
    assert unquote('foo bar""') == 'foo bar"'
    assert unquote('"foo bar""') == 'foo bar"'
    assert unquote('foo bar"') == 'foo bar'
    assert unquote('"foo bar') == 'foo bar'
    assert unquote('foo bar') == 'foo bar'
    assert unquote('''"foo bar" bar''') == '"foo bar" bar'
    assert unquote('''"foo bar" bar''') == '"foo bar" bar'
    assert unquote('"""foo bar"""') == '"foo bar"'
    assert unquote('"""foo "bar" """') == '"foo "bar" "'

# Generated at 2022-06-23 02:52:43.913813
# Unit test for function split_args
def test_split_args():
    ''' test the split_args function '''


# Generated at 2022-06-23 02:52:47.409706
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('foo') == 'foo'



# Generated at 2022-06-23 02:52:55.817573
# Unit test for function split_args
def test_split_args():
    assert split_args("echo 'hello world'") == ["echo", "'hello world'"]
    assert split_args("echo \"hello world\"") == ["echo", '"hello world"']
    assert split_args("echo 'hello world") == ["echo", "'hello world"]
    assert split_args("echo 'hello world\\'") == ["echo", "'hello world\\'"]
    assert split_args("echo 'hello world\\''") == ["echo", "'hello world\\''"]
    assert split_args("echo 'hello world'\\'''") == ["echo", "'hello world'\\'''"]
    assert split_args('echo "hello world\\"') == ["echo", '"hello world\\"']
    assert split_args('echo "hello world\\""') == ["echo", '"hello world\\""']

# Generated at 2022-06-23 02:52:59.780710
# Unit test for function unquote
def test_unquote():
    ''' unquote(): Basic functionality '''
    result = unquote('"""This is a test."""')
    assert result == '"This is a test."'


# Generated at 2022-06-23 02:53:02.950919
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('hello"') == 'hello"'



# Generated at 2022-06-23 02:53:08.537886
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("blah") == False
    assert is_quoted("'blah'") == True
    assert is_quoted('"blah"') == True
    assert is_quoted("'") == False


# Generated at 2022-06-23 02:53:14.104776
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("abc") == False
    assert is_quoted("'abc'") == True
    assert is_quoted("\"abc\"") == True
    assert is_quoted("'ab'c'") == False
    assert is_quoted("'abc") == False
    assert is_quoted("abc'") == False


# Generated at 2022-06-23 02:53:21.115722
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted("\"") == False
    assert is_quoted("''") == False
    assert is_quoted("'''") == False
    assert is_quoted("''''") == False
    assert is_quoted("\"\"") == False
    assert is_quoted("\"''\"") == False
    assert is_quoted("\"'''\"") == False
    assert is_quoted("\"''\"''") == False
    assert is_quoted("\"'''\"'''") == False

    assert is_quoted("'y") == False
    assert is_quoted("y'") == False

    assert is_quoted("''y''") == False
    assert is_quoted("''y") == False


# Generated at 2022-06-23 02:53:32.587630
# Unit test for function unquote
def test_unquote():
    assert 'a b " c' == unquote('"a b " c"')
    assert 'a b " c' == unquote("'a b ' c'")
    assert 'foo' == unquote('"foo"')
    assert 'foo' == unquote("'foo'")
    assert '"foo' == unquote('"foo')
    assert '"foo' == unquote("'foo")
    assert "foo'" == unquote('foo"')
    assert "foo'" == unquote("foo'")
    assert 'foo' == unquote('foo')
    assert '"foo' == unquote('"foo')
    assert "foo'" == unquote("foo'")
    assert 'a b " c' == unquote('"a b " c"')

# Generated at 2022-06-23 02:53:36.840034
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'bar'") == True
    assert is_quoted("'foo')") == False
    assert is_quoted('"bar') == False
    assert is_quoted('foo') == False


# Generated at 2022-06-23 02:53:45.760795
# Unit test for function split_args
def test_split_args():
    # Test that simple cases work
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    assert split_args("foo      bar baz") == ["foo", "bar", "baz"]
    # Test that multiple spaces in a row aren't split across tokens
    assert split_args("foo      bar baz") == ["foo", "bar", "baz"]
    # Test that spaces inside quotes aren't split across tokens
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]
    assert split_args("foo 'bar baz foo'") == ["foo", "'bar baz foo'"]
    # Test that multiple quotes in a row outside a jinja2 block don't cause an error
    assert split_args('foo " bar ') == ["foo", '" bar']


# Generated at 2022-06-23 02:53:49.829103
# Unit test for function unquote
def test_unquote():
    assert unquote('"bob"') == 'bob'
    assert unquote("'bob'") == 'bob'
    assert unquote('bob') == 'bob'
    assert unquote('dog') == 'dog'


# Generated at 2022-06-23 02:53:55.140182
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('"word"') == 'word'
    assert unquote('\'"\'') == '\'"\''
    assert unquote("'word'") == 'word'
    assert unquote("word") == 'word'


# Generated at 2022-06-23 02:54:05.031300
# Unit test for function split_args

# Generated at 2022-06-23 02:54:15.288643
# Unit test for function split_args
def test_split_args():
    import nose.tools as nt
    assert split_args("a='b c'") == ["a='b c'"]
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a={{ b }}") == ['a={{ b }}']
    assert split_args("a={{ b }}{% if 1%}") == ['a={{ b }}{% if 1%}']
    assert split_args("a={{ b }} {% if 1%}") == ['a={{ b }}', '{% if 1%}']
    assert split_args("a={{ 'b' }} {% if 1%}") == ['a={{ \'b\' }}', '{% if 1%}']

# Generated at 2022-06-23 02:54:25.745938
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted('"abc') == False
    assert is_quoted('abc"') == False
    assert is_quoted('"abc\'') == False
    assert is_quoted('\'"abc"\'') == False
    assert is_quoted('\'"abc\'"') == True
    assert is_quoted('"') == False
    assert is_quoted('"\\""') == True
    assert is_quoted('"a"\\""') == False
    assert is_quoted("'abc'") == True
    assert is_quoted("'abc") == False
    assert is_quoted("abc'") == False
    assert is_quoted("'abc\"") == False
    assert is_quoted("'''abc'") == False


# Generated at 2022-06-23 02:54:33.737879
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("foo") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote("foo'") == "foo'"
    assert unquote("foo\"") == "foo\""
    assert unquote("'foo") != 'foo'
    assert unquote('"foo') != 'foo'
    assert unquote('"foo"') != "'foo'"
    assert unquote('foo"') != "foo'"
    assert unquote('foo') != "'foo'"
    assert unquote("'foo'") != 'foo'
    assert unquote('"foo"') != 'foo'
    assert unquote('foo"') != "foo'"

# Generated at 2022-06-23 02:54:46.205536
# Unit test for function split_args
def test_split_args():
    ''' Unit test for function split_args '''

    # Test 1 - Test with simple args
    args = 'a=b c="foo bar"'
    params = split_args(args)
    assert params == ['a=b', 'c="foo bar"']

    # Test 2 - Test with args with jinja2 tags
    args = '{{a}} = {{b}} c="foo bar"'
    params = split_args(args)
    assert params == ['{{a}} = {{b}}', 'c="foo bar"']

    # Test 3 - Test with args with quotes inside jinja2 tags
    args = '{{\'a\'}} = {{\'b\'}} c="foo bar"'
    params = split_args(args)
    assert params == ['{{\'a\'}} = {{\'b\'}}', 'c="foo bar"']



# Generated at 2022-06-23 02:54:55.615723
# Unit test for function split_args

# Generated at 2022-06-23 02:55:03.847804
# Unit test for function split_args
def test_split_args():

    def _split(args):
        return split_args(args)

    # test each of the jinja2 blocks, with both one-line blocks and multi-line blocks
    assert _split("a=b c=\"foo bar\" {{ foo }}") == ['a=b', 'c="foo bar"', '{{', 'foo', '}}']
    assert _split("a=b c=\"foo bar\" {{ foo }} {{ bar }}") == ['a=b', 'c="foo bar"', '{{', 'foo', '}}', '{{', 'bar', '}}']
    assert _split("a=b c=\"foo bar\" {{ foo\n bar }}") == ['a=b', 'c="foo bar"', '{{', 'foo\n bar', '}}']