

# Generated at 2022-06-23 02:45:11.414427
# Unit test for function split_args
def test_split_args():
    import sys
    commandline = "this 'is' a \"command line with no variables\""
    result = [u'this', u'is', u'a', u'command line with no variables']

    print("Sys version: {0}\n".format(sys.version))
    print("Test simple unquoted command line with no variables: {0}".format(commandline))
    split_result = split_args(commandline)
    if split_result == result:
        print("PASS\n")
    else:
        print("FAIL\n")
        print("Expected result: {0}".format(result))
        print("Actual result: {0}".format(split_result))

    commandline = "this 'is' a \"command line with no variables\"\n"

# Generated at 2022-06-23 02:45:24.709070
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('a"b"c')
    assert is_quoted('"a"')
    assert is_quoted('"a') == False
    assert is_quoted('a"') == False
    assert is_quoted('a"bc') == False
    assert is_quoted('a"bc"')
    assert is_quoted('"bc"')
    assert is_quoted('\'bc\'')
    assert is_quoted('\'b\\\'c\'')
    assert is_quoted('a"b\\"c"')
    assert is_quoted('"a\\"b\\"c"')
    assert is_quoted('"a\\"b\\"c') == False
    assert is_quoted('"a"b"c') == False

# Generated at 2022-06-23 02:45:28.900132
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-23 02:45:38.917513
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert not is_quoted('"foobar')
    assert not is_quoted('foobar"')
    assert not is_quoted('"foobar\'')
    assert not is_quoted('')
    assert not is_quoted(' ')
    assert is_quoted('  """foobar"""  ')
    assert is_quoted("'foobar'")
    assert is_quoted("'foobar")
    assert not is_quoted("foobar'")
    assert not is_quoted("'foobar\"")
    assert not is_quoted("\"'foobar")


# Generated at 2022-06-23 02:45:42.425760
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('foo') == "foo"
    assert unquote('"foo') != "foo"



# Generated at 2022-06-23 02:45:51.342827
# Unit test for function split_args
def test_split_args():
    assert(split_args('') == [])
    assert(split_args('  ') == [])
    assert(split_args('one') == ['one'])
    assert(split_args('one   two') == ['one', 'two'])
    assert(split_args('one "two three"') == ['one', '"two three"'])
    assert(split_args('one "two \\" three"') == ['one', '"two \\" three"'])
    assert(split_args('one "two three') == ['one', '"two three'])
    assert(split_args('one two\' three') == ['one', 'two\' three'])
    assert(split_args('one') == ['one'])
    assert(split_args('one two three') == ['one', 'two', 'three'])
   

# Generated at 2022-06-23 02:46:02.202266
# Unit test for function split_args

# Generated at 2022-06-23 02:46:06.394044
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"')
    assert is_quoted("'abcd'")
    assert not is_quoted('"abcd\'')
    assert not is_quoted('abcd"')
    assert not is_quoted('abc"d')
    assert not is_quoted('abcd')



# Generated at 2022-06-23 02:46:10.913488
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo\'"') == False
    assert is_quoted('""')
    assert is_quoted('"') == False


# Generated at 2022-06-23 02:46:23.640648
# Unit test for function unquote
def test_unquote():
    if unquote('') != '':
        raise Exception('unquote failed for "test"')
    if unquote('a') != 'a':
        raise Exception('unquote failed for "a"')
    if unquote('"a"') != 'a':
        raise Exception('unquote failed for "\'a\'"')
    if unquote('"a') == '"a':
        raise Exception('unquote failed for "\'a"')
    if unquote('a"') == 'a"':
        raise Exception('unquote failed for "a\'"')
    if unquote('"a\'"') == '"a\'"':
        raise Exception('unquote failed for "\'a\'"')

# Generated at 2022-06-23 02:46:28.999617
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('""') is False
    assert is_quoted('"') is False
    assert is_quoted('foo') is False
    assert is_quoted('"foo') is False
    assert is_quoted('foo"') is False
    assert is_quoted('"foo"') is True
    assert is_quoted('\'foo\'') is True


# Generated at 2022-06-23 02:46:38.754646
# Unit test for function unquote
def test_unquote():
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote('foobar"') == 'foobar"'
    assert unquote("foobar'") == "foobar'"
    assert unquote('"foobar') == '"foobar'
    assert unquote("'foobar") == "'foobar"
    assert unquote('"foo bar') == '"foo bar'
    assert unquote("'foo bar") == "'foo bar"
    assert unquote('foobar') == 'foobar'
    assert unquote('foo bar') == 'foo bar'

# Generated at 2022-06-23 02:46:42.078286
# Unit test for function unquote
def test_unquote():
    ''' check if unquote properly removes curly braces, and does not touch if it is not quoted '''
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'

# Unit tests for function split_args

# Generated at 2022-06-23 02:46:47.472041
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote("foo'") == "foo'"
    assert unquote('foo"') == 'foo"'

# Generated at 2022-06-23 02:46:49.361956
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'



# Generated at 2022-06-23 02:46:56.936206
# Unit test for function unquote
def test_unquote():
    if unquote('"test"') != 'test':
        raise Exception ("test failure on unquote")
    if unquote('"test') == 'test':
        raise Exception ("test failure on unquote")
    if unquote('test"') == 'test':
        raise Exception ("test failure on unquote")
    if unquote('"test""test"') == 'test"test':
        raise Exception ("test failure on unquote")
    if unquote('test') != 'test':
        raise Exception ("test failure on unquote")



# Generated at 2022-06-23 02:47:01.966894
# Unit test for function unquote
def test_unquote():
    assert unquote('"This is a test"') == "This is a test"
    assert unquote("'This is a test'") == "This is a test"
    assert unquote("This is a test") == "This is a test"
    assert unquote("'This is a test") == "'This is a test"
    assert unquote("This is a test'") == "This is a test'"


# Generated at 2022-06-23 02:47:13.992688
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"stuff"') is True
    assert is_quoted("'stuff'") is True
    assert is_quoted('"stuff') is False
    assert is_quoted("'stuff") is False
    assert is_quoted('stuff"') is False
    assert is_quoted("stuff'") is False
    assert is_quoted('"stuff" more stuff') is False
    assert is_quoted('"stuff" more "stuff"') is False
    assert is_quoted('"stuff') is False
    assert is_quoted('stuff\\"') is False
    assert is_quoted('stuff\\" more stuff') is False
    assert is_quoted('"stuff') is False
    assert is_quoted('stuff\\" more "stuff') is False
    assert is_quoted('stuff"') is False

# Generated at 2022-06-23 02:47:20.275019
# Unit test for function split_args
def test_split_args():
    c = split_args("a=b c='foo bar' d={{ baz }} e={{ foo }}")
    assert(c == ['a=b', "c='foo bar'", 'd={{ baz }}', 'e={{ foo }}'])
    d = split_args("a=b c='foo bar\nbaz' d={{ baz }} e={{ foo }} f={{ foo }}")
    assert(d == ['a=b', "c='foo bar\nbaz'", 'd={{ baz }}', 'e={{ foo }}', 'f={{ foo }}'])

# Generated at 2022-06-23 02:47:31.581679
# Unit test for function split_args

# Generated at 2022-06-23 02:47:34.751981
# Unit test for function unquote
def test_unquote():
    return unquote('"foobar"') == 'foobar' and unquote("'foobar'") == 'foobar' and unquote('foobar') == 'foobar'


# Generated at 2022-06-23 02:47:45.708410
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")

    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello"')
    assert not is_quoted('hello\'')
    assert not is_quoted('hello')

    assert is_quoted('"hello ""world""')
    assert is_quoted("'hello ''world''")

    assert not is_quoted('"hello ""world"""')
    assert not is_quoted("'hello ''world'''")
    assert not is_quoted('"hello ""world"\'')

    assert is_quoted("'hello world' 'world hello'")


# Generated at 2022-06-23 02:47:50.891685
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("test")) == False
    assert(is_quoted("'test'")) == True
    assert(is_quoted('"test"')) == True


# Generated at 2022-06-23 02:47:54.804429
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('""') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False


# Generated at 2022-06-23 02:48:06.585650
# Unit test for function split_args
def test_split_args():
    data = """
    # test1
    command1 arg1=val1 arg2=val2 arg3='val 3'

    # test2
    command2 arg1="val1" arg2="val2" arg3="foo bar"

    # test3
    command3 arg1="foo bar"
    """
    data = split_args(data)
    assert data == [
        '# test1\ncommand1', 'arg1=val1', 'arg2=val2', "arg3='val 3'\n\n",
        '# test2\ncommand2', 'arg1="val1"', 'arg2="val2"', 'arg3="foo bar"\n\n',
        '# test3\ncommand3', 'arg1="foo bar"'
    ]

# Generated at 2022-06-23 02:48:12.141122
# Unit test for function unquote
def test_unquote():
    assert unquote("\"Hello World\"") == "Hello World"
    assert unquote("'Hello World'") == "Hello World"
    assert unquote('"Hello World') == '"Hello World'
    assert unquote("'Hello World") == "'Hello World"

if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(args=[__file__]))

# Generated at 2022-06-23 02:48:15.641698
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('sgd') == False
    assert is_quoted('"sgd"') == True
    assert is_quoted('"sgd') == False
    assert is_quoted('sgd"') == False
    assert is_quoted("'sgd'") == True
    assert is_quoted('"sgd""') == False
    assert is_quoted('""sgd') == False


# Generated at 2022-06-23 02:48:22.405981
# Unit test for function split_args

# Generated at 2022-06-23 02:48:27.488212
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"fo""o"') == 'fo"o'
    assert unquote("'fo''o'") == 'fo\'o'


# Generated at 2022-06-23 02:48:29.614567
# Unit test for function unquote
def test_unquote():
    data = '"foo"'
    assert unquote(data) == 'foo'


# Generated at 2022-06-23 02:48:39.524244
# Unit test for function is_quoted
def test_is_quoted():
    from ansible.module_utils.basic import AnsibleModule

    def test_value(value, expected):
        # Get the module arguments from a dict
        module_args = dict(
            value=value,
        )

        # Create a module for ourselves
        module = AnsibleModule(
            argument_spec=module_args,
        )

        # Compare the value
        module.exit_json(changed=False, value=value, expected=expected, actual=is_quoted(value))

    # Test the values
    test_value('', False)
    test_value('a', False)
    test_value('a b', False)
    test_value('"a"', True)
    test_value('"a b"', True)
    test_value('a "b" c', False)

# Generated at 2022-06-23 02:48:50.448588
# Unit test for function split_args

# Generated at 2022-06-23 02:49:00.943743
# Unit test for function split_args
def test_split_args():
    '''
    Tests the split_args function
    '''


# Generated at 2022-06-23 02:49:04.195673
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('') == False)
    assert(is_quoted("'abc'") == True)
    assert(is_quoted("'a''c'") == True)
    assert(is_quoted("'a''c") == False)
    assert(is_quoted("''c'") == False)
    assert(is_quoted("\"unquoted\"") == True)
    assert(is_quoted("\"unquoted") == False)
    assert(is_quoted("unquoted\"") == False)


# Generated at 2022-06-23 02:49:08.650305
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == 'hello'
    assert unquote("\"hello\"") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote("\"hello") == "\"hello"
    assert unquote("hello'") == "hello'"
    assert unquote("hello\"") == "hello\""



# Generated at 2022-06-23 02:49:17.250799
# Unit test for function split_args
def test_split_args():
    '''
    tests for split_args function
    '''

    # these are test args, the output of each is in the next list

# Generated at 2022-06-23 02:49:28.219606
# Unit test for function split_args
def test_split_args():
    args = "rm -rvf {{ test_dir }}"
    params = split_args(args)
    assert len(params) == 1
    assert params[0] == "rm -rvf {{ test_dir }}"

    args = "\"rm -rvf {{ test_dir }}\""
    params = split_args(args)
    assert len(params) == 1
    assert params[0] == "\"rm -rvf {{ test_dir }}\""

    args = "\"rm -rvf {{ test_dir }}\" \"foo bar\""
    params = split_args(args)
    assert len(params) == 3
    assert params[0] == "\"rm"
    assert params[1] == "-rvf"
    assert params[2] == "{{ test_dir }}\" \"foo bar\""

# Generated at 2022-06-23 02:49:36.064861
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert not is_quoted('hello"')
    assert not is_quoted('"hello')
    assert not is_quoted('"hello\'')
    assert not is_quoted('\'hello\'')
    assert not is_quoted('"hello"foo')
    assert is_quoted('"hello" ')
    assert is_quoted(' "hello"')
    assert not is_quoted('\\"hello\\" ')
    assert not is_quoted(' "hello"\\ ')
    assert is_quoted('"hello"\\ ')
    assert not is_quoted(' "hello"\\')
    assert is_quoted('""')
    assert not is_quoted('')
    assert is_quoted('"')
    assert is_quoted

# Generated at 2022-06-23 02:49:42.103537
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'") == True
    assert is_quoted("\"test\"") == True
    assert is_quoted("\"test") == False
    assert is_quoted("test\"") == False
    assert is_quoted("'test") == False
    assert is_quoted("test'") == False


# Generated at 2022-06-23 02:49:48.816953
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('"') is False
    assert is_quoted('""') is False
    assert is_quoted('foo') is False
    assert is_quoted('"foo"') is True
    assert is_quoted('"foo') is False
    assert is_quoted('foo"') is False



# Generated at 2022-06-23 02:49:54.987864
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted("'a'bc'")
    assert not is_quoted("'abc")
    assert not is_quoted("abc'")
    assert not is_quoted("'")
    assert is_quoted("''")


# Generated at 2022-06-23 02:50:07.176017
# Unit test for function split_args
def test_split_args():

    import os.path
    import sys

    # define the test cases, where each tuple is of the form (input string, expected list, error msg)

# Generated at 2022-06-23 02:50:18.139590
# Unit test for function split_args
def test_split_args():
    import sys


# Generated at 2022-06-23 02:50:28.123021
# Unit test for function is_quoted
def test_is_quoted():
    r = is_quoted('"foo"')
    assert r == True
    r = is_quoted('foo"')
    assert r == False
    r = is_quoted('"foo')
    assert r == False
    r = is_quoted('foo')
    assert r == False
    r = is_quoted("'foo'")
    assert r == True
    r = is_quoted("'foo")
    assert r == False
    r = is_quoted("foo'")
    assert r == False
    r = is_quoted('foo')
    assert r == False
    r = is_quoted('""')
    assert r == True
    r = is_quoted('"')
    assert r == False



# Generated at 2022-06-23 02:50:34.549917
# Unit test for function is_quoted
def test_is_quoted():
    for data in (
        '', 'abc', 'abc"', '"abc', 'abc"def', '"abc"', '"abc"def"',
        "', '"):
        expected = data.startswith('"') and data.endswith('"')
        actual = is_quoted(data)
        assert expected == actual, "'%s' should%s be quoted" % (data, '' if expected else "n't")


# Generated at 2022-06-23 02:50:38.377372
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("")
    assert not is_quoted("foo")
    assert is_quoted("'foo'")
    assert is_quoted("'bar'")
    assert is_quoted("\"bar\"")


# Generated at 2022-06-23 02:50:45.344066
# Unit test for function is_quoted
def test_is_quoted():
    test_result = []
    test_result.append(is_quoted('"hello world"'))
    test_result.append(is_quoted("'hello world'"))
    test_result.append(is_quoted('"hello world'))
    test_result.append(is_quoted("'hello world"))
    test_result.append(is_quoted("hello world"))

    if test_result != [True, True, False, False, False]:
        raise Exception("is_quoted not working")


# Generated at 2022-06-23 02:50:56.254175
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('"")') == '")'
    assert unquote('"\\"') == '"\\'
    assert unquote('"a\\"b"') == 'a"b'
    assert unquote('"\\"a\\"b\\""') == '\\"a"b\\"'
    assert unquote('"\\""') == '\\"'
    assert unquote('"\\\\"') == '\\\\'
    assert unquote('"\\" \\ "') == '" \\ '
    assert unquote('"\\"\\"') == '\\"'

# Generated at 2022-06-23 02:51:07.700792
# Unit test for function split_args

# Generated at 2022-06-23 02:51:13.683391
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\'') == '"foo\''
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('foo') == 'foo'
    assert unquote('f"oo') == 'f"oo'
    assert unquote('"foo"') != '"foo' or 'foo"'
    assert unquote('"foo"') != 'foo'
    assert unquote('') == ''


# Generated at 2022-06-23 02:51:24.237589
# Unit test for function unquote
def test_unquote():
    assert 'bar' == unquote('"bar"')
    assert "bar" == unquote("'bar'")
    assert "bar" == unquote("'bar")
    assert "bar" == unquote("bar'")
    assert "bar" == unquote("bar")
    assert "bar" == unquote("'bar' ")
    assert "bar" == unquote(" 'bar'")
    assert "b'a'r" == unquote("'b'a'r'")
    assert "b'a'r" == unquote("\"b'a'r\"")

if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-23 02:51:34.801792
# Unit test for function split_args
def test_split_args():
    # These all should work and not change what is expected
    assert split_args('foo bar=baz') == ['foo', 'bar=baz']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foobar"') == ['a=b', 'c="foobar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\"') == ['a=b', 'c="foo bar\\"']
    assert split_args('a=b c="foo bar"\\') == ['a=b', 'c="foo bar"\\']
    assert split_args('a=b c="foo bar\\""')

# Generated at 2022-06-23 02:51:38.273163
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('foo')



# Generated at 2022-06-23 02:51:49.558527
# Unit test for function is_quoted

# Generated at 2022-06-23 02:52:00.360283
# Unit test for function is_quoted

# Generated at 2022-06-23 02:52:10.381595
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"abc"') == True)
    assert(is_quoted("'abc'") == True)
    assert(is_quoted("'ab'c'") == False)
    assert(is_quoted("''abc'") == False)
    assert(is_quoted("'abc''") == False)
    assert(is_quoted("abc") == False)
    assert(is_quoted("'abc") == False)
    assert(is_quoted("abc'") == False)
    assert(is_quoted("'abc''xyz'") == False)



# Generated at 2022-06-23 02:52:15.839857
# Unit test for function unquote
def test_unquote():
    assert "string" == unquote("'string'")
    assert "string" == unquote('"string"')
    assert "string" == unquote("string")
    assert "" == unquote("''")
    assert "" == unquote('""')
    assert "'string'" == unquote("'string'", True)



# Generated at 2022-06-23 02:52:21.373835
# Unit test for function split_args
def test_split_args():

    def assert_splits(args, expected):
        """
        assert that the result of parsing args matches the expected value.
        """
        assert split_args(args) == expected

    # basic examples
    assert_splits('a=b c="foo bar" d=\'foo bar\'', ['a=b', 'c="foo bar"', "d='foo bar'"])
    assert_splits('a=b c="foo\\ bar" d=\'foo\\ bar\'', ['a=b', 'c="foo bar"', "d='foo bar'"])

    # whitespace is collapsed
    assert_splits('  a  = b  c  =  "foo  bar"  ', ['a=b', 'c="foo  bar"', ])

    # newlines are preserved

# Generated at 2022-06-23 02:52:32.802518
# Unit test for function split_args
def test_split_args():
    import sys
    import shutil
    import tempfile
    import subprocess

    # First we need to create a temporary directory to work in.
    args_dir = tempfile.mkdtemp(dir='/tmp')

    # Next we need to create a temporary file to work with.  We have to
    # use the mkstemp() function, since we need to keep the file open
    # while we write to it.
    fd, args_path = tempfile.mkstemp(dir=args_dir)
    args_file = os.fdopen(fd, 'w')

    # Now we create some test strings.
    quotes = ['"', "'"]
    quotes_str = {'"': 'double-quoted', "'": 'single-quoted'}

# Generated at 2022-06-23 02:52:34.434376
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == 'abcd'
    assert unquote("'abcd'") == 'abcd'
    assert unquote('abc') == 'abc'


# Generated at 2022-06-23 02:52:36.258019
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"fo"o"')
    assert not is_quoted("'fo'o'")

# Generated at 2022-06-23 02:52:42.958593
# Unit test for function unquote
def test_unquote():
        assert unquote('"test"') == 'test'
        assert unquote('"test') == '"test'
        assert unquote('test"') == 'test"'
        assert unquote('"test\'"') == 'test\''
        assert unquote('A"B"C"') == 'A"B"C"'
        assert unquote('" "') == ' '

# Generated at 2022-06-23 02:52:49.578120
# Unit test for function unquote
def test_unquote():
    # Simple test
    assert unquote('foo') == 'foo'

    # List of quotes
    assert unquote(['foo']) == ['foo']

    # Single quote
    assert unquote("'foo'") == 'foo'

    # Double quote
    assert unquote('"foo"') == 'foo'

    # Single quote inside double quotes
    assert unquote('"\'foo\'"') == '"foo"'

    # Double quote inside single quotes
    assert unquote("'\"foo\"'") == '"foo"'


# Generated at 2022-06-23 02:52:53.176987
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('"a"b"c') == 'a"b"c'
    assert unquote('"a"') == 'a'



# Generated at 2022-06-23 02:53:03.530550
# Unit test for function split_args
def test_split_args():
    import json
    import sys

    if sys.version_info[0] == 2:
        def to_text(s):
            if isinstance(s, unicode):
                return s
            else:
                return unicode(s, 'utf-8')
    else:
        def to_text(s):
            return s

    # data copied from DocFragments

# Generated at 2022-06-23 02:53:08.115193
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('') == ''



# Generated at 2022-06-23 02:53:10.262018
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'

# Generated at 2022-06-23 02:53:19.591960
# Unit test for function split_args
def test_split_args():

    '''
    This is a fairly comprehensive unit test for the
    split_args function. It does the following:

    * makes sure that basic args are split
    * makes sure that quoted args are split and reassembled
    * makes sure that args with newlines are handled properly
    * makes sure args with newlines and spaces are handled properly
    * makes sure that jinja2 blocks are handled properly
    * makes sure that jinja2 blocks inside of quotes are handled properly
    * makes sure that jinja2 blocks inside of jinja2 blocks are handled properly
    * makes sure that line continuation is handled properly
    * makes sure that line continuation within jinja2 blocks and quotes is handled properly
    '''

    # simple args
    args = 'foo=bar baz=blam'
    params = split_args(args)

# Generated at 2022-06-23 02:53:25.993228
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('"foo\'') == '"foo\''
    assert unquote('\'foo"') == '\'foo"'
    assert unquote('foo') == 'foo'
    assert unquote('  "foo"  ') == '  "foo"  '
    assert unquote('') == ''


# Generated at 2022-06-23 02:53:37.680935
# Unit test for function split_args
def test_split_args():
    assert split_args('') == [], "empty string should return empty list"
    assert split_args('\n') == [], "newline should return empty list"
    assert split_args(' \t \n') == [], "whitespace should return empty list"
    assert split_args('foo="bar baz"') == ['foo="bar baz"'], "should not split quoted strings"
    assert split_args('foo="bar baz" spam=eggs') == ['foo="bar baz"', 'spam=eggs'], "should split whitespace"
    assert split_args('{{ foo }}') == ['{{ foo }}'], "should not split inside jinja template tags"

# Generated at 2022-06-23 02:53:43.173654
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("abc") == False
    assert is_quoted("'abc'") == True
    assert is_quoted('"abc"') == True
    assert is_quoted("''") == True
    assert is_quoted('""') == True
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted("'foo'bar'") == False
    assert is_quoted('"foo"bar"') == False


# Generated at 2022-06-23 02:53:54.873814
# Unit test for function split_args
def test_split_args():
    ''' simple unit tests for split_args '''
    import datetime
    import random
    import six

    # These are tests for split_args

# Generated at 2022-06-23 02:53:59.820014
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted("foo'")
    assert not is_quoted('"foo\'')


# Generated at 2022-06-23 02:54:01.229339
# Unit test for function is_quoted
def test_is_quoted():
    data = '"quoted"'
    assert is_quoted(data)



# Generated at 2022-06-23 02:54:02.714648
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'

# Generated at 2022-06-23 02:54:13.506318
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"abc"') == True)
    assert(is_quoted("'abc'") == True)
    assert(is_quoted('"ab\'c"') == True)
    assert(is_quoted("'ab\"c'") == True)
    assert(is_quoted('"\'"') == True)
    # Encoding characters
    assert(is_quoted('"\xe2\x98\x83"') == True)
    assert(is_quoted("'\xe2\x98\x83'") == True)
    assert(is_quoted("'abc") == False)
    assert(is_quoted("abc'") == False)
    assert(is_quoted("\"abc") == False)
    assert(is_quoted("abc\"") == False)
   

# Generated at 2022-06-23 02:54:16.628383
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("abc") == 'abc'

# Generated at 2022-06-23 02:54:25.052015
# Unit test for function split_args
def test_split_args():
    '''
    Assertions for the split_args function

    These cover various cases, both in terms of whitespace and various types of jinja2 blocks
    '''
    assert split_args('a=1 b="2"') == ['a=1', 'b="2"']
    assert split_args('a=1 \nb="2"') == ['a=1', 'b="2"']
    assert split_args('a=1 \n b="2"') == ['a=1', 'b="2"']
    assert split_args('a=1 \n b="2" c="3"') == ['a=1', 'b="2" c="3"']

# Generated at 2022-06-23 02:54:33.359816
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted("Hello") == False)
    assert (is_quoted("Hello\"") == False)
    assert (is_quoted("\"Hello") == False)
    assert (is_quoted("\"Hello\"") == True)
    assert (is_quoted("'Hello") == False)
    assert (is_quoted("'Hello'") == True)
    assert (is_quoted("\"Hello\'") == False)
    assert (is_quoted("\'Hello\"") == False)
    assert (is_quoted("\'Hello\'") == True)
    assert (is_quoted("\"Hello\'") == False)



# Generated at 2022-06-23 02:54:40.761519
# Unit test for function is_quoted
def test_is_quoted():

    assert is_quoted('"foo"') == True, "should be True"
    assert is_quoted("'foo'") == True, "should be True"
    assert is_quoted("'fo'o'") == False, "should be False because of the single quote in the middle"
    assert is_quoted("foo") == False, "should be False because it doesn't start and end with a quote"



# Generated at 2022-06-23 02:54:50.746628
# Unit test for function split_args
def test_split_args():
    import sys
    import unittest

    class SplitArgsTest(unittest.TestCase):

        def test_simple(self):
            data = "a=b"
            result = split_args(data)
            self.assertEqual(result, ['a=b'])

        def test_newlines(self):
            data = "a=b\nc=d"
            result = split_args(data)
            self.assertEqual(result, ['a=b\n', 'c=d'])

        def test_jinja_block(self):
            data = '''a=b {{ foo }} c=d'''
            result = split_args(data)
            self.assertEqual(result, ['a=b {{ foo }} c=d'])


# Generated at 2022-06-23 02:55:02.384851
# Unit test for function split_args

# Generated at 2022-06-23 02:55:06.953282
# Unit test for function unquote
def test_unquote():
    # When the string is quoted
    assert unquote("'quoted string'") == "quoted string"
    assert unquote('"quoted string"') == "quoted string"
    # When the string is not quoted
    assert unquote("not quoted string") == "not quoted string"