

# Generated at 2022-06-23 02:45:07.406453
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote("'test'") == "test"
    assert unquote("'test") == "'test"
    assert unquote("test'") == "test'"
    assert unquote("\"test\"") == "test"
    assert unquote("\"test") == "\"test"
    assert unquote("test\"") == "test\""
    assert unquote("'\"test\"'") == "\"test\""


# Generated at 2022-06-23 02:45:13.925524
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted('"foo\'')
    assert not is_quoted('foo')
    assert not is_quoted(None)



# Generated at 2022-06-23 02:45:19.325791
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo') == '"foo'
    assert unquote('foo') == 'foo'

# Generated at 2022-06-23 02:45:22.392927
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') != 'foo'
    assert unquote("'foo") != 'foo'
    assert unquote('foo"') != 'foo'
    assert unquote("foo'") != 'foo'


# Generated at 2022-06-23 02:45:26.592377
# Unit test for function unquote
def test_unquote():
    assert unquote("'test'") == 'test'
    assert unquote("\"test\"") == 'test'
    assert unquote("\"test") == "\"test"
    assert unquote("'test") == "'test"
    assert unquote("test") == "test"
# end of test_unquote()

# Generated at 2022-06-23 02:45:31.580112
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted("foo\"") == False
    assert is_quoted("'foo'bar") == False
    assert is_quoted("foo") == False


# Generated at 2022-06-23 02:45:43.415385
# Unit test for function split_args
def test_split_args():
    '''
        test_split_args: verify the output from split_args
    '''

# Generated at 2022-06-23 02:45:50.759140
# Unit test for function is_quoted
def test_is_quoted():

    assert(is_quoted('"abc"') == True)
    assert(is_quoted("'abc'") == True)
    assert(is_quoted('"a"b"c"') == False)
    assert(is_quoted('a"b"c') == False)
    assert(is_quoted('"a"b"c') == False)
    assert(is_quoted('"ab"c"') == False)
    assert(is_quoted('abc') == False)


# Generated at 2022-06-23 02:45:58.725844
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')

    assert is_quoted('""')
    assert is_quoted('"a"')
    assert is_quoted('"a b"')

    assert is_quoted("''")
    assert is_quoted("'a'")
    assert is_quoted("'a b'")

    assert not is_quoted('"')
    assert not is_quoted("'")

    assert not is_quoted('a"')
    assert not is_quoted("a'")

# Generated at 2022-06-23 02:46:10.873335
# Unit test for function split_args
def test_split_args():
    # Just a few basic tests, more complete tests in test/units/module_utils/shell.py
    assert split_args("") == []
    assert split_args("var=value") == ['var=value']
    assert split_args("var='value'") == ["var='value'"]
    assert split_args("var=\"value\"") == ['var="value"']
    assert split_args("cmd 'arg with spaces'") == ["cmd 'arg with spaces'"]
    assert split_args("cmd \"arg with spaces\"") == ['cmd "arg with spaces"']
    assert split_args("cmd \"arg with spaces\" arg2=value") == ['cmd "arg with spaces"', 'arg2=value']
    assert split_args("cmd \"arg {{with spaces\"") == ['cmd "arg {{with spaces"']

# Generated at 2022-06-23 02:46:18.610942
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"string"')
    assert is_quoted("'string'")
    assert is_quoted('"string') == False
    assert is_quoted("'string") == False
    assert is_quoted('string"') == False
    assert is_quoted("string'") == False
    assert is_quoted('"string') == False
    assert is_quoted("'string") == False
    assert is_quoted('""')
    assert is_quoted("''")
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted('') == False
    assert is_quoted('string') == False
    assert is_quoted('"string" with spaces') == False

# Generated at 2022-06-23 02:46:24.974995
# Unit test for function is_quoted
def test_is_quoted():
    if is_quoted('"hello world"') is True:
        if is_quoted('hello world') is False:
            if is_quoted('"hello" world"') is False:
                if is_quoted('"hello world') is False:
                    print('test_is_quoted: Success')
                    return True
    print('test_is_quoted: Failure')
    return False


# Generated at 2022-06-23 02:46:29.250305
# Unit test for function unquote
def test_unquote():
    assert(unquote("ubuntu") == "ubuntu")
    assert(unquote("'ubuntu'") == "ubuntu")
    assert(unquote("\"ubuntu\"") == "ubuntu")
    assert(unquote("\"ubuntu'") == "\"ubuntu'")


# Generated at 2022-06-23 02:46:38.952613
# Unit test for function split_args
def test_split_args():
    """Test split_args function"""
    # first set of tests are for condition where we don't have a jinja filter at all
    # each test will consist of a string from the ansible-playbook command line, and a list
    # of the parsed params

# Generated at 2022-06-23 02:46:40.421220
# Unit test for function unquote
def test_unquote():
    assert unquote("abc") == "abc"
    assert unquote('"abc"') == "abc"
    assert unquote('"a\\"bc"') == "a\"bc"

# Generated at 2022-06-23 02:46:51.636543
# Unit test for function split_args

# Generated at 2022-06-23 02:46:57.165319
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("")
    assert not is_quoted("hello")
    assert is_quoted("'hello'")
    assert is_quoted('"hello"')
    assert not is_quoted("hello'")
    assert not is_quoted("'hello")
    assert is_quoted("'hello' world")
    assert is_quoted("'hello\\'' world")
    assert not is_quoted("'hello\\' world")


# Generated at 2022-06-23 02:47:10.260469
# Unit test for function split_args
def test_split_args():
    print("Testing function split_args")
    # Test simple args
    print('  Test simple args')
    test1 = "foo=bar"
    result = split_args(test1)
    if result != ["foo=bar"]:
        print("    FAIL: test1 returned %s instead of %s" % (result, "foo=bar"))
    test2 = "arg1 arg2"
    result = split_args(test2)
    if result != ["arg1", "arg2"]:
        print("    FAIL: test2 returned %s instead of %s" % (result, ["arg1", "arg2"]))
    # Test args with spaces and quotes
    print('  Test args with spaces and quotes')
    test3 = "foo=\"bar baz\""
    result = split_args(test3)

# Generated at 2022-06-23 02:47:19.670123
# Unit test for function split_args
def test_split_args():
    '''
    Ensure that the split_args function works as expected
    '''

    def do_test(test_case):
        result = split_args(test_case['input'])
        assert result == test_case['expected'], "unexpected result, expected %s, got %s" % (test_case['expected'], result)

    simple_quoted = 'foo="bar baz" one="1 2 3" nice="easy as"'
    simple_expected = ['foo="bar baz"', 'one="1 2 3"', 'nice="easy as"']
    do_test({'input': simple_quoted, 'expected': simple_expected})

    simple_unquoted = 'foo=bar baz one=1 2 3 nice=easy as'

# Generated at 2022-06-23 02:47:30.635983
# Unit test for function split_args

# Generated at 2022-06-23 02:47:42.582266
# Unit test for function split_args

# Generated at 2022-06-23 02:47:47.245669
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("'hello") == False
    assert is_quoted("hello'") == False
    assert is_quoted("hello") == False
    assert is_quoted('"hello') == False


# Generated at 2022-06-23 02:47:56.147733
# Unit test for function split_args

# Generated at 2022-06-23 02:47:59.163722
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote("test") == "test"


# Generated at 2022-06-23 02:48:12.577401
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar' d='a\\'b'") == ['a=b', "c='foo bar'", "d='a\\'b'"]
    assert split_args("a=b c='foo bar' d=\"a'b\"") == ['a=b', "c='foo bar'", 'd="a\'b"']
    assert split_args("a=b c=\"foo bar\" d=\"a'b\"") == ['a=b', 'c="foo bar"', 'd="a\'b"']

# Generated at 2022-06-23 02:48:16.903419
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote('hello world') == 'hello world'
    assert unquote('"hello world') == '"hello world'
    assert unquote('hello world"') == 'hello world"'
    assert unquote("'hello world'") == 'hello world'
    assert unquote('"hello world""') == 'hello world"'

# Generated at 2022-06-23 02:48:23.424154
# Unit test for function is_quoted
def test_is_quoted():

    assert(not is_quoted(''))
    assert(not is_quoted(None))
    assert(is_quoted('"foo"'))
    assert(is_quoted('"foo'))
    assert(is_quoted('"f\'oo"string'))
    assert(is_quoted('\'foo\'"string'))
    assert(is_quoted('\'foo\''))
    assert(not is_quoted('\'foostring'))
    assert(not is_quoted('\'f"oo\''))
    assert(not is_quoted('\'f"oo'))



# Generated at 2022-06-23 02:48:34.798215
# Unit test for function is_quoted
def test_is_quoted():
    fail_msg = 'is_quoted(data) method failed.'
    assert(is_quoted('') is False)
    assert(is_quoted('""') is False)
    assert(is_quoted('"asdasd"') is True)
    assert(is_quoted('"asdasd') is False)
    assert(is_quoted('asdasd"') is False)
    assert(is_quoted("'asdasd'") is True)
    assert(is_quoted("'asdasd") is False)
    assert(is_quoted("asdasd'") is False)
    assert(is_quoted("''") is False)
    assert(is_quoted("'''") is False)
    assert(is_quoted("'") is False)
   

# Generated at 2022-06-23 02:48:37.136268
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'


# Generated at 2022-06-23 02:48:39.822381
# Unit test for function is_quoted
def test_is_quoted():
    assert False == is_quoted('baba')
    assert True  == is_quoted('"baba"')
    assert True  == is_quoted("'baba'")


# Generated at 2022-06-23 02:48:50.550973
# Unit test for function split_args
def test_split_args():
    test1_args = '''a=1 c="foo bar"'''
    test1_ans = ['a=1', 'c="foo bar"']
    test2_args = '''a=1 c="foo bar" d="{{ foo }}"'''
    test2_ans = ['a=1', 'c="foo bar"', 'd="{{ foo }}"']
    test3_args = '''a=1 c="foo bar d={{ foo }}"'''
    test3_ans = ['a=1', 'c="foo bar d={{ foo }}"']
    test4_args = '''a=1 c="foo bar d={{ foo }}" e="foo bar"'''
    test4_ans = ['a=1', 'c="foo bar d={{ foo }}"', 'e="foo bar"']
   

# Generated at 2022-06-23 02:48:56.132419
# Unit test for function unquote
def test_unquote():
    assert unquote("test") == "test"
    assert unquote("'test'") == "test"
    assert unquote('"test"') == "test"
    assert unquote("''test''") == "test"
    assert unquote('""test""') == "test"
    assert unquote("'test") == "test"
    assert unquote('"test') == "test"

# Generated at 2022-06-23 02:49:01.029413
# Unit test for function unquote
def test_unquote():
    assert unquote('"\'"') == "'"
    assert unquote("'\"'") == '"'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert not is_quoted(unquote('"foo"'))
    assert not is_quoted(unquote("'foo'"))


# Generated at 2022-06-23 02:49:03.473303
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"hello"'))
    assert(is_quoted('""'))
    assert(is_quoted("'hello'"))
    assert(is_quoted("''"))
    assert(not is_quoted('hello'))
    assert(not is_quoted('he"llo"'))
    assert(not is_quoted('"hello'))


# Generated at 2022-06-23 02:49:10.072833
# Unit test for function unquote
def test_unquote():
    teacher_list = []
    student_list = []

    # Case 1: string is quoted - expect output string to be unquoted
    teacher_list.append('"cat"')
    student_list.append('cat')

    # Case 2: string is not quoted - expect output string to be equal to input string
    teacher_list.append('cat')
    student_list.append('cat')

    for i in range(len(teacher_list)):
        assert unquote(teacher_list[i]) == student_list[i]

# Generated at 2022-06-23 02:49:13.640642
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("''") == True)
    assert(is_quoted("'hello'") == True)
    assert(is_quoted('"hello"') == True)
    assert(is_quoted("") == False)
    assert(is_quoted("hello") == False)
    assert(is_quoted("'hello") == False)
    assert(is_quoted('"hello') == False)


# Generated at 2022-06-23 02:49:25.584794
# Unit test for function split_args

# Generated at 2022-06-23 02:49:32.924494
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"ab"')
    assert is_quoted("'ab'")
    assert not is_quoted("'ab")
    assert not is_quoted('"ab')
    assert not is_quoted("ab")
    assert not is_quoted('"a"b"')
    assert not is_quoted("'a'b'")


# Generated at 2022-06-23 02:49:41.056386
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"one"')
    assert is_quoted("'two'")
    assert not is_quoted('"three')
    assert not is_quoted("'four")
    assert not is_quoted('five"')
    assert not is_quoted("six'")
    assert is_quoted('') is False
    assert is_quoted('""')
    assert is_quoted("''")


# Generated at 2022-06-23 02:49:49.699301
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc') != 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'abc") != 'abc'
    assert unquote('"') == '"'
    assert unquote("'") == "'"
    assert unquote('"""') == '"'
    assert unquote("'''") == "'"


# Generated at 2022-06-23 02:49:59.485324
# Unit test for function split_args
def test_split_args():
    print("Testing function split_args")

# Generated at 2022-06-23 02:50:03.570162
# Unit test for function unquote
def test_unquote():
    data = "\"abc\""
    data = unquote(data)
    print(data)
    
    assert data == "abc"
    print("unquote test passed")
    return 



# Generated at 2022-06-23 02:50:07.176312
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("Test") == False, "Shouldn't be quoted"
    assert is_quoted("'Test'") == True, "Should be quoted"
    assert is_quoted('"Test"') == True, "Should be quoted"



# Generated at 2022-06-23 02:50:10.196021
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote("'hello'") == 'hello'


# Generated at 2022-06-23 02:50:12.687375
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'

# Test for function split_args

# Generated at 2022-06-23 02:50:16.478093
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'



# Generated at 2022-06-23 02:50:25.076507
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("'test'") == True
    assert is_quoted("\"test\"") == True
    assert is_quoted("\"test") == False
    assert is_quoted("test\"") == False
    assert is_quoted("\"test\"\"test\"") == False
    assert is_quoted("\"test") == False
    assert is_quoted("\"\"") == True
    assert is_quoted("\"\"\"\"") == False
    assert is_quoted("test") == False
    assert is_quoted("''") == True
    assert is_quoted("''''") == False
    assert is_quoted("test") == False
    assert is_quoted("'test") == False
    assert is_quoted("test'") == False

# Generated at 2022-06-23 02:50:36.159761
# Unit test for function split_args
def test_split_args():
    '''
    This function performs various tests on split_args() to verify parsing of
    complex command line arguments.
    '''
    # import modules needed for these tests
    import sys

    print("1..7")  # TAP plan

    #
    # test with simple non-arguments, to ensure splitting works, but not reassembly
    #

    try:
        result = split_args("")
    except Exception:
        print("not ok 1 - test 1")
    else:
        print("ok 1 - test 1")
        print("# result: %s" % repr(result))

    try:
        result = split_args(" ")
    except Exception:
        print("not ok 2 - test 2")
    else:
        print("ok 2 - test 2")
        print("# result: %s" % repr(result))

# Generated at 2022-06-23 02:50:46.413544
# Unit test for function unquote
def test_unquote():
    '''
    >>> test_unquote()
    Testing unquote on string with different quotes
    Testing unquote on string with not equal quotes
    Testing unquote with an empty string
    Testing unquote with a string containing quotes and another character
    Testing unquote on string containing quotes and no other character
    '''
    print("Testing unquote on string with different quotes")
    assert unquote('"foo\'') == '"foo\''
    print("Testing unquote on string with not equal quotes")
    assert unquote('"foo\'') == '"foo\''
    print("Testing unquote with an empty string")
    assert unquote('') == ''
    print("Testing unquote with a string containing quotes and another character")
    assert unquote('"foo"') == 'foo'

# Generated at 2022-06-23 02:50:54.837485
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('fo"o') == 'fo"o'
    assert unquote("fo'o") == "fo'o"
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote("'") == "'"



# Generated at 2022-06-23 02:50:59.176370
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted('"hello') == False
    assert is_quoted("'hello") == False
    assert is_quoted('hello"') == False
    assert is_quoted("hello'") == False



# Generated at 2022-06-23 02:51:04.603446
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted("\"foo\"")

    assert not is_quoted("'\"foo\"'")
    assert not is_quoted("\"'foo'\"")
    assert not is_quoted("foo")
    assert not is_quoted("foo")
    assert not is_quoted("")



# Generated at 2022-06-23 02:51:11.727354
# Unit test for function unquote
def test_unquote():
    data1 = '"example"'
    expected = 'example'
    actual = unquote(data1)
    assert expected == actual, "%s != %s" % (expected, actual)

    data2 = "'example'"
    actual = unquote(data2)
    assert expected == actual, "%s != %s" % (expected, actual)

    data3 = 'example'
    actual = unquote(data3)
    assert data3 == actual, "%s != %s" % (data3, actual)

if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-23 02:51:24.640066
# Unit test for function unquote
def test_unquote():
    ''' unit test for module utils method unquote '''

    # string starts with single quote
    # string starts with double quote
    # string ends with single quote
    # string ends with double quote
    # string starts and ends with single quote
    # string starts and ends with double quote
    # string starts and ends with different quotes
    # string starts and ends with different quotes, but has an internal double quote
    # string doesn't start and ends with quote
    # string starts with quote and has multiple quotes
    # string starts with quote, has an internal quote, and ends with quote
    # string has a matching quote pair within a pair
    # string has a matching quote pair inside a block
    # unicode string
    # unicode string with quotes

# Generated at 2022-06-23 02:51:35.624789
# Unit test for function split_args

# Generated at 2022-06-23 02:51:41.989108
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'


# Generated at 2022-06-23 02:51:49.342715
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"')     == 'hello'
    assert unquote("'hello'")     == 'hello'
    assert unquote('"hello')      == '"hello'
    assert unquote('hello"')      == 'hello"'
    assert unquote('"hello\'s"')  == 'hello\'s'
    assert unquote('"hello\\""')  == 'hello"'
    assert unquote('hello')       == 'hello'
    assert unquote('"')           == '"'
    assert unquote('"hello\\"')   == 'hello\\'
    assert unquote('"hello\\\\""') == 'hello\\'


# Generated at 2022-06-23 02:51:56.286256
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\'s"') == "foo\'s"
    assert unquote("'foo\"s'") == 'foo"s'

# Generated at 2022-06-23 02:52:09.728384
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="b" c="foo bar"') == ['a="b"', 'c="foo bar"']
    assert split_args('a="b" c="foo bar"') == ['a="b"', 'c="foo bar"']
    assert split_args('/usr/bin/ansible-connection -vvvvv --socket=/tmp/ansible-aalpern-ssh-22-controlpath-9Hsi1h/socket') == ['/usr/bin/ansible-connection', '-vvvvv', '--socket=/tmp/ansible-aalpern-ssh-22-controlpath-9Hsi1h/socket']

# Generated at 2022-06-23 02:52:16.735172
# Unit test for function unquote
def test_unquote():
    assert unquote("this") == "this"
    assert unquote("'this'") == "this"
    assert unquote('"this"') == "this"
    assert unquote("'this") == "'this"
    assert unquote('"this') == '"this'
    assert unquote("this'") == "this'"
    assert unquote('this"') == 'this"'

test_unquote()

# Generated at 2022-06-23 02:52:27.109122
# Unit test for function split_args
def test_split_args():
    # Basic
    assert split_args('a=b c="foo bar" d=123 "foo bar"') == ['a=b', 'c="foo bar"', 'd=123', '"foo bar"']
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']
    assert split_args('"foo" "foo bar"') == ['"foo"', '"foo bar"']
    assert split_args('a=b "foo bar"') == ['a=b', '"foo bar"']
    assert split_args('"foo bar" a=b') == ['"foo bar"', 'a=b']

# Generated at 2022-06-23 02:52:36.345203
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b 'c=d'") == ['a=b', "'c=d'"]
    assert split_args("a=b \"c=d\"") == ['a=b', '"c=d"']
    assert split_args("a=b \"c=d e=f\"") == ['a=b', '"c=d e=f"']
    assert split_args("a=b \"c=d e={{ foo }}\"") == ['a=b', '"c=d e={{ foo }}"']

# Generated at 2022-06-23 02:52:45.429996
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello world"') == True
    assert is_quoted("'hello world'") == True
    assert is_quoted("'hello \"world'") == False
    assert is_quoted("'hello world'") == True
    assert is_quoted("'hello \"world\"'") == True
    assert is_quoted("'hello \"world\"") == False
    assert is_quoted("hello world'") == False
    assert is_quoted("'hello world") == False
    assert is_quoted("hello world") == False


# Generated at 2022-06-23 02:52:54.482163
# Unit test for function unquote

# Generated at 2022-06-23 02:53:00.393828
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('""')
    assert is_quoted("''")
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted('foo\'"')



# Generated at 2022-06-23 02:53:04.117785
# Unit test for function unquote
def test_unquote():

    if unquote('"foo"') != 'foo':
        raise AssertionError('unquote() failed to strip extra quotes')
    if unquote('foo') == 'foo':
        raise AssertionError('unquote() failed to return the same value for a non-quoted string')


# Generated at 2022-06-23 02:53:15.717870
# Unit test for function split_args
def test_split_args():
    args = 'a=b c=d'
    result = ['a=b', 'c=d']
    assert split_args(args) == result

    args = 'a=b c=d "e=f g=h"'
    result = ['a=b', 'c=d', 'e=f g=h']
    assert split_args(args) == result

    args = 'a=b c=d "e=f g=h'
    try:
        result = split_args(args)
    except Exception:
        pass

    args = 'a=b c=d "e=f \\" g=h'
    result = ['a=b', 'c=d', 'e=f " g=h']
    assert split_args(args) == result


# Generated at 2022-06-23 02:53:21.584864
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('"abcd"') == True)
    assert (is_quoted('"abcd') == False)
    assert (is_quoted("'abcd'") == True)
    assert (is_quoted("'abcd") == False)
    assert (is_quoted('abcd"') == False)
    assert (is_quoted('abcd\'"') == False)
    assert (is_quoted('"') == False)
    assert (is_quoted("'") == False)
    # no quotes
    assert (is_quoted('abcd') == False)
    assert (is_quoted('') == False)
    assert (is_quoted(None) == False)



# Generated at 2022-06-23 02:53:32.841541
# Unit test for function split_args
def test_split_args():

    # Test python shlex type of quoting
    args = "a=b c='foo bar' 'd e'=f \"g h\"=i j='k''l' 'm \" n'=o p=\"q r\" s=\"t''u\""
    params = split_args(args)
    assert(params == ['a=b', "c='foo bar'", "'d e'=f", '"g h"=i', "j='k''l'", "'m \" n'=o", 'p="q r"', "s=\"t''u\""])

    # We don't want to parse anything with nested quotes, just strip them out for now

# Generated at 2022-06-23 02:53:38.262795
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('foo"') == False
    assert is_quoted("foo'") == False
    assert is_quoted('"foo') == False
    assert is_quoted("'foo") == False
    assert is_quoted('foo') == False


# Generated at 2022-06-23 02:53:45.099842
# Unit test for function unquote
def test_unquote():
    assert 'foobar' == unquote('foobar')
    assert 'foobar' == unquote('"foobar"')
    assert 'foobar' == unquote("'foobar'")
    assert '"foobar"' == unquote('""foobar""')
    assert '"foobar"' == unquote("''foobar'")
    assert 'foobar\\' == unquote('"foobar\\"')
    assert 'foobar"' == unquote("'foobar'")
    assert "foobar'" == unquote('"foobar"')
    assert "foobar\\'" == unquote("'foobar\\'")

# Generated at 2022-06-23 02:53:57.357710
# Unit test for function split_args
def test_split_args():
    # test case 1
    args = '''a=b c=d'''
    params = split_args(args)
    assert params == ['a=b', 'c=d']

    # test case 2
    args = '''a=b c=d\
    e=f g=h'''
    params = split_args(args)
    assert params == ['a=b', 'c=d\ne=f', 'g=h']

    # test case 3
    args = '''a=b c="d e f" g=h'''
    params = split_args(args)
    assert params == ['a=b', 'c="d e f"', 'g=h']

    # test case 4
    args = '''a=b c=\"d e f\" g=h'''
    params = split_args

# Generated at 2022-06-23 02:54:00.634477
# Unit test for function unquote
def test_unquote():
    '''
    Test whether single and double quotes get removed or not
    '''
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('test') == 'test'



# Generated at 2022-06-23 02:54:05.706076
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted('hello') == False
    assert is_quoted('') == False
    assert is_quoted('"hello') == False


# Generated at 2022-06-23 02:54:15.728948
# Unit test for function split_args
def test_split_args():
    ''' Test function split_args '''

    print("------------------------------------------------------------")
    print("Testing function split_args")
    print("------------------------------------------------------------")

# Generated at 2022-06-23 02:54:19.261042
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted("'test")



# Generated at 2022-06-23 02:54:27.741000
# Unit test for function is_quoted
def test_is_quoted():
    assert(not is_quoted('test'))
    assert(is_quoted('"test"'))
    assert(is_quoted('"test'))
    assert(not is_quoted('test"'))
    assert(not is_quoted('te"st'))
    assert(not is_quoted('te"st"'))
    assert(not is_quoted(''))
    assert(is_quoted('""'))
    assert(is_quoted('"\'"'))
    assert(is_quoted('\'"\''))
    assert(not is_quoted('"\'"'))
    assert(not is_quoted('\'"\''))
    assert(not is_quoted(None))



# Generated at 2022-06-23 02:54:32.206880
# Unit test for function unquote
def test_unquote():
    assert unquote(None) == None
    assert unquote('') == ''
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'


functions = {
    'unquote': unquote
}

doc_fragments = ['common_redirection_args', 'common_connection_args']

# Generated at 2022-06-23 02:54:43.105986
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"hello"') == True)
    assert(is_quoted("''") == True)
    assert(is_quoted('""') == True)
    assert(is_quoted('"hello') == False)
    assert(is_quoted('hello"') == False)
    assert(is_quoted("'hello'") == True)
    assert(is_quoted("'hello") == False)
    assert(is_quoted("hell'o'") == False)
    assert(is_quoted("hell'o") == False)
    assert(is_quoted("hello") == False)
    assert(is_quoted("") == False)
    assert(is_quoted("'''hello'") == False)
    assert(is_quoted("'''hello''") == False)


# Generated at 2022-06-23 02:54:52.053249
# Unit test for function split_args
def test_split_args():
    # Some basic checks first
    assert split_args("") == []
    assert split_args(" ") == []
    assert split_args("a") == ["a"]
    assert split_args(" a") == ["a"]
    assert split_args("a ") == ["a"]
    assert split_args(" a ") == ["a"]
    assert split_args("  ") == []
    assert split_args("  a   b   c") == ["a", "b", "c"]
    assert split_args("  a   'b c'   d") == ["a", "'b c'", "d"]
    assert split_args('  a   "b c"   d') == ["a", '"b c"', "d"]

    # Basic check with quotes

# Generated at 2022-06-23 02:54:57.794735
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"toto"')
    assert is_quoted("'toto'")
    assert not is_quoted('"toto')
    assert not is_quoted("'toto")



# Generated at 2022-06-23 02:55:02.828787
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo bar'") is True
    assert is_quoted("foo bar") is False
    assert is_quoted('"foo bar"') is True

