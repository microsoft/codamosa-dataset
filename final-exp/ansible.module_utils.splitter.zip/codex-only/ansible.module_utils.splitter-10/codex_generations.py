

# Generated at 2022-06-23 02:45:10.562362
# Unit test for function split_args

# Generated at 2022-06-23 02:45:17.653898
# Unit test for function unquote
def test_unquote():
    string = "\"foo\""
    result = unquote(string)
    assert(result == "foo")
    string = "'foo'"
    result = unquote(string)
    assert(result == "foo")
    string = "foo"
    result = unquote(string)
    assert(result == "foo")
    string = "fo'o"
    result = unquote(string)
    assert(result == "fo'o")

# Generated at 2022-06-23 02:45:22.531816
# Unit test for function unquote
def test_unquote():
    ''' test for function unquote '''
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'bar") == "'foobar"
    assert unquote("foo") == "foo"



# Generated at 2022-06-23 02:45:31.119331
# Unit test for function split_args
def test_split_args():
    # an initial check to make sure the input and output count of args is the same
    assert split_args('foo bar biz baz') == ['foo', 'bar', 'biz', 'baz']

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('''a=b c="foo
bar"''') == ['a=b', 'c="foo\nbar"']

    assert split_args('''a=b
c="foo bar"''') == ['a=b\nc="foo bar"']

    # now test the block count functionality

# Generated at 2022-06-23 02:45:39.538339
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('""') == ''
    assert unquote("''") == ''
    assert unquote('"a"b"') == 'a"b'
    assert unquote("'a'b'") == 'a\'b'
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"

# Generated at 2022-06-23 02:45:43.061731
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted('foo"') == False
    assert is_quoted('"foo') == False
    assert is_quoted("'foo'") == True
    assert is_quoted("'") == False
    assert is_quoted('"') == False

# Generated at 2022-06-23 02:45:48.848825
# Unit test for function unquote
def test_unquote():
    assert(unquote('"testabcd"') == 'testabcd')
    assert(unquote("'testabcd'") == 'testabcd')
    assert(unquote('"test""""abcd"') == 'test"""abcd')
    assert(unquote('"test""""abcd') == 'test"""abcd')
    assert(unquote('testabcd') == 'testabcd')


# Generated at 2022-06-23 02:45:57.166458
# Unit test for function unquote
def test_unquote():
    ''' test unquote '''
    data = '"test"'
    assert len(data) == 5
    assert data[0] == '"'
    assert data[-1] == '"'
    assert data[1] == 't'
    assert data[-2] == 't'
    assert is_quoted(data) == True
    assert unquote(data) == 'test'

    data = 'test'
    assert is_quoted(data) == False
    assert unquote(data) == 'test'

    data = "test'"
    assert is_quoted(data) == False
    assert unquote(data) == "test'"

    data = "'test"
    assert is_quoted(data) == False
    assert unquote(data) == "'test"



# Generated at 2022-06-23 02:46:06.846932
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo\nbar') == ['a=b', 'c="foo\nbar']
    assert split_args('''"foo bar"''') == ['"foo bar"']
    assert split_args('-i inventory foo') == ['-i', 'inventory', 'foo']
    assert split_args('a="{{ foo }}"') == ['a="{{ foo }}"']
    assert split_args('a="{{ foo }}') == ['a="{{ foo }}']
    assert split_args('a="{{ foo }}') == ['a="{{ foo }}']
    assert split

# Generated at 2022-06-23 02:46:10.955864
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('"test"') == True)
    assert (is_quoted('test') == False)
    assert (is_quoted('"test') == False)
    assert (is_quoted('test"') == False)
    assert (is_quoted('') == False)


# Generated at 2022-06-23 02:46:16.519742
# Unit test for function split_args
def test_split_args():
    # Quoting
    assert split_args('foo="bar baz"') == ['foo=bar baz']
    assert split_args('foo="bar \\"baz\\""') == ['foo=bar "baz"']
    assert split_args('foo=\\"bar baz\\"') == [r'foo=\"bar', 'baz\"']
    assert split_args('foo="bar baz') == ['foo=bar baz']
    assert split_args('foo="bar\nbaz"') == ['foo=bar\nbaz']
    assert split_args('foo=bar baz="foo bar"') == ['foo=bar', 'baz=foo bar']
    assert split_args('foo="bar"baz="foo"') == ['foo=barbaz=foo']

    # Jinja2 blocks

# Generated at 2022-06-23 02:46:27.564751
# Unit test for function split_args

# Generated at 2022-06-23 02:46:38.892400
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted('"abc') == False
    assert is_quoted('abc"') == False
    assert is_quoted('"abc\'"') == False
    assert is_quoted('\'"abc"') == False
    assert is_quoted('\'abc\'') == True
    assert is_quoted('\'abc') == False
    assert is_quoted('abc\'') == False
    assert is_quoted('\\\'abc\\\'') == True
    assert is_quoted('\'abc\\\'\\\'') == True
    assert is_quoted('\\\'abc\\\'\\\'') == True
    assert is_quoted('ab"c"') == False
    assert is_quoted('ab\'c\'') == False

# Generated at 2022-06-23 02:46:44.422887
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo" ') == 'foo'
    assert unquote(' "foo"') == 'foo'
    assert unquote(' "foo" ') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("'foo' ") == 'foo'
    assert unquote(" 'foo'") == 'foo'
    assert unquote(" 'foo' ") == 'foo'



# Generated at 2022-06-23 02:46:54.388022
# Unit test for function split_args
def test_split_args():
    assert split_args('foo="bar baz"') == ['foo=bar baz']
    assert split_args('foo="bar baz') == ['foo=bar baz']
    assert split_args('foo="bar baz\\"') == ['foo=bar baz']
    assert split_args('foo="bar baz\\""') == ['foo="bar baz"']
    assert split_args('foo="bar baz\\"" spam="eggs eggs"') == ['foo="bar baz"', 'spam=eggs eggs']
    assert split_args('foo="bar baz\\"" spam="eggs eggs') == ['foo="bar baz"', 'spam=eggs eggs']

# Generated at 2022-06-23 02:47:03.719965
# Unit test for function split_args
def test_split_args():
    # string tests
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    assert split_args("foo bar baz 'hello world'") == ["foo", "bar", "baz", "'hello world'"]
    assert split_args('foo bar baz "hello world"') == ["foo", "bar", "baz", '"hello world"']
    assert split_args('foo bar "baz hello world" xyz') == ["foo", "bar", '"baz hello world"', "xyz"]

# Generated at 2022-06-23 02:47:16.009475
# Unit test for function unquote
def test_unquote():
    ''' unquote should remove first and last quotes from a string, if the string starts and ends with the same quotes '''
    assert (unquote('"abc"') == 'abc')
    assert (unquote('"a""b"') == 'a""b')
    assert (unquote("'a""b'") == 'a""b')
    assert (unquote("'a'bc'") == "a'bc")
    assert (unquote('abc') == 'abc')
    assert (unquote('') == '')
    assert (unquote('""') == '')
    assert (unquote("''") == '')
    assert (unquote('"') == '"')
    assert (unquote("'") == "'")


# Generated at 2022-06-23 02:47:23.675951
# Unit test for function split_args
def test_split_args():
    '''
    This function is meant to be called programmatically by a unit test.
    It will run a series of tests and raise exceptions when the first fails.
    '''

# Generated at 2022-06-23 02:47:36.486133
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo bar baz"') == True)
    assert(is_quoted('foo bar baz') == False)
    assert(is_quoted('"foo bar baz') == False)
    assert(is_quoted('foo bar baz"') == False)
    assert(is_quoted('') == False)
    assert(is_quoted('""') == True)
    assert(is_quoted('"\'"') == True)
    assert(is_quoted('\'\'"') == True)
    assert(is_quoted('\'\'') == True)
    assert(is_quoted('"\'"x') == False)
    assert(is_quoted('"\'"x"') == True)
    assert(is_quoted('"x\'"') == True)

# Generated at 2022-06-23 02:47:42.848605
# Unit test for function unquote
def test_unquote():
    assert unquote('"value"') == 'value'
    assert unquote("'value'") == 'value'
    assert unquote('value') == 'value'
    assert unquote('"val"ue"') == 'val"ue'
    assert unquote("'val'ue'") == "val'ue"


# Generated at 2022-06-23 02:47:52.672377
# Unit test for function split_args

# Generated at 2022-06-23 02:48:04.327335
# Unit test for function split_args
def test_split_args():
    # Tests with an empty arg string
    assert split_args('') == []

    # Tests with a simple unquoted argument
    assert split_args('foo') == ['foo']

    # Tests with a quoted argument
    assert split_args('"foo"') == ['foo']

    # Tests with multiple arguments
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('"foo bar"') == ['foo bar']
    assert split_args("'foo bar'") == ['foo bar']
    assert split_args("'foo' bar") == ["foo", 'bar']
    assert split_args("'foo' 'bar'") == ["foo", "bar"]
    assert split_args("foo 'bar'") == ['foo', "bar"]

# Generated at 2022-06-23 02:48:11.764051
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"')    == 'test'
    assert unquote('test')      == 'test'
    assert unquote('"test')     == '"test'
    assert unquote('test"')     == 'test"'
    assert unquote("'test'")    == 'test'
    assert unquote("'test")     == "'test"
    assert unquote("test'")     == "test'"



# Generated at 2022-06-23 02:48:17.547011
# Unit test for function split_args
def test_split_args():
    assert split_args("a=1") == ["a=1"]
    assert split_args("a={{ b }}") == ["a={{ b }}"]
    assert split_args("a={{ b }} c= {{ d }}") == ["a={{ b }}", "c= {{ d }}"]
    assert split_args("a=\"{{ b }}\" c= {{ d }}") == ["a=\"{{ b }}\"", "c= {{ d }}"]
    assert split_args("a=\"{{ b }}\" c= d e=\"{{ f }}\"") == ["a=\"{{ b }}\"", "c= d", "e=\"{{ f }}\""]
    assert split_args("a=\"{{ b }}\" c= d e=\"{{ f }}\"") == ["a=\"{{ b }}\"", "c= d", "e=\"{{ f }}\""]
    assert split

# Generated at 2022-06-23 02:48:23.778268
# Unit test for function unquote
def test_unquote():
    assert unquote('hello world') == 'hello world'
    assert unquote('"hello world"') == 'hello world'
    assert unquote("'hello world'") == 'hello world'
    assert unquote('\'hello world"') == '\'hello world"'
    assert unquote('"hello world\'') == '"hello world\''

# Generated at 2022-06-23 02:48:37.729319
# Unit test for function split_args

# Generated at 2022-06-23 02:48:49.513140
# Unit test for function split_args

# Generated at 2022-06-23 02:49:00.120209
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('"a\\"b"') == True)
    assert (is_quoted('"a"') == True)
    assert (is_quoted("'a'") == True)
    assert (is_quoted("'a\\'b'") == True)
    assert (is_quoted("'a'c'") == False)
    assert (is_quoted("'a\"b'") == False)
    assert (is_quoted("a'b'") == False)
    assert (is_quoted('a"b"') == False)
    assert (is_quoted('"a"b"') == False)
    assert (is_quoted("'a'b'") == False)
    assert (is_quoted('') == False)


# Generated at 2022-06-23 02:49:04.001196
# Unit test for function unquote
def test_unquote():
    ''' unquote should remove first and last quotes from a string, if the string starts and ends with the same quotes '''
    assert unquote('"quoted"') == 'quoted'
    assert unquote("'quoted'") == 'quoted'
    assert unquote('not quoted') == 'not quoted'

# Generated at 2022-06-23 02:49:12.659008
# Unit test for function split_args
def test_split_args():
    assert split_args('{{ foo }}') == ['{{', 'foo', '}}']
    assert split_args('{{ foo }} bar=baz') == ['{{', 'foo', '}}', 'bar=baz']
    assert split_args('bar=baz {{ foo }}') == ['bar=baz', '{{', 'foo', '}}']
    assert split_args('bar="baz {{ foo }}"') == ['bar="baz {{ foo }}"']
    assert split_args('bar="baz {{ foo }}"') == ['bar="baz {{ foo }}"']
    assert split_args('''"baz {{ foo }}"''') == ['"baz {{ foo }}"']
    assert split_args('''"baz {{ foo }}" ''') == ['"baz {{ foo }}"', '']
    assert split_args

# Generated at 2022-06-23 02:49:25.060053
# Unit test for function split_args
def test_split_args():
    '''
    # test various ways of quoting and using jinj2
    '''
    failed = False
    errmsg = []
    if split_args("{{ foo }}") != ['{{ foo }}']:
        failed = True
        errmsg.append("Failed split on normal jinja2 block")

    if split_args("{% foo %}") != ['{% foo %}']:
        failed = True
        errmsg.append("Failed split on normal jinja2 block")

    if split_args("{% foo %} {% bar %}") != ['{% foo %}', '{% bar %}']:
        failed = True
        errmsg.append("Failed split on normal jinja2 block")


# Generated at 2022-06-23 02:49:31.560093
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert not is_quoted('')
    assert is_quoted('"foo"')
    assert is_quoted('"fo\'o"')
    assert is_quoted('\'"foo"\'')
    assert is_quoted('\'foo\'')
    assert not is_quoted('\'foo')
    assert not is_quoted('foo\'')
    assert is_quoted('"""foo"""')
    assert is_quoted('\'\'\'foo\'\'\'')


# Generated at 2022-06-23 02:49:35.541014
# Unit test for function is_quoted
def test_is_quoted():
    # OK cases
    assert is_quoted('"test"')
    assert is_quoted("'test'")

    # KO cases
    assert not is_quoted("'test")
    assert not is_quoted('"test')
    assert not is_quoted("test'")
    assert not is_quoted('test"')



# Generated at 2022-06-23 02:49:47.936845
# Unit test for function split_args
def test_split_args():
    assert split_args("echo foo bar baz") == ['echo', 'foo', 'bar', 'baz']
    assert split_args("command 'foo bar' baz") == ['command', 'foo bar', 'baz']
    assert split_args("command 'foo bar' 'baz'") == ['command', 'foo bar', 'baz']
    assert split_args("command 'foo bar' 'baz") == ['command', 'foo bar', 'baz']
    assert split_args("command 'foo bar") == ['command', 'foo bar']
    assert split_args("command \"foo bar") == ['command', 'foo bar']
    assert split_args("command foo\\ bar") == ['command', 'foo bar']
    assert split_args("command foo\\\nbar") == ['command', 'foobar']

# Generated at 2022-06-23 02:49:52.320061
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'ab'c'") == "'ab'c'"


# Generated at 2022-06-23 02:49:59.298895
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    # Edge cases
    assert not is_quoted('')
    assert not is_quoted('""')
    assert not is_quoted("''")


# Generated at 2022-06-23 02:50:10.929937
# Unit test for function split_args
def test_split_args():
    assert split_args("echo foo") == ['echo', 'foo']
    assert split_args("echo 'foo bar'") == ['echo', '\'foo bar\'']
    assert split_args("echo 'foo\nbar'") == ['echo', '\'foo\nbar\'']
    assert split_args("echo foo\\\nbar") == ['echo', 'foobar']
    assert split_args("echo 'foo\nbar'\nfoo=bar") == ['echo', '\'foo\nbar\'', 'foo=bar']

    assert split_args("echo {{foo}}") == ['echo', '{{foo}}']
    assert split_args("echo {{foo}}\\\nbar") == ['echo', '{{foo}}bar']

# Generated at 2022-06-23 02:50:16.577490
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == "abc"
    assert unquote("'abc'") == "abc"
    assert unquote("abc") == "abc"
    assert unquote('abc"') == 'abc"'
    assert unquote("abc'") == "abc'"
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"

# Generated at 2022-06-23 02:50:28.121889
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"')
    assert is_quoted('\'abcd\'')
    assert not is_quoted('abcd')
    assert not is_quoted('"abcd')
    assert not is_quoted('abcd"')
    assert not is_quoted('"abc')
    assert not is_quoted('abc\'')

if __name__ == '__main__':
    # Unit test for function split_args

    # tests that we can properly parse quoted strings with different quotes
    # inside and outside the string
    assert split_args(r'foo="bar baz"') == ['foo=bar baz']
    assert split_args(r'foo="bar \'baz\'"') == ['foo=bar \'baz\'']

# Generated at 2022-06-23 02:50:38.639937
# Unit test for function split_args

# Generated at 2022-06-23 02:50:41.766734
# Unit test for function unquote
def test_unquote():
    for data in ["'foo'", '"foo"', "foo"]:
        assert unquote(data) == 'foo'

if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-23 02:50:49.678055
# Unit test for function unquote
def test_unquote():
    # odd number of repeats
    assert unquote("'''") == "'''"
    assert unquote("''''") == "''"
    assert unquote('"""') == '"""'
    assert unquote('""""') == '""'

    assert unquote("'") == "'"
    assert unquote("'a'") == "'a'"

    # If a string starts and ends with the same quotes...
    assert unquote("''") == ""
    assert unquote('""') == ""
    assert unquote("'a'") == "a"
    assert unquote('"a"') == "a"

    assert unquote("'''a'''") == "'''a'''"
    assert unquote('"""a"""') == '"""a"""'

    # ... then we remove only the outermost pair of quotes.

# Generated at 2022-06-23 02:51:01.407611
# Unit test for function unquote
def test_unquote():
    data = "foo"
    expected = "foo"
    assert unquote(data) == expected

    data = "\"foo\""
    expected = "foo"
    assert unquote(data) == expected

    data = "'foo'"
    expected = "foo"
    assert unquote(data) == expected

    data = "\"foo"
    expected = "\"foo"
    assert unquote(data) == expected

    data = "'foo"
    expected = "'foo"
    assert unquote(data) == expected

    data = "foo\""
    expected = "foo\""
    assert unquote(data) == expected

    data = "foo'"
    expected = "foo'"
    assert unquote(data) == expected


# Generated at 2022-06-23 02:51:10.907047
# Unit test for function is_quoted
def test_is_quoted():
    # Test a basic unquoted string
    data = 'abcde'
    assert(is_quoted(data) == False)

    # Test a basic quoted string
    data = '"abcde"'
    assert(is_quoted(data) == True)

    # Test a string with single quotes
    data = "'abcde'"
    assert(is_quoted(data) == True)

    # Test a string with two double quotes
    data = "ab\"cd\"e"
    assert(is_quoted(data) == False)

    # Test a string with two single quotes
    data = "ab\'cd\'e"
    assert(is_quoted(data) == False)

    # Test a string with an escaped double quote
    data = "ab\\\"cd\\\"e"

# Generated at 2022-06-23 02:51:16.602786
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('\'foo') == '\'foo'
    assert unquote('foo') == 'foo'



# Generated at 2022-06-23 02:51:21.406912
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote("'hello world'") == 'hello world'
    assert unquote('hello world') == 'hello world'
    assert unquote('hello "world') == 'hello "world'



# Generated at 2022-06-23 02:51:26.581344
# Unit test for function is_quoted
def test_is_quoted():
    # Expected value: True
    assert is_quoted("'hello'")
    # Expected value: True
    assert is_quoted("\"hello\"")
    # Expected value: False
    assert not is_quoted("hello")
    # Expected value: False
    assert not is_quoted("'hello\"")
    # Expected value: False
    assert not is_quoted("\"hell'o")


# Generated at 2022-06-23 02:51:35.247458
# Unit test for function is_quoted
def test_is_quoted():
    ''' function is_quoted should recognize quoted strings '''
    assert is_quoted('"string"')
    assert is_quoted('"a"b"')
    assert is_quoted('''"a'b"''')

    # is_quoted should ignore the content of the string and
    # only check the first and the last character
    assert is_quoted('foo"string"bar')
    assert is_quoted('foo"a"b"bar')
    assert is_quoted('''foo"a'b"bar''')

    # is_quoted should return False when receiving an unquoted string
    assert not is_quoted('string')
    assert not is_quoted('''a'b''')
    assert not is_quoted('foo')
    assert not is_quoted('"foobar')

# Generated at 2022-06-23 02:51:47.993916
# Unit test for function split_args
def test_split_args():
    ans = []
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b c=d\ne=f g=h\ni=j k=l") == ["a=b", "c=d\ne=f", "g=h\ni=j", "k=l"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo \\\"bar\\\" baz\"") == ['a=b', 'c="foo \\"bar\\" baz"']

# Generated at 2022-06-23 02:51:58.605874
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted("'hello'") == True
    assert is_quoted("'hello") == False
    assert is_quoted("hello'") == False
    assert is_quoted('"hello\'') == False
    assert is_quoted('\'hello"') == False
    assert is_quoted("'hello\"") == False
    assert is_quoted('"hel"lo"') == False
    assert is_quoted('""') == False
    assert is_quoted('') == False


# Generated at 2022-06-23 02:52:08.845271
# Unit test for function split_args
def test_split_args():
    import unittest

    class TestSplitArgs(unittest.TestCase):


        def test_basic(self):
            args = split_args("foo='bar baz' one=1 two=2 three=3")
            self.assertEqual(args, ['foo=\'bar baz\'', "one=1", "two=2", "three=3"])

        def test_quotes_with_newlines_single(self):
            # this used to end up in one param, it should be split into 3
            args = split_args("abc=\"foo\nbar\nbaz\"")
            self.assertEqual(args, ['abc="foo\nbar\nbaz"'])


# Generated at 2022-06-23 02:52:17.199743
# Unit test for function unquote
def test_unquote():
    # Test with some strings
    test_strings = [
        ('"thisstring"', 'thisstring'),
        ('"this string"', '"this string"'),
        ('"this \'str\'ing"', '"this \'str\'ing"'),
        ('\'this "str"ing\'', '\'this "str"ing\''),
        ('"this\\string"', '"this\\string"'),
        ('this\\string', 'this\\string'),
        ('thisstring', 'thisstring'),
        ('', ''),
        ('""', ''),
        ('"', '"'),
        ('"\\""', '"\\""'),
        ('\'"\'', '\'"\''),
        ('\\"', '"')]


# Generated at 2022-06-23 02:52:21.860231
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'
    foo = '''
    This string has several
lines, some of which
    contain whitespace.'''
    assert unquote(foo) == foo

# Generated at 2022-06-23 02:52:32.859167
# Unit test for function split_args
def test_split_args():
    '''
    This is some testing code that can be run via nosetests to verify the
    functionality of the split_args function.
    '''

    # make sure we throw an exception when we have unbalanced quotes
    try:
        split_args('a=b c="foo')
        raise Exception("this test should have thrown an exception")
    except:
        pass

    # make sure we throw an exception when we have unbalanced jinja2 blocks
    try:
        split_args('a=b c="{{foo')
        raise Exception("this test should have thrown an exception")
    except:
        pass

    # test a variety of escaped characters
    test1 = 'a="foo bar" b="\" c=\\ d=\\"" e=\\\\"'

# Generated at 2022-06-23 02:52:37.474892
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("'moo'")
    assert not is_quoted("'moo")
    assert not is_quoted('"moo')


# Generated at 2022-06-23 02:52:48.944944
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('"a"') == ['a']
    assert split_args('"a b"') == ['a b']
    assert split_args('a=1') == ['a=1']
    assert split_args('a=1 b=2') == ['a=1', 'b=2']
    # assert split_args('a="b c"') == ['a=b c']
    assert split_args('a=1 "b c"') == ['a=1', 'b c']
    assert split_args('a=1 b="c d"') == ['a=1', 'b=c d']
    assert split_args('a=1 b="c d" e=3') == ['a=1', 'b=c d', 'e=3']
    assert split_

# Generated at 2022-06-23 02:52:55.037898
# Unit test for function is_quoted
def test_is_quoted():
    print("\nTesting is_quoted")
    assert is_quoted('') == False
    assert is_quoted('""') == True
    assert is_quoted('"a"') == True
    assert is_quoted('"ab"') == True
    assert is_quoted('"abc"') == True
    assert is_quoted('"a"b"') == False
    assert is_quoted('\'\'') == True
    assert is_quoted('\'a\'') == True
    assert is_quoted('\'ab\'') == True
    assert is_quoted('\'abc\'') == True
    assert is_quoted('\'a\'b\'') == False


# Generated at 2022-06-23 02:53:00.646201
# Unit test for function unquote
def test_unquote():
    result = unquote("''")
    assert not result

    result = unquote("hello")
    assert result == "hello"

    result = unquote("'hello'")
    assert result == "hello"

    result = unquote("he'llo")
    assert result == "he'llo"

    result = unquote("'he'llo'")
    assert result == "he'llo"


# Generated at 2022-06-23 02:53:06.139034
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"abc"') == True)
    assert(is_quoted("'abc'") == True)
    assert(is_quoted('"ab"c"') == False)
    assert(is_quoted('"abc') == False)
    assert(is_quoted('abc"') == False)
    assert(is_quoted('"abc') == False)
    assert(is_quoted('abc') == False)

#Unit test for function unquote

# Generated at 2022-06-23 02:53:12.184301
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('hello')  == 'hello'
    assert unquote('"a" == "a"') == 'a" == "a'
    print('unquote works as expected')


# Generated at 2022-06-23 02:53:17.130380
# Unit test for function unquote
def test_unquote():
    test1 = "'this is a quoted string'"
    test2 = "this is an unquoted string"
    test3 = "this is a 'single quoted string'"
    result1 = unquote(test1)
    result2 = unquote(test2)
    result3 = unquote(test3)
    assert result1 == "this is a quoted string"
    assert result2 == "this is an unquoted string"
    assert result3 == "this is a 'single quoted string'"

# Generated at 2022-06-23 02:53:28.255414
# Unit test for function split_args
def test_split_args():
    '''
    test the split_args() function
    '''
    print()
    print("*** Test split_args")

    def compare(args, expected):
        print("Args: {}".format(args))
        print("Expected: {}".format(expected))
        result = split_args(args)
        print("Got     : {}".format(result))
        if expected != result:
            raise Exception("Unexpected args returned")

    compare("a=b c=\"foo bar\"", ["a=b", "c=\"foo bar\""])
    compare('a=b c="foo bar baz"', ['a=b', 'c="foo bar baz"'])
    compare('a=b c="foo bar baz" \\', ['a=b', 'c="foo bar baz" \\'])

# Generated at 2022-06-23 02:53:38.704575
# Unit test for function split_args

# Generated at 2022-06-23 02:53:48.371019
# Unit test for function split_args
def test_split_args():
    ''' make sure our custom arg splitter works as expected '''
    arg_str = 'one="two three" four'
    arg_list = split_args(arg_str)
    assert arg_list == ['one="two three"', 'four']

    arg_str = 'one="two three" four five="six seven"'
    arg_list = split_args(arg_str)
    assert arg_list == ['one="two three"', 'four', 'five="six seven"']

    arg_str = 'one="two three" four five="six seven"'
    arg_list = split_args(arg_str)
    assert arg_list == ['one="two three"', 'four', 'five="six seven"']

    arg_str = 'one="two three" four {{ five="six seven" }}'

# Generated at 2022-06-23 02:53:57.809709
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"quoted\"")
    assert is_quoted("\"quoted-with-dash\"")
    assert is_quoted("\"\"")
    assert is_quoted("\"") == False
    assert is_quoted("\'quoted\'")
    assert is_quoted("\'") == False
    assert is_quoted("\'\'")
    assert is_quoted("\'quoted-with-dash\'")
    assert is_quoted("") == False
    assert is_quoted("simple") == False
    assert is_quoted("simple-with-dash") == False


# Generated at 2022-06-23 02:54:07.523418
# Unit test for function split_args
def test_split_args():

    expected_result = ['a=b', 'c="foo bar"']
    actual_result = split_args("a=b c=\"foo bar\"")
    assert actual_result == expected_result, \
        "Expected result: {0}, Actual result: {1}".format(expected_result, actual_result)

    expected_result = ['a=foo', 'b=\'bar baz\'']
    actual_result = split_args("a=foo b='bar baz'")
    assert actual_result == expected_result, \
        "Expected result: {0}, Actual result: {1}".format(expected_result, actual_result)

    expected_result = ['a=foo', 'b="bar baz"']
    actual_result = split_args("a=foo b=\"bar baz\"")
    assert actual_

# Generated at 2022-06-23 02:54:16.378308
# Unit test for function unquote
def test_unquote():
    assert 'foo' == unquote('"foo"')
    assert "'foo'" == unquote("'foo'")
    assert '' == unquote('""')
    assert '""' == unquote('""""')
    assert 'foo' == unquote('foo')
    assert 'foo' == unquote('"foo')
    assert 'foo' == unquote('foo"')
    assert '"foo"' == unquote('"""foo"""')
    assert '"foo' == unquote('"""foo')
    assert 'foo"' == unquote('foo"""')


# Generated at 2022-06-23 02:54:24.883594
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foo') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('"fo"o"') == False
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted("'fo'o'") == False
    assert is_quoted('"foo" "bar"') == False
    assert is_quoted('"foo" "bar') == False
    assert is_quoted("'foo' 'bar'") == False
    assert is_quoted("'foo' 'bar") == False
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False


# Generated at 2022-06-23 02:54:34.711701
# Unit test for function split_args
def test_split_args():

    def _test_split_args(s, expected):
        tokens = split_args(s)
        assert tokens == expected, "Split '%s' resulted in %s instead of %s"%(s, tokens, expected)

    _test_split_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _test_split_args('a=b c="foo bar" d="foo', ['a=b', 'c="foo bar"', 'd="foo'])
    _test_split_args('a=b c=\\"foo bar\\" d="foo', ['a=b', 'c="foo bar"', 'd="foo'])

# Generated at 2022-06-23 02:54:44.978363
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"""') == True
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"""foo"""') == True
    assert is_quoted('\'foo\'') == True
    assert is_quoted('\'foo') == False
    assert is_quoted('foo\'') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo""') == False
    assert is_quoted('""foo"') == False
    assert is_quoted('"""foo') == False
    assert is_quoted('foo"""') == False
    assert is_quoted('foo""') == False

# Generated at 2022-06-23 02:54:46.825792
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == 'hello'
    assert unquote("hello") == 'hello'



# Generated at 2022-06-23 02:54:51.455315
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"hello"') == True
    assert is_quoted('\'hello\'') == True
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted('hello') == False


# Generated at 2022-06-23 02:55:02.580320
# Unit test for function split_args
def test_split_args():
    failed_to_split_args = 0