

# Generated at 2022-06-23 02:45:14.875184
# Unit test for function split_args
def test_split_args():
    test_cases = dict()
    test_cases[''] = []
    test_cases['a b'] = ['a', 'b']
    test_cases['a b c'] = ['a', 'b', 'c']
    test_cases['a b c '] = ['a', 'b', 'c']
    test_cases[' a b c '] = ['a', 'b', 'c']
    test_cases[' a b c'] = ['a', 'b', 'c']

    test_cases[' a = b'] = ['a = b']
    test_cases['a = b'] = ['a = b']
    test_cases['a=b'] = ['a=b']
    test_cases[' a = b '] = ['a = b']
    test_cases['a = b '] = ['a = b']
   

# Generated at 2022-06-23 02:45:27.680404
# Unit test for function split_args
def test_split_args():

    assert split_args("-a foo") == ['-a', 'foo']
    assert split_args("-a foo bar") == ['-a', 'foo bar']
    assert split_args("-a 'foo bar'") == ['-a', "'foo bar'"]
    assert split_args("-a \"foo bar\"") == ['-a', '"foo bar"']
    assert split_args("-a 'foo bar' baz") == ['-a', "'foo bar'", 'baz']
    assert split_args("-a \"foo bar\" baz") == ['-a', '"foo bar"', 'baz']
    assert split_args("-a \"foo bar\" 'baz bang'") == ['-a', '"foo bar"', "'baz bang'"]

# Generated at 2022-06-23 02:45:34.295085
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('"foo bar') == '"foo bar'
    assert unquote('foo bar"') == 'foo bar"'
    assert unquote('foo') == 'foo'
    assert unquote('foo bar') == 'foo bar'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('"foo bar') == '"foo bar'
    assert unquote('foo bar"') == 'foo bar"'
    assert unquote('"""') == '""'
    assert unquote('""""""') == '""""'


# Generated at 2022-06-23 02:45:45.624954
# Unit test for function split_args

# Generated at 2022-06-23 02:45:54.549000
# Unit test for function split_args

# Generated at 2022-06-23 02:45:57.835604
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('\'hello"') == '\'hello"'
    assert unquote('"hello\'') == '"hello\''
    assert unquote('"hello world"') == 'hello world'


# Generated at 2022-06-23 02:46:07.335469
# Unit test for function unquote
def test_unquote():
    assert unquote("'Hello World'") == "Hello World"
    assert unquote("'Hello \"World\"'") == "Hello \"World\""
    assert unquote("\"Hello 'World'\"") == "Hello 'World'"
    assert unquote("'Hello \\\'World\\\'\"") == "Hello \\\'World\\\'\""
    assert unquote("\"Hello 'World'") == "\"Hello 'World'"
    assert unquote("Hello 'World'\"") == "Hello 'World'\""
    assert unquote("Hello World'") == "Hello World'"
    assert unquote("'Hello World") == "'Hello World"
    assert unquote("'Hello World'") == "Hello World"
    assert unquote("\"Hello World\"") == "Hello World"
    assert unquote("Hello World") == "Hello World"


# Generated at 2022-06-23 02:46:09.806268
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote('some text') == 'some text'
    assert unquote('"c:\\program files"') == 'c:\\program files'



# Generated at 2022-06-23 02:46:15.728326
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'I was quoted'")
    assert is_quoted('"I was quoted"')
    assert is_quoted("'I'll be quoted'")
    assert is_quoted("'I\\'ll be quoted'")
    assert not is_quoted("I was not quoted")
    assert not is_quoted("'I was not quoted")
    assert not is_quoted("I was not quoted'")
    assert not is_quoted("I'm not quoted")
    assert not is_quoted("'I'm not quoted'")


# Generated at 2022-06-23 02:46:27.153573
# Unit test for function split_args

# Generated at 2022-06-23 02:46:33.189042
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"abc"'))
    assert(is_quoted("'abc'"))
    assert(is_quoted('""'))
    assert(is_quoted("''"))
    assert(not is_quoted('"'))
    assert(not is_quoted("'"))
    assert(not is_quoted('abc'))
    assert(not is_quoted('"abc'))



# Generated at 2022-06-23 02:46:35.741530
# Unit test for function unquote
def test_unquote():
    assert unquote(u'"Blah Blah"') == u'Blah Blah'
    assert unquote(u"'Blah Blah'") == u'Blah Blah'


# Generated at 2022-06-23 02:46:43.700539
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') == True
    assert is_quoted("''") == True
    assert is_quoted('test') == False
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True


# Generated at 2022-06-23 02:46:48.546363
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'


# Generated at 2022-06-23 02:46:52.659293
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote("''") == ''



# Generated at 2022-06-23 02:47:02.302912
# Unit test for function split_args
def test_split_args():
    testargs = ["foo=bar", 'foo="bar baz"', "foo='bar baz bax'", 'foo=bar baz',
                "foo={{ testvar }}", 'foo="bar {{ testvar }} bax"', "foo='bar {{ testvar }} bax'",
                "foo={% if testvar %}bar{% endif %}",
                "foo=\"bar {% if testvar %}bar{% endif %} bax\"", "foo='bar {% if testvar %}bar{% endif %} bax'",
                "foo={# some comment #}", "foo=\"bar {# some comment #} bax\"", "foo='bar {# some comment #} bax'"
                ]

    for arg in testargs:
        res = split_args(arg)

# Generated at 2022-06-23 02:47:11.765295
# Unit test for function split_args
def test_split_args():
    def check(expected, argstr):
        result = split_args(argstr)
        if result != expected:
            raise AssertionError("Expected split_args(%s) to be %s, but got %s" % (argstr, expected, result))
    check(['"foo"', 'bar', '"baz with spaces"'],  '"foo" bar "baz with spaces"')
    check(['foo', 'bar', 'baz', '"bam with spaces"'],  'foo bar baz "bam with spaces"')
    check(['foo', 'bar', 'baz', '"bam with spaces"'],  "foo bar baz 'bam with spaces'")

# Generated at 2022-06-23 02:47:15.789079
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote('foo') == "foo"
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'



# Generated at 2022-06-23 02:47:23.521723
# Unit test for function split_args
def test_split_args():
    ''' test splitting arguments '''

    # simple space split
    # same after being reassembled
    assert split_args("a b") == ["a", "b"]

    # simple newline split
    # same after being reassembled
    assert split_args("a\nb") == ["a\nb"]

    # newline in quotes should not affect split
    # same after being reassembled
    assert split_args('a="foo\nbar"') == ['a="foo\nbar"']
    assert split_args('a=\'foo\nbar\'') == ["a='foo\nbar'"]

    # pipe in single quotes is not split
    # same after being reassembled
    assert split_args("a='foo|bar'") == ["a='foo|bar'"]

    # pipe in double quotes is not split
    # same after being

# Generated at 2022-06-23 02:47:36.418837
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('hello')
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("hel'lo")
    assert not is_quoted("hello")
    assert not is_quoted("he'llo")
    assert not is_quoted("hel\"lo")
    assert is_quoted("\"he'llo\"")
    assert is_quoted("\"hel\"\"lo\"")
    assert is_quoted("\"hel\"lo\"")
    assert not is_quoted("\"hello")
    assert not is_quoted("'hello\"")


# Generated at 2022-06-23 02:47:48.500038
# Unit test for function split_args
def test_split_args():
    '''
    Uses the test matrix below to test the function split_args
    '''

# Generated at 2022-06-23 02:47:53.297513
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"abc"') == True)
    assert(is_quoted("'abc'") == True)
    assert(is_quoted("'a'bc'") == False)
    assert(is_quoted("'ab'c'") == False)
    assert(is_quoted("'abc") == False)
    assert(is_quoted('"abc') == False)


# Generated at 2022-06-23 02:48:04.875564
# Unit test for function split_args
def test_split_args():
    '''
    Run unit tests for the split_args function.
    '''

    # Some sample arg strings and the expected result after running split_args

# Generated at 2022-06-23 02:48:15.068610
# Unit test for function is_quoted
def test_is_quoted():

    # For generic tests
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted("\"") == False
    assert is_quoted("''") == False
    assert is_quoted("\"\"") == False
    assert is_quoted("'a'") == True
    assert is_quoted("'abcd'") == True
    assert is_quoted("\"a\"") == True
    assert is_quoted("\"abcd\"") == True
    assert is_quoted("abcd") == False
    assert is_quoted("'ab'cd'") == False
    assert is_quoted("\"ab\"cd\"") == False
    assert is_quoted("'abcd") == False
    assert is_quoted("\"abcd") == False


#

# Generated at 2022-06-23 02:48:17.467041
# Unit test for function unquote
def test_unquote():
    assert "abcd" == unquote('"abcd"')
    assert "abcd" == unquote("'abcd'")
    assert "abcd" == unquote('abcd')


# Generated at 2022-06-23 02:48:19.786989
# Unit test for function unquote
def test_unquote():
    data = '"a"'
    assert unquote(data) == 'a'


# Generated at 2022-06-23 02:48:35.151232
# Unit test for function split_args
def test_split_args():
    # Basic test
    assert split_args("foo=bar") == ["foo=bar"]

    # Test with quotes
    assert split_args("helo='world this is cool'") == ["helo='world this is cool'"]

    # Test with jinja2 in the quotes
    assert split_args("helo='world {{this}} is {{cool}}'") == ["helo='world {{this}} is {{cool}}'"]

    # Test with jinja2 not in quotes, which should split the arguments
    assert split_args("helo='world' this='is' cool") == ["helo='world'", "this='is'", "cool"]

    # Test with lots of quotes and jinja2, which is the main use case

# Generated at 2022-06-23 02:48:45.212454
# Unit test for function split_args
def test_split_args():

    assert ['a=b'] == split_args(" a=b ")
    assert ['a=b'] == split_args("a=b")
    assert ['a=b'] == split_args("a=b\n")
    assert ['a=b'] == split_args("a=b\n\n")
    assert ['a=b', 'c=d'] == split_args("a=b c=d")
    assert ['a=b', 'c=d'] == split_args("a=b c=d\n")
    assert ['a="b c"'] == split_args("a=\"b c\"")
    assert ['a="b c"'] == split_args("a=\"b c\"\n")
    assert ['a="b\nc"'] == split_args("a=\"b\nc\"")

# Generated at 2022-06-23 02:48:56.646129
# Unit test for function unquote
def test_unquote():
    if unquote('"abc"') != 'abc':
        raise ValueError("unquote('\"abc\"') must return 'abc'")
    if unquote("'xyz'") != 'xyz':
        raise ValueError("unquote(''xyz'') must return 'xyz'")
    if unquote('abc') != 'abc':
        raise ValueError("unquote('abc') must return 'abc'")
    if unquote('"abc') != '"abc':
        raise ValueError("unquote('\"abc') must return '\"abc'")
    if unquote("'abc") != "'abc":
        raise ValueError("unquote(''abc') must return ''abc'")
    if unquote('abc\'') != 'abc\'':
        raise ValueError("unquote('abc\'') must return 'abc\''")


# Generated at 2022-06-23 02:49:06.463286
# Unit test for function unquote
def test_unquote():
    assert unquote('this is a string') == 'this is a string'
    assert unquote('"this is a string"') == 'this is a string'
    assert unquote('"this \'is\' a string"') == 'this \'is\' a string'
    assert unquote('\'this "is" a string\'') == 'this "is" a string'
    assert unquote('"this \"is\" a string"') == 'this "is" a string'
    assert unquote('"this \'is\' a string\"') == 'this \'is\' a string"'
    assert unquote('"\"this" is a string') == '"this" is a string'
    assert unquote('\'\"this\' is a string') == '"this\' is a string'

# Generated at 2022-06-23 02:49:15.290732
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') == True
    assert is_quoted('""""') == False
    assert is_quoted('"""') == False
    assert is_quoted('"') == False

    assert is_quoted("''") == True
    assert is_quoted("''''") == False
    assert is_quoted("'''") == False
    assert is_quoted("'") == False

    assert is_quoted("'\"") == False
    assert is_quoted("\"'") == False



# Generated at 2022-06-23 02:49:26.972412
# Unit test for function split_args
def test_split_args():
    # test with jinja blocks
    assert split_args("a='{{foo}}' b='{{bar}}' c='{{bam}}'") == ["a='{{foo}}'", "b='{{bar}}'", "c='{{bam}}'"]
    assert split_args("a='{{foo}}' b='{{bar}}' c='{{bam}}'\n") == ["a='{{foo}}'", "b='{{bar}}'", "c='{{bam}}'\n"]
    assert split_args("a='{{foo}}' b='{{bar}}' c='{{bam}}'\n\n") == ["a='{{foo}}'", "b='{{bar}}'", "c='{{bam}}'\n\n"]

# Generated at 2022-06-23 02:49:35.710454
# Unit test for function split_args
def test_split_args():
    result = split_args('''{% if greeting == 'hello' and recipient in ['world', 'universe'] %}42{% else %}0{% endif %}''')
    assert result == ["{%", "if", "greeting", "==", "'hello'", "and", "recipient", "in", "['world',", "'universe']", "%}42{%", "else", "%}0{%", "endif", "%}"]

    result = split_args("user='bob'")
    assert result == ["user='bob'"]

    result = split_args("foo bar")
    assert result == ['foo', 'bar']

    result = split_args("foo \\")
    assert result == ['foo', '\\']

    result = split_args("foo \\ \nbar")

# Generated at 2022-06-23 02:49:47.937886
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert not is_quoted('"hello')
    assert not is_quoted('hello"')
    assert not is_quoted('''hello''')
    assert not is_quoted('''hello"''')
    assert is_quoted('''"hello"''')
    assert is_quoted(r'''"hello"''')
    assert not is_quoted(r'''"hello''')
    assert is_quoted(r'''"hello\""''')
    assert not is_quoted(r'''"hello\"''')
    assert is_quoted(r'''"\"hello\""''')
    assert is_quoted(r"'" + "'".join(["hello"] * 100) + "'")

# Generated at 2022-06-23 02:49:55.539812
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")
    assert not is_quoted('"foobar')
    assert not is_quoted("'foobar")
    assert not is_quoted('foobar"')
    assert not is_quoted("foobar'")
    assert not is_quoted('"foobar\'')
    assert not is_quoted('\'foobar"')
    assert not is_quoted('""')
    assert not is_quoted("''")


# Generated at 2022-06-23 02:49:59.175173
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('foo') == 'foo'

# Generated at 2022-06-23 02:50:08.746103
# Unit test for function unquote
def test_unquote():
    assert(unquote("'this is a quoted string'") == 'this is a quoted string')
    assert(unquote('"this is a quoted string"') == 'this is a quoted string')
    assert(unquote("'this is a quoted string") == "'this is a quoted string")
    assert(unquote('"this is a quoted string') == '"this is a quoted string')
    assert(unquote("this is a quoted string'") == "this is a quoted string'")
    assert(unquote('this is a quoted string"') == 'this is a quoted string"')
    assert(unquote("this is a quoted string") == "this is a quoted string")
    assert(unquote('') == '')


# Generated at 2022-06-23 02:50:11.614317
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted("'test")
    assert not is_quoted("test")
    assert not is_quoted("'test'extra")



# Generated at 2022-06-23 02:50:14.157598
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') is True
    assert is_quoted("'hello'") is True



# Generated at 2022-06-23 02:50:23.233133
# Unit test for function is_quoted
def test_is_quoted():
    quoted_strings = (
        ('"foo"', True),
        ('"foo', False),
        ('foo"', False),
        ("'foo'", True),
        ("'foo", False),
        ('foo\'', False),
        (u'"foo"', True),
        (u'"foo', False),
        (u'foo"', False),
        (u"'foo'", True),
        (u"'foo", False),
        (u'foo\'', False),
    )

    for s, b in quoted_strings:
        if is_quoted(s) != b:
            msg = "Expected is_quoted() to return '%s' for the string %r" % (b, s)
            raise Exception(msg)

# unit tests for function unquote

# Generated at 2022-06-23 02:50:35.383883
# Unit test for function split_args

# Generated at 2022-06-23 02:50:39.612492
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted("'a'bc'") == False
    assert is_quoted("'ab'c'") == False


# Generated at 2022-06-23 02:50:48.712221
# Unit test for function split_args

# Generated at 2022-06-23 02:50:53.799707
# Unit test for function is_quoted
def test_is_quoted():
  assert is_quoted('"""')
  assert is_quoted("'''")
  assert is_quoted("'foobar'")
  assert is_quoted("foobar") == False
  assert is_quoted("'foobar") == False
  assert is_quoted("foobar'") == False


# Generated at 2022-06-23 02:50:59.721361
# Unit test for function unquote
def test_unquote():
    if unquote('"foo"') != 'foo':
        raise AssertionError
    if unquote('"foo') == '"foo':
        raise AssertionError
    if unquote('foo"') == 'foo"':
        raise AssertionError
    if unquote('"""') == '"""':
        raise AssertionError
    if unquote('""') != '':
        raise AssertionError


# Generated at 2022-06-23 02:51:10.422158
# Unit test for function split_args

# Generated at 2022-06-23 02:51:19.263070
# Unit test for function split_args
def test_split_args():
    '''
    Test cases are written outside of the function so that pylint will not
    complain about them not being called.
    '''

# Generated at 2022-06-23 02:51:28.562793
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == "abc"
    assert unquote("'abc'") == "abc"
    assert unquote("abc") == "abc"


# Generated at 2022-06-23 02:51:34.250780
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('foo')


# Generated at 2022-06-23 02:51:37.818025
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert is_quoted('\\"foo\\"')
    assert is_quoted("\\'foo\\'")


# Generated at 2022-06-23 02:51:43.383120
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('""foo""') == '"foo"'
    assert unquote("''foo''") == "'foo'"



# Generated at 2022-06-23 02:51:57.718747
# Unit test for function split_args
def test_split_args():
    # test basic arg splitting
    assert split_args('a b c d') == ['a', 'b', 'c', 'd']

    # test that arg splitting handles quoted args
    assert split_args('a "b b" c') == ['a', '"b b"', 'c']
    assert split_args('a "b b" "c c"') == ['a', '"b b"', '"c c"']
    assert split_args('a "b b" "c c" "d d') == ['a', '"b b"', '"c c"', '"d d']

    # make sure quotes are not split across line boundaries
    assert split_args('a b "c c c\nc c c') == ['a', 'b', '"c c c\nc c c']

    # test that escaped quotes are ignored


# Generated at 2022-06-23 02:52:06.153419
# Unit test for function unquote
def test_unquote():
    # test even with spaces, the quotes are removed
    assert unquote("'foo bar'") == "foo bar"
    assert unquote('"foo bar"') == "foo bar"

    # test quotes within string are left alone
    assert unquote("'foo bar' baz") == "'foo bar' baz"
    assert unquote("'foo bar' baz") == "'foo bar' baz"

    # test unquoted data is returned unmodified
    assert unquote("foo bar") == "foo bar"

    # test empty string is returned unmodified
    assert unquote("") == ""

    # test apostrophes are removed
    assert unquote("'foo bar'") == "foo bar"

    # test backticks are removed
    assert unquote("`foo bar`") == "foo bar"

    # test bracketing of quotes is

# Generated at 2022-06-23 02:52:15.487588
# Unit test for function split_args
def test_split_args():

    # Main test, this will cover most of the parsing needs:
    # run 'nosetests -v unit/utils.py' to run this test
    args = '''
    a=b c="foo bar" 'foo bar' \
    d="{{ foo }}" e='{{ "foo" }}' f="{% foo %}" g='{% "foo" %}' \
    h="{# foo #}" i='{# "foo" #}' \
    j="{# {{ fn() }}.join(a) #} {% {{ fn() }}.join(a) %}"
    '''
    params = split_args(args)

# Generated at 2022-06-23 02:52:26.165864
# Unit test for function split_args
def test_split_args():
    assert split_args('"a=b" c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('"a=b" c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('"a=\"b\"" c="foo bar"') == ['a="b"', 'c="foo bar"']
    assert split_args('"a=\'b\'" c="foo bar"') == ["a='b'", 'c="foo bar"']
    assert split_args('"a=\'b\'\" c="foo bar"') == ["a='b'", 'c="foo bar"']
    assert split_args('a="b c"') == ['a=b c']

# Generated at 2022-06-23 02:52:30.057139
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted("'foo") == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo') == False


# Generated at 2022-06-23 02:52:38.278056
# Unit test for function split_args
def test_split_args():

    # We're going to test all the possible ways we parse args
    # some of these are probably not useful, but we're being
    # excessively thorough here.  Hopefully, this will catch any
    # regressions that might happen in the future.

    tests = []

    # simple test where the white space is not in any quotes
    tests.append((["foo", "bar", "baz"], "foo bar baz"))

    # simple test where the white space is in double quotes
    tests.append((["foo bar", "baz"], '"foo bar" baz'))

    # simple test where the white space is in single quotes
    tests.append((["foo bar", "baz"], "'foo bar' baz"))

    # test with a jinja2 var inside double quotes

# Generated at 2022-06-23 02:52:48.178337
# Unit test for function split_args

# Generated at 2022-06-23 02:52:53.433899
# Unit test for function unquote
def test_unquote():
    assert unquote('hello') == 'hello'
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('"\'hello\'"') == '\'hello\''
    assert unquote("'\"hello\"'") == '"hello"'
    assert unquote('"\'"hello\'"\'') == '\'"hello"\''
    assert unquote('\'"hello"\'') == '\'"hello"\''


# Generated at 2022-06-23 02:53:03.562455
# Unit test for function unquote
def test_unquote():
    assert is_quoted(unquote('foo')) == False
    assert is_quoted(unquote('"foo"')) == True
    assert is_quoted(unquote('"foo')) == False
    assert is_quoted(unquote('foo"')) == False
    assert unquote('"foo"') == "foo"
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote(unquote('"foo"')) == 'foo'
    assert unquote(unquote('"""foo"""')) == '"foo"'
    assert unquote(unquote('"foo bar"')) == 'foo bar'
    assert unquote(unquote('"foo bar')) == '"foo bar'
    assert unquote(unquote('foo bar"')) == 'foo bar"'

# Generated at 2022-06-23 02:53:15.628764
# Unit test for function split_args
def test_split_args():

    # Ensure we can handle a single token simply
    assert split_args('a=b') == ['a=b']

    # Ensure we can handle quoted strings that have whitespace
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Ensure we can handle quoted strings at the end of the
    # string that have whitespace
    assert split_args('a=b c="foo bar" d="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']

    # Ensure we can handle quoted strings at the beginning of
    # the string that have whitespace
    assert split_args('a="foo bar" b=c') == ['a="foo bar"', 'b=c']

    # Ensure we can handle quoted strings at the beginning of
    #

# Generated at 2022-06-23 02:53:20.527029
# Unit test for function is_quoted
def test_is_quoted():

    # Test for simple quotes
    data = '"This is a quoted string" with unquoted text'
    assert is_quoted(data)

    # Test for single quotes
    data = "'This is a quoted string' with unquoted text"
    assert is_quoted(data)

    # Test for unquoted
    data = 'This is an unquoted string with unquoted text'
    assert not is_quoted(data)

    # Test for empty string
    data = ''
    assert not is_quoted(data)



# Generated at 2022-06-23 02:53:24.617088
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'

# Generated at 2022-06-23 02:53:35.447684
# Unit test for function split_args
def test_split_args():
    '''test the split_args function'''

    # test simple space separated args
    res = split_args("a=b c=\"foo bar\"")
    assert res == ['a=b', 'c="foo bar"']

    # test args with spaces in the middle of jinja2 blocks
    res = split_args("a=b c=\"foo {{ bar }}\"")
    assert res == ['a=b', 'c="foo {{ bar }}"']

    # test args with spaces in the middle of quotes
    res = split_args("a=b c=\"foo bar\"")
    assert res == ['a=b', 'c="foo bar"']

    # test args with spaces in the middle of quotes
    # and jinja2 blocks
    res = split_args("a=b c=\"foo {{ bar }}\"")

# Generated at 2022-06-23 02:53:43.328914
# Unit test for function unquote
def test_unquote():
    test_strings = [
        ('\'mysql_foo\'','mysql_foo'),
        ('"mysql_foo"','mysql_foo'),
        ('\'mysql_foo', '\'mysql_foo'),
        ('"mysql_foo', '"mysql_foo'),
        ('mysql_foo\'', 'mysql_foo\''),
        ('mysql_foo"', 'mysql_foo"'),
        ('mysql_foo', 'mysql_foo'),
        ('"mysql_foo123"', 'mysql_foo123'),
    ]
    for (test_string, result) in test_strings:
        assert unquote(test_string) == result


# Generated at 2022-06-23 02:53:48.218811
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"') == True
    assert is_quoted('\'abcd\'') == True
    assert is_quoted('"abcd\'') == False
    assert is_quoted('\'abcd"') == False
    assert is_quoted('abcd') == False


# Generated at 2022-06-23 02:53:53.311694
# Unit test for function unquote
def test_unquote():
    data = '"hello"'
    assert unquote(data) == "hello"
    data = "'hello'"
    assert unquote(data) == "hello"
    data = '"'
    assert unquote(data) == '"'
    data = "'"
    assert unquote(data) == "'"

# Generated at 2022-06-23 02:53:58.154218
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"hello"') == True)
    assert(is_quoted("'hello'") == True)
    assert(is_quoted('hello') == False)
    assert(is_quoted('"hello') == False)
    assert(is_quoted('hello"') == False)


# Generated at 2022-06-23 02:54:07.492997
# Unit test for function is_quoted
def test_is_quoted():
    print("Testing is_quoted...")
    assert(is_quoted("'hello world'") == True)
    assert(is_quoted("'hello world") == False)
    assert(is_quoted("hello world'") == False)
    assert(is_quoted("hello world") == False)
    assert(is_quoted("'hello' world'") == False)
    assert(is_quoted("\"hello world\"") == True)
    assert(is_quoted("\"hello world") == False)
    assert(is_quoted("hello world\"") == False)
    assert(is_quoted("hello world") == False)
    assert(is_quoted("\"hello\" world\"") == False)
    print("Done.\n")


# Generated at 2022-06-23 02:54:13.819911
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('')
    assert not is_quoted('"test')
    assert not is_quoted('test"')
    assert not is_quoted("'test")
    assert not is_quoted('test\'')


# Generated at 2022-06-23 02:54:24.807154
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"""') == False
    assert is_quoted('"""foo') == False
    assert is_quoted('foo"""') == False
    assert is_quoted('"""foo""') == False
    assert is_quoted('"""foo"""') == False
    assert is_quoted('"""foo"""bar"""') == False
    assert is_quoted('''"'foo"''') == False
    assert is_quoted('"""foo"') == False
    assert is_quoted('"""foo') == False
    assert is_quoted('"""foo"""') == True
    assert is_quoted('"""foo""') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('"foo"""') == False
    assert is_

# Generated at 2022-06-23 02:54:34.674644
# Unit test for function split_args

# Generated at 2022-06-23 02:54:37.715504
# Unit test for function is_quoted
def test_is_quoted():
    '''
    A function testing the behaviour of is_quoted
    '''
    assert is_quoted('"something"') == True
    assert is_quoted("'something'") == True
    assert is_quoted('something"') == False
    assert is_quoted("something'") == False



# Generated at 2022-06-23 02:54:45.908845
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert not is_quoted('"abc')
    assert not is_quoted('abc"')
    assert not is_quoted('ab"c')
    assert is_quoted('"ab"c"')
    assert is_quoted("'abc'")
    assert not is_quoted("'abc")
    assert not is_quoted("abc'")
    assert not is_quoted("ab'c")
    assert is_quoted("'ab'c'")



# Generated at 2022-06-23 02:54:53.484956
# Unit test for function unquote
def test_unquote():
    assert unquote("''") == ""
    assert unquote("'foo'") == "foo"
    assert unquote("\"foo\"") == "foo"
    assert unquote("foo") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote("\"foo") == "\"foo"
    assert unquote("foo'") == "foo'"
    assert unquote("foo\"") == "foo\""
    assert unquote("'foo'bar'") == "foo'bar"
    assert unquote("\"foo\"bar\"") == "foo\"bar"
    assert unquote("foo") == "foo"

# Generated at 2022-06-23 02:54:57.311951
# Unit test for function unquote
def test_unquote():
    tests = [
        ('', ''),
        ('""', ''),
        ('""a', '""a'),
        ('a""', 'a""'),
        ('"a"', 'a'),
        ('abc', 'abc')
    ]

    for test in tests:
        if unquote(test[0]) != test[1]:
            raise Exception("unquote failed on argument '%s'" % test[0])


# Generated at 2022-06-23 02:55:10.901005
# Unit test for function split_args
def test_split_args():
    def _check_split_args(args, expected):
        actual = split_args(args)
        if actual != expected:
            print("\nError: split_args failed to split '''%s''' into correct tokens" % args)
            print("Expected: %s" % expected)
            print("Actual: %s" % actual)
        else:
            print("\nSuccess: split_args split '''%s''' into correct tokens" % args)
            print("Result: %s" % actual)

    print("")
    _check_split_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _check_split_args('a=b c=\'foo bar\'', ['a=b', "c='foo bar'"])
    _check_split_args