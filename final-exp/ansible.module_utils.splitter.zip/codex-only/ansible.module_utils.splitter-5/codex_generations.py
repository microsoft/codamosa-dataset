

# Generated at 2022-06-23 02:45:03.057995
# Unit test for function unquote
def test_unquote():
    test_string = '"Hello There" "Hello There"'
    assert unquote(test_string) == 'Hello There" "Hello There'



# Generated at 2022-06-23 02:45:11.565952
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"this is quoted"')
    assert is_quoted("'this is quoted'")
    assert is_quoted('"') is False
    assert is_quoted("'") is False
    assert is_quoted('') is False
    assert is_quoted('aoeu') is False
    assert is_quoted('"aoeu') is False
    assert is_quoted('aoeu"') is False
    assert is_quoted('"\\"aoeu\\""')
    assert is_quoted('"aoeu\\""')
    assert is_quoted('"aoeu"')
    assert is_quoted('"\\"aoeu"') is False
    assert is_quoted('"aoeu\\"') is False


# Generated at 2022-06-23 02:45:14.624446
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('abc')   == 'abc'



# Generated at 2022-06-23 02:45:27.452531
# Unit test for function split_args
def test_split_args():
    # Test basic parsing
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Test parsing with line continuation
    args = 'a=1 \\\nb=2'
    assert split_args(args) == ['a=1', 'b=2']

    # Test parsing with multiple line continuation
    args = 'a=1 \\\n  \\\n  b=2'
    assert split_args(args) == ['a=1', 'b=2']

    # Test parsing with line continuation inside quotes
    args = 'a=1 \\\nb="2 \\\n3"'
    assert split_args(args) == ['a=1', 'b="2 \\\n3"']


# Generated at 2022-06-23 02:45:32.739540
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'fo\"o") == "'fo\"o"
    assert unquote("\"fo'o") == "\"fo'o"
    assert unquote('') == ''



# Generated at 2022-06-23 02:45:37.541414
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'") == True
    assert is_quoted("'test") == False
    assert is_quoted("test") == False
    assert is_quoted("'") == False
    assert is_quoted("''") == False


# Generated at 2022-06-23 02:45:43.513318
# Unit test for function is_quoted
def test_is_quoted():

    # Test cases where function should return True
    assert(is_quoted('"test"') == True)
    assert(is_quoted("'test'") == True)
    assert(is_quoted('"test') == False)
    assert(is_quoted('test"') == False)
    assert(is_quoted("'test") == False)
    assert(is_quoted("test'") == False)


# Generated at 2022-06-23 02:45:52.645482
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u"a={{ b if c else 'foo' }}") == [u'a={{ b if c else \'foo\' }}']
    assert split_args(u"a={{ b if c else 'foo' }} d=e") == [u'a={{ b if c else \'foo\' }}', u'd=e']
    assert split_args(u"a={{ b if c else \"foo\" }} d=e") == [u'a={{ b if c else "foo" }}', u'd=e']

# Generated at 2022-06-23 02:46:03.094192
# Unit test for function is_quoted
def test_is_quoted():
    q = is_quoted
    assert not q("foo")
    assert not q("'foo")
    assert     q("'foo'")
    assert     q("'foo\"'")
    assert     q("'foo\"''")
    assert not q("\"foo\\\"'")
    assert not q("'foo'\"")
    assert not q("\"foo'\"")
    assert not q("foo\"")
    assert not q("\"foo")
    assert     q("\"foo\"")
    assert     q("\"foo\'\"")
    assert     q("\"foo\'\"\'")
    assert not q("\'foo\\\"\"")
    assert not q("\"foo\"\'")
    assert not q("\'foo\'")
    assert not q("\'foo\'")
    assert not q("\'foo")

# Generated at 2022-06-23 02:46:10.009837
# Unit test for function is_quoted
def test_is_quoted():
    assert( is_quoted('"test"') == True )
    assert( is_quoted('"test') == False )
    assert( is_quoted('test"') == False )
    assert( is_quoted('test') == False )

    assert( is_quoted("'test'") == True )
    assert( is_quoted("'test") == False )
    assert( is_quoted("test'") == False )
    assert( is_quoted("test") == False )

    assert( is_quoted('""') == True )
    assert( is_quoted("''") == True )


# Generated at 2022-06-23 02:46:22.405422
# Unit test for function split_args
def test_split_args():
    test_hash = {
        # arg, expected result
        'a=b c="foo bar"': [ 'a=b', 'c="foo bar"' ],
        'a=b c="foo bar"  d="hi there': [ 'a=b', 'c="foo bar"', 'd="hi there' ],
        'a=b c="foo bar"  d=hi\nthere': [ 'a=b', 'c="foo bar"', 'd=hi', 'there' ],
        'a=b c=foo\nd=bar': [ 'a=b', 'c=foo', 'd=bar' ]
    }
    for arg in list(test_hash.keys()):
        res = split_args(arg)

# Generated at 2022-06-23 02:46:28.681685
# Unit test for function unquote
def test_unquote():
    data1 = unquote('"This is a test"')
    data2 = unquote("'This is a test'")
    data3 = unquote("This is a test")
    data4 = unquote("'This is a test")

    if data1 != "This is a test" or data2 != "This is a test" or data3 != "This is a test" or data4 != "'This is a test":
        raise Exception("Error in unquote function")

test_unquote()

# Generated at 2022-06-23 02:46:35.726822
# Unit test for function is_quoted
def test_is_quoted():
    assert True is is_quoted('"foo"')
    assert True is is_quoted("'foo'")
    assert False is is_quoted("'foo")
    assert False is is_quoted("foo'")
    assert False is is_quoted("'foo\"")
    assert False is is_quoted('"foo\'')



# Generated at 2022-06-23 02:46:45.743411
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'a'") is True
    assert is_quoted('"a"') is True
    assert is_quoted('"a" "b"') is False
    assert is_quoted("'a' 'b'") is False
    assert is_quoted('') is False
    assert is_quoted('a') is False
    assert is_quoted('"a" a') is False


# Generated at 2022-06-23 02:46:51.313062
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') != 'foo'
    assert unquote("'foo") != 'foo'
    assert unquote('foo"') != 'foo'
    assert unquote("foo'") != 'foo'

# Generated at 2022-06-23 02:46:55.341660
# Unit test for function unquote
def test_unquote():
    assert unquote('a') == 'a'
    assert unquote('"a"') == 'a'
    assert unquote("'a'") == 'a'
    assert unquote('"""a"""') == '"""a"""'
    assert unquote("'''a'''") == "'''a'''"


# Generated at 2022-06-23 02:47:10.154663
# Unit test for function split_args
def test_split_args():
    ''' test split_args function '''
    # Test simple case, no spaces inside quotes:
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]

    # Test case with spaces inside quotes:
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test case with spaces and newlines inside quotes:
    assert split_args("a=b c='foo\nbar'") == ['a=b', "c='foo\nbar'"]

    # Test case with spaces inside quotes and jinja2 blocks:

# Generated at 2022-06-23 02:47:15.068528
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")
    assert not is_quoted('"foobar')
    assert not is_quoted('foobar"')
    assert not is_quoted('foobar')
    assert not is_quoted('')
    assert not is_quoted('   ')


# Generated at 2022-06-23 02:47:25.862751
# Unit test for function split_args
def test_split_args():
    # ensure defaults handling works
    assert split_args('') == []

    # ensure we're handling quotes correctly
    args = 'foo="bar baz" one=two'
    assert split_args(args) == ['foo="bar baz"', 'one=two']

    # ensure we're handling newlines correctly
    args = "['foo bar', 'hello world']"
    assert split_args(args) == ["['foo bar', 'hello world']"]
    args = "[foo\nbar\nhello\nworld]"
    assert split_args(args) == ["[foo", "bar", "hello", "world]"]
    args = "['foo\n bar',\n 'hello world']"
    assert split_args(args) == ["['foo", " bar',\n 'hello world']"]

# Generated at 2022-06-23 02:47:38.822356
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') != 'foo'
    assert unquote("'foo") != 'foo'

if __name__ == '__main__':
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from unit.compat import unittest


# Generated at 2022-06-23 02:47:49.302054
# Unit test for function split_args

# Generated at 2022-06-23 02:47:59.408693
# Unit test for function unquote
def test_unquote():
    # Simple checks
    assert(unquote("'test'") == "test")
    assert(unquote("test") == "test")
    assert(unquote('"test"') == "test")
    assert(unquote("'tes't") == "'tes't")
    assert(unquote("'t'est'") == "'t'est'")
    assert(unquote('"t"est"') == '"t"est"')

    # Check with an escaped quote
    assert(unquote("'te\"st'") == 'te"st')
    assert(unquote("'te\\'st'") == "te'st")
    assert(unquote("'te\\'st\"'") == "te'st\"")
    assert(unquote("'te\\'st'a") == "'te'st'a")

#

# Generated at 2022-06-23 02:48:04.526392
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"a\"bc"') == 'a\"bc'
    assert unquote('\'ab"c\'') == 'ab"c'
    assert unquote('""') == ''
    assert unquote('abc') == 'abc'



# Generated at 2022-06-23 02:48:14.858308
# Unit test for function split_args
def test_split_args():
    '''
    split_args provides useful functionality for the Runner() and shlex.split()
    isn't enough because it doesn't handle things like:
    ./script.py {{ foo.bar }} "{{ baz.boz }}" --foo={{ abc.def }}
    '''


# Generated at 2022-06-23 02:48:21.781386
# Unit test for function unquote
def test_unquote():
    # Checks removal of first and last quotes
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    # Checks removal of quotes only if they are of the same type
    assert unquote('"test\'') == '"test\''
    # Checks no removal if there are no quotes
    assert unquote('test') == 'test'
    assert unquote('') == ''
    assert unquote('""') == '""'
    assert unquote("''") == "''"
    assert unquote('"\'"') == '"\'"'

# Generated at 2022-06-23 02:48:26.496906
# Unit test for function unquote
def test_unquote():
    ''' tests unquote function '''
    assert unquote("hello") == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote('"hello"') == "hello"
    assert unquote('   "hello"   ') == "hello"


# Generated at 2022-06-23 02:48:36.753259
# Unit test for function split_args
def test_split_args():
    '''
    Run a bunch of tests and compare output
    to expected output.
    '''

    # test that whitespace is converted to a single space
    assert split_args("a  b") == ["a", "b"]

    # test that empty newlines are preserved
    assert split_args("a\n\nb") == ["a", "b"]

    # test that trailing newlines are preserved
    assert split_args("a\nb\n") == ["a", "b"]

    # test that quoted args are preserved
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b c" d=3') == ['a="b c"', 'd=3']
    assert split_args('a b="c d"') == ['a', 'b="c d"']



# Generated at 2022-06-23 02:48:39.587850
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo bar"') == "foo bar"
    assert unquote("'foo bar'") == "foo bar"
    assert unquote('foo bar') == "foo bar"


# Unit tests for function split_args

# Generated at 2022-06-23 02:48:47.866019
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted("'foo")
    assert not is_quoted('foo\'')
    assert not is_quoted('"foo\'')
    assert not is_quoted('\'foo"')



# Generated at 2022-06-23 02:48:54.070151
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("hello")) != True
    assert(is_quoted("'hello'")) == True
    assert(is_quoted("\"hello\"")) == True
    assert(is_quoted("\"hello")) != True
    assert(is_quoted("hello\"")) != True
    assert(is_quoted("'hello\"")) != True


# Generated at 2022-06-23 02:49:03.866846
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("\"foo'") == "\"foo'"
    assert unquote("'foo\"") == "'foo\""
    assert unquote("\\'foo") == "\\'foo"
    assert unquote("\\\"foo") == "\\\"foo"
    assert unquote("'foo\\'") == "foo\\'"
    assert unquote("\"foo\\\"") == "foo\\\""


# Generated at 2022-06-23 02:49:07.572536
# Unit test for function unquote
def test_unquote():
    assert unquote('"string"') == 'string'
    assert unquote('"string') == '"string'
    assert unquote('string"') == 'string"'
    assert unquote('string') == 'string'



# Generated at 2022-06-23 02:49:17.002586
# Unit test for function unquote
def test_unquote():
    if unquote('"abx"') != 'abx':
        raise AssertionError()
    if unquote("'abx'") != 'abx':
        raise AssertionError()
    if unquote("\"'abx\"") != '\'"abx':
        raise AssertionError()
    if unquote("''abx'") != "''abx":
        raise AssertionError()
    if unquote("'abx''") != "'abx''":
        raise AssertionError()
    if unquote("abx") != "abx":
        raise AssertionError()
    if unquote("axb") != "axb":
        raise AssertionError()

if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-23 02:49:27.993667
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'') == 'foo\''
    assert unquote('"foo"bar"') == '"foo"bar"'
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote("'foo\"bar'") == 'foo\"bar'
    assert unquote('"foo\'bar"') == "foo'bar"
    assert unquote("\\\"foo'") == "\\\"foo'"
    assert unquote("\\'foo\"") == "\\'foo\""


# Generated at 2022-06-23 02:49:34.379354
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"string"'))
    assert(is_quoted('"string with spaces"'))
    assert(is_quoted('"a string with \'quotes inside\'"'))
    assert(is_quoted('"a string with \\"quotes inside\\""'))
    assert(is_quoted("'string'"))
    assert(not is_quoted('string'))
    assert(not is_quoted('"string'))
    assert(not is_quoted("'string"))
    assert(not is_quoted('string"'))
    assert(not is_quoted("string'"))


# Generated at 2022-06-23 02:49:44.300844
# Unit test for function unquote
def test_unquote():
    ''' unquote should remove first and last quotes from a string, if the string starts and ends with the same quotes '''
    assert unquote('"a"') == 'a'
    assert unquote("'a'") == 'a'
    assert unquote("'a''") == "'a''"
    assert unquote("\"a\"'") == "\"a\"'"
    assert unquote("'a") == "'a"
    assert unquote("a'") == "a'"
    assert unquote("b") == "b"


# Generated at 2022-06-23 02:49:48.603409
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"string"')
    assert is_quoted("'string'")
    assert not is_quoted('string')
    assert not is_quoted('')


# Generated at 2022-06-23 02:49:54.059639
# Unit test for function unquote
def test_unquote():
    assert(unquote("''") == "")
    assert(unquote("'foo'") == "foo")
    assert(unquote("\"foo\"") == "foo")
    assert(unquote("fo\"o") == "fo\"o")
    assert(unquote("") == "")
    assert(unquote("'\"'") == "\"")
    assert(unquote("\"'\"") == "'")

# Generated at 2022-06-23 02:49:59.909809
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('test') == False
    assert is_quoted('') == False
    assert is_quoted('"test') == False
    assert is_quoted('test"') == False
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True


# Generated at 2022-06-23 02:50:10.128843
# Unit test for function split_args
def test_split_args():
    # Test splitting alphanumeric string
    test_string = 'a b c d'
    assert split_args(test_string) == ['a', 'b', 'c', 'd']
    # Test splitting alphanumeric and blank
    test_string = ' a b c d e '
    assert split_args(test_string) == ['a', 'b', 'c', 'd', 'e']
    # Test splitting with quotes
    test_string = 'a="b c d" e="f g h"'
    assert split_args(test_string) == ['a="b c d"', 'e="f g h"']
    # Test escaping quotes
    test_string = 'a="b \\"c\\" d" e="f g h"'

# Generated at 2022-06-23 02:50:16.218123
# Unit test for function unquote
def test_unquote():
    "unquote function"

    assert 'foo' == unquote('"foo"')
    assert 'foo bar' == unquote("'foo bar'")
    assert 'foo' == unquote("'foo'")
    assert 'foo bar' == unquote("foo bar")
    assert 'foo bar' == unquote("'foo bar")
    assert 'foo bar' == unquote("foo bar'")



# Generated at 2022-06-23 02:50:24.078985
# Unit test for function split_args

# Generated at 2022-06-23 02:50:32.196970
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted("\"") == False
    assert is_quoted("'a") == False
    assert is_quoted("\"a") == False
    assert is_quoted("\"a\"") == True
    assert is_quoted("'a'") == True
    assert is_quoted("'a\"'") == False
    assert is_quoted("\"a'\"") == False



# Generated at 2022-06-23 02:50:41.437617
# Unit test for function split_args
def test_split_args():
    test1 = 'a=b c="foo bar"'
    target1 = ['a=b', 'c="foo bar"']
    test2 = "a=b c='foo bar'"
    target2 = ['a=b', "c='foo bar'"]
    test3 = "a=b c='foo''bar'"
    target3 = ['a=b', "c='foo''bar'"]
    test4 = "a=b c='foo'\\''bar'"
    target4 = ['a=b', "c='foo'\\''bar'"]
    test5 = "a=b c='foo'\\''bar' d='foo bar"
    target5 = ['a=b', "c='foo'\\''bar'", "d='foo bar"]
    test6 = "a='foo' 'bar'"

# Generated at 2022-06-23 02:50:49.967582
# Unit test for function split_args

# Generated at 2022-06-23 02:51:02.060288
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\" d=\"foo \\\"bar\\\"\"") == ['a=b', 'c="foo bar"', 'd="foo \\"bar\\""']
    assert split_args("a=b c=\"foo bar\" d='foo \"bar\"'") == ['a=b', 'c="foo bar"', 'd=\'foo "bar"\'']
    assert split_args("a=b c='foo bar' d='foo \"bar\"'") == ['a=b', "c='foo bar'", "d='foo \"bar\"'"]


# Generated at 2022-06-23 02:51:07.186123
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted('abc') == False
    assert is_quoted('"') == False
    assert is_quoted('"abc') == False

    assert is_quoted("'abc'") == True
    assert is_quoted("'") == False
    assert is_quoted("'abc") == False


# Generated at 2022-06-23 02:51:14.977645
# Unit test for function unquote
def test_unquote():
    assert unquote("") == ""
    assert unquote(" ") == " "
    assert unquote("hello") == "hello"
    assert unquote("\"hello\"") == "hello"
    assert unquote("\"hello") == "\"hello"
    assert unquote("hello\"") == "hello\""
    assert unquote("\"hello\" \"world\"") == "\"hello\" \"world\""
    assert unquote("\"hello world\"") == "hello world"
    assert unquote("\"hello\"world\"") == "\"hello\"world\""

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.six import PY3
from ansible.module_utils._text import to_bytes

if PY3:
    unicode = str



# Generated at 2022-06-23 02:51:18.946977
# Unit test for function is_quoted
def test_is_quoted():
  assert(is_quoted('"hello"'))
  assert(is_quoted("'hello'"))
  assert(not is_quoted('hello'))
  assert(not is_quoted(''))


# Generated at 2022-06-23 02:51:28.532044
# Unit test for function split_args
def test_split_args():
    # Test normal argument call
    args = 'a=b c="foo bar"'
    result = split_args(args)
    # Strings are equal
    assert result == ['a=b', 'c="foo bar"']

    # Test argument with quotes inside
    args = "a=b c='foo \"bar\"'"
    result = split_args(args)
    # Strings are equal
    assert result == ["a=b", 'c=\'foo "bar"\'']

    # Test argument with escaped quotes inside
    args = "a=b c='foo \'bar\''"
    result = split_args(args)
    # Strings are equal
    assert result == ["a=b", "c='foo '\'bar'\''"]

    # Test argument with escaped backslash inside

# Generated at 2022-06-23 02:51:36.552762
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"abcd"') is True)
    assert(is_quoted("'abcd'") is True)
    assert(is_quoted('"abcd') is False)
    assert(is_quoted("'abcd") is False)
    assert(is_quoted('abcd"') is False)
    assert(is_quoted("abcd'") is False)


# Generated at 2022-06-23 02:51:48.802738
# Unit test for function split_args
def test_split_args():
    # Test without jinja
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test with jinja
    assert split_args('arg1 arg2="{{foo}} {{bar}}" arg3={{baz}}') == ['arg1', 'arg2="{{foo}} {{bar}}"', 'arg3={{baz}}']

    # Test with nested jinja (issue #28881)
    assert split_args('arg1 arg2="{{foo}} {% if bar %}{{bar}} {% endif%}{{baz}}" arg3={{baz}}') == ['arg1', 'arg2="{{foo}} {% if bar %}{{bar}} {% endif%}{{baz}}"', 'arg3={{baz}}']

    #

# Generated at 2022-06-23 02:51:59.944901
# Unit test for function split_args
def test_split_args():
    '''
    make sure we aren't breaking anything in the args splitting
    '''

    # ensure we handle quotes properly
    assert split_args('a="b c"')  == ['a=b c']
    assert split_args("a='b c'")  == ['a=b c']
    assert split_args('a=b" c"')  == ['a=b c']
    assert split_args("a=b' c'")  == ['a=b c']
    assert split_args('a="b c')   == ['a=b c']
    assert split_args("a='b c")   == ['a=b c']

    # ensure we handle backslashes in variables properly
    assert split_args('a=b\\ c')  == ['a=b\\ c']

# Generated at 2022-06-23 02:52:05.516004
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted('"foo"')
    assert is_quoted("''")
    assert is_quoted("'foo'")
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted('foobar')


# Generated at 2022-06-23 02:52:12.640411
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'
    assert unquote('""foo""') == '"foo"'
    assert unquote("''foo''") == "'foo'"
    print('test_unquote: passed')

# TODO: move to test_utils

# Generated at 2022-06-23 02:52:19.755616
# Unit test for function is_quoted
def test_is_quoted():
    tests = [
        ('foo', False),
        ('',    False),
        ('"foo"', True),
        ('"', False),
        ('\'foo\'', True),
        ('\'', False),
    ]

    for test in tests:
        result = is_quoted(test[0])
        if result != test[1]:
            raise Exception('Test %s failed. %s is quoted: %s' % (test, test[0], result))



# Generated at 2022-06-23 02:52:24.489906
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"')
    assert is_quoted("'foobar'")
    assert not is_quoted('"foobar')
    assert not is_quoted('foobar"')
    assert not is_quoted("foobar'")
    assert not is_quoted('foobar')


# Generated at 2022-06-23 02:52:30.196375
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo"') == True
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"""foo"""') == True
    assert is_quoted("'''foo'''") == True


# Generated at 2022-06-23 02:52:36.967041
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('a=1 b=2') == ['a=1', 'b=2']
    assert split_args('a=1 \\\nb=2') == ['a=1 \\\nb=2']
    assert split_args('a=1 \\\n\\\nb=2') == ['a=1 b=2']
    assert split_args('a=1 \\\nb="2 2"') == ['a=1', 'b="2 2"']
    assert split_args('a=1 \\\n"b=2"') == ['a=1', '"b=2"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-23 02:52:46.380690
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("")
    assert not is_quoted("'")
    assert not is_quoted("\"")
    assert not is_quoted("asdf")
    assert not is_quoted("'asd'f")
    assert not is_quoted("\"asd\"f")
    assert is_quoted("''")
    assert is_quoted("\"\"")
    assert is_quoted("\"'\"")
    assert is_quoted("'\"'")
    assert is_quoted("\"'\"'\"")
    assert is_quoted("\"'\"\"'\"")



# Generated at 2022-06-23 02:52:51.454325
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') is True
    assert is_quoted("'foo'") is True
    assert is_quoted('"foo') is False
    assert is_quoted("'foo") is False
    assert is_quoted('foo"') is False
    assert is_quoted("foo'") is False
    assert is_quoted('""') is True
    assert is_quoted("''") is True


# Generated at 2022-06-23 02:52:57.869548
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("simple") == False
    assert is_quoted("\"simple\"") == True
    assert is_quoted("'simple'") == True
    assert is_quoted("\"\"\"simple\"\"\"") == False
    assert is_quoted("'''simple'''") == False



# Generated at 2022-06-23 02:53:03.767294
# Unit test for function is_quoted
def test_is_quoted():
    # is_quoted properly detects quoted and non-quoted strings
    assert not is_quoted('foobar')
    assert not is_quoted('"foobar')
    assert is_quoted('"foobar"')
    assert not is_quoted('"foobar""')
    assert not is_quoted('\'foobar\'')



# Generated at 2022-06-23 02:53:15.674028
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the function split_args
    The test case is defined in the function and can be run standalone,
    the function will return True if the test case passes, False if not

    Usage: python split_args.py
    '''

    # test case definition:

# Generated at 2022-06-23 02:53:21.867625
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo \\\"bar\\\"\"") == ['a=b', 'c="foo \\"bar\\""']
    assert split_args("a=b c='foo \\\'bar\\\''") == ['a=b', "c='foo \\'bar\\''"]
    assert split_args("a=b c=\"foo bar\" d='foo'") == ['a=b', 'c="foo bar"', "d='foo'"]

# Generated at 2022-06-23 02:53:33.053433
# Unit test for function split_args
def test_split_args():

    strings = [
        "a=b c='foo bar'",
        "a='foo bar' c=d",
        "a='foo bar' c='foo bar'",
        "a='foo \"bar\"' c='foo bar'",
        "a='foo \"bar\"' c='foo \"bar\"'",
        "a='foo \"bar\"' c=\"foo \"bar\"\"",
        "a='foo \"bar\"' c='foo bar' d='foo \"bar\"'",
        "a=\"foo bar\" c=\"foo bar\"",
        "a=\"foo bar\" c='foo \"bar\"'",
        "a=\"foo bar\" c='foo \"bar\"'",
        "a=\"foo bar\" c=\"foo bar\"",
    ]

# Generated at 2022-06-23 02:53:42.701619
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted('"hello"')
    assert not is_quoted("'hello")
    assert not is_quoted('"hello')
    assert not is_quoted("hello'")
    assert not is_quoted('hello"')
    assert not is_quoted("'hello\"")
    assert not is_quoted("\"hello'")
    assert not is_quoted('hello')
    assert not is_quoted('')
    assert not is_quoted('"""')
    assert not is_quoted("'''")
    assert not is_quoted("'")
    assert not is_quoted('"')


# Generated at 2022-06-23 02:53:49.046358
# Unit test for function split_args
def test_split_args():
    ''' test function split_args '''

    def _split_args(args):
        return split_args(args)

    def _test_split_args(args, expected):
        result = _split_args(args)
        assert result == expected, "%s != %s" % (result, expected)

    _test_split_args("a=b c=d", ['a=b', 'c=d'])
    _test_split_args("a={{ foo }} b={{ bar }}", ['a={{ foo }}', 'b={{ bar }}'])
    _test_split_args("a={{ foo }} b={{ bar }} c=\"{{ baz }}\"", ['a={{ foo }}', 'b={{ bar }}', 'c="{{ baz }}"'])

# Generated at 2022-06-23 02:54:00.945356
# Unit test for function split_args
def test_split_args():
    # 1. simple args
    params = ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == params

    # 2. split args on newline
    params = ['a=b', 'c="foo bar"']
    assert split_args('a=b\nc="foo bar"') == params

    # 3. split args with line continuation
    params = ['a=b', 'c="foo\nbar"']
    assert split_args('a=b c="foo\\\nbar"') == params

    # 4. split args with line continuation and newline
    params = ['a=b', 'c="foo\nbar"']
    assert split_args('a=b c="foo\\\nbar"') == params

    # 5. split args with line continuation and newline

# Generated at 2022-06-23 02:54:04.565121
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted('"') == False
    assert is_quoted('hello') == False



# Generated at 2022-06-23 02:54:11.785935
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")

    assert not is_quoted('n"quoted"')
    assert not is_quoted('"quote"d')
    assert not is_quoted('"quoted')
    assert not is_quoted('quoted"')
    assert not is_quoted('n"quoted')
    assert not is_quoted('"quote"d')


# Generated at 2022-06-23 02:54:15.333150
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('\'abc\'') == 'abc'
    assert unquote('abc') == 'abc'

# Generated at 2022-06-23 02:54:25.745776
# Unit test for function split_args
def test_split_args():
    # a very basic test
    assert split_args("something") == ['something']

    # a test for a quoted word
    assert split_args('something=something') == ['something=something']

    # a test for a quoted word
    assert split_args('something="something"') == ['something="something"']

    # a test for a quoted word
    assert split_args("something='something'") == ["something='something'"]

    # a test for a quoted word
    assert split_args("something=\"something'") == ['something="something\'']

    # a test for a quoted word
    assert split_args('something=\'something"') == ['something=\'something"']

    # a test for a quoted word
    assert split_args("something") == ['something']

    # a test for a quoted word

# Generated at 2022-06-23 02:54:35.230172
# Unit test for function split_args

# Generated at 2022-06-23 02:54:47.069502
# Unit test for function unquote
def test_unquote():
     data = '"some string"'
     assert unquote(data) == 'some string', "unquote(%s) should return %s" % (data, 'some string')

     data = "'some string'"
     assert unquote(data) == 'some string', "unquote(%s) should return %s" % (data, 'some string')

     data = '"some \'bad\' string"'
     assert unquote(data) == 'some \'bad\' string', "unquote(%s) should return %s" % (data, 'some \'bad\' string')

     data = "'some \"bad\" string'"
     assert unquote(data) == 'some \"bad\" string', "unquote(%s) should return %s" % (data, 'some \"bad\" string')

     data = "another \'bad\' string"
     assert unquote

# Generated at 2022-06-23 02:54:53.732066
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo", "unquote of non-quoted string fails"
    assert unquote("'foo'") == "foo", "unquote of single-quoted string fails"
    assert unquote('"foo"') == "foo", "unquote of double-quoted string fails"
    assert unquote("\"'foo'\"") == "'foo'", "unquote of double-quoted string with embedded single quotes fails"
    assert unquote(r'"foo\"bar"') == r'foo"bar', "unquote of double-quoted string with escaped quotes fails"

# Generated at 2022-06-23 02:54:58.923949
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('"abc"') == True)
    assert (is_quoted('"abc') == False)
    assert (is_quoted('abc"') == False)
    assert (is_quoted('"ab"c"') == False)
    assert (is_quoted('"') == False)
    assert (is_quoted('') == False)
    assert (is_quoted('abc') == False)
    assert (is_quoted('"abc""') == False)
    assert (is_quoted('""abc"') == False)
    assert (is_quoted('"""abc"""') == False)
    assert (is_quoted('"""') == False)
    assert (is_quoted('"""a"b"c""') == False)


# Generated at 2022-06-23 02:55:06.635490
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted("'foo") is False
    assert is_quoted("foo'") is False
    assert is_quoted("foo") is False
    assert is_quoted("'foo\"") is False
    assert is_quoted("\"foo'") is False

# Unit test function for unquote