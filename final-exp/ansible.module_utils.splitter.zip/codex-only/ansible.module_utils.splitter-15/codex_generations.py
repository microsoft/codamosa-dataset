

# Generated at 2022-06-23 02:45:07.215595
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("''")
    assert is_quoted("'''")
    assert is_quoted("'abcd'")
    assert is_quoted('"""')
    assert is_quoted('"abcd"')
    assert not is_quoted('"abcd')
    assert not is_quoted('abcd"')
    assert not is_quoted("'abcd")
    assert not is_quoted("abcd'")



# Generated at 2022-06-23 02:45:20.490154
# Unit test for function split_args
def test_split_args():
    ''' unit test for function split_args '''


# Generated at 2022-06-23 02:45:28.645943
# Unit test for function is_quoted
def test_is_quoted():
    test_pairs = [('"foo"', True),
                  ("'bar'", True),
                  ('"foo', False),
                  ("'bar", False),
                  (r'"foo\""', False),
                  (r"'bar\'", False),
                  ('', False),
                  ('foo', False),
                  ('"foo', False),
                  ('foo"', False),
                  ('"foo"bar', False),
                  ('""foo"', False),
                  ('""', True),
                  ('"foo""bar"', False),
                  (r'"\n"', True),
                  (r'"\\"', True)
                  ]
    for (data, output) in test_pairs:
        assert is_quoted(data) == output


# Generated at 2022-06-23 02:45:30.702328
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello world'")
    assert is_quoted('"hello world"')
    assert not is_quoted('hello world')



# Generated at 2022-06-23 02:45:34.950451
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("abc") == 'abc'



# Generated at 2022-06-23 02:45:40.257756
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('\'abc\'') == 'abc'
    assert unquote('\'abc') == '\'abc'
    assert unquote('abc\'') == 'abc\''


# Generated at 2022-06-23 02:45:50.010317
# Unit test for function is_quoted
def test_is_quoted():
    useful_data = [
        'asdf',
        '"asdf',
        '"asdf"',
        '""asdf""',
        '"asdf""',
        '""asdf"',
        'asdf""',
        '""asdf',
        "'asdf",
        "'asdf'",
        "''asdf''",
        "'asdf''",
        "''asdf'",
        "asdf''",
        "''asdf",
    ]

    good_data = [
        '"asdf"',
        '""asdf""',
        "'asdf'",
        "''asdf''",
    ]


# Generated at 2022-06-23 02:45:52.665951
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"this is a string"') == True)
    assert(is_quoted("'this is another string'") == True)
    assert(is_quoted('this is a string') == False)
    assert(is_quoted('"this is a string') == False)



# Generated at 2022-06-23 02:45:58.999344
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('"foo" bar')
    assert not is_quoted('foo" bar')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert is_quoted("'''foo'''")
    assert is_quoted('"""foo"""')
    assert is_quoted('"f""o""o"')
    assert is_quoted("'f''o''o'")
    assert not is_quoted('"""f"""')
    assert not is_quoted("'''f'''")
    assert not is_quoted('"f"o"o"')
    assert not is_quoted("'f'o'o'")


# Generated at 2022-06-23 02:46:08.185482
# Unit test for function split_args

# Generated at 2022-06-23 02:46:16.621073
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted('"te"st"') == False
    assert is_quoted('"test') == False
    assert is_quoted('test"') == False
    assert is_quoted('"test') == False
    assert is_quoted('') == False
    assert is_quoted('""') == True
    assert is_quoted('"') == False
    assert is_quoted('""""') == True
    assert is_quoted('"""') == True
    assert is_quoted('"""test"""') == True
    assert is_quoted('"""test"') == True
    assert is_quoted('"test"""') == True
    assert is_quoted('"""test"""test"""') == True
    assert is_quoted('"""test"""')

# Generated at 2022-06-23 02:46:28.198551
# Unit test for function split_args
def test_split_args():
    result = split_args("'foo bar' baz")
    assert len(result) == 2
    assert result == ["'foo bar'", "baz"]
    assert len(result[0]) == 8  # Includes the quotes

    result = split_args("'foo bar'\nbaz")
    assert len(result) == 2
    assert result == ["'foo bar'\n", "baz"]
    assert len(result[0]) == 9  # Includes the quotes and newline

    result = split_args("'foo bar'\nbaz qux")
    assert len(result) == 2
    assert result == ["'foo bar'\n", "baz qux"]
    assert len(result[0]) == 9  # Includes the quotes and newline


# Generated at 2022-06-23 02:46:36.457742
# Unit test for function is_quoted
def test_is_quoted():
    res = is_quoted('')
    assert res == False

    res = is_quoted('""')
    assert res == True

    res = is_quoted('"a"')
    assert res == True

    res = is_quoted('\\"a\\"')
    assert res == True

    res = is_quoted('""""')
    assert res == False

    res = is_quoted('"\'"')
    assert res == True

    res = is_quoted('"\'"\'"')
    assert res == False

    res = is_quoted('"\\"')
    assert res == False



# Generated at 2022-06-23 02:46:43.699710
# Unit test for function is_quoted
def test_is_quoted():
    assert(True == is_quoted("'hello'"))
    assert(True == is_quoted('"hello"'))
    assert(False == is_quoted('hello'))


# Generated at 2022-06-23 02:46:53.025509
# Unit test for function unquote
def test_unquote():
    cases = {'hello world': 'hello world',
             '"hello world"': 'hello world',
             '"hello world': '"hello world',
             'hello world"': 'hello world"',
             '"hello \"world\""': 'hello "world"',
             "''": ''}

    for (given, expected) in cases.items():
        result = unquote(given)
        if result != expected:
            print("failed! given %s expected %s but got %s" % (given, expected, result))
        else:
            print("ok")



# Generated at 2022-06-23 02:47:02.589379
# Unit test for function split_args
def test_split_args():
    args = 'echo this is a "test" arg1=foo arg2=bar arg3="{{ foo_bar }}" arg4={{ foo_bar }}'
    params = split_args(args)
    assert params == ['echo', 'this', 'is', 'a', 'test', 'arg1=foo', 'arg2=bar', 'arg3="{{ foo_bar }}"', 'arg4={{ foo_bar }}']

    args = 'echo this is a "test" arg1=foo arg2=bar arg3="{{ foo_bar }}" arg4={{ foo_bar }} arg5="{{ foo_bar }}"'
    params = split_args(args)

# Generated at 2022-06-23 02:47:06.607133
# Unit test for function unquote
def test_unquote():
    data = '"a"'
    assert(unquote(data) == 'a')
    data = "'a'"
    assert(unquote(data) == 'a')
    data = "\"'a'"
    assert(unquote(data) == "'a'")
    data = "'\"a'"
    assert(unquote(data) == '"a')



# Generated at 2022-06-23 02:47:17.033731
# Unit test for function split_args
def test_split_args():
    ''' test_split_args '''
    params = split_args("a=b c=\"foo bar\"")
    assert params == ['a=b', 'c="foo bar"']

    params = split_args("a=b c='foo bar'")
    assert params == ['a=b', "c='foo bar'"]

    params = split_args("a=b c=\"{{ foo }}\"")
    assert params == ['a=b', 'c="{{ foo }}"']

    params = split_args("a=b c=\"{{ foo bar baz }}\"")
    assert params == ['a=b', 'c="{{ foo bar baz }}"']

    params = split_args("a=b c=\"{{ foo }} {{ bar }} {{ baz }}\"")

# Generated at 2022-06-23 02:47:24.509407
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo\\"bar"') == True
    assert is_quoted('"foobar"') == True
    assert is_quoted('"foo"bar"') == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted('\\"foo"') == False


# Generated at 2022-06-23 02:47:37.477063
# Unit test for function split_args
def test_split_args():
    # simple list
    assert split_args('foo bar') == ['foo', 'bar']
    # combining list with jinja2
    assert split_args('foo bar {{ foo }}') == ['foo', 'bar', '{{ foo }}']
    # combining list with jinja2
    assert split_args('foo bar {% foo %}') == ['foo', 'bar', '{% foo %}']
    # combining list with jinja2
    assert split_args('foo bar {# foo #}') == ['foo', 'bar', '{# foo #}']
    # combining list with jinja2 and quotes
    assert split_args('foo bar {{ foo "foo bar" }}') == ['foo', 'bar', '{{ foo "foo bar" }}']
    # combining list with jinja2 with escaped quotes

# Generated at 2022-06-23 02:47:43.881366
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') != 'foo'
    assert unquote("'foo") != 'foo'
    assert unquote('foo"') != 'foo'
    assert unquote('foo\'') != 'foo'



# Generated at 2022-06-23 02:47:51.310648
# Unit test for function split_args
def test_split_args():
    '''
    By default, split args should split on whitespace.
    This should have no special
    handling for quotes or jinja2 blocks.
    '''
    params = split_args('a b c')
    assert params == ['a', 'b', 'c']
    params = split_args(' a b c ')
    assert params == ['a', 'b', 'c']

    '''
    In these cases we have more than one jinja2 block, so we
    should append the token instead of concatenating.
    '''
    params = split_args('{{ a }} {{ b }}')
    assert params == ['{{', 'a', '}}', '{{', 'b', '}}']
    params = split_args('{% a %} {% b %}')

# Generated at 2022-06-23 02:48:00.193409
# Unit test for function split_args
def test_split_args():
    def split_test(args, expected):
        result = split_args(args)
        if result != expected:
            raise Exception(
                "error while splitting arguments, expected %s, got %s" %
                (repr(expected), repr(result)))
    split_test(
        "a=b c='foo bar'",
        ['a=b', "c='foo bar'"]
    )
    split_test(
        'a=b c="foo bar"',
        ['a=b', 'c="foo bar"']
    )
    split_test(
        'a=b c="{{"{{bar}}"}}"',
        ['a=b', 'c="{{{{bar}}}}"']
    )

# Generated at 2022-06-23 02:48:11.182232
# Unit test for function is_quoted
def test_is_quoted():

    # -- is_quoted
    assert not is_quoted('quoted'), "False should be returned if the string is not quoted"
    assert is_quoted('"quoted"'), "True should be returned if the string is double quoted"
    assert is_quoted("'quoted'"), "True should be returned if the string is single quoted"
    assert is_quoted('"""quoted"""'), "True should be returned if the string is triple double quoted"
    assert is_quoted("'''quoted'''"), "True should be returned if the string is triple single quoted"
    assert not is_quoted('"quoted'), "False should be returned if the string is not properly quoted"
    assert not is_quoted("'quoted"), "False should be returned if the string is not properly quoted"

# Generated at 2022-06-23 02:48:19.458394
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('"a,b"') == 'a,b'
    assert unquote('"a,b,c"') == 'a,b,c'
    assert unquote('"a,b,"') == 'a,b,'
    assert unquote('"ab"') == 'ab'
    assert unquote('""""') == ''
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote('abc"') == 'abc"'
    assert unquote('"ab"c') == '"ab"c'
    assert unquote('"a"b"c"') == '"a"b"c"'
    assert unquote('"a"bc') == '"a"bc'

# Generated at 2022-06-23 02:48:33.734142
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('one') == 'one'
    assert unquote('"one"') == 'one'
    assert unquote('\'one\'') == 'one'
    assert unquote('\'one\'') == 'one'
    assert unquote('two') == 'two'
    assert unquote('"two"') == 'two'
    assert unquote('\'two\'') == 'two'
    assert unquote('three') == 'three'
    assert unquote('"three"') == 'three'
    assert unquote('\'three\'') == 'three'
    assert unquote('"\'four\'"') == '\'four\''


# Generated at 2022-06-23 02:48:38.009442
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted('"hello\'"') == False

# Unit test function unquote

# Generated at 2022-06-23 02:48:41.268124
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'a'")
    assert is_quoted('"a"')
    assert not is_quoted("a")
    assert not is_quoted("ab")
    assert not is_quoted('a"')
    assert not is_quoted("'a")


# Generated at 2022-06-23 02:48:48.347072
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote("foo'") == "foo'"
    assert unquote("'foo' 'bar'") == "foo' 'bar"
    assert unquote("\"foo\" \"bar\"") == "foo\" \"bar"
    assert unquote("\"foo\"bar\"") == "\"foo\"bar\""



# Generated at 2022-06-23 02:48:59.761153
# Unit test for function unquote
def test_unquote():
    test_data = {
        '"foo bar"': "foo bar",
        '"foo bar': "foo bar",
        'foo bar"': 'foo bar"',
        "foo bar": "foo bar",
        '"foo bar" "foo bar"': '"foo bar" "foo bar"',
        '"foo bar" "foo bar': '"foo bar" "foo bar',
        "foo 'bar'": "foo 'bar'",
        "foo \"bar\"": 'foo "bar"',
        "foo": "foo",
        '"foo\\"bar"': 'foo"bar',
        '"foo\\"bar" "foo\\"bar"': '"foo"bar" "foo"bar"',
    }

    for d in test_data:
        result = unquote(d)
        assert result == test

# Generated at 2022-06-23 02:49:03.602794
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('"a"') == 'a'
    assert unquote('\'a\'') == 'a'
    assert unquote('a') == 'a'
    assert unquote('"a\'') == '"a\''

# Generated at 2022-06-23 02:49:12.449738
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted("'hel'lo'")
    assert is_quoted("'hello") is False
    assert is_quoted("hello'") is False
    assert is_quoted("'hello\"") is False
    assert is_quoted("\"hello'") is False

    assert is_quoted('"hello"')
    assert is_quoted('"hel"lo"')
    assert is_quoted('"hello') is False
    assert is_quoted('hello"') is False
    assert is_quoted('"hello\'"') is False
    assert is_quoted('\'hello"') is False

    assert is_quoted("") is False
    assert is_quoted("''") is False
    assert is_quoted("'") is False

# Generated at 2022-06-23 02:49:24.202173
# Unit test for function split_args
def test_split_args():
    '''
    This runs a series of tests against the split_args function
    '''
    # Basic commands
    assert split_args("ls") == ['ls']
    assert split_args("ls -l") == ['ls', '-l']
    assert split_args("ls -l -a") == ['ls', '-l', '-a']
    assert split_args("ls -l -a /") == ['ls', '-l', '-a', '/']
    assert split_args("ls -l -a /") == ['ls', '-l', '-a', '/']
    assert split_args("ls --color=auto") == ['ls', '--color=auto']

    # Jinja2 escaping
    assert split_args("ls '{{ foo }}'") == ['ls', "{{ foo }}"]

# Generated at 2022-06-23 02:49:30.451961
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"a"bc"') == '"a"bc"'
    assert unquote('abc') == 'abc'



# Generated at 2022-06-23 02:49:38.026090
# Unit test for function split_args
def test_split_args():

    # Test a basic command that contains no Jinja2 markup
    test = split_args('echo foo bar')
    assert test == ['echo', 'foo', 'bar']

    # Test a command that contains complex Jinja2 markup and escapes
    test = split_args('echo "{{ foo }} {{ bar }}"')
    assert test == ['echo', '"{{ foo }} {{ bar }}"']

    # Test a command that contains single quotes and multiple parameters
    test = split_args('echo "{{ foo }}" "{{ bar }}"')
    assert test == ['echo', '"{{ foo }}"', '"{{ bar }}"']

    # Test a command that contains single quotes and multiple parameters
    test = split_args('echo "foo={{ foo }}" "bar={{ bar }}"')

# Generated at 2022-06-23 02:49:41.573589
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"test"') == True)
    assert(is_quoted("'test'") == True)
    assert(is_quoted('test') == False)


# Generated at 2022-06-23 02:49:53.433232
# Unit test for function split_args
def test_split_args():
    '''Unit test for function split_args'''

    # Test that basic string comes back intact
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test that quotes are preserved
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']

    # Test that empty string returns empty list
    assert split_args('') == []

    # Test that a single quoted param returns a list with that element
    assert split_args('"a b"') == ['a b']

    # Test that an unbalanced quoted param raises an exception
    try:
        split_args('"a b')
        assert False
    except Exception:
        pass

    # Test that a bare equal sign is preserved

# Generated at 2022-06-23 02:50:03.820593
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'hello'") is True)
    assert(is_quoted("\"hello\"") is True)
    assert(is_quoted("\"hello\"'") is False)
    assert(is_quoted("'hello'\"") is False)
    assert(is_quoted("hello") is False)
    assert(is_quoted("'hello") is False)
    assert(is_quoted("hello'") is False)
    assert(is_quoted("\"hello") is False)
    assert(is_quoted("hello\"") is False)
    assert(is_quoted("") is False)


# Generated at 2022-06-23 02:50:15.769870
# Unit test for function split_args

# Generated at 2022-06-23 02:50:18.139021
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == 'hello world'
    assert unquote("'hello world'") == 'hello world'
    assert unquote('hello world') == 'hello world'

# Generated at 2022-06-23 02:50:25.599982
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted("hello") == False)
    assert (is_quoted("'hello'") == True)
    assert (is_quoted("\"hello\"") == True)
    assert (is_quoted("\"hello") == False)
    assert (is_quoted("'hello") == False)
    assert (is_quoted("hello\"") == False)
    assert (is_quoted("hello'") == False)



# Generated at 2022-06-23 02:50:37.225344
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted("''") == False
    assert is_quoted("'''") == False
    assert is_quoted("'''hi'") == False
    assert is_quoted("''hi") == False
    assert is_quoted("''hi''") == True
    assert is_quoted("''hi'a'") == False
    assert is_quoted("'hi'") == True
    assert is_quoted("'hi'a'") == False
    assert is_quoted("'hi''a'") == False
    assert is_quoted("'hi'a") == False
    assert is_quoted('"') == False
    assert is_quoted('""') == False

# Generated at 2022-06-23 02:50:47.081259
# Unit test for function split_args
def test_split_args():
    assert split_args("a=1 b=2")   == ['a=1', 'b=2']
    assert split_args('a=1 b="2 3"') == ['a=1', 'b="2 3"']
    assert split_args('"a 1" b=2') == ['"a 1"', 'b=2']
    assert split_args('a=>1 b=2') == ['a=>1', 'b=2']

    # example output: ['a="foo bar"', 'c="{{ foo }}" d="{% foo %}"']
    assert split_args('a="foo bar"\nc="{{ foo }}" d="{% foo %}"') == \
        ['a="foo bar"', 'c="{{ foo }}" d="{% foo %}"']

    # example output: ['a="{{ foo }}

# Generated at 2022-06-23 02:50:52.647429
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted('"this is a test"')
    assert is_quoted("'this is also a test'")
    assert is_quoted("'test'")
    assert not is_quoted("test'")
    assert not is_quoted("'test")
    assert not is_quoted("test")


# Generated at 2022-06-23 02:51:02.754909
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello' ") == 'hello'
    assert unquote(" 'hello'") == 'hello'
    assert unquote(" 'hello' ") == 'hello'
    assert unquote("'hello") == "'hello"
    assert unquote("hello'") == "hello'"
    assert unquote("'") == "'"
    assert unquote("''") == ""
    assert unquote("'   '") == "   "
    assert unquote("'hello world'") == 'hello world'
    assert unquote("'hello\\\\world'") == 'hello\\\\world'
    assert unquote("'hello\\'world'") == "hello\\'world"
    assert unquote("\"hello\\\"world\"")

# Generated at 2022-06-23 02:51:05.864879
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('"hello')
    assert not is_quoted("hello")


# Generated at 2022-06-23 02:51:07.665405
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert not is_quoted('test')


# Generated at 2022-06-23 02:51:11.430520
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('hello') == 'hello'
    assert unquote('"hello world"') == 'hello world'
    assert unquote('"hell o"') == 'hell o'
    assert unquote('') == ''

# Generated at 2022-06-23 02:51:15.155080
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'



# Generated at 2022-06-23 02:51:26.283798
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar" "d e" \'f g\' \'h\' \'i\' \'j\' "k" l=m'
    results = split_args(args)
    if results != ['a=b', 'c="foo bar"', '"d e"', "'f g'", '\'h\'', '\'i\'', '\'j\'', '"k"', 'l=m']:
        raise AssertionError("splitting args failed:\n%s\n%s" % (results, args))

    args = 'a=b c="foo bar" "d e" \'f g\' \'h\' \'i\' \'j\' "k" l=m n=o'
    results = split_args(args)

# Generated at 2022-06-23 02:51:33.393780
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("foo") == False
    assert is_quoted("'foo") == False
    assert is_quoted('"foo') == False
    assert is_quoted("foo'") == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True


# Generated at 2022-06-23 02:51:36.837398
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") == True
    assert is_quoted("'hello") == False
    assert is_quoted("''") == True
    assert is_quoted("hello") == False
    assert is_quoted('"hello"') == True


# Generated at 2022-06-23 02:51:42.818068
# Unit test for function unquote
def test_unquote():
    assert unquote('"Hello world"') == 'Hello world'
    assert unquote('"Hello world') == '"Hello world'
    assert unquote('Hello world"') == 'Hello world"'
    assert unquote('Hello world') == 'Hello world'

# Generated at 2022-06-23 02:51:57.550231
# Unit test for function split_args
def test_split_args():

    def _test_split(args, expected):
        actual = split_args(args)
        assert actual == expected, "Expected %s but got %s while processing %s" % (expected, actual, args)

    _test_split("", [])
    _test_split("  ", [])
    _test_split("'  '", ['\'  \''])
    _test_split('  a=b c="1 2"  d="3 4"', ['a=b', 'c="1 2"', 'd="3 4"'])
    _test_split('a=b c="1 2" d="3 4"', ['a=b', 'c="1 2"', 'd="3 4"'])

# Generated at 2022-06-23 02:52:06.215374
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') is True
    assert is_quoted("'abc'") is True
    assert is_quoted('"abc') is False
    assert is_quoted("'abc") is False
    assert is_quoted('abc"') is False
    assert is_quoted("abc'") is False
    assert is_quoted('"ab"c"') is False
    assert is_quoted("'ab'c'") is False
    assert is_quoted('') is False


# Generated at 2022-06-23 02:52:10.138078
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("''") == True
    assert is_quoted("'''") == False
    assert is_quoted("'") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("''foo''") == False
    assert is_quoted('"') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('""foo""') == False



# Generated at 2022-06-23 02:52:17.913889
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Some String"') == True
    assert is_quoted('\'Some String\'') == True
    assert is_quoted('Some String') == False

if __name__ == '__main__':
    import sys, os
    if len(sys.argv) > 1:
        print('unquoted: %s' % unquote(sys.argv[1]))
    else:
        test_is_quoted()
        print('Tests complete')

# Generated at 2022-06-23 02:52:27.752015
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'a'") == 'a'
    assert unquote('"a"') == 'a'
    assert unquote('""') == ''
    assert unquote("''") == ''
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"ab"c"') == '"ab"c"'
    assert unquote('"ab\\"c"') == 'ab\\"c'

# Generated at 2022-06-23 02:52:31.768689
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"') == True
    assert is_quoted("'abcd'") == True

    assert is_quoted('abcd"') == False
    assert is_quoted("abcd'") == False
    assert is_quoted('') == False


# Generated at 2022-06-23 02:52:43.657352
# Unit test for function unquote

# Generated at 2022-06-23 02:52:52.545063
# Unit test for function split_args
def test_split_args():
    assert split_args('c="foo bar"') == ['c="foo bar"']
    assert split_args('c="foo bar" b=2') == ['c="foo bar"', 'b=2']
    assert split_args('c="foo bar" b=2 a=1') == ['c="foo bar"', 'b=2', 'a=1']
    assert split_args('a=1 c="foo bar" b=2') == ['a=1', 'c="foo bar"', 'b=2']
    assert split_args('a=1 c="foo bar" b=2 d="foo bar"') == ['a=1', 'c="foo bar"', 'b=2', 'd="foo bar"']
    assert split_args('a=1 c="foo bar" b=2 d="foo bar" e=3')

# Generated at 2022-06-23 02:53:01.595729
# Unit test for function is_quoted
def test_is_quoted():
    assert( is_quoted('"hello"') == True )
    assert( is_quoted('"he"llo"') == False )
    assert( is_quoted("'hello'") == True )
    assert( is_quoted("'he'llo'") == False )
    assert( is_quoted('\'he"llo\'') == False )
    assert( is_quoted('hello') == False )
    assert( is_quoted('"hello') == False )
    assert( is_quoted('hello"') == False )
    assert( is_quoted('') == False )


# Generated at 2022-06-23 02:53:14.105217
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a={{b}} c=\"foo bar\"") == ['a={{b}}', 'c="foo bar"']
    assert split_args("a={{b}} c={{foo bar}}") == ['a={{b}}', 'c={{foo bar}}']
    assert split_args("a={{b}} c=\"foo bar\" d={{hi}}") == ['a={{b}}', 'c="foo bar"', 'd={{hi}}']
    assert split_args("a={{b}} c=\"foo bar\" d={{hi}} e={{j}}") == ['a={{b}}', 'c="foo bar"', 'd={{hi}}', 'e={{j}}']


# Generated at 2022-06-23 02:53:22.084699
# Unit test for function split_args
def test_split_args():

    args_string = 'a=b c="foo bar"'
    args = split_args(args_string)
    assert args[0].strip() == 'a=b', 'split_args failed with args %s' % (args_string)
    assert args[1].strip() == 'c="foo bar"', 'split_args failed with args %s' % (args_string)

    args_string = 'a=b c="foo bar'
    try:
        args = split_args(args_string)
        assert False
    except Exception as e:
        pass

    args_string = '''a=b c="foo bar"'''
    args = split_args(args_string)
    assert args[0].strip() == 'a=b', 'split_args failed with args %s' % (args_string)

# Generated at 2022-06-23 02:53:23.490073
# Unit test for function is_quoted
def test_is_quoted():
    return is_quoted("'8080'") == True


# Generated at 2022-06-23 02:53:34.643878
# Unit test for function split_args

# Generated at 2022-06-23 02:53:44.167397
# Unit test for function split_args
def test_split_args():
    args = "arg1 arg2='arg2' arg3=\\\"arg3\\\""
    params = split_args(args)
    assert params[0] == 'arg1'
    assert params[1] == "arg2='arg2'"
    assert params[2] == 'arg3="arg3"'

    args = "arg1 arg2='a r g 2' arg3=a\\ r\\ g3"
    params = split_args(args)
    assert params[0] == 'arg1'
    assert params[1] == "arg2='a r g 2'"
    assert params[2] == 'arg3=a\\ r\\ g3'


# Generated at 2022-06-23 02:53:49.981970
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"quoted string\"") == True
    assert is_quoted("'quoted string'") == True
    assert is_quoted("'quoted string") == False
    assert is_quoted("quoted string\"") == False
    assert is_quoted("no quotes") == False
    assert is_quoted("") == False


# Generated at 2022-06-23 02:53:59.486383
# Unit test for function is_quoted
def test_is_quoted():
    if not is_quoted('"a"'):
        raise AssertionError('should be quoted')
    if not is_quoted("'a'"):
        raise AssertionError('should be quoted')
    if is_quoted('a'):
        raise AssertionError('should not be quoted')
    if is_quoted(''):
        raise AssertionError('should not be quoted')
    if is_quoted('"a'):
        raise AssertionError('should not be quoted')
    if is_quoted("'a"):
        raise AssertionError('should not be quoted')



# Generated at 2022-06-23 02:54:12.736381
# Unit test for function split_args
def test_split_args():
    from pprint import pprint as pp


# Generated at 2022-06-23 02:54:19.180981
# Unit test for function unquote
def test_unquote():
    import sys
    assert(unquote("'hello'") == 'hello')
    assert(unquote("'hello") == 'hello')
    assert(unquote("hello'") == "hello'")
    assert(unquote("hello") == "hello")
    assert(unquote("'hello'") == "hello")
    assert(unquote("\"hello\"") == "hello")
    return True


# Generated at 2022-06-23 02:54:25.095767
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted("'hello'\"") == False
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted("''") == False
    assert is_quoted("word") == False
    assert is_quoted("'word") == False


# Generated at 2022-06-23 02:54:31.724815
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("''") == True)
    assert(is_quoted('""') == True)
    assert(is_quoted("'foo'") == True)
    assert(is_quoted('"foo"') == True)
    assert(is_quoted("'foo") == False)
    assert(is_quoted("foo'") == False)
    assert(is_quoted('"foo') == False)
    assert(is_quoted("foo\"") == False)



# Generated at 2022-06-23 02:54:37.181925
# Unit test for function unquote
def test_unquote():
    # Test case for unquote
    # input: quoted string
    # expected output: unquoted string
    assert unquote("'hello'") == 'hello'
    assert unquote('"hello"') == 'hello'
    assert unquote("hello") == 'hello', 'hello should not be changed'



# Generated at 2022-06-23 02:54:43.157478
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('\'hello\'') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'
    assert unquote('') == ''



# Generated at 2022-06-23 02:54:53.487881
# Unit test for function split_args

# Generated at 2022-06-23 02:55:03.220514
# Unit test for function split_args
def test_split_args():
    def check_split_args(args, expected):
        result = split_args(args)
        if result != expected:
            raise AssertionError("result (%s) != expected (%s)" % (result, expected))
    check_split_args("ls -l", ['ls', '-l'])
    check_split_args("ls a='b c'", ['ls', "a='b c'"])
    check_split_args("ls a=\"b c\"", ['ls', 'a="b c"'])
    check_split_args("ls a='{{ foo }}'", ['ls', "a='{{ foo }}'"])
    check_split_args("ls a=\"{{ foo }}\"", ['ls', 'a="{{ foo }}"'])