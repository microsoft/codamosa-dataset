

# Generated at 2022-06-23 02:45:11.068992
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo\\"bar"') == ['a=b', 'c="foo\\"bar"']
    assert split_args('a=b c="foo\\\\"') == ['a=b', 'c="foo\\\\"']
    assert split_args('a=b c="foo\\\\\\""') == ['a=b', 'c="foo\\\\\\""']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\\'foo bar\\'") == ['a=b', "c=\\'foo bar\\'"]

# Generated at 2022-06-23 02:45:16.908223
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("hello")) == False
    assert(is_quoted("'hello'")) == True
    assert(is_quoted('"hello"')) == True
    assert(is_quoted('"hel\'lo"')) == True
    assert(is_quoted("'hel\"lo'")) == True


# Generated at 2022-06-23 02:45:21.629443
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('hello')
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")


# Generated at 2022-06-23 02:45:28.399247
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted('foo')
    assert not is_quoted('')
    assert not is_quoted('"foo')
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted('foo\'"')
    assert not is_quoted('foo\'')
    assert not is_quoted('foo"')
    assert not is_quoted('foo\'')

# Generated at 2022-06-23 02:45:39.742452
# Unit test for function split_args
def test_split_args():
    ''' basic argument parsing tests for the split_args function '''
    assert split_args('') == []
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar', 'baz"']
    assert split_args('foo "bar baz"') == ['foo', '"bar', 'baz"']
    assert split_args('foo "bar baz"') == ['foo', '"bar', 'baz"']
    assert split_args('foo "bar baz" spam') == ['foo', '"bar', 'baz"', 'spam']

# Generated at 2022-06-23 02:45:42.472052
# Unit test for function is_quoted
def test_is_quoted():
    """should return True for \"something\" and 'something'
    """
    assert(is_quoted("\"something\""))
    assert(is_quoted("'something'"))



# Generated at 2022-06-23 02:45:48.152557
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert is_quoted("'test'")
    assert not is_quoted("'test")
    assert is_quoted("''")
    assert not is_quoted("'")
    assert is_quoted('""')
    assert not is_quoted('"')


# Generated at 2022-06-23 02:45:54.597729
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('"') is False
    assert is_quoted('""') is True
    assert is_quoted('""""') is False
    assert is_quoted('"abcd"') is True
    assert is_quoted('abcd"efg') is False
    assert is_quoted('"abcd') is False
    assert is_quoted(r'"\"') is True
    assert is_quoted(r'"\""') is True
    assert is_quoted(r'"abc\""') is True
    assert is_quoted(r'"\"abc\""') is True
    assert is_quoted(r'"\""abc\""') is True
    assert is_quoted(r'"\\') is False

# Generated at 2022-06-23 02:46:05.830258
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import unittest

    class TestSplitArgs(unittest.TestCase):

        def test_split_args_basic(self):
            args = 'a=b c="foo bar"'
            self.assertEqual(split_args(args), ['a=b', 'c="foo bar"'])

        def test_split_args_whitespace(self):
            args = 'a=b    c="foo bar"'
            self.assertEqual(split_args(args), ['a=b', 'c="foo bar"'])

        def test_split_args_line_continuations(self):
            args = 'a=b \\ \nc="foo bar"'
            self.assertEqual(split_args(args), ['a=b', 'c="foo bar"'])


# Generated at 2022-06-23 02:46:10.786316
# Unit test for function unquote
def test_unquote():
    # Testing for quote
    data_quote_single = "'abc'"
    data_quote_double = '"abc"'
    data_no_quote = 'abc'

    assert(unquote(data_quote_single) == 'abc')
    assert(unquote(data_quote_double) == 'abc')
    assert(unquote(data_no_quote) == 'abc')

    return True

# Generated at 2022-06-23 02:46:17.099411
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('""')) == True
    assert (is_quoted('""""')) == False
    assert (is_quoted("''")) == True
    assert (is_quoted("'''")) == False
    assert (is_quoted("'")) == False
    assert (is_quoted('"')) == False


# Generated at 2022-06-23 02:46:21.313514
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"one\"")
    assert is_quoted("'one'")
    assert not is_quoted("one")
    assert not is_quoted("\"one")
    assert not is_quoted("one\"")


# Generated at 2022-06-23 02:46:28.536158
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert is_quoted('"') == False
    assert is_quoted('""')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")
    assert not is_quoted("'foo")
    assert not is_quoted('foo"')
    assert not is_quoted('foo')



# Generated at 2022-06-23 02:46:35.896293
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'

if __name__ == '__main__':
    import sys
    import doctest

    doctest.testmod()

    # Run our command-line args test
    sys.exit(test_unquote())

# Generated at 2022-06-23 02:46:50.517842
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo bar 'foo bar'") == ["foo", "bar", "'foo bar'"]
    assert split_args("foo bar \"foo bar\"") == ["foo", "bar", "\"foo bar\""]
    assert split_args("foo bar \"foo bar\" foo") == ["foo", "bar", "\"foo bar\"", "foo"]
    assert split_args("foo {{ bar }} baz") == ["foo", "{{ bar }}", "baz"]
    assert split_args("{{ foo }} bar {{ baz }} bam") == ["{{ foo }}", "bar", "{{ baz }}", "bam"]

# Generated at 2022-06-23 02:46:53.352360
# Unit test for function unquote
def test_unquote():
    assert unquote('"stuff"') == 'stuff'
    assert unquote('\'stuff\'') == 'stuff'
    assert unquote('stuff') == 'stuff'

# Generated at 2022-06-23 02:46:58.019612
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"') == True
    assert is_quoted("'abcd'") == True
    assert is_quoted('"abcd') == False
    assert is_quoted("'abcd") == False
    assert is_quoted('abcd"') == False
    assert is_quoted('abcd\'') == False
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted('') == False


# Generated at 2022-06-23 02:47:01.658731
# Unit test for function is_quoted
def test_is_quoted():
    '''
    Tests for function is_quoted
    '''
    assert is_quoted('"abcd"')
    assert is_quoted("'abcd'")
    assert not is_quoted('"abcd')
    assert not is_quoted("'abcd")
    assert not is_quoted('abcd')



# Generated at 2022-06-23 02:47:09.708746
# Unit test for function split_args
def test_split_args():
    assert split_args('a b="foo bar"') == ['a', 'b="foo bar"']
    assert split_args('a b="foo bar biz   "') == ['a', 'b="foo bar biz   "']
    assert split_args('a b="foo \'bar biz\'  "') == ['a', 'b="foo \'bar biz\'  "']
    assert split_args('a b="foo \'bar biz\'  " c=\\') == ['a', 'b="foo \'bar biz\'  "', 'c=']
    assert split_args('a b="foo \'bar biz\'  " c=\\\nd=') == ['a', 'b="foo \'bar biz\'  "', 'c=\nd=']

# Generated at 2022-06-23 02:47:19.300045
# Unit test for function split_args
def test_split_args():
    '''
    Unit tests for function split_args
    '''
    from ansible.compat.six import BytesIO

    try:
        from unittest import TestCase
    except ImportError:
        # Python <= 2.6 doesn't have unittest
        from unittest2 import TestCase
    import sys

    sys.stdout = BytesIO()

    class Test(TestCase):
        def test_simple_string(self):
            args = 'foobar=test'
            expected = ['foobar=test']
            result = split_args(args)
            self.assertEqual(result, expected)

        def test_single_quoted_string(self):
            args = 'foo=\'bar\''
            expected = ['foo=\'bar\'']
            result = split_args(args)
            self

# Generated at 2022-06-23 02:47:30.217510
# Unit test for function is_quoted
def test_is_quoted():
    q_data = [
        ('simple string', False),
        ('"simple string"', True),
        ('"quoted with \' single quote"', True),
        ("'quoted with ` backtick'", True),
        ('\'quoted with " double quote\'', True),
        ('\'foo', False),
        ('"bar', False),
        ('foo"', False),
        ('bar"', False),
        ('"foo\'', False),
        ('"bar\'', False),
        ('\'foo"', False),
        ('\'bar"', False),
        ('""', True),
        ('\'\'', True),
    ]


# Generated at 2022-06-23 02:47:34.961963
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('"foo\\"bar"')
    assert is_quoted('"foo\\\\"')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')


# Generated at 2022-06-23 02:47:40.670029
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('"test')
    assert not is_quoted("'test")
    assert not is_quoted('test')

# Generated at 2022-06-23 02:47:50.776234
# Unit test for function split_args

# Generated at 2022-06-23 02:47:54.360353
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted('hello"')
    assert not is_quoted('"hello')
    assert not is_quoted("'hello")
    assert not is_quoted('hello')



# Generated at 2022-06-23 02:48:01.656667
# Unit test for function is_quoted
def test_is_quoted():
    def _test_is_quoted(s, expected):
        assert expected == is_quoted(s), "Expected %s for is_quoted(%s), received %s" % (expected, repr(s), is_quoted(s))

    quoted = '"quoted"'
    unquoted = "unquoted"
    _test_is_quoted(quoted, True)
    _test_is_quoted(unquoted, False)


# Generated at 2022-06-23 02:48:11.648211
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello world"') == "hello world"
    assert unquote('"hello world') == '"hello world'
    assert unquote('hello world"') == 'hello world"'
    assert unquote('hello world') == 'hello world'
    assert unquote('""hello world""') == '"hello world"'
    assert unquote('"hello world""') == 'hello world"'
    assert unquote('"""hello world"""') == '"hello world"'
    assert unquote('"hello world""') == 'hello world"'
    assert unquote('""hello world"') == '"hello world'
    assert unquote('""hello world') == '"hello world'
    assert unquote('"hello world') == 'hello world'


# Generated at 2022-06-23 02:48:14.244136
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert not is_quoted('abc"')
    assert not is_quoted('"abc')
    assert is_quoted("'abc'")
    assert not is_quoted("'abc")
    assert not is_quoted("abc'")


# Generated at 2022-06-23 02:48:23.424733
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c='foo bar' d=\"foo bar\"") == ['a=b', "c='foo bar'", 'd="foo bar"']
    assert split_args("a=b c='foo bar' d=\"foo bar\" e=f g='h \" i'") == ['a=b', "c='foo bar'", 'd="foo bar"', "e=f", 'g=\'h " i\'']

    assert split_args("a=b c=\"foo{{bar}}\"") == ['a=b', 'c="foo{{bar}}"']

# Generated at 2022-06-23 02:48:26.761699
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("test1") is False
    assert is_quoted("'test1'") is True
    assert is_quoted("\"test1\"") is True


# Generated at 2022-06-23 02:48:32.348310
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('\'abc\'') == 'abc'
    assert unquote('"a""') == 'a"'
    assert unquote('\'a\'\'') == 'a\''
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote('abc') == 'abc'



# Generated at 2022-06-23 02:48:38.570052
# Unit test for function is_quoted
def test_is_quoted():
    # Test the is_quoted function
    assert(is_quoted('"This is quoted"') == True)
    assert(is_quoted("'This is quoted'") == True)
    assert(is_quoted('This is not quoted') == False)
    assert(is_quoted('"This is not quoted\'') == False)
    assert(is_quoted('"This is not quoted') == False)
    assert(is_quoted("This is not quoted'") == False)


# Generated at 2022-06-23 02:48:46.580147
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('data') == 'data'
    assert unquote('"data"') == 'data'
    assert unquote('"data') == '"data'
    assert unquote('data"') == 'data"'
    assert unquote("'data'") == 'data'
    assert unquote("'data") == "'data"
    assert unquote("data'") == "data'"
    assert unquote("''") == ''
    assert unquote("'") == "'"
    assert unquote("'''") == "'"
    assert unquote("\"\"") == ''
    assert unquote("\"") == "\""
    assert unquote("\"\"\"") == "\""

# Generated at 2022-06-23 02:48:58.171982
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo\\\nbar\"") == ['a=b', 'c="foo\nbar"']
    assert split_args("a=b c=\"'foo bar'\"") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"'foo)bar'\"") == ['a=b', "c='foo)bar'"]
    assert split_args("a=b c=\"'foo}}bar'\"") == ['a=b', "c='foo}}bar'"]
    assert split_args("a=b c=\"'foo}}bar\"") == ['a=b', "c='foo}}bar"]

# Generated at 2022-06-23 02:49:07.862713
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello world"') == True
    assert is_quoted('"hello world') == False
    assert is_quoted('hello world"') == False
    assert is_quoted('"hello" world"') == False
    assert is_quoted('\'hello world\'') == True
    assert is_quoted('\'hello world') == False
    assert is_quoted('hello world\'') == False
    assert is_quoted('"hello world\'') == False
    assert is_quoted('hello world') == False
    assert is_quoted('"hello world""') == False
    assert is_quoted('hello world""') == False
    assert is_quoted('"""hello world"""') == True
    assert is_quoted('"""hello world""') == False

# Generated at 2022-06-23 02:49:13.942253
# Unit test for function is_quoted
def test_is_quoted():
    ''' Unit test for function is_quoted '''
    assert is_quoted("'quoted'")
    assert is_quoted('"quoted"')
    assert not is_quoted("foo")
    assert not is_quoted('"foo\'')
    assert not is_quoted("'bar\"")


# Generated at 2022-06-23 02:49:25.623157
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"\ne=f') == ['a=b', 'c="foo bar"', 'e=f']
    assert split_args('a=b c="foo bar"\ne=f') == split_args('a=b c="foo bar"\\\ne=f')
    assert split_args('a=b c="foo bar" "some thing"') == ['a=b', 'c="foo bar"', '"some thing"']
    assert split_args('a=b c="foo bar" d={{ foo }}') == ['a=b', 'c="foo bar"', 'd={{ foo }}']

# Generated at 2022-06-23 02:49:34.674951
# Unit test for function split_args
def test_split_args():
    ''' Unit Test for function split_args '''
    t_dict = dict(
        plain='foo bar baz',
        quoted='"foo bar baz"',
        quoted_paren='"foo bar baz" qux',
        paren='foo bar baz qux',
        quoted_paren_paren='"foo bar" baz "qux quux"',
        multiline='''foo \
bar baz''',
        multiline_paren="""foo \
bar baz qux""",
        multiline_quoted_paren="""foo \
"bar baz" qux""",
        )
    for t in t_dict:
        result = split_args(t_dict[t])

# Generated at 2022-06-23 02:49:40.757478
# Unit test for function unquote
def test_unquote():
    ''' unit test for unquote'''
    assert unquote('"test"') == 'test'
    assert unquote('"test') == '"test'
    assert unquote("'test'") == 'test'
    assert unquote("'test") == "'test"

# Generated at 2022-06-23 02:49:51.739000
# Unit test for function unquote
def test_unquote():
    ''' Test cases for unquote'''
    test_list = [
        ('"foo bar"', "foo bar"),
        ("'foo bar'", "foo bar"),
        ('"foo bar', '"foo bar'),
        ("'foo bar", "'foo bar"),
        ("foo bar'", "foo bar'"),
        ('foo bar"', 'foo bar"'),
        ('"foo bar\'', '"foo bar\'')
    ]
    for testcase in test_list:
        assert unquote(testcase[0]) == testcase[1]

    assert test_list == [(unquote(x[0]), unquote(x[1])) for x in test_list]


# Generated at 2022-06-23 02:49:55.008230
# Unit test for function unquote
def test_unquote():
    assert (unquote("\"a\"") == "a")
    assert (unquote("'b'") == "b")
    assert (unquote("c") == "c")



# Generated at 2022-06-23 02:50:06.133513
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") is True
    assert is_quoted('"foo"') is True
    assert is_quoted("'\"'") is True
    assert is_quoted('"\'"') is True
    assert is_quoted("'\"foo\"'") is True
    assert is_quoted('"\'foo\'"') is True
    assert is_quoted("foo") is False
    assert is_quoted("'foo") is False
    assert is_quoted("foo'") is False
    assert is_quoted('"foo') is False
    assert is_quoted('foo"') is False
    assert is_quoted("'foo\"") is False
    assert is_quoted('"foo\'') is False
    assert is_quoted("''") is False
    assert is_quoted

# Generated at 2022-06-23 02:50:11.205365
# Unit test for function unquote
def test_unquote():
    print("Testing function unquote")
    assert (unquote("'test'") == "test")
    assert (unquote('"test"') == "test")
    assert (unquote("test") == "test")
    assert (unquote("'test") == "'test")
    print("Function unquote passed all tests")

# Generated at 2022-06-23 02:50:21.542377
# Unit test for function split_args

# Generated at 2022-06-23 02:50:33.907916
# Unit test for function split_args
def test_split_args():
    # basic tests
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b c=d ") == ["a=b", "c=d"]

    # quoting tests
    assert split_args("a='b c'") == ['a=\'b c\'']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args("a='b c d'") == ['a=\'b c d\'']
    assert split_args('a="b c d"') == ['a="b c d"']

    # mixed quoting and unquoted tests

# Generated at 2022-06-23 02:50:40.293266
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("\"foo\"") == True
    assert is_quoted("'foo") == False
    assert is_quoted("'") == False
    assert is_quoted("\"") == False
    assert is_quoted("foo") == False
    assert is_quoted("\"foo'") == False


# Generated at 2022-06-23 02:50:49.240190
# Unit test for function split_args
def test_split_args():
    ''' paramgrammar.split_args(args) unit tests '''

    import sys
    if sys.version_info < (2,7):
        import unittest2 as unittest
    else:
        import unittest

    # a simple example from module_utils/basic.py
    # this test verifies that a module argument
    # can contain a double quoted value with spaces,
    # and that the second arg's value is not split
    # on the equals sign within the double quotes
    test1 = unittest.TestCase("__init__")
    test1.assertEqual(split_args("a=\"foo bar\" b=\"c=d\""), ['a="foo bar"', 'b="c=d"'])

    # verify that a value contained in a single quote
    # is not split on the spaces

# Generated at 2022-06-23 02:50:58.266015
# Unit test for function split_args
def test_split_args():
    """Unit test for AnsibleModule split_args() function"""

    def _test_split(args, expect_result):
        if isinstance(args, basestring):
            result = split_args(args)
        elif isinstance(args, list):
            test_args = u"{0}".format(args[0])
            for arg in args[1:]:
                test_args = u"{0} {1}".format(test_args, arg)
            result = split_args(test_args)
        else:
            raise TypeError("test_split_args() passed incorrect argument type")

        if result != expect_result:
            raise AssertionError("test_split_args() failed for {0}: expected {1} but got {2}".format(args, expect_result, result))

    # Should raise a

# Generated at 2022-06-23 02:51:09.142064
# Unit test for function split_args
def test_split_args():

    # First, we import our module and create a dictionary to store test cases
    import module_utils.common as common

    testcases = dict()

    # We put each test case into the dictionary, with a key and value. The key is simply a description of the case.
    # The value is a list which has three items in it. The first is a string containing the arguments.
    # The second is a list, which contains the expected arguments after being parsed.
    # The third is a boolean indicating whether or not the test case is expected to fail or succeed.
    testcases['single_word_single_arg'] = ['single', ['single'], False]
    testcases['multiple_word_single_arg'] = ['foo bar', ['foo bar'], False]

# Generated at 2022-06-23 02:51:14.259709
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('""') == ''
    assert unquote('""hello') == '"hello'
    assert unquote('hello""') == 'hello"'
    assert unquote("''") == ''
    assert unquote("''hello") == "'hello"
    assert unquote("hello''") == 'hello\''

# Generated at 2022-06-23 02:51:25.841243
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted('"foo"')
    assert is_quoted("''")
    assert is_quoted("'foo'")
    assert is_quoted('"foo bar"')
    assert is_quoted('"foo bar') is False
    assert is_quoted('foo bar"') is False
    assert is_quoted('""foo""') is False
    assert is_quoted('"""foo"""') is False
    assert is_quoted('"foo" "bar"') is False
    assert is_quoted('/bin/python') is False
    assert is_quoted('"foo "bar"') is False
    assert is_quoted('"foo\nbar"') is False
    assert is_quoted('""foo') is False

# Generated at 2022-06-23 02:51:29.369984
# Unit test for function is_quoted
def test_is_quoted():
    # is_quoted returns True, if the input string starts and ends with quotes
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')


# Generated at 2022-06-23 02:51:38.233013
# Unit test for function unquote
def test_unquote():
    assert unquote("foobar") == "foobar"
    assert unquote("'foobar'") == "foobar"
    assert unquote('"foobar"') == "foobar"
    assert unquote("'foobar") == "'foobar"
    assert unquote("foobar'") == "foobar'"
    assert unquote("'foobar\"") == "'foobar\""
    assert unquote("\"foobar'") == "\"foobar'"

if __name__ == '__main__':
    # Run the unit tests
    test_unquote()

# Generated at 2022-06-23 02:51:49.545220
# Unit test for function split_args
def test_split_args():
    import unittest

    class MyTest(unittest.TestCase):
        def test_split_args(self):
            args = 'foo bar="baz ding"'
            self.assertEqual(split_args(args), ['foo', 'bar=baz ding'])

            args = 'foo="bar baz" ding=pop'
            self.assertEqual(split_args(args), ['foo=bar baz', 'ding=pop'])

            args = '''foo="bar baz" \
ding=pop'''
            self.assertEqual(split_args(args), ['foo=bar baz', 'ding=pop'])

            args = '''foo="bar baz" \\
ding=pop'''

# Generated at 2022-06-23 02:52:00.955799
# Unit test for function split_args

# Generated at 2022-06-23 02:52:12.391403
# Unit test for function unquote
def test_unquote():
    """
    Test cases for unquote
    """
    data1 = """ "hello" """
    data2 = """ 'hi' """
    data3 = """  """
    data4 = """ 'hi' """
    data5 = """ hello """
    data6 = """ 'hello """
    data7 = """ ' ' """
    data8 = """ " " """

    assert unquote(data1) == "hello"
    assert unquote(data2) == "hi"
    assert unquote(data3) == ""
    assert unquote(data4) == "hi"
    assert unquote(data5) == "hello"
    assert unquote(data6) == "'hello"
    assert unquote(data7) == " "
    assert unquote(data8) == " "

# Generated at 2022-06-23 02:52:23.776224
# Unit test for function split_args
def test_split_args():
    import sys

    # just one test
    assert split_args("a='foo bar' b={{baz}} c={{{blah}}} d={{ 'hey' }}") == ['a=foo bar', "b={{baz}}", "c={{{blah}}}", "d={{ 'hey' }}"]

    # test with Python 3 unicode strings

# Generated at 2022-06-23 02:52:34.013069
# Unit test for function split_args
def test_split_args():
    def assert_list(args, ref):
        assert ref == split_args(args), "failed: %s != %s" % (ref, split_args(args))

    assert_list('a=b', ['a=b'])
    assert_list('a="b b"', ['a="b b"'])
    assert_list('"a=b b"', ['"a=b b"'])
    assert_list('a={{ b }}', ['a={{ b }}'])
    assert_list('a="{{ b }}"', ['a="{{ b }}"'])
    assert_list('a={{ b }} c="foo bar"', ['a={{ b }}', 'c="foo bar"'])
    assert_list('a={{ b }} c="foo bar"', ['a={{ b }}', 'c="foo bar"'])

# Generated at 2022-06-23 02:52:40.706384
# Unit test for function split_args
def test_split_args():
    examples = dict()
    examples['foo bar baz'] = ['foo', 'bar', 'baz']
    examples['foo=bar baz="this is a test" test=nothing'] = ['foo=bar', 'baz="this is a test"', 'test=nothing']
    examples['"this has a backslash\\\\inside a quoted string"'] = ['this has a backslash\\\\inside a quoted string']
    examples['a b="with \\"quotes\\" inside" c'] = ['a', 'b="with \\"quotes\\" inside"', 'c']
    examples['test="test1 test2 test3"'] = ['test="test1 test2 test3"']
    examples['test="test1\ntest2\ntest3"'] = ['test="test1\ntest2\ntest3"']

# Generated at 2022-06-23 02:52:51.608485
# Unit test for function split_args

# Generated at 2022-06-23 02:53:00.808783
# Unit test for function is_quoted
def test_is_quoted():
    ''' unittest for function is_quoted '''
    tests = [
        ('', False),
        ('"hello world"', True),
        ("'hello world'", True),
        ('"hello world', False),
        ("'hello world", False),
        ('hello world"', False),
        ('hello world"', False),
        ('"hello"world"', False),
        ('hello', False)
    ]
    for test in tests:
        assert is_quoted(test[0]) == test[1]


# Generated at 2022-06-23 02:53:04.497089
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted("'test")
    assert not is_quoted('"test')



# Generated at 2022-06-23 02:53:11.464470
# Unit test for function unquote
def test_unquote():
    '''
    Unquote string

    :return:
    '''
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo"') == 'foo"'
    assert unquote('foo') == 'foo'

# Generated at 2022-06-23 02:53:17.735527
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('foo') == False
    assert is_quoted("'foo") == False
    assert is_quoted('"foo') == False
    assert is_quoted("foo'") == False
    assert is_quoted('foo"') == False
    assert is_quoted("'foo\"") == False
    assert is_quoted('"foo\'') == False


# Generated at 2022-06-23 02:53:22.813405
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("foo") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'



# Generated at 2022-06-23 02:53:27.697062
# Unit test for function unquote
def test_unquote():
    print(unquote('"test"'))
    print(unquote("'test'"))
    print(unquote('test'))
    print(unquote('"test'))
    print(unquote('test"'))

if __name__ == '__main__':
    test_unquote()

# Generated at 2022-06-23 02:53:30.505476
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('foo"') == 'foo"'



# Generated at 2022-06-23 02:53:40.740263
# Unit test for function split_args
def test_split_args():
    import textwrap

# Generated at 2022-06-23 02:53:45.014897
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote("foo'") == "foo'"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo") == "foo"



# Generated at 2022-06-23 02:53:56.854476
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("''") is True
    assert is_quoted("'''") is False
    assert is_quoted("'''") is False
    assert is_quoted('""') is True
    assert is_quoted('"""') is False
    assert is_quoted('"""') is False
    assert is_quoted("'foo'") is True
    assert is_quoted('"foo"') is True
    assert is_quoted("'foo") is False
    assert is_quoted('"foo') is False
    assert is_quoted("foo'") is False
    assert is_quoted("foo'") is False
    assert is_quoted("foo") is False
    assert is_quoted("foo bar") is False


# Generated at 2022-06-23 02:54:06.679302
# Unit test for function split_args
def test_split_args():
    assert split_args('/bin/foo "one arg"') == [b'/bin/foo', '"one arg"']
    assert split_args("/bin/foo 'one arg'") == [b'/bin/foo', "'one arg'"]
    assert split_args("/bin/foo 'one arg") == [b'/bin/foo', "'one arg"]
    assert split_args("/bin/foo \"one arg") == [b'/bin/foo', '"one arg']
    assert split_args("/bin/foo \"one arg\\\"") == [b'/bin/foo', '"one arg"']
    assert split_args("/bin/foo \"one arg'") == [b'/bin/foo', '"one arg\'']

# Generated at 2022-06-23 02:54:18.401185
# Unit test for function split_args
def test_split_args():
    test1 = "test1"
    test2 = "test2"
    test3 = "test3"
    test2a = test2 + "=" + test3


# Generated at 2022-06-23 02:54:27.780079
# Unit test for function split_args

# Generated at 2022-06-23 02:54:35.563371
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"""') is False
    assert is_quoted('"a"') is True
    assert is_quoted('"a') is False
    assert is_quoted('b"') is False
    assert is_quoted('') is False
    assert is_quoted('"""a"""') is False
    assert is_quoted('"""abc"""') is False
    assert is_quoted('"""a"b"c"""') is False
    assert is_quoted('"""a\\"b\\"c"""') is True
    assert is_quoted('"""\\"a\\"b\\"c\\""""') is True
    assert is_quoted('"""\\"a\\"b\\"c\\""""') is True
    assert is_quoted('"""\\"a\\"bc\\""""') is True


# Generated at 2022-06-23 02:54:46.434683
# Unit test for function split_args
def test_split_args():
    args1 = '''
    I like my waffles plain
    and my eggs over easy
    '''
    assert split_args(args1) == ['I', 'like', 'my', 'waffles', 'plain\n', 'and', 'my', 'eggs', 'over', 'easy', '\n']

    args2 = '''
    are you {{ 'expecting' }} this {{ 'result' }}
    '''
    assert split_args(args2) == ['are', 'you', '{{', '\'expecting\'', '}}', 'this', '{{', '\'result\'', '}}\n']

    args3 = '''
    this is a single line
    '''
    assert split_args(args3) == ['this', 'is', 'a', 'single', 'line\n']


# Generated at 2022-06-23 02:54:50.697573
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert not is_quoted("hello'")
    assert not is_quoted("hello")
    assert not is_quoted('"hello')
    assert not is_quoted("hel'lo")


# Generated at 2022-06-23 02:55:00.093158
# Unit test for function is_quoted
def test_is_quoted():
    data = "test"
    assert not is_quoted(data)

    data = "\"test\""
    assert is_quoted(data)

    data = "\"test"
    assert not is_quoted(data)

    data = "test\""
    assert not is_quoted(data)

    data = "'test'"
    assert is_quoted(data)

    data = "'test"
    assert not is_quoted(data)

    data = "test'"
    assert not is_quoted(data)


# Generated at 2022-06-23 02:55:12.213464
# Unit test for function split_args
def test_split_args():
    '''
    This function contains a number of unit tests for the function split_args().
    This function runs the unit tests and returns 0 on success, 1 if any of
    the unit tests fail.
    '''
    import traceback
    import sys

    class UnitTestError(Exception):
        pass

    def _test(arg, expected_result):
        '''
        This function runs a single unit test. If the unit test fails, the function
        will throw an exception. This exception is caught by the function test_split_args().
        '''
        actual_result = split_args(arg)
        print("Input: %s" % arg)
        print("Expected result: %s" % expected_result)
        print("Actual result: %s" % actual_result)
        if actual_result != expected_result:
            raise Unit