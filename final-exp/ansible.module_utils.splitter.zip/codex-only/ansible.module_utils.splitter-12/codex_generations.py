

# Generated at 2022-06-23 02:45:13.739954
# Unit test for function unquote
def test_unquote():
    assert unquote("'first'") == 'first'
    assert unquote("'first") == "'first"
    assert unquote("first'") == "first'"
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == "foo bar"
    assert unquote("'foo'bar") == "'foobar"
    assert unquote("foo'bar'") == "foobar"
    assert unquote("'foo'bar'") == "'foobar"
    assert unquote("'foo\"bar'") == 'foo"bar'
    assert unquote("'foo\\'bar'") == "foo'bar"
    assert unquote("'foo\\\"bar'") == 'foo\\"bar'
    assert unquote("\"foo\\'bar\"") == "foo'bar"

# Generated at 2022-06-23 02:45:16.920115
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == "foo"
    assert unquote('"bar"') == 'bar'
    assert unquote("") == ""
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"



# Generated at 2022-06-23 02:45:27.266497
# Unit test for function is_quoted
def test_is_quoted():
    test_strs = ('"',
                 'foo',
                 '"foo"',
                 '"foo',
                 'foo"',
                 "''",
                 "foo",
                 "''foo''",
                 "''foo",
                 "foo''",
                 '"""',
                 'foo',
                 '"""foo"""',
                 '"""foo',
                 'foo"""',
                 "''''",
                 "foo",
                 "''''foo''''",
                 "''''foo",
                 "foo''''",
                 )

# Generated at 2022-06-23 02:45:34.079583
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d x=y") == ['a=b', 'c=d', 'x=y']
    assert split_args("a=b ' c=d' x=y") == ['a=b', ' c=d', 'x=y']
    assert split_args("a=b 'c=d x=y'") == ['a=b', "c=d x=y"]
    assert split_args("a=b 'c={% foo %}'") == ['a=b', "c={% foo %}"]
    assert split_args("a=b c={% foo %} x=y") == ['a=b', "c={% foo %}", 'x=y']

# Generated at 2022-06-23 02:45:40.441492
# Unit test for function unquote
def test_unquote():
    ''' test unquoting strings '''
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("foo") == 'foo'
    assert unquote("'") == "'"
    assert unquote('"') == '"'
    assert unquote(u'"foo"') == u'foo'

# Generated at 2022-06-23 02:45:44.730564
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted('abc') == False
    assert is_quoted("'abc'") == True
    assert is_quoted("'ab'c'") == False
    assert is_quoted("'ab''c'") == True


# Generated at 2022-06-23 02:45:53.315629
# Unit test for function unquote
def test_unquote():
    ''' test unquote function'''
    data = '"Hello world"'
    res = unquote(data)
    if res == 'Hello world':
        print("unquote('Hello world') => pass")
    else:
        print("unquote('Hello world') => failed")
    res = unquote(res)
    if res == 'Hello world':
        print("unquote('Hello world') => pass")
    else:
        print("unquote('Hello world') => failed")
    data = "'Hello world'"
    res = unquote(data)
    if res == 'Hello world':
        print("unquote('Hello world') => pass")
    else:
        print("unquote('Hello world') => failed")
    res = unquote(res)

# Generated at 2022-06-23 02:46:03.477034
# Unit test for function split_args

# Generated at 2022-06-23 02:46:11.624718
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('""') == True
    assert is_quoted('"a"') == True
    assert is_quoted(r'"ab\"cd"') == True
    assert is_quoted('""a"') == False
    assert is_quoted('"a""') == False
    assert is_quoted("''") == True
    assert is_quoted("'a'") == True
    assert is_quoted(r"'ab\'cd'") == True
    assert is_quoted("''a'") == False
    assert is_quoted("'a''") == False


# Generated at 2022-06-23 02:46:24.256332
# Unit test for function split_args
def test_split_args():
    assert split_args('foo="bar baz"') == ['foo=bar baz']
    assert split_args('foo="bar baz" spam=ham') == ['foo=bar baz', 'spam=ham']
    assert split_args('foo="bar baz" spam=ham') == ['foo=bar baz', 'spam=ham']
    # backslash escaped quotes inside quotes should be preserved
    assert split_args(r'foo="bar\"baz" spam=ham') == ['foo=bar"baz', 'spam=ham']
    # backslash escaped quotes outside quotes should be preserved
    assert split_args(r'foo=bar\"baz spam=ham') == ['foo=bar\\"baz', 'spam=ham']
    # backslash escaped quotes outside quotes should be preserved

# Generated at 2022-06-23 02:46:29.355815
# Unit test for function is_quoted
def test_is_quoted():
    assertTrue(is_quoted("'data'"))
    assertTrue(is_quoted("\"data\""))
    assertFalse(is_quoted("'data"))
    assertFalse(is_quoted("data'"))
    assertFalse(is_quoted("data"))
    assertFalse(is_quoted("'data\"'"))

# Generated at 2022-06-23 02:46:37.051869
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("")  == False
    assert is_quoted("'") == False
    assert is_quoted("\"") == False
    assert is_quoted("''") == False
    assert is_quoted("\"\"") == False
    assert is_quoted("'a'") == True
    assert is_quoted("'ab'") == True
    assert is_quoted("\"a\"") == True
    assert is_quoted("\"ab\"") == True
    assert is_quoted("a'b") == False
    assert is_quoted("a\"b") == False


# Generated at 2022-06-23 02:46:51.447587
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("") == False)
    assert(is_quoted("'") == False)
    assert(is_quoted('"') == False)
    assert(is_quoted('""') == False)
    assert(is_quoted("''") == False)
    assert(is_quoted("'\"") == False)
    assert(is_quoted("\"'") == False)
    assert(is_quoted("'a'") == True)
    assert(is_quoted('"a"') == True)
    assert(is_quoted("'''") == False)
    assert(is_quoted('""a"') == False)
    assert(is_quoted("'a\"'") == True)
    assert(is_quoted("\"a''\"") == True)



# Generated at 2022-06-23 02:46:58.799232
# Unit test for function split_args

# Generated at 2022-06-23 02:47:00.890153
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted('abc') == False
    assert is_quoted('') == False


# Generated at 2022-06-23 02:47:04.989256
# Unit test for function unquote
def test_unquote():
    ''' unit tests for function unquote '''
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'



# Generated at 2022-06-23 02:47:11.175749
# Unit test for function unquote
def test_unquote():
    tests = (
        ('spam', 'spam'),
        ('"spam"', 'spam'),
        ('"spam', '"spam'),
        ('spam"', 'spam"'),
    )
    for arg, expected in tests:
        res = unquote(arg)
        assert res == expected

# Generated at 2022-06-23 02:47:22.580343
# Unit test for function split_args

# Generated at 2022-06-23 02:47:34.108243
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote("'foo") == "'foo"
    assert unquote('"foo') == '"foo'
    assert unquote('"foo\'') == '"foo\''
    assert unquote('\'foo"') == '\'foo"'
    assert unquote("''") == ''
    assert unquote('""') == ''
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"bar baz"') == 'bar baz'
    assert unquote('\'bar baz\'') == 'bar baz'



# Generated at 2022-06-23 02:47:44.152111
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote("\"foo\"") == "foo"
    assert unquote("\"foo") == "foo"
    assert unquote("\"\"foo\"\"") == "foo"
    assert unquote("\"\"\"foo\"\"\"") == "foo"
    assert unquote("\"\'foo\'\"") == "'foo'"
    assert unquote("\'foo\'") == "foo"
    assert unquote("\'\'foo\'\'") == "foo"
    assert unquote("\'\'\'foo\'\'\'") == "foo"
    assert unquote("\'\"foo\"\'") == "\"foo\""
    assert unquote("\"\"\"foo") == "foo"
    assert unquote("\"\"\"\"foo\"\"\"") == "foo"

# Generated at 2022-06-23 02:47:51.906643
# Unit test for function is_quoted
def test_is_quoted():
    if not is_quoted(''):
        raise AssertionError('is_quoted() returned false for empty string')
    if not is_quoted('""'):
        raise AssertionError('is_quoted() returned false for empty quotes')
    if not is_quoted('"x"'):
        raise AssertionError('is_quoted() returned false for single-character string')
    if not is_quoted('\'x\''):
        raise AssertionError('is_quoted() returned false for single-character string')
    if is_quoted('"x'):
        raise AssertionError('is_quoted() returned true for mis-matched quotes')
    if is_quoted('x"'):
        raise AssertionError('is_quoted() returned true for mis-matched quotes')


# Unit test

# Generated at 2022-06-23 02:47:56.173310
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo\'"') == 'foo\''
    assert unquote('\'foo"\'') == 'foo"'

# Generated at 2022-06-23 02:48:04.013850
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"a quoted string"')
    assert not is_quoted('a quoted string"')
    assert not is_quoted('a quoted string')
    assert not is_quoted('"a quoted string')
    assert is_quoted("'another quoted string'")
    assert not is_quoted("'another quoted string")
    assert not is_quoted("another quoted string'")
    assert not is_quoted("'another quoted string")


# Generated at 2022-06-23 02:48:09.042299
# Unit test for function unquote
def test_unquote():
    import pytest
    assert unquote('"test"') == 'test'
    assert unquote('"test\'"') == 'test\''
    assert unquote('"test\'') == 'test\''
    assert unquote('test') == 'test'
    with pytest.raises(Exception):
        unquote(None)

# Generated at 2022-06-23 02:48:18.097392
# Unit test for function split_args
def test_split_args():
    params = split_args('a=b c="d e"')
    assert params == ['a=b', 'c="d e"']

    params = split_args('a=b c="d e')
    assert params == ['a=b', 'c="d', 'e']

    params = split_args('a=b c="d \'e"')
    assert params == ['a=b', 'c="d \'e"']

    params = split_args('a=b c="d \"e"')
    assert params == ['a=b', 'c="d "e"']

    params = split_args("a=b c='d e'")
    assert params == ['a=b', "c='d e'"]

    params = split_args("a=b c='d \'e'")

# Generated at 2022-06-23 02:48:22.700141
# Unit test for function unquote
def test_unquote():
    for data in ['"foo"', "'bar'", 'baz', "'fo''o'", '"b''ar"', '"fo\"o"']:
        assert unquote(data) == eval(data)


# Generated at 2022-06-23 02:48:35.101404
# Unit test for function unquote
def test_unquote():
    assert unquote("''") == ''
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("foo bar") == "foo bar"
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo 'bar") == "'foo 'bar"
    assert unquote('"foo "bar') == '"foo "bar'
    assert unquote("foo bar'") == "foo bar'"
    assert unquote("foo bar'\"") == "foo bar'\""


# Generated at 2022-06-23 02:48:44.657497
# Unit test for function split_args
def test_split_args():
    e = Exception("fail")

# Generated at 2022-06-23 02:48:47.779127
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quoted"')
    assert is_quoted("'quoted'")
    assert not is_quoted('noquotes')
    assert not is_quoted('"noquotes')



# Generated at 2022-06-23 02:48:58.076137
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == 'foo bar'
    assert unquote('""') == ''
    assert unquote("''") == ''
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote("foo'") == "foo'"
    assert unquote('foo bar') == 'foo bar'



# Generated at 2022-06-23 02:49:05.466581
# Unit test for function is_quoted
def test_is_quoted():
    print('Testing function "is_quoted"')
    print(('    is_quoted("bla") = ' + str(is_quoted("bla"))))
    print(('    is_quoted("\"bla\"") = ' + str(is_quoted("\"bla\""))))
    print(('    is_quoted("\'bla\'") = ' + str(is_quoted("'bla'"))))
    print(('    is_quoted("\'\"bla\"\'") = ' + str(is_quoted("'\"bla\"'"))))



# Generated at 2022-06-23 02:49:14.796863
# Unit test for function split_args
def test_split_args():

    # If a string is passed in, it should be returned as param length one
    assert(len(split_args('bogus_string')) == 1)

    # Test some trivial cases that are expected to split on spaces
    # while keeping quoted strings together
    (param1, param2, param3) = split_args('a b "c d"')
    assert(param1 == 'a')
    assert(param2 == 'b')
    assert(param3 == '"c d"')

    # Test some trivial cases that are expected to split on spaces
    # while keeping quoted strings together
    (param1, param2, param3) = split_args('a b "c d"')
    assert(param1 == 'a')
    assert(param2 == 'b')
    assert(param3 == '"c d"')

    # Test

# Generated at 2022-06-23 02:49:20.943450
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foobar"') is True
    assert is_quoted("'foobar'") is True
    assert is_quoted('"foo bar"') is True
    assert is_quoted("'foo bar'") is True
    assert is_quoted('foo bar') is False
    assert is_quoted('"foo bar') is False



# Generated at 2022-06-23 02:49:22.694014
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote('hello') == 'hello'


# Generated at 2022-06-23 02:49:36.083808
# Unit test for function split_args
def test_split_args():
    res = split_args("a=b c={{d}} {{e}} f= '{{g}}'")
    assert res == ['a=b', 'c={{d}}', '{{e}}', "f=", "'{{g}}'"]

    res = split_args("a=b 'c={{d}} {{e}}' f= '{{g}}'")
    assert res == ['a=b', "'c={{d}} {{e}}'", "f=", "'{{g}}'"]

    res = split_args("a=b {{c}}")
    assert res == ['a=b', '{{c}}']

    res = split_args("a={{b} c={{d}} {{e}} f= '{{g}}'")

# Generated at 2022-06-23 02:49:43.424982
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted('abc') == False
    assert is_quoted('') == False
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted('"""') == False
    assert is_quoted("'''") == False


# Generated at 2022-06-23 02:49:52.031523
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("'this is quoted'") == True)
    assert(is_quoted("'this is quoted") == False)
    assert(is_quoted("this is quoted'") == False)
    assert(is_quoted("this is quoted") == False)
    assert(is_quoted("''") == True)
    assert(is_quoted("'") == False)
    assert(is_quoted("'\n'") == True)
    assert(is_quoted("\n") == False)


# Generated at 2022-06-23 02:50:01.048591
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("") == False
    assert is_quoted("'") == False
    assert is_quoted("'foo") == False
    assert is_quoted("foo'") == False
    assert is_quoted("'foo'") == True
    assert is_quoted('"') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo\"bar'") == True
    assert is_quoted("'foo\'bar'") == True
    assert is_quoted('"foo\'bar"') == True
    assert is_quoted('"foo\"bar"') == True


# Generated at 2022-06-23 02:50:07.557387
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('""'))
    assert(is_quoted('"foo"'))
    assert(is_quoted("''"))
    assert(is_quoted("'bar'"))
    assert(not is_quoted('"'))
    assert(not is_quoted("'bar"))
    assert(not is_quoted("bar'"))
    assert(not is_quoted("boo"))



# Generated at 2022-06-23 02:50:15.111125
# Unit test for function unquote
def test_unquote():
    if unquote('"test"') != 'test':
        raise ValueError('unquote() failed to remove quotes around a string')

    if unquote('') != '':
        raise ValueError('unquote() failed to leave an empty string')

    if unquote('""') != '':
        raise ValueError('unquote() failed to remove quotes from empty string')

    if unquote('"test') == 'test':
        raise ValueError('unquote() failed to leave string unmodified if not quoted')


# Generated at 2022-06-23 02:50:23.295794
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"hello"') == True)
    assert(is_quoted("'hello'") == True)
    assert(is_quoted('"hello') == False)
    assert(is_quoted("'hello") == False)
    assert(is_quoted('hello"') == False)
    assert(is_quoted("hello'") == False)
    assert(is_quoted('"hello\'') == False)
    assert(is_quoted("'hello\"") == False)
    assert(is_quoted('hello') == False)
    assert(is_quoted('"hello" world') == False)
    assert(is_quoted('"1"') == True)
    assert(is_quoted('""') == True)
    assert(is_quoted('') == False)

# Generated at 2022-06-23 02:50:31.999506
# Unit test for function is_quoted
def test_is_quoted():
    assert (is_quoted('') == False)
    assert (is_quoted('abcd') == False)
    assert (is_quoted('"abcd"') == True)
    assert (is_quoted('\'abcd\'') == True)
    assert (is_quoted('"a"') == True)
    assert (is_quoted('\'\'') == True)
    assert (is_quoted('\'a') == False)
    assert (is_quoted('a\'') == False)


# Generated at 2022-06-23 02:50:43.302304
# Unit test for function split_args

# Generated at 2022-06-23 02:50:51.621888
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"')
    assert not is_quoted('"abcd')
    assert not is_quoted('abcd"')
    assert not is_quoted('abcd')
    assert not is_quoted('')
    assert is_quoted("'abcd'")
    assert not is_quoted("'abcd")
    assert not is_quoted("abcd'")
    assert not is_quoted("abcd")
    assert not is_quoted("")


# Generated at 2022-06-23 02:51:02.488857
# Unit test for function unquote

# Generated at 2022-06-23 02:51:11.671167
# Unit test for function split_args

# Generated at 2022-06-23 02:51:24.569231
# Unit test for function is_quoted
def test_is_quoted():
    # Unquoted strings must be accepted
    assert True == is_quoted('Test')
    # Quoted strings must be accepted
    assert True == is_quoted('"Test"')
    assert True == is_quoted('"Test')
    assert True == is_quoted('Test"')
    assert True == is_quoted('\'Test\'')
    assert True == is_quoted('\'Test')
    assert True == is_quoted('Test\'')
    # Unquoted strings with quotes should not be accepted
    assert False == is_quoted('"Test')
    assert False == is_quoted('Test"')
    assert False == is_quoted('\'Test')
    assert False == is_quoted('Test\'')
    # Empty string should not be accepted
    assert False == is_quoted('')

# Generated at 2022-06-23 02:51:34.749662
# Unit test for function unquote
def test_unquote():
    '''The function unquote returns a string with the first and last
    quotes removed from the string, if the string starts and ends with
    the same quotes.'''
    # Test cases where the string is quoted
    assert unquote('""') == ''
    assert unquote('"abc"') == 'abc'
    assert unquote("''") == ''
    assert unquote("'abc'") == 'abc'
    # Test cases where the string is not quoted
    assert unquote('') == ''
    assert unquote('"') == '"'
    assert unquote("'") == "'"
    assert unquote('abc') == 'abc'
    assert unquote('"abc') == '"abc'
    assert unquote("'abc") == "'abc"



# Generated at 2022-06-23 02:51:41.780362
# Unit test for function unquote
def test_unquote():
    assert unquote('"bob"') == 'bob'
    assert unquote('bob') == 'bob'
    assert unquote('"bob') == '"bob'
    assert unquote('bob"') == 'bob"'

# Unit tests for function split_args

# Generated at 2022-06-23 02:51:49.512038
# Unit test for function is_quoted
def test_is_quoted():
    assert( is_quoted('abcd') == False )
    assert( is_quoted('"abcd"') == True )
    assert( is_quoted('\'abcd\'') == True )
    assert( is_quoted('"abcd') == False )
    assert( is_quoted('abcd\'') == False )


# Generated at 2022-06-23 02:51:53.735462
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote("'hello") == "'hello"



# Generated at 2022-06-23 02:52:01.558332
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"test_string"') == True)
    assert(is_quoted("'test_string'") == True)
    assert(is_quoted('"test_string') == False)
    assert(is_quoted("'test_string") == False)
    assert(is_quoted('test_string"') == False)
    assert(is_quoted("test_string'") == False)
    assert(is_quoted('"test_string\'') == False)
    assert(is_quoted('\'test_string"') == False)



# Generated at 2022-06-23 02:52:12.792012
# Unit test for function split_args
def test_split_args():
    # Functions to test
    test_function = split_args

    # Args to test

# Generated at 2022-06-23 02:52:20.361691
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote("'test'") == 'test'
    assert unquote('a"test') == 'a"test'
    assert unquote("a'test") == "a'test"
    assert unquote('addtest"') == 'addtest"'
    assert unquote('addtest"') == 'addtest"'
    assert unquote('"test') == '"test'
    assert unquote("'test") == "'test"



# Generated at 2022-06-23 02:52:27.747996
# Unit test for function unquote
def test_unquote():
    teststring = """\"test here\""""
    teststring2 = """\'test here\'"""

    if unquote(teststring) == "test here":
        pass
    else:
        raise Exception("unquote function not working for double quotes")

    if unquote(teststring2) == "test here":
        pass
    else:
        raise Exception("unquote function not working for single quotes")

# Generated at 2022-06-23 02:52:35.022588
# Unit test for function unquote
def test_unquote():
    assert unquote('"Test String"') == 'Test String'
    assert unquote('Test String') == 'Test String'
    assert unquote('"Test String') == '"Test String'
    assert unquote("'Test String'") == 'Test String'
    assert unquote("'Test String") == "'Test String"
    assert unquote("Test 'String'") == "Test 'String'"
    assert unquote("Test \"String\"") == "Test \"String\""
    assert unquote('"Test \"String\"') == 'Test \"String\"'
    assert unquote("'Test String\"") == "'Test String\""


# FIXME: this is a horrible name, given that it doesn't actually quote anything

# Generated at 2022-06-23 02:52:40.116552
# Unit test for function is_quoted
def test_is_quoted():
    import pytest
    assert is_quoted ('""') == True
    assert is_quoted ('"') == False
    assert is_quoted ('\'\'') == True
    assert is_quoted ('\'') == False
    assert is_quoted ('"test"') == True
    assert is_quoted ('\'test\'') == True
    assert is_quoted ('test') == False


# Generated at 2022-06-23 02:52:44.424343
# Unit test for function unquote
def test_unquote():
    assert '' == unquote('')
    assert '"' == unquote('"')
    assert "'" == unquote("'")
    assert 'foo' == unquote('foo')
    assert 'foo' == unquote('"foo"')
    assert 'foo' == unquote("'foo'")



# Generated at 2022-06-23 02:52:47.802805
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("hello world") is False
    assert is_quoted("'hello world'") is True
    assert is_quoted("\"hello world\"") is True
    assert is_quoted("\"") is False


# Generated at 2022-06-23 02:52:55.629983
# Unit test for function split_args
def test_split_args():
    assert split_args('foo=bar name="JoJo the idiotic circus boy"') == [
        'foo=bar',
        'name="JoJo the idiotic circus boy"',
    ]

    assert split_args('foo=bar name="JoJo the idiotic circus boy') == [
        'foo=bar',
        'name="JoJo the idiotic circus boy',
    ]

    assert split_args('foo=bar name="JoJo the idiotic circus boy" ') == [
        'foo=bar',
        'name="JoJo the idiotic circus boy"',
    ]

    assert split_args("foo=bar name=\"JoJo the idiotic circus boy'") == [
        'foo=bar',
        "name=\"JoJo the idiotic circus boy'",
    ]


# Generated at 2022-06-23 02:53:01.708942
# Unit test for function is_quoted
def test_is_quoted():
    if not is_quoted('"hello"'):
        raise AssertionError("test is_quoted 1 failed")
    if is_quoted('hello"'):
        raise AssertionError("test is_quoted 2 failed")
    if is_quoted('"hello'):
        raise AssertionError("test is_quoted 3 failed")
    if is_quoted('\'hello\''):
        raise AssertionError("test is_quoted 4 failed")


# Generated at 2022-06-23 02:53:13.806958
# Unit test for function is_quoted
def test_is_quoted():
    assert( is_quoted('""') )
    assert( is_quoted('"abcd"efg"') )
    assert( is_quoted("''") )
    assert( is_quoted("'abcd'efg'") )
    assert( is_quoted('"foo bar"') )
    assert( is_quoted('\'foo bar\'') )
    assert( is_quoted('"foo bar" baz') )
    assert( is_quoted('\'foo bar\' baz') )
    assert( not is_quoted('foo bar') )
    assert( not is_quoted('"foo bar') )
    assert( not is_quoted('foo bar"') )
    assert( not is_quoted('foo "bar" blah') )



# Generated at 2022-06-23 02:53:17.275755
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted("'bar'")
    assert not is_quoted('baz')

    assert is_quoted(r'"foo\"bar"')
    assert not is_quoted('"foo\\"bar"')



# Generated at 2022-06-23 02:53:28.305062
# Unit test for function split_args
def test_split_args():
    # test basic functionality
    params = split_args("a=3 b=foo c='foo bar' d=\"froz \"\"boz\"\"\"")
    assert params == ['a=3', 'b=foo', "c='foo bar'", 'd="froz \\""boz\\""'], params

    # test with line continuation character
    params = split_args("a=3 b=foo \\\nc='foo bar'")
    assert params == ['a=3', 'b=foo', "c='foo bar'"], params

    # test with line continuation character, joining quoted strings
    params = split_args("a=3 b=foo \\\n\"foo bar\"")
    assert params == ['a=3', 'b=foo', '"foo bar"'], params

    # test with line continuation character, joining jinja2 blocks

# Generated at 2022-06-23 02:53:38.748686
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('"hello"') is True
    assert is_quoted("'hello'") is True
    assert is_quoted('hello"') is False
    assert is_quoted("hello'") is False
    assert is_quoted('"hello') is False
    assert is_quoted("'hello") is False
    assert is_quoted("'hello' world") is False
    assert is_quoted("'hel''lo' world") is False
    assert is_quoted("'hel\"lo' world") is False
    assert is_quoted("\"hel'lo\" world") is False
    assert is_quoted("\"hel\"lo\" world") is False
    assert is_quoted("\"hello world") is False


# Generated at 2022-06-23 02:53:48.370302
# Unit test for function split_args
def test_split_args():
    '''
    This is a very simple test case at this point, just testing if it can
    split args, and if it handles quotes for strings split across tokens
    '''

    # testing simple split
    print(split_args("foo bar baz"))

    # testing quoting
    print(split_args('foo="bar baz" one two'))
    print(split_args("foo='bar baz' one two"))

    # testing jinja2 blocks
    print(split_args("foo='bar {{ baz }}' one two"))
    print(split_args("foo='bar {{ baz }}' one={{two}}"))
    print(split_args("#!./molecule/default/tests/test.py {% if blah == 'foo' %} --foo=bar {% endif %}"))

    # testing unbalanced args


# Generated at 2022-06-23 02:53:53.050084
# Unit test for function unquote
def test_unquote():
    assert unquote("'var'") == 'var'
    assert unquote('"var"') == 'var'
    assert unquote('"var') == '"var'
    assert unquote("'var") == "'var"
    assert unquote("var") == "var"

# Generated at 2022-06-23 02:53:57.906372
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('"foo\'bar"') == 'foo\'bar'

# Generated at 2022-06-23 02:54:01.700658
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"')    == "test"
    assert unquote('"te"st"')   == '"te"st"'
    assert unquote('"test')     == '"test'
    assert unquote('test"')     == 'test"'


# Generated at 2022-06-23 02:54:09.381724
# Unit test for function split_args
def test_split_args():
    assert split_args('foo="bar"') == ['foo=bar']
    assert split_args("foo='bar'") == ['foo=bar']
    assert split_args("foo=bar") == ['foo=bar']
    assert split_args('ansible_ssh_host="{{ ansible_host }}"') == ['ansible_ssh_host={{ ansible_host }}']
    assert split_args('foo=bar{{') == ['foo=bar{{']
    assert split_args('foo=bar{{ foo }}') == ['foo=bar{{ foo }}']
    assert split_args('foo=bar{%') == ['foo=bar{%']
    assert split_args('foo=bar{% foo %}') == ['foo=bar{% foo %}']

# Generated at 2022-06-23 02:54:11.953243
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello world"') == True
    assert is_quoted('') == False


# Generated at 2022-06-23 02:54:21.913126
# Unit test for function split_args
def test_split_args():

    # Simple test (should just return what was passed in)
    result = split_args("a=b c=d")
    assert result == ['a=b', 'c=d']

    # Quoted string test
    result = split_args("a=b c='foo bar'")
    assert result == ['a=b', 'c=\'foo bar\'']

    # Quoted string test with escaped quotes
    result = split_args("a=\"foo \\\"bar\\\" baz\"")
    assert result == ['a="foo \\\"bar\\\" baz"']
    result = split_args("a='foo \\\'bar\\\' baz'")
    assert result == ['a=\'foo \\\'bar\\\' baz\'']

    # Quoted string test with escaped quotes, and multiple spaces
    result = split_args

# Generated at 2022-06-23 02:54:27.829644
# Unit test for function unquote
def test_unquote():
    # this would fail if unquote does not strip the surrounding quotes
    assert unquote('"foo"') == "foo"
    # this would fail if unquote strips the quotes from a non-quoted string
    assert unquote('foo') == "foo"
    # this would fail if unquote strips the quotes from a string with quotes inside
    assert unquote('"foo"bar"') == '"foo"bar"'


# Generated at 2022-06-23 02:54:33.589421
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("\"") is False)
    assert(is_quoted("\"\"") is True)
    assert(is_quoted("\"\"\"") is False)
    assert(is_quoted("\"'\"") is False)
    assert(is_quoted("'") is False)
    assert(is_quoted("''") is True)
    assert(is_quoted("'''") is False)
    assert(is_quoted("'\"'") is False)
    assert(is_quoted("no_quotes") is False)


# Generated at 2022-06-23 02:54:46.080624
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('"this is a test" b=c') == ['this is a test', 'b=c']
    assert split_args('a=b c="foo bar"') == split_args('a=b\nc="foo bar"')
    assert split_args('a=b c="foo bar"') == split_args('a=b c=\\"foo bar\\"')
    assert split_args('a=b c="foo bar"') == split_args('a=b\nc=\\"foo bar\\"')
    assert split_args('a=b c="foo bar"') == split_args('a=b c="foo bar""')

# Generated at 2022-06-23 02:54:48.745904
# Unit test for function unquote
def test_unquote():
     assert unquote('"abc"') == 'abc'
     assert unquote("'abc'") == 'abc'
     assert unquote('abc') == 'abc'



# Generated at 2022-06-23 02:54:52.265798
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"this is a string"')
    assert is_quoted("'this is a string'")
    assert not is_quoted('this is a string')
    assert not is_quoted('"this is a string')
    assert not is_quoted("'this is a string")


# Generated at 2022-06-23 02:55:00.220438
# Unit test for function unquote
def test_unquote():
    assert unquote("") == ""
    assert unquote("foobar") == "foobar"
    assert unquote("'foobar'") == "foobar"
    assert unquote('"foobar"') == "foobar"
    assert unquote("'foo'bar'") == "'foo'bar'"
    assert unquote("foo'bar'") == "foo'bar'"
    assert unquote("'foo'bar") == "'foo'bar"



# Generated at 2022-06-23 02:55:11.990148
# Unit test for function is_quoted
def test_is_quoted():
    # is_quoted with strings
    assert is_quoted('"ab"') is True
    assert is_quoted('"ab') is False
    assert is_quoted('ab"') is False
    assert is_quoted('ab') is False
    assert is_quoted('"abcd"') is True
    assert is_quoted('') is False

    # is_quoted with lists
    assert is_quoted(['"ab"']) is True
    assert is_quoted(['"ab']) is False
    assert is_quoted(['ab"']) is False
    assert is_quoted(['ab']) is False
    assert is_quoted(['"abcd"']) is True
    assert is_quoted([]) is False
