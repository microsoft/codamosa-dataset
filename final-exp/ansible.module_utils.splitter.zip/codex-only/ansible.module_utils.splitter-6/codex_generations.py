

# Generated at 2022-06-23 02:45:10.070732
# Unit test for function is_quoted
def test_is_quoted():
    # Unquoted strings
    assert not is_quoted('')
    assert not is_quoted('This is a string')
    assert not is_quoted('  This is a string  ')
    assert not is_quoted('  "This is a string"  ')
    assert not is_quoted('  \'This is a string\'  ')
    assert not is_quoted('  \'This is a string"  ')
    assert not is_quoted('  "This is a string\'  ')
    # Quoted strings
    assert is_quoted('"This is a string"')
    assert is_quoted('\'This is a string\'')


# Generated at 2022-06-23 02:45:15.004023
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote("foo") == 'foo'
    assert unquote("'foo") == "'foo"
    assert unquote("\"foo") == "\"foo"

# Unit tests for function split_args

# Generated at 2022-06-23 02:45:25.420832
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import mock

    def _test_split_args(args, result):
        args = to_bytes(args)
        result = [to_bytes(x) for x in result]

        with mock.patch("ansible.utils.unicode.to_bytes") as mock_to_bytes:
            mock_to_bytes.return_value = args
            with mock.patch("ansible.utils.unicode.to_unicode") as mock_to_unicode:
                mock_to_unicode.return_value = args
                params = split_args(args)
                assert params == result, "failed to parse %s, got %s instead of %s" % (args, params, result)

    # basic

# Generated at 2022-06-23 02:45:30.533146
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted('""') == True
    assert is_quoted("''") == True
    assert is_quoted('"') == False
    assert is_quoted("'") == False
    assert is_quoted('test') == False

if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-23 02:45:40.667116
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"') == False)
    assert(is_quoted('""') == True)
    assert(is_quoted('"foo"') == True)
    assert(is_quoted('"foo') == False)
    assert(is_quoted('foo"') == False)
    assert(is_quoted("'") == False)
    assert(is_quoted("''") == True)
    assert(is_quoted("'foo'") == True)
    assert(is_quoted("'foo") == False)
    assert(is_quoted("foo'") == False)



# Generated at 2022-06-23 02:45:46.907078
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('"a\\"bc"') == 'a"bc'
    assert unquote('"a\\\"bc"') == 'a\\"bc'
    assert unquote('"a\\\\\\"bc"') == 'a\\\\"bc'
    assert unquote('"a\\\\\\"bc"x') == 'a\\\\\\"bc"x'
    assert unquote('abc') == 'abc'


# Generated at 2022-06-23 02:45:50.256214
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted("'test'") == True
    assert is_quoted("'test") == False
    assert is_quoted('test"') == False
    assert is_quoted('test') == False


# Generated at 2022-06-23 02:45:55.449634
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == "hello"
    assert unquote("'hello'") == "hello"
    assert unquote("hello") == "hello"
    assert unquote("he'llo") == "he'llo"
    assert unquote("'he'llo'") == "he'llo"
    assert unquote('"he"llo"') == 'he"llo'
    assert unquote('"he"llo\'"') == 'he"llo\''


# Generated at 2022-06-23 02:46:07.024144
# Unit test for function split_args
def test_split_args():

    # test to make sure parameter expansion works as expected
    assert split_args('a={{ foo }} c={{ bar }}') == ['a={{ foo }}', 'c={{ bar }}']
    assert split_args('a={{ foo }} c={{ bar }}') == ['a={{ foo }}', 'c={{ bar }}']
    assert split_args('a={{ foo }}\nc={{ bar }}') == ['a={{ foo }}', 'c={{ bar }}']

    # no space after escaped newline
    assert split_args('a=b\\\nc=d') == ['a=b', 'c=d']

    # space after escaped newline
    assert split_args('a=b\\\n c=d') == ['a=b', 'c=d']

    # no space after escaped newline, inside quotes
    assert split

# Generated at 2022-06-23 02:46:12.720164
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"Hello"')
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"f"o"o"')
    assert is_quoted('"f o"o"') == False
    assert is_quoted('') == False
    assert is_quoted('""')
    assert is_quoted('" \'"')
    assert is_quoted('"') == False


# Generated at 2022-06-23 02:46:24.841141
# Unit test for function split_args
def test_split_args():
    assert split_args('{ foo }') == ['{', 'foo', '}']
    assert split_args('foo {{ bar }}') == ['foo', '{{', 'bar', '}}']
    assert split_args('foo {% bar %}') == ['foo', '{%', 'bar', '%}']
    assert split_args('foo {{ bar }} {% baz %}') == ['foo', '{{', 'bar', '}}', '{%', 'baz', '%}']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo {{ bar {% baz %} {{') == ['foo', '{{', 'bar', '{%', 'baz', '%}', '{{']

# Generated at 2022-06-23 02:46:27.865890
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == "abc"
    assert unquote("'abc'") == "abc"
    assert unquote("abc") == "abc"


# Generated at 2022-06-23 02:46:37.865886
# Unit test for function split_args

# Generated at 2022-06-23 02:46:40.627218
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("foo") == False
    assert is_quoted(" foo ") == False
    assert is_quoted("'foo'") == True
    assert is_quoted("\"foo\"") == True



# Generated at 2022-06-23 02:46:44.747559
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'") == True
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello") == False
    assert is_quoted("hello'") == False


# Generated at 2022-06-23 02:46:54.640738
# Unit test for function split_args
def test_split_args():
    if split_args("  a=\"foo\"  'bar'  ") != ['a="foo"', "'bar'"]:
        raise Exception("failed 1")

    if split_args("  a=\"foo  bar\"  'baz'  ") != ['a="foo  bar"', "'baz'"]:
        raise Exception("failed 2")

    if split_args("a=\"foo  bar\"'baz'") != ['a="foo  bar"', "'baz'"]:
        raise Exception("failed 3")

    if split_args("a={{ bar }}'baz'") != ['a={{ bar }}', "'baz'"]:
        raise Exception("failed 4")

    if split_args("a={{ bar }}  'baz'") != ['a={{ bar }}', "'baz'"]:
        raise Exception("failed 5")



# Generated at 2022-06-23 02:47:03.920091
# Unit test for function unquote
def test_unquote():
    assert unquote('a"b"c') == 'a"b"c'
    assert unquote('"abc"') == 'abc'
    assert unquote('""') == ''

if __name__ == '__main__':

    import doctest
    doctest.testmod()

    from ansible.module_utils.splitter import split_args
    print("Starting Splitter Test")

# Generated at 2022-06-23 02:47:09.353639
# Unit test for function unquote
def test_unquote():
    assert unquote('"hi there"') == 'hi there'
    assert unquote('hi there') == 'hi there'
    assert unquote('') == ''

# Generated at 2022-06-23 02:47:20.484625
# Unit test for function split_args
def test_split_args():
    all_tests_passed = True

    # Simple no quotes, no jinja2 tests
    test_cases = [
        'a=b c="foo bar"',
        'a=b c="foo bar" d=xyzzy',
        'a=b c="foo bar" d="xyzzy"',
        'a=b c="foo bar" d="xyzzy" e=f',
    ]
    for good_args in test_cases:
        params = split_args(good_args)
        if len(params) != 3:
            all_tests_passed = False
            print("1. test failed, expected 3 params, got %d (%s)" % (len(params), params))
        else:
            if params[0] not in ['a=b', 'a=b\nc=']:
                all_tests_

# Generated at 2022-06-23 02:47:23.700986
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote('""') == ''
    assert unquote('"') == ''
    assert unquote('abc') == 'abc'


# Generated at 2022-06-23 02:47:34.179444
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test') == 'test'
    assert unquote('test') == 'test'
    assert unquote('test"') == 'test'
    assert unquote('"test""') == 'test"'
    assert unquote('"test""test2"') == 'test"test2'
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('"') == ''
    assert unquote('" """ "" "" "') == ' """ "" "" '

# Generated at 2022-06-23 02:47:45.898924
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"
    assert unquote('foo"') == 'foo"'
    assert unquote('foo\'"') == 'foo\'"'
    assert unquote('"foo\'"') == 'foo\'"'
    assert unquote('foo"\'') == 'foo"\''
    assert unquote('"foo"\'') == 'foo"\''
    assert unquote('\'foo"\'') == 'foo"\''
    assert unquote('""foo""') == 'foo'
    assert unquote('"""foo"""') == '"foo"'
    assert unquote

# Generated at 2022-06-23 02:47:58.439040
# Unit test for function split_args
def test_split_args():
    result = split_args('a=b c="foo bar"')
    assert result == ['a=b', 'c="foo bar"']

    result = split_args('a=b "c=foo bar"')
    assert result == ['a=b', '"c=foo bar"']

    result = split_args('a=b "c=foo bar')
    assert result == ['a=b', '"c=foo bar']

    result = split_args('a=b c=\\"foo bar\\"')
    assert result == ['a=b', 'c=\\"foo bar\\"']

    result = split_args('a=b c="foo bar\\"')
    assert result == ['a=b', 'c="foo bar\\"']

    result = split_args('a=b c=\\"foo bar')
   

# Generated at 2022-06-23 02:48:03.075234
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("foo") == False
    assert is_quoted("'foo'") == True
    assert is_quoted('"foo"') == True
    assert is_quoted("") == False


# Generated at 2022-06-23 02:48:08.989738
# Unit test for function is_quoted
def test_is_quoted():
    ''' test is_quoted function with strings that should return true '''
    assert is_quoted('foo') == False
    assert is_quoted('') == False
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('""') == True
    assert is_quoted("''") == True


# Generated at 2022-06-23 02:48:13.276999
# Unit test for function unquote
def test_unquote():
    assert unquote('x') == 'x'
    assert unquote('"x"') == 'x'
    assert unquote("'x'") == 'x'
    assert unquote('"x') == '"x'
    assert unquote("'x") == "'x"


# Generated at 2022-06-23 02:48:19.496590
# Unit test for function unquote
def test_unquote():
    testcases = {
        'foo': 'foo',
        '"foo"': 'foo',
        "'foo'": 'foo',
        '"foo": "bar"': '"foo": "bar"',
        '"foo" "bar"': '"foo" "bar"',
    }
    for data, expected in testcases.items():
        assert unquote(data) == expected


# -- module-level support methods --


# Generated at 2022-06-23 02:48:34.957090
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']
    assert split_args('a=b c="foo \'bar\'"') == ['a=b', 'c="foo \'bar\'"']
    assert split_args('a=b c="foo \\"bar\\""') == ['a=b', 'c="foo \\"bar\\""']
    assert split

# Generated at 2022-06-23 02:48:44.574766
# Unit test for function split_args
def test_split_args():

    test_cases = dict()

    test_cases['args_1'] = dict(
        args='echo hello',
        result=['echo', 'hello'],
    )

    test_cases['args_2'] = dict(
        args='{{ echo hello }',
        result=['{{ echo hello }'],
    )

    test_cases['args_3'] = dict(
        args='{{ echo "hello world" }',
        result=['{{ echo "hello world" }'],
    )

    test_cases['args_4'] = dict(
        args='{{ echo "hello world" }}}',
        result=['{{ echo "hello world" }}}'],
    )


# Generated at 2022-06-23 02:48:54.004997
# Unit test for function is_quoted
def test_is_quoted():
    tests = [
        ('"test"', True),
        ("'test'", True),
        ("'test", False),
        ("test'", False),
        ('"test', False),
        ("test", False),
        (" ", False),
        ("'\"", False),
        ("\"'", False),
        ("''", False),
    ]

    failed = 0
    for data, result in tests:
        if is_quoted(data) != result:
            failed += 1
            print("Failed: %s, expected %s" % (data, result))

    if failed > 0:
        raise Exception("%d is_quoted tests failed" % failed)


# Generated at 2022-06-23 02:49:03.688219
# Unit test for function split_args

# Generated at 2022-06-23 02:49:12.258710
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('""') == True
    assert is_quoted('"a string"') == True
    assert is_quoted('a string') == False
    assert is_quoted('""a string""') == False
    assert is_quoted('"a string""') == False
    assert is_quoted('""a string"') == False
    assert is_quoted("''") == True
    assert is_quoted("'a string'") == True
    assert is_quoted("a string") == False
    assert is_quoted("''a string''") == False
    assert is_quoted("'a string''") == False
    assert is_quoted("''a string'") == False


# Generated at 2022-06-23 02:49:23.956821
# Unit test for function split_args
def test_split_args():
    from . import unittest
    class TestSplitArgs(unittest.TestCase):
        def _test(self, args, expected):
            self.assertEqual([unquote(item) for item in split_args(args)], expected)

        # Tests for different types of arguments
        def test_simple_args(self):
            self._test('a=1 b=2 c=3', ['a=1', 'b=2', 'c=3'])

        def test_simple_args_with_space(self):
            self._test(' a = 1  b = 2  c = 3 ', ['a=1', 'b=2', 'c=3'])


# Generated at 2022-06-23 02:49:32.089263
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    def _run_test(args, expected):
        args = to_bytes(args)
        result = split_args(args)
        for idx, item in enumerate(expected):
            expected[idx] = to_bytes(item)
        if result != expected:
            basic._ANSIBLE_ARGS = None
            raise AssertionError("split_args() failed: args=%s expected=%s got=%s" % (args, expected, result))

    _run_test('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _run_test('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _run_test

# Generated at 2022-06-23 02:49:35.074981
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted("'test")



# Generated at 2022-06-23 02:49:47.846720
# Unit test for function split_args
def test_split_args():
    # first test single-line args
    # test without quotes
    args = 'foo bar biz boz'
    params = split_args(args)
    assert len(params) == 4
    assert params[0] == 'foo'
    assert params[1] == 'bar'
    assert params[2] == 'biz'
    assert params[3] == 'boz'
    # test with quotes
    args = 'foo "bar biz" boz'
    params = split_args(args)
    assert len(params) == 3
    assert params[0] == 'foo'
    assert params[1] == 'bar biz'
    assert params[2] == 'boz'
    args = 'foo \'bar biz\' boz'
    params = split_args(args)
    assert len(params) == 3


# Generated at 2022-06-23 02:49:57.464998
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote("'b'") == 'b'
    assert unquote('') == ''
    assert unquote('abc') == 'abc'
    assert unquote('"double quoted"') == 'double quoted'
    assert unquote("'single quoted'") == 'single quoted'
    assert unquote('""') == ''
    assert unquote("''") == ''
    assert unquote('"\'"') == "'"
    assert unquote("'\"'") == '"'
    assert unquote('"\\"') == '\\'
    assert unquote('\\"') == '\\"'
    assert unquote('"\\"') == '\\'
    assert unquote('"\\"a"') == '\\"a'

# Generated at 2022-06-23 02:50:08.746550
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=\"foo bar\""]
    assert split_args("a=\"foo bar\" c=b") == ["a=\"foo bar\"", "c=b"]
    assert split_args("a=\"foo bar\" c=\"hello world\"") == ["a=\"foo bar\"", "c=\"hello world\""]
    assert split_args("a=\"{{foo}}={{bar}}\" c=\"hello world\"") == ["a=\"{{foo}}={{bar}}\"", "c=\"hello world\""]
    assert split_args("a={{foo}} c=\"hello world\"") == ["a={{foo}}", "c=\"hello world\""]

# Generated at 2022-06-23 02:50:16.785891
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'")
    assert is_quoted("'foo'")
    assert is_quoted('"foo"')

    assert not is_quoted("foo")
    assert not is_quoted("'foo")
    assert not is_quoted("foo'")
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')
    assert not is_quoted("'foo\"bar'")
    assert not is_quoted('"foo\'bar"')


# Generated at 2022-06-23 02:50:22.329426
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"quote me"')
    assert is_quoted("'quote me too'")
    assert not is_quoted('"quote me')
    assert not is_quoted("'quote me too")
    assert not is_quoted('quote me"')
    assert not is_quoted("quote me too'")
    assert not is_quoted('"quote " me"')
    assert not is_quoted("'quote ' me too'")


# Generated at 2022-06-23 02:50:34.856810
# Unit test for function unquote
def test_unquote():
    def test_data(expected, data):
        assert expected == unquote(data), "%s != %s"%(expected, unquote(data) )

    test_data("", '""')
    test_data("", "''")
    test_data("foo", '"foo"')
    test_data("foo", "'foo'")
    test_data('"foo"', '"foo"')
    test_data("'foo'", "'foo'")
    test_data('"foo"', "'\"foo\"'")
    test_data("'foo'", '"\'foo\'"')
    test_data('"""foo"""', '"""foo"""')
    test_data("'''foo'''", "'''foo'''")
    test_data('"""foo"""', "'''\"foo\"'''")
    test

# Generated at 2022-06-23 02:50:37.782626
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'

# Generated at 2022-06-23 02:50:40.673663
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("'a'bc'") == "'a'bc'"
    assert unquote('abc') == 'abc'

# Generated at 2022-06-23 02:50:43.746548
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'hello'")
    assert is_quoted('"hello"')
    assert is_quoted('"hello') == False
    assert is_quoted("'hello") == False



# Generated at 2022-06-23 02:50:49.275021
# Unit test for function unquote
def test_unquote():
    assert unquote('abcd') == 'abcd'
    assert unquote('"abcd"') == 'abcd'
    assert unquote("'abcd'") == 'abcd'
    assert unquote('"ab cd"') == 'ab cd'


# Generated at 2022-06-23 02:51:01.896538
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b "c=d"') == ['a=b', '"c=d"']
    assert split_args('a=b "c=d') == ['a=b', '"c=d']
    assert split_args('a=b c=d\\') == ['a=b', 'c=d\\']
    assert split_args('a=b c=d\\\ne=f') == ['a=b', 'c=d\\', 'e=f']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-23 02:51:03.755777
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'


# Generated at 2022-06-23 02:51:11.080357
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('"foobar"') == 'foobar'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('\'foobar\'') == 'foobar'
    assert unquote('\'foo bar\'') == 'foo bar'
    assert unquote('\"foobar\"') == '\\"foobar\\"'
    assert unquote('\'foobar\'') == 'foobar'
    assert unquote('"foo bar') == 'foo bar'
    assert unquote('foo bar"') == 'foo bar'



# Generated at 2022-06-23 02:51:23.898973
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d=\"{{foo}}\"") == ['a=b', 'c="foo bar"', 'd="{{foo}}"']
    assert split_args("a=b c=\"foo bar\" d=\"{{foo}}\" 'e'") == ['a=b', 'c="foo bar"', 'd="{{foo}}"', "'e'"]
    assert split_args("a=b c=\"foo\n bar\" d=\"{{foo}}\" 'e' f='g' h=\"i\"") == ['a=b', 'c="foo\n bar"', 'd="{{foo}}"', "'e'", "f='g'", 'h="i"']
    assert split

# Generated at 2022-06-23 02:51:28.508621
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote('abc') == 'abc'



# Generated at 2022-06-23 02:51:37.376546
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"testing a quoted string"'))
    assert(is_quoted("'testing another quoted string'"))
    assert(not is_quoted('"testing an unquoted string'))
    assert(not is_quoted("'testing another unquoted string"))
    assert(not is_quoted("testing an unquoted string\""))
    assert(not is_quoted("testing another unquoted string'"))
    assert(not is_quoted("testing an unquoted string"))


# Generated at 2022-06-23 02:51:48.021000
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('example') == False
    assert is_quoted('"example"') == True
    assert is_quoted('\'example\'') == True
    assert is_quoted('"example') == False
    assert is_quoted('example"') == False
    assert is_quoted('""example""') == True
    assert is_quoted('\'\'example\'\'') == True
    assert is_quoted('\'\'example') == False
    assert is_quoted('example\'\'') == False
    assert is_quoted('"example\'') == False
    assert is_quoted('"example\'') == False


# Generated at 2022-06-23 02:51:59.975253
# Unit test for function split_args
def test_split_args():
    # basic
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b\nc=d") == ['a=b\n', 'c=d']
    assert split_args("a=b\\\nc=d") == ['a=b\\\n', 'c=d']

    # quotes
    assert split_args('foo="bar baz"') == ['foo="bar baz"']
    assert split_args('foo="bar \\"baz\\""') == ['foo="bar \\"baz\\""']

    # jinja2
    assert split_args('foo="{{ bar }}"') == ['foo="{{ bar }}"']
    assert split_args('foo="{% bar %}"') == ['foo="{% bar %}"']
   

# Generated at 2022-06-23 02:52:03.863510
# Unit test for function unquote
def test_unquote():
    assert(unquote("\"test\"") == "test")
    assert(unquote("\"\"test\"\"") == "\"test\"")
    assert(unquote("\"test\"\"") == "\"test\"\"")
    assert(unquote("test") == "test")
    assert(unquote("") == "")


# Generated at 2022-06-23 02:52:08.601837
# Unit test for function split_args
def test_split_args():
    ''' unit test for split_args function '''
    from ansible.playbook.play_context import PlayContext
    assert split_args(PlayContext().CLIARGS['args']) == PlayContext().CLIARGS['args'].split()



# Generated at 2022-06-23 02:52:11.368861
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'one'")
    assert is_quoted("\"two\"")
    assert not is_quoted("one,two")


# Generated at 2022-06-23 02:52:16.549974
# Unit test for function unquote
def test_unquote():
    "unquote"
    assert unquote('foobar') == 'foobar'
    assert unquote('"foobar"') == 'foobar'
    assert unquote("'foobar'") == 'foobar'
    assert unquote('"foo\'bar"') == "foo\'bar"
    assert unquote("'foo\"bar'") == 'foo"bar'
    assert unquote('foo"bar') == "foo\"bar"
    assert unquote("foo'bar") == "foo'bar"



# Generated at 2022-06-23 02:52:19.921970
# Unit test for function unquote
def test_unquote():
    if unquote('"blablabla"') != 'blablabla':
        raise Exception("unquote test failed")

test_unquote()

# backwards compat for some modules
_split_args = split_args

# Generated at 2022-06-23 02:52:25.318283
# Unit test for function is_quoted
def test_is_quoted():
    quoted_data = '"this is a quoted string"'
    assert is_quoted(quoted_data) is True
    assert unquote(quoted_data) == 'this is a quoted string'



# Generated at 2022-06-23 02:52:30.197535
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foo') is False
    assert is_quoted('') is False
    assert is_quoted('"foo"') is True
    assert is_quoted('\'foo\'') is True
    assert is_quoted('"foo\'') is False
    assert is_quoted('\'foo"') is False



# Generated at 2022-06-23 02:52:37.889745
# Unit test for function unquote
def test_unquote():
    input_pass_list = ['aaa', '"aaa"', "'aaa'"]
    input_fail_list = ['"aa', 'aa"', "'aa", "aa'", 'a"a', 'a\'a']
    result = True
    for x in input_pass_list:
        if unquote(x) != 'aaa':
            print ('---%s---' % x)
            result = False
    for x in input_fail_list:
        if unquote(x) != x:
            print ('---%s---' % x)
            result = False
    if result:
        print ('UNIT TEST PASSED')
    else:
        print ('UNIT TEST FAILED')

#test_unquote()



# Generated at 2022-06-23 02:52:47.846996
# Unit test for function split_args
def test_split_args():
    import sys
    import json
    from distutils.version import LooseVersion
    from nose.plugins.skip import SkipTest

    if LooseVersion(sys.version_info[0]) == 2:
        raise SkipTest()

    #
    # Test the trivial case
    #
    arg_string = 'a=b c="foo bar"'
    expected_output = ['a=b', 'c="foo bar"']
    test_output = split_args(arg_string)
    assert test_output == expected_output, 'split_args failed to parse trivial case: %s != %s' % (json.dumps(test_output), json.dumps(expected_output))

    #
    # Test the case of a quoted string at the end
    #
    arg_string = 'a=b c="foo bar"'
    expected_output

# Generated at 2022-06-23 02:52:50.832510
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"') == 'foo'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote("'foo") == "'foo"



# Generated at 2022-06-23 02:53:02.696329
# Unit test for function split_args
def test_split_args():
    # Single argument
    assert split_args('a=b') == ['a=b']

    # Two arguments
    assert split_args('a=b c=d') == ['a=b', 'c=d']

    # Two arguments with inline newline
    assert split_args('a=b \nc=d') == ['a=b', 'c=d']
    assert split_args('a=b\\\nc=d') == ['a=b\nc=d']

    # One argument with embedded newline
    assert split_args('a=b\nc=d') == ['a=b\nc=d']

    # One argument with double quote
    assert split_args('a="b c"') == ['a="b c"']

    # One argument with single quote

# Generated at 2022-06-23 02:53:12.712646
# Unit test for function is_quoted
def test_is_quoted():
    data = '""'
    assert(is_quoted(data))
    data = '"abc"'
    assert(is_quoted(data))
    data = "''"
    assert(is_quoted(data))
    data = "'abc'"
    assert(is_quoted(data))
    data = '"abc'
    assert(not is_quoted(data))
    data = 'abc"'
    assert(not is_quoted(data))
    data = "''abc'"
    assert(not is_quoted(data))


# Generated at 2022-06-23 02:53:16.059222
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"')
    assert is_quoted("'hello'")
    assert is_quoted("hello") is False
    assert is_quoted("'hello") is False



# Generated at 2022-06-23 02:53:28.042107
# Unit test for function unquote
def test_unquote():
    '''
    Sometimes we need to use some kind of quoting in the inventory,
    so it's better to provide some unquoting-unittest
    '''
    data_list = [
        '"string"',
        "'string'",
        '"string',
        'string"',
        '"string"some string"',
        '"some string"string"',
        '"string""string"',
        '"stri""ng"',
        'string',
        'string string',
        '"string string"',
        'string###',
        'string&amp;&amp;',
        'string&amp;&amp;&amp;&amp;',
        '"string string"###'
    ]

    for data in data_list:
        result = unquote(data)

        # if data starts and ends

# Generated at 2022-06-23 02:53:32.893045
# Unit test for function unquote
def test_unquote():
    if unquote('"abc"') != 'abc':
        raise AssertionError
    if unquote("'abc'") != 'abc':
        raise AssertionError
    if unquote('abc') != 'abc':
        raise AssertionError
    if unquote('def') != 'def':
        raise AssertionError


# Generated at 2022-06-23 02:53:42.774557
# Unit test for function split_args
def test_split_args():
    '''
    Tests for split_args function
    '''

    # Test for conditions:
    #
    # 1. No spaces
    # 2. With space, no quotes
    # 3. With space, with quotes
    # 4. With space, with jinja2 print
    # 5. With space, with jinja2 block
    # 6. With space, with jinja2 comment
    # 7. With space, with jinja2 print and quotes
    # 8. With space, with jinja2 block and quotes
    # 9. With space, with jinja2 comment and quotes
    # 10. With space, with jinja2 print and block
    # 11. With space, with jinja2 print and comment
    # 12. With space, with jinja2 block and comment
    # 13. With space, with

# Generated at 2022-06-23 02:53:47.786891
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('"foo"') == True)
    assert(is_quoted("'foo'") == True)
    assert(is_quoted('"foo') == False)
    assert(is_quoted("'foo") == False)
    assert(is_quoted('foo"') == False)
    assert(is_quoted("foo'") == False)
    assert(is_quoted('"') == False)
    assert(is_quoted("'") == False)
    assert(is_quoted('') == False)


# Generated at 2022-06-23 02:53:59.484634
# Unit test for function split_args

# Generated at 2022-06-23 02:54:12.726275
# Unit test for function split_args

# Generated at 2022-06-23 02:54:22.506932
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b") == ['a=b']
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo \\\"bar\\\" quz\"") == ['a=b', 'c="foo \\"bar\\" quz"']
    assert split_args("a=b c=\"{{ foo }} {{\\\"bar\\\"}}\"") == ['a=b', 'c="{{ foo }} {{\\\"bar\\\"}}"']

# Generated at 2022-06-23 02:54:24.535177
# Unit test for function unquote
def test_unquote():
    assert unquote("'foo'") == "foo"
    assert unquote("\"foo\"") == "foo"



# Generated at 2022-06-23 02:54:26.799450
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")


# Generated at 2022-06-23 02:54:30.170307
# Unit test for function is_quoted
def test_is_quoted():
    assert(not is_quoted(''))
    assert(is_quoted('foo'))
    assert(not is_quoted('"foo" bar'))
    assert(is_quoted('"foo"'))


# Generated at 2022-06-23 02:54:32.568206
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('') is False)
    assert(is_quoted('"test"') is True)
    assert(is_quoted('test') is False)


# Generated at 2022-06-23 02:54:41.313575
# Unit test for function unquote
def test_unquote():
    assert unquote('abc') == 'abc'
    assert unquote('"abc"') == 'abc'
    assert unquote('\'abc\'') == 'abc'
    assert unquote('"a\'bc"') == "a'bc"
    assert unquote('\'a"bc\'') == 'a"bc'
    assert unquote('\'a"b"c\'') == 'a"b"c'
    assert unquote('\'a"""b"""c\'') == 'a"""b"""c'



# Generated at 2022-06-23 02:54:45.361607
# Unit test for function unquote
def test_unquote():
    assert unquote('a') == 'a'
    assert unquote('"a"') == 'a'
    assert unquote('"a""b"') == 'a"b'
    assert unquote('b"c') == 'b"c'


# Generated at 2022-06-23 02:54:51.136182
# Unit test for function unquote
def test_unquote():
    ''' unquote should remove quotes from a string '''
    if unquote('"testing"') != "testing":
        raise Exception('unquote failed to remove quotes properly')
    if unquote("'testing'") != "testing":
        raise Exception('unquote failed to remove quotes properly')
    if unquote("testing") == "testing":
        raise Exception('unquote removed quotes from a string that had none')


# Generated at 2022-06-23 02:54:59.348314
# Unit test for function split_args
def test_split_args():
    def _test_split_args(args, expected_params):
        params = split_args(args)
        if params != expected_params:
            print("ERROR: split_args(%s) returned: %s" % (args, params))
            print("Expected: %s" % expected_params)
            raise ValueError("Test Failed: split_args() failed, please check")


# Generated at 2022-06-23 02:55:07.945013
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'abc'") == 'abc'
    assert unquote("abc") == 'abc'
    assert unquote("'a\"") == "'a\""
    assert unquote("\"a'") == "\"a'"
    assert unquote("'a\"b'") == "'a\"b'"
    assert unquote("\"a'b\"") == "\"a'b\""
