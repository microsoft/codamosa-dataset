

# Generated at 2022-06-23 02:45:05.919837
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"') == True
    assert is_quoted('"test') == False
    assert is_quoted('test"') == False
    assert is_quoted('test') == False
    assert is_quoted('') == False
    assert is_quoted('""') == True



# Generated at 2022-06-23 02:45:19.185886
# Unit test for function split_args
def test_split_args():
    def split_and_rejoin(line):
        # We join with spaces to make it easy to compare to single-spaced input
        return ' '.join(split_args(line))

    # Simple parameter
    assert split_and_rejoin('foo') == 'foo'

    # Simple key=value
    assert split_and_rejoin('key=value') == 'key=value'

    # Simple key and value with quotes
    assert split_and_rejoin('key="value"') == 'key="value"'

    # Simple key and value with quotes and spaces
    assert split_and_rejoin('key="value with spaces"') == 'key="value with spaces"'

    # Simple key and value with spaces and quotes
    assert split_and_rejoin('key = "value with spaces"') == 'key = "value with spaces"'

    # Simple

# Generated at 2022-06-23 02:45:23.201003
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert not is_quoted('test')
    assert is_quoted("'test'")
    assert not is_quoted("'test")
    assert not is_quoted('"test')


# Generated at 2022-06-23 02:45:26.756367
# Unit test for function unquote
def test_unquote():
    import sys
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote('hello') == 'hello'
    assert unquote('') == ''
    print('Success - unquote')


# Generated at 2022-06-23 02:45:33.775883
# Unit test for function is_quoted
def test_is_quoted():
    if not is_quoted('"hello"'):
        raise Exception("should have been quoted")
    if is_quoted("'hello'"):
        raise Exception("should not have been quoted")
    if is_quoted("hello'"):
        raise Exception("should not have been quoted")
    if is_quoted("'hello"):
        raise Exception("should not have been quoted")
    if is_quoted("'hello\""):
        raise Exception("should not have been quoted")
    if is_quoted("\"hello'"):
        raise Exception("should not have been quoted")
    if is_quoted("\"hello"):
        raise Exception("should not have been quoted")
    if is_quoted("hello"):
        raise Exception("should not have been quoted")

test_is_quoted()


# Generated at 2022-06-23 02:45:40.874540
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'abc'") and is_quoted('"abc"') and is_quoted("'12 345'")
    assert not is_quoted("'abc") and not is_quoted('"abc') and not is_quoted("12 345'")
    assert is_quoted("'\\''") and is_quoted("\"\\\"\"")
    assert not is_quoted("\"\\\"") and not is_quoted("'\\'")


# Generated at 2022-06-23 02:45:42.699263
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote('"b"') == 'b'
    return True


# Generated at 2022-06-23 02:45:51.970923
# Unit test for function split_args
def test_split_args():

    def assert_split_args(args, expected):
        actual = split_args(args)
        assert expected == actual, "args='%s'\nexpected='%s'\nactual='%s'" % (args, expected, actual)

    assert_split_args(' ', [])
    assert_split_args('foo', ['foo'])
    assert_split_args('foo bar baz', ['foo', 'bar', 'baz'])

    assert_split_args('"', ['"'])
    assert_split_args('"foo', ['"foo'])
    assert_split_args('"foo bar', ['"foo bar'])
    assert_split_args('"foo bar"', ['"foo bar"'])
    assert_split_args('"foo bar" baz', ['"foo bar"', 'baz'])


# Generated at 2022-06-23 02:46:02.826218
# Unit test for function split_args

# Generated at 2022-06-23 02:46:06.764612
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"quoted\"")
    assert is_quoted("'quoted'")
    assert not is_quoted("'single quote")
    assert not is_quoted("'")
    assert not is_quoted("unquoted")


# Generated at 2022-06-23 02:46:14.965227
# Unit test for function split_args

# Generated at 2022-06-23 02:46:20.461696
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\" d='foo bar' e={{x}}") == ["a=b", "c=\"foo bar\"", "d='foo bar'", "e={{x}}"]
    assert split_args("a=\"{{'a'}}\"") == ["a=\"{{'a'}}\""]


# Generated at 2022-06-23 02:46:29.739987
# Unit test for function unquote
def test_unquote():
    assert unquote("test")                           == "test"
    assert unquote('"test"')                         == "test"
    assert unquote("'test'")                         == "test"
    assert unquote('"te""st"')                       == 'te""st'
    assert unquote("'te''st'")                       == "te''st"
    assert unquote('"te\'st"')                       == "te'st"
    assert unquote("'te\"st'")                       == 'te"st'
    assert unquote('"te\'"st"')                      == "te'\"st"
    assert unquote("'te\'"'"'"'st'")                 == "te'''st"

# Generated at 2022-06-23 02:46:38.998224
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True
    assert is_quoted('') == False
    assert is_quoted('abcd') == False
    assert is_quoted(None) == False
    assert is_quoted('"hello') == False
    assert is_quoted('hello"') == False
    assert is_quoted('"hello\'') == False
    assert is_quoted('''   'hello'  ''') == True
    assert is_quoted('''   "hello"  ''') == True
    assert is_quoted('''   hello  ''') == False
    assert is_quoted('''   "hello  ''') == False


# Generated at 2022-06-23 02:46:43.413522
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello"') == True
    assert is_quoted("'hello'") == True

    assert is_quoted('') == False
    assert is_quoted('"hello') == False
    assert is_quoted("'hello") == False

    assert is_quoted('hello"') == False
    assert is_quoted('hello\'"') == False

    assert is_quoted('"hello\'"') == True



# Generated at 2022-06-23 02:46:50.186524
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'test'")
    assert is_quoted("\"test\"")
    assert not is_quoted("test")
    assert not is_quoted("'test")
    assert not is_quoted("test'")
    assert not is_quoted("''test'")
    assert not is_quoted("test''")


# Generated at 2022-06-23 02:46:54.176966
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('""')
    assert is_quoted('"some_string"')
    assert is_quoted('\'some_string\'')
    assert is_quoted('some_string') is False


# Generated at 2022-06-23 02:47:01.228119
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('"hello"world')
    assert not is_quoted('"hello\'"world')
    assert not is_quoted('hello world')
    assert not is_quoted('\'"hello\'')
    assert not is_quoted('\'\'')
    assert is_quoted('"hello world"')
    assert is_quoted('"hello\'"')
    assert is_quoted('\'"hello"')
    assert is_quoted('\'\'\'')


# Generated at 2022-06-23 02:47:06.027961
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('asdf') == False
    assert is_quoted('"asdf"') == True
    assert is_quoted('\'asdf\'') == True


# Generated at 2022-06-23 02:47:11.254428
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"hello world"')
    assert is_quoted("hello world") == False
    assert is_quoted("'hello world'")
    assert is_quoted("hello 'world'") == False
    assert is_quoted("'hello' world") == False


# Generated at 2022-06-23 02:47:22.626289
# Unit test for function split_args
def test_split_args():

    class MyVarsModule(object):

        def get_vars(self, loader, path, entities, cache=True):
            return {'bar': 'foo'}

    import sys
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    dl.set_vault_password('password')
    dl.set_vault_identity('0')
    dl.set_collection_list(['collections'])

    # A few cases to test:

# Generated at 2022-06-23 02:47:34.336266
# Unit test for function split_args
def test_split_args():
    # Basic '=' tests
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b c=d e=f") == ["a=b", "c=d", "e=f"]

    # Basic '=' tests with quotes
    assert split_args("a='b c'") == ["a='b c'"]
    assert split_args("a='b c' d='e f'") == ["a='b c'", "d='e f'"]
    assert split_args("a='b c' d='e f' g='h i'") == ["a='b c'", "d='e f'", "g='h i'"]

    # Basic '=' tests with quotes and

# Generated at 2022-06-23 02:47:38.957492
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') is True
    assert is_quoted("'foo'") is True
    assert is_quoted('"a"b"') is False
    assert is_quoted('"foo') is False



# Generated at 2022-06-23 02:47:41.752486
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'foo'") is True
    assert is_quoted('"foo"') is True
    assert is_quoted("foo'") is False
    assert is_quoted("'foo") is False

# Generated at 2022-06-23 02:47:48.864563
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("")
    assert not is_quoted("hello")
    assert not is_quoted("'hello")
    assert not is_quoted("hello'")
    assert not is_quoted("'hello' hello")
    assert is_quoted("'hello'")
    assert is_quoted("'hello \"world\"'")
    assert is_quoted("\"hello 'world'\"")
    assert is_quoted("'\"'")
    assert is_quoted("'\\''")


# Generated at 2022-06-23 02:47:52.781181
# Unit test for function unquote
def test_unquote():
    assert unquote('"abcd"') == "abcd"
    assert unquote('"abcd') == '"abcd'
    assert unquote('abcd"') == 'abcd"'



# Generated at 2022-06-23 02:47:56.536661
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == "a"
    assert unquote("'a'") == "a"
    assert unquote('"a"b') == '"a"b'
    assert unquote("'a'b") == "'a'b"

# Generated at 2022-06-23 02:48:03.503988
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foo') == False
    assert is_quoted('"foo"') == True
    assert is_quoted('\'foo\'') == True
    assert is_quoted('"foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('""') == True
    assert is_quoted('') == False
    assert is_quoted('\'\'') == True


# Generated at 2022-06-23 02:48:08.936824
# Unit test for function unquote
def test_unquote():
    assert unquote('"abc"') == 'abc'
    assert unquote("'def'") == 'def'
    assert unquote('a"b"c') == 'a"b"c'
    assert unquote("a'd'b") == "a'd'b"
    assert unquote("a\"b\"c") == "a\"b\"c"
    assert unquote("") == ""

# Generated at 2022-06-23 02:48:18.028739
# Unit test for function split_args
def test_split_args():
    params = split_args('''git clone -b foo https://github.com/ansible/ansible.git --recursive\ngit clone -b bar https://github.com/ansible/ansible.git --recursive''')
    assert len(params) == 2
    assert params[0] == 'git clone -b foo https://github.com/ansible/ansible.git --recursive\n'
    assert params[1] == 'git clone -b bar https://github.com/ansible/ansible.git --recursive'
    params = split_args(r'''git clone -b foo "https://github.com/ansible/ansible.git" --recursive''')
    assert len(params) == 1

# Generated at 2022-06-23 02:48:22.654145
# Unit test for function unquote
def test_unquote():
    assert unquote("'hello world'") == "hello world"
    assert unquote("hello world") == "hello world"
    assert unquote("\"hello world\"") == "hello world"



# Generated at 2022-06-23 02:48:36.838824
# Unit test for function split_args
def test_split_args():
    '''
    This unit test is pretty light, since the function itself doesn't
    do much work, but it's better than nothing!
    '''

    result = split_args("foo bar baz")
    assert result == ['foo', 'bar', 'baz'], "Plain args failed"

    result = split_args("foo bar=baz")
    assert result == ['foo', 'bar=baz'], "Args with equal sign failed"

    result = split_args("{{ foo_bar }}")
    assert result == ['{{ foo_bar }}'], "Single jinja2 block failed"

    result = split_args("foo bar {{ foo_bar }} baz")
    assert result == ['foo', 'bar', '{{ foo_bar }}', 'baz'], "Jinja2 block with surrounding args failed"

    result = split

# Generated at 2022-06-23 02:48:41.146924
# Unit test for function unquote
def test_unquote():
    ''' tests the unquote function '''
    assert unquote('"hello world"') == 'hello world'
    assert unquote("'hello world'") == 'hello world'
    assert unquote('"hello\'s world"') == 'hello\'s world'
    assert unquote('\'hello"s world\'') == 'hello"s world'
    assert unquote('hello') == 'hello'

# Generated at 2022-06-23 02:48:50.833771
# Unit test for function split_args

# Generated at 2022-06-23 02:49:01.308483
# Unit test for function is_quoted
def test_is_quoted():
    ''' test is_quoted function '''

    # test various strings
    assert is_quoted('"simple"')
    assert not is_quoted('"simple')
    assert not is_quoted('simple"')
    assert not is_quoted('"sim"ple"')
    assert is_quoted('\'simple\'')
    assert not is_quoted('\'simple')
    assert not is_quoted('simple\'')
    assert not is_quoted('\'sim\'ple\'')

    # test various strings
    assert unquote('"simple"') == 'simple'
    assert unquote('"simple') == '"simple'
    assert unquote('simple"') == 'simple"'
    assert unquote('"sim"ple"') == '"sim"ple"'
    assert unquote('\'simple\'')

# Generated at 2022-06-23 02:49:10.413667
# Unit test for function unquote
def test_unquote():
    test_data = [
        ('abc', 'abc'),
        ('"xyz"', 'xyz'),
        ("'xyz'", 'xyz'),
        ('xyz"', 'xyz"'),
        ('"xyz', '"xyz'),
        ('xyz"abc', 'xyz"abc'),
        ('"xyz"abc', 'xyz"abc'),
        ('"xyz"abc"', 'xyz"abc"'),
        ('"', '"'),
        ('"abc"xyz"', 'abc"xyz"'),
        ('"abc\'xyz"', "abc'xyz"),
        ('"abc\\"xyz"', 'abc"xyz'),
        ('"abc\\\\xyz"', 'abc\\xyz')
    ]
    for test in test_data:
        assert unquote

# Generated at 2022-06-23 02:49:22.697585
# Unit test for function split_args
def test_split_args():
    # this should pass
    assert split_args('"foo bar"') == ['"foo bar"']
    assert split_args('"foo bar') == ['"foo bar']
    assert split_args('foo bar"') == ['foo bar"']
    assert split_args('"foo bar baz') == ['"foo bar baz']
    assert split_args('"foo bar baz"') == ['"foo bar baz"']
    assert split_args('foo bar baz"') == ['foo bar baz"']
    assert split_args('foo "bar baz') == ['foo "bar baz']
    assert split_args('foo "bar baz"') == ['foo "bar baz"']
    assert split_args('foo "bar baz') == ['foo "bar baz']

# Generated at 2022-06-23 02:49:27.966522
# Unit test for function is_quoted
def test_is_quoted():
    assert( not is_quoted('') )
    assert( not is_quoted('"') )
    assert( not is_quoted('\'') )
    assert( is_quoted('""') )
    assert( is_quoted('\'\'') )
    assert( is_quoted('"foo bar"') )
    assert( is_quoted('\'foo bar\'') )
    assert( is_quoted('"foo \'bar\'"') )


# Generated at 2022-06-23 02:49:30.771910
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('foo')
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")

# Generated at 2022-06-23 02:49:34.560137
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abcd"')
    assert is_quoted("'abcd'")
    assert not is_quoted('abcd"')
    assert not is_quoted("abcd'")
    assert not is_quoted('abcd')


# Generated at 2022-06-23 02:49:47.810548
# Unit test for function unquote
def test_unquote():
    assert unquote("") == ""
    assert unquote("test") == "test"
    assert unquote("\"test\"") == "test"
    assert unquote("\"\"") == ""
    assert unquote("\\\"") == "\\\""
    assert unquote("\\\\\"") == "\\\\\""
    assert unquote("'test'") == "test"
    assert unquote("''") == ""
    assert unquote("'\\''") == "'"
    assert unquote("'\\\\''") == "\\\\'"
    assert unquote("\"'test'\"") == "'test'"
    assert unquote("'\"test\"'") == "\"test\""
    assert unquote("'\"\"'") == "\"\""
    assert unquote("\"''\"") == "''"

# Generated at 2022-06-23 02:49:54.158931
# Unit test for function unquote
def test_unquote():
    assert unquote('"blah"') == 'blah'
    assert unquote("'blah'") == 'blah'
    assert unquote("'blah") == "'blah"
    assert unquote("blah'") == "blah'"
    assert unquote("'blah\"") == "'blah\""
    assert unquote("\"blah'") == "\"blah'"
    assert unquote("blah") == "blah"

# Generated at 2022-06-23 02:50:06.471796
# Unit test for function split_args
def test_split_args():
    assert split_args("a=1 b=2") == ['a=1', 'b=2']
    assert split_args("a=1 'b b'") == ['a=1', "'b b'"]
    assert split_args("a=1 'b b' c=\"c c\"") == ['a=1', "'b b'", 'c="c c"']
    assert split_args("{{ foo }}{{ bar }}") == ['{{ foo }}', '{{ bar }}']
    assert split_args("{{ foo }}\n{{ bar }}") == ['{{ foo }}\n', '{{ bar }}']
    assert split_args("{{ foo }}\n{{ bar }}", space_split=False) == ['{{ foo }}\n{{ bar }}']

# Generated at 2022-06-23 02:50:10.200775
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == "test"
    assert unquote("'test'") == "test"
    assert unquote('test') == "test"
    assert unquote("'test'") == "test"
    assert unquote("'test") == "'test"
    assert unquote("test'") == "test'"


# Generated at 2022-06-23 02:50:13.587598
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"""') == False
    assert is_quoted('""') == True
    assert is_quoted('\'\'') == True
    assert is_quoted('\'"') == False
    assert is_quoted('abcd') == False
    assert is_quoted('"abcd"') == True

# Generated at 2022-06-23 02:50:22.640284
# Unit test for function split_args
def test_split_args():
    '''
    This has unit tests for AnsibleModule.params, which uses
    the function split_args
    '''

    import json

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import BOOLEANS_TRUE, BOOLEANS_FALSE

    def doit(args):
        m = AnsibleModule(argument_spec={})
        m.params = split_args(args)
        return m.params

    assert doit('a=1 b=2') == ['a=1', 'b=2']
    assert doit('a=1 b=1 c="foo bar"') == ['a=1', 'b=1', 'c="foo bar"']

# Generated at 2022-06-23 02:50:34.194575
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('foobar') is False
    assert is_quoted('"foobar"') is True
    assert is_quoted('foobar') is False
    assert is_quoted('"foobar') is False
    assert is_quoted('foobar"') is False
    assert is_quoted('"foobar""') is False
    assert is_quoted('"""foobar"""') is True
    assert is_quoted('\'foobar\'') is True
    assert is_quoted('foobar\'') is False
    assert is_quoted('\'foobar') is False
    assert is_quoted('foobar\'foobar"') is False
    assert is_quoted('"foo\'bar"') is True



# Generated at 2022-06-23 02:50:44.923786
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the function split_args()

    It will not run with a normal unit test, but is intended to be used to
    ensure that the logic is correct on this function, as it's nuanced based on
    some rather weird inputs.
    '''


# Generated at 2022-06-23 02:50:56.137246
# Unit test for function split_args
def test_split_args():

    # Ensure we get the original string back for no jinja2 or quoting
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Ensure that a quoted arg with spaces in it comes back as a single argument
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Ensure that a jinja2 block comes back as a single argument
    assert split_args('a=b c="{{ foo }}"') == ['a=b', 'c="{{ foo }}"']

    # Ensure a line break followed by a jinja2 block is coalesced as a single argument
    assert split_args('a=b c="{{\\n foo }}"') == ['a=b', 'c="{{\n foo }}"']



# Generated at 2022-06-23 02:51:07.659911
# Unit test for function split_args

# Generated at 2022-06-23 02:51:16.268661
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="this=that"') == ['a=b', 'c="foo bar"', 'd="this=that"']
    assert split_args('a=b c="foo bar\" d=\"this=that"') == ['a=b', 'c="foo bar\" d=\"this=that"']
    assert split_args('a=b c="foo bar\\" d="this=that"') == ['a=b', 'c="foo bar\\" d="this=that"']
    assert split_args("a=b c='foo bar\\' d=\"this=that'") == ['a=b', "c='foo bar\\' d=\"this=that'"]


# Generated at 2022-06-23 02:51:26.763555
# Unit test for function split_args
def test_split_args():
    # Used for assertions at the end of this function
    assert_results = []

    # Test cases

# Generated at 2022-06-23 02:51:35.375552
# Unit test for function split_args
def test_split_args():
    ''' test split args function '''


# Generated at 2022-06-23 02:51:44.482404
# Unit test for function unquote
def test_unquote():
    assert 'abc' == unquote('abc')
    assert 'abc' == unquote('"abc"')
    assert 'abc' == unquote("'abc'")
    assert 'ab"c' == unquote('ab"c')
    assert 'ab\'c' == unquote('ab\'c')
    assert '"ab"c"' == unquote('"ab"c"')
    assert '\'ab\'c\'' == unquote('\'ab\'c\'')



# Generated at 2022-06-23 02:51:52.697160
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted('""'))
    assert(is_quoted('"a word"'))
    assert(is_quoted("''"))
    assert(is_quoted("'another word'"))
    assert(not is_quoted('"no closing quote'))
    assert(not is_quoted('no opening quote"'))
    assert(not is_quoted('this string has no quotes'))
    print('test_is_quoted passed')


# Generated at 2022-06-23 02:52:02.717843
# Unit test for function split_args
def test_split_args():
    input = '''{{ foo }}'''
    expected = ['{{', 'foo', '}}']
    output = split_args(input)
    assert output == expected

    input = '''{{ foo }} bar'''
    expected = ['{{', 'foo', '}}', 'bar']
    output = split_args(input)
    assert output == expected

    input = '''{{ foo }}
bar'''
    expected = ['{{', 'foo', '}}\nbar']
    output = split_args(input)
    assert output == expected

    input = '''{{ foo }}\
bar'''
    expected = ['{{', 'foo', '}}bar']
    output = split_args(input)
    assert output == expected

    input = '''{{ foo }}
{% bar %}'''

# Generated at 2022-06-23 02:52:14.393682
# Unit test for function is_quoted

# Generated at 2022-06-23 02:52:25.246357
# Unit test for function split_args
def test_split_args():
    assert split_args('"{{ foo }}"') == ['{{ foo }}']
    assert split_args('"{{ foo }}" "{{ bar }}"') == ['{{ foo }}', '{{ bar }}']
    assert split_args('"{{ foo }} {{ bar }}"') == ['{{ foo }} {{ bar }}']
    assert split_args('"{{ foo }} {{ bar }}" "{{ bam }}"') == ['{{ foo }} {{ bar }}', '{{ bam }}']
    assert split_args('a={{ foo }}') == ['a={{ foo }}']
    assert split_args('a={{ foo }} b=c') == ['a={{ foo }}', 'b=c']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-23 02:52:35.180069
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == [ 'a=b' ]
    assert split_args('a=b c="foo bar"') == [ 'a=b', 'c="foo bar"' ]
    assert split_args('a=b c="foo bar" d="g\'h"') == [ 'a=b', 'c="foo bar"', 'd="g\'h"' ]
    assert split_args('a=b c="foo bar" d=g\'h\'') == [ 'a=b', 'c="foo bar"', 'd=g\'h\'' ]
    assert split_args('a=b c=\'foo bar\'') == [ 'a=b', 'c=\'foo bar\'' ]
    assert split_args('a="b c"') == [ 'a="b c"' ]
    assert split_

# Generated at 2022-06-23 02:52:40.619540
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("foo bar")
    assert is_quoted("\"foo bar\"")
    assert is_quoted("'foo bar'")



# Generated at 2022-06-23 02:52:44.770066
# Unit test for function unquote
def test_unquote():
    assert 'one two' == unquote('"one two"')
    assert 'two' == unquote('two')
    assert 'one two' == unquote('\'one two\'')



# Generated at 2022-06-23 02:52:51.087142
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""') == True
    assert is_quoted('"foo"') == True
    assert is_quoted('') == False
    assert is_quoted('""foo') == False
    assert is_quoted('foo"') == False
    assert is_quoted('"foo') == False
    assert is_quoted('foo') == False
    assert is_quoted('"foo"foo') == False
    assert is_quoted('''"foo"foo''') == False



# Generated at 2022-06-23 02:53:02.866646
# Unit test for function split_args
def test_split_args():
    # Test 1: simple, unquoted and normal
    data = 'a=b c="foo bar"'
    expected = ['a=b', 'c="foo bar"']
    results = split_args(data)
    assert results == expected, 'received: %s, expected: %s' % (results, expected)

    # Test 2: split on newline
    data = 'a=b c="foo bar"\nd=e'
    expected = ['a=b', 'c="foo bar"\n', 'd=e']
    results = split_args(data)
    assert results == expected, 'received: %s, expected: %s' % (results, expected)

    # Test 3: complex, with jinja2 and quotes
    data = 'a=b c="foo bar{{ foo }}"\nd=e'
    expected

# Generated at 2022-06-23 02:53:15.503932
# Unit test for function split_args
def test_split_args():

    # Test specific examples of expected behavior
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo \\\"bar\\\" baz\"") == ['a=b', 'c="foo \\"bar\\" baz"']
    assert split_args("a=b c=\"foo \\\"bar\\\" baz\"\nd=e f=\"g h\"") == ['a=b', 'c="foo \\"bar\\" baz"', 'd=e', 'f="g h"']
    assert split_args("a=b c=\"{{ foo }}\r\nd=e\"") == ['a=b', 'c="{{ foo }}\r\nd=e"']

# Generated at 2022-06-23 02:53:20.702611
# Unit test for function unquote
def test_unquote():
    assert unquote('"a b"') == 'a b'
    assert unquote('"a b') != 'a b'
    assert unquote('a b"') != 'a b'
    assert unquote('a b') == 'a b'
    assert unquote("'a b'") == 'a b'
    assert unquote("'a b") != 'a b'
    assert unquote("a b'") != 'a b'
    assert unquote("a b") == 'a b'


# Generated at 2022-06-23 02:53:28.262148
# Unit test for function unquote
def test_unquote():
    f = unquote
    assert f("foo") == "foo"
    assert f("'foo'") == "foo"
    assert f("\"foo\"") == "foo"
    assert f("'foo") == "'foo"
    assert f("foo'") == "foo'"
    assert f("''foo'") == "foo"
    assert f("'foo''") == "foo"
    assert f("\"foo\"bar\"") == "foo\"bar"


# Generated at 2022-06-23 02:53:31.710419
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote("'foobar") == "'foobar"

# Generated at 2022-06-23 02:53:41.832283
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('""')
    assert is_quoted('\"\"')
    assert is_quoted('"foo"')
    assert is_quoted('"foo bar"')
    assert is_quoted('""')

    assert is_quoted("''")
    assert is_quoted("''")
    assert is_quoted("'foo'")
    assert is_quoted("'foo bar'")
    assert is_quoted("''")

    assert not is_quoted('"')
    assert not is_quoted("'")
    assert not is_quoted("'foo")
    assert not is_quoted('"foo')
    assert not is_quoted("foo\"")
    assert not is_quoted("foo'")
    assert not is_quoted("foo")
    assert not is_quoted

# Generated at 2022-06-23 02:53:51.104189
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('''"''') == False
    assert is_quoted('"') == False
    assert is_quoted('"""') == False
    assert is_quoted('"a') == False
    assert is_quoted('a"') == False
    assert is_quoted('a') == False
    assert is_quoted('""') == False
    assert is_quoted('"a"') == True
    assert is_quoted("'a'") == True


# Generated at 2022-06-23 02:54:01.655853
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the function split_args to make sure that it produces the expected
    output when given a specific input string
    '''

# Generated at 2022-06-23 02:54:10.718243
# Unit test for function split_args
def test_split_args():
    '''
    This function is called as a unit test for function split_args().
    It runs through a few cases to make sure the function works as expected.
    '''
    def _test_split_args(expected, args):
        result = split_args(args)
        if isinstance(expected, list):
            if isinstance(result, list):
                print("Testing %s" % (args))
                if len(expected) != len(result):
                    print("failed! wrong number of parameters returned. Got %s and expected %s"
                          % (result, expected))
                    raise Exception("failed")
                for exp, res in zip(expected, result):
                    if exp != res:
                        print("failed! got %s and expected %s" % (result, expected))
                        raise Exception("failed")

# Generated at 2022-06-23 02:54:14.221227
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('\'"foo"\'') == '\'"foo"\''

# Generated at 2022-06-23 02:54:25.152254
# Unit test for function split_args
def test_split_args():
    # Basic usage
    assert ['a=b', 'c="foo bar"'] == split_args('a=b c="foo bar"')
    # Semicolon separated list
    assert split_args('a=b; c="foo bar"; d="foo bar baz"') == ['a=b', 'c="foo bar"', 'd="foo bar baz"']
    # Equal signs in quoted values
    assert split_args('a=b c="foo=bar"') == ['a=b', 'c="foo=bar"']
    # Equal signs in quoted values with a semicolon list
    assert split_args('a=b; c="foo=bar"; d="foo=bar=baz"') == ['a=b', 'c="foo=bar"', 'd="foo=bar=baz"']
    # Equal signs in quoted

# Generated at 2022-06-23 02:54:34.863773
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c={{foo}} d="{{bar}}"') == ['a=b', 'c={{foo}}', 'd="{{bar}}"']
    assert split_args('a=b c="{{foo}}" d="bar"') == ['a=b', 'c="{{foo}}"', 'd="bar"']
    assert split_args('a=b c="{{foo}}\\"d="e"') == ['a=b', 'c="{{foo}}"d="e"']
    assert split_args('a=b c="{{foo}}\\""d="e"') == ['a=b', 'c="{{foo}}""d="e"']

# Generated at 2022-06-23 02:54:38.944849
# Unit test for function split_args
def test_split_args():
    example = 'a=b c="foo bar \\"baz\\\"" b=c'
    results = split_args(example)
    assert results == ['a=b', 'c="foo bar \\"baz\\""', 'b=c']

# Generated at 2022-06-23 02:54:44.785706
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted('"test') == False
    assert is_quoted('test"') == False
    assert is_quoted('test') == False
    assert is_quoted("'test'")
    assert is_quoted("'test") == False
    assert is_quoted("test'") == False
    assert is_quoted('test') == False


# Generated at 2022-06-23 02:54:54.706170
# Unit test for function split_args
def test_split_args():
    assert split_args('a=1 b=2') == ['a=1', 'b=2']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b c" d="e f"') == ['a="b c"', 'd="e f"']
    assert split_args('a="b\\ c" d="e f"') == ['a="b c"', 'd="e f"']

# Generated at 2022-06-23 02:55:00.262070
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"')
    assert is_quoted('\'foo\'')
    assert not is_quoted('\'foo"')
    assert not is_quoted('"foo\'')
    assert not is_quoted('foo')
    assert not is_quoted('"foo')
    assert not is_quoted('foo"')



# Generated at 2022-06-23 02:55:11.765151
# Unit test for function split_args