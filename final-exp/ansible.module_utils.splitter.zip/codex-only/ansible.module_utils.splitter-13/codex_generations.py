

# Generated at 2022-06-23 02:45:10.760241
# Unit test for function split_args
def test_split_args():

    # Test default behaviour to split on spaces and newlines
    test_str = '''a=b c="foo bar"
    d="foo bar" e=f

    f=g'''

    result = split_args(test_str)
    assert len(result) == 6
    assert result[0] == 'a=b'
    assert result[1] == 'c="foo bar"'
    assert result[2] == 'd="foo bar"'
    assert result[3] == 'e=f'
    assert result[4] == 'f=g'


    # Test that splitting inside jinja2 blocks works
    test_str = '''a=b "c={{ foo }}" d=e
    f="{{ foo }}" g=h'''

    result = split_args(test_str)

# Generated at 2022-06-23 02:45:24.036986
# Unit test for function split_args

# Generated at 2022-06-23 02:45:31.862368
# Unit test for function split_args
def test_split_args():
    assert split_args("foo bar")                           == ['foo', 'bar']
    assert split_args("foo bar \"baz boo\"")               == ['foo', 'bar', '"baz boo"']
    assert split_args("foo \"bar baz\"")                   == ['foo', '"bar baz"']
    assert split_args("\"bar baz\" foo")                   == ['"bar baz"', 'foo']
    assert split_args("foo \"bar baz\" boo")               == ['foo', '"bar baz"', 'boo']
    assert split_args("foo \"bar baz\"")                   == ['foo', '"bar baz"']
    assert split_args("\"bar\\ baz\"")                     == ['"bar baz"']

# Generated at 2022-06-23 02:45:37.026498
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted("'ab'c'") == False
    assert is_quoted("'ab'c") == False


# Generated at 2022-06-23 02:45:43.811804
# Unit test for function unquote
def test_unquote():
    for string, expected_result in [("'test'", "test"), ('"test"', "test"), ('"test', "\"test"), ('test"', "test\""), ('"test\'', "\"test\'"), ('"test\'\'', "\"test\'\'"), ('"test"test', "\"test\"test"), ('"test""test', "\"test\"\"test"), ('test"test"', "test\"test\""), ('test"test', "test\"test")]:
        assert unquote(string) == expected_result

# Generated at 2022-06-23 02:45:52.879301
# Unit test for function split_args
def test_split_args():
    '''
    Tests the split_args function to ensure proper reassembly
    when jinja2 blocks include white space.
    '''
    test_cases = dict()
    test_cases['simple.yml'] = dict(
        args="a=b c=d",
        expected=['a=b', 'c=d'])
    # test case: quotes around sole argument
    test_cases['quotes_1arg_1.yml'] = dict(
        args="'a b c'",
        expected=["'a b c'"])
    test_cases['quotes_1arg_2.yml'] = dict(
        args="'a b c' d='e f g'",
        expected=["'a b c'", "d='e f g'"])

# Generated at 2022-06-23 02:46:03.091065
# Unit test for function unquote
def test_unquote():
    ''' test unquote returns unquoted string test_data if string starts and ends with the same quotes '''

    test_data = "string"
    assert(unquote(test_data) == test_data)

    test_data = 'string'
    assert(unquote(test_data) == test_data)

    test_data = '"string"'
    assert (unquote(test_data) == 'string')

    test_data = "'string'"
    assert (unquote(test_data) == 'string')

    test_data = '"string'
    assert (unquote(test_data) == '"string')

    test_data = "'string"
    assert (unquote(test_data) == "'string")

    test_data = 'string"'
    assert (unquote(test_data) == 'string"')

# Generated at 2022-06-23 02:46:07.835737
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"hello\"") == True
    assert is_quoted("\"hello") == False
    assert is_quoted("hello\"") == False
    assert is_quoted("'hello'") == True
    assert is_quoted("'hello") == False
    assert is_quoted("hello'") == False



# Generated at 2022-06-23 02:46:16.561360
# Unit test for function split_args
def test_split_args():
    a = "foo bar biz baz"
    assert split_args(a) == ['foo', 'bar', 'biz', 'baz']

    a = "foo bar"
    assert split_args(a) == ['foo', 'bar']

    a = "{{ foo }}"
    assert split_args(a) == ['{{ foo }}']

    a = "{{ foo }} bar"
    assert split_args(a) == ['{{ foo }}', 'bar']

    a = "{{ foo }}bar"
    assert split_args(a) == ['{{ foo }}bar']

    a = "{{ foo }}bar{{ biz }}baz"
    assert split_args(a) == ['{{ foo }}bar{{ biz }}baz']

    a = "{{ foo }}  bar{{ biz }}baz"

# Generated at 2022-06-23 02:46:28.154667
# Unit test for function unquote
def test_unquote():
    assert unquote('') == ''
    assert unquote('""') == ''
    assert unquote('"foo"') == 'foo'
    assert unquote('    "foo"    ') == 'foo'
    assert unquote('""foo""') == '"foo"'
    assert unquote("''") == ''
    assert unquote("'foo'") == 'foo'
    assert unquote("    'foo'    ") == 'foo'
    assert unquote("''foo''") == "'foo'"

    assert unquote("a") == "a"
    assert unquote("a'") == "a'"
    assert unquote("'a") == "'a"
    assert unquote("a\"") == "a\""
    assert unquote("\"a") == "\"a"

# Generated at 2022-06-23 02:46:33.335706
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"") is False
    assert is_quoted("\"\"\"") is False
    assert is_quoted("'") is False
    assert is_quoted("'''") is False
    assert is_quoted("'foo'") is True
    assert is_quoted("\"foo\"") is True
    assert is_quoted("foo") is False

# Generated at 2022-06-23 02:46:37.275577
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"test"')
    assert is_quoted("'test'")
    assert not is_quoted('test')
    assert not is_quoted('"test')
    assert not is_quoted('test"')


# Generated at 2022-06-23 02:46:45.305143
# Unit test for function split_args
def test_split_args():

    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b "c={{foo}} bar"') == ['a=b', '"c={{foo}} bar"']
    assert split_args('a=b "c={{foo}} \n bar" d') == ['a=b', '"c={{foo}} \n bar"', 'd']
    assert split_args('a=b "c={{foo}} \\\n bar" d') == ['a=b', '"c={{foo}} \\\n bar"', 'd']
    assert split_args('a=b "c={{foo}} bar" d') == ['a=b', '"c={{foo}} bar"', 'd']

# Generated at 2022-06-23 02:46:55.097729
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("\"value\"") == True
    assert is_quoted("\"value\"aaa") == False
    assert is_quoted("value\"") == False
    assert is_quoted("\"value") == False
    assert is_quoted("'value'") == True
    assert is_quoted("'value") == False
    assert is_quoted("value'") == False
    assert is_quoted("value") == False
    assert is_quoted("value1\"value2\"") == False
    assert is_quoted("\"value1\"value2\"") == False
    assert is_quoted("\"value1\"value2") == False
    assert is_quoted("\"value1\"value2'") == False
    assert is_quoted("'value1'\"value2\"") == False

# Generated at 2022-06-23 02:47:10.153712
# Unit test for function split_args
def test_split_args():
    def _test_split_args(args, expected):
        args_list = split_args(args)
        assert args_list == expected

    _test_split_args("", [])
    _test_split_args("a=1", ["a=1"])
    _test_split_args("a=1 b=2", ["a=1", "b=2"])
    _test_split_args("a=1\nb=2", ["a=1\n", "b=2"])
    _test_split_args("a=1 'b b' c=3", ["a=1", "'b b'", "c=3"])
    _test_split_args("a=1 'b b c=3", ["a=1", "'b", "b", "c=3"])
    _test_split

# Generated at 2022-06-23 02:47:15.303121
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted("'abc'") == True
    assert is_quoted("'abc") == False
    assert is_quoted("abc'") == False
    assert is_quoted("\"abc\"") == True
    assert is_quoted("\"abc") == False
    assert is_quoted("abc\"") == False


# Generated at 2022-06-23 02:47:23.268927
# Unit test for function split_args

# Generated at 2022-06-23 02:47:31.996320
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('a') == False
    assert is_quoted('ab') == False
    assert is_quoted('a"') == False
    assert is_quoted('"') == False
    assert is_quoted('"a') == True
    assert is_quoted('"ab"') == True
    assert is_quoted("'") == False
    assert is_quoted("'a") == True
    assert is_quoted("'ab'") == True
    assert is_quoted('"a"b"') == False


# Generated at 2022-06-23 02:47:43.364489
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b {# foo #} c="foo bar"') == ['a=b', '{# foo #}', 'c="foo bar"']
    assert split_args('a=b {# foo #} c="foo bar"') == ['a=b', '{# foo #}', 'c="foo bar"']
    assert split_args('a=b {{ foo }} c="foo bar"') == ['a=b', '{{ foo }}', 'c="foo bar"']
    assert split_args('a=b {{ foo }} {# foo #} c="foo bar"') == ['a=b', '{{ foo }}', '{# foo #}', 'c="foo bar"']

# Generated at 2022-06-23 02:47:53.048714
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote('"\\"foo\\""') == '\\"foo\\"'
    assert unquote('\'foo\'') == 'foo'
    assert unquote('\'\\\'foo\\\'\'') == '\\\'foo\\\''
    assert unquote('\\"foo\\"') == '\\"foo\\"'
    assert unquote('\\\'foo\\\'') == '\\\'foo\\\''

    # test nested quoting
    assert unquote('"\\"\\"foo\\"\\""') == '\\"\\"foo\\"\\"'
    assert unquote('\'\\\'\\\'foo\\\'\\\'\'') == '\\\'\\\'foo\\\'\\\''


# Generated at 2022-06-23 02:48:04.650774
# Unit test for function split_args
def test_split_args():

    args = u'echo "foo bar"'
    params = split_args(args)
    assert params == [u'echo', u'"foo bar"']

    # test with a quote inside a jinja2 block
    args = u'echo "{{ foo }}"'
    params = split_args(args)
    assert params == [u'echo', u'"{{ foo }}"']

    args = u'{{ foo }}'
    params = split_args(args)
    assert params == [u'{{ foo }}']

    args = u'echo {{ foo }}'
    params = split_args(args)
    assert params == [u'echo', u'{{ foo }}']

    args = u'echo {{ foo }} {{ bar }}'
    params = split_args(args)

# Generated at 2022-06-23 02:48:10.890103
# Unit test for function is_quoted
def test_is_quoted():
    ''' test for function is_quoted'''
    test_data = [
        ["abc", False],
        ["'abc'", True],
        ['"abc"', True],
        ['""', True],
        ["''", True],
        ["'abc", False],
        ["\"abc", False],
    ]
    for data, expected in test_data:
        assert is_quoted(data) == expected



# Generated at 2022-06-23 02:48:13.396742
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo bar"')
    assert not is_quoted('foo bar')
    assert is_quoted("'foo bar'")


# Generated at 2022-06-23 02:48:16.736044
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted("foo") == False


# Generated at 2022-06-23 02:48:21.639412
# Unit test for function is_quoted
def test_is_quoted():
    data = '"Hello"'
    res = is_quoted(data)
    if not res:
        raise AssertionError('input: %s output: %s' % (data, res))
    data = "Hello'"
    res = is_quoted(data)
    if res:
        raise AssertionError('input: %s output: %s' % (data, res))


# Generated at 2022-06-23 02:48:34.174613
# Unit test for function is_quoted
def test_is_quoted():
    # Testing if a quoted string is recognized as quoted
    assert is_quoted('"abcd"')
    # Testing if a quoted string is recognized as quoted
    assert not is_quoted('"abcd')
    # Testing if a quoted string is recognized as quoted
    assert not is_quoted('abcd"')
    # Testing if a quoted string is recognized as quoted
    assert is_quoted("'abcd'")
    # Testing if a quoted string is recognized as quoted
    assert not is_quoted("'abcd")
    # Testing if a quoted string is recognized as quoted
    assert not is_quoted("abcd'")


# Generated at 2022-06-23 02:48:35.592370
# Unit test for function unquote
def test_unquote():
    assert unquote('"example"') == 'example'



# Generated at 2022-06-23 02:48:39.333337
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"my string"')
    assert is_quoted("'my string'")
    assert not is_quoted('"my string')
    assert not is_quoted("'my string")
    assert not is_quoted("my string")


# Generated at 2022-06-23 02:48:50.362627
# Unit test for function split_args

# Generated at 2022-06-23 02:49:00.862098
# Unit test for function unquote
def test_unquote():
    print("unquote")
    assert unquote('"abcdefghi"') == "abcdefghi"
    assert unquote("'abcdefghi'") == "abcdefghi"
    assert unquote("'abcdefghi") == "'abcdefghi"
    assert unquote("'abcdefghi") == unquote('"abcdefghi')
    assert unquote('abcdefghi"') == "abcdefghi"
    assert unquote('abcdefghi') == "abcdefghi"
    assert unquote('"abcdefghi') == "abcdefghi"
    assert unquote('"abcdefghi""') == '"abcdefghi"'
    assert unquote('"abcdefghi""') == unquote("'abcdefghi''")

# Generated at 2022-06-23 02:49:08.651075
# Unit test for function is_quoted
def test_is_quoted():
    if (is_quoted('"test"') != True):
        raise Exception('is_quoted failed')
    if (is_quoted('test') == True):
        raise Exception('is_quoted failed')
    if (is_quoted('\'test\'') != True):
        raise Exception('is_quoted failed')
    if (is_quoted('\'test') == True):
        raise Exception('is_quoted failed')
    if (is_quoted('test\'') == True):
        raise Exception('is_quoted failed')


# Generated at 2022-06-23 02:49:14.809170
# Unit test for function unquote
def test_unquote():
    for teststr in ["atest", "\"atest\"", "\"\"atest\"\"", "'atest'", "''atest''", "\"''atest''\"", "'''atest'''",
                    "\"'''atest'''\"", "'\"atest\"'", "\"'atest'\""]:
        assert unquote(teststr) == "atest"


# Generated at 2022-06-23 02:49:26.489366
# Unit test for function split_args
def test_split_args():
    """Split args explicitly tests the condition of args split over
    a jinja2 block, contained in quotes and an escaped \" character.
    """

# Generated at 2022-06-23 02:49:32.559221
# Unit test for function unquote
def test_unquote():
    for test in [("\"'\"", "'"), ("'\"'", "\""), ("\"''\"", "''"), ("\"\"", ""), ("''", ""), ("'a'", "a"), ("\"a\"", "a"),
              ("", "")]:
        assert unquote(test[0]) == test[1]



# Generated at 2022-06-23 02:49:40.055871
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') == False
    assert is_quoted('') == False
    assert is_quoted("foobar") == False
    assert is_quoted("-foobar") == False
    assert is_quoted("foobar=") == False
    assert is_quoted("'foobar'") == True
    assert is_quoted("\"foobar\"") == True
    assert is_quoted("'foobar") == False
    assert is_quoted("foobar'") == False
    assert is_quoted("\"foobar") == False
    assert is_quoted("foobar\"") == False
    assert is_quoted("'foo'bar'") == False
    assert is_quoted("'foo\"bar'") == False
    assert is_quoted("\"foo'bar\"") == False


# Generated at 2022-06-23 02:49:49.863492
# Unit test for function unquote
def test_unquote():
    assert unquote("\"test1\"") == "test1"
    assert unquote("'test2'") == "test2"
    assert unquote("\"test3") == "\"test3"
    assert unquote("'test4") == "'test4"
    assert unquote("test5\"") == "test5\""
    assert unquote("test6'") == "test6'"
    assert unquote("") == ""
    assert unquote("\"\"") == ""
    assert unquote("\'\'") == ""
    assert unquote("'\"'") == '"'
    assert unquote("'\"\"'") == '""'
    assert unquote("\"''\"") == "''"


# Generated at 2022-06-23 02:50:01.199084
# Unit test for function unquote
def test_unquote():
    assert unquote("'ansible'") == 'ansible'
    assert unquote('"ansible"') == 'ansible'
    assert unquote("ansible") == 'ansible'
    assert unquote("'ansible") == "'ansible"
    assert unquote("'ansible\"") == "'ansible\""
    assert unquote("'ansible\"\"") == "'ansible\"\""
    assert unquote("\"\"ansible") == '""ansible'
    assert unquote("\"\"ansible\"") == '""ansible"'
    assert unquote("\"\"ansible\"\"") == '""ansible""'
    assert unquote("\"\"ansible\"\"\"") == '""ansible"""'
    assert unquote("\"\"ansible\"\"\"\"") == '""ansible"""'
    assert unquote

# Generated at 2022-06-23 02:50:05.892926
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("salut")
    assert is_quoted("'salut'")
    assert is_quoted("\"salut\"")
    assert not is_quoted("'salut")
    assert not is_quoted("salut'")


# Generated at 2022-06-23 02:50:12.348782
# Unit test for function unquote
def test_unquote():
    assert unquote("foo") == "foo"
    assert unquote('"foo"') == "foo"
    assert unquote("'foo'") == "foo"
    assert unquote("'fo\"o'") == "fo\"o"
    assert unquote("  'fo\"o'") == "  'fo\"o'"
    assert unquote("'fo\"o'\n") == "'fo\"o'\n"


# Generated at 2022-06-23 02:50:20.003859
# Unit test for function unquote
def test_unquote():
    if not is_quoted(unquote('""')): # Check if unquote returns non-quoted value
        raise Exception('Unexpected non-quoted value returned')
    if unquote('""') != '': # Check if empty string is returned
        raise Exception('Unexpected non-empty value returned')
    if unquote('bar') != 'bar': # Check if non-quoted value is returned unchanged
        raise Exception('Unexpected changed value returned')


# ===========================================
# Module execution.
#
if __name__ == '__main__':
    # Test unquote function
    test_unquote()

# Generated at 2022-06-23 02:50:25.148451
# Unit test for function unquote
def test_unquote():
    assert unquote('foo') == 'foo'
    assert unquote('"foo"') == 'foo'
    assert unquote("'foo'") == 'foo'
    assert unquote('f"oo') == 'f"oo'
    assert unquote('fo"o') == 'fo"o'
    assert unquote('fo"o"') == 'fo"o"'



# Generated at 2022-06-23 02:50:31.751836
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('abc') is False
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert is_quoted('"a"bc"') is False
    assert is_quoted("'a'bc'") is False
    assert is_quoted('"a\\"bc"')
    assert is_quoted("'a\\'bc'")


# Generated at 2022-06-23 02:50:37.519419
# Unit test for function unquote
def test_unquote():
    def result(data, expected):
        actual = unquote(data)
        assert actual == expected, "'%s' != '%s' (%s)" % (actual, expected, repr(data))
    result('"test"', 'test')
    result("'test'", 'test')
    result("'test", "'test")
    result("test'", "test'")
    result('test', 'test')

# Generated at 2022-06-23 02:50:46.996687
# Unit test for function split_args
def test_split_args():
    # no args
    assert split_args('') == []

    # one arg
    assert split_args('a') == ['a']
    assert split_args('a=b') == ['a=b']
    assert split_args('"a=b"') == ['"a=b"']
    assert split_args("'a=b'") == ["'a=b'"]

    # two args
    assert split_args('a "b c"') == ['a', '"b c"']
    assert split_args("'a=b' c") == ["'a=b'", 'c']
    assert split_args("'a=b' 'c d'") == ["'a=b'", "'c d'"]

# Generated at 2022-06-23 02:50:51.367560
# Unit test for function is_quoted
def test_is_quoted():
    assert(is_quoted("foo") is False)
    assert(is_quoted("'foo'") is True)
    assert(is_quoted("\"foo\"") is True)
    assert(is_quoted("'foo\"") is False)

# unit test for function unquote()

# Generated at 2022-06-23 02:51:02.450969
# Unit test for function split_args
def test_split_args():
    print(split_args('"foo bar" baz'))
    print(split_args('foo="bar baz" test="one two"'))
    print(split_args('foo="bar baz" test="one two" "foo bar"'))
    print(split_args('"foo bar" test="one two" baz'))
    print(split_args('foo="bar\\ baz" test="one two"'))
    print(split_args('foo="bar"\\ baz test="one two"'))
    print(split_args('foo="bar"\\ baz test="one two"\\'))
    print(split_args('foo="bar"\\ baz test="one two"\\\nfoo="bar"\\ baz test="one two"'))

# Generated at 2022-06-23 02:51:11.634060
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("   ") == []
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b c=d ") == ['a=b', 'c=d']
    assert split_args("a=b c=d\n") == ['a=b', 'c=d']
    assert split_args("a=b c=d\ne=f") == ['a=b', 'c=d\ne=f']
    assert split_args("a=b c=d \ne=f") == ['a=b', 'c=d\ne=f']

# Generated at 2022-06-23 02:51:17.161223
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"bleh"')
    assert is_quoted("'bleh'")
    assert not is_quoted('"bleh')
    assert not is_quoted('bleh"')
    assert not is_quoted('bleh')



# Generated at 2022-06-23 02:51:27.804846
# Unit test for function split_args
def test_split_args():

    ##########
    # Tests for quote balancing

    # check that a string with no quotes has no change
    # to it when split_args is called
    split_args_result = split_args('foo=bar')
    assert split_args_result == ['foo=bar']

    # check that a string with simple quotes is not split
    split_args_result = split_args('foo="bar baz"')
    assert split_args_result == ['foo="bar baz"']

    # check that a string with nested quotes is not split
    split_args_result = split_args('foo="bar \\"baz\\""')
    assert split_args_result == ['foo="bar \\"baz\\""']

    # check that a string with nested quotes is not split

# Generated at 2022-06-23 02:51:31.469852
# Unit test for function unquote
def test_unquote():
    ansible_unquoted_string = 'test'
    ansible_quoted_string = '"test"'
    assert(ansible_unquoted_string == unquote(ansible_quoted_string))



# Generated at 2022-06-23 02:51:40.006405
# Unit test for function unquote
def test_unquote():
    assert unquote('foobar') == 'foobar'
    assert unquote('"foobar"') == 'foobar'
    assert unquote('\'foobar\'') == 'foobar'
    assert unquote('"foo""bar"') == 'foo""bar'
    assert unquote('"foo\'"bar"') == 'foo\'"bar'
    assert unquote('"foo\'bar"') == 'foo\'bar'
    assert unquote('"foo\tbar"') == 'foo\tbar'
    assert unquote('"foo""bar') == '"foo""bar'
    assert unquote('foo""bar"') == 'foo""bar'
    assert unquote('foo"""bar') == 'foo"""bar'



# Generated at 2022-06-23 02:51:45.062471
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert not is_quoted('foo')

    assert is_quoted('"foo"')
    assert is_quoted("'foo'")

    assert not is_quoted('""')
    assert not is_quoted("''")

    assert is_quoted('"foo')
    assert is_quoted("'foo")

    assert is_quoted('foo"')
    assert is_quoted("foo'")


# Generated at 2022-06-23 02:51:49.546816
# Unit test for function unquote
def test_unquote():
    assert unquote('"test"') == 'test'
    assert unquote('"test') != 'test'
    assert unquote('test"') != 'test'
    assert unquote('test') == 'test'



# Generated at 2022-06-23 02:51:53.787808
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"foo"') == True
    assert is_quoted("'foo'") == True
    assert is_quoted('foo') == False
    assert is_quoted('"foo') == False
    assert is_quoted("'foo") == False


# Generated at 2022-06-23 02:52:00.554948
# Unit test for function unquote
def test_unquote():
    assert unquote('"a"') == 'a'
    assert unquote("'a'") == 'a'
    assert unquote('"a"""') == 'a""'
    assert unquote("'a'''") == "a''"
    assert unquote('a') == 'a'
    assert unquote('"a') == '"a'
    assert unquote('a"') == 'a"'
    assert unquote("'a") == "'a"
    assert unquote("a'") == "a'"

# Generated at 2022-06-23 02:52:06.215349
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"') == True
    assert is_quoted("'abc'") == True
    assert is_quoted("abc") == False
    assert is_quoted("\"abc'") == False
    assert is_quoted("ab\"c") == False
    assert is_quoted("ab'c") == False


# Generated at 2022-06-23 02:52:11.024242
# Unit test for function unquote
def test_unquote():
    assert 'blah' == unquote('blah')
    assert 'blah' == unquote('"blah"')
    assert "blah's" == unquote("\"blah's\"")
    assert '"blah"' == unquote('""blah""')

# Generated at 2022-06-23 02:52:19.980233
# Unit test for function is_quoted
def test_is_quoted():
    assert(not is_quoted('abc'))
    assert(is_quoted('"abc"'))
    assert(is_quoted("'abc'"))

    assert(not is_quoted('"a"bc"'))
    assert(not is_quoted("'a'bc'"))

    assert(not is_quoted('""'))
    assert(not is_quoted("''"))
    # longer than one character
    assert(not is_quoted('""""""'))
    assert(not is_quoted("''''''"))


# Generated at 2022-06-23 02:52:31.536318
# Unit test for function unquote
def test_unquote():
    assert unquote('""') == ''
    assert unquote('"foo"') == 'foo'
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote('"foo bar" baz') == 'foo bar" baz'
    assert unquote('foo bar') == 'foo bar'
    assert unquote('foo bar"') == 'foo bar"'
    assert unquote('foo') == 'foo'
    assert unquote('"foo') == '"foo'
    assert unquote('"foo"bar') == '"foo"bar'
    assert unquote('"" "foo"') == '"" "foo"'
    assert unquote('"\'foo\'"') == '\'foo\''



# Generated at 2022-06-23 02:52:36.735894
# Unit test for function unquote
def test_unquote():
    
    test_list = [
        ['"Test_string"', 'Test_string'],
        ["'Test_string'", 'Test_string'],
        ['"Test_string', '"Test_string'],
        ['Test_string"', 'Test_string"'],
        ["Test_string'", "Test_string'"]
    ]
    
    for (test_string, expected_result) in test_list:
        assert unquote(test_string) == expected_result

# Generated at 2022-06-23 02:52:48.401601
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="This is a \"test\"."') == ['a=b', 'c="foo bar"', 'd="This is a \"test\"."']
    assert split_args('a=b c="foo bar" d="This is a \\"test\\"."') == ['a=b', 'c="foo bar"', 'd="This is a \\"test\\"."']
    assert split_args('a=b c="foo bar" d="This is a test."') == ['a=b', 'c="foo bar"', 'd="This is a test."']

# Generated at 2022-06-23 02:52:56.527710
# Unit test for function split_args
def test_split_args():

    def check_split_args(params, result):
        res = split_args(params)
        if res != result:
            raise AssertionError("%s != %s" % (res, result))

    check_split_args("a=b c='d e'", ['a=b', "c='d e'"])
    check_split_args("''", [''])
    check_split_args('""', [''])
    check_split_args("'' ''", ['', ''])
    check_split_args('"" ""', ['', ''])
    check_split_args("a=b c=d{{e}} f=g", ['a=b', 'c=d{{e}}', 'f=g'])

# Generated at 2022-06-23 02:53:07.395815
# Unit test for function split_args

# Generated at 2022-06-23 02:53:09.363441
# Unit test for function unquote
def test_unquote():
    assert unquote('"foo bar"') == 'foo bar'
    assert unquote("'foo bar'") == 'foo bar'



# Generated at 2022-06-23 02:53:18.985633
# Unit test for function split_args

# Generated at 2022-06-23 02:53:28.730240
# Unit test for function split_args
def test_split_args():
    test_basic_args()
    test_arg_with_list()
    test_list_of_args()
    test_list_with_spaces()
    test_arg_with_dict()
    test_arg_with_quotes()
    test_arg_with_equals_in_quotes()
    test_arg_list_with_embedded_dict()
    test_arg_dict_with_embedded_list()
    test_arg_list_with_embedded_dict_and_equals()
    test_arg_list_with_embedded_dict_and_space_in_key()
    test_arg_list_with_embedded_dict_and_space_in_value()
    test_arg_dict_with_embedded_list_and_commas()
    test_arg_dict_

# Generated at 2022-06-23 02:53:32.372030
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted("foo")
    assert is_quoted('"foo"')
    assert is_quoted("'foo'")



# Generated at 2022-06-23 02:53:38.607225
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted('')
    assert is_quoted('"value"')
    assert is_quoted("'value'")
    assert not is_quoted(r"\'value\'")
    assert not is_quoted(r'"value"')
    assert not is_quoted(r"''value''")
    assert not is_quoted(r'""value""')
    assert is_quoted(r'''"""\"value\""""''')


# Generated at 2022-06-23 02:53:48.371018
# Unit test for function split_args

# Generated at 2022-06-23 02:53:56.391861
# Unit test for function unquote
def test_unquote():
    test_data = ['test_1', '\'test_2\'', '"test_3"', "test_4", "\"test_5", "test_6\"", "test_7'"]
    test_results = ['test_1', 'test_2', 'test_3', 'test_4', "\"test_5", "test_6\"", "test_7'"]
    for (d, r) in zip(test_data, test_results):
        assert unquote(d) == r


# Generated at 2022-06-23 02:54:05.237086
# Unit test for function split_args
def test_split_args():

    import unittest
    import sys

    class MyTest(unittest.TestCase):

        def runTest(self):

            # Test1
            msg = "Empty string should return an empty array"
            args = ""
            result = split_args(args)
            self.assertEqual(result, [], msg)

            # Test2
            msg = "A string with one argument should return an array with one element"
            args = "command"
            result = split_args(args)
            self.assertEqual(result, ["command"], msg)

            # Test3
            msg = "A string with multiple arguments should return an array with the arguments"
            args = "argument1 argument2"
            result = split_args(args)
            self.assertEqual(result, ["argument1", "argument2"], msg)

            # Test

# Generated at 2022-06-23 02:54:14.821311
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted(''), "empty string is not quoted"
    assert is_quoted('"hi"'), "string with same start and end quote is quoted"
    assert is_quoted("'hi'"), "string with same start and end quote is quoted"
    assert not is_quoted("'hi"), "string without a matching end quote is not quoted"
    assert not is_quoted('"hi'), "string without a matching end quote is not quoted"
    assert not is_quoted("hi'"), "string without a matching start quote is not quoted"
    assert not is_quoted('hi"'), "string without a matching start quote is not quoted"
    assert not is_quoted('hi'), "string without quotes is not quoted"


# Generated at 2022-06-23 02:54:25.411185
# Unit test for function split_args
def test_split_args():
    from ansible.compat import StringIO

    # This is a list of tuples. The first element is the string to pass to split_args
    # the second element is the list of args that should be parsed from the first element

# Generated at 2022-06-23 02:54:28.201696
# Unit test for function is_quoted
def test_is_quoted():
    x = '"foo"'
    y = 'foo'
    assert(is_quoted(x))
    assert(not is_quoted(y))
    assert(unquote(x) == 'foo')


# Generated at 2022-06-23 02:54:35.837056
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('') is False
    assert is_quoted('""') is True
    assert is_quoted("''") is True
    assert is_quoted('"foo"') is True
    assert is_quoted("'foo'") is True
    assert is_quoted('"\\"foo') is False  # false because it is not properly closed
    assert is_quoted("'\\'foo") is False  # false because it is not properly closed
    assert is_quoted('"fo\\"o') is False  # false because it is not properly closed
    assert is_quoted("'fo\\'o") is False  # false because it is not properly closed


# Generated at 2022-06-23 02:54:42.369905
# Unit test for function is_quoted
def test_is_quoted():
    assert is_quoted('"abc"')
    assert is_quoted("'abc'")
    assert not is_quoted('"abc')
    assert not is_quoted('abc"')
    assert not is_quoted('"abc\'')
    assert not is_quoted('abc')
    assert not is_quoted('')


# Generated at 2022-06-23 02:54:47.918651
# Unit test for function unquote
def test_unquote():
    assert unquote('"hello"') == 'hello'
    assert unquote("'hello'") == 'hello'
    assert unquote("\"'hello'\"") == "'hello'"
    assert unquote('"\'hello\'"') == '\'hello\''
    assert unquote("hello") == 'hello'
    assert unquote('"hello') == '"hello'
    assert unquote('hello"') == 'hello"'



# Generated at 2022-06-23 02:54:54.450259
# Unit test for function is_quoted
def test_is_quoted():
    assert not is_quoted(""), "{} should be False"
    assert not is_quoted("'"), "'' should be False"
    assert not is_quoted("\""), "'' should be False"
    assert is_quoted("\"foo\""), "\"foo\" should be True"
    assert is_quoted("'foo'"), "'foo' should be True"
    assert not is_quoted("\"foo"), "\"foo should be False"
    assert not is_quoted("foo\""), "foo\" should be False"


# Generated at 2022-06-23 02:55:03.525070
# Unit test for function split_args
def test_split_args():
    # Nothing to split
    assert split_args('nothing') == ['nothing']
    # One pair of quotes to split
    assert split_args('"one pair"') == ['"one pair"']
    # One pair of quotes with whitespace to split
    assert split_args(' "one pair" ') == ['"one pair"']
    # Multiple quotes and whitespace to split
    assert split_args('"one pair of quotes" "second pair of quotes"') == ['"one pair of quotes"', '"second pair of quotes"']
    # Slashes to not split
    assert split_args('"one pair \\"of quotes" "second pair of quotes"') == ['"one pair \\"of quotes"', '"second pair of quotes"']
    # Quotes inside quotes to not split