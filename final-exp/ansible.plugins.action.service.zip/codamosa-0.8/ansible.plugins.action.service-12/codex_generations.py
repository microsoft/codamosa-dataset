

# Generated at 2022-06-11 12:13:50.848822
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert ActionModule is not None

# Generated at 2022-06-11 12:13:59.050801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    module = ActionModule({})

# Generated at 2022-06-11 12:13:59.567108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('common/service')

# Generated at 2022-06-11 12:14:06.262805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import unittest

    import AnsiballZ_service as service
    module = service.get_action_class()

    task_vars = {'ansible_facts': {'service_mgr': 'auto'}}
    task = json.loads('{"args": {"name": "test_service", "state": "test_state"}, "collections": [], '
                      '"delegate_to": "", "register": "", "ansible_ssh_host": ""}')
    connection = json.loads('{"connection": "ansible.legacy.ssh"}')

    action = module(task, connection, task_vars)
    for attribute in ['_supports_async', '_supports_check_mode']:
        assert hasattr(action, attribute)

# Generated at 2022-06-11 12:14:11.914190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.playbook.play import Play
  #play = Play().load(play, variable_manager=variable_manager, loader=loader)
  #task = Task().load(task, play=play)
  #pass

# Generated at 2022-06-11 12:14:24.297002
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    vault_secrets_file = 'test_vault_secrets.yml'
    vault_password_file = 'test_vault_password.txt'
    vault_secrets = dict(
        vault_password='12345678',
        foo='bar'
    )

    # Write vault passwords to file
    vault = VaultLib(['--vault-password-file=%s' % vault_password_file])
    vault.write(vault_secrets_file, vault_secrets)

    # Write vault password to disk

# Generated at 2022-06-11 12:14:34.290978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.connection import Connection
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    import sys
    import io

    # Create the modules used when playing an ansible playbook
    sys.argv = [sys.argv[0]]
    loader = DataLoader()

    #

# Generated at 2022-06-11 12:14:35.755612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule(None, None)
    assert not test is None

# Generated at 2022-06-11 12:14:36.526383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:14:46.890366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import shutil
    import tempfile

    cwd = os.getcwd()


# Generated at 2022-06-11 12:14:55.723059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 12:15:06.842998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()


# Generated at 2022-06-11 12:15:17.522369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule

    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display

# Generated at 2022-06-11 12:15:26.561669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import unittest
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.service import ActionModule

    class TestActionModule(ActionModule):
        def __init__(self, play, connection, task, templar, shared_loader_obj):
            ActionBase._shared_loader_obj = shared_loader_obj
            TaskResult._shared_loader_obj = shared_loader_obj
            super(TestActionModule, self).__init__(play, connection, task, templar)


# Generated at 2022-06-11 12:15:33.225971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(service_mgr=dict(arguments=dict(path='/usr/bin/service'))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert am.__class__.__name__ == 'ActionModule'
    assert am._task['service_mgr']['arguments']['path'] == '/usr/bin/service'

# Generated at 2022-06-11 12:15:34.184434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:15:36.829812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule
    
    Check if method returns correct results
    
    Args:
        None
    
    Returns:
        None
    """
    pass


# Generated at 2022-06-11 12:15:43.714691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module
    assert module._supports_check_mode == True
    assert module._supports_async == True
    assert module.TRANSFERS_FILES == False

    assert module.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }

    assert module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])


# Generated at 2022-06-11 12:15:50.799459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    mock_loader = DictDataLoader({})
    mock_inventory = Inventory(loader=mock_loader, variable_manager=VariableManager(loader=mock_loader), host_list=[])
    mock_play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=''))
         ]
    ), variable_manager=VariableManager(), loader=mock_loader)

    tqm = None

# Generated at 2022-06-11 12:16:01.101668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    unit test for method run of class ActionModule
    '''
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = test_dir + "/test_data"
    test_file_path = test_data_dir + "/test.yml"
    data  = yaml.load(open(test_file_path,"r"))
    task  = data["tasks"][0]
    action_module = ActionModule(task, connection=None, play_context=PlayContext(remote_addr="127.0.0.1"), loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=None)
    assert result["failed"] == False

# Generated at 2022-06-11 12:16:17.347999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac = ActionModule()
    ac.run(tmp='tmp', task_vars='task_vars')


# Generated at 2022-06-11 12:16:27.981837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader)
    play = Play()


    options = dict(verbosity=3)

    pbex = PlaybookExecutor(playbooks=[], inventory=inventory, variable_manager=variable_manager, loader=loader, options=options, passwords={})
    tqm = None

# Generated at 2022-06-11 12:16:38.388965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'service'
    use_name = 'auto'
    args_name = 'name=sshd'
    args_state = 'state=running'
    args_enabled = 'enabled=yes'
    args_sleep = 'sleep=3'
    args_ignore = 'ignore_errors=yes'
    async_val = 0
    loop_val = 1
    service_name = 'sshd'
    service_state = 'running'
    service_enabled = 'yes'
    sleep_time = 3
    ignore_flag = 'yes'
    task_args = {}
    tmp = None
    task_vars = None
    options = {}

    # Construct ActionBase object
    x = ActionBase()

    # set the following values for ActionBase
    x._supports_check_mode = True
    x._supp

# Generated at 2022-06-11 12:16:39.397009
# Unit test for constructor of class ActionModule
def test_ActionModule():
  test_ActionModule = ActionModule()

# Generated at 2022-06-11 12:16:50.412581
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:16:58.988603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)
    expected = {
        'auto': {'module': 'ansible.legacy.service'}
    }
    assert action.UNUSED_PARAMS == expected
    assert 'openwrt_init' in action.BUILTIN_SVC_MGR_MODULES
    assert 'service' in action.BUILTIN_SVC_MGR_MODULES
    assert 'systemd' in action.BUILTIN_SVC_MGR_MODULES
    assert 'sysvinit' in action.BUILTIN_SVC_MGR_MODULES

# Generated at 2022-06-11 12:16:59.947621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:17:09.665237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # parametrize return value of method _execute_module
    @pytest.fixture
    def _execute_module(self):
        return {}

    # parametrize return value of method _templar.template
    @pytest.fixture
    def _templar_template(self):
        return 'sudo_service'

    @pytest.fixture
    def task_vars(self):
        return {}

    @pytest.fixture
    def task_args(self):
        return {
            'name': 'sshd',
            'state': 'started',
            'use': 'auto'
        }


# Generated at 2022-06-11 12:17:19.178705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    block = Block()
    task = Task()
    module_args = dict(name='httpd')
    block._append_task(task)
    task.action = 'service'
    task.args = dict(use='auto', state='restarted', service='httpd', enabled=True)
    am = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.run(task_vars=dict(ansible_facts=dict(service_mgr='systemd')))

# Generated at 2022-06-11 12:17:19.741264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:17:51.938904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    assert isinstance(am, ActionModule)


# Generated at 2022-06-11 12:18:01.865103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Calling run method of class ActionModule
    # and testing the result
    actionModule = ActionModule()
    actionModule._connection = None
    actionModule._templar = None
    actionModule._shared_loader_obj = None
    actionModule._display = None
    actionModule._task = None
    actionModule._loader = None
    actionModule._play_context = None
    actionModule.inner_run = inner_run
    actionModule.inner_run_async = inner_run_async
    actionModule.inner_run_on_connection = inner_run_on_connection
    actionModule.inner_run_async_on_connection = inner_run_async_on_connection
    actionModule.inner_run_pexpect = inner_run_pexpect

# Generated at 2022-06-11 12:18:11.411213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Example module as in lib/ansible/plugins/action/command.py
    # See also https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/action/__init__.py
    from ansible.plugins.action.service import ActionModule
    am = ActionModule(
        task=dict(action=dict(module_name='example_module')),
        connection=dict(transport='local'),
        play_context=dict(become=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert am is not None
    assert am._supports_check_mode is True
    assert am._supports_async is True

# Generated at 2022-06-11 12:18:13.274063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.legacy.plugins.action import service as service_action_module

    # create an instance of ActionModule and mock our task arguments
    action_module = service_action_module.ActionModule(load_args=dict(task=dict(name='test task', args=dict(name='nginx', state='started'))))
    action_module.run()

# Generated at 2022-06-11 12:18:18.957213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Connection:
        def __init__(self):
            self.tmpdir = None
        def _shell(self):
            return self
    class PlayContext:
        def __init__(self):
            self.check_mode = False
    class Task:
        def __init__(self):
            self.args = {}
            self.async_val = None
            self.module_defaults = None
            self._parent = None
            self.delegate_to = None
            self.name = None
            self.collections = []
    class Play:
        def __init__(self):
            self._action_groups = {}
    class HostVars:
        def __init__(self):
            self.ansible_facts = {'service_mgr': 'systemd'}

# Generated at 2022-06-11 12:18:30.043821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = create_action_instance(ActionModule)
    action._supports_check_mode = True
    action._supports_async = True
    action._shared_loader_obj.module_loader.has_plugin = Mock(
        return_value=True
    )
    action._execute_module = Mock(
        return_value=dict(
            changed=True,
            msg='',
            meta=dict(
                previous=dict(
                    state='stopped',
                    enabled='disabled'
                ),
                current=dict(
                    state='started',
                    enabled='enabled'
                )
            )
        )
    )
    result = action.run(task_vars=dict(ansible_facts=dict(service_mgr='auto')))

# Generated at 2022-06-11 12:18:39.993707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.path import unfrackpath
    from ansible.vars.hostvars import HostVars

    test_action_module = unfrackpath("/home/travis/build/ansible/ansible/lib/ansible/plugins/action/service.py")
    test_hostvars = unfrackpath("/home/travis/build/ansible/ansible/test/units/lib/ansible/vars/hostvars.py")

    # define input variables for unit test
    test_module = "ansible.legacy.service"
    test_tmp = "/tmp/ansible_service_payload_8579Oy"

# Generated at 2022-06-11 12:18:41.343910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule)
    assert ActionModule

# Generated at 2022-06-11 12:18:50.693894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible_collections.testns.testcoll.plugins.modules import action_test
    from ansible.playbook.task import Task
    from ansible.cli.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    display = Display()
    play_context = PlayContext(play=dict())
    display.verbosity = 4
    task = Task()
    task._ds = dict(service='testing', use='testing')
    task._task_deps = dict()

# Generated at 2022-06-11 12:18:51.780520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:19:56.786158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('This is unit test of method run of class ActionModule')

    task_module = ActionModule()
    task_module.run('This is tmp file', 'This is task_vars')

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-11 12:19:57.658465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule({}, {}, {})

# Generated at 2022-06-11 12:19:58.183148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:20:04.451030
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:20:07.425014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    :return:
    """
    module = ActionModule('host', 'user', 'pass', 'sudo_pass')
    assert module.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:20:18.087027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    meta = {'no_log': True, 'use': 'auto'}
    ACTION_MODULE_INSTANCE = ActionModule()

    ACTION_MODULE_INSTANCE._task.args['_raw_params'] = 'name=ansible-module-service enable=yes state=start'
    ACTION_MODULE_INSTANCE._task.args['_uses_shell'] = False
    ACTION_MODULE_INSTANCE._task.args['_raw_params'] = 'ansible-module-service enable=yes state=start'
    ACTION_MODULE_INSTANCE._task.args['_uses_shell'] = False
    ACTION_MODULE_INSTANCE._task.args['_raw_params'] = 'ansible-module-service enable=yes state=start'
    ACTION_MODULE_INSTANCE._task.args['_uses_shell'] = False



# Generated at 2022-06-11 12:20:19.327107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, 'test', {}, {})
    assert action

# Generated at 2022-06-11 12:20:20.070021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:20:20.671903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:20:21.243158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:23:09.747933
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ACTION_MODULE = ActionModule(None, {}, {})
    assert ACTION_MODULE


# Generated at 2022-06-11 12:23:19.652891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = Task()
    task.action = 'service'
    task.args = {'name':'foo'}
    pm = PluginManager('action')
    pm.add_plugin(ActionModule("test_ActionModule_run", task, None))
    results = pm.run()
    assert results[0].succeeded() is False  # no service manager module registered yet
    assert results[0]._result['failed'] is True
    assert results[0]._result['msg'].startswith("Could not detect which service manager to use")

    from ansible.plugins.action.service import ActionModule as am
    am.BUILTIN_SVC_MGR_MODULES.add("testservice")
    pm.add_plugin(am("test_ActionModule_run", task, None))
    results = pm.run()


# Generated at 2022-06-11 12:23:30.521009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import re
    import os
    import sys
    import mock
    import ansible.runner
    import ansible.utils
    import ansible.errors
    import ansible.module_utils
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.executor.task_result
    import ansible.executor.module_common

    # null connection, as we don't need to connect here
    from ansible.executor.connection_info import Connection
    conn = Connection(None)

    # initial test setup
    am = ActionModule(connection=mock.MagicMock(), task_vars={}, tmpdir='test.dir')
    task = ansible.playbook.task.Task()
    play_context = ansible.playbook.play_context.PlayContext()

# Generated at 2022-06-11 12:23:31.123172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:23:39.615801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    actual_result = ActionModule(connection='connection', task='task', templar='templar', shared_loader_obj='shared_loader_obj').run(tmp='tmp', task_vars='task_vars')
    assert actual_result == {'_ansible_no_log': False, 'changed': False, 'invocation': {'module_args': {'name': 'httpd', 'enabled': True, 'state': 'started'}, 'module_name': 'ansible.legacy.service'}, 'rc': 0, 'results': ['(Consumed key:state:started)', '(Consumed key:name:httpd)']}