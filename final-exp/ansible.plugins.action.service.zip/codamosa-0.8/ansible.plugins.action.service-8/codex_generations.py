

# Generated at 2022-06-11 12:13:52.504391
# Unit test for constructor of class ActionModule
def test_ActionModule():
        # Initialize a ActionModule object.

        # Assertions.
        assert(ActionModule.TRANSFERS_FILES)
        assert(isinstance(ActionModule.UNUSED_PARAMS, dict))
        assert(isinstance(ActionModule.BUILTIN_SVC_MGR_MODULES, set))


# Generated at 2022-06-11 12:14:00.435383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import json
    import pytest

    from ansible.plugins.action.service import ActionModule

    from ansible.module_utils.six.moves import StringIO

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-11 12:14:09.540584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.UNUSED_PARAMS.get('systemd') == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']
    assert action_module.BUILTIN_SVC_MGR_MODULES.__contains__('openwrt_init')
    assert action_module.BUILTIN_SVC_MGR_MODULES.__contains__('service')
    assert action_module.BUILTIN_SVC_MGR_MODULES.__contains__('systemd')

# Generated at 2022-06-11 12:14:10.619141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None



# Generated at 2022-06-11 12:14:15.531111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # TODO: I've no idea how to write unit tests for the method run, so I'll leave it for now.
    pass

# Generated at 2022-06-11 12:14:19.934257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Testing ActionModule.run'''

    # FIXME: improve 'test_ActionModule_run' by testing the AnsibleAction and AnsibleActionFail exceptions

    # Test ActionModule.run with a valid service module
    task_args = dict(use='service')
    action_module = ActionModule(task=dict(args=task_args))
    tmp = None
    task_vars = dict()
    result = {}
    assert action_module.run(tmp, task_vars) == result

    # Test ActionModule.run with an invalid service module
    task_args = dict(use='invalid-service')
    action_module = ActionModule(task=dict(args=task_args))
    tmp = None
    task_vars = dict()
    result = {}

# Generated at 2022-06-11 12:14:22.213328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.run({}, {'task_vars':{}})

# Generated at 2022-06-11 12:14:27.420215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock tasks to use for creating the class instance
    mock_tasks = [
        {
            'args': {
                'use': 'auto',
            },
        },
    ]
    for task in mock_tasks:
        # Create a fresh instance of the class to be tested for every test
        action_module_test = ActionModule(task=task)
        assert type(action_module_test.run()) is dict


# Generated at 2022-06-11 12:14:28.722856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module != None

# Generated at 2022-06-11 12:14:40.260465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = dict()
    config['name'] = 'test_am'
    config['args'] = dict()
    config['args']['name'] = 'test'
    config['action'] = 'service'
    config['delegate_to'] = '127.0.0.1'
    config['async'] = 1
    config['async_poll_interval'] = 1
    config['action_plugins'] = ''
    config['become'] = False
    config['become_method'] = ''
    config['become_user'] = ''
    config['collections'] = ''
    config['connect_timeout'] = 30
    config['delay'] = 1
    config['delegate_facts'] = False
    config['environment'] = ''
    config['first_available_file'] = ''

# Generated at 2022-06-11 12:14:54.211004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # for this test to pass we need to mock the objects
    import mock

    # mock the 'run' function of ActionBase
    with mock.patch('ansible.plugins.action.ActionBase.run', return_value=dict(skipped=True)):
        # instantiate ActionBase object
        actionBase = ActionBase()

        # instantiate ActionModule object
        actionModule = ActionModule(actionBase._task, actionBase._connection, actionBase._play_context, actionBase._loader, actionBase._templar, actionBase._shared_loader_obj)

        # this assert should always be true
        assert actionModule is not None

# Generated at 2022-06-11 12:15:01.538260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test if the method run works as required.
    The method 'run' takes a temporary directory as input.
    The default value of 'tmp' is 'None'.
    The method 'run' takes a task_vars as input.
    The default value of 'task_vars' is 'None'.
    """
    am = ActionModule()
    args = dict()
    args['use'] = 'auto'
    tmp = None
    task_vars = None
    assert am.run(tmp, task_vars) is not None

# Generated at 2022-06-11 12:15:12.508252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import os
    import json


# Generated at 2022-06-11 12:15:12.945134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True is True

# Generated at 2022-06-11 12:15:17.796724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service as action_service
    action_module = action_service.ActionModule(load_name='_load_name', module_name='_module_name', task=None)
    assert action_module.run(tmp='_tmp', task_vars='_task_vars') == {'failed': True, 'msg': 'Not implemented yet'}

# Generated at 2022-06-11 12:15:20.222101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test():
        assert(False)
    m = ActionModule()
    m.run()
    m._supports_check_mode
    m._supports_async
    assert(True)


# Generated at 2022-06-11 12:15:30.216403
# Unit test for constructor of class ActionModule
def test_ActionModule():

    options = dict(
        remote_user = 'developer',
        no_log = False,
        async_val = True,
        remote_pass = 'developer',
        become = dict(
            become = None,
            become_user = 'developer',
            become_pass = None
        )
    )

    task = dict(
        action = dict(
            module = 'service',
            args = dict(),
            delegate_to = '127.0.0.1'),
        async_val = True,
        async_timeout = 10,
        delegate_to = '127.0.0.1'
    )


# Generated at 2022-06-11 12:15:32.506301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(None, action=None, task_vars={}, shared_loader_obj=None)
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-11 12:15:33.842124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(Task(), Connection())
    assert not isinstance(module, ActionBase)

# Generated at 2022-06-11 12:15:41.428693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the construction when use is auto.
    # Define a task to use with the action plugin.
    task_args = {'use': 'auto'}
    action = ActionModule(task=dict(args=task_args))

    # Test the construction when use is not auto
    # And is a member of the UNUSED_PARAMS dictionary
    task_args = {'use': 'systemd',
                 'pattern': 'fake pattern',
                 'sleep': 'fake sleep time',
                 'arguments': 'fake argument',
                 'args': 'fake argument'
                 }
    action = ActionModule(task=dict(args=task_args))

# Generated at 2022-06-11 12:16:07.106593
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Arrange
    import os
    import tempfile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.module_utils.six import iteritems
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-11 12:16:16.971093
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest
    from ansible.module_utils.facts import Facts

    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes
    from ansible.plugins.action.service import ActionModule
    from ansible.utils.vars import combine_vars

    #################################################
    #                  Mocks module                  #
    #################################################
    mod_mock_path = "ansible_collections.notstdlib.moveitallout.plugins.modules.service"
    import sys
    try:
        from importlib import reload
    except:
        from imp import reload
    reload(sys.modules['{}.ansible_facts'.format(mod_mock_path)])

# Generated at 2022-06-11 12:16:24.916911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_module = 'examples.ansible_local.library.service'
    os_version = '1.0'
    # Without argument method run returns empty result
    assert ActionModule.run(test_module) == {}
    # With arguments method run returns full result
    result = ActionModule.run(test_module, os_version)
    assert result['rc'] == 0
    assert result['changed']
    assert result['failed'] == False
    assert result['invocation']['module_args'] == 'name=expereo state=started'
    assert 'stdout' in result


# Generated at 2022-06-11 12:16:35.614602
# Unit test for constructor of class ActionModule
def test_ActionModule():
    random_action_module = ActionModule(None, dict(module_defaults=False, _ansible_check_mode=False, 
        _ansible_no_log=False, async_val=None, _ansible_verbosity=4, 
        _ansible_syslog_facility="0", _ansible_diff=False), task_uuid="test_uuid")
    assert random_action_module is not None
    # Test if the object has the given parameters
    assert random_action_module._supports_check_mode == True
    assert random_action_module._supports_async == True

    assert random_action_module.BUILTIN_SVC_MGR_MODULES == {"openwrt_init", "service", "systemd", "sysvinit"}

# Generated at 2022-06-11 12:16:36.241063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None

# Generated at 2022-06-11 12:16:46.756836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1. Create a mock object of the class based on which you are creating the object
    m_tmp = MagicMock(name="tmp")
    m_task_vars = MagicMock(name="task_vars")
    mock_module = MagicMock()
    mock_module.name = "service"
    mock_module.args = {}
    mock_module.async_val = False
    mock_module.delegate_to = ""
    mock_module.collections = ""
    mock_module._parent = MagicMock()
    mock_module._parent._play = MagicMock()
    mock_module._parent._play._action_groups = [["start", "stop", "restart"], ["enable", "disable"]]
    mock_setup_module = MagicMock()

# Generated at 2022-06-11 12:16:56.237469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = Connection()
    task_vars = dict(ansible_facts=dict(service_mgr='auto'))
    loader_obj = DictDataLoader({})
    shared_loader_obj = SharedPluginLoaderObj()
    actionplugin = Service(
        task=dict(),
        connection=connection,
        _play_context=PlayContext(),
        loader=loader_obj,
        shared_loader_obj=shared_loader_obj,
        templar=Templar(loader=loader_obj)
    )
    # we can't test the results in any real way, but at least make sure it
    # doesn't blow up
    actionplugin.run(task_vars=task_vars)

# Generated at 2022-06-11 12:17:06.339881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import pytest
    mock_args = {
        'use': 'auto',
        'name': 'telnet',
        'enabled': 'yes',
        'state': 'started',
        'enabled': 'yes'
    }
    mock_module = 'ansible.legacy.service'
    mock_action_module = ActionModule()
    mock_action_module._templar = DummyTemplar('ansible_service_mgr', 'ansible.legacy.systemd')
    mock_action_module._execute_module = DummyModuleExecutor()
    mock_task = DummyTask(args=mock_args)
    mock_task.delegate_to = None
    mock_task.async_val = None
    mock_task.async_timeout = None
    mock

# Generated at 2022-06-11 12:17:17.332367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import datetime
    from ansible.utils.display import Display

    display = Display()
    display.deprecated('hi')

    test_task = type('', (), {})()
    test_task._parent = type('', (), {})()
    test_task._parent.task_name = 'Task 1'
    test_task._parent.async_val = 0
    test_task._parent._play = type('', (), {})()
    test_task._parent._play.name = 'Play 1'
    test_task._parent._play.start_at = datetime.datetime.now()
    test_task._parent._play.basedir = '/playbooks/testplay/playbooks'
    test_task._parent._play.helpers = type('', (), {})()
    test_task._parent._play._action_groups

# Generated at 2022-06-11 12:17:26.606940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.service_mgr import get_service_mgr
    from ansible.module_utils.facts.system.service_mgr import ServiceMgr
    from ansible.module_utils.facts.system.service_mgr import Service
    from ansible.module_utils.facts.system.service_mgr import ServiceStatus
    from ansible.module_utils.facts.system.service_mgr import ServiceManager
    from ansible.module_utils.facts.system.service_mgr import ServiceManagerInfo
    from ansible.module_utils.facts.system.service_mgr import ServiceManagerStatus
    from ansible.module_utils.facts.system.service_mgr import ServiceManagerTypes

    # make sure that we get the expected service mgr when we set the use to auto

# Generated at 2022-06-11 12:18:02.926446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    class FakePlay(object):
        class FakePlayContext(PlayContext):
            def __init__(self):
                self.connection = None
                self.remote_addr = None
                self.remote_user = None
                self.port = None
        class FakeTask(Task):
            def __init__(self):
                self.args = {'use': 'auto'}
                self.async_val = 2
        class FakeHost(Host):
            def __init__(self):
                self.groups = ['group1']

# Generated at 2022-06-11 12:18:05.295810
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule(task = Mock())
    module.run(tmp = 'test', task_vars = {'service_mgr':'systemd'})

# Generated at 2022-06-11 12:18:12.523121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert type(action_module).__name__ == 'ActionModule'
    assert action_module.__dict__['TRANSFERS_FILES'] == False
    assert action_module.__dict__['UNUSED_PARAMS'] == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert action_module.__dict__['BUILTIN_SVC_MGR_MODULES'] == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-11 12:18:14.497612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.plugins.loader import find_action_plugin
    my_action_module = find_action_plugin('service')()
    assert(type(my_action_module) == ActionModule)
    my_task = Task()
    my_task.args = { 'name': 'nfs' }
    my_action_module.set_task(my_task)

# Generated at 2022-06-11 12:18:25.276112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = ("127.0.0.1", 22)
    connection = Connection(host)
    task_uuid = 'peter'
    loader = None
    variable_manager = None
    templar = None
    shared_loader_obj = None
    action = ActionModule(connection, task_uuid, loader, variable_manager, templar, shared_loader_obj)

    assert action._supports_check_mode == True
    assert action._supports_async == True

    assert action.TRANSFERS_FILES == False

    assert action.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }


# Generated at 2022-06-11 12:18:32.640280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # NOTE: using a mock for the full class object is not really possible due to inheritance
    am = ActionModule()
    am._task = DummyTask()
    am._shared_loader_obj = DummySharedLoaderObj()
    am._connection = DummyConnection()
    am._connection._shell = DummyShell()
    am._templar = DummyTemplar()
    am._display = DummyDisplay()

    # method run returns a dict
    assert isinstance(am.run(None, None), dict)


# Generated at 2022-06-11 12:18:33.218954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:18:39.723945
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ##############
    # Initialize #
    ##############
    action_module = ActionModule()

    ###############
    # Run the test#
    ###############
    # Mocked task args
    task_args = {'name': 'foo', 'state': 'latest'}
    # Mocked task_vars
    task_vars = {'ansible_facts': {'service_mgr': 'auto'}}
    action_module.run(None, task_vars=task_vars)

# Generated at 2022-06-11 12:18:49.300693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Constructor of ActionModule")
    # Constructor of action module test
    task = dict(ActionModule=dict(service="restart_service"))
    action = dict(service="restart_service")
    action_executor = dict(ActionModule=dict(service="restart_service"))
    tmp = "/tmp"
    task_vars = dict()
    shared_plugin_loader_obj = dict(ActionModule=dict(service="restart_service"))
    connection = dict(ActionModule=dict(service="restart_service"))
    play_context = dict(ActionModule=dict(service="restart_service"))
    loader = dict(ActionModule=dict(service="restart_service"))
    display = dict(ActionModule=dict(service="restart_service"))

# Generated at 2022-06-11 12:18:52.691265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_obj=None, templar=None, shared_loader_obj=None)
    action_module.run()

test_ActionModule_run()

# Generated at 2022-06-11 12:19:55.289503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.service import ActionModule

# Generated at 2022-06-11 12:19:57.122512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Testing Method: run
    """
    # TODO: Write a unit test
    pass

# Generated at 2022-06-11 12:20:04.382349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes

    loader = DictDataLoader({})
    passwords = {}
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 12:20:13.561731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MyTask:
        async_val = False
        _parent = object
        _task_fields = ['async_val']
    mytask = MyTask()
    mytask._parent = object
    mytask.args = dict(key1='value1', key2='value2')

    # test_action_module1
    setattr(mytask, 'async_val', False)
    setattr(mytask, 'args', dict(key1='value1', key2='value2'))
    setattr(mytask, '_parent', object)
    setattr(mytask, 'async_val', False)
    action_module = ActionModule(task=mytask, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.TR

# Generated at 2022-06-11 12:20:15.968411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# test_ActionModule()

# Generated at 2022-06-11 12:20:19.891015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test ActionModule run method
    Raw arguments (dict):
    {'use': 'auto'}
    Params after templating (dict):
    {'use': 'auto'}
    """

    # Setup test data
    tmp = None
    task_vars = {}

# Generated at 2022-06-11 12:20:28.294892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import pytest
    from ansible.plugins.action import ActionBase

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    class MockConnection(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

    class MockTask(object):
        def __init__(self):
            self.args = dict(name='foo', state='restarted')
            self.module_defaults = dict()
            self.async_val = 1


    class MockAsyncTask(MockTask):
        def __init__(self):
            super(MockAsyncTask, self).__init__()
            self.async_val = 5


    class MockTemplar(object):
        def __init__(self):
            pass

# Generated at 2022-06-11 12:20:28.784315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am=ActionModule()

# Generated at 2022-06-11 12:20:29.241918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:20:29.707885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:23:10.223419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    params = {
        'module_name': 'test_module',
        'module_args': { 'test_module_args':'test_module_args' },
        'task_vars': { 'test_task_vars': 'test_task_vars' }
    }
    options = {
        'connection':'local'
    }
    results = module.run(tmp=None, task_vars=params['task_vars'])

# Generated at 2022-06-11 12:23:15.784303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    A test for the constructor of the ActionModule class.
    '''

    connection = DummyConnection()
    task = DummyTask(connection = connection)
    host = DummyHost()

    action = ActionModule(task, host, connection, '/usr/local/bin/ansible')
    action.run()

    assert 1 == 1, 'The unit test should have failed!'


# Generated at 2022-06-11 12:23:19.260546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = dict(use='test', name='test', test='test')
    module._task.delegate_to = 'test'
    assert module.run(tmp='', task_vars='test') == dict(changed=False, failed=False)

# Generated at 2022-06-11 12:23:30.116418
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:23:31.076518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Success: test_ActionModule")
    assert True

# Generated at 2022-06-11 12:23:33.054653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.process import get_bin_path
    assert 1 == 1

# Generated at 2022-06-11 12:23:39.012579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockTask():
        def __init__(self):
            self.args = {}
    task = MockTask()
    task.args = {
        'name': 'foo',
        'state': 'started',
        'use': 'auto'
    }
    action_module = ActionModule(task, dict())
    with patch.object(ActionModule, '_execute_module', return_value=dict(rc=0)):
        assert action_module.run()