

# Generated at 2022-06-11 12:13:56.763918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os, sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'unit'))

    from ansible.module_utils.common._collections_compat import unittest

    from mock import Mock, patch

    from .test_mock_class import TestActionModule, TestActionModuleArgs

    test_action_module_args = TestActionModuleArgs()
    test_action_module = TestActionModule(test_action_module_args)

    test_action_module.run()

    class TestActionModuleRun(unittest.TestCase):
        pass

    # TODO

# Generated at 2022-06-11 12:14:03.203626
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Instance of ansible.executor.task_result.TaskResult()
    task_result = TaskResult()

    # TaskResult instance does not have a _result attribute, so it should raise an exception
    assert_raises(AttributeError, ActionModule, task_result, {})

    # Instance of ansible.executor.task_result.TaskResult()
    task_result = TaskResult()
    task_result._result = {}
    # TaskResult._result attribute does not have a 'invocation' sub-attribute, so it should raise an exception
    assert_raises(AttributeError, ActionModule, task_result, {})

    # TaskResult._result attribute does not have a 'task' sub-attribute, so it should raise an exception
    task_result = TaskResult()
    task_result._result = {'invocation': {}}
   

# Generated at 2022-06-11 12:14:04.056800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    myaction = ActionModule()

# Generated at 2022-06-11 12:14:04.545812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:14:11.259183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This test is for constructor of the class ActionModule
    ansible_task = object()
    connection = object()
    play_context = object()
    loader = object()
    templar = object()
    shared_loader_obj = object()

    action_module = ActionModule(ansible_task, connection, play_context, loader, templar, shared_loader_obj)
    assert action_module

# Generated at 2022-06-11 12:14:16.521177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = dict()
    mock_connection = dict()
    mock_loader = dict()

    # test constructor
    action_module = ActionModule(mock_task, mock_connection, mock_loader)
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-11 12:14:18.009200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(None, {}, None, None, None)
    assert act

# Generated at 2022-06-11 12:14:18.638684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule()

# Generated at 2022-06-11 12:14:26.290061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleLegacyServiceModuleAction()
    assert module is not None
    assert module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert module.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert module.TRANSFERS_FILES == False
    assert module.run() == {}

# Generated at 2022-06-11 12:14:27.200267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Generated at 2022-06-11 12:14:34.031867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:14:45.058109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ModuleOne = type('ModuleOne', (object, ), {
        '_lowered_action': 'command'
    })
    ModuleTwo = type('ModuleTwo', (object, ), {
        '_lowered_action': 'shell',
        'run': ActionModule.run
    })
    ModuleThree = type('ModuleThree', (object, ), {
        '_lowered_action': 'ansible.legacy.add_host',
    })
    module = ActionModule.run
    action = ActionModule(ModuleOne)
    result = module(action, None, None)
    assert result.get('failed') is True
    action = ActionModule(ModuleTwo)
    result = module(action, None, None)
    assert result.get('failed') is True
    action = ActionModule(ModuleThree)

# Generated at 2022-06-11 12:14:54.499908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import find_plugin, PluginLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    import pytest

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    tqm = None

# Generated at 2022-06-11 12:14:55.158033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-11 12:15:03.309870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a dummy action
    action = ActionModule(dict(),
        task=dict(name="test", async_val=10, async_poll_interval=0, action='service', args=dict(name='http', state='started')))
    assert action._task.name == "test"
    assert action._task.async_val == 10
    assert action._task.async_poll_interval == 0
    assert action._task.action == "service"
    assert action._task.args['name'] == "http"
    assert action._task.args['state'] == "started"

# Generated at 2022-06-11 12:15:08.914603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict(use=("auto"))),
        connection=dict(host="localhost", port=22, user="user"),
        play_context=dict(remote_user="user", become=True),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action

# Generated at 2022-06-11 12:15:12.455063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
      Unit test with mocking of methods present in the class.
      This method tests the various conditions present in run method.
    '''
    import types
    assert isinstance(ActionModule.run, types.MethodType)



# Generated at 2022-06-11 12:15:14.095981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}

# Generated at 2022-06-11 12:15:14.736640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:15:22.769134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    introspec=task_vars={'hostvars': {'localhost':{'ansible_facts':{'service_mgr':'auto'}}}}
    _task = task(dict())
    _task.args['use'] = 'auto'
    _task.delegate_to = 'localhost'

    # Case 1
    _action_module = ActionModule(_task, None)
    _action_module._execute_module = lambda *x, **y: dict(ansible_facts={'ansible_service_mgr':'auto'})
    assert _action_module.run(task_vars=introspec) == dict(changed=False, skipped=True)

    # Case 2
    _action_module = ActionModule(_task, None)

# Generated at 2022-06-11 12:15:39.966574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(task = {'args':{'name':'test'}}, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    assert a.run() == {'failed': True, 'msg': 'Provided service name (None) is not valid'}

# Generated at 2022-06-11 12:15:40.576144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-11 12:15:48.683297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible
    import ansible.plugins
    import ansible.plugins.action

    ansible_version, ansible_version_info = ansible.__version__, ansible.version_info
    ansible.__version__ = '2.10.0'
    ansible.version_info = tuple(2 * [int(i) for i in ansible.__version__.split('.')])

    import ansible.plugins.action.service
    action_module = ansible.plugins.action.service.ActionModule(
        {},
        [],
        {},
        '<string>',
        '',
        1,
        0,
        {},
        False,
        False,
        False,
    )


# Generated at 2022-06-11 12:15:52.705551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._task = {}
    action_module._task.args = {}

    # Test
    try:
        action_module.run()
    except NotImplementedError:
        assert True
    else:
        assert False

# Generated at 2022-06-11 12:16:03.285256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import __builtin__
    setattr(__builtin__, '__file__', '/tmp/ansible_test')
    task = { 'async': None,
             'async_val': 0,
             'args': {'arguments': {}, 'use': 'auto'},
             'collections': [],
             'delegate_to': None,
             'delegate_facts': False,
             'environment': {},
             'module_defaults': {},
             'name': u'Create a new file',
             'notify': [],
             'role': None,
             'role_name': None,
             'tags': [],
             'until': None,
             'vars': {}}
    loader = None
    variable_manager = None
    shared_loader_obj = None
    display = None


# Generated at 2022-06-11 12:16:14.199435
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # define test attributes
    ActionModule.BUILTIN_SVC_MGR_MODULES = set()
    ActionModule._loader = None
    ActionModule._shared_loader_obj = None
    ActionModule._templar = None
    ActionModule._task = None
    ActionModule._connection = None
    ActionModule._play_context = None
    ActionModule._loaded_frm_file = False
    ActionModule._display = None
    ActionModule._task_vars = {}
    ActionModule._task_vars['ansible_facts'] = None
    ActionModule._task_vars = {}
    ActionModule._task_vars['ansible_facts'] = None
    ActionModule._templar = None
    ActionModule._task_vars = None
    ActionModule._task = None
    ActionModule._play_context = None

# Generated at 2022-06-11 12:16:14.927554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__bases__ == (ActionBase,)

# Generated at 2022-06-11 12:16:22.573776
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Arrange
    # Create a mock task instance and a mock class instance.
    mock_task = Mock()
    mock_class = Mock()
    mock_class._task = mock_task

    # Act
    # Call method run of class ActionModule.
    result = ActionModule.run(mock_class)
    # Assert
    # Assert method run returns an instance of class AnsibleActionFail and
    # the instance is decorated with _ansible_module_name.
    assert isinstance(result, AnsibleActionFail)
    assert result.result["_ansible_module_name"] == "service"
    
    

# Generated at 2022-06-11 12:16:31.993063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    action = action_loader._create_action_plugin(
        'ansible.plugins.action.service',
        {'operation': 'at', 'name': 'foo', 'enabled': True, 'use': 'auto', 'state': 'started'}
    )
    assert action.__class__.__name__ == 'ActionModule'
    assert action._task.args['operation'] == 'at'
    assert action._task.args['name'] == 'foo'
    assert action._task.args['enabled'] == True
    assert action._task.args['use'] == 'auto'
    assert action._task.args['state'] == 'started'
    del(action)

# Generated at 2022-06-11 12:16:42.341720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m._execute_module = lambda *args, **kw: {'rc': 0, 'stdout': '', 'stderr': ''}
    m._templar = dict()
    m._templar['template'] = lambda s: 'auto' if s == '{{ansible_facts.service_mgr}}' else 'ansible.legacy.service'
    m._task = dict()
    m._task.args = dict()
    m._task.args['use'] = ''
    m._task.async_val = 0
    m._task.delegate_to = ''
    m._task.module_defaults = dict()
    m._task._parent = dict()
    m._task._parent._play = dict()
    m._task._parent._play._action_groups = dict()


# Generated at 2022-06-11 12:17:17.418942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    task = Task()
    task._role = None
    play_context = PlayContext()
    task.action = 'service'
    task_vars = dict()
    connection = None
    loader = None
    shared_loader_obj = None
    action_base = ActionModule(task, connection, play_context,
                               loader=loader,
                               shared_loader_obj=shared_loader_obj,
                               templar=None,
                               task_vars=task_vars)

# Generated at 2022-06-11 12:17:19.820571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-11 12:17:20.392088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:17:29.892230
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockModule(object):
        def __init__(self):
            self.result = dict(failed=False, changed=False)

    module = MockModule()
    action = ActionModule(task=dict(
        args=dict(
            use='auto',
            state=str,
            name=str,
            enabled=bool,
            pattern=str,
            pattern_match=str,
            runlevel=str,
            sleep=int,
            arguments=list,
            args=list,
            target=str,
        ),
    ), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Expected behaviour:
    #   If module is 'auto', delegate to delegated host if it is set, otherwise delegate to self
    #   If module is specified and exists

# Generated at 2022-06-11 12:17:39.074956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'localhost'
    task = dict(action=dict(__ansible_module__='service', use='auto'))
    connection = 'local'
    play_context = dict(remote_addr=connection)
    loader = None
    templar = None
    shared_loader_obj = None
    _noop_task = None
    action = ActionModule(task=task, connection=connection, play_context=play_context, loader=loader, shared_loader_obj=shared_loader_obj, templar=templar, _noop_task=_noop_task)
    assert action.__class__.__name__ == 'ActionModule'
    assert action._shared_loader_obj is not None
    assert action.connection == connection
    assert action._connection == 'local'
    assert action.play_context == play_

# Generated at 2022-06-11 12:17:45.742025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ..mock.loader import DictDataLoader
    from ..mock.parsing import parse_yaml_from_string
    from ..mock import mock_plugins

    mock_plugins.install()
    loader = DictDataLoader({
        "someplaybook.yml": parse_yaml_from_string(
            """
            - hosts: all
              gather_facts: false
              tasks:
                - action:
                    module: service
                    args:
                        name: foo
                        state: started
                        enabled: True
            """)
    })

    play = Play().load(loader=loader, file_name='someplaybook.yml', task_vars={})
    tqm = None
    from ..plugins.loader import TaskQueueManager

# Generated at 2022-06-11 12:17:56.236768
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.errors import AnsibleOptionsError

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager

# Generated at 2022-06-11 12:18:06.136689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    import ansible.playbook.play_context
    import ansible.executor.task_result
    import ansible.executor.task_result

    runner = action_loader.get('service', class_only=True)()
    ansible.executor.task_result.TaskResult = ansible.executor.task_result.TaskResult

    runner._remove_tmp_path = lambda self, connection, tmp_path: None

# Generated at 2022-06-11 12:18:07.460391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(None, None, None, None)
    assert act is not None

# Generated at 2022-06-11 12:18:13.445647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module.TRANSFERS_FILES is False
    assert action_module.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert action_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-11 12:19:02.199022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:19:12.320769
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:19:21.937240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule_instance = ActionModule()
    module = 'ansible.legacy.service'
    # test passing module name
    test_ActionModule_instance._task.args['use'] = 'auto'
    test_ActionModule_instance._display.verbosity = 2
    test_ActionModule_instance.run()
    assert test_ActionModule_instance._task.args['use'] == module

    # test passing module name
    test_ActionModule_instance._task.args['use'] = 'service'
    test_ActionModule_instance._display.verbosity = 2
    test_ActionModule_instance.run()
    assert test_ActionModule_instance._task.args['use'] == module

    # test using default module
    test_ActionModule_instance._task.args['use'] = 'auto'
    test_ActionModule_instance._

# Generated at 2022-06-11 12:19:23.341863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        action = ActionModule({})
        result = action.run()
        assert result == {}

# Generated at 2022-06-11 12:19:32.897287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar

    context.CLIARGS = {}

    a = action_loader.get('service', task=dict(args=dict()), connection='fake', play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(a, ActionModule)


# Generated at 2022-06-11 12:19:34.839979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.strategy.linear import ActionModule
    action = ActionModule(None, None, None, private_data_dir=None)

# Generated at 2022-06-11 12:19:37.295548
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()

    task_vars = {
        "foo": "bar",
    }

    args = {}

    module.run(None, task_vars)

# Generated at 2022-06-11 12:19:47.579940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader_obj = Mock()
    mock_task = Mock()
    mock_task.async_val = True
    mock_task._parent = Mock()
    mock_task._parent._play = Mock()
    mock_task._parent._play._action_groups = {}
    mock_task.args = {'name': 'foo'}

    test_obj = ActionModule(mock_loader_obj, mock_task, connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())

    assert test_obj._task._parent._play._action_groups == {}


# Generated at 2022-06-11 12:19:56.155368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    task_vars = dict()
    task_vars['ansible_service_mgr'] = 'not a service manager'
    set_module_args = dict()
    set_module_args.update({'state': 'restarted'})

    module = ActionModule(mock.Mock(), task_vars=task_vars)
    task_vars['ansible_service_mgr'] = 'not a service manager'
    set_module_args.update({'state': 'restarted'})
    del module.UNUSED_PARAMS['systemd']

    with pytest.raises(AnsibleActionFail):
        result = module.run(set_module_args, task_vars)

# Generated at 2022-06-11 12:19:58.657653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='postgresql', state='enabled')),
        connection=dict(host='localhost'),
        play_context=dict(become=True, become_user='root')
    )
    assert action_module._task.args['name'] == 'postgresql'

# Generated at 2022-06-11 12:22:39.480274
# Unit test for constructor of class ActionModule
def test_ActionModule():

    datadir = os.path.join(os.path.dirname(__file__), '..', 'unit', 'action_plugins')
    my_env = Environment(loader=FileSystemLoader(datadir))
    my_env.globals['ansible_facts'] = {'service_mgr': 'auto'}
    my_env.globals['ansible_facts'].update(get_system_facts())

    task = Task()
    host = Host(name="localhost")
    task.set_loader(my_env)
    task.environment = Environment()

    task.args = {'service': 'iscsi', 'state': 'started'}
    task.action = "service"

    am = ActionModule(task, host, connection=None)

# Generated at 2022-06-11 12:22:48.519811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' unit test for ActionModule '''

    # Test case: constructor of class ActionModule - success case
    mock_task = type('mock', (), {
        'args': {},
        'async_val': type('mock', (), {
            'return_value': False,
        })(),
        'module_defaults': {},
        '_parent': type('mock', (), {
            '_play': type('mock', (), {
                '_action_groups': {},
            })(),
        })(),
    })
    mock_connection = type('mock', (), {
        '_shell': type('mock', (), {
            'tmpdir': '',
        })(),
    })

# Generated at 2022-06-11 12:22:57.470158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a task
    task_obj = type('test_task', (object,), dict())
    task_obj.action = 'service'
    task_obj.async_val = 10000
    task_obj.async_poll_interval = 10
    task_obj.args = {}
    task_obj.module_defaults = ''
    task_obj.module_vars = ''
    task_obj.register = 'test'
    task_obj.ignore_errors = False
    task_obj.any_errors_fatal = False
    task_obj.delegate_to = None

    # Create a task_executor
    task_executor_obj = type('task_executor', (object,), dict())

    # Create a PlayContext

# Generated at 2022-06-11 12:22:57.966679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:23:05.849386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-11 12:23:15.956889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    # read tempfile
    with open(tempfile.NamedTemporaryFile(delete=True).name, 'r') as f:
        file_read=f.read()
    # write tempfile
    with open(tempfile.NamedTemporaryFile(delete=True).name, 'w') as f:
        file_write=f.write('')
    # read existing file
    with open(__file__, 'r') as f:
        file_read = f.read()
    # create file
    fd, fpath = tempfile.mkstemp()
    data = os.read(fd, 1)
    os.close(fd)
    # remove file
    os.remove(fpath)
    os.remove(fpath)
    # set environmental variable


# Generated at 2022-06-11 12:23:26.234221
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    act = ActionModule(dict(use='auto'), dict(
        ansible_facts=dict(service_mgr='auto', ansible_async=False),
        ansible_module_uids=dict(uid1=dict(module_name='ansible.legacy.setup')),
        ansible_play=dict(
            _action_groups=dict(),
            _play_context=dict(
                _play_context=dict(
                    _play_context=dict(
                        module_defaults=dict(
                            foo='bar',
                        ),
                    ),
                )
            )
        )
    ))


    def get_async_val(self):
        return self._task.async_val

    def has_plugin():
        return True

    # add missing function from ActionBase

# Generated at 2022-06-11 12:23:36.820797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action as action_module
    import ansible.playbook.task as task
    import ansible.playbook.play_context as play_context

    play_context_obj = play_context.PlayContext()
    action_module_obj = action_module.ActionModule("", play_context_obj)

    assert action_module_obj.TRANSFERS_FILES == False
    assert action_module_obj.UNUSED_PARAMS['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']
    assert action_module_obj.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

    # test run method
    task_obj = task.Task()
    task_obj

# Generated at 2022-06-11 12:23:45.000939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.module_common import _task_fields_old_style
    from ansible.plugins.loader import module_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    class MockLoader(module_loader.ModuleLoader):
        def has_plugin(self, name):
            return name == 'test' or name == 'test.test'

    play_context = PlayContext()
    task = Task()
    task.args = dict(name='test')

    # HACK: task.args passed to get_action_args_with_defaults() in run() is a dictproxy and cannot