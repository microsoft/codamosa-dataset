

# Generated at 2022-06-11 12:13:52.345247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod._shared_loader_obj.module_loader.has_plugin('ansible.legacy.service') == True
    assert action_mod._shared_loader_obj.module_loader.has_plugin('ansible.legacy.systemd') == True

# Generated at 2022-06-11 12:13:56.803287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        mod = ActionModule()
        assert mod.TRANSFERS_FILES == False
        tmp = '/var/tmp'
        task_vars = {}
        result = mod.run(tmp, task_vars)
        assert result['ansible_facts']['ansible_service_mgr'], 'systemd'
    except Exception as err:
        assert False, "ActionModule is throwing exception"

# Generated at 2022-06-11 12:13:57.616876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:13:58.121873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:14:03.894173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_source, m_parent_task, m_task, m_task_vars = Mock(), Mock(), Mock(), Mock()
    m_task.async_val, m_task.delegate_to = True, "localhost"
    m_task.args, m_task.module_defaults, m_task._parent = {'use': 'auto'}, Mock(), Mock()
    m_task._parent._play = Mock()
    m_task._parent._play._action_groups = Mock()
    m_task_vars.module_loader.has_plugin.return_value = True
    m_task_vars.module_loader.find_plugin_with_context.return_value = Mock()

# Generated at 2022-06-11 12:14:14.313669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the arguments
    module = ActionModule()
    tmp = None
    task_vars = {}
    task_vars['ansible_facts'] = {}
    task_vars['ansible_facts']['service_mgr'] = 'auto'
    task_vars['ansible_facts']['ansible_service_mgr'] = 'auto'
    module._task.args = {'name': 'ntp', 'use': 'auto'}
    module._task.delegate_to = None
    module._task.async_val = False

    # Execute the run function
    result = module.run(tmp, task_vars)
    assert result['skipped'] == False

# Generated at 2022-06-11 12:14:26.091707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case #1: default behavior
    #   ActionModule.run() should run module `ansible.legacy/service`
    #   if no module argument is provided
    #
    # Expected result:
    #   ActionModule.run() should return a dict object containing the
    #   following key:
    #       - module_stderr
    #       - module_stdout
    #
    # HACK:
    #   - Create a temporary global `args` dict object before executing
    #     ActionModule.run()
    #
    args = {}
    setattr(ActionModule, '_shared_loader_obj',
            {
                'module_loader': {
                    'has_plugin': lambda x: True
                }
            }
    )

# Generated at 2022-06-11 12:14:36.737239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = dict()
    mock_task['args'] = dict()
    mock_task['args']['use'] = 'auto'
    mock_task['args']['name'] = 'apache2'
    mock_task['args']['state'] = 'started'
    mock_task['delegate_to'] = 'ubuntu01'
    mock_connection = dict()
    mock_shared_loader_obj = dict()
    mock_shared_loader_obj['module_loader'] = dict()
    mock_shared_loader_obj['module_loader']['has_plugin'] = lambda a: True
    mock_task['async_val'] = True

# Generated at 2022-06-11 12:14:47.044527
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import json
    import os
    import sys

    # Make sure we use the right ansible module path
    ansible_src = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))), 'lib', 'ansible')
    sys.path.insert(1, ansible_src)

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    from ansible.vars.manager import VariableManager

    playbook = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'service.yml')
    loader = DataLoader()

# Generated at 2022-06-11 12:14:57.028712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test ActionModule()")

    task = Task(module_defaults={}, action_defaults={})
    host = MD5Host("127.0.0.1")

    action = ActionModule(task, host, connection=None)
    assert action

    task = Task(module_defaults={}, action_defaults={'use': 'auto'})
    host = MD5Host("127.0.0.1")
    action = ActionModule(task, host, connection=None)
    assert action

    task = Task(module_defaults={}, action_defaults={'use': 'auto', 'name': 'foo', 'state': 'restarted'})
    host = MD5Host("127.0.0.1")
    action = ActionModule(task, host, connection=None)
    assert action



# Generated at 2022-06-11 12:15:14.545309
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    task_vars = dict()
    result = dict(skipped=False)
    from ansible.executor.task_result import TaskResult
    task_result = TaskResult(task=None, host=None, result=result)
    obj = ActionModule()
    obj.task_vars = task_vars
    obj._supports_check_mode = True
    obj._supports_async = True
    obj._task = dict(args=dict())
    obj._shared_loader_obj = None
    obj._display = None
    obj._templar = None
    obj._task_vars = dict()
    obj._task_vars['ansible_facts'] = dict(service_mgr='auto')
    obj._task.args = dict()
    obj._task.delegate_to = None
    obj._task

# Generated at 2022-06-11 12:15:17.059789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {}
    tmp = {}
    task_vars = {}
    am = ActionModule(None, module_args, tmp, task_vars)
    assert am is not None

# Generated at 2022-06-11 12:15:19.080729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fail = False
    try:
        p = ActionModule()
        fail = True
    except Exception:
        pass
    assert fail == False


# Generated at 2022-06-11 12:15:20.222999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_obj = ActionModule(connection=None, task_vars=dict())

# Generated at 2022-06-11 12:15:21.046858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)

# Generated at 2022-06-11 12:15:24.861458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    import ansible.playbook.task

    # Make sure the object is constructed properly
    actionmod = ansible.plugins.action.ActionModule(ansible.playbook.task.Task(), dict())
    assert actionmod is not None

# Generated at 2022-06-11 12:15:27.486013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-11 12:15:37.247025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # First test with a task with a 'use' option
    task = {
        'args': {
            'use': 'service',
            'name': 'httpd',
            'state': 'started'
        },
        'delegate_to': 'localhost',
        'async': 57
    }
    actionmodule = ActionModule(task=task, connection='', play_context={}, loader=None, templar=None, shared_loader_obj=None)
    assert actionmodule._task.async_val == 57
    assert actionmodule.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}

# Generated at 2022-06-11 12:15:46.320011
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:15:51.354658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # module_name is loaded from ansible.modules.system.service
    module_name = 'service'
    args = {'name':'sshd', 'state':'started'}
    task_vars = {}
    

    # Ensure that we can load the correct action plugin
    action_plugin = action.ActionModule(
        task=dict(args=args),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    results = action_plugin.run(task_vars=task_vars)
    assert results['action'] == module_name

# Generated at 2022-06-11 12:16:14.538641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(AnsibleAction, match='Could not detect which service manager to use. Try gathering facts or setting the "use" option.'):
        am = ActionModule(load_fixture('service_auto'), task_vars={})
        am._task_vars = {
            'ansible_facts': {
                'service_mgr': 'auto',
            },
        }
        am.run(tmp=None, task_vars={})

    # test for special handling of openwrt_init when module name is `auto`
    am = ActionModule(load_fixture('service_auto'), task_vars={})
    am._task_vars = {
        'ansible_facts': {
            'service_mgr': 'openwrt_init',
        },
    }
    result = am.run

# Generated at 2022-06-11 12:16:15.117914
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:16:17.639260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Constructor of ActionModule is called inside constructor of ActionBase
    #Hence constructor of ActionModule cannot be tested seperately
    #This is a blank test to keep the constructor of ActionModule intact
    assert True

# Generated at 2022-06-11 12:16:28.337271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test ActionModule
    module = AnsibleModule(argument_spec=dict(
                        pattern=dict(default="*"),
                        sleep=dict(default=0, type='int'),
                        enabled=dict(type='bool', default=False),
                        use=dict(default="auto"),
                        state=dict(default="started", choices=["started", "stopped", "restarted", "reloaded", "absent"]),
                        name=dict(),
                        argument=dict(aliases=["arguments", "args"]),
    ))


# Generated at 2022-06-11 12:16:38.666879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp_loader = DictDataLoader({})
    temp_inventory = InventoryManager(loader=temp_loader, sources=[])
    temp_variable_manager = VariableManager(loader=temp_loader, inventory=temp_inventory)
    temp_play_context = PlayContext()
    temp_play_context.network_os = 'default'
    temp_play_context._restriction = ['all']


# Generated at 2022-06-11 12:16:45.448160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_instance = ActionModule()
    module_name = 'ansible.legacy.' + 'auto'
    result = ActionModule_instance._execute_module(
        module_name=module_name,
        module_args={"filter": 'ansible_service_mgr'},
        task_vars={"ansible_service_mgr": "upstart"},
        wrap_async=False)
    assert result['ansible_facts']['ansible_service_mgr'] == "upstart"

# Generated at 2022-06-11 12:16:56.377760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.systemd as systemd
    import ansible.plugins.action.sysvinit as sysvinit
    import ansible.plugins.action.service as service
    import ansible.modules.system.service as module_service
    import ansible.modules.system.systemd as module_systemd
    import ansible.modules.system.sysvinit as module_sysvinit
    import ansible.plugins.action as action

    assert systemd.ActionModule.UNUSED_PARAMS['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']
    assert sysvinit.ActionModule.UNUSED_PARAMS['sysvinit'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']
    assert service.ActionModule.UNUSED_PARAMS['service'] == []

# Generated at 2022-06-11 12:17:05.778108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    tmp_dir = "/tmp/ansible"
    module_name = "ansible.legacy.copy"
    module_args = {"dest": "/tmp/foo", "content": "hello world"}
    args_files = {}
    task_vars = {}
    inject = {}
    result = am.run(tmp_dir, task_vars)
    assert(result == {'changed': False, 'invocation': {"module_args": {"content": "hello world", "dest": "/tmp/foo"}}, 'module_name': "ansible.legacy.copy"})

# Generated at 2022-06-11 12:17:06.737593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(dict(A='B'))

# Generated at 2022-06-11 12:17:17.724681
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:17:46.816384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(load_module_spec=False, task_name='action module test name', task_args=dict())
    assert isinstance(m, ActionModule)

# Generated at 2022-06-11 12:17:51.513525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Configure the values we expect to see in the module instance
    task_args = dict()
    task_args['use'] = 'auto'
    task = dict()
    task['args'] = task_args

    action = ActionModule()
    action._task = task
    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 12:17:54.874615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.action_version == 1.0
    assert am.uses_filesystem is False
    assert am.uses_templating is False
    assert am.uses_delegation is False

# Generated at 2022-06-11 12:17:55.656307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:18:05.567849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create dummy args.
    args = dict(use='auto')

    # Create an instance of action module using dummy args
    am = ActionModule()

    # Create dummy task.
    task = dict(args=args)

    # Create instance of class action plugin
    ap = ActionBase()
    ap._task = task
    ap._shared_loader_obj = dict(module_loader=dict(has_plugin=lambda x: True))

    # Set connection plugin to ap
    am._connection = ap

    # Set display to ap
    am._display = ap

    # Set executer plugin to ap
    am._execute_module = ap

    # Set loader plugin to ap
    am._loader = ap

    # Create dummy tmp_path.
    tmp_path = dict(remote_conn=dict(tmpdir=None))

    # Create instance of class

# Generated at 2022-06-11 12:18:14.795584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test checks that the ActionModule class constructor works correctly. These
    checks include using the ActionModule class as a context manager and
    instantiating an instance of the class.
    """

    import sys
    import contextlib

    # Test that ActionModule works as a context manager
    try:
        obj = ActionModule()
        with contextlib.closing(obj):
            assert True
    except:
        assert False

    # Test that ActionModule raises a TypeError if not a context manager
    if sys.version_info >= (3, 0):
        with contextlib.closing(ActionModule()):
            try:
                obj = ActionModule()
                obj.__enter__()
                obj.__exit__()
                obj.__exit__()
                assert False
            except TypeError:
                assert True
            except:
                assert False

# Generated at 2022-06-11 12:18:25.736989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    task = Task()
    task._role = None
    task._role_params = None
    task.args = {'use': 'auto'}
    task.async_val = None
    task.notify = []
    task.when = []
    task.loop = None
    task.delegate_to = None

    task_queue_manager = TaskQueueManager()

    action_module = ActionModule(task, task_queue_manager.shared_loader_obj)

    import ansible.plugins.connection.connection_loader as connection_loader
    connection_loader.load()
    connection = connection_loader.get('local', task.delegate_to)


# Generated at 2022-06-11 12:18:27.816181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 12:18:37.854398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {
        "ansible_check_mode": True,
        "ansible_connection": "network_cli",
        "ansible_network_os": "iosxr",
        "ansible_facts": {
            "service_mgr": "auto"
        }
    }

    module = "auto"
    task_vars["ansible_facts"]["service_mgr"] = module
    facts = {
        "ansible_facts": {
            "ansible_service_mgr": "auto"
        },
        "changed": False
    }
    actionModule = ActionModule(tmp, task_vars)
    result = actionModule.run(tmp, task_vars)

    assert result["changed"] == facts["changed"]
    assert result["ansible_facts"]

# Generated at 2022-06-11 12:18:38.522592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:19:29.458384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make an instance of ActionModule class
    x = ActionModule()

# Generated at 2022-06-11 12:19:38.124607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible
    import ansible.constants as C
    import ansible.module_utils.basic
    mock_task_t = ansible.module_utils.basic.AnsibleTask(
        tmp=C.DEFAULT_LOCAL_TMP,
        task_vars={}
    )
    mock_task = ansible.playbook.task.Task()
    mock_task._ds = dict(action='service')
    mock_task._parent = mock_task_t
    mock_action = ansible.plugins.action.ActionModule(mock_task, connection='local', play_context = dict(), loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(mock_action, ActionModule) is True

# Generated at 2022-06-11 12:19:48.325549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test the run() method of class ActionModule
    '''

    class Task(object):
        pass
    
    class ModuleLoader(object):
        def has_plugin(self, name):
            return name == 'test.test'
    
    class Display(object):
        def warning(self, message):
            return None
    
    #Create an instance of ActionModule
    am = ActionModule()
    
    #Create an instance of Shell
    shell = Shell()
    
    #Create an instance of Connection
    class Connection(object):
        pass
    connection = Connection()
    connection._shell = shell
    
    #Create an instance of VarManager
    vm = VarManager()
    
    #Create an instance of Task and add attributes to it
    task = Task()
    task.async_val = 2
   

# Generated at 2022-06-11 12:19:52.217894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test when no params where given
    action_module = ActionModule(dict())
    assert action_module.TRANSFERS_FILES == False

    # Test for when module was given
    action_module = ActionModule(dict(use='expect'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:20:01.266226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup module and arguments
    module = ActionModule({'use': 'auto', 'name': 'foo'}, {}, {'succeeded': True, 'changed': True, 'msg': 'ok'}, '/', '', '')

    # Test 'system' manager
    # Positive case:
    # Setup module and arguments
    module = ActionModule({'use': 'system', 'name': 'foo'}, {}, {'succeeded': True, 'changed': True, 'msg': 'ok'}, '/', '', '')
    assert module.run() == {'succeeded': True, 'changed': True, 'msg': 'ok'}
    # Negative case:
    # Setup module and arguments

# Generated at 2022-06-11 12:20:01.830786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:20:10.969912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import copy
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    mock_loader = DictDataLoader({
        "test.yml": """
        - hosts: localhost
          tasks:
            - name: test
              service:
                name: "{{service_name}}"
        """,
    })

    mock_inventory = InventoryManager(
        loader=mock_loader,
        sources=['test.yml']
    )

    mock_variablemanager = VariableManager

# Generated at 2022-06-11 12:20:13.068799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None)
    assert mod._supports_check_mode is True
    assert mod._supports_async is True

# Generated at 2022-06-11 12:20:16.174077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()

    try:
        actionModule.run(tmp=None, task_vars=None)
    except:
        pass

# Generated at 2022-06-11 12:20:22.609500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object using the mock class
    mock_templar = mock.MagicMock()
    mock_shared_loader_obj = mock.MagicMock()
    mock_display = mock.MagicMock()
    mock_task = mock.MagicMock()
    mock_connection = mock.MagicMock()

    # Create an instance of MyClass
    module = ActionModule(
        mock_templar, mock_shared_loader_obj, mock_display, mock_task, mock_connection
    )

    assert isinstance(module, ActionModule)

    module.run(
        tmp = None, task_vars = None
    )

# Generated at 2022-06-11 12:22:56.157606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # Just test if the method is defined
    result = module.run()

    assert result

# Generated at 2022-06-11 12:22:57.420383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(payload=dict(args=dict()))

# Generated at 2022-06-11 12:22:58.588442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Unit test functionality
    #
    return True

# Generated at 2022-06-11 12:23:06.407280
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:23:07.091116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:23:10.448630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:23:20.476012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import mock
    import sys
    sys.modules["ansible.legacy.service"] = mock.Mock()
    actionBase = mock.Mock()
    # mock the ActionBase class

    sys.modules["ansible.plugins.action.ActionBase"] = actionBase

    loaderObj = mock.Mock()
    sys.modules["ansible.plugins.loader.ActionModule"] = loaderObj
    from ansible.plugins.action.service import ActionModule
    actionModule = ActionModule()

    object = mock.Mock()
    setattr( actionBase, "run", object )
    # mock the run method of ActionBase class

    result = mock.Mock()
    setattr( object, "run", result )
    # mock the result of method run of class ActionBase

    # case when module is equal to 'auto

# Generated at 2022-06-11 12:23:21.325321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:23:25.682555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test ActionModule.run() """
    AM = ActionModule('config.cfg', 'script', 'ansible_connection', 'localhost', '10.0.2.15', 123, 'root', 'ansible_password')
    assert AM.run(tmp=None, task_vars=None) == {}

# Generated at 2022-06-11 12:23:36.338423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import sys
    import os
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_text
    from ansible.plugins.loader import action_loader

    localhost = 'localhost'
    action_module_instance = action_loader.get('service', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    loader = DataLoader()
    variable_manager = VariableManager()