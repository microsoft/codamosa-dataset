

# Generated at 2022-06-11 12:13:45.493191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert action_module

# Generated at 2022-06-11 12:13:47.735197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule """
    module = ActionModule(None, None, None)
    module.run()
    module.BUILTIN_SVC_MGR_MODULES
    module.UNUSED_PARAMS

# Generated at 2022-06-11 12:13:51.694434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule
    action = ActionModule(
        task=dict(args=dict(state="present", name="python3-babel")),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action

# Generated at 2022-06-11 12:13:52.583705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # FIXME

# Generated at 2022-06-11 12:13:55.145556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp_dir = "/tmp"
    task_vars = {}
    result = action_module.run(tmp_dir,task_vars)


# Generated at 2022-06-11 12:13:57.263915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-11 12:14:03.468476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test function for the run method of the class ActionModule
    
    :return:
    '''

    # Init testing environment
    import sys
    import os
    import pytest
    test_config_path = os.path.dirname(os.path.dirname(os.path.realpath(__file__))) + os.sep + os.sep + 'testing_configuration.yml'
    if not os.path.exists(test_config_path):
        test_config_path = os.getcwd() + os.sep + 'testing_configuration.yml'
        if not os.path.exists(test_config_path):
            print('Error: no configuration file for test')
            sys.exit()

    # Get configuration for test
    import yaml

# Generated at 2022-06-11 12:14:15.095944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils._text import to_bytes
    import json
    import unittest

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self._task = MockTask()
            self._connection = MockConnection()
            self._shared_loader_obj = MockPluginLoader()
            self._task.async_val = 10
            self._task.args = {
                'name': 'test_name',
                'state': 'test_state',
                'use': 'test_use'
            }
            self._templar = MockTemplar()
            self._display = MockDisplay()


# Generated at 2022-06-11 12:14:16.232033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-11 12:14:27.312666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys, os
    import json
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase

    class MockTask(object):
        def __init__(self, args):
            self.args = args
            self._parent = self

        @property
        def async_val(self):
            return False

        @property
        def no_log(self):
            return False


# Generated at 2022-06-11 12:14:42.879034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # verify class variable
    assert(action_module.TRANSFERS_FILES == False)
    assert(action_module.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']})
    assert(action_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit']))

# Generated at 2022-06-11 12:14:43.817058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:14:51.247322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test fixture
    mock_task_vars = {'service': {'changed': False, 'failed': True, 'msg': 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.'}}
    mock_task = MagicMock()
    mock_task.args = {'name': 'testService', 'state': 'started'}

    mock_task.delegate_to = None
    mock_task.async_val = None

    # Build ActionModule object to test
    action_module = ActionModule(mock_task, None)
    assert action_module is not None

    # Unit test for run method
    # Expected: run method will return a result and in task_vars, 'service' will have {'changed': False, 'failed': True, 'msg': 'Could not detect which service manager

# Generated at 2022-06-11 12:15:02.232238
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Setup connection_loader mock object
    class ConnectionLoaderMock(object):
        def __init__(self):
            return
    connection_loader_mock_obj = ConnectionLoaderMock()

    results = dict()

    # Setup action_loader mock object
    class ActionLoaderMock(object):
        def __init__(self):
            return

        def get(self, name, *args, **kwargs):
            class ActionMock():
                def __init__(self):
                    return

                def run(self, conn, tmp, task_vars, *args, **kwargs):
                    return
            return ActionMock()

# Generated at 2022-06-11 12:15:04.228141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize object of class ActionModule
    obj = ActionModule()
    # Test method run for class ActionModule
    assert True

# Generated at 2022-06-11 12:15:15.262760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _get_command_params(module):
        if module == 'ansible.posix.service':
            command_params = {
                'service': 'haproxy',
                'state': 'stopped',
            }
        elif module == 'ansible.posix.systemd':
            command_params = {
                'name': 'haproxy',
                'state': 'stopped',
            }
        elif module == 'ansible.posix.sysvinit':
            command_params = {
                'name': 'haproxy',
                'state': 'stopped',
            }
        else:
            command_params = {
                'name': 'haproxy',
                'state': 'stopped',
            }
        return command_params
    from ansible.playbook.task import Task

# Generated at 2022-06-11 12:15:17.208795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_class = ActionModule(
        task=dict(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module_class

# Generated at 2022-06-11 12:15:18.191049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # write test case here
    pass

# Generated at 2022-06-11 12:15:19.660251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None)
    assert not module.run(None, None)


# Generated at 2022-06-11 12:15:27.072641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._shared_loader_obj.module_loader.has_plugin = lambda a, b: True
    module._execute_module = lambda a, b: b
    module._templar.template = lambda a: 'systemd'
    module._task.args = {'use': 'auto'}
    module._task.delegate_to = ''
    module._task.async_val = None
    module._task._parent._play._action_groups = {'install': {}}
    module._task.module_defaults = {}

    assert module.run() == {'use': 'systemd'}

# Generated at 2022-06-11 12:15:43.755284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with the minimal required arguments
    assert ActionModule(
        task=dict(args=dict()),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-11 12:15:50.824394
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:16:01.113630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts import Facts
    from ansible_galaxy.models.role_metadata import RoleMetadata
    from ansible_galaxy.models.repository_spec import RepositorySpec
    from ansible_galaxy.models.collection import Collection
    from ansible_galaxy.models.collection_artifact import CollectionArtifact
    from ansible_galaxy.models.install_galaxy_collections_data import InstallGalaxyCollectionsData
    from ansible_galaxy.models.collection_artifact_file import CollectionArtifactFile
    from ansible_galaxy.models.installed_repository_spec import InstalledRepositorySpec
    from ansible_galaxy.models.installed_repository_requirement import InstalledRepositoryRequirement

# Generated at 2022-06-11 12:16:12.301195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unit.loader as loader
    import unit.mock_runner as runner

    # create a mock task
    task = loader.load('./unit/fixtures/playbook-tasks/service.yml')

    host = runner.MockRunner(
        task=task,
        connection=runner.MockConnection(),
    ).get_host_manager().get_host(task.hostname)

    am = ActionModule(task=task, connection=host.get_connection())

    assert hasattr(am, '_supports_check_mode')
    assert hasattr(am, '_supports_async')
    assert hasattr(am, '_connection')
    assert hasattr(am, '_task')
    assert hasattr(am, '_loader')
    assert hasattr(am, '_templar')
   

# Generated at 2022-06-11 12:16:15.467737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = AnsibleModule(argument_spec={})
  action_module = ActionModule(task=module, connection=module, play_context=module, loader=module, templar=module, shared_loader_obj=module)
  action_module.run()

# Generated at 2022-06-11 12:16:16.359456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-11 12:16:26.567838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {'use': 'auto', 'state': 'started'}
    task_vars = {}
    tmp = 'test_ActionModule'

    import json

    mock_display = 'mock_display'
    mock_task = 'mock_task'
    mock_connection = 'mock_connection'
    mock_task_vars = 'mock_task_vars'
    mock_tmp = 'mock_tmp'
    mock_shared_loader_obj = 'mock_shared_loader_obj'
    mock_templar = 'mock_templar'


# Generated at 2022-06-11 12:16:37.134791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.service_mgrs import ServiceMgrFactCollector

    tmp = None
    task_vars = None
    obj = ActionModule(task_vars)
    obj.VERSION = "2.9"

    obj._task = "TestTask"
    obj._shared_loader_obj = "TestSharedLoaderObject"
    obj._display = "TestDisplay"
    obj._task.args = {"use": "auto"}
    obj._task.module_defaults = {}
    obj._task.delegate_to = "TestDelegateTo"
    obj._task.action = "TestAction"
    obj._task.async_val = "TestAsyncVal"
    obj._task._parent = "TestParent"
    obj._task._parent._play = "TestPlay"
    obj._

# Generated at 2022-06-11 12:16:47.730588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule

    mock_templar = {}
    mock_plugins = {}
    mock_loader = {}
    mock_task = {}

    # fake _execute_module
    def execute_module(module_name, module_args, task_vars, wrap_async):
        print(module_name)
        print(module_args)
        print(task_vars)
        print(wrap_async)

    # fake _display.debug
    def debug(msg):
        print(msg)

    # fake _display.warning
    def warning(msg):
        print(msg)

    # fake _display.vvvv
    def vvvv(msg):
        print(msg)

    # fake _remove_tmp_path

# Generated at 2022-06-11 12:16:48.679319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run()

# Generated at 2022-06-11 12:17:24.089949
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:17:33.636159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule.
    '''
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_text

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager.set_inventory(inventory)

    task = Task()
    task_vars = dict()

    print(ActionModule(task, connection=None, play_context=None, loader=loader, templar=None, shared_loader_obj=None))

# Generated at 2022-06-11 12:17:37.641436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._shared_loader_obj = object
    action_module._connection = object
    action_module._task = object
    action_module._task.args = dict()
    action_module._task.async_val = True
    action_module._task.delegate_to = ""
    action_module._task._parent._play._action_groups = []
    action_module._task.module_defaults = dict()
    action_module.run()

# Generated at 2022-06-11 12:17:46.984680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor without any parameters
    """
    # Num of tasks
    num_task = 1
    # Num of delegates
    num_delegate = 1
    # Num of tasks that runs async
    num_async = 0
    # Num of tasks that has become
    num_become = 0
    # Num of tasks that uses a template
    num_template = 0
    # Num of tasks that has a loop
    num_loop = 0
    # Num of tasks that has a role
    num_role = 0
    # Num of tasks that has a rescue
    num_rescue = 0

    # Initialize the action module object
    action_obj = ActionModule()

    # Initialize the result
    result = {}
    # Test action module object's constructor with valid and invalid parameters

# Generated at 2022-06-11 12:17:57.720981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiation of the class ActionModule is needed for testing.
    result = {}
    module = 'ansible.legacy.setup'
    module_args = {'gather_subset': '!all', 'filter': 'ansible_service_mgr'}
    task_vars = {'ansible_service_mgr': 'auto'}

    from ansible.plugins.action.service import ActionModule
    am = ActionModule()
    am._task.async_val = False
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    import os

    # To avoid error in the instantiation, some attributes need to be set
    am._shared_loader_obj = TaskQueueManager._load_ansible_config()
    am._shared_loader_obj.module_

# Generated at 2022-06-11 12:17:58.289800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:17:59.564729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert type(action_module) == ActionModule

# Generated at 2022-06-11 12:18:03.915338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test class constructor for ActionModule"""

    # Create a new instance of class ActionModule with 'auto' service manager
    action_module = ActionModule({'use': 'auto'},{},{})

    # Check the result
    assert action_module._task.args.get('use','auto') == 'auto'

# Generated at 2022-06-11 12:18:04.575189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:18:14.071634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_spec = {
        'run_once': True,
        'service_state': True,
        'service': True,
        'name': True,
        '_raw_params': True,
    }

    def ansible_module_args(name, **kwargs):
        def ansible_module_args_(self):
            return {}
        setattr(ansible_module_args_, '__name__', name)
        return ansible_module_args_

    # TODO: check args
    mock_task = dict(name='test_service', args=dict(name='test', async_val=1))
    mock_self = mock_loader = mock_shared_loader_obj = mock_templar = mock_display = mock_connection = None
    mock_tmp = 'testtmp'
    mock_task_v

# Generated at 2022-06-11 12:19:14.611624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Mock task and action_plugin, to execute the code
    mock_task = MagicMock()
    mock_connection = MagicMock()

    action_plugin = ActionModule(task=mock_task, connection=mock_connection, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Method to run result, method to execute the code
    result = action_plugin.run(task_vars=None)

    # We expect to return True
    assert result == {'_ansible_module_generated': True, '_ansible_no_log': True, '_ansible_verbose_always': True, '_ansible_version': '2.9.7'}

# Generated at 2022-06-11 12:19:24.257895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader_obj = DataLoader()
    test_vars = {'hostvars': { 'host1': {'ansible_facts': {'service_mgr': 'auto'} } }}
    inventory_obj = InventoryManager(loader=loader_obj, sources=[])
    variable_manager_obj = VariableManager(loader=loader_obj, inventory=inventory_obj)
    playbook_obj = Play().load('test/integration/targets/pipelining.yml', variable_manager=variable_manager_obj, loader=loader_obj)

# Generated at 2022-06-11 12:19:28.060255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None,None,None,None,None,None)
    assert am is not None
    return am

if __name__ == '__main__':
    am = test_ActionModule()    
    print("***** Module name: " + am.__class__.__name__ + " *****")

# Generated at 2022-06-11 12:19:30.283814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    #Test success
    am.run(tmp = None, task_vars = None)


# Generated at 2022-06-11 12:19:39.623154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import ast


# Generated at 2022-06-11 12:19:49.807239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Playbook

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager
    from ansible.context import CLIContext

    config = dict(defaults=dict(fact_caching=dict(foo='bar')))
    ctx = CLIContext(config=config)

    inventory = InventoryManager(loader=None, sources=None, context=ctx)
    variable_manager = VariableManager(loader=None, inventory=inventory)


# Generated at 2022-06-11 12:19:59.357464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for class ActionModule '''
    # pylint: disable=attribute-defined-outside-init
    # HACK: AnsibleAction.__init__() takes no parameters so we need to use this hack to set the class attributes
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    m = ActionModule()
    m.task = Task()
    m.task._parent = Block()
    m.task._parent._play = PlayContext()
    m.task._parent._play._play = PlayContext()
    m.task._parent._play._play._ds = dict()

# Generated at 2022-06-11 12:20:04.525403
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = dict(name=['openresty'], state='reloaded')
    action = ActionModule(task_args=task_args)

    action._play_context = dict(forks=10)

    server = dict(address='127.0.0.1', port=22, user='root', password='pwd')
    task_vars = dict(ansible_ssh_user=server.get('user'), ansible_ssh_pass=server.get('password'), ansible_ssh_host=server.get('address'), ansible_ssh_port=server.get('port'))

    action.setup(task_vars=task_vars)
    action.run(task_vars=task_vars)

# Generated at 2022-06-11 12:20:13.707615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture_path = os.path.join(
        os.path.dirname(__file__),
        'fixtures')
    module_name = 'service'
    test_env = dict(
        ANSIBLE_CONFIG={'config_file': 'ansible.cfg'},
        ANSIBLE_LIBRARY=fixture_path,
        )
    with patch.dict(os.environ, test_env):
        os.mkdir(fixture_path)
        with open(os.path.join(fixture_path, '__init__.py'), 'w') as f:
            f.write('')

# Generated at 2022-06-11 12:20:22.972888
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create a mock task, and mock the `args` for get_action_args_with_defaults()
    my_task = mock.Mock(args={'use': 'auto', 'name': 'foo', 'enabled': 'yes', 'sleep': 1})

    # create a mock context, and mock the `resolved_fqcn` for get_action_args_with_defaults()
    my_context = mock.Mock(resolved_fqcn='test.test_file')

    # constructor
    my_action = ActionModule(my_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # mock `_execute_module()` for get_action_args_with_defaults()
    my_action._execute_module = mock.Mock()

# Generated at 2022-06-11 12:23:06.516819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    __ansible_action__ = 'service'
    __ansible_action_args__ = {'name': 'httpd', 'state': 'started', 'use': 'sysvinit', 'pattern': 'httpd', 'enabled': True}
    __ansible_action_args__ = {'name': 'httpd', 'state': 'started', 'use': 'sysvinit', 'pattern': 'httpd', 'enabled': True}
    __ansible_action_args__ = {'name': 'httpd', 'state': 'started', 'use': 'sysvinit', 'pattern': 'httpd', 'enabled': True}

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-11 12:23:16.602184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    template1 = dict()
    template2 = dict()
    template2['pattern'] = 'httpd'
    template2['name'] = 'httpd'
    template2['runlevel'] = '3'
    template2['sleep'] = '3'
    template2['arguments'] = 'arg1 arg2'
    template2['args'] = 'arg1 arg2'

    # test case 1: module = 'auto', facts['ansible_service_mgr'] = 'systemd'
    task = dict()
    task['args'] = template1.copy()
    myaction = ActionModule(task, 'connection', 'play', loader=None, templar=None, shared_loader_obj=None)
    myaction.set_runner_facts({'ansible_facts': {'service_mgr': 'systemd'}})


# Generated at 2022-06-11 12:23:17.293185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:23:18.210074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-11 12:23:24.453073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    actions = [
        'enable',
        'disable',
        'is_enabled',
        'start',
        'stop',
        'restart',
        'reload',
        'restarted'
    ]
    assert action._supports_async == True
    assert action._supports_check_mode == True
    assert action._supports_async == True

# Generated at 2022-06-11 12:23:27.296333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module_obj

# Generated at 2022-06-11 12:23:28.691226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    b = ActionModule()
    assert b

# Generated at 2022-06-11 12:23:38.708439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule._remove_tmp_path = Mock(return_value=None)
    ActionModule._display = Mock()
    ActionModule._display.display = Mock(return_value=None)
    ActionModule._task = Mock()
    ActionModule._task.args = {'use': 'auto'}
    ActionModule._templar = Mock()
    ActionModule._templar.template = Mock(return_value='auto')
    ActionModule._execute_module = Mock(return_value={"ansible_facts": {"ansible_service_mgr": "auto"}})
    ActionModule._shared_loader_obj = Mock()
    ActionModule._shared_loader_obj.module_loader = Mock()
    ActionModule._shared_loader_obj.module_loader.has_plugin = Mock(return_value=True)