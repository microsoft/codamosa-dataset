

# Generated at 2022-06-11 12:13:55.031806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock environment that simulates the return of the module setup
    mock_task = MagicMock()
    mock_shared_loader_obj = MagicMock()
    mock_task.args = {'name': 'httpd'}
    mock_task.async_val = 5
    mock_task._parent._play._action_groups = ['setup']
    mock_task._parent._play._action_groups = ['setup']
    mock_task.module_defaults = {}
    mock_task.delegate_to = None
    mock_task._parent._play.basedir = 'dir'

    mock_executor = MagicMock()
    mock_executor.module_name = 'service'
    mock_executor.module_args = {'name': 'httpd'}

# Generated at 2022-06-11 12:14:02.188871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = mock.Mock()
    task.args = {'name': 'httpd', 'state': 'started'}

    # create a mock shared loader obj
    shared_loader_obj = mock.Mock()

    # create a mock AnsibleModule obj
    ansible_module_cls = mock.Mock()
    ansible_module_cls.run.return_value = (0, '', '')
    ansible_module_cls.params = {}
    ansible_module_cls.fail_json.return_value = (1, '', '')

    # create a mock Executor
    executor = mock.Mock()

    # create a mock TaskExecutor
    task_executor = mock.Mock()
    task_executor.get_plugin_loader.return_value

# Generated at 2022-06-11 12:14:12.998373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play_context
    import ansible.playbook.task_include
    import ansible.playbook.block
    import ansible.playbook.handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import ansible.cli.adhoc
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.inventory.host
    import ansible.vars.hostvars
    import ansible.parsing.vault

    # Create basic objects
    variable_manager = VariableManager()
    loader = ansible.plugins.loader.ActionModuleLoader(variable_manager)

# Generated at 2022-06-11 12:14:22.922795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_vars = {"ansible_facts": {"service_mgr": "auto"}}
    host_vars['ansible_service_mgr'] = "auto"
    action_module = ActionModule()
    action_module._task = []
    action_module._task.args = {"use": "auto"}
    action_module._task.delegate_to = None
    action_module._task.async_val = False
    task_vars = {}
    task_vars['hostvars'] = host_vars
    result = action_module.run(None, task_vars)
    assert result

# Generated at 2022-06-11 12:14:27.775366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Just a simple test of ActionModule to get test coverage up a bit
    action_mod = ActionModule(
        task=dict(action=dict(module_name='ansible.legacy.service', module_args=dict(name='foo'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_mod is not None

# Generated at 2022-06-11 12:14:39.223664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import os
    import unittest

    from ansible.plugins.action import ActionBase
    from ansible.executor.module_common import get_action_args_with_defaults

    class TestActionModule(ActionBase):
        def run(self, tmp, task_vars):
            return {}

    a = TestActionModule(task=dict(action='setup'), connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    assert a._task.action == 'setup'

    # Test with bogus src
    orig_load_file = ActionBase._load_file

# Generated at 2022-06-11 12:14:40.772444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None)
    assert am is not None

# Generated at 2022-06-11 12:14:49.526743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    unit test for constructor of class ActionModule
    :return:
    '''
    import unittest
    import ansible.plugins.action.service
    from ansible.module_utils._text import to_text
    from ansible.playbook.play_context import PlayContext

    class Test_ActionModule(unittest.TestCase):
        def setUp(self):
            self.play_context = PlayContext()
            self.play_context.remote_addr = '192.168.1.1'
            self.play_context.remote_user = 'root'
            self.play_context.connection = 'local'
            self.included_path = None
            self.included_deps = None
            self.cache_engine_name = None
            self.cache_plugin_name = None


# Generated at 2022-06-11 12:14:50.820858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # File action_module.py, line 3
    assert False



# Generated at 2022-06-11 12:14:54.689201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' constructor of class ActionModule'''
    # Test action_module
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-11 12:15:02.757468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule.run(None)
    assert t is not None


# Generated at 2022-06-11 12:15:03.774175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 12:15:14.922842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from io import StringIO
    import yaml
    import json
    import pytest
    import sys
    # Ansible returns byte strings in Py2 and unicode strings in Py3.
    if sys.version_info[0] < 3:
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

    class MockTask(Task):
        def __init__(self, *args, **kwargs):
            super(MockTask, self).__init__(*args, **kwargs)


# Generated at 2022-06-11 12:15:15.507942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:15:16.110083
# Unit test for constructor of class ActionModule
def test_ActionModule():
   return ActionModule

# Generated at 2022-06-11 12:15:22.894748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    Test_ActionBase = ActionBase()
    Test_ActionBase.task = Test_task()
    Test_ActionBase.task.async_val = False
    Test_ActionBase.task.args = {}
    Test_ActionBase._supports_check_mode = True
    Test_ActionBase._supports_async = True
    Test_ActionBase._execute_module_return = {"result":"success"}
    Test_ActionBase._remove_tmp_path_return = True

    m = ActionModule()
    m.run(tmp='',task_vars='')
    m.run(tmp='',task_vars='')
    m.run(tmp='',task_vars='')

# Generated at 2022-06-11 12:15:25.853962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m_action = ActionModule(load_module_spec=False)
    assert isinstance(m_action, ActionModule)
    # methods:
    assert hasattr(m_action, "run")


# Generated at 2022-06-11 12:15:35.887845
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module._supports_check_mode == True
    assert module._supports_async == True

    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.TRANSFERS_FILES == False

    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}


# Generated at 2022-06-11 12:15:45.125875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a task
    task_source = dict(action=dict(__ansible_module__='ansible.legacy.setup', __ansible_arguments__={'gather_subset': '!all', 'filter': 'ansible_service_mgr'}))
    task = Task.load(task_source, None, PlayContext())

    # Create a connection
    connection_source = dict(connection='local')
    connection = Connection(connection_source, task)

    # Initialize ActionModule
    action = ActionModule(task, connection, '.', play_context=PlayContext())
    task.action = 'setup'
    task.connection

# Generated at 2022-06-11 12:15:52.371293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up mocked values
    _mocked_self = MagicMock()
    _mocked_self._task = dict()
    _mocked_self._task.args = dict()
    _mocked_self._task.args['use'] = 'auto'
    _mocked_self._task.delegate_to = 'test-delegate'
    _mocked_self._templar = dict()
    _mocked_self._templar.template = MagicMock()
    _mocked_self._templar.template.return_value = 'auto'
    _mocked_self._display = dict()
    _mocked_self._display.debug = MagicMock()
    _mocked_self._execute_module = MagicMock()
    _mocked_self._shared_loader_obj = dict()
    _

# Generated at 2022-06-11 12:16:09.013323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(ANSIBLE_MODULE_UTILS='C:\\Users\\tungr\\AppData\\Local\\Temp\\ansible_modlib.zip'), task=('test_task'))
    assert am is not None

# Generated at 2022-06-11 12:16:18.318732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.network
    from ansible.module_utils.connection import Connection
    from ansible.plugins.action import ActionBase

    class ObjConnection(Connection):
        pass

    class ObjActionBase(ActionBase):

        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

        def run(self, tmp=None, task_vars=None):
            m = {'changed': False, 'failed': False, 'rc': 0}

# Generated at 2022-06-11 12:16:29.191186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_module_args = {'use': 'auto'}

    # Replace the tmpdir with a fake one
    monkeypatch.setattr(ActionModule, "_remove_tmp_path", lambda x, y: None)

    # create a fake connection to use
    import ansible.plugins.connection
    fake_connection = ansible.plugins.connection.network_cli.Connection(
        None,
        os.path.join(os.path.dirname(__file__), 'fake_connection.py'),
        runner=None
    )

    # create a fake connection to use
    monkeypatch.setattr(ActionModule, "run", lambda x, y: {'ansible_facts': {'service_mgr': 'auto'}})

# Generated at 2022-06-11 12:16:39.445231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.compat.tests.mock import patch

    module = 'ansible.plugins.action.service'

    with patch('%s.ActionBase._execute_module' % module, return_value=dict(FAILED=False, rc=0)):
        action = ActionModule(task=dict(action=dict(service=dict(args=dict()))))
        action.run(task_vars=dict(ansible_facts=dict(service_mgr='auto')))
        assert action.run(task_vars=dict(ansible_facts=dict(service_mgr='auto')))['module_name'] == 'ansible.legacy.service'

    with patch('%s.ActionBase._execute_module' % module, return_value=dict(FAILED=False, rc=0)):
        action = Action

# Generated at 2022-06-11 12:16:40.527270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)

# Generated at 2022-06-11 12:16:51.434853
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:16:58.833853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_class = ActionModule()

    # It should have the following attributes
    assert test_class._task.args.get('use') == 'auto'
    assert test_class.TRANSFERS_FILES == False
    assert test_class.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert test_class.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}

# Generated at 2022-06-11 12:17:02.449615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor ActionModule
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-11 12:17:12.868132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModule(object):
        pass
    task = ActionModule()
    task.args = {'use': 'auto'}
    task.async_val = '2'
    task.delegate_to = 'ansible'
    executor = ActionModule()
    executor.loader = 'yes'
    my_act_mod = ActionModule()
    my_act_mod.task = task
    my_act_mod._execute_module = 'y'
    my_act_mod._connection = 'ansible'
    my_act_mod._task = task
    my_act_mod._shared_loader_obj = executor
    my_act_mod._templar = 'yes'
    my_act_mod._display = 'yes'

    test_var = {'service_mgr': 'auto'}
   

# Generated at 2022-06-11 12:17:13.706134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:17:41.746180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule')
    print('ActionModule object created')

# Generated at 2022-06-11 12:17:45.424874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

# Generated at 2022-06-11 12:17:55.928365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import pytest

    from ansible.module_utils.six import StringIO

    from units.mock.path import mock_unfrackpath_noop
    from units.mock.procenv import clear_common_env_vars, patch_common_env_vars
    from units.mock.vars import MockVars


# Generated at 2022-06-11 12:17:56.547253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-11 12:18:05.342678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__name__ == 'ActionModule'
    assert ActionModule.__doc__ == 'Provides a preset ansible module that is capable of performing multiple operations.'

    assert ActionModule.TRANSFERS_FILES == False

    expected_unused_params = {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert ActionModule.UNUSED_PARAMS == expected_unused_params

    expected_builtin_service_mgr_modules = set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert ActionModule.BUILTIN_SVC_MGR_MODULES == expected_builtin_service_mgr_modules

# Generated at 2022-06-11 12:18:12.887690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner = ActionModule(
        task = dict(
            args = dict(use = 'auto')
        ),
        connection = dict(
            _shell = dict(
                tmpdir = "tmp"
            )
        )
    )

    result = runner.run(task_vars=dict(
        ansible_facts = dict(
            service_mgr = "auto"
        )
    ))

    assert('ansible_facts' in result)
    assert('ansible_service_mgr' in result['ansible_facts'])

    assert('failed' in result)
    assert(result['failed'] == False)

# Generated at 2022-06-11 12:18:18.785111
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test for various service manager modules

    for module in ['systemd', 'sysvinit']:
        m = ActionModule()
        m._task.args = {'use': module}
        assert(m._task.args.get('use', 'auto').lower() == module)
        assert(m.run({}, {}))

    # test for 'auto' service manager

    facts = {
        'ansible_service_mgr': 'systemd',
    }

    m = ActionModule()
    m._task.args = {'use': 'auto'}
    assert(m._task.args.get('use', 'auto').lower() == 'auto')
    assert(m.run({}, {'ansible_facts': facts}))

    # test for invalid service manager

    m = ActionModule()

# Generated at 2022-06-11 12:18:29.887980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {'pattern': 'sshd', 'runlevel': 'default', 'sleep': '1', 'arguments': 'stop', 'args': 'stop'}
    result = {
        'stdout': '',
        'stdout_lines': [],
        'changed': True,
        'cmd': 'chkconfig sshd off',
        'rc': 0,
        'stderr': '',
        'stderr_lines': []
    }
    action_module = ActionModule(connection=None, distro=None, no_log=False, loader=None, play_context=None, new_stdin=None, in_data=None, module_compression=None, task_uuid=None, check_mode=False, diff=False, ansible_version=None)

# Generated at 2022-06-11 12:18:30.491636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:18:34.741343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create object for class ActionModule
    test_obj = ActionModule(
        task = DummyTask(), connection = DummyConnection(), play_context = DummyPlayContext(),
        loader = DummyLoader(), templar = DummyTemplar(), shared_loader_obj = None
    )

    # Test the run method
    test_obj.run()

# Generated at 2022-06-11 12:19:34.046344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initializing test values
    task_args = {'name': 'ansible-apache'}
    ansible_facts = {
        'service_mgr': 'service',
    }
    task_vars = dict(ansible_facts=ansible_facts)

    # Creating the MockActionModule object
    # This is a dummy object set as a model for this class
    # This object does not have the method run, so it raises an AttributeError
    mock_action_module = ActionModule()

    # Trying to create an instance of ActionModule: fails
    try:
        # This line will raise an AttributeError
        action_module = ActionModule(mock_task, connection, play_context, loader, templar, shared_loader_obj)
    except Exception as e:
        assert type(e) == AttributeError

    #

# Generated at 2022-06-11 12:19:36.793396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(loader=None, task=None, connection=None, play_context=None, shared_loader_obj=None, action_plugin=None)
    assert module is not None


# Generated at 2022-06-11 12:19:46.991593
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set up a class instance object without calling the constructor
    class MyActionModule1(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    my_action_module1 = MyActionModule1()
    my_action_module1.transfers_files = False

    # call method run with arguments
    try:
        my_action_module1.run(tmp='test_tmp', task_vars='test_task_vars')
    except Exception as e:
        assert(False)

    # set up a class instance object without calling the constructor
    class MyActionModule2(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    my_action_module2 = MyActionModule2()
    my_action_module2.transfers

# Generated at 2022-06-11 12:19:49.888413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor for Action Module
    action_mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:19:55.857779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=unused-argument
    am = ActionModule(None, {}, {}, None)
    assert am.BUILTIN_SVC_MGR_MODULES == {'systemd', 'sysvinit', 'openwrt_init', 'service'}
    assert am.UNUSED_PARAMS['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']
    assert am.TRANSFERS_FILES is False

# Generated at 2022-06-11 12:20:03.367870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    import pytest
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.stats import AggregateStats
    from ansible.module_utils.remote_management.common.network import RemoteModule
    from ansible.module_utils._text import to_text
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.connection.netconf import Connection as NetconfConnection
    from ansible.plugins.loader import find_plugin
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-11 12:20:05.441269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None)
    assert am is not None

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:20:15.566293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec = dict(
            pattern = dict(default='*'),
            runlevel = dict(default='default'),
            sleep = dict(default='none')
        )
    )
    module.check_mode = True
    del module.params['ANSIBLE_CHECK_MODE']
    del module.params['ANSIBLE_MODULE_ARGS']
    del module.params['ANSIBLE_MODULE_RETVALS']
    del module.params['ANSIBLE_MODULE_CONSTANTS']
    del module.params['ANSIBLE_MODULE_SRC']
    del module.params['ANSIBLE_MODULE_NAME']
    del module.params['ANSIBLE_MODULE_ARGS']
    del module.params['ANSIBLE_MODULE_SRC']

# Generated at 2022-06-11 12:20:19.399545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert x.__dict__['_shared_loader_obj'] == shared_loader_obj

# Generated at 2022-06-11 12:20:28.053539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.strategy import StrategyBase

    class TestCallback(CallbackBase):
        def __init__(self):
            self.callback_commands = {}
            super(TestCallback, self).__init__()

        def v2_runner_on_ok(self, result):
            host = result._host.get_name()
            self.callback_commands[host] = result._result['stdout']

    loader = DataLoader()
    c = TestCallback()

# Generated at 2022-06-11 12:23:02.223337
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(True)
    action._shared_loader_obj.module_loader.has_plugin('ansible.legacy.service') == True

# Generated at 2022-06-11 12:23:06.523026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import fragment_loader, collect_all_string_fragments

    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

# Generated at 2022-06-11 12:23:07.773872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert (t.TRANSFERS_FILES == False)

# Generated at 2022-06-11 12:23:17.951300
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Stub
    class StubModule(ActionBase):
        class StubResult:
            def __init__(self, module_name):
                self.module_name = module_name

            def update(module_name):
                pass

        # Stubbed method to retrieve module name
        def get_name_from_file(module_name):
            return module_name

    class ActionModule(StubModule):
        def run(self, tmp=None, task_vars=None):
            # Stubbed method to get module name
            if self._task.args.get('use', 'auto').lower() == 'auto':
                module = 'ansible.legacy.setup'
            else:
                module = 'ansible.legacy.service'

            # Stubbed method to execute the module
            result = self.StubResult(module)
           

# Generated at 2022-06-11 12:23:18.509747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:23:19.897128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This function will be used to test ActionModule class constructor using pytest.
    pass

# Generated at 2022-06-11 12:23:30.654038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = DummyTask()
    action_module = ActionModule(_task, DummyConnection())
    action_module._display.verbosity = 99
    action_module._templar = DummyTemplar()
    action_module._templar.template = lambda x: x
    action_module._shared_loader_obj.module_loader.has_plugin = lambda x: True
    action_module._execute_module = lambda *a, **b: {'module_call': a, 'module_vars': b}

# Generated at 2022-06-11 12:23:33.007562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # args = dict(
    #     name='foo',
    #     enabled=None,
    #     state='started',
    # )
    pass

# Generated at 2022-06-11 12:23:34.117088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO
    pass

# Generated at 2022-06-11 12:23:42.594193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import PluginLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    a = ActionModule(
        task=Task(),
        connection=None,
        play_context=None,
        loader=PluginLoader(),
        shared_loader_obj=PluginLoader(),
        final_q=None,
        loader_cache=None,
        templar=None,
        class_vars=None,
        task_vars=None,
        task_executor=TaskExecutor(),
        worker_process=WorkerProcess()
    )
    assert a