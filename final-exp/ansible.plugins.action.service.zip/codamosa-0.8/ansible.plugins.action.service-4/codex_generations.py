

# Generated at 2022-06-11 12:13:51.890909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check instantiation
    am = ActionModule(
        task=dict(action="service", async_val="async_val",
                  args=dict(use='auto', pattern="pattern",
                            runlevel="runlevel", sleep="sleep"),
                  async_val="async_val",
                  delegate_to='delegate',
                  delegate_facts=True
                  ),
        connection="connection", play_context=dict(check_mode=True),
        loader=dict(action_plugins=["action1", "action2"]),
        templar=dict(), shared_loader_obj="shared"
    )
    assert am.task.action == "service"
    assert am.task.async_val == "async_val"
    assert am.task.args.get("use") == "auto"
    assert am.task.args

# Generated at 2022-06-11 12:13:59.935827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up
    mock_task = {}
    mock_shared_loader_obj = {}
    action_module = ActionModule(mock_task, mock_shared_loader_obj)
    action_module._display = {}
    action_module._templar = {}
    action_module._connection = {}
    action_module._connection._shell = {}
    action_module._connection._shell.tmpdir = "tmpdir"
    action_module._task = mock_task
    action_module._task.args = {"use": "auto"}
    action_module._task.async_val = False
    action_module._task._parent = {}
    action_module._task._parent._play = {}
    action_module._task._parent._play._action_groups = "action_groups"

# Generated at 2022-06-11 12:14:00.303936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:14:01.937572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    invocation = {}
    result = {}

    # Create an ActionModule and call run
    actmod = ActionModule(invocation, result)
    actmod.run(tmp='tmp', task_vars='task_vars')

# Generated at 2022-06-11 12:14:02.785437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise Exception("Not implemented yet")

# Generated at 2022-06-11 12:14:07.638633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import MockCollectionLoader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    am = ActionModule(None, {}, {}, None)
    assert am is not None

# Generated at 2022-06-11 12:14:14.139787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule
    am.TRANSFERS_FILES = False
    am.UNUSED_PARAMS = {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    am.BUILTIN_SVC_MGR_MODULES = set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-11 12:14:25.969803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None, None, None, None)

    BUILTIN_SVC_MGR_MODULES_mock = set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

    # Check that the run function is called
    module_run_mock = MagicMock()
    def mock_run(self, tmp=None, task_vars=None):
        module_run_mock()

    with patch.object(ActionModule, 'run', mock_run):
        module.run()
        module_run_mock.assert_called_once()

    # Check that the _execute_module function is called
    execute_module_mock = MagicMock()

# Generated at 2022-06-11 12:14:28.197017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import collections
    module = ActionModule(collections.namedtuple('Task', ['args'])({'name': 'FIXME'}))
    assert isinstance(module, ActionModule)

# Generated at 2022-06-11 12:14:31.219257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task_vars=dict(service_mgr='systemd'))
    assert isinstance(action, object)
    assert isinstance(action, ActionBase)


# Generated at 2022-06-11 12:14:48.020591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_iterator import PlayIterator
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    pb = Playbook()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    iterator = PlayIterator(pb, play_context, loader, variable_manager, None)


# Generated at 2022-06-11 12:14:48.726703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:14:59.338894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    import ansible.constants
    import tempfile
    import shutil
    import sys
    import os

    script_path = os.path.dirname(os.path.realpath(__file__))

    ansible.constants.HOST_KEY_CHECKING = False
    ansible.constants.DEFAULT_HASH_BEHAVIOUR = "merge"

    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-11 12:15:00.387682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:15:11.253836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock ansible.module_utils.basic.AnsibleModule
    mock_ansible_module = Mock(spec_set=['get_bin_path'])
    # mock module_utils.basic.get_bin_path method
    mock_ansible_module.get_bin_path.side_effect = [(0, '/usr/bin/python2.6')]
    # mock ansible.plugins.action.ActionBase
    mock_action_base = Mock(spec_set=['run'])
    # mock ansible.plugins.action.ActionBase.run method
    mock_action_base.run.side_effect = [{
        'changed': True,
        'ansible_facts': {
            'service_mgr': 'service'
        }
    }]
    # mock ansible.plugins.action.Handler
   

# Generated at 2022-06-11 12:15:20.795988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile

    temp_dir_name = tempfile.mkdtemp()
    temp_file_name = 'temp_file'
    temp_script_name = 'temp_script'
    temp_script_file_name = 'temp_script_file'
    temp_file = temp_dir_name + '/' + temp_file_name
    ansible_facts = temp_dir_name + '/ansible_facts'
    temp_script = temp_dir_name + '/' + temp_script_name
    temp_script_file = temp_dir_name + '/' + temp_script_file_name

    # create files
    with open(temp_file, 'w') as temp_file_obj:
        temp_file_obj.write('some_text')

# Generated at 2022-06-11 12:15:22.961883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)

    assert action_module.TRANSFERS_FILES == False



# Generated at 2022-06-11 12:15:33.225549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = dict(ansible_facts = dict(service_mgr = 'service'))
    args = dict(name = 'httpd', state = 'started', enabled = True)
    task = dict(args = args, async_val = False)
    action = dict(use = 'auto', delegate_to = 'localhost')
    tmp = None
    result = dict()

    action_module = ActionModule()
    action_module._task = action_module._templar.template(task)
    action_module._task.args = action_module._task.args.copy()
    action_module._task.args.update(action)
    action_module._shared_loader_obj.module_loader.has_plugin = lambda module: True if module in ['service', 'ansible.legacy.service'] else False
    action_module._

# Generated at 2022-06-11 12:15:34.184271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run action module
    """
    pass

# Generated at 2022-06-11 12:15:36.498395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-11 12:15:52.376918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:16:02.941016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.local_objects import AnsibleVars
    import ansible.plugins.action
    import ansible.plugins.action.service
    import ansible.plugins.action.systemd
    from ansible.executor.task_result import TaskResult

    inventory = ansible.inventory.Inventory()

    action_module = ansible.plugins.action.service.ActionModule(
        task=ansible.playbook.task.Task(),
        connection=ansible.playbook.conditional.Conditional(),
        play_context=ansible.playbook.play.PlayContext(),
        loader=None,
        templar=ansible.template.AnsibleTemplar(),
        shared_loader_obj=None
    )

    # Note: mock instance `action_module` only has method `run`.
    #       So it

# Generated at 2022-06-11 12:16:13.853148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create test context
    #####################
    from ansible.module_utils.facts.processor.service_mgr import ServiceMgrDetector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgr

    from ansible.plugins.loader import find_plugin

    from ansible.module_utils.facts import ansible_local

    # Create fake Ansible facts
    ###########################
    # Patch Ansible fact collector
    ############################

# Generated at 2022-06-11 12:16:18.082121
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert action_module, "Create ActionModule failed."
    assert isinstance(action_module.UNUSED_PARAMS, dict), "Create ActionModule failed."
    assert isinstance(action_module.BUILTIN_SVC_MGR_MODULES, set), "Create ActionModule failed."



# Generated at 2022-06-11 12:16:23.384795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    am = ActionModule(
        task=Task(),
        connection='local',
        play_context={},
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert am is not None

# Generated at 2022-06-11 12:16:28.286638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ## Just testing the method exists
    """Test run method of class ActionModule"""
    task_vars = dict()
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.run(task_vars=task_vars)

# Generated at 2022-06-11 12:16:29.348718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am

# Generated at 2022-06-11 12:16:30.432229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is ActionModule


# Generated at 2022-06-11 12:16:32.601323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actmod = ActionModule()
    assert isinstance(actmod, ActionBase) == True

# Test to check the function run.

# Generated at 2022-06-11 12:16:36.524756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert action.TRANSFERS_FILES is False
    assert action.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}

# Generated at 2022-06-11 12:17:11.832770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(
        ansible_service_mgr='auto',
        hostvars={
            'test1': {'ansible_facts': {'service_mgr': 'test2'}}
        }
    )
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    dl = DataLoader()
    inv = InventoryManager(loader=dl, sources='')
    vm = VariableManager(loader=dl, inventory=inv)


# Generated at 2022-06-11 12:17:16.770830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = ActionBase.conn_classes['local']()
    task = ActionBase.task_class()
    action_module = ActionModule(conn, task)

    # Setup for test case 1 when module is not auto.
    task.args = dict(name='Hello World', use='package')
    action_module.run()

# Generated at 2022-06-11 12:17:26.102142
# Unit test for constructor of class ActionModule
def test_ActionModule():    
    ansible_2_2_0 = dict(
        _ansible_version = '2.2.0.0',
        _ansible_no_log = False,
        _ansible_check_mode = False)
    ansible_2_6_0 = dict(
        _ansible_version = '2.6.0.0',
        _ansible_no_log = False,
        _ansible_check_mode = False)
    module_args = dict(
        name = 'httpd',
        state = 'started',
        use = 'auto')
    task = dict(
        action = dict(
            module = 'service',
            args = module_args))
    tmp = '/tmp'
    task_vars = dict()

    # Constructor should throw exception if _ansible_version is older than 2

# Generated at 2022-06-11 12:17:27.418866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    print(actionModule.run())

# Generated at 2022-06-11 12:17:29.143949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner=ActionModule()
    print(runner.run(tmp=None, task_vars=None))

# Generated at 2022-06-11 12:17:31.843670
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # instantiate object
    am = ActionModule()

    # #test run
    # assert am.run(tmp=None, task_vars=None) == 'Yay'

# Generated at 2022-06-11 12:17:40.809070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule class
    actionModule = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_style=None, templar=None, shared_loader_obj=None)
    # Get 'Transfers_Files'
    transfers_files = actionModule.TRANSFERS_FILES
    assert transfers_files == False
    # Get 'Unused_params'
    unused_params = actionModule.UNUSED_PARAMS
    assert unused_params == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    # Get 'Builtin_svc_mgr_modules'
    builtin_svc_mgr_modules = actionModule.BUILTIN_SVC_MGR_MODULES
    assert builtin_svc_

# Generated at 2022-06-11 12:17:50.841124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = dict(name="test-host", port=22)
    play_context = dict(
        become=False,
        become_method=None,
        become_user=None,
        diff=False,
        remote_addr="test-addr",
    )
    task_vars = {}
    connection = dict(
        connection="local",
        module_implementation_preferences="default",
        remote_addr="test-addr",
    )
    fake_loader = None
    templar = None
    display = None
    task = dict(
        args={
            "use": "auto",
        }
    )
    a = ActionModule(host, play_context, task_vars, connection, fake_loader, templar, display, task)
    assert a is not None

# Generated at 2022-06-11 12:17:51.986544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-11 12:17:55.072181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test run of class ActionModule
    '''
    module = AnsibleModule()
    m = ActionModule(module)
    assert m._task.args.get('use')=='auto'

# Generated at 2022-06-11 12:18:47.926014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

# Generated at 2022-06-11 12:18:49.178499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)

# Generated at 2022-06-11 12:18:49.699399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:18:50.275973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:18:52.734543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #
    # Interface exists.
    #
    #print("Interface exists.")
    assert(hasattr(ActionModule, 'run'))
    assert(callable(ActionModule.run))

# Generated at 2022-06-11 12:18:53.636602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass  # no return value to test

# Generated at 2022-06-11 12:19:03.765712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    class DummyTask(object):
        def __init__(self, delegate_to):
            self._parent = self
            self._play = self
            self._play._action_groups = dict()
            self.delegate_to = delegate_to
            self.args = dict()


    class DummyModuleLoader(object):
        def find_plugin_with_context(module, collection_list):
            raise 'not implemented'

        def has_plugin(module):
            return 'openwrt_init' == module


    class DummyTemplar(object):
        def template(text):
            return text

    class DummyModuleArgs(object):
        def copy():
            return self

    class DummyActionFail(object):
        def __init__(self, msg):
            self.result = dict()


# Generated at 2022-06-11 12:19:13.807871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task={
            'args': {
                'use': 'auto',
                'state': 'started',
                'name': 'cron'
            },
            'delegate_to': None,
            'module_defaults': None,
            'async_val': 1,
        },
        shared_loader_obj=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        task_vars=None
    )
    assert action._task.args.get('use') == 'auto'
    assert action._task.async_val == 1
    assert action.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])



# Generated at 2022-06-11 12:19:14.387966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 0

# Generated at 2022-06-11 12:19:24.082908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
#     # Generate arguments to instantiate class with
#     # Ref: https://www.pythonforbeginners.com/basics/python-dynamic-class-instantiation
#     import sys
#     from ansible.module_utils._text import to_text
#     from ansible.module_utils.common.collections import ImmutableDict
#     from ansible.module_utils.six import text_type
#     from ansible.parsing.plugin_docs import read_docstring
#     from ansible.playbook.play import Play
#     from ansible.playbook.task import Task
#     from ansible.plugins.loader import module_loader
#     from ansible.template import Templar
#     from ansible.vars import VariableManager
#     from ansible.module_utils.connection import Connection
#    

# Generated at 2022-06-11 12:21:56.306594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    class Task(object):
        async_val = False
        class ActionModule(object):
            args = {
                '_raw_params': 'service httpd',
                'use': 'auto',
                'name': 'httpd',
                'state': 'stopped'
            }
        class Connection(object):
            class Shell(object):
                tmpdir = 'tmp'
        _parent = ActionModule
        _play = ActionModule
        _task = ActionModule
        async_val = False

# Generated at 2022-06-11 12:22:00.976291
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_vars = dict(
        ansible_service_mgr='auto'
    )

    action_module = ActionModule()
    action_module._task_vars = task_vars

    assert action_module.run(task_vars=task_vars).get('changed', False) is True
    assert action_module.run(task_vars=task_vars).get('module_name') == 'ansible.legacy.service'

# Generated at 2022-06-11 12:22:08.158384
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock object of class ModuleLoader
    mock_shared_loader_obj = ModuleLoader()

    # Create a mock object of class TaskExecutor
    mock_task = MagicMock()
    mock_task.args = {'use': 'auto'}

    # Create a mock object of class AnsibleModule
    mock_action_base = AnsibleModule()

    # Create the instance of the object 'action_module' to be tested
    action_module = ActionModule(mock_task, mock_connection, mock_shared_loader_obj, mock_action_base._templar)

    # The 'run' method of class 'ActionModule' is called with the arguments tmp, task_vars and the mock object of class 'TaskExecutor'
    # Since the contents of modules are not tested the return value is False
    assert not action_module.run

# Generated at 2022-06-11 12:22:09.621235
# Unit test for constructor of class ActionModule
def test_ActionModule():
  try:
    action_module = ActionModule()
  except:
    assert False

  assert True

# Generated at 2022-06-11 12:22:19.941250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(
        task=dict(
            async_val=None,
            args=dict(
                name=dict(required=True),
                use='manage_service_salt',
                state='started',
                enabled='yes'
            ),
            async_timeout=None,
            connection='local',
            delegate_to=None,
            delegate_facts=None,
            environment=None,
            no_log=None,
            run_once=None
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_mod._supports_check_mode == True
    assert action_mod._supports_async == True
    assert action_mod.TRANSFERS

# Generated at 2022-06-11 12:22:20.568822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:22:23.581306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of Class ActionModule
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Make sure the result is not empty
    assert module != ''

# Generated at 2022-06-11 12:22:31.098197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=W0212,too-many-locals,too-many-statements
    # W0212: Access to a protected member of a client class
    # too-many-locals: for this testcase we need too many locals
    # too-many-statements: for this testcase we have too many statements
    import ansible.plugins
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_text

# Generated at 2022-06-11 12:22:39.517307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MyActionModule(ActionModule):
        def _exec_module(self, mod_args):
            return { 'stdout': 'ok' }

    task = dict(action=dict(service=dict(name='httpd', state='started')))
    # setup a class based on MyActionModule overriding the data members that we need
    class MyActionModuleInstance(MyActionModule):
        def __init__(self):
            self._task = task
        def run(self, *args, **kwargs):
            return super(MyActionModuleInstance, self).run(*args, **kwargs)

    am = MyActionModuleInstance()

# Generated at 2022-06-11 12:22:42.211214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   module = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict(name='test', state='absent')), MockTask())
   assert module._task.args['use'] == 'auto'