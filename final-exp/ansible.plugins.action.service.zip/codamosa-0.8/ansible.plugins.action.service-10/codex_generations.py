

# Generated at 2022-06-11 12:13:57.073555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.executor.task_executor import TaskExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.unsafe_proxy import SafeText

    # Build module_defaults
    module_defaults = {}
    module_defaults['listen_ip'] = '0.0.0.0'
    module_defaults['listen_port'] = '4001'
    module_defaults['my_var'] = 'hello'

    # Build action

# Generated at 2022-06-11 12:13:57.885155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()


# Generated at 2022-06-11 12:14:01.561809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.service import ActionModule
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True

# Generated at 2022-06-11 12:14:03.119987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, '/home/user/.ansible', 'somehost')
    assert action is not None

# Generated at 2022-06-11 12:14:09.241072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_class_instance=ActionModule('setup', '{"gather_subset":"!all","filter":"ansible_service_mgr"}', {'delegate_to': 'localhost'})
    result=ActionModule_class_instance.run(tmp=None, task_vars=None)
    assert result['failed'] is False
    assert result['module_args'] == 'ansible.legacy.setup'

# Generated at 2022-06-11 12:14:10.305884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:14:12.682522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()._supports_check_mode == True
    assert ActionModule()._supports_async == True


# Generated at 2022-06-11 12:14:24.906717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test case is to test the constructor, assuming the following lines in a playbook
    - name: "test svc mgr"
      service:
          name=crond
          state=restarted
      delegate_to: localhost

    """
    # create task
    mock_loader, datastore, _ = setup_loader()
    mock_loader.mock_module_loader({'ansible.legacy.setup': None})
    mock_loader.mock_module_loader({'ansible.legacy.service': None})
    mock_loader.module_loader.module_utils_loader = None

    task = Task()
    task.args = dict()
    task.args['name'] = 'crond'
    task.args['state'] = 'restarted'
    task.delegate_to = 'localhost'

   

# Generated at 2022-06-11 12:14:35.165875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_task_args = {
        'use': 'auto',
        'name': 'sshd',
        'state': 'restarted',
        'arguments': '',
        'pattern': '',
        'sleep': '',
        'runlevel': '',
        'args': '',
    }

    action_task_vars = {'ansible_facts': {'service_mgr': 'foo'}}
    action_task_module_defaults = {}
    display_ = DummyDisplay()
    templar_ = DummyTemplar()

    # Case 1: action_task_args - name of the module to invoke is set.
    #         asserting that it returns the correct module name.
    action_task_args_ = action_task_args.copy()

# Generated at 2022-06-11 12:14:46.009481
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:15:03.925970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._supports_check_mode = True
    module._supports_async = True
    module._task = object()
    module._task.args = {}
    module._task.delegate_to = None
    module._task.async_val = False
    module._connection = object()
    module._connection._shell = object()
    module._connection._shell.tmpdir = '/tmp'
    module._shared_loader_obj = object()
    module._shared_loader_obj.module_loader = object()
    module._shared_loader_obj.module_loader.has_plugin = lambda x: True
    module._shared_loader_obj.module_loader.find_plugin_with_context = lambda x, y: object()
    module._executor = object()
    module._executor.get_

# Generated at 2022-06-11 12:15:15.068466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.utils.vars import combine_vars

    options = {'use': 'auto'}

    task_vars = {
            'ansible_facts': {
                'ansible_service_mgr': 'systemd'
                }
            }

    task_vars.update(combine_vars(context.CLIARGS, None, options, True))

    am = ActionModule({'name': 'service', 'args': options }, None)

    result = am.run(None, task_vars)

    print(result)

    assert result['changed'] == True

    options = {'use': 'auto'}

    task_vars = {
            'ansible_facts': {
                'ansible_service_mgr': 'systemd'
                }
            }

# Generated at 2022-06-11 12:15:20.253261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init
    action_module = ActionModule(None, None)

    # Set vars
    tmp = '/tmp'
    task_vars = {'ansible_facts': {'service_mgr': 'auto'}}

    result = action_module.run(tmp, task_vars)

    # Remove vars
    del tmp
    del action_module
    del task_vars

    assert result['changed'] is True


# Generated at 2022-06-11 12:15:30.259126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.module_common import TaskParameters, get_action_args_with_defaults
    from ansible.module_utils.facts import FactCache
    from ansible.plugins.action.service import ActionModule
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    _task_parameters = TaskParameters(
        task_name='service',
        action='service',
        use='auto',
        delegate_to=None,
        delegate_facts=False,
        args={},
    )

    _task = MagicMock()
    _task.args = {}
    _task.action = 'service'
    _task.name = 'service'
    _task.async_val = None
    _task.loop = None
   

# Generated at 2022-06-11 12:15:31.633411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, {}, None, None, None, None, None)

# Generated at 2022-06-11 12:15:41.301891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = 'test1'
    options = {'start': True, 'enabled': False, 'use': 'auto' }
    service = 'foo'
    delegate_to = 'test2'

    mock_task = Mock()
    mock_task.args = options
    mock_task.delegate_to = delegate_to

    mock_display = Mock()
    mock_templar = Mock()
    mock_shared_loader = Mock()
    mock_connection = Mock()

    mock_connection._shell = Mock()
    mock_connection._shell.tmpdir = '/test/tmpdir'

    mock_lookup_loader = Mock()

    mock_module_loader = Mock()
    mock_module_loader.has_plugin.return_value = True

    mock_collection_loader = Mock()

    mock_shared_loader.lookup

# Generated at 2022-06-11 12:15:49.193348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import fragments_loader
    from ansible.vars.manager import VariableManager
    facts_d = dict(
        ansible_facts=dict(
            service_mgr='auto'
        )
    )
    vm = VariableManager(loader=fragments_loader, host_vars=dict(
        localhost=dict()
    ), fact_cache=dict(
        localhost=facts_d
    ))
    task = dict(
        args=dict(name='telnet', state='started', use='auto')
    )
    action = ActionModule(task, connection=None, play_context=None, loader=fragments_loader, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 12:15:59.890366
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # import required modules for this test
    import os
    import sys
    module_path = os.path.join(os.path.dirname(__file__), '..', '..', '..')
    sys.path.append(module_path)
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.service import ActionModule
    from ansible.plugins.loader import find_plugin

    # initial args parameters
    args = {'name': 'foo', 'use': 'auto'}

    # This is the way how we can mock class function's call
    # In this case we want to mock function get_action_args_with_defaults
    # We want to return our own parameters, so we use side_effect
    # We need to add our action_groups manually because we don't have access to ActionBase class


# Generated at 2022-06-11 12:16:00.947554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Works')



# Generated at 2022-06-11 12:16:12.110408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()


# Generated at 2022-06-11 12:16:36.094855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import unittest
    import ansible.errors
    import ansible.executor.play_context
    import ansible.playbook.play_context
    import ansible.playbook.task_include
    import ansible.template
    import ansible.utils.vars
    import ansible.vars.hostvars

    from ansible.plugins.action import ActionBase

    class FakeActionBase(ActionBase):
        task = None
        _shared_loader_obj = None
        _loader = None
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self.task = task
            self._connection = connection
            self._loader = loader
            self._shared_loader_obj = shared_loader_obj
            self._templar = templ

# Generated at 2022-06-11 12:16:38.206829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.service import ActionModule
    x = ActionModule()
    print(x)
test_ActionModule()

# Generated at 2022-06-11 12:16:45.826115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, "fakeargs", None, None, None)
    assert module.TRANSFERS_FILES == False
    assert module.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert module.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}
    assert isinstance(module.BUILTIN_SVC_MGR_MODULES, set)

# Generated at 2022-06-11 12:16:46.913976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 12:16:49.457461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None)
    assert a._supports_async == True
    assert a._supports_check_mode == True

# Generated at 2022-06-11 12:16:59.947941
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Constructing an ActionModule
    action_module = ActionModule(
        task=dict(action=dict(module_name='service', args=dict(name='filterprint', state='started'))),
        connection=None,
        play_context=dict(check_mode=False, diff=False),
        loader=dict(basedir='/home/ansible/playbooks'),
        templar=None,
        shared_loader_obj=None
    )

    # Constructing an ActionModule

# Generated at 2022-06-11 12:17:09.666540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    play_context = PlayContext()
    play_context._artifacts_dir = '/tmp/artifacts/'
    play_context._stdout_callback = 'default'
    task = Task()
    task._role = None
    task._parent = None
    task._play = None
    task._loader = None
    task._task_vars = {'ansible_artifacts_dir': '/tmp/artifacts/'}
    action_plugin = ActionModule(task, play_context, '/tmp/ansible_servicemodule', '/tmp/ansible_servicemodule', False)
    assert action_plugin._connection is not None
    assert action_plugin._task.async_val is False
    assert action_plugin._tem

# Generated at 2022-06-11 12:17:10.124108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(None, None)

# Generated at 2022-06-11 12:17:21.037202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrError
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action.service import ActionModule
    import unittest

    class MyActionModule(ActionModule):
        def _execute_module(self, *k, **kw):
            if self.module_name == 'ansible.legacy.setup':
                return ansible.legacy.setup(self)
            elif self.module_name == 'ansible.legacy.service':
                return ansible.legacy.service(self)
            elif self.module_name == 'ansible.legacy.service_without_use':
                return ansible

# Generated at 2022-06-11 12:17:30.524761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os, sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from Units.mock.loader import DictDataLoader
    from Units.mock.loader import DictDataLoader
    from Units.mock.paths import mock_unfrackpath_noop as mock_unfrackpath

    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        pass

    variable_manager = None
    loader

# Generated at 2022-06-11 12:18:06.091608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import copy
    import ansible.plugins.action
    from ansible.plugins.action.service import ActionModule
    import ansible.executor.task_result
    import ansible.executor.task_queue_manager

    test_result = ansible.executor.task_result.TaskResult()

    test_queue_manager = ansible.executor.task_queue_manager.TaskQueueManager(None, None, None, None, None)

    test_task = ansible.playbook.task.Task()
    test_task.action = 'service'
    test_task.args = 'enable'
    test_task.async_val = 300
    test_task.delegate_to = 'localhost'
    test_task.notify = ['test']
    test_task.run_once = True
    test

# Generated at 2022-06-11 12:18:15.174344
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:18:26.193955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def return_true(*args, **kwargs):
        return True
    
    def return_false(*args, **kwargs):
        return False
    
    _task = type('DummyTask', (object,), {
                        'async_val': return_true,
                        'async_seconds': return_false,
                        'args': {'use': 'auto'}})()
    _connection = type('DummyConnection', (object,), {})()
    _display = type('DummyDisplay', (object,), {})()
    _loader = type('DummyLoader', (object,), {})()
    _templar = type('DummyTemplar', (object,), {})()

# Generated at 2022-06-11 12:18:26.847048
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:18:37.040690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests.mock import patch
    from ansible.executor import module_common
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.module_utils.basic
    import os

    class TaskMock:

        def __init__(self):
            self.args = {'use': 'auto'}
            self._parent = PlayMock()
            self.async_val = None

    class PlayMock:

        def __init__(self):
            self._action_groups = {'group_name': 'action_name'}


# Generated at 2022-06-11 12:18:43.119823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(connection=None, task=None, loaders=[], play_context=None,
                          shared_loader_obj=None, templar=None,
                          all_vars=dict(), parameters=dict(), connection_loader=None,
                          loader=None, templar_loader=None,
                          action_loader=None, _ds=None,
                          _usage=None, connection_lock=None)
    assert action is not None


# Generated at 2022-06-11 12:18:46.330706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, connection=None, play_context=None, loader_object=None, templar=None, shared_loader_object=None)
    assert action_module is not None

# Generated at 2022-06-11 12:18:54.169183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This unit test is for testing method run of class ActionModule()
    args = dict(
        name='httpd',
        use='auto',
    )
    # Instantiate a class object of class ActionModule()
    obj = ActionModule(task=dict(args=args))
    # Execute method run() of class ActionModule()
    result = obj.run(tmp=None, task_vars=None)
    assert result == {'failed': False, 'changed': False, 'invocation': {'module_args': {'name': 'httpd', 'use': 'auto'}}, 'ansible_facts': {'ansible_service_mgr': 'systemd'}}

# Generated at 2022-06-11 12:18:54.897972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:19:04.868722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._shared_loader_obj = Fake(name='_shared_loader_obj')
    module._shared_loader_obj.module_loader.has_plugin = Fake(name='module_loader.has_plugin')
    module._shared_loader_obj.module_loader.has_plugin.side_effect = [True, False, False, True]
    module._execute_module = Fake(name='_execute_module')
    module._execute_module.side_effect = [{
        "ansible_facts": {
            "service_mgr": "openwrt_init"
        }
    }, {
        "ansible_facts": {
            "service_mgr": "auto"
        }
    }]
    module._task = Fake(name='_task')

# Generated at 2022-06-11 12:20:07.001350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = {}
    test_am = ActionModule()

    # Testing with positive test case
    test_am._task = {'args': {'use': 'auto'}, 'async_val': False}
    test_am.run(tmp='test', task_vars={'ansible_facts': {'service_mgr': 'systemd'}})

    # Testing with negative test case
    test_am._task = {'args': {'use': 'auto'}, 'async_val': False}
    test_am.run(tmp='test', task_vars={'ansible_facts': {}})

# Generated at 2022-06-11 12:20:17.646838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.community.plugins.module_utils.common.collections_loader import AnsibleCollectionLoader

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.plugins.loader import action_loader

    from ansible.vars import VariableManager

    loader = AnsibleCollectionLoader()

    variable_manager = VariableManager()
    variable_manager._extra_vars = {'ansible_service_mgr': 'auto'}
    variable_manager.set_inventory(
        VariableManager.set_inventory(loader.load_inventory('tests/ansible/inventory'))
    )

    cachet_dir = './tests/ansible/cachet'


# Generated at 2022-06-11 12:20:24.225537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as action
    import ansible.plugins.action.service as service

    # Create a mock of the class

    mock_result = {
        'result': '',
        'changed': False,
        'rc': 0,
    }

    mock_ansible_exit_exception = action.AnsibleExitJson(mock_result)


# Generated at 2022-06-11 12:20:31.390853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars_dict = {'hostvars': {'delegate_to': {'ansible_facts': {'service_mgr': 'auto'}}}}
    task_vars_dict = {'ansible_facts': {'service_mgr': 'auto'}, 'ansible_service_mgr': 'auto'}
    module_name = 'ansible.legacy.setup'
    module_args = {'filter': 'ansible_service_mgr', 'gather_subset': '!all'}

    # checking for method run with valid args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    tmp_path = "/tmp/ansible/test"
    result = action_module.run

# Generated at 2022-06-11 12:20:31.820702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:20:33.162743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('data', 'data')
    assert action_module


# Generated at 2022-06-11 12:20:40.718211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask:
        def __init__(self):
            self.async_val = False
            self.args = {'use': 'auto'}
    class MockPlay:
        def __init__(self):
            self._action_groups = {'test': []}
    class MockPlayContext:
        def __init__(self):
            self._play = MockPlay()
    class MockTaskExecutor:
        def __init__(self):
            self._play_context = MockPlayContext()
    class MockTaskQueueManager:
        def __init__(self):
            self._task_executor = MockTaskExecutor()

    am = ActionModule(task=MockTask(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.run

# Generated at 2022-06-11 12:20:41.178651
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:20:48.363425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    course_args = dict(
        use='auto',
        name='foo',
        state='started',
        enabled='yes'
    )

    # Mocks
    mock_task_executor_for_module = dict(
        async_val=True,
        async_timeout=300,
        wrap_async=True,
        delegate_to=None,
        ignore_errors=False,
        register=None,
        retries=3,
        delay=3
    )
    mock_task_name = 'foo'

# Generated at 2022-06-11 12:20:49.277006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_obj = ActionModule()
    assert my_obj is not None

# Generated at 2022-06-11 12:23:21.321893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shares={})
    assert module is not None

# Generated at 2022-06-11 12:23:31.696345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_connection = Mock()
    m_connection._shell = Mock()
    m_connection._shell.tmpdir = "/tmp/"
    # m_connection._shell.run = ""
    m_shared_loader_obj = Mock()
    m_shared_loader_obj.module_loader = Mock()
    m_shared_loader_obj.module_loader.has_plugin = Mock()

    m_task = Mock()
    m_task.args = {'use': 'auto'}
    m_task.delegate_to = None
    m_task._parent = Mock()
    m_task._parent._play = Mock()
    m_task.module_defaults = Mock()
    m_task._action_groups = []

    m_play_context = Mock()
    m_play_context.check_mode = False
    m

# Generated at 2022-06-11 12:23:41.421156
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.playbook.task import Task
    import ansible.utils.template
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    task_vars = dict()
    task_vars['ansible_system'] = 'Linux'