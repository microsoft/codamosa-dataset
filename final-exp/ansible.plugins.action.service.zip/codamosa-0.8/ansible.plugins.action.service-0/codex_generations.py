

# Generated at 2022-06-11 12:13:52.264365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiate module
    tmp = None
    task_vars = {'ansible_facts': {'service_mgr': 'auto'}}
    x = ActionModule(tmp, task_vars)

    # test method run
    tmp = None
    task_vars = {'ansible_facts': {'service_mgr': 'auto'}}
    result = x.run(tmp, task_vars)
    assert result['module_name'] == 'ansible.legacy.setup'

# Generated at 2022-06-11 12:13:54.475905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new object of ActionModule
    obj = ActionModule()
    # _execute_module method of ActionModule is tested in test_ansible_module.py
    obj._execute_module()

# Generated at 2022-06-11 12:14:00.921414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_facts=dict(
            service_mgr='something_else'
        )
    )
    mock_task = dict(
        async_val=False,
        args=dict(
            use='auto'),
        delegate_to='localhost',
        module_defaults=dict(),
        vars=task_vars
    )

    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, None)

    mod = ActionModule(tqm, mock_task)
    mod.run()
    assert mod._execute_module.called

# Generated at 2022-06-11 12:14:01.561714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Load module
    module = ActionModule()

# Generated at 2022-06-11 12:14:11.916334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    am = ActionModule(
            task = dict(args = dict(use = 'auto', name = 'nosuchservice')),
            connection = dict(transport = 'local'),
            task_vars = dict(ansible_service_mgr = 'systemd')
        )

    result = am.run(tmp='/tmp', task_vars=dict(ansible_facts = dict(service_mgr = 'blah'), hostvars = dict(other=dict(ansible_facts = dict(service_mgr = 'blah2')))))
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['ansible_facts']['ansible_service_mgr'] == 'ansible.legacy.service'


# Generated at 2022-06-11 12:14:24.296934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.template import Templar
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import UnsafeProxy

    options_fake = UnsafeProxy({'module_name': 'auto', 'module_defaults': {'foo': 'bar'}, 'no_log': False, 'run_once': False, 'async': True, 'async_timeout': 900, 'apply': {}})
    module_executor_fake = 'fake_module_executor'
    connection_fake = 'fake_connection'
    play_context_fake = PlayContext(become_method=None)

# Generated at 2022-06-11 12:14:34.291019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {
        'name': 1234,
        'use': 'auto'
    }

    task_vars = {
        'ansible_facts': {
            'service_mgr': 'WindowsPowerShell'
        }
    }

    task = TestTask()
    task.set_loader(TestLoader())
    action = ActionModule(task, TestConnection(), task_vars=task_vars)

    module = 'ansible.legacy.service'
    new_module_args = task_args.copy()
    if 'use' in new_module_args:
        del new_module_args['use']

    # get defaults for specific module

# Generated at 2022-06-11 12:14:45.277692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from units.mock.loader import DictDataLoader
    from ansible.plugins.loader import action_loader

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.utils.display import Display
    display = Display()

    service_manager_mock = ActionModule(
        task=dict(action=dict(service=dict())),
        connection=None,
        play_context=dict(),
        loader=DictDataLoader({}),
        templar=None,
        shared_loader_obj=None)

    loader = action_loader._create_action_

# Generated at 2022-06-11 12:14:54.011606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(None, None)
    assert isinstance(actionmodule.__dict__['UNUSED_PARAMS'], dict)
    assert actionmodule.__dict__['UNUSED_PARAMS']['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']
    assert actionmodule.__dict__['BUILTIN_SVC_MGR_MODULES'] == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert actionmodule.TRANSFERS_FILES == False
    assert actionmodule._supports_async == True
    assert actionmodule._supports_check_mode == True
    assert isinstance(actionmodule.run(None, None), dict)

# Generated at 2022-06-11 12:14:58.741749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module.run(tmp={'tmpdir': ''},
                             task_vars={'ansible_service_mgr': 'systemd'}) == {
                                 'ansible_facts': {'service_mgr': 'systemd'},
                                 'changed': False
                             }

# Generated at 2022-06-11 12:15:16.061141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            async_val=0,
            action=dict(module_defaults=dict()),
            args=dict(),
            async_val=50,
            delegate_to="localhost",
            environment=dict(),
            loop='None',
            loop_args=dict(),
            module_defaults=dict(),
            no_log=False,
            register='None',
            run_once=False,
            _uri_args=None,
            until='None'),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    assert module.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert module

# Generated at 2022-06-11 12:15:23.409938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up mocked arguments
    task_vars = {'ansible_facts': {'service_mgr': 'auto'}}

    # create a mock ActionBase
    mock_action = ActionBase()
    mock_action.loader = None
    mock_action.connection = None
    mock_action.task_vars = task_vars
    mock_action.shared_loader_obj = None

    # create a mock _task
    mock_task = type('', (), {})()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.async_val = None
    mock_task._parent = type('', (), {})()
    mock_task._parent._play = type('', (), {})()
    mock_task._parent._play._action_

# Generated at 2022-06-11 12:15:33.534139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    unit test for method run of class ActionModule
    '''

    class OptionsModule:
        '''
        class OptionsModule
        '''
        use = "auto"
        delegate_to = None

    class OptionsModuleDelegateTo:
        '''
        class OptionsModuleDelegateTo
        '''
        use = "auto"
        delegate_to = "remote"

    module_args = dict(name="git")
    module_args_noop = dict(name="git", state="noop")

    # ActionModule object instance

# Generated at 2022-06-11 12:15:42.882167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-11 12:15:46.356370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
            task=dict(
                action=dict(
                    module_name='service',
                    args=dict(
                        module='echo',
                        name='systemd',
                        use='setup'
                    )
                )
            )
        )
    assert action_module is not None

# Generated at 2022-06-11 12:15:47.146746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_action_module = ActionModule()

# Generated at 2022-06-11 12:15:49.193480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, ActionModule)

# Generated at 2022-06-11 12:15:59.889904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            module_defaults=dict(),
            args=dict(
                use='auto',
                name='foo',
                state='started',
            ),
            async_val=5,
            async_key=10,
        ),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    result = module.run()

# Generated at 2022-06-11 12:16:11.083630
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:16:19.014395
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    my_actionmodule = ActionModule()
    my_actionmodule.tmp = 'Ansible test tmp dir'
    my_actionmodule._task.args = {'name': 'cron'}
    result = my_actionmodule.run(tmp=None, task_vars=None)
    assert result['changed'] is False
    assert result['ansible_facts']['ansible_service_mgr'] == 'systemd'
    assert result['ansible_facts']['ansible_service_name'] == 'cron'
    assert result['ansible_facts']['ansible_service_state'] == 'activated'
    assert result['ansible_facts']['ansible_service_status'] == {'ActiveState': 'active'}

# Generated at 2022-06-11 12:16:26.156080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:16:36.803884
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Hack to get around the fact that we can't patch a class in a module
    class ActionModuleTest(ActionModule):

        def _execute_module(self, module_name, module_args, task_vars=None, wrap_async=False):
            return {
                'action_plugin': 'execute_module'
            }

    action_module = ActionModuleTest(
        task=dict(
            args=dict(
                name='httpd',
                state='running'
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    expected = {
        'action_plugin': 'execute_module'
    }


# Generated at 2022-06-11 12:16:47.360066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    class MockModule:
        def __init__(self, params):
            self.params = params


# Generated at 2022-06-11 12:16:58.133086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import base64
    from ansible.executor.process.result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.six import int2byte
    from ansible.module_utils._text import to_text
    from ansible_collections.ansible.legacy.plugins.action.service import ActionModule
    import mock
    import os
    import shutil
    import sys

    mock_task_result = mock.Mock(TaskResult)
    mock_task_queue_manager = mock.Mock(TaskQueueManager)
    mock_task_vars = {}
    mock_task_args = {'use': 'auto', 'name': 'httpd'}


# Generated at 2022-06-11 12:17:01.004326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 12:17:10.706827
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Dummy class for use as an object in our test
    class DummyClass(object):
        def __init__(self):
            self.args = dict()
            self.args['use'] = 'auto'
            self.async_val = False
            self.delegate_to = None
            self._parent = DummyClass()
            self.module_defaults = dict()
            self._play = DummyClass()
            self.collections = list()
            self._play._action_groups = dict()

    # Instantiate a dummy class for use as a task_vars object
    task_vars = DummyClass()

    # Instantiate a dummy class for use as a task object
    task = DummyClass()
    task_vars.task = task

    # Instantiate the class we are testing
    x = ActionModule

# Generated at 2022-06-11 12:17:12.357548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True, "No way to unit test the service module"

# Generated at 2022-06-11 12:17:19.693770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule(connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    assert t.TRANSFERS_FILES == False
    assert len(t.UNUSED_PARAMS) == 1
    assert len(t.BUILTIN_SVC_MGR_MODULES) == 4
    assert t.run(tmp=None, task_vars=None) == {}
    assert t.run(tmp=None, task_vars=None) == {}

# Generated at 2022-06-11 12:17:21.980994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # this is a unit test for method run of class ActionModule
    # check if it returns expected values
    m = ActionModule()
    assert m.run() == m.run()

# Generated at 2022-06-11 12:17:22.515062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:17:38.717616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ansible.plugins.action.ActionBase
    action_base = ActionBase()
    # Create an instance of ansible.plugins.action.ActionModule
    action_module = ActionModule()
    # Use the method from AnsibleActionBase
    # AnsibleActionBase.run(self, tmp=None, task_vars=None)
    result = action_base.run(
        tmp=None, 
        task_vars={'ansible_facts':{'service_mgr':'auto'}, 'ansible_service_mgr':'auto'}
    )
    # Test the result
    assert result == {}

# Generated at 2022-06-11 12:17:39.236656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-11 12:17:45.742282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Add dummy task to load the module
    module_utils = ansible.module_utils.basic.AnsibleModule
    module_utils._ANSIBLE_ARGS = None
    module_utils = imp.reload(module_utils)
    task = ansible.playbook.task.Task()
    task._role = None
    task._parent = None
    task._play = None
    task._loader = None
    task._block = None
    task._shared_loader_obj = None
    task._role = ansible.playbook.role.Role()
    task._role._role_path = os.path.abspath("/ansible/test/unit/files/role_test")
    task._role._role_name = "TestRole"

# Generated at 2022-06-11 12:17:55.512819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test to see if ActionModule class is initialized correctly
    '''
    connect_info = dict(paramiko=dict())
    class_obj = ActionModule(task=dict(args=dict(use='service')), connection=connect_info, play_context=dict(), loader=object(), templar=object(), shared_loader_obj=object())
    assert class_obj._connection == connect_info
    assert class_obj.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert class_obj.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }

# Generated at 2022-06-11 12:17:56.105603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:18:03.824187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(action=dict(module_name='shell', module_args=dict(arg1=3, arg2=4, arg3=5, arg4=6))),
        connection=dict(host=None, port=None, user=None, password=None, ssh_executable=None),
        play_context=dict(basedir=None, remote_addr=None, password=None, private_key_file=None, remote_user=None, module_defaults=None),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-11 12:18:13.485210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.plugins.loader as ploader
    import ansible.plugins.action as aaction
    import ansible.plugins.action.service as aservice

    ploader.add_directory(os.path.join(os.path.dirname(__file__), '../../plugins/action'))

    mytask = Task()
    mytask._role = None
    mytask.action = "service"
    mytask.args = dict(name="httpd", state="started")
    mytask._parent = PlaybookExecutor()

    play_context = PlayContext()
    mytask._play_context = play_context

    am

# Generated at 2022-06-11 12:18:24.063136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    skip = True
    if skip:
        return None

    import unittest
    class DummyModule(object):
        def run(self, tmp=None, task_vars=None):
            print("DummyModule  run called")

    class DummyTemplar(object):
        def template(self, string_to_template):
            print("DummyTemplar  template called")
            return "template result"

    class DummyTask(object):
        def __init__(self):
            self.args = {
                "use": "auto",
                "name": "nginx",
                "state": "started",
            }
            self.delegate_to = "localhost"
            self.async_val = False


# Generated at 2022-06-11 12:18:34.572980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_module_loader_has_plugin(module):
        if module == 'ansible.legacy.service' or module == 'ansible.legacy.systemd':
            return True
        else:
            return False

    class fact_retrival_exception(Exception):
        pass

    class AnsibleActionFail_exception(Exception):
        def __init__(self, message):
            self.result = {'failed': True, 'msg': message, 'module_stdout': '', 'module_stderr': ''}


# Generated at 2022-06-11 12:18:38.569168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert isinstance(action, ActionModule)



# Generated at 2022-06-11 12:18:53.207293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(False)

# Generated at 2022-06-11 12:18:55.349671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    module_name = action_module.run()
    print(module_name)

# test_ActionModule_run()

# Generated at 2022-06-11 12:18:56.553971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor should properly initialize the ActionModule class
    """
    assert ActionModule

# Generated at 2022-06-11 12:19:06.961855
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:19:07.653434
# Unit test for method run of class ActionModule
def test_ActionModule_run():  
    assert 1 != 1

# Generated at 2022-06-11 12:19:12.658477
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test1 = ActionModule(dict(), [], [])
    test1._shared_loader_obj = object()
    test1._templar = object()
    test1._task = object()
    test1._remove_tmp_path = lambda x: False
    test1._display = object()
    test1._task.args = {'use': 'auto'}
    test1._task.async_val = False
    test1._task.delegate_to = False
    test1._task._parent = object()
    test1._task._parent._play = object()
    test1._task._parent._play._action_groups = {}
    test1._task.module_defaults = {}

    def call_module_loader(module_name, *args, **kwargs):
        if module_name == 'auto':
            facts

# Generated at 2022-06-11 12:19:22.223122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initial setup
    import ansible_fake_plugins.action.service
    import ansible_runner
    import sys
    import os

    # Create a fake task object with default values
    task = ansible_runner.run(private_data_dir='private_data', playbook='playbook.yml', quiet=True)

    # Create a fake action module which will be called by the module under test
    # actions = fake_plugins.action_plugins
    # actions.ActionModule.run("module", "delegate_to", "async_val", tmp=None, task_vars=None)

    # Create an instance of the module under test

# Generated at 2022-06-11 12:19:31.882222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup connection to some host
    connection = Connection()

    # Setup a task and an action module for this task
    task_vars = dict()
    task_vars["ansible_facts_service_mgr"] = 'auto'
    task_vars["ansible_host"] = 'host'
    set_module_args(dict(
        name='foo',
        state='started',
        enabled=True,
        use='auto',
    ))

    # Test if the run method works for the action module
    action = ActionModule(connection, 'foo', {})
    assert action.run(connection._shell.tmpdir, task_vars=task_vars)["module_name"] == 'ansible.legacy.service'
    assert action.run(connection._shell.tmpdir, task_vars=task_vars)

# Generated at 2022-06-11 12:19:40.830526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Use simple params in task
    task_args = dict(
        name='httpd',
        state='restarted',
        enabled='yes',
        use='auto'
    )

    # Create a dictionary for ansible facts for the target host
    ansible_facts = dict(
        ansible_service_mgr='sysvinit',
        ansible_facts=dict(
            service_mgr='sysvinit'
        )
    )

    m = ActionModule(dict(name='service', args=task_args), dict(ANSIBLE_MODULE_ARGS=task_args, ANSIBLE_FACTS=ansible_facts))
    m.run(task_vars={'vars': {}})


# Generated at 2022-06-11 12:19:44.870928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a temporary directory with a test file in it
    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.mkstemp(dir=tmp_dir)

    args = {'tmp': tmp_dir, 'task_vars': {}}

    module = ActionModule()

# Generated at 2022-06-11 12:20:23.747264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # **IMPORTANT**
    # This test should NOT be run in the Travis environment.
    # Travis does not currently have python-avahi package installed.
    # This test needs to be run manually on a local machine with that package installed.

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock
    from ansible_collections.notstdlib.moveitallout.plugins.modules import package

    class TestActionModule(unittest.TestCase):
        ''' a group of related Unit Tests '''


# Generated at 2022-06-11 12:20:24.482402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-11 12:20:25.301880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:20:28.123442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    assert am.TRANSFERS_FILES is False
    assert am.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}

# Generated at 2022-06-11 12:20:34.753618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_task_vars = {
        'ansible_service_mgr': 'auto',
        'changed': '',
        'failed': False
    }

    # Test run with auto module
    test_self = {
        '_task': {
            'args': {
                'name': 'httpd',
                'use': 'auto'
            },
            'delegate_to': '',
            'async_val': 0
        },
        '_task_vars': test_task_vars,
        '_execute_result': test_task_vars
    }
    assert (ActionModule.run(test_self, '', '') == test_task_vars)

    # Test run with systemd module

# Generated at 2022-06-11 12:20:36.011431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(load_collection_on_demand=True)
    assert type(action_module) is ActionModule

# Generated at 2022-06-11 12:20:43.565846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock = MagicMock()
    mock.run = MagicMock()
    mock.run.return_value = {"ansible_facts": { "service_mgr": "auto" }}
    conn = MagicMock()
    conn._shell.tmpdir = 'test_tmp_path'
    task_vars = {}
    args = {'use': 'auto'}

# Generated at 2022-06-11 12:20:49.363372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from unit.mock import patch

    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert a._task is None
    assert a._connection is None
    assert a._play_context is None
    assert a._loader is None
    assert a._templar is None
    assert a._shared_loader_obj is None
    assert a._supports_check_mode is True
    assert a._supports_async is True
    assert a._display is None
    assert a._task.async_val is False



# Generated at 2022-06-11 12:20:56.778003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    temp_file_path = os.path.join(tempfile.gettempdir(), 'test_action_module_service')
    with open(temp_file_path, 'w') as temp_file:
        temp_file.write("""
{
"_ansible_no_log": false,
"_ansible_verbose_always": true,
"_ansible_debug": true,
"ansible_facts": {
"service_mgr": "auto"
},
"changed": false
}
""")
    action_module = ActionModule()
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['service_mgr'] = 'auto'

# Generated at 2022-06-11 12:21:03.727855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    # Test the argument 'use' of method run of class ActionModule.
    # Test case 1.
    input_args1 = {
        'use': 'auto'
    }
    input_kwargs1 = {
        'task_vars': 'dict'
    }
    module1 = ActionModule()
    setattr(module1, '_display', '_display')
    setattr(module1, '_templar', '_templar')
    setattr(module1, '_shared_loader_obj', '_shared_loader_obj')
    setattr(module1, '_task', '_task')
    setattr(module1, '_task.args', input_args1)
    setattr(module1, '_task.delegate_to', None)

# Generated at 2022-06-11 12:22:31.350971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print(module)
    assert module is not None

# Generated at 2022-06-11 12:22:33.697619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.run.__module__ == 'ansible.plugins.action.service'
    assert ActionModule.run.__doc__

# Generated at 2022-06-11 12:22:37.002486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct the object and call run() method without required arguments
    am = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = am.run()
    # "result" should be empty
    assert result == {}

# Generated at 2022-06-11 12:22:46.017288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible import context
    from ansible.context import get_fqcn
    from ansible.module_utils.common.collections import ImmutableDict

    # test_ActionModule_run_when_no_act_args_and_no_task_args
    my_run_method = ActionModule(task=dict(action=dict(), args=dict(), delegate_to='localhost', async_val=20))
    my_run_method._connection = dict(
        _shell=dict(tmpdir='tmpdir', exec_command='exec_command'),
        _shell_plugin_class='_shell_plugin_class',
        _container=dict(container_name='container_name'),
        _connected=True)
    my_run_method._shared_loader_obj = dict

# Generated at 2022-06-11 12:22:49.016832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module.run(task_vars={}), dict)

# Generated at 2022-06-11 12:22:49.873720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 12:22:58.828911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    action_module = ActionModule(loader=loader, connection=None, play_context=None)
    action_module._shared_loader_obj = namedtuple('_shared_loader_obj', ('module_loader',))
    action_module._shared_loader_obj.module_loader = namedtuple('_loader', ('has_plugin',))
    action_module._shared_loader_obj.module_loader.has_plugin = lambda module: False
    action_module._execute_module = lambda **kw: {'ansible_facts': {'service_mgr': 'auto'}}
    action_module._display = namedtuple('_display', ('warning',))

# Generated at 2022-06-11 12:23:02.561803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule(argument_spec={
        'name': {'type': 'str'}
    })

    assert module.argument_spec.keys() == ['name']


# We always want a test class to execute the tests (thus, cannot be decorated with @pytest.mark.skipif)
# pylint: disable=no-member

# Generated at 2022-06-11 12:23:02.962229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:23:07.140153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_class = ActionModule(None, None)

    import unittest
    class TestActionModule_run(unittest.TestCase):
        def test_run_no_module(self):
            with self.assertRaises(AnsibleActionFail) as context:
                test_class.run(None, dict(ansible_facts=dict()))
            self.assertIsNotNone(context.exception)
            self.assertIsNotNone(str(context.exception))
            assert 'autodetection' in str(context.exception)

        def test_run_auto_module_unknown(self):
            with self.assertRaises(AnsibleActionFail) as context:
                test_class.run(None, dict(ansible_facts=dict(service_mgr='auto')))
            self.assertIsNot