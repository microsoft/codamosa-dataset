

# Generated at 2022-06-11 12:13:55.385371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = [
        {
            "_ansible_no_log": False,
            "ansible_loop_var": "item",
            "ansible_version": {
                "full": "2.7.1",
                "major": 2,
                "minor": 7,
                "revision": 1,
                "string": "2.7.1"
            },
            "item": {
                "path": "/etc/init.d/foo",
                "state": "started"
            }
        }
    ]

    action_class = ActionModule()

    # Run test
    out = action_class.run(task_vars=task_vars)

    # Check result
    assert type(out) is dict
    assert out.get("failed") is False
    assert out.get("msg")

# Generated at 2022-06-11 12:13:55.904779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:14:02.722188
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:14:03.213539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('test')

# Generated at 2022-06-11 12:14:14.798962
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


    class MockPlaybookExecutor(PlaybookExecutor):

        def __init__(self, *args, **kwargs):
            super(MockPlaybookExecutor, self).__init__(*args, **kwargs)

        def get_host_list(self):
            return []


# Generated at 2022-06-11 12:14:17.690264
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-11 12:14:28.239913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    # Create the test objects
    play_source =  dict(
        name = "Ansible Play",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='service', args=dict(name='sshd', state='started'))),
            dict(action=dict(module='service', args=dict(name='sshd', state='started', use='auto'))),
        ]
    )
    config_data = dict()
    inventory = InventoryManager(loader=None, host_list=[])

# Generated at 2022-06-11 12:14:35.358118
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('ActionModule constructor')
    my_action_mod = ActionModule(
        task=dict(action=dict(module_name='echo', module_args=dict(echo='Hello'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    print('Dump %s' % my_action_mod)
    print('Run %s' % my_action_mod.run())


# Generated at 2022-06-11 12:14:36.154924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-11 12:14:40.523308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule("templates", "action", "module", "task_name", "module_name", "module_args", "delegate_to", "play_context", "loader", "templar", "shared_loader_obj").run("tmp", "task_vars")


# Generated at 2022-06-11 12:14:57.733846
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:15:04.737295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert isinstance(action_module, ActionBase)
    assert action_module._supports_check_mode
    assert action_module._supports_async
    assert action_module.TRANSFERS_FILES == False
    assert isinstance(action_module.UNUSED_PARAMS, dict)
    assert isinstance(action_module.BUILTIN_SVC_MGR_MODULES, set)


# Generated at 2022-06-11 12:15:06.633358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(args=dict(use=None, name=None)))

    assert action is not None

# Generated at 2022-06-11 12:15:10.368983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(action='test'), connection=dict(), play_context=dict(remote_addr='test'), loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-11 12:15:10.998995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1

# Generated at 2022-06-11 12:15:14.211116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is a unit test for the constructor of class ActionModule"""

    mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert mod.TRANSFERS_FILES == False
    assert mod._supports_check_mode == True
    assert mod._supports_async == True

# Generated at 2022-06-11 12:15:15.215220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule(), 'run')

# Generated at 2022-06-11 12:15:23.015997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    Module = type('Module',(object,), dict(
        ACTION_WARNINGS = dict(),
        ACTION_COMMAND_WARNINGS = dict(),
        _connection = None,
        action = 'test_action',
        _play = None,
        _task = None,
        _loader = None,
        _shared_loader_obj = None,
        _templar = None,
        _display = None
    ))
    module = Module()

    # Tested function, test true
    def _execute_module(module_name='test_module', module_args=dict(), task_vars=None, wrap_async=False, tmp=None):
        return dict(a=1)
    module._execute_module = _execute_module
    module._task.args = dict(use='auto')
    module._

# Generated at 2022-06-11 12:15:25.622664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_result = {}
    task_vars = {}
    tmp = None
    return test_result == ActionModule(task_vars, tmp).run(tmp, task_vars)

# Generated at 2022-06-11 12:15:35.570346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {}
    args['use'] = 'auto'
    task_vars = {}

    x = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, shared_loader_obj=None, templar=None, shared_action_plugin=None)
    x._display = Display()
    x._execute_module = Mock(return_value={'stdout':'service'})
    x._templar = Mock(return_value='auto')
    x._task = Mock(return_value='auto')
    x._execute_module = Mock(return_value={'stdout':'service'})
    x._task.args = args
    x.run(tmp=None, task_vars=task_vars)

# Mock of Display class

# Generated at 2022-06-11 12:16:01.588792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import shared_loader_obj
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils._text import to_bytes

    loader = shared_loader_obj
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager._inventory = inventory
    play_context = PlayContext()
    task = Task()
    task.action = 'ping'

# Generated at 2022-06-11 12:16:09.484310
# Unit test for constructor of class ActionModule
def test_ActionModule():
  """
  Test ActionModule constructor
  """
  conn = {}
  tsk = {}
  ldr = {}
  play = {}
  tmp = {}
  task_vars = {}
  is_conditional = False
  add_task_fact_vars = False
  load_async = False

  action_module_object = ActionModule(conn, tsk, ldr, play, tmp, task_vars, is_conditional, add_task_fact_vars, load_async)

# Generated at 2022-06-11 12:16:18.601441
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pytest
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_bytes

    def _executor_loader(module_name, module_args=None, async_module=False, async_timeout=0, inject=None, complex_args=None, **kwargs):
        return TaskResult(host=None, result={'module': 'service', 'args': {'name': 'foo', 'state': 'started'}})

    class _ModuleStore(object):
        def has_plugin(self, module_name):
            return True

    class _SharedLoaderObj(object):
        def __init__(self):
            self.module_loader = _ModuleStore()


# Generated at 2022-06-11 12:16:23.946127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule. '''

    # NOTE: the tests in test_service.py test code in the run() method of this module, so
    # we don't need to repeat the service tests here.
    #
    # Here we will test code unique to the run() method of this module.
    #

    # TODO: add tests
    pass

# Generated at 2022-06-11 12:16:25.430022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        a = ActionModule()
    except Exception as e:
        assert False

# Generated at 2022-06-11 12:16:26.056082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:16:33.415898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(action=dict(module_name="service", module_args=dict(name="nginx"))),
        connection=None,
        _play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert am.TRANSFERS_FILES == False
    assert am.ACTION_VERSION == '2.0'
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-11 12:16:39.161200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict

    m = ActionModule()
    result = TaskResult(host=None, task=None)
    m._task = Task()
    m._task.args = ImmutableDict()
    m.run(tmp=None, task_vars={})



# Generated at 2022-06-11 12:16:43.344698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.plugins.action import ActionModule
    from ansible.module_utils._text import to_bytes

    import pytest

    # NOTE: pytest fixtures
    # can be used per test function
    # are defined in function scope
    # created for each test
    # can use return value
    # can use the `request` object

    # TODO: how to test this module?

    # Provide mock object for
    # `ActionModule._execute_module`
    # (`ansible.plugins.action.ActionBase`)
    mock_exc_mod = pytest.Mock()

# Generated at 2022-06-11 12:16:47.464836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module=ActionModule(connection=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)
    module = action_module._task.args.get('use', 'auto').lower()
    assert(module=='auto')

# Generated at 2022-06-11 12:17:16.066856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.service import ActionModule
    am = ActionModule(None, {}, None, None)
    assert am is not None

# Generated at 2022-06-11 12:17:17.374997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    return am


# Generated at 2022-06-11 12:17:19.433458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule('ansible.legacy.service', dict(name='foo')).run(tmp='foobar', task_vars=dict())

# Generated at 2022-06-11 12:17:26.185420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tests.data.actions_data as actions_data

    task_vars = actions_data.task_vars
    tmp = actions_data.tmp
    module_defaults = actions_data.module_defaults

    action = ActionModule(actions_data.task, actions_data.connection, action_loader=actions_data.action_loader, task_vars=task_vars, tmp=tmp, module_defaults=module_defaults)

    # execute unit test
    assert action.run(tmp=tmp, task_vars=task_vars) == actions_data.expected_result

# Generated at 2022-06-11 12:17:27.062076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-11 12:17:36.356945
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_action_base = ActionBase()
    test_action_base._supports_check_mode = True
    test_action_base._supports_async = True

    #Patch ActionBase.run
    import tempfile, os

    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    def action_base_run(action_base, tmp=None, task_vars=None, **kwargs):
        return dict(test_action_base_run=1, tmp=tmp, task_vars=task_vars)

    test_action_base.run = action_base_run.__get__(test_action_base, ActionBase)

    #Patch ActionModule._execute_module

# Generated at 2022-06-11 12:17:45.940095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed_module

    shell = removed_module()
    connection = removed_module()
    connection._shell = shell

    import ansible.plugins.loader as loader_plugin
    loader_plugin.add_directory('/path/to/nonexistant/dir')
    action = ActionModule(connection=connection, task_vars=dict())
    action._task = removed_module()
    action._task._parent = removed_module()
    action._task._parent._play = removed_module()

    action._task.args = {'use': 'auto'}
    action._task.module_defaults = dict()
    action._task.async_val = 0

    action._templar = removed_module()


# Generated at 2022-06-11 12:17:51.274587
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # check when action name is specified in action argument
    # also check if module name is set to use
    assert ActionModule().init(dict(action='service', use='auto')).run(dict())

    # check when action name is not specified in the action argument but
    # the module name is modified to service
    assert not ActionModule().init(dict(action='auto')).run(dict())

# Generated at 2022-06-11 12:17:57.559860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(
            async_val=False,
            async_jid='12321'
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    print(am._task)
    assert am._task['async_val'] == False
    assert am._task['async_jid'] == '12321'

# Generated at 2022-06-11 12:18:01.821308
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    # call method 1
    result = action_module.run()
    assert result == None

    # call method 2
    result = action_module.run(None, None)
    assert result == None

    # call method 3
    result = action_module.run('', '')
    assert result == None

# Generated at 2022-06-11 12:19:01.921520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def fake_execute_module(*args, **kwargs):
        raise AnsibleAction('ansible.legacy.service', {}, {}, '', '')

    task = FakeTask(dict(use="auto"))
    action_module_obj = ActionModule(task, FakeConnection())
    action_module_obj._execute_module = fake_execute_module
    action_module_obj._display = FakeDisplay()

    assert action_module_obj.run() == {'invocation': {'module_name': 'ansible.legacy.service'}, 'failed': True, 'msg': 'AnsibleAction not found in loaded modules'}



# Generated at 2022-06-11 12:19:12.079755
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import shared_loader_obj as _shared_loader_obj
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar

    from units.mock.loader import DictDataLoader

    from units.mock.vault import MockVaultSecret

    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_success

    from units.mock.plugins.action import MockActionBase
    from units.mock.plugins.action import ActionModuleMock
    from units.mock.plugins.loader import MockPluginLoader


# Generated at 2022-06-11 12:19:21.630470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Hack to load plugins
    import ansible.plugins
    for p in ('action', 'cache', 'callback', 'connection', 'filter', 'httpapi', 'inventory', 'lookup', 'module_utils',
              'shell_plugin', 'strategy', 'terminal', 'test', 'vars'):
        if p not in ansible.plugins.__all__:
            ansible.plugins.__all__.append(p)
    import ansible.plugins.action.service
    import ansible.plugins.action.systemd
    import ansible.plugins.action.sysvinit
    import ansible.plugins.action.openwrt_init

    # Create an instance of ActionModule

# Generated at 2022-06-11 12:19:27.857126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()
    # Test inherited class is ActionBase
    assert isinstance(actionmodule, ActionBase)
    # Test inherited class is ActionBase
    assert isinstance(actionmodule, ActionBase)
    # Test Transfers_Files is True for ActionModule class
    assert actionmodule.TRANSFERS_FILES
    # Test run method exists in ActionModule class
    assert hasattr(actionmodule, 'run')
    # Test run method exists in ActionModule class
    assert hasattr(actionmodule, 'run')

# Generated at 2022-06-11 12:19:28.771272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-11 12:19:34.548726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = MockConnection()
    action = ActionModule(connection, 'setup')
    assert action.TRANSFERS_FILES == False
    assert action.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert action._shared_loader_obj == None
    action = ActionModule(connection, 'setup', shared_loader_obj=True)
    assert action._shared_loader_obj == True


# Generated at 2022-06-11 12:19:38.531525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    action.assert_only_one_log_message(
        dict(action=dict(action='ping'), module='ping', ini_path='/etc/ansible/ansible.cfg', verbosity=3, forks=5),
        '"action": "ping"'
    )

# Generated at 2022-06-11 12:19:48.816104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile

    # Test with default values
    o = ActionModule(task={}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    assert o._task.args == {}
    assert o._connection.become == False
    assert o._connection.conn_params == None
    assert o._connection.become_method == None
    assert o._connection.become_user == None
    assert o._connection.noop_on_check == True
    assert o._connection.host == None
    assert o._connection.remote_user == 'root'
    assert o._connection.password == None
    assert o._connection.port == None
    assert o._connection.private_key_file == None
    assert o._connection.ssh_common_args == None
    assert o._connection.ssh_

# Generated at 2022-06-11 12:19:57.122868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = {}
    data["task"] = "task1"
    data["args"] = {"use": "auto"}
    action_module = ActionModule(data, name='some_name')
    assert action_module.BUILTIN_SVC_MGR_MODULES == {'sysvinit', 'service', 'systemd', 'openwrt_init'}
    assert action_module.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'], 'sysvinit': ['sleep'], 'service': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'], 'openwrt_init': ['sleep']}

# Generated at 2022-06-11 12:20:03.911789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    module = action_loader.get('service', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(module, ActionModule)
    # Set up class's objects

# Generated at 2022-06-11 12:22:51.895030
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = {'ansible_facts':{'service_mgr':'servicemgr_type', 'ansible_service_mgr':'ansible_service_mgr_type'}}
    inventory = {'hostvars':hostvars}
    task = {'args':{'use':'auto'}}
    task_vars = {'hostvars':hostvars, 'inventory_hostname':'host'}

    action_module = ActionModule(task=task, shared_loader_obj=None, connection=None, play_context=None, loader=None, templar=None, shared_action_plugin_loader=None)


# Generated at 2022-06-11 12:22:53.057994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert not module.TRANSFERS_FILES

# Generated at 2022-06-11 12:23:01.763258
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def get_ansible_vars(host):
        vars = dict()
        if host == "hostA":
            vars['service_mgr'] = "systemd"
        if host == "hostB":
            vars['service_mgr'] = "systemd"
        if host == "hostC":
            vars['service_mgr'] = "service"
        if host == "hostD":
            vars['service_mgr'] = "systemd"
        return vars

    def get_ansible_facts(host, mod, arg):
        facts = dict()
        return facts

    def get_ansible_module(mod, arg):
        module = dict()
        return module

    module = ActionModule()

    task_vars = dict()
    task_vars['ansible_facts'] = get

# Generated at 2022-06-11 12:23:06.264204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name_mock = 'test.mock.name'
    module_name_mock_true = 'test.mock.name.real'
    task_mock = 'task'
    task_mock_async = 'task_async'
    task_mock_name = 'task_name'
    task_mock_name_end = 'task_name_end'
    task_mock_id = 'task_id'
    task_mock_async_id = 'async_id'
    task_mock_async_id_end = 'async_id_end'
    shared_loader_mock = 'shared_loader'
    play_context_mock = 'play_context'
    loader_mock = 'loader'

# Generated at 2022-06-11 12:23:16.478288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for checking run method of ActionModule
    """
    # Initializing and setting up mock objects
    m_message = ['dummy_message']
    mock_module_index = [('name', 'random_module')]
    m_module_name = ['random_module']
    m_module_args = ['random_args']
    m_task_vars = ['random_task_variables']
    m_tmp = ['random_tmp_value']
    actionbaseobj = ActionBase()
    actionbaseobj.display = Display()
    mock_actionbase_run = MagicMock()
    mock_actionbase_run.return_value = {'message': 'OK', 'reboot': False}
    actionbaseobj.run = mock_actionbase_run
    shared_loader_obj = Mock()
    shared_loader

# Generated at 2022-06-11 12:23:20.079170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule({'service': {'name': 'foo'}}, '', '', False)
    assert module.BUILTIN_SVC_MGR_MODULES == ['openwrt_init', 'service', 'systemd', 'sysvinit']

# Generated at 2022-06-11 12:23:20.721502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:23:23.234370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:23:33.738153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import print_
    from ansible.module_utils.six.moves import StringIO

    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgr
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.constants as C
    import ansible.executor.task_result as tr

    test_service = 'test_service'
    test_state = 'test_state'
    test_enabled = False
    test_module_defaults = {}
    test_action_groups = {}
    test_task_vars = {'test_task_vars': True}
    test_delegate_to = 'test_delegate_to'
    test_as

# Generated at 2022-06-11 12:23:35.696842
# Unit test for constructor of class ActionModule
def test_ActionModule():
        module = ActionModule(None, None, None)
        assert module is not None
        assert module._display is not None