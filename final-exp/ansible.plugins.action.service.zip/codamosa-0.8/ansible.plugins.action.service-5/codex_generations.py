

# Generated at 2022-06-11 12:13:50.338233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initializing object of class ActionModule
    action = ActionModule()

    # Checking if object is initialized properly
    assert isinstance(action.UNUSED_PARAMS, dict)

# Generated at 2022-06-11 12:13:58.678601
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Check that it works with module_name being None.
    # See https://github.com/ansible/ansible/issues/54406
    am = ActionModule(None, None, {})

    # Check that ActionModule.run() works when it's inherited
    
    class DerivedActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(DerivedActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self.hello = 'Hello'

        def run(self, tmp=None, task_vars=None):
            return am.run(tmp, task_vars)


# Generated at 2022-06-11 12:13:59.043920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:14:02.189159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''

    action = ActionModule()
    assert type(action) == ActionModule
    assert type(action.BUILTIN_SVC_MGR_MODULES) == set
    assert type(action.UNUSED_PARAMS) == dict
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:14:02.718172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:14:04.977482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test case test the constructor using default values
    test_ActionModule will call the constructor and check whether
    the result is initialised with a valid object
    """
    obj = ActionModule()
    assert obj is not None

# Generated at 2022-06-11 12:14:11.051830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.service import ActionModule

    temp_action_module = ActionModule(TaskResult('host01', 'task01'), dict())
    assert not isinstance(temp_action_module.run(), dict)

# Generated at 2022-06-11 12:14:12.130950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("start test")
    assert True

# Generated at 2022-06-11 12:14:24.474809
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create Mock for object ActionModule
    mock_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    mock_task= {'args': {'use': 'auto'}}
    mock_ActionModule._task = mock_task
    assert mock_ActionModule.run() == {'failed': True, 'msg': 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.', 'skipped': False}
    mock_task= {'args': {'use': 'auto', 'name': 'ntpd'}}
    mock_ActionModule._task = mock_task

# Generated at 2022-06-11 12:14:27.397753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = ActionModule
    #mock_self = ActionModule()
    module = mock_task_args.get('use', 'auto').lower()
#Unit test for method get_action_args_with_defaults of class ActionModule

# Generated at 2022-06-11 12:14:36.626786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-11 12:14:46.970205
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mod = ActionModule(None, None, None)

    assert mod.run(None, None) == {}

    assert mod.run(None, {}) == {}

    assert mod.run(None, {'ansible_service_mgr': 'systemd'}) == {}

    assert mod.run(None, {'ansible_service_mgr': 'openwrt_init'}) == {}

    assert mod.run(None, {'ansible_service_mgr': 'systemd', 'delegate_to': 'bogus'}) == {}

    assert mod.run(None, {'ansible_service_mgr': 'openwrt_init', 'delegate_to': 'bogus'}) == {}


# Generated at 2022-06-11 12:14:47.486465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:14:57.833015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    argument_spec = {'use': {'type': 'str', 'choices': ['auto', 'openrc', 'sysvinit', 'systemd', 'ansible.legacy.service', 'ansible.legacy.openwrt_init']}}
    t = ActionModule(argument_spec=argument_spec, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert t._shared_loader_obj == shared_loader_obj
    assert t.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert t.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-11 12:15:08.862201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create/get mock dependencies
    test_result = dict(**MOCK_RESULT)
    test_result.update({'failed': True})

    mock_task = dict(**MOCK_TASK)
    mock_task.update({
        'args': dict(
            name='httpd',
            use='auto'
        ),
        'delegate_to': '',
        'async_val': 0,
        'async_poll': 0
    })

    mock_task_vars = dict(**MOCK_TASK_VARS)

    # Create target object
    a = ActionModule(MOCK_RUNNER, MOCK_CONNECTION, MOCK_LOADER, MOCK_TEMPLAR, MOCK_DISPLAY)

    # Do test

# Generated at 2022-06-11 12:15:11.989512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(add_context=True,play_context=True,task=True,task_vars='Ansible_Module',shared_loader_obj=True,templar=True)
    action.run()

# Generated at 2022-06-11 12:15:21.259935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = Connection()
    task_vars = dict()
    tmpdir = None
    task = Task(args=dict(use='auto'), async_val=True)
    mock_shared_loader_obj = MagicMock()
    am = ActionModule(task, connection, tmpdir, task_vars, mock_shared_loader_obj)
    am._execute_module = MagicMock(return_value={'ansible_facts': {'ansible_service_mgr':'auto'}})
    am._templar = MagicMock(return_value="auto")
    mock_shared_loader_obj.module_loader.has_plugin = MagicMock(return_value=True)
    mock_shared_loader_obj.module_loader.find_plugin_with_context=MagicMock()


# Generated at 2022-06-11 12:15:28.251367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_loader = DictDataLoader([])
    fake_playbook = Playbook()
    fake_play = Play()
    fake_task = Task()

    fake_play.set_loader(fake_loader)
    fake_play._parent = fake_playbook
    fake_task._parent = fake_play
    action_module = ActionModule(fake_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert isinstance(action_module, ActionModule)
    return

# Generated at 2022-06-11 12:15:31.694683
# Unit test for constructor of class ActionModule
def test_ActionModule():

    am = ActionModule()

    assert am.TRANSFERS_FILES == False
    assert am.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}

# Generated at 2022-06-11 12:15:41.344616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1
    # Default run case

    # initialize
    action = ActionModule()
    action._task = {}
    action._task.args = {}
    action._task.args['name'] = 'eth0'
    action._task.args['use'] = 'auto'
    action._task.action = 'service'
    action._task.async_val = False
    action._task.delegate_to = 'localhost'
    action._task.module_defaults = {}
    action._task.run_once = False
    action._task.no_log = True
    action._task.tags = []
    action._task.task_vars = {}
    action._task.task_vars['ansible_facts'] = {}

# Generated at 2022-06-11 12:16:00.026447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_equals(ActionModule.__name__, 'ActionModule')

# Generated at 2022-06-11 12:16:01.102478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:16:12.257099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.executor.task_queue_manager
    import ansible.inventory.manager
    import ansible.playbook.play
    import ansible.plugins.loader

    from ansible.plugins.loader import ActionModuleLoaderPlugin
    from ansible.plugins.action import ActionBase


    class ActionModuleTest(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(ActionModuleTest, self).run(tmp, task_vars)


    class ActionModuleLoaderPluginTest(ActionModuleLoaderPlugin):
        def get(self, name, *args, **kwargs):
            return super(ActionModuleLoaderPluginTest, self).get(name, *args, **kwargs)


    # Create arguments for ActionModuleTest:
    #     tmp: Temporary directory to use when running the module.
   

# Generated at 2022-06-11 12:16:18.009128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    t = Task()
    t._role = None
    t.action = 'service'
    t.args = {}
    t.async_val = None

    pc = PlayContext()
    t._parent = pc

    ac = action_loader.get('service', task=t)
    assert isinstance(ac, ActionModule)

# Generated at 2022-06-11 12:16:28.813143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MyActionModule(ActionModule):
        def _execute_module(self, module_name=None, module_args=None, tmp=None, task_vars=None, wrap_async=None):
            self.called = True
            self.module_name = module_name
            self.module_args = module_args
            self.wrap_async = wrap_async
            return dict(
                ansible_facts=dict(service_mgr='systemd'),
                failed=False,
                msg="OK",
                rc=0,
            )

    action = MyActionModule()
    action.set_task(dict(
        args=dict(
            name='foo',
            enabled=True,
            state='started',
            use='auto'
        )
    ))
    action._connection = dict()
    result

# Generated at 2022-06-11 12:16:29.477316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:16:37.417391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._shared_loader_obj.module_loader.has_plugin = MagicMock(return_value=True)
    module._execute_module = MagicMock(return_value={'rc': 0})
    module._remove_tmp_path = MagicMock(return_value=True)
    module._task = MagicMock()
    module._task.args = {'use': 'auto'}
    module._task.async_val = False
    result = module.run(tmp=None, task_vars={})
    assert result == {'changed': False}


# Generated at 2022-06-11 12:16:42.816866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Test_action_module(ActionModule):
        def __init__(self):
            self.show_custom_stats = False
            self.bypass_checks = False
            self.no_log = False
            self.async_timeout = 5

    assert Test_action_module().transfers_files() == False
    assert Test_action_module().noop_on_check() == False

# Generated at 2022-06-11 12:16:45.158814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add tests for method run of class ActionModule
    assert False, "Tests for method run of class ActionModule not implemented"

# Generated at 2022-06-11 12:16:56.142939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actions_map = {
        "package": actionplugin.ActionModule
    }


# Generated at 2022-06-11 12:17:28.131879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(task=dict(args={}), connection='connection')
    assert obj.TRANSFERS_FILES is False
    assert obj.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert obj.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-11 12:17:30.674496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(loader=None, play_context=None, new_stdin=None)
    test_ans = action.run()
    assert test_ans is None

# Generated at 2022-06-11 12:17:31.841048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:17:36.351558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = dict(
        args = {
           'use': 'auto',
           'name': 'foo',
           'state': 'started'
        },
        async_val = False,
        delegate_to = None,
        run_once = False,
        _parent = dict(
            _play = dict(
                _action_groups = ['maintenance']
            )
        )
    )
    mock_connection = dict()
    mock_play_context = dict()

    am = ActionModule(mock_task, mock_connection, mock_play_context, loader=None, templar=None, shared_loader_obj=None)
    am.run()

# Generated at 2022-06-11 12:17:40.640195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict()),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    action_module.action = 'test_service'
    action_module.name = 'test_service'

# Generated at 2022-06-11 12:17:43.021971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    result = action_module_obj.run()
    assert result == {}, "Test run method of class ActionModule is failed"

# Generated at 2022-06-11 12:17:53.530424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = MagicMock()
    host.get_name.return_value = 'name'
    loader = MagicMock()
    variable_manager = MagicMock()
    task = MagicMock()
    play_context = MagicMock()
    play_context.connection = 'connection'
    task._parent._play = play_context
    display = MagicMock()
    action_module = ActionModule(host, loader, variable_manager, display)
    action_module._task = task
    action_module._shared_loader_obj = loader
    action_module._connection = 'connection'
    action_module._remove_tmp_path = MagicMock()

    action_module.run(tmp=None, task_vars=None)

    assert action_module._supports_check_mode
    assert action_module._supports_as

# Generated at 2022-06-11 12:18:03.392826
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action

    # We will test the run method of 'service' module with following parameters
    #
    # action: service
    # use: auto
    # name: httpd
    # state: started
    # enabled: yes
    #
    # We will use task_vars to set the following values:
    #
    # ansible_facts:
    #    service_mgr: systemd
    #
    # This will change the 'use' parameter to 'systemd' and then call the run method of 'systemd' module.

    module_name = 'service'
    module_args = {'action': 'service', 'use': 'auto', 'name': 'httpd', 'state': 'started', 'enabled': 'yes'}

# Generated at 2022-06-11 12:18:04.198740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-11 12:18:13.170977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    svc_mgr_action = ActionModule(
        task=dict(action=dict(module=dict(args=dict(use='auto'), use='auto', delegate_to='localhost')),
                  async_val=4000, async_jid='100',
                  delegate_to='localhost', delegate_facts=True),
        connection=dict(module_implementation_preferences=['psutil', 'auto', 'service']),
        task_vars={'ansible_facts': dict(service_mgr='psutil')})

    assert (svc_mgr_action.run() == dict(failed=True, changed=False, skipped=False, msg='Could not detect which service manager to use. Try gathering facts or setting the "use" option.'))

# Generated at 2022-06-11 12:19:06.032470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule('test', 'test')

# Generated at 2022-06-11 12:19:11.827764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is a unit test for method 'run' of class 'ActionModule'
    """
    print("In test_ActionModule_run()")
    action_module = ActionModule()
    tmp=None
    task_vars=None
    result = action_module.run(tmp=None, task_vars=None)
    assert result.get('failed', False) == False
    print("Out test_ActionModule_run()")

# Generated at 2022-06-11 12:19:14.178444
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of a module that can be used for testing
    module = ActionModule()

    # TODO: Not sure how to test this method with its dependencies.
    pass

# Generated at 2022-06-11 12:19:23.943126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.play_context
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.utils.unsafe_proxy
    import ansible.vars.unsafe_proxy
    import ansible.inventory.host
    import ansible.utils.template

    # Mock AnsibleModule class
    import ansible.utils.module_docs_fragments
    class MockModuleUtils(object):
        def __init__(self):
            self.module_docs_fragments = ansible.utils.module_docs_fragments

    # Mock AnsibleModule class
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self._ansible_module = None
            self.check_mode = False
            self.no

# Generated at 2022-06-11 12:19:24.862955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
    # TODO add unit test

# Generated at 2022-06-11 12:19:34.251908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = {
        'use': 'auto'
    }


# Generated at 2022-06-11 12:19:34.802310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:19:35.833431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:19:40.171452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)
    assert action_module.TRANSFERS_FILES == False
    assert len(action_module.UNUSED_PARAMS) == 1
    assert len(action_module.BUILTIN_SVC_MGR_MODULES) == 4

# Generated at 2022-06-11 12:19:50.237605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule._display.debug = lambda x: None

    # class MockTask:
    #     def __init__(self, args):
    #         self.args = args
    #         self.async_val = None
    #         self.delegate_to = None
    #         self._module_defaults = None
    #         self._parent = None
    #         self._play = None
    #
    # class MockTemplar:
    #     def __init__(self):
    #         pass
    #
    #     def template(self, data):
    #         return data
    #
    # class MockArgs:
    #     def __init__(self):
    #         self.data = {}
    #
    #     def __getitem__(self, item):
    #         return self.data[

# Generated at 2022-06-11 12:22:35.235735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.loader import action_loader

    module_args = dict(
        name="sshd",
        state="restarted",
        enabled="yes",
        use="auto"
    )

    dummy_connection = object()


# Generated at 2022-06-11 12:22:43.888942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    play_context = {}
    play_context.update({
        'name': 'fake'
    })

    task_context = {}
    task_context.update({
        'name': 'fake'
    })

    task_context.update({
        'args': {'use': 'systemd'}
    })

    play_context['service_mgr'] = 'systemd'

    role_context = role = Role()
    role_context.update({
        'role_path': '/dev/null'
    })

    task = Task()

    task._role = role
    task._role._context = role_context

   

# Generated at 2022-06-11 12:22:53.057498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = dict()
    mock_task['args'] = dict()
    # Could possibly try testing all 3 modules/classes
    mock_task['args']['use'] = 'auto'
    mock_task['delegate_to'] = 'localhost'
    mock_task['async'] = '10'
    mock_task['async_val'] = 10
    mock_task['module_defaults'] = dict()
    mock_task['collections'] = None

    # unit test for no delegation
    mock_task['delegate_to'] = None

    mock_task_instance = ActionModule(mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    mock_task_instance.run(tmp=None, task_vars=None)

# Generated at 2022-06-11 12:22:54.212623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    Action = ActionModule()
    assert not Action.run()


# Generated at 2022-06-11 12:22:56.281104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:22:56.791596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:23:04.912475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.legacy.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.legacy.tests.unit.compat.mock import patch
    from ansible_collections.ansible.legacy.tests.unit.modules.utils import set_module_args
    from ansible_collections.ansible.legacy.tests.unit.modules.utils import AnsibleExitJson
    module = 'ansible.legacy.service'
    module_data = '''module_name: %s
module_args:
  name: httpd
''' % module

    # Configure the params that would be returned by querying the
    # remote device
    params = {
        'use': 'auto',
        'name': 'httpd'
    }

   

# Generated at 2022-06-11 12:23:07.672151
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(action=dict(module='service', args=dict(name='foo', state='started', enabled='no'))))
    assert am is not None
    assert isinstance(am, ActionModule)

# Generated at 2022-06-11 12:23:17.908771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from collections import namedtuple
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    module_args = dict(use='apt')

# Generated at 2022-06-11 12:23:28.601326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.action.normal import ActionModule as test_ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from ansible.utils.vars import AnsibleVars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
