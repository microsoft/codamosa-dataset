

# Generated at 2022-06-25 07:31:27.612127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    dict_1 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_1, bool_0, bool_1, tuple_0)
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.UNUSED_PARAMS == {tuple_0: ['arguments', 'args', 'pattern', 'runlevel', 'sleep'], tuple_0: ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert action_module_

# Generated at 2022-06-25 07:31:36.015987
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = (1, 2, 3)
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    dict_1 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_1, bool_0, bool_1, tuple_0)
    action_module_1 = ActionModule(dict_1, tuple_0, dict_1, bool_0, bool_1, tuple_0)
    action_module_2 = ActionModule(tuple_0, dict_0, dict_1, bool_0, bool_1, tuple_0)
    action_module_3 = ActionModule

# Generated at 2022-06-25 07:31:44.813490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_1 = {tuple_0: tuple_0, tuple_0: tuple_0}
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    dict_2 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_2, bool_0, bool_1, tuple_0)
    action_module_0.run(dict_1, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:31:53.493700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    dict_1 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_1, bool_0, bool_1, tuple_0)
    tmp_0 = "/>/eJbM2#w8";
    dict_2 = dict()
    dict_3 = dict()
    dict_3['module_defaults'] = dict_2
    dict_3['_action_groups'] = dict_2
    dict_3['play'] = dict_2

# Generated at 2022-06-25 07:31:56.139911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_2 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}
    bool_2 = True
    bool_3 = True
    action_module_1 = ActionModule(tuple_0, tuple_0, dict_2, bool_2, bool_3, tuple_0)
    print(action_module_1.__class__)
    print(action_module_1.__module__)

# Generated at 2022-06-25 07:31:57.059511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:31:59.638982
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule(None, None, None, None, None, None)

    # Test empty case
    try:
        action_module_0.run(None, None)
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 07:32:06.879678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    dict_1 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_1, bool_0, bool_1, tuple_0)
    dict_2 = dict_0
    dict_3 = dict_0
    dict_4 = dict_0
    dict_4['ansible_service_mgr'] = 'auto'
    dict_3['ansible_facts'] = dict_4
    dict_5 = dict_0
    dict_5['ansible_facts'] = dict_4
    dict

# Generated at 2022-06-25 07:32:16.912440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    dict_1 = dict_0
    dict_2 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_2, bool_0, bool_1, tuple_0)
    action_module_0.run(dict_0, dict_1)

if __name__ == '__main__':
    # unit test function 'test_case_0'
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:32:26.153984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    dict_1 = {tuple_0: tuple_0, tuple_0: tuple_0, tuple_0: tuple_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(tuple_0, tuple_0, dict_0, bool_0, bool_1, tuple_0)
    assert action_module_0 != None

# Generated at 2022-06-25 07:32:34.739048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(None, None, None, None, None, None)
    var_0.run()


# Generated at 2022-06-25 07:32:41.317953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    action_module_1 = ActionModule(var_2, var_3, var_4, var_5, var_6, var_7)


# Generated at 2022-06-25 07:32:46.702817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    # Invoke method run of class ActionModule with parameter(s)
    var_10 = action_module_0.run(var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9)

# Generated at 2022-06-25 07:32:51.518539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Given
    var_0 = None
    # When
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)

    act_result = action_module_0
    exp_result = None
    assert act_result == exp_result


# Generated at 2022-06-25 07:32:58.128552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)


# Generated at 2022-06-25 07:33:02.384034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)

    assert True

# Generated at 2022-06-25 07:33:05.419808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object (with a filename of 'test_case_0.yml')
    test_case_0()


# Generated at 2022-06-25 07:33:11.817014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    # assert that a specific exception is raised
    # with pytest.raises(Exception):
    #    action_module_0.run()


# Generated at 2022-06-25 07:33:16.889066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    action_module_1 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_6)


# Generated at 2022-06-25 07:33:27.651763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    action_module_1 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_2 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_3 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_4 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    action_module_5 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)

# Generated at 2022-06-25 07:33:36.676059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(Exception):
        test_case_0()

# Generated at 2022-06-25 07:33:39.509630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a instance of object
    obj = ActionModule()
    # Call method run of the object
    obj.run()
    # Test method run of class ActionModule
    assert None # TODO: implement your test here


# Generated at 2022-06-25 07:33:40.824851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  class_1 = ActionModule(tmp = None, task_vars = None)
  var_3 = assertEqual(class_1.run(), None)
  return var_3

# Generated at 2022-06-25 07:33:46.890584
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:33:51.080391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_1['use'] = 'auto'
    var_1['name'] = 'foo'
    var_1['state'] = 'running'
    obj_ActionModule = ActionModule(var_0, var_1, var_2, var_3)


# Generated at 2022-06-25 07:33:54.592431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = dict()
    use = dict()
    module_args = dict()
    tmp = dict()
    task_vars = dict()
    result = dict()
    with pytest.raises(AnsibleActionFail):
        test_case_0()

# Generated at 2022-06-25 07:33:55.649725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()

# Generated at 2022-06-25 07:34:00.661126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run = ActionModule.run

    # Unit tests
    assert test_case_0()

    # TODO: parameterize fixture

# Generated at 2022-06-25 07:34:03.706047
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mod = ActionModule()

    mod.run(None, None)

# Generated at 2022-06-25 07:34:07.775098
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # 1. Create an instance of the ActionModule class with the required parameters (no additional arg provided)
    var_0 = ActionModule()
    try:
        test_case_0()
    except AssertionError:
        var_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:34:17.661419
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    result = None

    ActionModule.run(var_0)

    # assert#
    #fail("undefined assert condition")

# Generated at 2022-06-25 07:34:27.091026
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Parmeters for ActionBase.__init__
    task = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    action_base = ActionBase(task, connection, play_context, loader, templar, shared_loader_obj)

    # Parmeters for ActionModule.__init__
    arg1 = None # ERROR: ValueError is raised.
    var_1 = ActionModule(arg1)
    var_2 = ActionModule(var_0)

# Generated at 2022-06-25 07:34:35.919538
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    var_0 = dict()
    fixture_0 = ActionModule(var_0)
    fixture_0.run()


if __name__ == '__main__':
    import unittest

    # class named TestClassName
    class TestClassName(unittest.TestCase):
        # so the setup function named setUp
        def setUp(self):
            pass
        # so the function which tests something named test_something
        def test_test_case_0(self):
            test_case_0()
            pass

        pass

    # run all the tests
    unittest.main()

# Generated at 2022-06-25 07:34:37.416463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()

# Generated at 2022-06-25 07:34:47.960177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()

    var_0['task_vars'] = dict()

    var_1 = {'name': 'service', 'args': {'use': 'auto'}}

    var_0['task'] = var_1

    var_1 = 'another_variable'

    var_0['tmp'] = var_1

    var_1 = {'play_context': {}}

    #var_0['play'] = var_1

    var_2 = 'localhost'

    var_0['hosts'] = var_2

    var_1 = 'desktop'

    var_0['delegate_to'] = var_1

    var_2 = 'ansible.legacy.service'

    var_0['module_name'] = var_2

    var_2 = {'use': 'auto'}

    var

# Generated at 2022-06-25 07:34:53.284306
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Arguments:
    #    self: <it's a class>
    #    tmp: None
    #    task_vars: None

    # Unit test for method run of class ActionModule
    # TODO: THIS ASSUMES THE TEST MODULE IS ALREADY LOADED.

    # Argumemts:
    #    tmp: None
    #    task_vars: None
    var_0 = ActionModule(None)
    local_assert_var = None
    try:
        var_1 = var_0.run(None, None)
        local_assert_var = True
    except:
        local_assert_var = False
    assert local_assert_var

# Generated at 2022-06-25 07:34:57.017447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = dict()
    var_2 = dict()
    temp_1 = dict()
    var_0 = ActionModule(var_1, var_2, temp_1)
    var_3 = dict()
    temp_2 = dict()
    var_4 = var_0.run(var_3, temp_2)
    return var_4

# Generated at 2022-06-25 07:35:00.830854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict()
    var_0 = dict()
    obj = ActionModule(var_0, module_args)

# Generated at 2022-06-25 07:35:09.012971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['use'] = 'auto'
    #var_1 = ...
    #var_2 = ...
    var_3 = test_case_0()
    var_4 = ActionModule()
    output_dict =  var_4.run(tmp=var_0, task_vars=var_3)
    var_5 = output_dict
    #print output_dict
    #assert var_5 == var_4


# Command line execution

# Generated at 2022-06-25 07:35:15.600749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case with arguments.
    tmp = None
    task_vars = {'ansible_fact_service_mgr': 'sysvinit'}
    obj = ActionModule(tmp, task_vars)
    res = obj.run()
    assert res['_ansible_no_log'] == False
    assert res['changed'] == False
    assert res['msg'] == 'ok'
    assert res['rc'] == 0

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:35:32.739228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert isinstance(module.run(), dict) == True


# Generated at 2022-06-25 07:35:34.006096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run('foo')


# Generated at 2022-06-25 07:35:39.446282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test data
    #[
    #  {
    #    "_ansible_parsed": true,
    #    "_ansible_no_log": false,
    #    "systemd": {
    #      "_ansible_no_log": false
    #    },
    #    "changed": false,
    #    "invocation": {
    #      "module_args": {
    #        "use": "systemd"
    #      }
    #    }
    #  }
    #]

    assert(False)

# Generated at 2022-06-25 07:35:44.111876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    # Calling constructor of class ActionBase
    var = dict()
    obj = ActionBase(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert obj is not None
    assert obj._task is None
    assert obj._play_context is None
    assert obj._loader is None
    assert obj._connection is None
    assert obj._templar is None
    assert obj._shared_loader_obj is None
    assert obj._restrict_keywords is None
    assert obj._supports_check_mode is None
    assert obj._supports_async is None
    # Calling constructor of class Ansible

# Generated at 2022-06-25 07:35:51.944754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    test_case = ActionModule(var_0, var_1, var_2, var_3)
    var_4 = dict()
    var_5 = dict()
    # Call method run with arguments test_case_0
    result = test_case.run(var_4, var_5)
    assert result['skipped'] == False
    assert result['invocation'] == dict()
    assert result['changed'] == False
    assert result['rc'] == 0
    assert result['module_name'] == 'ansible.legacy.setup'

# Generated at 2022-06-25 07:35:54.539990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fp_0 = str()     # type: str
    tmp_0 = None     # type: Any
    task_vars_0 = dict()

    # Constructor test
    module_0 = ActionModule(fp_0, tmp_0, task_vars_0)

    # Method test
    ansible_0 = module_0.run()
    assert ansible_0 == dict()

# Generated at 2022-06-25 07:36:04.953702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    var_0['use'] = 'auto'
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_3['ansible_service_mgr'] = var_8 = 'auto'
    var_2['ansible_facts'] = var_3
    var_1['ansible_facts'] = var_2
    var_1['changed'] = False
    var_10 = dict()
    var_10['auto'] = var_1
    var_10['auto'] = var_1
    var_10['auto'] = var_1
    var_10['auto'] = var_1
    var_10['auto'] = var_1
    var_10['auto'] = var_1
    var_10['auto'] = var_1
   

# Generated at 2022-06-25 07:36:09.936457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule('', '', '', '', '')
    assert isinstance(t, object)
    assert isinstance(t, ActionBase)


# Generated at 2022-06-25 07:36:14.092765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    tmp = None
    task_vars = None
    assert module.run(tmp, task_vars) == 0

# Generated at 2022-06-25 07:36:23.966913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    task = Task(action=dict(module="service", name="foo", use="auto"))

# Generated at 2022-06-25 07:36:47.463156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    assert isinstance(action_module_0, ActionModule)
    return_value_0 = action_module_supports_check_mode(action_module_0)
    assert return_value_0 == True


# Generated at 2022-06-25 07:36:51.648437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_0 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_6)


# Generated at 2022-06-25 07:37:00.194491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1 test case
    t0 = {"args": {"enable": False, "use": "auto", "name": "ssh"}, "delegate_to": "localhost"}
    t2 = {"status": None, "running": True, "rc": 0, "ansible_facts": {"service_mgr": "auto", "ansible_service_mgr": "auto"}, "changed": False}
    t1 = {"changed": False, "msg": "", "rc": 0, "running": True, "service": "ssh", "state": "started", "status": None}

# Generated at 2022-06-25 07:37:09.906319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None

    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None

# Generated at 2022-06-25 07:37:19.349771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = { 'use' : 'systemd' }
    meta = {}
    invock = { 'delegate_to' : 'server1' }
    action = { 'async' : 123 }
    task_vars = { 'ansible_facts' : { 'service_mgr' : 'systemd' } }
    loader = {}
    templar = {}
    connection = {}
    display = {}
    action_module_0 = ActionModule(task, meta, invock, action, task_vars, loader, templar, connection, display)


if __name__ == '__main__':
    if test_case_0():
        print("OK")
    else:
        print("ERROR")

# Generated at 2022-06-25 07:37:23.267735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # No args for constructor
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    action_module_0 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_6)


# Generated at 2022-06-25 07:37:24.953021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    @patch('ansible.plugins.action.ServiceModule._execute_module')
    def test_module(self):
        self.assertTrue(test_case_0())
    test_module()
test_ActionModule()

# Generated at 2022-06-25 07:37:28.817021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    tmp = None
#    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars, var_0, var_0, var_0, var_0)
    # Act
    action_module_0.run(tmp, task_vars)
    # Assert

# Generated at 2022-06-25 07:37:30.051965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    pass


# Generated at 2022-06-25 07:37:32.540086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:38:04.449084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test default constructor
    var_1 = None
    action_module_0 = ActionModule(var_1, var_1, var_1, var_1, var_1, var_1)
    var_2 = None
    # Test overloaded constructor
    action_module_1 = ActionModule(var_2, var_2, var_2, var_2, var_2, var_2)

# Generated at 2022-06-25 07:38:15.666552
# Unit test for constructor of class ActionModule
def test_ActionModule():
  var_0 = None
  var_1 = None
  var_2 = None
  var_3 = None
  var_4 = None
  var_5 = None
  var_6 = None

# Generated at 2022-06-25 07:38:18.909129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = None
    var_2 = action_run(var_1, var_1)



# Generated at 2022-06-25 07:38:22.807318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_3 = Null()
    var_4 = Null()
    action_module_1 = ActionModule(var_3, var_4, var_3, var_3, var_3, var_3)
    var_5 = None
    var_6 = action_run(var_5, var_5)



# Generated at 2022-06-25 07:38:31.608763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_4 = None
    var_5 = dict()
    var_5.put('use', 'auto')
    var_6 = ActionModule(var_4, var_5, var_4, var_4, var_4, var_4)
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_6.test_case_0(var_7, var_8)
    var_6.test_case_1(var_9, var_10)
    var_6.test_case_2(var_11, var_7)

# Generated at 2022-06-25 07:38:34.775363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = None
    var_2 = action_run(var_1, var_1)

# Generated at 2022-06-25 07:38:36.753684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = None
    var_2 = action_run(var_0, var_1)

# Generated at 2022-06-25 07:38:41.513472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    assert ran_setup() == True


# Generated at 2022-06-25 07:38:50.135123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup stubs
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = None
    action_module_0._supports_check_mode = True
    action_module_0._supports_async = True
    # Setup stubs
    var_2 = None
    var_3 = {}
    var_4 = AnsibleAction(var_2, var_3, var_3)
    # Setup stubs
    var_5 = {}
    var_5['ansible_facts'] = {}
    var_5['ansible_facts']['service_mgr'] = 'auto'
    var_6 = 'auto'

# Generated at 2022-06-25 07:38:52.686455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    action_module_1 = ActionModule(var_3, var_4, var_5, var_6, var_7, var_8)


# Generated at 2022-06-25 07:40:23.029966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = ActionModule(var_1, var_1, var_1, var_1, var_1, var_1)


# Generated at 2022-06-25 07:40:30.313049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = ActionModule(var_3, var_4, var_5, var_6, var_7, var_8)
    var_10 = ActionModule(var_3, var_4, var_5, var_6, var_7, var_8)
    var_11 = ActionModule(var_3, var_4, var_5, var_6, var_7, var_8)
    var_12 = ActionModule(var_3, var_4, var_5, var_6, var_7, var_8)

# Generated at 2022-06-25 07:40:33.160830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = ActionModule(var_3, var_4, var_5, var_6, var_7, var_8)
    assert isinstance(var_9, ActionModule)


# Generated at 2022-06-25 07:40:36.644995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert(action_module_0.TRANSFERS_FILES == False)



# Generated at 2022-06-25 07:40:39.924952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    action_module_1 = ActionModule(var_3, var_4, var_5, var_6, var_7, var_8)
    assert action_module_1 is not None


# Generated at 2022-06-25 07:40:44.769107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #sigh, we want to create a task object for testing purposes but this is a protected class
    #so we're forced to use protected functions to build the object for testing
    #alternative options are to either make the task object public or to build a testable object that
    #mimics the properties of the task object
    var_0 = None
    var_1 = None
    var_2 = None
    task_vars_0 = None
    action_module_0 = ActionModule(var_0, var_1, var_2, var_2, var_2, var_2)



# Generated at 2022-06-25 07:40:46.666802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = None
    var_3 = None
    var_4 = action_run(var_2, var_3)
    assert var_4 == var_1


# Generated at 2022-06-25 07:40:49.598301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = ActionModule(var_3, var_4, var_5, var_6, var_7, var_8)
    var_10 = None
    var_11 = None
    var_12 = var_9.run(var_10, var_11)
    assert "AnsibleActionFail" in str(var_12["_ansible_no_log"])

# Generated at 2022-06-25 07:40:50.944722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_run is not None, "Method run not implemented"

# Generated at 2022-06-25 07:40:53.856485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    assert isinstance(var_6, ActionModule)
