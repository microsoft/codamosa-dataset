

# Generated at 2022-06-25 07:31:27.590146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('start to test')
    
    int_0 = -811
    dict_0 = {int_0: int_0}
    list_0 = [int_0, int_0]
    bool_0 = False
    list_1 = [int_0, bool_0]
    dict_1 = {int_0: int_0, bool_0: bool_0, int_0: bool_0}
    int_1 = 715
    list_2 = [int_1, list_1, bool_0, bool_0]
    list_3 = [int_0] * 5
    dict_2 = {int_1: list_0, bool_0: int_1, list_1: list_2, bool_0: int_1}
    int_2 = -330

# Generated at 2022-06-25 07:31:30.920233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    system_0 = ActionModule()
    dict_0 = dict()
    dict_0['use'] = 'auto'
    ActionModule.run(system_0, dict_0)

test_ActionModule_run()

# Generated at 2022-06-25 07:31:37.654466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -4359
    int_1 = -24189
    int_2 = -36001
    list_0 = [int_1]
    list_1 = [int_0, int_2, int_1]
    list_2 = [int_1, int_1, int_1]
    list_3 = [int_2, int_2, int_2]
    list_4 = [int_0, int_1, int_2]
    list_5 = [int_1, int_2, int_0]
    list_6 = [int_1, int_1, int_1]
    list_7 = [int_2]
    list_8 = [int_0, int_0, int_1]
    list_9 = [int_2]

# Generated at 2022-06-25 07:31:40.899283
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Call method run of class ActionModule with arguments
    # self, tmp=None, task_vars=None
    # test case 0

    test_case_0()

# Generated at 2022-06-25 07:31:43.770735
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an object of the class
    obj = ActionModule()
    # Invoke the run method on the object
    obj.run()

# Generated at 2022-06-25 07:31:53.451897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1496
    str_0 = '_'
    str_1 = '`'
    str_2 = '`'
    str_3 = '`'
    str_4 = '`'
    str_5 = '`'
    str_6 = '`'
    str_7 = '`'
    str_8 = '`'
    str_9 = '`'
    str_10 = '`'
    str_11 = '`'
    str_12 = '`'
    str_13 = '`'
    str_14 = '`'
    str_15 = '`'
    str_16 = '`'
    str_17 = '`'
    str_18 = '`'
    str_19 = '`'
    str_20 = '`'
   

# Generated at 2022-06-25 07:31:56.721633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule()
    with pytest.raises(AnsibleActionFail) as ex:
        t.run('tmp', 'task_vars')
    assert "Could not detect which service manager to use" in str(ex.value)

# Generated at 2022-06-25 07:31:57.596833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:31:58.828794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:32:06.307986
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:32:16.724728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(action_module_0 != None)
    return action_module_0


# End of method name that starts with test_


# Generated at 2022-06-25 07:32:17.876080
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(0,0)


# Generated at 2022-06-25 07:32:21.391611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False
# vim: set ts=4 sw=4 et:

# Generated at 2022-06-25 07:32:28.352712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We can refactor this to avoid the duplication
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    def _find_service_mgr_from_path():
        return NotImplementedError()

    original_find_service_mgr_from_path = ServiceMgrFactCollector._find_service_mgr_from_path
    try:
        ServiceMgrFactCollector._find_service_mgr_from_path = _find_service_mgr_from_path
        action_module_0 = ActionModule()
        action_module_0.run()
    finally:
        ServiceMgrFactCollector._find_service_mgr_from_path = original_find_service_mgr_from_path


# Generated at 2022-06-25 07:32:32.957506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg = dict(
        use = 'auto',
        name = 'httpd',
    )
    action_module_run = ActionModule()
    assert action_module_run.run(arg) == dict(
        ansible_facts = dict(
            ansible_service_mgr = "Failed to get a service manager.",
        ),
        changed = False,
        failed = True,
    )

# Generated at 2022-06-25 07:32:44.821537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Testcase with inputs
    # Run instance with 'module' value as 'auto' and 'async' value as 'default'
    action_module_0.run()

    # Testcase with inputs
    # Run instance with 'module' value as 'auto' and 'async' value as 'default'
    action_module_0.run()

    # Testcase with inputs
    # Run instance with 'module' value as 'auto' and 'async' value as 'default'
    action_module_0.run()

    # Testcase with inputs
    # Run instance with 'module' value as 'auto' and 'async' value as 'default'
    action_module_0.run()

    # Testcase with inputs
    # Run instance with 'module' value as 'auto' and 'async

# Generated at 2022-06-25 07:32:50.165169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_str = str(type(action_module_0))
    assert action_module_str == "<class 'ansible.plugins.action.service.ActionModule'>"

#Unit test for 'supports_check_mode' property

# Generated at 2022-06-25 07:32:53.123780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run = ActionModule()
    action_module_run.run('tmp', 'task_vars')


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:32:56.617369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule()
    try:
        action_module_2.run()
    except:
        pass

# Generated at 2022-06-25 07:33:00.902510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test run of ActionModule: ")
    test_case_0()

# Generated at 2022-06-25 07:33:19.750997
# Unit test for constructor of class ActionModule
def test_ActionModule():

    host = "127.0.0.1"
    connection = "local"
    remote_user = "james"
    module_name = "setup"

    # Test for primary constructor
    action_module = ActionModule(host, connection, remote_user, True, None, None, module_name)

    assert isinstance(action_module, ActionModule)
    assert action_module._task.action == "setup"
    assert action_module._task.args == {}
    assert action_module._task.delegate_to == "_default"
    assert action_module._task.delegate_facts == False
    assert action_module._task.loop is None
    assert action_module._task.loop_args == {}
    assert action_module._task.module_defaults == {}
    assert action_module._task.no_log == False


# Generated at 2022-06-25 07:33:20.370839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:33:27.767255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module = ActionModule()
  tmp = None
  task_vars = None
  try:
    action_module.run(tmp, task_vars)
  except (AnsibleActionFail) as exception:
    print(exception)
  # AssertionError: Could not detect which service manager to use. Try gathering facts or setting the "use" option.

if __name__ == '__main__':
  test_case_0()
  test_ActionModule_run()

# Generated at 2022-06-25 07:33:33.418151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'fG'
    str_1 = 'Desktop'
    bool_0 = True
    bytes_0 = None
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'S\xb2'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    bytes_2 = b'\x93p\xc8c\xf5\x9c\\\x8fS\xed'
    action_module_1 = ActionModule(set_0, tuple_0, bytes_1, tuple_0, tuple_0, bytes_2)
    var_0 = action

# Generated at 2022-06-25 07:33:34.580215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # initialize the object
    action_module_0 = ActionModule()
    # test whether the object is constructed successfully
    assert action_module_0

# Generated at 2022-06-25 07:33:35.498938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:33:40.672205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'fG'
    str_1 = 'Desktop'
    bool_0 = True
    bytes_0 = None
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'S\xb2'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    bytes_2 = b'\x93p\xc8c\xf5\x9c\\\x8fS\xed'
    action_module_1 = ActionModule(set_0, tuple_0, bytes_1, tuple_0, tuple_0, bytes_2)
    var_0 = action

# Generated at 2022-06-25 07:33:42.833867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = 'fG'
    str_3 = 'Desktop'
    bool_1 = True
    bytes_3 = None
    list_1 = [bool_1]
    action_module_2 = ActionModule(str_2, str_2, str_3, bool_1, bytes_3, list_1)


# Generated at 2022-06-25 07:33:53.704375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'H\xfe'
    str_1 = 'Documents'
    bool_1 = True

# Generated at 2022-06-25 07:34:04.087695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'fG'
    str_1 = 'Desktop'
    bool_0 = True
    bytes_0 = None
    list_0 = [bool_0]
    action_module_2 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'S\xb2'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    bytes_2 = b'\x93p\xc8c\xf5\x9c\\\x8fS\xed'
    action_module_2 = ActionModule(set_0, tuple_0, bytes_1, tuple_0, tuple_0, bytes_2)


# Generated at 2022-06-25 07:34:28.810677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule()
    str_2 = 'Tab'
    bytes_3 = b'\xdb\x14\x96\x8e\x95\xc1'
    set_1 = {bytes_3}
    action_module_2.set_loader(str_2, set_1)
    action_module_2.set_task(str_2, set_1)
    dict_0 = {str_2: set_1}
    str_3 = 'Ob'
    int_1 = 400
    bool_1 = True
    action_module_2.set_task_vars(str_3, int_1, str_3, bool_1)

# Generated at 2022-06-25 07:34:37.719167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '~W<QK@'
    bytes_0 = b'\x8f\x91'
    bytes_1 = b'\x83n'
    bytes_2 = b'\x8bw\x1d'
    str_1 = '.'
    list_0 = [bytes_0, bytes_2, bytes_1]
    action_module_0 = ActionModule(str_0, str_0, str_0, str_1, bytes_1, list_0)
    bytes_3 = b'\x03\xaa'
    str_2 = '\\Z[\x13'
    bytes_4 = b'\xb9'
    bytes_5 = b'\xa7\xad'
    set_0 = {bytes_4, bytes_3, bytes_5}
   

# Generated at 2022-06-25 07:34:48.231604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'P3q'
    str_1 = 'Desktop'
    bool_0 = False
    bytes_0 = None
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'\x85V\xfa\x89\x1c\xd12S\xb9'
    dict_0 = {}
    dict_1 = {dict_0: bool_0}
    int_0 = 200
    set_0 = {int_0, int_0}
    float_0 = 0.315
    dict_2 = {dict_1: float_0}
    dict_3 = {dict_2: dict_2}

# Generated at 2022-06-25 07:34:50.835464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:34:59.961511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'hX'
    str_1 = 'Users'
    bool_0 = True
    bytes_0 = None
    list_0 = [str_1, str_1]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'\n\xc4\xbd\xfa\x9d\xac\x06\xbc\xfe\x8e\xe1\xcc\xb3\x02\x1c\xdf'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    int_1 = 100
    float_0 = 2.0

# Generated at 2022-06-25 07:35:00.589408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:35:06.692114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Running test: test_ActionModule_run")
    test_case_0()


if __name__ == '__main__':
    import sys
    print("Testing: ", sys.argv[0])
    test_ActionModule_run()

# Generated at 2022-06-25 07:35:12.862073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'fG'
    str_1 = 'Desktop'
    bool_0 = True
    bytes_0 = None
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'S\xb2'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    bytes_2 = b'\x93p\xc8c\xf5\x9c\\\x8fS\xed'
    action_module_1 = ActionModule(set_0, tuple_0, bytes_1, tuple_0, tuple_0, bytes_2)
    var_0 = action

# Generated at 2022-06-25 07:35:23.567816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = 'C7l'
    str_3 = '.'
    str_4 = 'xk'
    bool_1 = False
    bytes_3 = b'\xef\x12\x9b\xab\r\xb2\xc4\xf4\x1c'
    list_1 = [bool_1]
    action_module_2 = ActionModule(str_3, str_4, str_2, bool_1, bytes_3, list_1)
    bytes_4 = b'\x10\xc1\xcc'
    set_1 = {bytes_4}
    int_1 = 21
    tuple_1 = (set_1, int_1)

# Generated at 2022-06-25 07:35:32.614944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_2 = 'J1'
    str_3 = 'Stable'
    str_4 = 'Stable'
    dict_0 = dict()
    dict_0['Stable'] = str_4
    str_5 = 'Stable'
    dict_0['Stable'] = str_5
    dict_0['Stable'] = dict_0
    dict_0['Stable'] = dict_0
    dict_0['Stable'] = dict_0
    dict_0['Stable'] = dict_0
    dict_0['Stable'] = dict_0
    dict_0['Stable'] = dict_0
    dict_0['Stable'] = dict_0
    dict_0['Stable'] = str_2
    dict_0['Stable'] = dict_0
    dict_0['Stable']

# Generated at 2022-06-25 07:36:08.234410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = 'gA'
    str_3 = 'Documents'
    bool_1 = False
    bytes_3 = b'\xb2\xcb'
    list_1 = [bool_1]
    action_module_2 = ActionModule(str_2, str_3, str_3, bool_1, bytes_3, list_1)
    bytes_4 = b'\x8c\x88\xc1\xab'
    set_1 = {bytes_4}
    int_1 = 200
    tuple_1 = (set_1, int_1)
    bytes_5 = b'\x9a\x9d\xcbN\xd7\x02\x90\xfe'

# Generated at 2022-06-25 07:36:09.018901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

#========================================


# Generated at 2022-06-25 07:36:18.849368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\x88\x00\xcd\xf1\x9b\xe9\xea\xad'
    str_1 = '$'
    bool_0 = False
    bytes_0 = b'!'
    list_0 = [str_1]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    assert (action_module_0._task.args == {'use': 'auto'})
    str_2 = 'L\xbd'
    str_3 = '~'
    bytes_1 = b'\xa2\xc2\xac'
    list_1 = [str_3]
    tuple_0 = (str_3, bytes_1)
    action_module_1 = Action

# Generated at 2022-06-25 07:36:20.077656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:36:29.530128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('Desktop', 'fG', 'Desktop', True, None, [True])
    assert action_module_0._connection.connection == 'fG'
    assert action_module_0._task.action == 'Desktop'
    assert action_module_0._task.args == {}
    assert action_module_0._loader.get_basedir == 'fG'
    assert action_module_0._connection.tmpdir == '/tmp/ansible_fG_Desktop'
    assert action_module_0._shared_loader_obj._module_cache == {}
    assert action_module_0._shared_loader_obj._module_name_cache == {}
    assert action_module_0._shared_loader_obj.action_loader == {}

# Generated at 2022-06-25 07:36:39.033554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'fG'
    str_1 = 'Desktop'
    bool_0 = True
    bytes_0 = None
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'S\xb2'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    bytes_2 = b'\x93p\xc8c\xf5\x9c\\\x8fS\xed'
    action_module_1 = ActionModule(set_0, tuple_0, bytes_1, tuple_0, tuple_0, bytes_2)
    var_0 = action

# Generated at 2022-06-25 07:36:49.444407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'fG'
    str_1 = 'Desktop'
    bool_0 = True
    bytes_0 = None
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'S\xb2'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    bytes_2 = b'\x93p\xc8c\xf5\x9c\\\x8fS\xed'
    action_module_1 = ActionModule(set_0, tuple_0, bytes_1, tuple_0, tuple_0, bytes_2)
    var_0 = action

# Generated at 2022-06-25 07:36:55.558235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ZX'
    str_1 = 'Desktop'
    bool_0 = True
    bytes_0 = None
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'S\xb2'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    bytes_2 = b'\x93p\xc8c\xf5\x9c\\\x8fS\xed'
    action_module_1 = ActionModule(set_0, tuple_0, bytes_1, tuple_0, tuple_0, bytes_2)
    var_0 = action_

# Generated at 2022-06-25 07:36:59.833647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_2 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    assert action_module_2.TRANSFERS_FILES == False



# Generated at 2022-06-25 07:37:09.884667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'g\x80\x15\xfe'
    str_1 = 'C:\\Program Files (x86)\\VMware\\Infrastructure\\UISnapins\\PscViews\\Login'
    bool_0 = True
    bytes_0 = None
    list_0 = []
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    assert str_0 is action_module_0._task.action
    assert str_0 is action_module_0._task.name
    assert str_1 is action_module_0._task.delegate_to
    assert bool_0 is action_module_0._task.async_val
    assert bytes_0 is action_module_0._task.async_poll_

# Generated at 2022-06-25 07:38:16.968383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'fG'
    str_1 = 'Desktop'
    bool_0 = True
    bytes_0 = None
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'S\xb2'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    bytes_2 = b'\x93p\xc8c\xf5\x9c\\\x8fS\xed'
    action_module_1 = ActionModule(set_0, tuple_0, bytes_1, tuple_0, tuple_0, bytes_2)
    # Constructor for class

# Generated at 2022-06-25 07:38:26.084148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mutable = { 'key' : [ 0, 0 ] }
    str_0 = 'o('
    str_1 = 'File'
    bool_0 = True
    bytes_0 = b'\x9d\x9e\x87'
    list_0 = [mutable, mutable]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    int_0 = 5
    list_1 = [mutable]
    action_module_1 = ActionModule(str_0, int_0, str_1, int_0, bytes_0, list_1)
    bytes_1 = b'\x14\xc8\x05p\x9c'
    dict_0 = {'key': bytes_1}
   

# Generated at 2022-06-25 07:38:27.592521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    test_case_0()


# Generated at 2022-06-25 07:38:28.941012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:38:30.397366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:38:38.019019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'desktop'
    str_1 = 'test case 2'
    bool_0 = True
    bytes_0 = b'\x16A'
    list_0 = [str_1]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    bytes_1 = b'\x90\x98\xc0'
    set_0 = {bytes_1}
    int_0 = 200
    tuple_0 = (set_0, int_0)
    bytes_2 = b'\xf9\x12\xb1\xa5!\xcb\x01\x99\x88\xa3d\x8a'

# Generated at 2022-06-25 07:38:47.388870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '#G'
    str_1 = 'Info.plist'
    bool_0 = True
    bytes_0 = None
    list_0 = [str_0, str_1]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    assert action_module_0._task.args.get('name') == 'wget'
    assert action_module_0._supports_check_mode is True
    assert action_module_0._supports_async is True
    assert action_module_0._display.verbosity >= 2


# Generated at 2022-06-25 07:38:47.990694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:38:56.011061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with mock.patch('ansible.plugins.action.ActionBase._execute_module') as mock_run:
        str_0 = 'fG'
        str_1 = 'Desktop'
        bool_0 = True
        bytes_0 = None
        list_0 = [bool_0]
        action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
        bytes_1 = b'S\xb2'
        set_0 = {bytes_1}
        int_0 = 200
        tuple_0 = (set_0, int_0)
        bytes_2 = b'\x93p\xc8c\xf5\x9c\\\x8fS\xed'

# Generated at 2022-06-25 07:39:04.266536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Cx'
    str_1 = 'Task'
    bool_0 = False
    bytes_0 = b'\xbf\xc8\xab\xa3'
    list_0 = [str_0]
    action_module_0 = ActionModule(str_0, str_0, str_1, bool_0, bytes_0, list_0)
    # if no exception was thrown represents the test as passed
    print("PASSED: No exception thrown while instantiating class ActionModule")
