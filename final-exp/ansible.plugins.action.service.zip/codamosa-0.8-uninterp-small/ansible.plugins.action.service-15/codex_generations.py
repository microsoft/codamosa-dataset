

# Generated at 2022-06-25 07:31:31.101891
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Human-readable test data.
    dict_0 = dict()
    dict_1 = {'ansible_service_mgr': 'auto'}
    dict_2 = dict()
    dict_2['module'] = 'ansible.legacy.setup'
    dict_2['module_args'] = dict()
    dict_2['module_args']['gather_subset'] = '!all'
    dict_2['module_args']['filter'] = 'ansible_service_mgr'
    dict_2['task_vars'] = dict()
    dict_2['task_vars']['ansible_facts'] = dict_1
    dict_2['task_vars']["ansible_facts"] = dict_1

# Generated at 2022-06-25 07:31:31.952667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:31:40.431276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'H\xa7\x96'
    dict_0 = {bytes_0: bytes_0}
    str_0 = '0v\x1c\x98\'x3\x13O\x0e'
    int_0 = 914
    bool_0 = False
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)


# Generated at 2022-06-25 07:31:49.549375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'ansible.legacy.service'
    dict_0 = {'name': 'test', 'command': 'start'}
    dict_1 = {'name': 'test', 'command': 'start'}
    str_0 = 'test_play'
    int_0 = 13
    bool_0 = True
    float_0 = 0.0
    action_module_0 = ActionModule(str_0, dict_0, str_0, int_0, bool_0, float_0)
    action_module_0.test_var = dict_1
    action_module_0._supports_check_mode = bool_0
    action_module_0._supports_async = bool_0
    tmp = None
    task_vars = None
    # result = action_module_0.run(tmp=

# Generated at 2022-06-25 07:31:51.382845
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        assert False

    assert True

# Generated at 2022-06-25 07:31:52.024205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)

# Generated at 2022-06-25 07:32:01.196553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'(K\x0f\x17\xe6\x8b\xf0\xb4\x1bm@\x8by\x9a'
    dict_0 = {bytes_0: bytes_0}
    str_0 = '>F+|K\x10\x18\x9c\xf1\xba\x1a\x0c\\\x0e\xed\x9c\x9b'
    int_0 = 1111
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)

# Generated at 2022-06-25 07:32:01.978152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:32:08.421592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xd5\x81\x9f\xef\x14F\xaa\x88\xbd\xa5\xcf\xbf\x1c\xd1\x9d\xab\x01\x0e'
    str_0 = '(\xeb\xb4\xff\x9b\x8e\x0f\xf7\xb1\xbf\xbd\xd8\xaf#\x9aB\x0c\x92\x18\xa1\x93\xb8\xaa\xeb\xa7\x9a\x8a\x96\xdc\x1c\xb4\x02\xe4\x04\x9d\x9b\xab'
    int_0 = 125
    bool_0 = True

# Generated at 2022-06-25 07:32:18.471882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xa5\x1a\xe4\xde\xd4\xbePU/\x19\x8f\xbd\xb1\x1a\x84\x8c\x94d'
    dict_0 = {}
    str_0 = 'AJ\x80o\xeb\x04G\x1e\xf3\xec\xa1%\x9b\x88'
    int_0 = 454
    bool_0 = False
    float_0 = 1.0
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:32:34.765777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup args for get_action_args_with_defaults
    module_name = 'ansible.legacy.service'
    module_args = {'use': 'auto'}

# Generated at 2022-06-25 07:32:45.875634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    bytes_0 = b'\x1bc\x94\xb3\xa0\x89\x16\x8d\xeb\xc2\x1b\xaf\xc0\x92\x18\x89\x97\x8a\xa4\xb6\xdd\x12\x80'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'z\x10\x0e\xdf\xdb\x1f\x15\xe8'
    int_0 = 1963
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    var_0 = {}
    var_

# Generated at 2022-06-25 07:32:48.833438
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:32:55.136864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    obj_0 = test_case_0('\xdd\x01\x8d\x04')
    obj_0._task.async_val = True
    if isinstance(obj_0._loader, test_case_0):
        test_case_0()
    obj_0._task.async_val = False

# Generated at 2022-06-25 07:32:55.536244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:33:04.572267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_1 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    print(action_module_1)

# Unittest for this class

# Generated at 2022-06-25 07:33:13.610893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    print(action_module_0)


# Generated at 2022-06-25 07:33:17.368967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of ActionModule class...")
    try:
        test_case_0()
        print("Testing constructor of ActionModule class: successful")
    except:
        print("Testing constructor of ActionModule class: failed")


# Generated at 2022-06-25 07:33:25.813692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)


# Generated at 2022-06-25 07:33:33.743281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert (action_module_0._supports_async == False)
    assert (action_module_0._supports_check_mode == False)
    assert (action_module_0.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'})
    assert (action_module_0.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']})



# Generated at 2022-06-25 07:33:49.492085
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement unit test for constructor of class ActionModule
    pass

# Generated at 2022-06-25 07:33:50.330060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule().run())


# Generated at 2022-06-25 07:33:54.456651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 07:34:00.782639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:34:01.607467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("paiz")
test_case_0()

# Generated at 2022-06-25 07:34:07.569187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'arg1': 123, 'arg2': 'abc', 'arg3': True}
    action_module_0 = ActionModule(dict_0)
    if isinstance(action_module_0, ActionModule):
        assert True
    else:
        assert False


# Generated at 2022-06-25 07:34:13.797554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:34:16.767010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert func_0() == 1


# Generated at 2022-06-25 07:34:18.206775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Setup fixture
  test_case_0()
  # Exercise SUT
  action_module_0.run()

# Generated at 2022-06-25 07:34:28.444641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\r\xf7\x1d\x0b\x1d?p\x9cP\x9a\x19\x10\x11\x17"
    dict_0 = {bytes_0: bytes_0}
    str_0 = "=\xef\x98\xa6\xb5\x15\x8b\x9dM\xfd\x01.I\x1b"
    int_0 = 1230
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    action_module_0.run()


# Generated at 2022-06-25 07:35:02.412561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys, types, os
    try:
        sys.modules[__name__]
    except:
        sys.modules[__name__] = types.ModuleType(__name__)
    return_value = ActionModule()
    assert isinstance(return_value, ActionModule)
    assert type(return_value) == ActionModule


# Generated at 2022-06-25 07:35:12.080235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test initialization
    action_module_0 = ActionModule()
    assert action_module_0.action_anonymous_0 == None, 'expected true'
    assert action_module_0._supports_check_mode == None, 'expected true'
    assert action_module_0.action_anonymous_1 == None, 'expected true'
    assert action_module_0.action_anonymous_2 == None, 'expected true'
    assert action_module_0.action_anonymous_3 == None, 'expected true'
    assert action_module_0.action_anonymous_4 == None, 'expected true'
    assert action_module_0.action_anonymous_5 == None, 'expected true'
    assert action_module_0.action_anonymous_6 == None, 'expected true'
    assert action_module_0

# Generated at 2022-06-25 07:35:23.147106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0._task == bytes_0

# Generated at 2022-06-25 07:35:31.988420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    var_0 = action_run()

    assert var_0 == {"fails": "fails", "returns": "returns", "successes": "successes"}

# Generated at 2022-06-25 07:35:40.424528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    module = 'auto'
    try:
        if action_module_0.task.delegate_to:  # if we delegate, we should use delegated host's facts
            pass
        else:
            pass
    except Exception:
        pass

# Generated at 2022-06-25 07:35:42.014187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:35:42.553655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert method_run() == expected_result

# Generated at 2022-06-25 07:35:46.140753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:35:49.112573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of class ActionModule
    action_module_0 = ActionModule()
    str_0 = action_module_0.run()
    assert ((type(str_0) is repr) or (type(str_0) is bytes))


# Generated at 2022-06-25 07:35:56.401447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'V4X\x05\xfd\xa2\xfd\xc8\xfeM\x7f\x1e.V\x8f\xb4\xee\xbf\x17\xc8\x0c^\xb0'
    dict_0 = {bytes_0: bytes_0}
    str_0 = '\x92\xf0\xeb\xf3\x9d\x1c\x1f"'
    int_0 = 1508
    bool_0 = True
    float_0 = 0.9
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)

# Generated at 2022-06-25 07:37:09.342772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'&\xdd\xa8\xe3\xd0]\xad\xc6\x8c\xab\xcf\x9c'
    dict_0 = {bytes_0: bytes_0}
    str_0 = '\\\x1d/kzZ \x0b'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True

# Generated at 2022-06-25 07:37:15.759353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    action_module_0 = ActionModule()
    action_run = pytest.raises(AnsibleAction, action_module_0.run())
    assert action_run == AnsibleActionFail('Could not detect which service manager to use. Try gathering facts or setting the "use" option.')


# Generated at 2022-06-25 07:37:24.070894
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\'\xa5\x9b\x0e'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'G\x9b\xd9\xfb\x8f\xeb-\xf1\xa2\x08\xc1\x13'
    int_0 = 1337
    bool_0 = False
    float_0 = 0.1
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    test_case_0()


# Generated at 2022-06-25 07:37:31.145695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {0: 0.25}
    str_0 = '=S\x19\x18v\x03\x16]\x9a\x9d,'
    int_0 = 0
    bool_0 = True
    float_0 = 0.125
    action_module_0 = ActionModule(dict_0, str_0, int_0, bool_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:37:41.433814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    assert action_module_0.task.args == dict_0

# Generated at 2022-06-25 07:37:42.994898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:37:49.218941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_0['alien'] = 'minion'
    dict_0['alien_word'] = 'arrakis'
    dict_0['alien_thing'] = 'sandworm'
    dict_0['ansible_version'] = 'ansible 2.5.5'
    dict_0['ansible_python_version'] = '2.7.12 (default, Nov 20 2017, 18:23:56) [GCC 5.4.0 20160609]'
    dict_0['ansible_python_version_major'] = '2'
    dict_0['ansible_python_version_minor'] = '7'
    dict_0['ansible_python_version_micro'] = '12'

# Generated at 2022-06-25 07:37:59.817035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t_ansible_action_fail_0 = AnsibleActionFail('ansible.legacy.auto')
    t_dict_0 = {t_ansible_action_fail_0: t_ansible_action_fail_0}
    t_str_0 = '\xaa\xd2\x83R\x1c\x0c\xc7\x83\xcf\x85\xa8\xc9\xdb\xf2'
    t_int_0 = 767
    t_bool_0 = False
    t_float_0 = 0.8943603949881746
    t_action_module_0 = ActionModule(t_ansible_action_fail_0, t_dict_0, t_str_0, t_int_0, t_bool_0, t_float_0)

# Generated at 2022-06-25 07:38:00.749423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:38:01.530244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:40:48.897549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    #Test case 0
    action_module_0.run()


# Generated at 2022-06-25 07:40:49.481564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:40:50.337952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:40:51.242409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()
    return var_1

# Generated at 2022-06-25 07:40:52.125331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Method to run unit test

# Generated at 2022-06-25 07:40:57.036396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
    action_module_0.run()

# Generated at 2022-06-25 07:41:02.750648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)

# Generated at 2022-06-25 07:41:03.864871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #TODO: Test for constructor of class ActionModule
    pass

# Generated at 2022-06-25 07:41:09.883949
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test constructor of class ActionModule')
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)


# Generated at 2022-06-25 07:41:12.626750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xc8t\xe9K\xbdDa\xa34\xee\xe8\xfe\xb4\xb4\xbc\x90\x92'
    dict_0 = {bytes_0: bytes_0}
    str_0 = 'Y,\x0by:b9Oe m'
    int_0 = 1128
    bool_0 = True
    float_0 = 0.5
    action_module_0 = ActionModule(bytes_0, dict_0, str_0, int_0, bool_0, float_0)
