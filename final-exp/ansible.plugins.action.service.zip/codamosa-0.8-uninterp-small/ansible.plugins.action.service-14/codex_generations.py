

# Generated at 2022-06-25 07:31:24.629720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    set_0 = {dict_0, dict_0}
    list_0 = [set_0]
    bool_0 = False
    action_module_0 = ActionModule(dict_0, set_0, list_0, set_0, list_0, bool_0)


# Generated at 2022-06-25 07:31:26.732302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() is None

# Generated at 2022-06-25 07:31:31.036123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    set_0 = {dict_0, dict_0}
    list_0 = [set_0]
    bool_0 = False
    action_module_0 = ActionModule(dict_0, set_0, list_0, set_0, list_0, bool_0)

    tmp = None;
    task_vars = None;

    action_module_0.run(tmp, task_vars)
    test_case_0()

# Generated at 2022-06-25 07:31:31.878349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:31:39.626931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    set_0 = {dict_0}
    list_0 = [set_0]
    bool_0 = False
    action_module_0 = ActionModule(dict_0, set_0, list_0, set_0, list_0, bool_0)
    result = action_module_0.run(None, None)

# Generated at 2022-06-25 07:31:45.893517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    set_0 = {dict_0, dict_0}
    list_0 = [set_0]
    bool_0 = False
    action_module_0 = ActionModule(dict_0, set_0, list_0, set_0, list_0, bool_0)
    assert action_module_0


# Generated at 2022-06-25 07:31:51.172550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    set_0 = {dict_0, dict_0}
    list_0 = [set_0]
    bool_0 = False
    action_module_0 = ActionModule(dict_0, set_0, list_0, set_0, list_0, bool_0)
    action_module_0.run()


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:31:55.801739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    set_0 = {dict_0, dict_0}
    list_0 = [set_0]
    bool_0 = False
    action_module_0 = ActionModule(dict_0, set_0, list_0, set_0, list_0, bool_0)


# Generated at 2022-06-25 07:31:56.721978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:32:01.861396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'ansible.legacy.setup'
    module_args = dict()
    task_vars = None
    tmp = None
    
    # When use is 'auto'
    action_module_0 = ActionModule(module_name, module_args, task_vars, tmp)
    try:
        action_module_0.run()
    except AnsibleAction:
        pass

    # When module is 'auto'
    action_module_1 = ActionModule(module_name, module_args, task_vars, tmp)
    try:
        action_module_1.run()
    except AnsibleAction:
        pass

# Generated at 2022-06-25 07:32:12.422904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {}
    bool_1 = False
    action_module_1 = ActionModule(var_1, var_1, bool_1, var_1, bool_1, bool_1)


# Generated at 2022-06-25 07:32:17.800337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    bool_0 = False
    action_module_0 = ActionModule(var_0, var_0, bool_0, var_0, bool_0, bool_0)
    str_0 = str()
    str_1 = str()
    var_1 = action_module_0.run(str_0, str_1)
    del str_0, bool_0, action_module_0, str_1, var_0, var_1

# Generated at 2022-06-25 07:32:24.372413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {}
    bool_1 = False
    action_module_1 = ActionModule(var_1, var_1, bool_1, var_1, bool_1, bool_1)
    assert type(action_module_1) == ActionModule


# Generated at 2022-06-25 07:32:28.415185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    bool_0 = False
    action_module_0 = ActionModule(var_0, var_0, bool_0, var_0, bool_0, bool_0)



# Generated at 2022-06-25 07:32:31.027296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {}
    bool_1 = False
    action_module_1 = ActionModule(var_1, var_1, bool_1, var_1, bool_1, bool_1)


# Generated at 2022-06-25 07:32:34.876725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    bool_0 = False
    action_module_0 = ActionModule(var_0, var_0, bool_0, var_0, bool_0, bool_0)
    bool_0 = action_module_0._supports_async
    assert bool_0 == True
    bool_0 = action_module_0._supports_check_mode
    assert bool_0 == True

# Generated at 2022-06-25 07:32:40.709844
# Unit test for constructor of class ActionModule
def test_ActionModule():
	try:
		action_module_0 = ActionModule()
	except Exception as e:
		print(str(e))
		raise AssertionError('Exception raised')
	else:
		pass


# end class ActionModule


# Generated at 2022-06-25 07:32:42.528470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    bool_0 = False
    action_module_0 = ActionModule(var_0, var_0, bool_0, var_0, bool_0, bool_0)
    var_2 = None
    var_3 = None
    action_module_0.run(var_2, var_3)

# Manual test coverage for ActionModule.run

# Generated at 2022-06-25 07:32:44.423783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {}
    bool_1 = False
    action_module_1 = ActionModule(var_1, var_1, bool_1, var_1, bool_1, bool_1)

# Generated at 2022-06-25 07:32:55.756362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(None, None, None, None, True, False)
    var_1 = None
    var_2 = {}
    var_3 = None
    var_4 = None
    var_4 = var_3
    var_2 = var_4
    var_2 = var_4
    var_2 = var_4
    var_1 = var_2
    var_5 = var_1
    var_6 = var_1
    var_6 = var_5
    var_6 = var_6
    var_7 = var_1
    var_7 = var_6
    var_7 = var_6
    var_6 = var_7
    var_8 = var_7
    var_9 = var_7
    var_8 = var_9
    var_10 = var

# Generated at 2022-06-25 07:33:04.961343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:33:05.686296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:33:09.410491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = ""
    task_vars = ""
    action_module_run_object = ActionModule()
    action_module_run_object.run(tmp, task_vars)



# Generated at 2022-06-25 07:33:18.459612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # data
    args = {}
    task_vars = {}
    tmp = None

    # act
    result = action_module_0.run(tmp, task_vars)

    # assert
    assert result == {
        'ansible_loop_var': 'item',
        'changed': False,
        'item': None,
        'skip_reason': 'Conditional result was False',
        'skipped': True,
        '_ansible_no_log': False,
        '_ansible_module_name': 'command',
        '_ansible_parsed': True}

# Generated at 2022-06-25 07:33:22.204442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module.run(tmp=None, task_vars=None)
    assert action_module.run == action_module.run
    assert action_module.run == action_module.run
    assert action_module.run == action_module.run
    assert action_module.run == action_module.run
    assert action_module.run == action_module.run

# Generated at 2022-06-25 07:33:25.268923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == NotImplementedError

# Generated at 2022-06-25 07:33:33.504154
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    task_vars = {'ansible_facts': {'service_mgr': 'systemd'}}
    task_args = {'use': 'auto', 'name': 'foo', 'state': 'started'}
    action_module._task.args = task_args
    result = action_module.run(None, task_vars)
    assert result['msg'] == 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.'
    assert result['failed'] == True

# Generated at 2022-06-25 07:33:37.672465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    action_module = ActionModule()
    tmp = None
    task_vars = dict()

    # When
    result = action_module.run(tmp, task_vars)

    # Then
    assert result is not None

# Generated at 2022-06-25 07:33:38.552197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:33:43.786629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False
    assert isinstance(action_module_0.UNUSED_PARAMS, dict)
    assert isinstance(action_module_0.BUILTIN_SVC_MGR_MODULES, set)

# Generated at 2022-06-25 07:33:57.801241
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run() == None

# Generated at 2022-06-25 07:34:00.600436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")
    action_module_0 = ActionModule() 
    action_module_0.run(tmp=None, task_vars=None)
   
if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:34:02.372780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    test_task_vars = dict()
    action_module_0.run(task_vars=test_task_vars)


# Generated at 2022-06-25 07:34:05.887598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This would fail because no value is given for tmp, task_vars.
    assert action_module_0.run() == None

# Generated at 2022-06-25 07:34:11.072425
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    print("test_ActionModule_run():TestCase0:\n")
    result = action_module_0.run(tmp=None, task_vars=None)
    print("test_ActionModule_run():result:", result)

if __name__ == '__main__':
    # unit test for class ActionModule
    print("test_action_module.py:\n")
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:12.438995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert not action_module_1 is None


# Generated at 2022-06-25 07:34:19.554037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module.run()
    action_module._loader
    action_module._templar
    action_module._shared_loader_obj
    action_module._connection
    action_module._play_context
    action_module._task
    action_module._loader_name
    action_module._task_vars
    action_module._loaded_name
    action_module._task_ds
    action_module._templar._available_variables
    action_module._valid_attrs
    action_module._display
    assert(action_module._task.action == 'service')

# Generated at 2022-06-25 07:34:23.898046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.set_task(task=None)


# Generated at 2022-06-25 07:34:28.169600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')


# Generated at 2022-06-25 07:34:37.877482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # autodetect ansible_service_mgr from facts
    action_module_1 = ActionModule()
    action_module_1._task.args = dict(name='apache2', state='started')
    action_module_1._execute_module = lambda module_name, module_args, task_vars, wrap_async=None: dict(ansible_facts=dict(ansible_service_mgr='systemd'))
    result = action_module_1.run()
    assert result['module_name'] == 'ansible.legacy.systemd'

    # use argument takes precedence over ansible_service_mgr
    action_module_2 = ActionModule()
    action_module_2._task.args = dict(name='apache2', state='started', use='openrc')
    action_module_2._execute_

# Generated at 2022-06-25 07:34:55.959848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    params = dict()
    params['use'] = 'auto'
    params['name'] = 'sshd'
    params['state'] = 'started'
    task = MockTask()
    task.args = params
    result = action_module_0.run(None, task)
    assert result is not None



# Generated at 2022-06-25 07:34:59.655147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() is None

# Generated at 2022-06-25 07:35:00.545826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print(action_module_0)


# Generated at 2022-06-25 07:35:06.633680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:35:08.349166
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test case
    # Should not have any error
    try:
        test_case_0()
    except:
        assert False

    assert True

# Generated at 2022-06-25 07:35:13.349992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize test
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None

    # Execute method
    retval = action_module_0.run(tmp=tmp, task_vars=task_vars)

    # Check result
    assert retval == None, 'Returned value does not match the expected value'



# Generated at 2022-06-25 07:35:14.865890
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c1 = ActionModule()
    c1.fail_json(msg='test')

# Generated at 2022-06-25 07:35:19.909259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_test1 = ActionModule()    
    print ("\n### Unit test for ActionModule run method")
    action_module_test1.run(tmp=None, task_vars=None)
    

# Generated at 2022-06-25 07:35:22.293689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Getting the instance of the ActionModule class
    action_module = ActionModule()
    #Checking if the instance created is of type ActionModule
    assert type(action_module) == ActionModule


# Generated at 2022-06-25 07:35:25.687666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 is not None


# Generated at 2022-06-25 07:35:58.016172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test 1:
    action_module_1 = ActionModule()

    # Test 2:
    action_module_2 = ActionModule()

    # Test 3:
    action_module_3 = ActionModule()

    # Test 4:
    action_module_4 = ActionModule()

    # Test 5:
    action_module_5 = ActionModule()

    # Test 6:
    action_module_6 = ActionModule()

    # Test 7:
    action_module_7 = ActionModule()

    # Test 8:
    action_module_8 = ActionModule()

    # Test 9:
    action_module_9 = ActionModule()

    # Test 10:
    action_module_10 = ActionModule()

    # Test 11:
    action_module_11 = ActionModule()

    # Test 12:
    action_module_12

# Generated at 2022-06-25 07:35:59.329789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0()
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:36:01.342017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:36:09.333765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for invalid service manager
    action_module_run_0 = ActionModule()
    action_module_run_0._task.args = {'name': 'ansible.legacy.service', 'use': 'ls', 'foo': 'bar'}
    action_module_run_0._task.module_defaults = {'foo': 'baz'}
    action_module_run_0._task.async_val = 2
    action_module_run_0._execute_module = lambda *args, **kwargs: {}
    action_module_run_0._display.vvvv = lambda *args, **kwargs: None
    action_module_run_0._display.warning = lambda *args, **kwargs: None

# Generated at 2022-06-25 07:36:19.029071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test example 1
    result = ActionModule().run({}, {'ansible_facts': {'service_mgr': 'ansible.legacy.systemd'}})
    assert {'changed': False, 'invocation': {'module_args': {'name': 'blah', 'state': 'started'}, 'module_name': 'ansible.legacy.service'}, 'module_name': 'ansible.legacy.service'} == result

    # Test example 2
    result = ActionModule().run({}, {'ansible_facts': {'service_mgr': 'auto'}})

# Generated at 2022-06-25 07:36:27.771282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()

    # Context manager for assertRaises method
    with pytest.raises(AnsibleActionFail):
        # Testing when m = 'auto' and ansible_service_mgr = auto
        m = 'auto'
        ansible_service_mgr = 'auto'
        action_module_1.run(m,ansible_service_mgr)

    # Context manager for assertRaises method
    with pytest.raises(AnsibleAction):
        # Testing when m = 'auto' and ansible_service_mgr != auto
        m = 'auto'
        ansible_service_mgr = None
        action_module_1.run(m,ansible_service_mgr)

# Generated at 2022-06-25 07:36:32.232277
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # We initialize a ActionModule object and assert that no exception is raised
    action_module = ActionModule()
    assert True


# Generated at 2022-06-25 07:36:42.920733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_0 = mock.Mock()
    del task_0.args["use"]
    variable_manager = mock.Mock()
    variable_manager.extra_vars = dict()
    loader = mock.Mock()
    shared_loader_obj = mock.Mock()
    shared_loader_obj.module_loader = mock.Mock()
    shared_loader_obj.module_loader.has_plugin.return_value = True
    shared_loader_obj.module_loader.find_plugin_with_context.return_value = mock.Mock()
    display = mock.Mock()
    templar = mock.Mock()

# Generated at 2022-06-25 07:36:46.704658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:36:48.878618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert not action_module_0
     
# Stub for test_case_1()

# Generated at 2022-06-25 07:37:24.858651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.runner = AnsibleRunner()
    action_module_0._task = Task()
    action_module_0._task.args = dict()
    #print(action_module_0.run())
    return True

# Generated at 2022-06-25 07:37:27.436785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_1 = ActionModule()
        print("test_ActionModule passed")
    except Exception:
        print("test_ActionModule failed")


# Generated at 2022-06-25 07:37:29.946521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(">>>>>>>>>> Begin testing constructor of ActionModule")
    action_module_0 = ActionModule()
    print(">>>>>>>>>> End testing constructor of ActionModule")


# Generated at 2022-06-25 07:37:31.914085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # call the method run of class ActionModule
    assert action_module_0.run() is None


# Generated at 2022-06-25 07:37:42.281600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block

    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert isinstance(result, TaskResult)
    assert result == {'changed': False, 'invocation': {'module_args': {'use': 'auto'}}, 'module_name': 'ansible.legacy.service'}
    
    action_module_0 = ActionModule()
    action_module_0._task = PlayIterator()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:37:44.640662
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule()
  assert action_module_0.TRANSFERS_FILES == False
  assert len(action_module_0.UNUSED_PARAMS) == 1
  assert len(action_module_0.BUILTIN_SVC_MGR_MODULES) == 4


# Generated at 2022-06-25 07:37:48.965413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # declaration of an array to store the instances of the class ActionModule
    action_module_instances = []
    # creating multiple instance objects of the class ActionModule
    for _ in range(0, 10):
        action_module_instances.append(ActionModule())


# Generated at 2022-06-25 07:37:55.256387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert action_module_0.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}
    action_module_0.run(None, None)


# Generated at 2022-06-25 07:37:57.213964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_test_case_0 = ActionModule()
    action_module_test_case_0.run()

# Generated at 2022-06-25 07:38:06.015752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 != None
    assert (action_module_0.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'})
    assert action_module_0.TRANSFERS_FILES == False
    assert (action_module_0.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']})


# Generated at 2022-06-25 07:39:29.685413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert action_module_0.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])


# Generated at 2022-06-25 07:39:33.605339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run unit tests for constructor of class ActionModule
    print('Running constructor unit tests for ActionModule')
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:39:40.551202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for that the constructor of class ActionModule raises an Exception with unrecognized module
    action_module_1 = ActionModule()
    not_a_module = "not a module"
    assert action_module_1.run(not_a_module)
    # Test for that the constructor of class ActionModule raises an Exception with a module that doesn't exist
    action_module_2 = ActionModule()
    unknown_module = "???"
    assert action_module_2.run(unknown_module)
    # Test for that the constructor of class ActionModule runs a module with a valid module
    action_module_3 = ActionModule()
    valid_module = "valid_module"
    assert action_module_3.run(valid_module)

# Generated at 2022-06-25 07:39:42.917068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task = ''
    def func():
        return None
    task.async_val = func
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:39:46.742939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._shared_loader_obj is not None
    assert action_module._task is not None
    assert action_module._display is not None
    assert action_module._connection is not None
    assert action_module._tmp is not None
    assert action_module._loader is not None
    assert action_module._templar is not None
    assert action_module._remote_uid is not None
    assert action_module._runner_path is not None


# Generated at 2022-06-25 07:39:48.424576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule()
    assert action_module_obj is not None


# Generated at 2022-06-25 07:39:56.852398
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_1 = ActionModule()

    tmp = None
    task_vars = None

    res = action_module_1.run(tmp, task_vars)

    assert res == {'_ansible_check_mode': True, '_ansible_module_name': 'ansible.legacy.service', '_ansible_no_log': False, '_ansible_parsed': True, '_ansible_skip_tags': ['always'], '_ansible_verbosity': 0, '_ansible_version': '2.9.11', 'failed': True, 'msg': 'Missing required arguments: name'}

# Unit tests for the following decorators of function run of class ActionModule

# Generated at 2022-06-25 07:39:59.584892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # this test is using a class variable, so we really should only
    # make a single instance of the class, and use that
    action_module_0 = ActionModule()

    # test argument types
    action_module_0.run(tmp=None, task_vars=None)



# Generated at 2022-06-25 07:40:05.053133
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    # test the instance attributes of object action_module_1
    assert action_module_1._supports_check_mode == True
    assert action_module_1._supports_async == True
    assert action_module_1.TRANSFERS_FILES == False
    assert action_module_1.UNUSED_PARAMS == {'systemd': ['sleep', 'runlevel', 'pattern', 'args', 'arguments'], 'openwrt_init': ['sleep', 'runlevel', 'pattern', 'args', 'arguments'], 'service': ['sleep', 'runlevel', 'pattern', 'args', 'arguments']}

# Generated at 2022-06-25 07:40:13.409049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    service_task_args = {'name': 'foo', 'state': 'started'}
    service_action = ActionModule()
    service_action._task.args = service_task_args
    service_action._task.async_val = 43
    service_action._task.delegate_to = 'foo'
    service_action._task.module_defaults = 'foo'
    service_action._task._parent = 'foo'
    service_action._task._play = 'foo'
    service_action._task._play._action_groups = 'foo'
    service_action._templar = 'foo'
    service_action._display = 'foo'
    service_action.BUILTIN_SVC_MGR_MODULES = 'foo'
    service_action.UNUSED_PARAMS = 'foo'
