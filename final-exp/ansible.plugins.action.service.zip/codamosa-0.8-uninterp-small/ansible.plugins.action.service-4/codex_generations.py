

# Generated at 2022-06-25 07:31:22.305681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run(set(), list())


# Generated at 2022-06-25 07:31:26.256920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:31:27.634155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    member_0 = ActionModule(None, None)
    assert isinstance(member_0, ActionModule)


# Generated at 2022-06-25 07:31:30.356733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict()
    ActionModule_instance_0 = ActionModule(params)
    ActionModule_instance_0.run()


# Generated at 2022-06-25 07:31:31.069481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:31:31.913658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:31:37.102140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(str_0)
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:31:40.133580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    try:
        am = ActionModule()
    except Exception as e:
        print("Exception: ", e)


# Generated at 2022-06-25 07:31:41.885886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Performing unit test for ActionModule constructor')

    some_instance = ActionModule()
    test_case_0()


# Generated at 2022-06-25 07:31:44.835763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    dl = DataLoader()
    vm = VariableManager()

    am = ActionModule(dl, vm)



# Generated at 2022-06-25 07:32:01.041418
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:32:05.516421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert action_module_0.BUILTIN_SVC_MGR_MODULES == {'service', 'openwrt_init', 'systemd', 'sysvinit'}

# Generated at 2022-06-25 07:32:06.005673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:32:07.063620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:32:08.155438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:32:11.485130
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    exit(0)

# Run test units
test_ActionModule_run()

# Generated at 2022-06-25 07:32:19.553534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0 = ActionModule()
    action_module_0.set_task('mock', 'module')
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()

# Generated at 2022-06-25 07:32:28.058732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    case_0 = {
        "ACTION_WARNINGS": "",
        "changed": True,
        "invocation": {
            "module_args": {
                "daemon_reload": True,
                "name": "httpd",
                "state": "restarted",
                "use": "auto"
            },
            "module_name": "service"
        },
        "rc": 0,
        "results": [
            "Running /sbin/service httpd restart",
            "Redirecting to /bin/systemctl restart  httpd.service"
        ],
        "_ansible_no_log": False,
        "warnings": []
    }

    result = action_module_0.run(**case_0)
    assert result['changed']


# Generated at 2022-06-25 07:32:30.447892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = None
    assert action_module.run(tmp, task_vars) == None


# Generated at 2022-06-25 07:32:31.452040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    assert(True)

# Generated at 2022-06-25 07:32:45.406178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, set_0]
    var_0 = action_module_0.run(list_0)


if __name__ == '__main__':
    test_case_0()  # Method of class ActionModule should run w/o errors
    test_ActionModule_run

# Generated at 2022-06-25 07:32:55.863217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {
        'hostvars': {'test': {'ansible_facts': {'service_mgr': 'systemd'}}},
        'ansible_facts': {'service_mgr': 'systemd'}
    }

# Generated at 2022-06-25 07:33:04.248711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:33:10.958033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, set_0]
    var_0 = action_run(list_0)

# Generated at 2022-06-25 07:33:18.663051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    action_module_0.run()


# Generated at 2022-06-25 07:33:19.487491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:33:27.912661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    task_vars_0 = {}
    bytes_0 = b'\x1a\x9f\x8d\xeb\x04\xec\xcd\x8c\x1f\xc0:'
    int_0 = 1988
    str_0 = '?zr\x14\x8b\x0e\xdbO'
    dict_0 = {int_0: str_0, str_0: str_0}
    set_0 = {str_0}
    action_module_0 = ActionModule(bytes_0, int_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, dict_0]

# Generated at 2022-06-25 07:33:33.523925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    assert action_module_0._play._action_groups is not None
    assert action_module_0._shared_loader_obj._config._action_warnings is not None
    assert action_module_0._task._validate_files is not None
    assert action_module_0._supports_check_mode is not None


# Generated at 2022-06-25 07:33:34.508775
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # TypeError: Required argument 'loader' (pos 1) not found
  return ActionModule()

test_case_0()

# Generated at 2022-06-25 07:33:43.513519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        bytes_0 = b'\xe3I\xcaq\xaf'
        float_0 = 1831.686
        str_0 = 'x}?x@FV'
        dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
        set_0 = {bytes_0}
        action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
        print("test case 0 succeeded")
    except Exception as error:
        print("test case 0 failed")
        print("error: " + str(error))
    finally:
        del action_module_0

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:34:07.884769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'tmp'
    task_vars = {
        "ansible_facts": {
            "service_mgr": "auto"
        },
        "use": "auto"
    }
    action_module_0 = ActionModule(tmp, task_vars)
    result = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:34:08.623901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:34:14.753643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, set_0]
    var_0 = action_run(list_0)
    assert var_0 == bytes_0

# Generated at 2022-06-25 07:34:21.317306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, set_0]
    assert action_run(list_0) == action_module_0.run()


# Generated at 2022-06-25 07:34:23.668977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:34:32.699909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, set_0]
    action_module_0.run(list_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:38.767286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)


# Generated at 2022-06-25 07:34:43.395196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    assert action_module_0._task is not None
    assert action_module_0._shared_loader_obj.module_loader is not None


# Generated at 2022-06-25 07:34:54.288404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, set_0]
    var_0 = action_module_0.run(list_0)

test_ActionModule_run()

# Generated at 2022-06-25 07:34:58.934278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)


# Generated at 2022-06-25 07:35:30.774784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except AssertionError as e:
        print(e)
        print('Failed: test_' + test_case_0.__name__)
    else:
        print('Passed: test_' + test_case_0.__name__)


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:35:38.013528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x19\x9c'
    float_0 = 987.954
    str_0 = '6'
    dict_0 = {bytes_0: float_0, float_0: float_0, str_0: float_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, dict_0]
    var_0 = action_run(list_0)


# Generated at 2022-06-25 07:35:41.331245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = [{'bytes_0': 'x}?x@FV', 'float_0': 1831.686, 'str_0': 'x}?x@FV'}, {'bytes_0': 'x}?x@FV', 'float_0': 1831.686, 'str_0': 'x}?x@FV'}, {'\xe3I\xcaq\xaf'}]
    var_0 = ActionModule.run(list_0)
    # assert var_0 is not None


# Generated at 2022-06-25 07:35:49.883792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    if 100 != len(action_module_0.UNUSED_PARAMS.keys()):
        var_0 = len(action_module_0.UNUSED_PARAMS.keys())
        raise ValueError

# Generated at 2022-06-25 07:35:56.653264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # run(self, tmp=None, task_vars=None)
    # Unit tests for method run of class ActionModule
    if test_case_0():
        test_case_1()
        test_case_2()
        test_case_3()
        test_case_4()
        test_case_5()
        test_case_6()
    else:
        test_case_7()
        test_case_8()
        test_case_9()
        test_case_10()
        test_case_11()
        test_case_12()
        test_case_13()
        test_case_14()
        test_case_15()
        test_case_16()
        test_case_17()
        test_case_18()


# Generated at 2022-06-25 07:36:04.514156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 07:36:11.057184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from ansible.parsing.vault import VaultLib

    # instantiate our module object

# Generated at 2022-06-25 07:36:19.340923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, set_0]
    var_0 = action_run(list_0)


# Generated at 2022-06-25 07:36:28.498208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)

    assert_equal(action_module_0.BUILTIN_SVC_MGR_MODULES, None)
    assert_equal(action_module_0.UNUSED_PARAMS, None)
    assert_equal(action_module_0.TRANSFERS_FILES, None)

# Generated at 2022-06-25 07:36:33.174783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    # Call method run of the ActionModule class with the following parameters
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:37:46.977530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    list_0 = [dict_0, dict_0, set_0]
    var_0 = action_module_0.run(list_0)


# Generated at 2022-06-25 07:37:56.074270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None

    # Test case #1
    bytes_0 = b'\xa8\xec\xe9\xa5\xf3\x82\x7f\x1c'
    float_0 = 676.35
    str_0 = '6'
    dict_0 = {bytes_0: float_0, float_0: int(), str_0: bytes_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)

    # Test case #2
    bytes_0 = b'\xdb\x9a^\xcd\xbc'
    float_0 = 0.15
    str_0 = 'U:'
    dict

# Generated at 2022-06-25 07:38:04.214607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Testing for method run of class ActionModule

# Generated at 2022-06-25 07:38:15.405107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # case 1
    str_1 = 'Vn<l8"\xee'
    int_0 = 1071
    bytes_1 = b'\x9d\xff\x05\xff\xef\xa5\xd3'
    tuple_0 = (str_1, int_0, bytes_1)
    float_1 = 3462.0
    list_1 = [0.0, float_1, 0.0]
    dict_1 = {bytes_1: int_0, float_1: 0, str_1: tuple_0}
    set_1 = {0.0, str_1, 0.0}
    action_module_1 = ActionModule(tuple_0, str_1, list_1, dict_1, set_1, list_1)
    var_1 = action_run

# Generated at 2022-06-25 07:38:17.587218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)



# Generated at 2022-06-25 07:38:21.236322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_result = test_ActionModule()
    assert_result == 3


# Generated at 2022-06-25 07:38:26.004015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

if __name__ == '__main__':
    import sys
    # Run unit test
    print(test_case_0())
    print(test_ActionModule_run())

# Generated at 2022-06-25 07:38:34.229155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\n'
    float_0 = 2237.5
    str_0 = 'm|l\x7fB\x10\x0f@\x1d\x00\x1c'
    dict_0 = {bytes_0: float_0, float_0: str_0, str_0: str_0}
    set_0 = {str_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)
    # assert action_module_0.connection == float_0
    # assert action_module_0.task_vars == float_0
    # assert action_module_0.tmp == str_0
    # assert action_module_0._async_poll_gen == float_

# Generated at 2022-06-25 07:38:38.857465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe3I\xcaq\xaf'
    float_0 = 1831.686
    str_0 = 'x}?x@FV'
    dict_0 = {bytes_0: str_0, float_0: str_0, str_0: str_0}
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, str_0, dict_0, set_0, dict_0)


# Generated at 2022-06-25 07:38:42.858633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('ansible.legacy.setup')
    assert isinstance(action_module_0, ActionBase)
    assert isinstance(action_module_0, ActionModule)