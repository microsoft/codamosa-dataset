

# Generated at 2022-06-25 07:31:27.634369
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.set_delegate_to(bytes_0)
    action_module_0.set_name(bytes_0)
    action_module_0.set_shared_loader_obj(bytes_0)
    action_module_0.set_task(bytes_0)
    action_module_0.set_task_vars(bytes_0)
    action_module_0.set_default_vars(bytes_0)
    action_module_0.set__display(bytes_0)
    action_module_0.set__task(bytes_0)
    action_module_0.set__connection(bytes_0)
    action_module_0.set_loader_name(bytes_0)

# Generated at 2022-06-25 07:31:35.079627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'i\xe2Pl\xd8\x0c\xbb\x1e\x8d\x95\xd2\x06\x09\x8c\xb9\xa1\x9b\xff\x8c\xa3\xce'
    str_0 = 'ansible_os_version'
    set_0 = {'\x00', '\x00', '\x00'}
    dict_0 = {'0': '\x00', '0': set_0}
    action_module_0 = ActionModule(bytes_0, '\x00', '\x00', str_0, set_0, dict_0)
    print(action_module_0)

# Generated at 2022-06-25 07:31:35.754796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:31:42.250840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    str_0 = ''
    set_0 = {bytes_0, bytes_0, str_0}
    dict_0 = {set_0: bytes_0, bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, str_0, bytes_0, set_0, dict_0)
    out_0 = action_module_0.run(bytes_0, bytes_0)
    test_result = out_0 == {}

# Generated at 2022-06-25 07:31:49.904984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Scheduled start of %s.'
    str_0 = 'arguments'
    set_0 = {bytes_0, str_0}
    bytes_1 = b'%s is not running.'
    str_1 = "ansible.legacy.setup"
    bytes_2 = b'chdir'
    str_2 = 'ansible.legacy.service'
    bytes_3 = b'status'
    str_3 = 'sleep'
    bytes_4 = b'Failed to modify service status: '
    str_4 = 'ansible_service_mgr'
    bytes_5 = b'Error starting %s: '
    str_5 = 'pattern'
    bytes_6 = b'%s is already running.'
    str_6 = 'args'
    bytes_7 = b

# Generated at 2022-06-25 07:31:58.829582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1._task.args = {'state': 'started'}
    action_module_1.BUILTIN_SVC_MGR_MODULES = {'openwrt_init', 'service', 'systemd', 'sysvinit'}
    action_module_1.TRANSFERS_FILES = False
    action_module_1.UNUSED_PARAMS = {'pattern': 'pattern', 'runlevel': 'runlevel', 'sleep': 'sleep', 'arguments': 'arguments',
                                     'args': 'args', 'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    action_module_1.run()

# Generated at 2022-06-25 07:32:03.788510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    str_0 = 'rcctl modified service status but failed to set flags: '
    set_0 = {bytes_0, bytes_0, str_0}
    dict_0 = {set_0: bytes_0, bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, str_0, bytes_0, set_0, dict_0)
    assert action_module_0._supports_async == True
    assert action_module_0._supports_check_mode == True
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:32:06.034022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, '', None, None, None)
    tmp, task_vars = None, None
    result = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:32:07.062611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:32:12.816794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tmp = None
  task_vars = None
  action_module_0 = ActionModule('AString', 'AString', 'AString', 'AString', set(), dict())
  # Call method run with arguments tmp and task_vars
  return_value = action_module_0.run(tmp, task_vars)
  # Assertions



# Generated at 2022-06-25 07:32:22.477943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # test with dummy arguments
    action_module_0.run(tmp = True, task_vars = True)

# Generated at 2022-06-25 07:32:25.661523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
    print("No error")

test_ActionModule()
test_case_0()
print("Unit test for ActionModule has passed")

# Generated at 2022-06-25 07:32:26.737566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0()

# Generated at 2022-06-25 07:32:30.086136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run()")
    action_module_0 = ActionModule()
    tmp = "tmp"
    task_vars = "task_vars"
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:32:30.944436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:32:32.429849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)
    assert isinstance(ActionModule(), ActionModule) == True


# Generated at 2022-06-25 07:32:41.636566
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()

    # set up attributes
    action_module_0.runner_supports_async = None
    action_module_0._task = None
    action_module_0._keep_remote_files = False
    action_module_0._loader = None
    action_module_0._templar = None
    action_module_0._shared_loader_obj = None
    action_module_0._connection = None
    action_module_0._play_context = None
    action_module_0._task_vars = task_vars
    action_module_0._tmp = None
    action_module_0._task_vars = {'ansible_facts': {'service_mgr': 'auto'}}

    # call run

# Generated at 2022-06-25 07:32:47.346918
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    arg_spec = dict()
    arg_spec['use'] = 'auto'
    arg_spec['name'] = ''
    arg_spec['confirm'] = 'auto' 
    arg_spec['service_name'] = ''
    arg_spec['disable'] = 'auto' 
    arg_spec['ignore_errors'] = 'auto' 
    arg_spec['binary'] = None
    arg_spec['arguments'] = None
    arg_spec['enabled'] = 'auto'
    arg_spec['masked'] = 'auto'
    arg_spec['pattern'] = None
    arg_spec['runlevel'] = None
    arg_spec['sleep'] = 'auto'
    arg_spec['state'] = None
    arg_spec['args'] = None

    action_module = ActionModule

# Generated at 2022-06-25 07:32:54.109459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_0 = DummyTask()
    task_0.args = {'use': 'auto'}
    task_0.action = 'dummy'
    task_0.delegate_to = ''
    task_0._parent._play = DummyPlay()
    task_0._parent._play._action_groups = {'all': ['dummy']}

    loader_0 = DummyLoader()
    ansible_0 = DummyModule()
    ansible_0.params = {'state': 'absent'}
    setup_0 = DummyModule()
    setup_0.params = {'filter': 'ansible_service_mgr', 'gather_subset': '!all'}
    opensuse_0 = DummyModule()
    opensuse_0.params = {'name': 'dummy'}
   

# Generated at 2022-06-25 07:32:57.191578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'ansible.legacy.setup'
    module_args = dict(gather_subset='!all', filter='ansible_service_mgr')
    action_module = ActionModule()
    action_module.run(module_name, module_args)


# Generated at 2022-06-25 07:33:12.906836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\n Unit Test Case #0\n')
    test_case_0()
    print('\n Unit Test Case #1\n')

# Generated at 2022-06-25 07:33:21.979718
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:33:25.506811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # This test doesn't work.
    # Try to rewrite it
    #assert <expression>

# Generated at 2022-06-25 07:33:30.190625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    # assert the value of tmp equals to None.
    assert action_module_0.tmp == None
    # assert the value of task_vars equals to {}.
    assert action_module_0.task_vars == {}
    # assert the value of _supports_check_mode equals to True.
    assert action_module_0._supports_check_mode == True
    # assert the value of _supports_async equals to True.
    assert action_module_0._supports_async == True


# Generated at 2022-06-25 07:33:36.677656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()
    results = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:33:37.452101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert True

# Generated at 2022-06-25 07:33:38.322499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:33:41.283178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:33:42.566036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as e:
        print('Failed test_ActionModule')
        print(e)
        assert False


# Generated at 2022-06-25 07:33:46.209433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:34:01.499731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: add unit tests here
    assert False


# Generated at 2022-06-25 07:34:04.993663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:34:13.226369
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'D\xc6\x9e\xbf\x8b\x83\xf1q\xfe\x8f\x88\xb1\x9b\xdd\x0e\xf8y\x02\xf2\xdc\x0f\xaf\x9e\x9a'
    bytes_1 = b'\x0b\xf5\x02\x8f\xdd\x9e\x937\xbb8\xa4\xa1\x82\xc6\xcf\x1b\xf4'

# Generated at 2022-06-25 07:34:21.026734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for alias "service", test for service running
    action_module_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(action_module_0, task_vars_0)
    assert var_0 == None

    # Test for alias "service", test for service not installed
    action_module_1 = None
    task_vars_1 = None
    var_1 = action_module_1.run(action_module_1, task_vars_1)
    assert var_1 == None

    # Test for alias "service", test for service not running
    action_module_2 = None
    task_vars_2 = None
    var_2 = action_module_2.run(action_module_2, task_vars_2)
    assert var_

# Generated at 2022-06-25 07:34:26.198934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'X\xca\x8d\xdf\xf1\xac\xb8\x8d\xfd\xce\x9e\xf3\xab\x8b\xd5\x1aR\xc5\xfe'
    bytes_1 = b''
    str_0 = ''
    int_0 = -6

# Generated at 2022-06-25 07:34:33.000916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test to check if the object created is an instance of the ActionModule class
    assert isinstance(ActionModule(), ActionModule)
    # Check if the ActionModule class has an attribute '_supports_check_mode'
    assert hasattr(ActionModule(), '_supports_check_mode')
    # Check if the ActionModule class has an attribute '_supports_async'
    assert hasattr(ActionModule(), '_supports_async')
    # Check if the ActionModule class has an attribute '_shared_loader_obj'
    assert hasattr(ActionModule(), '_shared_loader_obj')
    # Check if the ActionModule class has an attribute '_task'
    assert hasattr(ActionModule(), '_task')
    # Check if the ActionModule class has an attribute '_connection'

# Generated at 2022-06-25 07:34:36.348320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True
    """
    action_module_0 = ActionModule()
    var_0 = action_run()
    assert var_0 ==
    """

if __name__ == "__main__":
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 07:34:46.968749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    bytes_0 = b'e\xe8J\x12\xd30\x80\xb1\x02aLvD\x8c'
    bytes_1 = b''
    str_0 = 'rcctl modified service status but failed to set flags: '
    set_0 = {bytes_0, bytes_0, str_0}
    dict_0 = {bytes_0: bytes_1}
    action_module_0 = ActionModule(bytes_0, bytes_1, str_0, bytes_0, set_0, dict_0)
    # Need to force module path to be the value of MOCK_MODULE_PATH.
    # The import statement would normally modify this value.
    imp.load_source = mock_imp_load_source
    # Setup - call original constructor

# Generated at 2022-06-25 07:34:48.041382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:34:54.247383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x84\xe7\x0fp\x0f\xe4\x9e\xa4\x0e\xb8\xaf\xa1\xc2\xe2\xdd.\x86\x83'
    str_0 = '\x1a\xe0\x02\xf6\x8b\xca\xc1!'

# Generated at 2022-06-25 07:35:32.240695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9e\x9f\x12\x88\x03\x1d\x89\x0c'
    bytes_1 = b'\x8fW\x91\x1d\x1c\x9e\x12\x8d'
    str_0 = 'service_mgr'
    bytes_2 = b'\xc5\xa9\xac\\\x1b\x9bq\xcf\x1b^\xee\x14\xdc\xf6\x1e\x9d'
    set_0 = {bytes_0, bytes_1, str_0, bytes_2}
    dict_0 = {bytes_0: bytes_1, str_0: bytes_2}

# Generated at 2022-06-25 07:35:35.581218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test method run of class ActionModule
    #
    # Make sure it is a subclass of AnsibleAction
    assert issubclass(ActionModule, AnsibleAction)
    assert action_module_0.run() == var_0

test_case_0()

# Generated at 2022-06-25 07:35:36.677568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:35:37.794660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 07:35:49.536812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()

    dict_2['use'] = 'service'

    dict_1['args'] = dict_2

    dict_0['tasks'] = [dict_1]

    dict_3['hostvars'] = dict_5

    dict_4['hostvars'] = dict_5

    dict_5['ansible_facts'] = dict_4

    dict_3['_ansible_no_log'] = False

    dict_3['failed_when_result'] = False

    dict_3['changed'] = False

    dict_3['invocation'] = dict_0

    dict_3['_ansible_verbosity'] = 0

   

# Generated at 2022-06-25 07:35:56.676037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x81\xb5\x83G\x8c/\x98.\xac>\x0f\x8d5'
    bytes_2 = b'\x81\xb5\x83G\x8c/\x98.\xac>\x0f\x8d6'
    bytes_1 = b'\x81\xb5\x83G\x8c/\x98.\xac>\x0f\x8d5\x01'
    str_0 = 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.'
    str_2 = 'rcctl modified service status but failed to set flags: '
    str_1 = 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.'


# Generated at 2022-06-25 07:36:02.275551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_1 = dict()
    action_module_0 = ActionModule(dict_0, dict_1, 'rcctl modified service status but failed to set flags: ')
    try:
        action_module_0.run()
    except AnsibleActionFail:
        pass
    except Exception:
        pass

# Generated at 2022-06-25 07:36:09.583497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'Started\n'
    bytes_1 = b'[pw_util.c:1] pw_openpw(pw): using /etc/master.passwd\n[pw_util.c:2] pw_openpw(pw): using /etc/pwd.db\n[pw_util.c:3] pw_openpw(pw): using /etc/spwd.db\n[pw_util.c:4] pw_openpw(pw): using /etc/master.passwd\n'
    str_0 = ' svc'
    set_0 = {bytes_0, bytes_0, str_0}
    dict_0 = {}

# Generated at 2022-06-25 07:36:10.376799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_case_0() == None

# Generated at 2022-06-25 07:36:14.534910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception:
        fail()
    else:
        pass


# Generated at 2022-06-25 07:37:25.774819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = '/var/tmp'
    task_vars_0 = dict()
    dict_0 = action_module_run(tmp_0, task_vars_0)
    assert dict_0 == task_vars_0
    str_0 = 'e\xe8J\x12\xd30\x80\xb1\x02aLvD\x8c'
    tmp_0 = str_0
    dict_1 = action_module_run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:37:26.995027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    svc_mgr_0 = 'openwrt_init'
    assert action_module_0.run(arg_0) == expected_0

# Generated at 2022-06-25 07:37:27.828059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:37:28.487436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:37:30.878876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(bytes_0, bytes_1, str_0, bytes_0, set_0, dict_0)


# Generated at 2022-06-25 07:37:36.108048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(2, 3, 4, 5, 6, 7)
    action_module_0.run(8, 9)


# Generated at 2022-06-25 07:37:38.755493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_module_run(tmp, task_vars)
    assert var_0 == None

# Generated at 2022-06-25 07:37:46.645252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'e\xe8J\x12\xd30\x80\xb1\x02aLvD\x8c'
    bytes_1 = b''
    str_0 = 'rcctl modified service status but failed to set flags: '
    set_0 = {bytes_0, bytes_0, str_0}
    dict_0 = {bytes_0: bytes_1}
    action_module_0 = ActionModule(bytes_0, bytes_1, str_0, bytes_0, set_0, dict_0)
    var_0 = action_run()



# Generated at 2022-06-25 07:37:53.894618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  bytes_0 = b'e\xe8J\x12\xd30\x80\xb1\x02aLvD\x8c'
  bytes_1 = b''
  str_0 = 'rcctl modified service status but failed to set flags: '
  set_0 = {bytes_0, bytes_0, str_0}
  dict_0 = {bytes_0: bytes_1}
  action_module_0 = ActionModule(bytes_0, bytes_1, str_0, bytes_0, set_0, dict_0)
  var_0 = action_module_0.run()
  print(var_0)

# Generated at 2022-06-25 07:37:56.243164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'C\xcf\x8b\xeb\x15\x0f\xdc\x0cm/'
    assert False


# Generated at 2022-06-25 07:40:31.592330
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'V\x91\x0b\x90'
    bytes_1 = b'\xf9\x97\xc8\x86d\xe3\xcc'
    str_0 = 'rcctl modified service status but failed to set flags: '
    set_0 = {bytes_0, bytes_0, str_0}
    dict_0 = {bytes_0: bytes_1}
    action_module_0 = ActionModule(bytes_0, bytes_1, str_0, bytes_0, set_0, dict_0)
    dict_1 = {bytes_1: str_0}
    var_0 = action_module_0.run(dict_1, dict_1)

# Function call
test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:40:36.231629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionBase)


# Generated at 2022-06-25 07:40:42.826921
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:40:48.642898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Running test for constructor")
    bytes_0 = b'e\xe8J\x12\xd30\x80\xb1\x02aLvD\x8c'
    bytes_1 = b''
    str_0 = 'rcctl modified service status but failed to set flags: '
    set_0 = {bytes_0, bytes_0, str_0}
    dict_0 = {bytes_0: bytes_1}
    action_module_0 = ActionModule(bytes_0, bytes_1, str_0, bytes_0, set_0, dict_0)


# Generated at 2022-06-25 07:40:50.274882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:40:56.481936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'e\xe8J\x12\xd30\x80\xb1\x02aLvD\x8c'
    bytes_1 = b''
    str_0 = 'rcctl modified service status but failed to set flags: '
    set_0 = {bytes_1, bytes_0, str_0}
    dict_0 = {bytes_0: bytes_1}
    action_module_0 = ActionModule(bytes_0, bytes_1, str_0, bytes_0, set_0, dict_0)
    action_module_1 = ActionModule(bytes_0, bytes_1, str_0, bytes_0, set_0, dict_0)
    assert action_module_0 is not action_module_1
    assert action_module_0._task is not action_module_1._

# Generated at 2022-06-25 07:40:57.282787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    unittest.main()

# Generated at 2022-06-25 07:40:58.768882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)


# Generated at 2022-06-25 07:41:00.204644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_module_0 = ActionModule()
        action_run()
        assert True
    except:
        assert False


# Generated at 2022-06-25 07:41:04.087225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {'ansible_facts': {'ansible_service_mgr': 'rcctl'}, 'changed': False, 'msg': ''}
    action_module_0 = ActionModule()
    var_1 = action_module_0.run(var_0)
    assert var_1 == var_0
     