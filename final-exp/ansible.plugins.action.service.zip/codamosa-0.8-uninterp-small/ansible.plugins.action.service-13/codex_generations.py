

# Generated at 2022-06-25 07:31:27.994491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()
    action_module_instance.run()
    action_module_instance.run("tmp")
    action_module_instance.run("tmp", "task_vars")
#     action_module_instance.run("tmp", "task_vars", "delegate_facts")
    action_module_instance.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:31:31.413696
# Unit test for method run of class ActionModule
def test_ActionModule_run():    
    _action_module = ActionModule()
    _action_module.run()

# Generated at 2022-06-25 07:31:35.033525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    action_module = test_case_0()
    result_0 = obj.run(action_module, action_module)
    assert result_0 is not None
    assert result_0 == action_module

if __name__ == '__main__':
    test_ActionModule_run()
    print ("Test complete!")

# Generated at 2022-06-25 07:31:35.948622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    if False :
        action_module.run()

# Generated at 2022-06-25 07:31:44.986320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    tmp = None
    task_vars = None
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    actionModule.runner_supports_async = test_ActionModule_run_runner_supports_async_0()
    actionModule._remove_tmp_path = test_ActionModule_run__remove_tmp_path_0
    actionModule._supports_async = test_ActionModule_run__supports_async_0()
    actionModule._display = test_ActionModule_run__display_0()
    actionModule._templar = test_ActionModule_run__templar_0()
    actionModule._task_vars = test_ActionModule_run__task_vars_

# Generated at 2022-06-25 07:31:50.491296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={'args': {'test': 'test_value'}, 'delegate_to': 'test_delegate_to', 'action': 'test_action', 'loop': {'test': 'test_value'}}, connection='test_connection', play_context={'test': 'test_value'}, loader='test_loader', templar='test_templar', shared_loader_obj='test_shared_loader_obj')

if __name__ == "__main__":
    test_case_0() # Test case for method __init__()
    test_ActionModule() # Test case for constructor of class ActionModule

# Generated at 2022-06-25 07:31:52.789333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = None
    action_module.run(tmp, task_vars)

# Generated at 2022-06-25 07:31:55.424233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('action', 'loader', 'templar', 'shared_loader_obj', None)
    print('ActionModule instance created exist')



# Generated at 2022-06-25 07:31:56.302934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:31:58.533536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("===== test_ActionModule_run start =====")
    # Always true
    assert True
    print("===== test_ActionModule_run  done =====")

# Generated at 2022-06-25 07:32:08.848241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert 'ActionBase' == type(action_module_0).__name__
    assert 'ActionModule' == type(action_module_0.run(tmp=None, task_vars=None)).__name__

# Generated at 2022-06-25 07:32:14.341787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    try:
        assert isinstance(action_module_0, ActionModule)
    except AssertionError:
        raise AssertionError("Unit test for constructor of class ActionModule failed at line number " + str(inspect.getframeinfo(inspect.currentframe()).lineno))


# Generated at 2022-06-25 07:32:16.178249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case #0 - instance creation of class ActionModule
    assert not test_case_0()

if __name__ == '__main__':
    2

# Generated at 2022-06-25 07:32:17.984599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_object = ActionModule()
    assert isinstance(action_module_object, ActionModule) == True


# Generated at 2022-06-25 07:32:23.524313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert not action_module._supports_async
    assert action_module._supports_check_mode


# Generated at 2022-06-25 07:32:24.487823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert(action_module is not None)

# Generated at 2022-06-25 07:32:25.662800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run = ActionModule()
    action_module_run.run()


# Generated at 2022-06-25 07:32:28.299005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp_1 = "tmp-1"
    task_vars_1 = {'task_vars': 'task_vars'}
    result_1 = action_module_1.run(tmp=tmp_1, task_vars=task_vars_1)
#

# Generated at 2022-06-25 07:32:34.406681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    action_module_3 = ActionModule()
    action_module_4 = ActionModule()
    action_module_5 = ActionModule()
    action_module_6 = ActionModule()
    action_module_7 = ActionModule()
    action_module_8 = ActionModule()
    action_module_9 = ActionModule()
    action_module_10 = ActionModule()
    action_module_11 = ActionModule()


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:32:40.748474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Get all attributes of module object in action_module variable
    action_module = ActionModule()
    # return boolean variable to check whether the variable TRANSFERS_FILES is present in the object action_module or not
    return hasattr(action_module, 'TRANSFERS_FILES')


# Generated at 2022-06-25 07:32:56.142366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:32:59.327024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test = ActionModule()
    output = test.run()
    assert type(output) is dict
    assert False


# Generated at 2022-06-25 07:33:01.750285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    # Processing test case data
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:33:04.326877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_test = ActionModule()
    assert isinstance(action_module_test, ActionModule)


# Generated at 2022-06-25 07:33:05.387864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:33:10.199781
# Unit test for constructor of class ActionModule
def test_ActionModule():
        action_module = ActionModule()
        assert type(action_module) == ActionModule


# Generated at 2022-06-25 07:33:20.529630
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    action_module_3 = ActionModule()
    action_module_4 = ActionModule()
    action_module_5 = ActionModule()
    action_module_6 = ActionModule()
    action_module_7 = ActionModule()
    action_module_8 = ActionModule()
    action_module_9 = ActionModule()
    action_module_10 = ActionModule()
    action_module_11 = ActionModule()

    # call function run -> stores the result of the function in the variable result
    result_0 = action_module_0.run()

    # assert statement checks the result of the function is equal to the expected value

# Generated at 2022-06-25 07:33:25.071580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("\nUNIT TEST: ActionModule.__init__\n")
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:33:29.082871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.module_loader = module_loader_0
    action_module_0.task_vars = task_vars_0
    action_module_0.task = task_0
    action_module_0.tmp = tmp_0
    result = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert result == result_0


# Generated at 2022-06-25 07:33:30.477894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:33:56.591333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    print("Test has passed")

# Generated at 2022-06-25 07:33:59.819219
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:34:04.092622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = []
    assert action_module_0.run(tmp, task_vars) is None

# Generated at 2022-06-25 07:34:08.697567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj_0 = ActionModule()

    # Define arguments for function run
    tmp_0 = None
    task_vars_0 = {}

    # Call function run
    try:
        ret_val_0 = action_module_obj_0.run(tmp_0, task_vars_0)

    except AnsibleActionFail:
        pass


# Generated at 2022-06-25 07:34:15.597085
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    # Test via direct assignment (eg. for testing other members)
    action_module.run(tmp=None, task_vars=None)

    # Test via indirect assignment (eg. for testing other members)
    tmp = None
    task_vars = None
    action_module.run(tmp, task_vars)

    # Test via direct assignment where tmp is not None
    action_module.run(tmp='tmp', task_vars=None)

    # Test via indirect assignment where tmp is not None
    tmp = 'tmp'
    task_vars = None
    action_module.run(tmp, task_vars)

    # Test via direct assignment where task_vars is not None
    action_module.run(tmp=None, task_vars='task_vars')

    # Test

# Generated at 2022-06-25 07:34:17.133972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0

# Generated at 2022-06-25 07:34:22.938189
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Case 1: When service is already present on target system
    action_module_obj_1 = ActionModule()
    # assert the code returns when service is already present on target system

    action_module_obj_1.run(task_vars = {
        'service_mgr': 'auto',
        'ansible_facts': {
            'ansible_service_mgr': 'auto',
        }

    })
    # Case 2: When service is not present on target system
    action_module_obj_2 = ActionModule()
    # assert the code returns when service is not present on target system


# Generated at 2022-06-25 07:34:29.461997
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:34:30.372413
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:34:35.314283
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test for module constructor calling
    action_module_obj_0 = ActionModule()

    # Print the object for debugging purpose
    print(action_module_obj_0)
    print(type(action_module_obj_0))
    print(action_module_obj_0.__dict__)

# Generated at 2022-06-25 07:35:28.572414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of the class ActionModule
    action_module = ActionModule()
    # Check if the instance is of class ActionModule
    assert isinstance(action_module, ActionModule)
    # Checks if the run method returned with empty {}
    assert action_module.run() == {}

# Generated at 2022-06-25 07:35:32.649899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(None,None)


# Generated at 2022-06-25 07:35:34.300809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:35:37.170504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert isinstance(action_module.run(), dict)

# Generated at 2022-06-25 07:35:37.901762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None



# Generated at 2022-06-25 07:35:41.999400
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Testing members of class ActionModule
    action_module_1 = ActionModule()
    # TEST: action_module_1 is instance of class object
    assert isinstance(action_module_1, object)
    # TEST: action_module_1 is instance of class ActionBase
    assert isinstance(action_module_1, ActionBase)
    # TEST: action_module_1 is instance of class ActionModule
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:35:50.163516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    # Test for the action_module_1 attribute: Connection
    assert action_module_1.connection == ""
    # Test for the action_module_1 attribute: _connection
    assert action_module_1._connection is None
    # Test for the action_module_1 attribute: _play_context
    assert action_module_1._play_context is None
    # Test for the action_module_1 attribute: _task
    assert action_module_1._task is None
    # Test for the action_module_1 attribute: _loader
    assert action_module_1._loader == ""
    # Test for the action_module_1 attribute: _templar
    assert action_module_1._templar == ""
    # Test for the action_module_1 attribute: _shared_loader_obj


# Generated at 2022-06-25 07:35:56.779765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock task_vars
    task_vars = dict(ansible_facts=dict(service_mgr='auto'))
    # mock task
    task = dict(async_val=True,
                args=dict(use='auto'),
                delegate_to=None,
                )
    action_module = ActionModule()
    actual = action_module.run(None, task_vars, task)

# Generated at 2022-06-25 07:35:59.272793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule()
    if ac == None:
        print("Constructor of class ActionModule. ActionModule()")
        assert False


# Generated at 2022-06-25 07:36:01.341964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 != None


# Generated at 2022-06-25 07:37:56.402871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.run()
    a.run(task_vars={
        'foo': 'bar'
    })
    a.run(tmp='/path/to/tmp')
    a.run(tmp='/path/to/tmp', task_vars={
        'foo': 'bar'
    })

# Generated at 2022-06-25 07:37:59.312844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 07:38:00.827699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:38:04.859671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:38:16.121089
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_1 = ActionModule()
    print('test_ActionModule_0')
    test_case_0()
    print('test_ActionModule_1')
    test_case_0()
    print('test_ActionModule_2')
    test_case_0()
    print('test_ActionModule_3')
    test_case_0()
    print('test_ActionModule_4')
    test_case_0()
    print('test_ActionModule_5')
    test_case_0()
    print('test_ActionModule_6')
    test_case_0()
    print('test_ActionModule_7')
    test_case_0()
    print('test_ActionModule_8')
    test_case_0()
    print('test_ActionModule_9')
    test_case_0

# Generated at 2022-06-25 07:38:22.281799
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:38:26.970825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.legacy.plugins.modules.packaging.os import Service
    service_0 = Service()
    service_0.run()

# Generated at 2022-06-25 07:38:29.992800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run")
    action_module_0 = ActionModule()
    action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:38:31.196606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:38:32.186511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run() == 0