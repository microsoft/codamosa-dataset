

# Generated at 2022-06-25 07:31:25.621088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Tested on Ansible 2.9.10
# Pretty Bad Test
# I don't know how to test this module

# Generated at 2022-06-25 07:31:26.558297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:31:31.175461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    dict_0 = {}
    int_0 = 2
    str_0 = ''
    action_module_0 = ActionModule(list_0, dict_0, int_0, list_0, list_0, str_0)
    dict_0 = {}
    dict_1 = {}
    action_module_0.run(dict_0, dict_1)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:31:32.020259
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Empty
    test_case_0()

# Generated at 2022-06-25 07:31:37.394271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = '/tmp'
    task_vars = {}
    ActionModule.run(tmp, task_vars)


# Generated at 2022-06-25 07:31:40.096800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule(list(), dict(), int(), list(), list(), str())
    assert result is not None


# Generated at 2022-06-25 07:31:40.952340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:31:48.078847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    dict_0 = {}
    int_0 = 8
    str_0 = ''
    action_module_0 = ActionModule(list_0, dict_0, int_0, list_0, list_0, str_0)
    action_module_1 = ActionModule(list_0, dict_0, int_0, list_0, list_0, str_0)
    action_module_0.run()
    action_module_1.run(action_module_1, dict_0)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:31:54.713841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    dict_0 = {}
    int_0 = 8
    str_0 = ''
    action_module_0 = ActionModule(list_0, dict_0, int_0, list_0, list_0, str_0)

    # assert return is None
    assert action_module_0.run() is None

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:31:58.751291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_1 = ['ansible.legacy.setup']
    dict_1 = {'args': 'python3', 'service': 'test', 'action': 'start', 'gather_subset': '!all', 'filter': 'ansible_service_mgr'}
    int_1 = 4
    list_2 = [{'action': 'start', 'service': 'test', 'args': 'python3'}]
    list_3 = [{'action': 'start', 'service': 'test', 'args': 'python3'}]
    str_1 = 'ansible.legacy.setup'
    action_module_1 = ActionModule(list_1, dict_1, int_1, list_2, list_3, str_1)


# Generated at 2022-06-25 07:32:15.876250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup local variables to be used in test below
    tmp = str_0
    task_vars = var_0

    # Create mocked action plugin which calls run method of class ActionModule
    class MockedActionPlugin:
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

    # Execute run method of class ActionModule
    action_module = ActionModule(mocked_action_plugin)
    action_module.run(tmp, task_vars)

ActionModule()

# Generated at 2022-06-25 07:32:18.812551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        # Test case 0
        test_case_0()
    except Exception as e:
        print('test_ActionModule_run(): Exception ', e)

run_test = test_ActionModule_run

if __name__ == '__main__':
    run_test()

# Generated at 2022-06-25 07:32:21.202204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:32:25.132774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = test_case_0()
    var_0 = {}
    var_1 = {}
    arg_1 = {}
    var_2 = {}
    result = ActionModule(arg_0, var_0, var_1, arg_1, var_2)
    assert result is not None

test_ActionModule()

# Generated at 2022-06-25 07:32:27.292207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #test_case_0()
    pass

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:32:32.835118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/tmp'
    var_0 = {}
    var_1 = []
    obj_0 = ActionModule()
    str_1 = 'use'
    str_2 = 'auto'
    str_3 = 'auto'
    var_1.append(str_0)
    var_1.append(var_0)
    test_ActionModule_run_0(str_3, str_2, str_1, var_1, obj_0)


# Generated at 2022-06-25 07:32:40.232146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/tmp'
    int_0 = 0
    var_0 = {}
    var_0 = {}
    var_0 = None
    for var_0 in range(2, 3):
        var_0 = test_case_0()
        var_0.run(str_0, var_0)
    #assert str_0 == var_0

# Generated at 2022-06-25 07:32:43.678290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'ansible.legacy_service'
    task_vars = 'ansible.legacy_service'
    action_module = ActionModule(self, play_context, new_stdin)
    action_module.run(tmp, task_vars)


# Generated at 2022-06-25 07:32:45.548696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test for ActionModule.run
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:32:50.579079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/tmp'
    var_0 = {}
    # execute action module
    test_object = ActionModule(str_0)
    test_object.run(str_0, var_0)
    # test assert from test_ActionModule->run


# python2

# Generated at 2022-06-25 07:33:06.100806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)

    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}

# Generated at 2022-06-25 07:33:14.589829
# Unit test for constructor of class ActionModule
def test_ActionModule():

    dict_0 = {}

    int_0 = 2
    str_0 = 'ansible.legacy.service'

    assert not 'use' in dict_0
    assert dict_0.get('use') is None

    dict_0['use'] = str_0

    tuple_0 = (dict_0,)

    int_1 = 9000

    action_module_0 = ActionModule(str_0, tuple_0, dict_0, int_0, tuple_0, int_1)

    assert action_module_0._shared_loader_obj.module_loader.has_plugin('ansible.legacy.service')



# Generated at 2022-06-25 07:33:23.246968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = mock.Mock()
    t.args = {'use': 'auto'}
    t.delegate_to = None
    t._parent = mock.Mock()
    t._parent._play = mock.Mock()
    t._parent._play._action_groups = {}

    tmp_res = {'ansible_facts': {'service_mgr': None}}
    module_res = {'rc': 0, 'stdout': '', 'stderr': ''}

    m = ActionModule(t, mock.Mock(), mock.Mock(), mock.Mock(), mock.Mock(), mock.Mock())

    with mock.patch.object(m, '_execute_module') as em:
        em.side_effect = [tmp_res, module_res]
        res = m.run()
        assert res

# Generated at 2022-06-25 07:33:30.497521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    assert find_var_in_code('ActionModule')
    assert find_var_in_code('float_0')
    assert find_var_in_code('int_0')
    assert find_var_in_code('bytes_0')
    assert find_var_in_code('set_0')

# Generated at 2022-06-25 07:33:40.516395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_run(float_0, int_0)
    return var_0

# Generated at 2022-06-25 07:33:45.230001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_run(float_0, int_0)
    return var_0



# Generated at 2022-06-25 07:33:52.674891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    float_0 = float()
    int_0 = int()
    float_0, int_0 = action_module_0.run(float_0, int_0)

# Generated at 2022-06-25 07:33:59.001627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    assert action_module_0.TRANSFERS_FILES == False



# Generated at 2022-06-25 07:34:08.187290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #set_0 = set()
    #dict_0 = {}
    #int_0 = 9000
    bytes_0 = b'\xa2\xdc\x02\xe2\xa0\xee\x03\x00'
    #int_1 = -17794
    #set_1 = {bytes_0, bytes_0}
    #tuple_0 = (set_1,)
    action_module_0 = ActionModule(bytes_0, dict_0, dict_0, int_1, tuple_0, int_1)
    arg_0 = '100.0'
    arg_1 = '-1396'
    var_0 = action_module_0.run(arg_0, arg_1)
    return var_0


# Generated at 2022-06-25 07:34:18.591143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    float_1 = 1.46
    int_2 = 0
    int_3 = -1
    assert type(action_run(float_1, int_2, int_3)) is dict
    assert type(action_run(float_0, int_0)) is dict


# Generated at 2022-06-25 07:34:38.943371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    assert action_module_0._task == bytes_0
    assert action_module_0._connection == set_0
    assert action_module_0._play_context == dict_0
    assert action_module_0._loader == int_1
    assert action_module_0._templar == tuple_0
    assert action_module_0._shared_loader

# Generated at 2022-06-25 07:34:44.140630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)

    action_module_0.action_write_locks = {}
    action_module_0.ansible_loop_control = str()
    action_module_0.ansible_loop_var = str()
    action_module_0.ansible_no_log = False
    action_module_0.ansible_one_line = True
    action_module

# Generated at 2022-06-25 07:34:53.354586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_run(float_0, int_0)

# Generated at 2022-06-25 07:34:54.011168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	test_case_0()



# Generated at 2022-06-25 07:34:59.160868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    assert type(action_module_0.run(float_0, int_0)) is dict

# Generated at 2022-06-25 07:35:05.261287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:35:10.921265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_module_0.run(float_0, int_0)
    assert var_0 == 9000

# Generated at 2022-06-25 07:35:20.053493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_module_0.run(float_0, int_0)


# Generated at 2022-06-25 07:35:23.176537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    action_module_0 = ActionModule(None, None, None, None, None, None)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:35:26.113416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    str_0 = str(dict_0)
    action_run(str_0)

# Generated at 2022-06-25 07:35:56.248073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_run(float_0, int_0)

# Generated at 2022-06-25 07:35:59.964207
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 10.00
    int_0 = 0
    action_module_0 = ActionModule()
    var_0 = action_run(float_0, int_0)


# Generated at 2022-06-25 07:36:07.855797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = 100.0
    int_2 = -1396
    bytes_1 = b'^\xc4\x7fH\x92'
    set_1 = {bytes_1, bytes_1}
    dict_1 = {}
    int_3 = 9000
    tuple_1 = (set_1,)
    action_module_1 = ActionModule(bytes_1, set_1, dict_1, int_3, tuple_1, int_3)
    assert(action_module_1.TRANSFERS_FILES)
    assert(action_module_1.UNUSED_PARAMS)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:36:14.572532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)


# Generated at 2022-06-25 07:36:20.033975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_run(float_0, int_0)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:36:27.637890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_run(float_0, int_0)


# Generated at 2022-06-25 07:36:36.358889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    assert action_module_0 is not None
    var_0 = action_run(float_0, int_0)


# Generated at 2022-06-25 07:36:42.151296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x0f'
    set_0 = {56, bytes_0}
    dict_0 = {}
    int_0 = 66
    tuple_0 = (bytes_0, 5, int_0, bytes_0)
    int_1 = 11
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_0, tuple_0, int_1)
    assert action_module_0._shared_loader_obj.module_loader.has_plugin('auto')

# Generated at 2022-06-25 07:36:50.310255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    assert_equal(action_module_0.task, bytes_0)
    assert_equal(action_module_0.connection, set_0)
    assert_equal(action_module_0._loader, dict_0)
    assert_equal(action_module_0._templar, int_1)

# Generated at 2022-06-25 07:36:59.430651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_module_0.run(float_0, int_0)
    var_0 = action_module_0.run(float_0, int_0)
    var_0 = action_module_0.run(float_0, int_0)

# Generated at 2022-06-25 07:37:59.422560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_module_0.run(float_0, int_0)

# Generated at 2022-06-25 07:38:05.656045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.0
    int_0 = -1409
    bytes_0 = b'\x9c\xed\xac\x08\xa2\xa6\x94R\xee\xdd\xbd\x9f\x9a\x13\x8d\x00\xf1'
    set_0 = {float_0, float_0, float_0}
    dict_0 = {bytes_0: False}
    int_1 = 9000
    tuple_0 = ({dict_0, int_1, bytes_0, bytes_0},)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    assert True

# Generated at 2022-06-25 07:38:13.502781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    int_2 = -1500
    var_0 = action_run(float_0, int_0)

# Generated at 2022-06-25 07:38:19.120065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)


# Generated at 2022-06-25 07:38:21.811086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #class ActionModule(ActionBase):
    # Unit test method run of class ActionModule
    # test run method here
    assert True

# Generated at 2022-06-25 07:38:32.281254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_run(float_0, int_0)
    int_2 = 1
    int_3 = 6000
    str_0 = ']q'
    bytes_1 = b"I"
    str_1 = ';_'
    float_1 = 2.0

# Generated at 2022-06-25 07:38:39.721835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    try:
        action_module_1 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    except Exception:
        pass

# Generated at 2022-06-25 07:38:49.594293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('test_ActionModule_run')
    float_0 = -100.0
    int_0 = -1858
    bytes_0 = b'$\xec\x1f\xe8\x88\xfb\x19\x87\xd3'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {'^\x1c\x19\x9b\xe2\x0c-\x1f\xa8\x1c'}
    int_1 = 9000
    tuple_0 = (dict_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_module_0.run(float_0, int_0)

# Generated at 2022-06-25 07:38:53.008840
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)


# Generated at 2022-06-25 07:38:56.775141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 100.0
    int_0 = -1396
    bytes_0 = b'^\xc4\x7fH\x92'
    set_0 = {bytes_0, bytes_0}
    dict_0 = {}
    int_1 = 9000
    tuple_0 = (set_0,)
    action_module_0 = ActionModule(bytes_0, set_0, dict_0, int_1, tuple_0, int_1)
    var_0 = action_run(float_0, int_0)