

# Generated at 2022-06-25 07:31:21.783503
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as exception:
        print(exception)
        assert False

test_ActionModule()

# Generated at 2022-06-25 07:31:28.126101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_1 = {}
    action_module_0 = ActionModule(dict_0, dict_1, dict_0, dict_0, dict_1, dict_0)
    action_module_0.run(dict_0, dict_0)
    test_case_0() # call test case at the end

test_ActionModule()

# Generated at 2022-06-25 07:31:29.549996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:31:31.914086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")
    test_case_0()

if __name__ == "__main__":
    print("Testing python module ActionModule")
    test_ActionModule()

# Generated at 2022-06-25 07:31:42.200419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 2324
    tuple_0 = ()
    dict_0 = {tuple_0: int_0, int_0: int_0}
    float_0 = 2.0
    int_1 = -2314
    action_module_0 = ActionModule(int_0, dict_0, dict_0, float_0, float_0, int_1)
    assert action_module_0._task, "_task not initialized"
    assert action_module_0._connection, "_connection not initialized"
    assert action_module_0._play_context, "_play_context not initialized"
    assert action_module_0._loader, "_loader not initialized"
    assert action_module_0._templar, "_templar not initialized"

# Generated at 2022-06-25 07:31:48.113604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2231
    dict_0 = {(): -2231, -2231: -2231}
    dict_1 = {(): -2231, -2231: -2231}
    float_0 = 2.0
    float_1 = 2.0
    int_1 = 3194
    action_module_0 = ActionModule(int_0, dict_0, dict_1, float_0, float_1, int_1)
    assert isinstance(action_module_0.executor, ActionBase)

# Unit tests for method run of class ActionModule

# Generated at 2022-06-25 07:31:51.768173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Indicates unit tests passed
if __name__ == '__main__':
    test_ActionModule()
    print('Test passed')

# Generated at 2022-06-25 07:31:58.700971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -3375
    tuple_0 = ()
    dict_0 = {tuple_0: int_0, int_0: int_0}
    float_0 = 2.0
    int_1 = -2314
    action_module_0 = ActionModule(int_0, dict_0, dict_0, float_0, float_0, int_1)
    tmp_0 = ''
    task_vars_0 = None
    test_case_0(action_module_0.run(tmp_0, task_vars_0))

# Generated at 2022-06-25 07:32:00.239176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print(action_module_0)


# Generated at 2022-06-25 07:32:07.261304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1927
    tuple_0 = ()
    dict_0 = {tuple_0: int_0, int_0: int_0}
    float_0 = 1.0
    int_1 = -2314
    action_module_0 = ActionModule(int_0, dict_0, dict_0, float_0, float_0, int_1)
    str_0 = ''
    dict_1 = {}
    tuple_1 = ()
    dict_2 = {tuple_1: -1927, -1927: int_0}
    dict_3 = {}
    int_2 = -2314
    str_1 = ''
    int_3 = 2
    dict_4 = {}
    dict_5 = {int_3: dict_3, str_1: dict_4}
   

# Generated at 2022-06-25 07:32:15.112518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:32:18.207638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as inst:
        print('Exception caught: ' + str(type(inst)) + ' ' + str(inst.args) + '\n')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:32:24.127603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Testing run of class ActionModule'
    var_0 = print(str_0)
    obj_0 = TestClass()
    var_1 = TestClass.run(obj_0)
    print(var_1)


# Generated at 2022-06-25 07:32:25.445602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_3 = 'Testing run of class ActionModule'
    var_3 = print(str_3)


# Generated at 2022-06-25 07:32:28.249231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("TEST CASE 0")
    test_case_0()

# Main function
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:32:32.552436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = ActionModule(var_0, var_1)
    var_3 = 'Test Case'
    var_4 = var_2.run(var_3)
    str_0 = 'Testing run of class ActionModule'
    var_5 = print(str_0)


# Generated at 2022-06-25 07:32:44.240404
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    local_var = ActionModule(self)
    local_var.action_write_locks()
    local_var.add_to_queue()
    local_var.action_write_locks()
    local_var.add_to_queue()
    local_var.action_write_locks()
    local_var.add_to_queue()
    local_var.action_write_locks()
    local_var.add_to_queue()
    local_var.action_write_locks()
    local_var.add_to_queue()
    local_var.action_write_locks()
    local_var.add_to_queue()
    local_var.action_write_locks()
    local_var.add_to_queue()
    local_var.action_write_locks()


# Generated at 2022-06-25 07:32:47.833341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:32:50.293215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule(action=None)
    assert isinstance(obj_0, ActionModule)
    test_case_0()

# Test for print statement

# Generated at 2022-06-25 07:32:54.195704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing method run of class ActionModule")
    # Testing parameters
    # tmp=None, task_vars=None
    try:
        ActionModule.run()
    except Exception as inst:
        print(inst.args)
        print(inst)
        print("The above exception was the direct cause of the following exception:")
        raise



# Generated at 2022-06-25 07:33:04.563187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule(data=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    var_2 = var_1.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:33:06.222594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Testing method run of class ActionModule'
    var_0 = print(str_0)


# Generated at 2022-06-25 07:33:10.629485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = var_0.run()
    var_2 = test_case_0()

# Unit test driver for test_ActionModule_run
# Execute unit test
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:33:12.398731
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Testing constructor of class ActionModule
    test_case_0()

# Generated at 2022-06-25 07:33:13.398051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:33:14.430748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:33:19.824947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n")
    print("# Unit test for method run of class ActionModule")

    var_1 = ActionModule()

    var_2 = var_1.run()
    print(var_2)

    var_3 = var_1.run(tmp = 3, task_vars = {'ansible_facts': {'service_mgr': 'auto'}})
    print(var_3)

# Generated at 2022-06-25 07:33:20.418017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:33:24.623631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Testing run of class ActionModule'
    var_0 = print(str_0)


# Generated at 2022-06-25 07:33:26.303067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    ansible_playbook_objects = AnsiblePlaybook()
    ansible_playbook_objects.main()

# Generated at 2022-06-25 07:33:35.442004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:33:37.657572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run(self=None, tmp=None, task_vars=None)
    if result:
        print("Test 0 passed")
    else:
        print("Test 0 failed")

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:33:39.648393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
        print('Good!')
    except Exception as err:
        print(err)
    finally:
        print('Test is ended!')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:33:42.427677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:33:45.341436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:33:48.423985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    var_0.run()
    assert True


# Generated at 2022-06-25 07:33:49.294863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:33:53.814899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    print('Testing method run in class ActionModule')


# Generated at 2022-06-25 07:33:57.974056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Testing method run of class ActionModule'
    var_0 = print(str_0)

    # Creating an object of class ActionModule
    cls_0 = ActionModule()

    # Calling method run of class ActionModule
    cls_0.run()

if __name__ == '__main__':

    # Calling function test_case_0 of module str
    test_case_0()

    # Calling function test_ActionModule_run of module str
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:00.454261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:34:09.641545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run")
    # action_module_0 = ActionModule(None, None, None, None, None, None)


if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:17.058866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    action_module_0.run(bytes_0)

# Generated at 2022-06-25 07:34:20.772644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)


# Generated at 2022-06-25 07:34:26.290846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_2 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    action_module_2.run('tmp', 'task_vars')

# Generated at 2022-06-25 07:34:28.281597
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:34:35.175934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1
    str_0 = None
    ActionModule_0 = ActionModule(str_0, str_0, int_0, str_0, str_0, int_0)
    module_name_0 = ActionModule_0.get_module_name()
    if (module_name_0 is str_0):
        pass
    else:
        print("FAIL: expected str but returned " + type(module_name_0).__name__)



# Generated at 2022-06-25 07:34:38.384252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:34:42.228711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 07:34:49.395220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:34:53.767688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(False, False, 0.0, True, [], -1153)
    var_0 = action_module_run()
    assert not (var_0)

# Generated at 2022-06-25 07:35:08.081858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_case_0
    assert test_case_0()


# Generated at 2022-06-25 07:35:10.334992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if (not (isinstance(action_module_0, ActionModule))):
        raise RuntimeError


# Generated at 2022-06-25 07:35:15.138193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 07:35:21.525325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:35:26.387061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 07:35:28.831739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 'bytes_0' in globals()
    # action_module_0.run(bytes_0)
    assert False # TODO: implement your test here


# Generated at 2022-06-25 07:35:36.302780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = 146429
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    var_0 = action_run(bytes_0)
    return action_module_1.run()

# Generated at 2022-06-25 07:35:37.756480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule(bool, bool, float, bool, list, int)) == ActionModule

# Generated at 2022-06-25 07:35:46.310668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Default arguments
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    var_0 = action_module_0.run(bytes_0)
    # Actual call to function - ... Check the number of arguments
    assert (var_0 == False)


# Generated at 2022-06-25 07:35:50.486664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    var_0 = action_run(bytes_0)


# Generated at 2022-06-25 07:36:21.889427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = True
    list_0 = []
    int_0 = 0
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    action_module_0.run()

# Generated at 2022-06-25 07:36:22.527886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests all of the functionality of this module

    pass

# Generated at 2022-06-25 07:36:27.648301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    assert isinstance(action_module_0, ActionModule)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:36:34.330790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:36:43.768432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    ansible_1 = ansible.get_instance()
    ansible_1.ansible_config.defaults = {'ACTION_MODULES': ['ansible.legacy.actions', 'ansible.legacy.modules'], 'ACTION_PLUGINS': ['ansible.legacy.action_plugins'], 'CACHEDIR': '/tmp/ansible_6YXU6c', 'ROLES_PATH': '/tmp/ansible_6YXU6c/roles:/etc/ansible/roles', 'DEFAULT_ROLES_PATH': '/etc/ansible/roles'}
    ansible_1.configured = False
    ansible_1.initialized = False
    ansible_1.ansible_debug = False
    ansible_1.ansible_verbosity = 0
    ans

# Generated at 2022-06-25 07:36:51.011240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    assert action_module_0.run() != None


# Generated at 2022-06-25 07:36:57.877249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    var_0 = {}
    var_1 = action_module_0.run(var_0)

# Mock '_templar.template'

# Generated at 2022-06-25 07:36:59.469544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if __name__ == '__main__':
        test_case_0()
    return None

# Generated at 2022-06-25 07:37:03.319329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 07:37:07.949833
# Unit test for constructor of class ActionModule
def test_ActionModule():
    map_0 = None # TODO: Implement test
    bool_0 = False # TODO: Implement test
    float_0 = 10.0 # TODO: Implement test
    bool_1 = True # TODO: Implement test
    list_0 = [] # TODO: Implement test
    int_0 = -1102 # TODO: Implement test
    action_module_0 = ActionModule(map_0, bool_0, float_0, bool_1, list_0, int_0) # TODO: Implement test


# Generated at 2022-06-25 07:38:04.144467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test run
    try:
        test_case_0()
    except AnsibleAction as e:
        raise AssertionError(f"AnsibleAction exception raised: {e.result}")

if __name__ == '__main__':
    import logging
    logging.basicConfig(format='TEST %(message)s')

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    unittest.main()

# Generated at 2022-06-25 07:38:10.243675
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup unit test context
    task = task_class()
    action_module = ActionModule(**{
        'connection': connection_class(),
        'display': display_class(),
        'task': task,
        'templar': templar_class(),
        'shared_loader_obj': shared_loader_obj_class(),
    })

    # invoke test
    assert action_module.run() == {}


# Generated at 2022-06-25 07:38:19.459615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    string_0 = get_random_string()
    string_1 = get_random_string()
    string_2 = get_random_string()
    string_3 = get_random_string()
    string_4 = get_random_string()

# Generated at 2022-06-25 07:38:19.897490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:38:22.493261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # HACK
    pass
    # test_case_0()

if __name__ == '__main__':
    # test_ActionModule_run()

    # HACK: remove this before uploading to ansible
    ActionModule._display.warning = print

# Generated at 2022-06-25 07:38:30.268715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Basic set up for testing with the DunderMifflin class
    boolex = False
    boolo = False
    floatv = 0.0
    boolei = True
    listda = []
    integr = -1153
    ad = ActionModule(boolex, boolo, floatv, boolei, listda, integr)
    ad.run()

if __name__ == '__main__':
    test_ActionModule_run()
    print('Done.')

# Generated at 2022-06-25 07:38:33.687311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -3428
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    bytes_1 = None
    var_0 = action_run_0(bytes_0, action_module_0)


# Generated at 2022-06-25 07:38:38.625624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    bool_1 = True
    str_0 = '5ae5d5b5-8a2a-4099-adbe-d40a5f856a20'
    list_0 = []
    int_0 = -250
    action_module_0 = ActionModule(bool_0, bool_1, str_0, list_0, int_0)
    str_1 = str(action_module_0.task_vars)
    assert str_1 == '[]'


# Generated at 2022-06-25 07:38:40.561529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule) == type



# Generated at 2022-06-25 07:38:46.120314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    bool_0 = False
    float_0 = 0.0
    bool_1 = True
    list_0 = []
    int_0 = -1153
    action_module_0 = ActionModule(bool_0, bool_0, float_0, bool_1, list_0, int_0)
    var_0 = action_run(bytes_0)
    if (action_module_0._connection._shell.tmpdir == var_0):
        var_0 = action_run(bytes_0)
    else:
        var_0 = action_run(bytes_0)
    var_1 = (action_module_0._connection._shell.tmpdir == var_0)
    if var_1:
        var_0 = action_run(bytes_0)
    else:
        var