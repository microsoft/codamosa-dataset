

# Generated at 2022-06-25 07:31:27.947013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '[H{5(*-~4OXK\r6o%{*'
    set_0 = {str_0, str_0, str_0, str_0}
    bool_0 = True
    bytes_0 = None
    action_module_0 = ActionModule(str_0, set_0, str_0, bool_0, bool_0, bytes_0)
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 07:31:30.966976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:31:32.837697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None, "Constructor of class ActionModule does not correctly\
    create an instance of the class"

test_ActionModule()

# Generated at 2022-06-25 07:31:41.469937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '+RtAQW`.J.Z_=}'
    str_1 = '5#SSy%J5?C'
    float_0 = 5.81724019
    action_module_0 = ActionModule(str_0, {str_0, str_1, str_1}, str_0, True, True, float_0)
    dict_0 = dict()
    dict_0['@data'] = str_0
    dict_1 = dict_0
    # AssertionError: ActionModule.run: task_vars not found
    # assert action_module_0.run(dict_1, dict_1) == None


# Generated at 2022-06-25 07:31:47.541166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Lz'
    set_0 = {str_0, str_0, str_0, str_0}
    str_1 = '@'
    bool_0 = True
    bytes_0 = None
    action_module_0 = ActionModule(str_0, set_0, str_0, bool_0, bool_0, bytes_0)
    action_module_0.run(str_1)

# Assigns attribute _supports_check_mode of type bool to class ActionModule

# Generated at 2022-06-25 07:31:49.029004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:31:50.802421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    assert True


# Generated at 2022-06-25 07:32:00.242466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil
    import tempfile

    action_module_0 = ActionModule(str_0, set_0, str_0, bool_0, bool_0, bytes_0)
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-25 07:32:00.869511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True

test_ActionModule()

# Generated at 2022-06-25 07:32:02.865553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print("Exception when calling constructor of class ActionModule")
        print(err)


# Generated at 2022-06-25 07:32:16.569343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'G\xc3\x0e\x14\xd5\x9c\x8f5'
    bool_0 = True
    dict_0 = {}
    list_0 = []
    action_module_0 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    with pytest.raises(AnsibleActionFail):
        action_module_0.run()



# Generated at 2022-06-25 07:32:21.574461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)


# Generated at 2022-06-25 07:32:27.340093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    method_var_0 = None
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, method_var_0, dict_0]
    action_module_1 = ActionModule(method_var_0, bool_0, dict_0, list_0, list_0, method_var_0)
    var_0 = action_module_1.run()
    assert var_0 == {}

# Generated at 2022-06-25 07:32:33.500101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    var_0 = ActionModule.run(action_module_0)
    # AssertionError: <class 'ansible.plugins.action.ActionModule'>
    var_0 = ActionModule.run(action_module_0, None)
    # AssertionError: <class 'ansible.plugins.action.ActionModule'>
    var_0 = ActionModule.run(action_module_0, None, None)
    # AssertionError: <class 'ansible.plugins.action.ActionModule'>

# Generated at 2022-06-25 07:32:45.204279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bytes_1 = b'\x9b\xf6\x0e_\xaf\x8e\xaf\xbf\x19\x9d'
    bool_0 = True
    bytes_2 = b'T\xf0\x0f\xbb\xb9\xdf\x85\xa7\n\xd9'
    bool_1 = False
    int_0 = 1110
    bytes_3 = b'\xb3\x15\xe3\xde\x0c\x1a\x91\x84\xd7'
    int_1 = 1359
    order_types_0 = None

# Generated at 2022-06-25 07:32:53.923015
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Generate instance of ActionModule so that we can call method run
    action_module_0 = ActionModule()
    
    # Run method run of class ActionModule with argument list containing 1 element
    var_0 = action_module_0.run('tmp')
    
    # Assert correct return value
    assert(var_0 == None)
    
    # Run method run of class ActionModule with argument list containing 2 element
    var_1 = action_module_0.run('tmp', 'task_vars')
    
    # Assert correct return value
    assert(var_1 == None)

# Generated at 2022-06-25 07:33:00.294023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = 'tmp'
    arg_1 = 'task_vars'
    action_module_0 = ActionModule(arg_0, arg_0, arg_0, arg_0, arg_0, arg_0)
    var_0 = action_module_0.run(arg_0, arg_1)
    print(var_0)


# Generated at 2022-06-25 07:33:10.113620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)

# Generated at 2022-06-25 07:33:18.663755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_0 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)


# Generated at 2022-06-25 07:33:27.785089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)

    assert_equal(action_module_1._display, ANSIBALLZ_SHELL)
    assert_equal(action_module_1._loader, ACTION_MODULE_LOADER)

# Generated at 2022-06-25 07:33:41.920896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:33:43.256702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:33:52.431321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:33:59.063207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)


# Generated at 2022-06-25 07:34:04.241081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    var_0 = action_module_1.run()
    assert var_0 == None


# Generated at 2022-06-25 07:34:12.671742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    var_0 = action_module_1.run()

    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_1 = True


# Generated at 2022-06-25 07:34:14.562571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:34:20.955177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    assert('ansible.legacy.service' == action_module_1.run()['ansible_facts']['service_mgr'])


# Generated at 2022-06-25 07:34:24.395359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    test_case_0()


# Generated at 2022-06-25 07:34:25.471783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 07:34:57.377753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x13\xed\x00\xc7K\x10\x88\xb4\xfd\x96\xd3\x9f\xec\xf5,\xdb\x81~\x8a'
    bool_0 = True
    int_0 = 5
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    tuple_0 = (action_module_0, bytes_0, dict_0)
    var_0 = action

# Generated at 2022-06-25 07:35:06.492199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, dict_0, dict_0, bytes_0)
    assert hasattr(action_module_1, '_shared_loader_obj') == True
    assert hasattr(action_module_1, '_task') == True
    assert hasattr(action_module_1, '_display') == True
    assert hasattr(action_module_1, '_templar') == True

# Generated at 2022-06-25 07:35:10.956367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)


# Generated at 2022-06-25 07:35:13.932544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule(list_0, None, None, None, None, None)
    action_module_2.run()


# Generated at 2022-06-25 07:35:23.804261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    bytes_1 = b'\xffs\x80\xf6\xb92\xfc\x8f\xed\x97\x9f\xc1\xeb\xb9\xfc'
    int_1

# Generated at 2022-06-25 07:35:31.967703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'$\xbf\x89s\xf9Z\xd9\xa3\x8a\xdd'
    bool_0 = True
    int_0 = 170
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    var_0 = action_module_1.run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:35:35.657866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:35:38.602345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(b'\x90', True, {}, [], [], b'\x90')
    try:
        var_0 = action_module_0.run()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 07:35:43.380198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:35:53.037647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1743
    dict_0 = {bool_0: bool_0, int_0: bytes_0, b'\xf2\x8b\x80\xc8\xc4\x07D\xa8\xe6\x9a': bytes_0}
    action_module_0 = None
    list_0 = [bytes_0, action_module_0, int_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    # Tests that the constructor throws the expected exception when called with an invalid value for an argument.
    # The expected

# Generated at 2022-06-25 07:36:54.789377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)


# Generated at 2022-06-25 07:37:02.207614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x7f\x9b[\xd7\xedI\xc8\xce\xbc\x97\xff'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)


# Generated at 2022-06-25 07:37:03.948033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(b'', True, {}, [], [], b'')
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-25 07:37:10.198876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x0c\x84\x92\x90\x9f\xc3\x94\xa3\x1d\x08\x1c\x10'
    bool_0 = True
    int_0 = 428
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    dict_1 = {bool_0: int_0, int_0: dict_0, bytes_0: list_0, int_0: dict_0, bytes_0: dict_0}

# Generated at 2022-06-25 07:37:19.940977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)

if __name__ == '__main__':
    import sys
    import logging
    logging.basicConfig(stream=sys.stdout)
    logging.getLogger().setLevel(logging.DEBUG)
    test_case

# Generated at 2022-06-25 07:37:27.460037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x99\x9c\x9e\x9d\x9a\x99\xe2\xee\xe3"\x96\xb9\x9a\x9a\x99\x99\x96\x92\x92\x92\x92\x9e\x9a\x96$'
    bool_0 = False
    int_0 = 1110
    dict_0 = {int_0: bytes_0, bool_0: dict_0}
    action_module_0 = ActionModule(bytes_0, bool_0, dict_0, dict_0, dict_0, bytes_0)
    var_0 = action_module_0.run()
    var_0

# Generated at 2022-06-25 07:37:28.407483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:37:32.333412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)


# Generated at 2022-06-25 07:37:35.513180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None

# Generated at 2022-06-25 07:37:41.219951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    var_0 = action_module_1.run()

# Generated at 2022-06-25 07:40:03.684379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)


# Generated at 2022-06-25 07:40:08.192559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 07:40:09.971464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of the super class
    super_object = super(ActionModule, object)

    # Create object of the defined class
    action_module_object = ActionModule()


# Generated at 2022-06-25 07:40:13.833025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test constructor of class ActionModule')
    test_case_0()



# Generated at 2022-06-25 07:40:21.076779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    action_module_0 = None
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_1 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)

# Generated at 2022-06-25 07:40:22.462275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    action_module_0 = ActionModule(action_module_0)
    var_1 = action_module_0.run()
    assert var_1 is None

# Generated at 2022-06-25 07:40:31.605354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xa5\xa7\x9f\x8d\x82\x1e\xad\x85\x89\xc6\x92\x91\x83\x8c\xbe\xaa\xbe\x82\x8f\x83\x9f\xb4\x91\x90\x81\x86\x83\x1e\x9d\x85\x9c\xc6\x8c\x8d\x1c\x86\x81\x9c\x99\x92\x81\xe2\x82\x1e\xcf\x84\x84'
    bool_0 = True
    int_0 = 1329

# Generated at 2022-06-25 07:40:42.083619
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:40:49.124733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    bytes_0 = b'xZ\xef#\x97\xd0\xf1\x99\x85f\xd2'
    bool_0 = True
    int_0 = 1110
    dict_0 = {int_0: bool_0, bool_0: int_0, int_0: int_0}
    list_0 = [action_module_0, bytes_0, dict_0]
    action_module_2 = ActionModule(bytes_0, bool_0, dict_0, list_0, list_0, bytes_0)
    var_0 = action_module_2.run()
    assert var_0 is None


# Generated at 2022-06-25 07:40:55.566120
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bytes_1 = b'\x96\xd4\x95\xdd'
  bool_1 = False
  int_1 = 995
  dict_1 = {bool_1: bool_1, bool_1: bool_1, bytes_1: bool_1}
  list_1 = [bool_1, bytes_1, dict_1]
  action_module_2 = ActionModule(bytes_1, bool_1, dict_1, list_1, list_1, bytes_1)
  assert(action_module_2.TRANSFERS_FILES == False)
  assert(action_module_2.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']})