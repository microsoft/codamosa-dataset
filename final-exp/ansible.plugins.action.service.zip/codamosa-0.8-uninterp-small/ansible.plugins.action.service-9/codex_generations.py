

# Generated at 2022-06-25 07:31:24.348945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 5039
    bytes_0 = b''
    float_0 = -1355.0
    tuple_0 = None
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, float_0, int_0, tuple_0, bool_0)


# Generated at 2022-06-25 07:31:31.502627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 5039
    bytes_0 = b''
    float_0 = -1355.0
    tuple_0 = None
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, float_0, int_0, tuple_0, bool_0)
    str_0 = 'use'
    dict_0 = {}
    action_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 07:31:36.249029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 4955
    bytes_0 = b'\n\xed'
    float_0 = -8472.0
    tuple_0 = None
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, float_0, int_0, tuple_0, bool_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:31:44.986259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    import os
    import sys
    import unittest

    project_dir = os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir))
    test_dir = os.path.join(project_dir, 'test')
    sys.path.insert(0, test_dir)

    # Run all unit test for this file
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(test_ActionModule))

    result = unittest.TextTestRunner().run(suite)

    if not result.wasSuccessful():
        sys.exit(1)

# Generated at 2022-06-25 07:31:45.854012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test for method run of class ActionModule
    assert True

# Generated at 2022-06-25 07:31:51.814407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 143
    bytes_0 = b'q'
    float_0 = 674.0
    tuple_0 = None
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, float_0, int_0, tuple_0, bool_0)
    if action_module_0.supports_check_mode != True:
        assert False
    if action_module_0.supports_async != True:
        assert False


# Generated at 2022-06-25 07:31:55.805265
# Unit test for constructor of class ActionModule
def test_ActionModule():
	int_0 = 807
	bytes_0 = b''
	float_0 = -3536.0
	tuple_0 = None
	bool_0 = True
	action_module_0 = ActionModule(int_0, bytes_0, float_0, int_0, tuple_0, bool_0)
	assert(action_module_0._display._no_pretty_print == False)
	assert(action_module_0._task.args['name'] == 'test_name')
	action_module_0._task.args['name'] = 'test_name'
	action_module_0.run(None, None)
	assert(action_module_0._task._ansible_version == 'test_version')
	assert(action_module_0._task.async_val == 50)


# Generated at 2022-06-25 07:31:57.777617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 5
    bytes_0 = b''
    float_0 = -1355.0
    tuple_0 = None
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, float_0, int_0, tuple_0, bool_0)


# Generated at 2022-06-25 07:32:03.330448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 6692
    bytes_0 = b'\x10:!\x0B\x19\x16\x1E\x7F\x0B'
    float_0 = -2880.18
    tuple_0 = (0.1, 0.7, 0.0)
    bool_0 = True
    action_module_0 = ActionModule(int_0, bytes_0, float_0, int_0, tuple_0, bool_0)
    action_module_0.run()


# Generated at 2022-06-25 07:32:04.380685
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    print('Test done')

test_ActionModule()

# Generated at 2022-06-25 07:32:19.846653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'$\xdf\xd5\xdf\xc7\x8f\x03\x90\xfd\x9c\x98\x00\xcc\xd3\xb7]\x0c\x03\x86\xf2\x94\x98G'
    int_1 = 2088
    set_1 = {56, 10}
    str_0 = '\xd5\x8c\x0f\xdc\xf5\x8b\x03\xbc\x9b\x9d\xd8\xad'
    int_2 = 930
    int_3 = 930
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_1, int_2, int_3)
    assert action_module

# Generated at 2022-06-25 07:32:25.365952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # task_vars = dict()
    tmp = None
    action_module_0 = ActionModule(tmp, task_vars)
    action_module_0.run(tmp, task_vars)
    print("test_ActionModule_run: finish")
# convert to unit test


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:32:34.484118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 153
    str_0 = '/etc/init.d'
    action_module_0 = ActionModule(str_0, int_0)
    int_1 = 1357
    action_module_0.action_set = {}
    str_1 = '-1'
    str_2 = 'ansible_facts'
    int_2 = 1676
    str_3 = 'ansible_facts'
    dict_0 = dict({str_3: str_1, str_2: int_1})
    action_module_0.run(action_module_0.action_set, dict_0)
    dict_1 = dict({})
    dict_2 = dict({})
    dict_3 = {}
    dict_3[str_0] = int_2

# Generated at 2022-06-25 07:32:35.425882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:32:41.695293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0._shared_loader_obj != None
    assert action_module_0.ACTION_WARNINGS != None
    assert action_module_0.ACTION_SKIP_CONNECTION != None
    assert action_module_0.ACTION_IGNORE_DEPRECATIONS != None


# Generated at 2022-06-25 07:32:43.883861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run(None, None)


# Generated at 2022-06-25 07:32:54.449681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arguments = []
    if len(arguments) == 0:
        test_case_0()
        test_case_0()
        test_case_0()
        return

    # set up parameters
    data = arguments[0]
    connection = arguments[1]
    shell = arguments[2]
    become = arguments[3]
    become_method = arguments[4]
    become_user = arguments[5]
    check = arguments[6]

    # call the procedure
    msg = 'Initialize the test'
    action_module_0 = ActionModule(data, connection, shell, become, become_method, become_user, check)
    print(msg)


# Generated at 2022-06-25 07:32:55.942302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    action_module_0 = ActionModule(str_0)


# Generated at 2022-06-25 07:33:01.301461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)


# Generated at 2022-06-25 07:33:04.580875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor of class ActionModule')
    action_module_0 = ActionModule()
    print('  Test of class ActionModule is completed')


# Generated at 2022-06-25 07:33:26.961251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)


# Generated at 2022-06-25 07:33:37.289915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test with use
    str_0 = 'b\xb5\x99\xad\x9b\x15\xd5\x14R\x81\x05\x1c\xfc\xf8\xc9\xd9\xe3\x7f'
    bytes_0 = b'\x89\xcb\xb4\xe9\x9c\xf4?\x11\xa8\xdfH\x98'
    float_0 = 0.934953
    set_0 = {str_0, float_0, float_0}
    int_0 = 1602

# Generated at 2022-06-25 07:33:44.626992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    assert(action_module_0 != None)


# Generated at 2022-06-25 07:33:54.316000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    action_module_0.run(list_0, int_0)

#

# Generated at 2022-06-25 07:34:01.844760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:34:12.305370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'k\xa8:?\xeb\x99\x03\x07\xca\x9b'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)


# Generated at 2022-06-25 07:34:20.545919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 889
    str_0 = '.'
    bytes_0 = b'\xb6\xd5\x88\x8d\x89\x1f\x90\xcf\xfe\xa6\xd7\xe0'
    set_0 = {int_0}
    bytes_1 = b'\xa5\x82\x8a\xb5\x84\x1a\xef\x95\xed\xa4\x1b\x93\xa8M\x10\x82\x95\x9f\xfb\xbb\x10\xf3\xf4\x8e\xc2\xaf\xfd'
    bool_0 = True

# Generated at 2022-06-25 07:34:26.515775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = b'y)~\x96a\x9c\xd3\xc4'
    list_0 = [str_0, str_0]
    int_0 = 192
    action_module_0 = ActionModule(str_0, list_0, int_0)
    var_0 = action_run(list_0, int_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:34:37.514115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    assert action_module_0.used_module == ""

# Generated at 2022-06-25 07:34:48.139357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    var_0 = action_run(list_0, int_0)

# Generated at 2022-06-25 07:35:15.094103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:35:22.834566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = ActionModule(10, 7, 4, '=F`', b'\x10', 5.37)
    int_0 = 930
    str_0 = '\x18'
    str_1 = 'K'
    float_0 = 0.917535
    dict_0 = {str_0: str_1}
    float_0 = 8.61
    list_0 = [str_1, float_0, float_0]
    module_0.run(dict_0, list_0)


# Generated at 2022-06-25 07:35:32.308845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    var_0 = action_run(list_0, int_0)


# Generated at 2022-06-25 07:35:37.012356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    assert(action_module_0.transfers_files == False)

#

# Generated at 2022-06-25 07:35:38.442857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert callable(ActionModule.run)

# Testing for method run of class ActionModule

# Generated at 2022-06-25 07:35:44.461013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test Case 0
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True

    # Construct an object of class ActionModule
    action_module_obj_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)

#

# Generated at 2022-06-25 07:35:46.023808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert false



# Generated at 2022-06-25 07:35:54.442008
# Unit test for constructor of class ActionModule
def test_ActionModule():

    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    test_case_0(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)



# Generated at 2022-06-25 07:36:04.951082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    assert not hasattr(action_module_0, "bytearray_1")

# Generated at 2022-06-25 07:36:14.112984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = '-'
    _charset0 = '<>_'
    var_1 = 'Vw$'
    _charset1 = '<>'
    _charset2 = '<>'
    _charset3 = '<>'
    _charset4 = '<>'
    _charset5 = '<>'
    _charset6 = '<>'
    _charset7 = '<>'
    var_2 = 'V8$wIN'
    var_3 = 'z2$@8'
    var_4 = '<>'
    _charset8 = '<>'
    _charset9 = '<>'
    _charset10 = '<>'

# Generated at 2022-06-25 07:37:19.988002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define arguments, expected results, and call the run method with inputs.
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    var

# Generated at 2022-06-25 07:37:30.303404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    var_0 = action_run(list_0, int_0)

test

# Generated at 2022-06-25 07:37:36.615353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    assert action_module_0._find_needle('ssh') == 'needle'
    assert action_module_0._find_needle('ssh') == 'needle'
    assert action_module_0._find_needle('ssh') == 'needle'
    assert action_module_0._find_needle('ssh') == 'needle'
    assert action_module_0._find_needle('ssh') == 'needle'
    assert len(action_module_0.BUILTIN_SVC_MGR_MODULES) == 4
    assert action_module_0._find_needle('ssh') == 'needle'

# Generated at 2022-06-25 07:37:47.897446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()
    #assert hasattr(action_module_0, 'action_set'), 'Expected instance property: action_set'
    #assert hasattr(action_module_0, 'module_set'), 'Expected instance property: module_set'
    #assert hasattr(action_module_0, 'module_defaults'), 'Expected instance property: module_defaults'
    #assert hasattr(action_module_0, 'task_vars'), 'Expected instance property: task_vars'
    #assert hasattr(action_module_0, 'connection'), 'Expected instance property: connection'
    #assert hasattr(action_module_0, '_task'), 'Expected instance property: _task'
    #assert hasattr(action_module_0, '_loader'), 'Expected instance property: _loader'
    #

# Generated at 2022-06-25 07:37:57.339285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)

# Generated at 2022-06-25 07:38:07.228106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)


# Generated at 2022-06-25 07:38:17.958432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:38:21.506045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()




# Generated at 2022-06-25 07:38:32.062225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '/usr/bin/pkg'
    list_0 = [str_0, str_0, str_0, str_0]
    int_0 = 948
    bytes_0 = b':\xf8\x18\x1e$'
    int_1 = 1593
    set_0 = {int_1, bytes_0}
    bytes_1 = b'\xf3\xebz\xff\xf4\xc3[\xb5Y\xa8M\x08%\xe3\x1a\x97\x89'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, int_1, bytes_0, set_0, bytes_1, bool_0)
    var_0 = action_run(list_0, int_0)

#

# Generated at 2022-06-25 07:38:39.562031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import PluginLoader
    import os
    from ansible.errors import AnsibleAction

    module_loader = PluginLoader(module_utils_paths=["/usr/lib/python3.4/site-packages/ansible/module_utils"],
                                 module_paths=["/usr/lib/python3.4/site-packages/ansible/modules/commands/systemd"],
                                 shared_loader_plugins={'module_utils': os.path.join("ansible/module_utils", "*.py")},
                                 )

    class TestConnection:

        def get_option(self, k):
            return ''

    action_module_0 = ActionModule(None, None, None, None, None, None)
    result = action_module_