

# Generated at 2022-06-25 07:31:23.211543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:31:34.514197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_0['result'] = None
    dict_0['start'] = None
    dict_0['end'] = None
    dict_0['exception'] = None
    dict_0['_ansible_parsed'] = None
    dict_0['_ansible_no_log'] = None
    dict_0['_ansible_item_label'] = None
    dict_0['_ansible_delegated_vars'] = None
    dict_0['_ansible_module_name'] = None
    dict_0['_ansible_module_killed'] = None
    dict_0['_ansible_module_post'] = None
    dict_0['_ansible_module_set'] = None
    dict_0['module_name'] = None

# Generated at 2022-06-25 07:31:37.896666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x8e'
    float_0 = -38.27415
    set_0 = {bytes_0, bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_0, bool_0, bool_0, set_0, bool_0)
    test_case_0()

if __name__ == '__main__': # pragma: no cover
    test_ActionModule()

# Generated at 2022-06-25 07:31:49.378907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xbf\xa2\xd2\xc3\x91\xf3\xbb\xfa'
    float_0 = -642.04
    set_0 = {1, -0.04, bytes_0, -48.303, -876.943}
    bool_0 = False
    action_module_0 = ActionModule(float_0, b'\x9b\xde\xc0\xfc\xbe\x8d\xe5\xa1\xe5\xed\x9d\xdc\x9f\x84\x97\x8b\xe7\xf6\xf5\xab\xc9\x9b', bool_0, bool_0, set_0, bool_0)
    action_module_0.run()

# Generated at 2022-06-25 07:31:55.729935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'E4\xb15'
    float_0 = -381.636
    set_0 = {bytes_0, bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_0, bool_0, bool_0, set_0, bool_0)
    result_0 = action_module_0.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:32:03.899781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arguments
    tmp=None
    task_vars=None
    # Return type: _raw_params
    ansible_facts_dict = dict()

    ansible_facts_dict['service_mgr'] = 'auto'
    # Return type: _raw_params
    ansible_module_dict = dict()
    ansible_module_dict['module_name'] = 'ansible.legacy.setup'
    ansible_module_dict['module_args'] = {'filter': 'ansible_service_mgr', 'gather_subset': '!all'}
    # Return type: _raw_params
    module_args = dict()
    module_args['name'] = 'ansible'
    module_args['enabled'] = True
    # Return type: _raw_params
    result = dict()
    result

# Generated at 2022-06-25 07:32:08.226489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module_0
    with pytest.raises(AttributeError):
        action_module_0 = ActionModule()

    # test that the first parameter was removed and the second remains
    try:
        action_module_0
    except NameError:
        pass
    else:
        assert False, "Expected NameError, got %r" % type(action_module_0)


# Generated at 2022-06-25 07:32:09.086524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:32:11.966464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(float(), bytes(), bool(), bool(), {bytes()}, bool())


# Generated at 2022-06-25 07:32:17.076864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xeb\xe1\x1a\xac\x9e\xd9\xbe\x8a\xf8\xf5K\xbe\x80\xc7'
    float_0 = -581.3
    set_0 = {bytes_0}
    action_module_0 = ActionModule(bytes_0, float_0, bytes_0, True, set_0, False)


# Generated at 2022-06-25 07:32:24.300418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == 'Success'

# Generated at 2022-06-25 07:32:34.339561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0.BUILTIN_SVC

# Generated at 2022-06-25 07:32:45.682441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xd3\xbc\xe0\x8f\x1d\xf5\xbbj\xeb\x11\xda\xc2\x80O\x1c\xba'
    float_0 = -233.816
    bytes_1 = b'\xcf|\x8d\x1e\xe5\xc25\x9c\x92\xcb\x87\x80\xf5\xdd'
    set_0 = {bytes_1}
    bool_0 = False
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0._supports_as

# Generated at 2022-06-25 07:32:54.449740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    var_0 = action_module_0.run(bytes_0)


# Generated at 2022-06-25 07:33:00.547404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xcc\xd7\xe6\xe8\xe9\x8f\xbb\x82\xec\xf7\x80\x8e\xb7'
    float_0 = -857.8503
    bytes_1 = b'\xbf\xed\xb4\xb4\x88\x9b\x8b\xbaI'
    set_0 = {bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    # test tmp=
    # test task_vars=
    # assert action_module_0.run(tmp=, task_vars=) ==


# Generated at 2022-06-25 07:33:10.340863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xa1\xfc\xdc\xfa\xfe\xd3\xaf|\xed\xb6\xa4\x83]\xc4\xcc\xa4\x98\xcc\xdb\x8d\x8a'
    bytes_1 = b'\xc1\xfd\xab\x87\x8d\x89\xcf\x98\xe1\xacz\x84\xc2\xbf\x87M\xce\xb5\x8e\x9a'

# Generated at 2022-06-25 07:33:11.392782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:33:21.296822
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -381.636
    bytes_0 = b'7\x9e^\xf4f\xf7'
    bool_0 = True
    bool_1 = True
    set_0 = {bytes_0, bytes_0}
    bool_2 = True
    action_module_0 = ActionModule(float_0, bytes_0, bool_0, bool_1, set_0, bool_2)
    bytes_1 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    var_0 = action_module_0.run(bytes_1)

    # Verify that the method run was called with the appropriate arguments
    # Additional assertions can be added to test for specific behavior

# Generated at 2022-06-25 07:33:28.697639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_1 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_1 = -381.636
    bytes_2 = b'7\x9e^\xf4f\xf7'
    set_1 = {bytes_2, bytes_2}
    bool_1 = True
    action_module_1 = ActionModule(float_1, bytes_2, bool_1, bool_1, set_1, bool_1)


# Generated at 2022-06-25 07:33:30.579950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize a new ActionModule object
    action_module_0 = ActionModule()
    # Call method action_run on instance action_module_0
    action_run(action_module_0)


# Generated at 2022-06-25 07:33:51.343347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)


# Generated at 2022-06-25 07:33:54.041255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run(bytes_0, set_0) == ''


# Generated at 2022-06-25 07:33:58.138969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
        var_0 = action_run(bytes_0)
    except:
        print('test case for method run of class ActionModule failed')

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:34:03.039018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 07:34:10.662818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    action_module_0.run(bytes_0)

# Generated at 2022-06-25 07:34:16.749512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1cu\xccn\xa9\x8c\x80\x90m\xeb\xba\xcb\xcd\xc3\x02\x05\x9a\xf7\xbf\xce\xd5'
    float_0 = -209.70625
    bytes_1 = b'|\x85\x81\xfd\xa4\x00'
    set_0 = {bytes_0, bytes_1, bytes_0, bytes_1}
    bool_0 = False
    bool_1 = False
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_1)
    dict_0 = dict()
    dict_1 = dict(environ=dict_0)


# Generated at 2022-06-25 07:34:17.329811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert True

# Generated at 2022-06-25 07:34:21.481316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = float()
    bytes_0 = bytes(1)
    bool_0 = bool()
    bool_1 = bool()
    set_0 = set()
    bool_2 = bool()
    action_module_0 = ActionModule(float_0, bytes_0, bool_0, bool_1, set_0, bool_2)
    action_module_0.run()


# Generated at 2022-06-25 07:34:22.630092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    for x in range(4):
        assert(isinstance(ActionModule(x, x, x, x, x, x), ActionModule))


# Generated at 2022-06-25 07:34:28.127207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)


# Generated at 2022-06-25 07:34:54.461004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module = ActionModule(tmp, task_vars)
    assert isinstance(action_module, ActionModule)


# Generated at 2022-06-25 07:35:00.821147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""
    action_module_0 = ActionModule('test')
    action_module_0.run()


# Generated at 2022-06-25 07:35:11.172490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_0['test_case_0'] = dict_1
    dict_1['test_case_0'] = dict_2
    dict_2['test_case_0'] = dict_3
    dict_3['test_case_0'] = dict_2
    dict_3['test_case_1'] = dict_1
    dict_2['test_case_1'] = dict_0
    dict_1['test_case_1'] = dict_3
    dict_0['test_case_1'] = dict_0
    dict_0['test_case_2'] = dict_3
    dict_3['test_case_2'] = dict_2
    dict_2['test_case_2']

# Generated at 2022-06-25 07:35:20.285212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)


# Generated at 2022-06-25 07:35:21.525617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:35:32.212626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    assert action_module_0._connection is not None
    assert action_module_0._task is not None
    assert action_module_0._templar is not None
    assert action_module_0._loader is not None
    assert action_module_0._shared_loader_

# Generated at 2022-06-25 07:35:39.519529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
        float_0 = -381.636
        bytes_1 = b'7\x9e^\xf4f\xf7'
        set_0 = {bytes_1, bytes_1}
        bool_0 = True
        action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
        # assert true
    except AssertionError:
        print('Assertion error raised')


# Generated at 2022-06-25 07:35:44.168348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)

# Generated at 2022-06-25 07:35:45.985635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == False


# Generated at 2022-06-25 07:35:52.430509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    var_0 = action_run(bytes_0)


# Create and run test suites

# Generated at 2022-06-25 07:36:55.772160
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    dict_0 = {}
    dict_1 = {}
    var_0 = action_module_0.run(var_0, dict_1, dict_0)


# Generated at 2022-06-25 07:37:04.674281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    var_1 = -381.636
    var_2 = b'7\x9e^\xf4f\xf7'
    var_3 = {var_2}
    var_4 = True
    var_5 = True
    var_6 = {var_2}
    var_7 = True
    var_8 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    var_9 = -381.636
    var_10 = b'7\x9e^\xf4f\xf7'
    var_11

# Generated at 2022-06-25 07:37:14.465042
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:37:21.607475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    var_0 = action_run(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:37:22.371577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('x')



# Generated at 2022-06-25 07:37:23.155687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_true(True)



# Generated at 2022-06-25 07:37:32.954761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = ''
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    bytes_2 = b'\xb4>\xd0\x02\x01\xd1\x8fp\x04\xaf\x9e'
    ansible_action_fail_0 = AnsibleActionFail(string_0)


# Generated at 2022-06-25 07:37:38.598598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\r\xe7H\xf0\x9f\x1av\x05\xfc'
    float_0 = -433.632
    bytes_1 = b'\x9d\xfd\x1a\xf6\x0f\x14\xb2'
    set_0 = {bytes_0, bytes_1, bytes_1, bytes_0}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(float_0, bytes_1, bool_1, bool_0, set_0, bool_1)
    bytes_2 = b'\xdc\xe5\x80\x11\xe1]\x13\x1b>'

# Generated at 2022-06-25 07:37:48.037420
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:37:54.953455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:40:27.411862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    bool_1 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_1, set_0, bool_0)
    return action_module_0


# Generated at 2022-06-25 07:40:33.213620
# Unit test for constructor of class ActionModule
def test_ActionModule():

    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    action_module_0.run(None)

    t1 = time.perf_counter()
    ActionModule(bytes_0)
    action_module_1 = ActionModule(bytes_0, bytes_1)
    t2 = time.perf_counter()
    print

# Generated at 2022-06-25 07:40:42.151063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
        float_0 = -381.636
        bytes_1 = b'7\x9e^\xf4f\xf7'
        set_0 = {bytes_1, bytes_1}
        bool_0 = True
        action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
        action_module_1 = ActionModule(float_0, bytes_0, bool_0, bool_0, set_0, bool_0)
        test_case_0()
    except Exception as err:
        assert False
    else:
        assert True


# Generated at 2022-06-25 07:40:48.784768
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xde\x7fW\x8a\xa7\x13j\x1e\xb6\x9d\x92'
    float_0 = 665.5
    bytes_1 = b'\xed\x8f\x9eG\x1b\x93\xe8\xcf'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    bool_1 = False
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_1, set_0, bool_0)


# Generated at 2022-06-25 07:40:55.495618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\t\x8f\xc9\x9c\xa5\xd2\xb2\xed\xf7\x01\xf5\x8a\xda\x9c\x89\xa6\x8b'
    float_0 = 55.383706
    bytes_1 = b'\xcaZ=\xc7\x91\xeb\x80\xae6\xfb\x8dD\x9c\x89\xc2'

# Generated at 2022-06-25 07:40:55.875507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-25 07:41:02.051977
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    var_0 = action_run(bytes_0)
    var_1 = action_run(bytes_0)
    var_2 = action_run(bytes_0)
    var_3 = action_run(bytes_0)

# Generated at 2022-06-25 07:41:07.151493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from sys import exc_info
    from traceback import format_exception
    try:
        test_case_0()
    except:
        exc_type, exc_value, exc_traceback = exc_info()
        lines = format_exception(exc_type, exc_value, exc_traceback)
        return False
    return True

if __name__ == '__main__':
    if not test_ActionModule_run():
        print('Test Failed')
        exit(1)
    print('Test Passed')
    exit(0)

# Generated at 2022-06-25 07:41:08.508193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:41:13.136661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x9f\xfe\xfcl\xb0j)zO\xe0N\xd2\x81\xfc\xb3|'
    float_0 = -381.636
    bytes_1 = b'7\x9e^\xf4f\xf7'
    set_0 = {bytes_1, bytes_1}
    bool_0 = True
    action_module_0 = ActionModule(float_0, bytes_1, bool_0, bool_0, set_0, bool_0)
    var_0 = action_module_0.run(bytes_0)