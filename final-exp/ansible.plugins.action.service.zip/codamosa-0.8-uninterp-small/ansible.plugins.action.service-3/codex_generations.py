

# Generated at 2022-06-25 07:31:27.055059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    set_0 = {bool_0}
    float_0 = 3930.0341
    str_0 = 'k6tn'
    action_module_0 = ActionModule(bool_0, set_0, float_0, str_0, str_0, set_0)
    action_module_0.run()


# Generated at 2022-06-25 07:31:35.754688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case = {
        'legacy_0': test_case_0
    }

    failed_cases = [key for key in test_case.keys() if not test_case[key]()]
    passed_cases = list(set(test_case.keys()) - set(failed_cases))

    print('\nSummary:')
    if passed_cases:
        print('\033[92m' + 'Passed test cases:\n\t' + '\n\t'.join(passed_cases) + '\033[0m')
    if failed_cases:
        print('\033[91m' + 'Failed test cases:\n\t' + '\n\t'.join(failed_cases) + '\033[0m')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:31:43.473419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    set_0 = {bool_0}
    float_0 = 3930.0341
    str_0 = 'k6tn'
    action_module_0 = ActionModule(bool_0, set_0, float_0, str_0, str_0, set_0)
    assert action_module_0._name == 'service'
    assert action_module_0.action_exec_time
    assert action_module_0._name == 'service'
    assert action_module_0._shared_loader_obj is not None
    assert action_module_0._task is not None
    assert action_module_0._templar is not None


# Generated at 2022-06-25 07:31:44.359075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:31:50.832911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    set_0 = {False}
    float_0 = 48543.037
    str_0 = 'M8H'
    action_module_0 = ActionModule(bool_0, set_0, float_0, str_0, str_0, set_0)
    action_module_0.run()


# Generated at 2022-06-25 07:31:51.451404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:31:57.057766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test case; test action module run method
    # Test that delegate_to is expanded to hostvars|ansible_facts>service_mgr
    # Test that ansible_service_mgr is expanded to ansible_facts>service_mgr
    # Test that service_mgr is set to ansible_service_mgr
    # Test that first result has key that is service_mgr
    # Assert that service_mgr is module
    pass

# Generated at 2022-06-25 07:31:59.160047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:32:02.237815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {True}
    float_0 = 4.242
    str_0 = 't4'
    action_module_0 = ActionModule(True, set_0, float_0, str_0, str_0, set_0)


# Test class

# Generated at 2022-06-25 07:32:03.391687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:32:12.840858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        var_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
        var_1 = action_run()
        assert var_1 == 0
    except Exception as e:
        print(e)

# Generated at 2022-06-25 07:32:18.472599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = '-j'
    var_1 = '&G+G8QEeh|b^n\rC\tR'
    var_2 = -3
    var_3 = 3273.0
    var_4 = True
    var_5 = -2147
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:32:26.015304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    action_module_0.run()

# Generated at 2022-06-25 07:32:33.111021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        str_0 = '-j'
        str_1 = '&G+G8QEeh|b^n\rC\tR'
        int_0 = -3
        float_0 = 3273.0
        bool_0 = True
        int_1 = -2147
        action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
        assert action_module_0.TRANSFERS_FILES
    except Exception as exception_0:
        assert True
    else:
        assert False


# Generated at 2022-06-25 07:32:44.200174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 't'
    str_1 = 'm$pE'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    action_module_0.run()

" - load the module "
action_module_0 = ActionModule('tmp')
" - run the module "
result = action_module_0.run()
" - dump the result "
result = action_module_0.dump_results(result)
" - exit "
sys.exit(action_module_0.exit_json(**result))

# Generated at 2022-06-25 07:32:52.116761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    

# Generated at 2022-06-25 07:32:56.702170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)


# Generated at 2022-06-25 07:33:04.557827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    action_module_0.run()

test_case_0()

# Generated at 2022-06-25 07:33:10.455853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)

# Generated at 2022-06-25 07:33:17.723075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:33:34.578550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0 is not None


# Generated at 2022-06-25 07:33:40.410058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'E$Vaz;YSAgj'
    str_1 = '/7V%^l'
    int_0 = -2
    float_0 = -0.0083
    bool_0 = False
    int_1 = -79
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    action_module_0.run()

# Generated at 2022-06-25 07:33:45.031840
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:33:47.934852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('', '', -1300, 3273.0, True, -2147)
    return action_module_0


# Generated at 2022-06-25 07:33:54.471468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case for method run of class ActionModule
    # test_case_0
    str_1 = '-j'
    str_2 = '&G+G8QEeh|b^n\rC\tR'
    int_1 = -3
    float_0 = 3273.0
    bool_0 = True
    int_2 = -2147
    action_module_1 = ActionModule(str_1, str_2, int_1, float_0, bool_0, int_2)
    result = action_module_1.run()
    assert result == None

# Generated at 2022-06-25 07:33:58.333624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'R&F+I-L!@2{x\x7f+\t'
    str_1 = 'IBjn?{A'
    int_0 = -3
    float_0 = -3.0
    bool_0 = True
    int_1 = 2
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_1 = action_run()
    assert var_1 == None

# Generated at 2022-06-25 07:34:01.177429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run')
    assert True == True


# Generated at 2022-06-25 07:34:04.593679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == None


# Generated at 2022-06-25 07:34:09.758657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_2 = '-j'
    str_3 = '&G+G8QEeh|b^n\rC\tR'
    int_2 = -3
    float_1 = 3273.0
    bool_1 = True
    int_3 = -2147
    action_module_0 = ActionModule(str_2, str_3, int_2, float_1, bool_1, int_3)


# Generated at 2022-06-25 07:34:12.812690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # HACK: load temporarily from the local import path so we can use these methods during test_case_0
    from ansible.plugins.action.service import ActionModule as service_am
    # HACK: force the stubbed method we want to call
    service_am.run = test_case_0
    service_am.run()

# Generated at 2022-06-25 07:34:39.214424
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0.run == test_case_0

test_ActionModule()

# Generated at 2022-06-25 07:34:46.601065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_0 = action_run(action_module_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:34:55.040471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -4
    str_0 = 'action5'
    str_1 = 'rLu_=.\r\r%Qt\x0b9?C!8\x7f3j'
    int_1 = -2
    float_0 = 2451.0
    bool_0 = False
    int_2 = -174
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    assert action_module_0 != None


# Generated at 2022-06-25 07:35:03.304708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ':.hW'
    str_1 = '36xG=Qw\n\t'
    int_0 = -5
    float_0 = -4.080893
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:35:10.719857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_0 = action_run()
    assert var_0 == var_1


# Generated at 2022-06-25 07:35:22.012125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    assert action_module_0
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0._shared_loader_obj.module_loader.has_plugin('ansible.legacy.service') == False
    assert action_module_0._task.args.get('use', 'auto').lower

# Generated at 2022-06-25 07:35:29.500626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'test_module'
    module_args = dict(arg='test')
    tasks_vars = dict(var='test')
    action_module = ActionModule(module_name, module_args, tasks_vars)
    result = action_module.run()
    assert result['test_module'] == dict(arg='test', var='test')


if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:35:39.705311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)

# Generated at 2022-06-25 07:35:44.508626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'scp'
    str_1 = '+5|5\r'
    int_0 = 5
    float_0 = 67.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_0 = tmp()
    var_1 = task_vars()
    var_2 = action_run(var_0, var_1)
    var_3 = assert_equals(var_2, '4')
    pass


if __name__ == '__main__':
    case_0()

# Generated at 2022-06-25 07:35:50.121090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'zy'
    str_1 = '#UdVgU|\x1f`\x11C\\'
    int_0 = 3
    float_0 = 0.39701
    bool_0 = False
    int_1 = -1889
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_0 = action_run()


# Generated at 2022-06-25 07:36:47.695709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert isinstance(ActionModule().run(), dict)


# Generated at 2022-06-25 07:36:52.643400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ')O+N8j_b[.JR\tX\b'
    str_1 = '-u'
    int_0 = -3
    float_0 = 2428.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)


# Generated at 2022-06-25 07:36:55.156422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:37:01.765749
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Unit test for method run of class ActionModule')
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:37:06.906347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '+'
    str_1 = '/r7V:'
    int_0 = 4
    float_0 = 2.583
    bool_0 = False
    int_1 = -33
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_0 = action_module_0.run()
    assert var_0 == None

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:37:14.718071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '+V$'
    str_1 = 'cK'
    int_0 = 4
    float_0 = 6913.0
    bool_0 = False
    int_1 = 2126
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    str_2 = 'l,d|=/m[fT/LpTtf+B/:T/F~|/@X'
    str_3 = 'x,N/-R~i/fT/T~|:n/'
    int_2 = -3
    float_1 = 4232.0
    bool_1 = False
    int_3 = -2147

# Generated at 2022-06-25 07:37:18.235174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Should create an instance of class ActionModule
    action_module_0 = ActionModule()

    assert isinstance(action_module_0, ActionModule) == True, "Expected object of type 'ActionModule', got '%s'" % (type(action_module_0))


# Generated at 2022-06-25 07:37:19.026916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-25 07:37:23.713125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:37:26.925068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing for constructor of class ActionModule')
    test_case_0()
    print('Test passed for constructor of class ActionModule')

#  Test cases for class ActionModule

# Generated at 2022-06-25 07:39:34.544032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    return

# Generated at 2022-06-25 07:39:41.320873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    # No exception thrown
    try:
        action_module_0.run(None, None)
    except:
        assert False
    return None

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:39:47.205725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setting up parameter values
    tmp = None
    task_vars = None

    class Bunch():
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    # Performing actions
    var_0 = ActionModule.run(None, task_vars)

    ansible_module_run_failure_0 = Bunch(
        msg='Could not detect which service manager to use. Try gathering facts or setting the "use" option.',
        exception='AnsibleActionFail',
        result='{"failed": true, "msg": "Could not detect which service manager to use. Try gathering facts or setting the \\"use\\" option."}'
    )

    # Applying assertions
    assert var_0 == ansible_module_run_failure_0
    assert var_0.msg

# Generated at 2022-06-25 07:39:52.882300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)


# Generated at 2022-06-25 07:39:53.436421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:39:58.304066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)


# Generated at 2022-06-25 07:40:01.486491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)

# Generated at 2022-06-25 07:40:06.876868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    str_2 = '0Qv[B:H$8Dzd{@l9b;S1&H^\nZ'
    str_3 = '4ih4D<\x0b^_6#P;!x'
    str_4 = 'mwM@LdI2i'
    str_5 = 'z>X;n'

# Generated at 2022-06-25 07:40:12.260725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    action_module_0.run(tmp=None, task_vars=None)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:40:17.260733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '-j'
    str_1 = '&G+G8QEeh|b^n\rC\tR'
    int_0 = -3
    float_0 = 3273.0
    bool_0 = True
    int_1 = -2147
    action_module_0 = ActionModule(str_0, str_1, int_0, float_0, bool_0, int_1)
    action_module_0.run()

# Unit test coverage for ActionModule.run