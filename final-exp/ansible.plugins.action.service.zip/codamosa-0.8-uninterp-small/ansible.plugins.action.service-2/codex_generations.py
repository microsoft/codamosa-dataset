

# Generated at 2022-06-25 07:31:23.212084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = dict()
    obj = ActionModule(task_vars, tmp)
    action_module_run = obj.run()

# Generated at 2022-06-25 07:31:26.005217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:31:33.662450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xdd\xc0\xcf\xca\x94\xfb1>\x04\xff\xc6\xa3/\xc1'
    dict_0 = {bytes_0: bytes_0}
    bool_0 = True
    list_0 = [bytes_0, dict_0]
    set_0 = {bool_0, bytes_0, list_0}

    if (test_ActionModule.count == 0):
        action_module_0 = ActionModule(bytes_0, dict_0, bool_0, list_0, bytes_0, set_0)
        action_module_0._display.vvvv(b'\xdd\xc0\xcf\xca\x94\xfb1>\x04\xff\xc6\xa3/\xc1')


# Generated at 2022-06-25 07:31:35.125893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print("Failed loading test for constructor of ActionModule")
        print("Reason: {}".format(err))
        raise err

# Generated at 2022-06-25 07:31:36.093198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:31:41.668730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {('foo', 'bar', 'baz'): ['foo', 'bar', 'baz']}
    tmp = b'foo'
    ActionModule_0 = ActionModule(task_vars, tmp)
    ActionModule_0.run(task_vars, tmp)

if __name__ == '__main__':
    test_case_0()
    # test_ActionModule_run()

# Generated at 2022-06-25 07:31:44.898515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xdd\xc0\xcf\xca\x94\xfb1>\x04\xff\xc6\xa3/\xc1'
    dict_0 = {bytes_0: bytes_0}
    bool_0 = True
    list_0 = [bytes_0, dict_0]
    set_0 = {bool_0, bytes_0, list_0}
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, list_0, bytes_0, set_0)
    action_module_0.run()


# Generated at 2022-06-25 07:31:53.493483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xdd\xc0\xcf\xca\x94\xfb1>\x04\xff\xc6\xa3/\xc1'
    dict_0 = {bytes_0: bytes_0}
    bool_0 = True
    list_0 = [bytes_0, dict_0]
    set_0 = {bool_0, bytes_0, list_0}
    action_module_0 = ActionModule(bytes_0, dict_0, bool_0, list_0, bytes_0, set_0)
    assert action_module_0.name == b'\xdd\xc0\xcf\xca\x94\xfb1>\x04\xff\xc6\xa3/\xc1'

# Generated at 2022-06-25 07:31:58.429370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {'use': 'auto', 'state': 'started'}
    hostvars = {}
    ansible_facts = {'service_mgr': 'auto'}
    delegate_to = 'auto'
    module_defaults = {'use': 'auto', 'state': 'started'}
    tmpdir = 'auto'
    module_loader = 'auto'
    display = 'auto'
    async_val = 'auto'
    template = 'auto'
    module_name = 'auto'
    module_args = 'auto'

# Generated at 2022-06-25 07:31:58.926240
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test_case_0()

# Generated at 2022-06-25 07:32:06.996191
# Unit test for constructor of class ActionModule
def test_ActionModule(): assert True == isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-25 07:32:17.310118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # we can't create a class instance without passing in a fully-built task, but we can do this to get the correct argument spec
    task = Task(Args({'use': 'auto'}))
    task.async_val = 100
    task.action = 'service'
    task.args = {'use': 'auto'}
    task.delegate_to = '0'
    task.module_defaults = {'auto': ''}
    task.action_async = 100

    # FIXME: register the test plugin path
    plugin_loader = PluginLoader(TestModule, 'test')
    plugin_loader.find_plugin_with_context = Mock(return_value=ModuleBase())
    shared_loader_obj = PluginLoader()
    shared_loader_obj.module_loader = plugin_loader

    temp_shell_obj = Shell

# Generated at 2022-06-25 07:32:24.892501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = dict()
    var_2 = dict()
    action_module_0 = ActionModule(var_1, var_2)
    assert not hasattr(action_module_0, '_supports_check_mode') and not hasattr(action_module_0, '_supports_async')


# Generated at 2022-06-25 07:32:29.239584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test action_module_0
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    assert action_module_0._task == dict()
    assert action_module_0._play_context == dict()



# Generated at 2022-06-25 07:32:32.149532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = dict()
    action_module_0 = ActionModule(var_0, var_1)
    assert not hasattr(action_module_0._shared_loader_obj.module_loader, "legacy")

# Generated at 2022-06-25 07:32:33.915781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)


# Generated at 2022-06-25 07:32:39.007274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    action_module_0.run()


# Generated at 2022-06-25 07:32:41.359965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict()
    action_module_0 = ActionModule(var_0, var_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:32:41.908959
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:32:43.800917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = dict()
    var_2 = dict()
    action_module_0 = ActionModule(var_1, var_2)

    # Test method run of class ActionModule
    test_case_0()

# Generated at 2022-06-25 07:32:54.965186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_run()
    assert var_0 == None

# Generated at 2022-06-25 07:33:01.368294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    return action_module_0


# Generated at 2022-06-25 07:33:08.323848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_run()
    print(var_0)
    print(action_module_0)

test_ActionModule()

# Generated at 2022-06-25 07:33:14.700585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    return action_module_0


# Generated at 2022-06-25 07:33:23.307782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = 'auto'
    _templar = 'auto'
    if self._task.args.get('use', 'auto').lower() == 'auto':
        try:
            if self._task.delegate_to:  # if we delegate, we should use delegated host's facts
                self._shared_loader_obj.module_loader.find_plugin(module, collection_list=self._task.collections).run()
            else:
                self._templar.template('{{ansible_facts.service_mgr}}').run()
        except Exception:
            pass  # could not get it from template!


# Generated at 2022-06-25 07:33:26.934771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #tuple_1 = (var_0,)
    #action_module_1 = ActionModule(int_0, tuple_1, list_0, float_0, list_0, bool_0)
    float_3 = float(action_module_1)
    if float_3 == float_0:
        int_1 = 5
    else:
        int_1 = 10
    return int_1


# Generated at 2022-06-25 07:33:32.226595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)



# Generated at 2022-06-25 07:33:39.808466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -83
    tuple_0 = ()
    list_0 = []
    float_0 = -77.7824
    bool_0 = True
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.run() is None, 'test'

test_case_0()

# Generated at 2022-06-25 07:33:48.207306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = dict(
        use='auto',
        name='foo',
    )
    var_1 = dict(
        module_defaults=dict(),
    )
    var_2 = dict(
        name='service',
    )
    var_3 = dict()
    var_4 = dict(
        module_defaults=var_3,
        module_name='ansible.legacy.service',
    )
    var_5 = dict(
        module_defaults=var_3,
        module_name='ansible.legacy.service',
        module_args=var_2,
    )

# Generated at 2022-06-25 07:33:52.110526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:34:09.031114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0, bool_0)


# Generated at 2022-06-25 07:34:12.865448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of the ActionModule class and test
    # TODO: Create a test case based on the test case specifications
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:34:17.970210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1043
    tuple_0 = ()
    list_0 = []
    float_0 = -34.69
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    assert action_module_0.run() == []

# Generated at 2022-06-25 07:34:26.035207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Constructor of class ActionModule")
    int_0 = -4795
    tuple_0 = ()
    list_0 = []
    float_0 = -52.0520
    bool_0 = True
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:34:28.800152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except Exception as e:
        # print e
        assert False 


# Generated at 2022-06-25 07:34:35.286718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = {}
    var_0 = action_module_0.run(var_0, var_0)

# Generated at 2022-06-25 07:34:38.758092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -4201577
    tuple_0 = ()
    list_0 = []
    float_0 = -32.3
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    action_run(action_module_0)


# Generated at 2022-06-25 07:34:48.939303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -47
    tuple_0 = ()
    list_0 = []
    float_0 = -28.638
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    assert action_module_0.ANSIBLE_METADATA == {}
    assert action_module_0.RETURN == {}
    assert action_module_0.action == int_0
    assert action_module_0.self == list_0
    assert action_module_0.defer == tuple_0
    assert action_module_0.runner == list_0
    assert action_module_0.module == float_0
    assert action_module_0.result == bool_0
    assert action_module_0.de

# Generated at 2022-06-25 07:34:58.023513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    an_str_0 = "Bksdr"
    an_str_1 = "i{b"
    an_str_2 = "Z:3P"
    an_str_3 = "0FyV"
    an_str_4 = "|f6Z"
    an_str_5 = "6Tm/"
    an_str_6 = "s[H?"
    an_str_7 = "U6lX"
    an_str_8 = "2>@{"
    an_str_9 = "{"
    an_str_10 = "4_x]"
    an_str_11 = "$"
    an_str_12 = "}"
    an_str_13 = "QKBt"
    an_str_14 = "\x7F"

# Generated at 2022-06-25 07:35:00.895234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:35:27.573476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:35:33.475793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -897
    tuple_0 = ()
    list_0 = []
    float_0 = -37.2945
    bool_0 = True
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    action_module_0.run()


if __name__ == "__main__":
    import traceback
    import os
    import sys

    try:
        test_case_0()
    except Exception:
        print("Exception in action module test")
        tb = traceback.format_exc()
        print(tb)

# Generated at 2022-06-25 07:35:34.863064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:35:38.742257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:35:44.623178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -21862
    tuple_0 = (892,)

# Generated at 2022-06-25 07:35:49.372560
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False

    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_module_0.run(tuple_0, list_0)


# Generated at 2022-06-25 07:35:54.441985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    # This assertion needs to be updated
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:35:56.036289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run = ActionModule()
    action_run.run()

# Generated at 2022-06-25 07:36:00.043865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:36:05.428135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    module = 'service'
    dict_0 = {'use': module}
    task_vars = dict_0
    
    # Method call
    action_module_0 = ActionModule()
    var_0 = action_module_0.run(None, task_vars)

    # Evaluation
    assert var_0 == dict_0, "Error in run method of ActionModule class."

# Generated at 2022-06-25 07:37:08.275333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:37:09.986843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == "False", "action_module.run() didn't return to valid value"

# Generated at 2022-06-25 07:37:16.113912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)


# Generated at 2022-06-25 07:37:22.304202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:37:25.620271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    # test_case_0
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)


# Generated at 2022-06-25 07:37:30.633695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    assert_true(action_module_0)


# Generated at 2022-06-25 07:37:33.882139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:37:37.344060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters
    tmp = None
    task_vars = None

    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_run()
    assert var_0 == None

# Generated at 2022-06-25 07:37:41.103468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 150
    tuple_0 = ()
    list_0 = []
    bool_0 = False
    float_0 = -181.50
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    del action_module_0


if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:37:44.382500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    #var_0 = action_run(action_module_0, )
    #assert var_0 == "test"
    #print(var_0)



# Generated at 2022-06-25 07:40:10.554411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    assert False == action_module_0.run(int_0, tuple_0, list_0, float_0, list_0, bool_0)


# Generated at 2022-06-25 07:40:16.745043
# Unit test for constructor of class ActionModule
def test_ActionModule():

    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    int_1 = action_module_0.run()
    if (int_1 == -1277):
        assert(False)


# Generated at 2022-06-25 07:40:18.001098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the main flow of case test_case_0()
    test_case_0()


# Generated at 2022-06-25 07:40:25.590943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_run()


if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-25 07:40:28.998768
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -7842
    tuple_0 = ()
    list_0 = []
    float_0 = -50.752
    bool_0 = True
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:40:31.777629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:40:39.387622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    assert action_module_0 != None


# Generated at 2022-06-25 07:40:42.664560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_1 = 1
    tuple_1 = (0.18, 0.038)
    list_1 = []
    float_1 = 1.1
    list_2 = []
    bool_1 = True
    action_module_1 = ActionModule(int_1, tuple_1, list_1, float_1, list_2, bool_1)


# Generated at 2022-06-25 07:40:47.412750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1277
    tuple_0 = ()
    list_0 = []
    float_0 = -68.7739
    bool_0 = False
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_module_0.run()
    assert var_0 == var_0

# Generated at 2022-06-25 07:40:49.537522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -11196
    tuple_0 = ()
    list_0 = []
    float_0 = -95.6492
    bool_0 = True
    action_module_0 = ActionModule(int_0, tuple_0, list_0, float_0, list_0, bool_0)
    var_0 = action_run()
    print(var_0)