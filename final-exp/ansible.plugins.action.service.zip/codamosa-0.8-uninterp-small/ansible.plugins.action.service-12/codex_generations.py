

# Generated at 2022-06-25 07:31:25.713727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '2d"L\x0cM+Q8 U\t`1\\;\x0b4o*'
    bytes_0 = b'-\xde\xe2'
    set_0 = {bytes_0, str_0, bytes_0, bytes_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, bytes_0, set_0, bool_0, bytes_0)
    action_module_0.run()

# Generated at 2022-06-25 07:31:28.345828
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp_1 = str()
    task_vars_1 = dict()
    try:
        action_module_1.run(tmp_1, task_vars_1)
    except:
        assert False

# Generated at 2022-06-25 07:31:35.273690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '2d"L\x0cM+Q8 U\t`1\\;\x0b4o*'
    bytes_0 = b'-\xde\xe2'
    set_0 = {str_0, str_0, str_0, bytes_0, bytes_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, bytes_0, set_0, bool_0, bytes_0)
    action_module_0.run(str_0, bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()
    print('Test cases finished')

# Generated at 2022-06-25 07:31:44.556947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization
    str_0 = '2d"L\x0cM+Q8 U\t`1\\;\x0b4o*'
    bytes_0 = b'-\xde\xe2'
    set_0 = {str_0, str_0, str_0, bytes_0, bytes_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, bytes_0, set_0, bool_0, bytes_0)
    action_module_0.mod_name = '5|\t\x1f8-\tG\n'
    str_1 = '\nxC\n_\t\x018E\x07\x1a\x11E\x04'
    action_module_0._name = str_1

# Generated at 2022-06-25 07:31:51.727891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '2d"L\x0cM+Q8 U\t`1\\;\x0b4o*'
    bytes_0 = b'-\xde\xe2'
    set_0 = {str_0, str_0, str_0, bytes_0, bytes_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, bytes_0, set_0, bool_0, bytes_0)


# Generated at 2022-06-25 07:32:00.964194
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:32:06.104809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '2d"L\x0cM+Q8 U\t`1\\;\x0b4o*'
    bytes_0 = b'-\xde\xe2'
    set_0 = {str_0, str_0, str_0, bytes_0, bytes_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, bytes_0, set_0, bool_0, bytes_0)
    test_case_0()
    return str_0, bytes_0, set_0, bool_0, action_module_0

if __name__ == "__main__":
    global_var = 0
    str_0, bytes_0, set_0, bool_0, action_module_0 = test_ActionModule()

# Generated at 2022-06-25 07:32:07.064015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:32:14.784078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'o*"M\x0cA+Q8 U\t`1\\;\x0b2d*'
    bytes_0 = b'\n\xb8\xf8'
    set_0 = {str_0, str_0, bytes_0, bytes_0, bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, str_0, bytes_0, set_0, bool_0, set_0)
    action_module_0.run()

# Generated at 2022-06-25 07:32:19.388221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '2d"L\x0cM+Q8 U\t`1\\;\x0b4o*'
    bytes_0 = b'-\xde\xe2'
    set_0 = {str_0, str_0, str_0, bytes_0, bytes_0}
    bool_0 = False
    action_module_0 = ActionModule(str_0, str_0, bytes_0, set_0, bool_0, bytes_0)

# Generated at 2022-06-25 07:32:29.034081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = str()
    var_1 = dict()
    action_module_0.run(var_0, var_1)


# Generated at 2022-06-25 07:32:31.303757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = str()
    var_1 = dict()
    action_module_0.run(var_0, var_1)

# Generated at 2022-06-25 07:32:33.729975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = None
    var_1 = {
    }
    action_module_0.run(var_0, var_1)


# Generated at 2022-06-25 07:32:39.965486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = str()
    var_1 = dict()
    response = action_module_0.run(var_0, var_1)
    assert response['failed'] == True
    assert response['changed'] == False


# Generated at 2022-06-25 07:32:41.568377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0)


# Generated at 2022-06-25 07:32:43.761966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = str()
    var_1 = dict()
    result = action_module_0.run(var_0, var_1)

# Generated at 2022-06-25 07:32:49.560746
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:32:57.532088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = dict()
    module_0 = {'e'}
    module_1 = str()
    facts_0 = dict()
    new_module_args_0 = None
    context_0 = str()
    tup_0 = (',',)
    def wrapped_f_0(task_vars_0=task_vars_0):
        return action_module_0._execute_module(module_name='ansible.legacy.service', module_args=new_module_args_0, task_vars=task_vars_0)
    wrapped_f_1 = action_module_0._execute_module
    ansible_service_mgr_0 = str()
    tup_1 = (':',)

# Generated at 2022-06-25 07:33:01.540398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = None
    action_module.run(tmp, task_vars)

# Generated at 2022-06-25 07:33:05.787164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_0 = None
    var_1 = None
    action_module_0.run(var_0, var_1)
    var_0 = str()
    action_module_0.test_result = var_0
    return


# Generated at 2022-06-25 07:33:14.847250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0)
    # assert_equal(expected, action_module_0.run(tmp, task_vars))
    raise NotImplementedError()

# Generated at 2022-06-25 07:33:18.290047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_0 = ActionModule(var_1)
    var_2 = var_0.run(var_1,var_2)

# Generated at 2022-06-25 07:33:20.132345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:33:23.532465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    os = None
    plugins = None
    shared_loader_obj = None
    var_0 = None
    action_module_0 = ActionModule(var_0)
    action_module_0.run(tmp=os, task_vars=plugins)

# Generated at 2022-06-25 07:33:33.256314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None

    action_module_1 = ActionModule(var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10, var_11, var_12, var_13)
    assert(isinstance(action_module_1, ActionModule))


# Generated at 2022-06-25 07:33:37.630059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0)

if __name__ == '__main__':
    try:
        test_ActionModule()
    except:
        print("Test Failed")
        raise

# Generated at 2022-06-25 07:33:39.191175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    action_module_0 = ActionModule(var_0)


# Generated at 2022-06-25 07:33:42.081694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    test_case_0()


# Generated at 2022-06-25 07:33:45.994422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var = None
    var_0 = ActionModule(var)
    assert var == None

# Generated at 2022-06-25 07:33:54.915812
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    var_0 = 'test_value_1'
    var_1 = 'test_value_2'

    # Set up mock
    AnsibleActionFail.run = mock_AnsibleActionFail_run
    AnsibleAction.run = mock_AnsibleAction_run

    # Construct argument dictionary
    arguments = {
        'tmp': var_0,
        'task_vars': var_1,
    }

    # Construct complex object for object test
    test_ActionModule_run_obj = ActionModule(var_0)

    # Construct global variable dictionary
    ansible_facts_ansible_service_mgr = 'test_value_3'
    ansible_service_mgr = 'test_value_4'
    hostvars_test_value_5_ansible_facts = 'test_value_6'
   

# Generated at 2022-06-25 07:34:09.720148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    info = {"ansible_facts": [{"ansible_service_mgr": "openwrt_init"}, {"ansible_service_mgr": "sysvinit"}, {"ansible_service_mgr": "systemd"}], "module": "ansible.legacy.setup"}
    result = {"module_args": ["openwrt_init", "sysvinit", "systemd"], "module": "ansible.legacy.setup"}
    ret = test_case_0()
    assert ret == result

# Generated at 2022-06-25 07:34:12.925341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	# create instance of class
	obj_ActionModule = ActionModule()
	# call method run with arguments
	obj_ActionModule.run(tmp, task_vars)

# Generated at 2022-06-25 07:34:18.306583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = create_task("ActionModule")
    var_1 = create_task("ActionModule")
    var_0.set_args(dict(name="foo", state="present"))
    var_2 = var_0.args
    var_3 = True if "state" in var_2 else False
    assert var_3, "Check if the var_2 contains the key 'state'"

test_case_0()

# Generated at 2022-06-25 07:34:28.833490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None

    def run():
        # print the test result
        print('test result:')
        print('the expected result:')
        print('the actual result:')
        print(var_0)
        print(var_1)
        print(var_2)
        print(var_3)
        print(var_4)

    class tmp:
        class args:
            class get:
                def __call__(self, arg_0):
                    return 

    class task_vars:
        pass

    var_1 = tmp()
    var_2 = task_vars()
    var_1.args = tmp()
    var_1.args.get = tmp.args.get

# Generated at 2022-06-25 07:34:29.707633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()


# Generated at 2022-06-25 07:34:31.606113
# Unit test for constructor of class ActionModule
def test_ActionModule():
  obj_ActionModule = ActionModule() # Create object of the class
  assert isinstance(obj_ActionModule, ActionModule) # Check if the object is instance of class


# Generated at 2022-06-25 07:34:34.128920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()


# Generated at 2022-06-25 07:34:40.078396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_0 = ActionModule()
    var_1 = var_0.run()
    assert var_1 == None

if __name__ == '__main__':
    import sys
    sys.exit(0)

# Generated at 2022-06-25 07:34:43.753797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None

    # Create the object
    var_0 = ActionModule(var_0, var_1, var_2, var_3)


# Generated at 2022-06-25 07:34:55.336882
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    # Check if module is called as the main module
    if os.path.basename(sys.argv[0]).split('.')[0] == '__main__':
        var_1 = ActionModule(
            task=var_0, connection=var_0, play_context=var_0, loader=var_0,
            templar=var_0, shared_loader_obj=var_0
        )
        var_2 = var_1._execute_module(
            module_name=var_0, module_args=var_0, task_vars=var_0,
            wrap_async=var_0
        )
        var_1.run(tmp=var_0, task_vars=var_0)
        assert var_1._supports_async == True
       

# Generated at 2022-06-25 07:35:06.162478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:35:06.929528
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert not test_case_0()



# Generated at 2022-06-25 07:35:08.247148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call the constructor of class ActionModule
    obj_ActionModule = ActionModule()


# Generated at 2022-06-25 07:35:10.013029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    test_case_0()
    

# Generated at 2022-06-25 07:35:21.269413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    import json
    import os
    import shutil

    # Create temp directory
    tempdir = tempfile.mkdtemp()
    # Create test vars
    test_vars = dict(tempdir=tempdir)
    # Create test PlayContext
    test_play_context = PlayContext()
    test_play_context.remote_addr='dummyhost'
    test_play_context.connection='dummyconnector'

# Generated at 2022-06-25 07:35:32.311228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-25 07:35:40.646999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    tmp = None
    task_vars = None
    var_0 = ActionModule()
    var_0.run(tmp, task_vars)
    var_1 = var_0._task.args
    var_2 = var_1.get('use')
    var_3 = var_0._task.delegate_to
    var_4 = var_0._templar
    var_5 = "{{hostvars['%s']['ansible_facts']['service_mgr']}}" % var_3
    var_6 = var_4

# Generated at 2022-06-25 07:35:49.716949
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_2 = {}
    var_1 = ActionModule({"variable_0": var_0}, var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10, var_11, var_12)
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22

# Generated at 2022-06-25 07:35:50.636729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None

# Generated at 2022-06-25 07:35:54.818342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = None
    tmp = None
    task_vars = None
    # Setting up mock
    test_case_0()
    action_module = ActionModule(tmp, task_vars)
    try:
        action_module.run(tmp = tmp, task_vars = task_vars)
    except Exception as e:
        result = e
    return result

# Generated at 2022-06-25 07:36:15.845904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.TRANSFERS_FILES == False
    #assert module.UNUSED_PARAMS == {u'systemd': [u'pattern', u'runlevel', u'sleep', u'arguments', u'args']}
    #assert module.BUILTIN_SVC_MGR_MODULES == set([u'openwrt_init', u'service', u'systemd', u'sysvinit'])


# Generated at 2022-06-25 07:36:19.282666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:36:21.281800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        var_1 = ActionModule(var_0)
    except:
        print("test_ActionModule raised unexpected exception")


# Generated at 2022-06-25 07:36:25.610514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = 'ansible.legacy.service'
    var_6 = 'ansible.legacy.service'
    # HACK: list of unqualified service manager names that are/were built-in, we'll prefix these with `ansible.legacy` to
    # avoid collisions with collections search
    var_7 = ['openwrt_init', 'service', 'systemd', 'sysvinit']
    action_service = ActionModule(var_0, var_1, var_2, var_3, var_4)
    assert action_service.run({}) == var_5
    assert action_service.BUILTIN_SVC_MGR_MODULES == var_7

# Generated at 2022-06-25 07:36:26.261777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:36:36.447729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
#       action plugin
#       ansible.playbook.play_context
#       ansible.inventory.host
#       ansible.executor.task_result
#       ansible.executor.task_queue_manager
#       ansible.executor.module_common.forbidden_attrs
#       ansible.playbook.task
#       ansible.playbook.play
#       ansible.executor.task_result
#       ansible.executor.task_queue_manager
#       ansible.executor.module_common.forbidden_attrs
#       ansible.vars.manager
#       ansible.template.template
#       ansible.inventory.host
#       ansible.vars.manager
#       ansible.template.template
#       ansible.vars.manager
#

# Generated at 2022-06-25 07:36:39.925556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    var_1 = {}
    var_2 = test_case_0()
    var_3 = 'test_case_0'
    var_4 = ActionModule(var_3, var_0, var_1, var_2)
    assert var_4 == None


# Generated at 2022-06-25 07:36:42.901969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    var_0 = None


# End


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:36:46.774763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj_0 = ActionModule(var_0)
    assert test_result == None, 'Cannot instantiate an object of ActionModule class'


# Generated at 2022-06-25 07:36:49.681499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    tmp = None
    task_vars = None

    # Invoke method
    result = ActionModule.run(tmp, task_vars)

    # Check result
    assert result == None

# Generated at 2022-06-25 07:37:25.008585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None


# Generated at 2022-06-25 07:37:27.878487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(AssertionError):
        test_case_0()
# Running unit test
if __name__ == "__main__":
    import pytest
    pytest.main()

# Generated at 2022-06-25 07:37:35.674845
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_native
    from ansible.plugins.loader import shared_loader_obj
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.action.normal import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six import string_types

   

# Generated at 2022-06-25 07:37:43.073877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {
        'module_defaults': None,
        '_supports_check_mode': None,
        '_supports_async': None,
        '_result': None,
        'name': None,
        '_loader': None,
        'action': None,
        'args': None,
        '_task': None,
        '_templar': None,
        '_shared_loader_obj': None,
        '_display': None
    }

    var_1 = {
        'action': 'auto',
        'use': 'auto'
    }

    var_2 = {
        '_supports_check_mode': True,
        '_supports_async': True,
        '_task': var_1
    }


# Generated at 2022-06-25 07:37:43.982274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:37:52.173757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # var_0 is of type object
    var_0 = None
    var_1 = ansible.plugins.action.ActionBase(var_0)
    # test of type dict
    var_2 = {u'ansible_facts': {u'first_fact': u'first_value'}, u'_ansible_verbose_always': True, u'changed': False}
    var_3 = true
    var_4 = None
    var_5 = None
    var_6 = ansible.plugins.action.ActionModule(var_0)
    pass



# Generated at 2022-06-25 07:37:53.808193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    assert var_0 is not None, "constructor test failed"


# Generated at 2022-06-25 07:38:03.642985
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    var_0 = ActionModule()
    var_2 = {}
    var_3 = {}
    var_1 = var_0.run(tmp=var_2, task_vars=var_3)
    assert len(var_1) == 2, "Expected length of var_1 to be 2, but got %s" % len(var_1)
    assert 'invocation' in var_1
    assert 'result' in var_1
    var_4 = var_1['invocation']
    assert len(var_4) == 6, "Expected length of var_4 to be 6, but got %s" % len(var_4)
    assert 'module_name' in var_4

# Generated at 2022-06-25 07:38:05.376068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except:
        print("Test case 0 failed")

# Generated at 2022-06-25 07:38:16.575918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None, "Could not create an object of type ActionModule."
    assert action_module.TRANSFERS_FILES == False, "Could not create an object of type ActionModule."
    assert action_module.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'], }, "Could not create an object of type ActionModule."
    assert action_module.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}, "Could not create an object of type ActionModule."


# Generated at 2022-06-25 07:38:54.292192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:38:56.010527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:39:01.922376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    list_1 = [tuple_0, tuple_0, tuple_0, tuple_0]
    str_0 = 'qN,oVWN4-s&'
    action_module_0 = ActionModule(list_1, list_1, list_1, tuple_0, tuple_0, str_0)
    float_0 = -533.6
    set_0 = {action_module_0, str_0}
    action_module_1 = ActionModule(tuple_0, action_module_0, float_0, str_0, set_0, action_module_0)


# Generated at 2022-06-25 07:39:06.791916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    tuple_0 = ()
    list_1 = [tuple_0, tuple_0, tuple_0, tuple_0]
    str_0 = '7_8eM<'
    action_module_0 = ActionModule(list_1, list_1, list_1, tuple_0, tuple_0, str_0)
    float_0 = 1e8
    set_0 = {action_module_0, str_0}
    action_module_1 = ActionModule(tuple_0, action_module_0, float_0, str_0, set_0, action_module_0)
    var_0 = action_module_1.run(list_0, list_0)
    assert var_0 is None


# Generated at 2022-06-25 07:39:10.942226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    list_1 = [tuple_0, tuple_0, tuple_0, tuple_0]
    str_0 = '7}(,t"`Q9'
    action_module_0 = ActionModule(list_1, list_1, list_1, tuple_0, tuple_0, str_0)
    assert action_module_0._task._role.get_name() == ''


# Generated at 2022-06-25 07:39:18.047842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    tuple_0 = ()
    list_1 = [tuple_0]
    str_0 = 'tG;C8&XnE!yj'
    action_module_0 = ActionModule(list_1, list_1, list_1, tuple_0, tuple_0, str_0)
    list_2 = ['6Ua%cwN%%N(']
    tuple_1 = (action_module_0,)
    set_0 = {str_0, tuple_1, list_2}
    action_module_1 = ActionModule(tuple_0, action_module_0, set_0, str_0, list_1, action_module_0)
    var_0 = None
    var_1 = action_module_1.run(var_0, list_2)

# Generated at 2022-06-25 07:39:28.366589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    list_1 = [tuple_0, tuple_0, tuple_0, tuple_0]
    str_0 = 'qN,oVWN4-s&'
    action_module_0 = ActionModule(list_1, list_1, list_1, tuple_0, tuple_0, str_0)
    float_0 = -533.6
    set_0 = {action_module_0, str_0}
    action_module_1 = ActionModule(tuple_0, action_module_0, float_0, str_0, set_0, action_module_0)
    assert isinstance(action_module_0, ActionModule)



# Generated at 2022-06-25 07:39:38.162388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    tuple_0 = ()
    list_1 = [tuple_0, tuple_0, tuple_0, tuple_0]
    str_0 = 'qN,oVWN4-s&'
    action_module_0 = ActionModule(list_1, list_1, list_1, tuple_0, tuple_0, str_0)
    float_0 = -533.6
    set_0 = {action_module_0, str_0}
    action_module_1 = ActionModule(tuple_0, action_module_0, float_0, str_0, set_0, action_module_0)
    var_0 = action_module_1.run(list_0, list_0)

# Generated at 2022-06-25 07:39:44.520138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    tuple_0 = ()
    list_1 = [tuple_0, tuple_0, tuple_0, tuple_0]
    str_0 = '9s2sC_(u'
    action_module_0 = ActionModule(list_1, list_1, list_1, tuple_0, tuple_0, str_0)
    float_0 = -402.0
    set_0 = {action_module_0, str_0}
    action_module_1 = ActionModule(tuple_0, action_module_0, float_0, str_0, set_0, action_module_0)
    var_0 = action_module_1.run(list_0, list_0)


# Generated at 2022-06-25 07:39:46.981539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {}
    class_0 = ActionModule
    assert class_0(set_0, set_0, set_0, set_0, set_0, set_0)


# Generated at 2022-06-25 07:41:10.406226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_1 = []
    tuple_0 = ()
    list_2 = [tuple_0, tuple_0, tuple_0, tuple_0]
    str_0 = 'qN,oVWN4-s&'
    action_module_0 = ActionModule(list_2, list_2, list_2, tuple_0, tuple_0, str_0)
    assert (action_module_0.UNUSED_PARAMS['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args'])
    float_0 = -533.6
    set_0 = {action_module_0, str_0}
    action_module_1 = ActionModule(tuple_0, action_module_0, float_0, str_0, set_0, action_module_0)
    var