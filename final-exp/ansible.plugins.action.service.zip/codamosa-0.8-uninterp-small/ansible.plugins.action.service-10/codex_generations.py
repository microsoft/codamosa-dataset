

# Generated at 2022-06-25 07:31:29.807396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    set_1 = set()
    int_1 = 3770
    tuple_0 = (set_1, str_0, int_0)
    str_0 = "zYXRRo.[FHwOb'"
    action_module_0 = ActionModule(set_0, tuple_0, str_0, int_1, set_0, str_0)
    action_module_0.run()

    set_0 = set()
    int_1 = 3770
    tuple_0 = (set_1, str_0, int_0)
    str_0 = "zYXRRo.[FHwOb'"
    action_module_0 = ActionModule(set_0, tuple_0, str_0, int_1, set_0, str_0)

# Generated at 2022-06-25 07:31:35.444023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 3510
    int_1 = 3770
    tuple_0 = (int_0, set_0, int_1)
    str_0 = "zYXRRo.[FHwOb'"
    action_module_0 = ActionModule(set_0, tuple_0, str_0, int_1, set_0, str_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert result is not None


# Generated at 2022-06-25 07:31:42.773566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    list_0 = list()
    int_0 = 6106
    int_1 = 6903
    tuple_0 = (int_0, set_0, int_1)
    str_0 = "YMXMS'$@=zPw~`"
    action_module_0 = ActionModule(set_0, tuple_0, str_0, int_1, set_0, str_0)

    action_module_0.run(tmp=list_0)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:31:48.558535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 3510
    int_1 = 3770
    tuple_0 = (int_0, set_0, int_1)
    str_0 = "zYXRRo.[FHwOb'"
    action_module_0 = ActionModule(set_0, tuple_0, str_0, int_1, set_0, str_0)
    tmp = None
    task_vars = None
    tmp_1 = action_module_0.run(tmp, task_vars)

test_ActionModule_run()

# Generated at 2022-06-25 07:31:56.973514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 6031
    int_1 = 1667
    tuple_0 = (int_0, set_0, int_1)
    str_0 = "zYXRRo.[FHwOb'"
    action_module_0 = ActionModule(set_0, tuple_0, str_0, int_1, set_0, str_0)

    tmp = None
    task_vars = None
    try:
        action_module_0.run(tmp, task_vars)
    except AnsibleActionFail:
        return False
    return True


# Generated at 2022-06-25 07:31:57.847114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:32:05.615108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for successful execution of run method of class ActionModule for case 0
    def test_case_run_0():
        set_0 = set()
        int_0 = 3623
        int_1 = 3839
        tuple_0 = (int_1, int_0)
        str_0 = "UIv"
        str_1 = "UyBRh"
        dict_0 = dict()
        action_module_0 = ActionModule(set_0, tuple_0, str_1, int_0, str_0, dict_0)
        res_0 = action_module_0.run(set_0, dict_0)
        assert res_0 == dict()
        assert res_0 != dict()
        assert res_0 == dict()
    #Test for successful execution of run method of class ActionModule for case 1
   

# Generated at 2022-06-25 07:32:10.756322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 1716
    int_1 = 4609
    tuple_0 = (int_0, set_0, int_1, int_1, set_0)
    str_0 = "zYXRRo.[FHwOb'"
    action_module_0 = ActionModule(set_0, tuple_0, str_0, int_1, set_0, str_0)

# Generated at 2022-06-25 07:32:17.417989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_1 = 3770
    tuple_0 = ActionModule.UNUSED_PARAMS
    str_0 = "zYXRRo.[FHwOb'"
    action_module_0 = ActionModule(set_0, tuple_0, str_0, int_1, set_0, str_0)
    action_module_0.run()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:32:27.939159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = set()
    int_0 = 3510
    int_1 = 3770
    tuple_0 = (int_0, set_0, int_1)
    str_0 = "zYXRRo.[FHwOb'"
    action_module_0 = ActionModule(set_0, tuple_0, str_0, int_1, set_0, str_0)
    str_1 = "zYXRRo.[FHwOb'"
    str_2 = "zYXRRo.[FHwOb'"
    action_module_1 = ActionModule(str_1, set_0, int_1, str_0, set_0, str_2)
    map_0 = {}
    task_vars_0 = {}
    str_3 = "zYXRRo.[FHwOb'"
   

# Generated at 2022-06-25 07:32:43.884026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    var_1 = {
        'module': 'service',
        'use': 'systemd',
        'state': 'started',
        'name': 'nginx',
        'reload': True,
    }
    var_2 = 'ansible.legacy.service'
    var_3 = 'service'
    obj_0 = ActionModule(var_1, var_2, var_3)
    var_4 = {
        'test': True,
    }
    var_5 = obj_0.run(var_4)
    assert var_5 == True

# Generated at 2022-06-25 07:32:49.958211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = set()
    int_0 = 3770
    str_0 = "zYXRRo.[FHwOb'"
    module_0 = ActionModule(var_0)
    module_0.test()


# Generated at 2022-06-25 07:32:50.925332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    var_1 = ActionModule()


# Generated at 2022-06-25 07:32:58.374679
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:33:00.851070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    formatter = test_ActionBase()
    # TODO: Why does constructor need 'formatter'?
    action_module = ActionModule(formatter)
    test_case_0()


# Generated at 2022-06-25 07:33:01.901702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = test_case_0()


# Generated at 2022-06-25 07:33:10.383202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    callable_0 = obj._execute_module
    var_0 = set({'Z'})
    var_1 = set()
    int_0 = -1071
    str_0 = "eV,f.!Z-PsbE"
    var_2 = set()
    var_3 = set()
    int_1 = -10938
    str_1 = "~-Y/!a!$-n,t"
    var_4 = set()
    var_5 = set()
    obj._execute_module = callable_0

    obj.run(tmp=var_0, task_vars=var_1)

# Generated at 2022-06-25 07:33:13.008266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()

    var_0 = set()
    str_0 = "pGg.!][@j"


# Generated at 2022-06-25 07:33:20.009009
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print("Testing method run of class ActionModule")

    # run the class code for method run. It should return an object of type AnsibleAction

    # set up test vars
    testcase_module_0 = ActionModule()
    ansible_action_0 = testcase_module_0.run()
    assert(isinstance(ansible_action_0, AnsibleAction) == True)
    print("\tTest case 0 of method run passed")

    return print("\tAll test cases for method run passed")

# Define main()

# Generated at 2022-06-25 07:33:20.915125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 07:33:28.866943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:33:29.664411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert (1 == 1)

# Generated at 2022-06-25 07:33:33.868617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._display.vvvv = MagickMock()
    action_module_0._execute_module = MagickMock()
    action_module_0._shared_loader_obj = {
        'module_loader': {
            'find_plugin_with_context': MagickMock(),
            'has_plugin': MagickMock(return_value=True)
        }
    }
    action_module_0._connection = MagickMock()
    action_module_0._remove_tmp_path = MagickMock()
    action_module_0._task = MagickMock()
    action_module_0._task._parent = MagickMock()
    action_module_0._task._parent._play = {'_action_groups': {}}
   

# Generated at 2022-06-25 07:33:38.282566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


if __name__ == '__main__':
    import subprocess
    subprocess.call(['pytest'])
#   test_case_0()
#   test_ActionModule_run()

# Generated at 2022-06-25 07:33:38.877801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:33:42.731515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:33:46.575110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

test_case_0()

# Generated at 2022-06-25 07:33:55.564448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tests for method run of class ActionModule
    action_module = ActionModule()
    module = "auto"
    task_vars = {"ansible_service_mgr": "test"}
    assert action_module.run(task_vars=task_vars) is not None
    module = "auto"
    task_vars = {"ansible_service_mgr": "test"}
    assert action_module.run(task_vars=task_vars) is not None
    module = "auto"
    task_vars = {"ansible_service_mgr": "test"}
    assert action_module.run(task_vars=task_vars) is not None
    module = "auto"
    task_vars = {"ansible_service_mgr": "test"}

# Generated at 2022-06-25 07:34:01.283893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = dict()
    task_vars = dict()
    result = action_module.run(tmp,task_vars)
    # assert result == ...


# Generated at 2022-06-25 07:34:07.901747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Setup args:
    args = { 'use': 'auto', }

    # Call method:
    result = action_module_0.run(tmp=None, task_vars=None)

    assert result == None

# Test if module is executable:
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:34:20.284674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)



# Generated at 2022-06-25 07:34:21.282766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert not action_module_0.run()

# Generated at 2022-06-25 07:34:27.120050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)


# Generated at 2022-06-25 07:34:35.361805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    action_module_0.run()

# Generated at 2022-06-25 07:34:42.492279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    assert action_module_0.supports_check_mode() == True
    assert action_module_0.supports_async() == True
    assert action_module_0.run(set_0, bytes_0) == None
    assert action_module_0.run(set_0, str_0) == None

# Generated at 2022-06-25 07:34:51.242898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    bool_1 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_1, float_0, list_0)


# Generated at 2022-06-25 07:34:57.048419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)


# Generated at 2022-06-25 07:35:01.271971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # AssertionError: None.__init__() takes exactly 6 arguments (1 given)
    assert test_case_0() == None



# Generated at 2022-06-25 07:35:09.378796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)


# Generated at 2022-06-25 07:35:17.520340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')

    # test case 0
    set_0 = None
    str_0 = ' \x10\x82\x80'
    int_0 = 0
    bool_0 = True
    str_1 = '\x00\xb0\xb7<\x87K'
    float_0 = 0.0013208972
    bool_1 = False
    action_module_0 = ActionModule(set_0, str_0, int_0, bool_0, str_1, float_0, bool_1)
    var_0 = action_module_0.run(None, None)
    assert var_0, 'Unable to run'



# Generated at 2022-06-25 07:35:40.122576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x01\xa5\x10\xac"\x1d\xcf\xb8\x85|\x9d\x98\xc6\xf0\xcb'

# Generated at 2022-06-25 07:35:46.504646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    var_0 = action_run(set_0)

# Generated at 2022-06-25 07:35:54.778983
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup
    str_0 = 'test'
    bool_0 = False
    float_0 = 0.4
    list_0 = []
    action_module_0 = ActionModule(str_0, bool_0, bool_0, bool_0, float_0, list_0)


    def side_effect(module_name, module_args, task_vars, wrap_async):

        if module_name == 'ansible.legacy.setup':
            return {
                'ansible_facts': {
                    'ansible_service_mgr': 'test'
                }
            }


# Generated at 2022-06-25 07:36:02.747393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    assert {} == action_module_0.run(set_0)

# Generated at 2022-06-25 07:36:09.014201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    assert isinstance(action_module_0, object)
    assert isinstance(action_module_0, object)
    assert isinstance(action_module_0, object)

# Generated at 2022-06-25 07:36:18.851367
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Try to run class method with valid parameters
    set_1 = None
    bytes_1 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_1 = 'D \x0b'
    bool_1 = True
    float_1 = 0.2
    list_1 = []
    action_module_1 = ActionModule(bytes_1, str_1, bool_1, bool_1, float_1, list_1)
    var_1 = action_module_1.run(set_1)
    # Check if class method run was called
    if var_1 == False:
        raise AssertionError("expected: %s, actual: %s" %("run", "not run"))

# Generated at 2022-06-25 07:36:26.986174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    var_0 = action_module_0.run(set_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:36:35.200017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    float_0 = 0.2
    str_0 = 'D \x0b'
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    list_0 = []
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    var_0 = action_module_0.run(set_0, set_0)

# Generated at 2022-06-25 07:36:36.855432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:36:44.336806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = None
    str_0 = '\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    bool_0 = True
    bool_1 = True
    float_0 = 0.9
    list_0 = None
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_1, float_0, list_0)
    bool_2 = False
    set_0 = None
    dict_0 = None
    str_1 = '\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'

# Generated at 2022-06-25 07:37:24.087012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    action_module_0.__getattribute__('')
    return action_module_0


# Generated at 2022-06-25 07:37:32.810154
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        set_0 = None
        bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
        str_0 = 'D \x0b'
        bool_0 = True
        float_0 = 0.2
        list_0 = []
        action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
        # assert action_module_0._supports_check_mode == True
        # assert action_module_0._supports_async == True
    except Exception as e:
        print('Exception: ' + str(e))
        assert False


# Generated at 2022-06-25 07:37:42.382992
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    bool_1 = False
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_1, float_0, list_0)
    assert action_module_0.templar
    assert action_module_0.display
    assert action_module_0.shared_loader_obj
    assert action_module_0.task
    assert action_module_0.connection

# Generated at 2022-06-25 07:37:43.023271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:37:44.215663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement proper unit test
    assert True == True


# Generated at 2022-06-25 07:37:54.510730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    assert_equal(action_module_0._supports_async, True)
    assert_equal(action_module_0._supports_check_mode, True)
    assert_equal(len(action_module_0.BUILTIN_SVC_MGR_MODULES), 3)

# Generated at 2022-06-25 07:38:01.146809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    assert len(action_module_0.UNUSED_PARAMS) == 3
    assert len(action_module_0.BUILTIN_SVC_MGR_MODULES) == 4
# End of unit test for constructor of class ActionModule


# Generated at 2022-06-25 07:38:06.506308
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2', 'D \x0b', True, True, 0.2, [])
    set_0 = None
    var_0 = action_module_0.run(set_0)
    print(var_0)

# Generated at 2022-06-25 07:38:13.634148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_1 = None
    bytes_1 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_1 = 'D \x0b'
    bool_1 = True
    float_1 = 0.2
    list_1 = []
    action_module_1 = ActionModule(bytes_1, str_1, bool_1, bool_1, float_1, list_1)


# Generated at 2022-06-25 07:38:19.889561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    set_0 = None
    action_module_0.run(set_0)

# Generated at 2022-06-25 07:39:47.003477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)


# Generated at 2022-06-25 07:39:54.134787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    action_module_0.run(set_0, set_0)

# Generated at 2022-06-25 07:39:59.535197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
        Constructor testing for class ActionModule
    """
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)


# Generated at 2022-06-25 07:40:05.000009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run.__doc__)
    bytes_0 = b'\xdf\xca\xa9\x0e\xee\xb2\x1b\x0c\x8f@\xa6^\x9d\xd6\xb5\x8b\x05\xaa\x87\xc2\x8c\x9dX\x1c\x15\x8c\x0f\x87\x04\xc6\x8a\x8f\x1dv\xda\xc2\xad\x90\x19\x1f\x12\xaf\xb6\xee\xf4\xd5C\xa5\x97\xfd\xfc\x1d\x0e'

# Generated at 2022-06-25 07:40:10.762293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor defined by class ActionModule
    action_module_0 = ActionModule()
    print(action_module_0.supports_check_mode)
    print(action_module_0.supports_async)

if __name__ == '__main__':
    # Test case for constructor of arg data type
    test_case_0()
    # Test case for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 07:40:13.359784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:40:18.560018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    assert action_module_0._supports_async
    assert action_module_0._supports_check_mode
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:40:28.561688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    assert action_module_0._supports_check_mode == True
    assert action_module_0._supports_async == True
    assert action_module_0._connection == bytes_0
    assert action_module_0._play_context == str_0
    assert action_module_0._loader == bool_0

# Generated at 2022-06-25 07:40:32.580039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)

# Test for function action_run

# Generated at 2022-06-25 07:40:40.851527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bytes_0 = b'\x1d\xe04\xa3C\x02u\xa5\xbf\xd7V\xbdYq\xc2'
    str_0 = 'D \x0b'
    bool_0 = True
    float_0 = 0.2
    list_0 = []
    action_module_0 = ActionModule(bytes_0, str_0, bool_0, bool_0, float_0, list_0)
    var_0 = action_module_0.run(set_0)