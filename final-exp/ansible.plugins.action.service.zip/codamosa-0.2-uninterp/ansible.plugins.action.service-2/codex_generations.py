

# Generated at 2022-06-17 09:30:44.528749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:30:53.581584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

# Generated at 2022-06-17 09:30:54.363254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:31:04.490722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = Mock()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.async_val = None

    # Create a mock connection
    mock_connection = Mock()
    mock_connection._shell = Mock()
    mock_connection._shell.tmpdir = '/tmp/test'

    # Create a mock loader
    mock_loader = Mock()
    mock_loader.module_loader = Mock()
    mock_loader.module_loader.has_plugin = Mock(return_value=True)

    # Create a mock templar
    mock_templar = Mock()
    mock_templar.template = Mock(return_value='auto')

    # Create a mock display
    mock_display = Mock()

    #

# Generated at 2022-06-17 09:31:13.781276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task object
    task_obj = MockTaskObj()

    # Create a mock play object
    play_obj = MockPlayObj()

    # Create a mock play context object
    play_context_obj = MockPlayContextObj()

    # Create

# Generated at 2022-06-17 09:31:24.372360
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:31:32.051571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(
            args=dict(
                use='auto'
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action.run() == dict(
        failed=True,
        msg='Could not detect which service manager to use. Try gathering facts or setting the "use" option.'
    )

# Generated at 2022-06-17 09:31:36.992823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action.TRANSFERS_FILES == False
    assert action.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert action.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-17 09:31:40.898418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:31:45.138971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:32:00.668679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.utils import dict_diff
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigParser

# Generated at 2022-06-17 09:32:13.202139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFact
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFact
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-17 09:32:13.732435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:15.919026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:32:16.394465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:23.811196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service
    import ansible.plugins.action.systemd
    import ansible.plugins.action.sysvinit
    import ansible.plugins.action.openwrt_init
    import ansible.plugins.action.setup
    import ansible.plugins.loader

    # Create a mock task object
    task = ansible.plugins.loader.Task()
    task.args = {'use': 'auto'}
    task.async_val = False

    # Create a mock connection object
    connection = ansible.plugins.loader.Connection()
    connection._shell = ansible.plugins.loader.Shell()
    connection._shell.tmpdir = '/tmp'

    # Create a mock shared loader object
    shared_loader_obj = ansible.plugins.loader.ActionModuleLoader()

# Generated at 2022-06-17 09:32:24.672956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:31.006517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_context = dict(
        become=False,
        become_method=None,
        become_user=None,
        check_mode=False,
        diff=False,
        passwords=dict(),
        remote_addr=None,
        remote_user=None,
        shell=None,
        stdin=None,
        sudo_flags=None,
        sudoable=False,
        verbosity=0,
    )


# Generated at 2022-06-17 09:32:42.763963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'auto'}
    task.delegate_to = None
    task.async_val = False

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_defaults
    module_defaults = {}

    # Create a mock action_groups
    action_groups = {}

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task_vars
    task_vars = {}

    # Create a mock tmp
    tmp = None



# Generated at 2022-06-17 09:32:49.604713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:33:03.579855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:33:04.781640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None) is not None

# Generated at 2022-06-17 09:33:09.027207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(args=dict(name='foo')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action._supports_check_mode is True
    assert action._supports_async is True

# Generated at 2022-06-17 09:33:18.418893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.common.text.formatters import human_to_bytes

# Generated at 2022-06-17 09:33:19.482816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:33:26.361036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                use='auto',
            ),
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )
    assert action_module is not None

# Generated at 2022-06-17 09:33:33.766873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import get_vars

# Generated at 2022-06-17 09:33:39.665028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an action module
    action_module = ActionModule(task, connection, loader, display, templar, shared_loader_obj)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Create a mock module_name
    module_name = 'ansible.legacy.service'

    # Create a mock module_args
   

# Generated at 2022-06-17 09:33:50.636179
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(name='foo', state='started')

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock module_defaults
    module_defaults = dict()

    # Create a mock action_groups
    action_groups = dict()

    # Create a mock async_val

# Generated at 2022-06-17 09:34:01.656443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display

# Generated at 2022-06-17 09:34:28.738471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:34:36.691053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

    # Test the run method
    result = action_module.run(None, None)


# Generated at 2022-06-17 09:34:37.357591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:34:46.243572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task = {
        'args': {
            'use': 'auto',
            'name': 'httpd',
            'state': 'started',
            'enabled': 'yes'
        }
    }
    module._task.async_val = False
    module._task.delegate_to = None
    module._connection = {
        '_shell': {
            'tmpdir': '/tmp/ansible-tmp-1588456817.7-274424502367982/'
        }
    }

# Generated at 2022-06-17 09:34:56.425000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service as service
    import ansible.plugins.action.systemd as systemd
    import ansible.plugins.action.sysvinit as sysvinit
    import ansible.plugins.action.openwrt_init as openwrt_init
    import ansible.plugins.action.service as service
    import ansible.plugins.action.setup as setup
    import ansible.plugins.action.auto as auto
    import ansible.plugins.action.raw as raw
    import ansible.plugins.action.script as script
    import ansible.plugins.action.copy as copy
    import ansible.plugins.action.file as file
    import ansible.plugins.action.lineinfile as lineinfile
    import ansible.plugins.action.template as template
    import ansible.plugins.action.unarchive as un

# Generated at 2022-06-17 09:35:07.476349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

# Generated at 2022-06-17 09:35:08.714504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:35:09.254480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:11.674614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:35:21.707896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import json
    import tempfile
    import shutil
    import unittest
    import ansible.constants as C
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.service import ActionModule

# Generated at 2022-06-17 09:36:14.730150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:36:18.722805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:36:32.458040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = None

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module
    module = MockModule()

    # Create a mock module

# Generated at 2022-06-17 09:36:42.232445
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:36:52.957183
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:36:58.918090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test', state='present')),
        connection=dict(host='localhost', port=22, user='root'),
        play_context=dict(remote_addr='localhost', port=22, remote_user='root'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-17 09:37:08.926053
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    mock_task.args = {'name': 'foo', 'state': 'started'}
    mock_task.delegate_to = None
    mock_task.async_val = None

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock loader
    mock_loader = MockLoader()

    # Create a mock shared loader obj
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock action base
    mock_action_base = MockActionBase()

    # Create a mock action module

# Generated at 2022-06-17 09:37:19.229023
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:33.071338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module
    module = MockModule()

    # Create a mock module args
    module_args = {'name': 'httpd', 'state': 'started'}

    # Create a mock task vars

# Generated at 2022-06-17 09:37:38.558534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module finder
    module_finder_obj = MockModuleFinderObj()
    # Create a mock module finder
    module_finder_obj_2 = MockModuleF

# Generated at 2022-06-17 09:39:39.121754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a test object
    action_module = ActionModule()
    # Test the constructor
    assert action_module

# Generated at 2022-06-17 09:39:40.371220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:39:52.699151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.module_utils.common.json import AnsibleJSONDecoder
    from ansible.module_utils.common.json import AnsibleJSONEncoderForCLI
    from ansible.module_utils.common.json import AnsibleJSONDecoderForCLI
    from ansible.module_utils.common.json import AnsibleModuleJSONEncoder
    from ansible.module_utils.common.json import AnsibleModuleJSONDecoder
    from ansible.module_utils.common.json import AnsibleModuleJSON

# Generated at 2022-06-17 09:40:00.801343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:40:08.065884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:40:17.768656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()
    # Create a mock action_groups
    action_groups = MockActionGroups()
    # Create a mock play
    play = MockPlay()
    # Create a

# Generated at 2022-06-17 09:40:19.391427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:40:31.692625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_