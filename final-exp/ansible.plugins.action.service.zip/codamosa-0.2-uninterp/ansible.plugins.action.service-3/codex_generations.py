

# Generated at 2022-06-17 09:30:44.413092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create

# Generated at 2022-06-17 09:30:53.444843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 09:30:55.905497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:30:59.340190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module is not None


# Generated at 2022-06-17 09:31:02.447556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:31:03.532281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:31:04.376389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:31:11.953158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a task
    task = dict(
        action=dict(
            module='service',
            args=dict(
                name='httpd',
                state='started',
                use='auto'
            )
        )
    )

    # create a task_vars
    task_vars = dict()

    # create a tmp
    tmp = None

    # create a shared_loader_obj
    shared_loader_obj = None

    # create a connection_loader
    connection_loader = None

    # create a play_context
    play_context = None

    # create a loader
    loader = None

    # create a templar
    templar = None

    # create a action_base

# Generated at 2022-06-17 09:31:23.939835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an action module object
    action_module = ActionModule(task, connection, loader, display, templar, action_plugin, shared_loader_obj)

    # Test the run method
    action_module.run()

    # Test the run method with an exception
    action_module.run(exception=True)

# Generated at 2022-06-17 09:31:29.744801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock module loader
    mock_module_loader = MockModuleLoader()

    # Create a mock context
    mock_context = MockContext()

    # Create a mock action groups
    mock_action_groups = MockActionGroups()

    # Create a mock module defaults
    mock_module_defaults = MockModuleDefaults()

    # Create a mock task vars
    mock_task_vars = MockTaskVars()

    #

# Generated at 2022-06-17 09:31:38.822215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:31:48.908164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    mock_task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader object
    mock_module_loader = MockModuleLoader()

    # Create a mock module context
    mock_module_context = MockModuleContext()

    # Create a mock module
    mock_module = MockModule()

    # Create a mock facts
    mock_facts = MockFacts()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock action
   

# Generated at 2022-06-17 09:31:59.241393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {
        'name': 'httpd',
        'state': 'started',
        'use': 'auto'
    }
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock module defaults
    module_defaults = MockModuleDefaults()
    # Create a mock action groups
    action_groups = MockActionGroups()
    # Create a mock

# Generated at 2022-06-17 09:31:59.868462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:08.277283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task with a mock connection
    mock_task = MockTask()
    mock_task.args = {'name': 'httpd', 'state': 'started'}
    mock_task.delegate_to = None
    mock_task.async_val = None
    mock_task.action = 'service'
    mock_task._parent = MockPlay()
    mock_task._parent._play = MockPlay()
    mock_task._parent._play._action_groups = []
    mock_task._parent._play._action_groups.append(MockActionGroup())
    mock_task._parent._play._action_groups[0]._action = 'service'
    mock_task._parent._play._action_groups[0]._action_name = 'service'

# Generated at 2022-06-17 09:32:18.646142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 09:32:32.814427
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:32:43.315230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock parent
    parent = MockParent()

    # Create a mock play
    play = MockPlay()

    # Create a mock action_groups

# Generated at 2022-06-17 09:32:49.118135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:32:53.108108
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a new instance of ActionModule
    action_module = ActionModule()
    # Check if the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:33:14.017382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

# Generated at 2022-06-17 09:33:22.647493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:33:31.336555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock action module
    action_module = MockActionModule(task)

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module context
    module_context = MockModuleContext()

    # Create a mock module
    module = MockModule()

    # Create a mock module args
    module_args = MockModuleArgs()

    # Create a mock

# Generated at 2022-06-17 09:33:40.247654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(name='foo', state='started')
    task.async_val = 42

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = 'tmpdir'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

    # Create a mock module
    module = MockModule()

   

# Generated at 2022-06-17 09:33:41.501652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:33:51.932802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    import ansible.plugins.action.service as service
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

# Generated at 2022-06-17 09:33:52.686390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:34:03.357916
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:34:06.897084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:34:14.954498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()
    # Create a mock module finder object
    module_finder

# Generated at 2022-06-17 09:34:54.789197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.async_val = False
    task.delegate_to = None

    # Create a mock connection
    connection = MockConnection()
    connection._shell = MockShell()
    connection._shell.tmpdir = '/tmp/ansible-tmp-1566642021.9-26682487885076'

    # Create a mock loader
    loader = MockLoader()
    loader.module_loader = MockModuleLoader()
    loader.module_loader.has_plugin = Mock(return_value=True)

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()
    templar.template = Mock

# Generated at 2022-06-17 09:34:55.318209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:02.203272
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:10.466482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()

    # Create an instance of AnsiblePlay
    ansible_play = AnsiblePlay()

    # Create an instance of AnsiblePlaybook
    ansible_playbook = AnsiblePlaybook()

    # Create an instance of AnsibleConnection
    ansible_connection = AnsibleConnection()

    # Create an instance of AnsibleShell
    ansible_shell = AnsibleShell()

    # Create an instance of AnsibleTemplar
    ansible_templar = AnsibleTemplar()

    # Create an instance of AnsibleDisplay
    ansible_display = AnsibleDisplay()

    # Create an

# Generated at 2022-06-17 09:35:16.348701
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:35:25.031159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock action_plugin
    action_plugin = MockActionPlugin()
    action_plugin._shared_loader_obj = shared_loader_obj
    action_plugin._task = task

# Generated at 2022-06-17 09:35:28.524701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:39.775088
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:45.870606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:35:56.561596
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:04.549967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock task object
    task_vars = MockTaskVars()
    # Create a mock action module object
    action_module = ActionModule(task, connection, loader, shared_loader_obj, display, templar, action_base, task_vars)
    # Check if the object is an instance of Action

# Generated at 2022-06-17 09:37:16.981450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with default values
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True
    assert action_module.TRANSFERS_FILES is False
    assert action_module.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert action_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-17 09:37:24.214729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class
    action_module = ActionModule()
    # create an instance of the Ansible class
    ansible = Ansible()
    # create an instance of the AnsibleOptions class
    ansible_options = AnsibleOptions()
    # create an instance of the PlayContext class
    play_context = PlayContext()
    # create an instance of the Task class
    task = Task()
    # create an instance of the TaskResult class
    task_result = TaskResult()
    # create an instance of the TaskExecutor class
    task_executor = TaskExecutor()
    # create an instance of the ActionBase class
    action_base = ActionBase()
    # create an instance of the AnsibleAction class
    ansible_action = AnsibleAction()
    # create an instance of the AnsibleActionFail class
    ansible_

# Generated at 2022-06-17 09:37:33.176401
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:41.465473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.init import Inventory

# Generated at 2022-06-17 09:37:52.501899
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, display, templar, shared_loader_obj, action_base)

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock ansible action
    ansible_action = MockAnsibleAction()



# Generated at 2022-06-17 09:37:58.475418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, display)

    # Run the method
    action_plugin.run(None, None)

    # Assert that the method ran correctly
    assert action_plugin._execute_module.call_count == 2

# Generated at 2022-06-17 09:38:07.040940
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.async_val = False

    # Create a mock connection
    mock_connection = MockConnection()
    mock_connection._shell = MockShell()
    mock_connection._shell.tmpdir = '/tmp'

    # Create a mock loader
    mock_loader = MockLoader()
    mock_loader.module_loader = MockModuleLoader()
    mock_loader.module_loader.has_plugin = Mock(return_value=True)

    # Create a mock shared loader obj
    mock_shared_loader_obj = MockSharedLoaderObj()
    mock_shared_loader_obj.module_loader = MockModuleLoader()
    mock_shared_loader_

# Generated at 2022-06-17 09:38:18.345334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:38:27.144953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os = 'default'
    play