

# Generated at 2022-06-17 09:30:46.990735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'auto'}
    task.delegate_to = None
    task.async_val = False

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock

# Generated at 2022-06-17 09:30:58.242614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = MockTask()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock action base object
    action_base = MockActionBase()

    # Create a mock task base object
    task_base = MockTaskBase()

    # Create a mock play object
    play = MockPlay()

    # Create a mock play context object
    play_context = MockPlayContext()

    # Create a mock play base object
    play_base = MockPlayBase()

    # Create a

# Generated at 2022-06-17 09:31:07.674147
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:31:08.200027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:31:17.350154
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'auto'}
    task.delegate_to = None
    task.async_val = False

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader object
    module_loader = MockModuleLoader()

    # Create a mock context object
    context = MockContext()

    # Create a mock module_defaults object
    module_defaults = MockModuleDefaults()

    # Create

# Generated at 2022-06-17 09:31:19.663180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:31:27.956422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._task.args['name'] == 'foo'
    assert action_module._task.args['state'] == 'present'

# Generated at 2022-06-17 09:31:35.235883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(host='localhost', port=22, user='root', password='password'),
        play_context=dict(become=False, become_method='sudo', become_user='root', check_mode=False, diff=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 09:31:46.647267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json_utils import jsonify
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:31:56.066474
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:32:10.163326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:32:19.220179
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:32:20.296027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:21.245604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:33.833098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import merge_hash

# Generated at 2022-06-17 09:32:44.514602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    import ansible.constants as C
    import json

    class TestCallbackModule(CallbackBase):
        """
        Test callback module
        """
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'


# Generated at 2022-06-17 09:32:54.456100
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test run method of ActionModule
    """
    import unittest
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 09:33:02.511520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service as service
    from ansible.plugins.action.service import ActionModule
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy

# Generated at 2022-06-17 09:33:10.867134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started', 'use': 'auto'}

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module
    module = MockModule

# Generated at 2022-06-17 09:33:18.989688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsModuleArgs
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsModuleResult
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts

# Generated at 2022-06-17 09:33:34.823033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module is not None
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True
    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-17 09:33:46.776230
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:54.176969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock action base object
    action_base_obj = MockActionBase()
    # Create a mock action base object
    action_base_obj = MockActionBase()
    # Create a mock task object
    task_obj = MockTask()
    # Create a mock task object
    task_obj = MockTask()
    # Create a mock task object
    task_obj = MockTask()
    # Create a mock task object
    task_obj = MockTask()
    #

# Generated at 2022-06-17 09:33:58.559558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:34:05.923485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    mock_task = type('', (object,), {'args': {'use': 'auto'}})()
    # Create a mock connection
    mock_connection = type('', (object,), {'_shell': type('', (object,), {'tmpdir': 'tmpdir'})()})()
    # Create a mock shared loader object
    mock_shared_loader_obj = type('', (object,), {'module_loader': type('', (object,), {'has_plugin': lambda x: True, 'find_plugin_with_context': lambda x, y: type('', (object,), {'resolved_fqcn': 'resolved_fqcn'})()})()})()
    # Create a mock display

# Generated at 2022-06-17 09:34:14.897676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock action module
    action_module = MockActionModule()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

# Generated at 2022-06-17 09:34:23.246850
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:34:33.407960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock _templar
    _templar

# Generated at 2022-06-17 09:34:39.214484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:34:47.739746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.async_val = False

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, templar, loader, shared_loader_obj, display)

    # Test run method
    result = action_plugin.run(None, None)

# Generated at 2022-06-17 09:35:21.364133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:33.075619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:35:43.162165
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 09:35:44.397970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:46.124346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:35:56.670970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:36:02.661005
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:36:15.922638
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service
    import ansible.plugins.action.systemd
    import ansible.plugins.action.sysvinit
    import ansible.plugins.action.openwrt_init
    import ansible.plugins.action.setup
    import ansible.plugins.action.ping
    import ansible.plugins.action.copy
    import ansible.plugins.action.raw
    import ansible.plugins.action.script
    import ansible.plugins.action.debug
    import ansible.plugins.action.command
    import ansible.plugins.action.include
    import ansible.plugins.action.include_role
    import ansible.plugins.action.include_tasks
    import ansible.plugins.action.async_status
    import ansible.plugins.action.wait_for
    import ansible.plugins

# Generated at 2022-06-17 09:36:24.550517
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task and connection
    mock_task = MagicMock()
    mock_connection = MagicMock()
    mock_task.async_val = False
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.module_defaults = {}
    mock_task.collections = []
    mock_task._parent = MagicMock()
    mock_task._parent._play = MagicMock()
    mock_task._parent._play._action_groups = {}

    # Create a mock shared loader object
    mock_shared_loader_obj = MagicMock()
    mock_shared_loader_obj.module_loader = MagicMock()

# Generated at 2022-06-17 09:36:34.938774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.action import ActionBase


# Generated at 2022-06-17 09:37:41.304686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_v

# Generated at 2022-06-17 09:37:52.499376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no parameters
    module = ActionModule()
    module._task.args = {}
    module._task.async_val = False
    module._task.delegate_to = None
    module._task.module_defaults = {}
    module._task.no_log = False
    module._task.notify = []
    module._task.run_once = False
    module._task.tags = []
    module._task.when = []
    module._task._parent = None
    module._task._role = None
    module._task._role_name = None
    module._task._play = None
    module._task._play_context = None
    module._task._play_context.become = False
    module._task._play_context.become_method = None
    module._task._play_context.become

# Generated at 2022-06-17 09:37:58.455434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.included_file import IncludedFile

# Generated at 2022-06-17 09:38:07.012193
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:38:18.315265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:38:20.466550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service as service
    action_module = service.ActionModule(None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:38:21.206799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:38:34.229394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started', 'use': 'auto'}
    task.async_val = False
    task.delegate_to = None

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module context
    module_context = MockModuleContext()



# Generated at 2022-06-17 09:38:48.478683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

# Generated at 2022-06-17 09:38:48.867860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass