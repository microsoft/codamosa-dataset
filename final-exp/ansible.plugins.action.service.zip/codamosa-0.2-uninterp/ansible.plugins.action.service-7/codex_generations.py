

# Generated at 2022-06-17 09:30:37.770270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:30:46.943830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task

    # Create a mock connection
    connection = MockConnection()
    action_module._connection = connection

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    action_module._shared_loader_obj = shared_loader_obj

    # Create a mock display
    display = MockDisplay()
    action_module._display = display

    # Create a mock templar
    templar = MockTemplar()
    action_module._templar = templar

    # Create a mock module loader
    module_loader = MockModuleLoader()
   

# Generated at 2022-06-17 09:30:55.252829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host

# Generated at 2022-06-17 09:30:59.572328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:31:06.925962
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:31:18.647075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action groups

# Generated at 2022-06-17 09:31:32.320504
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:31:34.550291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:31:37.934994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None, None, None, None, None, None, None)
    assert am is not None

# Generated at 2022-06-17 09:31:48.174345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFact
    from ansible.module_utils.facts.system.service_mgr import ServiceMgr
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrInfo
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrService
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrServiceInfo
    from ansible.module_utils.facts.system.service_mgr import ServiceMgr

# Generated at 2022-06-17 09:32:07.443569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:32:18.909518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.delegate_to = 'localhost'

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action
    action = MockAction()

    # Create a mock task_vars

# Generated at 2022-06-17 09:32:23.976405
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:32:34.783846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock action base object
    action_base = MockActionBase()
    # Create a mock module loader object
    module_loader = MockModuleLoader()
    # Create a mock module finder object
    module_finder = MockModuleFinder()
    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()
    # Create a mock module finder object
    module_finder

# Generated at 2022-06-17 09:32:44.767380
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:32:54.636144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = False

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp/test'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

    # Test the run method

# Generated at 2022-06-17 09:32:59.597052
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(
        task=task,
        connection=connection,
        loader=loader,
        display=display,
        templar=templar,
        shared_loader_obj=shared_loader_obj
    )

    # Assert that the instance is created
    assert action_module is not None



# Generated at 2022-06-17 09:33:09.186302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()

# Generated at 2022-06-17 09:33:15.283861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None, None)
    assert am.TRANSFERS_FILES == False
    assert am.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert am.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-17 09:33:22.919720
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:40.498883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:33:51.288251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, shared_loader_obj, display, templar)

    # Check the constructor
    assert action_module._task == task
    assert action_module._connection == connection
    assert action_module._shared_loader_obj == shared_loader_obj
    assert action_module._display == display
    assert action_module._templar == templar


# Generated at 2022-06-17 09:33:58.029527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule(
        task=dict(action=dict(module_name='service', module_args=dict(name='httpd', state='started'))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    # Check if the instance is created successfully
    assert action_module is not None

# Generated at 2022-06-17 09:34:05.795743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:34:14.899036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-17 09:34:23.785134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(name='foo', state='present')
    task.async_val = None
    task.delegate_to = None

    # Create a mock connection
    connection = MockConnection()
    connection._shell = MockShell()
    connection._shell.tmpdir = '/tmp'

    # Create a mock loader
    loader = MockLoader()
    loader.module_loader = MockModuleLoader()
    loader.module_loader.has_plugin = Mock(return_value=True)

    # Create a mock templar
    templar = MockTemplar()
    templar.template = Mock(return_value='auto')

    # Create a mock display
    display = MockDisplay()

    # Create a mock action module

# Generated at 2022-06-17 09:34:33.584190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:34:39.362257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock action_base
    action_base = MockActionBase()
    action_base._shared_loader_obj = shared_loader_obj

    # Create a mock task_v

# Generated at 2022-06-17 09:34:47.830751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = Mock()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.async_val = False
    mock_task.module_defaults = {}
    mock_task._parent = Mock()
    mock_task._parent._play = Mock()
    mock_task._parent._play._action_groups = {}

    # Create a mock connection
    mock_connection = Mock()
    mock_connection._shell = Mock()
    mock_connection._shell.tmpdir = '/tmp/ansible-tmp-1576288722.7-290862409845863'

    # Create a mock shared loader object
    mock_shared_loader_obj = Mock()
    mock_shared_loader_obj.module_loader

# Generated at 2022-06-17 09:34:48.779790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:35:33.034162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 09:35:43.130023
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:54.665272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock play
    play = MockPlay()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock play_context
    play_context = MockPlayContext()
    # Create a mock play_context


# Generated at 2022-06-17 09:35:56.829123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:35:58.534033
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:36:05.727819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(host='localhost', port=22, user='test', password='test'),
        play_context=dict(remote_addr='localhost', port=22, remote_user='test', password='test'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 09:36:06.953525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:36:17.317977
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:36:25.349594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service as service
    import ansible.plugins.action.setup as setup
    import ansible.plugins.action.systemd as systemd
    import ansible.plugins.action.sysvinit as sysvinit
    import ansible.plugins.action.openwrt_init as openwrt_init
    import ansible.plugins.action.service_common as service_common
    import ansible.plugins.action.service_legacy as service_legacy
    import ansible.plugins.action.service_systemd as service_systemd
    import ansible.plugins.action.service_sysvinit as service_sysvinit
    import ansible.plugins.action.service_openwrt_init as service_openwrt_init
    import ansible.plugins.action.service_windows as service_windows
    import ans

# Generated at 2022-06-17 09:36:29.639105
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module._supports_check_mode
    assert action_module._supports_async
    assert action_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert action_module.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 09:37:33.894008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:37:41.745879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = Mock()

    # Create a mock shared loader object
    mock_shared_loader_obj = Mock()

    # Create a mock display
    mock_display = Mock()

    # Create a mock templar
    mock_templar = Mock()

    # Create a mock connection
    mock_connection = Mock()

    # Create a mock shell
    mock_shell = Mock()

    # Set the shell's tmpdir attribute
    mock_shell.tmpdir = '/tmp'

    # Set the connection's shell attribute
    mock_connection._shell = mock_shell

    # Create a mock module loader
    mock_module_loader = Mock()

    # Set the shared loader object's module loader attribute
    mock_shared_loader_obj.module_loader = mock_module_loader

    # Create a mock module context


# Generated at 2022-06-17 09:37:52.518746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    from ansible.module_utils.common.json_utils import AnsibleJSONDecoder
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 09:37:56.924487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:38:06.561541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.async_val = False
    task.delegate_to = None

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, templar, display, shared_loader_obj)

    # Test the run method
    action_module.run()

    # Assert the results

# Generated at 2022-06-17 09:38:18.100235
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:38:18.591862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:38:20.976132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:38:34.167194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_

# Generated at 2022-06-17 09:38:48.480213
# Unit test for constructor of class ActionModule