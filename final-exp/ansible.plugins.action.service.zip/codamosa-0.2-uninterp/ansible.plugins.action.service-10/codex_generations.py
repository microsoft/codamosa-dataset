

# Generated at 2022-06-17 09:30:43.698355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:30:44.224195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:30:53.306312
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.delegate_to = None
    task.async_val = False

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock action groups
    action_groups = MockActionGroups()

    # Create a mock module defaults
    module_defaults = MockModuleDefaults()

    #

# Generated at 2022-06-17 09:30:59.756898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

# Generated at 2022-06-17 09:31:07.021728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock connection object
    connection = MockConnection()
    # Create a mock loader object
    loader = MockLoader()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock display object
    display = MockDisplay()
    # Create a mock action module object
    action_module = ActionModule(task, connection, loader, templar, display)
    # Create a mock module object
    module = MockModule()
    # Create a mock task_vars object
    task_vars = MockTaskVars()
    # Create a mock module_defaults object
    module_defaults = MockModuleDefaults()
    # Create a

# Generated at 2022-06-17 09:31:18.802494
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:31:32.357208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.async_val = None
    task.delegate_to = None

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

    # Test run method

# Generated at 2022-06-17 09:31:45.603068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.async_val = False
    task.args = {'name': 'foo', 'state': 'started'}
    task.delegate_to = None
    task.module_defaults = {}
    task.collections = []

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp/'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action
    action = MockAction()

    #

# Generated at 2022-06-17 09:31:54.511447
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:32:02.093339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 09:32:19.215150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task and task_vars
    task = dict(
        args = dict(
            use = 'auto',
        )
    )
    task_vars = dict()

    # Create a mock loader
    loader = dict(
        module_loader = dict(
            has_plugin = lambda x: True,
        )
    )

    # Create a mock shared loader object
    shared_loader_obj = dict(
        module_loader = dict(
            find_plugin_with_context = lambda x, y: dict(
                resolved_fqcn = 'ansible.legacy.service',
            )
        )
    )

    # Create a mock display
    display = dict(
        vvvv = lambda x: None,
        debug = lambda x: None,
        warning = lambda x: None,
    )



# Generated at 2022-06-17 09:32:32.937596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.init import Inventory
    from ansible.vars.init import VariableManager

# Generated at 2022-06-17 09:32:43.508661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module context
    module_context = MockModuleContext()

    # Create a mock module
    module = MockModule()

    # Create a mock facts
    facts = Mock

# Generated at 2022-06-17 09:32:54.075998
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:02.356096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:33:05.883940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test')),
        connection=dict(host='localhost'),
        play_context=dict(become=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-17 09:33:06.453556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:33:07.026861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:33:10.392481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:33:18.807444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock async

# Generated at 2022-06-17 09:33:40.362022
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:51.176360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:33:52.475661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:33:53.078795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:34:03.617373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service as service
    import ansible.plugins.action.setup as setup
    import ansible.plugins.action.systemd as systemd
    import ansible.plugins.action.sysvinit as sysvinit
    import ansible.plugins.action.openwrt_init as openwrt_init
    import ansible.plugins.action.service as service
    import ansible.plugins.loader as loader
    import ansible.plugins.loader.module_utils as module_utils
    import ansible.plugins.loader.module_utils.service as service_utils
    import ansible.plugins.loader.module_utils.systemd as systemd_utils
    import ansible.plugins.loader.module_utils.sysvinit as sysvinit_utils
    import ansible.plugins.loader.module_utils.openwrt_init

# Generated at 2022-06-17 09:34:12.102848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.delegate_to = None
    task.async_val = None

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock loader object
    loader_obj = MockLoaderObj()

    # Create a mock display object
    display_obj = MockDisplay()

    # Create a mock templar object
    templar_obj = MockTemplar()

    # Create a mock module loader object
    module_loader_obj = MockModuleLoaderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()

    # Create

# Generated at 2022-06-17 09:34:19.942814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = 42

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module
    module = MockModule()

    # Create a mock module

# Generated at 2022-06-17 09:34:25.222745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.block import Block
   

# Generated at 2022-06-17 09:34:27.168627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:34:34.565857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine

# Generated at 2022-06-17 09:35:08.972539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:35:10.839512
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:35:21.528255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:35:31.948124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = MockTask()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an action module object
    action_module = ActionModule(task, connection, loader, display, templar, shared_loader_obj)

    # Test the run method
    action_module.run(tmp=None, task_vars=None)



# Generated at 2022-06-17 09:35:39.969572
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.delegate_to = 'localhost'

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock shared_

# Generated at 2022-06-17 09:35:41.889905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a test object
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 09:35:50.785800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = 0
    task.delegate_to = None
    task.module_defaults = {}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, shared_loader_obj, display, templar)

    # Create a mock module
    module = MockModule()

   

# Generated at 2022-06-17 09:35:54.179450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:54.713714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:36:00.384758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._task = MagicMock()
    action_module._task.args = {'use': 'auto'}
    action_module._task.async_val = False
    action_module._task.delegate_to = None
    action_module._task.module_defaults = None
    action_module._task._parent = MagicMock()
    action_module._task._parent._play = MagicMock()
    action_module._task._parent._play._action_groups = None
    action_module._templar = MagicMock()
    action_module._templar.template = MagicMock(return_value='auto')

# Generated at 2022-06-17 09:36:56.261975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(name='test', state='present')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:37:06.943418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.async_val = 42

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock action groups
    action_groups = MockActionGroups()

    # Create a mock module defaults
    module_defaults = MockModuleDefaults()

    # Create a mock task_vars
    task

# Generated at 2022-06-17 09:37:18.563928
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:32.906865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock play
   

# Generated at 2022-06-17 09:37:38.444399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module
    module = MockModule()

    # Create a mock module args
    module_args = MockModule

# Generated at 2022-06-17 09:37:52.190799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service as service
    import ansible.plugins.loader as loader
    import ansible.plugins.connection.local as local
    import ansible.plugins.connection.ssh as ssh
    import ansible.plugins.connection.winrm as winrm
    import ansible.plugins.connection.network_cli as network_cli
    import ansible.plugins.connection.httpapi as httpapi
    import ansible.plugins.connection.docker as docker
    import ansible.plugins.connection.paramiko_ssh as paramiko_ssh
    import ansible.plugins.connection.local as local
    import ansible.plugins.connection.chroot as chroot
    import ansible.plugins.connection.jail as jail
    import ansible.plugins.connection.lxd as lxd
    import ansible.plugins.connection.lxc as l

# Generated at 2022-06-17 09:38:03.826665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module context
    module_context = MockModuleContext()

    # Create a mock module
    module = MockModule()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock module args
    module_args = MockModuleArgs()

    # Create a mock module defaults
    module_defaults = MockModuleDefaults()

    # Create a mock

# Generated at 2022-06-17 09:38:14.323827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:38:17.405577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:38:20.598874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass