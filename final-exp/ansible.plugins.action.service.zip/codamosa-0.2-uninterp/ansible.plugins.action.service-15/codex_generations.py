

# Generated at 2022-06-17 09:30:38.195115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_

# Generated at 2022-06-17 09:30:47.977010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action base
    action_base = MockActionBase()
    # Create a mock module
    module = MockModule()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module context
    module_context = MockModuleContext()
    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock action module
    action_

# Generated at 2022-06-17 09:30:55.545092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a ActionModule object
    action_module = ActionModule()

    # Create a task object
    task = dict(
        action=dict(
            module_name='service',
            module_args=dict(
                name='httpd',
                state='started',
                enabled=True
            )
        )
    )

    # Create a task_vars object
    task_vars = dict()

    # Call method run of ActionModule
    result = action_module.run(task_vars=task_vars, task=task)

    # AssertionError: 'module' not in result
    assert 'module' in result

    # AssertionError: 'service' not in result['module']
    assert 'service' in result['module']

    # AssertionError: 'name' not in result['module']['

# Generated at 2022-06-17 09:31:07.523681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser

    loader = DataLoader()
    variable

# Generated at 2022-06-17 09:31:19.512676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task
    task = type('Task', (object,), {'args': {'use': 'auto'}, 'delegate_to': None, 'async_val': None, '_parent': type('Play', (object,), {'_action_groups': {}})})()

    # Create a fake connection
    connection = type('Connection', (object,), {'_shell': type('Shell', (object,), {'tmpdir': None})})()

    # Create a fake loader
    loader = type('Loader', (object,), {'module_loader': type('ModuleLoader', (object,), {'has_plugin': lambda x: True})})()

    # Create a fake display

# Generated at 2022-06-17 09:31:32.767996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

# Generated at 2022-06-17 09:31:34.345012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:31:40.017284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:31:49.713181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:31:59.601457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play
    play = MockPlay()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock options
    options = MockOptions()
    # Create a mock inventory
    inventory = MockInventory()
    # Create a mock variable manager
    variable_manager = MockVariableManager()

# Generated at 2022-06-17 09:32:16.364415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:32:16.871430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:24.693844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_v

# Generated at 2022-06-17 09:32:26.883967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:32:35.625514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('MockTask', (object,), {
        'args': {
            'use': 'auto',
            'name': 'foo',
            'state': 'started',
        },
        'async_val': 0,
        'delegate_to': '',
        'module_defaults': {},
        '_parent': type('MockPlay', (object,), {
            '_action_groups': {},
        }),
    })()

    # Create a mock loader

# Generated at 2022-06-17 09:32:41.879552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test', state='present')),
        connection=dict(host='localhost', port=22, user='test', password='test'),
        play_context=dict(remote_addr='localhost', port=22, remote_user='test', password='test'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 09:32:43.701847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:32:54.250725
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:32:58.645028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid task
    task = dict(
        action=dict(
            module='service',
            args=dict(
                name='httpd',
                state='started',
                enabled='yes'
            )
        )
    )
    action_module = ActionModule(task, dict())
    assert action_module is not None

    # Test with a invalid task
    task = dict(
        action=dict(
            module='service',
            args=dict(
                name='httpd',
                state='started',
                enabled='yes'
            )
        )
    )
    action_module = ActionModule(task, dict())
    assert action_module is not None

# Generated at 2022-06-17 09:33:04.485825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('', (), {})()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.async_val = False

    # Create a mock templar
    mock_templar = type('', (), {})()
    mock_templar.template = lambda x: 'auto'

    # Create a mock display
    mock_display = type('', (), {})()
    mock_display.debug = lambda x: None
    mock_display.warning = lambda x: None
    mock_display.vvvv = lambda x: None

    # Create a mock connection
    mock_connection = type('', (), {})()
    mock_connection._shell = type('', (), {})()

# Generated at 2022-06-17 09:33:31.231596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess
    from ansible.executor.stats import AggregateStats
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-17 09:33:40.219503
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module
    module = MockModule()

    # Create a mock module_utils
    module_utils = MockModule

# Generated at 2022-06-17 09:33:51.061741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = False

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp/test'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

    # Test the run method

# Generated at 2022-06-17 09:34:01.971126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:34:03.035622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:34:03.796098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:34:12.258878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest
    import ansible.plugins.action.service as service

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self.action = service.ActionModule()
            self.action._shared_loader_obj = None
            self.action._task = None
            self.action._connection = None
            self.action._play_context = None
            self.action._loader = None
            self.action._templar = None
            self.action._task_vars = None
            self.action._tmp = None
            self.action._display = None
            self.action._supports_check_mode = None
            self.action._supports_async = None
            self.action._task

# Generated at 2022-06-17 09:34:13.303119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:34:13.840301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:34:18.109282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:34:58.167906
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:08.767216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up test
    test_host = 'testhost'
    test_task = dict(
        action=dict(
            module='service',
            args=dict(
                name='foo',
                state='started',
                use='auto'
            )
        ),
        delegate_to=test_host
    )
    test_task_vars = dict(
        ansible_facts=dict(
            service_mgr='auto'
        ),
        hostvars=dict(
            testhost=dict(
                ansible_facts=dict(
                    service_mgr='auto'
                )
            )
        )
    )

    # run test

# Generated at 2022-06-17 09:35:10.673801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:35:20.468912
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:32.961704
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:43.056289
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:51.128917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.utils import dict_diff
    from ansible.module_utils.network.common.utils import get_module
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.utils import load_params
    from ansible.module_utils.network.common.utils import validate_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional

# Generated at 2022-06-17 09:36:01.804158
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = 42
    task.delegate_to = 'localhost'

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp/ansible-tmp-12345'

    # Create a mock loader
    loader = MockLoader()
    loader.module_loader.has_plugin.return_value = True

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader.module_loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()
    templar

# Generated at 2022-06-17 09:36:09.213668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
   

# Generated at 2022-06-17 09:36:10.300900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    assert True

# Generated at 2022-06-17 09:37:10.631063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:37:20.193242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {
        'name': 'httpd',
        'state': 'started',
        'use': 'auto',
    }

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock action_base
    action_base = MockActionBase()
    action_base._shared_loader_obj

# Generated at 2022-06-17 09:37:33.303279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.remote_addr = 'localhost'


# Generated at 2022-06-17 09:37:38.710318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.async_val = False
    task.delegate_to = None
    task.module_defaults = {}
    task.collections = []

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock facts
    facts = MockFacts()

    # Create a mock module
   

# Generated at 2022-06-17 09:37:46.464061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                use='auto',
            ),
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )
    assert action_module

# Generated at 2022-06-17 09:37:55.859813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service
    import ansible.plugins.action.systemd
    import ansible.plugins.action.sysvinit
    import ansible.plugins.action.openwrt_init
    import ansible.plugins.action.setup
    import ansible.plugins.action.copy
    import ansible.plugins.action.file
    import ansible.plugins.action.lineinfile
    import ansible.plugins.action.template
    import ansible.plugins.action.unarchive
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_file
    import ansible.plugins.action.win_lineinfile
    import ansible.plugins.action.win_template
    import ansible.plugins.action.win_unzip
    import ansible.plugins.action.win_

# Generated at 2022-06-17 09:38:06.528672
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files

# Generated at 2022-06-17 09:38:18.102528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-17 09:38:26.901441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:38:36.136580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task_vars
    task_vars = {}

    # Create a mock action base