

# Generated at 2022-06-17 09:30:46.737948
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:30:55.144737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object
    mock_task = type('', (), {})()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.async_val = None

    # Create a mock object
    mock_shared_loader_obj = type('', (), {})()
    mock_shared_loader_obj.module_loader = type('', (), {})()
    mock_shared_loader_obj.module_loader.has_plugin = lambda x: True

    # Create a mock object
    mock_templar = type('', (), {})()
    mock_templar.template = lambda x: 'ansible_service_mgr'

    # Create a mock object
    mock_display = type('', (), {})()

# Generated at 2022-06-17 09:31:00.540680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:31:02.728056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:31:04.826093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:31:16.099053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import get_vars

# Generated at 2022-06-17 09:31:21.885074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert am.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-17 09:31:32.305574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:31:45.603471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

# Generated at 2022-06-17 09:31:54.576382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    mock_task.args = {'name': 'foo', 'state': 'started', 'use': 'auto'}

    # Create a mock connection
    mock_connection = MockConnection()
    mock_connection._shell = MockShell()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader object
    mock_module_loader_obj = MockModuleLoaderObj()

    # Create a mock module finder object
    mock_module_finder_obj = MockModuleFinderObj()

    # Create a mock module context object
    mock_module_context_obj = MockModuleContextObj()

    # Create a mock module object
    mock_module_obj = MockModuleObj()

    # Create a mock task object
   

# Generated at 2022-06-17 09:32:13.073431
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    mock_task.args = {'name': 'foo', 'state': 'started', 'use': 'auto'}

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock module loader
    mock_module_loader = MockModuleLoader()

    # Create a mock shared loader obj
    mock_shared_loader_obj = MockSharedLoaderObj()
    mock_shared_loader_obj.module_loader = mock_module_loader

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock action base
    mock_action_base = MockActionBase()

    # Create a mock task vars

# Generated at 2022-06-17 09:32:20.581044
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:32:33.545712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = type('MockTask', (object,), {'args': {'use': 'auto'}})()
    # Create a mock connection
    connection = type('MockConnection', (object,), {'_shell': type('MockShell', (object,), {'tmpdir': 'tmpdir'})()})()
    # Create a mock loader
    loader = type('MockLoader', (object,), {'module_loader': type('MockModuleLoader', (object,), {'has_plugin': lambda x: True})()})()
    # Create a mock display
    display = type('MockDisplay', (object,), {'warning': lambda x: None, 'debug': lambda x: None, 'vvvv': lambda x: None})()
    # Create a mock templar
    templar = type

# Generated at 2022-06-17 09:32:42.934420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no argument
    module = ActionModule()
    module._task.args = {}
    module._task.delegate_to = None
    module._task.async_val = False
    module._task.module_defaults = {}
    module._task._parent._play._action_groups = {}
    module._task.collections = []
    module._shared_loader_obj.module_loader.has_plugin = lambda x: True
    module._shared_loader_obj.module_loader.find_plugin_with_context = lambda x, y: None
    module._execute_module = lambda x, y, z, w: {}
    module._remove_tmp_path = lambda x: None
    module._display.warning = lambda x: None
    module._display.debug = lambda x: None

# Generated at 2022-06-17 09:32:44.691349
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:32:54.599223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.async_val = 0
    task.delegate_to = None

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action plugin object
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader object
    module_loader = MockModuleLoader()

    # Create a mock context object
    context = MockContext()

   

# Generated at 2022-06-17 09:33:02.581472
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:10.908337
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:19.015471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 09:33:31.377080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.delegate_to = 'localhost'
    task.async_val = False

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, display, templar, shared_loader_obj, action_base)

   

# Generated at 2022-06-17 09:33:45.250939
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a test object
    am = ActionModule()
    # Check if the object is an instance of the class ActionModule
    assert isinstance(am, ActionModule)

# Generated at 2022-06-17 09:33:53.998892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.init import Inventory
    from ansible.vars.init import VariableManager
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 09:34:00.873432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = MockTask()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock loader object
    loader = MockLoader()

    # Create an instance of the ActionModule class
    action_module = ActionModule(task, connection, templar, loader, display, shared_loader_obj)

    # Check if the instance is an instance of the ActionModule class
    assert isinstance(action_module, ActionModule)

    # Check if the instance has the correct attributes
    assert action_module._task == task

# Generated at 2022-06-17 09:34:11.716250
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:34:14.331842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:34:17.016218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:34:26.838864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:34:34.807007
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:34:41.436464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service as service
    import ansible.plugins.loader as loader
    import ansible.playbook.task as task
    import ansible.playbook.play as play
    import ansible.playbook.play_context as play_context
    import ansible.executor.task_result as task_result
    import ansible.executor.task_queue_manager as task_queue_manager
    import ansible.executor.playbook_executor as playbook_executor
    import ansible.executor.module_common as module_common
    import ansible.utils.display as display
    import ansible.utils.plugin_docs as plugin_docs
    import ansible.utils.vars as vars
    import ansible.template as template
    import ansible.inventory.host as host

# Generated at 2022-06-17 09:34:44.790029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:35:25.281480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock action_base
    action_base = MockActionBase()
    action_base._shared_loader_obj = shared_loader_obj

    # Create a mock action_module

# Generated at 2022-06-17 09:35:33.930372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:35:43.727148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj(loader)

    # Create a mock connection
    connection = MockConnection()

    # Create a mock action plugin
    action_plugin = MockActionPlugin(connection, shared_loader_obj, templar, display)

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock module_default

# Generated at 2022-06-17 09:35:51.165325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:35:55.236244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and action module
    task = MockTask()
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock result
    result = action_module.run(tmp=None, task_vars=None)

    # Assert that the result is not none
    assert result is not None

# Generated at 2022-06-17 09:35:56.941439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:35:58.533006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:59.106842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:36:08.930930
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:36:19.118311
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:15.801301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:37:16.361950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:37:18.923575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:37:30.892262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    module = ActionModule(task=dict(action=dict(module='service', args=dict())))
    result = module.run(task_vars=dict())
    assert result.get('failed') is False
    assert result.get('changed') is False

    # Test with args
    module = ActionModule(task=dict(action=dict(module='service', args=dict(name='foo', state='started'))))
    result = module.run(task_vars=dict())
    assert result.get('failed') is False
    assert result.get('changed') is False

# Generated at 2022-06-17 09:37:33.679731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:37:35.596991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service
    action_module = ansible.plugins.action.service.ActionModule(None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:37:42.503924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a test object of class ActionModule
    test_obj = ActionModule()
    # Create a test task
    test_task = {
        'args': {
            'use': 'auto'
        }
    }
    # Create a test task_vars
    test_task_vars = {
        'ansible_facts': {
            'service_mgr': 'auto'
        }
    }
    # Create a test result
    test_result = {
        'ansible_facts': {
            'service_mgr': 'auto'
        }
    }
    # Call the method run of class ActionModule
    result = test_obj.run(task_vars=test_task_vars)
    # Assert the result
    assert result == test_result

# Generated at 2022-06-17 09:37:52.686380
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:38:03.978054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 09:38:05.104563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(args=dict(name='test', state='present')))

# Generated at 2022-06-17 09:40:27.107471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock options
    options = MockOptions()
    # Create a mock inventory
    inventory = MockInventory()
    # Create a mock variable manager

# Generated at 2022-06-17 09:40:31.109756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module