

# Generated at 2022-06-17 09:30:38.054068
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:30:44.218850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present', use='auto')),
        connection=dict(host='localhost', port=22, user='root', password='password'),
        play_context=dict(check_mode=True, remote_addr='localhost', port=22, remote_user='root', password='password'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 09:30:45.400304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module is not None

# Generated at 2022-06-17 09:30:54.187096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(name='foo', state='started')

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task
    action_module._connection = MockConnection()
    action_module._shared_loader_obj = MockSharedLoaderObj()
    action_module._templar = MockTemplar()
    action_module._display = MockDisplay()

    # Create a mock module loader
    module_loader = MockModuleLoader()
    module_loader.has_plugin = Mock(return_value=True)
    action_module._shared_loader_obj.module_loader = module_loader

    # Create a mock module context
    module_context = MockModuleContext()

# Generated at 2022-06-17 09:31:04.480404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.service import ActionModule
    from ansible.plugins.action.systemd import ActionModule as ActionModuleSystemd

# Generated at 2022-06-17 09:31:05.195534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:31:07.263665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:31:07.773405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:31:14.770407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock module default
    module_default = MockModuleDefault()
    # Create a mock action group
    action_group = MockActionGroup()
    # Create a mock play
    play = MockPlay()
    # Create a mock play context
    play_

# Generated at 2022-06-17 09:31:24.564544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock play
    play = MockPlay()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock play_context
    play_context = MockPlayContext()
    # Create a mock options
    options = MockOptions()
    # Create a mock inventory
    inventory = MockInventory

# Generated at 2022-06-17 09:31:39.568375
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:31:43.952790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present', use='auto')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:31:44.575714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:31:53.643052
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:32:01.870711
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:32:08.388036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='service', module_args=dict(name='foo', state='started'))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:32:11.990697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module is not None

    # Test with arguments
    action_module = ActionModule(None, None, task_vars=None, wrap_async=None)
    assert action_module is not None

# Generated at 2022-06-17 09:32:14.275680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:32:15.038921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-17 09:32:22.057083
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:32:44.767443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle as pickle
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip

    # Create a mock task
    task_args = dict(
        name='foo',
        state='present',
        use='auto',
    )
    task_vars = dict(
        ansible_facts=dict(
            service_mgr='auto',
        ),
    )
    task_action = 'service'
    task_delegate_

# Generated at 2022-06-17 09:32:54.636280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_v

# Generated at 2022-06-17 09:32:56.557119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:33:08.705615
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:18.418469
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:31.281667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json_utils import jsonify
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 09:33:35.141162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:33:41.451611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started', 'use': 'auto'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, loader, display, templar, action_plugin, shared_loader_obj)

    # Call method run of class ActionModule
    action_module.run

# Generated at 2022-06-17 09:33:47.888583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:33:59.969745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = Mock()
    mock_task.args = dict()
    mock_task.args['use'] = 'auto'
    mock_task.async_val = False
    mock_task.delegate_to = None

    # Create a mock module loader
    mock_module_loader = Mock()
    mock_module_loader.has_plugin.return_value = True

    # Create a mock shared loader object
    mock_shared_loader_obj = Mock()
    mock_shared_loader_obj.module_loader = mock_module_loader

    # Create a mock templar
    mock_templar = Mock()
    mock_templar.template.return_value = 'auto'

    # Create a mock display
    mock_display = Mock()

    # Create a mock connection
    mock_

# Generated at 2022-06-17 09:34:26.601685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:34:34.413900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 09:34:36.322594
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-17 09:34:45.475911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock action_base
    action_base = MockActionBase()

    #

# Generated at 2022-06-17 09:34:48.141916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:34:57.404482
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:34:57.949005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:03.589971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:35:04.381787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:13.709379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, loader, display, templar, action_plugin, shared_loader_obj)

    # Call method run of class ActionModule
    result = action_module.run()

   

# Generated at 2022-06-17 09:36:05.385361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:36:16.520896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'auto'}
    task.async_val = False
    task.delegate_to = None
    task.module_defaults = {}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock action

# Generated at 2022-06-17 09:36:24.889246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock action base object
    action_base_obj = MockActionBase()
    # Create a mock action module object
    action_module_obj = ActionModule(task, connection, templar, task_vars, loader, display, shared_loader_obj, action_base_obj)
    # Create a mock result
   

# Generated at 2022-06-17 09:36:36.278271
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:36:46.586915
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:36:59.389440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:37:09.289434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    import ansible.utils.module_docs as module_docs
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 09:37:19.446644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd'}
    task.delegate_to = 'localhost'
    task.async_val = None

    # Create a mock connection
    connection = MockConnection()
    connection._shell = MockShell()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

    # Create a mock module
   

# Generated at 2022-06-17 09:37:33.135413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['service_mgr'] = 'auto'
    task_vars['ansible_facts']['ansible_service_mgr'] = 'auto'
    task_vars['ansible_facts']['ansible_service_mgrs'] = ['auto']
    task_vars['ansible_facts']['ansible_service_mgrs'] = ['auto']
    task_vars['ansible_facts']['ansible_service_mgrs'] = ['auto']
    task_vars['ansible_facts']['ansible_service_mgrs'] = ['auto']

# Generated at 2022-06-17 09:37:33.897814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:39:38.704322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_duplicate

# Generated at 2022-06-17 09:39:43.587313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    module = ActionModule()
    assert module.TRANSFERS_FILES is False
    assert module.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-17 09:39:52.909040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.reserved import Reserved
    from ansible.plugins.loader import action_loader
    from ansible.playbook.block import Block

# Generated at 2022-06-17 09:40:00.934913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:40:01.993467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-17 09:40:13.268165
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:40:20.083387
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group