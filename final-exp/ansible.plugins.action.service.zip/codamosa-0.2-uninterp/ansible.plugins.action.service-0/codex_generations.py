

# Generated at 2022-06-17 09:30:46.686512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, display, templar, shared_loader_obj, action_base)

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock result
    result = dict()

    # Create a mock tmp
    tmp = None

# Generated at 2022-06-17 09:30:49.181850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:30:58.404474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action groups
    action_groups = MockActionGroups()

    # Create a mock task parent
   

# Generated at 2022-06-17 09:31:00.870497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:31:09.782881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started', 'use': 'auto'}
    task.async_val = False
    task.delegate_to = None

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module context
    module_context = MockModuleContext()



# Generated at 2022-06-17 09:31:12.607902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:31:23.938917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:31:25.383056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-17 09:31:36.333049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module
    module = MockModule()

    # Create a mock facts
    facts = MockFacts()

    # Create a mock module args
    module_args = MockModuleArgs()

    # Create a mock action groups
    action_groups = MockActionGroups()

    # Create a mock task vars
    task_vars = Mock

# Generated at 2022-06-17 09:31:47.322838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:31:54.893338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-17 09:32:02.185867
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:32:07.314112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='httpd', state='started')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:32:18.909157
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 09:32:32.855146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service as service
    import ansible.plugins.action.setup as setup
    import ansible.plugins.action.systemd as systemd
    import ansible.plugins.action.sysvinit as sysvinit
    import ansible.plugins.action.openwrt_init as openwrt_init
    import ansible.plugins.action.service as service
    import ansible.plugins.action.systemd as systemd
    import ansible.plugins.action.sysvinit as sysvinit
    import ansible.plugins.action.openwrt_init as openwrt_init
    import ansible.plugins.loader as loader
    import ansible.plugins.loader as loader
    import ansible.plugins.loader as loader
    import ansible.plugins.loader as loader
    import ansible.plugins.loader as loader
   

# Generated at 2022-06-17 09:32:42.906840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock context
    context = MockContext()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock task_vars
    task_vars = MockTaskVars()

   

# Generated at 2022-06-17 09:32:53.894019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of AnsibleActionFail
    ansible_action_fail = AnsibleActionFail()

    # Create an instance of AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of AnsibleActionFail
    ansible_action_fail = AnsibleAction

# Generated at 2022-06-17 09:33:02.701228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a task
    task = dict(
        action=dict(
            module='service',
            args=dict(
                name='httpd',
                state='started',
                enabled='yes',
                use='auto'
            )
        )
    )
    # Create a task_vars
    task_vars = dict()
    # Create a tmp
    tmp = dict()
    # Create a play_context
    play_context = dict()
    # Create a loader
    loader = dict()
    # Create a templar
    templar = dict()
    # Create a shared_loader_obj
    shared_loader_obj = dict()
    # Create a connection
    connection = dict()
    # Create a _play_context
    _play_context = dict()
    # Create a _task

# Generated at 2022-06-17 09:33:11.033866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('', (), {})()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.async_val = False

    # Create a mock connection
    mock_connection = type('', (), {})()
    mock_connection._shell = type('', (), {})()
    mock_connection._shell.tmpdir = '/tmp'

    # Create a mock shared loader object
    mock_shared_loader_obj = type('', (), {})()
    mock_shared_loader_obj.module_loader = type('', (), {})()
    mock_shared_loader_obj.module_loader.has_plugin = lambda x: True

    # Create a mock templar object

# Generated at 2022-06-17 09:33:19.144281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock action_plugin
    action_plugin = MockActionPlugin()

    # Create a mock task_vars

# Generated at 2022-06-17 09:33:33.350250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:33:43.801209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.delegate_to = 'localhost'
    task.async_val = 0

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, shared_loader_obj, display, templar)

    # Create a mock result
    result = MockResult()

    # Create a mock task vars

# Generated at 2022-06-17 09:33:46.826968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement
    pass

# Generated at 2022-06-17 09:33:54.209005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('', (), {})()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.async_val = None

    # Create a mock connection
    mock_connection = type('', (), {})()
    mock_connection._shell = type('', (), {})()
    mock_connection._shell.tmpdir = 'tmpdir'

    # Create a mock loader
    mock_loader = type('', (), {})()
    mock_loader.module_loader = type('', (), {})()
    mock_loader.module_loader.has_plugin = lambda x: True

    # Create a mock display
    mock_display = type('', (), {})()
    mock_display.debug = lambda x: None
    mock

# Generated at 2022-06-17 09:34:04.862990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service
    import ansible.plugins.action.systemd
    import ansible.plugins.action.sysvinit
    import ansible.plugins.action.openwrt_init
    import ansible.plugins.action.setup
    import ansible.plugins.action.raw
    import ansible.plugins.action.copy
    import ansible.plugins.action.file
    import ansible.plugins.action.lineinfile
    import ansible.plugins.action.template
    import ansible.plugins.action.win_copy
    import ansible.plugins.action.win_file
    import ansible.plugins.action.win_lineinfile
    import ansible.plugins.action.win_template
    import ansible.plugins.action.win_updates
    import ansible.plugins.action.win_wait

# Generated at 2022-06-17 09:34:09.907567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:34:18.257928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create an instance of AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of AnsibleTask
    ansible_task = AnsibleTask()
    # Create an instance of AnsiblePlay
    ansible_play = AnsiblePlay()
    # Create an instance of AnsiblePlaybook
    ansible_playbook = AnsiblePlaybook()
    # Create an instance of AnsibleRunner
    ansible_runner = AnsibleRunner()
    # Create an instance of AnsibleRunnerConfig
    ansible_runner_config = AnsibleRunnerConfig()
    # Create an instance of AnsibleOptions
    ansible_options = AnsibleOptions()
    # Create an instance of AnsibleCLI
    ansible_cli = AnsibleCLI()
    # Create an

# Generated at 2022-06-17 09:34:20.624232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:34:32.429937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.plugins.loader import action_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.init import Inventory

# Generated at 2022-06-17 09:34:39.401729
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:14.653518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service
    action_module = ansible.plugins.action.service.ActionModule(None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 09:35:23.965229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import unittest
    import tempfile
    import shutil
    import json
    import ansible.plugins.action.service as service
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

# Generated at 2022-06-17 09:35:33.795596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:35:34.598600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:43.467150
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:54.738707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module context
    module_context = MockModuleContext()
    # Create a mock module
    module = MockModule()
    # Create a mock module args
    module_args = MockModuleArgs()
    # Create a mock module defaults
    module_defaults = MockModuleDefaults()
    # Create a mock

# Generated at 2022-06-17 09:35:56.312375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:36:08.178157
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:36:10.520724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:36:19.074785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock action base
    action_base = ActionBase(task, connection, shared_loader_obj, display, templar, loader, action_plugin)

    # Create an instance of class ActionModule
    action_module = ActionModule(task, connection, shared_loader_obj, display, templar, loader, action_plugin)

    #

# Generated at 2022-06-17 09:37:12.987972
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:37:15.405342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:37:22.201796
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:25.900240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:37:35.445615
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:39.419570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:37:52.818135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:38:04.200259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task with a mock action
    mock_task = Mock()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_action = Mock()
    mock_action.run = Mock(return_value={'ansible_facts': {'service_mgr': 'auto'}})
    mock_action._execute_module = Mock(return_value={'ansible_facts': {'service_mgr': 'auto'}})
    mock_action._task = mock_task
    mock_action._templar = Mock()
    mock_action._templar.template = Mock(return_value='auto')
    mock_action._shared_loader_obj = Mock()
    mock_action._shared_loader_obj.module_loader = Mock()
    mock_

# Generated at 2022-06-17 09:38:09.714243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:38:20.637216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_v

# Generated at 2022-06-17 09:40:30.019029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MockTask()
    mock_task.args = {'name': 'foo', 'state': 'started'}
    mock_task.delegate_to = 'localhost'

    # Create a mock connection
    mock_connection = MockConnection()

    # Create a mock module loader
    mock_module_loader = MockModuleLoader()

    # Create a mock shared loader object
    mock_shared_loader_obj = MockSharedLoaderObj()
    mock_shared_loader_obj.module_loader = mock_module_loader

    # Create a mock display
    mock_display = MockDisplay()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock action base
    mock_action_base = MockActionBase()

    # Create a mock action module
   