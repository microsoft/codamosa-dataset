

# Generated at 2022-06-17 09:30:46.004426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started', 'use': 'auto'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module context
    module_context = MockModuleContext()

    # Create a mock module
    module = MockModule()

    # Create a mock action

# Generated at 2022-06-17 09:30:49.225320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:30:58.404583
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:31:00.883849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:31:12.614379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFact
    from ansible.module_utils.facts.system.service_mgr import ServiceMgr
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrDistro
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrDistroFamily
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrDistroName

# Generated at 2022-06-17 09:31:18.166470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = None
    task.delegate_to = None
    task.module_defaults = {}

    # Create a mock play
    play = MockPlay()
    play.action_groups = []
    play.action_blocks = []
    play.become = False
    play.become_method = None
    play.become_user = None
    play.deprecated_playbook_variables = {}
    play.handlers = []
    play.hosts = []
    play.name = 'test_play'
    play.roles = []
    play.tags = []
    play.tasks = []
    play.vars = {}

# Generated at 2022-06-17 09:31:22.080680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:31:34.562515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action base
    action_base = ActionBase(task, connection, shared_loader_obj, templar, display)

    # Create a mock action module
    action_module = ActionModule(task, connection, shared_loader_obj, templar, display)

    # Create a mock task vars

# Generated at 2022-06-17 09:31:36.516513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:31:47.508234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block


# Generated at 2022-06-17 09:32:01.897207
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {
        'name': 'foo',
        'state': 'started',
        'use': 'auto'
    }

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = module_loader

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock task_vars
   

# Generated at 2022-06-17 09:32:13.201864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.plugins import get_all_plugin_loaders, get_all_plugins
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.sentinel import Sentinel
    from ansible.plugins.loader import find_plugin_file
   

# Generated at 2022-06-17 09:32:13.702240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:21.071056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action base
    action_base = MockActionBase()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()
    # Create a mock action_groups
    action_groups = MockActionGroups()
    # Create a mock play
    play = MockPlay()
    # Create a

# Generated at 2022-06-17 09:32:33.726171
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:32:35.589516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:45.001109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, shared_loader_obj, display, templar, action_plugin, module_loader, context)

    # Check if the instance is of the type ActionModule

# Generated at 2022-06-17 09:32:50.972000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-17 09:32:52.710541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:33:02.626438
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:23.049219
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:33:31.547023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:33:34.729955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None) is not None

# Generated at 2022-06-17 09:33:41.134914
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:46.528790
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:33:47.975172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:34:00.018735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import mock
    from ansible.plugins.action.service import ActionModule

    if PY3:
        builtin_module_name = 'builtins'
    else:
        builtin_module_name = '__builtin__'


# Generated at 2022-06-17 09:34:07.218691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.delegate_to = 'localhost'

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()
    module_loader.has_plugin = Mock(return_value=True)

    # Create a mock context
    context = MockContext()


# Generated at 2022-06-17 09:34:12.322234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'auto'}
    task.delegate_to = None

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task

    # Create a mock loader object
    loader_obj = MockLoader()
    action_module._shared_loader_obj = loader_obj

    # Create a mock display object
    display_obj = MockDisplay()
    action_module._display = display_obj

    # Create a mock templar object
    templar_obj = MockTemplar()
    action_module._templar = templar_obj

    # Create a mock connection object
    connection_obj = MockConnection()
    action_module._connection = connection_obj

    # Create a mock task_v

# Generated at 2022-06-17 09:34:12.861475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:34:47.764165
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:34:48.665741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:34:57.796905
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:08.428495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock action_groups
    action_groups = dict()

    # Create a mock module_defaults
    module_defaults = dict()

    # Create a mock module_name
   

# Generated at 2022-06-17 09:35:18.413292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.splitter import parse_kv
    from ansible.module_utils.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 09:35:25.847074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:35:34.570904
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:35.249717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:35:44.712942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:35:46.219139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:36:47.706924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:36:55.617856
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:06.447161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task
    task = dict(
        action=dict(
            module='service',
            args=dict(
                name='foo',
                state='started',
                use='auto'
            )
        )
    )
    # Create a fake task_vars
    task_vars = dict()
    # Create a fake loader
    loader = dict()
    # Create a fake display
    display = dict()
    # Create a fake templar
    templar = dict()
    # Create a fake shared_loader_obj
    shared_loader_obj = dict()
    # Create a fake connection
    connection = dict()
    # Create a fake _task
    _task = dict()
    # Create a fake _execute_module

# Generated at 2022-06-17 09:37:18.358138
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:32.832993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started', 'use': 'auto'}

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared_loader_obj
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module

# Generated at 2022-06-17 09:37:34.848677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None, None)
    assert module is not None

# Generated at 2022-06-17 09:37:38.639660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:37:42.490942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:37:53.168708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}
    task.delegate_to = 'localhost'
    task.async_val = 0

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action
    action = MockAction()

    # Create a mock task_vars

# Generated at 2022-06-17 09:38:04.487612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = False

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module_defaults
    module_defaults = MockModuleDefaults()

    # Create a mock action_groups
    action_groups = MockActionGroups()

    # Create a mock action_groups
   

# Generated at 2022-06-17 09:40:15.721639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:40:27.191629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action module
    action_module = ActionModule(task, connection, loader, display, templar, shared_loader_obj)

    # Create a mock ansible action
    ansible_action = MockAnsibleAction()

    # Create a mock ansible action fail
    ansible_action_fail = MockAnsibleActionFail()

    # Create a mock ansible action