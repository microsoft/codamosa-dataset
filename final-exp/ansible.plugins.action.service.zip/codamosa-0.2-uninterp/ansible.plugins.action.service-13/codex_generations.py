

# Generated at 2022-06-17 09:30:41.602245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector

# Generated at 2022-06-17 09:30:51.347546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar_obj = MockTemplarObj()

    # Create a mock display object
    display_obj = MockDisplayObj()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock module loader object
    module_loader_obj = MockModuleLoaderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinderObj()

    # Create a mock module finder object
    module_finder_obj = MockModuleFinder

# Generated at 2022-06-17 09:31:04.279163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play

# Generated at 2022-06-17 09:31:07.494984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:31:08.004946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:31:20.111610
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import sys
    import unittest
    from unittest.mock import patch

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved

    from ansible_collections.ansible.legacy.plugins.modules.service import ActionModule

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self.display = Display()
            self.display.verbosity = 3
            self.display.color = False


# Generated at 2022-06-17 09:31:21.711330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:31:32.306150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module
    module = MockModule()

    # Create a mock module args
    module_args = MockModuleArgs

# Generated at 2022-06-17 09:31:34.323159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:31:34.983392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:31:50.765038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-17 09:32:00.299128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vault_vars
    from ansible.utils.vars import load_command_line_vars

# Generated at 2022-06-17 09:32:05.340943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-17 09:32:15.438277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    import json
    import tempfile
    import shutil
    import unittest

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    from ansible.plugins.action import ActionBase

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 09:32:22.368529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = 42

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp/ansible-tmp-12345'

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

    # Create a

# Generated at 2022-06-17 09:32:30.920607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule()
    assert module.TRANSFERS_FILES == False
    assert module.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-17 09:32:31.675455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:32:42.823005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock display
    display = MockDisplay()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock task_vars

# Generated at 2022-06-17 09:32:49.661714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_v

# Generated at 2022-06-17 09:33:00.440990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)

    play_

# Generated at 2022-06-17 09:33:22.518952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.common.json_utils import _json
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder

# Generated at 2022-06-17 09:33:32.558941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task_obj = mock.Mock()
    task_obj.args = {'use': 'auto'}
    task_obj.delegate_to = None
    task_obj.async_val = None
    task_obj.module_defaults = None
    task_obj._parent = mock.Mock()
    task_obj._parent._play = mock.Mock()
    task_obj._parent._play._action_groups = None
    task_obj._parent._play._action_groups = None

    # Create a mock connection object
    connection_obj = mock.Mock()
    connection_obj._shell = mock.Mock()
    connection_obj._shell.tmpdir = None

    # Create a mock shared loader object
    shared_loader_obj = mock.Mock()
    shared_loader

# Generated at 2022-06-17 09:33:35.526727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:33:47.965029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and connection
    mock_task = MagicMock()
    mock_task.args = {'name': 'foo', 'state': 'started', 'use': 'auto'}
    mock_connection = MagicMock()
    mock_connection._shell.tmpdir = '/tmp/ansible-tmp-1559056389.8-247077373769072'

    # Create a mock module loader
    mock_module_loader = MagicMock()
    mock_module_loader.has_plugin.return_value = True

    # Create a mock shared loader object
    mock_shared_loader_obj = MagicMock()
    mock_shared_loader_obj.module_loader = mock_module_loader

    # Create a mock templar
    mock_templar = MagicMock()
    mock_templar

# Generated at 2022-06-17 09:34:00.011562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = dict(name='foo')
    task.async_val = False
    task.delegate_to = None

    # Create a mock connection
    connection = MockConnection()
    connection._shell.tmpdir = '/tmp'

    # Create a mock loader
    loader = MockLoader()
    loader.module_loader.has_plugin.return_value = True

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionBase()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock context
    context = MockContext()
    context.resolved_f

# Generated at 2022-06-17 09:34:07.219683
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:34:17.092975
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionBase()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock module_defaults
    module_defaults = dict()

    # Create a mock module_loader
    module_loader = MockModuleLoader()

    # Create a mock module_utils
    module_utils

# Generated at 2022-06-17 09:34:26.839708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:34:34.806489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}
    task.async_val = None
    task.delegate_to = None

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

    # Create a mock module
    module = MockModule()



# Generated at 2022-06-17 09:34:37.705722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:35:20.581615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars


# Generated at 2022-06-17 09:35:25.516516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:35:28.224226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:35:39.585876
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:35:49.817133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 09:36:01.323226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 09:36:02.661097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action is not None

# Generated at 2022-06-17 09:36:04.766050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:36:16.354741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = MockActionPlugin()
    # Create a mock module loader
    module_loader = MockModuleLoader()
    # Create a mock module finder
    module_finder = MockModuleFinder()
    # Create a mock module context
    module_context = MockModuleContext()
    # Create a mock module resolver
    module_resolver = MockModuleResolver()

    # Create an instance

# Generated at 2022-06-17 09:36:20.707947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='httpd')),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 09:37:22.211114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.utils.vars import combine_lists

# Generated at 2022-06-17 09:37:22.915147
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:37:27.857788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:37:36.082342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action plugin object
    action_plugin = MockActionBase()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader object
    module_loader = MockModuleLoader()

    # Create a mock context object
    context = MockContext()

    # Create a mock resolved fqcn object
    resolved_fqcn = MockResolvedF

# Generated at 2022-06-17 09:37:42.894383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock module
    module = MockModule()

    # Create a mock action groups
    action_groups = MockActionGroups()

    # Create a mock action
    action = MockAction()



# Generated at 2022-06-17 09:37:50.564228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='service', module_args=dict(name='test'))),
        connection=dict(host='localhost', port=22, user='test', password='test'),
        play_context=dict(become=False, become_method='sudo', become_user='root', check_mode=False, diff=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 09:37:57.649111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_

# Generated at 2022-06-17 09:38:06.662352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.normal import ActionModule

# Generated at 2022-06-17 09:38:18.103013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactsCollector

# Generated at 2022-06-17 09:38:26.901412
# Unit test for constructor of class ActionModule