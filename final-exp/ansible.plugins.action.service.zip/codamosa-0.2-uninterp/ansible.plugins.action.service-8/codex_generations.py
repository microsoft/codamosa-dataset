

# Generated at 2022-06-17 09:30:46.388121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no module
    action_module = ActionModule(
        task=dict(
            args=dict(
                use='auto',
            ),
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )
    action_module._execute_module = lambda module_name, module_args, task_vars, wrap_async=None: dict(
        ansible_facts=dict(
            ansible_service_mgr='auto',
        ),
    )
    action_module._display = dict()
    action_module._display.warning = lambda msg: None
    action_module._display.debug = lambda msg: None
    action_module._display.vvvv = lambda msg: None
    action_module._

# Generated at 2022-06-17 09:30:54.986605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 09:31:07.446045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.service import ActionModule
    import ansible.plugins.action.service
    import ansible.plugins.action.systemd
    import ansible.plugins.action.sysvinit
    import ansible.plugins.action.openwrt_init
    import ansible.plugins.action.service
    import ansible.plugins.action.setup
    import ansible.plugins.action.systemd
    import ansible.plugins.action.sysvinit
    import ansible.plugins.action.openwrt_init
    import ansible.plugins.action.service
    import ansible.plugins.action.setup
    import ansible.plugins.action.systemd
    import ansible.plugins.action.sysvinit
    import ansible.plugins.action.openwrt_init
    import ansible.plugins.action.service

# Generated at 2022-06-17 09:31:14.652798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_v

# Generated at 2022-06-17 09:31:15.364353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:31:15.998939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:31:25.366554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service as service
    import ansible.plugins.action.systemd as systemd
    import ansible.plugins.action.sysvinit as sysvinit
    import ansible.plugins.action.openwrt_init as openwrt_init
    import ansible.plugins.action.service as service
    import ansible.plugins.action.setup as setup
    import ansible.plugins.loader as loader
    import ansible.plugins.loader.shared_loader_obj as shared_loader_obj
    import ansible.plugins.loader.collection_loader as collection_loader
    import ansible.plugins.loader.action_loader as action_loader
    import ansible.plugins.loader.module_utils_loader as module_utils_loader
    import ansible.plugins.loader.lookup_loader as lookup_loader
    import ans

# Generated at 2022-06-17 09:31:36.903148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'foo', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module context
    module_context = MockModuleContext()

    # Create a mock module
    module = MockModule()

    # Create a mock module collection
    module_collection

# Generated at 2022-06-17 09:31:38.564297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:31:48.695027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_kilobytes
    from ansible.module_utils.common.text.formatters import kilobytes_to_human

# Generated at 2022-06-17 09:31:59.059201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:32:10.559568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {
        'name': 'foo',
        'state': 'started',
        'use': 'auto'
    }

    # Create a mock task_vars
    task_vars = {
        'ansible_facts': {
            'service_mgr': 'systemd'
        }
    }

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module_utils loader

# Generated at 2022-06-17 09:32:14.601464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:32:21.732300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:32:23.976823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None)
    assert module is not None

# Generated at 2022-06-17 09:32:29.314523
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:32:34.666791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(host='localhost', port=22, user='vagrant', password='vagrant'),
        play_context=dict(remote_addr='localhost', port=22, remote_user='vagrant', password='vagrant'),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:32:38.362086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:32:40.268636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:32:47.873882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock object for the task
    task = mock.Mock()
    task.args = {'use': 'auto'}
    task.delegate_to = None
    task.async_val = None

    # Create a mock object for the connection
    connection = mock.Mock()
    connection._shell = mock.Mock()
    connection._shell.tmpdir = None

    # Create a mock object for the shared loader object
    shared_loader_obj = mock.Mock()
    shared_loader_obj.module_loader = mock.Mock()
    shared_loader_obj.module_loader.has_plugin = mock.Mock(return_value=True)

    # Create a mock object for the templar
    templar = mock.Mock()

# Generated at 2022-06-17 09:33:09.224183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:33:13.590921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:33:15.615755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:33:28.431135
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:33:34.993135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock module context
    module_context = MockModuleContext()

    # Create a mock module
    module = MockModule()

    # Create a mock module result
    module_

# Generated at 2022-06-17 09:33:40.922522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='service', module_args=dict(name='httpd'))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 09:33:51.542934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:33:56.558937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present', use='auto')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-17 09:34:06.703470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash_overwrite
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import merge_v

# Generated at 2022-06-17 09:34:12.121680
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='test', state='present')),
        connection=dict(host='localhost', port=22, user='test', password='test'),
        play_context=dict(become=True, become_user='root', become_method='sudo'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-17 09:34:48.441764
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars
   

# Generated at 2022-06-17 09:34:57.619755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock display object
    display = MockDisplay()

    # Create a mock action base object
    action_base_obj = MockActionBase()

    # Create a mock task object
    task_obj = MockTaskObj()

    # Create a mock task object
    task_obj = MockTaskObj()

    # Create a mock action base object
    action_base_obj = MockActionBase()

    # Create a mock action base object
    action_base_obj = MockActionBase()

    # Create a mock action base object
    action_base

# Generated at 2022-06-17 09:34:58.792739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:35:09.173968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()
    # Create a mock display
    display = MockDisplay()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Create a mock action module
    action_module = ActionModule(task, connection, shared_loader_obj, display, templar)
    # Create a mock module
    module = MockModule()
    # Create a mock module args
    module_args = MockModuleArgs()
    # Create a mock module name
    module_name = MockModuleName()
    # Create a mock module default
    module

# Generated at 2022-06-17 09:35:19.128200
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:35:32.698598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceM

# Generated at 2022-06-17 09:35:33.402253
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:35:43.385971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with empty task
    task = dict()
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task == task
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None
    assert action._supports_check_mode is True
    assert action._supports_async is True

    # Test with task and connection
    task = dict()
    connection = dict()
    action = ActionModule(task, connection, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._task == task
    assert action._connection

# Generated at 2022-06-17 09:35:54.134663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='foo', state='present')),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    assert action_module._task.args == dict(name='foo', state='present')
    assert action_module._connection == dict()
    assert action_module._play_context == dict()
    assert action_module._loader == dict()
    assert action_module._templar == dict()
    assert action_module._shared_loader_obj == dict()
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True

# Generated at 2022-06-17 09:36:02.218395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFacts
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFact
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrDistribution
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrDistributionRelease
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrDistributionVersion
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrDistributionName
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrDistributionId

# Generated at 2022-06-17 09:37:05.681600
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:37:17.857084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = MagicMock()
    mock_task.args = {'use': 'auto'}
    mock_task.delegate_to = None
    mock_task.async_val = False
    mock_task._parent = MagicMock()
    mock_task._parent._play = MagicMock()
    mock_task._parent._play._action_groups = []

    # Create a mock loader
    mock_loader = MagicMock()
    mock_loader.module_loader = MagicMock()
    mock_loader.module_loader.has_plugin = MagicMock(return_value=True)

    # Create a mock templar
    mock_templar = MagicMock()
    mock_templar.template = MagicMock(return_value='auto')

    # Create a mock

# Generated at 2022-06-17 09:37:18.405669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:37:32.833318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.conditional import Conditional

# Generated at 2022-06-17 09:37:41.443197
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:37:52.976088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'name': 'httpd', 'state': 'started'}

    # Create a mock connection
    connection = MockConnection()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock display
    display = MockDisplay()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock shared loader object
    shared_loader_obj = MockSharedLoaderObj()

    # Create a mock module loader
    module_loader = MockModuleLoader()

    # Create a mock context
    context = MockContext()

    # Create a mock action plugin
    action_plugin = MockActionPlugin()

    # Create a mock action plugin
    action_

# Generated at 2022-06-17 09:37:53.484427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:37:54.791442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:37:58.705876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:38:07.217024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'use': 'auto'}
    task.async_val = False
    task.delegate_to = None
    task.module_defaults = {}

    # Create a mock connection
    connection = MockConnection()
    connection._shell = MockShell()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock shared loader obj
    shared_loader_obj = MockSharedLoaderObj()
    shared_loader_obj.module_loader = loader

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock display
    display = MockDisplay()

    # Create a mock action module
    action_module = ActionModule(task, connection, templar, shared_loader_obj, display)

   

# Generated at 2022-06-17 09:40:20.560484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for method run(self, tmp=None, task_vars=None)
    # of class ActionModule
    #
    # Setup test
    #
    # Test
    #
    # Teardown test
    pass

# Generated at 2022-06-17 09:40:32.204653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.service as service
    import ansible.plugins.loader as loader
    import ansible.playbook.task as task
    import ansible.playbook.play as play
    import ansible.playbook.play_context as play_context
    import ansible.executor.task_queue_manager as task_queue_manager
    import ansible.executor.playbook_executor as playbook_executor
    import ansible.vars.manager as vars_manager
    import ansible.vars.hostvars as hostvars
    import ansible.vars.unsafe_proxy as unsafe_proxy
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars
    import ansible.vars.hostvars as hostvars
