

# Generated at 2022-06-23 08:29:12.882072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostvars = {'localhost': {'ansible_service_mgr': 'test'}}
    ansible_facts = {'service_mgr': 'test'}
    task_vars = {'hostvars': hostvars, 'ansible_facts': ansible_facts}
    test_ansible_module = ActionModule(None, 'role_name')
    test_ansible_module._execute_module = lambda x, y, z: {'test': x}
    test_ansible_module._task.args = {}
    test_ansible_module._task.args['use'] = 'auto'
    test_ansible_module._task.delegate_to = 'localhost'
    test_ansible_module._task.async_val = 1

    expected_result = {'test': 'test'}
   

# Generated at 2022-06-23 08:29:15.685586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule without any options and all set to default values
    # AnsibleAction, ActionBase, ModuleLoader, DataLoader, TaskLoader, PluginLoader, PluginLoaderFilter, CollectionLoader, StrategyBase
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:29:16.936842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1



# Generated at 2022-06-23 08:29:17.539703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:29:21.941344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert module != None

# Generated at 2022-06-23 08:29:29.577573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule("test_actionmodule", {}, {}, "test_connection", "test_play_context")
    assert action.TRANSFERS_FILES is False
    # Following may fail if implementation of UNUSED_PARAMS changed in future
    for key, value in action.UNUSED_PARAMS.items():
        assert isinstance(key, str)
        assert isinstance(value, list)
    for elem in action.BUILTIN_SVC_MGR_MODULES:
        assert isinstance(elem, str)

# Generated at 2022-06-23 08:29:32.578057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Test pkg constructor, exceptions, etc. '''
    from ansible.plugins.task.legacy_service import ActionModule

    a = ActionModule(None, {}, None, None)
    assert a

# Generated at 2022-06-23 08:29:39.597708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTask:
        def __init__(self, args):
            self.args = args
            self.async_val = 15

        def set_loader(self, loader):
            pass

    loader = None
    templar = []

    for args in (dict(name='httpd'), dict(name='httpd', use='auto'), dict(name='httpd', use='systemd', state='restarted')):
        yield check_ActionModule, FakeTask(args), loader, templar



# Generated at 2022-06-23 08:29:41.509092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an object of class ActionModule
    service = ActionModule()
    assert service.runner_name == 'local'

# Generated at 2022-06-23 08:29:49.058340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTask():
        async_val = False
        #fake loading of collections
        collections = []
        class FakeParent():
            class FakePlay():
                class FakeActionGroups():
                    def __init__(self):
                        self._action_groups = []

                class FakeDS():
                    def __init__(self):
                        self._ds = {}
                        self._ds['ansible_service_mgr'] = 'systemd'
                _action_groups = FakeActionGroups()
                _ds = FakeDS()
            _parent = FakePlay()

        _task = FakeParent()
        _task.args = {}
        _task.args['use'] = 'auto'
        args = _task.args
    task = FakeTask()
    #Loading ActionModule class
    am = ActionModule(task, fake_display(), {})
   

# Generated at 2022-06-23 08:29:58.713072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os

    current_path = os.path.dirname(os.path.realpath(__file__))
    action_module_json_file = os.path.join(current_path, 'ActionModule.json')

    with open(action_module_json_file) as json_data:
        d = json.load(json_data)

        for module in d:
            for test in d[module]:
                if module == 'module_setup':
                    temp_module = TestActionModule()
                    temp_module.module_setup(module, test['args'])

                elif module == 'load_module_plugins_from_files':
                    temp_module = TestActionModule()
                    temp_module.load_module_plugins_from_files(module, test['args'])


# Generated at 2022-06-23 08:30:10.293105
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:30:23.475434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleAction, AnsibleActionFail
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible import context
    import ansible.utils.args as ansible_args

    # The mock add_plugin function

# Generated at 2022-06-23 08:30:25.354267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule({}, {}, {})


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:30:33.870850
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    action_module._display = {}
    action_module._display["display"] = lambda *args, **kwargs: None

    action_module._task = {}
    action_module._task["args"] = {}

    action_module._task["args"]["name"] = "httpd"

    action_module._task["args"]["use"] = "auto"

    action_module._task["args"]["pattern"] = "httpd"

    action_module._task["args"]["runlevel"] = "default"

    action_module._task["args"]["sleep"] = 5

    action_module._task["args"]["arguments"] = "-c /tmp/httpd.conf"


# Generated at 2022-06-23 08:30:40.708976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module1 = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)

    assert action_module1._supports_check_mode == True
    assert action_module1._supports_async == True

    test_templar = {}
    action_module1._templar = test_templar

    action_module1._remove_tmp_path("/tmp/test")

# Generated at 2022-06-23 08:30:45.824174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Success case
    action = ActionModule(None, None)
    assert action.argspec
    assert action.supports_check_mode
    assert action.result
    assert action.TRANSFERS_FILES
    assert action.BUILTIN_SVC_MGR_MODULES
    assert action.UNUSED_PARAMS
    assert action.supports_async
    assert action.supports_async_timeout
    assert action.supports_async_poll_delay
    assert action.supports_async_post

# Generated at 2022-06-23 08:30:47.107608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:30:48.583493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert not action is None


# Generated at 2022-06-23 08:30:57.151106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict(skipped=False, failed=False, changed=False, msg='', stdout='')
    config = dict(
        gather_facts='no',
        tasks=[
            dict(
                action=dict(
                    module='service',
                    name='httpd',
                    state='started',
                    use='auto'
                ),
                name='restart httpd'
            )
        ]
    )

# Generated at 2022-06-23 08:31:06.379787
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager

    task_vars = dict(
        ansible_facts={},
        ansible_check_mode=True,
        ansible_verbose_override=True,
        ansible_log_path='/path/to/ansible.log',
        ansible_connection='local',
        ansible_playbook_python='/path/to/python'
    )


# Generated at 2022-06-23 08:31:17.018545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ####################################################################################################################
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            use=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )
    tmp = 'tmp'
    task_vars = {
        'ansible_service_mgr': 'systemd',
    }

    am = ActionModule(module, tmp, task_vars)
    ####################################################################################################################

    action_module_run_result = am.run(tmp=tmp, task_vars=task_vars)


# Generated at 2022-06-23 08:31:30.228715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        def _execute_module(self, module_name, module_args, task_vars, wrap_async):
            assert module_name == 'test_module_name'
            assert module_args == 'test_module_args'
            assert task_vars == 'test_task_vars'
            assert wrap_async is True
            return dict(test_result='test_result')

    tmp = ''
    task_vars = 'test_task_vars'
    action_module = TestActionModule(tmp, task_vars)
    action_module._task.args = dict(test_name='test_value')
    action_module._task.async_val = True

    # Test run() when module is 'test_module_name'

# Generated at 2022-06-23 08:31:36.132789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('module', 'action', 'args', 'set_fact', 'hostvars')
    assert action_module._task.args == 'args'
    assert action_module._connection.module_implementation_preferences == ['c', 'powershell', 'python', 'winrm', 'netconf']

# Generated at 2022-06-23 08:31:45.718717
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:31:50.006514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test if a ActionModule instance can be created
    am = ActionModule(task={}, connection={}, play_context={}, loader={}, templar={}, share={})
    assert isinstance(am, ActionModule)

# Generated at 2022-06-23 08:31:51.694744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:31:52.214167
# Unit test for constructor of class ActionModule
def test_ActionModule():
  main = AnsibleTask

# Generated at 2022-06-23 08:31:55.263584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {"use": "systemd"}
    action_module = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-23 08:32:03.604374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = {}
    module = ActionModule()
    module.set_connection(params)
    module.set_task(params)
    module.set_loader(params)
    module.set_play_context(params)
    module.set_shared_loader_obj(params)
    module.set_loader_obj(params)
    module.set_templar(params)
    module.set_task_vars(params)
    module.set__fact_cache(params)
    module.set_tempfile_lookup(params)
    module.set__noop_task(params)
    module.set__task_vars_cache(params)


# Generated at 2022-06-23 08:32:13.779638
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.module_utils.six import string_types
    from ansible.plugins.loader import action_loader

    action_executor = action_loader.get('raw')
    task_executor_mock = Mock()
    task_executor_mock.get_loader.return_value = action_loader
    task_executor_mock.get_templar.return_value = action_executor.get_loader()
    task_executor_mock.connection = Mock()
    task_executor_mock.connection.shell = Mock()
    task_executor_mock.connection.shell.tmpdir = '/tmp'

# Generated at 2022-06-23 08:32:16.533371
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ActionModule_obj = ActionModule()
    ActionModule_obj.run('tmp', 'task_vars')



# Generated at 2022-06-23 08:32:21.469191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    options = []
    play_context = dict()

    # Create a new instance of ActionModule and test execute method
    action_module = action_loader.get('service', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(task_vars=None, tmp=None)
    assert not result.get('failed', True)

# Generated at 2022-06-23 08:32:33.828244
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import modules_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager

    context = PlayContext()

    context.connection = 'local'
    context.become = False
    context.become_user = 'root'
    context.remote_addr = '127.0.0.1'
    context.remote_user = 'root'
    context.port = 2268

    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'ansible_connection': context.connection,
        'ansible_port': context.port,
        'ansible_user': context.remote_user,
        }

# Generated at 2022-06-23 08:32:35.655759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:32:40.895406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import mock
    import tempfile
    import shutil
    import json
    import tempfile
    import stat

    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play, PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.callback import CallbackBase

    from ansible.plugins.action import ActionModule


# Generated at 2022-06-23 08:32:51.893922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service as service
    import ansible.plugins.loader
    
    am = service.ActionModule(None, None, None, None)
    ansible.plugins.loader.find_plugin = lambda module, collection_list=None: None

    def mock_execute_module():
        return {'rc': 0}
    am.run = lambda tmp, task_vars: mock_execute_module()
    module, new_module_args, task_vars = am._run({'args': {'use': 'auto'}, 'module': 'service'}, {'module_defaults': {}, 'module_name': 'service'}, {})

    assert module == 'auto'

# Generated at 2022-06-23 08:32:53.674257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.run()

# Generated at 2022-06-23 08:33:02.646715
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import unittest

    from ansible.module_utils.hashivault import HASI_VAULT_ADDR, HASI_VAULT_TOKEN

    sys.modules['hvac'] = unittest.mock.Mock()

    from ansible.module_utils.hashivault import hashivault_lookup_plugin


# Generated at 2022-06-23 08:33:13.187761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    role_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/roles/test_collections/geerlingguy.java')
    collection_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/collections/ansible_collections/geerlingguy/java')
    loader = DataLoader()
    collection_loader = collections_loader.CollectionsLoader()
    collection_loader.resolve_collections([collection_path])
    collection_list = collection_loader.list_collections()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._extra_vars = {}
    variable_manager.options_vars

# Generated at 2022-06-23 08:33:14.801482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    ACTION_MODULE = ActionModule()
    ACTION_MODULE


# Generated at 2022-06-23 08:33:24.243618
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # test exception handling 
    try:
        task_vars = { 'ansible_facts': {} }
        result = action_module.run(task_vars)
    except AnsibleActionFail as e:
        assert isinstance(e, AnsibleActionFail)
    # test condition when module name is auto 
    try:
        task_vars = { 'ansible_facts': { 'service_mgr': 'service' } }
        result = action_module.run(task_vars)
        assert not result.get('failed') and result.get('msg') == "SUCCESS"
    except AnsibleActionFail as e:
        assert isinstance(e, AnsibleActionFail)
    # test condition when module name is auto 

# Generated at 2022-06-23 08:33:35.395017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.display import Display
    from ansible.plugins.action.service import ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 08:33:38.365430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-23 08:33:41.452956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(loader=None, connection=None, play_context=None, loader_args=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:33:46.623045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule()

    assert module is not None

    # Test with arguments
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert module is not None

# Generated at 2022-06-23 08:33:47.877149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: Implement!
    pass


# Generated at 2022-06-23 08:33:53.599076
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task = dict(
        use='service',
        pattern='pattern',
        name='name'
    )

    task_vars = dict()

    result = dict()

    instance = ActionModule(task, task_vars, result)
    assert isinstance(instance, ActionModule)
    assert instance._task.args.get("pattern") == "pattern"
    assert instance._task.args.get("name") == "name"

# Generated at 2022-06-23 08:33:59.267523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule
    """
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    assert action_module


# Generated at 2022-06-23 08:34:04.314095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule

    task_vars = {}
    action_module = ActionModule(task=dict(args={'use': 'auto'}), connection=None, task_vars=task_vars)

    # TODO: test execution of action module
    assert True

# Generated at 2022-06-23 08:34:09.723776
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = {'host': 'host-1', 'ansible_host': 'host-1'}
    action = ActionModule(connection)
    assert action.name == 'service'
    assert action.connection._shell.tmpdir == '/var/tmp/ansible-tmp-1541873285-81334-69863151217641'

# Generated at 2022-06-23 08:34:10.701834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    assert True

# Generated at 2022-06-23 08:34:19.386655
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        from ansible.module_utils.common._collections_compat import ImmutableDict
    except:
        from collections import ImmutableDict

    def get_vars():
        return ImmutableDict(ANSIBLE_MODULE_ARGS={'test': 'test'})

    test = ActionModule(
        task=dict(args={'test': 'test'}, async_val=2),
        connection=None,
        play_context=dict(become=False, diff=False, environment={}, only_tags=[], skip_tags=[], become_user='become_user'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    test._task.environment = get_vars
    test.run()

# Generated at 2022-06-23 08:34:29.961810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import yaml

    # create dummy action plugin

# Generated at 2022-06-23 08:34:41.430645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create object of class ActionModule
    actionModule_obj = ActionModule(
        task=dict(action=dict(module_name='action_module', module_args=dict(use='module', name='module_name'))),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=dict())

    # using object of class ActionModule to get the module name and
    # module args
    task = actionModule_obj._task
    module_name = actionModule_obj._task.action['module_name']
    module_args = actionModule_obj._task.action['module_args']

    assert module_name == 'action_module' and module_args == {
        'use': 'module',
        'name': 'module_name'
    }

# Generated at 2022-06-23 08:34:50.827081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock vars:
    task_vars = dict(
        ansible_facts=dict(
            service_mgr=None
        )
    )

    module_args = dict(
        name="foo",
        state="started"
    )

    # Instantiate mock class
    shared_loader_obj = None

# Generated at 2022-06-23 08:34:56.294408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(
        task=dict(name='mock', args={'use':'auto'}, async_val=None, async_timeout=None, action='mock'),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert mod.TRANSFERS_FILES is False

# Generated at 2022-06-23 08:35:03.473004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    MockActionBase = MagicMock()
    MockActionModule = type('MockActionModule', (ActionModule,), {'run': MockActionBase.run, '_remove_tmp_path': MockActionBase._remove_tmp_path})

    mock_task = MagicMock()
    mock_task.async_val = 1

    mock_connection = MagicMock()
    mock_connection._shell = MagicMock()

    mock_connection._shell.tmpdir = 'tmpdir'
    task_vars = {}

    mock_display = MagicMock()

    mock_options = {'use': 'auto'}
    mock_loader = MagicMock()
    mock_templar = MagicMock()
    mock_task.args = mock_options
    mock_task._parent = MagicMock()
    mock_task._parent._

# Generated at 2022-06-23 08:35:04.943818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, {}), ActionBase)

# Generated at 2022-06-23 08:35:14.850048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common._collections_compat import Mock
    from ansible.plugins.loader import action_loader

    # Create a mock module
    my_module = Mock()
    my_module.check_mode = False
    my_module.run_command = Mock(return_value=(0, '', ''))
    my_module.params = {'name': 'openssh-servicemanager', 'state': 'present'}
    my_module.ansible_module_instance = Mock()
    my_module.ansible_module_instance.run = my_module

    # Set up a mock loader, action plugin and action base plugin
    action_plugin = action_loader.get('yum', class_only=True)
    action_base_plugin = action_loader.get('auto', class_only=True)


# Generated at 2022-06-23 08:35:18.404825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am._supports_check_mode == True
    assert am._supports_async == True

# Generated at 2022-06-23 08:35:21.398344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    con = connection_loader.get('local', None, None, None)
    action = ActionModule(connection=con, templar=Templar(), task=None)
    assert action

# Generated at 2022-06-23 08:35:22.405918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:35:25.690690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run(tmp="test", task_vars=dict())
    module.run(tmp="test", task_vars=dict(ansible_facts=dict(service_mgr="test")))

# Generated at 2022-06-23 08:35:43.111628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext

    test_play = Playbook().load('/tmp/test_play', variable_manager={}, loader=None)
    test_task = test_play.get_variable_manager()._tasks[0]
    test_task._role = None
    test_task._parent = test_task
    test_task._play = test_play
    test_task._final_state = None
    test_task._role_context = None
    test_task._block = None
    test_task._play_context = PlayContext()
    test_task._task_vars = {}
    test_task._loader = None
    test_task._connection = None
    test_task._shared_loader_obj = None
    test_task._tem

# Generated at 2022-06-23 08:35:50.713593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    # Note: Using a mock task and other objects to test run method
    #       the 'execute' function cannot be mocked as it is used
    #       inside 'run' method.

    # Creating task object
    class MockModule:
        def __init__(self):
            self.run_command = ''

        def run(self, *args):
            self.run_command = args



# Generated at 2022-06-23 08:35:58.822242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.module_utils.common.removed as removed
    removed.warn = lambda x: x

    class FakeVarsModule:
        def __init__(self):
            self.ANSIBLE_MODULE_ARGS = {
                'name': 'httpd',
                'state': 'started',
                'use': 'auto',
            }

            self.ansible_facts = {
                'service_mgr': 'systemd'
            }

    class FakeTask:
        def __init__(self):
            self._parent = FakePlay()

            self.args = {'use': 'auto'}
            self.async_val = 42
            self.module_defaults = {}  # This can be anything

    class FakePlay:
        def __init__(self):
            self._action_groups = {}

   

# Generated at 2022-06-23 08:35:59.955699
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-23 08:36:10.263990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test without use parameter
    task_vars = dict(
        ansible_facts=dict(service_mgr='systemd')
    )
    task_args = dict()
    async_val = False
    package = 'httpd'
    name = 'httpd'
    state = 'started'
    update_cache = False

    task_args['name'] = name
    task_args['state'] = state
    task_args['update_cache'] = update_cache
    task_args['package'] = package

    runner_mock = Mock()
    runner_mock.run.return_value = dict(
        ansible_facts=dict(
            ansible_service_mgr='systemd'
        )
    )

    shared_loader_obj = Mock()

# Generated at 2022-06-23 08:36:23.046866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager, TaskQueue

    play_context = PlayContext()
    task_result = TaskResult(host="1234")
    task_queue = TaskQueue()
    task_queue_manager = TaskQueueManager()

    plugin_name = 'systemd'
    options = {
        'use': 'systemd',
        'name': 'sshd',
        'state': 'started',
        'enabled': 'yes',
    }

    task_vars = {
        'ansible_facts': {
            'service_mgr': 'systemd',
            'service_name': 'sshd'
        }
    }

    task = task_queue

# Generated at 2022-06-23 08:36:32.106338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    doc = '''
        - name: test1
          service:
            name: test_service
            state: started

        - name: test2
          service:
            name: test_service
            state: stopped
            use: systemd
    '''
    # setup mocks
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system import system
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactModule

    facts = system.SystemFacts()
    facts.collect_fact = MagicMock(return_value=ServiceMgrFactModule(ansible_facts={}))
    ServiceMgrFactCollector.collect = MagicMock(return_value=facts)

    ###

    # prepare task


# Generated at 2022-06-23 08:36:34.064211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.BUILTIN_SVC_MGR_MODULES == frozenset(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-23 08:36:34.641438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-23 08:36:44.030002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._task.args.get('use', 'auto').lower() == 'auto'
    assert action_module.TRANSFERS_FILES == False
    assert action_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True

# Generated at 2022-06-23 08:36:52.680824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Test(object):
        class _task(object):
            args = {}
            async_val = False

    class Test2(object):
        class _task(object):
            args = {}
            async_val = True
    class Test3(object):
        class _task(object):
            args = {}
            async_val = []

            def __init__(self):
                self.collections = []

    class Test4(object):
        class _task(object):
            args = {}
            async_val = []

            def __init__(self):
                self.collections = [('community.general', 'my_collection')]

    class Test5(object):
        class _task(object):
            args = {}
            async_val = []
            collections = []


# Generated at 2022-06-23 08:37:01.072115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict(use='auto', pattern='test', state='started')
    task = dict(action=dict(module='command', args=args))
    t = ActionModule(task, dict())
    result = t.run(tmp=None, task_vars=dict())
    assert result['failed'] == True and result['msg'] == 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.'

    task['action']['args']['use'] = 'systemd'
    t = ActionModule(task, dict())
    result = t.run(tmp=None, task_vars=dict())
    assert result.get('failed') == None and result.get('msg') == None

# Generated at 2022-06-23 08:37:11.991106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test code goes here')
    # ansible.utils.boolean.boolean
    # ansible.plugins.action.ActionBase.get_platform_subclass
    # ansible.plugins.action.ActionBase.run
    # ansible.plugins.action.ActionBase._execute_module
    # ansible.plugins.action.ActionBase._execute_task
    # ansible.plugins.action.ActionBase._low_level_execute_command
    # ansible.plugins.action.ActionBase._run
    # ansible.plugins.action.ActionBase.run
    # ansible.plugins.action.ActionBase._execute_loop
    # ansible.plugins.action.ActionBase._low_level_execute_command
    # ansible.plugins.action.ActionBase._run
    # ansible.plugins.action.ActionBase._execute_

# Generated at 2022-06-23 08:37:14.202571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, {}, {}, {}, None, '/tmp')
    assert action.run() == {}

# Generated at 2022-06-23 08:37:15.683363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('testing action module...')

# Generated at 2022-06-23 08:37:22.557200
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action = ActionModule(
          task=None, 
          connection=None, 
          play_context=None, 
          loader=None, 
          templar=None, 
          shared_loader_obj=None
  )

  assert action._shared_loader_obj is shared_loader_obj
  assert action._loader is loader
  assert action._templar is templar
  assert action._task is task
  assert action._connection is connection
  assert action._play_context is play_context



# Generated at 2022-06-23 08:37:29.808239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance = ActionModule()
    assert instance.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}
    assert instance.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert instance.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:37:33.566421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")
    p = ActionModule(dict(name="test"), None)
    assert isinstance(p, object)

# Generated at 2022-06-23 08:37:35.489332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, 'test') is not None

# Generated at 2022-06-23 08:37:41.705617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import argparse
    from ansible.plugins.action.service import ActionModule
    am = ActionModule()

    args = ['service', 'name=foo', 'state=started']
    myargs = am.parser(args)
    assert myargs.name == 'foo'
    assert myargs.state == 'started'
    assert am.module_name == 'service'

    args = ['service', 'name=foo', 'state=started', 'arg1="one two"', 'arg2=two']
    myargs = am.parser(args)
    assert myargs.name == 'foo'
    assert myargs.state == 'started'
    assert myargs.arg1 == 'one two'
    assert myargs.arg2 == 'two'

# Generated at 2022-06-23 08:37:50.086236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This method is used to test the constructor of class ActionModule
    """

# Generated at 2022-06-23 08:37:50.669992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:37:54.101756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict(use='auto')),
        connection=dict(play_context=dict(check_mode=True)),
        templar=None,
        shared_loader_obj=None)
    assert module._task.args.get('use') == 'auto'
    assert not module._supports_check_mode

# Generated at 2022-06-23 08:38:02.571484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # JIRA Issue PO-2261 - When the delegate_to keyword is used, the host facts
  # of the delegated host must be used.
  facts = {
    u'ansible_facts': {
      u'ansible_service_mgr': 'service'
    }
  }
  tmp_file_name = "setup_test_123456789"

  # Build a task object to perform the test on

# Generated at 2022-06-23 08:38:14.580954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.six import PY2

    class Connection(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

        def _shell(self):
            return self

        def get_shell_plugins(self, *args, **kwargs):
            return []

    class TestActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

# Generated at 2022-06-23 08:38:15.103144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:38:20.848707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import random
    import string

    class MockTemplar(object):
        def template(self, template):
            return 'auto'

    class MockShell(object):
        tmpdir = 'tmpdir'

    class MockConnection(object):
        _shell = MockShell()

    class MockTask(object):
        async_val = None
        delegate_to = None
        module_defaults = None
        collections = None

        def __init__(self, args=None):
            if args is None:
                args = {}
            self.args = args

    class MockModuleLoad(object):
        def find_plugin(self, name, collection_list):
            return 'service'


# Generated at 2022-06-23 08:38:22.679573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, lazy_load = False).__class__.__name__ == 'ActionModule'

# Generated at 2022-06-23 08:38:32.897646
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test ActionModule:")

    # TEST 1: Check if ActionModule is of type AnsibleAction
    am = ActionModule(None, None)
    if not isinstance(am, ansible.plugins.action.ActionBase):
        print("ActionModule is not of type AnsibleAction")

    # TEST 2: Check if the _supports_check_mode attribute is set to TRUE
    if not am._supports_check_mode:
        print("_supports_check_mode not set to TRUE")

    # TEST 3: Check if the _supports_async attribute is set to TRUE
    if not am._supports_async:
        print("_supports_async not set to TRUE")


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-23 08:38:34.116292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-23 08:38:36.314216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test is not None


# Generated at 2022-06-23 08:38:42.421771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.common.removed import removed_module
    from ansible.plugins.loader import action_loader

    my_action = action_loader.get('service',
                                  task=dict(action='service',
                                            use='auto',
                                            name='testname',
                                            state='started',
                                            delegate_to='c2'
                                            ),
                                  variable_manager=dict(),
                                  loader=dict(),
                                  play_context=dict(),
                                  shared_loader_obj=dict(),
                                  connection=dict()
                                  )

    my_action_run = my_action.run(tmp=dict(), task_vars=dict())

    assert my_action_run is not None
   

# Generated at 2022-06-23 08:38:54.824279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # prepare test data
    host_list = [
        {
            'hostname': 'fake_hostname',
            'ip': '1.1.1.1',
            'port': 22
        }
    ]

    task_vars = {
        'ansible_facts': {
            'service_mgr': 'sysvinit'
        }
    }

    def run_task(task):
        pass


# Generated at 2022-06-23 08:38:59.716240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = type_module.ActionModule()
    class b:
        def __init__(self):
            self._play = None
            self.args = dict()
            self.args['use'] = 'auto'
            self.async_val = None
            self.delegate_to = None
    a._task = b()
    class c:
        def __init__(self):
            self.args = dict()
            self.args['name'] = 'httpd'
            self.args['state'] = 'started'


# Generated at 2022-06-23 08:39:04.938646
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    print("Testing ActionModule.run")
    module.run()
    print("ActionModule.run test finished")
    # AnsibleAction
    # AnsibleActionFail
    # module_defaults
    # module_name
    # module_args
    # async_val

if __name__ == '__main__':
    test_ActionModule_run()