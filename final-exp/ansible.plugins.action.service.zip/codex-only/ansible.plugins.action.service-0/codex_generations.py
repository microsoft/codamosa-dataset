

# Generated at 2022-06-23 08:28:59.536241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-23 08:29:05.945076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = MockConnection()
    task = MockTask()
    task_vars = dict()
    task.args = {'use': 'auto'}
    module = ActionModule(conn, task, task_vars)
    module._task.delegate_to = None
    module._task.async_val = True
    # run
    result = module.run()
    assert result['module_name'] == 'ansible.legacy.setup'
    assert result['module_args']['gather_subset'] == '!all'
    assert result['module_args']['filter'] == 'ansible_service_mgr'
    # run
    result = module.run()
    assert result['module_name'] == 'ansible.legacy.service'

# Generated at 2022-06-23 08:29:16.224708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        use="auto"
    )
    templar = dict(
        template=lambda x : x,
        template_from_file=lambda x : x,
        template_ds=lambda x : x,
        template_from_file_ds=lambda x : x
    )
    def execute_module(module_name, module_args, task_vars, wrap_async):
        if module_name == 'ansible.legacy.setup':
            return dict()
        elif module_name == 'ansible.legacy.service':
            return dict(
                changed=True
            )
        return dict()

# Generated at 2022-06-23 08:29:17.907639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert isinstance(True, bool)



# End of code

# Generated at 2022-06-23 08:29:29.079073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible
    import os
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.process import get_bin_path

    ansible_path = os.path.dirname(ansible.__file__)
    dir = os.getcwd()


# Generated at 2022-06-23 08:29:35.607502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create action module object
    action_module = ActionModule()

    # Create test ansible task
    ansible_task = {'use': 'auto'}

    # Create test ansible result
    ansible_result = {}

    # Execute run method and store the result
    ansible_result = action_module.run(None, None)

    # Verify results
    assert ansible_result['ansible_facts']['service_mgr'] == 'auto'

# Generated at 2022-06-23 08:29:47.012762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import sys

    # These imports are needed to fix errors 'ImportError: cannot import name ...'
    import ansible.context
    import ansible.executor.module_common
    import ansible.plugins.loader
    import ansible.utils.display

    import ansible.module_utils
    import ansible.module_utils.facts

    class ActionBase_:
        _display = ansible.utils.display.Display()

        def _execute_module(self, module_name, module_args, task_vars=dict(), wrap_async=False):
            dict_result = dict()
            dict_result['module_name'] = module_name
            dict_result['module_args'] = module_args
            dict_result['task_vars'] = task_vars
            dict_result['wrap_async']

# Generated at 2022-06-23 08:29:53.764537
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugins
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.template import Templar

    context = PlayContext({})
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_loader(loader)
    variable_manager.extra_vars = {'hostvars': {}}
    variable_manager.options_vars = {}
    variable_manager.set_options(direct=context._attributes)
    variable_manager.set_parent_vars({})

    templar = Templar(loader=loader, variables=variable_manager)


# Generated at 2022-06-23 08:30:02.480656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.loader import action_loader

    # Create object for a class 'ActionModule'
    action_module = action_loader.get('service.yml', class_only=True)
    assert type(action_module) == type(ActionModule)

    # Assert 'action_module' is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

    # Assert '_supports_check_mode' is set True
    assert action_module._supports_check_mode

    # Assert '_supports_async' is set True
    assert action_module._supports_async


# Generated at 2022-06-23 08:30:06.214631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action

# Generated at 2022-06-23 08:30:18.098766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        module_args = dict()
        task_vars = dict()
        action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_obj=None, templar=None, shared_loader_obj=None)
        result = action_module.run(tmp=None, task_vars=task_vars)
    except Exception as e:
        print("test_ActionModule() FAILED", e)

    return True

if __name__ == '__main__':
    if test_ActionModule():
        print("test_ActionModule() SUCCEEDED", end='\n')
    else:
        print("test_ActionModule() FAILED", end='\n')

# Generated at 2022-06-23 08:30:19.695781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write this unit test
    pass

# Generated at 2022-06-23 08:30:23.977536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Code for unit test
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 08:30:32.333456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    Am = ActionModule(
        task=dict(args=dict()),
        connection=dict(
            _shell=dict(
                tmpdir='tmpdir'
            )
        ),
        shared_loader_obj=dict(
            module_loader=dict(
                has_plugin=lambda x: False
            )
        )
    )
    assert Am.run() == {'_ansible_verbose_always': False, '_ansible_no_log': False, '_ansible_verbosity': 0, '_ansible_version': '2.4.3.0', 'changed': False, 'failed': True, 'msg': 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.', 'parsed': False}

# Generated at 2022-06-23 08:30:40.466921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.constants import DEFAULT_MODULE_NAME, DEFAULT_MODULE_ARGS
    from ansible.playbook.play_context import PlayContext

    task = Task()
    play_context = PlayContext()
    connection = FakeConnection()
    TaskExecutor = ActionModule(task, connection, play_context, loader=None, templar=None, shared_loader_obj=None)

    assert TaskExecutor._task.name == DEFAULT_MODULE_NAME
    assert TaskExecutor._task.args == DEFAULT_MODULE_ARGS



# Generated at 2022-06-23 08:30:42.151149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None,None, {'use': 'auto'}, None)
    assert a._task.args.get('use') == 'auto'

# Generated at 2022-06-23 08:30:53.963106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    info = {'state': 'started', 'name': 'httpd', 'use': 'auto'}
    module.task._task_fields['args'] = info

    module.task._task_fields['_ansible_no_log'] = False
    module.task._task_fields['_ansible_check_mode'] = False
    module.task._task_fields['_ansible_async'] = 0
    module.task._task_fields['_ansible_delegated_vars'] = dict()
    module.task._task_fields['_ansible_verbosity'] = 0

    module.task._task_fields['_ansible_debug'] = True
    module.task._task_fields['_ansible_diff'] = True

# Generated at 2022-06-23 08:31:00.737941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    class constructor for ActionModule
    '''
    action_module = ActionModule(
        task=dict(action=dict(module_name='setup', module_args=dict(filter='ansible_service_mgr'))),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=dict(),
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-23 08:31:08.016522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager, \
        TaskQueueManagerRun
    import ansible.constants as C
    import ansible.plugins.loader as ploader
    import ansible.utils.vars as avars
    import ansible.utils.module_docs as amodule_docs
    from collections import namedtuple
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from io import StringIO
    from ansible.plugins.action import ActionBase


# Generated at 2022-06-23 08:31:15.522303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.task as task

    plugin = ActionModule(
        task=task.Task(
            task_args=dict(
                pattern='httpd',
                use='auto',
            ),
        ),
    )

    plugin.run(task_vars={'ansible_facts': {'service_mgr': 'not-auto'}})

    a = ActionModule(
        task=task.Task(
            task_args=dict(
                pattern='httpd',
                use='auto',
            ),
        ),
    )
    a.run()

# Generated at 2022-06-23 08:31:21.229506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import copy
    import os
    import yaml
    from ansible.plugins.action.auto import ActionModule
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import action_loader
    from ansible.plugins import module_loader
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-23 08:31:31.897713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for the method run of class ActionModule
    '''
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module.BUILTIN_SVC_MGR_MODULES = set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    action_module.UNUSED_PARAMS = {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}

    tmp = None
    task_vars = {}
    task_vars['ansible_facts'] = {'ansible_service_mgr': 'auto'}
    action_module._task.delegate_to = None

# Generated at 2022-06-23 08:31:43.190942
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # call method with args
    args = {'pattern': 'a', 'runlevel': 'a', 'sleep': 'a', 'arguments': 'a', 'args': 'a'}
    result = ActionModule.run(args)
    assert result['failed'] is True
    # call method with args
    args = {'pattern': 'a', 'runlevel': 'a', 'sleep': 'a', 'arguments': 'a', 'args': 'a', 'use': 'auto'}
    result = ActionModule.run(args)
    assert result['failed'] is True
    # call method with args
    args = {'pattern': 'a', 'runlevel': 'a', 'sleep': 'a', 'arguments': 'a', 'args': 'a', 'use': 'auto', 'delegate_to': 'a'}

# Generated at 2022-06-23 08:31:45.607261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    params = {}
    tmp, task_vars = None, None

    # Construct object
    module = ActionModule(tmp, task_vars)

    # Check if object is empty
    if module:
        assert False

# Generated at 2022-06-23 08:31:46.067067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:31:56.405509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'service'
    task_vars = {"ansible_service_mgr": "auto"}
    import ansible.executor.module_common
    import ansible.plugins.action
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.plugins.loader
    import ansible.utils.plugin_docs
    class Instance(object):
        def __init__(self):
            self.args = {"use": "auto"}
            self.delegate_to = ""
            self.async_val = False
            self.port = 22

# Generated at 2022-06-23 08:31:59.207313
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Use reflection to determine the class under test.
    # This is necessary because we want test to be constructed at runtime.
    # Otherwise the framework would need to be referenced in the test suite,
    # which is not the case.

    action_module = ActionModule()

    # TODO: Use the actual result object
    action_module.run()

# Generated at 2022-06-23 08:32:10.792954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

    data = UnsafeProxy({'dest': '/etc/foo.conf', 'content': '# foo', 'state': 'present'})
    templar = Templar(loader=None, variables={'hostvars': HostVars(loader=None, task=None)})

    task = Task()
    task.args = {
        'use': 'auto',
        'name': 'foo',
        'content': '# foo',
        'state': 'present',
        'dest': '/etc/foo.conf',
    }


# Generated at 2022-06-23 08:32:21.547468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialization test
    from ansible.playbook.task import Task

    Task._shared_loader_obj = Task._shared_loader_obj
    task_vars = dict()
    task_vars['hostname'] = 'hello'
    Task._shared_loader_obj._task_vars = task_vars
    ActionModule_instance = ActionModule(task=Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert(ActionModule_instance is not None)
    # Testing get_action_args_with_defaults
    module = 'ansible.legacy.service'
    context = ActionModule_instance._shared_loader_obj.module_loader.find_plugin_with_context(module, collection_list=None)
    module_args = dict

# Generated at 2022-06-23 08:32:26.673938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock

    Task = mock.Mock()
    Task.args = {'use': 'auto'}
    Task.delegate_to = None
    task_vars = {}

    module = ActionModule(Task)
    module.run(task_vars=task_vars, tmp=None)

# Generated at 2022-06-23 08:32:37.101535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_instance = ActionModule()
    test_instance._shared_loader_obj = AnsibleLoaderModule()
    test_instance._task.args = {'use':'auto', 'name':'testservice', 'state':'started'}
    test_instance._task.delegate_to = 'localhost'
    test_instance._task._parent = AnsibleTaskModule()
    test_instance._task._parent._play = AnsiblePlayModule()
    test_instance._task._parent._play._action_groups = []
    test_instance._supports_check_mode = 'True'
    test_instance._supports_async = 'True'
    test_instance._templar = AnsibleTemplarModule()
    test_instance._remove_tmp_path = AnsibleRemoveTmpPathModule()
    test_instance._display = Ansible

# Generated at 2022-06-23 08:32:42.562272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    example_action_module = ActionModule({'use': 'auto'})

    assert example_action_module.TRANSFERS_FILES is False
    assert example_action_module._supports_check_mode is True
    assert example_action_module._supports_async is True

# Generated at 2022-06-23 08:32:43.180401
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-23 08:32:46.366946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(loader=None, task=None, connection=None, play_context=None, shared_loader_obj=None, terminator=None)
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:32:49.674679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    g = globals()
    g['cls'] = ActionModule

    # Check if ActionModule can be instantiated
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-23 08:33:00.965488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for run method of ActionModule class.
    """
    ActionModule.TRANSFERS_FILES=False
    ActionModule.UNUSED_PARAMS={
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']
    }
    ActionModule.BUILTIN_SVC_MGR_MODULES = set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    action_module_object = ActionModule(connection=None, runner_queue=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module_object.module_defaults = {}

# Generated at 2022-06-23 08:33:08.854698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.errors import AnsibleAction, AnsibleActionFail
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.plugins.action import ActionBase

    obj = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert obj._shared_loader_obj == None
    assert obj.TRANSFERS_FILES == False



# Generated at 2022-06-23 08:33:22.696806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult

    actions = dict()
    play_context = dict()
    loader = dict()
    templar = dict()
    shared_loader_obj = dict()

    # TaskResult.run() is needed by TaskQueueManager._final_qc()
    task_result = TaskResult(
        host='host',
        task=dict(),
        action=dict(),
        task_fields=dict(),
        connection=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )


# Generated at 2022-06-23 08:33:34.186887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	import json

	# construct a mock task object
	task = TaskMock()
	task.task_vars = {"test_var1":"test_val1", "test_var2":"test_val2"}
	task.args = {"test_args1":"test_args_val1", "test_args2":"test_args_val2"}
	task.delegate_to = "delegate_to_val"
	task.async_val = "async_val"

	# Construct a mock module_loader object and insert it into the ActionModule class
	module_loader_obj = ModuleLoaderMock()
	setattr(ActionModule, "_shared_loader_obj", module_loader_obj)
	# set a connection object as well
	connection_obj = ConnectionMock()

# Generated at 2022-06-23 08:33:38.966552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate a subclass and a instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

    # test if module is present in the right path
    assert 'action_plugins.service' == ActionModule.__module__

    # test all member variables of the object
    assert hasattr(action_module, 'TRANSFERS_FILES')
    assert hasattr(action_module, 'UNUSED_PARAMS')
    assert hasattr(action_module, 'BUILTIN_SVC_MGR_MODULES')

# Generated at 2022-06-23 08:33:42.162849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Run Unit tests for run method of class ActionModule
    '''
    action = ActionModule()
    assert action.run() is not None
    assert action.run() == {}

# Generated at 2022-06-23 08:33:43.367027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-23 08:33:53.736158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import filecmp

    # Load fake data
    # When running in test mode, the real data store will not be used.
    # Instead, a fake data store is used.
    action = ActionModule(None, None, None, None)
    fake_loader = action._shared_loader_obj
    fake_loader._find_plugin = lambda a, b, c: dict()

    fake_loader._ask_pass = lambda a, b, c: None
    fake_loader._save_keys = lambda a: None
    fake_loader._add_host_overrides = lambda a, b: None
    fake_loader._add_host_vars_from_inventory = lambda a, b, c: None
    fake_loader._vault = None
    fake_loader._loader = None

    fake_loader._connection_cache = dict()

# Generated at 2022-06-23 08:33:54.721388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.run()

# Generated at 2022-06-23 08:33:57.059766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    exec(str(ActionModule.run.__code__))

# Generated at 2022-06-23 08:34:04.575782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=dict(), templar=dict(), shared_loader_obj=dict())
    assert isinstance(action_module._task, dict)
    assert isinstance(action_module._connection, dict)
    assert isinstance(action_module._templar, dict)
    assert isinstance(action_module._shared_loader_obj, dict)



# Generated at 2022-06-23 08:34:11.783968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test ActionModule class.
    """
    def TestActionModule_get_defaults_for_task_run(task):
        """
        Test_ActionModule_get_defaults_for_task_run
        """

    fake_task = type("", (object,), {'async_val': False, '_parent': 'parent', '_play': 'play', '_async_poll_delay': 15, '_async_poll_interval': 5, '_async_timeout': 300, '_task_tags': 'tags', '_role': 'role', '_role_params': 'role_params'})()

# Generated at 2022-06-23 08:34:20.463892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.stats import AggregateStats
    import ansible.constants as C
    import ansible.utils.plugin_docs as plugin_docs

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='service', use='auto', name='nginx', state='started'), register='result'),
                dict(action=dict(module='debug', msg='{{result.stdout}}'))
             ]
        )


# Generated at 2022-06-23 08:34:30.506249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    print('starting test_ActionModule_run')

    m = ActionModule()
    m._shared_loader_obj.module_loader.mock_modules = {
        'ansible.legacy.service': {
            'run': lambda self, module_name, module_args, task_vars, wrap_async: {'changed': True, 'msg': 'service is happy'},
        }
    }

    m._task.action = 'service'
    m._task.args = {
        'name': 'foo',
        'state': 'started',
        'use': 'auto',
    }
    TaskVars = type('TaskVars', (dict,), {})
    task_vars = TaskVars()

# Generated at 2022-06-23 08:34:32.589435
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(action=dict(use='auto')), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    action.run()

# Generated at 2022-06-23 08:34:39.339125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a._task.action == 'service'
    assert a._task.args == {'use': 'auto'}
    assert a.BUILTIN_SVC_MGR_MODULES == set(['sysvinit', 'service', 'openwrt_init', 'systemd'])
    assert a.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}

# Generated at 2022-06-23 08:34:39.850891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:34:41.730098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run({}) == dict(changed=False, _ansible_verbose_always=True, _ansible_no_log=False)

# Generated at 2022-06-23 08:34:51.068900
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:34:55.180572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        None,
        Task(name="unit test task", connection=None),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    assert module is not None

# Generated at 2022-06-23 08:34:56.657778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None)
    assert am != None

# Generated at 2022-06-23 08:35:03.684400
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = AnsibleModule(
        argument_spec = dict(
            name = dict(default=None, type='str'),
            use = dict(default=None, type='str'),
            state = dict(default='started', type='str'),
            enabled = dict(default=None, type='bool'),
            pattern = dict(default='', type='str'),
            runlevel = dict(default='', type='str'),
            sleep = dict(default='', type='int'),
            arguments = dict(default='', type='str'),
            args = dict(default='', type='str'),
        ),
        supports_check_mode = True,
        add_file_common_args = True
    )

    # There are four different scenarios to test. Let's start with the first one:
    # 1. when use='auto', state='started', ansible

# Generated at 2022-06-23 08:35:04.838524
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(test_ActionModule())

# Generated at 2022-06-23 08:35:14.252522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict(res='test result')
    tmp = '/test/tmp'
    task_vars = dict(res='original_result')

    # # Call run: 1
    # action_module = ActionModule()
    # res = action_module.run(tmp, task_vars)
    # assert(res == result)

    # # Call run: 2
    # action_module = ActionModule()
    # task_vars_copy = task_vars.copy()
    # res = action_module.run(tmp, task_vars_copy)
    # assert(res == result)
    # assert(task_vars == dict(res='original_result'))
    # assert(task_vars_copy == dict(res='test result'))

# Generated at 2022-06-23 08:35:18.697560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(loader=None, play_context=None, new_on_missing_args=False, new_on_missing_kwargs=False, new_run_once=False, task=None)

# Generated at 2022-06-23 08:35:22.633733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = Mock()
    mock_executor = Mock()
    mock_task = Mock()
    mock_task._parent = Mock()
    am = ActionModule(mock_loader, mock_executor, mock_task)

    assert isinstance(am, ActionModule)

# Generated at 2022-06-23 08:35:26.736300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(
        task=dict(args=dict()),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    assert a._supports_check_mode == True
    assert a._supports_async == True

# Generated at 2022-06-23 08:35:43.621992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    variable_manager = VariableManager()
    variable_manager._extra_vars = dict(service_mgr='auto')

    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=None)


# Generated at 2022-06-23 08:35:56.374607
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # mock the execute module method
    import copy

    old_execute_module = ActionModule.execute_module

    def test_execute_module(self, module_name, module_args=None, task_vars=None, wrap_async=True):

        class Result:
            def __init__(self, status=None, msg=None):
                self._result = {'changed': status, 'msg': msg}

            @property
            def result(self):
                return self._result

        if module_args.get('use') == 'auto':
            return Result(status=True, msg="No service manager found")

# Generated at 2022-06-23 08:36:05.077808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task_vars = create_autospec(TaskVars)

    mock_tmp = create_autospec(tmp)
    mock_task_vars.copy.return_value = {}

    am = ActionModule(get_action_args_with_defaults,
                      get_connection,
                      'ansible.legacy.action.service',
                      get_loader,
                      get_templar,
                      get_shared_loader_obj().module_loader)
    am._shared_loader_obj = get_shared_loader_obj()
    am._templar = get_templar()
    am._connection = get_connection()
    am._task = get_task()
    am._loader = get_loader()
    result = am.run(mock_tmp, mock_task_vars)
    assert_

# Generated at 2022-06-23 08:36:05.627502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:36:07.535760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-23 08:36:09.467380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run(tmp='tmp', task_vars='task_vars')
    assert result == None

# Generated at 2022-06-23 08:36:14.498324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {'dest': '/etc/my.cnf', 'src': 'my.cnf', 'state': 'link'}

    tmp = '/tmp'

    actions_constructor = ActionModule(ActionBase._shared_loader_obj, {})
    actions_object = actions_constructor._create_action(ActionModule, 'local_action', module_args, tmp)

    assert actions_object._supports_check_mode == True
    assert actions_object._supports_async == True
    assert actions_object._task_action == 'local_action'
    assert actions_object._task_vars == {}
    assert actions_object._task_args == module_args

# Generated at 2022-06-23 08:36:15.167263
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:36:26.731044
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    from ansible.plugins.loader import manager as plugin_manager
    from .test_module import MockModule

    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    plugin_manager.add_directory('./plugins')
    plugin_manager.add_directory('../../lib/ansible/modules/system')
    plugin_manager.add_directory('../../lib/ansible/modules/extras')

    setup_module = plugin_manager.get('setup')
    setup_module.runner = MockModule()

    facts = setup_module.run(module_args={'filter': 'ansible_service_mgr'})
    facts = facts['ansible_facts']

# Generated at 2022-06-23 08:36:27.581578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
# end unit test for method run of class ActionModule

# Generated at 2022-06-23 08:36:32.925271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = FakeConnection()
    loader = FakeDataLoader()
    templar = FakeTemplar()
    display = FakeDisplay()

    action_module = ActionModule(
        connection=connection,
        task_vars=dict(hello='world'),
        loader=loader,
        templar=templar,
        shared_loader_obj=loader,
        display=display
    )
    assert action_module

# Generated at 2022-06-23 08:36:39.243432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager

    args = dict(
        name='foo launch',
        pattern='',
        state='started',
        enabled='yes',
        sleep='',
        arguments='',
        runlevel='',
        module='',
        use='auto'
    )

    obj = ActionModule(dict(name=args['name']), variable_manager=VariableManager(), loader=None)
    assert obj._supports_check_mode
    assert obj._supports_async
    assert obj._task.args == args

# Generated at 2022-06-23 08:36:40.122294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:36:49.007770
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test 1
    print("test 1")
    module = ActionModule(None,None,None,None)
    module._task.args = dict()
    module._task.args["use"] = "auto"
    module._shared_loader_obj.module_loader.has_plugin = lambda  x: True
    module.run(None, None)
    # test 2
    print("test 2")
    module = ActionModule(None,None,None,None)
    module._task.args = dict()
    module._task.args["use"] = "auto"
    module._shared_loader_obj.module_loader.has_plugin = lambda  x: False
    module.run(None, None)
    # test 3
    print("test 3")
    module = ActionModule(None,None,None,None)
    module._task

# Generated at 2022-06-23 08:37:00.513545
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

# Generated at 2022-06-23 08:37:01.370903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:37:11.000322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Retrieve the service manager used on the remote host
    """
    # Create a new instance of AnsibleActionModule
    my_action_module = ActionModule()
    # Get the current Ansible Facts
    task_vars = my_action_module._task.ansible_facts

    task_vars = dict()

    # Execute the run method of class AnsibleActionModule and retrieve
    # the result
    result = my_action_module.run(None, task_vars)

    assert result
    #assert isinstance(result, dict)
    #assert 'ansible_facts' in result
    #assert 'ansible_service_mgr' in result['ansible_facts']

# Generated at 2022-06-23 08:37:11.391191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:37:22.565359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    import ansible.plugins.action
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 08:37:30.817401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with minimal arguments
    task_args = dict(module_name='ansible.legacy.setup',module_args=dict(gather_subset='!all', filter='ansible_service_mgr'))
    am = ActionModule(task=task_args, connection='local', play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert am._supports_check_mode is True
    assert am._supports_async is True


# Generated at 2022-06-23 08:37:31.666902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("In test_ActionModule")
    test_action_module = ActionModule()
    assert test_action_module

# Generated at 2022-06-23 08:37:37.416408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    assert am.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert am.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}

# Generated at 2022-06-23 08:37:38.434278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:37:48.170944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of AnsibleModule class
    # Create a mock object of AnsibleActionFail class
    # Create a mock object of AnsibleAction class
    # Create a mock object of AnsibleModuleDefaults class
    # Create a mock object of ActionBase class
    # Create a mock object of AnsibleModule class
    # Create a mock object of AnsibleModule class
    # Create a mock object of AnsibleModule class
    am = MagicMock(spec=AnsibleModule)
    aaf = MagicMock(spec=AnsibleActionFail)
    aa = MagicMock(spec=AnsibleAction)
    amd = MagicMock(spec=AnsibleModuleDefaults)
    ab = MagicMock(spec=ActionBase)
    aml = MagicMock(spec=AnsibleModule)
    am1 = MagicMock

# Generated at 2022-06-23 08:37:48.753259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:37:51.688533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        _ = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    except Exception:
        print("Class constructor is broken")

# Generated at 2022-06-23 08:37:52.473464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-23 08:38:03.173744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # testing default action
    m = 'ansible.legacy.service'
    args = {
        'name' : 'sshd',
        'use'  : 'auto',
    }
    action = ActionModule(m, args)
    action.run(task_vars={"ansible_facts":{'ansible_service_mgr':'systemd'}})
    assert action._task.args['use'] == m

    # testing default action
    m = 'ansible.legacy.service'
    args = {
        'name' : 'sshd',
        'use'  : 'auto',
    }
    action = ActionModule(m, args)
    action.run(task_vars={"ansible_facts":{'ansible_service_mgr':'openwrt'}})
    assert action

# Generated at 2022-06-23 08:38:14.620583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    

# Generated at 2022-06-23 08:38:15.143615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert False

# Generated at 2022-06-23 08:38:19.332110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase

    actionBase = ActionBase()
    actionModule = ActionModule()

    # Addition test for ActionBase.run call
    actionBase.run()
    actionModule.run()

# Generated at 2022-06-23 08:38:27.058361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict(
        name='foo',
        state='restarted',
        start='running',
    )

    task = dict(
        action=dict(
            module='service',
            use='auto',
        ),
        args=params
    )

    task_vars = dict(
        ansible_facts=dict(
            service_mgr="auto"
        )
    )


# Generated at 2022-06-23 08:38:35.649001
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=too-many-statements
    import ansible.constants as C
    import ansible.compat
    import ansible.utils.display
    import ansible.plugins.action
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.path import unfrackpath
    from ansible.utils.vars import merge_hash
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-23 08:38:36.209585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:38:37.140530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO write unit tests for method run of class ActionModule
    pass

# Generated at 2022-06-23 08:38:37.821233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return 'hello world'

# Generated at 2022-06-23 08:38:40.104021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert actionModule.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:38:45.737436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1
    # Test when module is 'auto'
    facts = {}
    facts['ansible_facts'] = {}
    facts['ansible_facts']['service_mgr'] = 'service'
    result = {}
    result.update(facts)
    task = MagicMock(args = {'use': 'auto'})
    tmp = None
    mock_shared_loader_obj = MagicMock()
    mock_shared_loader_obj.module_loader.has_plugin.return_value = True
    mock_shared_loader_obj.module_loader.find_plugin_with_context.return_value = mock_shared_loader_obj
    mock_shared_loader_obj.resolved_fqcn = 'resolved_fqcn'

# Generated at 2022-06-23 08:38:47.907267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of class ActionModule
    action_mock = ActionModule(
        task=dict(action=dict(module_name='service', module_args=dict(name="foo")))
    )
    # Execute run() method of  ActionModule
    action_mock.run(None, {})


# Generated at 2022-06-23 08:38:49.793240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None, None, None, None)
    assert mod != None


# Generated at 2022-06-23 08:38:59.576296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    test_task_args_facts = dict(
        name='test_service_facts',
        use='auto',
        delegate_to='localhost',
    )

    test_task_args_bad_mgr_facts = dict(
        name='test_service_bad_mgr_facts',
        use='auto',
    )

    test_task_args_bad_mgr = dict(
        name='test_service_bad_mgr',
        use='auto',
    )

   