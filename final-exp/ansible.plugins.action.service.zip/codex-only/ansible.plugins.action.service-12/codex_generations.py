

# Generated at 2022-06-23 08:29:02.278797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Fails if no action plugin is passed
    assert ActionModule('action_plugin', 'connection_plugin', 'shell_plugin', '/path/to/ansible_module', '/path/to/ansible.cfg')

# Generated at 2022-06-23 08:29:13.506660
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = 'foo loader'
    play_context = PlayContext()
    task_queue_manager = TaskQueueManager(loader=loader, inventory=InventoryManager(loader=loader), variable_manager=VariableManager(loader=loader), loader=loader)
    action = ActionModule(task=1, connection=2, _play_context=play_context, loader=loader, shared_loader_obj=3,
                          task_queue_manager=task_queue_manager)

    assert action.loader == 'foo loader'
    assert action._loader == 'foo loader'

# Generated at 2022-06-23 08:29:18.857345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # testing constructor of ActionModule
    from ansible import context
    from ansible.config.manager import ConfigManager
    config_manager = ConfigManager()

    try:
        context.CLIARGS._store = {}
        context.CLIARGS._store['action_plugins'] = './lib/ansible/plugins/action'
        action_module = ActionModule(task=None, connection=None, play_context=None, loader=None,
                                     templar=None, shared_loader_obj=None)
        # use the object of ActionModule and pass the parameters required
        # by run() method
        tmp = None
        task_vars = {}
        results = action_module.run(tmp, task_vars)
    except Exception as e:
        assert False and str(e)

# Generated at 2022-06-23 08:29:25.761546
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def __init__(self):
        self._shared_loader_obj = ""
        self._connection = ""
        self._task = ""
        self._loader = ""
        self._display = ""
        self._play_context = ""
        self._templar = ""
        self.task_vars = {}
        self._templar.template = ""
    a = test_ActionModule_run()
    a.run()

# Generated at 2022-06-23 08:29:36.465314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.block import Block

    from ansible.playbook.task import Task

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)
    play_context = PlayContext()

# Generated at 2022-06-23 08:29:47.545011
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:29:48.445197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:29:55.722394
# Unit test for constructor of class ActionModule
def test_ActionModule():
	from ansible.plugins.action.service import ActionModule
	obj = ActionModule(task=dict())
	assert obj._supports_check_mode == True
	assert obj._supports_async == True
	assert obj.TRANSFERS_FILES == False
	assert obj.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
	assert obj.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])


# Generated at 2022-06-23 08:30:00.826236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:30:01.576069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:30:13.859331
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockTemplar:
        def template(self, s):
            return s

    class MockModuleLoader:
        def has_plugin(self, x):
            return True

    class MockConnection:
        class Shell:
            tmpdir = ""
        _shell = Shell()

    class MockTask:
        async_val = True
        class AsyncWrapper:
            def __init__(self, v):
                self.v = v
            def __nonzero__(self):
                return self.v
        async_val = AsyncWrapper(False)
        module_defaults = {}
        class Args:
            use = 'auto'
            noisy = {}
        args = Args()
        _parent = None
        def update_persistent_task_var(self, x, y):
            pass

# Generated at 2022-06-23 08:30:14.720570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:30:27.188319
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dest = "/var/log/ansible"
    owner = "root"
    perms = "0666"
    for_path = dest
    for_path_regex = None
    for_path_glob = None
    ignore_errors = False
    recurse = False
    recursion_level = None
    state = "file"
    use = "auto"
    _ansible_check_mode = True
    _ansible_debug = True
    _ansible_diff = True
    _ansible_keep_remote_files = False
    _ansible_no_log = False
    ansible_pipelining = True
    ansible_ssh_common_args = None
    ansible_ssh_extra_args = None
    ansible_sftp_extra_args = None
    ansible_scp_extra

# Generated at 2022-06-23 08:30:27.836162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, {}, [])
    assert am is not None

# Generated at 2022-06-23 08:30:34.107089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES == False and am.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']} and am.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-23 08:30:37.980944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #Create an object of type ActionModule
    action_module_object = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 08:30:45.901277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # GIVEN
    class FakeModule(ActionBase):
        def __init__(self, *args, **kwargs):
            ActionBase.__init__(self, *args, **kwargs)
            self.tmp = ''

        def run(self, **kwargs):
            self.tmp = kwargs.get('tmp')

    class FakeTask(object):
        def __init__(self):
            self.args = {'use': 'auto'}

    class FakeTemplar(object):
        def __init__(self, *args, **kwargs):
            self._vars = {'ansible_facts': {'service_mgr': 'fake'}}

        def template(self, data):
            return self._vars['ansible_facts']['service_mgr']


# Generated at 2022-06-23 08:30:52.948683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test if ActionModule is properly initialized and if is_local_action method works as expected
    """
    from ansible.playbook.play_context import PlayContext

    # Make sure constructor doesn't throw any exception
    action_module = ActionModule(task=None, connection=None, play_context=PlayContext(remote_addr='127.0.0.1'), loader=None, templar=None, shared_loader_obj=None)

    assert action_module.is_local_action()

# Generated at 2022-06-23 08:30:54.098096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:31:02.623265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test constructor with given valid use value and without use value.
    """
    fixture = dict(
        action='auto',
        use='systemd',
        name='httpd',
        state='started',
        enabled=False,
    )

    ansible_action = ActionModule(task=dict(args=fixture), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = ansible_action.run(tmp=None, task_vars=None)
    assert result['msg'] == 'Systemd service unknown was not found'

# Generated at 2022-06-23 08:31:05.696410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.service import ActionModule
    action = ActionModule({'name': 'test_service'}, {}, {'connection': 'local'}, None, {})
    assert not action.supports_check_mode
    assert action.supports_async

# Generated at 2022-06-23 08:31:07.956091
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(play_context=None, new_stdin=None) != ""

# Generated at 2022-06-23 08:31:13.485174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test the constructor of class ActionModule in module ActionModule
    '''
    action_module = ActionModule(None, {})

    assert isinstance(action_module, ActionBase)
    assert action_module.TRANSFERS_FILES == False

    assert action_module.UNUSED_PARAMS['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']

# Generated at 2022-06-23 08:31:20.348421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import load_extra_vars
    import ansible.constants as C
    import os
    import tempfile

    # Fake a playbook
    pb = tempfile.TemporaryDirectory()
    os.chdir(pb.name)

    # Fake inventory
    inv = tempfile.TemporaryDirectory()
    im = InventoryManager(loader=None, sources=[])
    im.add_group('localhost')
    im.add_host(host='localhost', group='localhost')
    im.get_group('localhost').set_variable('ansible_service_mgr', 'systemd')

    task = Task()
    task.action = 'service'


# Generated at 2022-06-23 08:31:31.438771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    # Create an argument parser
    import argparse
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('arg1', type=int, help='first argument')
    parser.add_argument('arg2', type=int, help='second argument')

    # Parse arguments
    args = parser.parse_args()

    # Define the arguments
    task_vars = dict(
        ansible_facts=dict(
            ansible_service_mgr='auto'
        ),
        hostvars=dict(
            localhost=dict(
                ansible_facts=dict(
                    ansible_service_mgr='auto'
                )
            )
        )
    )
    tmp = None
    _display = None
    _

# Generated at 2022-06-23 08:31:35.531434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # on creation of ActionModule instance, we do not check whether _shared_loader_obj is initialized or not
    am = ActionModule()

    # check whether instance object is created or not
    assert am is not None

# Generated at 2022-06-23 08:31:37.394182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: add test for ActionModule.run method
    pass

# Generated at 2022-06-23 08:31:46.299473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import builtins
    import sys
    def test_templar_template(*args, **kwargs):
        assert args == ('{{ansible_facts.service_mgr}}',)
        return 'auto'
    setattr(builtins, '__builtins__', {'open': lambda path: path, 'FileNotFoundError': FileNotFoundError})
    sys.modules['ansible'] = type('module', (object,), {'errors': {'AnsibleAction': AnsibleAction, 'AnsibleActionFail': AnsibleActionFail}})
    sys.modules['ansible.utils.context_objects'] = type('module', (object,), {'TaskVars': type('TaskVars', (object,), {'task_vars': {}})})

# Generated at 2022-06-23 08:31:56.665050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    # test setup
    fake_loader = DictDataLoader({})
    task_vars = dict(
        ansible_facts=dict(
            service_mgr='systemd'
        ),
        ansible_check_mode=False,
    )
    play_context = dict(
        check_mode=False,
    )
    connection = Connection(None)
    tmp = '/home/ansible/fake_tmp'
    become_method = 'sudo'
    become_user = 'root'
    become_exe = '/bin/sudo'

    # test the run method of the ActionModule class with a simple command
    # test 1: testing a simple command that is expect to succeed
    task_args = dict(
        use='auto',
        name='mysql',
        state='reloaded',
    )
   

# Generated at 2022-06-23 08:32:05.597899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockModule(object):
        CALL_NAME = '_execute_module'
        CALL_COUNT = 0

        @classmethod
        def _execute_module(cls, *args, **kwargs):
            cls.CALL_COUNT += 1

    class MockTask(object):
        def __init__(self, args):
            self.args = args

    class MockTaskExecutor(object):
        def __init__(self, task_vars):
            self._task_vars = task_vars
            self._task = MockTask(task_vars)

        def _get_task_vars(self, task_vars):
            return self._task_vars

        def _initialize_task_vars(self, task_vars):
            return self._task_vars


# Generated at 2022-06-23 08:32:14.610976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = unittest2.mock.MagicMock()
    host.get_vars = unittest2.mock.MagicMock(return_value={'foo': 'bar'})
    task = unittest2.mock.MagicMock()
    task.async_val = False
    tm = unittest2.mock.MagicMock()
    tm.has_plugin = unittest2.mock.MagicMock()
    tm.has_plugin.return_value = True

    # Case 1 : test case when module == auto, exe_module raise an exception
    # (facts['ansible_service_mgr'] is not available)
    m = unittest2.mock.MagicMock()
    m.run = unittest2.mock.MagicMock()
   

# Generated at 2022-06-23 08:32:17.207088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible_collections.ansible.legacy.plugins.action.service import ActionModule
    result = ActionModule()
    assert result is not None

# Generated at 2022-06-23 08:32:19.405439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    am = ansible.plugins.action.ActionModule(None, None, None, None, None, None)
    return True

# Generated at 2022-06-23 08:32:19.988985
# Unit test for constructor of class ActionModule
def test_ActionModule():
	pass

# Generated at 2022-06-23 08:32:20.549795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 0

# Generated at 2022-06-23 08:32:22.450566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    constructor test
    '''
    action_module_obj = ActionModule()
    assert isinstance(action_module_obj, ActionModule)

# Generated at 2022-06-23 08:32:23.058527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-23 08:32:34.884820
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import os

    from ansible.plugins.callback.default import CallbackModule
    from ansible.plugins.action.service import ActionModule

    # Setup test action & connection
    action = ActionModule(
        connection=None,
        task_vars={'test_value': 123},
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )

    CallbackModule()

    # Setup test command
    test_command = [
        os.path.dirname(os.path.realpath(__file__)) + "/files/ansible_service_mgr_test.sh",
        "run", "auto", "/tmp/ansible_service_mgr_test.log"
    ]

    # Test module with command

# Generated at 2022-06-23 08:32:46.217912
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule(name='service', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_module._supports_check_mode
    assert action_module._supports_async
    assert action_module._task.async_val == False
    assert action_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert action_module.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }

# Generated at 2022-06-23 08:32:48.962526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test empty constructor
    am = ActionModule()
    assert am is not None

    # Test constructor with task argument
    am = ActionModule(dict(action='service'))
    assert am is not None

# Generated at 2022-06-23 08:32:49.786397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:32:54.512495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MyActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            print(tmp, task_vars)
    a = MyActionModule(task={'args': {'use': 'auto'}}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    a.run()

# Generated at 2022-06-23 08:32:57.205867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task = None)
    print (module)

# Unit tets for ActionBase

# Generated at 2022-06-23 08:32:58.091134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(None, None)

# Generated at 2022-06-23 08:33:09.826758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(FakeActionModule, self).run(tmp, task_vars)

        def _execute_module(self, module_name=None, module_args=None, task_vars=None, wrap_async=None):
            return {}

    module = FakeActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    # Assume 'action' is a dict
    assert isinstance(module._get_action_args(dict()), dict)

# Generated at 2022-06-23 08:33:10.854981
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action is not None

# Test for run method of class ActionModule

# Generated at 2022-06-23 08:33:22.740326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    This function is to test the run function in class ActionModule
    '''
    # Create an instance of ActionModule
    module_instance = ActionModule()

    # Create an instance of AnsibleAction and set result
    ansibleaction_instance = AnsibleAction()
    ansibleaction_instance.result = {'changed': True, 'module_stderr': '', 'module_stdout': '', 'reboot_required': False, 'stderr': '', 'stdout_lines': []}

    # Create an instance of ActionBase
    ActionBase_instance = ActionBase()
    actionbase_result = {}

    # Create an instance of AnsibleLoader
    loader_instance = AnsibleLoader()
    
    # Create an instance of AnsibleConnection
    connection_instance = AnsibleConnection()

    # Create an instance of AnsibleShell

# Generated at 2022-06-23 08:33:26.080634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def _execute_module(self, module_name, tmp=None, task_vars=None, wrap_async=None):
            print ("Executing module")
            return super(ActionModule, self)._execute_module(module_name, tmp, task_vars, wrap_async)
    assert TestActionModule


# Generated at 2022-06-23 08:33:36.457102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._shared_loader_obj = object()
    action_module._connection = object()
    action_module._connection._shell = object()
    action_module._connection._shell.tmpdir = ''
    action_module._task = object()
    action_module._task.module_defaults = {}
    action_module._task._parent = object()
    action_module._task._parent._play = object()
    action_module._task.async_val = False
    action_module._task.args = {}
    action_module._task.args['use'] = 'auto'
    action_module._task.delegate_to = None
    action_module._task.collections = None
    action_module._templar = object()
    action_module._display = object()

   

# Generated at 2022-06-23 08:33:48.250936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.utils.vars import AnsibleVars
    from ansible.utils.vars import load_extra_vars
    from ansible.vars import VariableManager
    from ansible.playbook.block import Block
    from ansible.template import Templar

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='custom', args=dict(use='service')))
            ]
        )

    # Create a play to wrap the task
    play = Play().load(play_source, variable_manager=VariableManager(), loader=None)

    # Create a task to wrap the action module


# Generated at 2022-06-23 08:33:49.292614
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass


# Generated at 2022-06-23 08:34:01.353260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task:
        def __init__(self):
            self.args = dict()
            self.async_val = False

    class Connection:
        def __init__(self):
            self.tmpdir = 'tmpdir'

    class PlayContext:
        def __init__(self):
            self.remote_addr = 'remote_addr'

    class Play:
        def __init__(self):
            self.context = PlayContext()

    class TaskExecutor:
        def __init__(self):
            self.result = dict()

    class PlayExecutor:
        def __init__(self):
            self.hostvars = dict()
            self.hostvars['hostvars'] = dict()
            self.result = dict()


# Generated at 2022-06-23 08:34:02.160067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(None, None, None)

# Generated at 2022-06-23 08:34:02.975973
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-23 08:34:07.032459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    name = 'unit_test_name'
    shared_loader_obj = object()
    task_loader_obj = object()
    play_context_obj = object()
    new_stdin_obj = object()
    loader_obj = object()
    templar_obj = object()
    connection = object()
    connection_loader = object()
    class_temp = ActionModule(name, shared_loader_obj, task_loader_obj, play_context_obj, new_stdin_obj, loader_obj, templar_obj, connection, connection_loader)
    assert class_temp is not None
    assert name == class_temp._name
    assert shared_loader_obj == class_temp._shared_loader_obj
    assert task_loader_obj == class_temp._task_loader
    assert play_context_obj == class_

# Generated at 2022-06-23 08:34:16.860696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Constructing object of class ActionModule")
    test_obj =  ActionModule('test', 'test2', 'test3', 'test4')
    print("Printing values of object variables of ActionModule")
    print("self:\t",test_obj._connection)
    print("self:\t",test_obj._task)
    print("self:\t",test_obj._connection_info)
    print("self:\t",test_obj._data)
    assert test_obj is not None
    assert test_obj._connection is not None
    assert test_obj._task is not None
    assert test_obj._connection_info is not None
    assert test_obj._data is not None


# Generated at 2022-06-23 08:34:27.597684
# Unit test for constructor of class ActionModule
def test_ActionModule(): 
    res = {'ansible_facts': {'service_mgr': 'auto'}}
    task = {'args': {'name': 'test'}}
    connection = {'_shell': {'tmpdir': 'test'}, '_play_context': {'check_mode': False, 'become': False, 'become_method': None}}
    display = {'vvvv': 'test'}
    templar = {'template': 'test'}
    svc = ActionModule(task, connection, display, templar)
    if svc._task.args['name'] == 'test' and svc._task.args['name'] == 'test':
        print('ActionModule Constructor Test Passed')

# Generated at 2022-06-23 08:34:39.484534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import ensure_str

    action = ActionModule(dict(), dict())
    assert action.TRANSFERS_FILES is False

    assert isinstance(action.UNUSED_PARAMS, dict)
    assert action.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }

    assert isinstance(action.BUILTIN_SVC_MGR_MODULES, set)
    assert len(action.BUILTIN_SVC_MGR_MODULES) == 4

    assert len(action._shared_loader_obj.module_loader.all(class_only=True)) == 0


# Generated at 2022-06-23 08:34:41.584207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:34:45.833722
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_args = {'name': 'nginx', 'state': 'started'}
    my_action_module = ActionModule(ActionBase(), task_args)
    assert my_action_module._task.action == "service"
    assert my_action_module._task.args == task_args

# Generated at 2022-06-23 08:34:59.305058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionTask:
        def __init__(self, args={}, delegate_to=None):
            self.args = args
            self.delegate_to = delegate_to

    class ActionModule:
        def __init__(self, task):
            self._task = task

    class ActionBase:
        def __init__(self, task):
            self._task = task
            self._templar = None

        def run(self, tmp=None, task_vars=None):
            return self._task.args

    tmp = "default"
    task_vars = {}

    class MockModuleFinder:
        def has_plugin(self, module):
            if module == "service":
                return True
            else:
                return False


# Generated at 2022-06-23 08:35:09.454203
# Unit test for constructor of class ActionModule
def test_ActionModule():

    mod = ActionModule()
    assert mod._task.async_val == True # Async val is true by default
    assert mod._task.delegate_to == None # Task delegate is None by default
    assert mod._task.role_name == None # Task role_name is None by default

    mod = ActionModule(task={"async": False, "delegate_to": "test_host", "role_name": "test_role"})
    assert mod._task.async_val == False
    assert mod._task.delegate_to == "test_host"
    assert mod._task.role_name == "test_role"

# Generated at 2022-06-23 08:35:12.354112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    # test deom
    assert task_vars == task_vars
    # assert task_vars == ''



# Generated at 2022-06-23 08:35:18.494532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor

    # create a dummy args dictionary
    args = dict(
        name="nginx",
        state="restarted",
        pattern="",
        runlevel="",
        sleep="",
        arguments="",
        args="",
        use="auto",
    )

    # create a dummy _templar
    _templar = dict()

    # create a dummy task object

# Generated at 2022-06-23 08:35:21.111071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test case for method run of class ActionModule
    """
    action = ActionModule()
    module = action.run()
    assert module is not None

# Generated at 2022-06-23 08:35:22.717788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(None, None, None)
    assert isinstance(m, ActionModule)

# Generated at 2022-06-23 08:35:24.153626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(action=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-23 08:35:31.552266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    in_args = [
        'service',
        'use=auto',
        'name=foobar'
    ]
    task_name = "service"
    task_args = {}
    task_vars = {}
    action = ActionModule(task_name, task_args, task_vars)

    _shared_loader_obj = type('Loader', (object,), {'module_loader': type('ModuleLoader', (object,), {'find_plugin': lambda self: None})})
    _task = type('Task', (object,), {'args': {'use': 'auto', 'name': 'foobar'}, '_parent': type('Play', (object,), {'_action_groups': {}})})
    _play_context = type('PlayContext', (object,), {'available_variables': dict()})


# Generated at 2022-06-23 08:35:35.727361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert action_module is not None

# Generated at 2022-06-23 08:35:46.570169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: for now, only testing successful cases. Need to rework and add tests for failed cases
    from ansible.module_utils.facts.service_mgr.systemd import Facts as systemd_facts
    from ansible.module_utils.facts.service_mgr.sysvinit import Facts as sysvinit_facts
    from ansible.module_utils.facts.service_mgr.openwrt.init import Facts as openwrt_init_facts
    from unittest import TestCase

    # create class with mocked methods
    class ModuleManager:
        class ServiceModule:
            def __init__(self, *args, **kwargs):
                self.module_loader = ModuleLoader()


# Generated at 2022-06-23 08:35:55.495843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the method run of class ActionModule
    """

    # Test the var module_defaults
    module_defaults = dict()

    # Test the var tmp
    tmp = None

    # Test the var task_vars
    task_vars = dict()

    # Test the object ActionModule
    actionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = actionModule.run(tmp, task_vars)
    assert result == {}

# Generated at 2022-06-23 08:35:55.975562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:36:04.443213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostvars = {
        'ansible_facts': {
            'service_mgr': 'auto'
        }
    }

    action_module = ActionModule(
        task={
            'delegate_to': 'localhost',
            'args': {
                'use': 'auto'
            }
        },
        connection={
            '_shell': {
                'tmpdir': '/tmp'
            }
        },
        shared_loader_obj=__import__('ansible.plugins.loader'),
        templar=__import__('ansible.parsing.yaml.objects').AnsibleBaseYAMLObject.from_dict({
            'hostvars': hostvars
        })
    )
    action_module.run()

# Generated at 2022-06-23 08:36:12.695840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = Connection(None)
    from ansible.release import __version__
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.set_host_variable(connection, 'ansible_facts', {'service_mgr': 'auto'})
    variable_manager.set_host_variable(connection, 'ansible_version', {'full': __version__, 'version': __version__[:3]})

    task = Task()
    task.context = {'connection': connection, 'variable_manager': variable_manager, 'loader': loader}
    task.name = 'auto'
    task.action = 'auto'
    task.async_val = 42

    task._executor = 'pnet_raw'
    task._role = None
    task._task = task
    task._play

# Generated at 2022-06-23 08:36:25.144518
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ansible_facts = dict()
    fake_templar = FakeTemplar({'ansible_facts': ansible_facts})

    # test 'auto' module
    fake_task = FakeTask(
        dict(use='auto', name='httpd'),
        dict(ansible_facts=dict(service_mgr='auto'))
    )
    fake_loader = FakeLoader({
        'ansible.legacy.setup': FakeModule(dict(), dict(ansible_facts=dict(ansible_service_mgr='systemd'))),
        'ansible.legacy.service': FakeModule(dict(), dict(changed=True))
    })
    fake_display = FakeDisplay()

# Generated at 2022-06-23 08:36:26.194357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)._task.action == 'service'

# Generated at 2022-06-23 08:36:28.145779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    # noinspection PyProtectedMember
    assert module._supports_check_mode == True
    assert module._supports_async == True

# Generated at 2022-06-23 08:36:31.865987
# Unit test for constructor of class ActionModule
def test_ActionModule():
   # Construct the object
   module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
   assert module is not None
   assert isinstance(module, ActionModule)


# Generated at 2022-06-23 08:36:39.184928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockTemplar:
        def __init__(self):
            self.counter = 0

        def template(self, template):
            self.counter += 1
            return template

    class MockDisplay:
        def __init__(self):
            self.counter = 0
            self.debug_called = False

        def debug(self, msg):
            self.debug_called = True

        def warning(self, msg):
            self.counter += msg.count('Ignoring')

        def vvvv(self, msg):
            self.counter += msg.count('Running')

    class MockTask:
        def __init__(self, args={}, delegate_to=None, async_val=None):
            self.args = args
            self.delegate_to = delegate_to
            self.async_val = async_val



# Generated at 2022-06-23 08:36:43.598366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    task_result = TaskResult(host="localhost", task={}, result={})
    action_mod = ActionModule(task_result=task_result)
    assert action_mod.run(tmp=None, task_vars=None) == task_result.result

# Generated at 2022-06-23 08:36:52.440029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize mock of object ActionBase
    action_base = ActionBase()

    action_base._shared_loader_obj = set()

    class task:
        args = {'use': 'auto'}

    # Set up attr of ActionBase
    action_base._task = task()

    # Initialize mock of object ActionModule
    action_module = ActionModule()

    # Set up attr of ActionModule
    action_module._display = action_base._display
    action_module._shared_loader_obj = action_base._shared_loader_obj
    action_module._task = action_base._task

    # Call method run of class ActionModule
    result = action_module.run(tmp=None, task_vars=None)

    # Assert
    assert result == dict()

# Generated at 2022-06-23 08:36:57.309993
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test assigning attribute 'TRANSFERS_FILES' in class ActionModule
    assert action.TRANSFERS_FILES == False

    action.run()

# Generated at 2022-06-23 08:37:09.707988
# Unit test for constructor of class ActionModule
def test_ActionModule():

    """This is a unit test for ActionModule constructor"""
    a = ActionModule()
    if not isinstance(a, ActionBase):
        raise TypeError("Failed to create instance of ActionBase")
    if not a.TRANSFERS_FILES:
        raise ValueError("Invalid TRANSFERS_FILES value")
    if a.UNUSED_PARAMS['systemd'] != ['pattern', 'runlevel', 'sleep', 'arguments', 'args']:
        raise ValueError("Invalid UNUSED_PARAMS value")
    if a.BUILTIN_SVC_MGR_MODULES != set(['openwrt_init', 'service', 'systemd', 'sysvinit']):
        raise ValueError("Invalid BUILTIN_SVC_MGR_MODULES value")


# Generated at 2022-06-23 08:37:21.712049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_result = dict(invocation="invocation")
    result = dict(ansible_facts=dict(service_mgr="openwrt_init"))
    module_return = dict(result=result)
    module_kv = dict(module_name="module_name",module_args="module_args",module_defaults="module_defaults")
    task_vars = dict(task_vars="task_vars")
    tmp = "tmp"
    task = "task"
    connection = "connection"
    loader_obj = "loader_obj"
    display = "display"
    templar = "templar"

    M = ActionModule(task, connection, tmp, task_vars, loader_obj, display, templar)
    mr = M.run(tmp, task_vars)
   

# Generated at 2022-06-23 08:37:24.351745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action
    return

# Generated at 2022-06-23 08:37:25.486615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run(tmp='test', task_vars='task_vars')

# Generated at 2022-06-23 08:37:30.648497
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Execute command 'ansible-playbook --version'
    # and get the version of ansible
    cmd = [ 'ansible-playbook', '--version' ]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    (output, err) = p.communicate()
    version_string = output.decode('utf-8').split('\n')[0]
    version = float(version_string.split()[1])

    # Create a dict
    fake_loader = DictDataLoader({})
    # Create a task from dict
    fake_task = Task()
    fake_task_vars = dict()

    # Create a play from dict

# Generated at 2022-06-23 08:37:33.913413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_action_module = ActionModule(None,None,None)
    print(my_action_module)

# Generated at 2022-06-23 08:37:40.984957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Constructor of ActionModule class.
    '''
    module = ActionModule(
        task=dict(
            action=dict(
                args=dict(),
            ),
        ),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert module._task == dict(
        action=dict(
            args=dict(),
        ),
    )

    assert module._connection == dict()

    assert module._play_context == dict()

    assert module._loader is None

    assert module._templar is None

    assert module._shared_loader_obj is None



# Generated at 2022-06-23 08:37:41.590465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:37:50.034141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    modules_mock = {}
    paths_mock = {}
    loader_mock = _Loader(modules_mock, paths_mock)
    results_mock = {
        "ansible_facts": {
            "service_mgr": "auto"
        },
        "changed": False,
        "_ansible_no_log": True,
        "invocation": {
            "module_args": {
                "gather_subset": "!all",
                "filter": "ansible_service_mgr"
            }
        }
    }
    module_mock = _ModuleMock({}, results_mock)
    module_mock.has_plugin = lambda x: True
    executor_mock = _Executor({'module_name': module_mock})

    task_mock = _

# Generated at 2022-06-23 08:37:51.284261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for ActionModule.run
    raise NotImplementedError()

# Generated at 2022-06-23 08:38:02.685031
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:38:10.575117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Use constructor to create ActionModule object
    action_module_obj = ActionModule(connection=None,
                                    play_context=None,
                                    loader=None,
                                    templar=None,
                                    shared_loader_obj=None)
    
    assert isinstance(action_module_obj, ActionBase)
    assert isinstance(action_module_obj, ActionModule)


# Generated at 2022-06-23 08:38:20.928745
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set up module
    set_module_args({"name": "coucou", "state": "started", "enabled": "yes", "use": "auto"})
    action_module = ActionModule()

    # set up mocked AnsibleModule with parameters

# Generated at 2022-06-23 08:38:22.485402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test the code of class ActionModule
    ## Execute the run method of class ActionModule
    pass

# Generated at 2022-06-23 08:38:23.187481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:38:27.147200
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert obj is not None

# Generated at 2022-06-23 08:38:35.740785
# Unit test for constructor of class ActionModule
def test_ActionModule():

    mock_shared_loader_obj = Mock()
    mock_task_obj = Mock()
    mock_connection_obj = Mock()

    mock_task_obj.async_val = 4
    mock_task_obj.register = 'ansible'
    mock_task_obj.action = 'shell'
    mock_task_obj.args = {'use': 'auto'}
    mock_task_obj.delegate_to = None

    am = ActionModule(mock_shared_loader_obj, mock_task_obj, mock_connection_obj)
    assert am is not None

# Generated at 2022-06-23 08:38:45.291281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_fact_1=dict(argument_var_1=1, argument_var_2='test'),
        ansible_fact_2=dict(argument_var_3='test2')
    )

# Generated at 2022-06-23 08:38:45.749399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:38:46.131226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:38:50.183577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test defaults
    mock_task = None
    mock_connection = None
    task_vars = dict(
        ansible_facts=dict(
            service_mgr='auto'
        ),
    )
    tmp = None
    am = ActionModule(mock_task, mock_connection, task_vars, tmp)
    am.BUILTIN_SVC_MGR_MODULES = []
    result = am.run(tmp=tmp, task_vars=task_vars)
    # Correct ActionModule is called
    assert result['module_name'] == 'ansible.legacy.service'
    # No use is passed
    assert 'use' not in result['module_args']
    # Service name is an argument
    assert result['module_args']['name'] == 'auto'

    # Test an

# Generated at 2022-06-23 08:38:59.091173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES is False, "Default value of ActionModule.TRANSFERS_FILES should be False"
    assert am.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }, "Default value of ActionModule.UNUSED_PARAMS should be {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],}"

# Generated at 2022-06-23 08:39:03.833722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # init vars
    task_vars = {}
    tmp = None
    # deploy templet
    templet_templeter = Templeter(task_vars, tmp, 'auto')
    # do test
    assert templet_templeter.run() == None

