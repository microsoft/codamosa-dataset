

# Generated at 2022-06-21 02:50:11.460859
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Just instantiate the class with no data to ensure init works
    action_plugin = ActionModule(None, None, None, None, None)
    assert isinstance(action_plugin, ActionModule)

    # Now call run function
    result = action_plugin.run()

    # Expected Output:
    # msg: Could not detect which service manager to use. Try gathering facts or setting the "use" option.
    # failed: True
    assert result['failed'] == True
    assert result['msg'] == 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.'

# Generated at 2022-06-21 02:50:17.790842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.runner.connection_plugins.local import Connection
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host

    connection = Connection()
    host = Host(name='host')
    play = Play()
    task= Task()
    task.name = 'name'
    result = ActionModule(connection, host, play, task, loader=None, shared_loader_obj=None, templar=None, passwords=None)
    assert (type(result) == ActionModule)

# Generated at 2022-06-21 02:50:27.200703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = Connection()
    module_loader = None
    play_context = PlayContext()
    play_context._task = Task()
    play_context._task._task = Task()
    play_context._task._task.args = {}
    play_context._task._task.args['name'] = 'the-name'
    play_context._task._task.action = 'the-action'
    play_context._task._task.async_val = 'the-async-val'
    play_context._task._task.delegate_to = 'the-delegate-to'
    play_context._task._task.become = 'the-become'
    play_context._task._task.become_method = 'the-become-method'

# Generated at 2022-06-21 02:50:36.186778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import collections
    import json
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar

    mock_task_args = collections.namedtuple('_', ['get'])(lambda x, y: {'use': 'auto'})
    mock_ds = json.dumps({'ansible_service_mgr': 'openwrt_init', 'ansible_facts': {'service_mgr': 'openwrt_init'}})
    mock_ds_bytes = to_bytes(mock_ds)
    mock_shared_loader_obj = collections.namedtuple('_', ['module_loader', 'path_loader'])(
        collections.namedtuple('_', ['has_plugin'])(lambda x: True), collections.namedtuple('_', ['search_path'])(lambda x: None))

# Generated at 2022-06-21 02:50:42.735354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #
    # Test creating ActionModule with argument data to satisfy 'run' method
    #
    import ansible.plugins.action.service
    data = dict(
        ANSIBLE_MODULE_ARGS=dict(
            name='httpd',
            state='started',
        ),
    )

    am = ansible.plugins.action.service.ActionModule(
        task=data,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert am is not None
    return am

# Run the unit test
#test_ActionModule()

# Generated at 2022-06-21 02:50:43.159244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:46.578955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ansible.modules.system.service.ActionModule(
        task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=dict())
    assert isinstance(module, ansible.modules.system.service.ActionModule)
    assert module._task == dict()
    assert module._connection == dict()
    assert module._play_context == dict()
    assert module._loader == None
    assert module._shared_loader_obj == dict()
    assert module._templar == None



# Generated at 2022-06-21 02:50:47.366444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:48.243212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 1==1

# Generated at 2022-06-21 02:50:49.116524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:56.931146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:02.170327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Use a try, except to make sure that there are no errors in the class
    try:
        # Create object
        class object1:
            def __init__(self, value):
                self.value = value
        # Testing the constructor of class ActionModule
        actionmodule = ActionModule(object1("[{'task': {'args': {'use': 'auto'}}}]"))
    except:
        # There are errors
        print("Error in ActionModule class.")
    else:
        # No errors
        print("ActionModule class ran without errors.")

# Test the class with a testing function
test_ActionModule()

# Generated at 2022-06-21 02:51:14.000551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.task_docs import TaskError, ActionDocs
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins import action_loader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.stats import AggregateStats
    from ansible.utils.vars import AnsibleVars
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleAction, AnsibleActionFail

    # Initialize the class
    display = Display()


# Generated at 2022-06-21 02:51:18.357954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # action = ActionModule('./abc/def.py', '/tmp/ansible', 'test_task', 'test_role')
    pass


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:51:24.476534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('In test_ActionModule_run')
    action = ActionModule()
    # Check if 'use' field of args is set to auto.
    action._task.args = {'use': 'auto'}
    # Execute run method of class ActionModule.
    # The ansible_facts field 'ansible_service_mgr' in delegate host's facts is set to auto.
    res = action.run({}, {'hostvars': {'delegate_to': {'ansible_facts': {'ansible_service_mgr': 'auto'}}}})
    assert res['failed'] == False
    assert res['invocation']['module_name'] == 'ansible.legacy.service'


# Generated at 2022-06-21 02:51:33.095349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import re
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager('/tmp/hosts', [], [])
    variables = VariableManager()
    
    data = dict(use='auto', name='test', state='started')
    data['use'] = 'auto'
    data['name'] = 'test'
    data['state'] = 'started'
    p = PlayContext()
    tqm = TaskQueueManager(inventory=inventory, variable_manager=variables, loader=None, options=None, passwords=None, stdout_callback=None)
    a = ActionModule(1, data, p, tqm)

# Generated at 2022-06-21 02:51:34.176925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:44.707165
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    play_context = PlayContext()

    play_context.remote_addr = '127.0.0.1'
    play_context.network_os = 'Network_os'
    play_context.remote_user = 'vagrant'
    play_context.become = True
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'
    play_context.verbosity = 3

    play_context.python_interpreter = '/usr/bin/python'

    mock_task = Mock()

# Generated at 2022-06-21 02:51:47.860184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:51:55.506477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # the module and class module_needs_subclass is used because it
    # is a valid module name, and the class name is a valid module class.
    # using the actual ActionModule leads to mocking and more trouble.
    from ansible.module_utils.module_needs_subclass import module_needs_subclass
    # the constructor needs a valid task object.
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    task = Task()
    task.args = {'name': 'the_name', 'use': 'the_use'}
    task._connection = 'mock_connection'
    play_context = PlayContext()
    play_context._listen = 'localhost'
    play_context.network_os = 'os_facts'

# Generated at 2022-06-21 02:52:08.796470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 02:52:09.700246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:16.630250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = AnsibleModule(None)
    module_path = '/home/user/ansible/'
    import sys
    if module_path is not None:
        sys.path.insert(0, module_path)

    from ansible import context
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    am = ActionModule(m, '', '', {}, {'foo': 'bar'})
    am._load_name = 'ActionModule'
    am._shared_loader_obj = AnsibleCollectionLoader()
    context.CLIARGS = {'module_path': '/home/user/ansible/lib/ansible/modules/network/zyxel'}
    am._task.args = {'use': 'zyxel'}

# Generated at 2022-06-21 02:52:18.599328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(connection=None, task=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:52:19.164876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:52:22.252307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    print('test_ActionModule_run')
    ###########################################
    # TODO
    ###########################################

###############################################################################


# Generated at 2022-06-21 02:52:33.905857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.executor.task_result

    global module_result #pylint: disable=global-statement
    module_result = dict(exception=dict(), result=dict())

    def get_module_result():
        return module_result

    def execute_module(module_name, module_args, task_vars, wrap_async):
        global module_result #pylint: disable=global-statement
        module_result['exception'] = None
        module_result['result'] = dict(changed=True, msg='success')

        return module_result

    class DummyTask:
        def __init__(self):
            self.args = {'use': 'auto', 'name': 'httpd'}

    class DummyExecutor:
        def __init__(self):
            self._shared_loader_obj

# Generated at 2022-06-21 02:52:40.277657
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.compat.tests import unittest

    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.plugins.loader import shared_loader_obj

    # Create action module instances
    action_module = ActionModule(shared_loader_obj=shared_loader_obj, task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=shared_loader_obj)
    action_module._execute_module = lambda *args, **kwargs: True
    action_module._task.args = {'use': 'auto', 'name': 'test'}
    action_module._task.async_val = False
    action_module._remove_tmp_path = lambda tmp: None

    # Create a service manager fact collector

# Generated at 2022-06-21 02:52:41.549773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:43.835529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_ = ActionModule({}, {}, {})
    module_.run() == None

# Generated at 2022-06-21 02:53:09.548471
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert(ActionModule(1,1,1,1))

# Generated at 2022-06-21 02:53:17.474345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Construct a task object to use the _execute_module method of the class
    loader = 'test'
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'test': 'test'}
    loader = 'test'

    play_context = PlayContext()

    mytask = Task()
    mytask.context = play_context
    mytask.action = 'shell'

# Generated at 2022-06-21 02:53:18.387166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule.run(None, None) is None

# Generated at 2022-06-21 02:53:20.605585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: mock _execute_module, have it return a different dictionary based on arguments.
    pass

# Generated at 2022-06-21 02:53:21.444681
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:53:25.258943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    res = am.run()
    assert res['failed']
    #TODO: Add a test case where facts are present and service manager can be detected

# Generated at 2022-06-21 02:53:26.547335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    print('Inside run method: ', module.run())

# Generated at 2022-06-21 02:53:36.531372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule.'''
    import os
    import shutil
    import tempfile
    import textwrap
    import unittest

    try:
        from unittest import mock
    except ImportError:
        import mock

    import ansible.executor.module_common as module_common
    import ansible.plugins.action as action
    import ansible.plugins.loader as loader

    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves import cStringIO

    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task


# Generated at 2022-06-21 02:53:42.518351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task = dict(),
        connection = dict(),
        play_context = dict(),
        loader=None,  # module_loader is not needed by our test
        shared_loader_obj = dict(),
        tempdir = dict(),
        display = dict()
    )
    # Mock the _execute_module method
    module._execute_module = MagicMock(return_value=dict())

    # Run the method
    result = module.run()

    # assert that the _execute_module method has been called
    assert module._execute_module.called

    # the result should be of type dict
    assert isinstance(result, dict)

# Generated at 2022-06-21 02:53:44.011563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:54:40.954459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    class TestTask(Task):
        def __init__(self):
            self._parent = PlayContext()
            # TODO: add collections

    task1=TestTask()
    task1._parent._play._action_groups= []
    task1.module_defaults=dict()
    task1.module_defaults['_ansible_verbosity'] = 0
    task1.action = 'auto'
    task1.delegate_to = None
    task1.async_val = None
    task1.async_seconds = None
    task1.loop = None
    task1

# Generated at 2022-06-21 02:54:41.792316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct an instance of class ActionModule
    action_module = ActionModule()


# Generated at 2022-06-21 02:54:51.077235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    #from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser

    inventory = InventoryManager(Loader=InventoryParser)
    variable_manager = VariableManager(Loader=None, inventory=inventory)

    # Load action

# Generated at 2022-06-21 02:55:00.501934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # class ActionBase
    class ActionBase_Class():
        _task = {
            'args':
                {
                    "use": "auto",
                    "name": "foo",
                    "state": "restarted",
                }
        }
        # class Ansible
        class Ansible():
            # class Runner
            class Runner():
                # class ActionModule
                class ActionModule():
                    # class AnsibleAction
                    class AnsibleAction():
                        def __init__(self, result):
                            self.result = result

                    TRANSFERS_FILES = False

                    UNUSED_PARAMS = {
                        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
                    }

                    # HACK: list of unqualified service manager names that are/were built-in, we'll prefix these with `

# Generated at 2022-06-21 02:55:07.124521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp, task_vars)

    assert result == {}


# Generated at 2022-06-21 02:55:12.131607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test constructor of ActionModule with parameters"""

    # Test with no parameters
    test_module = ActionModule()
    assert test_module
    assert test_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert test_module.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}

    # Test with parameters
    test_module = ActionModule()
    assert test_module
    assert test_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-21 02:55:23.539496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiating a test module
    module = ActionModule()

    # Creating a test task
    task = module._task

    # Populating the task arguments
    task.args = {'name': 'service_name', 'use': 'auto'}

    # Creating a test executor variable
    executor = {}

    # Populating the executor variable
    executor['result'] = {}

    # Instantiating a temporary variable for checking the result
    tmp = None

    try:
        # Executing the run method of class ActionModule
        result = module.run(tmp,executor)
    except TypeError:
        pass

    # Asserting the result of the run method

# Generated at 2022-06-21 02:55:33.564564
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import random
    from ansible.plugins.loader import action_loader

    try:
        import mock
    except ImportError:
        print("skipped tests for test_ActionModule, mock is not installed")
        raise unittest.SkipTest

    # create a mock shared loader object
    shared_loader_obj = mock.MagicMock()

    # create a mock action plugin to use for this unit test
    mock_action_plugin = mock.MagicMock()
    mock_action_plugin_instance = mock_action_plugin()
    mock_action_plugin.ActionBase = mock_action_plugin_instance

    # Add our mock action plugin to the action_loader
    action_loader.add(mock_action_plugin, 'test_ActionModule')

    # create a temporary directory to use for this unit test
    tmpdir = temp

# Generated at 2022-06-21 02:55:44.177741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Python 3.x
    try:
        from unittest.mock import Mock, patch
    # Python 2.x
    except ImportError:
        from mock import Mock, patch

    # Use a class instance as a mixin
    class Mixin(object):
        # Get the mixin's variables
        def __getitem__(self, key):
            return getattr(self, key)

    # Python 3.x
    try:
        from unittest.mock import MagicMock
    # Python 2.x
    except ImportError:
        from mock import MagicMock

    # Create a Mock module loader
    mock_loader = Mock()

    # Create a Mock module_loader
    mixin_module_loader = Mixin()
    mixin_module_loader.module_loader = mock_loader
    mixin_module_

# Generated at 2022-06-21 02:55:49.864785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(args=dict(name="apache2")), connection=dict())
    # I don't know how to test this method
    # We could mock the function to access to the variable module
    #module.run()
    #print(module.__dict__)
    #print(module.__class__)

# Generated at 2022-06-21 02:57:57.745758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dummy_loader(), task=dummy_task(), connection=dummy_connection(), play_context=dummy_play_context())

# Generated at 2022-06-21 02:57:58.382530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()

# Generated at 2022-06-21 02:58:03.153717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def _exec_module(module_name, module_args):
        return {}


# Generated at 2022-06-21 02:58:11.441813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()

    # Test service manager detection with use=auto
    actionModule._task.args = {'name': 'ntpd', 'use': 'auto'}
    actionModule._task.delegate_to = None
    actionModule._templar = {'template': lambda x: 'systemd'}
    assert actionModule.run()['module_name'] == 'ansible.legacy.systemd'
    actionModule._templar = {'template': lambda x: 'auto'}
    assert actionModule.run()['module_name'] == 'ansible.legacy.service'

    # Test service manager detection with use=auto for delegated tasks
    actionModule._task.args = {'name': 'ntpd', 'use': 'auto'}
    actionModule._task.delegate_to = "localhost"
    action

# Generated at 2022-06-21 02:58:22.572249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager



# Generated at 2022-06-21 02:58:27.894429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule(
        connection=None,
        task_uuid=None,
        ansible_loop_name=None,
        loader=None,
        templar=None,
        shares=None,
    )

# Generated at 2022-06-21 02:58:34.269431
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:58:38.659532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup mocks
    test_am = ActionModule()
    setattr(test_am, '_shared_loader_obj', Mock())
    setattr(test_am._shared_loader_obj, 'module_loader', Mock())
    setattr(test_am, '_task', Mock())
    setattr(test_am._task, 'args', { 'use': 'auto' })
    setattr(test_am, '_remove_tmp_path', Mock(spec=ActionModule._remove_tmp_path))
    setattr(test_am, '_execute_module', Mock(spec=ActionModule._execute_module))
    setattr(test_am, '_display', Mock())
    setattr(test_am._display, 'vvvv', Mock())
    setattr(test_am, '_templar', Mock())

   

# Generated at 2022-06-21 02:58:44.289438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task["args"] = dict()
    task["args"]["use"] = "test"

    am = ActionModule(task, None)
    assert am.TRANSFERS_FILES == False
    assert am.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
        }
    assert am.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-21 02:58:53.184679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(play_context=dict(become=False), new_stdin='', loader=None, shared_loader_obj=None)
    m._shared_loader_obj.module_loader.mock_add_directory('/home/username/.ansible/plugins/modules')
    m._shared_loader_obj.module_loader.mock_add_directory('/home/username/.ansible/collections/ansible_collections/ansible/builtin/plugins/modules')
    m._shared_loader_obj.module_loader.mock_add_directory('/home/username/ansible/plugins/modules')
    m._shared_loader_obj.module_loader.mock_add_directory('/home/username/ansible/collections/ansible_collections/ansible/builtin/plugins/modules')
   