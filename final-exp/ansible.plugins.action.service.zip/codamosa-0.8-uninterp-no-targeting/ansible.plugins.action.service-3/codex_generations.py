

# Generated at 2022-06-21 02:50:03.706211
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

    assert action_module is not None

# Generated at 2022-06-21 02:50:10.389598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(name='test', mode='test')
    task_vars = dict(ansible_facts=dict(service_mgr='auto'))
    _loader = 'test'
    _shared_loader_obj = 'test'
    _templar = 'test'
    _display = 'test'
    task = dict(use='test', args=dict(use='test'))
    am = ActionModule(task, _loader, _shared_loader_obj, _templar, _display)
    assert am is not None

# Generated at 2022-06-21 02:50:13.407592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule(None, None)
    assert AM

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:50:14.724889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    return obj

# Generated at 2022-06-21 02:50:19.213402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor from ansible.plugins.action.ActionBase
    x = ActionModule(
        task = {
            "args": {
                "name": "",
                "pattern": "",
                "state": "",
                "runlevel": "",
                "sleep": "",
                "systemd": "",
                "systemrestart": ""
            }
        }
    )

# Generated at 2022-06-21 02:50:19.702461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:22.322719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action.UNUSED_PARAMS['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args'], 'Failed to construct action class.'

# Generated at 2022-06-21 02:50:31.802489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    from ansible.inventory.manager import InventoryManager
    # initializing member variables
    _shared_loader_obj = None
    _task_vars = dict()
    _loader = None
    _templar = None
    _task = Task()
    _play_context =  None
    _new_stdin = None
    _connection = None
    _play = None

    # initializing test variables
    results = dict(skipped=False, failed=False, changed=False, unreachable=False, ignored=False, msg='')
    hostvars = dict()
    hostvars['test_host'] = dict()

# Generated at 2022-06-21 02:50:41.229643
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Inside test_ActionModule_run')
    result = dict()
    module = ActionModule()
    module.run(None, result)
    print('result: ' + str(result))
    assert result['failed'] == False
    assert result.get('changed', False) == True
    assert 'ansible_facts' in result
    assert result['ansible_facts']['service_mgr'] is not None
    assert 'ansible_service_mgr' in result['ansible_facts']
    assert result['ansible_facts']['service_mgr'] == result['ansible_facts']['ansible_service_mgr']


# Generated at 2022-06-21 02:50:47.084472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    The function tests that run function is working as expected
    """
    print("\n Testing the run function of class ActionModule")
    test_module = ActionModule()
    test_module._supports_check_mode = True
    test_module._supports_async = True

# Generated at 2022-06-21 02:50:54.781862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert(module.TRANSFERS_FILES)

# Generated at 2022-06-21 02:51:05.549273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    raise NotImplementedError


if __name__ == '__main__':
    import sys
    import os
    import unittest
    import tempfile
    import shutil

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_action_module(self):
            raise NotImplementedError
            #TODO: test_action_module

    basetestcase = TestActionModule
    basetestcase.tempdir = tempfile.mkdtemp()

    atexit.register(shutil.rmtree, basetestcase.tempdir)
    os.chdir(basetestcase.tempdir)

    un

# Generated at 2022-06-21 02:51:06.356059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pass
    pass

# Generated at 2022-06-21 02:51:07.082299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_test_action_module = ActionModule()
    assert obj_test_action_module is not None

# Generated at 2022-06-21 02:51:14.392979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    conn = {}
    tmp = {}
    task_vars = {}
    o = ActionModule(conn, tmp, task_vars)
    o._task.args = {'use' : 'auto'}
    o._task.delegate_to = ''
    o._task.action = 'openwrt_init'
    o.BUILTIN_SVC_MGR_MODULES = ['openwrt_init']
    try:
        o.run(tmp, task_vars)
        assert 0
    except AnsibleActionFail:
        assert 1

# Generated at 2022-06-21 02:51:21.880407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._display.verbosity = 4
    task_vars = dict(
        ansible_facts=dict(
            service_mgr='failing'
        ))
    res = module.run(None, task_vars=task_vars)
    assert res['_ansible_verbose_always'] == True
    assert res['failed'] == True
    assert res['msg'] == 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.'


# Generated at 2022-06-21 02:51:34.178620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import DefaultFactCollector
    from ansible.module_utils.facts.hardware.linux import Hardware
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.platform import Platform

    module = AnsibleModule(
        argument_spec = dict(
            use = dict(default='auto', type='str'),
        ),
        supports_check_mode=True,
    )

    connection = Connection(module._socket_path)
    facts = Facts(module, connection, DefaultFactCollector)
    hardware = Hardware(facts)
    distribution = Distribution(facts)


# Generated at 2022-06-21 02:51:39.059774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule")

    import ansible.plugins.action.service
    task = ansible.plugins.action.service.ActionModule("task")
    task.run("tmp", "task_vars")

# Generated at 2022-06-21 02:51:46.291754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task_vars = dict()

    test_instance = ActionModule()

    test_instance._supports_check_mode = True
    test_instance._supports_async = True
    test_instance._task = dict()
    test_instance._task['args'] = dict()

    test_instance._shared_loader_obj = mock_shared_loader_obj = mock.Mock()
    test_instance._display = mock.Mock()
    test_instance._task._parent._play = mock.Mock()
    test_instance._task._parent._play._action_groups = mock.Mock()
    test_instance._templar = mock.Mock()
    test_instance._templar.template.side_effect = ["service_mgr_value"]
    test_instance._execute_module = mock.Mock()

# Generated at 2022-06-21 02:51:52.948969
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Constructor test
    module = ActionModule(
        task=dict(
            name='test_task',
            async_val=20,
            async_timeout=300,
            action='test_action',
            loop='test_loop',
            items=[],
            first_available_file='test_first_available_file',
            environment={},
            args=dict(
                use='auto'
            ),
        ),
        connection=dict(),
        play_context=dict(
            check_mode=False
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module

# Generated at 2022-06-21 02:52:15.308401
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test = ActionModule()
    test._connection = MagicMock()
    test._shared_loader_obj = MagicMock()
    test._loader = test._shared_loader_obj.module_loader
    test._templar = MagicMock()
    test._shared_loader_obj.module_loader.find_plugin_with_context = MagicMock()
    test._shared_loader_obj.module_loader.find_plugin_with_context.return_value = ('/module_path', 'module_name', 'module_args', None, None)
    test._execute_module = MagicMock()
    test._execute_module.return_value = {'foo': 'bar'}
    test._display = MagicMock()
    test._task = MagicMock()
    test._task.args = {'use': 'auto'}

# Generated at 2022-06-21 02:52:20.453331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import yaml
    import tempfile
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.service import ActionModule as ServiceActionModule

    # Setup
    fake_hostvars = {
        'localhost': {
            'ansible_facts': {'service_mgr': 'systemd'}
        }
    }
    fake_task_vars = {
        'hostvars': fake_hostvars
    }
    module_args ={}

    # Mock some methods
    test_registered_module = tempfile.NamedTemporaryFile()

# Generated at 2022-06-21 02:52:20.998504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:22.251461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: implement this!
    assert False

# Generated at 2022-06-21 02:52:33.906144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._display = {'debug': lambda text: print('debug: %s' % text)}
    module._remove_tmp_path = lambda tmpdir: print('remove_tmp_path %s' % tmpdir)
    module._task = {
        'args': {
            # Module service (not auto), but don't use systemd, sysvinit or openwrt_init (legacy modules)
            'use': 'service',
            'state': 'started',
            'name': 'foo',
            'pattern': 'foo',
            'runlevel': 'foo',
            'sleep': 'foo',
            'arguments': 'foo',
            'args': 'foo'
        },
        'delegate_to': 'baz'  # delegate
    }

# Generated at 2022-06-21 02:52:39.445854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_action = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert my_action is not None

# Generated at 2022-06-21 02:52:42.033864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test for "__init__"
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-21 02:52:46.789194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None, connection=None, play_context=None, loader_obj=None, templar=None, shared_loader_obj=None)

    assert action is not None

# Generated at 2022-06-21 02:52:50.662491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    # Tests with incorrect parameters
    action = ActionModule(None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-21 02:52:56.905839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup the mocks
    mock_actionbase_obj = MagicMock(spec=ActionBase)
    mock_actionbase_obj._task.delegate_to = '1.1.1.1'
    mock_actionbase_obj._task.args = {'use': 'auto'}
    mock_actionbase_obj._task._parent._play._action_groups = []
    mock_actionbase_obj._shared_loader_obj.module_loader.find_plugin_with_context.return_value.resolved_fqcn = 'test'
    mock_actionbase_obj._shared_loader_obj.module_loader.has_plugin.return_value = True
    mock_actionbase_obj._templar.template.return_value = 'test'

# Generated at 2022-06-21 02:53:24.003143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:53:33.612366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class shell(object):
        def __init__(self):
            self.tmpdir = 'tmpdir'

    class connection(object):
        def __init__(self):
            self._shell = shell()

        def _remove_tmp_path(self, tmp):
            pass

    class task(object):
        def __init__(self):
            self.args = dict()
            self.args['use'] = 'auto'
            self.async_val = False
            self.delegate_to = None

    class action_base(object):
        def __init__(self):
            self._task = task()
            self._connection = connection()
            self._shared_loader_obj = object()
            self._templar = object()
            self._display = object()


# Generated at 2022-06-21 02:53:34.693942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)

# Generated at 2022-06-21 02:53:35.985717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:53:40.171559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    task_vars = {'ansible_facts': {'service_mgr': 'auto'}}
    m._shared_loader_obj.module_loader.has_plugin = lambda *args, **kwargs: True
    m.run(task_vars=task_vars)

# Generated at 2022-06-21 02:53:51.207455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # A good way to prepare test data
    # is to use a YAML file and load it
    # with the yaml.load function
    # you can also use json.load or
    # import json then json.loads
    import yaml
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class MockTask():
        _parent = None
        _play = None
        async_val = False
        async_seconds = None
        delegate_to = None
        nagios_action = None
        role_name = None
        tags = []

        def __init__(self, args):
            self.args = args

        def set_loader(self, loader):
            self._loader = loader

        def copy(self):
            return self


# Generated at 2022-06-21 02:54:00.350626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import json
    import unittest
    import mock
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from units.mock.loader import DictDataLoader

    # dict containing a valid service module invocation
    # inputs to constructor:
    #   1. task args
    #   2. task async val
    #   3. connection info (None)
    #   4. templar (None)
    #   5. shared plugin loader obj (None)
    #   6. connection plugin loader obj (None)
    #   7. lookup plugin loader obj (None)
    #   8. filter plugin loader obj (None)
    # inputs to method run:
    #   1. tmp path (None)
    #   2. task vars


# Generated at 2022-06-21 02:54:01.199390
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:54:10.314544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='service', args=dict(name='network', state='started', use='systemd')))

    task_copy = task.copy()
    am = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._task.module == 'service'
    assert task == task_copy

    task_copy = task.copy()
    am = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._task.module == 'service'
    assert task == task_copy

# Generated at 2022-06-21 02:54:11.546657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module


# Generated at 2022-06-21 02:55:12.316981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # fake environment, this test just needs to create and one of the action plugin instances
    class FakeEnv:
        def __init__(self):
            self.base_dir = '.'
            self.loader_class = None  # not needed for plugin discovery
            self.collection_paths = []
            self.path_plugins = '.'
            self.action_plugins = []

    class FakeTask:
        def __init__(self):
            self.args = {'name': 'ntp', 'use': 'auto', 'state': 'started'}
            self.delegate_to = None
            self.async_val = None
            self.async_seconds = None

        @property
        def module_defaults(self):
            return {'arg1': None, 'arg2': None}


# Generated at 2022-06-21 02:55:22.388731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.vars.unsafe_proxy import UnsafeProxy

    task = Task()
    task._role = None
    task.args = dict(name='my_package', state='present')
    task.async_val = 10

    am = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am._shared_loader_obj == shared_loader_obj
    assert am._loader.__class__.__name__ == 'DataLoader'
    assert am._templar.__class__.__name__ == 'Templar'
    assert am._connection.__class__.__name__ == 'Connection'


# Generated at 2022-06-21 02:55:33.362261
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup the mocks
    mock = MagicMock()
    # define the mock return values
    mock._task.args = {
        'name': "apache2",
        'state': 'started'
    }
    mock._task.args.get.return_value = "auto"
    mock._task.delegate_to = False
    mock._task.async_val = False
    mock._task._parent._play._action_groups = 'all'
    mock._shared_loader_obj.module_loader.find_plugin_with_context.return_value = "ansible.legacy.setup"
    mock._shared_loader_obj.module_loader.has_plugin.return_value = "True"

# Generated at 2022-06-21 02:55:44.105711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = dict(
        state=dict(type='str', required=True),
        name=dict(type='str', required=True),
        enabled=dict(type='bool', default=False)
    )
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module._display = dict()
    action_module._task = dict()
    action_module._task.args = dict(
        use='auto', state='started', name='ansible.test_module', enabled=True
    )
    action_module._task._parent = dict()
    action_module._task._parent._play = dict()
    action_module._task._parent._play._action_groups = dict()

    action_module._shared_loader_

# Generated at 2022-06-21 02:55:51.195807
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Unit test for constructor of uninitialized object
    try:
        action_module = ActionModule()
    except AttributeError as e:
        assert "object has no attribute '_templar'" in e.args[0]
    else:
        raise RuntimeError("AttributError Expected")

    # Unit test for constructor with initialized templar
    templar = dict()
    action_module = ActionModule(templar=templar)
    assert action_module._templar is templar



# Generated at 2022-06-21 02:55:54.008864
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_obj = ActionModule()
    assert(ActionModule_obj) == None

# Generated at 2022-06-21 02:55:56.904593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a static class object
    static_class_obj = ActionModule()
    # invoke the method with required args

    @staticmethod
    def get_default_args():
        return {}

    static_class_obj.get_default_args = get_default_args
    static_class_obj.run()

# Generated at 2022-06-21 02:55:59.326045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule(None, None, None, None)
    assert 'ActionModule' == act_mod.__class__.__name__

# Generated at 2022-06-21 02:56:02.337632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # *********************************************************
    # TODO: Write test for class ActionModule method run
    pass

# Generated at 2022-06-21 02:56:12.652496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import shared_loader_obj
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.task.automation import Automation
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.remote_management.winrm.connection import WinRMConnection
    from ansible.inventory.host import Host
    from ansible.module_utils._text import to_bytes
    import mock


    play_context = PlayContext()

# Generated at 2022-06-21 02:58:31.365584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-21 02:58:33.784640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule(copy.copy(DEFAULT_PARAMS), DUMMY_CONNECTION)
    assert result

# Generated at 2022-06-21 02:58:39.369112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert actionModule is not None

# Generated at 2022-06-21 02:58:44.749532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    unit test for constructor of class ActionModule
    '''
    import ansible.plugins.action.service as service

    action = {
        '_uses_shell': False,
        '_raw_params': 'apt',
        '_task': None,
        '_local_action': False,
        '_attributes': {
            'use': 'auto'
        }
    }

    action_module = service.ActionModule(action, '/tmp/ansible/action_plugin/')
    print(str(action_module))

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-21 02:58:46.757321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:58:51.735548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._shared_loader_obj = None
    action_module._task_vars = None
    action_module._task = None
    action_module._task._parent = None
    action_module._task._play = None
    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)
    print(result)

# Generated at 2022-06-21 02:59:00.741417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    task = Task()
    task._role = None
    task.async_val = 0
    task.args = dict(name='nginx', state='started')
    play_context = PlayContext()
    task._play_context = play_context
    task._play = None
    action_module = ActionModule(task, None)
    assert action_module

# Generated at 2022-06-21 02:59:03.267548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test action_service
    action_service = ActionModule()
    assert action_service
    return True

# Generated at 2022-06-21 02:59:11.714002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' action_plugins.service.ActionModule() '''

    module = ActionModule('setup', dict(gather_subset='!all', filter='ansible_service_mgr'), False, '/tmp', '/tmp', 10, None)
    assert module
    assert isinstance(module, ActionModule)

    # constructor with invalid parameters
    module = ActionModule('setup', dict(gather_subset='!all', filter='ansible_service_mgr'), False, None, None, 10, False)
    assert module
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 02:59:15.886873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_obj is not None