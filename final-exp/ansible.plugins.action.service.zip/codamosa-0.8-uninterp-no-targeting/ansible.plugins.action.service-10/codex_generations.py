

# Generated at 2022-06-21 02:50:06.067870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-21 02:50:11.904489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create empty task_vars
    task_vars = {}
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # test ActionModule.run()
    action.run(tmp=None, task_vars=task_vars)
    assert True

# Generated at 2022-06-21 02:50:16.459308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)
    assert action.TRANSFERS_FILES is False
    assert action.UNUSED_PARAMS is not None
    assert action.BUILTIN_SVC_MGR_MODULES is not None
    assert 'run' in dir(action)

# Generated at 2022-06-21 02:50:26.360926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''test_ActionModule_run'''
    import ansible.plugins.connection.connection_loader as connection_loader
    import ansible.plugins.loader as plugins
    import ansible.playbook.play_context as play_context
    import ansible.plugins.action.ActionModule as ActionModule
    import ansible.plugins.cache.fact_cache as fact_cache
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.executor.process.worker as worker
    import ansible.executor.process.worker_process as worker_

# Generated at 2022-06-21 02:50:26.865408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:32.264007
# Unit test for constructor of class ActionModule
def test_ActionModule():

    test = ActionModule()
    assert test.TRANSFERS_FILES == False
    assert test.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']
    }
    assert test.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])


# Generated at 2022-06-21 02:50:42.525042
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockModule(ActionModule):
        def __init__(self, shared_loader_obj, connection, become_method, become_user, check_mode, diff, diff_peek):
            super(MockModule, self).__init__(shared_loader_obj, connection, become_method, become_user, check_mode, diff, diff_peek)
            self._shared_loader_obj = shared_loader_obj

        def _execute_module(self, module_name, module_args, task_vars, wrap_async):
            if module_name == 'ansible.setup':
                return dict(ansible_facts=dict(service_mgr='auto'))
            elif module_name == 'ansible.legacy.service':
                return dict(msg="success")

# Generated at 2022-06-21 02:50:54.887534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.context import CLIContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-21 02:50:55.966229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("hello world")

# Generated at 2022-06-21 02:51:05.897103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test imports
    import ansible.template as template
    import ansible.module_utils.basic as basic
    import ansible.vars.reserved as reserved
    import ansible.utils.display as display
    import ansible.plugins.action as action
    import ansible.playbook.task_include as task_include
    import ansible.utils.vars as vars
    import ansible.errors as errors
    import ansible.executor.task_result as task_result
    import ansible.playbook.play_context as play_context
    import ansible.playbook.block as block
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.playbook.handler as handler
    import ansible.playbook.role.include as role_include
    import ansible.release as release


# Generated at 2022-06-21 02:51:20.678317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Verifies if method run of class ActionModule returns any value
    # depends on if the method returns something
    module_name = 'ansible.legacy.service'
    module_args = 'service'
    task_vars = ''
    results = 'test'
    task_vars = {'ansible_facts':{'service_mgr':'test'}}
    module = ActionModule(module_name,module_args,task_vars)
    assert module.run()

# Generated at 2022-06-21 02:51:21.954731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run(ActionModule)

# Generated at 2022-06-21 02:51:25.736288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule_run_obj = ActionModule()
    assert test_ActionModule_run_obj._supports_check_mode == True

# Generated at 2022-06-21 02:51:26.643519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-21 02:51:27.472089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:28.346926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1

# Generated at 2022-06-21 02:51:36.529798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create Task object (required)
    task = Task()

    # Create data loader and inventory manager objects
    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inv_mgr)

    # Create the shared module_loader, to handle the shared stuff
    module_loader = ActionModule._shared_loader_obj

# Generated at 2022-06-21 02:51:43.437780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook import Playbook
    from ansible.plugins.loader import find_plugin

# Generated at 2022-06-21 02:51:53.508436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    module._task.args = {'name':'test_service', 'use':'auto'}
    mock_ansible_facts = {'ansible_facts': {'service_mgr':'init'}}
    result = module.run(task_vars={'ansible_facts':mock_ansible_facts})
    assert result['failed'] is False
    assert result['module_name'] == 'ansible.legacy.service'
    assert result['module_args'] == {'name': 'test_service'}

    del module._task.args['use']
    with pytest.raises(AnsibleActionFail):
        result = module.run(task_vars={'ansible_facts':mock_ansible_facts})

# Generated at 2022-06-21 02:51:54.932659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = {'name': 'foo', 'state': 'started'}
    module.run()

# Generated at 2022-06-21 02:52:09.237542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise AttributeError()

# Generated at 2022-06-21 02:52:12.258317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test all possible scenarios for constructor of class ActionModule,
    """
    task_vars = dict()
    result = dict()

    module = ActionModule(None, None)
    assert module is not None


# Generated at 2022-06-21 02:52:15.560398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    c = ActionModule(ActionModule.ALL_META)
    assert c.run != None

# Generated at 2022-06-21 02:52:18.705912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    #assert am is not None, "ActionModule() returns an object"
    am.run(None, None)

# Generated at 2022-06-21 02:52:26.089439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        name='test_name',
        action=dict(
            module='test_module',
            args=dict(arg1='val1')
        )
    )

    shared_loader_obj = object()
    display_ = object()
    connection = object()
    templar = object()
    task_vars = dict()

    action_module = ActionModule(task, shared_loader_obj, display_, connection, templar, task_vars)

    try:
        action_module.run(None, task_vars)
    except Exception as e:
        assert isinstance(e, AnsibleActionFail)
        pass



# Generated at 2022-06-21 02:52:35.759437
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ansible_mock = Mock()
    ansible_mock.send_file = None
    ansible_mock.recv_file = None
    # Test without facts
    # Test without a service name
    # Test without a state
    # Test with a state
    # Test with a state and a service name

    task = Mock()
    task.async_val = None
    task.args = {'state': 'started'}
    task.action = 'ansible_service'
    task.delegate_to = None
    task.module_defaults = None
    task._parent = None
    task._parent._play = None
    task._parent._play._action_groups = None

    action_module = ActionModule(task, ansible_mock, 'foo')
    action_module.run()

# Generated at 2022-06-21 02:52:41.622176
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:52:53.723875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_ActionModule = ActionModule()

    # test with correct inputs
    #test_task = {"module_defaults": {}, "module_vars": {"use": "auto"}}
    #test_task_vars = {}
    #my_ActionModule._task = test_task
    #my_ActionModule._execute_module = lambda x,y,z: ({"success": True, "msg": "fake_result"})
    #my_ActionModule._templar = lambda x: x
    #my_ActionModule._display = lambda x,y: None
    #my_ActionModule._remove_tmp_path = lambda x: None
    #my_ActionModule._connection = lambda x,y: None

    #my_ActionModule.run(tmp=None, task_vars=test_task_vars)
    pass

# Generated at 2022-06-21 02:52:59.599354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create 'service' object
    obj_service = ActionModule()

    # Create 'task' object
    obj_task = object()

    # Assign 'args' object to task object
    obj_task.args = {'use': 'auto'}

    # Assign 'async_val' object to task object
    obj_task.async_val = 1

    # Create 'tmp' object
    obj_tmp = object()

    # Create 'task_vars' object
    obj_task_vars = object()

    returnValue = obj_service.run(tmp=obj_tmp, task_vars=obj_task_vars)

    # returnValue should be a 'dict' type
    assert type(returnValue) == dict

    # returnValue should have set of keys

# Generated at 2022-06-21 02:53:01.518872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Entering test_ActionModule_run')
    # TODO
    return True

# Generated at 2022-06-21 02:53:38.372097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Replacement for required AnsibleModule.load_params function
    def load_params(self):
        self.params = self._task.args

    from ansible.plugins.action import ActionBase

    ActionBase.load_params = load_params

    # Create mocks
    _connection = MagicMock()
    _shared_loader_obj = MagicMock()
    _display = MagicMock()
    _task = MagicMock()
    _task.args = {'use': 'auto', 'name': 'apache2'}
    _task._parent = MagicMock()
    _task.async_val = {'jid': 'skjsskkjskkskjskjkjskks', 'poll': 0}
    _task.module_defaults = {'hello': "world"}
    _task._parent._play = MagicM

# Generated at 2022-06-21 02:53:40.052021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), '/').__class__.__name__ == "ActionModule"

# Generated at 2022-06-21 02:53:40.761696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:53:51.497053
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    from ansible.module_utils._text import to_bytes
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    class OptionModule(object):
        def __init__(self,*args,**kwargs):
            self.no_log = True
            self.action_plugin_class = 'ActionModule'
            self._args = kwargs
            self.typed_args = {}

    class ModuleStub(object):
        def __init__(self, *args, **kwargs):
            self._shared_loader_obj = None
            self._templar = None
            self._loader = None
            self._connection = None


# Generated at 2022-06-21 02:53:55.004234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = None
    tmp = None
    task_vars = None
    action_module = ActionModule(task, tmp, task_vars)
    res = action_module.run()
    assert res is not None

# Generated at 2022-06-21 02:54:02.209258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_action_base = {
        'run.return_value': '',
        '_execute_module.return_value': '',
        '_templar.template': lambda x:x,
        '_templar.template.return_value': '',
        '_shared_loader_obj.module_loader.has_plugin.return_value': False,
        '_shared_loader_obj.module_loader.find_plugin_with_context.return_value.resolved_fqcn': '',
        '_display.warning': lambda x:x,
        '_display.debug': lambda x:x,
        '_display.vvvv': lambda x:x,
    }

    mock_action_base_obj = type('', (object,), mock_action_base)()


# Generated at 2022-06-21 02:54:11.576354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins
    import ansible.plugins.action

    # Create object and initialize variables
    m_task = Mock()
    m_task.args = {
        'module_defaults': {},
        'use': 'auto'
    }
    m_shared_loader_obj = Mock()
    m_shared_loader_obj.module_loader = Mock()
    m_shared_loader_obj.module_loader.has_plugin.return_value = True
    m_shared_loader_obj.module_loader.find_plugin_with_context.return_value = Mock()
    m_task._parent = Mock()
    m_task._parent._play = Mock()
    m_task._parent._play._action_groups = {}
    m_task.async_val = False

    test_obj = ansible.plugins

# Generated at 2022-06-21 02:54:20.677488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(dict(
                            module_defaults=dict(
                                service=dict(
                                    enabled=True,
                                    name="apache2"
                                    )                                
                                ),
                            name="service",
                            no_log=False,
                            args={"enabled": "yes", "name": "apache2"}
                            ),
                            loader=None,
                            templar=None,
                            shared_loader_obj=None
                            )
    task_vars = dict()
    module.run(task_vars=task_vars)

# Generated at 2022-06-21 02:54:28.479874
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.action import ActionBase

    module_action_base = {'action': '', '_uses_shell': False,
                          '_raw_params': '', '_attributes': {}, '_task': {},
                          '_play_context': {}}

    mock_task = dict(action='service', async_val=30, async_seconds=10, args=dict(name="foo", state="present"), delegate_to='localhost')
    mock_task.setdefault('notify', [])


# Generated at 2022-06-21 02:54:40.007453
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:55:43.853444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(dict(async_=6))
    assert a._task.async_val == 6

# Generated at 2022-06-21 02:55:49.412321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader_mock = mock.MagicMock()
    task_mock = mock.MagicMock()

    module = ActionModule(loader=loader_mock, task=task_mock)

    assert module._shared_loader_obj == loader_mock
    assert module._task == task_mock

# Generated at 2022-06-21 02:56:00.208525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_conn = MockConnection()
    mock_task = MockTask()
    m_conn._shell.tmpdir = 'mock'
    m_conn._shell.exec_command.return_value = (0, '', '')
    m_module = ActionModule(task=mock_task, connection=m_conn, play_context=mock.MagicMock(), loader=mock.MagicMock(), templar=mock.MagicMock(), shared_loader_obj=mock.MagicMock())

    m_module.run(task_vars={'ansible_facts': {'service_mgr': 'systemd'}})


# Generated at 2022-06-21 02:56:07.804631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a task which instantiates a class called ActionModule
    task = dict(
        action=dict(
            module='service',
            use='auto',
        )
    )
    # Assert if ActionModule is not initialized,
    # and test the constructor
    assert isinstance(ActionModule(task, dict()), ActionModule)

# Generated at 2022-06-21 02:56:14.526921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test")
    # Setup for test
    import ansible.plugins.action.service
    task = {"action": {"__ansible_action_delegate_to": None, "__ansible_arguments": {"use": 'auto'}, "__ansible_module_name": "service"}, "args": {"use": "auto"}, "collections": [], "delegate_to": None, "loop": None, "name": "test_service", "register": "ansible_service_facts", "remote_user": None, "vars": {}}

    # Test run function
    task_vars = {"ansible_facts": {"service_mgr": "systemd"}}
    service = ansible.plugins.action.service.ActionModule(task, None)
    ans = service.run(task_vars)

# Generated at 2022-06-21 02:56:20.041149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    # Constructors for Ansible objects
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import ActionBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor


    ##############################################################################
    # Ansible objects configuration
    ##############################################################################

    # Options

# Generated at 2022-06-21 02:56:24.988689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cwd = os.getcwd()
    os.chdir("/tmp")
    mod = ActionModule()
    os.chdir(cwd)


# Generated at 2022-06-21 02:56:31.578276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    u = ActionModule()
    assert u._supports_async == True
    assert u._supports_check_mode == True
    assert u.TRANSFERS_FILES == False
    assert u.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'], }
    assert u.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
# Unit test end

# Generated at 2022-06-21 02:56:35.883678
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the ActionModule.run method
    """

    # Create a connection a task, and open a tmp file on the connection

    # Tests
    # TODO

    pass

# Generated at 2022-06-21 02:56:46.751876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed_module
    import pytest
    module = removed_module
    args = {'use': 'auto'}
    tmp = 'tmp'
    task_vars = {}
    am = ActionModule(module, args, tmp, task_vars)
    result = am.run(tmp, task_vars)
    assert result == {'_ansible_verbose_always': True, '_ansible_no_log': False, '_ansible_debug': False, '_ansible_diff': False, 'changed': False, 'msg': 'Disabled action `service` as the `ansible.builtin.remove` module was removed'}

# Generated at 2022-06-21 02:59:18.882795
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert True

# Generated at 2022-06-21 02:59:24.764112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    from ansible.plugins.action import ActionBase

    from ansible.vars.hostvars import HostVars

    play_context = PlayContext()
    play_context.prompt = ('test', 'test')
    play_context.remote_user = 'test'
    play_context.connection = 'test'
    play_context.network_os

# Generated at 2022-06-21 02:59:31.480824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    moduleAction = ActionModule(None, None, None)
    assert moduleAction
    assert moduleAction.TRANSFERS_FILES == False
    assert moduleAction._supports_check_mode == True
    assert moduleAction._supports_async == True

    moduleAction.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-21 02:59:42.490898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test setup')

    module = ActionModule()


    print('Test teardown')


if __name__ == '__main__':

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    import os
    import json

    import pytest
    from test.support.pytest import ModuleTestCase

    # All the tests for this module
    from unit.plugins.action import TestActionModule

    # This python module
    from library.service import ActionModule as AM

    module = pytest.fixture

# Generated at 2022-06-21 02:59:51.289985
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Module class and it's name
    module_class = 'ActionModule'
    module_name = 'service'

    # Initialize module class object
    module = ActionModule()

    # Print 'Constructor' name and it's module class
    print('ActionModule(): ','module_class: ', module_class)

    # Print 'Constructor' name and it's module name
    print('ActionModule(): ','module_name: ', module_name)

# Call to 'test_ActionModule' function
test_ActionModule()

# Generated at 2022-06-21 02:59:56.664770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_module is not None