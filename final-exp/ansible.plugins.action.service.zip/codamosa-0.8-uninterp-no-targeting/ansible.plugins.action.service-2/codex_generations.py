

# Generated at 2022-06-21 02:50:10.307935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    __task = {
        'args': {
            'use': 'systemd'
        },
        'async_val': 0,
        'delegate_to': None,
        'module_defaults': {}
    }
    action_module = ActionModule(__task, None)
    assert isinstance(action_module, ActionModule), "Should return an ActionModule object"

# Generated at 2022-06-21 02:50:12.745947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    module = ActionModule()
    # When
    module.run()
    # Then
    assert True

# Generated at 2022-06-21 02:50:15.434795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule({'name': 'ansible.legacy.file'}, 'dest', 'src', 'args', 'runner')
    assert mod.name == 'ansible.legacy.file'
    assert mod.runner.name == 'dest'

# Generated at 2022-06-21 02:50:24.874192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock task
    task = dict()
    task['verbosity'] = 0
    task['no_log'] = False
    task['async'] = None
    task['poll'] = 0
    task['_ansible_check_mode'] = False
    task['_ansible_verbosity'] = 0
    task['_ansible_debug'] = False
    task['_ansible_diff'] = False
    task['collections'] = []
    task['collection_name'] = None
    task['collection_version'] = None
    task['_ansible_no_log'] = False
    task['_ansible_ignore_errors'] = False
    task['_ansible_module_name'] = 'service'
    task['module_defaults'] = dict()
    task['module_defaults']['no_log'] = False

# Generated at 2022-06-21 02:50:34.475025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test ActionModule"""
    from ansible.executor.task_executor import TaskExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    loader = DataLoader()
    host_list = [{'hostname': 'localhost'}]

# Generated at 2022-06-21 02:50:35.938482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act_module = ActionModule()
    # nothing to test here :/
    assert True == True

# Generated at 2022-06-21 02:50:36.578626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:44.414793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import mock
    import os

    from ansible.compat.tests.mock import patch
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.connection import Connection
    from ansible.module_utils._text import to_bytes

    # Create the action plugin
    action = ActionModule(mock.Mock())

    # Create the task result
    task_result = mock.Mock(TaskResult)
    task_result.is_changed = False

# Generated at 2022-06-21 02:50:55.134541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeOptions(object):

        verbosity = 3
        always_show_content = False
        color = 0
        nocolor = None
        diff = False
        module_path = None
        forks = 5
        ask_vault_pass = False
        vault_password_files = []
        new_vault_password_file = None
        output_file = None
        tags = []
        skip_tags = []
        one_line = None
        tree = None
        ask_sudo_pass = False
        ask_su_pass = False
        sudo = None
        sudo_user = None
        su = None
        su_user = None
        become = False
        become_method = None
        become_user = None
        become_ask_pass = False
        become_flags = None
        no_log = False
       

# Generated at 2022-06-21 02:51:05.607618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn=Mock(spec=Connection)
    connection=Mock()
    connection.return_value = conn
    loader=Mock(spec=DataLoader)
    tmp=Mock()
    task_vars=Mock()
    play_context=Mock()
    module_loader=Mock(spec=ModuleLoader)
    display=Mock()
    task_vars=Mock()
    action_plugin_loader=Mock()
    shared_loader_obj=Mock()
    task_vars=Mock()
    task_vars.module_name.return_value = 'service'

# Generated at 2022-06-21 02:51:16.606213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TaskVars
    task_vars = {'myvariable': 'myvalue'}

    # ActionModule
    action_module = ActionModule(
        task=Task(load_args=dict(
            use='auto',
            name='apache2',
            state='restarted',
            enabled=True,
            force=True
        )),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # AnsibleAction

# Generated at 2022-06-21 02:51:17.554061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:20.010462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise Exception("Not implemented")
    # service = ActionModule()
    # TODO: write test for ActionModule.run()

# Generated at 2022-06-21 02:51:33.193157
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import shutil
    import tempfile

    #init ActionModule
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # get default parameters
    default_args = action_module.run()
    default_args['tmp'] = ''
    default_args['task_vars'] = {}

    # replace default parameters values with test values
    args = default_args.copy()
    args['tmp'] = tempfile.mkdtemp()
    args['task_vars'] = {
        'ansible_facts': {
            'service_mgr': 'auto'
        }
    }
    # execute run

# Generated at 2022-06-21 02:51:44.049162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.plugin.loader import action_loader

    class TestCallback(CallbackBase):
        pass

    class TestConnection(object):
        def __init__(self):
            self.tmpdir = "/tmp/test"

    class TestTask(object):
        def __init__(self):
            self.args = dict(
                use="auto",
                state="started"
            )


# Generated at 2022-06-21 02:51:53.851823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, {}, None)
    test_config = config.make_config([], {"fact_caching": "jsonfile", "fact_caching_connection": "123"})
    test_connection = connection.Connection(os.path.join(os.path.dirname(__file__), "fixtures", "ansible.cfg"))
    test_task = Task(test_connection, test_config, None, '123')
    test_task_vars = dict()
    result = action_module.run(False, test_task_vars)
    # test expected result
    assert result is not None and 'ansible_facts' in result and 'ansible_fqdn' in result['ansible_facts']

# Generated at 2022-06-21 02:52:00.628076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    class FakeModule(object):
        @property
        def args(self):
            return {'name': "foo", 'state': "bar"}

    class FakeAnsibleModule():
        def __init__(self, module):
            self.module = module
            self.params = self.module.args

        def fail_json(self, **kwargs):
            raise AnsibleAction(kwargs)

        def exit_json(self, **kwargs):
            raise AnsibleAction(kwargs)

        def set_options(self, *k, **kw):
            pass

        def _set_action_serial(self, *k, **kw):
            pass

        def _get_task_vars(self, *k, **kw):
            return {}


# Generated at 2022-06-21 02:52:01.427836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:52:13.581040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import subprocess
    from ansible.plugins.action.service import ActionModule

    tempdir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'temp', 'test.sh')
    os.makedirs(os.path.dirname(tempdir))
    with open(tempdir, 'w') as f:
        f.write("#!/bin/bash\n"
                "echo \"127.0.0.1\" > /dev/stdout\n")

# Generated at 2022-06-21 02:52:24.665717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext(), loader=None, templar=MockTemplar(), shared_loader_obj=None)
    assert mod._connection == MockConnection()
    assert mod._task == MockTask()
    assert mod.TRANSFERS_FILES == False
    assert mod.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert mod.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }


# Generated at 2022-06-21 02:52:43.569846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        loader=None,
        task_uuid=None,
        connection=None,
        play_context=None,
        loader_cache=None,
        shared_loader_obj=None,
        templar=None,
        task=None
    )
    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True

# Generated at 2022-06-21 02:52:43.908247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:52:54.604568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils import context_objects as co
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    import ansible.constants as C
    import json
    import sys
    import os

    # create play.yml with minimal elements

# Generated at 2022-06-21 02:53:05.385577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-21 02:53:07.207960
# Unit test for constructor of class ActionModule
def test_ActionModule():
   # action = ActionModule(task, connection, 'service', 'service', {})
    #assert action.action_name == 'service'
    return True

# Generated at 2022-06-21 02:53:11.595110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    foo = ActionModule(connection=None, runner=None)
    assert foo is not None
    # Unit test for run function of class ActionModule
    assert foo.run({'use': 'auto'}, None) is not None

# Generated at 2022-06-21 02:53:24.003167
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule()
    assert isinstance(action, ActionBase)

    action = ActionModule()
    assert action.get_checks() is None # failure expected as these are not defined

    action = ActionModule()
    assert action.get_name() is None # failure expected as these are not defined

    action = ActionModule()
    assert action.get_path() is None # failure expected as these are not defined

    action = ActionModule()
    assert action.get_args() is None # failure expected as these are not defined

    action = ActionModule()
    assert action.get_action_loader_class() is None # failure expected as these are not defined

    action = ActionModule()
    assert action.display() == {'skipped': False, 'changed': False, 'msg': 'Unchanged'}

    action = ActionModule()
    assert action.run

# Generated at 2022-06-21 02:53:25.251559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule
    assert False, 'Not implemented'


# Generated at 2022-06-21 02:53:33.216139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    import sys
    import unittest
    import ansible
    import platform
    import os
    import json

    class MockModule(object):

        def __init__(self, module_name, module_args, async_val=False):
            self.module_name = module_name
            self.module_args = module_args
            self.async_val = async_val

    class MockTask(object):

        def __init__(self, args, async_val=False):
            self.args = args
            self.async_val = async_val
            self._parent = self

        def _parent(self):
            return self

    class MockPlay(object):

        def __init__(self):
            self._action_groups = dict()


# Generated at 2022-06-21 02:53:34.310825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test = ActionModule()
    assert test

# Generated at 2022-06-21 02:54:10.142192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    tqm = None

# Generated at 2022-06-21 02:54:21.739746
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test1:
    # Test with just name of the class
    action = ActionModule()
    assert action._supports_check_mode == True
    assert action._supports_async == True

    # Test2:
    # Test with just name of the class
    # Expected error:
    #   value error if the required arguments are not passed
    try:
        action = ActionModule(task_vars=None, templar=None)
    except ValueError() as e:
        pass

    # Test3:
    # Test with just name of the class
    # Expected error:
    #   value error if the required arguments are not passed
    #   typeerror if the required arguments are not passed

# Generated at 2022-06-21 02:54:28.983109
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up arguments
    connection = Connection()
    module_loader = None
    templar = Templar(loader=None, variables={})
    task = PlaybookExecutionTask(variable_manager={}, loader={}, play={}, play_ds={})
    shared_loader_obj = SharedPluginLoaderObj()
    display = Display()

    # Test the constructor
    action_module = ActionModule(connection=connection, _shared_loader_obj=shared_loader_obj, templar=templar, task=task, module_loader=module_loader, display=display)


# Generated at 2022-06-21 02:54:37.683572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Instantiate a couple of ActionModule objects to test that the constructor works.
    I couldn't find a way to access the objects created in `setup_module_loading_fixtures` so this does not actually test the module
    '''
    obj = ActionModule({},{})
    assert obj._supports_check_mode == True
    assert obj._supports_async == True
    assert obj._shared_loader_obj == None
    assert obj._templar == None
    assert obj._task == None

# Generated at 2022-06-21 02:54:39.350303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()


# Generated at 2022-06-21 02:54:40.292827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:54:41.269078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 02:54:42.102295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:54:51.186720
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    ansible_cfg = os.path.join(tmpdir, 'ansible.cfg')
    with open(ansible_cfg, 'w') as f:
        f.write("[defaults]\nasking_password = False")

    # Create a temporary inventory
    inventory = os.path.join(tmpdir, 'hosts')
    with open(inventory, 'w') as f:
        f.write("localhost ansible_connection=local")

    # Create a ansible task
    task_path = os.path.join(tmpdir, 'test_ActionModule_run.yml')

# Generated at 2022-06-21 02:54:55.261991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creating new object of ActionModule
    action_module = ActionModule(connection=None, 
                                 task_queue_manager=None, 
                                 loader=None, 
                                 shared_loader_obj=None,
                                 path_info=None, 
                                 add_file_common=None, 
                                 role_params=None, 
                                 task_uuid=None, 
                                 task=None, 
                                 play_context=None, 
                                 new_stdin=None)
    # Asserting the object to be of class ActionModule
    assert action_module.__class__.__name__ == 'ActionModule'
    # Asserting the result to be of type dict
    assert isinstance(action_module.run(), dict)

# Generated at 2022-06-21 02:55:55.292766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)
    foo = ActionModule()
    assert foo._supports_check_mode == True
    assert foo._supports_async == True

# Generated at 2022-06-21 02:56:03.342101
# Unit test for constructor of class ActionModule
def test_ActionModule():

    plugin_name = 'service'
    task_vars = {'service_mgr': 'systemd'}
    mock_loader_obj = Mock(**{'module_loader.find_plugin_with_context.return_value': 'ansible.service_mgr.systemd'})
    mock_execute_module = Mock(return_value={'test': 'test'})

    # Create an instance of ActionModule

# Generated at 2022-06-21 02:56:07.385012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.task.action import ActionModule

    config = {'ANSIBLE_LOG_PATH': '/tmp/log.txt'}
    tmp = '/tmp/ansible.test'
    task_vars = {'ansible_service_mgr': 'service'}
    task = {'args': {}, 'delegate_to': 'host', 'action': 'action_module'}
    action_module = ActionModule(task, config, tmp, task_vars)

    assert action_module._supports_check_mode is True
    assert action_module._supports_async is True
    assert action_module._connection._shell.tmpdir == tmp
    assert 'run' in dir(action_module)

# Generated at 2022-06-21 02:56:19.652400
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    sys.path.append('../')

    from ansible_collections.ansible.legacy.plugins.actions.service import ActionModule
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_noop
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-21 02:56:20.393626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:56:28.557211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set arguments for method run
    tmp = None
    task_vars = {}
    # set expected result
    with pytest.raises(AnsibleAction, match='Could not detect which service manager to use. Try gathering facts or setting the "use" option.'):
        instance = ActionModule()
        instance.run(tmp=tmp,task_vars=task_vars)

# Generated at 2022-06-21 02:56:39.375565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={"args": {'name': 'dummy', 'state': 'dummy'}}, connection=None, play_context=None, loader=None,
                                 templar=None, shared_loader_obj=None)

    assert action_module.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:56:40.665887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	assert True, "Unit test not implemented"

# Generated at 2022-06-21 02:56:41.539268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:56:49.427879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action

# Generated at 2022-06-21 02:59:23.364605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # for coverage testing
    test_action = ActionModule(None, {}, {}, None)
    return test_action

# Generated at 2022-06-21 02:59:33.738829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    name = "ActionModule_run"
    print(name)

    # initialisations
    module_to_use = "auto"
    module_args = {"name": "httpd"}
    task_vars = {
        "ansible_facts": {
            "service_mgr": "systemd"
        }
    }
    tmp = "/home/ansible"
    task = {
        "args": {
            "use": module_to_use
        }
    }
    runner = ActionModule(task, "plugin")
    runner._connection = {
        "_shell": {
            "tmpdir": "/home/ansible"
        }
    }

    # HACK: task._parent._play._action_groups = {
    #     "all": {"name": ["name"]},
    #     "group": {"name

# Generated at 2022-06-21 02:59:34.670463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:59:43.396317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.task_include as task_include
    import ansible.playbook.block as block
    import ansible.playbook.role as role
    from ansible.playbook.task import Task
    from collections import namedtuple
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    variable_manager

# Generated at 2022-06-21 02:59:47.867570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def _assertion(results):
        assert results['ansible_facts']['ansible_service_mgr'] == 'ansible.legacy.service'

    mock_loader = Mock()
    mock_loader.module_loader = Mock()
    mock_loader.module_loader.has_plugin.return_value = True
    mock_loader.module_loader.find_plugin_with_context.return_value.resolved_fqcn = 'ansible.legacy.service'

    mock_task = Mock()
    mock_task.args = dict(use='auto')
    mock_task.delegate_to = None
    mock_task.async_val = False
    mock_task.async_val = False
    mock_task._parent = Mock()
    mock_task._parent._play = Mock()
    mock_

# Generated at 2022-06-21 02:59:51.491531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert module is not None


# Generated at 2022-06-21 03:00:03.490186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Return the module
    :return: the module
    """
    action_module = ActionModule()
    action_module._display = Display()
    action_module._shared_loader_obj = SharedPluginLoaderObj()
    # Create a task to test
    task_args = dict(
        name='foo'
    )
    task_vars = dict(
        ansible_facts=dict(
            ansible_service_mgr="systemd"
        )

    )
    task_path = 'test.test_module'
    # Create the task
    action_module._task = Task()
    action_module._task.args = task_args
    action_module._task.action = 'auto'
    action_module._task.module_defaults = None
    action_module._task.async_val = None
