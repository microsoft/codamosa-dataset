

# Generated at 2022-06-21 02:50:05.861508
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Get the action module object
    action_module_obj = ActionModule(load_action_plugins=False, task_uuid=None)

    # Check if the object is of type ActionModule
    if isinstance(action_module_obj, ActionModule):
        print("The object is of type ActionModule")

    # Check if the UNUSED_PARAMS list is not empty
    assert action_module_obj.UNUSED_PARAMS


# Generated at 2022-06-21 02:50:10.185587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule

    class FakeAction(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return tmp

    am = FakeAction(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.run() is None

# Generated at 2022-06-21 02:50:12.543584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run(tmp=None, task_vars=None)


# Generated at 2022-06-21 02:50:13.382288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__metaclass__ == type

# Generated at 2022-06-21 02:50:16.413093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    MyActionModule = ActionModule(None, dict(a=1, b=2), '', '', '', '', None)
    MyActionModule.run()

# Generated at 2022-06-21 02:50:20.343821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(task=dict(args=dict(use='systemd')))
    assert a.run() == dict(msg=dict(systemd='Found no matching hosts.'))

# Generated at 2022-06-21 02:50:32.125161
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:50:37.622338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # Constructs an instance of the first class
  action_module = ActionModule(loader=None, connection=None, templar=None, shared_loader_obj=None)

  # call method
  method_result = action_module.run(tmp=None, task_vars=None)
  assert method_result is not None

# Generated at 2022-06-21 02:50:42.840936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    action = action_loader._create_action_plugin('service', {'name': 'foo', 'use': 'systemd', 'state': 'started', 'enabled': True})
    result = action.run(task_vars={'ansible_facts': {'service_mgr': 'systemd'}})
    assert result.get('module_name') == 'systemd'
    assert result.get('module_args') == {'name': 'foo', 'enabled': True, 'state': 'started'}

# Generated at 2022-06-21 02:50:43.516261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #dummy_action = ActionModule()
    assert True

# Generated at 2022-06-21 02:51:03.330393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import json

    ansible_facts = {
        "ansible_service_mgr": "auto"
    }

    args = {
        "use": "auto"
    }

    m_run = {
        "changed": False,
        "module_stderr": "",
        "module_stdout": "",
        "msg": "Playbook executed successfully",
        "rc": 0
    }

    task_vars = {
        "ansible_facts": ansible_facts,
        "ansible_check_mode": False,
    }

    m = ActionModule()

    result = m.run(tmp=None, task_vars=task_vars)

# Generated at 2022-06-21 02:51:08.912954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Check that object is really an object of class ActionModule
    assert isinstance(am, ActionModule) == True

# Generated at 2022-06-21 02:51:18.248677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action1 = {}
    action1["action"] = "meta"
    action1["args"] = {}
    action1["args"]["_raw_params"] = "noop"
    action1["args"]["_uses_shell"] = False
    action1["args"]["_unsafe_writes"] = False

    action2 = {}
    action2["action"] = "shell"
    action2["args"] = {}
    action2["args"]["_raw_params"] = "echo hello world"
    action2["args"]["_uses_shell"] = False
    action2["args"]["_unsafe_writes"] = False

    action3 = {}
    action3["action"] = "service"
    action3["args"] = {}

# Generated at 2022-06-21 02:51:19.095432
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:51:20.493989
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	assert False, "No test of method run of class ActionModule"

# Generated at 2022-06-21 02:51:23.529207
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test for method run of class ActionModule
    """
    assert False

# Generated at 2022-06-21 02:51:34.768918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    test_task = Task()
    test_task._ds = dict(service='cron', name='cron', use='systemd')
    test_task.action = 'service'
    test_task.name = 'service'
    test_task.async_val = 0
    test_task._parent = Play()
    test_task._role = None
    test_task._block = None
    test_task._parent._loader = None


# Generated at 2022-06-21 02:51:41.911573
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Import packages
    import importlib
    import sys
    importlib.reload(sys)
    # Import test modules
    from ansible.plugins.action import ActionBase
    from ansible.utils.display import Display
    from units.compat.mock import patch
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.plugins.action import ActionBase as MockActionBase
    from units.mock.plugins.action import ActionModule as MockActionModule
    # Initialize objects
    args = dict()

# Generated at 2022-06-21 02:51:52.876983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_facts=dict(
            service_mgr='auto',
            ansible_service_mgr='auto',
        )
    )

    # Construct an instance of ActionModule
    action_mod = ActionModule(
        task=dict(action=dict(module='name', args=dict())),
        connection=dict(module='name', args=dict()),
        play_context=dict(check_mode=True, network_os='openswitch'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    try:
        # Test run method
        action_mod.run(task_vars=task_vars)
    except Exception as e:
        print(e)

# Generated at 2022-06-21 02:52:00.073068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    action_module = ansible.plugins.action.ActionModule(None, None, None, None)
    action_module._templar.template('{{ansible_facts.service_mgr}}') == 'systemd'
    ansible.plugins.action.ActionModule.run(action_module, None, None)

# Generated at 2022-06-21 02:52:17.012678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_action_module = ActionModule(None, None)
    assert isinstance(obj_action_module, ActionModule)

# Generated at 2022-06-21 02:52:18.982201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES is False

# Generated at 2022-06-21 02:52:27.578056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(
        task=dict(
            async_val='async',
            async_timeout=100,
            tags=['tag1', 'tag2', 'tag3'],
            args={
                'use': 'auto',
                'name': 'httpd',
                'state': 'started',
                'enabled': True
            },
            delegate_to='localhost',
            delegate_facts=True
        ),
        connection=dict(),
        play_context=dict(
            check_mode=True
        ),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    assert action_mod.TRANSFERS_FILES is False
    assert len(action_mod.UNUSED_PARAMS) == 1
    assert action_mod.UNUSED

# Generated at 2022-06-21 02:52:28.453434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:36.860601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import copy
    a = ActionModule(connection=None, task_vars=dict())
    assert a is not None
    assert isinstance(a.UNUSED_PARAMS, dict)
    assert isinstance(a.BUILTIN_SVC_MGR_MODULES, set)
    assert 'systemd' in a.UNUSED_PARAMS
    assert 'service' in a.BUILTIN_SVC_MGR_MODULES
    assert a._supports_check_mode
    assert a._supports_async
    b = copy.copy(a)
    assert b is not None
    assert a.UNUSED_PARAMS is b.UNUSED_PARAMS
    assert a.BUILTIN_SVC_MGR_MODULES is b.BUILTIN_SVC_MGR

# Generated at 2022-06-21 02:52:44.152463
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.connection import Connection
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import TaskHandler
    from ansible.inventory.manager import InventoryManager
    import json


# Generated at 2022-06-21 02:52:45.612265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-21 02:52:55.239502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {
        "name": "my-service",
        "state": "started",
        "pattern": "my-service",
        "sleep": "5",
        "unused-parameter": "ignored",
        "delegate_to": "delegating-host",
    }
    tmp = "/tmp/a-temporary-directory"
    task_vars = 'some-task-variables'

    from ansible.plugins.loader import manager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=manager, sources=None)
    play_context = PlayContext()

    # make sure we use the set variables
    play_context.variable_manager = variable_manager
    play_context.variable

# Generated at 2022-06-21 02:53:00.918128
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.playbook.task import Task

    from ansible.plugins.loader import shared_loader_obj, module_loader

    # create connection object
    from ansible.executor.playbooks import PlaybookExecutor
    from ansible.executor.playbook.play import Play
    from ansible.playbook.play import Play as Play2
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task as Task2
    from ansible.playbook.role.include import Include
    executor = PlaybookExecutor(tqm=None)
    play2 = Play2()
    executor._tqm._data = play2._variable_manager.get_v

# Generated at 2022-06-21 02:53:12.140630
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:53:43.922935
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.plugins.action as action
    import ansible.module_utils as mu
    import ansible.playbook.play_context as play_context
    import ansible.playbook.task_include as task_include
    import ansible.template as template

    fake_task = object()
    fake_task._ds = object()
    fake_task.args = {'use': 'auto'}
    fake_task._parent = object()
    fake_task._parent._play = object()
    fake_task._parent._play._action_groups = object()
    fake_task.async_val = 42
    fake_task.register = 'fake-register'

    play_context.PlayContext = object()

    task_include.TaskInclude = object()

    my_loader = object()
    my_loader.module_loader

# Generated at 2022-06-21 02:53:45.866058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    pass

# Generated at 2022-06-21 02:53:48.985647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule({'use': 'auto'}, {}, {}, {})
    action_module.BUILTIN_SVC_MGR_MODULES = set([])
    action_module.run()

# Generated at 2022-06-21 02:53:59.562817
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_args = {
        'name': 'test_name',
        'enabled': True,
        'state': 'started'
    }
    module_args = {'use': 'auto'}
    mock_task = MockTask(action_args, module_args)
    mock_connection = MockConnection()
    mock_loader = MockLoader()
    mock_shared_loader_obj = MockSharedLoaderObj(loader=mock_loader)

    action = ActionModule(task=mock_task, connection=mock_connection, play_context=None, loader=mock_shared_loader_obj, templar=None, shared_loader_obj=mock_shared_loader_obj)

    result = action.run()
    assert result['changed'] is True
    assert result['reboot_required'] is False

# Generated at 2022-06-21 02:54:10.380426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Patch the method _execute_module from the Ansible module action
    with patch.object(ActionBase, '_execute_module') as mock_execute_module:
        # Patch the method template from the Ansible templar
        with patch.object(ConnectionBase, '_run_module') as mock_run_module:
            # Create a new ActionModule object
            my_action = ActionModule(task=dict(action=dict(module_name='test_name', module_args=dict())))

            # Set the attributes of the ActionModule object
            my_action._task.args = {'use': 'auto'}
            my_action._task.delegate_to = None
            my_action._templar = MagicMock(name="templar")

            # Create a variable containing a mocked AnsibleFacts object
            mocked_ans_

# Generated at 2022-06-21 02:54:20.742290
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.play_context import PlayContext

    myContext = PlayContext()
    myContext.remote_addr = '127.0.0.1'


# Generated at 2022-06-21 02:54:22.008796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run()



# Generated at 2022-06-21 02:54:29.518812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, 'test_data', 'test_play', 1, 'test_loader', 'test_templar', 'test_shared_loader_obj', None, None, 'test_connection')
    assert action._task.async_val == 1
    assert action._task.block == []
    assert action._task.args == {}
    assert action._task.delegate_to == 'test_connection'
    assert action._task.loop is None
    assert action._task.name == 'test_name'
    assert action._task.notify == []
    assert action._task.when is True
    assert action._task.tags == []

# Generated at 2022-06-21 02:54:37.340762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that the constructor of superclass works (constructor of ActionBase class)

    # Make sure that task_vars is set to []
    task_vars = []

    # Make sure that action always return a dict
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.run(None, task_vars) == dict()

# Generated at 2022-06-21 02:54:49.708341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup:
    # Create an instance of the action module object
    action_module_obj = ActionModule()

    # Stub:
    # Use a stub to prevent run() actually running
    class StubExecutorModule(object):
        def __init__(self, task_vars):
            self._task_vars = task_vars
        def run(self, tmp=None, task_vars=None):
            return {}
    action_module_obj._execute_module = StubExecutorModule(None)

    # Test:
    # Call run() on the action module object
    # The following calling convention is from
    # http://docs.ansible.com/ansible/latest/modules/service_module.html#examples
    #- service: name=httpd state=restarted

# Generated at 2022-06-21 02:55:49.202211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    assert m.run()

# Generated at 2022-06-21 02:55:59.301082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.TRANSFERS_FILES is False
    assert am.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert am.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-21 02:56:02.337724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Pass the required and optional arguments of the `run` method.
    # Return an action result object.
    pass

# Generated at 2022-06-21 02:56:09.371437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(name='vim-enhanced', state='latest')),
        connection=dict(host=dict()),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module

# Generated at 2022-06-21 02:56:21.013770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def fm_list(list_):
        return list_

    action_module = ActionModule()
    result = action_module._execute_module(module_name='ansible.legacy.setup', module_args=dict(gather_subset='!all', filter='ansible_service_mgr'), task_vars={})
    assert result['ansible_facts']['ansible_service_mgr'] == 'systemd'
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True
    assert action_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-21 02:56:28.557182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # execute init method of constructor
    my_obj = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)
    
    # check if the instance created is of ActionModule
    assert my_obj._is_action_module

# Generated at 2022-06-21 02:56:29.093018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None

# Generated at 2022-06-21 02:56:41.284071
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import collections
    from ansible.executor.task_result import TaskResult

    from ansible.executor.module_common import get_action_args_with_defaults

    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import ActionModuleLoader

    # class ActionBase(object)
    myBase = ActionBase()  # No parameters
    # class ActionModule(ActionBase):

    myAM = ActionModule()  # No parameters

    # myAM._supports_check_mode = True

    print("\n***Test params***\n")
    print("ActionModule._supports_check_mode:%s" % myAM._supports_check_mode)

    # setTask(): Sets the task to be run by the module.
    myD = collections.Mapping()  # No parameters

# Generated at 2022-06-21 02:56:48.379362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.TRANSFERS_FILES == False
    assert module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert module.UNUSED_PARAMS['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']


# Generated at 2022-06-21 02:56:49.371772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:59:24.028373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.executor.task_result
    ansible.executor.task_result.ActionResult = ActionResult

    import ansible.plugins.action.core
    ansible.plugins.action.core.ActionBase = ActionBase

    import ansible.plugins.action.service
    ansible.plugins.action.service.ActionModule = ActionModule_for_test

    import ansible.plugins.action.service
    ansible.plugins.action.service.ActionModule_for_test = ActionModule_for_test

    import ansible.plugins.action.service
    ansible.plugins.action.service.ActionModule = ActionModule_for_test

    import ansible.plugins.action.service
    ansible.plugins.action.service.ActionBase = ActionBase

    import ansible.plugins.action.service

# Generated at 2022-06-21 02:59:33.340068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #test_ActionModule_constructor: The constructor should store the parameters it is passed
    p = ActionModule(None, None, None, None, None, None, None)
    #pylint: disable=protected-access
    assert 'UNUSED_PARAMS' == p._action._shared_loader_obj._action_loader._action_paths[0]['UNUSED_PARAMS']
    assert 'BUILTIN_SVC_MGR_MODULES' == p._action._shared_loader_obj._action_loader._action_paths[0]['BUILTIN_SVC_MGR_MODULES']
    #pylint: disable=protected-access


# Generated at 2022-06-21 02:59:39.811836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This function is used to test if the constructor of class ActionModule can called request.
    """
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-21 02:59:45.102411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Creating a mock object for ActionBase class
    class ActionBaseClass():
        def execute_module(self, module, tmp, task_vars, wrap_async):
            return {'result': 'module run'}

        def run(self, tmp, task_vars):
            return {'result': 'run'}

        def _load_name_to_path_map(self, *args, **kwargs):
            return {}

    class ActionModuleClass(ActionModule):

        def __init__(self):
            self.ActionBaseClass = ActionBaseClass()

        def _execute_module(self, *args, **kwargs):
            return self.ActionBaseClass.execute_module(*args, **kwargs)


# Generated at 2022-06-21 02:59:50.933169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None,
                                 shared_loader_obj=None,
                                 connection=None,
                                 play_context=None,
                                 loader_object=None,
                                 templar=None,
                                 task_vars=None,
                                 add_finalizer=None)
    assert action_module is not None