

# Generated at 2022-06-21 02:50:06.067898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert ActionModule
    except:
        print('FAILURE: Could not create an instance of ActionModule')
        assert False
    else:
        print('SUCCESS: Successfully created an instance of ActionModule')
        assert True

# Generated at 2022-06-21 02:50:11.905731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None, None)
    assert am is not None, "Creating instance of ActionModule should work"
    assert am._execute_module() is not None, "Method _execute_module() should return a result"
    assert am._execute_module(module_name=None) is not None, "Method _execute_module() should return a result"
    assert am.run() is not None, "Method run() should return a result"

# Generated at 2022-06-21 02:50:13.096685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run(tmp={}, task_vars={})

# Generated at 2022-06-21 02:50:16.349874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create object of ActionModule
    obj = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert obj is not None


# Generated at 2022-06-21 02:50:17.235181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:25.447781
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test the constructor to mke sure 'remote_user' is set as
    expected.
    """

    # Below is the construction of a valid payload to test
    # against
    module_args = dict(
        ANSIBLE_MODULE_ARGS={
            'delegate_to': None, 'use': 'auto',
            'name': 'asdf',
            'enabled': None, 'state': 'started',
            'enable': None, 'disable': None,
        },
        ANSIBLE_MODULE_KWARGS={},
        ANSIBLE_MODULE_REQUIRED_IF={},
    )
    task_vars = {'ansible_user_id': None}

# Generated at 2022-06-21 02:50:26.896439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "No tests for module ansible.plugins.action.service"

# Generated at 2022-06-21 02:50:35.871032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._display = Display()
    action_module._task = Task()
    action_module._task.args = {'pattern': 'cron', 'use': 'systemd'}
    action_module._task.action = 'service'
    action_module._task.delegate_to = None
    action_module._templar = MagicMock()
    action_module._templar.template("{{hostvars['%s']['ansible_facts']['service_mgr']}}" % action_module._task.delegate_to).return_value = 'auto'

    action_module._shared_loader_obj = SharedLoaderObj()
    action_module._shared_loader_obj.module_loader = PluginLoader()
    action_module._shared_loader_obj.module_

# Generated at 2022-06-21 02:50:44.445652
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Arrange
    plugin_loader = MagicMock()
    action_module = ActionModule(
        action_loader=plugin_loader,
        connection=None,
        play_context=None,
        new_stdin='',
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    action_module._execute_module = MagicMock()
    action_module._execute_module.return_value = {'ansible_facts':{'service_mgr': 'systemd'}}

    action_module._task = MagicMock()
    action_module._task.args = {}
    action_module._task.args['use'] = 'auto'
    action_module._task.async_val = False

    plugin_loader.has_plugin = MagicMock()
    plugin_

# Generated at 2022-06-21 02:50:55.133768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import json
    import unittest
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategies.linear import LinearStrategy
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for unit tests."""
        def v2_runner_on_ok(self, result, **kwargs):
            """Print a json representation of the result."""
            host = result._host
            print

# Generated at 2022-06-21 02:51:03.991045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test ActionModule constructor
    action_module = ActionModule()

# Generated at 2022-06-21 02:51:06.515571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-21 02:51:16.522072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import ansible.constants as C

    # the arguments to dict() are specified in the reference implementation of this method
    # it is a matter of finding them in the code

# Generated at 2022-06-21 02:51:20.719191
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    instance = ActionModule()
    result = instance.run(tmp='tmp', task_vars='task_vars')

    print(result)

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-21 02:51:33.529334
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pytest

    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.service_mgr import ServiceMgr
    from ansible.module_utils.facts.system.service_mgr import TestModule
    from ansible.module_utils._text import to_text
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.service import ActionModule
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector

    action_module = ActionModule(ActionBase)
    action_module._display = TestModule()
    action_module._display.verbosity = 5

# Generated at 2022-06-21 02:51:35.564455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-21 02:51:38.820913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None,None,None,None)
    module.run(tmp=None, task_vars=None)

# Generated at 2022-06-21 02:51:46.209322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class __module__:

        @staticmethod
        def fail_json(*args, **kwargs):
            import json
            print(json.dumps({'failed': True, 'msg': kwargs['msg']}))

        @staticmethod
        def exit_json(*args, **kwargs):
            import json
            print(json.dumps(kwargs))

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
            self.params = kwargs
            self.changed = False

# Generated at 2022-06-21 02:51:47.093667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:54.666894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    package_list = [
        {
            'name': 'ansible',
            'version': '2.7.0',
            'release': '1.fc28.noarch.rpm'
        },
        {
            'name': 'ansible-doc',
            'version': '2.7.0',
            'release': '1.fc28.noarch.rpm'
        },
        {
            'name': 'ansible-lint',
            'version': '3.4.21',
            'release': '1.fc28.noarch.rpm'
        }
    ]

    for package in package_list:
        module = ActionModule(None, None)

# Generated at 2022-06-21 02:52:16.067861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    module_loader = None
    display = Display()

# Generated at 2022-06-21 02:52:25.970409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.context import CLIContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader


    context._init_global_context(CLIContext())

    play_context = dict(
        become_method='sudo',
        become_user='root',
        check_mode=False,
    )
    play = Play().load({}, variable_manager={}, loader=action_loader)
    tqm = None
    loader.load_plugins()

# Generated at 2022-06-21 02:52:35.699088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'ansible_facts': {'service_mgr': 'systemd'}}
    task_args = {
        'name': 'ansible',
        'state': 'started',
    }
    specs = {
        '_templar': None,
        '_remove_tmp_path': None,
        '_shared_loader_obj': None,
    }

    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action._task = MockTask()
    action._connection = MockConnection()
    action._play_context = MockPlayContext()
    action._loader = MockLoader()
    action._templar = MockTemplar()

# Generated at 2022-06-21 02:52:41.576361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = type('object',(object,),{})
    host.get_vars = lambda: {}
    module_defaults = type('object',(object,),{})
    module_defaults.provider = {}
    task = type('object',(object,),{})
    task.args = {}
    task.module_defaults = module_defaults
    task.noop_on_check_mode = True
    task.run_once = True
    task.notify = []
    task.tags = []
    task.when = []
    task.action = 'service'
    task.args = {'use':'auto'}
    task.async_val = 0
    task._parent = type('object',(object,),{})
    task._parent._play = type('object',(object,),{})

# Generated at 2022-06-21 02:52:53.689903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    See if a ActionModule can be invoked with no arguments.
    """
    import tempfile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 02:53:05.048315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run_result = False
    try:
        import pymongo
        mongo_client = pymongo.MongoClient("mongodb://localhost:27017/")
        mongo_db = mongo_client["test_results"]
        mongo_collection = mongo_db["results"]
        mongo_collection.ensure_index("case_code", unique=True)
        mongo_collection.ensure_index("case_name", unique=True)
        run_result = True
    except:
        run_result = False

# Generated at 2022-06-21 02:53:13.997860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    task_vars = {'hostvars': {'node2': {'ansible_facts': {'service_mgr': 'sysvinit'}}}}
    task = {'async': 1, 'async_val': 2, 'args': {'use': 'auto'}, 'delegate_to': 'node2', 'module_defaults': 3}
    result = module.run(tmp=None, task_vars=task_vars)
    assert result == {'ansible_job_id': '373341002531.2867', 'failed': False, '_ansible_verbose_always': True,
                      'changed': False, 'msg': 'Job dispatched'}

# Generated at 2022-06-21 02:53:20.299104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True
    # obj = ActionModule(task=dict(),connection=dict(),play_context=dict(),loader=dict(),templar=dict(),shared_loader_obj=None)
    # results = obj.run()
    # assert False
    # assert "TODO" not in results
    # assert isinstance(results, dict)

# Generated at 2022-06-21 02:53:22.057892
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule '''
    pass

# Generated at 2022-06-21 02:53:31.301359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    if True:
        print(ActionModule().run(tmp=None, task_vars=dict()))

    # Test 2
    if True:
        print(ActionModule().run(tmp=None, task_vars=dict()))

    # Test 3
    if True:
        print(ActionModule().run(tmp=None, task_vars=dict()))

    # Test 4
    if True:
        print(ActionModule().run(tmp=None, task_vars=dict()))

if __name__ == "__main__":
    # Unit test for method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-21 02:54:09.712889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def load_expected_result(file_name: str) -> dict:
        result = {}
        with open(file_name, 'r') as f:
            for line in f:
                k, v = line.strip().split('=')
                result[k.strip()] = v.strip()
        return result

    params = load_expected_result('params_facts')

    connection = 'network_cli'
    options = {'gather_subset': 'all', 'filter': 'ansible_service_mgr'}
    task_vars = {'ansible_facts': {'ansible_service_mgr': 'service'}}

    task = ActionModule(connection=connection, task_vars=task_vars, options=options)
    print(task.params)
    print(params)


# Generated at 2022-06-21 02:54:19.725087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = Connection()
    task = Task()
    loader = TaskLoader()
    templar = Templar()
    display = Display()
    action_module = ActionModule(connection=connection, task=task, loader=loader, templar=templar, display=display)

    # Check constructor of class ActionModule
    assert action_module
    assert isinstance(action_module, ActionModule)
    assert action_module._supports_check_mode
    assert action_module._supports_async
    assert action_module._connection == connection
    assert action_module._task == task
    assert action_module._loader == loader
    assert action_module._templar == templar
    assert action_module._display == display

# Generated at 2022-06-21 02:54:28.161277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.loader import callback_loader
    from ansible.constants import DEFAULT_LOAD_CALLBACK_PLUGINS

    myinventory = InventoryManager(loader=DataLoader(), sources='localhost')
    variable_manager = VariableManager(loader=DataLoader(), inventory=myinventory)
    play_context = PlayContext()
   

# Generated at 2022-06-21 02:54:39.866150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Construct a dummy task
    class DummyTask():
        def __init__(self):
            self.async_val = 0
            self.args = dict(use='auto')
            self.collections = None
            self.module_defaults = dict()

    # Construct a dummy play
    class DummyPlay():
        def __init__(self):
            self._action_groups = dict()

    # Construct a dummy play context
    class DummyPlayContext():
        def __init__(self):
            self._play = DummyPlay()
            self.connection = 'local'

    # Construct a dummy variable manager
    class DummyVariableManager():
        def __init__(self):
            return

    my

# Generated at 2022-06-21 02:54:50.509633
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    test_action = ActionModule(task=Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(test_action) == ActionModule
    assert test_action.task == Task()
    assert test_action.connection is None
    assert test_action.play_context is None
    assert test_action.loader is None
    assert test_action.templar is None
    assert test_action.shared_loader_obj is None
    assert test_action.TRANSFERS_FILES

# Generated at 2022-06-21 02:54:51.874883
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule()

    assert module is not None

# Generated at 2022-06-21 02:55:00.397736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes
    # Constructor test:
    arguments = {'use': 'service'}
    task_vars = {}
    action_module = ActionModule(None, arguments, task_vars=task_vars, loader=None, templar=None, shared_loader_obj=None)

    # _supports_check_mode test:
    action_module._supports_check_mode = True
    assert action_module._supports_check_mode is True

    # _supports_async test:
    action_module._supports_async = True
    assert action_module._supports_async is True

# Generated at 2022-06-21 02:55:09.389691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(
        task=dict(args=dict(name='foo')))
    result = m.run(
        tmp='/foo/bar',
        task_vars=dict(ansible_facts=dict(service_mgr='systemd')))
    assert result['_ansible_no_log'] == False
    assert result['parsed'] == False
    assert result['skipped'] == False
    assert result['module'] == 'ansible.legacy.systemd'
    assert result['module_args'] == dict(name='foo')

# Generated at 2022-06-21 02:55:14.916564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    action = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    results = action.run(tmp, task_vars)

# Generated at 2022-06-21 02:55:19.774689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test ActionModule_run")
    # Test if the method run of ActionModule class can be called
    test_am = ActionModule(None, None)
    test_result = test_am.run(None, None)
    # Test if the result is the correct type
    assert isinstance(test_result, dict)

# Generated at 2022-06-21 02:56:15.247913
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule({},{},{}).__class__.__name__ == 'ActionModule'


# Generated at 2022-06-21 02:56:21.017741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('service')
    assert module.TRANSFERS_FILES == False
    assert module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert module.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }

# Generated at 2022-06-21 02:56:32.271011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    play_context = PlayContext()
    play_context._plugin_rules = {"action": ["%s.yml" % __name__]}
    task = dict(
        action="service",
        args=dict(name="httpd", state="started"),
        delegate_to="localhost",
    )
    play_context._set_from_task(task)
    play_context._task = task
    play_context._task.async_val = 0
    play_context._remote_tmp = '/home/admin/ansible/test'
    play_context._shell = 'shell'
    play_context._loader = 'loader'
    play_context._connection = 'connection'

    action_module = ActionModule

# Generated at 2022-06-21 02:56:42.037973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    mock_TaskResult = TaskResult
    mock_TaskResult.__dict__.clear()

    mock_TaskResult.exception = KeyError
    mock_TaskResult.exception.parsed = False
    mock_TaskResult.exception.msg = ''
    mock_TaskResult.failed = False
    mock_TaskResult.instance = {}
    mock_TaskResult.result = True

    mock_AnsibleActionFail = KeyError
    mock_AnsibleActionFail.__dict__.clear()
    mock_AnsibleActionFail.return_value = ''

    mock_AnsibleAction = KeyError
    mock_AnsibleAction.__dict__.clear()
    mock_AnsibleAction.return_value = ''


# Generated at 2022-06-21 02:56:49.380204
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    action = ActionModule(task=Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.UNUSED_PARAMS['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']
    assert action.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

# Generated at 2022-06-21 02:56:55.456419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = dict(
        name='foo',
        state='started',
        enabled=False,
    )
    act = ActionModule(None, module_args, None, None, None)
    assert not act._supports_check_mode
    assert not act._supports_async

# Generated at 2022-06-21 02:56:59.003411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule()._shared_loader_obj.module_loader.has_plugin('auto')
    assert not ActionModule()._shared_loader_obj.module_loader.has_plugin('ansible.legacy.service')

# Generated at 2022-06-21 02:57:10.714834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.compat.tests.mock as mock
    import ansible.compat.tests.module_utils as module_utils
    import ansible.plugins.action.service as service
    module_utils.basic.ANSIBLE_MODULE_UTILS = module_utils
    module_utils.basic.MODULE_REQUIRES = module_utils

    action_service = service.ActionModule(mock.MagicMock())
    action_service._shared_loader_obj = mock.MagicMock()
    action_service._shared_loader_obj.module_loader = mock.MagicMock()
    action_service._shared_loader_obj.module_loader.has_plugin = mock.MagicMock(return_value = True)
    action_service._connection = mock.MagicMock()
    action_service._connection._shell = mock

# Generated at 2022-06-21 02:57:13.342390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test case for ActionModule constructor.
    """
    action_module = ActionModule()

# Generated at 2022-06-21 02:57:15.091167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor with no arguments
    obj = ActionModule()


# Generated at 2022-06-21 02:59:47.034538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task=None)

# Generated at 2022-06-21 02:59:54.526292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils import context_objects as co
    import ansible.constants as C

    # Initializing the test variables