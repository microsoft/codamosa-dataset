

# Generated at 2022-06-21 02:50:04.328797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:50:05.474343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	print('test ActionModule run')

# Generated at 2022-06-21 02:50:15.685832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase

    action_module = ActionModule(task=None, connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    action_module._shared_loader_obj = action_module._shared_loader_obj
    action_module._task.args = dict()
    action_module._task.args=dict(use='auto')
    action

# Generated at 2022-06-21 02:50:24.974383
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import tempfile
    import io
    import copy

    tmp = tempfile.NamedTemporaryFile().name

    task_vars = {
        'ansible_facts': {'service_mgr': 'systemd'},
        'hostvars': {'127.0.0.1': {'ansible_facts': {'service_mgr': 'systemd'}}},
        'ansible_check_mode': False,
        'ansible_version': {'full': '2.7.6'},
    }

    task = type('task', (object,), {'args': {'name': 'nginx', 'use': 'auto', 'arguments': 'foo=bar'}, 'async_val': 42})

# Generated at 2022-06-21 02:50:28.494738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:50:29.036704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass #TODO

# Generated at 2022-06-21 02:50:39.402738
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Set up test data.
    mock_tmplr_data = {'ansible_facts': 'tmp_value'}
    mock_tmplr = mock.Mock()
    mock_tmplr.template.return_value = mock_tmplr_data

    mock_loader_obj = mock.Mock()
    mock_loader_obj.module_loader.has_plugin.return_value = True

    mock_task = mock.Mock()
    mock_task.args = {
        'use': 'auto',
        'test': 'true'
    }
    mock_task.delegate_to = None
    mock_task.async_val = True

    mock_display = mock.Mock()

    mock_connection = mock.Mock()

    # Set up mock object.
    mock_actionmod = mock

# Generated at 2022-06-21 02:50:43.492421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert get_action_args_with_defaults('ActionModule', {'name': 'test'}, {}, None) == {'name': 'test'}

# Generated at 2022-06-21 02:50:46.607613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    # TODO: improve
    assert isinstance(ActionModule(), ActionBase)

# Generated at 2022-06-21 02:50:50.655098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Require fail when use dict-like object as task args
    try:
        my_action_module = ActionModule(dict())
    except Exception:
        print("ActionModule constructor works properly in bad case")
        return 0
    return 1

# Generated at 2022-06-21 02:51:06.017016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'action_plugins.service_common'

    module = __import__(module_name, fromlist=[''])

    mocker_type(module, "get_action_args_with_defaults")
    mocker_type(module.ActionModule, "run")
    mocker_type(module.ActionModule, "execute_module")

    # Remove the default implementation to get more freedom for testing
    del module.ActionModule.run

    # List of methods that are supposed to be called
    calls = []

    def test_execute_module(self, *args, **kwargs):
        calls.append('execute_module')
        return {"test_output": "pewpew"}
    module.ActionModule.execute_module = test_execute_module


# Generated at 2022-06-21 02:51:16.335727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_options = {'connection': 'local', 'forks': 1, 'become': False, 'check': False, 'module_path': None, 'remote_user': 'root', 'private_key_file': None, 'ssh_common_args': '', 'ssh_extra_args': '', 'sftp_extra_args': '', 'scp_extra_args': '', 'become_method': 'sudo', 'become_user': 'root', 'verbosity': 0, 'accelerate_port': None, 'accelerate_timeout': 30, 'accelerate_connect_timeout': None, 'module_lang': None, 'become_ask_pass': None}
    loader = DictDataLoader({})
    variable_manager = VariableManager()

# Generated at 2022-06-21 02:51:18.419674
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()
    assert action_module



# Generated at 2022-06-21 02:51:18.875354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:21.461067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure invalid_use_parameter raises error of None, None, None and message
    module = ActionModule(None, {'use': 'invalid_use_parameter'})
    assert isinstance(module, ActionModule)



# Generated at 2022-06-21 02:51:25.728741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest
    from ansible.plugins.action.service import ActionModule

    action_module = ActionModule({}, {}, 'test')
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:51:27.165583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
# ################# END OF MODULE #########################

# Generated at 2022-06-21 02:51:36.120510
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:51:38.226612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #test hostvars argument
    #test gather_subset argument
    pass


# Generated at 2022-06-21 02:51:46.055486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.plugins.action import ActionModule as MockServiceActionModule
    from units.mock.plugins.action import ActionModule as MockSetupActionModule
    from units.mock.plugins.module_loader import MockModuleLoader
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    # Initialization of test data

# Generated at 2022-06-21 02:52:05.475424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(
        ansible_facts=dict(
            service_mgr='abc',
            ansible_service_mgr='xyz',
        ),
    )

    action = ActionModule({}, dict(
        use='auto',
        state='restarted',
        enabled='yes',
    ))

    result = action.run(task_vars=task_vars)
    assert result['changed']
    assert result['_ansible_module_name'] == 'ansible.legacy.service'

    action = ActionModule({}, dict(
        use='auto',
        state='restarted',
        enabled=False,
    ))

    result = action.run(task_vars=task_vars)
    assert result['changed']

# Generated at 2022-06-21 02:52:10.753665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(
            action=dict(
                service=dict()
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

# Generated at 2022-06-21 02:52:23.904919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    For all examples given in the documentation, this checks that the input is formatted as expected for
    each method.
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import json

    loader = DataLoader()
    variable_manager = VariableManager()
    loader.set_variable_manager(variable_manager)
    inventory = InventoryManager(loader, variable_manager, host_list = [])
   

# Generated at 2022-06-21 02:52:34.691994
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import json
    from ansible.module_utils.common.collections import ImmutableDict
    data = ImmutableDict({
        "action": "service",
        "ansible_facts": {
            "ansible_service_mgr": "auto"
        },
        "changed": False,
        "invocation": {
            "module_args": {
                "name": "foo"
            },
            "module_name": "service"
        }
    })
    print(sys.argv[1])
    if sys.argv[1] == "create":
        json.dump(data, sys.stdout)
    if sys.argv[1] == "remove":
        json.dump(data, sys.stdout)

# Generated at 2022-06-21 02:52:38.098089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	module = ActionModule()

	arguments = dict()
	arguments['use'] = 'auto'

	task = dict()
	task['args'] = arguments 

	module._task = task

	result = module.run(tmp=None, task_vars=None)

	assert result == dict()

# Generated at 2022-06-21 02:52:45.973876
# Unit test for constructor of class ActionModule
def test_ActionModule():
	running_result = dict(
				_ansible_verbose_always=True,
				_ansible_no_log=True,
				msg='',
				ansible_facts=dict(
					ansible_service_mgr='auto'),
				changed=False
				)
	expected_result = dict(
				_ansible_verbose_always=True,
				_ansible_no_log=True,
				msg='',
				ansible_facts=dict(
					ansible_service_mgr='auto'),
				changed=False
				)

	assert running_result == expected_result

# Generated at 2022-06-21 02:52:55.372794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #Test run function
    class FakeTask:
        class FakeDelegate:
            delegate_to = "localhost"
        delegate = FakeDelegate()
        async_val = False

        def __init__(self):
            self.args = dict()
    class FakeModuleLoader:
        def has_plugin(self, module_name):
            if module_name in ['ansible.legacy.service', 'ansible.legacy.setup']:
                return True
            return False
        def find_plugin_with_context(self, module_name, collection_list=None):
            m = Mock()
            m.resolved_fqcn = module_name
            return m

    class FakeConnection:
        class FakeShell:
            tmpdir = "/tmp"
        _shell = FakeShell()


# Generated at 2022-06-21 02:52:57.979386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert not ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 02:53:06.460136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instance of ActionModule class
    am = ActionModule(
        task=dict(
            args=dict(
                use=None,
            ),
            async_val=None,
            delegate_to=None,
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )

    # Instance of AnsibleModule class
    amm = am._execute_module(
        module_name='ansible.legacy.setup',
        module_args=dict(
            gather_subset='!all',
            filter='ansible_service_mgr',
        ),
        task_vars=None,
    )

    # Instance of ActionModule class

# Generated at 2022-06-21 02:53:15.762916
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create an object of class ActionModule
    actionModule = ActionModule(
        task=None,
        connection=None,
        _play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # Forcefully setting the below attributes of ActionModule for avoiding
    # 'ActionBaseUndefinedError' exception.
    # _supports_async is needed to avoid exception in run() method
    actionModule._supports_async = True
    # _supports_check_mode is needed to avoid exception in run() method
    actionModule._supports_check_mode = True

    # Invoke the run() method of the ActionModule
    result = actionModule.run(tmp=None, task_vars=None)

    # Verify the result

# Generated at 2022-06-21 02:53:41.542902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:53:43.085925
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule(None, None).run({})

# Generated at 2022-06-21 02:53:53.757521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-21 02:54:03.053957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is a unit test method for the run() function of class
    ansible.plugins.action.service.ActionModule.
    """
    # Define a mock context
    class MockContext(object):

        def __init__(self, fqcn, module_args, **kwargs):
            self.resolved_fqcn = fqcn
            self.module_args = module_args

    # Define a mock loader
    class MockLoader(object):

        def __init__(self, modules = []):
            self._modules = modules

        def find_plugin_with_context(self, module, **kwargs):
            for m in self._modules:
                if m.__name__ == module:
                    return MockContext(m, None, **kwargs)


# Generated at 2022-06-21 02:54:11.882756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockModule(object):
        BOOL_TRUE = (True, True)
        BOOL_FALSE = (False, False)

    class MockConfig(object):
        config = (None, None)

    class MockTemplar(object):
        def __init__(self):
            self.result = {}

        def template(self, params):
            return self.result.get(params, params)

    class MockTask(object):
        def __init__(self):
            self.args = {}
            self.module_defaults = {}

    class MockPluginLoader(object):
        def __init__(self):
            self.result = {}


# Generated at 2022-06-21 02:54:22.275471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("testing...")
    connection = IOMock()
    task_vars = {}
    tmp = 'tmp'
    task_args = {'chdir': 'chdir', 'pattern': 'pattern', 'runlevel': 'runlevel', 'sleep': 'sleep', 'state': 'state', 'use': 'use', 'enabled': 'enabled', 'arguments': 'arguments', 'args': 'args'}
    file_ = Mock()
    task = TaskMock(args=task_args)
    action = ActionModule(connection=connection, task=task, templar=file_, shared_loader_obj=file_, action_loader=file_)
    action.run(tmp=tmp, task_vars=task_vars)
    print('OK')


# Generated at 2022-06-21 02:54:30.836783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from nose.tools import assert_equals
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_failure
    from units.mock.plugins.action import MockActionBase

    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from units.mock.executor.task_queue_manager import MockTaskQueueManager


    # initialize needed objects

# Generated at 2022-06-21 02:54:37.143751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Start to test constructor of class ActionModule...')
    c = ActionModule(loader=None, task=None, connection=None)
    print(c)
    print('Type of c is:'+str(type(c)))
    print('Class %s is tested!' % c.__class__.__name__)


# Generated at 2022-06-21 02:54:38.216849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:54:50.046034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_bytes
    from ansible import context

    import os
    import json
    import sys

    context.CLIARGS = context.CLIARGS._replace(connection=to_bytes('local'))
    sys.path.append(os.path.dirname(__file__))

    # create data loader
    loader = DataLoader()
    # create inventory

# Generated at 2022-06-21 02:55:54.315995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for constructor of class ActionModule.
    """
    host = MagicMock()
    host.name = 'test_host'
    task = MagicMock()
    task._parent = MagicMock()
    task._parent._play = MagicMock()
    task._parent._play._action_groups = None
    task.args = {
        'use': 'auto',
    }
    action_module = ActionModule(task, host, "_shared_loader_obj")
    assert action_module.name == 'service'
    assert action_module.BUILTIN_SVC_MGR_MODULES == {'systemd', 'service', 'openwrt_init', 'sysvinit'}

# Generated at 2022-06-21 02:56:01.577128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit']), \
        "Builtin service manager modules mismatch! BUILTIN_SVC_MGR_MODULES: %s" % str(ActionModule.BUILTIN_SVC_MGR_MODULES)

    # Test Unused params - systemd
    assert 'pattern' in ActionModule.UNUSED_PARAMS['systemd'], \
        "Unused params systemd missing param 'pattern'"
    assert 'runlevel' in ActionModule.UNUSED_PARAMS['systemd'], \
        "Unused params systemd missing param 'runlevel'"

# Generated at 2022-06-21 02:56:04.641368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None,None,None)


# Generated at 2022-06-21 02:56:10.128242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import base64


# Generated at 2022-06-21 02:56:18.289624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a._supports_check_mode = True
    a._supports_async = True
    a._shared_loader_obj = None
    a._task = None
    a._connection = None
    a._templar = None
    a._display = None
    a._loader = None
    #a.run()
    # TODO: write a test
    pass

# Generated at 2022-06-21 02:56:18.969701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:56:23.467499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        action = dict(
            module = 'service',
            name = 'httpd',
            state = 'started',
        ),
        args = dict(
            use = 'auto',
        ),
    )
    task_vars = dict(
        ansible_facts = dict(
            service_mgr = 'auto',
        ),
        hostvars = dict(
            test_host = dict(
                ansible_facts = dict(
                    service_mgr = 'auto',
                ),
            ),
        ),
    )
    module = 'service'
    new_module_args = dict(
        ignore_errors = 'yes',
        name = 'httpd',
        state = 'started',
    )

    am = ActionModule()

# Generated at 2022-06-21 02:56:33.057372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import json
    import os
    import sys
    import socket

    # load test data
    test_data = json.load(open(os.path.join(os.path.dirname(__file__), 'ActionModule_data.json')))
    # fetch current IP address
    def get_ip():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            # doesn't even have to be reachable
            s.connect(('10.255.255.255', 1))
            IP = s.getsockname()[0]
        except:
            IP = '127.0.0.1'
        finally:
            s.close()
        return IP

    # get current os
    def get_platform():
        platform = sys.platform


# Generated at 2022-06-21 02:56:38.814274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import shutil
    import tempfile
    from ansible.module_utils.six import PY3, StringIO
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    if not PY3:
        import ansible.module_utils.basic

    class TestPlaybookExecutor(PlaybookExecutor):
        def __init__(self, playbooks, inventory, variable_manager, loader, options, passwords):
            self.loader = loader
            self.inventory = inventory
            self

# Generated at 2022-06-21 02:56:40.062544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-21 02:59:13.652206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test ActionModule.run()
    import ansible.plugins.action.service
    # Create an instance of the class to test
    action_module = ansible.plugins.action.service.ActionModule(None, None, None, None, None, None, None)

    # Prepare test data
    task_vars = {}
    tmp = None

    # Test "auto" service module
    # Test the first "if" block in the "auto" part
    action_module.run(tmp, task_vars)
    # Test the second "if" block in the "auto" part
    action_module.run(tmp, task_vars)
    # Test the third "if" block in the "auto" part
    action_module.run(tmp, task_vars)

    # Test a specific service module

# Generated at 2022-06-21 02:59:15.621106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, 'Unit test for method run of class ActionModule'

# Generated at 2022-06-21 02:59:16.424504
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert 1==1

# Generated at 2022-06-21 02:59:24.765244
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    class Task(object):
        args = {}
    class Connection(object):
        class Shell(object):
            tmpdir = 'tmp'
        _shell = Shell()
    module._task = Task()
    module._task.args = {'use': 'auto'}
    module._task.async_val = False
    module._task.delegate_to = None
    module._connection = Connection()
    module._display = object()
    module._supports_check_mode = True
    module._supports_async = True
    module._templar = object()
    module._shared_loader_obj = object()
    class ModuleLoader(object):
        def has_plugin(self, module):
            return True

# Generated at 2022-06-21 02:59:29.067594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    import json
    import os

    config = {
        "somedir": os.getcwd() + os.sep + "tests" + os.sep + "test_data_structure_plugin" + os.sep + "action" + os.sep + "action_plugins",
        "fact_cache": os.getcwd() + os.sep + "unit_tests" + os.sep + "test_data_structure_plugin" + os.sep + "cache" + os.sep + "facts",
    }

    source_data = open(config["fact_cache"] + os.sep + "ansible_facts.json", "r", encoding="utf-8")
    source = json.load(source_data)
    source_data.close

# Generated at 2022-06-21 02:59:35.096437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.system.service
    service_module = ansible.modules.system.service
    class DummyModule:
        def __init__(self):
            self.params = dict()
            self.params['name'] = 'foo'
            self.params['state'] = 'started'
            self.params['enabled'] = True
            self.params['pattern'] = 'foo'
            self.params['runlevel'] = 0

    class DummyConnection:
        class Shell:
            def __init__(self):
                self.tmpdir = 'tmp'

        def __init__(self):
            self._shell = DummyConnection.Shell()

    action_module = ActionModule()
    action_module._shared_loader_obj = DummyModule()
    action_module._connection = DummyConnection()
    action_module

# Generated at 2022-06-21 02:59:43.532622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            async_val='async_val',
            async_jid='async_jid',
            args={
                'state': 'state',
                'name': 'name',
                'enabled': 'enabled',
                'use': 'use',
                'daemon_reload': 'daemon_reload',
            }
        ),
        connection='connection',
        play_context=dict(
            check_mode='check_mode',
            network_os='network_os',
        ),
        loader='loader',
        templar='templar',
        shared_loader_obj='shared_loader_obj'
    )

    assert module._connection == 'connection'
    assert module._loader == 'loader'
    assert module._templar == 'templar'


# Generated at 2022-06-21 02:59:51.864171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import tempfile

    tempdir = tempfile.gettempdir()
    sys.path.insert(0, tempdir)
    try:
        # Test if this module is importable by
        # importing it and the creating an instance of it.
        import ansible.plugins.action.service as service
        module = service.ActionModule("setup.yml")
    except:
        raise
    finally:
        # Remove the test directory from the path if it already exists
        del sys.path[0]

test_ActionModule()

# Generated at 2022-06-21 02:59:58.908434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.BUILTIN_SVC_MGR_MODULES = set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert True

if __name__ == '__main__':
    test_ActionModule_run()