

# Generated at 2022-06-21 02:50:05.773962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO:
    pass

# Generated at 2022-06-21 02:50:17.026810
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup test inputs
    tmp = '/tmp'
    task_vars = {}

    # Setup mocks
    module = 'ansible.legacy.service'
    new_module_args = 'test'
    mock_execute_module = 'mock_execute_module'
    mock_remote_tmp = 'mock_remote_tmp'
    mock_remove_tmp_path = 'mock_remove_tmp_path'

    # Setup test class
    am = ActionModule(mock_execute_module, mock_remote_tmp, mock_remove_tmp_path)

    # Setup test class attributes
    am._task.async_val = 'async'
    am._task.args = new_module_args
    am._task.delegate_to = 'delegate_to'

# Generated at 2022-06-21 02:50:19.813009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Set up the class for unittest
    module = ActionModule(dict(), dict())
    # test one of the initialized value
    assert 'auto' == module.UNUSED_PARAMS['systemd'][0]

# Generated at 2022-06-21 02:50:20.985327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module != None



# Generated at 2022-06-21 02:50:24.874282
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-21 02:50:29.976269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    obj = ActionModule(task=Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = obj.run(tmp=None, task_vars=None)
    assert isinstance(result, TaskResult)
    assert result.is_skipped()

# Generated at 2022-06-21 02:50:34.658123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import action_loader

    result = action_loader.get('test', class_only=True)(connection_loader.get('local', '', module_loader))
    assert isinstance(result, ActionModule)

# Generated at 2022-06-21 02:50:40.491525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {
        'foo': 'bar',
        'service_mgr': 'systemd',
        'delegate_to': 'server-1'
    }
    task = {"args": {}, "delegate_to": 'server-1', "register": "service_mgr", "use": "auto"}
    action = ActionModule(task, task_vars=task_vars)
    print(action.run())


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:50:44.598447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct a ActionModule object
    action_module = ActionModule()
    # Check if a module is loaded by the ActionModule
    assert action_module._load_params() == None

# Generated at 2022-06-21 02:50:55.607977
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create an instance of the class to be tested,
    # and all required mock objects
    a = ActionModule(
        task={
            'async': 50,
            'args': {
                'test arg': 'test value'
            }
        }
    )
    a._shared_loader_obj = None
    a._templar = None
    a._display = None
    if a.BUILTIN_SVC_MGR_MODULES and a.BUILTIN_SVC_MGR_MODULES[0]:
        pass
    else:
        a.BUILTIN_SVC_MGR_MODULES.add('service')

    # test the run() method
    (failed, result) = a.run(tmp=None, task_vars=None)
    assert not failed

# Generated at 2022-06-21 02:51:14.121782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils
    import ansible.plugins

    class FakeConnection():
        class _shell:
            tmpdir = 'test_tmpdir'

        def get_option(self, name):
            return 'test_host'

    connection = FakeConnection()

    class FakeDisplay():
        def __init__(self, connection):
            self.connection = connection

        def display(self, display_msg, color=None):
            pass

        def vvvv(self, display_msg, host=None):
            pass

        def debug(self, display_msg, host=None):
            pass

        def warning(self, display_msg):
            pass

    display = FakeDisplay(connection)

    class FakeTask():
        def __init__(self, connection, module_defaults):
            self.connection = connection
            self.module

# Generated at 2022-06-21 02:51:23.050498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test case 1
    '''
    my_action = ActionModule()
    my_action._supports_check_mode = True
    my_action._supports_async = True
    my_action._task_vars = {}
    my_action.__init__()
    my_action.run()

    '''
    Unit test case 2
    '''
    my_action = ActionModule()
    my_action._supports_check_mode = True
    my_action._supports_async = True
    my_action._task_vars = {"module": "mymodule"}
    my_action.__init__()
    my_action.run()

# Generated at 2022-06-21 02:51:24.267898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:51:35.058187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.plugins.action import ActionBase
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.template import Templar
    from ansible.utils.display import Display
    from ansible.vars import VariableManager

    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    def setUpModule():
        # Import plugins and set up basic module_utils
        add_all_plugin_dirs()
        connection = Connection(None)

        # Set up connection plugins
       

# Generated at 2022-06-21 02:51:44.954127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    import unittest
    import ansible
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from AnsibleModuleMock import AnsibleModuleMock
    from AnsibleModuleMock import get_test_AnsibleModuleMock
    from ansible_collections.misc.not_a_real_collection.plugins.modules.testing.unit.compat import mock


# Generated at 2022-06-21 02:51:54.112126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # set up fake play iterator
    play = Play().load({'name': 'test_play'}, variable_manager=None, loader=None)
    fake_play_iterator = PlayIterator(play, play._play_context)
    the_host = Host('hostname')

    # set up fake task
    task = Task().load({'name': 'test_task'}, variable_manager=None, loader=None)

# Generated at 2022-06-21 02:52:00.862356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.TRANSFERS_FILES == False
    assert action_module.UNUSED_PARAMS.keys() == ['systemd']
    assert action_module.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    dummy_executor = Dummy_Executor()
    dummy_task = Dummy_Task()
    dummy_play_context = Dummy_Play_context()

# Generated at 2022-06-21 02:52:13.312917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile
    import shutil
    import ansible.utils.module_docs as mod_docs
    from ansible.utils.path import unfrackpath
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    #from ansible.executor.task_queue_manager import TaskQueueManager

    context = {}


# Generated at 2022-06-21 02:52:15.632087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # nothing to do


# Generated at 2022-06-21 02:52:17.101135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, "run")

# Generated at 2022-06-21 02:52:37.632186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We do not have a mock task object, but we need the attribute self._task.args to be set.
    # We use an empty dict.
    mock_task = type('obj', (object,), {'args': {}})
    mock_task.args = {}
    a = ActionModule(task=mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test the case when args.use is 'auto'
    a._task.args['use'] = 'auto'

    # Test the case when module is None or 'auto' or not in plugin
    if 'auto' == a._task.args['use']:
        a._shared_loader_obj.module_loader.has_plugin = MagicMock(return_value=False)

        #

# Generated at 2022-06-21 02:52:40.381267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run
    """
    # TODO We need to implement this unit test
    pass

# Generated at 2022-06-21 02:52:44.567419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, '/tmp/ansible_service_payload', 10, True)
    assert am.TRANSFERS_FILES == False
    assert am.UNUSED_PARAMS == {'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args']}
    assert len(am.BUILTIN_SVC_MGR_MODULES) == 4


# Generated at 2022-06-21 02:52:45.469447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:50.662673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection = Connection()
    task_vars = dict(ansible_facts=dict(ansible_service_mgr='auto'))
    tmp = None
    assert ActionModule(connection, tmp, task_vars).run(tmp, task_vars)

# Generated at 2022-06-21 02:53:04.033203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Work with fake models here
    module_loader = 'ansible.plugins.action.service.module_loader'
    InventoryManager._create = lambda self, hosts=None, host_list=None, cache=False, vault_password=None, loader=None, sources=None, **kwargs: "Inventory"
    Action

# Generated at 2022-06-21 02:53:13.101738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    Connection = collections.namedtuple('Connection', 'host')
    TmpPath = collections.namedtuple('TmpPath', 'path')
    TaskVars = collections.namedtuple('TaskVars', 'hostvars')

    class Templar(object):
        def __init__(self, hostvars):
            self.hostvars = hostvars

        def template(self, template):
            return self.hostvars.get(template, None)

    class Loader(object):
        def __init__(self, module_loader):
            self.module_loader = module_loader

    class Module(object):
        def __init__(self, name, args, kwargs):
            self.name = name
            self.args = args
            self.kwargs = kwargs


# Generated at 2022-06-21 02:53:23.445996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    # Create a task
    task = Task()
    task._role = None
    task._block = None
    task._play = Play().load({}, variable_manager={}, loader=None)
    task._play._included_files = []
    task._play._basedir = '.'
    task._play._parent_uuids = []
    task._play._uuid = '8a3a8747-3b3d-4c0d-a9e0-7f5e5459303a'
    task.deprecate = 'deprecate'
    task.notify = []
    task._parent = task
    task._role = None
    task._task_fields = {}

# Generated at 2022-06-21 02:53:32.777580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.callback import CallbackModule
    import os

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 02:53:37.555886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # See tests/lib/galaxy/test/unit/plugins/action/test_service.py for more tests
    # The code below is a placeholder which allows this module to be imported
    # so that test_service can be run
    pass

# Generated at 2022-06-21 02:54:12.144031
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock facts.
    task_vars = {
        'ansible_facts': {
            'service_mgr': 'systemd'
        }
    }

    options = {
        'module': 'systemd',
        'name': 'foo',
        'state': 'started',
        'enabled': False
    }

    # Mock task.
    task = {
        'args': options
    }

    # Mock loader.
    loader = {
        'find_plugin_with_context': lambda module_name, collection_list: 'Mock_Plugin_Class'
    }

    # Instantiate the class ActionModule.
    action_module = ActionModule(task, 'generated', 'dummy_connection', loader=loader)

    # Invoke the run method.

# Generated at 2022-06-21 02:54:15.886842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Call method to test function
    module = ActionModule(None, {}, None, None)

    # Show why it failed the test
    msg = ''
    try:
        module.run(None, None)
    except Exception as e:
        msg = str(e)
    assert msg == '', msg


# Generated at 2022-06-21 02:54:17.428075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    return am

# Generated at 2022-06-21 02:54:20.177256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    assert am is not None
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 02:54:25.261088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # basic test, does not actually execute anything
    module = ActionModule(task=dict(action=dict(use='auto')))
    test_task_vars = dict(ansible_facts=dict())
    results = module.run(task_vars=test_task_vars)
    assert results.get('changed'), results

# Generated at 2022-06-21 02:54:32.296008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    
    args = dict(
        name='test_service',
        state='started',
        enabled=True,
        pattern='test_pattern',
    )

# Generated at 2022-06-21 02:54:41.140096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.cli.adhoc import AdHocCLI
    from ansible.plugins.action import ActionBase

    context.CLIARGS = AdHocCLI.parse()

    args_dict = {
        'name': 'test',
        'use': 'systemd'
    }

    #Test to check args
    am = ActionModule(None, args_dict, None, None)

    #Module is executed and the result is fetched.
    am._execute_module = lambda *args, **kwargs: {
        'failed': False,
        'invocation': {'module_args': 'test'},
        'changed': True
    }

    #Test to check result

# Generated at 2022-06-21 02:54:45.683753
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    class MockPlayContext(PlayContext):
        pass

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources='localhost,')
    fake_variable_manager = VariableManager()
    fake_task = Task()

    acm = ActionModule(fake_task, fake_variable_manager, fake_loader, None, fake_inventory, MockPlayContext())

# Generated at 2022-06-21 02:54:52.013070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up objects for test
    action = ActionModule(task=dict(), connection=mockConnection(), play_context=PlayContext())
    # Run test
    result = action.run()
    # Assert test result

# Generated at 2022-06-21 02:54:59.586326
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Empty task
    task = {}
    # Empty task_vars
    task_vars = {}
    # Empty action_base.action_loader
    action_loader = {}
    # Empty connection
    connection = {}
    # Empty play_context.CLIARGS
    cliargs = {}

    # Instantiate ActionModule class
    action_module = ActionModule(
        task = task,
        connection = connection,
        play_context = cliargs,
        loader = action_loader,
        templar = None,
        shared_loader_obj = None
    )

    assert action_module is not None

# Generated at 2022-06-21 02:56:02.808514
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved

    display = Display()
    task = Task()

    var_manager = VariableManager()
    var_manager.set_inventory(Inventory(host_list=['localhost']))

    action_module = ActionModule(task, display, var_manager)
    assert action_module is not None

# Generated at 2022-06-21 02:56:07.281706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pprint
    from ansible.plugins.action.service import ActionModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.vars import combine_v

# Generated at 2022-06-21 02:56:10.392884
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule.run")
    module = ActionModule()
    taskvars = {}
    result = module.run(None, taskvars)
    return True

# Unit test if method run is working with correct parameters

# Generated at 2022-06-21 02:56:11.838090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # TODO implement test

# Generated at 2022-06-21 02:56:13.307269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    r=ActionModule()

# Generated at 2022-06-21 02:56:16.769086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("STUB: No unit test implemented for module ansible.plugins.action.service")

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:56:19.475703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''

    obj = ActionModule()
    print(obj.run())

# Generated at 2022-06-21 02:56:30.396782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    def _execute_module(module_name=None, module_args=None, task_vars=None, wrap_async=False):
        return {'failed': True, 'msg': 'Dummy execute module'}

    module = ActionModule()
    module._execute_module = _execute_module
    module._templar = None
    module._shared_loader_obj = None
    module._display = None
    module._task = None

    result = module.run(None, None)

    assert isinstance(result, TaskResult)
    assert result.is_failed()

# Generated at 2022-06-21 02:56:41.534488
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {
            'name': 'test',
            'action': {
                '__ansible_module__': 'service',
                '__ansible_arguments__': 'name=foo',
                '__ansible_facts__': dict(),
                '__ansible_action_name__': 'test',
                },
            'async': 1,
            'delegate_to': 'foo',
            }
    am = ActionModule(task, dict())
    assert am._supports_async == True
    assert am._supports_check_mode == True
    assert am._task.async_val == 1
    assert am._task.args['name'] == 'foo'
    assert am._task.delegate_to == 'foo'
    assert am._task.name == 'test'

# Generated at 2022-06-21 02:56:49.583812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dData = {
        'action': 'service',
        'args': {
            'name': [
                'sshd',
                'vsftpd'
            ],
            'use': 'auto',
            'state': 'started'
        },
        'collections': [],
        'delegate_to': None,
        'loop': [],
        'loop_args': {},
        'module_defaults': {},
        'register': '',
        'when': True
    }
    obj = ActionModule(None, dData)
    assert obj is not None

# Generated at 2022-06-21 02:59:32.338844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("TESTING _run method of class ActionModule")
    args = {'use': 'auto', 'name': 'sshd', 'state': 'started'}
    action = ActionModule(None, args, task_vars=None)
    print("ACTION: ", action)
    result = action.run(tmp=None, task_vars=None)
    print("RESULT: ", result)


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-21 02:59:35.285925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert (action_module.TRANSFERS_FILES == False)

# Generated at 2022-06-21 02:59:43.596929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import mock
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.service import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.module_utils._text import to_text
    from ansible.executor.task_result import TaskResult

    # Mock data for TaskQueueManager
    mock_ci = mock.create_autospec(TaskQueueManager)
    mock_ci._final_q = mock.MagicMock(side_effect=None)

    # Method

# Generated at 2022-06-21 02:59:48.034209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.context import context as an_context
    

# Generated at 2022-06-21 02:59:48.705310
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-21 02:59:52.915504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task["async"] = None
    task["args"] = dict()
    task["args"]["use"] = "sysvinit"
    action = ActionModule(None, task, None, None, None, None, None, None)
    assert (action is not None)
    assert (not action._supports_check_mode)
    assert (action._supports_async)

# Generated at 2022-06-21 03:00:03.864243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.normal import ActionModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    import pytest
    fake_loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=fake_loader, sources='')
    variable_manager.set