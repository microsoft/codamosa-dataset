

# Generated at 2022-06-21 02:50:15.823904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible import context
    from ansible.plugins.action.service import ActionModule
    from ansible.module_utils.six import PY3

    # Setup the class object we're testing
    module_args = dict(
        name='test_service',
        state='started',
    )
    set_module_args(module_args)
    am = ActionModule(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext())
    am._shared_loader_obj = ImmutableDict(**{
        'module_loader': MockModuleLoader()
    })
    module_name = 'ansible.legacy.service'

# Generated at 2022-06-21 02:50:23.556342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('test_playbook/playbooks/roles/apt/tasks/main.yml', {}, {}, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None
    # Test the BUILTIN_SVC_MGR_MODULES
    assert action.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}

# Generated at 2022-06-21 02:50:29.261652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_plugin = ActionModule('mock', 'myname', 'mypath')
    assert action_plugin._connection is 'mock'
    assert action_plugin._name is 'myname'
    assert action_plugin._parent is 'mypath'
    assert isinstance(action_plugin, ActionBase)

# Generated at 2022-06-21 02:50:29.753237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True == True

# Generated at 2022-06-21 02:50:30.353121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:34.166389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module._supports_async == True
    assert action_module._supports_check_mode == True

# Generated at 2022-06-21 02:50:37.620929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    # test_actionmodule = ActionModule()
    # assert test_actionmodule is not None
    pass

# Generated at 2022-06-21 02:50:44.825740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._shared_loader_obj = object  # hack to avoid AttributeError on module._shared_loader_obj
    module._task = object  # hack to avoid AttributeError on module._task
    module._connection = object  # hack to avoid AttributeError on module._connection
    module._execute_module = lambda *args, **kwargs: dict(ansible_facts=dict(service_mgr='auto'))
    module._display = object  # hack to avoid AttributeError on module._display
    module._templar = object  # hack to avoid AttributeError on module._templar

    # setup 'auto' tests

# Generated at 2022-06-21 02:50:56.182630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # 0. Define facts
    module_loader = '<module_loader>'
    play_context = '<play_context>'
    tmp_path = '<tmp_path>'

    # 1. Create a ActionModule object
    my_action_module = ActionModule(
        task=None,
        connection='<connection>',
        _play_context=play_context,
        loader=module_loader,
        templar='<templar>',
        shared_loader_obj='<shared_loader_obj>',
    )

    # 2. Check the properties of ActionModule object
    assert my_action_module._supports_async is True
    assert my_action_module._supports_check_mode is True

# Generated at 2022-06-21 02:50:58.524018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 02:51:06.516437
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule()
  assert am is not None

# Generated at 2022-06-21 02:51:15.872869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    from unit.mock.loader import DictDataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DictDataLoader({
        "test.yml": """
- hosts: localhost
  tasks:
    - name: test
      service:
        name: foo
        state: stopped
"""
    })

    inventory = InventoryManager(loader=loader, sources="localhost,")

# Generated at 2022-06-21 02:51:23.303553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.errors as errors

    # instantiate an object of ActionModule class
    act = ActionModule(0, 'test', {'negate': False, 'name': 'test', 'use': 'auto'}, '/home/vagrant/.ansible/tmp/ansible-tmp-1586237167.758025-231048013366361')

    # call method run
    # assert as follows:
    # if no exception is thrown by method run, then it passes
    try:
        act.run(tmp='None', task_vars={})
    except Exception as e:
        assert e is None

# Generated at 2022-06-21 02:51:23.658132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:51:24.009571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:51:34.922363
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockConnection(object):
        # pylint: disable=unused-argument
        def __init__(self, host, port, user, ansible_ssh_pass, private_key_file, *args, **kwargs):
            pass

        def exec_command(self, cmd, tmp_path, sudo_user=None, sudoable=False, executable='/bin/sh', in_data=None, su=None, su_user=None):  # pylint: disable=redefined-builtin
            if 'echo $PATH' in cmd:
                return '1', '2', 0
            elif 'sudo -H -S -n  -u root /bin/sh -c ' in cmd:
                return '', '', 0
            else:
                raise Exception('unexpected command: %s' % cmd)


# Generated at 2022-06-21 02:51:39.834275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = {}
    test_obj = ActionModule(d, '', '', '')
    print('test_ActionModule: ')
    print(test_obj)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:51:52.378554
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import yaml
    from collections import namedtuple

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible_collections.ansible.community.plugins.module_utils.legacy_ansible_service_mgr import ActionModule

    # Create a task
    class Task(object):
        def __init__(self, args=None, async_val=None, delegate_to=None, module_defaults=ImmutableDict()):
            self.delegate_to = delegate_to
            self.async_val = async_val
            self.module_defaults = module_defaults
            self.args = args or dict()

        @property
        def _parent(self):
            return self

        @property
        def _play(self):
            return self


# Generated at 2022-06-21 02:51:55.793023
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance
    action_mod = ActionModule()

    # Check the object's class type
    assert type(action_mod) == ActionModule

# Generated at 2022-06-21 02:51:56.611029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:10.562523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-21 02:52:23.840686
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import tempfile
    import os
    import shutil
    import tempfile
    import json

    try:
        import __builtin__ as builtins  # python2
    except ImportError:
        import builtins  # python3

    class AnsibleActionMock(object):
        def __init__(self, result):
            self.result = result

        def run(self, tmp=None, task_vars=None):
            return self.result

    class AnsibleModuleMock(object):
        def __init__(self, result):
            self.result = result

        def run(self, module_name, module_args=None, task_vars=None, wrap_async=None):
            return self.result


# Generated at 2022-06-21 02:52:34.662807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    task = MagicMock()
    action = ActionModule(task, connection=None, tempdir=None, loader=None, templar=None, shared_loader_obj=None)

    # test with success
    action._execute_module = MagicMock(return_value={'action_module': 'test'})
    action._task = MagicMock(args={'use': 'auto'})
    action._display = MagicMock()
    action._display.vvvv = MagicMock(return_value=None)
    action._display.warning = MagicMock(return_value=None)
    task_vars = {'ansible_facts': {'service_mgr': 'auto'}}
    result = action.run(tmp=None, task_vars=task_vars)
    action._remove_tmp_

# Generated at 2022-06-21 02:52:39.377441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.loader import action_loader

    from ansible.utils.display import Display
    display = Display()

    block = Block()

# Generated at 2022-06-21 02:52:41.683563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 02:52:53.757579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    from ansible.plugins.action.service import ActionModule
    from ansible.plugins.loader import ActionModuleLoader
    import ansible.utils
    import ansible.constants

    # make the module seem like it exists
    p = os.path.join(ansible.constants.DEFAULT_MODULE_PATH, 'system', 'ping.py')
    with open(p, 'w+') as f:
        f.write('#!/usr/bin/python')
    os.chmod(p, 0o755)

    # make a fake action plugin
    class PluginModule(object):
        def __init__(self):
            self.name = 'ping'


# Generated at 2022-06-21 02:52:55.193876
# Unit test for constructor of class ActionModule
def test_ActionModule():
   am = ActionModule()
   assert am is not None

# Generated at 2022-06-21 02:53:05.191628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ This function is a unit test for method run of class ActionModule. """

    # test instantiation of class ActionModule
    action_module = ActionModule()

    # disable the display of warnings and debug
    action_module._display.verbosity = 0

    # test the run method
    # test the run method in case of an exception
    # NOTE: since the run method has to many explicit dependencies,
    # we can only test the case that an exception is raised
    assert action_module.run() == dict(
        msg="'use' is not set, defaulting to 'auto'",
        failed=True,
        exception=AnsibleActionFail("Could not detect which service manager to use. Try gathering facts or setting the "
                                    "\"use\" option."))

# Generated at 2022-06-21 02:53:10.559536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import task

    # create an object of ActionModule class
    action_module = ActionModule(task.Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # check if ActionModule class is subclass of ActionBase class
    assert issubclass(ActionModule, task.BaseAction)

# Generated at 2022-06-21 02:53:12.378174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = {'use': 'auto'}
    module.run()

# Generated at 2022-06-21 02:53:50.456792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the run method of class ActionModule.
    """
    module = ActionModule()

    # Set up attributes of ActionModule
    module._task = 'mock_task'
    module._loader = 'mock_loader'
    module._shared_loader_obj = 'mock_shared_loader_obj'
    module._templar = 'mock_templar'
    module._connection = 'mock_connection'
    module._play_context = 'mock_play_context'
    module._display = 'mock_display'
    module._task.args = {'use': ''}
    module._task.delegate_to = 'mock_delegate'
    module._task.async_val = 'mock_async_val'

# Generated at 2022-06-21 02:53:57.380770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule.__doc__ is not None)
    assert(ActionModule.__name__ is not None)
    assert(ActionModule.BUILTIN_SVC_MGR_MODULES is not None)
    assert(ActionModule.UNUSED_PARAMS is not None)
    a = ActionModule()
    assert(a.run() is not None)

# Generated at 2022-06-21 02:54:09.409827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.systemd as systemd
    import ansible.plugins.action.freebsd_service as freebsd_service
    import ansible.plugins.action.openwrt_init as openwrt_init
    import ansible.plugins.action.sysvinit as sysvinit
    import ansible.plugins.action.daemontools as daemontools
    import ansible.plugins.action.service as service
    import ansible.plugins.action.win_service as win_service

    # test for Auto
    # test for systemd
    # test for freebsd
    # test for openwrt
    # test for sysvinit
    # test for daemontools
    # test for service
    # test for win_service

# Generated at 2022-06-21 02:54:15.762125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        obj = ActionModule(connection=None, task=None, task_vars=None, templar=None, shared_loader_obj=None, debug=None)
    except Exception as e:
        assert False, "Failed to instantiate ActionModule"


# Generated at 2022-06-21 02:54:23.475479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class under test
    connection = dict(tmp=dict())
    action_module = ActionModule(execute_module=dict(), connection=connection, task_vars=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # test that the method under test fails if first argument is not set
    try:
        action_module.run(tmp=dict())
        assert False
    except AssertionError:
        pass

    # test that the method under test fails if first argument is not dict
    try:
        action_module.run(tmp=dict(), task_vars='task_vars')
        assert False
    except AssertionError:
        pass

    # test that the method under test fails if second argument is not set

# Generated at 2022-06-21 02:54:27.628359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(
        task=dict(args=dict(name='test')),
        connection=dict(),
        play_context=dict(become=False),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert a._task.args['name'] == 'test'

# Generated at 2022-06-21 02:54:30.259341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    # Task is not defined
    assert m.run() == {}

# Generated at 2022-06-21 02:54:40.562274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    from ansible.plugins.action.service import ActionModule
    import ansible.module_utils.facts.system.service_mgr
    import ansible.module_utils.facts.system.systemd
    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils import facts
    import ansible.plugins.loader
    from ansible.module_utils._text import to_bytes
    import json
    import sys
    import os
    import pytest

    # Create a mock module
    module = ansible.plugins.action.ActionBase()
    module.runner = ansible.executor.task_queue_manager.TaskQueueManager(None, None, None, None, None, None)

# Generated at 2022-06-21 02:54:40.945087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:54:41.346134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:55:52.206504
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.service import ActionModule
    from ansible.plugins.connection.connection_info import ConnectionInformation
    from ansible.plugins.loader import connection_loader, action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role import Role
    from ansible.cli import CLI
   

# Generated at 2022-06-21 02:55:53.455131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:55:57.624230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the object instance
    '''
    module = ActionModule()

    # Check whether the transfer_files is False
    assert not module.TRANSFERS_FILES
    '''
    pass

# Generated at 2022-06-21 02:55:58.447695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Hello World!")

# Generated at 2022-06-21 02:56:04.439678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager

    # Create a new instance of ActionModule that will be used for testing
    action_plugin = action_loader.get('service', class_only=True)
    assert action_plugin is not None, 'Could not create a new instance of ActionModule'

    # Create a new instance of VariableManager that will be used for testing
    variable_manager = VariableManager()

    # Create a new instance of TaskBase that will be used for testing
    class Test_TaskBase:
        ''' Class to be used to create an instance of TaskBase that can be used for testing '''

# Generated at 2022-06-21 02:56:10.339565
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test inputs
    #   tmp:  (None)
    #   task_vars:  (None)
    tmp = None
    task_vars = None

    # create new instance of ActionModule
    am = ActionModule()

    # call method run of ActionModule
    result = am.run(tmp=tmp, task_vars=task_vars)
    return result

# main function entry point

# Generated at 2022-06-21 02:56:18.972729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service
    import ansible.module_utils.ansible_release as ansible_release
    import ansible.module_utils.facts.system as facts_system
    facts_system.AnsibleModule = None
    ansible.plugins.action.service.AnsibleModule = None
    ansible.module_utils.ansible_release.AnsibleModule = None
    obj = ActionModule()
    assert obj is not None

# Generated at 2022-06-21 02:56:20.119140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test class constructor
    :return: None
    '''
    assert ActionModule is not None

# Generated at 2022-06-21 02:56:28.807365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_action_base = ActionBase()
    mock_action_module = ActionModule(
        task = mock_action_base,
        connection = mock_action_base,
        play_context = mock_action_base,
        loader = mock_action_base,
        templar = mock_action_base,
        shared_loader_obj = mock_action_base
    )

    assert mock_action_module

# Generated at 2022-06-21 02:56:40.977114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    import shutil

    import ansible.playbook.play_context
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.ssh_functions import check_for_controlpersist

    class MockShell(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

# Generated at 2022-06-21 02:59:22.972862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Expected results
    expected_action_module = ActionModule(load_plugins=True, play_context=None, local_action=None, task_loader=None, shared_loader_obj=None, from_local=False)

    expected_action_module._supports_check_mode = True
    expected_action_module._supports_async = True

    # Real values
    real_action_module = ActionModule(load_plugins=True, play_context=None, local_action=None, task_loader=None, shared_loader_obj=None, from_local=False)

    real_action_module._supports_check_mode = True
    real_action_module._supports_async = True

    assert expected_action_module == real_action_module


# Generated at 2022-06-21 02:59:33.597615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = get_action_module_class('service')()
    module._supports_check_mode = True
    module._supports_async = True

    module._shared_loader_obj.module_loader.has_plugin('auto')
    module._templar.template('{{ansible_service_mgr}}')

    found_plugin = {}
    def has_plugin(self, name):
        if name in found_plugin:
            return found_plugin[name]
        return False

    module._shared_loader_obj.module_loader.has_plugin = has_plugin

    setattr(module._task, '_parent', False)
    setattr(module._task, '_play', False)
    setattr(module._task, '_action_groups', False)

# Generated at 2022-06-21 02:59:43.111782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    raw_task = dict(
        action=dict(
            module='service',
            use='auto'
        ),
        delegate_to='example.com',
        async_val=10,
        args=dict(
            name='serviceX',
            state='started',
            enabled='yes'
        )
    )

# Generated at 2022-06-21 02:59:45.562190
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule({},{})
    assert ac is not None

# Generated at 2022-06-21 02:59:54.107291
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class AnsibleModule:
        def __init__(self, argument_spec, supports_check_mode=False, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None, required_together=None,
                     required_one_of=None, add_file_common_args=False):
            pass

    task_vars = {}
    module_defaults = {}
    action_groups = {}
    delegate_to = None
    async_val = False
    connection = None
    tmp = None
    super_connection = None
    play_context = None
    loader = None
    shared_loader_obj = None
    templar = None
    display = None


# Generated at 2022-06-21 03:00:01.582995
# Unit test for constructor of class ActionModule