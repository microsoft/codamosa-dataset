

# Generated at 2022-06-21 02:50:11.219499
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._connection._shell.tmpdir = "www.tmpdir.com"
    action_module._task.args = {'service': 'sb', 'use': 'auto'}
    action_module._task.delegate_to = None
    action_module._task.module_defaults = None
    action_module._task._parent._play._action_groups = None
    action_module._templar = "www.templar.com"
    action_module._shared_loader_obj.module_loader.has_plugin = MagicMock(return_value=False)
    action_module._execute_module = MagicMock()
    action_module._

# Generated at 2022-06-21 02:50:11.726971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:50:14.270528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=1, connection=1, play_context=1, loader=1, templar=1, shared_loader_obj=1)
    assert action_module is not None

# Generated at 2022-06-21 02:50:16.823112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    em = Connection('testhost', 1234, 'testuser', 'ssh')
    x = ActionModule(em, 'test play', 'test_task', '/test/test.yml', 'testhost')
    print(x)


# Generated at 2022-06-21 02:50:26.721745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.executor import task_queue_manager, task_executor
    from ansible.inventory import inventory
    from ansible.config.manager import ConfigManager

    context.CLIARGS = {}
    context.CLIARGS['module_path'] = []

    config_manager = ConfigManager()
    config_manager.loader = config_manager.get_loader_for_path('/etc/ansible')
    config_manager._read_config_data(data=dict(DEFAULT=dict(module_defaults=dict(service='systemd'))))

    loader = config_manager._loader
    var_manager = task_executor.VarsManager()
    inventory = inventory.Inventory(loader=loader, variable_manager=var_manager, host_list='localhost')

# Generated at 2022-06-21 02:50:35.737864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod is not None

    task = mod._task
    del mod._task

    assert mod.ACTION_WARNINGS == {
        'deprecated': [],
        'removed': [],
    }
    assert mod._supports_async == True
    assert mod._supports_check_mode == True
    assert mod.BYPASS_HOST_LOOP == False
    assert mod.NO_LOG == False
    assert mod.TRANSFERS_FILES == False
    assert mod.RETRYABLE == False

    mod._task = task

    assert mod.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}


# Generated at 2022-06-21 02:50:38.693096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor with args
    assert isinstance(ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None), ActionModule)

# Generated at 2022-06-21 02:50:45.205642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.cli.adhoc
    import ansible.playbook.play
    
    # Create a temporary file in directory AnsibleModuleTest
    fh, module_name = tempfile.mkstemp(dir = 'AnsibleModuleTest')
    os.close(fh)
    # Delete the temporary file
    def cleanup():
        os.remove(module_name)
    # Make sure we delete the file after the test
    request.addfinalizer(cleanup)

    # Create a temporary file in directory AnsibleModuleTest
    fh, hosts_name = tempfile.mkstemp(dir = 'AnsibleModuleTest')
    os.close(fh)
    # Delete the temporary file
    def cleanup():
        os.remove(hosts_name)
    # Make sure we delete the file after the test

# Generated at 2022-06-21 02:50:46.049694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:50:57.173432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(
            args={},
            async_val=False,
            delegate_to='localhost',
            delegate_facts=False,
            become=False,
            become_method='sudo',
            become_user='test',
            loop='test',
            no_log=False,
            register='test',
        ),
        connection='local',
        play_context=dict(
            check_mode=False,
            diff=True,
            network_os='test',
            remote_addr='test',
            remove_tmp=True,
        ),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
        filesystem=dict(),
    )
    assert am.TRANSFERS_FILES

# Generated at 2022-06-21 02:51:08.640834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    module._task.args = {
        'use': 'auto'
    }

    # Case 1
    module.run()

    # Case 2
    module.run()

    # Case 3
    module.run()

# Generated at 2022-06-21 02:51:14.543799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    AM = ActionModule(task=dict(args = dict(name = 'foo', state = 'present', sleep = 3), _parent = dict(_play=dict(_action_groups = dict(all= dict()), _action_plugins = []))), connection=dict())
    assert AM.run(tmp='/tmp', task_vars=dict(ansible_facts = dict(service_mgr = 'service'))) == dict(failed=True,msg='Could not detect which service manager to use. Try gathering facts or setting the "use" option.')

# Generated at 2022-06-21 02:51:18.935162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_module = ActionModule({'use': 'systemctl'})
    test_module.run()
    return 0

if __name__ == '__main__':
    exit(test_ActionModule_run())

# Generated at 2022-06-21 02:51:24.449690
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.constants as C
    import ansible.module_utils
    C.DEFAULT_MODULE_LANG = 'en_US.UTF-8'
    ansible.module_utils.basic.MODULE_COMPLEX_ARGS = {}
    ansible.module_utils.basic.MODULE_REQUIRE_ARGS = {}
    ansible.module_utils.basic.MODULE_NO_JSON = False
    ansible.module_utils.basic.MODULE_SUPPORT_CHECKMODE = False
    ansible._ = dict()
    args = dict(name='foo')
    set_module_args(args)
    import ansible.plugins
    args = dict(gather_subset='!all', filter='ansible_service_mgr')
    hostvars = dict()

# Generated at 2022-06-21 02:51:26.562558
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #assert 2 == 2
    assert True == True


# Generated at 2022-06-21 02:51:35.908228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockTask():
        def __init__(self, delegate_to, module_defaults, async_val, args):
            self._parent = MockParent()
            self.delegate_to = delegate_to
            self.module_defaults = module_defaults
            self.async_val = async_val
            self.args = args
            self.args['use'] = 'auto'
        
        def _parent(self):
            return self._parent
    
    class MockParent():
        def __init__(self):
            self._play = MockPlay()
        
        def _play(self):
            return self._play
    
    class MockPlay():
        def __init__(self):
            self._action_groups = None
    
    class MockExecutor():
        def __init__(self):
            self

# Generated at 2022-06-21 02:51:45.270332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.parsing.dataloader import DataLoader

    # Initialize variables
    playbook = Play()
    context = PlayContext()
    inventory = InventoryManager(loader = DataLoader())
    variable_manager = VariableManager(loader = DataLoader(), inventory = inventory)

# Generated at 2022-06-21 02:51:46.711385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 02:51:54.566046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = Host('127.0.0.1')
    host.set_variable('ansible_connection', 'local')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    host.set_variable('ansible_python_version', '2.7.15')
    host.set_variable('ansible_system', 'Linux')
    host.set_variable('ansible_distribution_major_version', '3.10')
    host.set_variable('ansible_distribution', 'Ubuntu')
    host.set_variable('ansible_distribution_version', '16.04')

# Generated at 2022-06-21 02:52:04.532938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins import module_loader

    # Given: a ansible task with:
    #   delegate_to: localhost
    #   use: auto
    #   state: started
    #   name: foo
    #   delegate_facts: True
    task_args = {
        'delegate_to': 'localhost',
        'use': 'auto',
        'state': 'started',
        'name': 'foo'
    }
    delegate_to = 'localhost'

# Generated at 2022-06-21 02:52:26.257818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import types
    import collections
    import tempfile

    # Create a temporary file and directory
    tmpdir = tempfile.mkdtemp()
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create a "mock" class and call its method run
    mock_self = types.SimpleNamespace()

    mock_self.delegate_to = "test"
    mock_self._task = types.SimpleNamespace()
    mock_self._task.async_val = False
    mock_self._task.args = {}
    mock_self._task.args['use'] = 'auto'

    mock_self._task.delegate_to = "test"
    mock_self._task.module_defaults = {}
    mock_self._task.collections = [1, 2, 3]
    mock

# Generated at 2022-06-21 02:52:29.359045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:52:33.442692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task_vars = {}
    mock_action_base = ActionBase()
    mock_action_module = ActionModule(mock_task_vars, mock_action_base)
    expected_result = {'ansible_loop_var': 'item', 'ansible_facts': {}}
    assert mock_action_module.run() == expected_result

# Generated at 2022-06-21 02:52:43.343436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager, DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager, TaskQueueManagerResult
    from ansible.executor.process.worker import WorkerProcess
    import ansible.constants
    import os

    # Create a mock task
    mock_loader = DataLoader()
    mock_inventory = InventoryManager(loader=mock_loader, sources=["localhost"])
    variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)
    play_context = PlayContext()

# Generated at 2022-06-21 02:52:52.495035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor name does not start/end with underscore
    assert not hasattr(ActionModule, '_ActionModule__init__')
    # Constructor name is not double underscore
    assert not hasattr(ActionModule, '__init__')
    # Constructor name is not double underscore
    assert not hasattr(ActionModule, '__init__')
    # Constructor name is not double underscore
    assert str(ActionModule.__init__).startswith('<slot wrapper')
    # Constructor name is not double underscore
    assert str(ActionModule.__init__).endswith('object at 0x')

# Generated at 2022-06-21 02:53:04.674975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.plugins.loader import find_plugin_file
    from ansible.plugins.connection.local import Connection
    from ansible.plugins.task.action import ActionModule
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.executor.process.result import Result
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # setup
    collection_path = find_plugin_file(
        'service.py', __file__,
        subdir='../../plugins/action/',
        onlyif=lambda x: os.path.isfile(x))

# Generated at 2022-06-21 02:53:08.557113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # action = ActionModule(task=None, connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    #
    assert True

# Generated at 2022-06-21 02:53:16.934167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules import service
    import ansible.plugins.action
    import ansible.executor.module_common
    import ansible.executor.task_result
    import ansible.plugins.loader
    import ansible.template
    import ansible.utils.unsafe_proxy
    import ansible.vars.hostvars

    a = service.ActionModule()

    class ExecutorModuleCommon(object):
        def __init__(self):
            self.action_groups = {}

    class ExecutorTaskResult(object):
        def __init__(self):
            self.result = {}

    class Executor(object):
        def __init__(self):
            self.module_common = ExecutorModuleCommon()
            self

# Generated at 2022-06-21 02:53:24.592550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    mod_path = "ansible.builtin.service"
    file_path = "/path/to/ansible_collections/ansible/builtin/plugins/modules"
    context = class_loader.find_plugin(mod_path, mod_args=None, class_only=True, ignore_deprecated=None)
    module_defaults = '{"arg_yay":"yay","arg_gonna_be":"changed"}'
    _action_groups = {"test":"test"}
    task = Task()
    task.async_val = True
    task.args = {"arg_yay":"yay","arg_gonna_be":"changed"}
    module._shared_loader_obj.module_loader.has_plugin()
    task.async_val = False

# Generated at 2022-06-21 02:53:25.079577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:53:52.019323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:53:55.919092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # constructors for class ActionModule
    action_module = ActionModule.__new__(ActionModule)

    # instance attributes for class ActionModule
    action_module.noop_on_check_mode = True
    action_module.noop_on_check_mode = False

# Generated at 2022-06-21 02:53:57.005286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:53:58.898785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:54:03.933528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Get a class object
    action_class = ActionModule(load_plugins=False)

    #Test attributes of object
    assert action_class._supports_async == True
    assert action_class._supports_check_mode == True

# Generated at 2022-06-21 02:54:05.781124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test action_module run begin")
    print("test action_module run end")

# Generated at 2022-06-21 02:54:06.754447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass


# Generated at 2022-06-21 02:54:10.952244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-21 02:54:21.635973
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock class for module_loader
    class module_loader:
        def has_plugin(self, module):
            if module == 'auto':
                return False
            else:
                return True
        def find_plugin_with_context(self, module, collection_list):
            if module == 'auto':
                return

    # Mock class for AnsibleModule
    class AnsibleModule:
        def __init__(self, module_loader):
            self.module_loader = module_loader
        def _execute_module(self, module_name, module_args, task_vars, wrap_async):
            return {}

    # Mock class for ActionBase
    class ActionBase:
        def __init__(self, AnsibleModule):
            pass
        def run(self):
            return {}

    # Mock class for ActionBase
   

# Generated at 2022-06-21 02:54:28.758398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import count
    from ansible.utils import template
    import ansible.constants as C

    my_task = dict()
    my_task['args'] = dict()
    my_task['args']['name'] = 'test'
    my_task['args']['state'] = 'test'
    my_task['args']['use'] = 'auto'

    my_task['action'] = 'test'

    my_task['delegate_to'] = None
    my_task['delegated_vars'] = None

    my_task['_role'] = None

# Generated at 2022-06-21 02:55:28.887313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(None, {}, {}, {})
    assert isinstance(actionModule, ActionModule)

# Generated at 2022-06-21 02:55:40.779467
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Arrange
    action = ActionModule(None, None)
    action._supports_check_mode = True
    action._supports_async = True

    # Act
    result = action.run()
    # Not sure what to do with the result here

    # Assert


# Arrange

# Generated at 2022-06-21 02:55:43.558754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(loader=None, connection=None, play_context=None)
    assert a._connection == None

# Generated at 2022-06-21 02:55:53.152298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test environment
    import os
    import sys
    import time
    import tempfile
    import shutil
    from datetime import datetime
    from unittest.mock import Mock

    script_path = os.path.dirname(os.path.abspath(__file__))
    module_utils_path = os.path.join(script_path, 'module_utils')
    sys.path.append(module_utils_path)

    import ansible_utils

    # Create test directories
    tmp_dir = tempfile.mkdtemp(prefix='unittest_service_')
    orig_cwd = os.getcwd()
    os.chdir(tmp_dir)

    # Create a test playbook
    test_playbook_path = 'test_service.yml'
    test_playbook_

# Generated at 2022-06-21 02:56:00.454348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ########################################################################################
    #
    # Unit test for "run" method of class ActionModule
    #
    ########################################################################################

    # Test Node
    #
    #      (self._task)                                                                                   (self._connection)
    #
    #      AnsibleActionFail('Could not detect which service manager to use. Try gathering facts or setting the "use" option.')
    #
    # Successor Nodes
    #

    module = ActionModule()

    module.run()

# Generated at 2022-06-21 02:56:12.165904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    my_task = Task()
    my_task.args['use'] = 'auto'
    my_play = Play()
    my_play.connection = 'local'
    my_play.tasks = [my_task]
    my_play.hosts = ['localhost']
    my_play.name = 'My Play'
    my_play.stdout

# Generated at 2022-06-21 02:56:16.340172
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    import ansible

    # Act, Assert do not raise exception while trying to run
    act_module = ActionModule()
    act_module.run(None, None)

# Generated at 2022-06-21 02:56:20.064182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Check that we can invoke the module's run method"""

    # Make a new object to store generated object in
    am = ActionModule()

    # Make a test object to insert into `am`
    am._task = object()
    return am.run()

# Generated at 2022-06-21 02:56:22.912873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for run method of ActionModule
    :return: None
    """
    pass  # No unit test exists

# Generated at 2022-06-21 02:56:32.878252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_loader_obj = MagicMock()
    mock_loader_obj.filter_loader.module_loader.has_plugin.return_value = True

    mock_play_context = MagicMock()
    mock_play_context.connection = 'smart'
    mock_task_vars = dict()

    mock_shared_loader_obj = MagicMock()
    mock_shared_loader_obj.module_loader.has_plugin.return_value = True

    mock_execute_module = MagicMock()

    am = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=mock_play_context, loader=mock_loader_obj, shared_loader_obj=mock_shared_loader_obj, templar=MagicMock(),
                      execute_module=mock_execute_module)

    #

# Generated at 2022-06-21 02:58:57.327128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.service as service
    module = service.ActionModule()

    assert module.run(None, None) is not None

# Generated at 2022-06-21 02:58:58.589815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:59:03.885296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule(
        task=dict(args=dict(name='httpd', state='started'), async_val=60, delegate_to='localhost',
                  connection='local', module_defaults=dict(), register='httpd_service'),
        connection=dict(tmpdir='/tmp', _shell=dict(tmpdir='/tmp')),
        task_vars=dict(
            ansible_facts=dict(service_mgr='systemd'),
            hostvars=dict(localhost=dict(
                ansible_facts=dict(service_mgr='systemd')))
        ),
        play_context=dict(check_mode=True)
    )
    assert c is not None

# Generated at 2022-06-21 02:59:04.697359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:59:13.964389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    action_module._supports_check_mode = True
    action_module._supports_async = True

    action_module._task.args["use"] = "auto"
    action_module._task.args["name"] = "ansible-test"
    action_module._task.args["state"] = "started"

    action_module._execute_module = lambda a, b, c, d=None: b
    action_module.BUILTIN_SVC_MGR_MODULES = set(['openwrt_init', 'service', 'systemd', 'sysvinit'])

    # Test for module == "auto"
    module = action_module.run(tmp=None, task_vars=None)["module_name"]
    assert module == "service"

    action_

# Generated at 2022-06-21 02:59:23.520913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing with positive set of inputs
    # Creating the object of class ActionModule
    module = ActionModule()
    # Creating the object of class Task
    task = Task()
    task.args = {'use': 'auto'}
    # Creating the object of class Executor, to call the method find_needle()
    exec_obj = Executor()
    # Creating the object of class Playbook, to pass the test_loader
    # to the method find_needle()
    play = Playbook()
    play.loader = exec_obj.loader
    # Passing the task and the play object to method find_needle()
    module.find_needle = exec_obj.find_needle
    # Passing task to the method run
    result = module.run(task=task, connection=None)
    assert result == {}

# Generated at 2022-06-21 02:59:33.763133
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.normal import ActionModule as ActionNormalModule

    class ActionTask:
        class ActionPlay:
            class ActionInventory:
                def __init__(self):
                    self.hosts=['1.1.1.1']
                def get_hosts(self, pattern):
                    return self.hosts
            class ActionVariableManager:
                def __init__(self):
                    self.extra_vars={}
                def get_vars(self, play=None, host=None, task=None, include_hostvars=True, include_delegate_to=True):
                    return self.extra_vars

# Generated at 2022-06-21 02:59:38.004139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule._connection = None
    ActionModule._task = None
    action_module_obj = ActionModule()
    action_module_obj._play_context = None
    action_module_obj._shared_loader_obj = None
    action_module_obj._templar = None
    action_module_obj._task_vars = None
    action_module_obj._display = None
    action_module_obj._loader = None
    action_module_obj._templar = None

# Generated at 2022-06-21 02:59:39.425556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-21 02:59:40.190662
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
