

# Generated at 2022-06-21 02:50:11.289961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import find_plugin
    find_plugin('core')
    from ansible.executor.process.result import Result
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import merge_hash
    from ansible.vars.hostvars import HostVars
    from ansible.utils.display import Display

    action

# Generated at 2022-06-21 02:50:12.501328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert action is not None

# Generated at 2022-06-21 02:50:14.031919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run() is not None

# Generated at 2022-06-21 02:50:15.725062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule._supports_check_mode is True
    assert actionModule._supports_async is True



# Generated at 2022-06-21 02:50:24.974617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import find_plugin
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from io import StringIO
    import json

    # Set up mock objects
    loader = DataLoader()

# Generated at 2022-06-21 02:50:26.678730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule({})
    assert isinstance(a, ActionModule)

# Generated at 2022-06-21 02:50:27.204963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:50:31.374742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import action
    action_obj = action.ActionModule(None, None, None, None, None, None, None)
    my_action_obj = ActionModule(None, None, None, None, None, None, None)

    assert type(action_obj) == type(my_action_obj)

# Generated at 2022-06-21 02:50:32.662372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-21 02:50:33.970555
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    print(m)

# Generated at 2022-06-21 02:50:54.888052
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Expected assertion information
    assert_expect_info = { 'error_msg': '', 'error_name': '' }

    # Expected task information
    task_info = {}

    # Expected result information
    result = {}

    # Expected action information
    action = ActionModule()

    # Run method run test
    result = action.run(task_info, result)
    assert 'ansible_facts' in result
    assert result['ansible_facts']['service_mgr'] == 'auto' 
    assert 'ansible_module_results' in result
    assert result['ansible_module_results']['ansible_facts']['service_mgr'] == 'auto' 
    assert result['ansible_module_results']['rc'] == 0


# Generated at 2022-06-21 02:51:02.771245
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(actionmodule, ActionModule) is True
    assert isinstance(actionmodule._task, type(None)) is True
    assert isinstance(actionmodule._connection, type(None)) is True
    assert isinstance(actionmodule._play_context, type(None)) is True
    assert isinstance(actionmodule._loader, type(None)) is True
    assert isinstance(actionmodule._templar, type(None)) is True
    assert isinstance(actionmodule._shared_loader_obj, type(None)) is True
    assert actionmodule._supports_check_mode is True
    assert actionmodule._supports_async is True

# Generated at 2022-06-21 02:51:14.298231
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def fake_execute_module(*args, **kwargs):
        if kwargs.get('module_name', '') == 'ansible.legacy.setup':
            return {
                'ansible_facts': {
                    'ansible_service_mgr': 'systemd'
                }
            }
        return {
            'changed': True
        }

    ansible_action = ActionModule(
        task=dict(
            action='service',
            name='httpd',
            state='started',
            use='auto',
        ),
        connection=dict(
            host=dict(
                name='hostname'
            )
        ),
        task_vars=dict(),
    )

    ansible_action._execute_module = fake_execute_module
    ansible_action._shared_loader_obj = fake_execute

# Generated at 2022-06-21 02:51:23.900709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.context import CLIContext
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    display = Display()
    ctx = CLIContext(display)
    context._init_global_context(ctx)

    shared_loader_obj = action_loader._create_shared_loader_obj()

    fixture_action = {
        'name': 'some_service',
        'state': 'running',
    }

    fixture_task = {
        'args': fixture_action,
        'delegate_to': False,
        'module_defaults': {},
        'collections': [],
        'async_val': 0,
    }


# Generated at 2022-06-21 02:51:33.203139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Stub of dict of TaskExecutor
    task_executor = {}
    # Stub of dict of AnsibleTask
    ansible_task = {'args': {}}
    # Stub of dict of TaskVars
    task_vars = {}
    test_action_module = ActionModule(task_executor, ansible_task, connection=None, templar=None, shared_loader_obj=None)
    # Check result from run() method
    assert test_action_module.run(tmp=None, task_vars=task_vars) == {'ansible_facts': {'service_mgr': 'auto'}}

# Generated at 2022-06-21 02:51:36.397214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    # unit test comment. Method run has no test case.
    pass

# Generated at 2022-06-21 02:51:45.433588
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = '127.0.0.1'
    task_vars = dict(ansible_all_ipv4_addresses=["10.1.1.111", "10.1.1.222", "192.168.1.1"], ansible_facts=dict())
    connection = Connection(host)
    loader = DictDataLoader({
        "ansible.legacy.service": DictDataLoader({
            "module_utils": "ansible.module_utils.service",
        }),
    })
    action_module = ActionModule(connection, loader, task_vars, '', False, tmpdir=None)
    task_vars['ansible_facts'] = {
        'service_mgr': 'auto',
    }
    task_vars['ansible_service_mgr'] = 'auto'


# Generated at 2022-06-21 02:51:50.843589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is an unit test for the constructor of class ActionModule."""
    action = ActionModule()
    assert action is not None
    assert action.BUILTIN_SVC_MGR_MODULES is not None
    assert action.UNUSED_PARAMS is not None
    assert action.TRANSFERS_FILES is False

# Generated at 2022-06-21 02:52:03.230167
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    import ansible.constants
    import tempfile
    import shutil

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    action = ActionModule(task=dict(action=dict(__ansible_action__='service')))
    action._remove_tmp_path = lambda x: True  # mock the _remove_tmp_path function


# Generated at 2022-06-21 02:52:07.542985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._supports_check_mode == True
    assert action_module._supports_async == True


# Generated at 2022-06-21 02:52:20.962826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:52:21.488551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:27.720880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # testing with action_plugin and module_name.
    assert ActionModule._config_action_plugin('foo.bar') == 'foo'
    assert ActionModule._config_action_plugin('foo') == 'foo'
    assert ActionModule._load_action_plugin('foo', '.') != 'foo'


# Generated at 2022-06-21 02:52:31.962540
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:52:41.048046
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(ansible_facts=dict(service_mgr='systemd'))
    tmp = None
    task = dict(args=dict(name='sshd', enabled=True, use='auto'))
    module = ActionModule(task, tmp, task_vars)

    module._execute_module = lambda *args, **kwargs: dict(ansible_facts=dict(ansible_service_mgr='systemd'))
    module._templar = lambda x: 'auto'

    module.run()

# Generated at 2022-06-21 02:52:45.842090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am.UNUSED_PARAMS['systemd'] == ['pattern', 'runlevel', 'sleep', 'arguments', 'args']

# Generated at 2022-06-21 02:52:52.488416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import unittest

    class TestActionModule(unittest.TestCase):
        def test_instantiate(self):
            action_plugin_class = sys.modules['ansible.plugins.action.service']
            action_plugin = action_plugin_class.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
            assert action_plugin

    # Instantiate these tests
    suite = unittest.TestLoader().loadTestsFromTestCase(TestActionModule)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 02:52:59.101694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(args=dict(name='nginx', state='started')),
        connection=None, play_context=None, loader=None,
        templar=None, shared_loader_obj=None
    )

    assert action.run() == {} # empty dict


# Generated at 2022-06-21 02:53:04.779495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # hostvars only present when delegated
    task_vars = {'hostvars': {'localhost': {'ansible_facts': {'service_mgr': 'auto'}}}}
    args = {'use': 'auto', 'name': 'foo', 'action': 'start'}

    # test run()
    action_module_obj = ActionModule(None, {'args': args})
    action_module_obj.run(task_vars=task_vars)

# Generated at 2022-06-21 02:53:06.088878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:53:33.109502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-21 02:53:35.001533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 02:53:43.037863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create ansible playbooks on the fly and run them

    # get required imported Ansible modules
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    # Set global variables
    results_callback = ResultCallback()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-21 02:53:46.145018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call empty constructor of class
    testObj = ActionModule(connection=None, task_vars=None)
    assert testObj is not None

# Generated at 2022-06-21 02:53:52.972916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mocker.patch does not work for the below two lines.
    # For now let's just disable the test for these.
    # Once we have a proper way to mock this, we may enable it.
    return
    '''Unit Test for method run of class ActionModule'''
    mock_collection = mocker.Mock()
    mock_connection = mocker.Mock()
    mock_task = mocker.Mock()

    svc_mgr = ActionModule(mock_connection, mock_task, mock_collection)
    svc_mgr.run()

    #verify the call has happened
    mock_connection._shell.tmpdir.assert_called_once_with()
    mock_collection.assert_called_once_with()



# Generated at 2022-06-21 02:54:02.480782
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.module_utils.facts.system.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost,'))

# Generated at 2022-06-21 02:54:11.664434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.service import ActionModule
    from ansible.plugins.loader import action_loader
    # Mock class for module_utils loader
    module_utils_loader = action_loader._create_module_utils_loader(None)
    # Mock class for module_loader loader
    module_loader = action_loader._create_module_loader(None)
    # Mock class for shared_plugin_loader loader
    shared_plugin_loader = action_loader._create_shared_plugin_loader(None)
    # Mock class for SharedPluginLoader
    loader = action_loader._create_loader(None, module_utils_loader, module_loader, shared_plugin_loader)
    # Create object of class ActionModule

# Generated at 2022-06-21 02:54:23.522661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader

    # Create a temporary and temporary_path, to be used when creating a task.
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_path = tempfile.mkstemp()[1]

    # Create a connection to localhost
    from ansible.inventory.host import Host
    host = Host('localhost')
    import ansible.executor.task_queue_manager
    from ansible.executor.task_result import TaskResult
    import ansible.context
    context._init_global_context(play_context=PlayContext())
    task_vars = ansible.context._init_global_context().vars

# Generated at 2022-06-21 02:54:31.293242
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:54:40.911098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            action=dict(
                module='service',
                args=dict(
                    name='foo',
                    enabled=True,
                    use='auto',
                    pattern='foo-service.*'
                )
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )


# Generated at 2022-06-21 02:55:52.087974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = DummyHost()
    host.set_initial_facts(dict(ansible_svc_mgr='auto'))

    # test without delegate_to:
    t = Task()
    t.action = "service"
    t.args = dict(name='foo', state="started", use='auto')
    t.delegate_to = None

    m = ActionModule(task=t, connection=host)
    m.run(task_vars=dict())

    assert "ansible_facts" in host.module_results
    assert "ansible_service_mgr" in host.module_results["ansible_facts"]
    assert host.module_results["ansible_facts"]["ansible_service_mgr"] == 'auto'

    # test with delegate_to:
    t = Task()

# Generated at 2022-06-21 02:56:02.344796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostvars = None
    host_list = [
        {
            "_ansible_no_log": False,
            "_ansible_verbose_always": True,
            "action": "start",
            "changed": False,
            "invocation": {
                "module_args": {
                    "arguments": "",
                    "enabled": null,
                    "name": "httpd",
                    "pattern": "httpd",
                    "runlevel": "default",
                    "sleep": null,
                    "state": "started",
                    "use": "auto"
                }
            }
        }
    ]
    task_execute_meta = None
    variable_manager = None

    test_obj = ActionModule(hostvars, host_list, task_execute_meta, variable_manager)

# Generated at 2022-06-21 02:56:09.371416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task={'use': 'openwrt_init'})
    tmp = None
    task_vars = {'ansible_service_mgr': 'openwrt_init'}
    result = module.run(tmp, task_vars)
    assert result
    assert result[0] == 'changed' or result[0] == 'ok'

# Generated at 2022-06-21 02:56:16.024235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor of class ActionModule
    action_module = ActionModule(
        task=dict(args=dict(use="service")),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-21 02:56:16.776363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:56:22.150106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    
    # create the basic objects from a play
    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader, sources='localhost,')
    variables = VariableManager(loader=dataloader, inventory=inventory)


# Generated at 2022-06-21 02:56:32.614081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # This function is used by main module import. It is called with the following
    # parameters:
    #
    #   * args:
    #       args.tmp - module option 'tmp' passed to action plugin constructor
    #       args.task_vars - variables relevant to the AnsibleTask being run
    #
    #   * tmp - temporary directory
    #   * task_vars - variables relevant to the AnsibleTask being run
    #
    # The function returns a two-tuple, first item is the result of the
    # ActionModule.run method, second item is a string containing the output
    # of the ActionModule.run method.
    #

    tmp = '/tmp'
    task_vars = {}

    # Create a fake instance of Ansible ActionModule class

# Generated at 2022-06-21 02:56:42.058203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    import pytest

    # initialize needed objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = Play

# Generated at 2022-06-21 02:56:42.945716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test doesn't work
    assert 1 == 1

# Generated at 2022-06-21 02:56:49.701821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a_task = type('task',(object,),{'args':{'use':'auto'},'delegate_to':'a_host'})
    a_host = type('host',(object,),{'name':'a_host','host_vars':{'a_host':{'ansible_facts':{'service_mgr':'a_mgr'}}}})
    a_action_plugin = type('plugin',(object,),{'_task':a_task,'_connection':{'_shell':{'tmpdir':'a_tmp_dir'}}})
    assert a_action_plugin().run() == {'changed': False, 'failed': False, 'rc': 0}

# Generated at 2022-06-21 02:59:23.838903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test method run of class ActionModule.'''
    # Create instance of class ActionModule
    am = ActionModule()
    am.run()

# Generated at 2022-06-21 02:59:26.544413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('test', 'test', 'test')
    assert action_module is not None


# Generated at 2022-06-21 02:59:31.283300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert(a._supports_check_mode == True)
    assert(a._supports_async == True)

# Generated at 2022-06-21 02:59:42.410717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils import basic
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class TestCallbackModule(CallbackBase):
        """
        A sample callback plugin used for performing an action as results come in

        If you want to collect all results into a single object for processing at
        the end of the execution, look into utilizing the ``json`` callback plugin
        or writing your own custom callback plugin
        """

        def __init__(self):
            self

# Generated at 2022-06-21 02:59:52.013587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            async_val=0,
            async_val=2,
            delegate_to='host',
            delegate_facts=True,
            register='result',
            loop='items',
            loop_control=dict(
                label='item'
            ),
            args=dict(
                action='start',
                name='firewalld',
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    return action_module