

# Generated at 2022-06-21 02:50:04.254395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import find_action_plugin
    action_module = find_action_plugin('service')
    assert action_module == ActionModule

# Generated at 2022-06-21 02:50:15.072547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    command_module = CommandActionModule.CommandActionModule()

    command_module._task.args.update({'use': 'auto'},)
    command_module._task.args.update({'name': 'httpd'},)
    command_module._task.args.update({'state': 'started'},)
    command_module._task.delegate_to = 'localhost'
    command_module._task.collections = []
    command_module._task._parent._play._action_groups = ['all']


# Generated at 2022-06-21 02:50:24.739120
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.executor.task_executor import TaskExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    play_context.connection = 'local'
    loader = DataLoader()

    host = InventoryManager(loader=loader, sources='').get_host('127.0.0.1')
    variable_manager = VariableManager(loader=loader, inventory=host.get_inventory())
    variable_manager.set_host_variable(host, 'ansible_service_mgr', 'auto')


# Generated at 2022-06-21 02:50:26.624962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()


test_ActionModule_run()

# Generated at 2022-06-21 02:50:34.400103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.loader import action_loader
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict
    
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 02:50:39.770186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    myActionModule = ActionModule()
    assert myActionModule.TRANSFERS_FILES is False
    assert myActionModule.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }
    assert myActionModule.BUILTIN_SVC_MGR_MODULES == {'openwrt_init', 'service', 'systemd', 'sysvinit'}

# Generated at 2022-06-21 02:50:53.506475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import pytest

    task_args = dict(
        name='test',
        state='test',
        use='auto',
    )

    action = ActionModule(task=dict(args=task_args))
    assert json.loads(action.run()['msg']) == task_args
    with pytest.raises(AnsibleActionFail) as error:
        action.run(task_vars=dict(ansible_facts={}))
    assert 'Could not detect which service manager to use. Try gathering facts or setting the "use" option.' in str(error.value)
    assert json.loads(action.run(task_vars=dict(ansible_facts=dict(service_mgr='unsupported')))['msg']) == task_args

# Generated at 2022-06-21 02:51:01.882006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils import module_finder
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy import ActionModuleComponent
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.utils.display import Display
    import sys


# Generated at 2022-06-21 02:51:04.812909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' unit testing for action module '''

    act_mod = ActionModule(None, None)

    assert type(act_mod) == ActionModule

# Generated at 2022-06-21 02:51:05.643980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:51:23.137935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.role import definition
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    block = Block(
        parent_block=None,
        role=definition.load(None, "../../../test/unit/ansible/test_data/roles/test_role", None, True, None, None, None),
        tasks=[
            Task()
        ],
        vars={
            "arguments": {
                "name": "cassandra",
                "state": "restarted",
                "sleep": 1
            }
        }
    )

    task = Task()
    task._parent = block
    task._role = block.role
    task.vars = block.vars
    task

# Generated at 2022-06-21 02:51:34.665812
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # This is a unit test function for class ActionModule.
    # ActionModule class have method called run.

    module = ActionModule()

    # Testcase 1:
    # Tested method : run
    # Tested Result:
    # If: module == 'auto':
    #     try:
    #         If: self._task.delegate_to:
    #             # if we delegate, we should use delegated host's facts
    #             module = self._templar.template("{{hostvars['%s']['ansible_facts']['service_mgr']}}" % self._task.delegate_to)
    #         else:
    #             module = self._templar.template('{{ansible_facts.service_mgr}}')
    #     except Exception:
    #         pass  # could not get it from

# Generated at 2022-06-21 02:51:35.123758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 02:51:36.628944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 02:51:43.192809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(
            name="ssh",
            state="started",
            enabled="yes",
            sleep="1",
            use='systemd',
        )),
        connection=dict(play_context=dict()),
        templar=dict(),
        shared_loader_obj=dict(),
        loader=dict(),
        path_loader=dict(),
    )
    assert action_module is not None
    assert action_module._task.args['name'] == 'ssh'

# Generated at 2022-06-21 02:51:46.011078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert(action is not None)


# Generated at 2022-06-21 02:51:51.608891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.module_utils.basic
    import ansible.plugins.action
    a = ansible.plugins.action.ActionModule(
        action_plugin_name='service',
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=ansible.module_utils.basic.AnsibleModule.AnsibleModule(
            argument_spec=dict(),
        )
    )
    assert a

# Generated at 2022-06-21 02:52:03.522445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import imp
    import json
    import os

    test_data_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../unittests/test_data')

    m = imp.load_source('module', os.path.join(test_data_path, 'fake_plugins/action/module.py'))
    a = m.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test_module_hashes = a._execute_module(module_name='hashes', module_args={'arg1': '123'}, task_vars={'hello':'world'})
    # print(json.dumps(test_module_hashes, indent=2))

# Generated at 2022-06-21 02:52:12.691325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule()
    assert AM.TRANSFERS_FILES is False
    assert AM._supports_check_mode is True
    assert AM._supports_async is True
    assert AM.BUILTIN_SVC_MGR_MODULES == set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
    assert AM.UNUSED_PARAMS == {
        'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
    }

    assert AM is not None
    return

# Generated at 2022-06-21 02:52:23.541490
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.compat.tests import unittest

    class ActionModule_run_TestCase(unittest.TestCase):
        '''Tests for _run method of class ActionModule'''

        def setUp(self):
            self.action_module = ActionModule()

        def test_run(self):
            '''Test run'''
            self.assertEqual(self.action_module.run(), None)

    unittest.main()

# Generated at 2022-06-21 02:52:38.502607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(name='test', args={'a': 1}),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-21 02:52:39.375145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:52:46.272526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_task = MagicMock()
    m_task.args = {}
    m_task.args['use'] = 'auto'
    m_task.delegate_to = None
    m_task.async_val = None

    m_task_vars = MagicMock()
    m_task.module_defaults = MagicMock()

    m_templar = MagicMock()
    m_templar.template = MagicMock(return_value='auto')

    m_display = MagicMock()

    m_ActionBaseRun = MagicMock()
    m_ActionBaseRun.return_value = {}

    
    m_execute_module = MagicMock()
    m_execute_module.return_value = {'ansible_facts': {'service_mgr': 'auto'}}

    m_

# Generated at 2022-06-21 02:52:55.469842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.playbook.task import Task
    from ansible.plugins.action.service import ActionModule

    module_defaults = dict(
        name=dict(type='str'),
        use=dict(default='auto', type='str'),
    )

    setattr(context, 'CLIARGS', dict(module_defaults=module_defaults))

    task = Task()
    task._parent = dict()
    task._parent['_play'] = dict()
    task._parent['_play']['_action_groups'] = dict()

    service_action = ActionModule(task, dict(name='nginx', state='started', use='auto'))

# Generated at 2022-06-21 02:53:05.682804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import sys
    import os

    class ModuleTest(unittest.TestCase):
        def setUp(self):
            from ansible.plugins.action.service import ActionModule
            self.am = ActionModule(None)
            self.am.BUILTIN_SVC_MGR_MODULES = set(['openwrt_init', 'service', 'systemd', 'sysvinit'])
            self.am.UNUSED_PARAMS = {
                'systemd': ['pattern', 'runlevel', 'sleep', 'arguments', 'args'],
            }
            self.am._shared_loader_obj.module_loader.find_plugin_with_context = self.dummy_find_plugin_with_context

# Generated at 2022-06-21 02:53:15.218863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='started', choices=['started', 'stopped', 'present', 'absent', 'reloaded']),
            name=dict(required=True),
            enabled=dict(required=False, type='bool'),
            pattern=dict(required=False),
            runlevel=dict(required=False, default='default'),
            sleep=dict(required=False, type='int'),
            arg=dict(required=False),
            use=dict(required=False, default='auto'),
            init_command=dict(required=False, default='/sbin/init'),
            systemctl_extra_args=dict(required=False, default='', type="list"),
        ),
        supports_check_mode=True,
    )


# Generated at 2022-06-21 02:53:20.713792
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            verbosity=5,
            async_val=3,
            async_seconds=5,
            connection='connection'
        )
    )
    assert module._supports_check_mode is True
    assert module._supports_async is True

# Generated at 2022-06-21 02:53:21.156755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 02:53:32.054423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method run of class ActionModule
    """
    # Create a fake task.
    task = MagicMock()
    task.args = {
        'async_val': False,
        'use': 'auto',
        'state': 'started',
        'enabled': False
    }
    # Create a fake task.action
    task.action = MagicMock()
    task.action.__name__ = 'service'

    # Create a fake task._parent._play
    play = MagicMock()
    play._action_groups = {'all'}
    task._parent = MagicMock()
    task._parent._play = play

    # Create a fake module_defaults
    module_defaults = MagicMock()
    module_defaults.get = MagicMock(return_value=None)

    # Create

# Generated at 2022-06-21 02:53:37.365221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule({'use': 'auto'}, {'_ansible_no_log': True}, loader=None, templar=None, shared_loader_obj=None)
    print(am)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 02:54:02.896219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:54:05.180771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Placeholder for future unit tests
    '''
    assert True is True

# Generated at 2022-06-21 02:54:12.829433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.module_utils.facts.system.service_mgr import OpenWrtInitFactCollector
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.reserved import _valid_reserved_names
    from ansible.vars.reserved import Reserved, DEFAULT_RESERVED_VAR_NAMES
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import os
    import pytest

    loader = Data

# Generated at 2022-06-21 02:54:16.738234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for ActionModule.run
    '''

    # we can't test this file because ActionModule is an abstract class
    assert True

# Generated at 2022-06-21 02:54:23.522390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='service', module_args=dict(name='httpd', state='reloaded'))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert action_module.run() is None

# Generated at 2022-06-21 02:54:31.291543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import types
    import os
    import sys
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.module_common import get_action_args_with_defaults
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.helpers import load_list_of_tasks
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins import module_loader, action_loader
   

# Generated at 2022-06-21 02:54:34.540101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    return isinstance(action, ActionModule)


# Generated at 2022-06-21 02:54:38.394125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock
    from ansible.plugins.action import ActionBase

    task_vars = dict()
    tmp = '/tmp'
    action_module = ActionModule(mock.MagicMock(), mock.MagicMock(), task_vars, tmp)
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-21 02:54:50.098577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test
    class FakeModule:
        def __init__(self):
            self.action = ''
            self.module_name = ''
            self.module_args = {}
            self.no_log = False
    class FakeTask:
        def __init__(self, _module_name, _module_args, _delegate_to):
            self.args = dict(_module_name=_module_name, _module_args=_module_args)
            self.delegate_to = _delegate_to
            self.async_val = 500
            self._parent = None
            self.module_defaults = None
    class FakePlay:
        def __init__(self, _action_groups):
            self._action_groups = _action_groups

# Generated at 2022-06-21 02:54:53.209423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with a valid object
    module = ActionModule(None, None, None)
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 02:55:56.680204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # we cannot really test too much here as the run() method is a stub
    assert len(ActionModule.BUILTIN_SVC_MGR_MODULES) > 0

    # this is what a unit test should look like

# Generated at 2022-06-21 02:56:03.820718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct an object of ActionModule
    action_module = ActionModule(
        task=dict(args=dict(use='dummy')),
        connection=None,
        _play_context=play_context.PlayContext(),
        loader=loader.AnsibleLoader(),
        templar=templar.Templar(),
        shared_loader_obj=loader.AnsibleLoader()
    )

    assert action_module._task.args.get('use') == 'dummy'
    assert action_module._connection is None
    assert isinstance(action_module._play_context, play_context.PlayContext)
    assert isinstance(action_module._loader, loader.AnsibleLoader)
    assert isinstance(action_module._templar, templar.Templar)

# Generated at 2022-06-21 02:56:08.304932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_module = ActionModule(None, None, None, None)
    print("Created ActionModule: %s" % action_module)
    assert action_module
    print("type = %s" % type(action_module))
    print("type = %s" % type(action_module.BUILTIN_SVC_MGR_MODULES))
    svc_mgrs = action_module.BUILTIN_SVC_MGR_MODULES
    assert len(svc_mgrs) == 4
    assert 'openwrt_init' in svc_mgrs
    assert 'service' in svc_mgrs
    assert 'systemd' in svc_mgrs
    assert 'sysvinit' in svc

# Generated at 2022-06-21 02:56:14.715283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import Include

# Generated at 2022-06-21 02:56:15.090301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:56:23.020831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(
        task=dict(args=dict(name='httpd', use='auto')),
        connection=None,
        _shell_type='csh',
        _shell_executable='/bin/csh'
    )

# Generated at 2022-06-21 02:56:32.901241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    loader = object()
    task = dict(name='test')
    task_vars = dict()
    connection = object()
    play_context = dict()
    module_loader = object()
    shared_loader_obj = dict()
    shared_loader_obj['module_loader'] = module_loader

    am = ActionModule(loader, task, task_vars, connection, play_context, shared_loader_obj)

    assert am._loader is loader
    assert am._task is task
    assert am._task_vars is task_vars
    assert am._connection is connection
    assert am._play_context is play_context
    assert am._shared_loader_obj is shared_loader_obj

    assert am.TRANSFERS_FILES == False

    assert am.BUILTIN_SVC_MGR_MODULES

# Generated at 2022-06-21 02:56:37.113331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = MockTask()
    action_module = ActionModule()

    task.args = {'name': 'mysql', 'use':'systemd'}
    action_module._task = task

    assert action_module.run() == {
                                    'msg': "module args: {'name': 'mysql', 'state': None, 'use': 'systemd'}",
                                    'changed': False
                                  }, 'ActionModule.run() should run the action module and return a dictionary with the keys msg and changed'

# Generated at 2022-06-21 02:56:45.896423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = am.run()
    assert type(result) == dict
    assert len(result) > 0
    assert 'invocation' in result
    assert 'module_args' in result['invocation']
    assert 'module_name' in result['invocation']
    assert 'failures' in result['invocation']
    assert 'changed' in result
    assert 'skipped' in result

# Generated at 2022-06-21 02:56:46.690443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 02:59:22.338119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes
    from ansible_collections.cisco.nxos import ansible_collections
    from ansible_collections.ansible.netcommon import ansible_collections
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    passwords = dict()
    inventory = InventoryManager(loader=loader, sources='localhost,')


# Generated at 2022-06-21 02:59:31.806624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule.
    '''
    import ansible.plugins.action.service
    action_module = ansible.plugins.action.service.ActionModule(
        task=dict(args=dict(use='auto', name='httpd', state='started')))
    assert not action_module.BUILTIN_SVC_MGR_MODULES.isdisjoint(set([
        'openwrt_init', 'service', 'systemd', 'sysvinit']))
    assert not action_module.UNUSED_PARAMS.keys() is None

# Generated at 2022-06-21 02:59:42.567830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate the action module
    action_module = ActionModule(None, {})

    # Instantiate the task object
    task = dict(
        delegate_to = 'localhost',
        async_val = 0,
        status = 'pending',
        action = 'ansible.builtin.service',
        _ansible_no_log = False,
        args = dict(
            use = 'openwrt_init'
        )
    )

    # Instantiate the loader object
    loader_obj = dict(
        module_loader = dict(
            find_plugin_with_context = find_plugin_with_context,
            has_plugin = dict(
                return_value = True
            )
        )
    )

    # Instantiate the connection object

# Generated at 2022-06-21 02:59:44.489676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-21 02:59:53.751857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test that the ActionModule.run method is returning the necessary data,
    and has no error when being called.
    """
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.utils.vars as vars_util
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.reserved import Reserved
    from ansible.inventory.host import Host
    from ansible.plugins.loader import become_loader, connection_loader, module_loader
   