

# Generated at 2022-06-26 06:07:35.832282
# Unit test for function get_new_command
def test_get_new_command():
    print('Testing function get_new_command')
    var_0 = True
    var_1 = "git diff -a"
    var_2 = get_new_command(var_0)
    var_3 = "git diff --no-index -a"
    var_4 = var_1 != var_3
    if var_2:
        print("Test passed")
    else:
        print("Test failed")

# Test case for match

# Generated at 2022-06-26 06:07:46.219044
# Unit test for function match
def test_match():
    var_0 = magic_mock('arg_0')
    const_0 = 'const_0'
    const_1 = 'const_1'
    const_2 = 'const_2'
    const_3 = 'const_3'
    const_4 = 'const_4'
    const_5 = 'const_5'
    var_0.script = const_0
    var_0.script_parts = [const_1, const_2, const_3, const_4, const_5]
    bool_0 = match(var_0)
    bool_1 = match(var_0)


# Generated at 2022-06-26 06:07:57.748965
# Unit test for function match
def test_match():
    var_0 = True
    var_1 = False
    var_2 = 'git dif README.md Git.qgs'
    var_3 = 'git diff README.md Git.qgs'
    var_4 = 'git dif README.md Git.qgs'

    var_5 = match(bool_0)
    var_6 = match(var_1)
    var_7 = match(var_2)
    var_8 = match(var_3)
    var_9 = match(var_4)

    var_10 = 'git diff --no-index README.md Git.qgs'
    var_11 = get_new_command(var_2)

    assert var_5 == False
    assert var_6 == False
    assert var_7 == True
    assert var_8 == False

# Generated at 2022-06-26 06:07:59.721422
# Unit test for function match
def test_match():
    assert callable(match)
    assert match(True) == True
    assert match(False) == False


# Generated at 2022-06-26 06:08:02.485469
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', ''))
    assert match(Command('git diff src/file1 src/file2', '', ''))
    assert not match(Command('git diff', '', ''))


# Generated at 2022-06-26 06:08:14.455265
# Unit test for function match
def test_match():
    assert callable(match)
    assert not match(Command('git diff file_0 file_1', '', stderr='error: pathspec \'file_0\' did not match any file(s) known to git.\nerror: pathspec \'file_1\' did not match any file(s) known to git.'))
    assert match(Command('git diff file_0 file_1', '', stderr='fatal: ambiguous argument \'file_0\': unknown revision or path not in the working tree.\nUse \'--\' to separate paths from revisions\n'))
    assert not match(Command('git diff file_0 file_1', '', stderr='error: unknown option `--file_0\'\n',))
    assert match(Command('git diff file_0 file_1', ''))

# Generated at 2022-06-26 06:08:15.822591
# Unit test for function match
def test_match():
    test_case_0()

# Generated at 2022-06-26 06:08:21.154298
# Unit test for function match
def test_match():
    var_0 = True
    var_1 = Command('hello', '', 'world')
    var_2 = get_new_command(var_1)
    assert var_0 == match(var_1)
    assert "git diff --no-index world" in var_2


# Generated at 2022-06-26 06:08:23.737134
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git diff file0 file1',
                      stdout='stdout')
    result = get_new_command(command)
    assert result == 'git diff --no-index file0 file1'

# Generated at 2022-06-26 06:08:34.296269
# Unit test for function match
def test_match():
    script = 'git diff file_0 file_1'
    command = Command('git diff file_0 file_1', script=script)
    assert match(command)

    script = 'git --no-pager diff file_0 file_1'
    command = Command('git --no-pager diff file_0 file_1', script=script)
    assert match(command)

    script = 'git diff --no-index file_0 file_1'
    command = Command('git diff --no-index file_0 file_1', script=script)
    assert not match(command)

    script = 'git diff file_0'
    command = Command('git diff file_0', script=script)
    assert not match(command)


# Generated at 2022-06-26 06:08:38.210625
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = True
    var_0 = get_new_command(bool_0)

# Generated at 2022-06-26 06:08:39.363560
# Unit test for function match
def test_match():
    pass

# Generated at 2022-06-26 06:08:42.805886
# Unit test for function match
def test_match():
    assert(match('git diff') is False)
    assert(match('git diff file1 file2') is True)
    assert(match('git diff file1 file2 --no-index') is False)
    assert(match('git diff foo.txt --no-index') is False)

# Generated at 2022-06-26 06:08:44.992744
# Unit test for function get_new_command
def test_get_new_command():
    pass


# Generated at 2022-06-26 06:08:46.666742
# Unit test for function get_new_command
def test_get_new_command():
    try:
        var_0 = True
        var_1 = True
        var_0 = get_new_command(var_0)
    except Exception:
        var_1 = False
    assert var_1


# Generated at 2022-06-26 06:08:49.202233
# Unit test for function match
def test_match():
    assert('thefuck conf.py conf.py' == match('thefuck conf.py conf.py'))


# Generated at 2022-06-26 06:08:52.313967
# Unit test for function match
def test_match():
    var_8 = Command('git diff some-file new-file', '', ('', '', ''))
    var_9 = True
    var_10 = match(var_8)
    assert var_9 == var_10


# Generated at 2022-06-26 06:08:55.563410
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = True
    var_1 = get_new_command(var_0)

# Generated at 2022-06-26 06:08:59.990960
# Unit test for function match
def test_match():
    assert match('git diff . a')
    assert not match('git diff .')
    assert not match('git diff')
    assert not match('git add .')
    assert match('git diff --no-index a b c')


# Generated at 2022-06-26 06:09:03.637799
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "foo bar"') == 'git commit --no-edit'
    assert get_new_command('git --no-edit commit -m "foo bar"') == 'git commit --no-edit'


# Generated at 2022-06-26 06:09:16.351772
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', ''))
    assert match(Command('git diff --word-diff file1 file2', ''))
    assert match(Command('git diff -w file1 file2', ''))
    assert match(Command('git diff --no-index file1 file2', ''))
    assert not match(Command('git diff --no-index', ''))
    assert not match(Command('git diff --no-index file1', ''))


# Generated at 2022-06-26 06:09:21.453268
# Unit test for function match
def test_match():
    assert match(Command('git diff a b', ''))
    assert not match(Command('git diff a b', '',
                             stderr='usage: git diff [options] [<commit>] '
                                    '[--] [<path>…​]'))



# Generated at 2022-06-26 06:09:30.172462
# Unit test for function match
def test_match():
    assert match(Command('git diff helloworld', '', stderr='diff: missing '
                                                           'destination file '
                                                           'after \'helloworld\''))
    assert not match(Command('git stash apply', '', stderr='diff: missing '
                                                    'destination file '
                                                    'after \'stash apply\''))


# Generated at 2022-06-26 06:09:34.350466
# Unit test for function match
def test_match():
    assert match(Command('git diff foo bar', ''))
    assert not match(Command('git diff -w foo bar', ''))
    assert not match(Command('git diff --no-index foo bar', ''))
    assert not match(Command('git diff --no-index', ''))
    assert not match(Command('git diff', ''))
    assert not match(Command('git foo bar', ''))

# Generated at 2022-06-26 06:09:45.216370
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == 'git diff --no-index '
    assert get_new_command('diff file_1 file_2') == 'git diff --no-index file_1 file_2'
    assert get_new_command('diff --no-index file_1 file_2') == 'git diff --no-index file_1 file_2'
    assert get_new_command('diff --no-index') == 'git diff --no-index --no-index '
    assert get_new_command('diff --no-index file_1 --no-index file_2') == 'git diff --no-index file_1 --no-index file_2'
    assert get_new_command('diff -w') == 'git diff --no-index -w'

# Generated at 2022-06-26 06:09:54.231340
# Unit test for function match
def test_match():
    assert match(Command('diff abc.txt abc.txt', '', ''))
    assert match(Command('git diff abc.txt xyz.txt', '', ''))
    assert not match(Command('diff --no-index abc.txt abc.txt', '', ''))
    assert not match(Command('git diff -w abc.txt xyz.txt', '', ''))
    assert not match(Command('git diff -w abc.txt', '', ''))
    assert not match(Command('git diff abc.txt', '', ''))


# Generated at 2022-06-26 06:10:00.700726
# Unit test for function match
def test_match():
    assert match(Command('diff a b'))
    assert not match(Command('diff a b c'))
    assert not match(Command('git diff a b'))
    assert not match(Command('diff a b', 'git diff a b'))
    assert not match(Command(''))



# Generated at 2022-06-26 06:10:02.593752
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git diff file1 file2")) == "git diff --no-index file1 file2"

# Generated at 2022-06-26 06:10:11.823766
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2', '')) == 'git diff --no-index file1 file2'
    assert get_new_command(Command('git diff file1 file2 somethingelse', '')) == 'git diff --no-index file1 file2 somethingelse'
    assert get_new_command(Command('git diff --cached file1 file2', '')) == 'git diff --cached --no-index file1 file2'


# Generated at 2022-06-26 06:10:15.566183
# Unit test for function match
def test_match():
    command = mock.Mock(script='git diff file1 file2')
    assert match(command)


# Generated at 2022-06-26 06:10:22.797719
# Unit test for function match
def test_match():
    assert not match(Command('git diff'))
    assert not match(Command('git diff --no-index'))
    assert match(Command('git diff file1 file2'))
    assert not match(Command('git diff a'))


# Generated at 2022-06-26 06:10:26.354390
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git diff file1 file2', '', '')) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:10:30.327690
# Unit test for function match
def test_match():
    command = Command('git diff test1 test2')
    assert match(command)
    command = Command('git diff test1')
    assert match(command) == False


# Generated at 2022-06-26 06:10:33.895464
# Unit test for function match
def test_match():
    assert match(Command('git diff', None))
    assert match(Command('git diff file1 file2', None))
    assert not match(Command('git diff file1 file2', None))
    assert not match(Command('git diff --no-index file1 file2', None))

# Generated at 2022-06-26 06:10:38.490093
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git diff file1 file2', stdout='', stderr='', rc=0)
    assert get_new_command(command) == 'git diff --no-index file1 file2'


# Generated at 2022-06-26 06:10:43.674108
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', ''))
    assert match(Command('git diff --cached file1 file2', ''))
    assert not match(Command('git diff', ''))
    assert not match(Command('git diff file1', ''))
    assert not match(Command('git diff --no-index file1 file2', ''))
    assert not match(Command('git diff --no-index --cached file1 file2', ''))


# Generated at 2022-06-26 06:10:51.396485
# Unit test for function match
def test_match():
    assert match(Command('git status'))
    assert not match(Command('git diff'))
    assert match(Command('git diff file1.txt file2.txt'))
    assert match(Command('git diff file1.txt file2.txt --color'))
    assert not match(Command('git diff --no-index file1.txt file2.txt'))


# Generated at 2022-06-26 06:10:54.035408
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2', '')) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:11:05.727512
# Unit test for function match
def test_match():
    command_diff = Command('git diff pom.xml src/main/resources/generate.xml', '', stderr='fatal: Not a git repository: .git/modules/temp\n')
    command_diff_noindex = Command('git diff --no-index pom.xml src/main/resources/generate.xml', '', stderr='fatal: Not a git repository: .git/modules/temp\n')
    command_diff_other = Command('git diff --cached', '', stderr='fatal: Not a git repository: .git/modules/temp\n')

    assert not match(command_diff)
    assert not match(command_diff_other)
    assert match(command_diff_noindex)


# Generated at 2022-06-26 06:11:17.325436
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git diff file1 file2',
                                   'fatal: Not a git repository (or any of the parent directories): .git',
                                    '', '')) == "git diff --no-index file1 file2"
    assert get_new_command(Command('git diff file1 file2',
                                   "fatal: ambiguous argument 'file1': unknown revision or path not in the working tree.\nUse '--' to separate paths from revisions",
                                    '', '')) == "git diff --no-index file1 file2"

# Generated at 2022-06-26 06:11:29.502743
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2')) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:11:32.763570
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff file1 file2')
    assert get_new_command(command) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:11:39.138961
# Unit test for function match
def test_match():
    assert match(Command('git diff file file2', '', stderr='error: Not a git repo (or any parent up to mount point /home)\n'))
    assert match(Command('git diff file file2', '', stderr='fatal: Not a git repository'))
    assert not match(Command('git diff file file2', '', stderr='error: pathspec \'file\' did not match any file(s) known to git.'))
    assert match(Command('git diff file file2', ''))
    assert not match(Command('git diff file', ''))


# Generated at 2022-06-26 06:11:46.446317
# Unit test for function match
def test_match():
    assert(match(Command('git diff a b', '/bin/git', 'git diff a b')) == True)
    assert(match(Command('git diff --no-index a b', '/bin/git', 'git diff --no-index a b')) == False)
    assert(match(Command('git diff a', '/bin/git', 'git diff a')) == False)
    assert(match(Command('git status', '/bin/git', 'git status')) == False)
    assert(match(Command('git diff', '/bin/git', 'git diff')) == False)


# Generated at 2022-06-26 06:11:50.723624
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff "./file1.txt" "./file2.txt"') \
        == 'git diff --no-index "./file1.txt" "./file2.txt"'

# Generated at 2022-06-26 06:11:56.380921
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff --cached file1 file2'))
    assert match(Command('git diff --no-index file1 file2')) == False
    assert match(Command('git diff --no-index file1 file2 file3')) == False
    assert match(Command('git diff file1')) == False
    assert match(Command('git diff ')) == False


# Generated at 2022-06-26 06:11:59.421252
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git diff file1 file2", "", "")) == "git diff --no-index file1 file2"

# Generated at 2022-06-26 06:12:02.416013
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git diff") == "git diff --no-index"


# Generated at 2022-06-26 06:12:05.919417
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2',
                         'git: \'diff\' is not a git command. See \'git --help\'.'))
    assert not match(Command('git diff --no-index file1 file2',
                         'git: \'diff\' is not a git command. See \'git --help\'.'))
    assert not match(Command('git diff file1',
                         'git: \'diff\' is not a git command. See \'git --help\'.'))



# Generated at 2022-06-26 06:12:10.222812
# Unit test for function match
def test_match():
    assert not match(Command('git diff a b'))
    assert match(Command('git diff --no-index a b'))
    assert match(Command('git diff --no-index file1 file2'))


# Generated at 2022-06-26 06:12:33.320421
# Unit test for function match
def test_match():
    assert match(Command('git diff', 'git diff file1 file2'))
    assert match(Command('git diff HEAD', 'git diff HEAD file2'))
    assert match(Command('git diff HEAD..origin/master', 'git diff HEAD..origin/master file2'))
    assert not match(Command('git diff HEAD file1 file2', 'git diff HEAD file1 file2'))
    assert not match(Command('git diff --cached', 'git diff --cached'))
    assert not match(Command('git diff --no-index', 'git diff --no-index file1 file2'))
    assert not match(Command('git diff --no-index file1 file2', 'git diff --no-index file1 file2'))


# Generated at 2022-06-26 06:12:41.856349
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', stderr='fatal: Not a git repository (or any of the parent directories): .git\nfatal: Needed a single revision'))
    assert match(Command('git diff --cached file1 file2', '', stderr='fatal: Not a git repository (or any of the parent directories): .git\nfatal: Needed a single revision'))
    assert not match(Command('git diff file1 file2', ''))


# Generated at 2022-06-26 06:12:43.995289
# Unit test for function match
def test_match():
    assert match(Command('git diff config.py requirements.txt'))


# Generated at 2022-06-26 06:12:51.036897
# Unit test for function match
def test_match():
    assert match(Command('diff 1 2'))
    assert match(Command('vimdiff 1 2'))
    assert match(Command('git diff 1 2'))
    assert not match(Command('git diff 1 2 3'))
    assert not match(Command('git diff 1 2 --no-index'))
    assert not match(Command('git diff --no-index 1 2'))


# Generated at 2022-06-26 06:12:55.786702
# Unit test for function match
def test_match():
    assert match(Command('git diff README.md',
                         'git diff README.md'))

    assert not match(Command('git diff --no-index README.md',
                             'git diff --no-index README.md'))

    assert not match(Command('git diff -f README.md',
                             'git diff -f README.md'))

    assert not match(Command('git diff -f --staged README.md',
                             'git diff -f --staged README.md'))


# Generated at 2022-06-26 06:13:00.765470
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff first second')
    assert get_new_command(command) == 'git diff --no-index first second'
    command = Command('git diff --cached first second')
    assert get_new_command(command) == 'git diff --cached first second'

# Generated at 2022-06-26 06:13:02.524929
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command('diff A B', '', path='/tmp'))
    assert result == 'git diff --no-index A B'

# Generated at 2022-06-26 06:13:10.947586
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', stderr='',
                         script='git diff file1 file2'))
    assert not match(Command('git diff --no-index file1 file2', '',
                             stderr='', script='git diff --no-index file1 file2'))
    assert not match(Command('git diff', '', stderr='',
                             script='git diff'))

# Generated at 2022-06-26 06:13:12.852596
# Unit test for function get_new_command
def test_get_new_command():
	script = "git diff README.md LICENSE"
	assert get_new_command(script) == "git diff --no-index README.md LICENSE"

# Generated at 2022-06-26 06:13:16.022784
# Unit test for function match
def test_match():
    command = Command('git diff file1 file2', '', '')
    assert match(command)


# Generated at 2022-06-26 06:13:54.634927
# Unit test for function get_new_command
def test_get_new_command():
    import types
    import random
    # Generate a random string
    def random_string(prefix, m):
        range_start = ord(prefix)
        range_end = ord('z')
        length = random.randint(1, m)
        return ''.join(chr(random.randint(range_start, range_end)) for x in range(length))
    class Command:
        def __init__(self):
            self.script = random_string('a', 128)
            self.script_parts = self.script.split()
    arg_list = ['diff', '--no-index']
    for i in xrange(0, 128):
        command = Command()
        # test the match function
        assert match(command)
        # test the replace function
        new_command = get_new_command(command)

# Generated at 2022-06-26 06:13:57.557489
# Unit test for function match
def test_match():
    assert (match(Command('git diff file1 file2'))
            is not None)
    assert (match(Command('git diff --opt file1 file2'))
            is not None)


# Generated at 2022-06-26 06:14:00.742559
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff foo bar')) == 'git diff --no-index foo bar'

# Generated at 2022-06-26 06:14:05.662268
# Unit test for function match
def test_match():
    # Test for diff
    assert match(Command('diff index.js main.js', '', ''))
    # Test for diff with options
    assert match(Command('diff --cached index.js main.js', '', ''))



# Generated at 2022-06-26 06:14:07.857037
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command=Command(script = 'git diff foo bar')) == 'git diff --no-index foo bar'

# Generated at 2022-06-26 06:14:11.832602
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', ''))
    assert not match(Command('git diff --no-index file1 file2', ''))

# Generated at 2022-06-26 06:14:20.577706
# Unit test for function match
def test_match():
    assert not git.match(Command('git config'))
    assert git.match(Command('git diff path1 path2'))
    assert git.match(Command('git diff path1 path2 --no-index'))
    assert not git.match(Command('git diff --no-index path1 path2'))
    assert git.match(Command('git add -p && git diff --staged path1 path2'))
    assert git.match(Command('git diff --cached path1 path2'))
    assert git.match(Command('git diff path1 path2 -w'))
    assert git.match(Command('git diff path1 path2 --color'))
    assert not git.match(Command('git diff --color path1 path2'))


# Generated at 2022-06-26 06:14:24.034223
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git diff file1 file2')
    assert get_new_command(command) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:14:27.168395
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('./diff file1 file2') ==
            './diff --no-index file1 file2')



# Generated at 2022-06-26 06:14:29.971803
# Unit test for function match
def test_match():
    assert match(Command('git diff one two', output='', stderr=''))
    assert not match(Command('git mergetool -t opendiff one two', output='', stderr=''))


# Generated at 2022-06-26 06:16:01.650596
# Unit test for function match
def test_match():
    assert match(script('git diff file1 file2'))       is True
    assert match(script('git diff --patch file1 file2'))     is True
    assert match(script('git diff --cached file1 file2'))   is True
    assert match(script('git diff file1 file2 file3'))       is False
    assert match(script('git diff --no-index file1 file2')) is False
    assert match(script('git diff -- file1 file2'))        is True


# Generated at 2022-06-26 06:16:06.534633
# Unit test for function get_new_command
def test_get_new_command():
	assert_equal(get_new_command('git diff dir1/dir2/file1 dir2/dir3/file2'), 'git diff --no-index dir1/dir2/file1 dir2/dir3/file2')


# Generated at 2022-06-26 06:16:09.403982
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff file1 file2', '')
    assert get_new_command(command) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:16:13.560024
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2', '')) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:16:17.056829
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert not match(Command('git diff --no-index file1 file2'))



# Generated at 2022-06-26 06:16:18.804812
# Unit test for function match
def test_match():
    assert match(Command('git diff 1.txt 2.txt', '', ''))
    assert not match(Command('git diff 1.txt', '', ''))
    assert not match(Command('git diff', '', ''))



# Generated at 2022-06-26 06:16:22.202138
# Unit test for function match
def test_match():
    assert match(Command('git f'))
    assert not match(Command('ls'))
    assert not match(Command('git diff --no-index'))

# Generated at 2022-06-26 06:16:24.507290
# Unit test for function get_new_command
def test_get_new_command():
        assert get_new_command("git diff file1 file2") == "git diff --no-index file1 file2"

# Generated at 2022-06-26 06:16:27.363240
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff file1 file2')
    assert get_new_command(command) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:16:29.803219
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff -i file1 file2'))
    assert not match(Command('git diff'))
    assert not match(Command('git diff -i'))
    assert not match(Command('git diff file1'))
