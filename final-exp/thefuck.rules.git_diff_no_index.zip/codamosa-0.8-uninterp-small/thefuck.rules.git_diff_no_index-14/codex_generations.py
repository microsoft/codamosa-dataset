

# Generated at 2022-06-26 06:07:39.846882
# Unit test for function match
def test_match():
	var_0 = 'git diff --no-index file1 file2'
	assert match(var_0) == True
	var_1 = 'git diff file1 file2'
	assert match(var_1) == False
	var_2 = 'git diff -b file1 file2'
	assert match(var_2) == False
	var_3 = 'git dif file1 file2'
	assert match(var_3) == False
	var_4 = 'git diff --no-index file1 file2 file3'
	assert match(var_4) == False
	var_5 = 'git diff file1 file2 file3'
	assert match(var_5) == False


# Generated at 2022-06-26 06:07:46.120171
# Unit test for function get_new_command
def test_get_new_command():
    var_0_1 = b'\x0c\xdafmj\x11\xae\x8e\xab\x1c\xae\xb0\xa7\xe2\x86 \xf0<\x18V\x95w\xce_\x0f\xc5'

    assert(var_0_1 == get_new_command(var_0_1))

# Generated at 2022-06-26 06:07:47.882513
# Unit test for function match
def test_match():
    assert isinstance(match(), bool)


# Generated at 2022-06-26 06:07:49.232224
# Unit test for function get_new_command
def test_get_new_command():
    pass



# Generated at 2022-06-26 06:07:51.709307
# Unit test for function match
def test_match():
    assert match(b'git diff refs/heads/master blah.py')


# Generated at 2022-06-26 06:07:59.682398
# Unit test for function match
def test_match():
    assert match('git diff file.txt') == True
    assert match('git diff --no-index file.txt') == False
    assert match('git diff HEAD file.txt') == False
    assert match('git diff HEAD file.txt file.txt~') == True
    assert match('git diff HEAD file.txt file.txt~ -w') == True
    assert match('git diff HEAD file.txt file.txt~ /dev/null') == True
    assert match('git diff') == False
    assert match('git add file.txt') == False
    assert match('git add file.txt file.txt~') == False
    assert match('ls') == False
    assert match('echo') == False


# Generated at 2022-06-26 06:08:03.625894
# Unit test for function match
def test_match():
    assert match(Command('git diff ./foo.txt ./bar.txt', None))
    assert not match(Command('git diff --no-index ./foo.txt ./bar.txt', None))
    assert not match(Command('git diff', None))
    assert not match(Command("git diff './foo.txt' './bar.txt'", None))


# Generated at 2022-06-26 06:08:14.454942
# Unit test for function match
def test_match():
    command = Command('git diff file1 file2', '')
    python_utils.assert_equals(match(command), True)

    command = Command('git diff branch1 branch2', '')
    python_utils.assert_equals(match(command), True)

    command = Command('git diff', '')
    python_utils.assert_equals(match(command), False)

    command = Command('git diff -w file1 file2', '')
    python_utils.assert_equals(match(command), False)

    command = Command('git diff --no-index file1 file2', '')
    python_utils.assert_equals(match(command), False)


# Generated at 2022-06-26 06:08:15.264763
# Unit test for function get_new_command
def test_get_new_command():
    assert True

# Generated at 2022-06-26 06:08:25.431077
# Unit test for function match
def test_match():
    assert match(Command('git foo --no-index', '', ''))
    assert match(Command('git diff --no-index', '', ''))
    assert match(Command('git bar --no-index', '', ''))
    assert match(Command('git diff', '', ''))
    assert match(Command('git diff foo bar', '', ''))
    assert match(Command('git diff --no-index foo bar', '', ''))
    assert match(Command('git foo', '', ''))
    assert match(Command('git bar', '', ''))
    assert match(Command('git foo --stat', '', ''))
    assert match(Command('git foo --stat', '', ''))
    assert match(Command('git diff foo bar', '', ''))
    assert not match(Command('git diff --no-index', '', ''))


# Generated at 2022-06-26 06:08:32.591192
# Unit test for function match
def test_match():
    assert match(Command('git diff a/b.txt b/c.txt', '', ''))
    assert not match(Command('git diff --no-index a/b.txt b/c.txt', '', ''))
    assert not match(Command('git diff', '', ''))


# Generated at 2022-06-26 06:08:36.662363
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff first.txt second.txt', '', '')
    assert get_new_command(command) == 'git diff --no-index first.txt second.txt'

# Generated at 2022-06-26 06:08:44.184842
# Unit test for function get_new_command
def test_get_new_command():
    assert (match('git diff file1 file2')
            and get_new_command('git diff file1 file2') ==
                'git diff --no-index file1 file2')
    assert (not match('git diff --no-index file1 file2')
            and get_new_command('git diff --no-index file1 file2') ==
                'git diff --no-index file1 file2')
    assert (not match('git diff file1 file2 file3')
            and get_new_command('git diff file1 file2 file3') ==
                'git diff file1 file2 file3')

# Generated at 2022-06-26 06:08:45.306452
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff')) == 'git diff --no-index'



# Generated at 2022-06-26 06:08:48.545201
# Unit test for function match
def test_match():
    assert match(Command('git diff', '', '/bin/git diff'))
    assert match(Command('git diff app.py', '', '/bin/git diff app.py'))
    assert match(Command('git diff app.py second.py', '', '/bin/git diff app.py second.py'))
    assert match(Command('git diff app.py second.py', '', '/bin/git diff app.py second.py'))
    assert not match(Command('git diff app.py second.py', '', '/bin/git diff --no-index app.py second.py'))

# Generated at 2022-06-26 06:08:55.052316
# Unit test for function match
def test_match():
    # Differencing same files
    assert match(Command('git diff file1 file1'))
    # Differencing different files
    assert match(Command('git diff file1 file2'))
    # Differencing same files with -b or -B
    assert match(Command('git diff -b file1 file1'))
    assert match(Command('git diff -B file1 file1'))
    # Differencing same files with --no-index
    assert not match(Command('git diff --no-index file1 file1'))
    # Differencing different files with --no-index
    assert not match(Command('git diff --no-index file1 file2'))


# Generated at 2022-06-26 06:09:00.631405
# Unit test for function match
def test_match():
    # assertions.assert_raises(match)
    # There should be two arguments and the first should be diff
    # and the second is not --no-index
    match('git diff')
    match('git diff --no-in dex')
    match('git diff a b')
    match('git diff ab')
    match('git diff a bb')

# Generated at 2022-06-26 06:09:05.848046
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff --verbose file1 file2'))
    assert not match(Command('ls file1 file2'))
    assert not match(Command('git diff --no-index file1 file2'))
    assert not match(Command('git diff file1'))
    assert not match(Command('git diff file1 file2 file3'))



# Generated at 2022-06-26 06:09:16.353275
# Unit test for function match
def test_match():
    new_command = 'git diff file1 file2'
    assert match(Command(new_command, ''))
    new_command = 'git diff file1 file2 -q'
    assert match(Command(new_command, ''))
    new_command = 'git diff'
    assert not match(Command(new_command, ''))
    new_command = 'git diff --no-index file1 file2'
    assert not match(Command(new_command, ''))


# Generated at 2022-06-26 06:09:21.741785
# Unit test for function match
def test_match():
    assert match(Command("git diff file"))
    assert match(Command("git diff file second"))
    assert match(Command("git diff file second file third"))
    assert not match(Command("git diff --no-index file second"))
    assert not match(Command("git diff --color-words file second"))


# Generated at 2022-06-26 06:09:32.965313
# Unit test for function match
def test_match():
    script = 'diff somefile otherfile'
    assert match(Command(script, ''))

    script = 'git diff somefile otherfile'
    assert match(Command(script, ''))

    script = 'diff somefile otherfile --no-index'
    assert not match(Command(script, ''))

    script = 'git diff somefile'
    assert not match(Command(script, ''))



# Generated at 2022-06-26 06:09:35.717279
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff a b') == 'git diff --no-index a b'

# Generated at 2022-06-26 06:09:41.711284
# Unit test for function match
def test_match():
    assert match(Mock(script='git diff file1 file2'))
    assert not match(Mock(script='git diff file1 file2 file3'))
    assert not match(Mock(script='git diff'))
    assert not match(Mock(script='diff file1 file2'))



# Generated at 2022-06-26 06:09:44.186143
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', 
               stderr='diff: /dev/null: No such file or directory'))
    assert not match(Command('git diff -w file1 file2'))
    assert not match(Command('git diff --no-index file1 file2'))


# Generated at 2022-06-26 06:09:49.427939
# Unit test for function get_new_command
def test_get_new_command():
    # Test for command git diff file_1 file_2
    command = Command('git diff file_1 file_2', '', 1)
    assert 'git diff --no-index file_1 file_2' == get_new_command(command).script

# Generated at 2022-06-26 06:09:53.846284
# Unit test for function match
def test_match():
    assert match(Command('git diff file1.txt file2.txt'))
    assert not match(Command('git diff'))
    assert not match(Command('git status'))
    assert not match(Command('git diff --cached'))
    assert not match(Command('git diff --no-index'))


# Generated at 2022-06-26 06:10:02.056940
# Unit test for function match
def test_match():
    assert match(Command('git diff foo bar', '', stderr='error: foo: No such file or directory'))
    assert not match(Command('git log', '', stderr='error: foo: No such file or directory'))
    assert not match(Command('git diff --no-index foo bar', '', stderr='error: foo: No such file or directory'))


# Generated at 2022-06-26 06:10:06.512484
# Unit test for function match
def test_match():
    assert match(Command('git diff foo bar', ''))
    assert match(Command('git diff foo bar baz', ''))
    assert not match(Command('git diff --no-index foo bar', ''))

# Generated at 2022-06-26 06:10:12.898739
# Unit test for function match
def test_match():
    command1 = Command('git diff files1 files2')
    assert match(command1)
    command2 = Command('git diff --no-index files1 files2')
    assert not match(command2)
    command3 = Command('git diff files1 files2 files3')
    assert not match(command3)


get_new_command('git diff --no-index file1 file2')

# Generated at 2022-06-26 06:10:19.654702
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert not match(Command('git diff --cached file1 file2'))
    assert not match(Command('git dif file1 file2'))
    assert not match(Command('git diff --no-index file1 file2'))



# Generated at 2022-06-26 06:10:34.506226
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', ''))
    assert not match(Command('git diff --no-index file1 file2', ''))
    assert not match(Command('git diff', ''))
    assert not match(Command('diff file1 file2', ''))
    assert not match(Command('git diff file1 file2 file3', ''))


# Generated at 2022-06-26 06:10:40.257918
# Unit test for function match
def test_match():
    command = Command('git diff file1.txt file2.txt')
    assert match(command) is True
    command = Command('git diff')
    assert match(command) is False
    command = Command('git diff --no-index file1.txt file2.txt')
    assert match(command) is False
    command = Command('git diff file1.txt file2.txt file3.txt')
    assert match(command) is False
    command = Command('git diff-tree HEAD')
    assert match(command) is False


# Generated at 2022-06-26 06:10:44.342473
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git diff a b', '')) ==
            'git diff --no-index a b')
    assert (get_new_command(Command('git -c diff.noprefix=false diff a b', '')) ==
            'git -c diff.noprefix=false diff --no-index a b')
    assert (get_new_command(Command('git diff -w a b', '')) ==
            'git diff -w --no-index a b')



# Generated at 2022-06-26 06:10:49.366127
# Unit test for function match
def test_match():
	assert match(Command('git add diff file1 file2', '', ''))
	assert match(Command('git add diff file1 file2', '', ''))
	assert not match(Command('git diff -r file1 file2', '', ''))


# Generated at 2022-06-26 06:10:57.932793
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git diff file1 file2', '')) \
        == 'git diff --no-index file1 file2'
    assert get_new_command(Command('git diff --word-diff file1 file2', '')) \
        == 'git diff --word-diff --no-index file1 file2'
    assert get_new_command(Command(
        'git diff file1 file2 --word-diff', '')) \
        == 'git diff --no-index file1 file2 --word-diff'
    assert get_new_command(Command('git diff --word-diff file1 file2', '')) \
        == 'git diff --word-diff --no-index file1 file2'

# Generated at 2022-06-26 06:11:06.554989
# Unit test for function match
def test_match():
    assert match(Command('git diff test.py other.py', '',
                         'git diff test.py other.py\nfatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git diff test.py other.py', '', ''))
    assert not match(Command('git diff', '', ''))
    assert not match(Command('git diff test.py other.py -q', '', ''))
    assert not match(Command('git diff test.py other.py -q', '', ''))
    assert not match(Command('diff test.py other.py', '', ''))


# Generated at 2022-06-26 06:11:10.014622
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2', '')) == 'git diff --no-index file1 file2'


# Generated at 2022-06-26 06:11:16.855360
# Unit test for function match
def test_match():
    # Test on a short script
    command = Command('git diff a b')
    assert match(command)
    # Test on a long script
    command = Command('git diff a --no-index b')
    assert not match(command)
    # Test on a script not containing 'git'
    command = Command('diff a b')
    assert not match(command)
    # Test on a script not containing 'diff'
    command = Command('git status')
    assert not match(command)


# Generated at 2022-06-26 06:11:23.662312
# Unit test for function match
def test_match():
    assert match(Command('diff file1 file2'))
    assert not match(Command('git diff --cached file1 file2'))
    assert not match(Command('git diff --no-index file1 file2'))
    assert not match(Command('git diff file1'))


# Generated at 2022-06-26 06:11:25.098071
# Unit test for function match
def test_match():
    command = Command('git diff file1 file2')
    assert match(command)


# Generated at 2022-06-26 06:11:51.028857
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', ''))
    assert not match(Command('git diff', '', ''))
    assert not match(Command('git -diff', '', ''))
    assert not match(Command('diff', '', ''))


# Generated at 2022-06-26 06:11:56.275726
# Unit test for function match
def test_match():
    assert match(Command('git diff foo bar',
                         'git diff foo bar',
                         'git diff baz qux'))
    assert not match(Command('git diff --no-index foo bar',
                         'git diff --no-index foo bar',
                         'git diff --no-index baz qux'))
    assert not match(Command('git status', 'git status', 'git status'))


# Generated at 2022-06-26 06:12:00.832056
# Unit test for function match
def test_match():
    assert match(Command('git diff file1.txt file2.txt'))
    assert match(Command('git diff file1.txt file2.txt', '', '/bin/git'))
    assert not match(Command('git diff'))
    assert not match(Command('git diff --no-index file1.txt file2.txt'))
    assert not match(Command('git diff --no-index file1.txt file2.txt', 'git', '/bin/git'))


# Generated at 2022-06-26 06:12:04.133619
# Unit test for function get_new_command
def test_get_new_command():
    # test for git diff
    from thefuck.rules.git_diff_no_index import get_new_command
    command = 'git diff HEAD'
    assert get_new_command(command) == 'git diff --no-index HEAD'

# Generated at 2022-06-26 06:12:09.432837
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', ''))
    assert not match(Command('', '', ''))
    assert not match(Command('git diff file1 file2', '', '', '', ''))
    
    

# Generated at 2022-06-26 06:12:15.374412
# Unit test for function match
def test_match():
    from thefuck.rules.git_diff import match
    assert match('''git diff file1 file2''')
    assert match('''git log -p file1 file2''')
    assert not match('''svn diff file1 file2''')
    assert not match('''git log file1 file2''')
    assert not match('''git diff -b file1 file2''')

# Generated at 2022-06-26 06:12:26.353585
# Unit test for function match
def test_match():
    assert match(Command(script='git diff file1 file2',
                         stderr='foo', stdout='bar'))
    assert not match(Command(script='git diff --no-index file1 file2',
                             stderr='foo', stdout='bar'))
    assert not match(Command(script='git diff',
                             stderr='foo', stdout='bar'))
    assert not match(Command(script='git log',
                             stderr='foo', stdout='bar'))
    assert not match(Command(script='ls',
                             stderr='foo', stdout='bar'))
    assert not match(Command(script='git diff file1 file2 file3',
                             stderr='foo', stdout='bar'))

# Generated at 2022-06-26 06:12:34.041972
# Unit test for function match
def test_match():
    # Check if diff is present
    assert(match(Command('git diff', '', '')))
    # Check if diff is present
    assert(match(Command('git lol diff', '', '')))
    # Check if --no-index is present
    assert(match(Command('git diff --no-index', '', '')))
    # Check if --no-index is not present
    assert(match(Command('git diff a b', '', '')))


# Generated at 2022-06-26 06:12:39.330497
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', '/home/berkeley'))
    assert not match(Command('git diff --no-index file1 file2', '', '/home/berkeley'))
    assert not match(Command('git diff', '', '/home/berkeley'))
    assert not match(Command('git diff file1', '', '/home/berkeley'))
    assert not match(Command('git diff file1 file2 file3', '', '/home/berkeley'))


# Generated at 2022-06-26 06:12:42.050626
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('diff f1.txt f2.txt') == 'git diff --no-index f1.txt f2.txt')

# Generated at 2022-06-26 06:13:29.717722
# Unit test for function match
def test_match():
    assert match(Command('git diff one two'))
    assert not match(Command('git diff'))
    assert not match(Command('git '))
    assert not match(Command('git --no-index two'))
    assert not match(Command('git diff --no-index one two'))
    assert not match(Command('diff one two'))


# Generated at 2022-06-26 06:13:33.410368
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git diff a b')
    assert get_new_command(command1) == 'git diff --no-index a b'
    command2 = Command('git diff --cached HEAD^')
    assert get_new_command(command2) == 'git diff --no-index --cached HEAD^'

# Generated at 2022-06-26 06:13:44.968083
# Unit test for function match
def test_match():
    """
    Unit test for function match()
    function match() returns True if 2 files are given as arguments
    to the command
    """
    assert match(Command('git diff file1 file2',
                         'git diff file1 file2'))
    assert match(Command('git diff file1 file2 -r',
                         'git diff file1 file2 -r'))
    assert match(Command('git diff file1 file2 --no-index',
                         'git diff file1 file2 --no-index'))
    assert not match(Command('git diff file1', 'git diff file1'))
    assert not match(Command('diff file1 file2', 'diff file1 file2'))
    assert not match(Command('git file1 file2', 'git file1 file2'))


# Generated at 2022-06-26 06:13:54.807841
# Unit test for function match
def test_match():
    command = Command(script='git diff file1 file2', stdout='', stderr='')
    assert match(command)

    command = Command(script='git diff branch1 branch2', stdout='', stderr='')
    assert match(command)

    command = Command(script='git diff -b branch1 branch2', stdout='', stderr='')
    assert match(command)

    command = Command(script='git diff -b branch1 branch2', stdout='', stderr='')
    assert not match(command)

    command = Command(script='git diff file1 file1 file2', stdout='', stderr='')
    assert not match(command)


# Generated at 2022-06-26 06:13:57.435147
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command('git diff file1 file2','')
    assert(get_new_command(test_command) == 'git diff --no-index file1 file2')

# Generated at 2022-06-26 06:14:01.405013
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff exp.py in.py', '') == 'git diff --no-index exp.py in.py'

# Generated at 2022-06-26 06:14:06.659859
# Unit test for function match
def test_match():
    assert match(Command('git diff hello.txt world.txt', ''))
    assert not match(Command('git diff --cached hello.txt world.txt', ''))
    assert not match(Command('git rebase hello.txt world.txt', ''))


# Generated at 2022-06-26 06:14:08.989232
# Unit test for function match
def test_match():
    assert match(Command('git diff a b'))
    assert match(Command('git diff'))
    assert match(Command('git diff --no-index a b'))
    assert not match(Command('git diff --no-index'))



# Generated at 2022-06-26 06:14:16.671771
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', ''))
    assert match(Command('git diff file1 file2', ''))
    assert match(Command('git diff file1', ''))
    assert not match(Command('git commit file1 file2', ''))
    assert not match(Command('git diff --no-index file1 file2', ''))


# Generated at 2022-06-26 06:14:21.135227
# Unit test for function match
def test_match():
    def make_command(output):
        return Command('echo {}'.format(output), 'some_dir')

    assert match(
        make_command('$ git diff file_a.txt file_b.txt'))
    assert not match(
        make_command('$ git diff'))
    assert not match(
        make_command('$ git diff --no-index file_a.txt file_b.txt'))
    assert not match(
        make_command('$ git diff file_a.txt file_b.txt file_c.txt'))


# Generated at 2022-06-26 06:16:13.071358
# Unit test for function match
def test_match():
    assert match(Command('git diff dir1 dir2'))
    assert match(Command('git di ff dir1 dir2'))
    assert match(Command('git diff dir1 dir2', 'ssh://user@domain/project.git'))
    assert match(Command('git diff dir1 dir2', 'ssh://user@domain/project.git', 'master'))
    assert not match(Command('git difftool dir1 dir2'))
    assert not match(Command('git diff --no-index dir1 dir2'))
    assert not match(Command('git diff dir1'))
    assert not match(Command('git difftool dir1 dir2', 'ssh://user@domain/project.git', 'master'))


# Generated at 2022-06-26 06:16:18.209865
# Unit test for function match
def test_match():
    assert not match(Command('git diff a b'))
    assert not match(Command('git diff --no-index a b'))
    assert match(Command('git diff a b c'))
    assert not match(Command('git diff --no-index a b c'))


# Generated at 2022-06-26 06:16:24.891804
# Unit test for function match
def test_match():
    assert not match(Command('git diff'))
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff --cached file1 file2'))
    assert not match(Command('git diff --no-index file1 file2'))
    assert not match(Command('git diff file1'))
    assert not match(Command('git diffy file1 file2'))


# Generated at 2022-06-26 06:16:31.214688
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', stderr=''))
    assert match(Command('git diff -w file1 file2', '', stderr=''))
    assert match(Command('git diff file1 file2 -w', '', stderr=''))
    assert match(Command('git diff -w file1 file2 -w', '', stderr=''))
    assert not match(Command('git diff --no-index file1 file2', '', stderr=''))
    assert not match(Command('git diff', '', stderr=''))
    assert not match(Command('git diff dir1 dir2', '', stderr=''))


# Generated at 2022-06-26 06:16:34.449957
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert not match(Command('git status'))
    assert match(Command('git diff --no-edit file1 file2'))


# Generated at 2022-06-26 06:16:39.838551
# Unit test for function match
def test_match():
    assert match(Command(command = 'git diff', script = 'git diff'))
    assert not match(Command(command = 'diff', script = 'diff'))
    assert match(Command(command = 'git diff file1 file2', script = 'git diff file1 file2'))


# Generated at 2022-06-26 06:16:43.306309
# Unit test for function get_new_command
def test_get_new_command():
    from sh import git
    assert get_new_command(git.diff(file1,file2)) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:16:48.201685
# Unit test for function match
def test_match():
    assert match(r"git diff file1 file2")
    assert not match(r"git diff file1")
    assert not match(r"git diff file1 file2 --no-index")
    assert not match(r"git commit -a")

# Generated at 2022-06-26 06:16:50.502941
# Unit test for function match
def test_match():
    assert match(Command('git diff foo bar'))
    assert match(Command('diff foo bar'))
    assert not match(Command('git log'))
    assert not match(Command('git diff --no-index foo bar'))


# Generated at 2022-06-26 06:16:59.512961
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', '/'))
    assert match(Command('git diff --stat file1 file2', '', '/'))
    assert not match(Command('git diff --no-index file1 file2', '', '/'))
    assert not match(Command('git diff file1', '', '/'))
    assert not match(Command('git help diff', '', '/'))
