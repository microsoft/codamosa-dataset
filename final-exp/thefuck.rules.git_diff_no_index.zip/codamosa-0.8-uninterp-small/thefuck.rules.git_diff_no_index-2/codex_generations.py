

# Generated at 2022-06-26 06:07:36.942900
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('fuck') == 'fuck'
    assert get_new_command('fuck --no-index') == 'fuck --no-index'
    assert get_new_command('fuck --no-index file1 file2') == 'fuck --no-index file1 file2'
    assert get_new_command('fuck file1 file2') == 'fuck --no-index file1 file2'
    assert get_new_command('fuck file1 file2 --no-index') == 'fuck --no-index file1 file2 --no-index'


# Generated at 2022-06-26 06:07:40.627304
# Unit test for function match
def test_match():
    str_0 = '!3KB-7@KTB\t'
    var_0 = match(str_0)
    assert var_0 == False


# Generated at 2022-06-26 06:07:44.868441
# Unit test for function get_new_command
def test_get_new_command():
    output = 'diff --no-index'
    var_0 = get_new_command('')
    assert isinstance(var_0, str)
    assert var_0 == output


# Generated at 2022-06-26 06:07:54.651668
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'git diff !3KB-7@KTB\t !3KB-7@KTB\t'
    str_1 = 'git diff --no-index !3KB-7@KTB\t !3KB-7@KTB\t'
    var_0 = get_new_command(str_0)
    assert str_1 == var_0

if __name__ == '__main__':
    test_case_0()
    test_get_new_command()

# Generated at 2022-06-26 06:08:02.313570
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'git diff b.txt a.txt'
    var_0 = get_new_command(str_0)
    assert var_0 == 'git diff --no-index b.txt a.txt'
    str_0 = 'git diff a.txt b.txt'
    var_0 = get_new_command(str_0)
    assert var_0 == 'git diff --no-index a.txt b.txt'

# Generated at 2022-06-26 06:08:04.408085
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = '!3KB-7@KTB\t'
    var_0 = get_new_command(str_0)

# Generated at 2022-06-26 06:08:07.438076
# Unit test for function match
def test_match():
    str_0 = '!3KB-7@KTB\t'
    var_0 = match(str_0)


# Generated at 2022-06-26 06:08:09.285370
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command == 'git diff --no-index'


# Generated at 2022-06-26 06:08:18.799701
# Unit test for function get_new_command
def test_get_new_command():
    assert str(get_new_command('git diff file1 file2')) == 'git diff --no-index file1 file2'
    assert str(get_new_command('git diff --cached file1 file2')) == 'git diff --cached --no-index file1 file2'
    assert str(get_new_command('git diff -U file1 file2')) == 'git diff -U --no-index file1 file2'
    assert str(get_new_command('git diff -U2 file1 file2')) == 'git diff -U2 --no-index file1 file2'
    assert str(get_new_command('git diff --no-index a b file1 file2')) == 'git diff --no-index a b file1 file2'

# Generated at 2022-06-26 06:08:19.966053
# Unit test for function match
def test_match():
    assert match is not None


# Generated at 2022-06-26 06:08:25.839035
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command(script='git diff foo bar'))
    assert new_command == 'git diff --no-index foo bar'

# Generated at 2022-06-26 06:08:31.808678
# Unit test for function match
def test_match():
    assert match(Command('git diff test.py test2.py',
                         '',
                         '/bin/git diff test.py test2.py'))
    assert not match(Command('git difftool -d test.py',
                             '',
                             '/bin/git difftool -d test.py'))


# Generated at 2022-06-26 06:08:35.835497
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff readme.txt readme_bak.txt') == 'git diff --no-index readme.txt readme_bak.txt'

# Generated at 2022-06-26 06:08:41.540470
# Unit test for function match
def test_match():
    assert match(Command('git diff foo bar'))
    assert match(Command('git diff --cached foo bar'))
    assert not match(Command('git status'))
    assert not match(Command('git diff foo'))
    assert not match(Command('git diff --no-index foo bar baz'))


# Generated at 2022-06-26 06:08:53.583202
# Unit test for function match
def test_match():
    assert match(Command('diff one.py two.py',
                         '',
                         'diff one.py two.py'))
    assert match(Command('git diff one.py two.py',
                         '',
                         'git diff one.py two.py'))
    assert not match(Command('diff --no-index one.py two.py',
                             '',
                             'diff --no-index one.py two.py'))
    assert not match(Command('git diff --no-index one.py two.py',
                             '',
                             'git diff --no-index one.py two.py'))
    assert not match(Command('git diff one.py two.py blah blah blah',
                             '',
                             'git diff one.py two.py blah blah blah'))

# Generated at 2022-06-26 06:08:57.942085
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff README.md LICENSE')
    assert get_new_command(command) == 'git diff --no-index README.md LICENSE'

# Generated at 2022-06-26 06:09:03.730790
# Unit test for function match
def test_match():
    assert match(Command('git diff first.txt second.txt', ''))
    assert match(Command('git diff --some-argument first.txt second.txt', ''))
    assert not match(Command('git diff --no-index first.txt second.txt', ''))
    assert not match(Command('git diff --no-index first.txt', ''))

# Generated at 2022-06-26 06:09:10.241180
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert not match(Command('diff file1 file2'))
    assert not match(Command('git diff --no-index file1 file2'))
    assert not match(Command('git diff --cached file1 file2'))


# Generated at 2022-06-26 06:09:14.502290
# Unit test for function match
def test_match():
    assert match(Command('git diff a b', '',
                '/bin/git diff a b\nfatal: Not a git repository: \'..\'\n'))
    assert match(Command('git diff a b', '', 'fatal: Not a git repository'))
    assert not match(Command('ls', '', ''))
    assert not match(Command('git diff a b --no-index', '', ''))
    assert not match(Command('git diff --no-index a b', '', ''))
    assert not match(Command('git diff --no-index a b c', '', ''))



# Generated at 2022-06-26 06:09:21.742193
# Unit test for function match
def test_match():
    assert match(Command('git diff a b', ''))
    assert match(Command('git diff -- a b', ''))
    assert not match(Command('git diff --no-index a b', ''))
    assert not match(Command('git diff --no-index -- a b', ''))
    assert not match(Command('git diff', ''))
    assert not match(Command('git diff a', ''))


# Generated at 2022-06-26 06:09:31.736040
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff file'))
    assert match(Command('git diff'))
    assert not match(Command('git file diff'))
    assert not match(Command('git diff --no-index file1 file2'))


# Generated at 2022-06-26 06:09:41.710788
# Unit test for function match
def test_match():
    for command in [
        'git diff foo bar',
        'git diff --cached foo bar',
        'git diff --no-commit foo bar']:
        assert match(Command(command, ''))

    for command in [
        'git diff --cached --no-index foo bar',
        'git diff --no-index foo bar',
        'git diff foo bar --no-index',
        'git diff foo bar baz']:
        assert not match(Command(command, ''))

# Generated at 2022-06-26 06:09:45.203356
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff file1 file2 some_arg1 some_arg2'))
    assert not match(Command('git diff --no-index file1 file2'))
    assert not match(Command('git diff --no-index file1 file2 some_arg1 some_arg2'))
    assert not match(Command('git diff file1'))
    assert not match(Command('git diff file1 some_arg1 some_arg2'))


# Generated at 2022-06-26 06:09:55.288489
# Unit test for function match
def test_match():
    assert match(Command('git diff README.md README',
                         stderr='fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert not match(Command('git diff --no-index README.md README',
                         stderr='fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert not match(Command('git diff HEAD',
                         stderr='fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert not match(Command('git diff',
                         stderr='fatal: Not a git repository (or any of the parent directories): .git\n'))



# Generated at 2022-06-26 06:10:03.424740
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff file1 file2') == 'git diff --no-index file1 file2'
    assert get_new_command('git diff file1 file2 file3') == 'git diff file1 file2 file3'
    assert get_new_command('git diff --staged file1 file2') == 'git diff --staged file1 file2'
    assert get_new_command('git diff --no-index file1 file2') == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:10:06.101600
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff file1')) is False

# Generated at 2022-06-26 06:10:12.418089
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', ''))
    assert match(Command('git diff --color file1 file2', ''))
    assert not match(Command('git diff --no-index file1 file2', ''))
    assert not match(Command('git diff --color --no-index file1 file2', ''))


# Generated at 2022-06-26 06:10:18.152996
# Unit test for function match
def test_match():
    assert match(Command('git diff fileOne fileSecond', '', ''))
    assert not match(Command('git diff --no-index fileOne fileSecond', '', ''))
    assert not match(Command('git diff', '', ''))


# Generated at 2022-06-26 06:10:20.498281
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff foo bar')) == 'git diff --no-index foo bar'

# Generated at 2022-06-26 06:10:22.409424
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2',''))
    assert match(Command('git diff file1 file2',''))


# Generated at 2022-06-26 06:10:34.572316
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert not match(Command('git diff --cached file1 file2', '', ''))
    assert not match(Command('git diff --no-index file1 file2', '', ''))
    assert not match(Command('git add file1 file2', '', ''))


# Generated at 2022-06-26 06:10:38.916448
# Unit test for function get_new_command
def test_get_new_command():
	if_command = Command('git diff file1 file2', '', stderr='fatal: Not a git repository')
	assert not get_new_command(if_command)

	if_command = Command('git diff file1 file2')
	assert get_new_command(if_command) == 'git diff --no-index file1 file2'



# Generated at 2022-06-26 06:10:40.505041
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('git diff file1 file2')) == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:10:43.274260
# Unit test for function match
def test_match():
    assert match(Command('git diff one two'))
    assert match(Command('git diff one two -w'))
    assert match(Command('git diff --one two'))
    assert match(Command('git diff -w --one two'))
    assert not match(Command('git diff'))


# Generated at 2022-06-26 06:10:48.214662
# Unit test for function get_new_command
def test_get_new_command():
  command = Command('git diff file1 file2', '', 0, None)
  assert get_new_command(command).script == 'git diff --no-index file1 file2'

# Generated at 2022-06-26 06:10:53.159479
# Unit test for function match
def test_match():
    command = Command('git diff file1 file2', '',\
                      stderr='fatal: Not a git repository (or any of the parent directories): .git',\
                      )
    assert match(command)


# Generated at 2022-06-26 06:10:57.697280
# Unit test for function match
def test_match():
    command_1 = ("git diff file1 file2")
    assert match(command_1)

    command_2 = ("git diff --no-index file1 file2")
    assert not match(command_2)

    command_3 = ("git diff -w file1 file2")
    assert not match(command_3)

    command_4 = ("diff file1 file2")
    assert not match(command_4)


# Generated at 2022-06-26 06:11:01.170705
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script='git diff file1 file2')) ==
            'git diff --no-index file1 file2')

# Generated at 2022-06-26 06:11:07.282056
# Unit test for function match
def test_match():
    assert match(Command('git diff',
                         'git diff'))
    assert match(Command('git diff README.md',
                         'git diff README.md'))
    assert not match(Command('git diff README.md',
                             'git diff --no-index README.md'))
    assert not match(Command('git diff --cached',
                             'git diff --cached'))
    assert match(Command('git diff README.md README1.md',
                         'git diff README.md README1.md'))


# Generated at 2022-06-26 06:11:12.937834
# Unit test for function match
def test_match():
    assert match(Command('git diff file1.txt file2.txt', '', ''))
    assert not match(Command('git diff --no-index file1.txt file2.txt', '', ''))
    assert not match(Command('git diff', '', ''))


# Generated at 2022-06-26 06:11:39.772602
# Unit test for function match
def test_match():
    assert match(Command('diff test.txt some-file.txt', ''))
    assert match(Command('git diff test.txt some-file.txt', ''))
    assert match(Command('git diff test.txt', ''))
    assert match(Command('git diff --cached test.txt', ''))
    assert match(Command('git diff --staged test.txt', ''))
    assert match(Command('git diff --cached some-file.txt', ''))
    assert match(Command('git diff --staged some-file.txt', ''))
    assert match(Command('git diff --cached test.txt some-file.txt', ''))
    assert match(Command('git diff --staged test.txt some-file.txt', ''))
    assert match(Command('git diff --staged test.txt some-file.txt', ''))


# Generated at 2022-06-26 06:11:46.186678
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git diff ./thefuck/rules/git.py ./thefuck/rules/git.py.py")
           == 'git diff --no-index ./thefuck/rules/git.py ./thefuck/rules/git.py.py')
    assert(get_new_command("git diff ./thefuck/rules/git.py ./thefuck/rules/git.py.py")
           != 'git diff ./thefuck/rules/git.py ./thefuck/rules/git.py.py')

# Generated at 2022-06-26 06:11:53.012367
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', ''))
    assert not match(Command('git diff --one-line file1 file2', ''))
    assert not match(Command('git diff --no-index file1 file2', ''))
    assert not match(Command('git diff file1 file2 file3', ''))


# Generated at 2022-06-26 06:11:56.862720
# Unit test for function match
def test_match():
    assert match(Command('git diff index.html old/index.html'))
    assert match(Command('git diff --cached index.html old/index.html'))
    assert not match(Command('git diff --no-index index.html old/index.html'))
    assert not match(Command('foo diff --no-index index.html old/index.html'))


# Generated at 2022-06-26 06:12:00.962172
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff foo.txt bar.txt',
                                   'fatal: ambiguous argument \'foo.txt\':')) == 'git diff --no-index foo.txt bar.txt'

# Generated at 2022-06-26 06:12:04.189461
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff foo bar') == 'git diff --no-index foo bar'
    assert get_new_command(
        'git diff -U25 foo bar') == 'git diff -U25 --no-index foo bar'

# Generated at 2022-06-26 06:12:09.516257
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', ''))
    assert not match(Command('git diff', '', ''))
    assert not match(Command('diff file1 file2', '', ''))


# Generated at 2022-06-26 06:12:14.909478
# Unit test for function get_new_command
def test_get_new_command():
    command_one = Command('git diff file1 file2')
    command_two = Command('git diff -t file1 file2')
    assert get_new_command(command_one) == 'git diff --no-index file1 file2'
    assert get_new_command(command_two) == 'git diff --no-index -t file1 file2'

# Generated at 2022-06-26 06:12:16.187261
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command('./test.py')

# Generated at 2022-06-26 06:12:27.086652
# Unit test for function match
def test_match():
    # diff with two files
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff file1 file2',
                         'git diff file1 file2'))
    # diff with only one file
    assert not match(Command('git diff file1'))
    assert not match(Command('git difffile1',
                             'git difffile1'))
    # diff with two files, but using --no-index
    assert not match(Command('git diff --no-index file1 file2',
                             'git diff --no-index file1 file2'))
    # diff with two files, but using --no-index with other options

# Generated at 2022-06-26 06:13:04.632460
# Unit test for function match
def test_match():
    command = Command('git diff file1 file2')
    assert match(command)

    command = Command('git show git diff file1 file2')
    assert not match(command)

    command = Command('git diff --no-index file1 file2')
    assert not match(command)

    command = Command('git diff file1 file2 file3')
    assert not match(command)


# Generated at 2022-06-26 06:13:12.411889
# Unit test for function match
def test_match():
    assert match(Command('git diff a b', '', stderr='fatal: Not a git repository (or any of the parent directories): .git\n'))
    assert not match(Command('git diff --no-index a b', ''))
    assert not match(Command('git diff a', ''))
    assert not match(Command('git diff a/ b', ''))
    assert not match(Command('git diff a b/', ''))
    assert not match(Command('git diff -- a b', ''))


# Generated at 2022-06-26 06:13:18.109038
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff a b')) == 'git diff --no-index a b'
    assert get_new_command(Command('git diff --cached a b')) == 'git diff --cached --no-index a b'

# Generated at 2022-06-26 06:13:26.589951
# Unit test for function match
def test_match():
    assert match(Command('git diff testfile1 testfile2', '',
                         'git diff testfile1 testfile2'))
    assert not match(Command('git diff testfile1 testfile2', '',
                             'git diff --no-index testfile1 testfile2'))
    assert not match(Command('git diff --cached', '', 'git diff --cached'))
    assert not match(Command('git diff', '', 'git diff'))
    assert match(Command('git diff testfile1 testfile2', '',
                         'git diff testfile1 testfile2\n'
                         'fatal: Not a git repository (or any parent up to mount point /home)\n'
                         'Stopping at filesystem boundary (GIT_DISCOVERY_ACROSS_FILESYSTEM not set).\n'))

#

# Generated at 2022-06-26 06:13:31.608431
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2',
                         '', ''))
    assert not match(Command('git diff file1 file2 file3',
                             '', ''))
    assert not match(Command('git diff --cached',
                             '', ''))


# Generated at 2022-06-26 06:13:35.990459
# Unit test for function match
def test_match():
		assert match(Command('git diff file1.txt file2.txt'))
		assert match(Command('git diff'))
		assert not match(Command('git diff --no-index file1.txt file2.txt'))



# Generated at 2022-06-26 06:13:42.425653
# Unit test for function match
def test_match():
	assert match(Command('git diff file1 file2', ''))
	assert match(Command('git diff -a -b file1 file2', ''))
	assert not match(Command('git diff dir1 dir2', ''))
	assert not match(Command('git diff --no-index file1 file2', ''))

# Generated at 2022-06-26 06:13:49.283023
# Unit test for function match
def test_match():
    assert match(Command('git diff slug.py slug2.py'))
    assert not match(Command('git diff'))
    assert not match(Command('git diff --no-index slug.py slug2.py'))
    assert not match(Command('diff slug.py slug2.py'))


# Generated at 2022-06-26 06:13:53.994466
# Unit test for function match
def test_match():
    assert match(Command(script='git diff file1 file2', stderr='', stdout=''))
    assert not match(Command(script='git add file1 file2', stderr='', stdout=''))
    assert not match(Command(script='git diff --no-index file1 file2', stderr='', stdout=''))


# Generated at 2022-06-26 06:13:57.119221
# Unit test for function match
def test_match():
    assert not match(MagicMock(script='git diff'))
    assert not match(MagicMock(script='git diff --no-index'))
    assert match(MagicMock(script='git diff file1 file2'))
    assert match(MagicMock(script='git diff --other-options file1 file2'))



# Generated at 2022-06-26 06:15:27.388337
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff asd ff')) == 'git diff --no-index asd ff'

enabled_by_default = True

# Generated at 2022-06-26 06:15:32.193321
# Unit test for function match
def test_match():
    assert match(Command(script='git diff file1 file2',
        stderr="fatal: Not a git repository (or any of the parent directories): .git\n",
        stdout='',
        )) == True
    assert match(Command(script='git diff --no-index file1 file2', stderr='', stdout='')) == False

# Generated at 2022-06-26 06:15:37.303526
# Unit test for function match
def test_match():
    assert match(Command('git diff foo bar'))
    assert not match(Command('git diff foo bar --no-index'))
    assert not match(Command('git diff'))
    assert not match(Command('git diff --no-index'))


# Generated at 2022-06-26 06:15:39.580000
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git diff a b', '', stderr=''))
            == 'git diff --no-index a b')

# Generated at 2022-06-26 06:15:42.618074
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git diff a b')
    ) == 'git diff --no-index a b'



# Generated at 2022-06-26 06:15:49.409865
# Unit test for function match
def test_match():
    script = ['git','diff','file1','file2']
    command = Command(script, '', '')
    assert(match(command))

    script = ['git','diff','file1','file2','--patch']
    command = Command(script, '', '')
    assert(match(command))

    script = ['git','diff']
    command = Command(script, '', '')
    assert(not match(command))



# Generated at 2022-06-26 06:15:54.774684
# Unit test for function match
def test_match():
    assert match(Command('git diff HEAD HEAD', ''))
    assert not match(Command('git diff', ''))
    assert not match(Command('git diff --no-index HEAD HEAD', ''))
    assert not match(Command('git diff head HEAD', ''))


# Generated at 2022-06-26 06:16:00.963377
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', ''))
    assert match(Command('git diff -w file1 file2', '', ''))
    assert not match(Command('git diff file1 file2 file3', '', ''))
    assert not match(Command('git add file1 file2', '', ''))
    assert not match(Command('git diff --no-index file1 file2', '', ''))



# Generated at 2022-06-26 06:16:06.143519
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff main.c extra.c', '',
                                              '')) \
                                              == 'git diff --no-index main.c extra.c'

enabled_by_default = True

# Generated at 2022-06-26 06:16:12.873117
# Unit test for function match
def test_match():
    command = Command('diff foo bar')
    assert match(command)
    command = Command('git diff foo bar')
    assert match(command)
    command = Command('git diff --patience foo bar')
    assert match(command)
    command = Command('git diff --no-index foo bar')
    assert not match(command)
    command = Command('git diff --no-index foo bar')
    assert not match(command)
    command = Command('git clone git@github.com:nvbn/git-pull-request.git')
    assert not match(command)
