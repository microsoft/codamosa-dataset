

# Generated at 2022-06-22 01:44:31.940834
# Unit test for function match
def test_match():
    assert(match(Command('git diff file1 file2', None)))
    assert(not match(Command('git reset', None)))

# Generated at 2022-06-22 01:44:36.078865
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2')) == 'git diff --no-index file1 file2'
    assert get_new_command(Command('git diff --color-words file1 file2')) == 'git diff --color-words --no-index file1 file2'

# Generated at 2022-06-22 01:44:40.761689
# Unit test for function match
def test_match():
    assert match(Script('diff file1 file2'))
    assert match(Script('git diff file1 file2'))
    assert match(Script('git diff --staged file1 file2'))



# Generated at 2022-06-22 01:44:44.744210
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git diff path_to_file1 path_to_file2")
    new_command = get_new_command(command)
    assert "git diff --no-index path_to_file1 path_to_file2" == new_command

# Generated at 2022-06-22 01:44:46.108064
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))


# Generated at 2022-06-22 01:44:53.240652
# Unit test for function match
def test_match():
    assert match(Command('git diff old new'))
    assert match(Command('git diff old new', 'some_env'))
    assert not match(Command('git foo'))
    assert not match(Command('git bar', 'some_env'))
    assert not match(Command('ls foo'))
    assert not match(Command('ls bar', 'some_env'))
    assert not match(Command('ls -la'))
    assert not match(Command('ls -la', 'some_env'))
    assert not match(Command('ls'))
    assert not match(Command('ls', 'some_env'))


# Generated at 2022-06-22 01:44:55.884032
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff somefile.py otherfile.py', None)) == 'git diff --no-index somefile.py otherfile.py'

# Generated at 2022-06-22 01:44:58.721344
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff A B')) == 'git diff --no-index A B'

# Generated at 2022-06-22 01:45:03.316466
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.diff_files import get_new_command
    assert get_new_command("diff file1 file2") == "git diff --no-index file1 file2"
    assert get_new_command("diff file1 file2 file3") == "git diff --no-index file1 file2 file3"


# Generated at 2022-06-22 01:45:11.365743
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff v0.6.1 v0.6.0', '', '/tmp')
    assert get_new_command(command) == 'git diff --no-index v0.6.1 v0.6.0'

    command = Command('git diff v0.6.1 v0.6.0 --stat', '', '/tmp')
    assert get_new_command(command) == 'git diff --no-index v0.6.1 v0.6.0 --stat'



# Generated at 2022-06-22 01:45:15.153846
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2')) == 'git diff --no-index file1 file2'

# Generated at 2022-06-22 01:45:18.208835
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command(script='git diff file1 file2'))
    assert new_command == 'git diff --no-index file1 file2'

# Generated at 2022-06-22 01:45:29.696465
# Unit test for function match
def test_match():
    assert match(Command('git diff'))
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff --some-args'))
    assert match(Command('git diff --some-args file1 file2'))
    assert not match(Command('git diff --no-index'))
    assert not match(Command('git diff --no-index file1 file2'))
    assert not match(Command('git diff file1 file2 -some-args'))
    assert not match(Command('git diff --no-index file1 file2 -some-args'))
    assert not match(Command('git diff file1 -some-args'))
    assert not match(Command('git diff --no-index file1 -some-args'))
    assert not match(Command('git diff file1 file2 file3'))
   

# Generated at 2022-06-22 01:45:31.483865
# Unit test for function match
def test_match():
   assert match(Command('git diff file1 file2', '', '/bin/git'))


# Generated at 2022-06-22 01:45:33.755158
# Unit test for function match
def test_match():
    assert (match(Command('git push', '')) is None)
    assert (match(Command('git diff 1', '')) is None)

# Generated at 2022-06-22 01:45:35.888836
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff file1 file2') == 'git diff --no-index file1 file2'

# Generated at 2022-06-22 01:45:37.908382
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git diff file1 file2")) == "git diff --no-index file1 file2"

# Generated at 2022-06-22 01:45:43.410902
# Unit test for function match
def test_match():
    assert match(Command('git diff old new', '', '', ''))
    assert not match(Command('git diff --no-index old new', '', '', ''))
    assert not match(Command('git diff old', '', '', ''))
    assert not match(Command('git log', '', '', ''))


# Generated at 2022-06-22 01:45:49.656420
# Unit test for function match
def test_match():
    assert match(Command('git diff foo bar', '', '/home/usr/', ''))
    assert not match(Command('git dif', '', '/home/usr/', ''))
    assert not match(Command('git diff --no-index foo bar', '', '/home/usr', ''))
    assert not match(Command('git diff foo', '', '/home/usr/', ''))


# Generated at 2022-06-22 01:45:53.425399
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', '/c/'))
    assert not match(Command('git diff file1 file2', '', '/c/'))

# Generated at 2022-06-22 01:45:59.317648
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git diff file1 file2') == u'git diff --no-index file1 file2'


enabled_by_default = True

# Generated at 2022-06-22 01:46:04.407035
# Unit test for function match
def test_match():
    assert match(Command('git diff dir1 dir2',
                         '',
                         ''))
    assert not match(Command('git diff dir1',
                         '',
                         ''))
    assert not match(Command('git diff dir1 -s dir2',
                         '',
                         ''))
    assert not match(Command('git diff dir1 --no-index dir2',
                         '',
                         ''))


# Generated at 2022-06-22 01:46:07.834733
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff file1 file2')
    assert get_new_command(command) == 'git diff --no-index file1 file2'


# Generated at 2022-06-22 01:46:13.437883
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2')) == 'git diff file1 file2 --no-index'
    assert get_new_command(Command('git diff file --cached file2')) == 'git diff file --cached --no-index file2'


enabled_by_default = True

# Generated at 2022-06-22 01:46:15.530742
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command('git diff file1 file2')
    assert new_cmd == 'git diff --no-index file1 file2'

# Generated at 2022-06-22 01:46:17.868602
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git diff file1 file2")
    result = get_new_command(command)
    assert result == "git diff --no-index file1 file2"

# Generated at 2022-06-22 01:46:20.505173
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff a b', '')
    new_command = get_new_command(command)
    assert 'diff --no-index a b' in new_command

# Generated at 2022-06-22 01:46:32.849018
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', ''))
    assert match(Command('git diff file1 file2 -a', ''))
    assert match(Command('git diff file1 file2 -b', ''))
    assert match(Command('git diff file1 file2 --cached', ''))
    assert match(Command('git diff -- file1 file2', ''))
    assert not match(Command('git diff --staged', ''))
    assert not match(Command('git diff --staged file', ''))
    assert not match(Command('git diff file', ''))
    assert not match(Command('git diff --no-index', ''))
    assert not match(Command('git diff --no-index file1 file2', ''))
    assert not match(Command('git diff --no-index file1 file2 --cached', ''))

# Generated at 2022-06-22 01:46:35.840913
# Unit test for function get_new_command
def test_get_new_command():
    script_diff = 'git diff hello.py'
    script_no_index = 'git diff --no-index hello.py new_hello.py'
    assert get_new_command(script_diff) == script_no_index



# Generated at 2022-06-22 01:46:37.791973
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('diff README.md LICENSE')
    assert get_new_command(command) == 'git diff --no-index README.md LICENSE'
    command = Command('git diff README.md LICENSE')
    assert get_new_command(command) == 'git diff --no-index README.md LICENSE'

# Generated at 2022-06-22 01:46:52.486457
# Unit test for function match
def test_match():
    assert (match(Command('git diff foo bar', '', '')))
    assert (match(Command('git diff --cached foo bar', '', '')))
    assert (not match(Command('git status', '', '')))
    assert (not match(Command('git diff --no-index foo bar', '', '')))
    assert (not match(Command('git diff --cached --no-index foo bar', '', '')))


# Generated at 2022-06-22 01:47:04.236306
# Unit test for function match
def test_match():
    # A script with the first argument git
    assert match(Command('git diff a.py b.py', ''))
    # A script with the first argument gid
    assert match(Command('gid diff a.py b.py', ''))
    # A script without the first argument git,
    # but the second argument is diff
    assert match(Command('gid dif a.py b.py', ''))
    # A script without the first argument git,
    # but the second argument is not diff
    assert not match(Command('gid a.py b.py', ''))
    # A script with the first argument git,
    # but the second argument is not diff
    assert not match(Command('git add a.py b.py', ''))
    # A script with the first argument git,
    # but the second argument is diff, and

# Generated at 2022-06-22 01:47:08.862933
# Unit test for function match
def test_match():
    assert match(Command('git diff file1.txt file2.txt', '',
                         ''))
    assert match(Command('git diff file1.txt file2.txt -y', '',
                         ''))

# Generated at 2022-06-22 01:47:15.613975
# Unit test for function match
def test_match():
    assert match(Command(script='git diff /tmp/file1 /tmp/file2', stderr=''))
    assert not match(Command(script='git diff --no-index /tmp/file1 /tmp/file2', stderr=''))
    assert not match(Command(script='ls diff /tmp/file1 /tmp/file2', stderr=''))
    assert not match(Command(script='git diff', stderr=''))


# Generated at 2022-06-22 01:47:27.196263
# Unit test for function match
def test_match():
    assert match(Command('diff testA testB',\
            '/home/mogeko/test'))
    assert match(Command('git diff testA testB',\
            '/home/mogeko/test'))
    assert match(Command('git diff testA',\
            '/home/mogeko/test'))
    assert match(Command('diff testA',\
            '/home/mogeko/test'))
    assert not match(Command('diff testA testB --no-index',\
            '/home/mogeko/test'))
    assert not match(Command('git diff testA testB --no-index',\
            '/home/mogeko/test'))
    assert not match(Command('ls',\
            '/home/mogeko/test'))

# Generated at 2022-06-22 01:47:29.156289
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(ShellCommand('git diff file1 file2', '')) == 'git diff --no-index file1 file2'

# Generated at 2022-06-22 01:47:31.295790
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('diff README.md LICENSE') == 'git diff --no-index README.md LICENSE'

# Generated at 2022-06-22 01:47:33.849073
# Unit test for function match
def test_match():
	assert match(Command('git diff file1 file1'))
	assert not match(Command('git diff --no-index file1 file1'))


# Generated at 2022-06-22 01:47:36.733828
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff file1 file2')
    assert('git diff --no-index file1 file2' == get_new_command(command))

# Generated at 2022-06-22 01:47:38.520612
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff a b') == 'git diff --no-index a b'

# Generated at 2022-06-22 01:47:57.318720
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        u'git diff file1 file2'
    ) == u'git diff --no-index file1 file2'

# Generated at 2022-06-22 01:48:04.639920
# Unit test for function match
def test_match():
    assert (match(Command(script='git diff test.py',
                          stderr='fatal: Not a git repository')))
    assert (not match(Command(script='git diff --no-index test.py',
                              stderr='fatal: Not a git repository')))
    assert (not match(Command(script='git diff --no-index test.py a.py',
                              stderr='fatal: Not a git repository')))
    assert (not match(Command(script='git --no-index test.py a.py',
                              stderr='fatal: Not a git repository')))


# Generated at 2022-06-22 01:48:07.890653
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('diff file1 file2') == 'diff --no-index file1 file2'


# Generated at 2022-06-22 01:48:12.829205
# Unit test for function get_new_command
def test_get_new_command():
    script = "diff foo.txt bar.txt"
    script_parts = script.split()
    command = Command(script, script_parts, "")
    assert get_new_command(command) == "git diff --no-index foo.txt bar.txt"


# Generated at 2022-06-22 01:48:19.529909
# Unit test for function match
def test_match():
    from thefuck.rules.git_no_index import match
    assert not match("git diff a b")
    assert match("git diff --no-index a b")
    assert match("git diff a b --no-index")
    assert match("git diff --no-index a b --no-index")
    assert match("git diff a b --no-index b c d")
    assert match("git diff a")
    assert match("git diff")
    assert match("git diff a b c d e f g h i j k l m")
    assert match("git diff")

# Generated at 2022-06-22 01:48:28.195605
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff --color file1 file2'))
    assert match(Command('git diff --nofoo file1 file2'))
    assert match(Command('git diff --color=always --no-index file1 file2'))
    assert not match(Command('git difffile1 file2'))
    assert not match(Command('git diff --no-index file1 file2'))
    assert not match(Command('git difffile1'))


# Generated at 2022-06-22 01:48:31.916315
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff test.py test2.py', '',
                      stderr='fatal: Not a git repository (or any of the parent directories): .git')
    assert match(command)
    assert get_new_comma

# Generated at 2022-06-22 01:48:35.327280
# Unit test for function match
def test_match():
    assert (match(Command('git diff file1 file2', '', '')))
    assert (not match(Command('git diff --no-index file1 file2', '', '')))
    assert (not match(Command('git diff file1', '', '')))


# Generated at 2022-06-22 01:48:43.670837
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', 'git diff file1 file2'))
    assert not match(Command('git commit file1 file2', '', 'git commit file1 file2'))
    assert not match(Command('git diff -a file1 file2', '', 'git diff file1 file2'))
    assert match(Command('git diff --no-index file1 file2', '', 'git diff file1 file2'))
    assert match(Command('git diff file1 file2 file3', '', 'git diff file1 file2'))


# Generated at 2022-06-22 01:48:48.477677
# Unit test for function match
def test_match():
    assert match(Command('git diff a.py b.py', '', '', 1))
    assert not match(Command('git difftool a.py b.py', '', '', 1))
    assert not match(Command('git diff --no-index a.py b.py', '', '', 1))

# Generated at 2022-06-22 01:49:28.091812
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', 'git'))
    assert match(Command('git diff --cached file1 file2', 'git'))
    assert match(Command('git diff -p file1 file2', 'git'))
    assert not match(Command('git diff --no-index file1 file2', 'git'))
    assert not match(Command('git diff --no-index file1 /dev/null', 'git'))
    assert not match(Command('git diff --no-index', 'git'))
    assert not match(Command('git diff', 'git'))


# Generated at 2022-06-22 01:49:36.792226
# Unit test for function match
def test_match():
    assert match(Command('git diff'))
    assert match(Command('git diff file1 file2'))
    assert match(Command('git diff file1 file2 file3'))
    assert not match(Command('git diff A B --no-index'))
    assert not match(Command('git diff --no-index'))
    assert not match(Command('git'))
    assert not match(Command('git dif'))
    assert not match(Command('git diff'))
    assert not match(Command('git diff file'))


# Generated at 2022-06-22 01:49:38.733269
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff a b', '')) == 'git diff --no-index a b'


# Generated at 2022-06-22 01:49:45.366166
# Unit test for function match
def test_match():
    assert match(Command('git diff', '', '/bin/bash'))
    assert match(Command('git diff a b', '', '/bin/bash'))
    assert not match(Command('ls a b', '', '/bin/bash'))
    assert not match(Command('git diff a b', '', '/bin/bash'))
    assert not match(Command('git diff --no-index a b', '', '/bin/bash'))

# Generated at 2022-06-22 01:49:47.551550
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(u'git diff file1 file2') == u'git diff --no-index file1 file2'

# Generated at 2022-06-22 01:49:49.674307
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff a b')) == 'git diff --no-index a b'


# Generated at 2022-06-22 01:49:55.824453
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2', '', stderr=''))
    assert match(Command('git diff -w file1 file2', '', stderr=''))
    assert not match(Command('git diff file1 file2 file3', '', stderr=''))
    assert not match(Command('git diff --no-index file1 file2', '', stderr=''))


# Generated at 2022-06-22 01:50:01.054173
# Unit test for function match
def test_match():
    assert match(Command('git diff test.py new.py', '', stderr='fatal: Not a git repository'))
    assert not match(Command('git diff new.py test.py', '', stderr='fatal: Not a git repository'))
    assert not match(Command('git diff --no-index test.py new.py', '', stderr='fatal: Not a git repository'))
    assert not match(Command('git diff test.py', '', stderr='fatal: Not a git repository'))
    assert not match(Command('git diff test.py new.py', stderr='fatal: Not a git repository'))


# Generated at 2022-06-22 01:50:03.949693
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff fileA fileB')
    assert get_new_command(command) == 'git diff --no-index fileA fileB'

# Generated at 2022-06-22 01:50:06.181362
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff f1 f2')) == 'git diff --no-index f1 f2'


# Generated at 2022-06-22 01:50:43.768120
# Unit test for function match
def test_match():
    assert match(Command('git diff test_git_diff.py __init__.py'))
    assert not match(Command('git diff --no-index test_git_diff.py __init__.py'))
    assert not match(Command('git diff'))


# Generated at 2022-06-22 01:50:46.355081
# Unit test for function get_new_command
def test_get_new_command():
    script = 'git diff'
    new_script = 'git diff --no-index'

    assert get_new_command(Command(script, '')) == new_script

# Generated at 2022-06-22 01:50:53.691869
# Unit test for function match
def test_match():
    assert match(Command('git diff file1 file2',
                         'git diff file1 file2\n', ''))
    assert not match(Command('git add file1',
                             'git add file1\n', ''))
    # with options
    assert match(Command('git diff -w file1 file2',
                         'git diff -w file1 file2\n', ''))
    # no arguments
    assert not match(Command('git diff',
                             'git diff\nusage: git diff [<options>]', ''))
    # no diff
    assert not match(Command('git log',
                             'git log\nusage: git log [<options>]', ''))



# Generated at 2022-06-22 01:50:56.187435
# Unit test for function match
def test_match():
    command = Command('git diff src/example.py src/example.java')
    assert match(command) is True
    command = Command('git diff')
    assert match(command) is False


# Generated at 2022-06-22 01:51:05.073535
# Unit test for function match
def test_match():
    command = Command('git diff asdf/ asdf/')
    assert match(command)

    command = Command('git diff asdf/ asdf/ --word-diff')
    assert match(command)

    command = Command('git diff --no-index asdf/ jklo/')
    assert not match(command)

    command = Command('git diff asdf/')
    assert not match(command)

    command = Command('git diff asdf/ asdf/ asdf/')
    assert not match(command)


# Generated at 2022-06-22 01:51:07.962091
# Unit test for function match
def test_match():
    supported_command = 'git diff 1.py 2.py'
    not_supported_command = 'git status'

    assert match(Command(supported_command, ''))
    assert not match(Command(not_supported_command, ''))


# Generated at 2022-06-22 01:51:11.520650
# Unit test for function match
def test_match():
    command = Command('git diff file1 file2')
    assert match(command)

    command = Command('git diff file1 file2 --no-index')
    assert not match(command)

    command = Command('git diff')
    assert not match(command)


# Generated at 2022-06-22 01:51:22.840641
# Unit test for function match
def test_match():
    assert match(Command('git diff src/app.js src/server.js',
                         stderr='error: pathspec \'src/app.js\' did not match any file(s) known to git.\n'
                                'error: pathspec \'src/server.js\' did not match any file(s) known to git.\n'
                                'Did you forget to \'git add\'?'))

    assert not match(Command('git diff src/app.js src/server.js',
                             stderr='fatal: ambiguous argument \'src/app.js\': both revision and filename\n'
                                    'Use \'--\' to separate paths from revisions, like this:\n'
                                    '\'git <command> [<revision>...] -- [<file>...]\''))



# Generated at 2022-06-22 01:51:33.157286
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2')) == 'git diff --no-index file1 file2'
    assert get_new_command(Command('git diff file1 file2 file3')) == 'git diff --no-index file1 file2 file3'
    assert get_new_command(Command('git diff file1')) == 'git diff file1'
    assert get_new_command(Command('git diff --cached file1 file2')) == 'git diff --no-index --cached file1 file2'
    assert get_new_command(Command('git diff file1 file2 -U')) == 'git diff --no-index file1 file2 -U'


# Generated at 2022-06-22 01:51:39.747985
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command('diff file1 file2')
    assert (get_new_command(cmd) == 'git diff --no-index file1 file2')
    cmd = Command('diff --git file1 file2')
    assert (get_new_command(cmd) == 'git diff --git --no-index file1 file2')
    cmd = Command('diff --global file1 file2')
    assert (get_new_command(cmd) == 'git diff --global --no-index file1 file2')

# Generated at 2022-06-22 01:52:53.817872
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git diff file1 file2')) == 'git diff --no-index file1 file2'


# Generated at 2022-06-22 01:52:59.604947
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff hello.py world.py',
                      'diff --git a/hello.py b/hello.py\\nindex aa9ce50..908a4b4 100644\\n--- a/hello.py\\n+++ b/hello.py\\n')
    assert get_new_command(command) == 'git diff --no-index hello.py world.py'



# Generated at 2022-06-22 01:53:03.066029
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command("git diff file_1.txt file_2.txt")) == "git diff --no-index file_1.txt file_2.txt")


# Generated at 2022-06-22 01:53:03.732888
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git diff file1 file2") == "git diff --no-index file1 file2"

# Generated at 2022-06-22 01:53:10.387813
# Unit test for function match
def test_match():
    assert match(Command('git diff a b', '', '/bin/git'))
    assert not match(Command('git diff --no-index a b', '', '/bin/git'))
    assert not match(Command('git diff -x a b', '', '/bin/git'))
    assert not match(Command('git diff', '', '/bin/git'))
    assert not match(Command('git add', '', '/bin/git'))
    assert not match(Command('rm a b', '', '/bin/rm'))

# Generated at 2022-06-22 01:53:13.225175
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git diff filename1 filename2')
    new_command = get_new_command(command)
    assert new_command == 'git diff --no-index filename1 filename2'

# Generated at 2022-06-22 01:53:18.204556
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('git diff 1 2') == 'git diff --no-index 1 2'
	assert get_new_command('git diff 1 2 ') == 'git diff --no-index 1 2'
	assert get_new_command('git diff 1 2 -w') == 'git diff --no-index 1 2 -w'


# Generated at 2022-06-22 01:53:19.888534
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git diff file1 file2', None) == 'git diff --no-index file1 file2'

# Generated at 2022-06-22 01:53:23.854131
# Unit test for function get_new_command
def test_get_new_command():
  from thefuck.rules.git_diff_noindex import get_new_command
  command = "git diff file1 file2"
  new_command = get_new_command(command)
  assert(get_new_command(command) == "git diff --no-index file1 file2")

# Generated at 2022-06-22 01:53:25.661553
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git diff file1 file2', '', ''))
            == 'git diff --no-index file1 file2')