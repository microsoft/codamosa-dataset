

# Generated at 2022-06-20 22:46:07.527316
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True # NOQA
    assert is_deactivating_service({'ActiveState': 'dead'}) is False



# Generated at 2022-06-20 22:46:14.954450
# Unit test for function main

# Generated at 2022-06-20 22:46:27.062082
# Unit test for function main

# Generated at 2022-06-20 22:46:38.471288
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:46:42.601583
# Unit test for function is_running_service
def test_is_running_service():
    assert(is_running_service({'ActiveState': 'active'}))
    assert(is_running_service({'ActiveState': 'activating'}))
    assert(not is_running_service({'ActiveState': 'inactive'}))


# Generated at 2022-06-20 22:46:50.399936
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Unit test for function parse_systemctl_show
    test_input = [
        'Description=This is a test unit file',
        'Requires=foo.service',
        'Wants=bar.service',
        'ExecStart=/usr/bin/this-command-fails --with-args',
        '  ExecStart=/usr/bin/this-command-fails --with-args',
        '  ExecStart=/usr/bin/this-command-fails --with-args',
        'ExecReload=/bin/kill --signal=1',
        '  ExecReload=/bin/kill --signal=1',
        '  ExecReload=/bin/kill --signal=1',
        'TestKey=test-value',
        '',
        '',
    ]

# Generated at 2022-06-20 22:46:55.522589
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:47:06.807275
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Id=my.service',
        'ExecStart={ path=/bin/echo ; argv[]=echo ; argv[]=Hello ; argv[]=World!',
        '  ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0',
        '  code=(null) ; status=0/0 }',
    ]
    r = parse_systemctl_show(lines)
    assert r['ExecStart'] == '{ path=/bin/echo ; argv[]=echo ; argv[]=Hello ; argv[]=World!\n  ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0\n  code=(null) ; status=0/0 }'

# Generated at 2022-06-20 22:47:17.973964
# Unit test for function main

# Generated at 2022-06-20 22:47:22.670619
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'active: need status'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'inactive'})


# Generated at 2022-06-20 22:47:39.313048
# Unit test for function main
def test_main():
    assert main() is None

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:48.725956
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([
        'Description=Command Scheduler',
        'Documentation=man:crond(8) man:crontab(5)',
        'LoadState=loaded',
        'ActiveState=active',
        'SubState=running',
        'UnitFileState=enabled',
        'Id=crond.service'
    ]) == {
        'Description': 'Command Scheduler',
        'Documentation': 'man:crond(8) man:crontab(5)',
        'LoadState': 'loaded',
        'ActiveState': 'active',
        'SubState': 'running',
        'UnitFileState': 'enabled',
        'Id': 'crond.service',
    }

# Generated at 2022-06-20 22:47:52.438697
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('= foo') is False



# Generated at 2022-06-20 22:48:03.364821
# Unit test for function main
def test_main():
    test_input = dict()

    test_input['name'] = 'sshd'
    test_input['state'] = 'restarted'
    test_input['enabled'] = True
    test_input['masked'] = False
    test_input['daemon_reload'] = False
    test_input['daemon_reexec'] = False
    test_input['scope'] = 'system'
    test_input['no_block'] = False
    test_input['force'] = None

    if os.getenv('SYSTEMD_STUB_NO_SERVICE'):
        test_output_success = dict()
        test_output_success['status'] = dict()
        test_output_success['status']['LoadState'] = 'not-found'

# Generated at 2022-06-20 22:48:05.113668
# Unit test for function is_running_service
def test_is_running_service():
    result = {'ActiveState': 'active'}
    assert is_running_service(result)



# Generated at 2022-06-20 22:48:12.740593
# Unit test for function main

# Generated at 2022-06-20 22:48:19.233172
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:30.687458
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    single_line_output = [
        'Id=foo',
        'Description=Foo Service'
    ]
    assert parse_systemctl_show(single_line_output) == {
        'Id': 'foo',
        'Description': 'Foo Service',
    }

    multi_line_output = [
        'ExecStart={',
        '    Path=/usr/bin/foo',
        '    Arguments=arg1 arg2',
        '}',
    ]
    assert parse_systemctl_show(multi_line_output) == {
        'ExecStart': '{\n    Path=/usr/bin/foo\n    Arguments=arg1 arg2\n}',
    }


# Generated at 2022-06-20 22:48:34.824450
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': "deactivating"}
    assert is_deactivating_service(service_status)
    service_status = {'ActiveState': "not deactivating"}
    assert not is_deactivating_service(service_status)
# end of Unit test for function is_deactivating_service



# Generated at 2022-06-20 22:48:38.339904
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-20 22:49:03.585240
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False



# Generated at 2022-06-20 22:49:06.629953
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('= static') is False



# Generated at 2022-06-20 22:49:09.534090
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert is_running_service({'ActiveState': 'exited'}) is False
    assert is_running_service({'ActiveState': 'dead'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False



# Generated at 2022-06-20 22:49:14.944495
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:49:26.388072
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:49:33.276889
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = '''
    ignoring request to reload object path '/org/freedesktop/DBus/Local': method name 'ReloadConfig' not allowed
    ignoring request to reload object path '/org/freedesktop/DBus/Local': method name 'ReloadConfig' not allowed
    ignoring request to reload object path '/org/freedesktop/DBus/Local': method name 'ReloadConfig' not allowed
    ignoring command 'help' from local client
    ignoring command 'help' from local client
    ignoring command 'help' from local client
    '''
    assert request_was_ignored(out)



# Generated at 2022-06-20 22:49:42.310590
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    deactivating_service_status = {
        "ActiveEnterTimestamp": "Sun 2016-05-15 18:28:49 EDT",
        "ActiveEnterTimestampMonotonic": "8135942",
        "ActiveExitTimestampMonotonic": "0",
        "ActiveState": "deactivating"
    }
    not_deactivating_service_status = {
        "ActiveEnterTimestamp": "Sun 2016-05-15 18:28:49 EDT",
        "ActiveEnterTimestampMonotonic": "8135942",
        "ActiveExitTimestampMonotonic": "0",
        "ActiveState": "active"
    }
    assert not is_deactivating_service(not_deactivating_service_status)
    assert is_deactivating_service(deactivating_service_status)



# Generated at 2022-06-20 22:49:52.796952
# Unit test for function main
def test_main():
    system_stub1 = {
        'rc': 0,
        'stdout': "",
        'stderr': ""
    }

    module_stub1 = {
        'rc': 0,
        'stdout': "",
        'stderr': ""
    }

    module_stub2 = {
        'rc': 0,
        'stdout': "",
        'stderr': ""
    }

    module_stub3 = {
        'rc': 0,
        'stdout': "",
        'stderr': ""
    }

    module_stub4 = {
        'rc': 0,
        'stdout': "",
        'stderr': ""
    }


# Generated at 2022-06-20 22:49:57.515158
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'not active'})



# Generated at 2022-06-20 22:50:10.228217
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', default='foo', aliases=['service', 'unit']),
            state=dict(type='str', default='started'),
            enabled=dict(type='bool', default=False),
            force=dict(type='bool', default=False),
            masked=dict(type='bool', default=False),
            daemon_reload=dict(type='bool', default=False),
            daemon_reexec=dict(type='bool', default=False),
            scope=dict(type='str', default='system', choices=['system', 'user', 'global']),
            no_block=dict(type='bool', default=False),
        ),
    )


# Generated at 2022-06-20 22:50:44.075097
# Unit test for function is_running_service
def test_is_running_service():
    status = {'ActiveState': 'active'}
    assert is_running_service(status) == True
    status = {'ActiveState': 'activating'}
    assert is_running_service(status) == True
    for state in ['failed', 'inactive', 'reloading', 'deactivating']:
        status = {'ActiveState': state}
        assert is_running_service(status) == False



# Generated at 2022-06-20 22:50:47.285253
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:50:51.717561
# Unit test for function is_running_service
def test_is_running_service():
    is_running_service({'ActiveState': 'active'})
    is_running_service({'ActiveState': 'activating'})
    try:
        is_running_service({'ActiveState': 'inactive'})
        raise Exception("Should have raised an exception.")
    except AssertionError:
        pass



# Generated at 2022-06-20 22:50:56.023235
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) is True
    service_status['ActiveState'] = 'active'
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-20 22:51:05.969184
# Unit test for function main

# Generated at 2022-06-20 22:51:08.432688
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-20 22:51:19.236846
# Unit test for function main

# Generated at 2022-06-20 22:51:26.869292
# Unit test for function is_running_service
def test_is_running_service():
    running = {'ActiveState': 'active'}
    activating = {'ActiveState': 'activating'}
    inactive = {'ActiveState': 'inactive'}
    bad_data = {'ActiveState': 'invalid-value'}
    assert is_running_service(running)
    assert is_running_service(activating)
    assert not is_running_service(inactive)
    assert not is_running_service(bad_data)



# Generated at 2022-06-20 22:51:36.419524
# Unit test for function is_running_service
def test_is_running_service():
    sample_activating = {'ActiveState': 'activating',
                         'LoadState': 'loaded',
                         'SubState': 'running',
                         'UnitFileState': 'enabled',
                         'UnitFilePreset': 'enabled',
                         }
    sample_active = {'ActiveState': 'active',
                     'LoadState': 'loaded',
                     'SubState': 'running',
                     'UnitFileState': 'enabled',
                     'UnitFilePreset': 'enabled',
                     }
    sample_inactive = {'ActiveState': 'inactive',
                       'LoadState': 'loaded',
                       'SubState': 'dead',
                       'UnitFileState': 'enabled',
                       'UnitFilePreset': 'enabled',
                       }

# Generated at 2022-06-20 22:51:39.884733
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-20 22:53:01.966529
# Unit test for function main

# Generated at 2022-06-20 22:53:07.365259
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({"ActiveState": "active"}) is True
    assert is_running_service({"ActiveState": "activating"}) is True
    assert is_running_service({"ActiveState": "inactive"}) is False
    assert is_running_service({"ActiveState": "deactivating"}) is False


# Generated at 2022-06-20 22:53:10.401459
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert(is_deactivating_service({'ActiveState': 'deactivating'}) is True)
    assert(is_deactivating_service({'ActiveState': 'active'}) is False)



# Generated at 2022-06-20 22:53:15.769592
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    deact_service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(deact_service_status) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False
    assert is_deactivating_service({'ActiveState': 'active'}) is False


# Generated at 2022-06-20 22:53:20.159695
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True



# Generated at 2022-06-20 22:53:24.355826
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True



# Generated at 2022-06-20 22:53:30.851960
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'unknown'}) is False



# Generated at 2022-06-20 22:53:42.103517
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:53:45.735048
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request to reload unit.')
    assert not request_was_ignored('Failed to get D-Bus connection:')
    assert request_was_ignored('Ignoring command:')
    assert request_was_ignored('Job for something.service failed')



# Generated at 2022-06-20 22:53:51.438137
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('')
    assert not request_was_ignored('=')
    assert not request_was_ignored('no change')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request [' + ('x' * 10000) + ']')

