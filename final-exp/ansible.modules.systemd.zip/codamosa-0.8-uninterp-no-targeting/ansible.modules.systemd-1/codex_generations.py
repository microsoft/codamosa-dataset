

# Generated at 2022-06-20 22:46:15.726142
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('FAILED')
    assert not request_was_ignored('= 1')



# Generated at 2022-06-20 22:46:25.491518
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring command\n')
    assert not request_was_ignored('ignoring requests')
    assert not request_was_ignored('ignoring commandz')
    assert not request_was_ignored('ignoring=request')
    assert not request_was_ignored('')
    assert not request_was_ignored('=')
    assert not request_was_ignored(' = ')
    assert not request_was_ignored(' = ')
    assert not request_was_ignored(' = ')



# Generated at 2022-06-20 22:46:36.631275
# Unit test for function main

# Generated at 2022-06-20 22:46:41.485878
# Unit test for function is_running_service
def test_is_running_service():
    def test_case(service_status, expected_result=False):
        result = is_running_service(service_status)
        assert result == expected_result
    # Test service status is a dictionary
    test_case(dict(ActiveState='active'), True)
    # Test service status is a string
    test_case(dict(ActiveState='inactive'), False)
    # Test service status is not present
    test_case(dict(), False)
    # Test service status is not a string
    test_case({'ActiveState': 10}, False)
    # Test service status is active and activating
    test_case({'ActiveState': 'activating'}, True)
    test_case({'ActiveState': 'active'}, True)
    # Test service status is failed and inactive
    test_case({'ActiveState': 'failed'}, False)

# Generated at 2022-06-20 22:46:46.531735
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as cm:
        main()
# unit test will be skipped as we cannot simulate chroot
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:46:57.158423
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('warning: process 123456 (example) already exists') is True
    assert request_was_ignored('process 123456 (example) already exists') is True
    assert request_was_ignored('process 123456 (example) already exists\n') is True
    assert request_was_ignored('warning: process 123456 (example) already exists\n') is True

    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True

    assert request_was_ignored('Unit XXX is masked') is True
    assert request_was_ignored('Unit XXX is masked\n') is True
    assert request_was_ignored('Unit XXX is masked.') is True
    assert request_was_ignored('Unit XXX is masked.\n') is True

   

# Generated at 2022-06-20 22:47:00.172821
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('some=thing')



# Generated at 2022-06-20 22:47:03.670664
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'inactive'}) == False



# Generated at 2022-06-20 22:47:12.716235
# Unit test for function is_running_service
def test_is_running_service():
    test_results = map(
        lambda state, expected: {
            'test': ('active' if state else 'inactive', state == expected),
            'result': state == expected
        },
        map(
            lambda state: is_running_service({'ActiveState': state}),
            [
                'active', 'activating',
                'reloading', 'inactive', 'failed', 'deactivating', 'activating'
            ]
        ),
        [True, True, True, False, False, False, True]
    )
    return [x for x in test_results if not x['result']]



# Generated at 2022-06-20 22:47:16.284603
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'exited'})



# Generated at 2022-06-20 22:47:36.600182
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to load config: Invalid argument\n')
    assert not request_was_ignored('Not starting unit httpd.service, because it is masked.')
    assert request_was_ignored('Ignoring request to reload httpd.service, as it is masked.')



# Generated at 2022-06-20 22:47:40.989374
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:47:49.475045
# Unit test for function main
def test_main():
    TEST_DATA = [
        # Workaround for https://github.com/ansible/ansible/issues/71528
        dict(
            # NOTE: Unit must be specified in the unit form (e.g. sshd.service).
            # See: https://github.com/ansible/ansible/issues/71528#issuecomment-539629222
            name="NetworkManager.service",
            state="started",
            scope="system",
            systemctl="systemctl",
            enabled=True,
            rc=0,
            changed=True,
            is_initd=False,
            status="",
            stdout="",
            stderr="",
            is_systemd=True,
            is_masked=False,
            is_running=True,
            found=True,
        ),
    ]

   

# Generated at 2022-06-20 22:47:59.903145
# Unit test for function is_running_service
def test_is_running_service():
    result = {}
    result = {'ActiveState': 'active'}
    assert is_running_service(result) is True
    result = {'ActiveState': 'activating'}
    assert is_running_service(result) is True
    result = {'ActiveState': 'inactive'}
    assert is_running_service(result) is False
    result = {'ActiveState': 'inactive'}
    assert is_running_service(result) is False
    result = {'ActiveState': 'failed'}
    assert is_running_service(result) is False
    result = {'ActiveState': 'other'}
    assert is_running_service(result) is False

# Generated at 2022-06-20 22:48:02.317962
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request to reload done, because service is inactive')
    assert request_was_ignored('ignoring command to reload done, because service is inactive')
    assert not request_was_ignored('foo = bar')



# Generated at 2022-06-20 22:48:11.074006
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:21.038802
# Unit test for function main
def test_main():

    # Since the unit test was already written to test the main function
    # and it doesn't cover the other functions, we only need to test the main
    # function without the functions.
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str'),
            state=dict(type='str'),
        ),
        supports_check_mode=True,
        required_one_of=[['state']],
        required_by=dict(
            state=('name', ),
        ),
    )
    global is_running_service
    is_running_service = lambda x: True
    is_deactivating_service = lambda x: False
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:27.684710
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'deactivating'}) == False
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'failed'}) == False



# Generated at 2022-06-20 22:48:29.904407
# Unit test for function main
def test_main():
    match = None
    
    # Test function
    result = main([])

    # Verify Results
    assert result['failed'] == False

# Generated at 2022-06-20 22:48:32.304927
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-20 22:49:19.568570
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    t = parse_systemctl_show([
        'Id=foo.service',
        'Description=small',
        'Description=foo',
        'Description=bar',
        'ExecStart={',
        '    a b c',
        '    d e f',
        '}'
    ])
    assert t == {'Id': 'foo.service', 'Description': 'small\nfoo\nbar', 'ExecStart': '{\n    a b c\n    d e f\n}'}



# Generated at 2022-06-20 22:49:27.074354
# Unit test for function is_running_service
def test_is_running_service():
    service_running = {'ActiveState': 'active',
                       'SubState': 'running'}
    service_activating = {'ActiveState': 'activating',
                          'SubState': 'activating'}
    service_failed = {'ActiveState': 'failed',
                      'SubState': 'failed'}
    if is_running_service(service_running) and is_running_service(service_activating) and not is_running_service(service_failed):
        pass
    else:
        raise Exception("Failed unit testing of is_running_service")



# Generated at 2022-06-20 22:49:30.887150
# Unit test for function is_running_service
def test_is_running_service():
    # check with default running service
    assert is_running_service({'ActiveState': 'active'})

    # check with service in unkown state
    assert not is_running_service({'ActiveState': 'unknown'})



# Generated at 2022-06-20 22:49:33.467013
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) == True



# Generated at 2022-06-20 22:49:42.465935
# Unit test for function request_was_ignored
def test_request_was_ignored():
    true_output = 'Unit kdump.service is not loaded, ignoring request.'

# Generated at 2022-06-20 22:49:46.983392
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request of stop for unit named.service, provided by process 2145 (systemd).') is True
    assert request_was_ignored('Asking process 733 (systemd) to stop named.service...') is False
    assert request_was_ignored('Asking systemctl to stop named.service...') is False
    assert request_was_ignored('Ignoring command stop for unit named.service, provided by process 733 (systemd).') is True



# Generated at 2022-06-20 22:49:49.805964
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
        test_dict = dict(ActiveState='deactivating')
        assert is_deactivating_service(test_dict)



# Generated at 2022-06-20 22:49:56.655347
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'blah'})
    assert not is_deactivating_service('blah')



# Generated at 2022-06-20 22:50:09.286976
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = ['Id=crond.service\n', 'Description={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }\n', 'Test=1 2 3 4 5 6 7\n', 'ExecStart={\n', '    path=/usr/sbin/crond ;\n', '    argv[]=/usr/sbin/crond -n $CRONDARGS\n', '}\n', 'ExecMainCode=0\n', 'ActiveState=active\n']
    parsed = parse_systemctl_show(lines)
    assert parsed['Id'] == 'crond.service'

# Generated at 2022-06-20 22:50:14.458746
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False


# Generated at 2022-06-20 22:50:44.445773
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('= not in out and (ignoring request in out or ignoring command')  # NOQA



# Generated at 2022-06-20 22:50:50.774526
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Single-line value
    assert parse_systemctl_show(['StandardOutput=journal']) == {'StandardOutput': 'journal'}
    # Single-line value that starts with {
    assert parse_systemctl_show(['Description={ This is a test }']) == {'Description': '{ This is a test }'}
    # Multi-line value
    assert parse_systemctl_show(['ExecStart=\n{\npath=/bin/run\n}\n']) == {'ExecStart': '{\npath=/bin/run\n}'}
    # Several single-line values, then a multi-line value, then a single-line value

# Generated at 2022-06-20 22:50:53.251373
# Unit test for function is_running_service
def test_is_running_service():
    status = {'ActiveState': 'active'}
    result = is_running_service(status)
    assert result == True
#

# Generated at 2022-06-20 22:50:58.112970
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    deactivating_status = {'ActiveState': 'deactivating'}
    active_status = {'ActiveState': 'active'}
    assert(is_deactivating_service(deactivating_status) == True)
    assert(is_deactivating_service(active_status) == False)


# Generated at 2022-06-20 22:51:07.876576
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('''blah blah
Apr 11 10:24:28 localhost.localdomain systemd: Job new-encoding.target/start ignored, unit new-encoding.target may be requested by dependency only.
Apr 11 10:24:28 localhost.localdomain systemd: Job encryption.target/start ignored, unit encryption.target may be requested by dependency only.''')

# Generated at 2022-06-20 22:51:18.748094
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    show = '''
        Id=basic.target
        Names=basic.target
    '''
    assert {} == parse_systemctl_show(show.split('\n'))


# Generated at 2022-06-20 22:51:30.275685
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # Unit test for function is_deactivating_service
    base_service_status = {
        "ActiveEnterTimestampMonotonic": "8135942",
        "ActiveState": "deactivating",
        "ActiveExitTimestampMonotonic": "0",
        "CPUAccounting": "no",
        "CPUSchedulingPolicy": "0",
        "CPUSchedulingPriority": "0",
        "CPUSchedulingResetOnFork": "no",
        "CanIsolate": "no",
        "ControlGroup": "/system.slice/crond.service",
        "ControlPID": "0",
        "CPUShares": "1024",
        "DefaultDependencies": "yes",
        "Delegate": "no",
    }

# Generated at 2022-06-20 22:51:40.178592
# Unit test for function main
def test_main():
    testcase = {
        "results": {
            "name": None,
            "enabled": False,
            "changed": False,
        },
        "state": "stopped",
        "enabled": False,
        "masked": False,
        "daemon_reload": False,
        "daemon_reexec": False,
        "scope": "system",
        "no_block": False,
        "unit": "test.service",
        "res_args": {
            "name": None,
            "enabled": False,
            "changed": False,
            "status": {
                "ActiveState": "unknown",
                "SubState": "unknown",
            }
        }
    }

# Generated at 2022-06-20 22:51:46.979601
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_running_service({'ActiveState': 'didfail'})
    assert not is_running_service({'ActiveState': 'failing'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:51:55.981623
# Unit test for function main
def test_main():
    args = dict(
        name='mysql',
        state='stopped',
        enabled=None,
        force=None,
        masked=None,
        daemon_reload=True,
        daemon_reexec=True,
    )
    res_args = dict(
        name='mysql',
        state='stopped',
        enabled=None,
        force=None,
        masked=None,
        daemon_reload=True,
        daemon_reexec=True,
    )
    results = dict(
        changed=False,
        status={
            "LoadState": "loaded",
            "ActiveState": "inactive",
            "SubState": "dead",
            "LoadError": "file not found"
        }
    )

# Generated at 2022-06-20 22:52:52.415629
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:52:57.578898
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) is True
    service_status = {'ActiveState': ''}
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-20 22:53:09.654795
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(
        ["Id=httpd.service",
         "Requires=sockets.target",
         "After=sockets.target"]) == {
            'Id': 'httpd.service',
            'After': 'sockets.target',
            'Requires': 'sockets.target',
        }
    assert parse_systemctl_show(
        ["Id=foo.service",
         "ExecStart={",
         "  do_foo",
         "}"]) == {
            'Id': 'foo.service',
            'ExecStart': 'do_foo',
        }

# Generated at 2022-06-20 22:53:13.426565
# Unit test for function is_running_service
def test_is_running_service():
    for state in ['inactive', 'failed']:
        assert not is_running_service({'ActiveState': state})
    for state in ['active', 'activating']:
        assert is_running_service({'ActiveState': state})



# Generated at 2022-06-20 22:53:19.681405
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status)

    service_status = {'ActiveState': 'activating'}
    assert is_running_service(service_status)

    service_status = {'ActiveState': 'deactivating'}
    assert not is_running_service(service_status)



# Generated at 2022-06-20 22:53:23.678080
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # setup
    service_status = {'ActiveState': 'deactivating'}
    # test
    assert is_deactivating_service(service_status)
    # teardown



# Generated at 2022-06-20 22:53:29.073319
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive', 'SubState': 'dead'}) is False
    assert is_running_service({'ActiveState': 'failed', 'SubState': 'dead'}) is False
    assert is_running_service({'ActiveState': 'active', 'SubState': 'dead'}) is True
# End of unit tests



# Generated at 2022-06-20 22:53:32.614322
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'not_deactivating'})
    assert not is_deactivating_service({'ActiveState': 'deactivating_and_stopped'})



# Generated at 2022-06-20 22:53:44.052004
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # test that we parse a single line output into a dict
    lines = ['ActiveState=active']
    assert parse_systemctl_show(lines) == dict(ActiveState='active')

    # test that we parse a multi-line output into a dict
    lines = ['ActiveState=active', 'ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT']
    assert parse_systemctl_show(lines) == dict(ActiveState='active', ActiveEnterTimestamp='Sun 2016-05-15 18:28:49 EDT')

    # test that we handle a long output values containing spaces and quotes

# Generated at 2022-06-20 22:53:46.997080
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'dead'}) is False
    assert is_deactivating_service({'ActiveState': 'active'}) is False

