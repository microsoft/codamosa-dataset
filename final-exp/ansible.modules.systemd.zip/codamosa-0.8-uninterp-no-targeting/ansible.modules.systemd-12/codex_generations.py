

# Generated at 2022-06-20 22:46:20.685520
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('= ignoring request')



# Generated at 2022-06-20 22:46:31.239151
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([
        'ActiveEnterTimestamp=Tue 2018-05-15 18:28:49 EDT',
        'Description=Command Scheduler',
        'ExecStart={',
        '  path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS',
        '}'
    ]) == {
        'ActiveEnterTimestamp': 'Tue 2018-05-15 18:28:49 EDT',
        'Description': 'Command Scheduler',
        'ExecStart': '{ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS }',
    }

# Generated at 2022-06-20 22:46:43.322766
# Unit test for function main

# Generated at 2022-06-20 22:46:50.024733
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # Tests for deactivating service
    assert is_deactivating_service({"ActiveState": "deactivating"})
    assert is_deactivating_service({"ActiveState": "deactivating"})
    assert not is_deactivating_service({"ActiveState": "inactive"})
    assert not is_deactivating_service({"ActiveState": "active"})
    assert not is_deactivating_service({"ActiveState": "activating"})



# Generated at 2022-06-20 22:47:01.743295
# Unit test for function main
def test_main():
    class AnsibleModule(object):
        def __init__(self):
            self.params = dict()
            self.result = dict()

        def fail_json(self, status, msg):
            pass

        def run_command(self, args, check_rc=False):
            return (0, "test output", "test error")

    def sysv_exists(unit):
        if 'name' in AnsibleModule.params and AnsibleModule.params['name'] == "":
            return False
        return True

    def sysv_is_enabled(unit):
        if 'enabled' in AnsibleModule.params and AnsibleModule.params['enabled'] == 'yes':
            return True
        return False


# Generated at 2022-06-20 22:47:04.919458
# Unit test for function is_running_service
def test_is_running_service():
    '''Test is_running_service'''
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:47:12.486061
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({"ActiveState": "active"})
    assert is_running_service({"ActiveState": "activating"})
    assert not is_running_service({"ActiveState": "inactive"})
    assert not is_running_service({"ActiveState": "failed"})
    assert not is_running_service({"ActiveState": "deactivating"})
    assert not is_running_service({"ActiveState": "unknown"})
    assert not is_running_service({})


# Generated at 2022-06-20 22:47:23.925653
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:47:30.955219
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    # Setup AnsibleModule

# Generated at 2022-06-20 22:47:37.266535
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'exited'})



# Generated at 2022-06-20 22:48:07.419161
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Failed to issue method call: Unit dbus.service not loaded.")
    assert not request_was_ignored("   Loaded: loaded (/etc/systemd/system/multi-user.target.wants/dbus.service; static; vendor preset: disabled)")



# Generated at 2022-06-20 22:48:17.966402
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:21.472162
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo=bar')
    assert not request_was_ignored('foo')



# Generated at 2022-06-20 22:48:27.685082
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    # !FIXME! this case has no clear answer
    assert is_running_service({'ActiveState': 'unknown'}) is True



# Generated at 2022-06-20 22:48:35.552861
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:46.720546
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def kv(key, value):
        return key + '=' + value

    def a(value):
        return '{' + value + '}'

    assert parse_systemctl_show([]) == {}
    assert parse_systemctl_show([kv('Key1', 'Value1')]) == {'Key1': 'Value1'}
    assert parse_systemctl_show([kv('Key1', 'Value1'), kv('Key2', 'Value2')]) == {'Key1': 'Value1', 'Key2': 'Value2'}
    assert parse_systemctl_show([kv('Key1', 'Value1'), '', kv('Key2', 'Value2')]) == {'Key1': 'Value1', 'Key2': 'Value2'}

# Generated at 2022-06-20 22:48:51.909379
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = ["'systemctl start httpd.service'",
           'ignoring command: httpd.service',
           "                   start: Job failed to start", '-- Reboot --']
    assert request_was_ignored(out)
# end unit test for request_was_ignored

#
# check if the status result contains a specific substring
#

# Generated at 2022-06-20 22:48:59.246817
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:49:03.268931
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({})



# Generated at 2022-06-20 22:49:07.938316
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # single line values
    lines = ['foo=bar', 'moo=boo']
    expected = {'foo': 'bar', 'moo': 'boo'}
    assert parse_systemctl_show(lines) == expected
    # multi line values
    lines = ['ExecStart={']
    expected = {'ExecStart': '{'}
    assert parse_systemctl_show(lines) == expected
    lines = ['ExecStart={', '  bar', '}']
    expected = {'ExecStart': '{' + '\n' + '  bar' + '\n' + '}'}
    assert parse_systemctl_show(lines) == expected
    # single line value starting with { is parsed as single line
    lines = ['foo={bar']
    expected = {'foo': '{bar'}
    assert parse

# Generated at 2022-06-20 22:49:46.795361
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    output = '''Id=foo.service
LoadState=loaded
ActiveState=active
SubState=running
Description=Foo Service
ExecStart={ path=/usr/bin/foo ; argv[]=/usr/bin/foo --foo ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'''

# Generated at 2022-06-20 22:49:51.393527
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command: start')
    assert request_was_ignored('ignoring request: start')
    assert not request_was_ignored('other output')
    assert not request_was_ignored('=' * 10)



# Generated at 2022-06-20 22:49:53.747754
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:50:02.809324
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    line1 = 'ActiveState=active'
    line2 = 'Description=Command Scheduler'
    line3 = '{ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'
    line4 = 'ExecReload={ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'
    line5 = 'StatusErrno=0'

# Generated at 2022-06-20 22:50:13.882030
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    from ansible.module_utils import basic

    # Ours
    from ansible.module_utils import systemd

    # Test initd
    os.environ['XDG_RUNTIME_DIR'] = '/run/user/0'  # Required for systemctl show to work

    temp_dir = tempfile.mkdtemp()
    filename = os.path.join(temp_dir, 'test.service')
    output = '''[Unit]
Description=Foo

[Service]
User=root
ExecStart=/usr/bin/true
'''


# Generated at 2022-06-20 22:50:16.460824
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict( {'ActiveState': 'deactivating'})) == True
    assert is_deactivating_service(dict( {'ActiveState': 'active'})) == False



# Generated at 2022-06-20 22:50:21.024954
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring command\n')
    assert not request_was_ignored('=')
    assert not request_was_ignored('request')



# Generated at 2022-06-20 22:50:29.360368
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['a=', 'b=hello', 'c={', 'world', '}', 'd={', 'abc', '}']) == {'a': '', 'b': 'hello', 'c': 'world', 'd': '{\\nabc\\n}'}
    assert parse_systemctl_show(['a=', 'b=hello', 'c={', 'world', 'def', '}', 'd={', 'abc', '}']) == {'a': '', 'b': 'hello', 'c': 'world\\ndef', 'd': '{\\nabc\\n}'}

# Generated at 2022-06-20 22:50:32.074348
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    unit = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(unit) is True



# Generated at 2022-06-20 22:50:37.010560
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:52:14.073186
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:52:25.191826
# Unit test for function request_was_ignored

# Generated at 2022-06-20 22:52:28.035011
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert (not is_deactivating_service({'ActiveState': 'failed'}))



# Generated at 2022-06-20 22:52:38.341930
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:52:51.411338
# Unit test for function request_was_ignored

# Generated at 2022-06-20 22:53:04.363276
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:53:06.662499
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:53:18.059328
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:53:23.914674
# Unit test for function is_running_service
def test_is_running_service():  # NOQA (covered by system tests)
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'unknown'})



# Generated at 2022-06-20 22:53:29.602008
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    print(is_running_service(service_status))
    assert(is_deactivating_service(service_status))
    service_status = {'ActiveState': 'A'}
    print(is_running_service(service_status))
    assert(not is_deactivating_service(service_status))
