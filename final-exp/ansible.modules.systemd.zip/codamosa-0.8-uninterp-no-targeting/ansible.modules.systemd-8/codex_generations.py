

# Generated at 2022-06-20 22:46:06.988662
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:46:08.621952
# Unit test for function main
def test_main():
    # Unit tests are fun!
    return True


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:46:15.131700
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('  Unit httpd.service failed to load: No such file or directory.')
    assert request_was_ignored('  Job for httpd.service failed. See "systemctl status httpd.service" and "journalctl -xe" for details.')
    assert not request_was_ignored('  httpd.service - The Apache HTTP Server')
    assert not request_was_ignored('     Active: failed (Result: exit-code) since Tue 2015-10-20 07:05:17 UTC; 2min 32s ago')


# ===========================================
# Module execution.
#


# Generated at 2022-06-20 22:46:27.154260
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Trivial test
    s = '''foo=bar'''
    assert parse_systemctl_show(s.split('\n')) == {'foo': 'bar'}

    # Test that Exec values are handled correctly
    s = '''foo=bar\nExec=baz\nExec2=qux\nExecRestart=/bin/true\nExecStart={/bin/false}\nExecStart=1\nExecStart=2\nExecStart=3\nExecStart=4\nExecStart=5\nExecStart=6\nExecStart=7\nExecStart=8\nExecStart=9\nExecStart=10\nExecStart=11\nExecStart=12\nExecStart=13\nExecStart=14\nExecStart=15\nExecStartPost=/bin/true'''  # NOQ

# Generated at 2022-06-20 22:46:38.525358
# Unit test for function main
def test_main():
    # unit test for making sure our parsing works
    test_output = dedent('''
    Unit foobar.service could not be found.
    ''')

    try:
        result = parse_systemctl_show(to_native(test_output).split('\n'))
        if result:
            assert False
    except:
        assert True

    test_output = dedent('''
    Description=Foobar
    LoadState=loaded
    ''')

    result = parse_systemctl_show(to_native(test_output).split('\n'))
    if 'Description' in result and 'LoadState' in result:
        assert True
    else:
        assert False


# Generated at 2022-06-20 22:46:41.899161
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to issue method call: Unit ismasked.service not found.')
    assert request_was_ignored('Failed to issue method call: Unit ismasked.service could not be found.')
    assert request_was_ignored('Failed to issue method call: Unit ismasked.service failed to load: No such file or directory. See system logs and \'systemctl status ismasked.service\' for details.')
    assert not request_was_ignored('masked')



# Generated at 2022-06-20 22:46:53.678402
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Failed to connect to bus: No such file or directory") == False
    assert request_was_ignored("Job failed. See system logs and 'systemctl status' for details.") == False
    assert request_was_ignored("= inactive dead ssh.service\n") == False
    assert request_was_ignored("= active running mysql.service") == False
    assert request_was_ignored("Failed to load environment file /run/systemd/user/dbus.service: No such file or directory") == False
    assert request_was_ignored("Job for dbus.service failed because the control process exited with error code") == False
    assert request_was_ignored("Executing: /usr/lib/systemd/systemd-sysv-install disable ssh") == True

# Generated at 2022-06-20 22:47:01.034482
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'unknown'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'reloading'}) is False



# Generated at 2022-06-20 22:47:09.672895
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'name': 'test_name',
        'scope': 'test_scope',
        'no_block': 'test_no_block',
        'state': 'test_state',
        'force': 'test_force',
        'masked': 'test_masked',
        'enabled': 'test_enabled',
        'daemon_reload': 'test_daemon_reload',
        'daemon_reexec': 'test_daemon_reexec'
    })

    # get_module() is too old to have the changed_when parameter
    module.run_command().changed_when = "test_changed"

# Generated at 2022-06-20 22:47:19.893515
# Unit test for function main

# Generated at 2022-06-20 22:47:36.686378
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-20 22:47:41.922465
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(out='= nothing') is False
    assert request_was_ignored(out='=   nothing') is False
    assert request_was_ignored(out='nothing') is False
    assert request_was_ignored(out='ignoring command') is True
    assert request_was_ignored(out='ignoring request') is True



# Generated at 2022-06-20 22:47:43.872349
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True



# Generated at 2022-06-20 22:47:48.498169
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'inactive', 'static': 'foo'})
    assert not is_deactivating_service({'ActiveState': 'active', 'static': 'foo'})
    assert not is_deactivating_service({'ActiveState': 'activating', 'static': 'foo'})
    assert is_deactivating_service({'ActiveState': 'deactivating', 'static': 'foo'})



# Generated at 2022-06-20 22:47:51.051187
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {
        'ActiveState': 'deactivating'
    }
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:47:58.207975
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # All keys should be strings
    assert all(isinstance(x, str) for x in list(parse_systemctl_show([
        'Description=Description line 1',
        'Description=Description line 2',
        'Description=Description line 3',
        'ExecStart={',
        '  ExecStart line 1',
        '  ExecStart line 2',
        '}',
        'ExecStop={',
        '  ExecStop line 1',
        '  ExecStop line 2',
        '}',
    ]).keys()))
    # Whitespace should be stripped from values

# Generated at 2022-06-20 22:48:03.455454
# Unit test for function main
def test_main():
    # Unit test for function main
    os.environ['XDG_RUNTIME_DIR'] = '/run/user/1000'
    sys.argv = ['/usr/bin/ansible-playbook', '-t', 'local', '-i', 'localhost,', 'test_main.yml']
    uode = SystemctlUnitState(module)
    uode.main()


# Generated at 2022-06-20 22:48:06.982715
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('random output')
    assert not request_was_ignored('random=output')
    assert not request_was_ignored('random ignoring=output')
    assert request_was_ignored('random ignoring request')
    assert request_w

# Generated at 2022-06-20 22:48:17.077251
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:28.941931
# Unit test for function main
def test_main():
    fail=False
    result={}
    out = ""
    params = {'daemon_reload': False, 'daemon_reexec': False, 'force': False, 'masked': True, 'enabled': False, 'name': 'foo', 'no_block': True, 'scope': 'system'}
    if out != "":
        if [out] == "":
            fail = True
        else:
            result['proposed'] = {}
            result['existing'] = {}
            result['end_state'] = {}


# Generated at 2022-06-20 22:49:09.666014
# Unit test for function main
def test_main():
    import sys
    import ansible_unittest

    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str'),
        state=dict(type='str'),
        enabled=dict(type='bool'),
        force=dict(type='bool'),
        masked=dict(type='bool'),
        daemon_reload=dict(type='bool'),
        daemon_reexec=dict(type='bool'),
        scope=dict(type='str', default='system', choices=['system', 'user', 'global']),
        no_block=dict(type='bool', default=False),
        ),
        supports_check_mode=True)
    unit = module.params['name']
    is_initd = sysv_exists(unit)
    is_systemd = False
    found = False

# Generated at 2022-06-20 22:49:17.728633
# Unit test for function is_running_service
def test_is_running_service():
    # Create a mock global variable
    global_vars = {'ansible_service_mgr': 'systemd'}
    assert not is_running_service({})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'not used state'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})


# Generated at 2022-06-20 22:49:19.462119
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:30.220583
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating', 'SubState': 'something-else'}
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str'),
            state=dict(type='str', default='started', choices=['started', 'stopped', 'reloaded', 'restarted']),
            enabled=dict(type='bool', default=False),
            masked=dict(type='bool', default=False),
            daemon_reload=dict(type='bool', default=False),
            force=dict(type='bool', default=False),
            no_block=dict(type='bool', default=False)
        ),
        supports_check_mode=True
    )
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:49:40.432908
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Unit display-manager.service could not be found, aborting.\n')
    assert request_was_ignored('= cat >> /etc/crontab << EOF\n')
    assert request_was_ignored('Test ignore request notification\n')
    assert request_was_ignored('= ignore request notification\n')
    assert request_was_ignored('= ignoring command notification\n')
    assert request_was_ignored('= ignoring request notification\n')
    assert request_was_ignored('= ignoring request notification\n')
    assert request_was_ignored('''=INVALID: /bin/systemctl start httpd.service
   Loaded: not-found (Reason: No such file or directory)
   Active: inactive (dead)
''')
    assert not request_was_ign

# Generated at 2022-06-20 22:49:44.423235
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'unknown'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False



# Generated at 2022-06-20 22:49:47.121247
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(service_status_running)
    assert not is_running_service(service_status_stopped)
    assert not is_running_service(service_status_disabled)
    assert not is_running_service(service_status_masked)


# Generated at 2022-06-20 22:49:51.109789
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivated'})



# Generated at 2022-06-20 22:49:58.218448
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='inactive', SubState='dead'))
    assert not is_running_service(dict(ActiveState='inactive', SubState='failed'))
    assert not is_running_service(dict(ActiveState='inactive', SubState=''))



# Generated at 2022-06-20 22:50:02.513496
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating', 'SubState': 'dead', 'LoadState': 'loaded'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:50:27.303704
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for mariadb.service failed because a timeout was exceeded.\nSee "systemctl status mariadb.service" and "journalctl -xe" for details.\n') is False
    assert request_was_ignored('Unit rabbitmq-server.service could not be found.\n') is False
    assert request_was_ignored('Unit rabbitmq-server.service could not be found.\nUnit rabbitmq-server.service could not be found.\n') is False
    assert request_was_ignored('Unit mariadb.service not loaded.\nmariadb.service could not be found.\n') is True
    assert request_was_ignored('Failed to issue method call: No such file or directory\n') is True

# Generated at 2022-06-20 22:50:29.290927
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:50:37.795762
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:39.955320
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = 'ignoring request'
    assert request_was_ignored(out)



# Generated at 2022-06-20 22:50:47.944459
# Unit test for function main

# Generated at 2022-06-20 22:50:59.276005
# Unit test for function main
def test_main():
    from ansible.module_utils.systemd import *
    import sys
    import re
    import doctest
    from ansible.module_utils._text import to_native
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    failed, tested = doctest.testmod()

    if failed == 0:
        print('%s' % ('All unit test results OK.'))
    else:
        print('%s' % ('Unit test results: %s of %s tests failed.') % (failed, tested))

    sys.exit(failed)


# Generated at 2022-06-20 22:51:08.145834
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:51:11.990780
# Unit test for function request_was_ignored
def test_request_was_ignored():
    tests = [
        ('=', False),
        ('ignoring request: foo', True),
        ('ignoring command', True),
        ('foo', False),
    ]
    for test, expected in tests:
        assert request_was_ignored(test) == expected, "Unexpected behavior for '%s'" % test



# Generated at 2022-06-20 22:51:18.787318
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_service = { 'ActiveState': 'deactivating' }
    assert is_deactivating_service(test_service) is True
    test_service['ActiveState'] = 'deactivating2'
    assert is_deactivating_service(test_service) is False
    test_service['ActiveState'] = 'deactivating'
    assert is_deactivating_service(test_service) is True



# Generated at 2022-06-20 22:51:23.455120
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-20 22:52:06.660712
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'unknown'})



# Generated at 2022-06-20 22:52:09.589843
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:52:20.504628
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:52:24.759068
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo=bar')
    assert not request_was_ignored('foo')



# Generated at 2022-06-20 22:52:35.743974
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Stopping target.\n')
    assert request_was_ignored('Stopping target...\n')
    assert request_was_ignored('Stopping target failed.\n')
    assert request_was_ignored('Failed to stop target.\n')
    assert request_was_ignored('Starting target.\n')
    assert request_was_ignored('Starting target...\n')
    assert request_was_ignored('Starting target failed.\n')
    assert request_was_ignored('Failed to start target.\n')
    assert request_was_ignored('Invalid command: ignoring request...\n')
    assert request_was_ignored('Invalid command: ignoring request.\n')
    assert request_was_ignored('Invalid command: ignoring request\n')
    assert request_

# Generated at 2022-06-20 22:52:38.101306
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False



# Generated at 2022-06-20 22:52:45.507101
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:52:57.154757
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import io

# Generated at 2022-06-20 22:52:58.719399
# Unit test for function request_was_ignored
def test_request_was_ignored():
    return request_was_ignored('Ignoring request')



# Generated at 2022-06-20 22:53:05.102328
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('= 1 running')
    assert not request_was_ignored('= 1 start')
    assert not request_was_ignored('Running, but request is ignored')
    assert not request_was_ignored('ignore')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')



# Generated at 2022-06-20 22:55:21.133530
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:55:25.804902
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'}) == True
    assert is_deactivating_service({'ActiveState': 'activating'}) == True
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True
    assert is_deactivating_service({'ActiveState': 'inactive'}) == False
    assert is_deactivating_service({'ActiveState': 'inactivating'}) == False
    assert is_deactivating_service({'ActiveState': 'unknown'}) == False
    assert is_deactivating_service({'ActiveState': 'failed'}) == False
    assert is_deactivating_service({'ActiveState': 'reloading'}) == False



# Generated at 2022-06-20 22:55:28.284476
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'not-deactivating'}) is False



# Generated at 2022-06-20 22:55:29.674766
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True



# Generated at 2022-06-20 22:55:31.434512
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:55:34.296128
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True
    assert is_deactivating_service({'ActiveState': 'active'}) == False

