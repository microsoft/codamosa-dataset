

# Generated at 2022-06-20 22:45:56.976436
# Unit test for function main

# Generated at 2022-06-20 22:46:01.054403
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:46:07.011971
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    (os.environ['ANSIBLE_STDOUT_CALLBACK'], os.environ['ANSIBLE_CALLBACK_WHITELIST']) = ('test','test')

# Generated at 2022-06-20 22:46:09.128327
# Unit test for function is_running_service
def test_is_running_service():
    service_status = dict(ActiveState='active')
    assert is_running_service(service_status)



# Generated at 2022-06-20 22:46:13.444176
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('some random output') is False
    assert request_was_ignored('= some random output') is False
    assert request_was_ignored('some random output ignoring command') is True
    assert request_was_ignored('some random output ignoring request') is True
    assert request_was_ignored('some random output\nsome other output ignoring request') is True



# Generated at 2022-06-20 22:46:15.298751
# Unit test for function main
def test_main():
    r = main() # returns result
    assert r['changed'] == True
    assert r['state'] == 'started'
    assert r['enabled'] == False
    

# Generated at 2022-06-20 22:46:19.021552
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-20 22:46:23.119595
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to set wall message, ignoring: Interactive authentication required.')
    assert request_was_ignored('Failed to issue method call: Interactive authentication required.')
    assert not request_was_ignored('Job for mysqld.service failed because the control process exited with error code.')



# Generated at 2022-06-20 22:46:28.436872
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'closing'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-20 22:46:40.040958
# Unit test for function main
def test_main():
    # test case for missing service
    unit_name = "test_unit"
    # load module with valid params

# Generated at 2022-06-20 22:46:58.697260
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))

    assert not is_running_service(dict(ActiveState='inactive'))
    assert not is_running_service(dict(ActiveState='deactivating'))
    assert not is_running_service(dict(ActiveState='failed'))



# Generated at 2022-06-20 22:47:07.592867
# Unit test for function main
def test_main():
    argument_spec = dict(
       name = dict(type = 'str', aliases = ['service', 'unit']),
       state = dict(type = 'str', choices = ['reloaded', 'restarted', 'started', 'stopped']),
       enabled = dict(type = 'bool'),
       force = dict(type = 'bool'),
       masked = dict(type = 'bool'),
       daemon_reload = dict(type = 'bool', default = False, aliases = ['daemon-reload']),
       daemon_reexec = dict(type = 'bool', default = False, aliases = ['daemon-reexec']),
       scope = dict(type = 'str', default = 'system', choices = ['system', 'user', 'global']),
       no_block = dict(type = 'bool', default = False),
    )
    required_

# Generated at 2022-06-20 22:47:16.650041
# Unit test for function is_running_service
def test_is_running_service():
    # if no ActiveState, it should return false
    assert not is_running_service({})
    # if ActiveState is active or activating, it should return true
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    # otherwise, return false
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'UNKNOWN'})



# Generated at 2022-06-20 22:47:25.502286
# Unit test for function main
def test_main():

    import random
    import requests
    import os
    import string
    import tempfile

    from ansible.module_utils.basic import *

    os.environ['SYSTEMD_OFFLINE'] = '1'


# Generated at 2022-06-20 22:47:31.242195
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for httpd.service failed because the control process exited with error code.\nSee "systemctl status httpd.service" and "journalctl -xe" for details.\n')
    assert not request_was_ignored(' Job for httpd.service failed because the control process exited with error code.\nSee "systemctl status httpd.service" and "journalctl -xe" for details.\n')



# Generated at 2022-06-20 22:47:34.616605
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:47:37.245291
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert not request_was_ignored("= active running")



# Generated at 2022-06-20 22:47:39.802926
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'unknown'})



# Generated at 2022-06-20 22:47:45.268318
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request, already active')
    assert not request_was_ignored('= not in output but it is')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('Ignoring request, already active "is-active"')



# Generated at 2022-06-20 22:47:57.816479
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Unit=foo.service']) == {'Unit': 'foo.service'}
    assert parse_systemctl_show(['After=foo.service']) == {'After': 'foo.service'}
    assert parse_systemctl_show(['ExecStart={ foo; }']) == {'ExecStart': '{ foo; }'}
    assert parse_systemctl_show(['ExecStart={', 'foo;', '}']) == {'ExecStart': '{\nfoo;\n}'}
    assert parse_systemctl_show(['ExecStart={', 'foo;', 'bar;', '}']) == {'ExecStart': '{\nfoo;\nbar;\n}'}

# Generated at 2022-06-20 22:48:30.630625
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({"ActiveState":"active"})
    assert is_running_service({"ActiveState":"activating"})
    assert not is_running_service({"ActiveState":"dead"})



# Generated at 2022-06-20 22:48:37.865270
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = dict()
    service_status = dict()
    service_status['ActiveState'] = 'deactivating'
    assert is_deactivating_service(service_status)
    service_status['ActiveState'] = 'activating'
    assert not is_deactivating_service(service_status)
    service_status['ActiveState'] = 'active'
    assert not is_deactivating_service(service_status)
    service_status['ActiveState'] = 'inactive'
    assert not is_deactivating_service(service_status)
    service_status['ActiveState'] = 'anything else'
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-20 22:48:40.484911
# Unit test for function is_running_service
def test_is_running_service():
    status = dict(
        ActiveState='active',
        MainPID=42,
    )
    assert is_running_service(status)

    status['ActiveState'] = 'activating'
    assert is_running_service(status)

    status['ActiveState'] = 'deactivating'
    assert not is_running_service(status)

    status['ActiveState'] = 'failed'
    assert not is_running_service(status)



# Generated at 2022-06-20 22:48:43.647609
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('= ignoring command')
    assert not request_was_ignored('= a non-ignored command')
    assert not request_was_ignored('some random string')



# Generated at 2022-06-20 22:48:53.819245
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:57.573510
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Description=foo',
        'ExecStart={',
        '    Command 1',
        '    Command 2',
        '}'
    ]
    parsed = parse_systemctl_show(lines)
    assert parsed == {
        'Description': 'foo',
        'ExecStart': '{\n    Command 1\n    Command 2\n}'
    }



# Generated at 2022-06-20 22:49:01.421352
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)
    service_status = {'ActiveState': 'inactive'}
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-20 22:49:10.743426
# Unit test for function is_running_service

# Generated at 2022-06-20 22:49:23.705705
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    from io import StringIO
    from tempfile import TemporaryFile
    import sys

    def run_test(test_input, expected_output):
        with TemporaryFile('w+') as fp:
            fp.write(test_input)
            fp.flush()
            fp.seek(0)
            output = parse_systemctl_show(fp)
        if output != expected_output:
            raise AssertionError('{0}\n!=\n{1}'.format(output, expected_output))
    run_test('foo=bar', {'foo': 'bar'})
    run_test('foo=bar\nx=y', {'foo': 'bar', 'x': 'y'})

# Generated at 2022-06-20 22:49:27.028526
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('a= b=')



# Generated at 2022-06-20 22:50:09.286883
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'exited'})



# Generated at 2022-06-20 22:50:17.946908
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('Ignoring command')
    assert request_was_ignored('Ignoring request')
    assert request_was_ignored('   Ignoring command    ')
    assert not request_was_ignored("ignore command")
    assert not request_was_ignored("ignore request")
    assert not request_was_ignored("ignore")
    assert not request_was_ignored("ignore me")
    assert not request_was_ignored("foo")
    assert not request_was_ignored("foo\nbar")
    assert not request_was_ignored("ignoring\nfoo")
    assert not request_was_ignored("foo\nignoring")
    assert not request_was_ign

# Generated at 2022-06-20 22:50:19.718973
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})


# Generated at 2022-06-20 22:50:28.498757
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:32.435258
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('= foo')
    assert not request_was_ignored('Loaded: foo')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')



# Generated at 2022-06-20 22:50:42.786239
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:49.255391
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {}
    assert not is_deactivating_service(service_status)
    service_status['ActiveState'] = 'active'
    assert not is_deactivating_service(service_status)
    service_status['ActiveState'] = 'activating'
    assert not is_deactivating_service(service_status)
    service_status['ActiveState'] = 'deactivating'
    assert is_deactivating_service(service_status)
    service_status['ActiveState'] = 'inactive'
    assert not is_deactivating_service(service_status)
    service_status['ActiveState'] = 'failed'
    assert not is_deactivating_service(service_status)


# Generated at 2022-06-20 22:50:56.338152
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service( {'ActiveState': 'active'} )
    assert not is_deactivating_service( {'ActiveState': 'activating'} )
    assert not is_deactivating_service( {'ActiveState': ''} )
    assert not is_deactivating_service( {'ActiveState': 'deactive'} )
    assert is_deactivating_service( {'ActiveState': 'deactivating'} )



# Generated at 2022-06-20 22:51:06.228990
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:51:06.763633
# Unit test for function main
def test_main():
    return

main()

# Generated at 2022-06-20 22:52:14.813611
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('\n   Loaded: loaded')
    assert request_was_ignored('   Loaded: loaded\n   ActiveState: inactive (dead)')
    assert request_was_ignored('\n   Loaded: loaded\n   ActiveState: active\n   CGroup:\n     ')
    assert request_was_ignored('\n   Loaded: loaded\n   ActiveState: active\n   CGroup:\n     ')
    assert request_was_ignored('\n   Ignore Command: ignored')
    assert request_was_ignored('\n   Ignore Request: ignored')
    assert not request_was_ignored('\n   Loaded: loaded\n   ActiveState: active\n   CGroup:\n     ')
    assert request_was_ignored('\n   Ignore Command: ignored')

# Generated at 2022-06-20 22:52:26.197818
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # The keys/values below were taken from the output of 'systemctl show systemd-journald.service'.
    lines = [
        'Type=notify',
        'NotifyAccess=main',
        'LimitNOFILE=65536',
        'LimitNPROC=64000',
        'LimitCORE=infinity',
        'TasksMax=infinity',
        'TimeoutStartSec=0s',
        'TimeoutStopSec=0s',
        'RuntimeMaxSec=infinity',
        'WatchdogSec=0s',
        'Restart=no',
        'RestartSec=100ms',
        'StartLimitInterval=50000',
        'StartLimitBurst=10',
        'StartLimitAction=none',
    ]
    parsed = parse_systemctl_show(lines)

# Generated at 2022-06-20 22:52:36.752510
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    module_args={}

# Generated at 2022-06-20 22:52:38.349014
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:52:51.516902
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:53:04.455527
# Unit test for function main
def test_main():
    print("Running test for function 'main'")

    # Load the parameters from YML
    with open('test.yml', 'r') as input_stream:
        params = yaml.safe_load(input_stream)

    # Load the output from YML
    with open('test_output.yml', 'r') as output_stream:
        output = yaml.safe_load(output_stream)
        print("output: " + str(output))

    # Test with parameters defined in YML
    if params:
        module = AnsibleModule(argument_spec=params['argument_spec'], supports_check_mode=True)
        if params['fail']:
            with pytest.raises(AnsibleFailJson):
                main()
        else:
            result = main()

# Generated at 2022-06-20 22:53:12.286040
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_data_1 = '''
Description=File System Check Daemon
Documentation=man:fsck(8) man:systemd-fsckd.service(8)
Documentation=http://www.freedesktop.org/wiki/Software/systemd/fsckd
DefaultDependencies=no
After=systemd-sysusers.service systemd-tmpfiles-setup.service
Wants=systemd-sysusers.service systemd-tmpfiles-setup.service
Requires=systemd-journald.socket
Before=shutdown.target
'''.split('\n')

# Generated at 2022-06-20 22:53:24.730808
# Unit test for function main

# Generated at 2022-06-20 22:53:33.863515
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:53:44.365941
# Unit test for function main
def test_main():
    from ansible.module_utils.systemd import systemd
    import pytest