

# Generated at 2022-06-20 22:46:16.056839
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:46:20.317078
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('ignored')



# Generated at 2022-06-20 22:46:25.026703
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-20 22:46:27.892258
# Unit test for function main
def test_main():
    assert main() is None

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:46:31.371376
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('= ignoring command')
    assert not request_was_ignored('= not ignored')
    assert not request_was_ignored('not ignoring request')



# Generated at 2022-06-20 22:46:43.373435
# Unit test for function main
def test_main():
    test_args = {
        "name": "avahi-daemon",
        "state": "started",
        "enabled": True,
        "scope": "system"
    }


# Generated at 2022-06-20 22:46:47.157755
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True



# Generated at 2022-06-20 22:46:53.246916
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test1 = [
        'Description=A line with no equal sign',
        'Other=A line with a single-line value',
        'ExecStart=Foo { bar { baz { quux { quuux',
        '  one two three four five six seven eight nine ten',
        '  eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty',
        '  thirty forty fifty sixty seventy eighty ninety one hundred',
        '  }}}}}',
        'ExecStop=Bar',
    ]

# Generated at 2022-06-20 22:46:55.447125
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    deactivating_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(deactivating_status)



# Generated at 2022-06-20 22:46:57.757483
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:47:19.054333
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('= foo')



# Generated at 2022-06-20 22:47:27.599815
# Unit test for function main
def test_main():
    # Initialize test environment
    sys.path.insert(0, os.path.dirname(__file__))
    import test_utils
    test_env = test_utils.TestAnsibleModule()

    unit = "foobar"
    module = test_env.create_ansible_module([unit, 'state=stopped'])
    (rc, out, err) = module.run_command("systemctl list-unit-files '%s*'" % unit)
    is_systemd = unit in out
    module.run_command = lambda *_: (0, '', '')
    if is_systemd:
        module.run_command = lambda *_: (1, '', '')

    from ansible.module_utils.basic import AnsibleFallbackNotFound

    module.warn = lambda *_: None
   

# Generated at 2022-06-20 22:47:33.569563
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'other'})



# Generated at 2022-06-20 22:47:41.793313
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    res = parse_systemctl_show(['hey=there'])
    assert res == { 'hey': 'there' }

    res = parse_systemctl_show(['hey={\nthere\n}\n'])
    assert res == { 'hey': '{\nthere\n}' }

    res = parse_systemctl_show(['hey={\nthere\n'])
    assert res == { 'hey': '{\nthere' }

    res = parse_systemctl_show(['hey={\nthere\n}\nhi=bye\n'])
    assert res == { 'hey': '{\nthere\n}', 'hi': 'bye' }

    res = parse_systemctl_show(['hey={\nthere\n'])
    assert res == { 'hey': '{\nthere' }

    res = parse

# Generated at 2022-06-20 22:47:49.445828
# Unit test for function is_running_service
def test_is_running_service():
    test_service_status = {'ActiveState': 'active'}
    assert is_running_service(test_service_status) is True
    test_service_status = {'ActiveState': 'activating'}
    assert is_running_service(test_service_status) is True
    test_service_status = {'ActiveState': 'inactive'}
    assert is_running_service(test_service_status) is False
    test_service_status = {'ActiveState': 'deactivating'}
    assert is_running_service(test_service_status) is False
    test_service_status = {'ActiveState': 'unknown'}
    assert is_running_service(test_service_status) is False



# Generated at 2022-06-20 22:47:52.256302
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = dict(ActiveState='deactivating')
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:47:54.107988
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:04.548929
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['ExecStart=', '    /bin/true', 'Hello=', '  world']) == {
            'ExecStart': '/bin/true',
            'Hello': 'world',
        }
    assert parse_systemctl_show(['ExecStart=', '    /bin/true', 'Description={', '  This is an example.', '}']) == {
            'ExecStart': '/bin/true',
            'Description': 'This is an example.',
        }
    assert parse_systemctl_show(['ExecStart=', '    {', '      /bin/true', '    }']) == {
            'ExecStart': '/bin/true',
        }

# Generated at 2022-06-20 22:48:12.423442
# Unit test for function main
def test_main():
    # open the example test file
    with open('/home/matt/Programming/JARVICE/playbook/units/unit_test_file_main.txt') as f:
        results = f.readlines()
    num_lines = 0
    for i, line in enumerate(results):
        if i == 0:
            num_lines = int(line)


# Generated at 2022-06-20 22:48:18.843883
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import systemd
    from ansible_collections.ansible.misc.tests.unit.modules.utils import AnsibleExitJson, set_module_args
    os.environ['XDG_RUNTIME_DIR'] = '/run/user/%s' % os.geteuid() # Add XDG_RUNTIME_DIR

# Generated at 2022-06-20 22:48:42.228442
# Unit test for function main
def test_main():

    # TODO:add for main()
    pass

# Standard call to the main function.
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:45.187005
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('foo ignoring request') is True
    assert request_was_ignored('foo ignoring command') is True
    # This can be improved
    assert request_was_ignored('foo = ignoring request') is False
    assert request_was_ignored('foo = bar') is False



# Generated at 2022-06-20 22:48:48.776683
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('=')
    assert not request_was_ignored('abcdef=')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('some more text ignoring command')



# Generated at 2022-06-20 22:48:54.342057
# Unit test for function is_running_service
def test_is_running_service():
    assert(is_running_service({'ActiveState': 'inactive'}) == False)
    assert(is_running_service({'ActiveState': 'active'}) == True)
    assert(is_running_service({'ActiveState': 'activating'}) == True)
    assert(is_running_service({'ActiveState': 'deactivating'}) == False)
    assert(is_running_service({'ActiveState': 'unknown'}) == False)


# Generated at 2022-06-20 22:48:57.359701
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('xyz ignoring request')
    assert not request_was_ignored('xyz ignoring command')



# Generated at 2022-06-20 22:48:59.899421
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:49:09.890485
# Unit test for function main
def test_main():
    """ Unit tests for systemctl module, the main unit test for the module. """
    # Dummy module
    module = DummyModule()

    # Dummy arguments
    arg1 = {"name": None}
    arg2 = {"name": "foobar"}
    arg3 = {"name": "my-units.target", "enabled": True, "state": "reloaded"}

    # Test in checkmode, unit not found
    result = systemctl(module, arg1)
    assert result["changed"] is False
    assert result["failed"] is False

    # Test in checkmode, unit is found, not enabled, status is unknown
    result = systemctl(module, arg2)
    assert result["changed"] is False
    assert result["failed"] is False
    assert result["status"]["LoadState"] == "not-found"

    # Test in

# Generated at 2022-06-20 22:49:12.502782
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {
        'ActiveState': 'deactivating'
    }
    assert is_deactivating_service(service_status) is True

# Generated at 2022-06-20 22:49:19.268696
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Unit ssh.service could not be found.')
    assert request_was_ignored('Ignoring command.')
    assert not request_was_ignored('Loaded: loaded (/usr/lib/systemd/system/httpd.service; enabled; vendor preset: disabled)')  # NOQA



# Generated at 2022-06-20 22:49:21.971844
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo = bar')



# Generated at 2022-06-20 22:49:50.048370
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:00.773684
# Unit test for function main
def test_main():
    '''Unit test for main'''
    #return {"changed": False,
    #        "enabled": False,
    #        "rc": 0,
    #        "result": {"name": "foo",
    #                    "status": {"ActiveState": "inactive",
    #                                "After": "syslog.target",
    #                                "Before": "remote-fs.target",
    #                                "SubState": "exited"}},
    #        "state": "stopped"}


# Generated at 2022-06-20 22:50:04.200397
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') == True
    assert request_was_ignored('ignoring command') == True
    assert request_was_ignored('=') == False



# Generated at 2022-06-20 22:50:09.404473
# Unit test for function is_running_service
def test_is_running_service():
    status = {'ActiveState': 'inactive'}
    assert not is_running_service(status)
    status = {'ActiveState': 'active'}
    assert is_running_service(status)
    status = {'ActiveState': 'activating'}
    assert is_running_service(status)



# Generated at 2022-06-20 22:50:15.127096
# Unit test for function is_running_service
def test_is_running_service():
    service_status = dict(ActiveState='active')
    assert is_running_service(service_status) == True
    service_status = dict(ActiveState='inactive')
    assert is_running_service(service_status) == False
    service_status = dict(ActiveState='activating')
    assert is_running_service(service_status) == True
    service_status = dict(ActiveState='deactivating')
    assert is_running_service(service_status) == False


# Generated at 2022-06-20 22:50:25.076943
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test function that assumes multi-line values when it sees '{'
    def parse_systemctl_show_broken(lines):
        parsed = {}
        multival = []
        k = None
        for line in lines:
            if k is None:
                if '=' in line:
                    k, v = line.split('=', 1)
                    if v.lstrip().startswith('{'):
                        if not v.rstrip().endswith('}'):
                            multival.append(v)
                            continue
                    parsed[k] = v.strip()
                    k = None
            else:
                multival.append(line)
                if line.rstrip().endswith('}'):
                    parsed[k] = '\n'.join(multival).strip()
                    multival = []

# Generated at 2022-06-20 22:50:35.290600
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    from copy import deepcopy
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-20 22:50:39.815060
# Unit test for function main

# Generated at 2022-06-20 22:50:47.854125
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # pylint: disable=undefined-variable
    assert parse_systemctl_show([
        'Test=foo',
        'ExecStart={\n    test',
        'foo',
        'bar\n}',
    ]) == {'Test': 'foo', 'ExecStart': '{\n    test\nfoo\nbar\n}'}
    assert parse_systemctl_show([
        'Test=foo',
        'ExecStart={ test',
        'foo',
        'bar }',
    ]) == {'Test': 'foo', 'ExecStart': '{ test\nfoo\nbar }'}

# Generated at 2022-06-20 22:50:59.178985
# Unit test for function main

# Generated at 2022-06-20 22:51:20.829543
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-20 22:51:30.962907
# Unit test for function main
def test_main():
    testobj = Systemctl()
    testobj.unit = 'grafana-server'
    testobj.state = 'started'
    testobj.enabled = 'True'
    testobj.masked = 'False'
    testobj.force = 'False'
    testobj.daemon_reload = 'True'
    testobj.daemon_reexec = 'True'
    testobj.scope = 'system'
    testobj.no_block = 'False'
    testobj.run_command('systemctl start testobj.unit')
    testobj.run_command('systemctl daemon-reload')
    testobj.run_command('systemctl daemon-reexec')
    testobj.run_command('systemctl is-enabled testobj.unit')

# Generated at 2022-06-20 22:51:40.894701
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:51:50.032550
# Unit test for function is_running_service
def test_is_running_service():
    try:
        assert is_running_service({'ActiveState': 'active'})
        assert is_running_service({'ActiveState': 'activating'})
        assert not is_running_service({'ActiveState': 'inactive'})
        assert not is_running_service({'ActiveState': 'deactivating'})
        assert not is_running_service({'ActiveState': 'failed'})
        assert not is_running_service({'ActiveState': 'activating'})
    except:
        print("Failed test_is_running_service")
assert is_running_service({'ActiveState': 'active'})


# Generated at 2022-06-20 22:51:57.629491
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', aliases=['service', 'unit']),
            state=dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped']),
            enabled=dict(type='bool'),
            force=dict(type='bool'),
            masked=dict(type='bool'),
            daemon_reload=dict(type='bool', default=False, aliases=['daemon-reload']),
            daemon_reexec=dict(type='bool', default=False, aliases=['daemon-reexec']),
            scope=dict(type='str', default='system', choices=['system', 'user', 'global']),
            no_block=dict(type='bool', default=False),
        ),
    )


# Generated at 2022-06-20 22:51:59.829828
# Unit test for function main
def test_main():
    main()

#pylint: disable=redefined-builtin, unused-wildcard-import, wildcard-import, locally-disabled
# import module snippets.  This are required
from ansible.module_utils.basic import *

main()

# Generated at 2022-06-20 22:52:08.941256
# Unit test for function is_running_service

# Generated at 2022-06-20 22:52:16.636541
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Ignoring request to reload unit syslog.service.")
    assert not request_was_ignored("Failed to connect to bus: No such file or directory")
    assert not request_was_ignored("Running in chroot, ignoring request.")
    assert not request_was_ignored("A non-empty environment must be provided to reload.")
    assert not request_was_ignored("Job for systemd-logind.service failed. See 'systemctl status systemd-logind.service' and 'journalctl -xn' for details.")



# Generated at 2022-06-20 22:52:26.916354
# Unit test for function main
def test_main():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    args = dict(
        name='test',
        state='present'
    )

    result = dict(
        name='test',
        state='present'
    )

    set_module_args(args)

    try:
        with warnings.catch_warnings(record=True) as w:
            main()
    except AnsibleExitJson as e:
        result = e.args[0]
    except AnsibleFailJson as e:
        result = e.args[0]
    assert result['name'] == 'test'
    assert result['state'] == 'present'


# Generated at 2022-06-20 22:52:37.363191
# Unit test for function main

# Generated at 2022-06-20 22:53:18.437850
# Unit test for function main

# Generated at 2022-06-20 22:53:22.680439
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:53:32.650299
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:53:44.051254
# Unit test for function main
def test_main():
    '''
    Some basic tests for the main routine
    '''
    from ansible_collections.niftyreg.systemd.tests.unit.compat import unittest
    from ansible_collections.niftyreg.systemd.tests.unit.compat.mock import patch, Mock, MagicMock

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)


# Generated at 2022-06-20 22:53:45.512787
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:53:55.048780
# Unit test for function is_deactivating_service

# Generated at 2022-06-20 22:54:04.481452
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    single_line = "Description=Custom Unit\n"
    multi_line = "ExecStart='\nthis\nis\na\nmultiline\nstring\n'\n"
    mixed_line = "ExecStart='\nthis\nis\na\nmultiline\nstring\n}\n"
    exec_start_with_no_multiline_value = "ExecStart='{this is a multiline value that is actually a single liner}'\n"

    output = parse_systemctl_show(single_line)
    assert output == {'Description': 'Custom Unit'}, 'single line did not turn out as expected: %s' % output

    output = parse_systemctl_show(multi_line)

# Generated at 2022-06-20 22:54:05.918122
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')



# Generated at 2022-06-20 22:54:13.931768
# Unit test for function main
def test_main():
    """ mock command calls to systemctl
        (init scripts not tested)
    """
    class MockModule(object):
        """ mock class to contain mock objects,
            ansible module api calls
        """
        def __init__(self):
            self.params = {}
            self.exit_json = self.call_exit_json

        def fail_json(self, **kargs):
            """ fail the module """
            self.exception = kargs['msg']

        def call_exit_json(self, **kargs):
            """ exit """
            self.exit_args = kargs
            self.exit_args['failed'] = False

        def get_bin_path(self, arg, required):
            """ test our own arg instead of lookup """
            return arg
    #########################
    # simple test
    #########################
   

# Generated at 2022-06-20 22:54:20.112570
# Unit test for function is_running_service
def test_is_running_service():
    def _is_running_service(output, assert_values):
        service_status = dict()
        for line in output.split('\n'):
            if '=' in line:
                key_value = line.strip().split('=', 1)
                if len(key_value) >= 2:
                    service_status[key_value[0]] = key_value[1]
        for state in assert_values:
            if state == 'running':
                assert(is_running_service(service_status))
            elif state == 'not running':
                assert(not is_running_service(service_status))
    # systemctl show systemd-journald.service
    _is_running_service("""
LoadState=loaded
ActiveState=active
SubState=running
UnitFileState=enabled
""", ['running'])
