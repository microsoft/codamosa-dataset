

# Generated at 2022-06-20 22:46:21.011564
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'activating'}) is False
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    assert is_deactivating_service({'ActiveState': 'invalid'}) is False



# Generated at 2022-06-20 22:46:31.687371
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    if 'Description=_' != parse_systemctl_show(['Description=_']):
        raise AssertionError()
    if 'ExecStart={}' != parse_systemctl_show(['ExecStart={']):
        raise AssertionError()
    if 'ExecStart={}' != parse_systemctl_show(['ExecStart={', '}']):
        raise AssertionError()
    if 'ExecStart={}' != parse_systemctl_show(['ExecStart={', '}']):
        raise AssertionError()
    if 'ExecStart={}' != parse_systemctl_show(['ExecStart={', 'stuff before}']):
        raise AssertionError()
    if 'ExecStart={}' != parse_systemctl_show(['ExecStart={', 'stuff after}']):
        raise AssertionError

# Generated at 2022-06-20 22:46:37.936402
# Unit test for function is_running_service
def test_is_running_service():
    service1 = {'ActiveState': 'active', 'SubState': 'running'}
    service2 = {'ActiveState': 'activating', 'SubState': 'running'}
    assert is_running_service(service1) == True
    assert is_running_service(service2) == True



# Generated at 2022-06-20 22:46:42.916405
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # from ansible.module_utils.pycompat24 import get_exception
    # from ansible.module_utils.six.moves import StringIO

    # put your test code here inside the try/except
    # catch the exception and show it to the user

# Generated at 2022-06-20 22:46:46.030872
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-20 22:46:48.865513
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')



# Generated at 2022-06-20 22:46:54.938812
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:46:59.203893
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:47:03.122226
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-20 22:47:10.399713
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert not is_deactivating_service({'ActiveState': 'failed'})



# Generated at 2022-06-20 22:47:41.660914
# Unit test for function main
def test_main():
    assert main('foo@1.mount') == "foo@1.mount"
    assert main('foo@\x01.mount') == ''
    assert main('foo.mount') == "foo.mount"
    assert main('foo\x01.mount') == ''


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:46.170796
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False



# Generated at 2022-06-20 22:47:58.505759
# Unit test for function main
def test_main():
    try:
       import json
    except ImportError:
       import simplejson as json
    _module = AnsibleModule({})
    # use /bin/bash as systemctl binary
    _module.get_bin_path = lambda x,y : "/bin/bash"
    # use /bin/echo as systemctl binary
    _module.run_command = lambda x,y : (0, "", "")
    try:
        # can systemctl be executed ?
        main()
        # if we get here systemctl can be executed, but we need to check output?
    except Exception as e:
        assert isinstance(e,AnsibleFailJson)
        assert "You need systemd to run this module" in str(e)


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:08.222270
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:18.589348
# Unit test for function main
def test_main():
    source = '''
name: test
state: started
'''
    module_args = dict(name='test')

# Generated at 2022-06-20 22:48:30.120550
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({
        "ActiveState": "active",
        "SubState": "running",
    }) is True
    assert is_running_service({
        "ActiveState": "active",
        "SubState": "listening",
    }) is True
    assert is_running_service({
        "ActiveState": "active",
        "SubState": "exited",
    }) is False
    assert is_running_service({
        "ActiveState": "activating",
        "SubState": "running",
    }) is True
    assert is_running_service({
        "ActiveState": "activating",
        "SubState": "listening",
    }) is True
    assert is_running_service({
        "ActiveState": "activating",
        "SubState": "exited",
    }) is False


# Generated at 2022-06-20 22:48:39.262581
# Unit test for function main

# Generated at 2022-06-20 22:48:41.891217
# Unit test for function is_running_service
def test_is_running_service():
    assert(not is_running_service({'ActiveState': 'deactivating'}))
    assert(not is_running_service({'ActiveState': 'inactive'}))
    assert(is_running_service({'ActiveState': 'activating'}))
    assert(is_running_service({'ActiveState': 'active'}))



# Generated at 2022-06-20 22:48:44.370692
# Unit test for function is_running_service
def test_is_running_service():
    service_status = dict(
        SubState = 'running',
        ActiveState = 'active',
        Result = 'success'
    )
    assert is_running_service(service_status)


# Generated at 2022-06-20 22:48:48.971600
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'not running'})


# Generated at 2022-06-20 22:49:50.322091
# Unit test for function is_running_service
def test_is_running_service():
    running = {'ActiveState': 'active'}
    assert is_running_service(running)
    activating = {'ActiveState': 'activating'}
    assert is_running_service(activating)


# Generated at 2022-06-20 22:50:00.919083
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:12.409800
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 22:50:18.750829
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True
    assert is_deactivating_service({'ActiveState': 'active'}) == False
    assert is_deactivating_service({'ActiveState': 'activating'}) == False
    assert is_deactivating_service({'ActiveState': 'inactive'}) == False
    assert is_deactivating_service({'ActiveState': 'failed'}) == False
    assert is_deactivating_service({'ActiveState': 'other'}) == False
    assert is_deactivating_service({'ActiveState': '123'}) == False



# Generated at 2022-06-20 22:50:21.729069
# Unit test for function main
def test_main():
    run_ansible_module(['-m', 'systemd', '-a', 'enabled=True', '-a', 'state=stopped'], 'test_systemd_module.py')

# Generated at 2022-06-20 22:50:25.481182
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    for state in set(['inactive', 'activating']):
        assert is_deactivating_service({'ActiveState': state}) is False



# Generated at 2022-06-20 22:50:27.742239
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({}) is False



# Generated at 2022-06-20 22:50:29.767578
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status={"ActiveState":'deactivating'}
    assert is_deactivating_service(status)



# Generated at 2022-06-20 22:50:38.077254
# Unit test for function main

# Generated at 2022-06-20 22:50:46.916838
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a single line value is parsed correctly
    result = parse_systemctl_show(['Description=A single line value'])
    assert result == {'Description': 'A single line value'}

    # Test that a single line value gets parsed correctly even if it starts with {
    result = parse_systemctl_show(['Description={A single line value that starts with {'])
    assert result == {'Description': '{A single line value that starts with {'}

    # Test that a multi-line value gets parsed correctly
    result = parse_systemctl_show(['ExecStart={', '  path=/usr/sbin/crond; argv[]=/usr/sbin/crond -n $CRONDARGS', '}'])

# Generated at 2022-06-20 22:52:08.248796
# Unit test for function main

# Generated at 2022-06-20 22:52:12.255061
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert not request_was_ignored("something=foo")


# Generated at 2022-06-20 22:52:16.771269
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert(is_deactivating_service({'ActiveState': 'deactivating'})) is True
    assert(is_deactivating_service({'ActiveState': 'active'})) is False
    assert(is_deactivating_service({'ActiveState': 'activating'})) is False



# Generated at 2022-06-20 22:52:28.177074
# Unit test for function main
def test_main():
    # Get parameters
    name = 'httpd'
    state = 'reloaded'
    enabled = True
    force = False
    masked = False
    daemon_reload = False
    daemon_reexec = False
    scope = 'system'
    no_block = False


# Generated at 2022-06-20 22:52:34.231811
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({})



# Generated at 2022-06-20 22:52:36.369323
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({ 'ActiveState': 'active' }) is True
    assert is_running_service({ 'ActiveState': 'activating' }) is True
    assert is_running_service({ 'ActiveState': 'exited' }) is False



# Generated at 2022-06-20 22:52:40.023115
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating')) is True
    assert is_deactivating_service(dict(ActiveState='dead')) is False



# Generated at 2022-06-20 22:52:51.930702
# Unit test for function main

# Generated at 2022-06-20 22:53:04.966287
# Unit test for function main
def test_main():
    import datetime
    import inspect
    import os
    import pipes
    import pytest
    import re
    import subprocess
    import sys
    import tempfile
    import time

    # set default options as test values should not be "real"

# Generated at 2022-06-20 22:53:16.291059
# Unit test for function main
def test_main():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    class ModuleStub(object):
        def __init__(self, *args, **kwargs):
            self.params = kw

# Generated at 2022-06-20 22:54:37.894435
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict({"ActiveState": "deactivating"}))
    assert not is_deactivating_service(dict({"ActiveState": "active"}))
    assert not is_deactivating_service(dict({"ActiveState": "inactive"}))



# Generated at 2022-06-20 22:54:45.103360
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Failed to start unit.service: Unit not found\n")
    assert not request_was_ignored("Job for unit.service failed.\n")
    assert not request_was_ignored("Loaded: loaded (/usr/lib/systemd/system/unit.service; enabled)\n")
    assert not request_was_ignored("Unit unit.service is masked.\n")
    assert request_was_ignored("Warning: Stopping unit, but it can still be activated by: unit.servi...")



# Generated at 2022-06-20 22:54:53.709419
# Unit test for function main
def test_main():
    import sys
    import tempfile
    import textwrap

    # Create a temporary systemd directory
    systemd_dir = tempfile.TemporaryDirectory()
    systemd_dir.name += '/systemd'
    os.makedirs(systemd_dir.name)
    os.environ['XDG_RUNTIME_DIR'] = '/run/user/1000000'

    # Create a temporary system directory
    system_dir = tempfile.TemporaryDirectory()
    system_dir.name += '/systemd'
    os.makedirs(system_dir.name)
    os.environ['XDG_RUNTIME_DIR'] = '/run/user/1000000'

    # Create an executable shell script

# Generated at 2022-06-20 22:54:58.686349
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # A single-line value that starts with {
    lines = [
        'Description=Some random service',
        'ExecStart={ path=/usr/bin/foo ; argv[]=/usr/bin/foo -b /etc/foo.conf -a }',
        'ExecStop=bar',
    ]
    parsed = parse_systemctl_show(lines)
    assert parsed == {
        'Description': 'Some random service',
        'ExecStart': '{ path=/usr/bin/foo ; argv[]=/usr/bin/foo -b /etc/foo.conf -a }',
        'ExecStop': 'bar',
    }
    # A multi-line value

# Generated at 2022-06-20 22:55:03.711908
# Unit test for function request_was_ignored
def test_request_was_ignored():
    failed_out = 'some error that would fail the module\n'
    assert request_was_ignored(failed_out) is False
    ignored_out = 'Job for xxx.service failed because the control process exited with error code.\n'
    assert request_was_ignored(ignored_out) is True



# Generated at 2022-06-20 22:55:13.051135
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:55:15.580288
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:55:21.073094
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Id=sshd.service']) == {'Id': 'sshd.service'}
    assert parse_systemctl_show(['Id=sshd.service', 'SyslogFacility=daemon']) == {'Id': 'sshd.service', 'SyslogFacility': 'daemon'}
    assert parse_systemctl_show(['Id=sshd.service', 'SyslogFacility=daemon', '']) == {'Id': 'sshd.service', 'SyslogFacility': 'daemon'}

# Generated at 2022-06-20 22:55:29.539218
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:55:36.874876
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)
    service_status = {'ActiveState': 'active'}
    assert not is_deactivating_service(service_status)
    service_status = {'ActiveState': 'inactive'}
    assert not is_deactivating_service(service_status)
    service_status = {'ActiveState': 'failed'}
    assert not is_deactivating_service(service_status)
    service_status = {'ActiveState': 'activating'}
    assert not is_deactivating_service(service_status)
    service_status = {'ActiveState': 'activating'}
    assert not is_deactivating_service(service_status)
