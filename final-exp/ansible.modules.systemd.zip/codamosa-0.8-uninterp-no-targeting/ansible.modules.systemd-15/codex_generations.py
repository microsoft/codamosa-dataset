

# Generated at 2022-06-20 22:46:27.994896
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:46:39.384122
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test for multiline value
    lines = ['ExecStart=/usr/sbin/httpd $OPTIONS -DFOREGROUND',
             '{',
             'path=/bin/bash',
             'argv[]=/bin/echo test',
             'ignore_errors=no',
             'start_time=[n/a]',
             'stop_time=[n/a]',
             'pid=0',
             'code=(null)',
             'status=0/0',
             '}']
    parsed = parse_systemctl_show(lines)
    assert 'ExecStart' in parsed
    assert parsed['ExecStart'] == '\n'.join(lines[0:7]).strip()

    # Test for normal value
    lines = ['UnitFileState=enabled']
    parsed = parse_systemctl_show(lines)

# Generated at 2022-06-20 22:46:48.313964
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_data = [
        'TestKey=TestValue',
        'TestKey2=TestValue2',
        'MultilineKey={\nline1\nline2\nline3\n}',
        'NoEqualsSign',
        'InvalidMultilineKey={\nline1\nline2\nline3'
    ]
    parsed = parse_systemctl_show(test_data)

    assert parsed['TestKey'] == 'TestValue'
    assert parsed['TestKey2'] == 'TestValue2'
    assert parsed['MultilineKey'] == '{\nline1\nline2\nline3\n}'
    assert parsed['NoEqualsSign'] == ''
    assert not 'InvalidMultilineKey' in parsed


# Generated at 2022-06-20 22:46:51.519133
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-20 22:47:03.163664
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', aliases=['service', 'unit']),
            state=dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped']),
            enabled=dict(type='bool'),
            force=dict(type='bool'),
            masked=dict(type='bool'),
            daemon_reload=dict(type='bool', aliases=['daemon-reload']),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled', 'masked', 'daemon_reload']],
        required_by=dict(
            state=('name', ),
            enabled=('name', ),
            masked=('name', ),
        ),
    )


# Generated at 2022-06-20 22:47:07.569916
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert not request_was_ignored("=]")
    assert not request_was_ignored("")



# Generated at 2022-06-20 22:47:12.430714
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-20 22:47:21.748886
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('foo') == False
    assert request_was_ignored('foo=bar') == False
    assert request_was_ignored('foo=bar baz=biz') == False
    assert request_was_ignored('foo=bar=baz') == False
    assert request_was_ignored('  foo  ') == False
    assert request_was_ignored('ignoring request of foo') == True
    assert request_was_ignored('ignoring command of foo') == True
    assert request_was_ignored('ignoring command of foo=') == True
    assert request_was_ignored('ignoring command of foo=bar') == True
    assert request_was_ignored('ignoring request of foo=bar') == True



# Generated at 2022-06-20 22:47:29.479432
# Unit test for function main
def test_main():
    try:
        import ansible
        from ansible.module_utils.systemd import *
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        raise ImportError(
            'ansible is required for this unit test.'
        )


# Generated at 2022-06-20 22:47:32.040430
# Unit test for function is_running_service
def test_is_running_service():
    service_status = '''
    ActiveState = active
    ActiveState = activating
    '''
    assert is_running_service(service_status)



# Generated at 2022-06-20 22:47:59.386222
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a multi-line value is consumed properly
    lines = ['Key=value', 'Key={\nline1\nline2\n}']
    parsed = parse_systemctl_show(lines)
    if parsed['Key'] != '{\nline1\nline2\n}':
        raise AssertionError('Test with multi-line value failed')

    # Test that a single-line value is consumed properly
    lines = ['Key=value']
    parsed = parse_systemctl_show(lines)
    if parsed['Key'] != 'value':
        raise AssertionError('Test with single-line value failed')

    # Test that a single-line value with leading whitespace is consumed properly
    lines = ['Key= \t value']
    parsed = parse_systemctl_show(lines)

# Generated at 2022-06-20 22:48:08.824135
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:10.477259
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:48:14.220858
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('=') is False
    assert request_was_ignored('x') is False



# Generated at 2022-06-20 22:48:18.283863
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-20 22:48:20.988701
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert not request_was_ignored("= not in out")



# Generated at 2022-06-20 22:48:28.274239
# Unit test for function is_running_service
def test_is_running_service():
    test_cases = {
        'active': True,
        'activating': True,
        'inactive': False,
        'deactivating': False,
        'failed': False,
    }
    for test_state, result_state in test_cases.items():
        test_status = {
            'ActiveState': test_state,
        }
        assert result_state == is_running_service(test_status)



# Generated at 2022-06-20 22:48:31.375717
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'inactive'}) == False


# Generated at 2022-06-20 22:48:38.981841
# Unit test for function main
def test_main():
    test_dict = dict(
        name=dict(type='str', aliases=['service', 'unit']),
        state=dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped']),
        enabled=dict(type='bool'),
        force=dict(type='bool'),
        masked=dict(type='bool'),
        daemon_reload=dict(type='bool', default=False, aliases=['daemon-reload']),
        daemon_reexec=dict(type='bool', default=False, aliases=['daemon-reexec']),
        scope=dict(type='str', default='system', choices=['system', 'user', 'global']),
        no_block=dict(type='bool', default=False),
    )

# Generated at 2022-06-20 22:48:49.155672
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        "Description=test service",
        "ExecStart={ path=/usr/bin/cat ; argv[]=/usr/bin/cat ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }",
        "ExecStartPost={ path=/usr/bin/tail ; argv[]=/usr/bin/tail -f /var/log/messages ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
    ]

# Generated at 2022-06-20 22:49:23.396443
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True



# Generated at 2022-06-20 22:49:32.909301
# Unit test for function main
def test_main():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-20 22:49:44.438436
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:49:45.977593
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating'))



# Generated at 2022-06-20 22:49:48.738018
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_output = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(test_output) == True


# Generated at 2022-06-20 22:49:57.351421
# Unit test for function is_running_service
def test_is_running_service():
    '''
    Test is_running_service function
    '''
    running_service_status = {'ActiveState': 'active'}
    assert is_running_service(running_service_status)

    not_running_service_status = {'ActiveState': 'deactivating'}
    assert not is_running_service(not_running_service_status)

    failing_service_status = {'ActiveState': 'failed'}
    assert not is_running_service(failing_service_status)



# Generated at 2022-06-20 22:50:01.525425
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    is_deactivating_service_data = {
        'ActiveState': 'deactivating',
    }
    assert is_deactivating_service(is_deactivating_service_data) is True



# Generated at 2022-06-20 22:50:12.855397
# Unit test for function request_was_ignored

# Generated at 2022-06-20 22:50:16.500984
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({"ActiveState":"active"}) == True
    assert is_running_service({"ActiveState":"activating"}) == True
    assert is_running_service({"ActiveState":"notrunning"}) == False
    assert is_running_service({"ActiveState":""}) == False


# Generated at 2022-06-20 22:50:19.120842
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_data = {
        'ActiveState': 'deactivating',
    }
    assert is_deactivating_service(test_data)



# Generated at 2022-06-20 22:51:32.467280
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    sample_return = {u'unitfilestate': u'runtime', u'active': False, u'Description': u'',
                     u'LoadState': u'loaded', u'SubState': u'running', u'Id': u'crond.service',
                     u'ActiveState': u'deactivating'}
    assert is_deactivating_service(sample_return) is True



# Generated at 2022-06-20 22:51:34.859616
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) is True



# Generated at 2022-06-20 22:51:37.061302
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {
        'ActiveState': 'inactive',
    }
    assert is_running_service(service_status) == False



# Generated at 2022-06-20 22:51:47.958953
# Unit test for function main

# Generated at 2022-06-20 22:51:50.694643
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {}
    service_status['ActiveState'] = 'deactivating'
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:51:58.026550
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    data = '''[Unit]
Description=Command Scheduler
Documentation=man:cron(8) man:crontab(5) man:cron.d(5)
After=auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice
Before=shutdown.target multi-user.target
Conflicts=shutdown.target

[Service]
Type=notify
EnvironmentFile=-/etc/sysconfig/crond
Environment=SYSTEMD_LOG_LEVEL=warning
ExecStart=/usr/sbin/crond -n $CRONDARGS
ExecReload=/bin/kill -HUP $MAINPID
PrivateTmp=true

[Install]
WantedBy=multi-user.target
Alias=cron.service
'''
    expected

# Generated at 2022-06-20 22:52:04.541915
# Unit test for function main
def test_main():
    """This function unit tests main function"""
    def raw_value(v):
        if v is None:
            return v
        return "%d" % v

    # initialize

# Generated at 2022-06-20 22:52:15.152494
# Unit test for function main
def test_main():
    '''
    Test function main
    :return:
    '''
    # See https://github.com/pytest-dev/pytest/issues/1526

# Generated at 2022-06-20 22:52:19.038450
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:52:22.054209
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'unknown'})



# Generated at 2022-06-20 22:54:35.841429
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Single line value
    assert parse_systemctl_show(['Description=test']) == {'Description': 'test'}
    # Multi-line value
    assert parse_systemctl_show(['ExecStart=\n{ test\n}']) == {'ExecStart': 'test'}
    # Multi-line value, with more than one = per line
    assert parse_systemctl_show(['ExecStart=\n{ test=1\n}']) == {'ExecStart': 'test=1'}
    # Multi-line value, with additional single-line value
    assert parse_systemctl_show(['ExecStart=\n{ test\n}', 'test=test']) == {'ExecStart': 'test', 'test': 'test'}
    # Single line value with = in value
    assert parse_systemctl_show

# Generated at 2022-06-20 22:54:39.434452
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='deactivating'))
    assert not is_running_service(dict(ActiveState='failed'))
    assert not is_running_service(dict(ActiveState='reloading'))
    assert not is_running_service(dict(ActiveState='inactive'))



# Generated at 2022-06-20 22:54:48.024327
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:54:50.612445
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False



# Generated at 2022-06-20 22:54:58.073398
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:55:05.494545
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for foo.service canceled.\n')
    assert request_was_ignored('Job appears to have been already running: foo.service.\n')
    assert not request_was_ignored('foo.service\n   Loaded: loaded (/usr/lib/systemd/system/foo.service; enabled) Active: active (running) since Sun 2016-05\n     Docs: man:foo(8)\n           http://foo.org/docs/\n')



# Generated at 2022-06-20 22:55:09.642433
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(test_status)
    test_status = {'ActiveState': 'foo'}
    assert not is_deactivating_service(test_status)


# Generated at 2022-06-20 22:55:16.920434
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_data = \
'''
Description=Foo Service
After=network.target
Before=shutdown.target
Documentation=man:fooservice(8)
Conflicts=shutdown.target
ConditionResult=yes
StartLimitInterval=0
StartLimitBurst=0
Type=simple
Restart=always
RestartSec=10
TimeoutSec=0
IgnoreOnIsolate=no
#Uncomment to override the ExecStart setting
#ExecStart=
ExecStart={ path=/usr/bin/foo-daemon ; argv[]=/usr/bin/foo-daemon ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
'''

# Generated at 2022-06-20 22:55:27.129511
# Unit test for function main

# Generated at 2022-06-20 22:55:34.309143
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # If a request was ignored by systemd,
    #  '=' is not present in output
    # and the output contains either of 'ignoring request' or 'ignoring command'
    out = "Failed with result 'signal'"
    assert request_was_ignored(out) is False

    out = "Failed with result 'exit-code'"
    assert request_was_ignored(out) is False

    out = "Job for sshd.service failed because a timeout was exceeded."
    assert request_was_ignored(out) is False

    out = "Ignored request"
    assert request_was_ignored(out) is True

    out = "Ignoring command"
    assert request_was_ignored(out) is True
