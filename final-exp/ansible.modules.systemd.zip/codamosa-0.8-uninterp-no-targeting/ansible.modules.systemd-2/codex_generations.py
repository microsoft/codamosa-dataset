

# Generated at 2022-06-20 22:46:21.769675
# Unit test for function is_running_service

# Generated at 2022-06-20 22:46:26.078917
# Unit test for function main
def test_main():
    module = AnsibleModule(dict())
    module.warn = lambda x: None
    module.exit_json = lambda **kwargs: None
    module.run_command = lambda x, **kwargs: (0, '', '')
    module.params = {'name': 'foo', 'state': None, 'enabled': None, 'masked': None, 'daemon_reload': False, 'scope': 'system'}
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:46:37.348991
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Ignoring request to reload foo.service (unit foo.service not loaded).")
    assert request_was_ignored("Ignoring command stop (unit foo.service is masked).")
    assert request_was_ignored("Ignoring command start (unit foo.service is masked).")
    assert request_was_ignored("Ignoring command restart (unit foo.service is masked).")
    assert request_was_ignored("Ignoring command reload (unit foo.service is masked).")
    assert request_was_ignored("Ignoring command reload-or-restart (unit foo.service is masked).")
    assert request_was_ignored("Ignoring command try-reload-or-restart (unit foo.service is masked).")

# Generated at 2022-06-20 22:46:42.337343
# Unit test for function main

# Generated at 2022-06-20 22:46:45.635970
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) is True


# Generated at 2022-06-20 22:46:49.312700
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState="deactivating"))
    assert not is_deactivating_service(dict(ActiveState="active"))
    assert not is_deactivating_service(dict(ActiveState="inactive"))



# Generated at 2022-06-20 22:46:54.735413
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:47:06.201807
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.shell import CliRunner
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        f.write(
            b"#!/bin/bash\n"
            b"echo 'ActiveState=active'\n"
        )
        f.flush()
        runner = CliRunner()
        runner.invoke(
            systemctl_module.main,
            [
                '-m', 'systemd',
                '-a',
                'name=foobar',
                'scope=system',
            ])
    assert runner.exception is None
    assert runner.result.exception is None

# Generated at 2022-06-20 22:47:17.452071
# Unit test for function main
def test_main():
    # Create a temp directory to work in
    test_dir = tempfile.mkdtemp()

    # This is the output of systemctl show on a RHEL 7 system.

# Generated at 2022-06-20 22:47:22.817724
# Unit test for function is_running_service
def test_is_running_service():
    service_inactive = {
        'ActiveState': 'inactive'
    }
    assert(is_running_service(service_inactive) is False)

    service_active = {
        'ActiveState': 'active'
    }
    assert(is_running_service(service_active) is True)

    service_activating = {
        'ActiveState': 'activating'
    }
    assert(is_running_service(service_activating) is True)



# Generated at 2022-06-20 22:47:53.475251
# Unit test for function main
def test_main():
    unit_test_main(module_args)

if __name__ == "__main__":
    main()

# Generated at 2022-06-20 22:48:04.092250
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:09.836381
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_status = dict()

    # Test 1: active service
    test_status['ActiveState'] = 'active'
    assert not is_deactivating_service(test_status)

    # Test 2: deactivating service
    test_status['ActiveState'] = 'deactivating'
    assert is_deactivating_service(test_status)

    # Test 3: inactive service
    test_status['ActiveState'] = 'inactive'
    assert not is_deactivating_service(test_status)



# Generated at 2022-06-20 22:48:20.511507
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    output1 = [
        'Id=busybox-udhcpc.service',
        'Description=busybox udhcpc service',
        'Documentation=man:udhcpc(8)',
        'LoadState=loaded',
        'ActiveState=inactive',
        'SubState=dead',
        'UnitFileState=disabled',
        'Result=na'
    ]
    # Multiple key/values on line does not span multiple lines

# Generated at 2022-06-20 22:48:31.759745
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:33.268801
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-20 22:48:35.890313
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(service_status_running)
    assert not is_running_service(service_status_exited)
    assert is_running_service(service_status_auto_restarting)



# Generated at 2022-06-20 22:48:47.029033
# Unit test for function main
def test_main():
    # tests currently require systemd to be running
    if not is_systemd():
        raise SkipTest 
    service = 'sshd'

# Generated at 2022-06-20 22:48:56.887267
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:49:02.427940
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    values = [
        'Unit=top.service',
        'Description=Multi-User System',
        'Documentation=man: systemd.special(7)',
        'DefaultDependencies=no',
        'Requires=sysinit.target',
        'After=sysinit.target',
        'Conflicts=shutdown.target',
    ]
    result = parse_systemctl_show(values)
    assert result == {
        'Unit': 'top.service',
        'Description': 'Multi-User System',
        'Documentation': 'man: systemd.special(7)',
        'DefaultDependencies': 'no',
        'Requires': 'sysinit.target',
        'After': 'sysinit.target',
        'Conflicts': 'shutdown.target'
    }

# Generated at 2022-06-20 22:49:34.091930
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status = dict(
        ActiveState='deactivating'
    )
    assert is_deactivating_service(status) is True



# Generated at 2022-06-20 22:49:45.385230
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['A=B{',
                                 'C',
                                 '}',
                                 'D=E']) == {'D': 'E', 'A': 'B{' + '\n' + 'C' + '\n' + '}'}
    assert parse_systemctl_show(['A=B{',
                                 'C',
                                 '}',
                                 'D=E{',
                                 'F',
                                 '}']) == {'D': 'E{' + '\n' + 'F' + '\n' + '}',
                                           'A': 'B{' + '\n' + 'C' + '\n' + '}'}



# Generated at 2022-06-20 22:49:54.716399
# Unit test for function main
def test_main():
    unit = None
    result = {
        'changed': False,
        'name': 'unit',
        'status': {
            'ActiveState': 'active',
            'Description': 'unit',
            'ExecMainPID': '3',
            'ExecMainStartTimestamp': 'Sat 2018-04-28 18:44:39 UTC',
            'ExecMainStatus': 'running',
        }
    }

# Generated at 2022-06-20 22:49:57.266712
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('SomeJunk\n=\n=') is False
    assert request_was_ignored('SomeJunk\n=\n=\n\n ignored request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('=\n=\n=\n\n') is False



# Generated at 2022-06-20 22:50:02.294664
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('=') is False
    assert request_was_ignored('some other stuff') is False



# Generated at 2022-06-20 22:50:07.709245
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out1 = 'Request directive ignored'
    out2 = 'Command directive ignored'
    out3 = 'Running command: /bin/systemctl daemon-reload'
    assert request_was_ignored(out1)
    assert request_was_ignored(out2)
    assert not request_was_ignored(out3)



# Generated at 2022-06-20 22:50:15.464752
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:23.394416
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = 'ignoring request'
    assert request_was_ignored(out) is True, '`ignoring request` is ignored by request_was_ignored'
    out = 'ignoring command'
    assert request_was_ignored(out) is True, '`ignoring command` is ignored by request_was_ignored'
    out = '='
    assert request_was_ignored(out) is False, '`=` should not be ignored by request_was_ignored as it is from systemctl'



# Generated at 2022-06-20 22:50:26.135405
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:50:32.076016
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for foo.service ignored.')
    assert request_was_ignored('Job for foo.service failed because a timeout was exceeded. See "systemctl status foo.service" and "journalctl -xe" for details.')  # NOQA
    assert not request_was_ignored('foo.service start operation timed out. Terminating.')  # NOQA



# Generated at 2022-06-20 22:51:23.657900
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    actual = parse_systemctl_show([
        'ExecStart={ path=/usr/bin/foo ; argv[]=/usr/bin/foo --bar',
        ' --baz=1 ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a]',
        ' ; pid=0 ; code=(null) ; status=0/0 }',
        'Description=A description that spans',
        '  multiple lines',
        'Foo=Bar'
    ])

# Generated at 2022-06-20 22:51:32.096080
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import os
    myenv = os.environ.copy()
    myenv["LANG"] = "C"
    myenv["LC_ALL"] = "C"
    myenv["LC_MESSAGES"] = "C"
    myenv["LC_CTYPE"] = "C"
    import subprocess
    from ansible.module_utils.six import b
    output = subprocess.check_output(['systemctl', 'show', '--no-page', 'crond.service'], env=myenv)
    lines = output.split(b('\n'))
    parsed = parse_systemctl_show(lines)
    assert parsed['Type'] == 'simple'



# Generated at 2022-06-20 22:51:37.873971
# Unit test for function is_running_service
def test_is_running_service():
    res = dict()
    res['ActiveState'] = "active"
    assert is_running_service(res) == True
    res['ActiveState'] = "activating"
    assert is_running_service(res) == True
    res['ActiveState'] = "deactivating"
    assert is_running_service(res) == False
    res['ActiveState'] = "inactive"
    assert is_running_service(res) == False


# Generated at 2022-06-20 22:51:43.927715
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating')) is True
    assert is_deactivating_service(dict(ActiveState='active')) is False
    assert is_deactivating_service(dict(ActiveState='inactive')) is False
    assert is_deactivating_service(dict(ActiveState='activating')) is False
    assert is_deactivating_service(dict(ActiveState='notstarted')) is False



# Generated at 2022-06-20 22:51:50.946077
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('bla ignoring request bla bla')
    assert request_was_ignored('bla ignoring command bla bla')
    assert not request_was_ignored('=')
    assert not request_was_ignored('bla command bla bla')
    assert not request_was_ignored('bla ignoring command bla bla bla bla =')



# Generated at 2022-06-20 22:51:55.916230
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'failed-restart'})


# Generated at 2022-06-20 22:51:57.881727
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:52:04.386681
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Foo=bar\n']) == {'Foo': 'bar'}
    assert parse_systemctl_show(['Foo={bar\n']) == {'Foo': '{bar'}
    assert parse_systemctl_show(['Foo=bar\n', 'biz\n']) == {'Foo': 'bar\nbiz'}
    assert parse_systemctl_show(['Foo=bar\n', 'biz\n', '}\n']) == {'Foo': 'bar\nbiz'}
    assert parse_systemctl_show(['ExecFoo=bar\n', 'biz\n', '}\n']) == {'ExecFoo': 'bar\nbiz'}

# Generated at 2022-06-20 22:52:09.106072
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('Ignoring request')
    assert request_was_ignored('foo ignoring request bar')
    assert not request_was_ignored('foo = bar')
    assert not request_was_ignored('foo ignoring command bar')
    assert not request_was_ignored('foo')



# Generated at 2022-06-20 22:52:14.077263
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState':'active'})
    assert is_running_service({'ActiveState':'activating'})
    assert not is_running_service({'ActiveState':'inactive'})
    assert not is_running_service({'ActiveState':'foo'})



# Generated at 2022-06-20 22:52:45.425523
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'deactivating'}) == False



# Generated at 2022-06-20 22:52:50.863545
# Unit test for function request_was_ignored
def test_request_was_ignored():
    from ansible.module_utils._text import to_native

    assert request_was_ignored("i am a teapot") is False
    assert request_was_ignored("blah blah systemctl: '=b' is not installed") is False
    assert request_was_ignored("blah blah ignoring request") is True
    assert request_was_ignored("blah blah ignoring command") is True



# Generated at 2022-06-20 22:52:54.700968
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:08.134005
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Id=systemd-hostnamed.service',
        'Names=systemd-hostnamed.service',
        'Requires=basic.target',
        'After=basic.target',
        'Wants=system.slice',
        'Conflicts=shutdown.target',
        'Before=shutdown.target',
        'Documentation=man:systemd-hostnamed.service(8)',
        'Description=Hostname Service',
        'ExecStart={ path=/lib/systemd/systemd-hostnamed ; argv[]=/lib/systemd/systemd-hostnamed --cache=net ; ignore_errors=no ; start_time=n/a ; stop_time=n/a ; pid=0 ; code=(null) ; status=0/0 }'
    ]

# Generated at 2022-06-20 22:53:13.643237
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-20 22:53:23.107534
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert not is_deactivating_service({'ActiveState': 'failed'})
    assert not is_deactivating_service({'ActiveState': 'unknown'})
    assert not is_deactivating_service({'ActiveState': ''})



# Generated at 2022-06-20 22:53:24.888627
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:34.001814
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:53:38.853778
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:53:47.820899
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    mv = ['{ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a]',
          ' stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }']
    pars = parse_systemctl_show([
        'Id=crond.service',
        'Wants=system.slice',
        'ExecStart=%s' % mv[0],
        '%s' % mv[1],
        'Description=Command Scheduler',
        'UnitFileState=enabled'])
    assert len(pars) == 4
    assert pars['Id'] == 'crond.service'
    assert pars['Wants'] == 'system.slice'

# Generated at 2022-06-20 22:54:44.384313
# Unit test for function main
def test_main():
    args = {
        'daemon_reload': False,
        'daemon_reexec': False,
        'enabled': None,
        'masked': None,
        'name': None,
        'no_block': False,
        'scope': 'system',
        'state': None
    }
    mock_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    main(mock_module, args)


# Generated at 2022-06-20 22:54:46.284020
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})


# Generated at 2022-06-20 22:54:54.963774
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Unit network.service not loaded.") is True
    assert request_was_ignored("Job network.service/stop-post failed with result 'dependency'.") is True
    assert request_was_ignored("Job network.service/stop-post failed with result 'dependency'.\n") is True
    assert request_was_ignored("Job network.service/stop-post failed with result 'dependency'."
                               " Job network.service/stop-post failed with result 'dependency'.") is True
    assert request_was_ignored("Job network.service/stop-post failed...") is False
    assert request_was_ignored("Job network.service/stop-post failed") is False
    assert request_was_ignored("Job network.service/stop-post failed\n") is False
    assert request_was_

# Generated at 2022-06-20 22:54:57.269820
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True # in set
    assert is_running_service({'ActiveState': 'activating'}) is True # in set
    assert is_running_service({'ActiveState': 'unknown'}) is False # not in set



# Generated at 2022-06-20 22:55:00.357976
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-20 22:55:11.146184
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:55:18.100231
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:55:24.859885
# Unit test for function is_running_service
def test_is_running_service():
    false_returns = [{'ActiveState': 'inactive'},
                     {'ActiveState': 'failed'},
                     {'ActiveState': 'deactivating'}]

    for false_return in false_returns:
        assert is_running_service(false_return) is False

    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True



# Generated at 2022-06-20 22:55:32.313538
# Unit test for function is_running_service
def test_is_running_service():
    # Test active case
    assert is_running_service({'ActiveState': 'active'})
    # Test case where systemd isn't done activating
    assert is_running_service({'ActiveState': 'activating'})
    # Test inactive case
    assert not is_running_service({'ActiveState': 'inactive'})
    # Test unknown case
    assert not is_running_service({'ActiveState': 'unknown'})
    # Test deactivating case
    assert not is_running_service({'ActiveState': 'deactivating'})
    # Test failed case
    assert not is_running_service({'ActiveState': 'failed'})
    # Test unknown case
    assert not is_running_service({'ActiveState': 'blah'})

