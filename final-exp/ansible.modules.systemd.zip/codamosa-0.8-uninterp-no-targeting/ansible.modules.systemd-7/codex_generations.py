

# Generated at 2022-06-20 22:46:07.649298
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('= not ignored')



# Generated at 2022-06-20 22:46:11.084893
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status = {'ActiveState': 'deactivating'}
    assert(is_deactivating_service(status) == True)
    status = {'ActiveState': 'inactive'}
    assert(is_deactivating_service(status) == False)



# Generated at 2022-06-20 22:46:20.172934
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Single-line value
    testcase = ['foo=bar']
    assert parse_systemctl_show(testcase) == {'foo': 'bar'}
    # Multi-line value
    testcase = ['ExecStart={\n    line1\n    line2\n}']
    assert parse_systemctl_show(testcase) == {'ExecStart': '{\n    line1\n    line2\n}'}
    # values that start with " but don't end with "
    testcase = ['Description="foo']
    assert parse_systemctl_show(testcase) == {'Description': '"foo'}
    # Another single-line value
    testcase = ['ExecReload={\n    line1\n    line2\n}']

# Generated at 2022-06-20 22:46:26.643031
# Unit test for function is_running_service
def test_is_running_service():
    module = AnsibleModule(argument_spec={})
    assert is_running_service({"ActiveState": "active"})
    assert is_running_service({"ActiveState": "activating"})
    assert not is_running_service({"ActiveState": "inactive"})
    assert not is_running_service({"ActiveState": "unexisted"})
    assert not is_running_service({"ActiveState": "None"})
    assert not is_running_service({})


# Generated at 2022-06-20 22:46:32.993082
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status_active = dict(
        ActiveState="active",
    )
    assert is_deactivating_service(status_active) is False

    status_activating = dict(
        ActiveState="activating",
    )
    assert is_deactivating_service(status_activating) is False

    status_deactivating = dict(
        ActiveState="deactivating",
    )
    assert is_deactivating_service(status_deactivating) is True



# Generated at 2022-06-20 22:46:44.871944
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:46:48.074241
# Unit test for function request_was_ignored
def test_request_was_ignored():
    for ignored in ['ignoring request', '= ignoring request', 'ignoring command', '= ignoring command']:
        assert request_was_ignored(ignored)

    assert not request_was_ignored('foo')


# Generated at 2022-06-20 22:46:51.285137
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson) as exc:
        module = ansible.modules.system.systemd.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:02.948208
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('''
Job failed. See system logs and 'systemctl status example.service' for details.
''') is False
    assert request_was_ignored('''
Job for example.service failed because the control process exited with error code. See "systemctl status example.service" and "journalctl -xe" for details.
''') is False
    assert request_was_ignored('''
Job for example.service failed.
See "systemctl status example.service" and "journalctl -xe" for details.
''') is False
    assert request_was_ignored('''
Unit example.service not found.
''') is False
    assert request_was_ignored('''
Ignoring unknown unit example.service.
''') is True

# Generated at 2022-06-20 22:47:06.888595
# Unit test for function request_was_ignored
def test_request_was_ignored():
    tests = [
        ('=', False),
        ('=foo', False),
        ('foo=', True),
        ('foo=bar', False),
        ('ignoring request', True),
        ('ignoring request=foo', True),
        ('ignoring command', True),
        ('ignoring command=foo', True),
    ]

    for (test, expected) in tests:
        assert request_was_ignored(test) == expected, test



# Generated at 2022-06-20 22:47:23.618506
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"})
    assert not is_deactivating_service({"ActiveState": "invalid"})
    assert not is_deactivating_service({"ActiveState": "inactive"})
    assert not is_deactivating_service({"ActiveState": "failed"})



# Generated at 2022-06-20 22:47:27.824592
# Unit test for function request_was_ignored
def test_request_was_ignored():
    """ Unit test for request_was_ignored function """
    assert request_was_ignored('ignoring request') == True
    assert request_was_ignored('ignoring command') == True
    assert request_was_ignored('=pending') == False



# Generated at 2022-06-20 22:47:31.129862
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({
        'ActiveState': 'deactivating'
    })
    assert not is_deactivating_service({
        'ActiveState': 'not'
    })



# Generated at 2022-06-20 22:47:40.529217
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:47:45.308322
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating'))
    assert not is_deactivating_service(dict(ActiveState='inactive'))
    assert not is_deactivating_service(dict(ActiveState='active'))
    assert not is_deactivating_service(dict(ActiveState='activating'))



# Generated at 2022-06-20 22:47:50.937169
# Unit test for function is_running_service
def test_is_running_service():
    service_status = dict(ActiveState='active')
    assert is_running_service(service_status)
    service_status = dict(ActiveState='activating')
    assert is_running_service(service_status)
    service_status = dict(ActiveState='failed')
    assert not is_running_service(service_status)



# Generated at 2022-06-20 22:47:54.384232
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"}) is True
    assert is_deactivating_service({"ActiveState": "active"}) is False



# Generated at 2022-06-20 22:48:04.776690
# Unit test for function main
def test_main():
    # Initialize mock object for function module
    function_module_mock = MagicMock()
    # Initialize object for function module

# Generated at 2022-06-20 22:48:12.531146
# Unit test for function main

# Generated at 2022-06-20 22:48:18.180699
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_input = [
        "Id=foo.service",
        "ExecStart={ path=/usr/bin/foo ; argv[]=/usr/bin/foo",
        "...}"]
    assert parse_systemctl_show(test_input) == {'Id': 'foo.service', 'ExecStart': '{ path=/usr/bin/foo ; argv[]=/usr/bin/foo\n...}'}



# Generated at 2022-06-20 22:49:03.169262
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True



# Generated at 2022-06-20 22:49:07.510593
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("something") is False
    assert request_was_ignored("this is=blah") is False
    assert request_was_ignored("this is ignoring=blah") is True
    assert request_was_ignored("bad request: ignoring command") is True


# Generated at 2022-06-20 22:49:13.914806
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = """
    Description=Foo bar
    StartLimitInterval=5min
    StartLimitBurst=10
    ExecStartPre=foo
        bar
    ExecStart=baz
    ExecStop=qux
    """
    status = parse_systemctl_show(lines.splitlines())
    assert status['Description'] == "Foo bar"
    assert status['StartLimitInterval'] == "5min"
    assert status['ExecStartPre'] == "foo\nbar"
    assert status['ExecStart'] == "baz"
    assert status['ExecStop'] == "qux"
    lines = "ExecStart={\n    foo\n    bar\n} qux"
    status = parse_systemctl_show(lines.splitlines())

# Generated at 2022-06-20 22:49:16.608082
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:49:21.717565
# Unit test for function main
def test_main():
    """Unit test for function main"""
    from ansible.module_utils.basic import AnsibleModule
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as f:
        module = AnsibleModule(
            argument_spec=dict(
                a=dict(type='str'),
                b=dict(type='str', required=True),
                c=dict(type='str', default='c'),
                d=dict(type='bool', required=True),
                e=dict(type='bool', default=True),
                f=dict(type='bool'),
                g=dict(type='list'),
                h=dict(type='dict'),
                i=dict(type='str', aliases=['name']),
            ),
            add_file_common_args=True,
            supports_check_mode=True
        )

# Generated at 2022-06-20 22:49:26.057676
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:49:32.847765
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring request'))
    assert(request_was_ignored('   ignoring command'))
    assert(request_was_ignored('     ignoring command'))
    assert(request_was_ignored('     ignoring command'))
    assert(request_was_ignored(''))
    assert(not request_was_ignored(' = warning'))
    assert(not request_was_ignored(' ='))
    assert(not request_was_ignored(' warning'))
    assert(not request_was_ignored('warning'))



# Generated at 2022-06-20 22:49:37.181319
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status1 = {'ActiveState':'deactivating'}
    service_status2 = {'ActiveState':'active'}
    assert is_deactivating_service(service_status1)
    assert not is_deactivating_service(service_status2)



# Generated at 2022-06-20 22:49:40.354920
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {"ActiveState": "deactivating"}
    assert is_deactivating_service(service_status) is True



# Generated at 2022-06-20 22:49:44.391379
# Unit test for function main
def test_main():
    monkeypatch = MonkeyPatch()

# Generated at 2022-06-20 22:50:42.581971
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['foo=bar', 'baz=foobar']) == {'foo': 'bar', 'baz': 'foobar'}
    assert parse_systemctl_show(['foo=baz']) == {'foo': 'baz'}
    assert parse_systemctl_show(['foo=baz', 'bar=foobar']) == {'foo': 'baz', 'bar': 'foobar'}
    assert parse_systemctl_show(['foo={', 'foo', 'bar', 'baz']) == {'foo': 'foo\nbar\nbaz'}
    assert parse_systemctl_show(['foo={', 'foo', 'bar', 'baz}']) == {'foo': 'foo\nbar\nbaz}'}

# Generated at 2022-06-20 22:50:49.798162
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    expected = {'Key1': 'Value1',
                'Key2': 'Value2',
                'MultiLineKey': 'Value3\n  With two lines'}
    lines1 = ['Key1=Value1', 'Key2=Value2', 'MultiLineKey={', '  Value3', '  With two lines', '}']
    lines2 = ['Key1=Value1', 'Key2=Value2', 'MultiLineKey={Value3\n  With two lines\n}']
    lines3 = ['Key1=Value1', 'Key2=Value2', 'MultiLineKey={', '  Value3', '  With two lines}']
    assert parse_systemctl_show(lines1) == expected
    assert parse_systemctl_show(lines2) == expected
    assert parse_systemctl_show(lines3) == expected




# Generated at 2022-06-20 22:51:00.993820
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:51:07.720684
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring command'))
    assert(request_was_ignored('Ignoring command'))
    assert(request_was_ignored('ignoring request'))
    assert(request_was_ignored('Ignoring request'))
    assert(request_was_ignored('Ignoring request, unit state is starting'))
    assert(request_was_ignored('ignoring request, unit not found'))
    assert(not request_was_ignored('  = Active: active (running)'))
    assert(not request_was_ignored('foo bar'))



# Generated at 2022-06-20 22:51:14.705609
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Failed to start foo.service: Access denied") == False
    assert request_was_ignored("bar.service: unrecognized service") == False
    assert request_was_ignored("Failed to reload foo.service: Operation not permitted") == False
    assert request_was_ignored("Failed to stop foo.service: Operation not supported") == False
    assert request_was_ignored("foo.service: ignoring command") == True
    assert request_was_ignored("foo.service: ignoring request") == True



# Generated at 2022-06-20 22:51:17.210321
# Unit test for function main
def test_main():
    import pytest
    import ansible.module_utils.systemd.pytest

    runner = pytest.runner.Runner(module_name='systemd')
    results = runner.run()

    assert results['success_count'] == results['test_count']
    assert ansible.module_utils.systemd.pytest.PYTEST_SUCCESS_COUNT == results['success_count']


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:51:22.424765
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'inactive'}
    if is_running_service(service_status):
        raise Exception("is_running_service failed for inactive service.")
    service_status['ActiveState'] = 'active'
    if not is_running_service(service_status):
        raise Exception("is_running_service failed for active service.")
    service_status['ActiveState'] = 'activating'
    if not is_running_service(service_status):
        raise Exception("is_running_service failed for activating service.")



# Generated at 2022-06-20 22:51:32.307096
# Unit test for function main

# Generated at 2022-06-20 22:51:34.041099
# Unit test for function main
def test_main():
    res = main()
    assert isinstance(res, dict)


# Generated at 2022-06-20 22:51:36.510880
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring command")
    assert request_was_ignored("ignoring request")
    assert not request_was_ignored("= ; 0")



# Generated at 2022-06-20 22:52:38.301110
# Unit test for function main
def test_main():
    os.environ['SYSTEMD_OFFLINE'] = '1'
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-20 22:52:42.247699
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert is_deactivating_service({'ActiveState': 'activating'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'failed'})


# Generated at 2022-06-20 22:52:47.090482
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored(' ')
    assert not request_was_ignored('')



# Generated at 2022-06-20 22:52:51.463805
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:53:04.409612
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'active', 'UnitFileState': 'enabled'})
    assert not is_deactivating_service({'ActiveState': 'inactive', 'UnitFileState': 'enabled'})
    assert not is_deactivating_service({'ActiveState': 'failed', 'UnitFileState': 'enabled'})
    assert not is_deactivating_service({'ActiveState': 'activating', 'UnitFileState': 'enabled'})
    assert is_deactivating_service({'ActiveState': 'deactivating', 'UnitFileState': 'enabled'})
    assert not is_deactivating_service({'ActiveState': 'failed', 'UnitFileState': 'disabled'})
    assert not is_deactivating_service({'ActiveState': 'inactive', 'UnitFileState': 'disabled'})

# Generated at 2022-06-20 22:53:09.631445
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)
    service_status = {'ActiveState': 'inactive'}
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-20 22:53:21.860398
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    output = [
        'Description=Foo',
        'After=network.target',
        'ConditionPathExists=/var/lib/bar',
        'ExecStart={',
        '    /usr/bin/foo',
        '    --bar',
        '}',
        'ExecStartPost={',
        '    /usr/bin/foo',
        '}',
        'ExecStartPost=/usr/bin/foo',
    ]
    res = parse_systemctl_show(output)
    assert res['Description'] == 'Foo'
    assert res['After'] == 'network.target'
    assert res['ConditionPathExists'] == '/var/lib/bar'
    assert res['ExecStart'].strip() == '\n'.join(output[3:6]).strip()
    assert res['ExecStartPost'].strip()

# Generated at 2022-06-20 22:53:26.222151
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = { 'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) is True
    service_status = { 'ActiveState': 'active'}
    assert is_deactivating_service(service_status) is False


# Generated at 2022-06-20 22:53:31.368672
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    is_deactivating_service_res_true = is_deactivating_service({'ActiveState': 'deactivating'})
    assert is_deactivating_service_res_true == True

    is_deactivating_service_res_false = is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service_res_false == False



# Generated at 2022-06-20 22:53:33.967547
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('foo ignoring command')
    assert request_was_ignored('foo ignoring request bar')
    assert request_was_ignored('foo=bar') is False

