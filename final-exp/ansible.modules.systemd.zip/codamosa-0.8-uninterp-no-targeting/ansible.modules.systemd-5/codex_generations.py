

# Generated at 2022-06-20 22:46:19.304569
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True



# Generated at 2022-06-20 22:46:23.759389
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    fake_service_status = dict()
    fake_service_status['ActiveState'] = 'deactivating'
    assert is_deactivating_service(fake_service_status)



# Generated at 2022-06-20 22:46:34.296900
# Unit test for function main

# Generated at 2022-06-20 22:46:45.953013
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:46:49.663800
# Unit test for function main
def test_main():
    """ Return success if running unit test, do not perform any AnsibleModule() calls """
    if os.getenv('UNIT_TEST') == 'true':
        return True
    return False

if not test_main():
    main()

# Generated at 2022-06-20 22:46:59.829940
# Unit test for function is_running_service
def test_is_running_service():
    test_cases = [
        [False, {'ActiveState': 'inactive'}],
        [False, {'ActiveState': 'failed'}],
        [False, {'ActiveState': 'deactivating'}],
        [False, {'ActiveState': 'activating'}],
        [True, {'ActiveState': 'active'}],
        [False, {'ActiveState': 'reloading'}],
        [False, {'ActiveState': 'Exited'}],
        [False, {'ActiveState': 'other_value'}],
    ]
    for result, case in test_cases:
        assert is_running_service(case) == result



# Generated at 2022-06-20 22:47:04.641600
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Job for sshd.service failed. See 'systemctl status sshd.service' and 'journalctl -xn' for details.")
    assert request_was_ignored("Unit sshd.service not found.")
    assert not request_was_ignored("Failed to start sshd.service: Unit sshd.service failed to load: No such file or directory.")



# Generated at 2022-06-20 22:47:09.150269
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import os
    dirname = os.path.dirname(__file__)
    path = os.path.join(dirname, 'systemctl-show-out.txt')
    lines = open(path).readlines()
    parse_systemctl_show(lines)



# Generated at 2022-06-20 22:47:13.033492
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-20 22:47:22.419638
# Unit test for function main
def test_main():

    test_system = 'system'
    test_scope = 'system'
    test_name = 'test-service-name'
    test_state = 'reloaded'
    test_enabled = True
    test_force = 'False'
    test_masked = True
    test_daemon_reload = False
    test_daemon_reexec = False
    test_no_block = False
    test_check_mode = False

    # create test module

# Generated at 2022-06-20 22:47:44.569880
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # It is important for the first value to be a single-line value that starts with {.
    # See the comment above parse_systemctl_show for why this is.
    out = """Description={OpenSSH Daemon}
ExecMainStartTimestamp={Tue 2018-02-27 10:24:20 CET}
ExecMainStartTimestampMonotonic=0
""".split('\n')

    parsed = parse_systemctl_show(out)
    assert parsed['Description'] == '{OpenSSH Daemon}'
    assert parsed['ExecMainStartTimestamp'] == '{Tue 2018-02-27 10:24:20 CET}'
    assert parsed['ExecMainStartTimestampMonotonic'] == '0'



# Generated at 2022-06-20 22:47:56.106604
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    tests=[
        (
            "test=test\nExecStart={\n\tpath=/test\n\targv[]=/test\n}\n",
            {
                "test": "test",
                "ExecStart": "\tpath=/test\n\targv[]=/test"
            }
        ),
        (
            "test={\n\ttest\n}\n",
            {
                "test": "\ttest"
            }
        ),
        (
            "test=test\n",
            {
                "test": "test"
            }
        )
    ]

    for testval, testparse in tests:
        lines = testval.split('\n')
        assert parse_systemctl_show(lines) == testparse



# Generated at 2022-06-20 22:48:00.511554
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo=bar')
    assert not request_was_ignored('foo')


# Functions below are called with the full path of the systemctl executable
# This can be used to have a nice error message with the path of the cmd.

# Generated at 2022-06-20 22:48:09.670083
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'deactivating'}) == False
    assert is_running_service({'ActiveState': 'failed'}) == False
    assert is_running_service({'ActiveState': 'nothing'}) == False

# Mapping of service state to expected active state

# Generated at 2022-06-20 22:48:13.651089
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request: unit ansible-test.service already masked') == True
    assert request_was_ignored('ignoring command: unit ansible-test.service already masked') == True
    assert request_was_ignored('asdf') == False



# Generated at 2022-06-20 22:48:18.073334
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-20 22:48:24.793291
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_input = """
ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT
ActiveEnterTimestampMonotonic=8135942
ConditionResult=yes
DefaultDependencies=yes"""
    test_output = parse_systemctl_show(test_input.split('\n'))
    assert len(test_output) == 3
    assert test_output['DefaultDependencies'] == 'yes'

# Generated at 2022-06-20 22:48:30.549692
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for postgresql.service failed.\nSee "systemctl status postgresql.service" and "journalctl -xe" for details.\n                                                                         \n')
    assert not request_was_ignored('Loaded: loaded (/etc/systemd/system/docker.service; enabled; vendor preset: enabled)\nActive: inactive (dead)\n')



# Generated at 2022-06-20 22:48:35.021175
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_states = ['deactivating']
    for state in test_states:
        yield is_deactivating_service_helper, {u'ActiveState': state}
    test_states = ['not', 'in', 'deactivating']
    for state in test_states:
        yield is_deactivating_service_helper, {u'ActiveState': state}, False


# Generated at 2022-06-20 22:48:45.912989
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def test(lines, expected):
        lines = ['{0}\n'.format(l) for l in lines]
        parsed = parse_systemctl_show(lines)
        assert parsed == expected,\
            'parse_systemctl_show({0!r}) -> {1!r} (expected {2!r})'\
            .format(lines, parsed, expected)

    test(['foo=bar', 'baz=qux'], {'foo': 'bar', 'baz': 'qux'})
    test(['foo=', 'baz=qux'], {'foo': '', 'baz': 'qux'})
    test(['foo=bar', 'baz='], {'foo': 'bar', 'baz': ''})

# Generated at 2022-06-20 22:49:05.561766
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_dict = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(test_dict)



# Generated at 2022-06-20 22:49:13.040745
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([]) == {}
    assert parse_systemctl_show(['foo=bar baz']) == {'foo': 'bar baz'}
    assert parse_systemctl_show(['foo=']) == {'foo': ''}
    assert parse_systemctl_show(['foo=bar\n']) == {'foo': 'bar'}
    assert parse_systemctl_show(['foo=bar\n', 'baz']) == {'foo': 'bar'}
    assert parse_systemctl_show(['foo=bar baz\n']) == {'foo': 'bar baz'}
    assert parse_systemctl_show(['foo=bar\n', 'baz\n']) == {'foo': 'bar'}

# Generated at 2022-06-20 22:49:18.278939
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'reloading'})
    assert not is_running_service({})



# Generated at 2022-06-20 22:49:21.170362
# Unit test for function is_running_service
def test_is_running_service():

    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status)

    service_status = {'ActiveState': 'activating'}
    assert is_running_service(service_status)

    service_status = {'ActiveState': 'inactive'}
    assert not is_running_service(service_status)



# Generated at 2022-06-20 22:49:25.580005
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-20 22:49:34.105088
# Unit test for function main

# Generated at 2022-06-20 22:49:43.063461
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Hi there, this is some text that is too short\n') is False
    assert request_was_ignored('Job for crond.service failed because the control process exited with error code. See "systemctl status crond.service" and "journalctl -xe" for details.\n') is False
    assert request_was_ignored('Unit crond.service is not loaded properly: Invalid argument.\n') is False
    assert request_was_ignored('Failed to issue method call: Unit crond.service not loaded.\n') is False
    assert request_was_ignored('Unit crond.service failed to load: No such file or directory.\n') is False
    assert request_was_ignored('Failed to issue method call: Unit crond.service not found.\n') is False
    assert request_

# Generated at 2022-06-20 22:49:49.029291
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False


# Generated at 2022-06-20 22:50:00.267845
# Unit test for function is_deactivating_service

# Generated at 2022-06-20 22:50:04.710660
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating'))
    assert not is_deactivating_service(dict(ActiveState='inactive'))
    assert not is_deactivating_service(dict(ActiveState='active'))



# Generated at 2022-06-20 22:50:39.671745
# Unit test for function is_running_service
def test_is_running_service():
    assert(is_running_service({'ActiveState': 'inactive'}) == False)
    assert(is_running_service({'ActiveState': 'active'}) == True)
    assert(is_running_service({'ActiveState': 'activating'}) == True)
    assert(is_running_service({}) == False)



# Generated at 2022-06-20 22:50:45.946220
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:56.802365
# Unit test for function main
def test_main():
    sys.path.append('./lib')
    import tests.systemd.fixtures.test_exit_json as fx_exit_json
    import tests.systemd.fixtures.test_fail_json as fx_fail_json
    import tests.systemd.fixtures.test_run_command as fx_run_command
    import tests.systemd.fixtures.test_warn as fx_warn
    import tests.systemd.fixtures.test_get_bin_path as fx_get_bin_path

    class MockSystemctlModule(object):
        def fail_json(self, *args, **kwargs):
            return fx_fail_json.fail_json(self, *args, **kwargs)

        def exit_json(self, *args, **kwargs):
            return fx_exit_

# Generated at 2022-06-20 22:51:00.471498
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})


# Generated at 2022-06-20 22:51:08.897627
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Description=sample text']) == {'Description': 'sample text'}
    assert parse_systemctl_show(['Description=sample text', 'with more lines']) == {'Description': 'sample text\nwith more lines'}
    assert parse_systemctl_show(['Description={', '  multiple lines', '}']) == {'Description': 'multiple lines'}
    assert parse_systemctl_show(['Description={end }', '  on same line']) == {'Description': '{end }\n  on same line'}
    assert parse_systemctl_show(['Description={end }', '  on same line', 'more lines']) == {'Description': '{end }\n  on same line\nmore lines'}

# Generated at 2022-06-20 22:51:10.888817
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    result = is_deactivating_service({'ActiveState': 'deactivating'})
    assert result is True

# Generated at 2022-06-20 22:51:12.560314
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:51:22.344394
# Unit test for function is_running_service
def test_is_running_service():
    from datetime import datetime
    from time import time, strftime


# Generated at 2022-06-20 22:51:32.177621
# Unit test for function main

# Generated at 2022-06-20 22:51:38.931051
# Unit test for function request_was_ignored
def test_request_was_ignored():
    for test_str in ['foo=bar',
                     'foo=bar=baz',
                     'foo=bar\ndo=baz\nhello=world']:
        assert request_was_ignored(test_str) is False
    for test_str in ['ignoring request',
                     'foo ignoring command',
                     'foo ignoring request',
                     'ignoring request: foo',
                     'ignoring request foo']:
        assert request_was_ignored(test_str) is True



# Generated at 2022-06-20 22:52:23.234975
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {
        'ActiveState': 'deactivating',
        'SubState': 'running',
        }
    assert is_deactivating_service(service_status) is True



# Generated at 2022-06-20 22:52:27.178037
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('[....] Starting some service (some service) ...\n[....] some service is not running ...')
# END of test cases.



# Generated at 2022-06-20 22:52:31.725867
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState':'deactivating'}) is True
    assert is_deactivating_service({'ActiveState':'activating'}) is False
    assert is_deactivating_service({'ActiveState':'active'}) is False


# Generated at 2022-06-20 22:52:40.438336
# Unit test for function main

# Generated at 2022-06-20 22:52:46.181065
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Ignoring request, ignoring command") is True
    assert request_was_ignored("some text = some text") is False
    assert request_was_ignored("some text = 0") is False
    assert request_was_ignored("some text = 0 some other text") is False



# Generated at 2022-06-20 22:52:48.748423
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False


# Generated at 2022-06-20 22:52:49.771257
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:52:58.396892
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # Test an ActiveState of 'deactivating'
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)

    # Test an ActiveState of 'active'
    service_status = {'ActiveState': 'active'}
    assert not is_deactivating_service(service_status)

    # Test an ActiveState of 'activating'
    service_status = {'ActiveState': 'activating'}
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-20 22:53:03.917728
# Unit test for function main
def test_main():
    global rc, out, err
    module = AnsibleModule(argument_spec={})
    with pytest.raises(AnsibleFailJson):
        main()
    

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:53:12.150071
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    test_name = 'test_mixed'
    mock_args = dict(
        name=test_name,
        state='reloaded',
        daemon_reexec=True,
        daemon_reload=True,
    )

# Generated at 2022-06-20 22:54:48.920074
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = '''
Property: xxx=yyy
Property: ExecFoo=foo
bar
baz
Property: ExecBar={
foo
bar
}
Property: ExecBaz={
foo
bar
baz
}
Property: ExecQux={
foo
bar
baz
}
'''.strip().split('\n')

    expected = {
        'Property': 'xxx=yyy',
        'ExecFoo': 'foo\nbar\nbaz',
        'ExecBar': '{ foo\nbar}',
        'ExecBaz': '{ foo\nbar\nbaz}',
        'ExecQux': '{ foo\nbar\nbaz}',
    }

    assert expected == parse_systemctl_show(lines)



# Generated at 2022-06-20 22:54:57.069218
# Unit test for function main
def test_main():
    from ansible.module_utils.six.moves import StringIO

# Generated at 2022-06-20 22:55:09.127101
# Unit test for function main

# Generated at 2022-06-20 22:55:13.156199
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(service_status = {'ActiveState': 'active'}) == True
    assert is_running_service(service_status = {'ActiveState': 'activating'}) == True
    assert is_running_service(service_status = {'ActiveState': 'inactive'}) == False
    assert is_running_service(service_status = {'ActiveState': 'deactivating'}) == False


# Generated at 2022-06-20 22:55:19.528112
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    data = """Unit=foo.service
ActiveState=active
After=something.service
Description=A value that spans
 multiple lines
ExecMainStartTimestampMonotonic=8134990
ExecMainStartTimestamp=Sun 2016-05-15 18:28:49 EDT
ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT"""
    assert parse_systemctl_show(data.split('\n')) == dict(
        Unit='foo.service',
        ActiveState='active',
        After='something.service',
        Description='A value that spans\nmultiple lines',
        ExecMainStartTimestampMonotonic='8134990',
        ExecMainStartTimestamp='Sun 2016-05-15 18:28:49 EDT',
        ActiveEnterTimestamp='Sun 2016-05-15 18:28:49 EDT',
    )



# Generated at 2022-06-20 22:55:21.834553
# Unit test for function main
def test_main():
    yield "main"

# import module snippets
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:55:24.743385
# Unit test for function request_was_ignored
def test_request_was_ignored():
    from ansible.module_utils.systemd import request_was_ignored
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')



# Generated at 2022-06-20 22:55:29.809043
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'failed'}) == False
    assert is_running_service({'ActiveState': 'deactivating'}) == False
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'unknown'}) == False


# Generated at 2022-06-20 22:55:33.875411
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    results = {}
    results['ActiveState'] = 'failed'
    assert is_deactivating_service(results) == False
    results['ActiveState'] = 'deactivating'
    assert is_deactivating_service(results) == True
    results['ActiveState'] = 'active'
    assert is_deactivating_service(results) == False

