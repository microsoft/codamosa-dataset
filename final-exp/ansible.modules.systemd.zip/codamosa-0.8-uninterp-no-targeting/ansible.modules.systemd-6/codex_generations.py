

# Generated at 2022-06-20 22:46:44.477623
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)
    service_status['ActiveState'] = 'NotDeactivating'
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-20 22:46:47.013317
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:46:51.705060
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': ''})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'activating'})



# Generated at 2022-06-20 22:46:59.978991
# Unit test for function is_running_service
def test_is_running_service():
    active_states = ['inactive', 'activating', 'active', 'deactivating']
    for state in active_states:
        service_status = dict()
        service_status['ActiveState'] = state
        assert is_running_service(service_status) is True
    inactive_states = ['failed', 'activating', 'deactivating']
    for state in inactive_states:
        service_status = dict()
        service_status['ActiveState'] = state
        assert is_running_service(service_status) is False



# Generated at 2022-06-20 22:47:02.901130
# Unit test for function main
def test_main():
    # No need to test this, it's a library
    pass
# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:47:15.072607
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Case 1: single line config value
    in_data = ["ActiveState=active\n"]
    out_data = {"ActiveState": 'active'}
    test_out_data = parse_systemctl_show(in_data)
    assert test_out_data == out_data

    # Case 2: multi line config, multi line value
    in_data = ["ExecStart=/bin/sh -c 'echo hello,\nworld'\n"]
    out_data = {"ExecStart": "/bin/sh -c 'echo hello,\nworld'"}
    test_out_data = parse_systemctl_show(in_data)
    assert test_out_data == out_data

    # Case 3: multi line config, single line value, but starts with a {

# Generated at 2022-06-20 22:47:21.389633
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'dead'})
    assert not is_running_service({'ActiveState': 'unknown'})


# Generated at 2022-06-20 22:47:29.235765
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:47:35.381493
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'deactivated'}) == False
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'failed'}) == False
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True


# Generated at 2022-06-20 22:47:39.648452
# Unit test for function is_running_service
def test_is_running_service():
    running_service_status = dict(ActiveState='active')
    assert is_running_service(running_service_status)

    assert not is_running_service(dict(ActiveState='deactivating'))
    assert not is_running_service(dict(ActiveState='dead'))
    assert not is_running_service(dict())



# Generated at 2022-06-20 22:48:03.274214
# Unit test for function main
def test_main():   
    class DummyArgs(object):
        def __init__(self, check, daemon_reload, daemon_reexec, enabled, force, masked, no_block, name, state, scope):
            self.check = check
            self.daemon_reload = daemon_reload
            self.daemon_reexec = daemon_reexec
            self.enabled = enabled
            self.force = force
            self.masked = masked
            self.no_block = no_block
            self.name = name
            self.state = state
            self.scope = scope
    
    class DummyModule(object):
        def __init__(self):
            self.check_mode = False
            self.exit_json = lambda **kwargs: None
            self.fail_json = lambda msg: None
            self.run_

# Generated at 2022-06-20 22:48:11.633957
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test single-line values
    assert parse_systemctl_show(['Id=some_service.service']) == {'Id': 'some_service.service'}
    assert parse_systemctl_show(['Id=some_service.service', 'Description=Some service']) == {'Id': 'some_service.service', 'Description': 'Some service'}

    # Test multi-line value that starts and ends with {...} on the same line
    assert parse_systemctl_show(['Id=some_service.service', 'ExecStart={ some command; }']) == {'Id': 'some_service.service', 'ExecStart': '{ some command; }'}

    # Test multi-line value that starts with { on one line and ends with } on a subsequent line

# Generated at 2022-06-20 22:48:15.508970
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command: reload')
    assert not request_was_ignored('ActiveState=active')
    assert not request_was_ignored('ActiveState=active foobar=baz')



# Generated at 2022-06-20 22:48:20.871559
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:48:32.188799
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import textwrap
    # Check that a single line value is correctly parsed
    assert parse_systemctl_show(['Key1=Value1']) == {'Key1': 'Value1'}
    # Check that a single line value that starts with { is correctly parsed
    assert parse_systemctl_show(['Key1={Value1']) == {'Key1': '{Value1'}
    # Check that a multi-line, multi-value value is correctly parsed

# Generated at 2022-06-20 22:48:39.261921
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    expected = {
        'a': '1', 'b': '2', 'c': '3', 'ExecStart': '{ a b\nc }\n'
    }
    parsed = parse_systemctl_show(['a=1', 'b=2', 'ExecStart={\n', 'a b', '\nc }\n', 'c=3'])
    assert parsed == expected
    assert parsed != {'a': '1', 'b': '{ a b\nc }\n', 'c': '3', 'ExecStart': '{ a b\nc }\n'}



# Generated at 2022-06-20 22:48:49.371152
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os
    import tempfile


# Generated at 2022-06-20 22:48:56.036430
# Unit test for function main
def test_main():
    import ansible.modules.system.systemd
    unit = 'test.service'
    systemctl = 'systemctl'
    args = dict(
        name=unit,
        state=None,
        enabled=None,
        mask=None,
        daemon_reload=None,
        daemon_reexec=None,
        scope=None,
    )
    args = json.dumps(args)
    module = MagicMock()
    module.params = json.loads(args)
    ansible.modules.system.systemd.main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:01.998089
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('')
    assert request_was_ignored('foo bar')
    assert request_was_ignored('foo ignoring request bar')
    assert request_was_ignored('foo ignoring command bar')
    assert not request_was_ignored('foo bar = bar baz')
    assert not request_was_ignored('foo bar')



# Generated at 2022-06-20 22:49:07.865164
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    assert is_deactivating_service({'ActiveState': 'activating'}) is False



# Generated at 2022-06-20 22:49:35.640049
# Unit test for function main
def test_main():
    # Test with service
    module = ansible_module_mock()
    module.params = {
        'name': 'chronyd',
        'state': 'started'
    }
    system = MockSysV()
    rc = 0
    out = err = ''
    service = '(chronyd)'
    failed = False
    results = []
    info = {
        'changed': {
            'state': None,
            'enabled': None,
            'masked': None
        },
        'status': {},
        'name': 'chronyd',
        'state': None,
        'enabled': None,
        'masked': None
    }

# Generated at 2022-06-20 22:49:37.457707
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True


# Generated at 2022-06-20 22:49:49.707541
# Unit test for function is_running_service
def test_is_running_service():
    active_states = [
        {'ActiveState': 'active', 'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT'},
        {'ActiveState': 'activating', 'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT'},
    ]
    for state in active_states:
        assert is_running_service(state) is True

    inactive_states = [
        {'ActiveState': 'inactive', 'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT'},
        {'ActiveState': 'deactivating', 'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT'},
    ]
    for state in inactive_states:
        assert is_running_service(state) is False



# Generated at 2022-06-20 22:49:57.339562
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = ["MainPID=2217", "Description={ cryptsetup", "  Create encrypted OpenSSL key for", "  qemu-guest-agent -m 4096 -O rsa", "}"]
    expected = {'MainPID': '2217',
                'Description': 'cryptsetup\nCreate encrypted OpenSSL key for\nqemu-guest-agent -m 4096 -O rsa'}
    assert expected == parse_systemctl_show(lines)



# Generated at 2022-06-20 22:50:06.093003
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring request'))
    assert(request_was_ignored('ignoring command'))
    assert(request_was_ignored('ignoring requests'))
    assert(request_was_ignored('ignoring commands'))
    assert(request_was_ignored('ignoring'))
    assert(not request_was_ignored('ignoring request '))
    assert(not request_was_ignored('=ignoring request '))
    assert(not request_was_ignored('=ignoring request='))



# Generated at 2022-06-20 22:50:09.467527
# Unit test for function main
def test_main():
    print('test_main')

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:50:17.126135
# Unit test for function is_running_service
def test_is_running_service():
    status = {
        'ActiveState': 'active',
        'SubState': 'running',
    }
    assert is_running_service(status)

    status = {
        'ActiveState': 'active',
        'SubState': 'exited',
    }
    assert is_running_service(status)

    status = {
        'ActiveState': 'activating',
        'SubState': 'exited',
    }
    assert is_running_service(status)

    status = {
        'ActiveState': 'inactive',
        'SubState': 'exited',
    }
    assert not is_running_service(status)


# Generated at 2022-06-20 22:50:26.792901
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:36.144686
# Unit test for function main

# Generated at 2022-06-20 22:50:45.341677
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    from ansible.module_utils.common._collections_compat import OrderedDict

# Generated at 2022-06-20 22:51:54.032650
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Before this fix the following code would have returned the following dict:
    # {'ExecStart=': '{\n path=/usr/sbin/httpd ; argv[]=/usr/sbin/httpd $OPTIONS -DFOREGROUND\n}'}
    input_data = ['ExecStart={', ' path=/usr/sbin/httpd ; argv[]=/usr/sbin/httpd $OPTIONS -DFOREGROUND', '}']
    expected = {'ExecStart=': '{\n path=/usr/sbin/httpd ; argv[]=/usr/sbin/httpd $OPTIONS -DFOREGROUND\n}'}
    actual = parse_systemctl_show(input_data)
    assert actual == expected



# Generated at 2022-06-20 22:51:59.390270
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request to reload')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring command to start')
    assert not request_was_ignored('ActiveState=inactive')
    assert not request_was_ignored('ActiveState=active')



# Generated at 2022-06-20 22:52:04.435485
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': ''}) is False


# Generated at 2022-06-20 22:52:08.131473
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    deactivating_output = {
        'ActiveState': 'deactivating'
    }
    running_output = {
        'ActiveState': 'active'
    }
    assert is_deactivating_service(deactivating_output) is True
    assert is_deactivating_service(running_output) is False



# Generated at 2022-06-20 22:52:12.615169
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status)
    service_status = {'ActiveState': 'activating'}
    assert is_running_service(service_status)



# Generated at 2022-06-20 22:52:17.986167
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    ret = dict()
    ret['ActiveState'] = 'deactivating'
    module_name = 'ansible.builtin.systemd'
    this_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    assert is_deactivating_service(ret)



# Generated at 2022-06-20 22:52:26.454383
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service(dict(ActiveState='active'))
    assert not is_deactivating_service(dict(ActiveState='activating'))
    assert not is_deactivating_service(dict(ActiveState='inactive'))
    assert not is_deactivating_service(dict(ActiveState='failed'))
    assert not is_deactivating_service(dict(ActiveState='reloaded'))
    assert not is_deactivating_service(dict(ActiveState='unknown'))
    assert is_deactivating_service(dict(ActiveState='deactivating'))



# Generated at 2022-06-20 22:52:36.977310
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Foo=bar', 'Baz=1234']) == {'Foo': 'bar', 'Baz': '1234'}
    assert parse_systemctl_show(['Foo=bar', 'Baz=1234', 'IgnoreMe=foo']) == {'Foo': 'bar', 'Baz': '1234'}
    assert parse_systemctl_show(['Foo=bar', '', 'Baz=1234']) == {'Foo': 'bar', 'Baz': '1234'}
    assert parse_systemctl_show(['Foo=bar', '', '', '', 'Baz=1234']) == {'Foo': 'bar', 'Baz': '1234'}

# Generated at 2022-06-20 22:52:40.772478
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-20 22:52:52.548930
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:54:48.959477
# Unit test for function is_running_service
def test_is_running_service():
    assert(is_running_service({'ActiveState': 'activating'}) == True)
    assert(is_running_service({'ActiveState': 'active'}) == True)
    assert(is_running_service({'ActiveState': 'deactivating'}) == False)
    assert(is_running_service({'ActiveState': 'inactive'}) == False)
    assert(is_running_service({'ActiveState': 'failed'}) == False)


# Generated at 2022-06-20 22:54:52.034036
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-20 22:54:57.128095
# Unit test for function main

# Generated at 2022-06-20 22:55:01.048724
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('= "foo"')
    assert not request_was_ignored('foo')



# Generated at 2022-06-20 22:55:11.639681
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for rabbitmq-server.service failed because the control process exited with error code. See "systemctl status rabbitmq-server.service" and "journalctl -xe" for details.\n')
    assert request_was_ignored('Job for rabbitmq-server.service failed because the control process exited with error code. See "systemctl status rabbitmq-server.service" and "journalctl -xe" for details.')
    assert request_was_ignored('Job for rabbitmq-server.service failed because the control process exited with error code. See "systemctl status rabbitmq-server.service" and "journalctl -xe" for details')
    assert request_was_ignored('Job for rabbitmq-server.service failed because control process exited, code=exited status=1\n')
    assert request_

# Generated at 2022-06-20 22:55:14.261709
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # Setup
    service_status = {'ActiveState': 'deactivating'}
    # Execute
    ret = is_deactivating_service(service_status)
    # Assert
    assert ret is True



# Generated at 2022-06-20 22:55:23.465133
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('', 'ignoring command') == True
    assert request_was_ignored('=', 'ignoring request') == False
    assert request_was_ignored('Done') == False
    assert request_was_ignored('=') == False
    assert request_was_ignored('Failed to get properties: No such interface \'org.freedesktop.DBus.Properties\' on object at path /org/freedesktop/systemd1/unit/crond_2eservice') == True
    assert request_was_ignored('Failed to get properties: No such interface "org.freedesktop.DBus.Properties" on object at path /org/freedesktop/systemd1/unit/crond_2eservice') == True


# Generated at 2022-06-20 22:55:31.323513
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:55:38.537194
# Unit test for function parse_systemctl_show