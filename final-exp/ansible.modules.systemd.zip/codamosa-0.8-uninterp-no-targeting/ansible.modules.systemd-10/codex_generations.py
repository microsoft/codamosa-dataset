

# Generated at 2022-06-20 22:46:15.726575
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'reloading'}) is False



# Generated at 2022-06-20 22:46:21.767842
# Unit test for function is_running_service
def test_is_running_service():
    running_service = {'ActiveState': 'active'}
    assert is_running_service(running_service)
    activating_service = {'ActiveState': 'activating'}
    assert is_running_service(activating_service)
    no_service = {'ActiveState': 'None'}
    assert not is_running_service(no_service)



# Generated at 2022-06-20 22:46:24.094039
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState":"deactivating"})
    assert not is_deactivating_service({"ActiveState":"dead"})



# Generated at 2022-06-20 22:46:26.924542
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})


# Generated at 2022-06-20 22:46:29.879795
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('No units listed.')
    assert not request_was_ignored('Assertion failed')



# Generated at 2022-06-20 22:46:34.721047
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='inactive'))
    assert not is_running_service(dict(ActiveState='failed'))
    assert not is_running_service(dict())



# Generated at 2022-06-20 22:46:46.264222
# Unit test for function main
def test_main():
    class args:
        def __init__(self, daemon_reload=False, daemon_reexec=False):
            self.daemon_reload = daemon_reload
            self.daemon_reexec = daemon_reexec

    class params:
        def __init__(self, name, state, enabled, force, masked, scope, no_block):
            self.name = name
            self.state = state
            self.enabled = enabled
            self.force = force
            self.masked = masked
            self.scope = scope
            self.no_block = no_block

    class AnsibleModuleMock:
        def __init__(self):
            self.params = params("", "started", True, False, False, "system", False)
            self.args = args()


# Generated at 2022-06-20 22:46:56.932089
# Unit test for function is_running_service
def test_is_running_service():
    service_status = dict(ActiveState='active')
    assert is_running_service(service_status) is True
    service_status = dict(ActiveState='activating')
    assert is_running_service(service_status) is True
    service_status = dict(ActiveState='exited')
    assert is_running_service(service_status) is False
    service_status = dict(ActiveState='failed')
    assert is_running_service(service_status) is False
    service_status = dict(ActiveState='old')
    assert is_running_service(service_status) is False
    service_status = dict(ActiveState='reloading')
    assert is_running_service(service_status) is False
    service_status = dict(ActiveState='inactive')
    assert is_running_service(service_status) is False

# Generated at 2022-06-20 22:46:58.211742
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})



# Generated at 2022-06-20 22:47:07.432554
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_lines = ['Description=Command Scheduler', 'Id=crond.service', 'FragmentPath=/usr/lib/systemd/system/crond.service', 'ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }', 'ExecReload={ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }']
    out = parse_systemctl_show(test_lines)

# Generated at 2022-06-20 22:47:40.156830
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'unknown'})

# Given a systemd.unit file name,
# return True if it is enabled, False if it is disabled,
# True if it does not exist.
# We assume that unit files ending with .wants/ and .requires/
# are always enabled.

# Generated at 2022-06-20 22:47:42.917901
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('foo=bar') is False
    assert request_was_ignored('foo') is False
# END unit test



# Generated at 2022-06-20 22:47:53.245430
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([
        'Id=ansible_test.service',
        'Description=Unit',
        'DefaultDependencies=no',
        'Conflicts=shutdown.target',
        'Before=shutdown.target',
        'After=sysinit.target',
        'Requires=sysinit.target',
        'Wants=network.target',
        'Documentation='
    ]) == {
        'Id': 'ansible_test.service',
        'Description': 'Unit',
        'DefaultDependencies': 'no',
        'Conflicts': 'shutdown.target',
        'Before': 'shutdown.target',
        'After': 'sysinit.target',
        'Requires': 'sysinit.target',
        'Wants': 'network.target',
        'Documentation': ''
    }


# Generated at 2022-06-20 22:47:58.555447
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # deactivating should return true
    assert is_deactivating_service(dict(ActiveState='deactivating'))
    # all other states should return false
    for s in ['active', 'activating', 'inactive', 'failed']:
        assert not is_deactivating_service(dict(ActiveState=s))



# Generated at 2022-06-20 22:48:01.957631
# Unit test for function is_running_service
def test_is_running_service():
    test_service_status = {
        'ActiveState': 'active',
        }
    assert is_running_service(test_service_status)
    test_service_status = {
        'ActiveState': 'inactive',
        }
    assert not is_running_service(test_service_status)


# Generated at 2022-06-20 22:48:10.825986
# Unit test for function main
def test_main():
    # Unit tests for main
    
    # Example from docs, test a service that is already stopped
    args = dict(
        name=None,
        state='stopped',
        daemon_reload=False,
    )
    rc, out, err = do_systemctl_test(None, **args)
    assert rc == 0, out+err

    # Example from docs, test a service that is already stopped
    args = dict(
        name='sshd.service',
        state='stopped',
        daemon_reload=False,
    )
    rc, out, err = do_systemctl_test(None, **args)
    assert rc == 0, out+err

    # Example from docs, test a service that is already stopped

# Generated at 2022-06-20 22:48:16.720791
# Unit test for function main
def test_main():
    import sys,os
    test_file = os.path.join(os.path.dirname(__file__), 'test.systemd.py')
    sys.path.append(os.path.dirname(test_file))
    import test_systemd as testmod
    sys.exit(testmod.from_command_line(argv=sys.argv))

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 22:48:18.968586
# Unit test for function main
def test_main():
    '''Unit test
    '''
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:48:30.462893
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Id=crond.service']) == {'Id': 'crond.service'}

    assert parse_systemctl_show(['Id=crond.service', 'Description=My description']) == {'Id': 'crond.service', 'Description': 'My description'}

    # Multi-line values for keys whose names do not start with Exec are not accepted
    assert parse_systemctl_show(['Id=crond.service', 'Description={']) == {'Id': 'crond.service', 'Description': '{'}
    assert parse_systemctl_show(['Id=crond.service', 'Description={', 'continues']) == {'Id': 'crond.service', 'Description': '{'}

# Generated at 2022-06-20 22:48:38.477233
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Cannot add dependency job for unit display-manager.service, ignoring: Unit display-manager.service failed to load: No such file or directory.\n')
    assert not request_was_ignored('Job for firewalld.service failed')
    assert not request_was_ignored('Job for systemd-logind.service canceled')
    assert not request_was_ignored('Unit firewalld.service is bound to inactive unit network.target.')
    assert not request_was_ignored('Job for sshd-keygen.service canceled.\nJob for sshd-keygen.service failed because the control process exited with error code.\n')
    assert not request_was_ignored('Job for systemd-logind.service canceled.\nFailed to issue method call: Unit systemd-logind.service is masked.\n')



# Generated at 2022-06-20 22:49:25.866869
# Unit test for function main
def test_main():
    # The following function is an alternative to the built-in print function
    def print(s, file=sys.stdout):
        file.write(s+"\n")

    # unit test code
    cmd_base = os.path.basename(sys.argv[0])
    if cmd_base == 'yaml_unit_tests.py':
        # Disable print_newline, otherwise it will print newline for stdout
        # and will mess up stdout and stderr.
        options = {'print_newline': False}
        # We can't use `yaml_unit_tests.py` to run this module.
        # Because we need to run the module under `ansible-playbook`.
        # But we can use `yaml_unit_tests.py` to test `main` function.
        utils.run

# Generated at 2022-06-20 22:49:29.658546
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('=' * 10)
    assert not request_was_ignored('pid')



# Generated at 2022-06-20 22:49:35.774577
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # Positive test case
    service_status = {
        'ActiveState': 'deactivating'
    }
    assert is_deactivating_service(service_status) is True

    # Negative test case
    service_status = {
        'ActiveState': 'something else'
    }
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-20 22:49:39.677610
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request") == True
    assert request_was_ignored("ignoring command") == True
    assert request_was_ignored(" something else ") == False
    assert request_was_ignored(" ") == False



# Generated at 2022-06-20 22:49:40.378025
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:49:43.653692
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': ''})



# Generated at 2022-06-20 22:49:46.674055
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert(is_deactivating_service({'ActiveState':'active'}) == False)
    assert(is_deactivating_service({'ActiveState':'activating'}) == False)
    assert(is_deactivating_service({'ActiveState':'deactivating'}) == True)



# Generated at 2022-06-20 22:49:55.060552
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'unknown'})
    assert not is_running_service({'ActiveState': 'unrecognized'})
    assert not is_running_service({'ActiveState': None})
    assert not is_running_service({})



# Generated at 2022-06-20 22:49:59.269662
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert(is_deactivating_service({'ActiveState': 'deactivating'}) is True)
    assert(is_deactivating_service({'ActiveState': 'failed'}) is False)
    assert(is_deactivating_service({'ActiveState': 'active'}) is False)
    assert(is_deactivating_service({'ActiveState': 'inactive'}) is False)



# Generated at 2022-06-20 22:50:04.353935
# Unit test for function main
def test_main():
    # This function is supposed to be tested elsewhere.  See
    # https://github.com/ansible/ansible/issues/71528#issuecomment-566713889.
    raise NotImplementedError()


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:51:35.530065
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-20 22:51:46.337856
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    result = {'Description': 'system and service manager', 'Id': 'systemd-journald.service',
              'ExecReload': '{ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; '
                            'start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'}

# Generated at 2022-06-20 22:51:48.911546
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test1 = {'ActiveState': 'active'}
    assert is_deactivating_service(test1) is False



# Generated at 2022-06-20 22:51:49.886304
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service() == False


# Generated at 2022-06-20 22:51:57.523437
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from mock import Mock, patch
    from pkg_resources import parse_version
    import sys


# Generated at 2022-06-20 22:52:03.998070
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['A=b', 'C=d']) == {'A': 'b', 'C': 'd'}
    assert parse_systemctl_show(['A=b=c', 'C=d']) == {'A': 'b=c', 'C': 'd'}
    assert parse_systemctl_show(['A=b\n', 'C=d']) == {'A': 'b', 'C': 'd'}
    assert parse_systemctl_show(['A=b', 'C=d\n']) == {'A': 'b', 'C': 'd'}
    assert parse_systemctl_show(['A=b', 'C=d ']) == {'A': 'b', 'C': 'd'}

# Generated at 2022-06-20 22:52:14.252931
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # happy path: single-line value
    assert parse_systemctl_show(['k1=v1']) == {'k1': 'v1'}
    # happy path: single-line multi-valued value
    assert parse_systemctl_show(['k2=v2a\nk2=v2b']) == {'k2': 'v2a'}
    # happy path: multi-line value
    assert parse_systemctl_show(['k3={\nvvvv\n}\n']) == {'k3': '{\nvvvv\n}'}
    # happy path: multi-line value that uses `{` but not `}`
    assert parse_systemctl_show(['k4={\nvvvv\n']) == {'k4': '{\nvvvv\n'}
   

# Generated at 2022-06-20 22:52:25.390204
# Unit test for function main
def test_main():
    for unit, action, retval in [
        ('sshd.service', 'is-enabled', 1),
        ('crond.service', 'is-enabled', 0),
        ('sendmail.service', 'is-enabled', 1),
    ]:
        yield run_function, main, {
            'name': unit,
            'enabled': None,
            'masked': None,
            'state': None,
            'force': False,
            'daemon_reload': False,
            'daemon_reexec': False,
            'scope': 'system',
            'no_block': False,
        }, {
            'name': unit,
            'status': {},
            'enabled': retval == 0,
            'changed': False,
        }


# ===========================================
# import module snippets

# Generated at 2022-06-20 22:52:36.175981
# Unit test for function is_deactivating_service

# Generated at 2022-06-20 22:52:45.672940
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('garbage') is False
    assert request_was_ignored('= garbage') is False
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('Active: inactive (dead)') is False
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('garbage\nignoring command') is True
    assert request_was_ignored('garbage\nignoring command\ngarbage') is True



# Generated at 2022-06-20 22:55:25.255558
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('message=Unit not found')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')

    assert not request_was_ignored('message=')
    assert not request_was_ignored('message=Unit found')
    assert not request_was_ignored('ignoring command foo')



# Generated at 2022-06-20 22:55:33.274596
# Unit test for function main
def test_main():
    args = dict(
        name='foobar',
        state='started',
        daemon_reload=False,
        daemon_reexec=False,
        scope='system',
        no_block=False,
    )
    result = dict(
        name='foobar',
        changed=False,
        status=dict(LoadState='loaded', ActiveState='active', SubState='running', UnitFileState='enabled'),
        state='started',
    )
    run_command_results = [
        # is-enabled
        [0, 'enabled', ''],
        # show
        [0, """\
LoadState=loaded
ActiveState=active
SubState=running
UnitFileState=enabled
""", ''],
        # is-active
        [0, 'active', ''],
    ]