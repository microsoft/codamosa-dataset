

# Generated at 2022-06-20 22:46:21.723126
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_true = {"ActiveState": "deactivating"}
    test_false = {"ActiveState": "active"}
    assert is_deactivating_service(test_true) is True
    assert is_deactivating_service(test_false) is False



# Generated at 2022-06-20 22:46:32.391002
# Unit test for function is_deactivating_service

# Generated at 2022-06-20 22:46:34.219189
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=foo')
    assert not request_was_ignored('Ignoring request')
    assert not request_was_ignored('')



# Generated at 2022-06-20 22:46:39.805247
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    if is_deactivating_service({'ActiveState': 'deactivating'}):
        assert True
    else:
        assert False
    if not is_deactivating_service({'ActiveState': 'active'}):
        assert True
    else:
        assert False
# End unit test

# Generated at 2022-06-20 22:46:48.993627
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for foo.service failed because the control process exited with error code.\n')
    assert request_was_ignored('Job for foo.service failed.\nSee \'systemctl status foo.service\' and \'journalctl -xn\' for details.\n')
    assert request_was_ignored('Failed to connect to bus: No such file or directory\n')  # User DBus not started
    assert not request_was_ignored('unit {0} not found.\n')
    assert not request_was_ignored('foo.service loaded active running foo service\n')
    assert not request_was_ignored('foo.service could not be found\n')
    assert not request_was_ignored('foo.service is masked.\n')

# Generated at 2022-06-20 22:47:00.839899
# Unit test for function main

# Generated at 2022-06-20 22:47:09.563339
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:47:19.813096
# Unit test for function main
def test_main():
    unit = 'dummy.service'

# Generated at 2022-06-20 22:47:21.511384
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True



# Generated at 2022-06-20 22:47:24.903903
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})


# Generated at 2022-06-20 22:47:49.288929
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # invalid_request should return True
    invalid_request = b'Job for unit-name.service failed because the control process exited with error code. See "systemctl status unit-name.service" and "journalctl -xe" for details.'  # NOQA
    assert request_was_ignored(invalid_request)

    # valid_request should return False
    valid_request = b'Failed to start unit-name.service: Unit unit-name.service failed to load: No such file or directory.\nSee system logs and '  # NOQA
    assert not request_was_ignored(valid_request)



# Generated at 2022-06-20 22:47:50.009545
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-20 22:47:53.418208
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('= not in')



# Generated at 2022-06-20 22:47:56.054182
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:48:05.385630
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_cases = [
        # Single-line, non-multivalue
        (
            ['Description=foo'],
            {'Description': 'foo'}
        ),
        # Multi-line, multivalue
        (
            ['ExecStart={', 'foo', 'bar', '}'],
            {'ExecStart': '\n'.join(['foo', 'bar'])}
        ),
        # Multi-line, single-line multivalue
        (
            ['ExecStart={', 'foo', '}'],
            {'ExecStart': '\n'.join(['foo'])}
        )
    ]
    for (input, output) in test_cases:
        assert output == parse_systemctl_show(input)



# Generated at 2022-06-20 22:48:09.121825
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('Job for ...')
    assert not request_was_ignored('unrecognized request')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')


# ===========================================
# systemd module specific support methods.
#


# Generated at 2022-06-20 22:48:19.692840
# Unit test for function is_deactivating_service

# Generated at 2022-06-20 22:48:24.278547
# Unit test for function is_running_service
def test_is_running_service():
    test_running = {'ActiveState': 'activating'}
    test_not_running = {'ActiveState': 'inactive'}
    assert is_running_service(test_running)
    assert not is_running_service(test_not_running)



# Generated at 2022-06-20 22:48:34.464561
# Unit test for function is_running_service
def test_is_running_service():
    running_service = dict(ActiveState="active", SubState="running", StatusErrno="0")
    assert is_running_service(running_service)
    restarting_service = dict(ActiveState="activating", SubState="restarting", StatusErrno="0")
    assert is_running_service(restarting_service)
    reloading_service = dict(ActiveState="activating", SubState="reloading", StatusErrno="0")
    assert is_running_service(reloading_service)
    inactive_service = dict(ActiveState="inactive", SubState="dead", StatusErrno="0")
    assert not is_running_service(inactive_service)
    inactive_service = dict(ActiveState="inactive", SubState="", StatusErrno="")

# Generated at 2022-06-20 22:48:37.068068
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'notrunning'})



# Generated at 2022-06-20 22:49:26.669913
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:49:31.811498
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"})
    assert not is_deactivating_service({"ActiveState": "active"})
    assert not is_deactivating_service({"ActiveState": "unknown"})



# Generated at 2022-06-20 22:49:39.224897
# Unit test for function is_running_service
def test_is_running_service():
    '''
    Unit tests for function is_running_service
    '''
    running = {'ActiveState': 'active'}
    activating = {'ActiveState': 'activating'}
    stopped = {'ActiveState': 'stopped'}
    invalid = {'ActiveState': 'invalid'}

    assert not is_running_service(stopped)
    assert  is_running_service(running)
    assert  is_running_service(activating)
    assert not is_running_service(invalid)



# Generated at 2022-06-20 22:49:48.074224
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({
        'ActiveState': 'inactive',
        'SubState': 'dead'}) is False
    assert is_running_service({
        'ActiveState': 'active',
        'SubState': 'running'}) is True
    assert is_running_service({
        'ActiveState': 'activating',
        'SubState': 'start-post'}) is True
    assert is_running_service({
        'ActiveState': 'active',
        'SubState': 'running',
        'Result': 'success'}) is True



# Generated at 2022-06-20 22:49:56.845436
# Unit test for function main
def test_main():
    """ basic (unit) test for main function """

# Generated at 2022-06-20 22:50:09.305060
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request to reload C(.service), as unit C(.service) is masked.')
    assert request_was_ignored('Ignoring request to reload process, as unit process.service is masked.')
    assert request_was_ignored('Ignoring command C(start), as unit C(cron.service) is masked.')
    assert request_was_ignored('Ignoring command start, as unit cron.service is masked.')
    assert not request_was_ignored('  Loaded: loaded C(/usr/lib/systemd/system/crond.service; enabled)')
    assert not request_was_ignored('Active: C(failed) since Thu 1970-01-01 00:00:00 UTC; 2s ago')

# Generated at 2022-06-20 22:50:14.458263
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("""Unit nginx.service could not be found.""")
    assert request_was_ignored("""Unit cron.service is masked.""")
    assert request_was_ignored("""Unit cron.service could not be found.""")
    assert not request_was_ignored("""Job for nginx.service failed. See "systemctl status nginx.service""")



# Generated at 2022-06-20 22:50:20.222996
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert not is_deactivating_service({'ActiveState': 'failed'})



# Generated at 2022-06-20 22:50:22.557390
# Unit test for function request_was_ignored
def test_request_was_ignored():
    request_was_ignored_true = request_was_ignored('Ignoring request xyz')
    assert request_was_ignored_true



# Generated at 2022-06-20 22:50:33.871063
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:52:17.201079
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': ''})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'activating_reloading'})
    assert not is_running_service({'ActiveState': 'activating_start'})



# Generated at 2022-06-20 22:52:18.973516
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('= did not ignore')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('= did not ignore command')



# Generated at 2022-06-20 22:52:30.673531
# Unit test for function main
def test_main():
    try:
        from ansible.module_utils.systemd import _common_args
    except:
        sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
        from ansible.module_utils.systemd import _common_args

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            pass

        def get_bin_path(self, name, required):
            return name

        def run_command(self, cmd, check_rc=False):
            return (0, "hello world", "")

    module = FakeModule(name='sshd', state='started', enabled=True)

    main()



# Generated at 2022-06-20 22:52:35.479480
# Unit test for function is_running_service
def test_is_running_service():
    ''' unit test for function is_running_service '''
    assert not is_running_service(dict(ActiveState='inactive'))
    assert is_running_service(dict(ActiveState='activating'))
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='reloading'))



# Generated at 2022-06-20 22:52:36.841445
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})



# Generated at 2022-06-20 22:52:41.712185
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Error Upstart job dbus failed to stop")
    assert request_was_ignored("Ignoring request to stop unit dbus.service")
    assert not request_was_ignored("Random text 123")



# Generated at 2022-06-20 22:52:44.964657
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={})
    result = main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-20 22:52:48.351140
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'failed'})



# Generated at 2022-06-20 22:52:53.596933
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Ensure that a single-line value is not interpreted as multi-line
    assert parse_systemctl_show(['Description={short desc}']) == {'Description': '{short desc}'}
    # Ensure that a multi-line value is interpreted as such. Note that even though the line endings
    # are CRLF here, the value should still be interpreted as multi-line.
    # 'ExecReload={ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',  # NOQA
    # 'ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ;

# Generated at 2022-06-20 22:53:06.425730
# Unit test for function parse_systemctl_show