

# Generated at 2022-06-20 22:45:53.405400
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:45:56.121492
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('Some string=with_equal')
    assert not request_was_ignored('Some string')
    assert request_was_ignored('Some string ignoring request')
    assert request_was_ignored('Some string ignoring command')



# Generated at 2022-06-20 22:45:56.878505
# Unit test for function main
def test_main():
    step_main()


# Generated at 2022-06-20 22:46:03.085977
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = 'Ignoring request to reload unit crond.service (via systemctl): Automatic reloading is disabled.'
    assert request_was_ignored(out) is True
    out = 'ignoring command'
    assert request_was_ignored(out) is True
    out = '/etc/cron.daily/logrotate'
    assert request_was_ignored(out) is False



# Generated at 2022-06-20 22:46:08.705193
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    data1 = {'ActiveState': 'active'}
    data2 = {'ActiveState': 'activating'}
    data3 = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(data1) is False
    assert is_deactivating_service(data2) is False
    assert is_deactivating_service(data3) is True



# Generated at 2022-06-20 22:46:19.214091
# Unit test for function is_running_service

# Generated at 2022-06-20 22:46:29.478503
# Unit test for function is_deactivating_service

# Generated at 2022-06-20 22:46:41.717889
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:46:46.428398
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': "deactivating"}) is True
    assert is_deactivating_service({'ActiveState': "activating"}) is False


# Generated at 2022-06-20 22:46:49.169635
# Unit test for function main
def test_main():
    unit_test_main(module_args={
        'name': 'test',
        'state': 'started',
        'enabled': True,

    })


# Generated at 2022-06-20 22:47:12.485318
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True
    assert is_deactivating_service({'ActiveState': 'active'}) == False
    assert is_deactivating_service({'ActiveState': 'activating'}) == False
    assert is_deactivating_service({'ActiveState': 'inactive'}) == False
    assert is_deactivating_service({'ActiveState': 'failed'}) == False


# Generated at 2022-06-20 22:47:13.824738
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for httpd.service failed.\n')
    assert not request_was_ignored('  Unit httpd.service could not be found.')



# Generated at 2022-06-20 22:47:24.903911
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([
        'Id=some.thing',
        'Description=Some thing',
        'ExecStart={',
        '  a',
        '  very',
        '  long',
        '  value',
        '}',
        'ExecReload={',
        '  another',
        '  long',
        '  value',
        '}',
    ]) == {
        'Id': 'some.thing',
        'Description': 'Some thing',
        'ExecStart': '{\n  a\n  very\n  long\n  value\n}',
        'ExecReload': '{\n  another\n  long\n  value\n}',
    }

# Generated at 2022-06-20 22:47:27.321960
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:47:30.210474
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-20 22:47:40.110474
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:47:49.189307
# Unit test for function main

# Generated at 2022-06-20 22:48:00.835711
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:09.936209
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:20.602729
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Accept a multi-line value for a key whose name starts with Exec
    parsed = parse_systemctl_show(['ExecStart=/usr/bin/docker-current daemon -H fd:// --exec-opt native.cgroupdriver=systemd\n    \\',
                                   '--live-restore'])
    assert parsed['ExecStart'] == '/usr/bin/docker-current daemon -H fd:// --exec-opt native.cgroupdriver=systemd\n    \\ --live-restore'
    # Accept a single-line value for a key whose name starts with Exec
    parsed = parse_systemctl_show(['ExecStart=/usr/bin/docker-current daemon -H fd:// --exec-opt native.cgroupdriver=systemd'])

# Generated at 2022-06-20 22:48:47.833272
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:48:51.724983
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('active')
    assert not request_was_ignored('< status active >')
    assert not request_was_ignored('< status activating >')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')



# Generated at 2022-06-20 22:48:54.758821
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert not request_was_ignored("somethingelse")
    assert not request_was_ignored("= somethingelse")



# Generated at 2022-06-20 22:49:00.940507
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:49:04.375198
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-20 22:49:06.826509
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': "deactivating"}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:49:12.604137
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignore\n')
    assert request_was_ignored('ignore\nbar')
    assert request_was_ignored('ignore\nbar\n')
    assert request_was_ignored('foo\nignore\nbar\n')
    assert request_was_ignored('foo\nignore\nbar')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo\n=\nbar')
    assert not request_was_ignored('foo\n=\nbar\n')
    assert not request_was_ignored('foo\n=')



# Generated at 2022-06-20 22:49:20.149702
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({
        'ActiveState': 'deactivating'
    })
    assert not is_deactivating_service({
        'ActiveState': 'inactive'
    })
    assert not is_deactivating_service({
        'ActiveState': 'active'
    })
    assert not is_deactivating_service({
        'ActiveState': 'activating'
    })



# Generated at 2022-06-20 22:49:26.104541
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert not is_deactivating_service({'ActiveState': 'failed'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-20 22:49:30.341713
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "active"}) is False
    assert is_deactivating_service({"ActiveState": "activating"}) is False
    assert is_deactivating_service({"ActiveState": "deactivating"})



# Generated at 2022-06-20 22:50:11.137215
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    orig = [
        'Id=foobar',
        'RefuseManualStart=no',
        'RefuseManualStop=no',
        'RemainAfterExit=no',
        'ExecStart={\npath=/bin/true ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0}',
        'ExecStop={\npath=/bin/true ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0}'
    ]

# Generated at 2022-06-20 22:50:13.219202
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-20 22:50:21.914244
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:26.111490
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {
        'ActiveState': 'active'
    }
    assert is_running_service(service_status)

    service_status['ActiveState'] = 'activating'
    assert is_running_service(service_status)


# Generated at 2022-06-20 22:50:35.602008
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:50:39.587029
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-20 22:50:45.446970
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'bla'})
    assert not is_running_service({'ActiveState': ''})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-20 22:50:51.291290
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(u'Job for httpd.service failed because the control process exited with error code.\nSee "systemctl status httpd.service" and "journalctl -xe" for details.')
    assert request_was_ignored(u'''Job for httpd.service failed.
See "systemctl status httpd.service" and "journalctl -xe" for details.
''')
    assert request_was_ignored(u'Job for httpd.service failed because a timeout was exceeded.\nSee "systemctl status httpd.service" and "journalctl -xe" for details.\nJob for httpd.service failed.')

# Generated at 2022-06-20 22:50:59.542850
# Unit test for function is_running_service
def test_is_running_service():
    result = {'ActiveState': 'active'}
    assert is_running_service(result) is True
    result = {'ActiveState': 'activating'}
    assert is_running_service(result) is True
    result = {'ActiveState': 'inactive'}
    assert is_running_service(result) is False
    result = {'ActiveState': 'deactivating'}
    assert is_running_service(result) is False
    result = {'ActiveState': 'unknown'}
    assert is_running_service(result) is False



# Generated at 2022-06-20 22:51:08.338845
# Unit test for function parse_systemctl_show

# Generated at 2022-06-20 22:52:32.934735
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines_01 = ['[Unit]', 'Description={Test service for systemctl module}', 'Requires=foo.service', 'After=foo.service', '', '[Service]', 'ExecStart=/bin/true', 'ExecReload=/bin/true', '', '[Install]', 'WantedBy=multi-user.target', '']

# Generated at 2022-06-20 22:52:37.189669
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request.')
    assert request_was_ignored('Ignoring command.')
    assert request_was_ignored(' Ignoring request.')
    assert not request_was_ignored('Stuff=Ignoring request.')
    assert not request_was_ignored(' Ignoring command!')



# Generated at 2022-06-20 22:52:50.111722
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import os.path
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import PY3
    import sys
    sys.path.insert(1, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from test.unit.service_test import FakeModule
    fake_module = FakeModule()
    fake_module.params = {}
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = fake_module.exit_json
    module.fail_json = fake_module.fail_json
    # Single-line Description=
    in_lines = StringIO('''Description=Test''')
    out_lines = StringIO()

# Generated at 2022-06-20 22:53:03.193203
# Unit test for function main
def test_main():
    local_args = dict(
        name="httpd",
        state="started",
        enabled=True,
        masked=False,
        daemon_reload=False,
        daemon_reexec=False,
        scope="system",
        no_block=False
    )

    # Skip the module execution

# Generated at 2022-06-20 22:53:10.306883
# Unit test for function is_running_service
def test_is_running_service():
    running_service = {'ActiveState': 'active',
                       'SubState': 'running'}
    activating_service = {'ActiveState': 'activating',
                          'SubState': 'activating'}
    not_active_service = {'ActiveState': 'inactive',
                          'SubState': 'not_running'}
    assert is_running_service(running_service)
    assert is_running_service(activating_service)
    assert not is_running_service(not_active_service)



# Generated at 2022-06-20 22:53:22.591863
# Unit test for function is_deactivating_service

# Generated at 2022-06-20 22:53:32.580988
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([
        'Id=crond.service',
        'Type=simple'
    ]) == {
        'Id': 'crond.service',
        'Type': 'simple',
    }
    assert parse_systemctl_show([
        'Id=crond.service',
        'Type=simple',
        'Description={',
        '  This is a description',
        '  that spans multiple lines',
        '}'
    ]) == {
        'Id': 'crond.service',
        'Type': 'simple',
        'Description': 'This is a description\nthat spans multiple lines'
    }

# Generated at 2022-06-20 22:53:38.727045
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'not-found'})


# Generated at 2022-06-20 22:53:47.706483
# Unit test for function main
def test_main():
    args = dict(
        name="foo",
        state="reloaded",
        enabled=True,
        force=True,
        masked=False,
        daemon_reload=False,
        daemon_reexec=False,
        scope="system",
        no_block=False,
        changed=True,
        status={},
        systemctl="/usr/bin/systemctl"
    )

    check_args(args)
    check_rc(1)

    with patch.object(AnsibleModule, 'run_command') as mock_run_command:
        mock_run_command.return_value = (1, "", "")
        # test with proper response
        with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
            main()
            mock_exit_json.assert_

# Generated at 2022-06-20 22:53:54.557818
# Unit test for function parse_systemctl_show