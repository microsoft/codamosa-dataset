

# Generated at 2022-06-11 08:08:28.324090
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Description=Something',
        'ExecStart=ExecStart',
        'ExecReload=ExecReload',
        'ExecStop=ExecStop',
        'ExecStopPost=ExecStopPost',
    ]
    assert parse_systemctl_show(lines) == {
        'Description': 'Something',
        'ExecStart': 'ExecStart',
        'ExecReload': 'ExecReload',
        'ExecStop': 'ExecStop',
        'ExecStopPost': 'ExecStopPost',
    }

# Generated at 2022-06-11 08:08:38.798766
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:51.200301
# Unit test for function main

# Generated at 2022-06-11 08:08:54.579405
# Unit test for function main
def test_main():
    pass
# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils._text import to_native

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:06.327628
# Unit test for function main

# Generated at 2022-06-11 08:09:14.491550
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_data = """[Unit]
Description=test

[Service]
ExecStart=/test
ExecReload=/test reload
  ExecRestart=/test restart
ExecStop=/test stop

[Install]
WantedBy=test.target
"""
    result = parse_systemctl_show(test_data.split('\n'))
    assert result['Description'] == 'test', 'Description should be test not %s' % result['Description']
    assert '\n' not in result['Description']
    assert result['ExecReload'] == '/test reload', 'ExecReload should be /test reload not %s' % result['ExecReload']
    assert '\n' not in result['ExecReload']
    assert result['ExecStart'] == '/test', 'ExecStart should be /test not %s' % result['ExecStart']

# Generated at 2022-06-11 08:09:25.235985
# Unit test for function main
def test_main():
    rc = 0
    out = 'ansible-systemd-test'
    err = 'This is a test for function main'


# Generated at 2022-06-11 08:09:36.273340
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:38.584830
# Unit test for function main
def test_main():
    pass


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:50.878718
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:10:09.562831
# Unit test for function main

# Generated at 2022-06-11 08:10:19.675122
# Unit test for function main
def test_main():
    unit = 'sshd'

# Generated at 2022-06-11 08:10:26.434952
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 08:10:28.857774
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')


# Generated at 2022-06-11 08:10:32.150123
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={'name': {'type': 'str'}, 'state': {'type': 'str'}})
    result = main()
    assert result

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:42.073936
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    """Simple unit test for function parse_systemctl_show"""
    # Single-line value
    assert parse_systemctl_show(['Description=foo']) == {"Description": "foo"}
    # Multi-line value
    assert parse_systemctl_show(['Description={', 'foo', '}']) == {"Description": "foo"}
    # Value that starts with { but doesn't end with }
    assert parse_systemctl_show(['Description={foo']) == {"Description": "{foo"}
    # Single line multi-line value
    assert parse_systemctl_show(['Description={foo}']) == {"Description": "foo"}
    # Test with multiline value, but not for a key starting with Exec
    assert parse_systemctl_show(['Description={foo', 'bar}']) == {"Description": "{foo\nbar}"}


# Generated at 2022-06-11 08:10:48.868456
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os
    import json
    import shutil

    argv = sys.argv
    sys.argv = sys.argv[:1]
    sys.argv.append('-vvvv')
    sys.argv.append('--force-handlers')
    sys.argv.append('--from- ansible')
    sys.argv.append('--ignore-deps=')
    sys.argv.append('--ignore-deps=0')
    sys.argv.append('--ignore_deps')
    sys.argv.append('--ignore_deps=0')

    test_path = os.path.dirname(os.path.abspath(__file__)) + os.sep + 'systest'

# Generated at 2022-06-11 08:11:00.392329
# Unit test for function main

# Generated at 2022-06-11 08:11:08.100585
# Unit test for function main
def test_main():
    # Reset the module
    arguments = module_args.copy()
    arguments['scope'] = 'system'
    arguments['name'] = 'httpd'
    arguments['enabled'] = False
    arguments['masked'] = None
    arguments['state'] = None
    arguments['force'] = False
    arguments['daemon_reload'] = False
    arguments['daemon_reexec'] = False

    # Reset the module
    module = AnsibleModule(
        argument_spec=arguments,
        supports_check_mode=True
    )

    # Run main.
    main()

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

main()

# Generated at 2022-06-11 08:11:19.350567
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    newline = "\n"
    # Sample output from systemctl show

# Generated at 2022-06-11 08:11:40.644192
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:11:43.927620
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['changed']


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:53.688894
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    params = {
        'name': "ansible",
        'enabled': True,
        'state': "started",
    }
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params = params
    module.run_command = lambda cmd: (0, cmd, '')
    module.run_command_environ_update = {}

    status = {}
    status['LoadState'] = 'loaded'
    status['ActiveState'] = 'active'
    module.check_mode = False

    main()


# include magic from lib/ansible/module_common.py
#<<INCLUDE_ANSIBLE_MODULE_COMMON>>

main()

# Generated at 2022-06-11 08:12:05.368685
# Unit test for function main
def test_main():
    from ansible.module_utils.systemd import AnsibleModule


# Generated at 2022-06-11 08:12:15.853994
# Unit test for function main
def test_main():
    global parse_systemctl_show

    module = AnsibleModule(argument_spec={})
    module.params['name'] = 'foo.service'
    # Check all paths for parse_systemctl_show
    lines = ['LoadState=loaded', 'ExecMainStatus=15', 'ExecMainStartTimestampMonotonic=123', '...']
    assert parse_systemctl_show(lines) == {'LoadState': 'loaded',
                                           'ExecMainStatus': '15',
                                           'ExecMainStartTimestampMonotonic': '123',
                                           '...': None}
    lines = ['LoadState=loaded']
    assert parse_systemctl_show(lines) == {'LoadState': 'loaded'}
    lines = ['LoadState=loaded', 'ExecStart=', '{', '  bla', '}']
   

# Generated at 2022-06-11 08:12:21.998860
# Unit test for function main
def test_main():

    with pytest.raises(SystemExit) as cm:
        main()
    assert cm.value.code == 0


# pylint: disable=redefined-builtin, unused-wildcard-import, wildcard-import, locally-disabled
# import module snippets.  This are required
if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-11 08:12:26.955056
# Unit test for function main
def test_main():
    from ansible.modules.system.systemd import main
    import pytest

    with pytest.raises(SystemExit) as cm:
        main()
    assert cm.value.code == 0


# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:30.403124
# Unit test for function main
def test_main():
    pass

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.local import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:40.142426
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:12:49.906542
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
                                             name = dict(type='str', aliases=['service', 'unit'])
                                            )
                            )

    unit = module.params['name']
    if unit is not None:
        for globpattern in (r"*", r"?", r"["):
            if globpattern in unit:
                module.fail_json(msg="This module does not currently support using glob patterns, found '%s' in service name: %s" % (globpattern, unit))

    systemctl = module.get_bin_path('systemctl', True)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:13:16.332109
# Unit test for function main

# Generated at 2022-06-11 08:13:24.777834
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:13:28.781178
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert {'A': 'B'} == parse_systemctl_show(['A=B'])
    assert {'A': 'B\nC'} == parse_systemctl_show(['A=B', 'C'])
    assert {'ExecA': 'B\nC'} == parse_systemctl_show(['ExecA=B', 'C'])



# Generated at 2022-06-11 08:13:38.048225
# Unit test for function main
def test_main():
    unit = 'sshd'
    state = 'started'
    enabled = True
    masked = False
    force = False
    daemon_reload = False
    daemon_reexec = False

    rc = 0
    out = err = ''

    args = dict(
        name=unit,
        state=state,
        enabled=enabled,
        masked=masked,
        force=force,
        daemon_reload=daemon_reload,
        daemon_reexec=daemon_reexec,
    )


# Generated at 2022-06-11 08:13:47.467244
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    module_mock = mock.MagicMock()

# Generated at 2022-06-11 08:13:48.455003
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-11 08:13:59.576291
# Unit test for function main

# Generated at 2022-06-11 08:14:08.029257
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    """
    Test parse_systemctl_show for cases in which there should be a single value
    and cases in which there should be a multi-line value
    """

    # Case where there should be a single value
    assert parse_systemctl_show(['Description=foo']) == {'Description': 'foo'}

    # Case where there should be a multi-line value
    assert parse_systemctl_show(['ExecStart={\n', '  foo\n', '  bar\n', '}\n']) == {'ExecStart': '{\n  foo\n  bar\n}'}
# End unit test for function parse_systemctl_show



# Generated at 2022-06-11 08:14:18.522806
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:20.408592
# Unit test for function main
def test_main():
    # Unit test are not implemented
    true = 1
    assert true == 1



# Generated at 2022-06-11 08:14:43.903059
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    t1 = parse_systemctl_show([
        "FirstKey=First Value",
        "SecondKey=Second Value",
        "Description=Description With a Line Break",
        "ExecStart={",
        "start",
        "end",
        "}",
        "ExecReload={",
        "reload",
        "end",
        "}",
        "FinalKey=Final Value"
    ])
    assert t1 == {
        'FirstKey': 'First Value',
        'SecondKey': 'Second Value',
        'Description': 'Description With a Line Break',
        'ExecStart': 'start\nend',
        'ExecReload': 'reload\nend',
        'FinalKey': 'Final Value'
    }



# Generated at 2022-06-11 08:14:54.449100
# Unit test for function main
def test_main():
    modules = {
        'systemctl': {
            'get_bin_path': lambda *args: '',
            'run_command': lambda *args, **kwargs: [0, '', ''],
            'fail_json': lambda *args, **kwargs: [0, '', ''],
            'warn': lambda *args, **kwargs: [0, '', ''],
        },
        'ansible_module_systemd': {
            'os': {
                'environ': {
                    'SYSTEMD_OFFLINE': '1'
                }
            }
        }
    }

    r = main(modules)
    assert r[0]['changed'] == False
    assert r[0]['enabled'] == False
    assert r[0]['state'] == 'started'

# import module snippets

# Generated at 2022-06-11 08:15:05.274558
# Unit test for function main
def test_main():
    import sys
    import json
    from ansible.module_utils.basic import *

    test_result = dict(
        changed=False,
        status=dict(),
        ansible_facts=dict()
    )

    test_result.update(dict(
        ansible_module_args=dict(
            name=None,
            state='reloaded',
            enabled=None,
            force=False,
            masked=None,
            daemon_reload=False,
            daemon_reexec=False,
            scope='system',
            no_block=False,
        )
    ))


# Generated at 2022-06-11 08:15:17.551406
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    import platform
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import builtins
    import ansible.module_utils.systemd_bin_path
    import os

    def get_bin_path(module, binary, required=True):
        if binary.endswith('systemctl'):
            return 'systemctl'
        else:
            # get_bin_path can't be stubbed when run unittest, only when called by systemctl_service
            return AnsibleModule.get_bin_path(module, binary, required)

    def get_distribution():
        return platform.dist()[0]

# Generated at 2022-06-11 08:15:18.822443
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:29.707261
# Unit test for function main
def test_main():
    # has to be done before module import
    os.environ['SYSTEMD_OFFLINE'] = '1'

    # mock function as we call sys.exit() beacuse of the return
    mock_module = MagicMock(exit_json=MagicMock())

    # mock some runtime vars
    mock_module.params = {
        'name': 'mock-unit.service',
        'state': 'reloaded',
        'enabled': False,
        'force': False,
        'masked': False,
        'daemon_reload': False,
        'daemon_reexec': False,
        'scope': 'system',
        'no_block': False,
    }

    # mock function as we call sys.exit() beacuse of the return

# Generated at 2022-06-11 08:15:39.839256
# Unit test for function main
def test_main():
    # Test module as a whole
    module_args = dict(
        daemon_reload=False,
        daemon_reexec=False,
        enabled=None,
        force=False,
        masked=None,
        name=None,
        no_block=False,
        scope='system',
        state=None
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    m_systemctl = MagicMock(return_value=True)
    m_run_command = MagicMock(return_value=(0, 'Sample text', ''))

# Generated at 2022-06-11 08:15:47.490182
# Unit test for function main

# Generated at 2022-06-11 08:15:56.666436
# Unit test for function main
def test_main():
    """
    Test for main function
    """
    try:
        del os.environ['SYSTEMD_OFFLINE']
    except KeyError:
        pass

    # Status of unit file
    rc, out, err = module.run_command("%s is-enabled '%s'" % (systemctl, unit))

    # Check is-enabled results
    if rc == 0:
        enabled = True
    elif rc == 1:
        enabled = False

    # Default to current state
    result['enabled'] = enabled

    # Change enable/disable if needed
    if enabled != module.params['enabled']:
        result['changed'] = True
        if not module.check_mode:
            (rc, out, err) = module.run_command("%s %s '%s'" % (systemctl, action, unit))
           

# Generated at 2022-06-11 08:16:05.784062
# Unit test for function main

# Generated at 2022-06-11 08:16:51.738715
# Unit test for function main
def test_main():
    # Mock the args dictionary
    args = dict(
        name = 'docker',
        state = 'stopped',
        enabled = True,
        force = False,
        masked = False,
        daemon_reload = False,
        daemon_reexec = False,
        scope = 'system',
        no_block = False
    )

    # Create a mock for the AnsibleModule class
    read_f_mock = mocker.patch('ansible.module_utils.basic.AnsibleModule.read_f')
    read_f_mock.return_value = fake_read_f()
    module_mock = mocker.patch('ansible.module_utils.basic.AnsibleModule')
    module_instance = module_mock.return_value
    module_instance.params = args
    # Add methods to

# Generated at 2022-06-11 08:16:58.590109
# Unit test for function main
def test_main():
    args = dict(
        name='mock_service',
        state='started',
        enabled=True,
        force=False,
        masked=False,
        daemon_reload=False,
        daemon_reexec=False,
        scope='system',
        no_block=False,
    )
    cmd_rc = dict()
    module_args = dict()
    service_status = dict()
    module = AnsibleModule(module_args)

    if module.params['name'] == 'mock_service':
        if module.params['state'] == 'started':
            cmd_rc['is_running'] = 0
            cmd_rc['is_enabled'] = 0
            cmd_rc['is_enabled_invalid'] = 1
            cmd_rc['is_enabled_init'] = 0

# Generated at 2022-06-11 08:17:09.213492
# Unit test for function main
def test_main():
    with open('tests/systemctl/test_main_default.json') as testdata:
        test_default = json.load(testdata)
    with open('tests/systemctl/test_main_started.json') as testdata:
        test_started = json.load(testdata)
    with open('tests/systemctl/test_main_stopped.json') as testdata:
        test_stopped = json.load(testdata)
    with open('tests/systemctl/test_main_restarted.json') as testdata:
        test_restarted = json.load(testdata)
    with open('tests/systemctl/test_main_reloaded.json') as testdata:
        test_reloaded = json.load(testdata)

# Generated at 2022-06-11 08:17:17.562179
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic
    import sys
    import platform
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.common.sys_info import system_info_data

    sysinfo = system_info_data()
    if platform.system() == 'HP-UX':
        sysinfo['systemctl'] = None
        sysinfo['init'] = '/sbin/init'
    else:
        sysinfo['systemctl'] = '/bin/systemctl'
        sysinfo['init'] = '/sbin/init'

    # We create a mock module

# Generated at 2022-06-11 08:17:23.792782
# Unit test for function main
def test_main():
    unit = 'httpd'

# Generated at 2022-06-11 08:17:32.579409
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = yaml.safe_load(open(sys.argv[0].replace('python', 'yaml')))
