

# Generated at 2022-06-11 08:08:08.918849
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['ExecStart=/bin/true']) == {'ExecStart': '/bin/true'}
    assert parse_systemctl_show(['ExecStart={', '/bin/true', '}']) == {'ExecStart': '/bin/true'}
    assert parse_systemctl_show(['ExecStart={', '  /bin/true', '}']) == {'ExecStart': '  /bin/true'}
    assert parse_systemctl_show(['ExecStart={', '  /bin/true', '  /bin/false', '}']) == {'ExecStart': '  /bin/true\n  /bin/false'}



# Generated at 2022-06-11 08:08:18.877364
# Unit test for function main
def test_main():
    # Define dictionaries for function input, output and desired result.
    function_input = dict(
        state = 'started',
        enabled = False,
        masked = False,
        daemon_reload = False,
        daemon_reexec = False,
        scope = 'system',
        no_block = False
    )

    # Define dictionary for error message if an error occurs.
    function_error = dict(
        rc = 1,
        output = 'Error',
        msg = 'Error Message'
    )

    # Define dictionary for expected function output.

# Generated at 2022-06-11 08:08:28.084769
# Unit test for function main

# Generated at 2022-06-11 08:08:38.541066
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.system.systemd import main

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, cmd):
            return (0, '', '')

        def get_bin_path(self, cmd, required=False):
            return '/bin/%s' % cmd

        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])

        def warn(self, msg):
            pass

        def exit_json(self, **kwargs):
            return

    cmd = ['systemctl', 'is-active', 'getty@tty1.service']

# Generated at 2022-06-11 08:08:50.920827
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # This test must be run from the system_service/library directory
    with open('unit_test_data/systemctl_show_output', 'r') as f:
        lines = f.readlines()
    parsed = parse_systemctl_show(lines)
    assert len(parsed) == 70

# Generated at 2022-06-11 08:08:54.165488
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = "● apache2.service: Ignoring request; unit has been stopped.\n"
    assert True is request_was_ignored(out)
    out = "● apache2.service: Ignoring command.\n"
    assert True is request_was_ignored(out)
    out = '● apache2.service: Loaded: loaded (/lib/systemd/system/apache2.service; enabled; vendor preset: enabled)\n'
    assert False is request_was_ignored(out)



# Generated at 2022-06-11 08:08:56.007189
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('whatever ignoring command')
    assert not request_was_ignored('= whatever')
    assert not request_was_ignored('= whatever ignoring command')



# Generated at 2022-06-11 08:08:59.780489
# Unit test for function main
def test_main():
    with open('/tmp/test.json', 'r') as f:
        module = AnsibleModule(json.load(f))

    rc = 0
    out = err = ''

    def _run_command(cmd):
        return (rc, out, err)

    module.run_command = _run_command
    module.warn = lambda *args, **kwargs: None
    module.fail_json = lambda *args, **kwargs: None

    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:10.565180
# Unit test for function main
def test_main():
    class TestingException(Exception): pass
    def apply_mocks(module, masks=None):
        def _apply_mocks(mod, masks):
            def _mock_run_command(self, *args, **kwargs):
                _rc = 0
                _out = _err = ""
                for _mask in masks:
                    if _mask[0] == 'run_command' and args == _mask[1]:
                        _rc = _mask[2]
                        _out = _mask[3]
                        _err = _mask[4]
                        break
                else:
                    pass
                return (_rc, _out, _err)
            def _mock_fail_json(self, *args, **kwargs):
                raise TestingException(args[0])

# Generated at 2022-06-11 08:09:21.868886
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:48.968380
# Unit test for function main
def test_main():
    import ansible.module_utils.systemd
    import sys
    mymod = sys.modules["ansible.module_utils.systemd"]
    import ansible.module_utils.basic
    import ansible.module_utils.six.moves.builtins
    mymod.AnsibleModule = ansible.module_utils.basic.AnsibleModule
    mymod.to_native = ansible.module_utils.six.moves.builtins.str
    mymod.parse_systemctl_show = lambda x: x
    mymod.AnsibleModule = lambda self, x: x
    x = mymod.main()
    assert x is not None

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:54.006364
# Unit test for function main
def test_main():
    with patch.object(AnsibleModule, "run_command") as run_mock:
        run_mock.return_value = (0, "", "")
        with patch.object(AnsibleModule, "get_bin_path") as get_mock:
            get_mock.return_value = "systemctl"
            main()



# Generated at 2022-06-11 08:10:06.049210
# Unit test for function main
def test_main():
    ''' Unit test for function main '''
    # Module params

# Generated at 2022-06-11 08:10:08.695020
# Unit test for function main
def test_main():
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:18.955524
# Unit test for function main
def test_main():

    #import platform
    #if platform.system() != "OpenBSD":
    #    pytest.skip("Ansible only works on OpenBSD")

    #pretend module_utils/shell.py argspec returns
    test_params = {
        'name': 'foo',
        'state': 'started',
        'enabled': True,
        'masked': False,
        'daemon_reload': False,
        'daemon_reexec': False,
        'scope': 'system',
        'no_block': False,
    }

    test_args = ["pam_mktemp", "RC=0", "STDOUT=garbage", "STDERR=garbage2"]

    test_result = dict(
        name='foo',
        changed=False,
        status=dict(),
    )

    testmodule = Ansible

# Generated at 2022-06-11 08:10:26.016399
# Unit test for function main
def test_main():
    # Mock function calls
    class MockModule(object):
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return "mock"

        @staticmethod
        def run_command(*args, **kwargs):
            return (0, "mock", "mock")

    module = MockModule()
    module.params = {
        'enabled': True,
        'masked': False,
        'name': "mock",
        'scope': "mock",
        'state': "mock"
    }
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs

    # Create test environment
    old_env = dict(os.environ)

# Generated at 2022-06-11 08:10:36.146475
# Unit test for function main
def test_main():
    '''Test for main'''
    # Mock module class
    class MockModule(object):
        '''Mock module'''
        def __init__(self):
            self.params = {'name': 'test', 'scope': 'system', 'daemon_reexec': False, 'enabled': None, 'daemon_reload': False, 'masked': None, 'state': None, 'force': False, 'no_block': False}
            self.result = {'enabled': False, 'changed': False, 'name': 'test', 'status': {'ActiveState': 'unknown', 'LoadError': 'no such file or directory', 'LoadState': 'not-found'}}
        def fail_json(self, *args, **kwargs):
            '''Fail json'''
            raise Exception('Execution failed')

# Generated at 2022-06-11 08:10:45.179670
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import systemctl

    from distutils.spawn import find_executable
    import os
    import datetime
    import random
    import string

    # ==================================================================
    # Helpers for generating random data for testing
    # ==================================================================
    # Generate random string of given length.
    #
    # @param length The length of the string.
    # @returns Random string.
    def randomString(length):
        return ''.join(random.choice(string.ascii_letters) for i in range(length))

    # Generate random string of given length, upper-case only.
    #
    # @param length The length of the string.
    # @returns Random upper-case string.

# Generated at 2022-06-11 08:10:47.633283
# Unit test for function main
def test_main():
    args = dict(
        name='foo',
        state='started',
    )
    retval = main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-11 08:10:58.854172
# Unit test for function main

# Generated at 2022-06-11 08:11:31.517374
# Unit test for function main
def test_main():
    assert 1 == 1


# Generated at 2022-06-11 08:11:40.187194
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test with a single-line value
    parsed = parse_systemctl_show('Description=The Apache HTTP Server'.split('\n'))
    assert len(parsed) == 1
    assert parsed['Description'] == 'The Apache HTTP Server'

    # Test with a multi-line value
    parsed = parse_systemctl_show('ExecStart=\n  ExecStart=/usr/sbin/httpd $OPTIONS -DFOREGROUND'.split('\n'))
    assert len(parsed) == 1
    assert parsed['ExecStart'] == 'ExecStart=/usr/sbin/httpd $OPTIONS -DFOREGROUND'

    # Test with a multi-line value that gets split in the middle of a line

# Generated at 2022-06-11 08:11:49.177952
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import BOOLEANS

    import sys
    if sys.version_info[0] < 3:
        from mock import patch
    else:
        from unittest.mock import patch

    def read_stderr(path):
        return "Failed to parse bus message: Warning: the unit file, source configuration file or drop-ins of {}, is not a valid unit file. Ignoring.".format(path)

    def read_stdout_failed(path):
        return "".format(path)



# Generated at 2022-06-11 08:12:00.702764
# Unit test for function main
def test_main():
    data = dict(
        name=None,
        state=None,
        enabled=None,
        force=True,
        masked=None,
        daemon_reload=True,
        daemon_reexec=True,
        scope='system',
        no_block=False,
    )

    temp_args = dict()
    for key in data:
        temp_args[key] = data[key]

    temp_args['name'] = 'crond.service'
    main(temp_args)

    temp_args = dict()
    for key in data:
        temp_args[key] = data[key]

    temp_args['state'] = 'started'
    main(temp_args)

    temp_args = dict()
    for key in data:
        temp_args[key] = data[key]



# Generated at 2022-06-11 08:12:12.295442
# Unit test for function main

# Generated at 2022-06-11 08:12:21.322911
# Unit test for function main
def test_main():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible.module_utils.basic import AnsibleModule
    with patch.dict(os.environ, {'XDG_RUNTIME_DIR': '/run/user/1'}):
        module = AnsibleModule(dict(name='test_unit'), False)
        with patch.object(module, 'run_command') as rc:
            rc.return_value = (0, '', '')
            main()
            rc.assert_called_with(module.get_bin_path('systemctl', True) + " show 'test_unit'", check_rc=True)


# Generated at 2022-06-11 08:12:23.317470
# Unit test for function main
def test_main():
  return possible_systemctl_commands


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:34.593186
# Unit test for function main

# Generated at 2022-06-11 08:12:38.928941
# Unit test for function main
def test_main():
    print("no unit tests")
    
# import module snippets
if __name__ == '__main__':
    test_main()
else:
    from ansible.module_utils.basic import *
    from ansible.module_utils.six import iteritems, itervalues
    from ansible.module_utils._text import to_native
    main()

# Generated at 2022-06-11 08:12:49.017452
# Unit test for function main
def test_main():
    with patch.object(sys, 'argv', ['systemd', '-m', 'systemd', '-a', 'name="foo"', '-a', 'enabled=yes', '-a', 'state=started', '-a', 'daemon_reload=yes']):
        unit = sys.modules['__main__']
        unit.main()

    print (unit.executed_command)
    print (unit.result['status'])
    assert unit.result['status']['LoadState'] == 'loaded'
    assert unit.result['status']['ActiveState'] == 'active'

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:19.708104
# Unit test for function main
def test_main():
    """
    Unit test for main()
    """

# Generated at 2022-06-11 08:14:30.050610
# Unit test for function main

# Generated at 2022-06-11 08:14:40.502860
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 08:14:51.535601
# Unit test for function main
def test_main():
    import json
    import sys
    import tempfile

    with tempfile.TemporaryDirectory() as tempdir:
        sys.path.insert(0, tempdir)
        # create a test module to add to loader
        test_module_path = os.path.join(tempdir, 'ansible_module_service.py')
        with open(test_module_path, 'w') as test_module:
            test_module.write('#!/usr/bin/python1\nimport json\nresult={"ansible_facts": {"a": "b"}}\nprint(json.dumps(result))\n')
        # create a test plugin to add to loader
        test_plugin_path = os.path.join(tempdir, 'test_service.py')

# Generated at 2022-06-11 08:14:58.712713
# Unit test for function main
def test_main():
    unit = 'docker.service'
    state = 'started'
    enabled = 'True'
    force = 'True'
    masked = 'False'
    daemon_reload = 'True'
    daemon_reexec = 'True'
    scope = 'system'
    no_block = 'False'

# Generated at 2022-06-11 08:15:01.336517
# Unit test for function main
def test_main():
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:14.403689
# Unit test for function main
def test_main():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.misc.not_a_real_collection.plugins.modules import systemd

# Generated at 2022-06-11 08:15:24.447378
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:15:35.175992
# Unit test for function main
def test_main():
    unit = 'crond'
    state = 'stopped'
    enabled = False
    force = False
    masked = True
    daemon_reload = False
    daemon_reexec = False
    scope = 'system'
    no_block = False

# Generated at 2022-06-11 08:15:43.350155
# Unit test for function main