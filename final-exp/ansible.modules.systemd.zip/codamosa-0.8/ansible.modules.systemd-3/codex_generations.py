

# Generated at 2022-06-11 08:08:39.596196
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_me = {}
        test_me['name'] = 'cron'
        test_me['state'] = 'started'
        test_me['enabled'] = True 
        test_me['masked'] = False 
        test_me['daemon_reload'] = False 
        test_me['daemon_reexec'] = False 
        test_me['scope'] = 'system'
        test_me['no_block'] = False
        test_main = main(test_me)
        print(test_main)

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.urls import *

main()

# Generated at 2022-06-11 08:08:52.128679
# Unit test for function main
def test_main():
    from ansible.module_utils.systemd import main as systemd_main
    from ansible.modules.system import systemd

    ignore_error = False
    value = None
    state = None
    changed = False

    # Case 1: state == started and is_running_service == True
    state = "started"
    systemd.is_running_service = MagicMock(return_value=True)
    systemd_main()
    # Check whether the function call is correct or not
    assert systemd.is_running_service.call_count == 1

    # Case 2: state == started and is_running_service == False
    state = "started"
    systemd.is_running_service = MagicMock(return_value=False)
    systemd_main()
    # Check whether the function call is correct or not
    assert systemd.is_running_

# Generated at 2022-06-11 08:09:04.028654
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:13.315740
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:24.176200
# Unit test for function main
def test_main():
    #test for determine_service_start_mode
    assert determine_service_start_mode(['local-fs.target']) == 'enabled'
    assert determine_service_start_mode(['local-fs.target', 'sockets.target']) == 'enabled'
    assert determine_service_start_mode(['local-fs.target', 'sockets.target', 'basic.target']) == 'enabled'
    assert determine_service_start_mode(['local-fs.target', 'sockets.target', 'basic.target', 'swap.target']) == 'enabled'
    assert determine_service_start_mode(['local-fs.target', 'sockets.target', 'basic.target', 'swap.target', 'paths.target']) == 'enabled'

# Generated at 2022-06-11 08:09:26.265158
# Unit test for function main
def test_main():
    with pytest.raises(Exception):
        main()

# import module snippets
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:37.460564
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:49.736602
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:58.360314
# Unit test for function main
def test_main():
    import os
    import sys
    import test.lib_throwaway
    testlib = os.path.join(os.path.dirname(__file__), 'test/lib_throwaway')
    if testlib not in sys.path:
        sys.path.append(testlib)
    from ansible_module_systemd import *
    del sys.path[-1]
    del test.lib_throwaway
    test_unit = "ansible_module_systemd"
    unit = "network.target"

# Generated at 2022-06-11 08:10:07.945083
# Unit test for function main
def test_main():
    args = dict(
        name='auditd',
        state='stopped',
        enabled=True,
        force=True,
        masked=False,
        daemon_reload=False,
        daemon_reexec=False,
        scope='system',
        no_block=False,
    )
    result = dict(
        name='auditd',
        changed=False,
        status=dict(),
    )
    module = AnsibleModule(argument_spec={})
    service = ServiceMgr(module)
    service.unit = args['name']
    service.systemctl = '/usr/bin/systemctl'
    service.scope = args['scope']
    service.no_block = args['no_block']
    service.force = args['force']


# Generated at 2022-06-11 08:10:39.379894
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    m = AnsibleModule(argument_spec={'name': {'type': 'str'}, 'enabled': {'type': 'bool', 'default': True}})
    result = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:40.912591
# Unit test for function main
def test_main():
    # Setup test environment
    module = AnsibleModule(argument_spec={})
    module.params = {'state': 'stopped'}

    # Test the main function
    main()


# Generated at 2022-06-11 08:10:48.205393
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec={
            'name': dict(type='str'),
        },
        supports_check_mode=True,
    )

    ''' Set CLI options depending on params '''
    module.get_bin_path('systemctl', True, ['/bin', '/usr/bin/'])

    if os.getenv('XDG_RUNTIME_DIR') is None:
        os.environ['XDG_RUNTIME_DIR'] = '/run/user/%s' % os.geteuid()

    result = dict(
        changed=False,
        status=dict(),
    )

    # Run daemon-reload first, if requested
    module.run_command("%s daemon-reload" % (systemctl), check_rc=True)

    # Run daemon-reex

# Generated at 2022-06-11 08:10:59.589998
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:11:03.426007
# Unit test for function main
def test_main():
    yamlfile = dict()
    (rc, out, err) = testmod(module_args=yamlfile)
    assert rc == 0
    assert out == ''
    assert err == ''

# Unit tests for function sysv_exists

# Generated at 2022-06-11 08:11:07.624774
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('status=0')
    assert not request_was_ignored('= status=0')



# Generated at 2022-06-11 08:11:18.918678
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:11:22.258077
# Unit test for function main
def test_main():

    result = {
        "name": "nfs-server",
        "changed": True,
        "status": {
            "LoadState": "loaded",
            "ActiveState": "active",
            "SubState": "running",
            "UnitFileState": "enabled",
            "Description": "NFS server and services"
        }
    }
    return result

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:33.013101
# Unit test for function main

# Generated at 2022-06-11 08:11:41.018380
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', aliases=['service', 'unit']),
            enabled=dict(type='bool', default=None),
            state=dict(type='str', default=None, choices=['reloaded', 'restarted', 'started', 'stopped']),
            forced=dict(type='bool', default=None),
            masked=dict(type='bool', default=None),
        ),
        required_one_of=[['state', 'enabled', 'masked', 'daemon_reload', 'daemon_reexec']],
        required_by=dict(
            state=('name', ),
            enabled=('name', ),
            masked=('name', ),
        ),
    )
    main()


# Generated at 2022-06-11 08:12:05.669803
# Unit test for function main
def test_main():
   assert main(unit=None, msg="Test") == 0
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:16.081895
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Description=Multi-User System', 'Wants=remote-fs.target', '', 'Conflicts=shutdown.target']) == {
        'Description': 'Multi-User System',
        'Wants': 'remote-fs.target',
        'Conflicts': 'shutdown.target',
        }
    assert parse_systemctl_show(['Description=Description goes here', '']) == {
        'Description': 'Description goes here',
        }

# Generated at 2022-06-11 08:12:24.497416
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([
        'key1=value1',
        'key2=one\ntwo',
        'key3={',
        'one\ntwo\nthree',
        '}',
        'key4={',
        'one\ntwo\nthree',
        '}',
    ]) == {
        'key1': 'value1',
        'key2': 'one\ntwo',
        'key3': 'one\ntwo\nthree',
        'key4': 'one\ntwo\nthree',
    }



# Generated at 2022-06-11 08:12:35.871131
# Unit test for function main

# Generated at 2022-06-11 08:12:37.214174
# Unit test for function main
def test_main():
  pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:48.846741
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    parsed = parse_systemctl_show(["Description=Long single-line value {starting {with {braces",
                                   "and } broken up } across lines"])
    assert parsed == {'Description': 'Long single-line value {starting {with {braces\nand } broken up } across lines'}
    parsed = parse_systemctl_show(["ExecStart=/usr/local/bin/foo { --with=option",
                                   "--and=another }",
                                   "Description=Single-line value with {braces but no } ending brace"])
    assert parsed == {'Description': 'Single-line value with {braces but no } ending brace',
                      'ExecStart': '/usr/local/bin/foo { --with=option\n--and=another }'}



# Generated at 2022-06-11 08:12:55.351255
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:13:03.185225
# Unit test for function main

# Generated at 2022-06-11 08:13:11.848211
# Unit test for function main

# Generated at 2022-06-11 08:13:20.695620
# Unit test for function main
def test_main():
    # Test without parameters
    module = AnsibleModule(
        argument_spec = dict(
            name = dict(type='str'),
        ),
        supports_check_mode=True,
    )
    unit = 'sshd'

    systemctl = module.get_bin_path('systemctl', True)

    rc = 0
    out = err = ''
    result = dict(
        name=unit,
        changed=False,
        status=dict(),
    )

    # check service data, cannot error out on rc as it changes across versions, assume not found
    (rc, out, err) = module.run_command("%s show '%s'" % (systemctl, unit))


# Generated at 2022-06-11 08:13:52.541213
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:01.281052
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:11.560100
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:21.806846
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:32.440222
# Unit test for function main
def test_main():
    from ansible.module_utils.systemd.systemctl import is_initd
    from ansible.module_utils.systemd import sysv_is_enabled
    from ansible.module_utils.systemd import sysv_exists
    
    unit = 'sshd'
    module_params = dict(
        name=unit,
        state=None,
        enabled=None,
        force=False,
        masked=None,
        daemon_reload=False,
        daemon_reexec=False,
        scope='system',
        no_block=False,
    )
    module = AnsibleModule(**module_params)
    
    module.run_command = MagicMock(side_effect=run_command_side_effect)
    module.warn = MagicMock()
    module.fail_json = MagicM

# Generated at 2022-06-11 08:14:43.527098
# Unit test for function main
def test_main():
    mf = ModuleTestFramework()
    # Load AnsibleModule and define parameters
    module = mf.get_module_from_file(INPUT_FILE, {'state': 'reloaded', 'name': 'crond.service'})

    # Mock functions we can test
    mf.mock_module_helper()
    mf.mock_run_command()

    # Use the mock defined outputs to the ansible module function

# Generated at 2022-06-11 08:14:54.173409
# Unit test for function main

# Generated at 2022-06-11 08:14:56.163604
# Unit test for function main
def test_main():
    pass

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:07.417731
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:15:18.833055
# Unit test for function main
def test_main():
    unit = 'test'
    systemctl = 'test'

# Generated at 2022-06-11 08:15:53.784007
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:16:03.018121
# Unit test for function main

# Generated at 2022-06-11 08:16:11.932014
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    import json
    import os

    unit = 'test_service_not_running'


# Generated at 2022-06-11 08:16:20.625548
# Unit test for function main

# Generated at 2022-06-11 08:16:28.534568
# Unit test for function main
def test_main():
    spec = dict(
        name=dict(type='str', default="test"),
        state=dict(type='str', default="test"),
        enabled=dict(type='bool', default=False),
        force=dict(type='bool', default=False),
        masked=dict(type='bool', default=False),
        daemon_reload=dict(type='bool'),
        daemon_reexec=dict(type='bool'),
        scope=dict(type='str', default='system'),
        no_block=dict(type='bool', default=False),
    )
    module = AnsibleModule(argument_spec=spec)
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 08:16:36.887953
# Unit test for function main

# Generated at 2022-06-11 08:16:45.577154
# Unit test for function main

# Generated at 2022-06-11 08:16:54.214128
# Unit test for function main
def test_main():
    module = ansible_module_get()

# Generated at 2022-06-11 08:17:03.189372
# Unit test for function main
def test_main():
    test_params = dict(
        name='sshd',
        state=None,
        enabled=None,
        masked=None,
        daemon_reload=False,
        daemon_reexec=False,
        force=False,
        no_block=None,
        scope='system'
    )


# Generated at 2022-06-11 08:17:13.121148
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule as am