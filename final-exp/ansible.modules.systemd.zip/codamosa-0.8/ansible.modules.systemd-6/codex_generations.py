

# Generated at 2022-06-11 08:08:01.586944
# Unit test for function main

# Generated at 2022-06-11 08:08:03.255243
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('foo')
    assert request_was_ignored('bar ignoring')
    assert request_was_ignored('ignoring foo')
    assert not request_was_ignored('= foo')
    assert not request_was_ignored('foo bar')



# Generated at 2022-06-11 08:08:08.831337
# Unit test for function main
def test_main():
    import imp
    import os
    import shutil
    import tempfile
    import traceback

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock, patch
    from ansible_collections.notstdlib.moveitallout.plugins.modules import systemd

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs

# Generated at 2022-06-11 08:08:18.766853
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:28.003095
# Unit test for function main
def test_main():

    def _get_test_service_name():
        test_service_name = "test.service"
        if os.path.exists("/etc/systemd/system/" + test_service_name):
            return test_service_name
        else:
            return "systemd-sysctl.service"

    # patch AnsibleModule
    sys.path.append(os.path.join(os.path.dirname(__file__), '../unit/'))
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class AnsiblePatch(object):
        def __init__(self, module):
            self.module = module

    def AnsibleModule(*args, **kwargs):
        return AnsiblePatch(basic.AnsibleModule(*args, **kwargs))

   

# Generated at 2022-06-11 08:08:31.636656
# Unit test for function main
def test_main():
    assert main() is None

# Run unit test
if __name__ == '__main__':
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    unittest.main()

# Generated at 2022-06-11 08:08:41.253810
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:53.920394
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Unit test for function parse_systemctl_show
    assert {
        'ExecStart': '{ path=/bin/sh ; argv[]=/bin/sh -c echo "this is a test" ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
        'Description': 'Test description',
    } == parse_systemctl_show([
        'ExecStart={ path=/bin/sh ; argv[]=/bin/sh -c echo "this is a test" ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
        'Description=Test description',
    ])

# Generated at 2022-06-11 08:08:59.295422
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:10.232007
# Unit test for function main
def test_main():
    # Setup
    unit='sshd'

# Generated at 2022-06-11 08:09:29.126913
# Unit test for function main
def test_main():
    result = main()
    assert result is None


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:09:40.341324
# Unit test for function main
def test_main():
    import sys

# Generated at 2022-06-11 08:09:52.471849
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:59.921025
# Unit test for function main

# Generated at 2022-06-11 08:10:08.825273
# Unit test for function main
def test_main():
    globalRC = 0
    globalOut = ''
    globalErr = ''

    class AnsibleModuleMock_main():
        def __init__(self):
            self.params = {
                'name': 'ALL',
                'state': 'reloaded',
                'enabled': True,
                'masked': None,
                'daemon_reload': False,
                'daemon_reexec': False,
                'scope': 'system',
                'no_block': False,
            }
            self.result = dict(
                changed=False,
            )

        def exit_json(self, **kwargs):
            global globalRC
            global globalOut
            global globalErr
            globalRC = 0
            globalOut = ''
            globalErr = ''

# Generated at 2022-06-11 08:10:19.146293
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_count = 0
    test_count += 1
    test_data = '''
Description=Some
service
'''
    expected = {'Description':'Some\nservice'}
    actual = parse_systemctl_show(test_data.split('\n'))
    if actual != expected:
        print('test %d: failed' % (test_count,))
        print('expected: %s' % (expected,))
        print('actual: %s' % (actual,))
    test_count += 1
    test_data = '''
Description={Some
service}
'''
    expected = {'Description':'{Some\nservice}'}
    actual = parse_systemctl_show(test_data.split('\n'))

# Generated at 2022-06-11 08:10:26.152068
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test a simple non-multiline value
    val = parse_systemctl_show(['foo=bar\n'])
    assert val == {'foo': 'bar'}

    # Test a multiline value for a key whose name does not start with Exec
    val = parse_systemctl_show(['foo={\n', '  k=v\n', '}\n'])
    assert val == {'foo': '{ k=v }'}

    # Test a non-multiline value for a key whose name does start with Exec
    val = parse_systemctl_show(['ExecStart=foo\n'])
    assert val == {'ExecStart': 'foo'}

    # Test a multiline value for a key whose name does start with Exec

# Generated at 2022-06-11 08:10:36.326916
# Unit test for function main
def test_main():
    testunit = 'network'
    testrc = 0
    testout = 'Lorem Ipsum'
    def test_run_command(args, check_rc=True):
        # set default return
        return testrc, testout, ''

# Generated at 2022-06-11 08:10:45.314428
# Unit test for function main

# Generated at 2022-06-11 08:10:48.103026
# Unit test for function main
def test_main():
    args = dict(
        daemon_reexec=True,
    )
    with pytest.raises(AnsibleFailJson):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:27.313167
# Unit test for function main

# Generated at 2022-06-11 08:11:36.822606
# Unit test for function main
def test_main():
    with mock.patch("systemd.main.AnsibleModule", autospec=True) as mock_ansible_module:
        main()
        assert mock_ansible_module.run_command.call_count == 7
        assert mock_ansible_module.run_command.call_args_list == [
            mock.call('systemctl daemon-reload'),
            mock.call('systemctl daemon-reexec'),
            mock.call("systemctl show 'httpd'"),
            mock.call("systemctl is-enabled 'httpd'"),
            mock.call("systemctl is-enabled 'httpd'"),
            mock.call("systemctl start 'httpd'"),
            mock.call("systemctl is-enabled 'httpd'"),
        ]


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:48.099913
# Unit test for function main
def test_main():
    print("unit test for function main")
    unit_test_values = {
        'main': {
            'params': {
                'name': None,
                'state': None,
                'enabled': None,
                'force': None,
                'masked': False,
                'daemon_reload': False,
                'scope': 'system',
                'no_block': False,
            },
        },
    }
    ansible_module = AnsibleModule(argument_spec=unit_test_values['main']['params'])
    print(ansible_module.check_mode)
    ansible_module.run_command = MagicMock()
    ansible_module.exit_json = MagicMock()
    print(ansible_module.check_mode)
    main()


# Generated at 2022-06-11 08:11:59.670324
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.system.systemd import _get_bin_path
    import tempfile
    (osf, systemd_path) = tempfile.mkstemp(dir='/usr/bin')
    os.chmod(systemd_path, 0o755)
    os.write(osf, b'#!/bin/sh\n')
    os.write(osf, b'case $1 in daemon-reload)\n case $2 in \'-q\') exit 0;\n esac;\n esac')
    os.write(osf, b'case $1 in daemon-reexec)\n case $2 in \'-q\') exit 0;\n esac;\n esac')

# Generated at 2022-06-11 08:12:11.164733
# Unit test for function main
def test_main():
    import shutil
    import os
    sys.path.append('../test')
    import system_unit_stub

    def test_stub_run_command(self, cmd, check_rc=False, close_fds=True):
        if cmd == 'systemctl reload sshd':
            return(2, "", "No shells found in /etc/shells")
        elif cmd == 'systemctl restart sshd':
            return(1, "", "Failed to restart sshd.service: Unit sshd.service not found.")
        else:
            return(0, "", "")

    def test_stub_chk_chroot(self):
        return False

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str'),
            state=dict(type='list'),
        )
    )

# Generated at 2022-06-11 08:12:19.123675
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("""
Job for test.service failed because the control process exited with error code.
See "systemctl status test.service" and "journalctl -xe" for details.
""")
    assert request_was_ignored("""
Job for test.service failed because the control process exited with error code.
See 'systemctl status test.service' and 'journalctl -xe' for details.
""")
    assert request_was_ignored("""
Job for test.service failed because the control process exited with error code.
See "systemctl status test.service" and 'journalctl -xe' for details.
""")
    assert request_was_ignored("""
Job for test.service failed because the control process exited with error code.
See 'systemctl status test.service' and "journalctl -xe" for details.
""")

# Generated at 2022-06-11 08:12:30.508764
# Unit test for function main
def test_main():
    print("Test main")

# Generated at 2022-06-11 08:12:40.225344
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test = '''
[Unit]
Description=XXX

[Service]
ExecStart=
{
  command
}
'''.strip()
    result = parse_systemctl_show(test.split('\n'))
    assert result['Description'] == 'XXX'
    assert result['ExecStart'] == '''
{
  command
}'''.strip()
    test = '''
[Unit]
Description=
{
  multiline
}
'''.strip()
    result = parse_systemctl_show(test.split('\n'))
    assert result['Description'] == '''
{
  multiline
}'''.strip()
    test = '''
[Unit]
Description=
{
  multiline
  multiline
}
'''.strip()

# Generated at 2022-06-11 08:12:44.585343
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('some text')
    assert request_was_ignored('some text ignoring request')
    assert request_was_ignored('some text ignoring command')
    assert not request_was_ignored('some = text')



# Generated at 2022-06-11 08:12:48.124234
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Job for dnf-automatic.timer failed because the control process exited with error code. See \"systemctl status dnf-automatic.timer\" and \"journalctl -xe\" for details.")



# Generated at 2022-06-11 08:13:43.140264
# Unit test for function main
def test_main():
    """
    Changed: [localhost] => {
            "changed": true,
            "name": "chrony",
            "state": "started"
        }
        [root@goat systemd]# systemctl is-enabled chrony
        enabled
        [root@goat systemd]#
    """
    global module

# Generated at 2022-06-11 08:13:54.364097
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:02.167859
# Unit test for function main
def test_main():
    response = {}

# Generated at 2022-06-11 08:14:12.527528
# Unit test for function main
def test_main():
    mod = AnsibleModule({
        'id': 'myid',
        'name': 'myname',
        'state': "reloaded",
        'enabled': False,
        'force': True,
        'masked': False,
        'daemon_reload': False,
        'daemon_reexec': False,
        'scope': 'system',
        'no_block': False,

    })
    set_module_args(mod)
    main()

if __name__ == '__main__':
    main()

# Unit test.
# python -m pytest -s -v -t . -k test_main
# python -m pytest -s -v -t . -k test_systemctl_show
# python -m pytest -s -v -t . -k test_parse_systemctl_

# Generated at 2022-06-11 08:14:22.492606
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:32.932428
# Unit test for function main
def test_main():

    # Test no action
    #################
    class MockModule(object):
        pass

    module = MockModule()
    module.get_bin_path = MagicMock(return_value='/bin/systemctl')
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.fail_json = MagicMock(side_effect=Exception("fail_json was called"))

    module.params = dict(
        name='foo',
        state=None,
        enabled=None,
        masked=None,
        daemon_reload=False,
        daemon_reexec=False,
        force=False,
        scope='system',
        no_block=None,
    )


# Generated at 2022-06-11 08:14:44.060971
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def assert_parse(inlines, expected):
        assert parse_systemctl_show(inlines.splitlines()) == expected

    # Simple key=value
    assert_parse('foo=bar', {'foo': 'bar'})

    # Single-line values that start with { but do not end with } should not be
    # treated as multi-line values
    assert_parse('foo={bar', {'foo': '{bar'})

    # Multi-line values should be accepted for keys whose names start with Exec
    assert_parse('ExecStart={foo\nbar}', {'ExecStart': 'foo\nbar'})

    # All lines must be consumed
    assert_parse('ExecStart={foo\nbar\nbaz', {'ExecStart': 'foo\nbar\nbaz'})

# Generated at 2022-06-11 08:14:54.598214
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:15:05.433805
# Unit test for function main

# Generated at 2022-06-11 08:15:17.658402
# Unit test for function main
def test_main():
    ''' Unit tests for the main function '''

# Generated at 2022-06-11 08:16:31.779562
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json

# Generated at 2022-06-11 08:16:40.261790
# Unit test for function main

# Generated at 2022-06-11 08:16:48.943385
# Unit test for function main

# Generated at 2022-06-11 08:16:56.834315
# Unit test for function main
def test_main():
    sys.argv = ['']

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()

    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # test required_one_of
    sys.argv = dict(name='abcd',
                    state='started',
                    enabled=True,
                    masked=True,
                    daemon_reload=True,
                    daemon_reexec=True,)

    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()

    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1

    # test required_by.state

# Generated at 2022-06-11 08:17:07.731518
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:17:15.087437
# Unit test for function main
def test_main():

    class Args(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    # Arrange
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    module.exit_json = MagicMock()


    args = Args(
        name = None,
        state = None,
        enabled = None,
        force = False,
        masked = None,
        daemon_reload = False,
        daemon_reexec = False,
        scope = 'system',
        no_block = False,
    )

    main()
    # Assert
    assert module.exit_json.called


# Generated at 2022-06-11 08:17:22.448385
# Unit test for function main
def test_main():
    unit = 'test_main_unit'

# Generated at 2022-06-11 08:17:31.196414
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # This is a multi-line value that is known to span multiple lines
    lines = ['ExecMainPID=345', 'ExecMainStartTimestamp=Thu 2016-10-06 10:50:13 EDT']
    assert parse_systemctl_show(lines) == {'ExecMainPID': '345', 'ExecMainStartTimestamp': 'Thu 2016-10-06 10:50:13 EDT'}

    # This is a multi-line value with a missing close bracket
    lines = ['ExecMainPID=345', 'ExecMainStartTimestamp=Thu 2016-10-06 10:50:13 EDT', 'ExecStart={ path=/bin/systemctl start foo.service']