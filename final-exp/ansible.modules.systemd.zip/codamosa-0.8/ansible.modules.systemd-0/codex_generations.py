

# Generated at 2022-06-11 08:08:03.647702
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:12.357885
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:13.644711
# Unit test for function main
def test_main():
    print(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:08:16.548678
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('something else')



# Generated at 2022-06-11 08:08:24.655770
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring request "foobar"')
    assert request_was_ignored('ignoring request foobar')
    assert request_was_ignored('ignoring request "foobar', '"')
    assert not request_was_ignored('= something/something')
    assert not request_was_ignored('to do something/something')
    assert not request_was_ignored('ignoring request"foobar')
    assert not request_was_ignored('ignoring request foo bar')
    assert not request_was_ignored('ignoring command foo bar')



# Generated at 2022-06-11 08:08:34.956251
# Unit test for function main
def test_main():
    """
    This is a unit test for testing main
    """

    # initialize

# Generated at 2022-06-11 08:08:46.420665
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:48.002529
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request, a start is pending")
    assert not request_was_ignored("something else")
    assert not request_was_ignored("failing at=start")



# Generated at 2022-06-11 08:09:00.229599
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    parsed = parse_systemctl_show([
        'Id=crond.service',
        'Description={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
        '',
        'WantedBy=multi-user.target',
        '',
        'Wants=system.slice',
    ])
    assert parsed['WantedBy'] == 'multi-user.target'
    assert parsed['Wants'] == 'system.slice'
    assert parsed['Id'] == 'crond.service'

# Generated at 2022-06-11 08:09:02.620615
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(' ')
    assert request_was_ignored('=' * 80)
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('ignoring requests')
    assert not request_was_ignored('ignoring commands')



# Generated at 2022-06-11 08:09:28.389903
# Unit test for function main
def test_main():

    import os
    import tempfile


# Generated at 2022-06-11 08:09:39.652865
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:42.120415
# Unit test for function main
def test_main():
    assert main() is None
# Run tests
if __name__ == '__main__':
    test_main()
    sys.exit(main())

# Generated at 2022-06-11 08:09:53.945886
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = ["foo=bar", "baz=quux", 'ExecStart=/bin/bash -c "echo Hello World"', "ExecStart2=this is really ExecStart"]
    assert parse_systemctl_show(lines) == {'foo': 'bar', 'baz': 'quux',
                                           'ExecStart': '/bin/bash -c "echo Hello World"',
                                           'ExecStart2': 'this is really ExecStart'}

    lines = ["ExecStart2=this is really ExecStart", "ExecStart=/bin/bash -c \"echo Hello World\""]
    assert parse_systemctl_show(lines) == {'ExecStart2': 'this is really ExecStart',
                                           'ExecStart': '/bin/bash -c "echo Hello World"'}


# Generated at 2022-06-11 08:10:05.964156
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:10:16.737018
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:10:24.597340
# Unit test for function main
def test_main():
    import tempfile
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    fh, testunitfile = tempfile.mkstemp(prefix='ansible-test-systemd-', dir=tmpdir)
    fh, systemd_file = tempfile.mkstemp(prefix='ansible-systemd-', dir=tmpdir)
    os.write(fh, b"\n".join([b"!/bin/sh", b"exit 0"]))
    os.close(fh)
    os.chmod(systemd_file, 0o755)
    tmp_systemd_path = tempfile.mkdtemp(prefix='ansible-systemd-', dir=tmpdir)

    test_params = {'name': testunitfile, 'state': 'stopped', 'check_mode': True}

# Generated at 2022-06-11 08:10:34.000250
# Unit test for function main
def test_main():
    # get initial conditions
    os.environ['SYSTEMD_OFFLINE'] = '1'

# Generated at 2022-06-11 08:10:43.025832
# Unit test for function main
def test_main():
    # import sys
    # sys.argv = ['ansible-systemd', '-h']
    # sys.argv = ['ansible-systemd', '-m', 'systemd', '--check', '-a', 'name=anacron', '-vvvv']
    # sys.argv = ['ansible-systemd', '-m', 'systemd', '--check', '-a', 'name=anacron,state=started', '-vvvv']
    # sys.argv = ['ansible-systemd', '-m', 'systemd', '-a', 'name=anacron,state=started', '-vvvv']
    main()
    
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-11 08:10:45.412316
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        assert False

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:15.576856
# Unit test for function main

# Generated at 2022-06-11 08:11:25.606190
# Unit test for function main
def test_main():
    try:
        obj = AnsibleModule(dict())
        obj.params['name'] = 'foo'
        obj.params['state'] = 'started'
        obj.params['enabled'] = True
        obj.params['force'] = False
        obj.params['masked'] = False
        obj.params['daemon_reload'] = False
        obj.params['scope'] = 'system'
        obj.params['no_block'] = False
        obj._ansible_debug = True
        main()
    except Exception as error:
        pass
# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 08:11:28.327959
# Unit test for function main
def test_main():
    # TODO: Implement
    assert(True)
# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:37.668091
# Unit test for function main
def test_main():
    # first unit test for module ansible.modules.system.systemd.service
    test_case = dict(
        state = dict(value=None),
        enabled = dict(value=None),
        masked = dict(value=None),
        daemon_reload = dict(value=False),
        daemon_reexec = dict(value=False),
        scope = dict(value='system'),
        no_block = dict(value=False),
        name = dict(value=None),
    )
    is_error, has_changed, result = main()
    assert not is_error
    assert not has_changed
    assert result['ansible_facts']['service_facts']['config_file'] == None
    assert result['ansible_facts']['service_facts']['service_links'] == None

# Generated at 2022-06-11 08:11:48.131532
# Unit test for function main

# Generated at 2022-06-11 08:11:53.352303
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os
    import tempfile
    import shutil

    def fail_if_missing(module, found, name, msg='target'):
        if not found:
            module.fail_json(msg='Could not find the requested service %s on the %s' % (name, msg))

    def sysv_exists(unit):
        return True

    def sysv_is_enabled(unit):
        return True

    def is_running_service(status):
        return True

    def is_deactivating_service(status):
        return False

    def is_chroot(module):
        return False

    def request_was_ignored(message):
        return False

    unit = 'sshd'

    systemctl = '/bin/systemctl'

# Generated at 2022-06-11 08:12:05.089082
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:12:15.690981
# Unit test for function main
def test_main():
    # Importing here to avoid the import loop below
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    # Unit test
    # Patch the module function
    with patch.object(AnsibleModule, 'exit_json') as mock_exit_json:
        with patch.object(AnsibleModule, 'run_command') as mock_run_command:
            mock_run_command.return_value = (0,'exists',"")
            mock_exit_json.side_effect = lambda **x: x


# Generated at 2022-06-11 08:12:26.904193
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # The following line is from the output of 'systemctl show sshd.service', with some parts
    # removed for the purpose of this test
    target = "ExecStart={ path=/usr/sbin/sshd ; argv[]=/usr/sbin/sshd -D $OPTIONS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
    lines = [
        'Id=sshd.service',
        'Description=OpenSSH server daemon',
        target,
    ]

    expected = {'Id': 'sshd.service', 'Description': 'OpenSSH server daemon', 'ExecStart': target}
    result = parse_systemctl_show(lines)
    assert expected == result


# Generated at 2022-06-11 08:12:37.999119
# Unit test for function main
def test_main():
    # called only in unit tests
    module = None

    # test case 1
    # results output from previous run
    results = {
        'status': {
            'ActiveEnterTimestampMonotonic': '',
            'ActiveEnterTimestamp': 'Sun 2020-07-12 13:49:23 EDT',
            'ActiveExitTimestampMonotonic': '',
            'ActiveExitTimestamp': 'Mon 2020-07-13 13:49:23 EDT',
            'InactiveEnterTimestampMonotonic': '',
            'InactiveEnterTimestamp': 'Sun 2020-07-12 13:49:23 EDT',
            'InactiveExitTimestampMonotonic': '',
            'InactiveExitTimestamp': 'Mon 2020-07-13 13:49:23 EDT',
        },
        'name': 'sshd.service',
    }


# Generated at 2022-06-11 08:13:01.506336
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_data = "ExecStart=/usr/bin/python2.7 -u /usr/bin/syncthing -no-browser\n-no-restart\n-logflags=0"
    lines = test_data.splitlines()
    parsed = parse_systemctl_show(lines)
    assert "ExecStart" in parsed
    assert parsed["ExecStart"] == test_data
    test_data2 = "Description=Syncthing - Open Source Continuous File Synchronization\n Documentation=man:syncthing(1) https://docs.syncthing.net/"
    lines = test_data2.splitlines()
    parsed = parse_systemctl_show(lines)
    assert "Description" in parsed
    assert parsed["Description"] == test_data2

# Generated at 2022-06-11 08:13:09.983152
# Unit test for function main

# Generated at 2022-06-11 08:13:18.952210
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:13:27.598448
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import copy

    unit = os.path.splitext(os.path.basename(__file__))[0]

    CWD = os.getcwd()
    TMP = tempfile.gettempdir()
    MODULE_NAME = 'ansible_collections.amazon.aws.plugins.modules.systemd_service'
    FIXTURES_PATH = os.path.join(CWD, 'test_fixtures')
    sys.path.insert(0, FIXTURES_PATH)

# Generated at 2022-06-11 08:13:29.615554
# Unit test for function main
def test_main():
    assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:13:39.002640
# Unit test for function main

# Generated at 2022-06-11 08:13:48.368219
# Unit test for function main

# Generated at 2022-06-11 08:13:50.525556
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:13:52.593217
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:13:55.907806
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    module.params['state'] = 'started'
    module.params['name'] = 'example'

    main()


# Generated at 2022-06-11 08:14:33.620393
# Unit test for function main

# Generated at 2022-06-11 08:14:44.937070
# Unit test for function main
def test_main():
    # mock() will help us to test function main.
    # It will record all the parameters and return values of the module we will test.
    # We will be able to check the result of the execution, parameters used to the call and returned values
    main_mock = MagicMock(return_value={'test':'main'}) # We define what main() will return

# Generated at 2022-06-11 08:14:52.363256
# Unit test for function main
def test_main():
    fake_module = ansible_module()
    fake_module.params = {'scope': 'system', 'no_block': False, 'name': 'foo', 'enabled': None, 'state': None, 'force': False, 'masked': None, 'daemon_reexec': False, 'daemon_reload': False}
    main()

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.urls import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:02.558493
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    result = parse_systemctl_show(SYSTEMCTL_SHOW_OUT.splitlines())
    assert result



# Generated at 2022-06-11 08:15:15.477297
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:15:25.703227
# Unit test for function main

# Generated at 2022-06-11 08:15:36.509933
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    expected = {
        'Description': 'Command Scheduler',
        'ExecReload': '{ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
        'ExecStart': '{ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
        'MainPID': '595',
    }

# Generated at 2022-06-11 08:15:44.098748
# Unit test for function main
def test_main():
    os.environ['SYSTEMD_OFFLINE'] = '1'

# Generated at 2022-06-11 08:15:52.995884
# Unit test for function main

# Generated at 2022-06-11 08:16:02.035783
# Unit test for function main
def test_main():
    unit = 'httpd'
    action = 'stop'

    module_args = dict(
        name=unit,
        state=action
    )

    systemctl = '/usr/bin/systemctl'

    # Reset state of commands in FakeModule class
    FakeModule.commands_run = []
    FakeModule.commands_rc = {}

    with patch('ansible.module_utils.basic.AnsibleModule', FakeModule):
        main()

    # We expect the following:
    # 1) show the current status of the unit
    # 2) stop the unit
    assert len(FakeModule.commands_run) == 2
    assert FakeModule.commands_run[0] == "{} show {}".format(systemctl, unit)

# Generated at 2022-06-11 08:17:28.784341
# Unit test for function main