

# Generated at 2022-06-11 08:08:12.938599
# Unit test for function main
def test_main():
    from ansible.module_utils.common.collections import Mapping
    with mock.patch('ansible.module_utils.basic.AnsibleModule') as AnsibleModule:
        AnsibleModule.run_command = mock.MagicMock(return_value=(0, "This is some valid output", ""))
        AnsibleModule.params = {
            'enabled': None,
            'masked': True,
            'name': 'sshd',
            'state': None,
            'daemon_reload': None,
            'daemon_reexec': None,
            'force': None,
            'scope': 'system',
        }
        AnsibleModule.exit_json = mock.MagicMock()
        AnsibleModule.fail_json = mock.MagicMock()
        sysv_exists = mock.MagicMock

# Generated at 2022-06-11 08:08:20.973875
# Unit test for function main
def test_main():
    import mock
    import sys
    module = mock.MagicMock()
    module.params = dict(
        name="",
        state="reloaded",
        enabled= False,
        force= False,
        masked= False,
        daemon_reload= False,
        daemon_reexec= False,
        scope= "system",
        no_block= False,
    )

    args = dict(
        changed= False,
        status=dict(),
    )
    with mock.patch.object(sys, 'argv', ['systemd.py']):
        main()

if __name__ == '__main__':
    main()

# vim: ai et ts=4 sw=4 sts=4 ft=python

# Generated at 2022-06-11 08:08:30.105305
# Unit test for function main
def test_main():
    # Initialize mock module object
    module = AnsibleModule(argument_spec=[
        'name',
        'enabled',
        'masked',
        'state',
        'daemon_reload',
        'daemon_reexec'
        ], check_invalid_arguments=False,
        bypass_checks=True)

    # Initialize module.params
    module.params = {
        'state': 'started',
        'name': 'foo',
        'enabled': 'True',
        'masked': 'True',
        'daemon_reload': False,
        'daemon_reexec': False,
        'no_block': False,
        'scope': 'system',
        'force': True
        }

    # Construct return values
    rc = 0
    out = 'success'

# Generated at 2022-06-11 08:08:40.469748
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:52.843692
# Unit test for function main
def test_main():
    # Mock function import
    class AnsibleModuleMock(object):
        def __init__(self, argument_spec=None, check_invalid_arguments=None,
                     bypass_checks=False, no_log=False,
                     mutually_exclusive=None, required_together=None,
                     required_one_of=None,
                     add_file_common_args=False, supports_check_mode=False,
                     required_by=None):
            return None
        def fail_json(self, **kwargs):
            return None

# Generated at 2022-06-11 08:08:57.944749
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 08:09:09.276316
# Unit test for function main

# Generated at 2022-06-11 08:09:21.235661
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:22.777603
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring unknown command")



# Generated at 2022-06-11 08:09:32.739043
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import json

# Generated at 2022-06-11 08:10:00.058051
# Unit test for function main
def test_main():
    mod_args = dict(
        name='foo.service',
        state='started',
        enabled=True,
        force=True,
        masked=False,
        daemon_reload=True,
        daemon_reexec=True,
        scope='system',
        no_block=False,
    )
    res_args = dict(
        name='foo.service',
        changed=False,
        status=dict(),
    )

# Generated at 2022-06-11 08:10:08.909702
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:10:19.177069
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import json  # to make assert statements human-readable
    assert parse_systemctl_show(['k=v']) == {'k': 'v'}
    assert parse_systemctl_show(['k=v1', 'k2=v2']) == {'k': 'v1', 'k2': 'v2'}
    assert parse_systemctl_show(['k=v', 'k2=v2']) == {'k': 'v', 'k2': 'v2'}
    assert parse_systemctl_show(['k=v1', 'k2=v2', 'k3=v3']) == {'k': 'v1', 'k2': 'v2', 'k3': 'v3'}

# Generated at 2022-06-11 08:10:21.147454
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(""" Job for dbus.service failed because the control process exited with error code. See "systemctl status dbus.service" and "journalctl -xe" for details.""")
    assert request_was_ignored("""
    dbus.service: Job dbus.service/start failed with result 'dependency'.
    """)



# Generated at 2022-06-11 08:10:29.745580
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for foo.service failed because a configured resource limit was exceeded. See "systemctl status foo.service" and "journalctl -xe" for details.')
    assert request_was_ignored('Job for foo.service failed because the control process exited with error code. See "systemctl status foo.service" and "journalctl -xe" for details.')
    assert request_was_ignored('Job for foo.service failed because service could not be started. See "systemctl status foo.service" and "journalctl -xe" for details.')
    assert request_was_ignored('Job for foo.service failed. See "systemctl status foo.service" and "journalctl -xe" for details.')
    assert request_was_ignored('A stop job is running for User Manager for UID 1000 (37s / 1min 30s)')

# Generated at 2022-06-11 08:10:39.841505
# Unit test for function main

# Generated at 2022-06-11 08:10:45.504109
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    unit_test_show_output = '''\
Description=The Apache HTTP Server
Documentation=man:httpd(8)
         man:apachectl(8)
After=network.target remote-fs.target nss-lookup.target
Documentation=man:apachectl(8)
Description=The Apache HTTP Server
After=network.target remote-fs.target nss-lookup.target
Wants=httpd.service
ExecStart={ path=/usr/sbin/httpd ; argv[]=/usr/sbin/httpd $OPTIONS -DFOREGROUND ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 ; watchdogs=0 }
'''

# Generated at 2022-06-11 08:10:56.065473
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines1 = [
        'Id=faked-multi-line.service',
        'ExecStart={\n',
        '    /usr/bin/fake-multi-line-exectable\n',
        '    this is a multi-line value\n',
        '}'
    ]
    lines2 = [
        'Id=faked-single-line.service',
        'ExecStart={/usr/bin/fake-single-line-executable}'
    ]

# Generated at 2022-06-11 08:11:06.605349
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:11:09.161748
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:32.312867
# Unit test for function main

# Generated at 2022-06-11 08:11:36.718712
# Unit test for function main
def test_main():
    global module
    global systemctl
    global unit
    global rc
    global out
    global err
    global result
    os.environ['XDG_RUNTIME_DIR'] = '/run/user/%s' % os.geteuid()

# Generated at 2022-06-11 08:11:48.068500
# Unit test for function main
def test_main():
    TEST_VARS = dict(
        module_args=dict(
            name='testservice',
            state='started',
            scope='user',
            no_block=True,
            force=True,
            masked=True,
        )
    )
    import sys

    if sys.version_info[0] < 3:
        import imp

        imp.load_source('main', 'systemd')
    else:
        import importlib.util

        spec = importlib.util.spec_from_file_location('main', 'systemd')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        sys.modules['main'] = module

    with patch('systemd.AnsibleModule', FakeAnsibleModule):
        import main

# Generated at 2022-06-11 08:11:59.669922
# Unit test for function main
def test_main():
    state = 'reloaded'
    enabled = True
    force = True
    masked = False
    daemon_reload = True
    unit = 'sshd'
    test = dict(
        name=unit,
        enabled=enabled,
        force=force,
        masked=masked,
        daemon_reload=daemon_reload,
        state=state,
        status=dict()
    )

    sys.modules['ansible'] = Mock()
    sys.modules['ansible'].module_utils = Mock()
    sys.modules['ansible'].module_utils.basic = Mock()
    sys.modules['ansible'].module_utils.basic.AnsibleModule = Mock()
    sys.modules['ansible'].module_utils.basic.AnsibleModule.return_value = test

# Generated at 2022-06-11 08:12:02.990707
# Unit test for function main
def test_main():
    # this module has become kind of ridiculous.
    assert 1

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:07.926291
# Unit test for function main
def test_main():
   result = main()
   assert result == '~/.ansible/tmp/ansible-tmp-1547785903.4-258427104940427/ /tmp/ansible_systemctl_payload_oSXWRn/ansible_systemctl_payload.zip'


# Generated at 2022-06-11 08:12:17.413091
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def run_test(lines, expected):
        parsed = parse_systemctl_show(lines)
        if parsed != expected:
            raise AssertionError("parse_systemctl_show('%s') returned %s instead of %s" % (lines, parsed, expected))

    # Run tests where each test case is a set of lines (passed to parse_systemctl_show) and an expected dictionary
    # of key-value pairs.

    # Very simple case
    run_test(['ExecStart=foo'], dict(ExecStart="foo"))

    # The real value for ExecReload= in a test file is much longer, but this is sufficient to test the code

# Generated at 2022-06-11 08:12:28.872090
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """

    # unit test for function main
    print("\tPerform unit test for function 'main'")

    # test module argument specification
    # !!! argument_spec as dict should not use module.params directly like this!

# Generated at 2022-06-11 08:12:39.407987
# Unit test for function main
def test_main():
    ''' Unit test for function main '''

    request_obj1 = 'object1'
    result_obj1 = {'request_obj': 'object1', 'status': {}}
    out1 = 'out'
    result_obj1['status'] = parse_systemctl_show(out1.split('\n'))
    result_obj1['status']['key1'] = 'value1'
    result_obj1['status']['key2'] = 'value2'
    result_obj1['status']['key3'] = 'value3'

    result_obj2 = {'request_obj': 'object1', 'status': {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}}


# Generated at 2022-06-11 08:12:50.926434
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:13:37.998463
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to execute operation: No such file or directory')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('PROGRESS=1')
    assert not request_was_ignored('cmd restart')
    assert not request_was_ignored('cmd: restart')



# Generated at 2022-06-11 08:13:47.467240
# Unit test for function main
def test_main():
    import os
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'name': dict(type='str', required=True), 'state': dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped'], required=False), 'enabled': dict(type='bool', required=False), 'force': dict(type='bool', required=False), 'masked': dict(type='bool', required=False), 'daemon_reload': dict(type='bool'), 'daemon_reexec': dict(type='bool'), 'scope': dict(type='str', default='system', choices=['system', 'user', 'global']), 'no_block': dict(type='bool', default=False)})
    # set env variables so that systemd related tools can work properly
    os

# Generated at 2022-06-11 08:13:58.836626
# Unit test for function main
def test_main():
    fd, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write('''
[Unit]
Description=Foobar

[Service]
ExecStart=/usr/bin/plasma-desktop
ExecStop=/usr/bin/kquitapp5 plasmashell

[Install]
WantedBy=multi-user.target
        ''')

    fs = [path]

# Generated at 2022-06-11 08:14:08.831781
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:19.340281
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:25.517924
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:34.283151
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.modules.system.systemd import __file__ as systemd_file
    import types
    import os.path

    # Test basic flow

# Generated at 2022-06-11 08:14:45.780480
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:14:55.595919
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:15:06.677918
# Unit test for function main
def test_main():
    """
    Unit test for function main
    :return:
    """
    from ansible.module_utils.basic import AnsibleModule
    import os


# Generated at 2022-06-11 08:15:52.264671
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:16:01.394818
# Unit test for function main
def test_main():
    import tempfile
    import shutil


# Generated at 2022-06-11 08:16:10.611684
# Unit test for function main
def test_main():
    result = { 'changed' : True, 'name' : 'test' }

# Generated at 2022-06-11 08:16:13.110138
# Unit test for function main
def test_main():
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    if module._name != 'main':
        return False, "Not the correct function"
    return True, "Success"



# Generated at 2022-06-11 08:16:16.704088
# Unit test for function main
def test_main():
    unit = 'systemd-logind'
    state = 'started'
    enabled = True
    ret = main(unit, state, enabled)
    assert ret['changed'] == True
    assert ret['status']['LoadState'] == 'loaded'


# Generated at 2022-06-11 08:16:24.530000
# Unit test for function main
def test_main():
    test_argv0 = os.path.basename(__file__)

# Generated at 2022-06-11 08:16:32.751687
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:16:41.410229
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:16:49.917753
# Unit test for function main

# Generated at 2022-06-11 08:16:55.867921
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    output = '''
Description=My Cool Service
ActiveState=active
ExecStart=potato potato
    potato
    potato
    }
    potato
    potato
    potato
    potato
Documentation=potato
'''
    result = parse_systemctl_show(output.splitlines())
    assert result["Description"] == "My Cool Service"
    assert result["ActiveState"] == "active"
    assert result["ExecStart"] == "potato potato\npotato\npotato\n}\npotato\npotato\npotato\npotato"

