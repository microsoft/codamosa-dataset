

# Generated at 2022-06-11 08:08:27.256688
# Unit test for function main
def test_main():
    unit = "foo"

# Generated at 2022-06-11 08:08:37.640679
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:49.750160
# Unit test for function main
def test_main():
    module_args = {}
    module_args.update(dict(name=""))
    module_args.update(dict(state=""))
    module_args.update(dict(enabled=""))
    module_args.update(dict(masked=""))
    module_args.update(dict(daemon_reload=""))
    module_args.update(dict(daemon_reexec=""))
    module_args.update(dict(scope=""))
    module_args.update(dict(no_block=""))
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] is True:
            raise
        else:
            pass
    except Exception as exc:
        print('You should edit systemctl module to avoid exception')
        print(exc)
        raise
# import module snippets

# Generated at 2022-06-11 08:09:01.513055
# Unit test for function main
def test_main():
    import sys

    sys.modules['ansible'] = Mock()
    sys.modules['ansible.module_utils.basic'] = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule = Mock()

    from ansible.module_utils.basic import AnsibleModule
    AnsibleModule.run_command = Mock(return_value=(0, '', ''))
    AnsibleModule.fail_json = Mock(return_value=None)

# Generated at 2022-06-11 08:09:11.817070
# Unit test for function main
def test_main():
    args = dict(
        name='service@name',
        state='reloaded',
        enabled=True,
        force=True,
        masked=True,
        daemon_reload=True,
        daemon_reexec=True,
        scope='system',
        no_block=False,
        systemctl='/usr/bin/systemctl',
    )

# Generated at 2022-06-11 08:09:23.357356
# Unit test for function main
def test_main():
    # mock ansible module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 08:09:27.306002
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('  \n ignoring request    \n'))
    assert(request_was_ignored('  \n ignoring command    \n'))
    assert(not request_was_ignored('  \n random message    \n'))
    assert(not request_was_ignored('  \n = random message    \n'))



# Generated at 2022-06-11 08:09:38.536251
# Unit test for function main
def test_main():
    unit = 'sshd'
    state = 'restarted'
    rc = 0
    out = err = ''
    result = dict(
        name=unit,
        changed=False,
        status=dict(),
    )
    
    result['status'] = dict(LoadState='not-found', ActiveState='inactive')
    is_running_service(result['status'])
    
    result['status'] = dict(LoadState='masked', ActiveState='inactive')
    is_running_service(result['status'])
    
    result['status'] = dict(LoadState='not-found', ActiveState='active')
    is_running_service(result['status'])
    
    result['status'] = dict(LoadState='masked', ActiveState='active')
    is_running_service(result['status'])


# Generated at 2022-06-11 08:09:50.829010
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test a few basic lines
    assert parse_systemctl_show(['x=y', 'a=b']) == {'x': 'y', 'a': 'b'}
    # Test multi-line values - ExecStart= and ExecReload= are known to have values that span
    # multiple lines, but Description= may also have multi-line values
    #
    # ExecStart=
    assert parse_systemctl_show(['ExecStart=foo', 'bar', 'ExecReload=baz']) == {'ExecStart': 'foo\nbar', 'ExecReload': 'baz'}
    assert parse_systemctl_show(['ExecStart={', 'foo', '}']) == {'ExecStart': 'foo'}
    assert parse_systemctl_show(['ExecStart={', 'foo', 'bar', '}'])

# Generated at 2022-06-11 08:09:58.027704
# Unit test for function main
def test_main():
    (rc, out, err) = module.run_command("echo {}/COPYING.LIB")
    with mock.patch.multiple(module,
            run_command=mock.DEFAULT,
            get_bin_path=mock.DEFAULT
    ) as _mocks:
        _mocks['run_command'].return_value = (rc, out, err)
        _mocks['get_bin_path'].return_value = "/usr/bin/systemctl"
        main()
        _mocks['run_command'].assert_called_with(systemctl, check_rc=True)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:13.495448
# Unit test for function main
def test_main():
    """
    unit test for systemd_service module
    """


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:22.551445
# Unit test for function main
def test_main():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import sysv_is_enabled
    from ansible.module_utils.systemd import sysv_exists


# Generated at 2022-06-11 08:10:31.538963
# Unit test for function main

# Generated at 2022-06-11 08:10:34.564956
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:44.161946
# Unit test for function main

# Generated at 2022-06-11 08:10:47.128832
# Unit test for function main
def test_main():
    pass

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.service import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:56.458302
# Unit test for function main
def test_main():
    fake_module = _init_fake_module()
    main()
    fake_module = _init_fake_module(params={'name': 'foo', 'scope': 'user', 'state': 'reloaded', 'force': False, 'masked': False, 'daemon_reload': False})
    main()
    fake_module = _init_fake_module(params={'name': 'foo', 'scope': 'user', 'state': 'reloaded', 'force': False, 'masked': False, 'daemon_reload': False})
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:11:06.773699
# Unit test for function main

# Generated at 2022-06-11 08:11:18.043553
# Unit test for function main
def test_main():
    test_spec = {
        "name": unit,
        "state": "started",
        "enabled": enabled
    }
    import platform
    from mock import patch, Mock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import string_types
    module = AnsibleModule(
        argument_spec=test_spec,
        supports_check_mode=True,
        required_one_of=[['state', 'enabled', 'masked', 'daemon_reload']],
        required_by=dict(
            state=('name',),
            enabled=('name',),
            masked=('name',),
        )
    )
    # make sure we always have systemctl
    m_get_

# Generated at 2022-06-11 08:11:23.189883
# Unit test for function main

# Generated at 2022-06-11 08:12:02.661011
# Unit test for function main
def test_main():
    # Test defaults
    mock = {
        'params': {
            'name': 'test1',
            'state': None,
            'enabled': None,
            'force': False,
            'masked': None,
            'daemon_reload': False,
            'daemon_reexec': False,
            'scope': 'system',
            'no_block': False,
        },
        'run_command.return_value': (
            0,
            '',
            '',
        ),
        'get_bin_path.return_value': "systemctl",
    }
    test = AnsibleModule(**mock)
    assert main() == test.exit_json(**dict(
        name='test1',
        changed=False,
        status=dict(),
    ))

    # Test defaults with state

# Generated at 2022-06-11 08:12:05.317464
# Unit test for function main
def test_main():
    # TODO: Implement test_main
    assert 1==1


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:15.853664
# Unit test for function main
def test_main():
  from ansible.module_utils.common.collections import ImmutableDict
  from ansible_collections.sensu.core_plugins.modules.systemd import main


# Generated at 2022-06-11 08:12:17.617203
# Unit test for function main
def test_main():
    assert True

# import module snippets
from ansible.module_utils.basic import *

main()

# Generated at 2022-06-11 08:12:29.014239
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:12:39.475221
# Unit test for function main
def test_main():
    """Function main unit test"""
    from ansible.module_utils.basic import AnsibleModule
    import json
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as tmpdirname:
        with open(os.path.join(tmpdirname, 'test.py'), 'w') as f:
            f.write('''#!/usr/bin/python

import sys

fake_dict = {
    'foo': 'bar',
    'fizz': 'buzz',
    'dne': 'does not exist'
}

input = sys.stdin.read()

if input in fake_dict:
    print(fake_dict[input])
else:
    print(input)
    sys.exit(1)
''')

# Generated at 2022-06-11 08:12:50.961225
# Unit test for function main
def test_main():
    unit = 'nginx'
    result = {}
    result['name'] = unit
    result['changed'] = False
    result['status'] = {}
    result['status'] = {'SysFSPath': '/etc/systemd/system/nginx.service', 'ExecMainStartTimestampMonotonic': '28m 13.715s', 'ExecMainPID': '26135', 'MainPID': '26135', 'ExecMainExitStatus': '1', 'ExecMainStartTimestamp': 'Thu 2019-08-29 18:35:14 UTC', 'ExecMainStartTimestampMonotonicUSec': '28136493411', 'ExecMainStatus': '0', 'ExecMainStartTimestampUSec': '1567087114301183', 'MainPID': '26135'}
    result['enabled'] = True

# Generated at 2022-06-11 08:13:00.278293
# Unit test for function main
def test_main():
    # Test with an empty parameter and
    # check the default of "system" for "scope"
    args = dict(
        name=None,
        state=None,
        enabled=None,
        force=None,
        masked=None,
        daemon_reload=False,
        daemon_reexec=None,
        scope=None,
    )


# Generated at 2022-06-11 08:13:08.522069
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', aliases=['service', 'unit']),
            state=dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped']),
            enabled=dict(type='bool'),
            force=dict(type='bool'),
            masked=dict(type='bool')
        ),
        required_one_of=[['state', 'enabled', 'masked', 'daemon_reload', 'daemon_reexec']],
        required_by=dict(
            state=('name', ),
            enabled=('name', ),
            masked=('name', ),
        ),
    )
    unit = module.params['name']

    systemctl = module.get_bin_path('systemctl', True)


# Generated at 2022-06-11 08:13:17.576036
# Unit test for function main
def test_main():
    # Test all possible cases
    set_module_args(dict(
        name=None,
        state=None,
        enabled=None,
        masked=None,
        daemon_reload=None,
        daemon_reexec=None,
        scope='system',
        no_block=None,
    ))
    result = dict(
        changed=False,
        status=dict(),
    )
    # Test existing unit
    with patch.object(systemd_spec.AnsibleModule, 'run_command', return_value=(0, "", "")), \
         patch.object(systemd_spec.AnsibleModule, 'get_bin_path', return_value="/systemctl"):
        assert main() == result

    # Test unit not found

# Generated at 2022-06-11 08:14:20.585809
# Unit test for function main
def test_main():
    main()


# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:31.041768
# Unit test for function main

# Generated at 2022-06-11 08:14:41.849096
# Unit test for function main
def test_main():
    fields = {
        'state': 'reloaded',
        'enabled': False,
        'force': True,
        'masked': False,
        'daemon_reload': True,
        'daemon_reexec': True
    }
    set_module_args(fields)


# Generated at 2022-06-11 08:14:42.533752
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:45.885621
# Unit test for function main
def test_main():
    """Validate function main"""
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:55.660623
# Unit test for function main
def test_main():
    from ansible.modules.system.service import main
    reload(main)

    # Stub AnsibleModule for testing.
    class SystemctlAnsibleModule:
        def __init__(self):
            self._values = {}
            self._callbacks = []

        def fail_json(self, **kwargs):
            self.exit_json(**kwargs)

        def exit_json(self, **kwargs):
            self._values = kwargs

        def set_fact(self, **kwargs):
            for (k, v) in kwargs.items():
                self._values[k] = v

        def get_bin_path(self, arg, required):
            return '/usr/bin/systemctl'


# Generated at 2022-06-11 08:15:06.730704
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.python import to_native
    import os
    import shutil
    import tempfile

    def fake_systemctl(module, command, env=None, check_rc=False, close_fds=True, executable=None, use_unsafe_shell=False, *args, **kwargs):
        """A fake version of AnsibleModule.run_command to return a known value."""
        rc = 0
        out = err = ''

        assert executable == shutil.which('systemctl')


# Generated at 2022-06-11 08:15:18.471431
# Unit test for function main
def test_main():
    mock_module = MagicMock()
    mock_module.params = {
        'name': 'foo',
        'state': 'started',
        'enabled': False,
        'masked': False,
        'daemon_reload': False,
        'daemon_reexec': False,
        'scope': 'system',
        'no_block': 'False'
    }
    mock_module.run_command.return_value = (True, '', '')
    mock_module.get_bin_path.return_value = True
    mock_module.fail_json.return_value = True
    mock_module.warn.return_value = True
    mock_module.exit_json.return_value = True

# Generated at 2022-06-11 08:15:19.872226
# Unit test for function main
def test_main():
    pass
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:15:30.962550
# Unit test for function main