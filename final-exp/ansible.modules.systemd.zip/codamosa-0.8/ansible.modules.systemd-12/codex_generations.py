

# Generated at 2022-06-11 08:08:18.950697
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for myservice.service ignored')
    assert request_was_ignored('Job for myservice.service ignored\n')
    assert request_was_ignored('Job for myservice.service ignored\nFailed to start myservice.service: Unit myservice.service not found.')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('Job for myservice.service failed')
    assert not request_was_ignored('Job for myservice.service failed\n')
    assert not request_was_ignored('Job for myservice.service failed\nFailed to start myservice.service: Unit myservice.service not found.')

# Generated at 2022-06-11 08:08:26.620551
# Unit test for function main
def test_main():
    for param in [ 'name', 'state', 'enabled', 'force','masked','daemon_reload','daemon_reexec','scope','no_block']:
        if param not in module._params:
            module.fail_json(msg="Module parameters %s not found"%(param))
    for param in ['enabled','daemon_reload','daemon_reexec','masked','state']:
        if module._params[param]:
            if module._params['name'] is None:
                module.fail_json(msg="Service name is None")
    main()

# Run unit test
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 08:08:37.162368
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:49.216773
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:52.117828
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('=')
    assert not request_was_ignored('abcd')
    assert not request_was_ignored('ignoring command')



# Generated at 2022-06-11 08:09:04.028645
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:09:06.103002
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('')
    assert not request_was_ignored('foo')



# Generated at 2022-06-11 08:09:08.914574
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        main()
    unitTest = UnitTest()
    unitTest.test()

if __name__ == "__main__":
    main()

# Generated at 2022-06-11 08:09:13.894940
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert (request_was_ignored('ignoring request'))
    assert (request_was_ignored('ignoring command'))
    assert (not request_was_ignored('job for crond.service failed'))


systemd_version_cache = {}

# Generated at 2022-06-11 08:09:24.694618
# Unit test for function main
def test_main():
  import tempfile
  import shutil
  tmpdir = tempfile.mkdtemp()
  # Touch some files
  open(os.path.join(tmpdir, 'ansible'), 'a').close()
  open(os.path.join(tmpdir, 'ansible.service'), 'a').close()
  open(os.path.join(tmpdir, 'ansible-systemd.service'), 'a').close()
  open(os.path.join(tmpdir, 'ansible-service'), 'a').close()
  args = {}

  class TestAnsibleModule(AnsibleModule):
      def __init__(self, *args, **kwargs):
          super(TestAnsibleModule, self).__init__(*args, **kwargs)
          self._tmpdir = tmpdir

# Generated at 2022-06-11 08:10:00.156248
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:10:08.964732
# Unit test for function main
def test_main():
    args = dict(
        state='started',
        name='test_service',
    )
    module = AnsibleModule(**args)
    global FAKE_CUR_CONF_SERVICES
    FAKE_CUR_CONF_SERVICES = '''[Unit]
Description=Test Service
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python -c "print('hello')"
RemainAfterExit=true

[Install]
WantedBy=multi-user.target'''
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.exit_json = MagicMock()
    main()
    module.exit_json

# Generated at 2022-06-11 08:10:19.178374
# Unit test for function main

# Generated at 2022-06-11 08:10:26.851243
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:10:36.995363
# Unit test for function main

# Generated at 2022-06-11 08:10:45.794673
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    EXEC_START_VALUE = """
    {
        path=/sbin/init
        argv[]=/sbin/init
        ignored_errors=no
        start_time=[n/a]
        stop_time=[n/a]
        pid=1
        code=(null)
        status=0/0
    }
    """
    DESCRIPTION_VALUE = """
    Have an extremely long description with no place to go
    So we need to span multiple lines
    """
    STRING_VALUE_WITH_CURLY_BRACES = '{I am a string}'

# Generated at 2022-06-11 08:10:56.635220
# Unit test for function main
def test_main():

    # These test cases originated from, or were inspired by, the
    # systemd ansible module tests in the ansible source code, in
    # test/integration/targets/module_utils/systemd/
    import sys
    sys.modules['ansible.module_utils.basic'] = None
    sys.modules['ansible.module_utils.six'] = None

    from ansible.module_utils.facts.system.systemd import SystemdDaemon
    from ansible.module_utils import basic
    from ansible.module_utils import six

    basic.AnsibleModule = type(six.StringIO(), (), {'run_command': lambda self, cmd: (0, '', ''), 'get_bin_path': lambda self, cmd: cmd})
    # Save original is_chroot function and replace it with a mock version
    original

# Generated at 2022-06-11 08:11:06.890839
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_data = """Id=getty.target
Names=getty.target
Requires=sysinit.target
RequiresOverridable=sysinit.target
Wants=systemd-user-sessions.service
After=sysinit.target
After=systemd-user-sessions.service
Description=Login Prompts
Documentation=man:systemd.special(7)
Documentation=http://www.freedesktop.org/wiki/Software/systemd/getty
Conflicts=shutdown.target
Before=shutdown.target
"""

# Generated at 2022-06-11 08:11:18.148876
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 08:11:29.589423
# Unit test for function main
def test_main():
    test_args = dict(
        name=None,
        state=None,
        enabled=None,
        force=None,
        masked=None,
        daemon_reload=None,
        daemon_reexec=None,
        scope=None,
        no_block=False
    )


# Generated at 2022-06-11 08:11:58.869237
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:12:07.765019
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    input = ['Description=some description',
             'ExecStart={', '   some executable',
             '', '   some argument', '}',
             'ExecStop={', '   some other executable', '}',
             'Description={',
             '   some other description',
             '}']

    expected_output = parse_systemctl_show(input)

    assert expected_output['Description'] == 'some description'
    assert expected_output['ExecStart'] == '\nsome executable\n\nsome argument\n'
    assert expected_output['ExecStop'] == '\nsome other executable\n'



# Generated at 2022-06-11 08:12:17.316889
# Unit test for function main

# Generated at 2022-06-11 08:12:28.824598
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:12:39.388321
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = ['Id=hello.service', 'Description=Hello world', 'ExecStart=ls -ld .', 'ExecStop=ls -ld ..', 'Hello=World']
    assert parse_systemctl_show(lines) == {'Id': 'hello.service', 'Description': 'Hello world', 'ExecStart': 'ls -ld .', 'ExecStop': 'ls -ld ..', 'Hello': 'World'}

    lines = ['Id=hello.service', 'Description=Hello world\nLong', 'ExecStart=ls -ld .', 'ExecStop=ls -ld ..', 'Hello=World']
    assert parse_systemctl_show(lines) == {'Id': 'hello.service', 'Description': 'Hello world\nLong', 'ExecStart': 'ls -ld .', 'ExecStop': 'ls -ld ..', 'Hello': 'World'}

   

# Generated at 2022-06-11 08:12:50.890419
# Unit test for function main

# Generated at 2022-06-11 08:12:56.181607
# Unit test for function main
def test_main():
    # define a dictionary to pass to main function
    module_args = dict(
        name="httpd",
        state="started",
        enabled=True,
    )

    # set module args
    set_module_args(module_args)

    # mock exit call and fail_json calls
    m_exit = MagicMock(side_effect=SystemExit)
    m_fail_json = MagicMock(side_effect=SystemExit)
    with patch.multiple(basic.AnsibleModule, exit_json=m_exit, fail_json=m_fail_json):
        # call function
        main()

    # no error should be raised
    # test exit_json calls
    assert m_exit.call_count == 1



# Generated at 2022-06-11 08:13:04.185560
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:13:12.793748
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    single_line = [
        'Id=systemd-journald.socket',
        'Names=systemd-journald.socket',
        'Description=Journal Socket',
        'Documentation=man:systemd-journald.service(8)',
        'LoadState=loaded',
        'ActiveState=active',
        'SubState=listening',
        'UnitFileState=linked',
        'FragmentPath=/usr/lib/systemd/system/systemd-journald.socket',
    ]


# Generated at 2022-06-11 08:13:21.968531
# Unit test for function main
def test_main():

    class MockModule:
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self.exit_json = lambda *args, **kwargs: None
            self.fail_json = lambda *args, **kwargs: None

            if self.params['name'] is None:
                self.params['name'] = 'nullservice'

        def get_bin_path(self, *args, **kwargs):
            return 'systemctl'

        def run_command(self, cmd):
            rc = 0
            out = err = ''
            if cmd.startswith('systemctl is-enabled'):
                if self.params.get('masked', 0) == 0:
                    if self.params.get('enabled', 0):
                        out = 'enabled\n'


# Generated at 2022-06-11 08:13:48.695188
# Unit test for function main
def test_main():
    import base64
    mod_dir = os.path.dirname(os.path.abspath(__file__))
    unit_path = os.path.join(mod_dir, 'test', 'systemctl_test.py')

    # TODO b64encode needs to be used twice?
    base64_unit_path = base64.b64encode(base64.b64encode(unit_path.encode('utf-8')).decode('ascii'))

    unit_name = 'test_unit_' + base64_unit_path.decode('ascii')
    old_env = os.environ.copy()
    new_env = os.environ.copy()
    new_env['SYSTEMD_OFFLINE'] = '1'

# Generated at 2022-06-11 08:13:59.772832
# Unit test for function main

# Generated at 2022-06-11 08:14:09.802703
# Unit test for function main
def test_main():
    os.environ['SYSTEMD_OFFLINE'] = "1"

# Generated at 2022-06-11 08:14:20.275489
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True),
            enabled=dict(type='bool'),
            masked=dict(type='bool'),
            daemon_reload=dict(type='bool', default=False, aliases=['daemon-reload']),
            daemon_reexec=dict(type='bool', default=False, aliases=['daemon-reexec']),
        ),
        supports_check_mode=True,
        required_one_of=[['daemon_reload', 'enabled', 'masked']],
    )

    sys.modules['ansible.module_utils.basic'] = AnsibleModule

    main()


# Generated at 2022-06-11 08:14:30.701809
# Unit test for function main
def test_main():
    module = get_module_mock()
    module.get_bin_path = MagicMock(return_value='/bin/systemctl')
    module.run_command = MagicMock(return_value=dict(rc=0, stdout='Success', stderr=''))

    systemctl = module.get_bin_path('systemctl', True)
    module.fail_json = MagicMock()

    # Test system scope
    result = dict(
        name='httpd',
        changed=False,
        status=dict()
    )
    is_initd = sysv_exists('httpd')
    is_systemd = False
    result['status'] = dict(LoadState='loaded')

# Generated at 2022-06-11 08:14:41.417039
# Unit test for function main
def test_main():
    argv = ['ansible', 'service', '-m', 'systemd', '-a', "'name=myservice enabled=yes'"]

    def moduleMock(module):
        module_dict = dict()
        module_dict['params'] = {'name': 'myservice', 'enabled': True, 'state': ''}
        return module_dict

    with patch('ansible.module_utils.basic.AnsibleModule', new=moduleMock) as mock_module:
        with patch.object(AnsibleModule, 'run_command', return_value=(0,'','enabled')) as mock_run:
            main()
            mock_run.assert_called_once_with('systemctl is-enabled \'myservice\'')

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:14:52.362782
# Unit test for function main
def test_main():
    with mock.patch(MOD_PATH + 'sysv_is_enabled', mock.Mock(return_value=True)):
        with mock.patch(MOD_PATH + 'sysv_exists', mock.Mock(return_value=True)):
            with mock.patch.object(module, 'exit_json', autospec=True) as mock_exit:
                with mock.patch.object(module, 'warn', autospec=True) as mock_warn:
                    with mock.patch.object(module, 'fail_json', autospec=True) as mock_fail:
                        with mock.patch.object(module, 'run_command', autospec=True) as mock_cmd:
                            # Mock object for info as it is a member of the function
                            info = {}
                            info['status'] = {}

# Generated at 2022-06-11 08:15:02.560586
# Unit test for function main

# Generated at 2022-06-11 08:15:15.432094
# Unit test for function main

# Generated at 2022-06-11 08:15:25.657197
# Unit test for function main
def test_main():
    """
    Unit test for main
    """
    def run_cmd(module, cmd):
        pass

    def run_command(module, cmd):
        if cmd == "systemctl is-enabled 'foo.service'":
            return (0, "enabled\n", "")
        if cmd == "systemctl is-active 'foo.service'":
            return (0, "active\n", "")
        if cmd == "systemctl show foo.service":
            return (0, 'ActiveState=activated\nGlobal=no\n', "")
        if cmd == "systemctl daemon-reload":
            return (0, "", "")
        if cmd == "systemctl daemon-reexec":
            return (0, "", "")

# Generated at 2022-06-11 08:16:05.493134
# Unit test for function main
def test_main():
    """ Unit test for function main """

    # Testing different states
    test_args = {
        'name': 'test_service',
        'state': 'stopped',
        'force': True,
        'daemon_reload': True,
        'scope': 'user',
        'no_block': True,
    }
    result = dict(
        changed=True,
        name='test_service',
        state='stopped',
    )
    test_main_generic(test_args, result)

    # Testing running state
    test_args = dict(
        name='test_service',
        state='running',
        force=True,
        daemon_reload=True,
        scope='user',
        no_block=True,
    )

# Generated at 2022-06-11 08:16:14.517641
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json

    def run_cmd(cmd):
        rc = 0
        out = err = ''
        if not module.check_mode:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            out, err = process.communicate()
            rc = process.returncode

        return rc, out, err

    class MockModule(object):
        __package__ = 'ansible.module_utils.basic'
        supports_check_mode = True
        exit_json = print
        fail_json = print

        def get_bin_path(name, required):
            return 'systemctl'


# Generated at 2022-06-11 08:16:17.177206
# Unit test for function main
def test_main():
    pass

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.basic import AnsibleModule
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:16:25.012413
# Unit test for function main

# Generated at 2022-06-11 08:16:33.199871
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.community.general.plugins.modules.system import systemctl as module
    result = dict(
        name='foo.bar',
        changed=False,
        status=dict(),
    )
    module.sysv_is_enabled = lambda x: True
    module.sysv_exists = lambda x: True
    # check service data, cannot error out on rc as it changes across versions, assume not found
    module.to_native = lambda x: '''foo.bar.service
LoadState=loaded
ActiveState=active'''
    module.is_systemd_running = lambda x: False
    module.request_was_ignored = lambda x: False
    module.parse_systemctl_show = lambda x: dict(foo='bar')
    module

# Generated at 2022-06-11 08:16:41.934446
# Unit test for function main
def test_main():
    import sys
    import os
    import json
    import ConfigParser
    from io import StringIO

    class AnsibleModuleMock:

        def __init__(self):
            self.params = dict()
            self.params['daemon_reload'] = False
            self.params['daemon_reexec'] = False

        def exit_json(self, **kwargs):
            print(json.dumps(kwargs))
            sys.exit(0)

        def fail_json(self, **kwargs):
            print(json.dumps(kwargs))
            sys.exit(1)

        def run_command(self, cmd, **kwargs):
            print("running command: " + cmd)
            os.system(cmd + " >/dev/null 2>&1")
            return 0, "", ""

       

# Generated at 2022-06-11 08:16:50.385141
# Unit test for function main

# Generated at 2022-06-11 08:16:57.799882
# Unit test for function main

# Generated at 2022-06-11 08:17:08.445618
# Unit test for function main
def test_main():
    ansible_RunResult = namedtuple('ansible_RunResult', ['rc', 'stdout', 'stderr'])
    ansible_ModuleResult = namedtuple('ansible_ModuleResult', ['params', 'check_mode'])
    ansible_Module = namedtuple('ansible_Module', ['exit_json', 'run_command', 'params', 'check_mode'])
    ansible_Result = namedtuple('ansible_Result', ['changed', 'stdout', 'stderr'])
    ansible_Module.params = {}
    ansible_Module.check_mode = False
    ansible_Module.params['name'] = None
    ansible_Module.params['state'] = None
    ansible_Module.params['enabled'] = None
    ansible_Module.params['force'] = None
    ansible

# Generated at 2022-06-11 08:17:16.906035
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    module = AnsibleModule({ 'name': 'dbus', 'state': 'started', 'check_mode': 'yes'})
    stdout = StringIO()
    stderr = StringIO()
    rc = 0
    # The following doesn't actually run the function. It returns a function that can be run by the test.
    # This is so we can mock the stdout, stderr, and rc of running the module.