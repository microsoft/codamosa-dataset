

# Generated at 2022-06-11 08:07:57.965735
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = '^[[?12l^[[?25h^[[1;24r^[[?1049h'
    assert(request_was_ignored(out) is False)
    out = '''
Job for ssh.service failed because the control process exited with error code. See "systemctl status ssh.service" and "journalctl -xe" for details.
^[[?12l^[[?25h^[[1;24r^[[?1049h
'''
    assert(request_was_ignored(out) is False)
    out = '''
Failed to create bus connection: No such file or directory
^[[?12l^[[?25h^[[1;24r^[[?1049h
'''
    assert(request_was_ignored(out) is False)

# Generated at 2022-06-11 08:07:59.410546
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('warning: ignoring request')
    assert request_was_ignored('warning: ignoring command')
    assert not request_was_ignored('warning: not ignoring command')



# Generated at 2022-06-11 08:08:05.902707
# Unit test for function main

# Generated at 2022-06-11 08:08:08.372444
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')         is True
    assert request_was_ignored('ignoring command')         is True
    assert request_was_ignored('=')                        is False
    assert request_was_ignored('else something')           is False
    assert request_was_ignored('ignoring request else')    is True
    assert request_was_ignored('ignoring command else')    is True


# Generated at 2022-06-11 08:08:18.288876
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    input = textwrap.dedent("""\
        Description={
            A
            multi-line
            value
        }
        Foo=Bar
        ExecStart={
            Does
            not
            end
            with
            }
            {
            A
            multi-line
            value
            that
            ends
            with
            }
        """).split('\n')
    expected = {
        'Description': 'A\nmulti-line\nvalue',
        'Foo': 'Bar',
        'ExecStart': 'Does\nnot\nend\nwith\n}\n{\nA\nmulti-line\nvalue\nthat\nends\nwith\n}',
    }
    actual = parse_systemctl_show(input)

# Generated at 2022-06-11 08:08:27.560565
# Unit test for function main
def test_main():
    job = dict()
    job['state'] = 'started'
    job['enabled'] = False
    job['force'] = False
    job['masked'] = False
    job['no_block'] = False
    job['scope'] = 'system'
    job['daemon_reload'] = False
    job['daemon_reexec'] = False

    name = "name"
    params = dict(name=name, state=job['state'], enabled=job['enabled'], force=job['force'], masked=job['masked'], no_block=job['no_block'], scope=job['scope'], daemon_reload=job['daemon_reload'], daemon_reexec=job['daemon_reexec'])

    # need a local validator for the main function
    # see https://github.

# Generated at 2022-06-11 08:08:31.548859
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request ')
    assert request_was_ignored('ignoring command ')
    assert not request_was_ignored('=')
    assert not request_was_ignored('[root@centos8 ~]# ')



# Generated at 2022-06-11 08:08:41.150424
# Unit test for function main

# Generated at 2022-06-11 08:08:53.747292
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_data = """
Description=sample description
ExecStart={ path=/bin/bash ; argv[]=/bin/bash -c "echo START ; sleep 10 ; echo STOP" ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
ExecStart={ path=/bin/bash ; argv[]=/bin/bash -c "echo START ; sleep 10 ; echo STOP" ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
ConditionResult=yes
    """
    parsed = parse_systemctl_show(test_data.splitlines())
    assert parsed['Description'] == 'sample description'
    assert parsed['ExecStart'].splitlines()

# Generated at 2022-06-11 08:09:05.523080
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Id=foobar.service',
        'Description={',
        "This is a description that spans",
        "multiple lines.",
        '}',
        'ExecReload=/bin/kill -HUP $MAINPID',
        'ExecStart=\n  ExecStart=/bin/true',
        'ExecStart=\n      command',
        'ExecStartPost=/bin/fakecommand\n',
        'ExecStartPost=command\n',
    ]
    parsed = parse_systemctl_show(lines)

# Generated at 2022-06-11 08:09:27.925820
# Unit test for function main

# Generated at 2022-06-11 08:09:31.403802
# Unit test for function main
def test_main():
    print('in the test')
    for i in range(10):
        print('running iteration ', i, 'main()')
        main()
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 08:09:42.445889
# Unit test for function main

# Generated at 2022-06-11 08:09:54.163822
# Unit test for function main

# Generated at 2022-06-11 08:09:58.304386
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as context:
        unit='sshd.service'
        state='started'
        systemctl='/usr/bin/systemctl'
        result={}
        result={'name': unit, 'state': state, 'status': {}, 'changed': True}
        main()
    assert result['name'] == unit
    assert result['state'] == state


# Generated at 2022-06-11 08:10:01.928747
# Unit test for function main
def test_main():
    pass


# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.service import sysv_is_enabled, sysv_exists

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:10:09.739467
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:10:19.798794
# Unit test for function main
def test_main():

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 08:10:26.497894
# Unit test for function main
def test_main():
    from ansible.module_utils.common.removed import removed_module

    # unit tests disabled in the global env
    if os.environ.get('SYSTEMD_TEST_DISABLE'):
        return

    # Load dummy module class
    removed_module()

    # Load test data
    testdata = load_fixture("systemd_test_data.json")

    # Load module

# Generated at 2022-06-11 08:10:36.673154
# Unit test for function main
def test_main():
    test_systemctl = '''
UNIT LOAD   ACTIVE SUB     DESCRIPTION
autofs.service   loaded    active   running HQFS AutoFS server
dhcpcd@eth0.service loaded active exited DHCPv4 client on eth0
dovecot.service loaded failed failed Dovecot IMAP/POP3 email server
'''


# Generated at 2022-06-11 08:11:03.426980
# Unit test for function main

# Generated at 2022-06-11 08:11:12.719434
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # '{' not followed by '}'
    result = parse_systemctl_show(['Description={Parse this as a single line',
                                   'Line 2'])
    assert result == {'Description': '{Parse this as a single line\nLine 2'}

    # '{' followed by '}'
    result = parse_systemctl_show(['ExecStart=/bin/true',
                                   '{',
                                   '  Successful=yes',
                                   '}'])
    assert result == {'ExecStart': '/bin/true\n{\n  Successful=yes\n}'}



# Generated at 2022-06-11 08:11:18.906140
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:11:30.219087
# Unit test for function main

# Generated at 2022-06-11 08:11:39.275041
# Unit test for function main
def test_main():
    import os
    UnitTest_Run_Successful = True
    unit_test_rc = 0
    unit_test_out = ''
    unit_test_err = ''
    unit_test_stdout = ''
    unit_test_stdin = ''
    unit_test_prog_name = __file__

    # Unit test #1: Test that main() returns 0 on success.
    print('INFO: Running unit test #1')
    rc, out, err = ansible_module_run(module_args='', check_mode=False)
    if rc != 0:
        print('ERROR: Expected 0, got %d' % rc)
        print('ERROR: stdout: %s' % out)
        print('ERROR: stderr: %s' % err)
        UnitTest_Run_Successful = False
        unit

# Generated at 2022-06-11 08:11:41.871121
# Unit test for function main
def test_main():
    check = ansible_module.command_spec['systemctl'] = 'python {0}'.format(__file__)
    ansible_module.params = {'service':'/test/test.service'}
    result = ansible_module.run_command()
    print(result)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 08:11:50.075690
# Unit test for function main

# Generated at 2022-06-11 08:12:01.762944
# Unit test for function main

# Generated at 2022-06-11 08:12:03.978443
# Unit test for function main
def test_main():
    print(__name__)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:12:14.895418
# Unit test for function main

# Generated at 2022-06-11 08:12:52.578775
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    def test_module(**kwargs):
        return AnsibleModule(argument_spec=dict(
            state=dict(required=True, choices=['reloaded', 'restarted', 'started', 'stopped']),
            enabled=dict(default=False, type='bool'),
            name=dict(default=None),
        ), **kwargs)

    result = dict(
        changed=False,
        name='test',
        enabled=False,
        status=dict(),
    )

    # Test empty status
    assert main(test_module(params=dict(
        name='test',
        enabled=True,
        state='stopped',
    ))) == result

    # Test running status
    result['status']['ActiveState'] = 'running'

# Generated at 2022-06-11 08:12:54.530829
# Unit test for function main
def test_main():
    assert True


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 08:13:02.248682
# Unit test for function main
def test_main():
    # Load test data
    test_data_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data')

# Generated at 2022-06-11 08:13:10.813645
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import sysv_exists
    from ansible.module_utils.systemd import sysv_is_enabled
    import os

    if os.getenv('TRAVIS') == 'true':
        if os.getenv('TRAVIS_DIST') == 'trusty' or os.uname()[2].startswith('4.10'):
            try:
                import systemd  # pylint: disable=import-error
            except ImportError:
                return None
        else:
            return None
    else:
        try:
            import systemd  # pylint: disable=import-error
        except ImportError:
            return None


# Generated at 2022-06-11 08:13:19.754222
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:13:28.309374
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_in = '''[Service]
ExecStart=
 {
  path=/usr/bin/dockerd
  argv[]=/usr/bin/dockerd
  argv[]--host=fd://
 }
'''.split('\n')
    assert parse_systemctl_show(test_in) == {'ExecStart': 'path=/usr/bin/dockerd\nargv[]=/usr/bin/dockerd\nargv[]--host=fd://'}
    test_in = '''[Service]
ExecStart=
 {
  path=/usr/bin/dockerd
  argv[]=/usr/bin/dockerd
  argv[]--host=fd://
'''.split('\n')

# Generated at 2022-06-11 08:13:37.826991
# Unit test for function main

# Generated at 2022-06-11 08:13:47.240460
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:13:58.648341
# Unit test for function main

# Generated at 2022-06-11 08:14:08.601661
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:15:15.524241
# Unit test for function main

# Generated at 2022-06-11 08:15:25.753732
# Unit test for function main
def test_main():
    import platform
    import json
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_native

    # *HACK*  We need to use the low-level APIs to ensure that the
    #         systemctl/systemd module only uses the right Python
    #         implementation of systemctl. This is a bit of a hack,
    #         but the best I can come up with for now.
    systemctl = '{0}/python-systemctl'.format(os.path.dirname(__file__))
    if platform.python_implementation() == 'PyPy':
        systemctl = '{0}-pypy'.format(systemctl)

    # *HACK*  We need to do this because we are running outside the Ansible
    #         runtime, so

# Generated at 2022-06-11 08:15:36.510080
# Unit test for function main
def test_main():
    from ansible.modules.system.service import main
    from ansible.module_utils import ansible_module_fake as ansible_module
    from io import StringIO
    from ansible.module_utils._text import to_bytes
    systemctl = 'systemctl'
    action = 'show'
    unit = 'gpg-agent.service'
    active_status = 'systemctl show ' + unit
    (rc, out, err) = ansible_module.run_command(active_status)
    print (rc, out, err)
    result = dict(
        name=unit,
        changed=False,
        status=dict(),
    )
    if rc == 0:
        result['status'] = main.parse_systemctl_show(to_native(out).split('\n'))

# Generated at 2022-06-11 08:15:44.102400
# Unit test for function main
def test_main():
    '''
    Unit tests for main()
    '''


# Generated at 2022-06-11 08:15:53.028615
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # test for simple single line variable
    test_input = 'ActiveState=active'
    assert parse_systemctl_show([test_input]) == {'ActiveState': 'active'}

    # test for multiline value ending with }
    test_input = [
        'Exec=\n',
        '{ path=/usr/bin/postgres ; argv[]=/usr/bin/postgres -D /var/lib/pgsql/data $',
        'POSTGRESQL_CTL_OPTS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; p',
        'id=0 ; code=(null) ; status=0/0 }'
    ]

# Generated at 2022-06-11 08:16:02.104328
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show('''Description=Test line'''.splitlines()) == {'Description': 'Test line'}
    assert parse_systemctl_show('''Description={ multi-line
        value'''.splitlines()) == {'Description': '{ multi-line\n        value'}
    assert parse_systemctl_show('''Description={ multi-line
        value
    }'''.splitlines()) == {'Description': '{ multi-line\n        value\n    }'}
    assert parse_systemctl_show('''Description={ multi-line
        value
    }'''.splitlines()) == {'Description': '{ multi-line\n        value\n    }'}

# Generated at 2022-06-11 08:16:11.317404
# Unit test for function main

# Generated at 2022-06-11 08:16:19.903578
# Unit test for function main
def test_main():
    input_args = {}
    input_args['enabled'] = False
    input_args['name'] = "network"
    input_args['state'] = "stopped"
    input_args['masked'] = False
    input_args['force'] = False
    input_args['daemon_reload'] = False
    input_args['daemon_reexec'] = False
    input_args['scope'] = "system"
    input_args['no_block'] = False
    expected_results = {}
    expected_results['changed'] = False
    expected_results['enabled'] = False
    expected_results['state'] = "stopped"
    expected_results['name'] = "network"

# Generated at 2022-06-11 08:16:21.567715
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import doctest
    doctest.testmod(verbose=True)
    return True



# Generated at 2022-06-11 08:16:23.254096
# Unit test for function main
def test_main():
    # Check if the function is set to a zero length string
    assert len(main()) != 0

if __name__ == '__main__':
    main()