

# Generated at 2022-06-11 08:08:11.716153
# Unit test for function parse_systemctl_show

# Generated at 2022-06-11 08:08:20.530530
# Unit test for function main
def test_main():
    out = StringIO()
    err = StringIO()
    sys.stdout = out
    sys.stderr = err
    test_args = {
        "name": "php5-fpm",
        "state": "started",
    }
    with pytest.raises(SystemExit):
        main(**test_args)
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__
    assert 'msg: Unable to start service php5-fpm: Failed to get properties: Unit php5-fpm.service not found.' in err.getvalue()
    assert 'status: {}' in err.getvalue()
    assert 'failed: True' in err.getvalue()
    assert 'changed: False' in err.getvalue()