

# Generated at 2022-06-23 04:29:46.094102
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    data = ['Id=auditd', 'Description=Security Auditing Service', 'ExecStart={ path=/usr/sbin/auditd ; argv[]=/usr/sbin/auditd -n ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }', 'ExecReload={ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }']
    output = parse_systemctl_show(data)

# Generated at 2022-06-23 04:29:56.689231
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("May 03 15:06:13 localhost.localdomain systemd[1]: systemd-vconsole-setup.service: ignoring request, already starting.")
    assert request_was_ignored("May 04 14:00:00 localhost.localdomain systemd[1]: vmtoolsd.service: ignoring command, manual mode, state 'starting'.")
    assert request_was_ignored("May 04 14:00:00 localhost.localdomain systemd[1]: vmtoolsd.service: ignoring request to reload, manual mode, state 'starting'.")



# Generated at 2022-06-23 04:30:00.769072
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:30:10.510132
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    input_data = '''
Description=Job spooling tools
Documentation=man:atd(8) man:at(1)
Wants=syslog.target
Defaults={ IgnoreOnIsolate=no }
After=nss-lookup.target network.target syslog.target timer.target
Requires=basic.target
RefuseManualStart=no
RefuseManualStop=yes
'''.split('\n')
    parsed = parse_systemctl_show(input_data)

# Generated at 2022-06-23 04:30:12.407102
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(status) is True



# Generated at 2022-06-23 04:30:13.457565
# Unit test for function main
def test_main():

  main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:16.465584
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'other-state'})



# Generated at 2022-06-23 04:30:19.694820
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})


# Generated at 2022-06-23 04:30:31.817245
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = '''
Job for foo.service failed because the control process exited with error code. See "systemctl status foo.service" and "journalctl -xe" for details.
    '''
    assert request_was_ignored(out) is True
    out = '''
foo.service: control process exited, code=exited status=2
Unit foo.service entered failed state.
Failed to start foo.service: Unit foo.service failed to load: Unit foo.service failed to load: No such file or directory.
● foo.service - foo
   Loaded: error (Reason: No such file or directory)
   Active: inactive (dead)
    failed
    '''
    assert request_was_ignored(out) is False



# Generated at 2022-06-23 04:30:36.830478
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False



# Generated at 2022-06-23 04:30:41.544692
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring command=status'))
    assert(request_was_ignored('ignoring request: unit=foo.service'))
    assert(not request_was_ignored('foo=bar'))



# Generated at 2022-06-23 04:30:50.276842
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('ansible.module_utils.systemd.open', create=True) as mock_open:
        file_handle = mock_open.return_value.__enter__.return_value

# Generated at 2022-06-23 04:31:06.356406
# Unit test for function main
def test_main():
    import platform

    if platform.system() == 'Darwin':
        # https://github.com/ansible/ansible/issues/29246
        raise unittest.SkipTest("mock test on MacOS is currently broken, see https://github.com/ansible/ansible/issues/29246")

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 04:31:12.653677
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:31:22.521332
# Unit test for function main

# Generated at 2022-06-23 04:31:29.190371
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:38.550419
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    module = ansible_module_helper.MockAnsibleModule()
    # '''Unit test for function main'''
    module.params = {
        'name': 'test_service',
        'state': 'stopped'
    }
    main()
    module.params = {
        'name': 'test_service',
        'state': 'started'
    }
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:44.320312
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'activating'}
    assert is_deactivating_service(service_status) is False
    service_status['ActiveState'] = 'deactivating'
    assert is_deactivating_service(service_status) is True


# Generated at 2022-06-23 04:31:51.817546
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_lines = """
    Id=myservice.service
    Description=My cool service
    After=network.target
    ExecStart={
        /bin/sh -c "
            echo 'hello'
            sleep 5
        "
    }

    ExecStop=foobar
    """
    parsed = parse_systemctl_show(test_lines.split('\n'))
    assert parsed['Id'] == 'myservice.service'
    assert parsed['Description'] == 'My cool service'
    assert parsed['ExecStart'] == '''
        /bin/sh -c "
            echo 'hello'
            sleep 5
        "
    '''
    assert parsed['ExecStop'] == 'foobar'



# Generated at 2022-06-23 04:31:54.462222
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({
        'ActiveState': 'inactive',
    }) is False

    assert is_running_service({
        'ActiveState': 'activating',
    }) is True

    assert is_running_service({
        'ActiveState': 'active',
    }) is True



# Generated at 2022-06-23 04:31:58.515973
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    assert is_deactivating_service({'ActiveState': 'activating'}) is False
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True



# Generated at 2022-06-23 04:32:01.791399
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {"ActiveState": "deactivating"}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:32:14.997085
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:17.094533
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('')
    assert not request_was_ignored('=')
    assert not request_was_ignored('= ignoring command')



# Generated at 2022-06-23 04:32:29.575162
# Unit test for function main
def test_main():
    # replace builtin with mock
    builtin_import = '__builtin__.open'
    if PY3:
        builtin_import = 'builtins.open'
    with mock.patch('ansible.modules.system.systemd.' + builtin_import) as mock_builtin_open:
        # read_mock expects a list which contains the output of the 'systemctl list-unit-files --no-legend',
        # 'systemctl list-unit-files --plain --no-legend', 'systemctl is-enabled' or 'systemctl show' command
        read_mock = mock.mock_open()
        read_handle = read_mock.return_value

        # write_mock mocks the 'systemctl enable', 'systemctl disable', 'systemctl daemon-reload',
        # 'systemctl daemon

# Generated at 2022-06-23 04:32:37.592428
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to execute operation: No such file or directory')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('Failed to open file')
    assert not request_was_ignored('unexpectedly finished')



# Generated at 2022-06-23 04:32:41.180080
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')



# Generated at 2022-06-23 04:32:45.039302
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:32:48.611156
# Unit test for function main
def test_main():
    # Mock is not available on Solaris
    if not is_sunos:
        from ansible.module_utils.systemd import SystemdDbusMock
        mock_module = SystemdDbusMock()
        with mock_module:
            main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:51.603864
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:55.256497
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'unknown'})



# Generated at 2022-06-23 04:32:57.117854
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for httpd.service failed because the control process exited with error code')



# Generated at 2022-06-23 04:33:00.776476
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'}) == False



# Generated at 2022-06-23 04:33:05.154807
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status_1 = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(status_1) == True
    status_2 = {'ActiveState': 'active'}
    assert is_deactivating_service(status_2) == False



# Generated at 2022-06-23 04:33:07.503689
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState':'deactivating'})



# Generated at 2022-06-23 04:33:16.399828
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:19.682343
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for systemd-hostnamed.service failed')
    assert request_was_ignored('Ignoring command')
    assert not request_was_ignored('ActiveEnterTimestampMonotonic')



# Generated at 2022-06-23 04:33:31.393971
# Unit test for function main
def test_main():
    import ansible.module_utils.basic
    ansible.module_utils.basic.AnsibleModule = mock.MagicMock()
    import sys
    sys.modules['systemctl'] = mock.MagicMock()
    sys.modules['service'] = mock.MagicMock()

    with mock.patch('service.os.path.exists') as path_exists_mock:
        path_exists_mock.return_value = True
        with mock.patch('service.os.path.isfile') as path_isfile_mock:
            path_isfile_mock.return_value = True

# Generated at 2022-06-23 04:33:37.143803
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:49.759070
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = 'Job for foo.service failed. See "systemctl status foo.service" and "journalctl -xe" for details.'
    assert request_was_ignored(out) is False
    out = 'Job for foo.service failed because the control process exited with error code. See "systemctl status foo.service" and "journalctl -xe" for details.'
    assert request_was_ignored(out) is False
    out = 'Job for foo.service failed because a configured resource limit was exceeded. See "systemctl status foo.service" and "journalctl -xe" for details.'
    assert request_was_ignored(out) is False
    out = 'Job for foo.service failed. See "systemctl status foo.service" and "journalctl -xe" for details.\n'
    assert request_was_ignored(out) is False
   

# Generated at 2022-06-23 04:33:54.678838
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert not request_was_ignored("= journalctl -n 0 -o json --no-pager")
    assert not request_was_ignored("JOB_ID=1")



# Generated at 2022-06-23 04:34:08.327150
# Unit test for function is_deactivating_service

# Generated at 2022-06-23 04:34:12.042826
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({"ActiveState": "active"})
    assert is_running_service({"ActiveState": "activating"})
    assert not is_running_service({"ActiveState": "inactive"})
    assert not is_running_service({"ActiveState": "deactivating"})



# Generated at 2022-06-23 04:34:20.115740
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'failedw'})



# Generated at 2022-06-23 04:34:28.204956
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("") is False
    assert request_was_ignored("ignoring request") is True
    assert request_was_ignored("Ignoring request") is True
    assert request_was_ignored("ignoring command") is True
    assert request_was_ignored("= not in out and ignoring command in out") is False
    assert request_was_ignored("= not in out and ignoring request in out") is False



# Generated at 2022-06-23 04:34:40.144999
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:53.705150
# Unit test for function main

# Generated at 2022-06-23 04:34:56.023394
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status) is True



# Generated at 2022-06-23 04:35:09.258674
# Unit test for function main
def test_main():
    args = dict(
        daemon_reload=True,
        daemon_reexec=True,
        enabled=True,
        masked=False,
        force=True,
        name='test',
        no_block=True,
        scope='system',
        state='started',
    )
    result = dict(
        changed=True,
        enabled=True,
        name='test',
        status=dict(
            ActiveState='active',
            ExecMainCode=1,
            ExecMainExitStatus=1,
            ExecMainPID=1,
            LoadState='loaded',
            MainPID=1,
            Result='success',
            SubState='running',
        ),
        state='started',
    )

# Generated at 2022-06-23 04:35:12.666296
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'foobar'})



# Generated at 2022-06-23 04:35:17.194654
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text

    executable = 'systemctl'
    if os.getenv('XDG_RUNTIME_DIR') is None:
        os.environ['XDG_RUNTIME_DIR'] = '/run/user/%s' % os.geteuid()

    args = dict(
        name='random.service',
        enabled=True,
        daemon_reload=True,
        daemon_reexec=True,
        scope='system',
        no_block=True,
        state='stopped',
        masked=True,
        force=True
    )

# Generated at 2022-06-23 04:35:30.395284
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
            'Description=Command Scheduler',
            'ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
            'ExecReload={ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
            ]
    parsed = parse_systemctl_show(lines)

# Generated at 2022-06-23 04:35:42.996356
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': '-'}) is False
    assert is_running_service({'ActiveState': 'WorngKey'}) is False
    assert is_running_service({'notActiveState': 'active'}) is False
    assert is_running_service({}) is False
    assert is_running_service(None) is False



# Generated at 2022-06-23 04:35:56.703032
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('<6>May 15 18:18:45 elliot systemd[1]: Failed to start Message of the Day.')
    assert not request_was_ignored('May 15 18:18:45 elliot systemd[1]: httpd.service: Failed with result \'timeout\'. -- Subject: Unit httpd.service has failed')
    assert not request_was_ignored('May 15 18:18:45 elliot systemd[1]: httpd.timer: Failed with result \'exit-code\'. -- Subject: Unit httpd.timer has failed')
    assert request_was_ignored('May 15 18:18:45 elliot systemd[1]: Ignoring command when unit is stopping: reload-or-restart')

# Generated at 2022-06-23 04:36:02.286336
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert request_was_ignored("ignoring request as daemon is not running")
    assert not request_was_ignored("= 4294967295")
    assert not request_was_ignored("Started Session c1 of user bcoca.")



# Generated at 2022-06-23 04:36:13.497825
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:20.725159
# Unit test for function is_running_service
def test_is_running_service():
    service_status = dict()
    service_status['ActiveState'] = 'active'
    assert is_running_service(service_status)
    service_status['ActiveState'] = 'activating'
    assert is_running_service(service_status)
    service_status['ActiveState'] = 'inactive'
    assert not is_running_service(service_status)
    service_status['ActiveState'] = 'deactivating'
    assert not is_running_service(service_status)
    service_status['ActiveState'] = 'failed'
    assert not is_running_service(service_status)



# Generated at 2022-06-23 04:36:22.661971
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:36:33.155901
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to start foo.service: Unit foo.service not found.') == False
    assert request_was_ignored('foo.service: Condition check resulted in Requested operation is not valid.') == False
    assert request_was_ignored('foo.service: Condition check resulted in Requested operation is not valid.') == False
    assert request_was_ignored('foo.service: Condition check resulted in Requested operation is not valid: at least one of its transaction members contains a file conflict.') == False
    assert request_was_ignored('foo.service: Failed with result \'exit-code\'.\nJob for foo.service failed. See "systemctl status foo.service" and "journalctl -xe" for details.\n') == False
    assert request_was_ignored('foo.service: Unit entered failed state.')

# Generated at 2022-06-23 04:36:45.825289
# Unit test for function main

# Generated at 2022-06-23 04:36:52.958488
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(status)
    status = {'ActiveState': 'deactivating-reload'}
    assert is_deactivating_service(status)
    status = {'ActiveState': 'inactive'}
    assert not is_deactivating_service(status)



# Generated at 2022-06-23 04:37:04.554554
# Unit test for function main

# Generated at 2022-06-23 04:37:09.844888
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'unknown'})



# Generated at 2022-06-23 04:37:13.938122
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('unit=')
    assert not request_was_ignored('foo bar')



# Generated at 2022-06-23 04:37:20.011406
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'activating'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:37:28.685869
# Unit test for function main
def test_main():
    # Test case 1:
    # disable is-enabled on systemctl
    # Tested command : systemctl is-enabled
    # Expected result: true
    if is_enabled('system', True):
        print("Disable is-enabled on systemctl command returned True")
    else:
        print("Disable is-enabled on systemctl command returned False")

    # Test case 2:
    # disable is-enabled on systemctl
    # Tested command : systemctl is-enabled
    # Expected result: false
    if is_enabled('system', False):
        print("Disable is-enabled on systemctl command returned True")
    else:
        print("Disable is-enabled on systemctl command returned False")

    # Test case 3:
    # no-block enable on systemctl
    # Tested command : systemctl no-block enable
    # Expected result

# Generated at 2022-06-23 04:37:41.296702
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['a=b']) == {'a': 'b'}
    assert parse_systemctl_show(['a=b', '']) == {'a': 'b'}
    assert parse_systemctl_show(['a=b', 'c=d']) == {'a': 'b', 'c': 'd'}
    assert parse_systemctl_show(['a=b', '', 'c=d']) == {'a': 'b', 'c': 'd'}
    assert parse_systemctl_show(['a=b', 'c=d', '']) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-23 04:37:49.398772
# Unit test for function main
def test_main():
    sys.modules['ansible.module_utils.basic'] = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule.run_command = Mock(return_value=(0,"stdout","stderr"))
    sys.modules['ansible.module_utils.basic'].AnsibleModule.exit_json = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule.fail_json = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule.params = { "name": "test", "state": "reloaded" }
    sys.modules['ansible.module_utils.basic'].AnsibleModule.check_mode = False


# Generated at 2022-06-23 04:38:03.015706
# Unit test for function main
def test_main():
    try:
        shutil.rmtree("/tmp/test_systemd")
    except:
        pass

    try:
        shutil.rmtree("/tmp/test_systemd_2")
    except:
        pass

    shutil.copytree("test/test_systemd_root", "/tmp/test_systemd")
    shutil.copytree("test/test_systemd_root_2", "/tmp/test_systemd_2")
    os.environ["SYSTEMD_COLORS"] = "0"
    os.environ["SYSTEMD_PAGER"] = ""
    os.environ["SYSTEMD_LESS"] = "FRXMK"
    os.environ["XDG_DATA_DIRS"] = "/etc/"

# Generated at 2022-06-23 04:38:14.709285
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['foo=bar']) == {'foo': 'bar'}
    assert parse_systemctl_show(['foo={', 'bar', 'baz}']) == {'foo': 'bar\nbaz'}

# Generated at 2022-06-23 04:38:20.061253
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service(dict(ActiveState='active'))
    assert not is_deactivating_service(dict(ActiveState='activating'))
    assert is_deactivating_service(dict(ActiveState='deactivating'))
    assert not is_deactivating_service(dict(ActiveState='inactive'))
    assert not is_deactivating_service(dict(ActiveState='failed'))



# Generated at 2022-06-23 04:38:34.103752
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = '''
    Description=Command Scheduler
    Documentation=man:crond(8) man:crontab(5)
    Requires=time-sync.target
    After=time-sync.target
    ConditionPathExists=/etc/crontab
    '''.splitlines()
    assert parse_systemctl_show(lines) == {
        'Description': 'Command Scheduler',
        'Documentation': 'man:crond(8) man:crontab(5)',
        'Requires': 'time-sync.target',
        'After': 'time-sync.target',
        'ConditionPathExists': '/etc/crontab',
    }


# Generated at 2022-06-23 04:38:40.846201
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:49.824535
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # basic test
    stat = {
        'ActiveState': 'deactivating'
    }
    assert is_deactivating_service(stat) is True
    # test that invalid ActiveState returns False
    stat = {
        'ActiveState': 'foo'
    }
    assert is_deactivating_service(stat) is False
    # test that missing ActiveState returns False
    stat = {}
    assert is_deactivating_service(stat) is False



# Generated at 2022-06-23 04:39:04.119320
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('asd asdf       =  asdfasdf       a') == False
    assert request_was_ignored('asd asdf       =  asdfasdf       a\n') == False
    assert request_was_ignored('asd asdf       ignoring request to  asd\n') == True
    assert request_was_ignored('asd asdf       ignoring request to  asd\n= asd\n') == False
    assert request_was_ignored('asd asdf       ignoring command to  asd\n') == True
    assert request_was_ignored('asd asdf       ignoring command to  asd\n= asd\n') == False

# Generated at 2022-06-23 04:39:11.288949
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import sys
    import re

    class SystemctlMock(object):
        """Systemctl mock class"""

        def __init__(self, module, unit=None, state=None, enabled=None,
                     daemon_reload=False, daemon_reexec=False, scope=None,
                     masked=None, force=False, no_block=False):
            self.module = module
            self.unit = unit
            self.state = state
            self.enabled = enabled
            self.daemon_reload = daemon_reload
            self.daemon_reexec = daemon_reexec
            self.scope = scope
            self.masked = masked
            self.force = force

# Generated at 2022-06-23 04:39:14.328598
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True



# Generated at 2022-06-23 04:39:22.546193
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:39:28.753456
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('= ignoring request') is False
    assert request_was_ignored('= ignoring command') is False
    assert request_was_ignored(None) is False



# Generated at 2022-06-23 04:39:30.764095
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False


# Generated at 2022-06-23 04:39:35.960931
# Unit test for function is_running_service
def test_is_running_service():
    retval = dict(ActiveState='inactive')
    assert not is_running_service(retval)
    retval['ActiveState'] = 'active'
    assert is_running_service(retval)
    retval['ActiveState'] = 'activating'
    assert is_running_service(retval)

