

# Generated at 2022-06-23 04:29:40.149159
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState= 'active')) == False
    assert is_deactivating_service(dict(ActiveState= 'activating')) == False
    assert is_deactivating_service(dict(ActiveState= 'deactivating')) == True


# Generated at 2022-06-23 04:29:42.731292
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    result = is_deactivating_service(service_status)
    assert result



# Generated at 2022-06-23 04:29:44.893853
# Unit test for function main
def test_main():
    (rc, out, err) = module.run_command("systemctl list-unit-files --no-pager 'test_nocheck_match_start_err.service'")
    assert rc == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:02.188889
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:11.722940
# Unit test for function main
def test_main():
    test_modules = {'systemd': 'systemd'}
    test_service_name = 'test.service'
    test_args = {}

    # we need to construct a module object, that has all the arguments that would normally be sent to the module,
    # for use in testing
    class SysModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def exit_json(self, **kwargs):
            return kwargs

        def get_bin_path(self, arg, required):
            print("get_bin_path(%s, %s)" % (arg, required))
            return True


# Generated at 2022-06-23 04:30:14.078730
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:30:19.118795
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('\nJob for httpd.service failed. See \'systemctl status httpd.service\' and \'journalctl -xn\' for details.\n')
    assert not request_was_ignored('Loaded: loaded (/usr/lib/systemd/system/httpd.service; enabled)')



# Generated at 2022-06-23 04:30:23.345653
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    fake_status = {'ActiveState': 'deactivating',
                   'LoadState': 'unloaded',
                   'SubState': 'dead'}
    assert is_deactivating_service(fake_status)



# Generated at 2022-06-23 04:30:29.515523
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request to reload unit rsyslog.service: Unit rsyslog.service not loaded.')
    assert not request_was_ignored('Job for rsyslog.service failed. See "systemctl status rsyslog.service" and "journalctl -xe" for details.')



# Generated at 2022-06-23 04:30:33.472367
# Unit test for function main
def test_main():
    with pytest.raises(FailJsonException):
        main()

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.urls import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:36.424934
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:30:47.152953
# Unit test for function main
def test_main():
    # Get parameters
    unit = module.params['name']

    # Create systemctl command
    systemctl = module.get_bin_path('systemctl', True)

    # Workaround for https://github.com/ansible/ansible/issues/71528
    if err and rc == 1 and 'Failed to parse bus message' in err:
        result['status'] = parse_systemctl_show(to_native(out).split('\n'))

        unit_base, sep, suffix = unit.partition('@')
        unit_search = '{unit_base}{sep}'.format(unit_base=unit_base, sep=sep)

# Generated at 2022-06-23 04:30:49.501118
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-23 04:30:55.248139
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:01.343761
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('  =  ')
    assert request_was_ignored('  Ignoring   ')
    assert request_was_ignored('  Ignoring Command ')
    assert not request_was_ignored('  Ignoring Command ')
    assert not request_was_ignored('  Ignoring Command ')



# Generated at 2022-06-23 04:31:04.318643
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(status)
    status = {'ActiveState': 'deactivating-reload'}
    assert not is_deactivating_service(status)



# Generated at 2022-06-23 04:31:16.569819
# Unit test for function is_running_service

# Generated at 2022-06-23 04:31:22.727222
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(' "frobinate-1.0" is not loaded properly: Ignoring request.')
    assert request_was_ignored(' "frobinate-1.0" is not loaded properly: ignoring request: ')
    assert request_was_ignored(' "frobinate-1.0" is not loaded properly: ignoring command: ')
    assert not request_was_ignored('Unit not-actually-loaded.service could not be found.')



# Generated at 2022-06-23 04:31:26.359322
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'other'}) is False
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True



# Generated at 2022-06-23 04:31:39.672460
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Unit test for function parse_systemctl_show
    expected = {
        'Description': 'foo',
        'ExecStart': 'bar',
    }
    # Test with every possible line break
    for line_break in ['\n', '\r', '\r\n']:
        lines = [
            'Description={0}'.format(line_break),
            'foo{0}'.format(line_break),
            'ExecStart={0}'.format(line_break),
            '{0}'.format(line_break),
            'bar{0}'.format(line_break),
            '{0}'.format(line_break),
        ]
        parsed = parse_systemctl_show(lines)
        assert parsed == expected



# Generated at 2022-06-23 04:31:50.145598
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:52.834238
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert(is_deactivating_service(service_status)==True)



# Generated at 2022-06-23 04:31:59.150875
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('foo bar=baz') is False
    assert request_was_ignored('foo bar = baz') is False
    assert request_was_ignored('foo bar =baz') is False
    assert request_was_ignored('foo bar= baz') is False



# Generated at 2022-06-23 04:32:08.096410
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(' some text\nignoring request\n')
    assert request_was_ignored(' some text\nignoring command\n')
    assert request_was_ignored(' some text\nignoring command, ignoring request\n')
    assert not request_was_ignored(' some text\n= some result')
    assert not request_was_ignored(' some text')
# End of unit tests for function request_was_ignored



# Generated at 2022-06-23 04:32:14.951629
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': ''}) is False
    assert is_running_service({}) is False



# Generated at 2022-06-23 04:32:26.691303
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([]) == {}
    assert parse_systemctl_show(['a=1', 'b=2']) == {'a': '1', 'b': '2'}
    assert parse_systemctl_show(['a=1', 'b=2', 'c=3']) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_systemctl_show(['a=1', 'b=2', 'c=3\n', 'd=4']) == {'a': '1', 'b': '2', 'c': '3\n', 'd': '4'}

# Generated at 2022-06-23 04:32:31.187250
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:32:35.698415
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False


# Generated at 2022-06-23 04:32:39.401732
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('=')



# Generated at 2022-06-23 04:32:45.173251
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status)
    service_status = {'ActiveState': 'activating'}
    assert is_running_service(service_status)
    service_status = {'ActiveState': 'inactive'}
    assert not is_running_service(service_status)



# Generated at 2022-06-23 04:32:51.617162
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = ["Description=Mock multi-line value", " with a }", " in the middle", "UnitFileState=enabled", "ExecStart=/bin/sh -c 'echo \"Hello World\"'"]
    expected = {"Description": "Mock multi-line value\n with a }\n in the middle", "UnitFileState": "enabled", "ExecStart": "/bin/sh -c 'echo \"Hello World\"'"}
    assert parse_systemctl_show(lines) == expected


# Generated at 2022-06-23 04:32:54.078260
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True



# Generated at 2022-06-23 04:32:55.596279
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')



# Generated at 2022-06-23 04:33:03.595692
# Unit test for function main

# Generated at 2022-06-23 04:33:11.354037
# Unit test for function main
def test_main():
    test_main_args = {}
    test_main_args.update({
        'name': 'test1',
        'state': 'started',
        'enabled': 'enabled',
        'masked': 'masked',
        'daemon_reload': False,
        'daemon_reexec': False,
        'force': False,
        'scope': 'system',
        'no_block': False,
    })
    mock_module = MagicMock()
    mock_module.params = test_main_args
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:17.523828
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('= not in out') is True
    assert request_was_ignored('systemd[1]') is False



# Generated at 2022-06-23 04:33:20.479465
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('="deadline"')
    assert not request_was_ignored('at=complete')



# Generated at 2022-06-23 04:33:25.008370
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:33:32.649559
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('''
Job for nginx.service failed. See 'systemctl status nginx.service' and 'journalctl -xn' for details.
Failed to start nginx.service: Unit nginx.service failed to load: No such file or directory.
Failed to issue method call: Unit nginx.service failed to load: No such file or directory.
''') is True
    assert request_was_ignored('''
Job for nginx.service failed. See 'systemctl status nginx.service' and 'journalctl -xn' for details.
''') is False



# Generated at 2022-06-23 04:33:37.567406
# Unit test for function main
def test_main():
    args = dict(
        name='httpd',
        state='started',
    )
    ret = main(dict(), dict(**args), args)
    assert ret['changed'] is True, "Result changed should be True"
    assert ret['state'] == 'started', "Result state should be 'started'"


# include magic from lib/ansible/module_common.py
#<<INCLUDE_ANSIBLE_MODULE_COMMON>>

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:50.070325
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test basic functionality
    lines = [
        'Foo=bar',
        'Baz=qux',
        'Bong=baz',
    ]
    assert parse_systemctl_show(lines) == {'Foo': 'bar', 'Baz': 'qux', 'Bong': 'baz'}

    # Test case where value spans multiple lines that aren't part of a multival

# Generated at 2022-06-23 04:33:58.632496
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'any'}) is False



# Generated at 2022-06-23 04:34:11.028715
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:16.172608
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('')
    assert not request_was_ignored('something')



# Generated at 2022-06-23 04:34:29.896938
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:41.127025
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:54.830886
# Unit test for function main
def test_main():
    print("TestMissingArguments")

# Generated at 2022-06-23 04:35:07.779864
# Unit test for function main
def test_main():
    args = dict(
        daemon_reload=True,
        daemon_reexec=True,
        force=True,
        name="test",
        state="started",
        enabled=True,
        masked=True,
        no_block=True,
        scope="system",
    )

    result = dict(
        changed=True,
        name="test",
        status=dict(),
    )

    with patch.object(AnsibleModule, 'run_command') as run_command_mock:
        run_command_mock.return_value = (0, "", "")

        with patch.object(AnsibleModule, 'get_bin_path') as get_bin_path_mock:
            get_bin_path_mock.return_value = "/usr/bin/systemctl"


# Generated at 2022-06-23 04:35:14.831763
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({})
# End of test for function is_running_service



# Generated at 2022-06-23 04:35:28.394593
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:34.655662
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    try:
        assert is_deactivating_service({'ActiveState': 'deactivating'})
    except AssertionError:
        raise AssertionError("Failed to detect deactivating service")
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:35:45.568815
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def test_parse_systemctl_show_input(data):
        return parse_systemctl_show(data.split('\n'))

    assert({'ExecStart': '/bin/bar'} == test_parse_systemctl_show_input(
        'ExecStart=/bin/bar'))
    assert({'ExecStart': '/bin/bar'} == test_parse_systemctl_show_input(
        'ExecStart=\n/bin/bar\n'))
    assert({'ExecStart': '/bin/bar\nbaz'} == test_parse_systemctl_show_input(
        'ExecStart=/bin/bar\nbaz'))

# Generated at 2022-06-23 04:35:58.798077
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Description=Test Service Category']) == {'Description': 'Test Service Category'}
    assert parse_systemctl_show(['Description=Test Service Category\n']) == {'Description': 'Test Service Category'}
    assert parse_systemctl_show(['Description=Test Service Category\n'
                                 'ExecStart=foo\n']) == {'Description': 'Test Service Category', 'ExecStart': 'foo'}

# Generated at 2022-06-23 04:36:11.820836
# Unit test for function request_was_ignored
def test_request_was_ignored():
    failed_responses = {'ignoring request',
                        'ignoring request to reload',
                        'ignoring request to start',
                        'ignoring request to stop',
                        'Ignoring request to',
                        'ignoring command',
                        'Ignoring command',
                        }

    successful_responses = {'static units',
                            'Static units',
                            'some output',
                            'a=b',
                            'a=b,c=d',
                            }

    for response in successful_responses:
        assert (not request_was_ignored(response)), "Should be success but was ignored"

    for response in failed_responses:
        assert (request_was_ignored(response)), "Should be ignored but was success"



# Generated at 2022-06-23 04:36:15.977504
# Unit test for function main
def test_main():
    # Arrange
    argv = sys.argv.copy()
    # Act
    sys.argv = [sys.argv[0]] + ["-m", "ansible.modules.system.systemd",
                                "-a", "name=foo",
                                "-a", "state=started"]

    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    # Unit test for function main
    test_main()

# Generated at 2022-06-23 04:36:19.712581
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('not ignoring ignore')
    assert request_was_ignored('not = ignoring ignore')
    assert not request_was_ignored('= not ignoring')


# Generated at 2022-06-23 04:36:22.631443
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False
    assert is_deactivating_service({'ActiveState': 'active'}) is False



# Generated at 2022-06-23 04:36:33.164024
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:39.629278
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = 'Job for abc.service failed because the control process exited with error code. See "systemctl status abc.service" and "journalctl -xe" for details.'
    out1 = '''abc.service is a disabled or a static unit, not starting it.'''
    assert request_was_ignored(out)
    assert request_was_ignored(out1)



# Generated at 2022-06-23 04:36:42.763546
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    if is_deactivating_service({'ActiveState': 'deactivating'}):
        print('unit test for function is_deactivating_service passed')



# Generated at 2022-06-23 04:36:51.638305
# Unit test for function main
def test_main():
    with patch('ansible.module_utils.basic.AnsibleModule') as mock:
        with patch('ansible.module_utils.systemd.AnsibleModule') as mock:
            with patch('ansible.module_utils.basic.AnsibleModule.run_command') as mock_run_command:
                with patch('ansible.module_utils.systemd.AnsibleModule.run_command') as mock_run_command:
                    mock_run_command.return_value = ('{}', '', 0)
                    with patch('ansible_collections.ansible.community.plugins.module_utils.systemd.parse_systemctl_show') as mock_parse_systemctl_show:
                        mock_parse_systemctl_show.return_value = {'ActiveState': 'active'}

# Generated at 2022-06-23 04:37:03.435074
# Unit test for function main
def test_main():
    RC_HANDLER = {
        0: dict(
            msg="",
            changed=False,
            status=dict(
                ActiveState="active"
            ),
            enabled=True,
        ),
    }

    exit_data = main_test(RC_HANDLER)
    if exit_data.get('rc', 1) != 0:
        exit_data.update(
            dict(
                failed=True,
                msg=exit_data.get("msg", "Unknown error")
            )
        )

    if 'stdout' in exit_data:
        if 'status' in exit_data:
            del exit_data['status']


# Generated at 2022-06-23 04:37:06.554586
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('a=b')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')



# Generated at 2022-06-23 04:37:19.390430
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:37:23.030594
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:37:36.445548
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(b"Job for foo.service failed. See 'systemctl status foo.service' and 'journalctl -xn' for details.\n")
    assert request_was_ignored(b"Failed to restart foo.service: Unit not found.\n")
    assert request_was_ignored(b"Failed to restart foo.service: Access denied\n")
    assert request_was_ignored(b"Failed to restart foo.service: Job type restart not applicable for unit foo.service.\n")
    assert request_was_ignored(b"Failed to start foo.service: Unit foo.service failed to load: No such file or directory.\n")
    assert request_was_ignored(b"Ignoring action restart: job is not active or reload failed.\n")
    assert request_was_

# Generated at 2022-06-23 04:37:47.204715
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    expected_parsed = {'ExecStart': '{ path=/usr/bin/systemd-sleep ; argv[]=/usr/bin/systemd-sleep ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ;code=(null) ; status=0/0 }',
                       'ActiveState': 'active',
                       'Description': 'Test service'}
    show_output = ('ActiveState=active\n'
                   'Description=Test service\n'
                   'ExecStart={ path=/usr/bin/systemd-sleep ; argv[]=/usr/bin/systemd-sleep ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ;code=(null) ; status=0/0 }')
    assert parse_systemctl_

# Generated at 2022-06-23 04:37:52.356870
# Unit test for function request_was_ignored
def test_request_was_ignored():
    test_cases = [
        ('set-property=ExecStart=', False),
        ('ignoring request', True),
        ('ignoring command', True),
    ]

    for cmd, result in test_cases:
        if request_was_ignored(cmd) != result:
            print('failed with {}'.format(cmd))
            raise AssertionError()



# Generated at 2022-06-23 04:38:05.099750
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test with a multi-line value
    lines = "ExecStart=/usr/sbin/crond -n $CRONDARGS\n  { path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
    expected = {'ExecStart': '\n  { path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'}

# Generated at 2022-06-23 04:38:12.923544
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    unit_fixture_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(unit_fixture_status) is True
    unit_fixture_status = {'ActiveState': 'active'}
    assert is_deactivating_service(unit_fixture_status) is False
    unit_fixture_status = {'ActiveState': 'inactive'}
    assert is_deactivating_service(unit_fixture_status) is False



# Generated at 2022-06-23 04:38:21.823400
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # A simple unit test for the function. The unit test passes if the following two
    # assertions both pass.
    parsed = parse_systemctl_show([
        'Unit=crond.service',
        'LoadState=loaded',
        'ActiveState=active',
    ])
    assert len(parsed['Unit']) > 0, 'Unit key should not be empty'
    assert '=' not in parsed['Unit'], 'Unit value should not span multiple lines'

# Generated at 2022-06-23 04:38:31.901538
# Unit test for function is_running_service
def test_is_running_service():
    status = {
        'ActiveState': 'active'
    }
    assert is_running_service(status) is True
    status = {
        'ActiveState': 'activating'
    }
    assert is_running_service(status) is True
    status = {
        'ActiveState': 'inactive'
    }
    assert is_running_service(status) is False
    status = {
        'ActiveState': 'unknown'
    }
    assert is_running_service(status) is False



# Generated at 2022-06-23 04:38:38.642172
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    res = parse_systemctl_show(("Id=foo.service", "Description={", "line 1", "    line 2", "    }", "After=bar.service", "StartLimitInterval=3s", "ExecStart={", "  /usr/bin/foo", "}"))
    assert res['Id'] == 'foo.service'
    assert res['Description'] == """
line 1
    line 2
    """
    assert res['After'] == 'bar.service'
    assert res['StartLimitInterval'] == '3s'
    assert res['ExecStart'] == """
  /usr/bin/foo
"""



# Generated at 2022-06-23 04:38:44.701470
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('''
Job for nginx.service failed because the control process exited with error code. See "systemctl status nginx.service" and "journalctl -xe" for details.
''')
    assert request_was_ignored('''
Failed to issue method call: Unit nginx.service not loaded.
''')
    assert not request_was_ignored('''
Unit nginx.service could not be found.
''')
    assert not request_was_ignored('''
Job for nginx.service failed.
''')
    assert request_was_ignored('''
Job for nginx.service failed because the control process exited with error code. See "systemctl status nginx.service" and "journalctl -xe" for details.
Job for nginx.service failed.
''')



# Generated at 2022-06-23 04:38:47.480111
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('foo ignoring request bar')
    assert request_was_ignored('foo ignoring command bar')
    assert not request_was_ignored('foo ignoring')
    assert not request_was_ignored('foo ignoring bar')
    assert not request_was_ignored('foo ignoring bar foo=bar')



# Generated at 2022-06-23 04:38:59.007569
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, load_platform_subclass
    import os
    import subprocess
    import json
    python_cmd = subprocess.Popen(['which', 'python3'], stdout=subprocess.PIPE).communicate()[0].rstrip()

    all_params = {'state': 'reloaded',
                  'name': 'test',
                  'enabled': True,
                  'force': False,
                  'masked': False,
                  'daemon_reload': False,
                  'daemon_reexec': False,
                  'scope': 'system',
                  'no_block': False,
                  'ANSIBLE_MODULE_ARGS': '{"enabled": true, "name": "test", "state": "reloaded"}'}


# Generated at 2022-06-23 04:39:03.468050
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # This is an actual value seen in the wild that begins with { but does not end with }.
    multiline_description = parse_systemctl_show([
        'Description=LXC Container: {{ container_name }}',
        '{',
        '  Id=lxc-{{ container_name }}-with-ssh.service',
        '  Names={{ container_name }}.service',
        '}',
        'Documentation=man:lxc(1)',
        'OnFailureIsolate=yes'
    ])

    # This is an actual value seen in the wild that begins with { and ends with }.

# Generated at 2022-06-23 04:39:07.254446
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False



# Generated at 2022-06-23 04:39:16.647302
# Unit test for function is_running_service

# Generated at 2022-06-23 04:39:18.192898
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(test_service_status)



# Generated at 2022-06-23 04:39:25.015929
# Unit test for function main
def test_main():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 04:39:32.166592
# Unit test for function request_was_ignored
def test_request_was_ignored():
    r = request_was_ignored("")
    assert r is False
    r = request_was_ignored("Failed to connect to bus: No such file or directory")
    assert r is False
    r = request_was_ignored("ignoring request")
    assert r is True
    r = request_was_ignored("ignoring command")
    assert r is True
    r = request_was_ignored("=: ignoring command")
    assert r is False



# Generated at 2022-06-23 04:39:37.134130
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("xyz ignoring request")
    assert request_was_ignored("xyz ignoring command")
    assert not request_was_ignored("xyz=ignoring")
    assert not request_was_ignored("xyz ignoring xyz")

