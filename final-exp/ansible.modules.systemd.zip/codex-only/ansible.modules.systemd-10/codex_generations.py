

# Generated at 2022-06-23 04:29:42.410557
# Unit test for function request_was_ignored
def test_request_was_ignored():
    expected_output = """
3.1. systemd[1]: ignoring request USR1
3.2. systemd[1]: ignoring command start request for unit dnf-automatic.service
3.3. systemd[1]: ignoring request USR1
"""
    output = expected_output.strip().split('\n')
    for i in range(0, len(output)):
        assert(request_was_ignored(output[i]) == True)



# Generated at 2022-06-23 04:29:47.756947
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:29:55.049522
# Unit test for function is_running_service
def test_is_running_service():
    active = dict(ActiveState='active')
    activating = dict(ActiveState='activating')
    inactive = dict(ActiveState='inactive')
    failed = dict(ActiveState='failed')
    for state in [active, activating]:
        assert is_running_service(state)
    for state in [inactive, failed]:
        assert not is_running_service(state)


# Generated at 2022-06-23 04:29:58.891566
# Unit test for function is_running_service
def test_is_running_service():
    running = dict(ActiveState='active')
    inactive = dict(ActiveState='inactive')
    assert is_running_service(running)
    assert not is_running_service(inactive)



# Generated at 2022-06-23 04:30:07.648963
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('... ignoring request')
    assert request_was_ignored('... ignoring request ...')
    assert request_was_ignored('... ignoring request...')
    assert request_was_ignored('... ignoring command')
    assert request_was_ignored('... ignoring command ...')
    assert request_was_ignored('... ignoring command...')
    assert not request_was_ignored('... ignoring request... FAILED')
    assert not request_was_ignored('... ignoring command... FAILED')
    assert not request_was_ignored('... ignoring FAILED')
    assert not request_was_ignored('... FAILED')
    assert not request_was_ignored('')



# Generated at 2022-06-23 04:30:18.129117
# Unit test for function main
def test_main():

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):  # pylint: disable=unused-argument
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):  # pylint: disable=unused-argument
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    def get_bin_path(name, required=False):
        return name

    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.exit_json = exit_json
            self.fail_json = fail_json

# Generated at 2022-06-23 04:30:31.592404
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test with a simple service that has a single-line value for Description=
    lines = [
        'Id=cron.service',
        'Names=cron.service',
        'Requires=basic.target',
        'After=basic.target auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket',
        'Before=shutdown.target multi-user.target',
        'Conflicts=shutdown.target',
        'Wants=system.slice',
        'WantedBy=multi-user.target',
        'Description=Command Scheduler',
        'Documentation=man:crond(8) man:crontab(5)',
        '',
    ]
    parsed = parse_systemctl_show(lines)
    assert parsed['Id'] == 'cron.service'


# Generated at 2022-06-23 04:30:35.292423
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request: unknown')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('ActiveState=active')
    assert not request_was_ignored('A=B')



# Generated at 2022-06-23 04:30:39.429599
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:30:49.565961
# Unit test for function main
def test_main():
    arg = ['service']
    is_systemd = False
    is_initd = False
    unit = 'sshd'
    for globpattern in (r"*", r"?", r"["):
        if globpattern in unit:
            module.fail_json(msg="This module does not currently support using glob patterns, found '%s' in service name: %s" % (globpattern, unit))

    systemctl = module.get_bin_path('systemctl', True)

    if os.getenv('XDG_RUNTIME_DIR') is None:
        os.environ['XDG_RUNTIME_DIR'] = '/run/user/%s' % os.geteuid()

    if unit:
        found = False
        is_initd = sysv_exists(unit)
        is_systemd

# Generated at 2022-06-23 04:30:55.364837
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(status) is True



# Generated at 2022-06-23 04:31:02.549067
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:09.704949
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:15.377022
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({u'ActiveState': u'active'})
    assert is_running_service({u'ActiveState': u'activating'})
    assert not is_running_service({u'ActiveState': u'inactive'})
    assert not is_running_service({u'ActiveState': u'unknown'})



# Generated at 2022-06-23 04:31:17.557404
# Unit test for function is_running_service
def test_is_running_service():
    result = is_running_service({'ActiveState': 'active', 'SubState': 'bar'})
    assert result is True


# Generated at 2022-06-23 04:31:19.978600
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'active'}) == True



# Generated at 2022-06-23 04:31:24.433304
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(["Id=cron.service"]) == {'Id': 'cron.service'}
    assert parse_systemctl_show(["Id=cron.service", "Description=Object Name"]) == {'Id': 'cron.service', 'Description': 'Object Name'}

# Generated at 2022-06-23 04:31:32.897545
# Unit test for function main

# Generated at 2022-06-23 04:31:35.019577
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:31:45.819504
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"}) is True
    assert is_deactivating_service({"ActiveState": "inactive"}) is False
    assert is_deactivating_service({"ActiveState": "active"}) is False
    assert is_deactivating_service({"ActiveState": "activating"}) is False
    assert is_deactivating_service({"ActiveState": "undefined"}) is False



# Generated at 2022-06-23 04:31:48.807153
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')



# Generated at 2022-06-23 04:31:57.305421
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring request: unit is masked'))
    assert(request_was_ignored('ignoring command start'))
    assert(not request_was_ignored('= auth-rpcgss-module.service - Authenticate user requests using RPCGSS client module '))
    assert(not request_was_ignored('   Loaded: loaded (/usr/lib/systemd/system/auth-rpcgss-module.service; disabled)'))
    assert(not request_was_ignored('transient'))



# Generated at 2022-06-23 04:32:11.100388
# Unit test for function main
def test_main():
    unit = sys.argv[0]

    # Add a unit to run all the other unit tests
    main_tests = dict(
        main = dict(name = unit, state = 'started'),
        main_restarted = dict(name = unit, state = 'restarted'),
        main_reloaded = dict(name = unit, state = 'reloaded'),
        main_stopped = dict(name = unit, state = 'stopped'),
    )

    # Only run main_test when we run the unit test

# Generated at 2022-06-23 04:32:12.198683
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({u'ActiveState': u'deactivating'})



# Generated at 2022-06-23 04:32:23.681730
# Unit test for function main
def test_main():
    # this is mostly integration testing, but should catch syntax errors
    import ansible_collections.ansible.community.plugins.modules.system.systemd as systemd
    # systemd/systemctl not on POSIX platforms
    if not systemd.sys.platform.startswith('win'):
        # build args
        module = MagicMock()
        module.run_command.return_value = (0, "", "")
        # set defaults
        module.params = dict(
            name=None,
            state=None,
            enabled=None,
            masked=None,
            daemon_reload=False,
            force=False,
            scope='system',
            no_block=False,
        )
        systemd.main()
        # test daemon-reload
        module.params['daemon_reload'] = True

# Generated at 2022-06-23 04:32:26.558614
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({})
    assert not is_running_service({'SubState': 'dead'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-23 04:32:30.129965
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({
        'ActiveState': 'deactivating'
    }) is True
    assert is_deactivating_service({
        'ActiveState': 'active'
    }) is False



# Generated at 2022-06-23 04:32:36.479115
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='deactivating'))
    assert not is_running_service(dict(ActiveState='inactive'))


# Generated at 2022-06-23 04:32:46.885027
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_cases = [  # noqa
        'Basic',
        'SingleLine',
        'MultiLine',
        'MultiLineTrailingNewline',
    ]
    for test_case in test_cases:
        name = test_case + '.txt'
        with open(name, 'r') as f:
            lines = f.readlines()
        parsed = parse_systemctl_show(lines)
        name = test_case + '.txt.expected'
        with open(name, 'r') as f:
            expected = f.read()
        if expected != repr(parsed):
            raise Exception('{} failed: {} != {}'.format(test_case, expected, repr(parsed)))


# Generated at 2022-06-23 04:32:52.916283
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status_dict = dict(
        ActiveState="deactivating"
    )
    assert is_deactivating_service(status_dict)
    status_dict['ActiveState'] = 'active'
    assert not is_deactivating_service(status_dict)
    status_dict['ActiveState'] = 'inactive'
    assert not is_deactivating_service(status_dict)



# Generated at 2022-06-23 04:32:55.255845
# Unit test for function is_running_service
def test_is_running_service():
    for _, service_status in service_status_result_values.items():
        assert is_running_service(service_status)



# Generated at 2022-06-23 04:32:59.816279
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service( {'ActiveState': 'active' })
    assert is_deactivating_service( {'ActiveState': 'activating' })
    assert is_deactivating_service( {'ActiveState': 'deactivating' })
    assert not is_deactivating_service( {'ActiveState': 'exited' })



# Generated at 2022-06-23 04:33:01.827188
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('  \nignoring command\n')
    assert not request_was_ignored('  \n= some valid output\n')



# Generated at 2022-06-23 04:33:12.127637
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(["foo=x", "bar=y", "baz="]) == {
        'foo': 'x',
        'bar': 'y',
        'baz': '',
    }
    assert parse_systemctl_show(["foo=x", "bar=y", "baz"]) == {
        'foo': 'x',
        'bar': 'y',
    }
    assert parse_systemctl_show(["foo=x\nbar=y"]) == {
        'foo': 'x\nbar=y',
    }
    assert parse_systemctl_show(["foo=x\nbar=y\nbaz=z"]) == {
        'foo': 'x\nbar=y\nbaz=z',
    }

# Generated at 2022-06-23 04:33:16.626525
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Request was ignored') == True
    assert request_was_ignored('asdfasdf ignoring request asdfasdf') == True
    assert request_was_ignored('') == False
    assert request_was_ignored('Request was not ignored') == False
    assert request_was_ignored('asdfasdf ignoring command asdfasdf') == True



# Generated at 2022-06-23 04:33:29.517724
# Unit test for function main

# Generated at 2022-06-23 04:33:34.323752
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('= ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('= active')



# Generated at 2022-06-23 04:33:41.737331
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:33:53.752221
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def helper(lines, expected):
        parsed = parse_systemctl_show(lines)
        if len(expected) != len(parsed):
            raise AssertionError('Expected %d keys, but got %d: %s' % (len(expected), len(parsed), parsed))
        for k in expected:
            if k not in parsed:
                raise AssertionError('Missing key "%s": %s' % (k, parsed))
            elif parsed[k] != expected[k]:
                raise AssertionError('Expected value for "%s" to be "%s", but got "%s"' % (k, expected[k], parsed[k]))
    helper(['a=b', 'c=d'], dict(a='b', c='d'))

# Generated at 2022-06-23 04:34:03.773667
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Warning: Stopping application-did-start-up.service, but it can still be activated by: application-start-failed.timer\n") is True
    assert request_was_ignored("Warning: Stopping hciuart.service, but it can still be activated by the trigger\n") is True
    assert request_was_ignored("Job for zabbix-agent.service failed because the control process exited with error code.") is False
    assert request_was_ignored("Failed to get D-Bus connection: No connection to service manager.") is True



# Generated at 2022-06-23 04:34:16.071702
# Unit test for function main
def test_main():
    # FIXME: AnsibleModule unit tests are expected to exit on failure, so this is a hack to prevent
    # the success exit from being recorded.
    #
    # A better solution would be to refactor this code to be reentrant (a state variable would be
    # useful for that) instead of just mocking out the parts that rely on subprocess.
    def fail_json(self, *args, **kwargs):
        raise Exception("fail_json")

    setattr(AnsibleModule, 'fail_json', fail_json)

    # Mock out module.run_command()
    is_enabled = None
    is_active = None
    show = None
    list_unit_files = None
    def run_command(self, *args, **kwargs):
        global is_enabled
        global is_active
        global show

# Generated at 2022-06-23 04:34:29.723592
# Unit test for function main
def test_main():
    import shlex

    class AnsibleModule():

        def __init__(self):
            self.exit_json = print

        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/systemctl"

        def run_command(self, cmd_args):
            cmd_parts = shlex.split(cmd_args)
            systemctl_cmd = cmd_parts[0]
            unit_not_found = 'Failed to get unit file state for'
            if systemctl_cmd == "/usr/bin/systemctl" and cmd_parts[1] == 'show':
                return 1, '', '%s %s\n...\nLoadError: Failed to find unit %s.service' % (unit_not_found, cmd_parts[2], cmd_parts[2])

# Generated at 2022-06-23 04:34:40.713851
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("some garbage\nFailed to execute operation: Invalid argument")
    assert request_was_ignored("Failed to execute operation: Unit foo.service not loaded.")
    assert request_was_ignored("Failed to execute operation: No such file or directory")
    assert request_was_ignored("some garbage\nFailed to execute operation: Unit foo.service not loaded.")
    assert not request_was_ignored("some garbage\nFailed to execute operation: Invalid argument\nmore garbage")
    assert not request_was_ignored("some garbage\nFailed to execute operation: Unit foo.service not loaded.\nmore garbage")
    assert not request_was_ignored("some garbage\nFailed to execute operation: No such file or directory\nmore garbage")



# Generated at 2022-06-23 04:34:54.305845
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # request was ignored (bad state)
    assert request_was_ignored("""
    May 16 14:22:19 host1 systemd[1]: my-service.service: Unit entered failed state.
    May 16 14:22:19 host1 systemd[1]: my-service.service: Failed with result 'exit-code'.
    """) is True

    # request was ignored (not started)

# Generated at 2022-06-23 04:34:59.992838
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request from PID')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring ')
    assert not request_was_ignored('pid')
    assert not request_was_ignored('/usr/bin/systemctl')



# Generated at 2022-06-23 04:35:13.764168
# Unit test for function main

# Generated at 2022-06-23 04:35:21.139489
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_cases = [{'ActiveState': 'inactive', 'expected': False},
                  {'ActiveState': 'active', 'expected': False},
                  {'ActiveState': 'activating', 'expected': False},
                  {'ActiveState': 'deactivating', 'expected': True}]
    for test_case in test_cases:
        assert is_deactivating_service(test_case) == test_case['expected']



# Generated at 2022-06-23 04:35:32.587620
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    """
    Verify that parse_systemctl_show parses the output of systemctl show correctly.
    """

# Generated at 2022-06-23 04:35:39.272091
# Unit test for function request_was_ignored
def test_request_was_ignored():
    ignored = 'Ignoring registered operation on inactive unit.'
    not_ignored = 'Running as unit: run-r72a35b60823040c7adb9d82c3fa91db3.scope'
    good = request_was_ignored(ignored)
    bad = request_was_ignored(not_ignored)
    assert good
    assert not bad



# Generated at 2022-06-23 04:35:44.133861
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'deactivating'}) is False



# Generated at 2022-06-23 04:35:49.951223
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:54.801572
# Unit test for function request_was_ignored
def test_request_was_ignored():
    result = request_was_ignored('ignoring request')
    assert result is True
    result = request_was_ignored('=' in 'test')
    assert result is False
    result = request_was_ignored('ignoring command')
    assert result is True



# Generated at 2022-06-23 04:35:59.794245
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {
        "LoadState": "loaded",
        "ActiveState": "deactivating"
    }
    assert is_deactivating_service(service_status)
    service_status['ActiveState'] = 'active'
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-23 04:36:06.391717
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'}) is True
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:36:10.370394
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False
    assert is_deactivating_service({'ActiveState': 'active'}) is False

# Generated at 2022-06-23 04:36:14.342648
# Unit test for function main
def test_main():
    my_obj = systemctl()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:21.093262
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    print(is_deactivating_service({'ActiveState':  'active'}))
    print(is_deactivating_service({'ActiveState':  'deactivating'}))
    print(is_deactivating_service({'ActiveState':  'activating'}))
    print(is_deactivating_service({'ActiveState':  'inactive'}))
    print(is_deactivating_service({'ActiveState':  'failed'}))
#test_is_deactivating_service()
# sys_scope=system, user, global

# Generated at 2022-06-23 04:36:32.542875
# Unit test for function main

# Generated at 2022-06-23 04:36:34.810199
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'inactive'}
    assert not is_running_service(service_status)



# Generated at 2022-06-23 04:36:47.085597
# Unit test for function main
def test_main():
    class AnsibleModuleExitException(Exception):
        pass
    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec
        def params(self):
            return {}
    am = AnsibleModule(argument_spec=dict())
    setattr(am, 'run_command', lambda *args, **kwargs: (0, '00:00:00', ''))
    setattr(am, 'get_bin_path', lambda *args, **kwargs: '/bin/systemctl')
    setattr(am, 'fail_json', lambda *args: None)
    setattr(am, 'exit_json', lambda *args: None)
    setattr(am, 'check_mode', False)
    setattr(am, 'warn', lambda *args: None)
   

# Generated at 2022-06-23 04:37:00.397350
# Unit test for function is_running_service

# Generated at 2022-06-23 04:37:03.260930
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('Not ignoring anything')



# Generated at 2022-06-23 04:37:15.546415
# Unit test for function main

# Generated at 2022-06-23 04:37:17.592873
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:37:24.306229
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('foo\n') is False
    assert request_was_ignored('foo=bar\n') is False
    assert request_was_ignored('ignoring request\n') is True
    assert request_was_ignored('ignoring command\n') is True
    assert request_was_ignored('load done.\n') is False
    assert request_was_ignored('foo\nignoring request\n') is False



# Generated at 2022-06-23 04:37:31.340028
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
     service_status = dict(ActiveState='active')
     assert is_running_service(service_status) is True
     service_status = dict(ActiveState='activating')
     assert is_running_service(service_status) is True
     service_status = dict(ActiveState='deactivating')
     assert is_deactivating_service(service_status) is True



# Generated at 2022-06-23 04:37:34.400910
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # Unit test for function is_deactivating_service with in set(['active', 'activating'])
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:37:43.243872
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def assert_equals(a, b):
        if a != b:
            raise AssertionError(a + ' != ' + b)
    assert_equals(parse_systemctl_show(['a=b', 'c=d']), {'a': 'b', 'c': 'd'})
    assert_equals(parse_systemctl_show(['a={', 'b', 'c}', 'd=e']), {'a': '{b\nc}', 'd': 'e'})
    assert_equals(parse_systemctl_show(['ExecStart={', 'foo', '}']), {'ExecStart': '{\nfoo\n}'})
    assert_equals(parse_systemctl_show(['ExecStart=foo']), {'ExecStart': 'foo'})

# Generated at 2022-06-23 04:37:51.216965
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test 1: simple case
    lines = ['foo=bar', 'baz=bat']
    expected = {'foo': 'bar', 'baz': 'bat'}
    assert parse_systemctl_show(lines) == expected

    # Test 2: multi-line values
    lines = ['ExecStart=\n  foo\n  bar\n', 'ExecStartPre=\n  baz\n  bat\n',
              'ExecStartPost=\n  qux\n  quux\n', 'ExecReload=\n  corge\n  grault\n']
    expected = {'ExecStart': 'foo\nbar', 'ExecStartPre': 'baz\nbat', 'ExecStartPost': 'qux\nquux',
                'ExecReload': 'corge\ngrault'}
    assert parse

# Generated at 2022-06-23 04:37:56.763713
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('= not ignored') is False
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('= not ignored, but got ignored') is False



# Generated at 2022-06-23 04:38:04.156365
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Loaded: loaded (Reason: ignored)')
    assert request_was_ignored('Loaded: loaded (Reason: ignoring request)')
    assert request_was_ignored('Loaded: loaded (Reason: ignoring command)')
    assert request_was_ignored('Loaded: loaded (Reason: ignoring request. Unit is a template)')
    assert not request_was_ignored('Loaded: loaded (Reason: not ignored)')



# Generated at 2022-06-23 04:38:15.737528
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Id=crond.service',
        'Description={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=n/a ; stop_time=n/a ; pid=0 ; code=(null) ; status=0/0 }',
        'LoadState=loaded'
    ]
    expected = {
        'Id': 'crond.service',
        'Description': '{ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=n/a ; stop_time=n/a ; pid=0 ; code=(null) ; status=0/0 }',
        'LoadState': 'loaded'
    }

# Generated at 2022-06-23 04:38:20.097561
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:38:27.580797
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-23 04:38:31.045388
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('= not in')



# Generated at 2022-06-23 04:38:39.377740
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('Sat Feb 21 09:16:07 PST 2015: ignoring request')
    assert request_was_ignored('Sat Feb 21 09:16:07 PST 2015: ignoring command')
    assert not request_was_ignored('Reloading')
    assert not request_was_ignored('Reloading.')
    assert not request_was_ignored('Reloading..')
    assert not request_was_ignored('Reloading...')
    assert not request_was_ignored('Reloading....')
    assert not request_was_ignored('Reloading.....')
    assert not request_was_ignored('Reloading......')



# Generated at 2022-06-23 04:38:41.265040
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') == True
    assert request_was_ignored('ignoring command') == True
    assert request_was_ignored('=') == False



# Generated at 2022-06-23 04:38:50.394888
# Unit test for function is_running_service
def test_is_running_service():
    running_service = {'ActiveState': 'active'}
    assert is_running_service(running_service)
    running_service = {'ActiveState': 'activating'}
    assert is_running_service(running_service)
    running_service = {'ActiveState': 'inactive'}
    assert not is_running_service(running_service)
    running_service = {'ActiveState': 'deactivating'}
    assert not is_running_service(running_service)


# Generated at 2022-06-23 04:39:04.824707
# Unit test for function main
def test_main():

    import os
    import shutil
    import sys
    import tempfile

    # Make a dummy module and run module code against it
    class FakeModule:

        def __init__(self, **kwarg):
            self.params = kwarg
            self.fail_json = lambda **kwarg: sys.exit(1)
            self.exit_json = lambda **kwarg: sys.exit(0)
            self.params['name'] = 'systemd-logind'

        def fail_json(self, **kwargs):
            self.exit_json(failed=True, **kwargs)

        def run_command(self, cmd, check_rc=True):
            return os.system(cmd), '', ''

    module = FakeModule(state='reloaded', daemon_reload=True)

# Generated at 2022-06-23 04:39:07.592370
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:39:10.070840
# Unit test for function main
def test_main():
    print("Running test code")
    print(sysv_is_enabled("fun"))

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:13.022501
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(test_status) is True
    test_status = {'ActiveState': 'inactive'}
    assert is_deactivating_service(test_status) is False



# Generated at 2022-06-23 04:39:20.213644
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # ExecStart= is a single-line value
    # Description= is a single-line value
    # ExecStartPre= is a multi-line value
    teststr = """
ExecStart=/bin/sh -c 'exec /usr/sbin/sshd -D $SSHD_OPTS'
Description=OpenSSH server daemon
ExecStartPre={ path=/usr/bin/ssh-keygen ; argv[]=/usr/bin/ssh-keygen -A ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
"""
    parsed = parse_systemctl_show(teststr.split('\n'))

# Generated at 2022-06-23 04:39:26.458776
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for httpd.service failed because the control process exited with error code. See "systemctl status httpd.service" and "journalctl -xe" for details.')
    assert not request_was_ignored('Job for httpd.service failed. See "systemctl status httpd.service" and "journalctl -xe" for details.')
# End unit test



# Generated at 2022-06-23 04:39:28.815559
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('foo ignoring foo')
    assert request_was_ignored('foo ignoring request foo')
    assert request_was_ignored('foo ignoring command foo')
    assert not request_was_ignored('foo bar foo')



# Generated at 2022-06-23 04:39:35.618103
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({ 'ActiveState': 'active' }) is True
    assert is_running_service({ 'ActiveState': 'activating' }) is True
    assert is_running_service({ 'ActiveState': 'inactive' }) is False
    assert is_running_service({ 'ActiveState': 'deactivating' }) is False
    assert is_running_service({ 'ActiveState': 'failed' }) is False
    # Any other value is False
    assert is_running_service({ 'ActiveState': 'nonsense' }) is False
    assert is_running_service({ 'ActiveState': 'true' }) is False
    assert is_running_service({ 'ActiveState': 'false' }) is False



# Generated at 2022-06-23 04:39:46.292841
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['foo=bar']) == {'foo': 'bar'}
    assert parse_systemctl_show(['foo=bar', 'baz=quux']) == {'foo': 'bar', 'baz': 'quux'}
    assert parse_systemctl_show(['foo=bar\n']) == {'foo': 'bar'}
    assert parse_systemctl_show(['foo=bar\n', 'baz=quux']) == {'foo': 'bar', 'baz': 'quux'}
    assert parse_systemctl_show(['foo={', ' bar', '}']) == {'foo': '{ bar }'}