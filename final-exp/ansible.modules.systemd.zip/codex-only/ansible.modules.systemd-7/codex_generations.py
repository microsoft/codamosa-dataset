

# Generated at 2022-06-23 04:29:43.570204
# Unit test for function main

# Generated at 2022-06-23 04:29:58.524120
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:30:00.152647
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:04.421110
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for foo.service failed.\nSee "systemctl status foo.service" and "journalctl -xe" for details.\n') is False
    assert request_was_ignored('Failed to start foo.service: Unit foo.service not found.\n') is False
    assert request_was_ignored('● foo.service - foo\n   Loaded: loaded (/etc/systemd/system/foo.service; ignored)\n') is True
    assert request_was_ignored('Failed to restart foo.service: Unit foo.service not loaded.\n') is True



# Generated at 2022-06-23 04:30:08.573899
# Unit test for function main
def test_main():
    from ansible.module_utils.common.removed import removed_module
    removed_module("unit test for function main")

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:18.661522
# Unit test for function main

# Generated at 2022-06-23 04:30:22.833477
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # Unit test for function is_deactivating_service
    # this test is expected to fail
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:30:34.912252
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:37.868388
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored(' = inactive')
    assert not request_was_ignored(' = active')



# Generated at 2022-06-23 04:30:48.614844
# Unit test for function is_running_service

# Generated at 2022-06-23 04:30:58.904399
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': ''})



# Generated at 2022-06-23 04:31:07.150369
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:14.940657
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_status_data = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(test_status_data) is True
    test_status_data['ActiveState'] = 'active'
    assert is_deactivating_service(test_status_data) is False
    test_status_data['ActiveState'] = 'activating'
    assert is_deactivating_service(test_status_data) is False



# Generated at 2022-06-23 04:31:22.899751
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'reloading'}) == False
    assert is_running_service({'ActiveState': 'deactivating'}) == False
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'failed'}) == False



# Generated at 2022-06-23 04:31:26.734149
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring request'))
    assert(request_was_ignored('ignoring command'))
    assert(not request_was_ignored('=1'))
    assert(not request_was_ignored('= done - ignored'))
    assert(not request_was_ignored('= ignoring(ignored)'))



# Generated at 2022-06-23 04:31:30.136604
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:31:41.628699
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Single line value
    text = "Key=Value"
    result = parse_systemctl_show(text.split('\n'))
    assert len(result) == 1
    assert 'Key' in result
    assert result['Key'] == 'Value'
    # Multi-line value for key starting with Exec
    text = "ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
    result = parse_systemctl_show(text.split('\n'))
    assert len(result) == 1
    assert 'ExecStart' in result
    assert result['ExecStart'] == text
   

# Generated at 2022-06-23 04:31:51.171886
# Unit test for function main

# Generated at 2022-06-23 04:31:56.949615
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'reloading'})



# Generated at 2022-06-23 04:32:10.513421
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:14.295999
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request: unit not loaded')
    assert not request_was_ignored('running')
    assert not request_was_ignored('Failed to reload')



# Generated at 2022-06-23 04:32:19.032957
# Unit test for function main
def test_main():
    import json
    import os
    import pytest
    import tempfile
    import shutil
    import stat
    import sys
    import mock

    print("Running unit test for function main")

    Path("/etc/systemd/system/systemd-test.service").touch()
    Path("/lib/systemd/system/systemd-test.service").touch()
    Path("/usr/lib/systemd/system/systemd-test.service").touch()

    with mock.patch('ansible.module_utils.basic.AnsibleModule.__init__') as ami:
        ami.return_value = None

# Generated at 2022-06-23 04:32:24.372605
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    module = AnsibleModule({'service_status': {'ActiveState': 'deactivating'}})
    y = AnsibleModule({'service_status': {'ActiveState': 'other'}})
    assert is_deactivating_service(module) is True
    assert is_deactivating_service(y) is False



# Generated at 2022-06-23 04:32:28.074504
# Unit test for function main
def test_main():
    from ansible.modules.remote_management.system import service
    import pytest
    with pytest.raises(SystemExit):
        service.main()

# Generated at 2022-06-23 04:32:38.783019
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        with mock.patch.object(os, 'geteuid') as mock_geteuid:
            mock_geteuid.return_value = 1234
            with mock.patch.object(os, 'getenv') as mock_getenv:
                mock_getenv.return_value = None
                main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0


# import module snippets
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:44.949604
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status)
    service_status = {'ActiveState': 'activating'}
    assert is_running_service(service_status)
    service_status = {'ActiveState': 'inactive'}
    assert not is_running_service(service_status)



# Generated at 2022-06-23 04:32:50.996508
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'SubState': 'running', 'ActiveState': 'active'})
    assert is_running_service({'SubState': 'running', 'ActiveState': 'activating'})
    assert not is_running_service({'SubState': 'failed', 'ActiveState': 'deactivating'})
    assert not is_running_service({'SubState': 'running', 'ActiveState': 'deactivating'})
    assert not is_running_service({'SubState': 'failed', 'ActiveState': 'active'})
    assert not is_running_service({'SubState': 'running', 'ActiveState': 'failed'})



# Generated at 2022-06-23 04:33:01.006449
# Unit test for function main
def test_main():
    reload(sys)
    # noinspection PyUnresolvedReferences
    sys.setdefaultencoding("utf-8")

    import os
    import tempfile
    import shutil
    import json

    class ModuleMock(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.fail_json_msg = None
            self.fail_json_calls = []
            self.exit_json_calls = []
            self.exit_json_kwargs = None


# Generated at 2022-06-23 04:33:03.250751
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:33:07.121251
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('some=out') is False
    assert request_was_ignored('some=out ignore=foo') is False
    assert request_was_ignored('some=out ignore=foo ignoring request to foo') is True



# Generated at 2022-06-23 04:33:15.392606
# Unit test for function is_running_service
def test_is_running_service():
    mock_status = {}
    assert not is_running_service(mock_status)
    mock_status['ActiveState'] = 'inactive'
    assert not is_running_service(mock_status)
    mock_status['ActiveState'] = 'active'
    assert is_running_service(mock_status)
    mock_status['ActiveState'] = 'activating'
    assert is_running_service(mock_status)



# Generated at 2022-06-23 04:33:23.166869
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    if is_running_service({'ActiveState': 'active'}) and is_running_service({'ActiveState': 'activating'}) and not is_running_service({'ActiveState': 'inactive'}):
        assert True
    if not is_deactivating_service({'ActiveState': 'deactivating'}) and not is_deactivating_service({'ActiveState': 'activating'}):
        assert True



# Generated at 2022-06-23 04:33:27.661443
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState':'deactivating'}) is True
    assert is_deactivating_service({'ActiveState':'inactive'}) is False
    assert is_deactivating_service({'ActiveState':'active'}) is False


# Generated at 2022-06-23 04:33:30.575770
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:33:36.722010
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:45.238893
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})
    assert not is_deactivating_service({'ActiveState': 'failed'})
    assert not is_deactivating_service({'ActiveState': 'Unknown'})



# Generated at 2022-06-23 04:33:48.315278
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:33:53.051054
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': "deactivating"}) is True
    assert is_deactivating_service({'ActiveState': "active"}) is False
    assert is_deactivating_service({'ActiveState': "activating"}) is False



# Generated at 2022-06-23 04:34:06.403407
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:18.625324
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('this is a string that includes no =')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('Loaded: loaded (Reason: Unit was started with --job-mode=ignore-dependencies.')
    assert not request_was_ignored('Loaded: loaded (Reason: Job mode was set to ignore.)')
    assert not request_was_ignored('Loaded: loaded (Reason: Job mode was set to replace.)')
    assert not request_was_ignored('Loaded: loaded (Reason: Job mode was set to replace-irreversibly.)')
    assert not request_was_ignored('Loaded: loaded (Reason: Job mode was set to isotask.)')
    # Fixture value for tests


# Generated at 2022-06-23 04:34:33.149977
# Unit test for function main

# Generated at 2022-06-23 04:34:42.230496
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:55.547600
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:03.345786
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('''Failed to start postgresql.service: Unit postgresql.service entered failed state.
See system logs and 'systemctl status postgresql.service' for details.''') is False
    assert request_was_ignored('''Failed to start chef-client.service: Unit chef-client.service failed to load: No such file or directory.''') is False
    assert request_was_ignored('''Ignoring request to reload systemd-logind.service: disabled by configuration''') is True
    assert request_was_ignored('''Ignoring command Scheduled startup of postfix.service, as it does not exist.''') is True
    assert request_was_ignored('''Ignoring command Scheduled startup of systemd-remount-api-vfs.service, as it does not exist.''')

# Generated at 2022-06-23 04:35:16.798092
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
            'InstalledBy=anaconda',
            'ShouldNotBeAssignedToAVariable=bar',
            'ExecStart={ path=/usr/bin/systemctl ; argv[]=/usr/bin/systemctl start user-0.slice }',
            'ExecStart={ path=/usr/bin/systemctl ; argv[]=/usr/bin/systemctl start user-0.slice ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
        ]
    parsed = parse_systemctl_show(lines)
    assert 'InstalledBy' in parsed
    assert 'ShouldNotBeAssignedToAVariable' in parsed
    assert 'ExecStart' in parsed

# Generated at 2022-06-23 04:35:25.858025
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'Id': 'httpd.service', 'ActiveState': 'active'}) is True
    assert is_running_service({'Id': 'httpd.service', 'ActiveState': 'activating'}) is True
    assert is_running_service({'Id': 'httpd.service', 'ActiveState': 'inactive'}) is False
    assert is_running_service({'Id': 'httpd.service', 'ActiveState': 'deactivating'}) is False



# Generated at 2022-06-23 04:35:33.454921
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_values = dict()
    test_values[dict(ActiveState='active')] = True
    test_values[dict(ActiveState='activating')] = True
    test_values[dict(ActiveState='deactivating')] = False
    test_values[dict(ActiveState='inactive')] = False
    test_values[dict(ActiveState='failed')] = False

    for value, expected in test_values.items():
        #return_value = {'ActiveState': value}
        return_value = dict()
        return_value['ActiveState'] = value
        result = is_deactivating_service(return_value)
        assert result == expected



# Generated at 2022-06-23 04:35:39.491613
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False



# Generated at 2022-06-23 04:35:45.362605
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:58.708568
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Simulate the output of 'systemctl show' for a unit file with a multi-line value for ExecStart=
    lines = [
        "Id=example.service",
        "Description=Example Service",
        "After=network.target",
        "ExecStart={\n"
        "    ExecStart=/bin/bash -c \"while true; do echo hi; sleep 1; done\"\n"
        "    }",
        "ExecReload=",
        "WantedBy=multi-user.target"
    ]
    parsed = parse_systemctl_show(lines)
    assert parsed['Id'] == 'example.service'
    assert parsed['Description'] == 'Example Service'
    assert parsed['After'] == 'network.target'

# Generated at 2022-06-23 04:36:12.430189
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Single line values for all keys
    test_input_lines = """Description=Foo"""
    test_output_expected = {'Description': 'Foo'}
    test_output_actual = parse_systemctl_show(test_input_lines.splitlines())
    assert test_output_actual == test_output_expected

    # Single line value for key 'Description=' which also starts with '{'
    test_input_lines = """Description={ Redirecting to /bin/systemctl start  crond.service }"""
    test_output_expected = {'Description': '{ Redirecting to /bin/systemctl start  crond.service }'}
    test_output_actual = parse_systemctl_show(test_input_lines.splitlines())
    assert test_output_actual == test_output_expected

    # Single line value

# Generated at 2022-06-23 04:36:20.694122
# Unit test for function is_running_service
def test_is_running_service():
    mock_obj = {'ActiveState': 'active'}
    assert is_running_service(mock_obj) is True
    mock_obj = {'ActiveState': 'activating'}
    assert is_running_service(mock_obj) is True
    mock_obj = {'ActiveState': 'deactivating'}
    assert is_running_service(mock_obj) is False
    mock_obj = {'ActiveState': 'inactive'}
    assert is_running_service(mock_obj) is False
    mock_obj = {'ActiveState': 'failed'}
    assert is_running_service(mock_obj) is False



# Generated at 2022-06-23 04:36:26.271633
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    deactivating_service = {'ActiveState': 'deactivating'}
    inactive_service = {'ActiveState': 'inactive'}
    assert is_deactivating_service(deactivating_service)
    assert not is_deactivating_service(inactive_service)



# Generated at 2022-06-23 04:36:28.103428
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:39.003939
# Unit test for function main
def test_main():
    test_args = {
        'name': 'nginx',
        'enabled': True,
        'state': 'started',
        'masked': False,
        'daemon_reload': True,
        'daemon_reexec': True,
        'scope': 'system',
        'no_block': False,
        'force': False,
    }


# Generated at 2022-06-23 04:36:41.436492
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"}) is True



# Generated at 2022-06-23 04:36:45.426485
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:36:58.612570
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(["foo=bar"]) == {"foo": "bar"}
    assert parse_systemctl_show(["ExecStart=foo"]) == {"ExecStart": "foo"}
    assert parse_systemctl_show(["ExecStart={foo}"]) == {"ExecStart": "{foo}"}
    assert parse_systemctl_show(["ExecStart={foo", "bar}"]) == {"ExecStart": "{foo\nbar}"}
    assert parse_systemctl_show(["ExecStart={foo\nbar}"]) == {"ExecStart": "{foo\nbar}"}
    assert parse_systemctl_show(["ExecStart={foo\nbar\nbaz}"]) == {"ExecStart": "{foo\nbar\nbaz}"}

# Generated at 2022-06-23 04:37:04.567688
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'foo_bar_something'})



# Generated at 2022-06-23 04:37:06.854535
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')



# Generated at 2022-06-23 04:37:19.619701
# Unit test for function main
def test_main():
    # init
    module = AnsibleModule({}, {})

    # unit tests
    # test parse_systemctl_status_line
    #    test transform
    assert parse_systemctl_status_line('a=b') == ('a', 'b')
    assert parse_systemctl_status_line('a= b') == ('a', 'b')
    assert parse_systemctl_status_line('a =b ') == ('a', 'b')
    assert parse_systemctl_status_line('a = b') == ('a', 'b')
    assert parse_systemctl_status_line('a   =   b') == ('a', 'b')
    #    test multiple equals
    assert parse_systemctl_status_line('a=b=c') == ('a', 'b=c')
    assert parse_systemctl_status_

# Generated at 2022-06-23 04:37:21.733685
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('some data')



# Generated at 2022-06-23 04:37:29.343067
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {
        'ActiveState': 'active'
    }
    assert is_running_service(service_status)
    service_status = {
        'ActiveState': 'activating'
    }
    assert is_running_service(service_status)
    service_status = {
        'ActiveState': 'inactive'
    }
    assert not is_running_service(service_status)
    service_status = {
        'ActiveState': 'deactivating'
    }
    assert not is_running_service(service_status)
    service_status = {
        'ActiveState': 'failed'
    }
    assert not is_running_service(service_status)
    service_status = {
        'ActiveState': 'unknown'
    }
    assert not is_running_service(service_status)

# Generated at 2022-06-23 04:37:41.791075
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    """Test function is_deactivating_service"""
    failed = False

# Generated at 2022-06-23 04:37:49.819963
# Unit test for function main
def test_main():
    test_unit = "sshd"
    test_state = "stopped"
    test_enabled = True
    test_masked = True
    test_daemon_reload = True
    test_daemon_reexec = True
    test_no_block = True

    test_args = dict(
        name=test_unit,
        state=test_state,
        enabled=test_enabled,
        masked=test_masked,
        daemon_reload=test_daemon_reload,
        daemon_reexec=test_daemon_reexec,
        no_block=test_no_block,
        force=False,
    )


# Generated at 2022-06-23 04:37:58.311760
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'deactivating'}) == False
    assert is_running_service({}) == False
    assert is_running_service({'ActiveState': 'bad'}) == False



# Generated at 2022-06-23 04:38:07.557024
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def normalize(s):
        s = s.strip()
        return s.rstrip('\n')

# Generated at 2022-06-23 04:38:18.591633
# Unit test for function request_was_ignored

# Generated at 2022-06-23 04:38:23.635594
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('something = 1')
    assert not request_was_ignored('other message')



# Generated at 2022-06-23 04:38:36.177973
# Unit test for function main
def test_main():
    sys.modules['ansible'] = MagicMock()
    sys.modules['ansible.module_utils.basic'] = MagicMock()
    sys.modules['ansible.module_utils.basic'].module_running_under_virtualenv = MagicMock(return_value=False)
    sys.modules['ansible.module_utils.basic'].AnsibleModule = MagicMock()
    import site
    sys.modules['site'] = MagicMock()
    sys.modules['site'].getsitepackages = MagicMock()
    sys.modules['site'].getsitepackages.return_value = []
    sys.modules['ansible.module_utils.six'] = MagicMock()
    sys.modules['ansible.module_utils.six'].PY3 = False

# Generated at 2022-06-23 04:38:47.540152
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('Life=42')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request and more')


# ===========================================
# Module execution.
#
# This module is based on AnsibleModule and supports the `run_command` plugin hook.


# Generated at 2022-06-23 04:38:57.536539
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'unknown'})
    assert is_running_service({'ActiveState': 'active'})
    assert not is_running_service({'ActiveState': 'reloading'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'dead'})



# Generated at 2022-06-23 04:39:02.717458
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:39:07.338936
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'deactivating-reload'})



# Generated at 2022-06-23 04:39:16.692837
# Unit test for function request_was_ignored

# Generated at 2022-06-23 04:39:19.554901
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to start service.target: Transaction is destructive.')
    assert not request_was_ignored('')
    assert request_was_ignored('Ignoring request to reload C(sshd.service): unit is masked.')
    assert not request_was_ignored('Reloading OpenBSD Secure Shell server.')
    assert request_was_ignored('Ignoring command.')



# Generated at 2022-06-23 04:39:27.944406
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring command.')
    assert request_was_ignored('Ignoring request.')
    assert request_was_ignored('Ignoring command.\n')
    assert request_was_ignored('Ignoring request.\n')
    assert request_was_ignored('Ignoring command.\nRunning transaction...')
    assert request_was_ignored('Ignoring request.\nRunning transaction...')
    assert not request_was_ignored('Running transaction...')



# Generated at 2022-06-23 04:39:30.805505
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState":"deactivating"}) is True
    assert is_deactivating_service({"ActiveState":"activating"}) is False



# Generated at 2022-06-23 04:39:36.958625
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('unit ignored')
    assert request_was_ignored('ignoring command: reload')
    assert request_was_ignored('cmd ignored')
    assert not request_was_ignored('garbage')
    assert not request_was_ignored('=garbage')

