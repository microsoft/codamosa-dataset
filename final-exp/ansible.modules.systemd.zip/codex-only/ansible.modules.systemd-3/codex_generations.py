

# Generated at 2022-06-23 04:29:37.938512
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring request'))



# Generated at 2022-06-23 04:29:45.875219
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_cases = [
        {'ActiveState': 'deactivating', 'expected': True},
        {'ActiveState': 'inactive', 'expected': False},
        {'ActiveState': 'unknown', 'expected': False}
    ]
    for case in test_cases:
        if is_deactivating_service(case) != case['expected']:
            raise AssertionError(
                'Test case %s failed: %s returned %s, expected %s' %
                (case, is_deactivating_service.func_name,
                 not case['expected'], case['expected']))



# Generated at 2022-06-23 04:29:55.507465
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'running'})
    assert is_running_service({'ActiveState': 'starting'})
    assert is_running_service({'ActiveState': 'reloading'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'exited'})
    assert not is_running_service({'ActiveState': 'dead'})



# Generated at 2022-06-23 04:30:04.171879
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) == False, 'Inactive state should return False'
    assert is_running_service({'ActiveState': 'activating'}) == True, 'activating state should return True'
    assert is_running_service({'ActiveState': 'active'}) == True, 'active state should return True'
    assert is_running_service({'ActiveState': 'deactivating'}) == False, 'deactivating state should return False'
    assert is_running_service({'ActiveState': 'failed'}) == False, 'failed state should return False'


# Generated at 2022-06-23 04:30:10.989616
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'dead'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:30:13.761225
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') == True
    assert request_was_ignored('[  OK  ]') == False
    assert request_was_ignored('ignoring command') == True



# Generated at 2022-06-23 04:30:19.915420
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('foo') is False
    assert request_was_ignored('foo=bar') is False
    assert request_was_ignored('foo\nbar=baz') is False
    assert request_was_ignored('foo\nbar=baz\n') is False
    assert request_was_ignored('foo\nbar=baz\nabc ignoring command') is True
    assert request_was_ignored('foo\nbar=baz\nabc ignoring request') is True
    assert request_was_ignored('foo\nbar=baz\nabc ignoring requested') is False
    assert request_was_ignored('foo\nbar=baz\nabc requesting ignore') is False
    assert request_was_ignored('foo\nbar=baz\nabc ignoring') is False



# Generated at 2022-06-23 04:30:33.293141
# Unit test for function main
def test_main():
    unit = 'sshd'
    result = dict(
        name=unit,
        changed=False,
        status=dict(),
    )

    if unit:
        found = False
        is_initd = sysv_exists(unit)
        is_systemd = False

        # check service data, cannot error out on rc as it changes across versions, assume not found
        systemctl = module.get_bin_path('systemctl', True)
        (rc, out, err) = module.run_command("%s show '%s'" % (systemctl, unit))

        if rc == 0 and not (request_was_ignored(out) or request_was_ignored(err)):
            # load return of systemctl show into dictionary for easy access and return
            if out:
                result['status'] = parse_systemctl_show

# Generated at 2022-06-23 04:30:43.970394
# Unit test for function main

# Generated at 2022-06-23 04:30:58.756881
# Unit test for function main
def test_main():
    import os
    import json
    import time
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.systemd import systemd


# Generated at 2022-06-23 04:31:08.736511
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('Ignoring request')
    assert request_was_ignored('Ignoring command')
    assert request_was_ignored('ignoring request: foo=bar')
    assert request_was_ignored('ignoring command: foo=bar')
    assert request_was_ignored('Ignoring request: foo=bar')
    assert request_was_ignored('Ignoring command: foo=bar')
    assert not request_was_ignored('foo=bar')
    assert not request_was_ignored('foo')



# Generated at 2022-06-23 04:31:12.341848
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo=')



# Generated at 2022-06-23 04:31:13.959833
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:23.748741
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:28.269500
# Unit test for function main
def test_main():
    with open("unit_test.txt", "r") as file:
        data = file.readlines()
    data = str(data)
    result = parse_systemctl_show(data.split("\n"))
    assert result['ActiveState'] == 'active'

# Generated at 2022-06-23 04:31:36.224097
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("""
Job for xyz.service failed because the control process exited with error code.
See "systemctl status xyz.service" and "journalctl -xe" for details.
""")
    assert not request_was_ignored("""
  Job for xyz.service failed because the control process exited with error code.
  See "systemctl status xyz.service" and "journalctl -xe" for details.
  """)



# Generated at 2022-06-23 04:31:43.685895
# Unit test for function is_running_service
def test_is_running_service():

    # NOT running
    assert is_running_service({"ActiveState": 'inactive',
                               "SubState": 'dead'}) is False

    # running
    assert is_running_service({"ActiveState": 'active',
                               "SubState": 'dead'}) is True

    # running
    assert is_running_service({"ActiveState": 'activating',
                               "SubState": 'dead'}) is True

    # NOT running
    assert is_running_service({"ActiveState": 'reloading',
                               "SubState": 'dead'}) is False

    # NOT running
    assert is_running_service({"ActiveState": 'deactivating',
                               "SubState": 'dead'}) is False

    # NOT running

# Generated at 2022-06-23 04:31:47.440300
# Unit test for function is_deactivating_service
def test_is_deactivating_service():

    # setup
    test_answer={'ActiveState': 'deactivating'}
    test_answer2={'ActiveState': 'active'}

    # Test
    assert is_deactivating_service(test_answer) is True
    assert is_deactivating_service(test_answer2) is False


# Generated at 2022-06-23 04:31:52.492329
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    my_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(my_status) is True
    my_status = {'ActiveState': 'active'}
    assert not is_deactivating_service(my_status)



# Generated at 2022-06-23 04:31:58.047971
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status)
    service_status = {'ActiveState': 'activating'}
    assert is_running_service(service_status)
    service_status = {'ActiveState': 'inactive'}
    assert not is_running_service(service_status)



# Generated at 2022-06-23 04:32:11.560860
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("xyz") is False
    assert request_was_ignored("=xyz") is False
    assert request_was_ignored("ignoring request") is True
    assert request_was_ignored("ignoring command") is True


# Syntax for the service state is: key: (desired, current, rc)

# Generated at 2022-06-23 04:32:17.007463
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Job for postgresql-9.6.service failed because the control process exited with error code. See \"systemctl status postgresql-9.6.service\" and \"journalctl -xe\" for details.\n")
    assert not request_was_ignored("Created symlink from /etc/systemd/system/multi-user.target.wants/postfix.service to /usr/lib/systemd/system/postfix.service.\n")
    assert not request_was_ignored("Removed symlink /etc/systemd/system/multi-user.target.wants/postfix.service.\n")

# Generated at 2022-06-23 04:32:29.515770
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:43.705252
# Unit test for function main

# Generated at 2022-06-23 04:32:52.027136
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Ignoring request to stop unit foo via API, as it is not loaded.")
    assert request_was_ignored("Ignoring command stop for unit foo, as it is not loaded.")
    assert not request_was_ignored("Failed to start foo.service: Connection timed out")
    assert request_was_ignored("Job for thefoo.service failed because the control process exited with error code.")
    assert not request_was_ignored("Failed to start thefoo.service: Connection timed out")
    assert not request_was_ignored("= foo.service - My service\n")



# Generated at 2022-06-23 04:32:56.008922
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) is True
    service_status = {'ActiveState': 'inactive'}
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-23 04:32:59.171927
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='inactive'))



# Generated at 2022-06-23 04:33:05.800328
# Unit test for function is_running_service
def test_is_running_service():
    assert(is_running_service({'ActiveState': 'active'}))
    assert(is_running_service({'ActiveState': 'activating'}))
    assert(not is_running_service({'ActiveState': 'failed'}))
    assert(not is_running_service({'ActiveState': 'inactive'}))
    assert(not is_running_service({'ActiveState': 'deactivating'}))


# Generated at 2022-06-23 04:33:15.300411
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = { 'ActiveState': "deactivating" }
    assert is_deactivating_service(service_status) is True
    service_status = { 'ActiveState': "anything else" }
    assert is_deactivating_service(service_status) is False
    service_status = { 'ActiveState': "activating" }
    assert is_deactivating_service(service_status) is False
    service_status = { 'ActiveState': "active" }
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-23 04:33:23.302515
# Unit test for function main
def test_main():
    import sys
    ansible_module = sys.modules['ansible.module_utils.basic']

    copy_of_fail_json = ansible_module.fail_json
    copy_of_exit_json = ansible_module.exit_json
    ansible_module.fail_json = lambda *args: [args]
    ansible_module.exit_json = lambda *args: [args]
    try:
        assert main() == [{
            'changed': False,
            'name': None,
            'status': {},
        }]
    finally:
        ansible_module.fail_json = copy_of_fail_json
        ansible_module.exit_json = copy_of_exit_json

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:31.107465
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='dead'))
    assert not is_running_service(dict(ActiveState='deactivating'))
    assert not is_running_service(dict(ActiveState='inactive'))
    assert not is_running_service(dict(ActiveState='failed'))
    assert not is_running_service(dict(ActiveState='failing'))



# Generated at 2022-06-23 04:33:38.778142
# Unit test for function main

# Generated at 2022-06-23 04:33:42.052130
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:33:53.984195
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:07.523556
# Unit test for function main

# Generated at 2022-06-23 04:34:10.431506
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:23.965844
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:30.163459
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'unknown'}) == False



# Generated at 2022-06-23 04:34:34.556285
# Unit test for function is_running_service
def test_is_running_service():
    return_values = [{
        'ActiveState': 'active',
        'SubState': 'running',
        }, {
        'ActiveState': 'active',
        'SubState': 'running',
        }, {
        'ActiveState': 'activating',
        'SubState': 'start-pre',
        }, {
        'ActiveState': 'some-intermediate-state',
        'SubState': 'running',
        }, {
        'ActiveState': 'inactive',
        'SubState': 'running',
        }]
    return_codes = [True, True, True, False, False]
    for return_value, return_code in zip(return_values, return_codes):
        assert is_running_service(return_value) == return_code
# END unit test



# Generated at 2022-06-23 04:34:36.471250
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status)



# Generated at 2022-06-23 04:34:43.175126
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    assert is_deactivating_service({}) is False



# Generated at 2022-06-23 04:34:53.045637
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:05.414506
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # pylint: disable=line-too-long
    # Simple test
    lines = ('Key1=Value1\n', 'Key2=Value2')
    parsed = parse_systemctl_show(lines)
    assert parsed['Key1'] == 'Value1' and parsed['Key2'] == 'Value2'
    # Test value with '=' in it (the value for Description= can contain '=')
    lines = ('Key1=Value1\n', 'Key2=Value2=Value3')
    parsed = parse_systemctl_show(lines)
    assert parsed['Key1'] == 'Value1' and parsed['Key2'] == 'Value2=Value3'
    # Test multi-line value

# Generated at 2022-06-23 04:35:11.809266
# Unit test for function is_deactivating_service

# Generated at 2022-06-23 04:35:25.913845
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:34.288142
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # test single-line value
    lines = ["BindsTo=foo.service"]
    assert(parse_systemctl_show(lines) == {"BindsTo": "foo.service"})
    # test single-line value that starts with {
    lines = ["BindsTo={foo.service"]
    assert(parse_systemctl_show(lines) == {"BindsTo": "{foo.service"})
    # test multi-line value that starts with {
    lines = ["BindsTo={foo.service", "bar.service}"]
    assert(parse_systemctl_show(lines) == {"BindsTo": "{foo.service\nbar.service}"})
    # test multi-line value that starts with { and spans multiple lines
    lines = ["BindsTo={foo.service", "bar.service", "baz.service}"]


# Generated at 2022-06-23 04:35:45.375835
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:58.708943
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:02.889883
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert(is_deactivating_service({'ActiveState': 'deactivating'}))  # NOQA



# Generated at 2022-06-23 04:36:05.052698
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:09.334023
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    running = {'ActiveState': 'deactivating'}
    inactive = {'ActiveState': 'inactive'}
    assert is_deactivating_service(running)
    assert not is_deactivating_service(inactive)



# Generated at 2022-06-23 04:36:16.270780
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # The first example lines were taken from fatal errors. The final example
    # was taken from successful execution.
    assert request_was_ignored("Failed to get D-Bus connection: Operation not permitted\n")
    assert not request_was_ignored("   [119b8efe..., 119b8efe...]")
    assert not request_was_ignored("  119b8efe...")



# Generated at 2022-06-23 04:36:29.283201
# Unit test for function main

# Generated at 2022-06-23 04:36:33.927008
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True
    assert is_deactivating_service({'ActiveState': 'active'}) == False
    assert is_deactivating_service({'ActiveState': 'activating'}) == False



# Generated at 2022-06-23 04:36:40.705859
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:46.348841
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('')
    assert request_was_ignored(' ')
    assert not request_was_ignored('='*70)
    assert not request_was_ignored('Unit foobar.service could not be found.')



# Generated at 2022-06-23 04:36:59.590206
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    from ansible.module_utils.systemd import _parse_systemctl_show

    module = AnsibleModule(argument_spec={})
    assert is_chroot(module) is False
    assert sysv_is_enabled("/etc/init.d/foo") is False

    assert request_was_ignored("ignored") == True
    assert request_was_ignored("no results found") == True
    assert request_was_ignored("Unknown command") == True
    assert request_was_ignored("foo") == False

    module = AnsibleModule(argument_spec={'name': {'type': 'str'}, 'state': {'type': 'str'}})

# Generated at 2022-06-23 04:37:03.308670
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:37:08.657120
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': ''}) is False



# Generated at 2022-06-23 04:37:21.245006
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that single-line values are parsed correctly
    s = 'Key=Value'
    result = parse_systemctl_show([s])
    assert(len(result.keys()) == 1)
    assert(result['Key'] == 'Value')

    # Test that multi-line values are parsed correctly
    s = 'ExecStart={\n  Expected\n  multiline\n  value\n}'
    result = parse_systemctl_show([s])
    assert(len(result.keys()) == 1)
    assert(result['ExecStart'] == '\n'.join(s.split('=')[1].split()))

    # Test that trailing newlines are parsed correctly
    s = 'Key=Value\n\n'
    result = parse_systemctl_show([s])

# Generated at 2022-06-23 04:37:33.480837
# Unit test for function main
def test_main():

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', aliases=['service', 'unit']),
            state=dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped']),
            enabled=dict(type='bool'),
            force=dict(type='bool'),
            masked=dict(type='bool'),
            daemon_reload=dict(type='bool', default=False, aliases=['daemon-reload']),
            daemon_reexec=dict(type='bool', default=False, aliases=['daemon-reexec']),
            scope=dict(type='str', default='system', choices=['system', 'user', 'global']),
            no_block=dict(type='bool', default=False),
	    ),
    )

   

# Generated at 2022-06-23 04:37:45.037384
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    def test_manager(module):
        module.run_command = lambda cmd: (0, None, None)
        module.warn = lambda msg: None
        module.exit_json = lambda **kwargs: None

    def test_no_mananger(module):
        module.run_command = lambda cmd: (1, None, None)
        module.fail_json = lambda **kwargs: None
        module.warn = lambda msg: None


# Generated at 2022-06-23 04:37:47.189369
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to talk to init daemon.')
    assert not request_was_ignored('ActiveState=active')
    assert request_was_ignored('Ignoring request.')
    assert request_was_ignored('   ignoring command.')



# Generated at 2022-06-23 04:38:00.198697
# Unit test for function main
def test_main():
    unit = 'httpd'
    systemctl = 'systemctl'

# Generated at 2022-06-23 04:38:08.905106
# Unit test for function main
def test_main():
    # Tests that the module will crash if it is given invalid arguments
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import json
    args = {'name': 'httpd', 'state': 'started', 'enabled': True}
    module = AnsibleModule(argument_spec={
        'name': dict(),
        'state': dict(choices=['started', 'stopped', 'reloaded', 'restarted']),
        'enabled': dict(required=False, type='bool'),
        'scope': dict(required=False, type='str', choices=['system', 'user', 'global']),
    },
                           supports_check_mode=True)

# Generated at 2022-06-23 04:38:18.123894
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'unknown'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'activating', 'SubState': 'failed'})
    assert not is_running_service({'ActiveState': 'activating', 'SubState': 'deactivating'})



# Generated at 2022-06-23 04:38:24.769705
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([]) == {}
    assert parse_systemctl_show(['foo']) == {}
    assert parse_systemctl_show(['foo=bar']) == {'foo': 'bar'}
    assert parse_systemctl_show(['foo=', 'bar']) == {'foo': ''}
    assert parse_systemctl_show(['foo=bar', 'baz']) == {'foo': 'bar'}
    assert parse_systemctl_show(['foo=bar', 'baz=']) == {'foo': 'bar', 'baz': ''}
    assert parse_systemctl_show(['foo=bar=baz']) == {'foo': 'bar=baz'}

# Generated at 2022-06-23 04:38:29.718079
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {"ActiveState": "deactivating", "SubState": "service"}
    assert is_deactivating_service(service_status)
    service_status = {"ActiveState": "active"}
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-23 04:38:34.008619
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('warning: ignoring request, as unit state is inactive')
    assert request_was_ignored('warning: ignoring command, as unit state is inactive')
    assert not request_was_ignored('= inactive')



# Generated at 2022-06-23 04:38:45.129029
# Unit test for function is_running_service
def test_is_running_service():
    tests = [
        dict(
            service_status={'ActiveState': 'active'},
            result=True
        ),
        dict(
            service_status={'ActiveState': 'activating'},
            result=True
        ),
        dict(
            service_status={'ActiveState': 'inactive'},
            result=False
        ),
    ]
    for test in tests:
        assert is_running_service(test['service_status']) == test['result']



# Generated at 2022-06-23 04:38:54.708594
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'failed-start-job'})



# Generated at 2022-06-23 04:39:07.898127
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:39:11.103241
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as exec_info:
        main()
    assert exec_info.value.args[0]['changed'] == False

# unit test for function fail_if_missing

# Generated at 2022-06-23 04:39:19.932378
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    parsed = parse_systemctl_show(["this=that", "foo=bar", "key=value", "ExecStart={", "cmd1", "cmd2", "}", "end=finish"])
    assert parsed['ExecStart'] == "cmd1\ncmd2"
    assert parsed['this'] == "that"
    assert parsed['foo'] == "bar"
    assert parsed['key'] == "value"
    assert parsed['end'] == "finish"
    assert '=' not in ''.join(parsed.keys())
    # Test with multi-line value that doesn't end in }
    parsed = parse_systemctl_show(["this=that", "foo=bar", "key=value", "Description={", "long", "description", "end=finish"])
    assert parsed['Description'] == "long\ndescription"

# Generated at 2022-06-23 04:39:23.356542
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False



# Generated at 2022-06-23 04:39:28.938041
# Unit test for function main
def test_main():
    args = dict(
        daemon_reload=True,
    )
    module = AnsibleModule(argument_spec=dict( **args))
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:35.199381
# Unit test for function main
def test_main():
    def test_default_params():
        test_params = {}
        test_params['name'] = 'foo'
        test_params['daemon_reload'] = False
        test_params['daemon_reexec'] = False
        test_params['scope'] = 'system'
        test_params['no_block'] = False
        return test_params

    test_params = test_default_params()
    for key in test_params:
        setattr(g_module, 'params', {key: test_params[key]})
        main()

    g_module.params['name'] = None
    main()


# Generated at 2022-06-23 04:39:46.229085
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def check_rst(rst, check):
        for i in check:
            assert i in rst
            assert rst[i] == check[i]
    # test case 1
    show_output = [
        'User=root',
        'Restart=on-failure',
        'PIDFile=/run/dovecot/master.pid',
        'ExecStartPre=/usr/libexec/dovecot/prestartscript',
        'ExecStart=/usr/sbin/dovecot',
        'ExecReload=/bin/kill -s HUP $MAINPID',
        'ExecStop=/usr/sbin/dovecot stop-forced',
    ]