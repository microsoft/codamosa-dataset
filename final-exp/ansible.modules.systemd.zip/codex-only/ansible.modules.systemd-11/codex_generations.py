

# Generated at 2022-06-23 04:29:45.376137
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('Job for httpd.service failed')
    assert not request_was_ignored('Job for httpd.service canceled')
    assert request_was_ignored('Job for httpd.service failed because state has changed starting -> running')
    assert request_was_ignored('Unit httpd.service not found.')
    assert request_was_ignored('Job for httpd.service canceled because state has changed running -> stopping')
    assert request_was_ignored('httpd.service: main process exited, code=exited, status=1/FAILURE')
    assert request_was_ignored('Unit httpd.service cannot be reloaded because it is inactive.')



# Generated at 2022-06-23 04:29:47.781198
# Unit test for function main
def test_main():
    # If a unit test for the module is written, place it here.
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:01.239240
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # test that function can handle a file with no multiline value
    lines = [
        'Id=my.service',
        'Description=This is a test',
        'ExecStart={ path=/usr/bin ; argv[]=/usr/bin/echo test'
    ]
    parsed = parse_systemctl_show(lines)
    assert 'Id' in parsed
    assert parsed['Id'] == 'my.service'
    assert 'Description' in parsed
    assert parsed['Description'] == 'This is a test'
    assert 'ExecStart' not in parsed

    # test that function can handle a file with a multiline value

# Generated at 2022-06-23 04:30:03.559164
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = dict(ActiveState='deactivating')
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:30:12.706312
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    assert is_deactivating_service({'ActiveState': 'unknown'}) is False
    assert is_deactivating_service({}) is False
    assert is_deactivating_service({'ActiveState': 'deactivating', 'SubState': 'abcd'}) is True
    assert is_deactivating_service({'ActiveState': 'active', 'SubState': 'abcd'}) is False
    assert is_deactivating_service({'ActiveState': 'unknown', 'SubState': 'abcd'}) is False
    assert is_deactivating_service({'SubState': 'abcd'}) is False



# Generated at 2022-06-23 04:30:16.465765
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Ignoring request, as unit crond.service was not loaded.")
    assert request_was_ignored("Ignoring request to reload crond.service, as it is not active.")
    assert not request_was_ignored("Loaded: loaded (/usr/lib/systemd/system/crond.service; enabled)")
    assert not request_was_ignored("Active: active (running) since 06:03:26;")



# Generated at 2022-06-23 04:30:30.442426
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {
        'ActiveState': 'active',
        'MainPID': '1234',
    }
    assert is_running_service(service_status)

    service_status = {
        'ActiveState': 'unknown',
        'MainPID': '1234',
    }
    assert not is_running_service(service_status)

    service_status = {
        'ActiveState': 'activating',
        'MainPID': '1234',
    }
    assert is_running_service(service_status)

    service_status = {
        'ActiveState': 'inactive',
        'MainPID': '0',
    }
    assert not is_running_service(service_status)


# Generated at 2022-06-23 04:30:41.353219
# Unit test for function request_was_ignored

# Generated at 2022-06-23 04:30:43.127989
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"}) is True


# Generated at 2022-06-23 04:30:44.944875
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'something'})



# Generated at 2022-06-23 04:30:48.300311
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert (request_was_ignored('ignoring request') is True)
    assert (request_was_ignored('ignoring command') is True)
    assert (request_was_ignored('foo=bar') is False)


# module specific function

# Generated at 2022-06-23 04:30:51.097336
# Unit test for function main
def test_main():

    # skipping test for now need to remove __builtin__ import first
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:30:57.023198
# Unit test for function main
def test_main():
    #this is the best test ever
    assert True==True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:05.521608
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:06.291772
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:08.822045
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})


# This is a base class that should not be used directly.

# Generated at 2022-06-23 04:31:20.129590
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active', 'SubState': 'running'}) is False
    assert is_deactivating_service({'ActiveState': 'active', 'SubState': 'post-stop'}) is False
    assert is_deactivating_service({'ActiveState': 'active', 'SubState': 'exited'}) is False
    assert is_deactivating_service({'ActiveState': 'active', 'SubState': 'dead'}) is False
    assert is_deactivating_service({'ActiveState': 'active', 'SubState': 'pending'}) is False
    assert is_deactivating_service({'ActiveState': 'active', 'SubState': 'exiting'}) is False

# Generated at 2022-06-23 04:31:24.191585
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:31:26.086334
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:40.243888
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([]) == {}
    assert parse_systemctl_show(['AssertPathExists=/proc/self/mountinfo']) == {'AssertPathExists': '/proc/self/mountinfo'}
    assert parse_systemctl_show(['Description=foo']) == {'Description': 'foo'}
    assert parse_systemctl_show([
        'ExecStart={',
        '  gdbus',
        '}']) == {'ExecStart': 'gdbus'}
    assert parse_systemctl_show([
        'ExecStart=',
        '{',
        '  gdbus',
        '}']) == {'ExecStart': 'gdbus'}

# Generated at 2022-06-23 04:31:50.203467
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test single line value
    lines = ['Id=foo']
    got = parse_systemctl_show(lines)
    want = {'Id': 'foo'}
    assert(got == want)

    # Test multi line value
    lines = ['ExecStart={', 'path=/bin/sleep 10', '}']
    got = parse_systemctl_show(lines)
    want = {'ExecStart': '\n'.join(lines)}
    assert(got == want)

    # Test single line value starting with { that doesn't end with }
    lines = ['Description={', 'foo', 'bar']
    got = parse_systemctl_show(lines)
    want = {'Description': '{'}
    assert(got == want)

    # Test multi line value followed by single line value

# Generated at 2022-06-23 04:32:01.074151
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:09.061294
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))

    assert not is_running_service(dict(ActiveState='failed'))
    assert not is_running_service(dict(ActiveState='inactive'))

    assert not is_running_service(dict(ActiveState=''))
    assert not is_running_service(dict(ActiveState=None))



# Generated at 2022-06-23 04:32:17.569726
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('nothing here')
    assert request_was_ignored('Unit nginx.service cannot be reloaded because it is inactive.')
    assert request_was_ignored('Unit nginx.service failed to reload: Job type reload is not applicable for unit nginx.service.')
    assert request_was_ignored('Invalid release setting, ignoring')
    assert request_was_ignored('invalid user argument, ignoring.')
    assert request_was_ignored('Failed to create directory /run/user/1000/jupyter/: Permission denied. Ignoring.')



# Generated at 2022-06-23 04:32:21.128103
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"})
    assert not is_deactivating_service({"ActiveState": "inactive"})



# Generated at 2022-06-23 04:32:22.614164
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:32:24.823123
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True
    assert is_deactivating_service({'ActiveState': 'active'}) == False


# Generated at 2022-06-23 04:32:39.036681
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:43.649667
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['ActiveEnterTimestamp=Wed 2016-05-18 14:05:08 EDT']) == {'ActiveEnterTimestamp': 'Wed 2016-05-18 14:05:08 EDT'}
    assert parse_systemctl_show(['Description=some single-line value']) == {'Description': 'some single-line value'}
    assert parse_systemctl_show(['ExecStart={ path=/usr/bin/thing ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) }']) == {'ExecStart': '{ path=/usr/bin/thing ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) }'}

# Generated at 2022-06-23 04:32:54.411228
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Warning: stopping unit currently NOT installed!\n")
    assert request_was_ignored("Warning: start request repeated too quickly for dnf-automatic.service\n")
    assert request_was_ignored("Warning: start request repeated too quickly for dnf-automatic.service\n")
    assert request_was_ignored("Warning: stop request repeated too quickly for dnf-automatic.service\n")
    assert request_was_ignored("Warning: stop request repeated too quickly for dnf-automatic.timer\n")
    assert request_was_ignored("Warning: start request repeated too quickly for dnf-automatic.timer\n")
    assert request_was_ignored("Warning: start request repeated too quickly for dnf-automatic.timer\n")

# Generated at 2022-06-23 04:33:02.403541
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to talk to bus: org.freedesktop.DBus.Error.UnknownMethod: Method "Subscribe" with signature "" on interface "org.freedesktop.systemd1.Manager" doesn\'t exist')
    assert request_was_ignored('Unit cowbell.service is masked, ignoring request.')
    assert request_was_ignored('Job for cowbell.service failed. See "systemctl status cowbell.service" and "journalctl -xe" for details.')
    assert request_was_ignored('The name org.freedesktop.systemd1 was not provided by any .service files')
    assert request_was_ignored('Ignoring command from PID 1 (systemd)')



# Generated at 2022-06-23 04:33:09.944209
# Unit test for function main
def test_main():
    testargs = [
        'name=faux.service',
        'state=started',
        'debug',
    ]

    with mock.patch.object(sys, 'argv', testargs):
        with mock.patch.object(sys, 'exit') as exit_mock:
            with mock.patch.object(sys, 'stdout') as stdout_mock:
                main()
                stdout_mock.assert_called_once()
                exit_mock.assert_called_once_with(0)

# Generated at 2022-06-23 04:33:15.662082
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:33:17.596859
# Unit test for function main
def test_main():
    with patch.object(module_args, 'run_command', return_value=(0, '', '')):
        main()

# Generated at 2022-06-23 04:33:21.450314
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'unknown'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True



# Generated at 2022-06-23 04:33:25.191009
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({})
    assert is_running_service({"ActiveState": "active"})
    assert is_running_service({"ActiveState": "activating"})



# Generated at 2022-06-23 04:33:32.495468
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'abandoned'}) is False
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'reloading'}) is False


# Generated at 2022-06-23 04:33:46.915784
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:49.263502
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:34:02.166500
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('=Ignoring request, unit is masked.')
    assert request_was_ignored('=Ignoring request, unit usr-local-bin.path is masked.')
    assert not request_was_ignored('= Unit proc-sys-fs-binfmt_misc.automount is masked.')
    assert not request_was_ignored('Job for proc-sys-fs-binfmt_misc.automount failed')
    assert request_was_ignored('=Ignoring request, unit is masked and in the process of shutting down.')
    assert request_was_ignored('=Ignoring request, unit is masked and in the process of starting.')
    assert request_was_ignored('=Ignoring request, unit is masked. Stopping, too.')

# Generated at 2022-06-23 04:34:06.295223
# Unit test for function request_was_ignored
def test_request_was_ignored():
    ignored_strings = [
        'ignoring request',
        'ignoring command',
        '='
    ]
    for string in ignored_strings:
        assert not request_was_ignored(string)



# Generated at 2022-06-23 04:34:10.673145
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert(is_deactivating_service(service_status) == True)
    service_status = {'ActiveState': 'inactive'}
    assert(is_deactivating_service(service_status) == False)



# Generated at 2022-06-23 04:34:15.868298
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)
    service_status = {'ActiveState': 'deactivated'}
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-23 04:34:21.604051
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request") == True
    assert request_was_ignored("ignoring command") == True
    assert request_was_ignored("= ignoring request") == False
    assert request_was_ignored("= ignoring command") == False
    assert request_was_ignored("ignoring request=") == False



# Generated at 2022-06-23 04:34:35.869873
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:52.491120
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    try:
        from ansible.module_utils.systemd import is_chroot
    except ImportError:
        pass


# Generated at 2022-06-23 04:35:00.045950
# Unit test for function is_running_service
def test_is_running_service():
    state = {'ActiveState' : 'active'}
    assert is_running_service(state)
    state['ActiveState'] = 'activating'
    assert is_running_service(state)
    state['ActiveState'] = 'inactive'
    assert not is_running_service(state)
    state['ActiveState'] = 'deactivating'
    assert not is_running_service(state)
    state['ActiveState'] = 'failed'
    assert not is_running_service(state)



# Generated at 2022-06-23 04:35:02.740487
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'unknown'}) == False


# Generated at 2022-06-23 04:35:07.719411
# Unit test for function is_running_service
def test_is_running_service():
    true_status = dict(
        ActiveState='active',
    )
    false_status = dict()
    assert is_running_service(true_status)
    assert not is_running_service(false_status)



# Generated at 2022-06-23 04:35:11.267245
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("""Job failed. See system logs and 'systemctl status' for details.""") == False
    assert request_was_ignored("""Failed to restart dnsmasq.service: Job type restart is not applicable for unit dnsmasq.service""") == False
    assert request_was_ignored("""Nothing to restart.""") == True



# Generated at 2022-06-23 04:35:18.424354
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    failure = None
    service_status = {'ActiveState': 'deactivating'}

    # status of service_status2 is not 'deactivating'
    service_status2 = {'ActiveState': 'inactive'}
    assert not failure, failure
    assert is_deactivating_service(service_status)
    assert not is_deactivating_service(service_status2)


# Generated at 2022-06-23 04:35:25.576409
# Unit test for function main
def test_main():
    result = main({"scope": "global", "enabled": "True", "name": "test", "masked": True, "state": "started", "force": True, "no_block": True}, None)
    if result['rc'] != 0:
        print("Result: %s" % result)
        sys.exit(1)
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:28.635606
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    from ansible.module_utils import basic
    test_status = dict(ActiveState='deactivating')
    assert is_deactivating_service(test_status)



# Generated at 2022-06-23 04:35:33.503069
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('=')
    assert not request_was_ignored('')



# Generated at 2022-06-23 04:35:42.642627
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Unit=foo.service',
        '',
        '[Service]',
        'ExecStart=',
        '{',
        'path=/usr/bin/mycmd',
        'argv[]=mycmd',
        '}',
    ]
    assert parse_systemctl_show(lines) == {
        'Unit': 'foo.service',
        'ExecStart': '\n'.join([
            '{',
            'path=/usr/bin/mycmd',
            'argv[]=mycmd',
            '}'
        ])
    }



# Generated at 2022-06-23 04:35:44.328700
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState':'active'})



# Generated at 2022-06-23 04:35:49.916397
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    assert is_deactivating_service({'ActiveState': 'activating'}) is False



# Generated at 2022-06-23 04:36:02.392331
# Unit test for function main

# Generated at 2022-06-23 04:36:13.528033
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for nginx.service failed because the control process exited with error code.\nSee "systemctl status nginx.service" and "journalctl -xe" for details.\n')
    assert not request_was_ignored('Job for nginx.service failed because a timeout was exceeded.\nSee "systemctl status nginx.service" and "journalctl -xe" for details.\n')
    assert request_was_ignored('Job for foo.service failed because a configured resource limit was exceeded. See "systemctl status foo.service" and "journalctl -xe" for details.\n')
    assert request_was_ignored('Job for bar.service failed due to a timeout. See "systemctl status bar.service" and "journalctl -xe" for details.\n')

# Generated at 2022-06-23 04:36:17.804363
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:22.636991
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})


# Generated at 2022-06-23 04:36:28.414109
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {}
    service_status['ActiveState'] = 'deactivating'
    assert is_deactivating_service(service_status) is True
    service_status['ActiveState'] = 'active'
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-23 04:36:31.528359
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    return is_deactivating_service(service_status)


# Generated at 2022-06-23 04:36:39.095024
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # single-line value
    lines = ['ActiveState=inactive']
    assert parse_systemctl_show(lines) == {'ActiveState': 'inactive'}
    # multi-line value that ends with }
    lines = ['ExecStart={', '  path=/bin/bar', '}']
    assert parse_systemctl_show(lines) == {'ExecStart': '{\n  path=/bin/bar\n}'}
    # multi-line value that does not end with }
    lines = ['ExecStart={', '  path=/bin/bar', '}\nExecStop={', '  path=/bin/baz', '}']

# Generated at 2022-06-23 04:36:49.471778
# Unit test for function main
def test_main():
    global module

# Generated at 2022-06-23 04:36:57.214944
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) == True
    service_status = {'ActiveState': 'none'}
    assert is_deactivating_service(service_status) == False
    service_status = {'ActiveState': 'active'}
    assert is_deactivating_service(service_status) == False



# Generated at 2022-06-23 04:37:03.866558
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'listening'}) is False
    assert is_deactivating_service({'ActiveState': 'activating'}) is False
    assert is_deactivating_service({'ActiveState': 'active'}) is False



# Generated at 2022-06-23 04:37:07.222208
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_service_status = dict()
    test_service_status['ActiveState'] = 'active'
    assert is_deactivating_service(test_service_status) == True



# Generated at 2022-06-23 04:37:11.838130
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:37:18.431011
# Unit test for function is_running_service
def test_is_running_service():
    '''Test function is_running_service'''
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-23 04:37:27.726044
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:37:32.647987
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({
        "ActiveState": "active",
        "SubState": "running",
        "After": "network.target",
        "Before": "nss-lookup.target",
        "Type": "simple",
        "UnitFileState": "enabled",
        "UnitFileStateResult": "success",
        "Id": "sshd.service",
    })
    assert is_running_service({
        "ActiveState": "activating",
        "SubState": "starting",
        "After": "network.target",
        "Before": "nss-lookup.target",
        "Type": "simple",
        "UnitFileState": "disabled",
        "UnitFileStateResult": "success",
        "Id": "sshd.service",
    })

# Generated at 2022-06-23 04:37:36.103580
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {
        'ActiveState': 'active',
        'SubState': 'running',
        'StatusErrno': '0',
        'Result': 'success',
    }
    assert is_running_service(service_status) is True



# Generated at 2022-06-23 04:37:46.914960
# Unit test for function is_deactivating_service
def test_is_deactivating_service():

    # Line 1
    thisModule = __import__("ansible.modules.system.systemd")
    thisModule.AnsibleModule = AnsibleModule
    thisModule.sysv_exists = sysv_exists
    thisModule.sysv_is_enabled = sysv_is_enabled
    thisModule.fail_if_missing = fail_if_missing
    thisModule.is_running_service = is_running_service
    thisModule.is_deactivating_service = is_deactivating_service
    thisModule.is_symlink = os.path.islink
    thisModule.run_command = lambda *args, **kwargs: {'rc': 0, 'stdout': '', 'stderr': '', 'stdin': ''}

# Generated at 2022-06-23 04:37:48.369880
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"}) is True



# Generated at 2022-06-23 04:37:51.676977
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:38:02.133738
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({
        'ActiveState': 'deactivating',
    })
    assert not is_deactivating_service({
    })
    assert not is_deactivating_service({
        'ActiveState': 'activating',
    })
    assert not is_deactivating_service({
        'ActiveState': 'active',
    })
    assert not is_deactivating_service({
        'ActiveState': 'inactive',
    })
    assert not is_deactivating_service({
        'ActiveState': 'failed',
    })



# Generated at 2022-06-23 04:38:10.080990
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_multi_line_1 = '''ExecStart=
  { path=/usr/bin/foo ; argv[]=/usr/bin/foo ; ignore_errors=no ; start_time=null ; stop_time=null ; pid=0 ; code=(null) ; status=0/0 }'''
    test_multi_line_2 = '''ExecStart=
  { path=/usr/bin/foo ; argv[]=/usr/bin/foo ; ignore_errors=no ; start_time=null ; stop_time=null ; pid=0 ; code=(null) ; status=0/0 }
'''

# Generated at 2022-06-23 04:38:12.591026
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {"ActiveState": "deactivating"}
    is_deactivating_service(service_status)



# Generated at 2022-06-23 04:38:17.510208
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to show property Failed to start abc.service: Connection timed out')
    assert not request_was_ignored('ActiveState=active')
    assert not request_was_ignored('ActiveState=inactive')
    assert request_was_ignored('Failed to start abc.service: Connection timed out')



# Generated at 2022-06-23 04:38:20.549886
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo = bar')



# Generated at 2022-06-23 04:38:34.563554
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # No "=" exists
    assert request_was_ignored('''
Job for chef-client.service failed because the control process exited with error code. See "systemctl status chef-client.service" and "journalctl -xe" for details.
''')
    # Contains "ignoring request"
    assert request_was_ignored('''
Job for crond.service failed because a daemon is already running in the system service manager. See "systemctl status crond.service" and "journalctl -xe" for details.
''')
    # Contains "ignoring command"
    assert request_was_ignored('''
Job for chef-client.service failed because the control process exited with error code. See "systemctl status chef-client.service" and "journalctl -xe" for details.
''')

    # Does not contain "="

# Generated at 2022-06-23 04:38:41.694507
# Unit test for function main
def test_main():
    # FIXME: ansible-test needs a better way to generate non-dictionary results
    if False:
        result = main()
        assert result is not None, result


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:44.898461
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    result = is_deactivating_service({'ActiveState': 'deactivating'})
    assert result == True



# Generated at 2022-06-23 04:38:52.650845
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:39:00.174951
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'active_state': 'deactivating'}) is True
    assert is_deactivating_service({'active_state': 'active'}) is False



# Generated at 2022-06-23 04:39:04.946968
# Unit test for function main
def test_main():
    import sys
    import pytest
    from unittest.mock import patch
    from io import StringIO
    sys.argv = [
        'ansible-test',
        '--color',
        '-v',
        'units/systemd_unit.py',
    ]
    stdout = StringIO()
    with patch('sys.stdout', stdout), \
         pytest.raises(SystemExit), \
         patch('ansible.module_utils.systemd.module_platform.module_platform', lambda: (distro, platform)):
        with pytest.raises(SystemExit) as pytest_wrapped_e:
            main()
        assert pytest_wrapped_e.type == SystemExit
        assert pytest_wrapped_e.value.code == 0
        stdout.seek(0)

# Generated at 2022-06-23 04:39:10.614249
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('Nothing to do.')
    assert not request_was_ignored('Ignored.')
    assert not request_was_ignored('Ignoring request.')
    assert not request_was_ignored('')
    assert not request_was_ignored(None)
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')



# Generated at 2022-06-23 04:39:18.193205
# Unit test for function request_was_ignored
def test_request_was_ignored():
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-23 04:39:20.620667
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    '''
    is_deactivating_service should return True if the service is in an
    active state.
    '''
    svc_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(svc_status) is True



# Generated at 2022-06-23 04:39:26.571979
# Unit test for function main

# Generated at 2022-06-23 04:39:34.734407
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # check for "ignoring request"
    assert request_was_ignored("Failed to issue method call: Unit crond.service not loaded.\n")
    # check for "ignoring command"
    assert request_was_ignored("Failed to issue method call: Unit crond.service failed to load: No such file or directory. See system logs and 'systemctl status crond.service' for details.\n")
    # should not match this
    assert not request_was_ignored("Status of crond.service is SUCCESS=daemon-reload\n")
    assert not request_was_ignored("Status of dnf-automatic.timer is SUCCESS=stop\n")



# Generated at 2022-06-23 04:39:39.529121
# Unit test for function is_running_service
def test_is_running_service():
    ''' Verify the function returns True if ActiveState is activating or active
    '''
    data = dict(ActiveState='active')
    assert is_running_service(data)
    data = dict(ActiveState='activating')
    assert is_running_service(data)

