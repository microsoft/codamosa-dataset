

# Generated at 2022-06-23 04:29:37.056617
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert set(['deactivating']) == set(['deactivating'])



# Generated at 2022-06-23 04:29:40.148974
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'not a real state'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:29:51.246686
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    '''
    Unit test for parse_systemctl_show function
    '''

    # Should return an empty dict if given an empty list of lines
    assert parse_systemctl_show([]) == {}

    # Should handle a single line
    assert parse_systemctl_show(['foo=bar']) == {'foo': 'bar'}

    # Should handle a multi-line simple values
    assert parse_systemctl_show(['foo=bar', 'baz']) == {'foo': 'bar\nbaz'}

    # Should handle a multi-line value with a brace in the first line
    assert parse_systemctl_show(['foo={', 'baz']) == {'foo': '{\nbaz'}

    # Should handle a multi-line value with a brace in the first line but not the last
    assert parse_systemctl_

# Generated at 2022-06-23 04:29:58.474631
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({})



# Generated at 2022-06-23 04:30:04.893165
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='inactive'))
    assert not is_running_service(dict(ActiveState='deactivating'))
    assert not is_running_service(dict(ActiveState='failed'))
    assert not is_running_service(dict(ActiveState='not-found'))



# Generated at 2022-06-23 04:30:07.542766
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:30:12.344544
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring request and command')
    assert request_was_ignored('Something ignoring request and command')
    assert not request_was_ignored('Failed to get D-Bus connection')



# Generated at 2022-06-23 04:30:14.689902
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:30:28.284123
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:38.028786
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:41.942283
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    ansible_service_status = dict(ActiveState="deactivating")
    assert(is_deactivating_service(ansible_service_status))



# Generated at 2022-06-23 04:30:43.310751
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 04:30:46.422908
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignore command')
    assert request_was_ignored('main = ignore') is False
    assert request_was_ignored('main = active') is False



# Generated at 2022-06-23 04:30:50.877495
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('ignoring command and args') is True
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring request and args') is True
    assert request_was_ignored('=' * 50) is False  # For a successful action
    assert request_was_ignored('foo') is False



# Generated at 2022-06-23 04:31:05.817618
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='inactive'))  # NOQA: E712
    assert not is_running_service(dict(ActiveState='exited'))
    assert not is_running_service(dict(ActiveState='failed'))
    assert not is_running_service(dict(ActiveState='dead'))
    assert not is_running_service(dict(ActiveState='reloading'))
    assert not is_running_service(dict(ActiveState=None))
    assert not is_running_service(dict())



# Generated at 2022-06-23 04:31:08.673649
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-23 04:31:14.065597
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test with a single-line value.
    lines = ["ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT", "ActiveEnterTimestampMonotonic=8135942"]
    parsed = parse_systemctl_show(lines)
    assert parsed == {'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT',
                      'ActiveEnterTimestampMonotonic': '8135942'}
    # Test with a multi-line value and a single-line value.

# Generated at 2022-06-23 04:31:17.779622
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False
    assert is_deactivating_service({'ActiveState': 'failed'}) is False

# Generated at 2022-06-23 04:31:19.856254
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') == True
    assert request_was_ignored('X equals Y') == False



# Generated at 2022-06-23 04:31:27.660381
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    key1, value1 = 'key1', 'value1'
    key2, value2 = 'key2', '{ value2'
    key3, value3 = 'key3', '{ value3'
    key4, value4 = 'key4', '{ value4'
    key5, value5 = 'key5', 'value5'
    key6, value6 = 'key6', 'value6'
    key7, value7 = 'key7', 'this is a value of arbitrary length'
    key8, value8 = 'ExecStart', '{do something -with-an-arg}'
    key9, value9 = 'ExecReload', '{do something -with-an-arg}'

    # Test 1: no multi-line values

# Generated at 2022-06-23 04:31:29.504389
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = """
    Unit myservice.service could not be found.
    """
    assert request_was_ignored(out)



# Generated at 2022-06-23 04:31:41.406815
# Unit test for function main
def test_main():
    current_dir = os.path.dirname(__file__)
    test_data_dir = os.path.join(current_dir, 'test_data')
    results = {
        'name': 'sshd',
        'changed': False,
        'status': {
            'LoadState': 'loaded',
            'ActiveState': 'active',
            'SubState': 'running',
            'UnitFileState': 'enabled',
        }
    }
    mock_module = Mock(exit_json=Mock())
    mock_module.get_bin_path.return_value = '/bin/systemctl'

# Generated at 2022-06-23 04:31:45.895190
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState":"deactivating"}) is True
    assert is_deactivating_service({"ActiveState":"active"}) is False
    assert is_deactivating_service({"ActiveState":"inactive"}) is False



# Generated at 2022-06-23 04:31:49.897155
# Unit test for function main
def test_main():
    with mock.patch.object(sys, 'argv', ['systemd']):
        with pytest.raises(SystemExit):
            main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:00.838304
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test with a single line value
    lines = [
        "Description=foo",
        "After=syslog.target",
    ]
    expected = {
        'Description': 'foo',
        'After': 'syslog.target',
    }
    rval = parse_systemctl_show(lines)
    assert rval == expected

    # Test with a value that spans multiple lines

# Generated at 2022-06-23 04:32:06.765518
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('= ignoring request') is False
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('= ignoring command') is False



# Generated at 2022-06-23 04:32:12.282370
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('Ignoring command')
    assert request_was_ignored('ignoring request or command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('ignore')
    assert not request_was_ignored('Ignoring command and request')



# Generated at 2022-06-23 04:32:23.780803
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:38.084661
# Unit test for function main

# Generated at 2022-06-23 04:32:48.851307
# Unit test for function main

# Generated at 2022-06-23 04:32:59.646798
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # test 1
    lines = [
        'Id=cups.service',
        'Names=cups.service',
        'Description=CUPS Printing Service',
        'LoadState=loaded',
        'ActiveState=active',
        'SubState=running',
        'FragmentPath=/usr/lib/systemd/system/cups.service',
        'UnitFileState=enabled',
        'UnitFilePreset=disabled',
        'Result=success'
    ]

# Generated at 2022-06-23 04:33:09.357265
# Unit test for function main
def test_main():
    ''' main '''
    # Patching exit_json and fail_json to be able to test
    old_exit_json = ansible_module.exit_json
    old_fail_json = ansible_module.fail_json

    def exit_json(*args, **kwargs):
        ''' exit_json '''
        return

    def fail_json(*args, **kwargs):
        ''' fail_json '''
        return

    ansible_module.exit_json = exit_json
    ansible_module.fail_json = fail_json

    main()

    ansible_module.exit_json = old_exit_json
    ansible_module.fail_json = old_fail_json


# Generated at 2022-06-23 04:33:15.793540
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:33:19.805550
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status = {
        'ActiveState': 'deactivating',
        'StatusResult': 'success'
    }
    assert is_deactivating_service(status) is True
    status['ActiveState'] = 'inactive'
    assert is_deactivating_service(status) is False



# Generated at 2022-06-23 04:33:24.501590
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'failed'}) == False



# Generated at 2022-06-23 04:33:27.661337
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating'))
    assert not is_deactivating_service(dict(ActiveState='active'))



# Generated at 2022-06-23 04:33:36.174492
# Unit test for function main
def test_main():
    import sys

    module = sys.modules['ansible.modules.system.systemd_unit']

    #Tested with ansible 2.4.0
    module.AnsibleModule = MagicMock(return_value='')
    module.AnsibleModule.params = {}
    module.AnsibleModule.run_command = MagicMock(return_value='Failed to connect to bus: No such file or directory')
    module.AnsibleModule.fail_json = MagicMock()

    module.main()
    assert module.AnsibleModule().run_command.called == 1


# Generated at 2022-06-23 04:33:49.401652
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:55.761794
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([
        'Description=Foo',
        'ExecReload=/bin/kill -HUP $MAINPID',
        'ExecStart={ path=/bin/foo arg1 arg2 arg3 }']) == {
            'Description': 'Foo',
            'ExecReload': '/bin/kill -HUP $MAINPID',
            'ExecStart': '{ path=/bin/foo arg1 arg2 arg3 }'}

# Generated at 2022-06-23 04:34:08.713445
# Unit test for function is_running_service
def test_is_running_service():
    # Generic status for testing
    service_status = {
        'ActiveState': 'loaded',
    }
    assert is_running_service(service_status) is False
    # Unit loaded but not active
    service_status = {
        'ActiveState': 'loaded',
    }
    assert is_running_service(service_status) is False
    # Unit inactive but not loaded
    service_status = {
        'ActiveState': 'inactive',
    }
    assert is_running_service(service_status) is False
    # Unit active, running
    service_status = {
        'ActiveState': 'active',
    }
    assert is_running_service(service_status) is True
    # Unit activating, running
    service_status = {
        'ActiveState': 'activating',
    }
    assert is_running

# Generated at 2022-06-23 04:34:11.067886
# Unit test for function is_running_service
def test_is_running_service():
    running_service = {
        'ActiveState': 'active'
    }
    assert is_running_service(running_service)



# Generated at 2022-06-23 04:34:23.554129
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('''
Ignoring SIGHUP: unit is not active
Job for getty@tty1.service failed because the control process exited with error code.
See "systemctl status getty@tty1.service" and "journalctl -xe" for details.''')
    assert not request_was_ignored('Job for getty@tty1.service failed because the control process exited with error code.\nSee "systemctl status getty@tty1.service" and "journalctl -xe" for details.')
    assert not request_was_ignored('Job for getty@tty1.service failed because the control process exited with error code. See "systemctl status getty@tty1.service" and "journalctl -xe" for details.')



# Generated at 2022-06-23 04:34:25.245822
# Unit test for function main
def test_main():
    check_module(ANSIBLE_MODULE_ARGS, ANSIBLE_MODULE_RETVALUES).run()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:31.652634
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'deactivating'}) == False
    assert is_running_service({}) == False



# Generated at 2022-06-23 04:34:33.453280
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-23 04:34:42.372297
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Id=cron.service',
        'Names=cron.service',
        'Description=Regular background program processing daemon',
        'Documentation=man:cron(8)',
        'BindsTo=sysinit.target',
        'After=sysinit.target',
        'RequiresMountsFor=/etc/crontab /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly /etc/cron.d /var/spool/cron',
        'RefuseManualStart=yes',
        'RefuseManualStop=yes',
    ]

# Generated at 2022-06-23 04:34:45.077233
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:34:49.434038
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('something else')
    assert not request_was_ignored('= something else')



# Generated at 2022-06-23 04:35:01.951460
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Failed to start unit: Unit foobar.service is masked")
    assert request_was_ignored("Failed to reload service unit: Unit foobar.service is masked.")
    assert request_was_ignored("Failed with result 'masked'.")
    assert request_was_ignored("Failed to set property QoSReservedSpace: Invalid argument")
    assert request_was_ignored("Failed with result 'not-supported'.")
    assert request_was_ignored("Failed to set property CPUShares: Invalid argument")
    assert request_was_ignored("Failed with result 'not-supported'.")
    assert request_was_ignored("Failed to reload service unit: Unit foobar.service is masked.")
    assert request_was_ignored("Failed with result 'masked'.")

# Generated at 2022-06-23 04:35:06.867596
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Description=Foo={', '  Bar=Baz', '  }', 'X=Y']) == {'Description': 'Foo={', 'X': 'Y'}


# Generated at 2022-06-23 04:35:20.167444
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('')
    assert request_was_ignored('''
Job for systemd-sysctl.service failed. See 'systemctl status systemd-sysctl.service' and 'journalctl -xn' for details.
Ignoring request to stop systemd-sysctl.service.
''')
    assert request_was_ignored('''
Unit polkitd.service is masked
Ignoring command stop request.
''')
    assert not request_was_ignored('''
masked by: /etc/systemd/system/getty.target.wants/getty@tty1.service
''')
    assert request_was_ignored('''
Running in chroot, ignoring request.
''')
    assert not request_was_ignored('foo bar')

# Generated at 2022-06-23 04:35:26.347451
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': "active"})
    assert is_running_service({'ActiveState': "activating"})
    assert not is_running_service({'ActiveState': "inactive"})
    assert not is_running_service({'ActiveState': "deactivating"})



# Generated at 2022-06-23 04:35:28.818123
# Unit test for function is_running_service
def test_is_running_service():
    running_result = {'ActiveState': 'active'}
    assert is_running_service(running_result) == True

    non_running_result = {'ActiveState': 'inactive'}
    assert is_running_service(non_running_result) == False

    assert is_running_service({}) == False


# Generated at 2022-06-23 04:35:42.139554
# Unit test for function main
def test_main():
    # this test only works with systemd
    if not is_systemd():
        return

    test_unit = 'test-unit'
    test_service = 'test-service'
    test_timer = 'test-timer'
    test_masked = 'test-masked'
    test_systemctl = 'systemctl'

    syslinux_init = SystemLinuxInit(test_systemctl)
    test_systemd = SystemD(test_systemctl)
    test_systemd.add_unit(test_unit)
    test_systemd.add_service(test_service)
    test_systemd.add_masked_service(test_masked)

    # Test state of unit
    # Disabled
    test_systemd.set_unit_state(test_unit, 'disabled')
    ret = main()

# Generated at 2022-06-23 04:35:44.551224
# Unit test for function main
def test_main():
    '''
    Test the main function by check the output of the function.
    '''
    test_main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:58.470091
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request to start unit')
    assert request_was_ignored('ignoring request to stop unit')
    assert request_was_ignored('ignoring request to reload unit')
    assert request_was_ignored('ignoring request to restart unit')
    assert request_was_ignored('ignoring request to enable unit')
    assert request_was_ignored('ignoring request to disable unit')
    assert request_was_ignored('ignoring request to mask unit')
    assert request_was_ignored('ignoring request to unmask unit')
    assert not request_was_ignored('Ignoring command start')
    assert not request_was_ignored('Ignoring command stop')
    assert not request_was_ignored('Ignoring command reload')

# Generated at 2022-06-23 04:36:06.394039
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'unknown'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})


# Generated at 2022-06-23 04:36:13.703209
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored("'some unit' loaded active running") is False
    assert request_was_ignored("Failed to start unit, message: Invalid argument") is False
    assert request_was_ignored("Failed to issue method call: No such file or directory") is False



# Generated at 2022-06-23 04:36:18.861002
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('ignore')
    assert not request_was_ignored('request')
    assert not request_was_ignored('ignoring')
    assert not request_was_ignored('')



# Generated at 2022-06-23 04:36:26.788124
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_lines = [
        'Description=LXD - container management daemon',
        'Documentation=man:lxd(1)',
        'ExecStart=/usr/bin/lxd --group lxd --logfile=/var/log/lxd/lxd.log',
        'ExecReload=/bin/kill -s HUP $MAINPID',
        'Nice=19',
        'OOMScoreAdjust=-999',
        'Restart=on-failure',
        'RestartSec=1s',
        'StartLimitInterval=0',
    ]
    res = parse_systemctl_show(test_lines)

# Generated at 2022-06-23 04:36:36.928063
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    output = """ActiveState=active
After=network.target time-sync.target
Before=shutdown.target
ConditionIsNotTrue=!failed
ConditionPathExists=/tmp/test.lock
Description=Start nginx
ExecStart=/bin/nginx
ExecReload=/bin/nginx reload
ExecStop=/bin/nginx stop
GuessMainPID=no
IGNORE_env=false
OnFailureIsolate=no"""
    result = parse_systemctl_show(output.splitlines())

# Generated at 2022-06-23 04:36:48.460736
# Unit test for function main

# Generated at 2022-06-23 04:36:54.967160
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'unknown'})



# Generated at 2022-06-23 04:36:59.460963
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})


# Generated at 2022-06-23 04:37:01.495486
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(
        {"ActiveState": "deactivating"}
    )



# Generated at 2022-06-23 04:37:10.617868
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_show_output = '''
    Unit=test.service
    Description=Ansible test unit
    After=network.target
    ConditionPathExists=!/etc/ansible/test_unit_removed
    '''

    test_show_output = test_show_output.split('\n')

    parsed = parse_systemctl_show(test_show_output)
    assert len(parsed) == len(test_show_output)
    assert parsed['Unit'] == 'test.service'
    assert parsed['Description'] == 'Ansible test unit'
    assert parsed['After'] == 'network.target'
    assert parsed['ConditionPathExists'] == '!/etc/ansible/test_unit_removed'

module = None
module_params = None
service_status = None
module_return = {}


# Generated at 2022-06-23 04:37:20.067030
# Unit test for function is_running_service
def test_is_running_service():
    running_state = {'ActiveState': 'active'}
    result = is_running_service(running_state)
    assert result is True
    activating_state = {'ActiveState': 'activating'}
    result = is_running_service(activating_state)
    assert result is True
    other_state = {'ActiveState': 'other'}
    result = is_running_service(other_state)
    assert result is False
    not_present_state = {}
    result = is_running_service(not_present_state)
    assert result is False



# Generated at 2022-06-23 04:37:28.035330
# Unit test for function main
def test_main():
    """Unit tests for function main"""
    import pytest
    from ansible_collections.ansible.community.plugins.modules.system.systemd import main
    # Get a list of default arguments
    default_args = main.__defaults__
    default_args.update(dict(
        daemon_reload=False,
        daemon_reexec=False,
        force=False,
        mask=False,
        name='',
        no_block=False,
        scope=False,
        state=False,
    ))
    # create a function with default arguments
    func = lambda *args, **kwargs: main(*args, **kwargs)
    assert func() == default_args


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:40.623342
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    expected = {
        'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT',
        'Description': 'Command Scheduler',
        'ExecStart': '{ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
        'FragmentPath': '/usr/lib/systemd/system/crond.service',
        'Id': 'crond.service',
        'Names': 'crond.service',
        'Type': 'simple',
    }

# Generated at 2022-06-23 04:37:48.832759
# Unit test for function main

# Generated at 2022-06-23 04:38:00.255788
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("""
Job for dnf-makecache.timer canceled.
    """) is True
    assert request_was_ignored("""
Failed to get properties: Unit dnf-makecache.timer not loaded.
    """) is False
    assert request_was_ignored("""
Failed to get properties: No such interface ''
    """) is False
    assert request_was_ignored("""
Failed to get properties: Unit dnf-makecache.timer not loaded.
    """) is False
    assert request_was_ignored("""
    """) is False



# Generated at 2022-06-23 04:38:08.977519
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Name=test\n', 'Description=This is a test']) == {'Name': 'test', 'Description': 'This is a test'}
    assert parse_systemctl_show(['Name=test\n', 'Description={', 'This is a test', '}']) == {'Name': 'test', 'Description': 'This is a test'}
    assert parse_systemctl_show(['Name=test\n', 'Description={', 'This is a test', '}\n', 'X=Y\n', 'Z={', 'This is another test', '}']) == {'Name': 'test', 'Description': 'This is a test', 'X': 'Y', 'Z': 'This is another test'}

# Generated at 2022-06-23 04:38:19.534027
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:25.300704
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:38:36.869889
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:55.440391
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'unknown'})
    assert is_running_service({'ActiveState': 'active', 'SubState': 'running'})
    assert is_running_service({'ActiveState': 'active', 'SubState': 'reloading'})
    assert is_running_service({'ActiveState': 'active', 'SubState': 'exited'})

# Generated at 2022-06-23 04:39:05.546469
# Unit test for function main
def test_main():
    test_dict = dict(
        name=None,
        state=None,
        enabled=None,
        daemon_reload=None,
        daemon_reexec=None,
        masked=None,
        force=False,
        no_block=False,
    )

    test_obj = AnsibleModule(argument_spec=test_dict)
    test_obj.main()


if __name__ == '__main__':
    if os.getenv('ANSIBLE_TEST'):
        test_main()
    else:
        main()

# Generated at 2022-06-23 04:39:08.882738
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:39:17.932937
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that it correctly handles values spanning multiple lines
    input_lines = [
        'MultiLine=',
        '{',
        '  multi line value',
        '}',
    ]
    expected_output = {
        'MultiLine': 'multi line value',
    }
    output = parse_systemctl_show(input_lines)
    assert output == expected_output

    # Test that it correctly handles values spanning multiple lines, with an empty value at the start
    input_lines = [
        'MultiLine=',
        '{',
        '  multi line value',
        '}',
        'EmptyLine=',
    ]
    expected_output = {
        'MultiLine': 'multi line value',
        'EmptyLine': '',
    }
    output = parse_systemctl_show(input_lines)

# Generated at 2022-06-23 04:39:30.407205
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Check that a single-line value is handled correctly
    lines = [u'Id=crond.service\n']
    parsed = parse_systemctl_show(lines)
    assert len(parsed) == 1
    assert parsed[u'Id'] == u'crond.service'

    # Check that a multi-line value is handled correctly
    lines = [u'ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }\n']
    parsed = parse_systemctl_show(lines)
    assert len(parsed) == 1
    assert parsed[u'ExecStart'] == u

# Generated at 2022-06-23 04:39:34.390620
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored(' Unit not loaded.')
    assert not request_was_ignored('Unit not loaded.')

