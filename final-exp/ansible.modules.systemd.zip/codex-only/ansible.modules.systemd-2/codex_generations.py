

# Generated at 2022-06-23 04:29:42.411344
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('some_thing_ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('some_thing_ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('some_thing_ignoring command with other things')
    assert not request_was_ignored('')



# Generated at 2022-06-23 04:29:54.945917
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:06.020849
# Unit test for function main

# Generated at 2022-06-23 04:30:08.317234
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:30:18.370461
# Unit test for function is_deactivating_service

# Generated at 2022-06-23 04:30:31.819975
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:42.716069
# Unit test for function main
def test_main():
    class AnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, **kwargs):
            self.kwargs = kwargs
            raise Exception(kwargs)
        def warn(self, msg):
            self.msg = msg
            print(msg)
        def get_bin_path(self, name, required):
            return '/usr/bin/' + name
        def run_command(self, cmd, check_rc=True):
            print(cmd)
            return (0, '', '')

# Generated at 2022-06-23 04:30:45.813721
# Unit test for function is_running_service
def test_is_running_service():
    with open('unit/ansible_module_systemd/service_running.txt') as f:
        service_status = dict(line.strip().split('=', 1) for line in f)

    assert is_running_service(service_status)



# Generated at 2022-06-23 04:30:59.510015
# Unit test for function request_was_ignored
def test_request_was_ignored():
    tests = (
        ('=', False),
        ('A=', False),
        ('ignoring request', True),
        ('ignoring command', True),
        ('ignoring request foo', True),
        ('foo ignoring request', True),
        ('ignoring\nrequest', True),
        ('ignoring\ncommand', True),
        ('foo ignoring\nrequest', True),
    )
    for text, expected in tests:
        result = request_was_ignored(text)
        assert result == expected, 'test_request_was_ignored: "{}" resulted in {} instead of {}'.format(text, result, expected)



# Generated at 2022-06-23 04:31:07.914073
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:16.190963
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    bad_status = dict(
        ActiveEnterTimestamp='Sun 2016-05-15 18:28:49 EDT',
        ActiveEnterTimestampMonotonic='8135942',
        ActiveExitTimestampMonotonic='0',
        ActiveState='deactivating',
        After='auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice',
        AllowIsolate='no',
    )
    assert is_deactivating_service(bad_status)

# Generated at 2022-06-23 04:31:28.471691
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = "Job for puppet.service failed because the control process exited with error code. See \"systemctl status puppet.service\" and \"journalctl -xe\" for details."  # NOQA
    assert not request_was_ignored(out)

# Generated at 2022-06-23 04:31:35.659236
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('To try running the unit as user instance, run the container with')
    assert not request_was_ignored('To try running the unit as user instance, run the container \
                                                    with --user option or make it setuid root')



# Generated at 2022-06-23 04:31:43.446801
# Unit test for function main
def test_main():
    '''
        Unit test of function main
    '''
    systemctl = "test"
    initd = "test"
    system = 'system'
    name = 'test'
    state = 'test'
    enabled = True
    force = True
    masked = True
    daemon_reload = True
    daemon_reexec = True
    scope = 'test'
    no_block = True


# Generated at 2022-06-23 04:31:51.952616
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:53.237792
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:32:02.727270
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    from ansible.module_utils.facts.system.systemd import parse_systemctl_show

    assert parse_systemctl_show([]) == {}
    assert parse_systemctl_show(['key=value']) == {'key': 'value'}
    assert parse_systemctl_show(['key=']) == {'key': ''}
    assert parse_systemctl_show(['key=value1', 'key=value2']) == {'key': 'value2'}
    assert parse_systemctl_show(['key=value1', 'other=value2', 'key=value3']) == {'key': 'value3', 'other': 'value2'}

# Generated at 2022-06-23 04:32:15.310958
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Job for haproxy.service failed because a configured resource limit was exceeded. See \"systemctl status haproxy.service\" and \"journalctl -xe\" for details.")

# Generated at 2022-06-23 04:32:23.551532
# Unit test for function is_running_service
def test_is_running_service():
    test_case1 = {'ActiveState': 'active', 'SubState': 'dead'}
    test_case2 = {'ActiveState': 'activating', 'SubState': 'starting'}
    test_case3 = {'ActiveState': 'unknown', 'SubState': 'foo'}
    assert is_running_service(test_case1)
    assert is_running_service(test_case2)
    assert not is_running_service(test_case3)



# Generated at 2022-06-23 04:32:25.104275
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': "deactivating"})

# Generated at 2022-06-23 04:32:39.036118
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:41.850110
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_input = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(test_input) is True



# Generated at 2022-06-23 04:32:45.877501
# Unit test for function main
def test_main():
    '''
    unit test for main function
    '''
    mod = AnsibleModule({
        'name': 'devops',
       'enabled': 'True',
       'systemd': 'True'
    })
    if mod:
        assert main() == True

# Generated at 2022-06-23 04:32:54.058769
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request to do something')
    assert request_was_ignored('ignoring command to do something')
    assert request_was_ignored('ignoring request to do something (already something)')
    assert request_was_ignored('ignoring command to do something (already something)')
    assert not request_was_ignored('=')
    assert not request_was_ignored('some random text')


supports_daemon_reload = True



# Generated at 2022-06-23 04:33:07.438015
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:16.335521
# Unit test for function main
def test_main():
    test1 = dict(
        name='foobar',
        state='started'
    )


# Generated at 2022-06-23 04:33:21.528689
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {
        'ActiveState': 'inactive',
    }
    assert is_running_service(service_status) == False
    service_status = {
        'ActiveState': 'activating',
    }
    assert is_running_service(service_status) == True
    service_status = {
        'ActiveState': 'active',
    }
    assert is_running_service(service_status) == True



# Generated at 2022-06-23 04:33:25.642457
# Unit test for function is_running_service
def test_is_running_service():
    test1 = {'ActiveState': 'active'}
    assert is_running_service(test1) is True
    test2 = {'ActiveState': 'inactive'}
    assert is_running_service(test2) is False



# Generated at 2022-06-23 04:33:30.453369
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status_active = {'ActiveState': 'active'}
    service_status_deactivating = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status_active) == False
    assert is_deactivating_service(service_status_deactivating) == True


# Generated at 2022-06-23 04:33:34.162069
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='inactive'))
    assert not is_running_service(dict(ActiveState='reloading'))
    assert not is_running_service(dict(ActiveState='invalid'))


# Generated at 2022-06-23 04:33:48.802441
# Unit test for function main
def test_main():
    test_arguments = dict()
    test_arguments['enabled'] = False
    test_arguments['masked'] = None
    test_arguments['force'] = False
    test_arguments['name'] = "test_name"
    test_arguments['no_block'] = False
    test_arguments['scope'] = "system"
    test_arguments['state'] = "reloaded"
    test_arguments['daemon_reload'] = False
    test_arguments['daemon_reexec'] = False
    from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params = test_arguments
    main()


# Generated at 2022-06-23 04:33:50.552383
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:33:54.306535
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    mock_service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(mock_service_status) is True

# unit test for function is_running_service

# Generated at 2022-06-23 04:33:59.142026
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('test=test')
    assert not request_was_ignored('test test')
    assert request_was_ignored('test test ignoring request')
    assert request_was_ignored('test test ignoring command')



# Generated at 2022-06-23 04:34:04.432984
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring this')
    assert request_was_ignored('nope, ignoring that')
    assert not request_was_ignored('= not in out')
    assert not request_was_ignored('= not in out either')



# Generated at 2022-06-23 04:34:12.271800
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'unknown'})
    assert not is_running_service({'ActiveState': 'reloading'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:34:16.423116
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring request'))
    assert(request_was_ignored('  ignoring command'))
    assert(not request_was_ignored('OpResult=done'))



# Generated at 2022-06-23 04:34:30.163138
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:34.736065
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import *
    from ansible.module_utils import basic
    import os
    import sys


# Generated at 2022-06-23 04:34:42.926228
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.community.general.tests.unit.compat.mock import MagicMock
    from ansible_collections.community.general.tests.unit.compat.mock import patch

# Generated at 2022-06-23 04:34:53.158722
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'somethingelse'}) is False
    assert is_running_service({}) is False
    assert is_running_service(None) is False
    assert is_running_service(42) is False



# Generated at 2022-06-23 04:34:59.710762
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    if '-test-unit' in sys.argv:
        if 'main' in sys.argv[sys.argv.index('-test-unit') + 1:]:
            sys.exit(0)
        else:
            sys.exit(1)
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:02.547179
# Unit test for function main
def test_main():
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:07.443390
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState':'active'})
    assert is_running_service({'ActiveState':'activating'})
    assert not is_running_service({'ActiveState':'inactive'})



# Generated at 2022-06-23 04:35:20.739515
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_output = '''Description=Awesome service
                        A service
                    ExecMainStatus=0
                    ExecMainExitTimestampMonotonic=0
                    ExecStart={ path=/bin/sh ; argv[]=/bin/sh -c echo "Hello, world!"; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
                    ExecStart={ path=/bin/sh ; argv[]=/bin/sh -c echo "Hello, world!"; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
                    '''
    result = parse_systemctl_show(test_output.split('\n'))

# Generated at 2022-06-23 04:35:28.689880
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Warning: Stopping dbus.service, but it can still be activated by:\n  dbus.socket\n")
    assert request_was_ignored("Failed to stop dbus.service: Unit dbus.service not loaded.\n")
    assert request_was_ignored("Warning: Stopping dbus.service, but it can still be activated by: dbus.socket\n")



# Generated at 2022-06-23 04:35:42.036881
# Unit test for function main

# Generated at 2022-06-23 04:35:45.569927
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('=')
    assert not request_was_ignored('list-unit-files')
    assert not request_was_ignored('\n')



# Generated at 2022-06-23 04:35:49.176701
# Unit test for function main
def test_main():
    pass  # TODO: add unit test

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:01.974545
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import shutil

    os.environ['XDG_RUNTIME_DIR'] = '/run/user/%s' % os.geteuid()

    testdir = tempfile.mkdtemp()


# Generated at 2022-06-23 04:36:05.765295
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {
        'ActiveState': 'deactivating',
    }
    assert(is_deactivating_service(service_status))



# Generated at 2022-06-23 04:36:08.544927
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status1 = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status1)



# Generated at 2022-06-23 04:36:20.049570
# Unit test for function main
def test_main():
    args = dict(
        state="started",
        name="vagrant-machine",
    )

    # test if unit exists
    module = AnsibleModule(**args)

    # mock load status
    load_status = """
    Type=oneshot
    Restart=no
    ExecStart=/usr/bin/hostname
    ExecStart=/bin/sleep 3
    ExecStart=/usr/bin/hostname
    """
    load_status_arr = load_status.split("\n")
    module.run_command = lambda *args, **kwargs: (0, "", "")
    module.run_command.return_value = (0, "", "")

# Generated at 2022-06-23 04:36:24.731159
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:28.069443
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:36:36.898571
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring request \n')
    assert request_was_ignored('ignoring request x\n')
    assert request_was_ignored('ignoring request\n')
    assert request_was_ignored('ignoring command\n')
    assert not request_was_ignored('=' * 60)
    assert not request_was_ignored('=' * 60 + '\n')
    assert not request_was_ignored('=====\n')
    assert not request_was_ignored('=====')
    assert not request_was_ignored('=====\n ignored request\n')


# Generated at 2022-06-23 04:36:42.058056
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('=  ignoring request') is False
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('=  ignoring command') is False



# Generated at 2022-06-23 04:36:49.148889
# Unit test for function is_running_service
def test_is_running_service():
    active_state_list = ['active', 'activating']
    inactive_state_list = ['inactive', 'deactivating']
    failed_state_list = ['failed', 'dying']
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not any([is_running_service({'ActiveState': state}) for state in inactive_state_list])
    assert not any([is_running_service({'ActiveState': state}) for state in failed_state_list])



# Generated at 2022-06-23 04:37:01.362283
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Description=foo', 'Foo=bar', 'Baz=qux', 'ExecStart=foo', '    bar']) == {'Description': 'foo', 'Foo': 'bar', 'Baz': 'qux', 'ExecStart': 'foo\n    bar'}
    # Verify that single-line values are handled correctly
    assert parse_systemctl_show(['Description={foo}', 'Foo=bar', 'Baz=qux', 'ExecStart=foo', '    bar']) == {'Description': '{foo}', 'Foo': 'bar', 'Baz': 'qux', 'ExecStart': 'foo\n    bar'}
    assert parse_systemctl_show(['ConditionResult=yes']) == {'ConditionResult': 'yes'}
    # Verify that multi-line values are

# Generated at 2022-06-23 04:37:10.440117
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('Assertion failed in foo(bar) at line 0\n')
    assert not request_was_ignored('/dev/foo: No such file or directory\n')
    assert request_was_ignored('ignoring request\n')
    assert request_was_ignored('ignoring command\n')
    assert request_was_ignored('ignoring request "cmd"\n')
    assert request_was_ignored('ignoring command "cmd"\n')
    assert request_was_ignored('ignoring request \'cmd\'\n')
    assert request_was_ignored('ignoring command \'cmd\'\n')
    assert request_was_ignored('ignoring request "cmd"\nignoring command "cmd"\n')

# Generated at 2022-06-23 04:37:14.540154
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})


# Generated at 2022-06-23 04:37:21.953475
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive', 'Status': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'inactive', 'Status': 'active'}) == False
    assert is_running_service({'ActiveState': 'active', 'Status': 'inactive'}) == True
    assert is_running_service({'ActiveState': 'activating', 'Status': 'inactive'}) == True



# Generated at 2022-06-23 04:37:25.285468
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'notdeactivating'})



# Generated at 2022-06-23 04:37:38.794696
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:37:40.996634
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:37:48.682652
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Failed to set wall message, ignoring: Interactive authentication required.")
    assert request_was_ignored("Failed to set wall message, ignoring: Permission denied")
    # Systemctl status output with '=' char
    assert not request_was_ignored("ActiveState=inactive")
    assert not request_was_ignored("LoadState=not-found")
    # Systemctl restart, reload output without '=' char
    assert request_was_ignored("Failed to restart tty.target: Unit tty.target not found.")
    assert request_was_ignored("Ignoring unknown unit: tty.target")
    assert request_was_ignored("Failed to reload tty.target: Unit tty.target not found.")



# Generated at 2022-06-23 04:37:50.910888
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"})
    assert not is_deactivating_service({"ActiveState": "inactive"})
    assert not is_deactivating_service({"ActiveState": "active"})



# Generated at 2022-06-23 04:38:04.071966
# Unit test for function main
def test_main():
    ACITVE_LOADED = dict(
        ActiveState='active',
        ActiveEnterTimestampMonotonic='547ms',
        ActiveExitTimestampMonotonic='0ns',
        ActiveEnterTimestamp='Thu 2017-12-21 18:23:18 CST',
        ActiveExitTimestamp='n/a',
        ActiveResult='success')

    INACTIVE_LOADED = dict(
        ActiveState='inactive',
        ActiveEnterTimestampMonotonic='0ns',
        ActiveExitTimestampMonotonic='0ns',
        ActiveEnterTimestamp='n/a',
        ActiveExitTimestamp='n/a',
        ActiveResult='n/a')


# Generated at 2022-06-23 04:38:15.527593
# Unit test for function main
def test_main():
    """Unit tests for main
    """
    import ansible.utils.template as template

    def make_module(*args, **kwargs):
        """Create a fake module."""
        params = dict(
            systemctl='systemctl',
            scope='system',
            daemon_reload=False,
            daemon_reexec=False,
            no_block=False,
            force=False,
            masked=None,
        )
        params.update(kwargs)
        module = FakeModule(**params)
        module.run_command = FakeRunCommand(module)
        module.warn = FakeWarn(module)
        module.fail_json = FakeFailJson(module)
        module.exit_json = FakeExitJson(module)
        return module


# Generated at 2022-06-23 04:38:17.991890
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:38:24.673378
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_data = [
        ["First single line output"],
        ["Output with multiple equals signs=1=2=3"],
        ["ExecStart={ something"],  # multi-line value that doesn't end with }
        ["ExecStart={ something; something else; }"],  # multi-line value that does end with }
        ["Normal single line output"],
        ["Multi line output that starts with { but does not end with }", "continued line", "continued line"],
        ["Multi line output that starts with { and ends with }", "continued line", "}"],
        ["Last single line output"],
    ]

# Generated at 2022-06-23 04:38:36.548284
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:46.162261
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:38:49.258835
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False



# Generated at 2022-06-23 04:38:51.950428
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Job is already running: dnf-automatic.timer")
    assert not request_was_ignored("Test=Unit")
    assert not request_was_ignored("Failure")



# Generated at 2022-06-23 04:38:54.089350
# Unit test for function main
def test_main():
    print(main)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:07.014558
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
  ''' Test for parse_systemctl_show '''
  # positive test
  test_parse = [
    'Id=foo',
    'ExecStart={',
    '   /bin/foo',
    '}'
  ]
  test_result = {'Id':'foo','ExecStart':'\n   /bin/foo\n'}
  assert parse_systemctl_show(test_parse) == test_result

  # negative test
  assert parse_systemctl_show('') == {}

  # multi-line negative test
  test_parse = [
    'Id=foo',
    'ExecStart={',
    '   /bin/foo',
  ]
  assert parse_systemctl_show(test_parse) == {}



# Generated at 2022-06-23 04:39:12.512840
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    with UnitTest._systemctl('unit', 'show', 'sshd.service') as unit_show:
        for state in ['active', 'activating', 'deactivating', 'inactive']:
            service_status = {'ActiveState': state}
            if state == 'deactivating':
                assert is_deactivating_service(service_status)
            else:
                assert not is_deactivating_service(service_status)



# Generated at 2022-06-23 04:39:21.083896
# Unit test for function main
def test_main():
    argument_spec = dict(
        name=dict(type='str', aliases=['service', 'unit']),
        state=dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped']),
        enabled=dict(type='bool'),
        force=dict(type='bool'),
        masked=dict(type='bool'),
        daemon_reload=dict(type='bool', default=False, aliases=['daemon-reload']),
        daemon_reexec=dict(type='bool', default=False, aliases=['daemon-reexec']),
        scope=dict(type='str', default='system', choices=['system', 'user', 'global']),
        no_block=dict(type='bool', default=False),
    )


# Generated at 2022-06-23 04:39:32.647015
# Unit test for function main

# Generated at 2022-06-23 04:39:45.081520
# Unit test for function main
def test_main():
    with patch.object(basic.AnsibleModule, 'run_command') as mock_run_command:
        with patch('os.access') as mock_access:
            with patch('os.path.exists') as mock_exists:
                with patch('os.geteuid') as mock_geteuid:

                    mock_run_command.return_value = (0, '', '')
                    mock_access.return_value = False
                    mock_exists.return_value = False
                    mock_geteuid.return_value = 0
