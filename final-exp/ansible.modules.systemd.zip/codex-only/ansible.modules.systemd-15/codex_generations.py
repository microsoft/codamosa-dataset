

# Generated at 2022-06-23 04:29:40.090986
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({
        'ActiveState': 'active'
    })
    assert is_running_service({
        'ActiveState': 'activating'
    })
    assert not is_running_service({
        'ActiveState': 'deactivating'
    })
    assert not is_running_service({
        'ActiveState': 'inactive'
    })


# unit test is_service_enabled

# Generated at 2022-06-23 04:29:44.435673
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False



# Generated at 2022-06-23 04:29:48.174410
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:29:54.850260
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert (
        request_was_ignored('ignoring request')
    )
    assert (
        request_was_ignored('ignoring command')
    )
    assert (
        not request_was_ignored('waiting for completion')
    )
    assert (
        not request_was_ignored('ActiveState=active')
    )



# Generated at 2022-06-23 04:30:02.571141
# Unit test for function is_running_service
def test_is_running_service():
    # Test with empty dict
    assert not is_running_service({})
    # Test with service not running
    assert not is_running_service({'ActiveState': 'exited'})
    # Test with service stopped
    assert not is_running_service({'ActiveState': 'dead'})
    # Test with service starting
    assert is_running_service({'ActiveState': 'activating'})
    # Test with service running
    assert is_running_service({'ActiveState': 'active'})


# Generated at 2022-06-23 04:30:07.183465
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {'ActiveState': 'inactive'}
    assert not is_running_service(service_status)
    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status)
    service_status = {'ActiveState': 'activating'}
    assert is_running_service(service_status)



# Generated at 2022-06-23 04:30:17.302422
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('''
Job for httpd.service failed because the control process exited with
error code. See "systemctl status httpd.service" and "journalctl -xe"
for details.
''')


# Generated at 2022-06-23 04:30:22.708276
# Unit test for function main

# Generated at 2022-06-23 04:30:34.911739
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Description=Foo bar']) == {'Description': 'Foo bar'}
    assert parse_systemctl_show(['ExecStart={', '  foo = bar', '}']) == {'ExecStart': '{\n  foo = bar\n}'}
    assert parse_systemctl_show(['ExecStart={', '  foo = bar', '  baz = qux', '}']) == {'ExecStart': '{\n  foo = bar\n  baz = qux\n}'}

# Generated at 2022-06-23 04:30:44.944724
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert(is_deactivating_service(service_status) is True)
    service_status = {'ActiveState': 'deacti'}
    assert(is_deactivating_service(service_status) is False)
    service_status = {'ActiveState': 'activating'}
    assert(is_deactivating_service(service_status) is False)
    service_status = {'ActiveState': 'active'}
    assert(is_deactivating_service(service_status) is False)
    service_status = {'ActiveState': '--'}
    assert(is_deactivating_service(service_status) is False)



# Generated at 2022-06-23 04:30:47.625003
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)
    assert not is_running_service(service_status)



# Generated at 2022-06-23 04:30:59.808552
# Unit test for function main
def test_main():
    """
    Test to start the main function
    """
    # Check for name argument
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', aliases=['service', 'unit']),
        ),
        supports_check_mode=False,
    )
    # Fail if a name is not provided
    if module.params['name'] is None:
        module.fail_json(msg="This module (systemd) requires a name to be provided")

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:07.977395
# Unit test for function main
def test_main():
    test_dict = {
    'daemon_reload': False,
    'daemon_reexec': False,
    'enabled': None,
    'force': False,
    'masked': False,
    'name': 'test_module',
    'no_block': False,
    'scope': 'system',
    'state': None,
    'ANSIBLE_MODULE_ARGS': {
        'daemon_reload': False,
        'daemon_reexec': False,
        'enabled': False,
        'force': False,
        'masked': False,
        'name': 'test_module',
        'no_block': False,
        'scope': 'system',
    }}
    module = AnsibleModule(**test_dict)
    main()



# Generated at 2022-06-23 04:31:19.140302
# Unit test for function main

# Generated at 2022-06-23 04:31:27.228752
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:40.590347
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import re
    long_string = """Description=Some long string
with a newline
and a brace}
After=multi-user.target"""
    multi_line_string = """ExecStart=%%{
    echo Foo
}%%
Requires=%%{
    echo Bar
}%%
After=%%{
    echo Baz
}%%
Requires=%%{
    echo Quux
}%%"""
    multiline_description = """Description=Some long string
with a newline
and a brace}
After=multi-user.target
Requires=%%{
    echo Quux
}%%"""
    broken_brace = """Description=Some long string
with a newline
and a brace
After=multi-user.target
Requires=%%{
    echo Quux
}%%"""
    # The following strings are taken from Ansible tickets:
    # https

# Generated at 2022-06-23 04:31:50.236524
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    simple_test_data = '''MemoryAccounting=no
MemoryCurrent=0
'''
    simple_test_result = {'MemoryAccounting': 'no', 'MemoryCurrent': '0'}
    assert parse_systemctl_show(simple_test_data.splitlines()) == simple_test_result


# Generated at 2022-06-23 04:31:53.457189
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    main()
    main()
    main()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:32:05.136779
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:11.265128
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:16.811579
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    tests = [
        # test that the code can handle a single-line value that starts with {
        ('''Description=Scratch a cat
Description={ Meow
Meow }
ActiveState=active''', {
            "ActiveState": "active",
            "Description": "Scratch a cat",
        }),

        # test that the code can handle multi-line values
        ('''Description=Scratch a cat
ExecStart={ /usr/bin/touch /tmp/meow
/usr/bin/cat /tmp/meow
}
ActiveState=active''', {
            "ActiveState": "active",
            "Description": "Scratch a cat",
            "ExecStart": "/usr/bin/touch /tmp/meow\n/usr/bin/cat /tmp/meow",
        }),
    ]

# Generated at 2022-06-23 04:32:19.898839
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('not ignoring command')



# Generated at 2022-06-23 04:32:31.736571
# Unit test for function main
def test_main():
    for state in ['started', 'stopped', 'reloaded', 'restarted']:
        unit = 'sshd'
        systemctl = '/bin/systemctl'
        module = AnsibleModule(
            argument_spec=dict(
                name=dict(type='str', aliases=['service', 'unit']),
                state=dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped']),
            ),
            supports_check_mode=True,
            required_one_of=[['state']],
            required_by=dict(
                state=('name', ),
            ),
        )
        module.params['state'] = state
        module.params['name'] = unit
        main()

# Generated at 2022-06-23 04:32:33.354929
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(
        'Job for crond.service failed. See "systemctl status crond.service" and "journalctl -xn" for details.'
    )



# Generated at 2022-06-23 04:32:46.040515
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    simple = [
        'Id=foo.service',
        'LoadState=loaded',
        'Name=foo.service',
        'Names=foo.service'
    ]
    assert parse_systemctl_show(simple) == {
        'Id': 'foo.service',
        'LoadState': 'loaded',
        'Name': 'foo.service',
        'Names': 'foo.service'
    }

    multiline_simple = [
        'Description=This is a long description\nthat spans multiple lines.',
        'ExecStart={ path=/bin/bad ; argv[]=/bin/bad ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'
    ]

# Generated at 2022-06-23 04:32:53.018536
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'unknwon'}) is False



# Generated at 2022-06-23 04:32:57.601521
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('  ignoring request ')
    assert request_was_ignored('  ignoring request because ')
    assert request_was_ignored('  ignoring command ')
    assert request_was_ignored('  ignoring command because ')
    assert not request_was_ignored('  random text because ')



# Generated at 2022-06-23 04:33:04.100366
# Unit test for function is_running_service
def test_is_running_service():
    active = {'ActiveState': 'active'}
    activating = {'ActiveState': 'activating'}
    not_active = {'ActiveState': 'inactive'}
    assert is_running_service(active)
    assert is_running_service(activating)
    assert not is_running_service(not_active)



# Generated at 2022-06-23 04:33:09.310088
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({
        'ActiveState': 'active',
        'SubState': 'running',
    })
    assert is_running_service({
        'ActiveState': 'activating',
        'SubState': 'starting',
    })
    assert not is_running_service({
        'ActiveState': 'failed',
        'SubState': 'dead',
    })



# Generated at 2022-06-23 04:33:15.755845
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring') is False
    assert request_was_ignored('=') is False
    assert request_was_ignored('') is False



# Generated at 2022-06-23 04:33:18.762826
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('= inactive (dead)')



# Generated at 2022-06-23 04:33:24.000566
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})


# Generated at 2022-06-23 04:33:27.987854
# Unit test for function is_running_service
def test_is_running_service():
    assert(is_running_service({'ActiveState': 'active'}))
    assert(is_running_service({'ActiveState': 'activating'}))
    assert(not is_running_service({'ActiveState': 'something else'}))



# Generated at 2022-06-23 04:33:31.692210
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {
        'ActiveState': 'deactivating',
    }
    assert is_deactivating_service(service_status) is True



# Generated at 2022-06-23 04:33:45.350578
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:50.529466
# Unit test for function main
def test_main():
    # Test with no arguments
    args = dict(
        daemon_reload=True,
        daemon_reexec=True,
        scope='system',
        no_block=False,
    )

    result = execute_module(DEFAULT_ARGS, additional_args=args)
    assert result['changed'] is False


# Generated at 2022-06-23 04:33:56.643530
# Unit test for function main
def test_main():
    test_loader = unittest.TestLoader()
    test_suite = test_loader.discover(os.path.dirname(__file__), pattern='test*.py')
    unittest.TextTestRunner(verbosity=2).run(test_suite)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:09.404633
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test1 = [
        "ConditionResult=yes",
        "ActiveState=active",
        "ExecMainStartTimestampMonotonic=251483345",
        "InactiveEnterTimestampMonotonic=0",
        "Description=Command Scheduler",
        "MainPID=1076",
        "ExecStart={ path=/usr/sbin/cron ; argv[]=/usr/sbin/cron -f ; ignore_errors=no ; start_time=251483345 ; stop_time=0 ; pid=0 ; code=(null) ; status=0/0 }",
        "OnFailureJobMode=replace"
    ]

# Generated at 2022-06-23 04:34:12.373634
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request to reload systemd-journald.service')
    assert not request_was_ignored('= Invalid service')
    assert request_was_ignored('ignoring command, already queued')
    assert not request_was_ignored('foo')



# Generated at 2022-06-23 04:34:22.075155
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('foo=bar') == False
    assert request_was_ignored('foo=bar bar=baz') == False
    assert request_was_ignored('foo') == False
    assert request_was_ignored('foo bar') == False
    assert request_was_ignored('foo ignoring command') == True
    assert request_was_ignored('foo ignoring command command2') == True
    assert request_was_ignored('foo ignoring request') == True
    assert request_was_ignored('foo ignoring request request2') == True



# Generated at 2022-06-23 04:34:36.222006
# Unit test for function is_deactivating_service
def test_is_deactivating_service():

    # test 1:
    # function is returning false, if input is empty
    service_status = {}
    result = is_deactivating_service(service_status)
    assert not result

    # test 2:
    # function is returning false, if input doesn't have ActiveState
    service_status = {'State': 'active'}
    result = is_deactivating_service(service_status)
    assert not result

    # test 3:
    # function is returning false, if input ActiveState is not deactivating
    service_status = {'ActiveState': 'activating'}
    result = is_deactivating_service(service_status)
    assert not result

    # test 4:
    # function is returning false, if input ActiveState is not deactivating

# Generated at 2022-06-23 04:34:40.713961
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState':'dead'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState':'activating'})



# Generated at 2022-06-23 04:34:54.371401
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:55.836206
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:59.933973
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'exited'})



# Generated at 2022-06-23 04:35:13.722743
# Unit test for function main
def test_main():
    unit = ('test_name')
    state = ('test_state')
    enabled = ('test_enabled')
    masked = ('test_masked')
    daemon_reload = ('test_daemon_reload')
    daemon_reexec = ('test_daemon_reexec')
    scope = ('test_scope')
    no_block = ('test_no_block')
    force = ('test_force')
    

# Generated at 2022-06-23 04:35:17.237126
# Unit test for function main

# Generated at 2022-06-23 04:35:20.915504
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating'))
    assert not is_deactivating_service(dict(ActiveState='active'))



# Generated at 2022-06-23 04:35:27.925170
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {
        'ActiveState': 'active'
    }
    assert is_running_service(service_status)

    service_status['ActiveState'] = 'activating'
    assert is_running_service(service_status)

    service_status['ActiveState'] = 'inactive'
    assert not is_running_service(service_status)



# Generated at 2022-06-23 04:35:32.362444
# Unit test for function is_running_service
def test_is_running_service():

    for state in ('active', 'activating'):
        result = is_running_service({'ActiveState': state})
        assert result, "%s should be running"%state

    for state in ('inactive', 'deactivating', 'failed'):
        result = is_running_service({'ActiveState': state})
        assert not result, "%s should not be running"%state



# Generated at 2022-06-23 04:35:37.242964
# Unit test for function request_was_ignored
def test_request_was_ignored():
    for line in ['=', 'foobar']:
        assert not request_was_ignored(line)

    for line in ['ignoring request', 'foobar ignoring command']:
        assert request_was_ignored(line)



# Generated at 2022-06-23 04:35:39.491613
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:35:43.264679
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({"ActiveState": "active"})
    assert is_running_service({"ActiveState": "activating"})
    assert not is_running_service({"ActiveState": "deactivating"})



# Generated at 2022-06-23 04:35:47.529026
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    result = is_deactivating_service(service_status)
    assert result == True
    service_status = {'ActiveState': 'active'}
    result = is_deactivating_service(service_status)
    assert result == False
    service_status = {'ActiveState': 'activating'}
    result = is_deactivating_service(service_status)
    assert result == False


# Generated at 2022-06-23 04:36:00.000264
# Unit test for function request_was_ignored

# Generated at 2022-06-23 04:36:03.264291
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState':'deactivating'})

# Generated at 2022-06-23 04:36:14.771546
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:29.111131
# Unit test for function main
def test_main():
    import inspect
    import base64
    import os
    import sys

    if os.path.exists("/tmp/ansible_systemd_payload"):
       with open("/tmp/ansible_systemd_payload", "r") as f:
           payload = f.read()
    else:
       payload = base64.b64decode("==").decode("utf-8")

    os.environ['XDG_RUNTIME_DIR'] = '/run/user/%s' % os.geteuid()
    globals()['systemctl'] = 'systemctl'

    # load the test scenario file
    module = AnsibleModule(argument_spec=dict())

    # manipulate or modify the state as needed (prior to final Check Mode testing)

# Generated at 2022-06-23 04:36:36.590628
# Unit test for function request_was_ignored
def test_request_was_ignored():
    res = request_was_ignored('')
    assert res is False
    res = request_was_ignored('ignoring request')
    assert res is True
    res = request_was_ignored('ignoring command')
    assert res is True
    res = request_was_ignored('FAILED')
    assert res is False
    res = request_was_ignored('Job for bla.service failed because the control process exited with\nerror code. See "systemctl status bla.service" and "journalctl -xe" for details.') # noqa
    assert res is False



# Generated at 2022-06-23 04:36:40.937461
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Ignoring request")
    assert request_was_ignored("Ignoring command")
    assert not request_was_ignored("=1h 10s 1838ms")



# Generated at 2022-06-23 04:36:49.197457
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:55.101718
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) is True
    service_status = {'ActiveState': 'active'}
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-23 04:36:59.255180
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)
    service_status = {'ActiveState': 'inactive'}
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-23 04:37:08.760553
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:37:11.661155
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('=' * 70)



# Generated at 2022-06-23 04:37:23.800447
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['foo=bar', 'baz =    boom', 'ExecStart={/bin/foo arg1 arg2 arg3}', 'ExecStop={/bin/bar arg1 arg2 arg3;/bin/baz arg1 arg2 arg3}']) == {'foo': 'bar', 'baz': 'boom', 'ExecStart': '/bin/foo arg1 arg2 arg3', 'ExecStop': '/bin/bar arg1 arg2 arg3;/bin/baz arg1 arg2 arg3'}

# Generated at 2022-06-23 04:37:36.973963
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:37:45.769219
# Unit test for function main
def test_main():
    test_path = os.path.join(os.path.dirname(__file__), 'test-module-systemd-service', 'integration')
    os.environ['PATH'] = "%s:%s" % (test_path, os.environ['PATH'])
    os.environ['SYSTEMD_OFFLINE'] = '1'
    try:
        import runpy
    except ImportError:
        return
    runpy.run_module("systemd_service", init_globals={}, run_name="__main__", alter_sys=True)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-23 04:37:49.992178
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(to_native(ValueError(''))) is False
    assert request_was_ignored('foo=bar') is False
    assert request_was_ignored('foo ignoring command=bar') is False
    assert request_was_ignored('foo=bar ignoring request') is False
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True



# Generated at 2022-06-23 04:37:55.030351
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # https://github.com/ansible/ansible/issues/15750
    assert request_was_ignored('Warning: Stopping firewalld.service, but it can still be activated by:   firewalld.socket')



# Generated at 2022-06-23 04:37:58.378825
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'a'}) is False



# Generated at 2022-06-23 04:38:03.253012
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'deactivating'}) == False
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'failed'}) == False
    assert is_running_service({'ActiveState': 'unknown'}) == False



# Generated at 2022-06-23 04:38:08.817290
# Unit test for function main
def test_main():
    import sys
    import inspect
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.basic import AnsibleModule

    def _exit_json(exception, exit_args):
        print("exit_args = %s" % exit_args)

    def _fail_json(exception, fail_args):
        print("fail_args = %s" % fail_args)

    def _get_bin_path(binary, required):
        # use a stock systemd binary
        return "/usr/bin/systemctl"


# Generated at 2022-06-23 04:38:19.377439
# Unit test for function main
def test_main():
    unit_helper = UnitHelper()


# Generated at 2022-06-23 04:38:27.189706
# Unit test for function is_running_service
def test_is_running_service():
    service = dict()
    for i in ['active', 'activating']:
        service['ActiveState'] = i
        assert is_running_service(service) == True
    for i in ['inactive', 'deactivating', 'failed', 'auto-restart']:
        service['ActiveState'] = i
        assert is_running_service(service) == False



# Generated at 2022-06-23 04:38:37.889692
# Unit test for function is_deactivating_service

# Generated at 2022-06-23 04:38:56.207045
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys
    import shlex


# Generated at 2022-06-23 04:39:04.823817
# Unit test for function is_running_service
def test_is_running_service():
    # Service running
    assert is_running_service({'ActiveState': 'active'})
    # Service starting
    assert is_running_service({'ActiveState': 'activating'})
    # Service stopping
    assert not is_running_service({'ActiveState': 'deactivating'})
    # Service stopped
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:39:10.747724
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request, no unit name supplied.') is True
    assert request_was_ignored('=') is False
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('Failed to connect to bus: No such file or directory') is False
    assert request_was_ignored('Cannot talk to the bus') is False



# Generated at 2022-06-23 04:39:12.241433
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})


# Generated at 2022-06-23 04:39:14.188166
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active')) is True
    assert is_running_service(dict(ActiveState='activating')) is True



# Generated at 2022-06-23 04:39:21.121590
# Unit test for function main

# Generated at 2022-06-23 04:39:32.686589
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Single-line values
    lines = [
        'Description=Foo',
        'Id=foo.service',
        'Before=bar.service',
    ]
    parsed = parse_systemctl_show(lines)
    assert parsed == {
        'Description': 'Foo',
        'Id': 'foo.service',
        'Before': 'bar.service',
    }

    # Multi-line values, with some additional keys to ensure we don't "bleed"

# Generated at 2022-06-23 04:39:36.823894
# Unit test for function main
def test_main():
    from ansible.module_utils.common.removed import removed
    with pytest.raises(removed):
        main()

if __name__ == '__main__':
    main()