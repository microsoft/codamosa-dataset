

# Generated at 2022-06-23 04:29:41.911218
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:29:54.360563
# Unit test for function main

# Generated at 2022-06-23 04:29:57.872841
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:30:01.608141
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('Assertion failed')
    assert not request_was_ignored('   Loaded: loaded')



# Generated at 2022-06-23 04:30:11.286644
# Unit test for function main

# Generated at 2022-06-23 04:30:14.740925
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request ...')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('/usr/bin/systemctl list-unit-files --no-pager --type=service --state=enabled --root')



# Generated at 2022-06-23 04:30:28.339198
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:38.207404
# Unit test for function main
def test_main():
    test_unit_args = dict(
        name='foo.service',
        state='reloaded',
        enabled=True,
        force=False,
        masked=False,
        daemon_reload=False,
        daemon_reexec=False,
        scope='system',
        no_block=False,
    )

# Generated at 2022-06-23 04:30:48.694820
# Unit test for function main
def test_main():
    root = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'systemctl_test_data')

    with mock.patch('systemctl.sysv_exists') as mock_sysv_exists:
        with mock.patch('systemctl.sysv_is_enabled') as mock_sysv_is_enabled:
            with mock.patch('systemctl.is_chroot') as mock_is_chroot:
                with mock.patch('systemctl.is_running_service') as mock_is_running_service:
                    with mock.patch('systemctl.is_deactivating_service') as mock_is_deactivating_service:
                        mock_is_chroot.return_value = False

# Generated at 2022-06-23 04:30:56.024955
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True
    assert is_deactivating_service({'ActiveState': 'inactive'}) == False


# Generated at 2022-06-23 04:31:01.070863
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status_list = [{'ActiveState': 'deactivating'},{'ActiveState': 'inactive'},{'ActiveState': 'failed'}]
    for status in status_list:
        assert(is_deactivating_service(status))



# Generated at 2022-06-23 04:31:06.277635
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'active'}) is True
    assert is_deactivating_service({'ActiveState': 'activating'}) is True
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False
    assert is_deactivating_service({'ActiveState': 'failed'}) is False



# Generated at 2022-06-23 04:31:11.632065
# Unit test for function main
def test_main():
    args = dict(
        name='httpd',
        state='reloaded',
        daemon_reload=False,
        daemon_reexec=False,
        scope='system',
        no_block=False,
    )
    check_args(args)
    main(args)


# Generated at 2022-06-23 04:31:23.929915
# Unit test for function request_was_ignored
def test_request_was_ignored():
    true_tests = [
        'Requested transaction contradicts existing jobs: Transaction is destructive.',
        'Requested transaction contradicts existing jobs: Transaction is destructive.',
        'Requested transaction contradicts existing jobs: Transaction is destructive.',
        'Job for mysqld.service failed because the control process exited with error code. See "systemctl status mysqld.service" and "journalctl -xe" for details',
        'The name org.freedesktop.PolicyKit1 was not provided by any .service files',
    ]

# Generated at 2022-06-23 04:31:37.116752
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(to_native(u"""
Job for systemd-journal-flush.service failed because a timeout was exceeded. See "systemctl status systemd-journal-flush.service" and "journalctl -xe" for details.
    """))

# Generated at 2022-06-23 04:31:43.370328
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('Failed to start x.service: Unit x.service not found.') is False



# Generated at 2022-06-23 04:31:47.136983
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:31:59.150642
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    expected = {'foo': 'bar', 'key': 'value', 'otherkey': 'othervalue', 'ExecStart': '{ path=/usr/bin/foo ; argv[]=/usr/bin/foo ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }\n{ path=/usr/bin/bar ; argv[]=/usr/bin/bar ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'}

# Generated at 2022-06-23 04:32:01.858902
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:32:15.043753
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:26.808125
# Unit test for function main
def test_main():
    """
    Unit test for main.
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import main as m

    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    class MockModule(object):

        def __init__(self):

            self.params = {
                "name": "mock_service",
            }
            self.name = "mock_service"
            self.service = "mock_service"
            self.fail_json = lambda *args, **kwargs: abort()
            self.exit_json = lambda *args, **kwargs: abort()


# Generated at 2022-06-23 04:32:30.818745
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    input_dict = {
        'ActiveState': 'deactivating',
        'AnotherKey': 'AnotherValue'
    }
    assert is_deactivating_service(input_dict)



# Generated at 2022-06-23 04:32:44.529066
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Single-line value requiring no parsing
    assert parse_systemctl_show(['foo=bar']) == {'foo': 'bar'}

    # Multi-line value spanning two lines
    assert parse_systemctl_show(['foo={', 'bar}']) == {'foo': 'bar'}

    # Single-line value starting with { but not ending with }
    assert parse_systemctl_show(['foo={bar']) == {'foo': '{bar'}

    # Multi-line value spanning three lines
    assert parse_systemctl_show(['foo={', 'bar,', 'baz}']) == {'foo': 'bar,\nbaz'}

    # Multi-line value split by non-value lines
    assert parse_systemctl_show(['foo={', 'bar', '=', 'baz}'])

# Generated at 2022-06-23 04:32:49.061920
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'notfound'})



# Generated at 2022-06-23 04:32:59.816692
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    """
    Test case with output of 'systemctl show' command.
    """

# Generated at 2022-06-23 04:33:06.204297
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:15.033683
# Unit test for function main
def test_main():
    unit = None
    state = None
    enabled = False
    masked = None
    force = False
    daemon_reload = None
    daemon_reexec = None
    scope = 'system'
    no_block = False

    class Module(object):
        args = dict(name=unit,
                    state=state,
                    enabled=enabled,
                    masked=masked,
                    force=force,
                    daemon_reload=daemon_reload,
                    daemon_reexec=daemon_reexec,
                    scope=scope,
                    no_block=no_block,)

    class TestClass(object):
        def __init__(self):
            self.params = Module()

    unit = TestClass()
    if unit is not None:
        for globpattern in '*', '?', '[':
            assert glob

# Generated at 2022-06-23 04:33:22.854480
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # return False with any other input
    assert request_was_ignored('') is False
    assert request_was_ignored('anything') is False

    # return True only if ignoring request
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True

    # False otherwise
    assert request_was_ignored('= ignoring request = ') is False



# Generated at 2022-06-23 04:33:26.142758
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring request'))
    assert(request_was_ignored('      ignoring command'))
    assert(not request_was_ignored('= asdf asdf'))



# Generated at 2022-06-23 04:33:28.632823
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:33:35.452459
# Unit test for function is_running_service
def test_is_running_service():
    test1 = dict(ActiveState='active')
    assert is_running_service(test1) == True

    test2 = dict(ActiveState='activating')
    assert is_running_service(test2) == True

    test3 = dict(ActiveState='inactive')
    assert is_running_service(test3) == False

    test4 = dict(ActiveState='deactivating')
    assert is_running_service(test4) == False


# Generated at 2022-06-23 04:33:41.668352
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({})
    assert not is_running_service({'ActiveState': 'unknown'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-23 04:33:43.279449
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-23 04:33:55.556226
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    print('test parse_systemctl_show')
    # Test 1: Parse a section with all single-line values
    lines = [
        'After=systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice',
        'Before=shutdown.target multi-user.target',
        'Description=Job spooling tools',
        'Documentation=man:atd(8) man:at(1) man:batch(1)',
        'Wants=system-systemd\x2datd.slice',
    ]

# Generated at 2022-06-23 04:33:59.983779
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo = bar')
    assert not request_was_ignored('bar')



# Generated at 2022-06-23 04:34:12.162819
# Unit test for function main

# Generated at 2022-06-23 04:34:18.916411
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('= ignoring command\n')
    assert request_was_ignored('= ignoring command\n= ignoring request')
    assert not request_was_ignored('something')
    assert not request_was_ignored('')
    assert not request_was_ignored('= something')



# Generated at 2022-06-23 04:34:26.909830
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    '''
    Test function is_deactivating_service()
    '''
    assert is_deactivating_service({'ActiveState': 'active'}) == False
    assert is_deactivating_service({'ActiveState': 'activating'}) == True
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True
    assert is_deactivating_service({'ActiveState': 'inactive'}) == False



# Generated at 2022-06-23 04:34:39.248334
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test case: single-line value
    result = parse_systemctl_show(['Description=A single-line value'])
    assert result == {'Description': 'A single-line value'}
    # Test case: multi-line value
    result = parse_systemctl_show([
        'ExecStart={\n',
        '\tPath=/usr/sbin/crond\n',
        '\tArguments=-n $CRONDARGS\n',
        '}',
    ])
    assert result == {'ExecStart': '{\n\tPath=/usr/sbin/crond\n\tArguments=-n $CRONDARGS\n}'}
    # Test case: multi-line value spanning multiple lines

# Generated at 2022-06-23 04:34:46.714112
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_sample = [
        'Description=Foo',
        'ExecStart={',
        '  blah blah blah',
        '  }',
        'ExecStop=bar'
    ]
    expected = {'Description': 'Foo', 'ExecStart': 'blah blah blah', 'ExecStop': 'bar'}
    actual = parse_systemctl_show(test_sample)
    assert expected == actual


# Generated at 2022-06-23 04:34:52.167513
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:34:54.846440
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = 'to create user instance, please see pam_systemd(8)'
    assert request_was_ignored(out)



# Generated at 2022-06-23 04:35:07.882668
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:11.687789
# Unit test for function is_running_service
def test_is_running_service():
    print("Test for function is_running_service")
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})


# Generated at 2022-06-23 04:35:18.905611
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'unknown'}) == False
    assert is_running_service({'ActiveState': 'failed'}) == False
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'active'}) == True



# Generated at 2022-06-23 04:35:26.503004
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {
        'ActiveState': 'inactive',
    }
    assert not is_running_service(service_status)

    service_status = {
        'ActiveState': 'active',
    }
    assert is_running_service(service_status)

    service_status = {
        'ActiveState': 'activating',
    }
    assert is_running_service(service_status)



# Generated at 2022-06-23 04:35:37.072350
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:41.652152
# Unit test for function is_running_service
def test_is_running_service():
    for state in ['active', 'activating']:
        assert is_running_service(dict(ActiveState=state))
    for state in ['inactive', 'failed', 'deactivating', 'unknown']:
        assert not is_running_service(dict(ActiveState=state))



# Generated at 2022-06-23 04:35:47.280768
# Unit test for function request_was_ignored
def test_request_was_ignored():
    failure_output = "Failed to start LSB: Apache2 web server.\nSee 'systemctl status apache2.service' and 'journalctl -xn' for details.\n"
    assert not request_was_ignored(failure_output)

    ignored_output = "Ignoring unknown unit: foo.service\n"
    assert request_was_ignored(ignored_output)

    ignored_output = "Ignoring request to reload foo.service, server has been shut down.\n"
    assert request_was_ignored(ignored_output)



# Generated at 2022-06-23 04:35:59.835586
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, env_fallback
    from mock import patch


# Generated at 2022-06-23 04:36:12.550754
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['Description=xfce4-terminal']) == {'Description': 'xfce4-terminal'}

# Generated at 2022-06-23 04:36:17.664248
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    assert is_deactivating_service({'ActiveState': 'activating'}) is False
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:36:22.530722
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('some output=ignoring request') is False
    assert request_was_ignored('some output=retval') is False
    assert request_was_ignored('some output=missing') is False
    assert request_was_ignored('some output=random') is False



# Generated at 2022-06-23 04:36:30.122278
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({u'ActiveState': u'deactivating'}), \
        'is_deactivating_service failed'
    assert not is_deactivating_service({u'ActiveState': u'active'}), \
        'is_deactivating_service failed'
    assert not is_deactivating_service({u'ActiveState': u'inactive'}), \
        'is_deactivating_service failed'



# Generated at 2022-06-23 04:36:32.646448
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:36:45.245269
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('') is False
    assert request_was_ignored('\n') is False
    assert request_was_ignored('=') is False
    assert request_was_ignored('=\n') is False
    assert request_was_ignored('=' * 10) is False
    assert request_was_ignored('=' * 10 + '\n') is False
    assert request_was_ignored('= ' * 10 + '\n') is False
    assert request_was_ignored('=\nignoring request') is True
    assert request_was_ignored('=\nignoring request\n') is True
    assert request_was_ignored('=\nignoring request ' * 10) is True
    assert request_was_ignored('=\nignoring request\n' * 10)

# Generated at 2022-06-23 04:36:51.112419
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {
        "ActiveState": "deactivating"
    }
    assert is_deactivating_service(service_status) is True
    service_status = {
        "ActiveState": "inactive"
    }
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-23 04:36:56.019259
# Unit test for function main

# Generated at 2022-06-23 04:37:02.882579
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('this is the status string Systemd returned=ignoring command')
    assert not request_was_ignored('ignoring=request')
    assert not request_was_ignored('some random status string=foo')



# Generated at 2022-06-23 04:37:07.605861
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    test_is_deactivating_service.result = is_deactivating_service(service_status)
    if test_is_deactivating_service.result is False:
        raise Exception('"deactivating" state should be treated as deactivating service')
test_is_deactivating_service.result = None


# Generated at 2022-06-23 04:37:09.466529
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})


# Generated at 2022-06-23 04:37:22.006630
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:37:29.493462
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:37:33.435057
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='inactive'))



# Generated at 2022-06-23 04:37:37.592353
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-23 04:37:47.863076
# Unit test for function main
def test_main():

    import json
    import shutil
    import tempfile
    executable = shutil.which('systemctl')

    if executable is None:
        module = AnsibleModule(argument_spec={})
        module.fail_json(msg="Executable 'systemctl' not found. Cannot execute module. Are required packages installed?")

    systemctl = executable

# Generated at 2022-06-23 04:37:51.266365
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})


# Generated at 2022-06-23 04:38:04.365985
# Unit test for function is_deactivating_service

# Generated at 2022-06-23 04:38:10.943486
# Unit test for function is_running_service
def test_is_running_service():
    running = {'ActiveState': 'active'}
    assert is_running_service(running)
    activating = {'ActiveState': 'activating'}
    assert is_running_service(activating)
    failed = {'ActiveState': 'failed'}
    assert not is_running_service(failed)
    in_transit = {'ActiveState': 'inactive'}
    assert not is_running_service(in_transit)


# Generated at 2022-06-23 04:38:16.603891
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})


# Generated at 2022-06-23 04:38:29.604407
# Unit test for function is_running_service
def test_is_running_service():
    running = {
        'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT',
        'ActiveEnterTimestampMonotonic': '8135942',
        'ActiveExitTimestampMonotonic': '0',
        'ActiveState': 'active',
        'After': 'auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice',
        'AllowIsolate': 'no',
    }
    assert is_running_service(running)

# Generated at 2022-06-23 04:38:32.813634
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('=') is False
    assert request_was_ignored('foo') is False



# Generated at 2022-06-23 04:38:34.616178
# Unit test for function main
def test_main():
    assert True

# import module snippets
from ansible.module_utils.basic import *


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:41.132372
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:47.117320
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:49.846720
# Unit test for function is_running_service
def test_is_running_service():
    assert(is_running_service({'ActiveState': 'active'}))
    assert(is_running_service({'ActiveState': 'activating'}))



# Generated at 2022-06-23 04:38:55.786408
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('= Some data')
    assert not request_was_ignored('[= Some data')
    assert not request_was_ignored('')
    assert not request_was_ignored('Failed to')



# Generated at 2022-06-23 04:39:04.446194
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_result = is_deactivating_service({'ActiveState': 'active'})
    assert test_result == False
    test_result = is_deactivating_service({'ActiveState': 'activating'})
    assert test_result == False
    test_result = is_deactivating_service({'ActiveState': 'deactivating'})
    assert test_result == True


# Generated at 2022-06-23 04:39:08.064402
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request.')
    assert not request_was_ignored('Something else')
    assert not request_was_ignored('Failing.')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request.')



# Generated at 2022-06-23 04:39:16.600757
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test a simple key-value pair
    assert parse_systemctl_show(['Description=Foo']) == {'Description': 'Foo'}
    # Test with a multi-line value
    lines = ['Description=', '  Foo', '  bar']
    assert parse_systemctl_show(lines) == {'Description': 'Foo\nbar'}
    # Test with a value that is followed by a key-value pair
    lines = ['Description=', '  Foo', '  bar', 'After=quux']
    assert parse_systemctl_show(lines) == {'Description': 'Foo\nbar', 'After': 'quux'}
    # Test with a multi-line value that has a "{" but does not end with a "}"

# Generated at 2022-06-23 04:39:20.156283
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('ignoring')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('ignoring command ')
    assert not request_was_ignored('=')



# Generated at 2022-06-23 04:39:32.125713
# Unit test for function parse_systemctl_show