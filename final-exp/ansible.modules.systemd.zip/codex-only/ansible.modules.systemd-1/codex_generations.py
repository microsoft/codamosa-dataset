

# Generated at 2022-06-23 04:29:39.369456
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo = bar')
    assert not request_was_ignored('foo')
    assert not request_was_ignored('foo =')



# Generated at 2022-06-23 04:29:42.686591
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'active'}) is True


# Generated at 2022-06-23 04:30:02.160505
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    parse_systemctl_show_test = parse_systemctl_show
    # A multi-line value must be preceded by a key/value pair.
    assert parse_systemctl_show_test([
        'ExecStart={'
    ]) == {}
    assert parse_systemctl_show_test([
        'ExecStart={',
    ]) == {}
    # Keys whose names do not start with Exec must not be multi-line.
    assert parse_systemctl_show_test([
        'Description=some value',
    ]) == {'Description': 'some value'}
    assert parse_systemctl_show_test([
        'Description=some value',
        ' that spans multiple lines',
    ]) == {'Description': 'some value\nthat spans multiple lines'}
    # Keys whose names start with Exec must be multi-line.
    assert parse

# Generated at 2022-06-23 04:30:05.805467
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    # GIVEN
    service_status = {'ActiveState': 'deactivating'}
    expected_result = True
    # WHEN
    actual_result = is_deactivating_service(service_status)
    # THEN
    assert actual_result == expected_result



# Generated at 2022-06-23 04:30:12.652195
# Unit test for function main
def test_main():
    import mock
    module = mock.MagicMock()

    module.params['name'] = 'test_name'
    module.params['force'] = 'test_force'
    module.params['masked'] = 'test_masked'
    module.params['daemon_reload'] = 'test_daemon_reload'
    module.params['daemon_reexec'] = 'test_daemon_reexec'
    module.params['scope'] = 'system'

# Generated at 2022-06-23 04:30:15.166624
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    true_params = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(true_params) is True
    false_params = {'ActiveState': 'inactive'}
    assert is_deactivating_service(false_params) is False



# Generated at 2022-06-23 04:30:20.051713
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    status_dict_a = {"ActiveState": 'inactive'}
    status_dict_b = {"ActiveState": 'deactivating'}

    assert not is_deactivating_service(status_dict_a)
    assert is_deactivating_service(status_dict_b)



# Generated at 2022-06-23 04:30:29.669563
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Single-line value
    assert parse_systemctl_show(["foo={bar}"])["foo"] == "{bar}"
    # Multi-line value
    assert parse_systemctl_show(["foo={bar", "baz}"])["foo"] == "{bar\nbaz}"
    # Multiple values
    assert parse_systemctl_show(["foo={bar", "baz}", "qux=quux"]) == {"foo": "{bar\nbaz}", "qux": "quux"}



# Generated at 2022-06-23 04:30:39.568042
# Unit test for function main
def test_main():
    out = StringIO()

# Generated at 2022-06-23 04:30:42.806978
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test1 = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(test1)



# Generated at 2022-06-23 04:30:45.342940
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = "A unit file state change job for nginx.service has been submitted, but the unit has other jobs queued. " + \
        "Waiting for job nginx.service/stop to finish..."
    assert request_was_ignored(out) is True
    out = "Job nginx.service/stop failed with result 'dependency'.\n"
    assert request_was_ignored(out) is False



# Generated at 2022-06-23 04:30:50.414571
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:31:00.458869
# Unit test for function request_was_ignored
def test_request_was_ignored():

    assert request_was_ignored('=') is False
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('foo bar') is False
    assert request_was_ignored('foo') is False
    assert request_was_ignored('ignoring bar') is False



# Generated at 2022-06-23 04:31:08.420564
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        "Description=OpenSSH server daemon",
        "Documentation=man:sshd(8) man:sshd_config(5)",
        "MainPID=1413",
        "Types=simple",
        "ExecStart={ path=/usr/sbin/sshd ; argv[]=/usr/sbin/sshd -D $SSHD_OPTS",
        "}",
        "ExecReload={ path=/usr/bin/kill ; argv[]=/usr/bin/kill -HUP $MAINPID }"
    ]
    parsed = parse_systemctl_show(lines)
    assert parsed['Description'] == 'OpenSSH server daemon'
    assert parsed['Documentation'] == 'man:sshd(8) man:sshd_config(5)'

# Generated at 2022-06-23 04:31:14.206276
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # return True if the request was ignored
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    # return False if there was an actual match
    assert not request_was_ignored("1. foo.service")
    assert not request_was_ignored("foo:foo.service")



# Generated at 2022-06-23 04:31:18.935054
# Unit test for function main

# Generated at 2022-06-23 04:31:20.657929
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:31:31.370927
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active', 'SubState': 'running'})
    assert is_running_service({'ActiveState': 'activating', 'SubState': 'running'})
    assert not is_running_service({'ActiveState': '-', 'SubState': 'running'})
    assert not is_running_service({'ActiveState': 'active', 'SubState': '-/-'})
    assert not is_running_service({'ActiveState': 'activating', 'SubState': '-/-'})
    assert not is_running_service({'ActiveState': 'inactive', 'SubState': 'running'})
    assert not is_running_service({'ActiveState': 'active', 'SubState': 'exited'})

# Generated at 2022-06-23 04:31:42.020358
# Unit test for function main

# Generated at 2022-06-23 04:31:54.703948
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:03.459892
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = map(lambda el: el.strip(),
                '''foo=bar
                   Exec1= { path=/bin/true ; argv[]=/bin/echo one ; ignore_errors=no }
                   Exec2= { path=/bin/true ; argv[]=/bin/echo two ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }'''.split('\n'))

# Generated at 2022-06-23 04:32:09.477491
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule, get_distribution, get_distribution_version


# Generated at 2022-06-23 04:32:12.464257
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored("ActiveState=active")
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")



# Generated at 2022-06-23 04:32:15.351462
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    unit = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(unit) is True



# Generated at 2022-06-23 04:32:27.212690
# Unit test for function main
def test_main():
    unit = 'syslog.service'
    params = {
        'no_block': False,
        'name': unit,
        'enabled': None,
        'masked': None,
        'state': 'restarted',
        'daemon_reload': False,
        'daemon_reexec': True,
        'scope': 'system',
        'force': False,
        'check_mode': False,
        'supported_check_mode': True,
    }

    # Don't fail on missing unit file
    if isinstance(unit, str):
        params['name'] = unit
    else:
        params['name'] = unit.encode('utf-8')

    set_module_args(params)

    with pytest.raises(AssertionError) as excinfo:
        main()


# Generated at 2022-06-23 04:32:41.404766
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:50.319265
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:52.936147
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:33:02.610346
# Unit test for function is_running_service
def test_is_running_service():
    running_states = [
        {
            'ActiveState': 'active',
        },
        {
            'ActiveState': 'activating',
        },
    ]
    inactive_states = [
        {
            'ActiveState': 'inactive',
        },
        {
            'ActiveState': 'deactivating',
        },
        {
            'ActiveState': 'failed',
        },
    ]
    for state in running_states:
        assert is_running_service(state) == True

    for state in inactive_states:
        assert is_running_service(state) == False



# Generated at 2022-06-23 04:33:12.740908
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    def test(input_, output_):
        assert parse_systemctl_show(input_) == output_
    test(['Foobar=baz'], {'Foobar': 'baz'})
    test(['Foobar=baz', 'Bar=quux'], {'Foobar': 'baz', 'Bar': 'quux'})
    test(['Foobar=baz', 'Bar=quux', 'Axe=', 'Hammer'], {'Foobar': 'baz', 'Bar': 'quux', 'Axe': '', 'Hammer': ''})

# Generated at 2022-06-23 04:33:18.380443
# Unit test for function is_running_service
def test_is_running_service():
    test_cases = [
        ({'ActiceState': 'active'}, True),
        ({'ActiveState': 'activating'}, True),
        ({'ActiveState': 'inactive'}, False),
        ({'ActiveState': 'deactivating'}, False),
        ({'ActiveState': 'failed'}, False)
    ]
    for ts in test_cases:
        assert(is_running_service(ts[0]) == ts[1])



# Generated at 2022-06-23 04:33:26.217545
# Unit test for function is_running_service
def test_is_running_service():
    service_code = {
        'ActiveState': 'active'
    }
    assert is_running_service(service_code) is True
    service_code = {
        'ActiveState': 'activating'
    }
    assert is_running_service(service_code) is True
    service_code = {
        'ActiveState': 'deactivating'
    }
    assert is_running_service(service_code) is False


# Generated at 2022-06-23 04:33:31.638056
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:33:44.603060
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating')) is True
    assert is_deactivating_service(dict(ActiveState='active')) is False
    assert is_deactivating_service(dict(ActiveState='activating')) is False
    assert is_deactivating_service(dict(ActiveState='somethingelse')) is False
    assert is_deactivating_service(dict(ActiveState=False)) is False
    assert is_deactivating_service(dict(ActiveState=True)) is False
    assert is_deactivating_service(dict(ActiveState=None)) is False
    assert is_deactivating_service(dict(ActiveState=1)) is False
    assert is_deactivating_service(dict(ActiveState=0)) is False



# Generated at 2022-06-23 04:33:46.298407
# Unit test for function main
def test_main():
    print("Not yet implemented")
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:33:49.121185
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    get_status_mock = dict(ActiveState='deactivating')
    assert is_deactivating_service(get_status_mock)



# Generated at 2022-06-23 04:33:53.190297
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})



# Generated at 2022-06-23 04:34:02.850898
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'auto'}) is False
    assert is_running_service({'ActiveState': 'manual'}) is False


# Generated at 2022-06-23 04:34:08.009409
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('')
    assert not request_was_ignored('ignoring command to do something else')



# Generated at 2022-06-23 04:34:12.099322
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)
    service_status = {'ActiveState': 'not-relevant'}
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-23 04:34:17.819081
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request to reload service mariadb.service')
    assert request_was_ignored('Ignoring command, already starting.')
    assert not request_was_ignored('Loaded: loaded (/usr/lib/systemd/system/ip6tables.service; enabled)')



# Generated at 2022-06-23 04:34:31.353225
# Unit test for function main
def test_main():
    import ansible.constants as C

    SystemTimezone = None

    def __init__():
        # ansible.constants.DEFAULT_LOCALE = 'UTF-8'
        C.DEFAULT_LOCALE = 'UTF-8'

    def m_get_bin_path(self, arg1, arg2):
        if arg1 == 'systemctl':
            return '/bin/systemctl'
        else:
            return ''


# Generated at 2022-06-23 04:34:36.233049
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo = bar')
    assert not request_was_ignored('foo bar')



# Generated at 2022-06-23 04:34:43.174945
# Unit test for function is_running_service
def test_is_running_service():
    # Test the case when service is running:
    assert is_running_service({"ActiveState": "active"})

    # Test the case when service is not running:
    assert not is_running_service({"ActiveState": "deactivating"})



# Generated at 2022-06-23 04:34:52.990525
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(service_status={'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service(service_status={'ActiveState': 'active'}) is False
    assert is_deactivating_service(service_status={'ActiveState': 'activating'}) is False
    assert is_deactivating_service(service_status={'ActiveState': 'inactive'}) is False
    assert is_deactivating_service(service_status={'ActiveState': 'failed'}) is False



# Generated at 2022-06-23 04:34:58.181261
# Unit test for function is_running_service
def test_is_running_service():
    assert not is_running_service({'ActiveState': 'inactive'})
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'failed'})


# Generated at 2022-06-23 04:35:03.255536
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('something else')
    assert not request_was_ignored('Service has begun start-up.')



# Generated at 2022-06-23 04:35:08.293137
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'somethingelse'}) is False



# Generated at 2022-06-23 04:35:12.667226
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({"ActiveState": "inactive"})
    assert not is_deactivating_service({})
    assert is_deactivating_service({"ActiveState": "deactivating"})



# Generated at 2022-06-23 04:35:17.136621
# Unit test for function main

# Generated at 2022-06-23 04:35:27.091896
# Unit test for function is_running_service
def test_is_running_service():
    test_cases = [
        {'ActiveState': 'active', 'expected': True},
        {'ActiveState': 'activating', 'expected': True},
        {'ActiveState': 'active-dead', 'expected': False},
        {'ActiveState': 'inactive', 'expected': False},
        {'ActiveState': 'deactivating', 'expected': False},
        {'ActiveState': 'failed', 'expected': False},
    ]
    for case in test_cases:
        assert is_running_service(case) == case['expected']



# Generated at 2022-06-23 04:35:29.820632
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:35:40.115683
# Unit test for function main
def test_main():
    test_dict = dict(
      state="started",
      name="systemd",
      enabled=True,
      masked=False,
      daemon_reload=False,
      daemon_reexec=False,
      scope="system",
      no_block=False,
    )

    test_host = Systemd(dict(), test_dict)
    result = test_host.main()
    assert result['changed'] == False
    assert result['state'] == "started"
    assert result['enabled'] == True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:48.175166
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:51.648307
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as excinfo:
        main()
    assert excinfo.value.args[0]['changed']


# Generated at 2022-06-23 04:35:53.833436
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) == True



# Generated at 2022-06-23 04:35:58.318495
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:36:02.184970
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:36:06.878567
# Unit test for function main
def test_main():
    """
    Test function main
    :return:
    """
    module = get_module()
    print(module)
    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:19.454260
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    import os
    import sys
    import unittest

    if sys.version_info >= (3, 0):
        from unittest.mock import patch
    else:
        from mock import patch

    try:
        from ansible.module_utils.service import systemd
    except ImportError:
        sys.path.append(os.path.join(os.path.dirname(__file__), '../../../lib'))
        from ansible.module_utils.service import systemd

    with patch.object(ansible.module_utils.service.systemd.os, 'name') as mock_name:
        mock_name.return_value = 'posix'
        if sys.version_info >= (3, 0):
            from unittest.mock import Mock
        else:
            from mock import Mock
        m = Mock

# Generated at 2022-06-23 04:36:21.722104
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:36:26.332063
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('=') is False
    assert request_was_ignored('foo') is False



# Generated at 2022-06-23 04:36:30.522268
# Unit test for function is_running_service
def test_is_running_service():
    # successful test
    service_status = {'ActiveState': 'active'}
    assert is_running_service(service_status) == True
    # failed test
    service_status = {'ActiveState': 'unknown'}
    assert is_running_service(service_status) == False



# Generated at 2022-06-23 04:36:35.163715
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:38.126316
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:41.782149
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False



# Generated at 2022-06-23 04:36:44.343510
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'deactivating'}) == False


# Generated at 2022-06-23 04:36:50.635394
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    module = AnsibleModule(argument_spec={})
    assert module, module.fail_json.msg
    input = dict()
    input['ActiveState'] = 'deactivating'
    assert is_deactivating_service(input) == True
    input['ActiveState'] = 'deactivating2'
    assert is_deactivating_service(input) == False



# Generated at 2022-06-23 04:36:55.822112
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request; proceeding anyway')
    assert request_was_ignored('= not in out and ignoring command')
    assert request_was_ignored('')
    assert not request_was_ignored('test = hello')


# Generated at 2022-06-23 04:37:07.941982
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    data = '''
    ExecReload={ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
    ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
    '''
    lines = data.splitlines()
    result = parse_systemctl_show(lines)

# Generated at 2022-06-23 04:37:13.216245
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'failed'}) == False
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True



# Generated at 2022-06-23 04:37:23.119238
# Unit test for function is_running_service
def test_is_running_service():
    # Unit test passes if is_running_service() returns True when expected
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    # Unit test passes if is_running_service() returns False when expected
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'deactivating'}) == False
    # Unit test fails if is_running_service() returns unexpected result
    assert is_running_service({'ActiveState': 'notastate'}) == False



# Generated at 2022-06-23 04:37:29.000127
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('Unit test-foo.service ignoring command')
    assert not request_was_ignored('Loaded: loaded (/lib/systemd/system/test-foo.service; enabled)')



# Generated at 2022-06-23 04:37:37.703867
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('Ignoring request to reload unit systemd-user-sessions.service (via systemctl): Request pending.\n'))
    assert(request_was_ignored('Ignoring request to reload unit systemd-user-sessions.service (via systemctl): Request pending.'))
    assert(not request_was_ignored('Job systemd-user-sessions.service/start finished, result=done'))
    assert(not request_was_ignored('Job systemd-user-sessions.service/start finished, result=done\n'))


# Generated at 2022-06-23 04:37:47.971456
# Unit test for function request_was_ignored
def test_request_was_ignored():
    r = 'Job for httpd.service failed because the control process exited with error code.\nSee "systemctl status httpd' + \
        '.service" and "journalctl -xe" for details.\n'
    assert not request_was_ignored(r)

    r = 'mkdir: cannot create directory ‘/run/systemd/system/’: Permission denied\nJob for httpd.service failed becaus' + \
        'e the control process exited with error code.\nSee "systemctl status httpd.service" and "journalctl -xe" for deta' + \
        'ils.\n'
    assert not request_was_ignored(r)


# Generated at 2022-06-23 04:37:51.054553
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request.') is True
    assert request_was_ignored('Ignoring command.') is True
    assert request_was_ignored('hello = 1') is False



# Generated at 2022-06-23 04:38:04.199301
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(
        name=dict(type='str', required=True),
        state=dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped']),
        enabled=dict(type='bool'),
        force=dict(type='bool'),
        masked=dict(type='bool'),
        scope=dict(type='str', default='system', choices=['system', 'user', 'global']),
        no_block=dict(type='bool', default=False),
    ))

# Generated at 2022-06-23 04:38:15.791945
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:28.391918
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import systemd
    from ansible.module_utils.systemd import (
        daemon_reload,
        daemon_reexec,
        disable_unit,
        enable_unit,
        get_bin_path,
        is_active,
        is_chroot,
        is_enabled,
        match_glob,
        unmask_unit,
        mask_unit,
        start_unit,
        stop_unit,
        sysv_exists,
        sysv_is_enabled,
        reload_unit,
        restart_unit,
    )
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

# Generated at 2022-06-23 04:38:30.056208
# Unit test for function main
def test_main():
    assert main() == 2


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:36.670428
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request of suspend for unit anaconda.service since unit stop-sigterm.target is masked')
    assert not request_was_ignored('Job for auditd.service failed. See "systemctl status auditd.service" and "journalctl -xe" for details.')
    assert request_was_ignored('')
    assert not request_was_ignored('keep_alive_interval: %d', '100')



# Generated at 2022-06-23 04:38:43.926505
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'not-deactivating'}) is False



# Generated at 2022-06-23 04:38:50.047553
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {}
    service_status['ActiveState'] = "deactivating"
    assert is_deactivating_service(service_status)
    service_status['ActiveState'] = "active"
    assert not is_deactivating_service(service_status)
# End of unit test for function is_deactivating_service


# Generated at 2022-06-23 04:38:55.827487
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('--> Ignoring request to reload unit crond.service, as it has a Running job.\n')
    assert not request_was_ignored('ActiveState=active\n')



# Generated at 2022-06-23 04:39:08.417503
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test a single-line value
    out = [
        "Id=foo.service",
    ]
    assert parse_systemctl_show(out) == {'Id': 'foo.service'}
    # Test a single-line value that starts with {
    out = [
        "Id={foo",
    ]
    assert parse_systemctl_show(out) == {'Id': '{foo'}
    # Test a multi-line value
    out = [
        "ExecStart={",
        "    /bin/true",
        "}",
    ]
    assert parse_systemctl_show(out) == {'ExecStart': '/bin/true'}
    # Test a multi-line value that doesn't start with {

# Generated at 2022-06-23 04:39:09.820853
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:11.898541
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert(is_deactivating_service(service_status) == True)



# Generated at 2022-06-23 04:39:19.243270
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_input = '''x=1
y=2
'''
    assert parse_systemctl_show(test_input.split('\n')) == {'x': '1', 'y': '2'}

    test_input = '''x=1
y=2
z=3
'''
    assert parse_systemctl_show(test_input.split('\n')) == {'x': '1', 'y': '2', 'z': '3'}

    test_input = '''x=1
y=2
ExecStart=a
b
c
'''
    assert parse_systemctl_show(test_input.split('\n')) == {'x': '1', 'y': '2', 'ExecStart': 'a\nb\nc'}


# Generated at 2022-06-23 04:39:22.837106
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating'))
    assert not is_deactivating_service(dict(ActiveState='active'))



# Generated at 2022-06-23 04:39:25.977492
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request or something else')
    assert not request_was_ignored('=' * 10)
    assert not request_was_ignored('something else')



# Generated at 2022-06-23 04:39:32.608885
# Unit test for function is_running_service
def test_is_running_service():
    running = dict(
        ActiveState='active',
    )
    assert is_running_service(running)
    activating = dict(
        ActiveState='activating',
    )
    assert is_running_service(activating)
    not_running = dict(
        ActiveState='inactive',
    )
    assert not is_running_service(not_running)
    no_key = dict()
    assert not is_running_service(no_key)



# Generated at 2022-06-23 04:39:45.079405
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("No jobs running for unit user-10.slice.") == True
    assert request_was_ignored("No jobs queued for unit user-10.slice.") == True
    assert request_was_ignored("Loaded: loaded (/etc/systemd/system/user-10.slice; enabled; vendor preset: enabled)") == True
    assert request_was_ignored("Active: active (running) since Wed 2018-06-27 16:53:44 EDT; 7min ago") == True
    assert request_was_ignored("Loaded: loaded (/usr/lib/systemd/system/initrd-fs.target; enabled; vendor preset: disabled)") == True
    assert request_was_ignored("Active: inactive (dead)") == True