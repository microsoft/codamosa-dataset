

# Generated at 2022-06-23 04:29:37.845310
# Unit test for function main
def test_main():
    main()


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:29:40.015193
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    result = is_deactivating_service(dict(ActiveState='deactivating'))
    assert result == True



# Generated at 2022-06-23 04:29:44.391217
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status_deactivating = {'ActiveState': 'deactivating'}
    service_status_active = {'ActiveState': 'active'}
    assert is_deactivating_service(service_status_deactivating) is True
    assert is_deactivating_service(service_status_active) is False



# Generated at 2022-06-23 04:29:51.112399
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    # pylint: disable=maybe-no-member
    # pylint: disable=protected-access
    # pylint: disable=import-error

    from ansible_collections.notmintest.not_a_real_collection.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.modules.utils import AnsibleFailJson

    # Create a fake argument spec
    module_args = dict()
    module_args['name'] = 'nginx'
    module_args['enabled'] = True
    module_args['daemon_reload'] = False
    module_args['daemon_reexec'] = False

    # Create a fake module

# Generated at 2022-06-23 04:30:03.892760
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:10.487197
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Description=Test Service',
        'ExecStart=/usr/bin/test',
        'ExecStart=/usr/bin/test2',
    ]
    v = parse_systemctl_show(lines)
    assert v['Description'] == 'Test Service'
    assert v['ExecStart'] == '/usr/bin/test\n/usr/bin/test2'


# Generated at 2022-06-23 04:30:17.462105
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(required=True, type='str'),
            state=dict(default=None, choices=['reloaded', 'restarted', 'started', 'stopped']),
            enabled=dict(type='bool'),
            force=dict(type='bool', default=False),
            masked=dict(type='bool'),
            daemon_reload=dict(type='bool', default=False),
            scope=dict(default='system', choices=['system', 'user', 'global']),
            no_block=dict(type='bool', default=False),
        ),
        supports_check_mode=True,
        required_one_of=[['state', 'enabled', 'masked']],
    )

    import tempfile

    tempdir = tempfile.mkdtemp()



# Generated at 2022-06-23 04:30:22.865457
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test a simple single-line value
    lines = ['ActiveState=active']
    assert parse_systemctl_show(lines) == {'ActiveState': 'active'}
    lines = ['Description=Test service']
    assert parse_systemctl_show(lines) == {'Description': 'Test service'}
    # Test a single-line value that contains '='
    lines = ['Description=A service with multiple =']
    assert parse_systemctl_show(lines) == {'Description': 'A service with multiple ='}
    # Test a single-line value that contains '=' and starts with {}
    lines = ['Description={A service with multiple =}']
    assert parse_systemctl_show(lines) == {'Description': '{A service with multiple =}'}
    # Test a multi-line value

# Generated at 2022-06-23 04:30:28.897768
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:30:30.942507
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState':'deactivating'})



# Generated at 2022-06-23 04:30:34.300589
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'uninstalled'})
    assert not is_running_service({'ActiveState': 'failed'})
    assert not is_running_service({'ActiveState': 'not-found'})
    assert not is_running_service({})


# Generated at 2022-06-23 04:30:35.587045
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_running_service({'ActiveState': 'deactivating'})


# Generated at 2022-06-23 04:30:36.872185
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'active'})



# Generated at 2022-06-23 04:30:47.621901
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = '''Id=auditd.service
Names=auditd.service
Requires=basic.target
Wants=system.slice
Conflicts=shutdown.target
Before=shutdown.target
After=system.slice
WantedBy=multi-user.target
UnitFileState=enabled
UnitFilePreset=enabled
Type=idle
Documentation=man:auditd(8)
Description=Security Auditing Service
LoadState=loaded
ActiveState=active
SubState=running
FragmentPath=/usr/lib/systemd/system/auditd.service
SourcePath=/usr/lib/systemd/system/auditd.service
DropInPaths=/etc/systemd/system/auditd.service.d
              /usr/lib/systemd/system/auditd.service.d
'''.splitlines()


# Generated at 2022-06-23 04:30:53.980675
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:58.612792
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command foo')
    assert not request_was_ignored('foo = bar')



# Generated at 2022-06-23 04:31:08.675682
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for pgd.service failed because the control process exited with error code.\nSee "systemctl status pgd.service" and "journalctl -xe" for details.\n'  # NOQA
                               'Unit pgd.service entered failed state.\n'
                               'Unit pgd.service entered failed state.\n')
    assert not request_was_ignored('Failed to start pgd.service: Unit pgd.service not found.\n'  # NOQA
                                   'Unit pgd.service entered failed state.\n'
                                   'Unit pgd.service entered failed state.\n')



# Generated at 2022-06-23 04:31:20.002981
# Unit test for function main
def test_main():
    # read return values from systemctl commands and create as fake input
    state = {
        'systemctl_is_active': [1, "Active: inactive (dead)", ""],
        'systemctl_show': [0, """\
Id=getty.target
Names=getty.target
Requires=system-getty.slice
Wants=system-getty.slice
Conflicts=shutdown.target
Before=shutdown.target
After=system-getty.slice
Documentation=man:systemd.special(7)
Description=Login Prompts
DefaultDependencies=yes
RequiresMountsFor=/etc/nologin
""", ""],
        'systemctl_list_unit_files': [0, 'getty.target static', ''],
        'systemctl_is_enabled': [0, 'enabled', ''],
    }


# Generated at 2022-06-23 04:31:23.299148
# Unit test for function main
def test_main():
    mock = MagicMock(return_value= (0, "", ""))
    with patch.object(module, 'run_command', mock):
        with patch.object(module, 'get_bin_path', mock):
            with patch.object(module, 'warn', mock):
                main()

# Generated at 2022-06-23 04:31:32.017553
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("Dec 18 16:31:17 testhost systemd[1]: Connection timed out. Ignoring request.")
    assert request_was_ignored("Dec 18 16:31:17 testhost systemd[1]: Connection timed out.\nIgnoring request.")
    assert request_was_ignored("Dec 18 16:31:17 testhost systemd[1]: Connection timed out. Ignoring command.")
    assert not request_was_ignored("Created symlink /etc/systemd/system/multi-user.target -> /lib/systemd/system/graphical.target.")
    assert not request_was_ignored("Removed symlink /etc/systemd/system/multi-user.target.")
    assert not request_was_ignored("Unit crond.service entered failed state.")



# Generated at 2022-06-23 04:31:34.409561
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import main
    assert main() is None

# Generated at 2022-06-23 04:31:43.226105
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False



# Generated at 2022-06-23 04:31:47.005643
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    for state in set(['inactive', 'failed', 'activating', 'active', 'reloading', 'unknown']):
        assert is_deactivating_service({'ActiveState': state}) is False



# Generated at 2022-06-23 04:31:59.009651
# Unit test for function is_deactivating_service

# Generated at 2022-06-23 04:32:04.410757
# Unit test for function main
def test_main():
    args = dict(
        name=None,
        state='started',
        enabled=None,
        masked=False,
        force=False,
        daemon_reload=False,
        daemon_reexec=False,
        scope='system',
        no_block=False,
    )
    testmodule = AnsibleModule( argument_spec=args )
    rc, out, err = testmodule.run_command("true")
    assert rc == 0
    rc, out, err = testmodule.run_command("false")
    assert rc == 1


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:11.848746
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # Check strings which are NOT ignored
    assert not request_was_ignored('some=thing something')
    assert not request_was_ignored('some string with ignoring some other string')
    # Check strings which are ignored
    assert request_was_ignored('ignoring the request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring the command')
    assert request_was_ignored('ignoring command with some other string')



# Generated at 2022-06-23 04:32:23.272085
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:26.269623
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) is True
    service_status['ActiveState'] = 'active'
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-23 04:32:40.504953
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    data = '''
Id=auditd.service
Description=Security Auditing Service
Documentation=man:auditd(8) man:auditctl(8) man:auditd.conf(5)
DefaultDependencies=no
Wants=basic.target
After=basic.target
Before=shutdown.target
IgnoreOnIsolate=yes
Conflicts=shutdown.target
Conflicts=umount.target
Conflicts=halt.target
Conflicts=kexec.target
StartLimitInterval=3min
StartLimitBurst=5
ConditionCapability=CAP_AUDIT_CONTROL

AllowIsolate=no
AllowIsolate=no
'''
    actual = parse_systemctl_show(data.split('\n'))

# Generated at 2022-06-23 04:32:45.215438
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('ignoring request not')
    assert not request_was_ignored('ignoring command not')



# Generated at 2022-06-23 04:32:51.972850
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('some random output that does not contain "="') == True
    assert request_was_ignored('systemd-resolve.service: ignoring request, unit is masked.') == True
    assert request_was_ignored('Unknown operation "hows my driving"') == True
    assert request_was_ignored('Failed to start foo.service: Unit foo.service failed to load: No such file or directory.See system logs and "systemctl status foo.service" for details.') == False


# Generated at 2022-06-23 04:33:01.430549
# Unit test for function main

# Generated at 2022-06-23 04:33:07.216159
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for httpd.service failed. See "systemctl status httpd.service" and "journalctl -xe" for details.')
    assert request_was_ignored('Job for httpd.service failed because the control process exited with error code. See "systemctl status httpd.service" and "journalctl -xe" for details.')
    assert request_was_ignored('Failed to get properties: Unit httpd.service not loaded.')
    assert request_was_ignored('Failed to get properties: No such file or directory')
    assert request_was_ignored('Failed to execute operation: No such file or directory')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert not request_was_ignored('ActiveState = inactive')


# Generated at 2022-06-23 04:33:16.161336
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:19.805357
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating' }
    assert is_deactivating_service(service_status) is True
    service_status = {'ActiveState': 'foo' }
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-23 04:33:31.445456
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_data = [
        "foo=bar",
        "baz=qux",
        "spam=eggs",
        "wibble=wobble",
        "multi=line",
        "    value",
        "    {",
        "        nested",
        "        value",
        "    }",
        "another=single",
        "    line",
        "    {value}",
        "single={value}",
    ]

# Generated at 2022-06-23 04:33:34.318239
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert(request_was_ignored('ignoring request'))
    assert(request_was_ignored('ignoring command'))
    assert(request_was_ignored('ignoring request to reload'))
    assert(request_was_ignored('The service did not respond to the start request.'))



# Generated at 2022-06-23 04:33:48.865699
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:51.944630
# Unit test for function main
def test_main():
    for i in [0,3]:
        os.environ['SYSTEMD_OFFLINE'] = "1"
        assert os.environ['SYSTEMD_OFFLINE'] == "1"
        #assert main() == True

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:05.173172
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:17.301359
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import json
    import textwrap

# Generated at 2022-06-23 04:34:23.132242
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Failed to connect to bus: No such file or directory')
    assert not request_was_ignored('=0123456789abcdef')
    assert not request_was_ignored('Failed to connect to bus: No such file or directory, ignoring command')



# Generated at 2022-06-23 04:34:36.765879
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:34:43.784416
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'foo'})


# Generated at 2022-06-23 04:34:56.703812
# Unit test for function main
def test_main():
    """ test main """
    # pylint: disable=redefined-outer-name, unused-variable
    # Arrange
    import sys
    import json

    # state
    class ContextFilter(logging.Filter):
        """ logging filter """
        def filter(self, record):
            """ filter """
            record.CURRENT_TEST = CURRENT_TEST
            return True

    LOGGER = logging.getLogger('ansible.module.test_systemd')
    LOGGER.setLevel(logging.DEBUG)
    STDHANDLER = logging.StreamHandler(sys.stdout)
    STDHANDLER.setLevel(logging.DEBUG)
    STDHANDLER.addFilter(ContextFilter())
    FORMATTER = logging.Formatter('%(asctime)s %(name)s %(message)s')

# Generated at 2022-06-23 04:34:59.112090
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {}
    service_status['ActiveState'] = "deactivating"
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:35:12.668336
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = open("test/unit/module_utils/test_systemd.txt", "r").readlines()
    parsed = parse_systemctl_show(lines)

# Generated at 2022-06-23 04:35:19.463070
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({"ActiveState": 'inactive'}) is False
    assert is_running_service({"ActiveState": 'active'}) is True
    assert is_running_service({"ActiveState": 'activating'}) is True
    assert is_running_service({"ActiveState": 'unknown'}) is False
    assert is_running_service(None) is False



# Generated at 2022-06-23 04:35:20.153655
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:35:31.992104
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:37.521846
# Unit test for function request_was_ignored
def test_request_was_ignored():
    _test = "ignoring command"
    assert request_was_ignored(_test)
    _test = "= ignoring request"
    assert request_was_ignored(_test)
    _test = "nothing"
    assert not request_was_ignored(_test)



# Generated at 2022-06-23 04:35:44.545813
# Unit test for function is_running_service
def test_is_running_service():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(
                choices=['started', 'stopped'],
                required=False
            ),
            name=dict(
                type='str'
            )
        )
    )

    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:35:53.440631
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_name = 'foo.service'
    service_status = {
        'ActiveEnterTimestampMonotonic': '0',
        'ActiveState': 'deactivating',
        'ConditionResult': 'no',
        'LoadState': 'loaded',
        'MainPID': '0',
        'Result': 'success',
        'SubState': 'dead',
        'UnitFileState': 'enabled',
    }
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:35:57.934425
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('A=B ignoring request')
    assert not request_was_ignored('A=B')



# Generated at 2022-06-23 04:36:05.394499
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-23 04:36:11.858265
# Unit test for function main
def test_main():
    # read return of main for test
    with open("test/unit/modules/systemd/return.json") as fl:
        data = json.load(fl)

    # check data types
    assert type(data) is dict
    assert type(data['status']) is dict


# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:36:14.214390
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignore ignore ignore this request")
    assert not request_was_ignored("The operation has finished successfully")
    assert not request_was_ignored("a = b")



# Generated at 2022-06-23 04:36:22.887151
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    in_list = ["ExecReload=/bin/kill -HUP $MAINPID",
               "ExecReload={ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }",
               "ExecStart=/usr/sbin/crond -n $CRONDARGS",
               "ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }",
              ]

# Generated at 2022-06-23 04:36:33.466219
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Simulate 'systemctl show' output containing a multi-line value for ExecStart=
    multi_line = [
        'ExecStart={',
        '  path=/bin/sleep ; argv[]=/bin/sleep 100 ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0',
        '}',
    ]
    assert parse_systemctl_show(multi_line)['ExecStart'] == '\n'.join(multi_line[1:])

    # Simulate 'systemctl show' output containing a single-line value for ExecStart=

# Generated at 2022-06-23 04:36:40.392575
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = '''Description=Foo bar (baz)
BindsTo=foo.service bar.service
JobTimeoutUSec=99999999999
'''.split('\n')
    data = parse_systemctl_show(lines)
    assert data['Description'] == 'Foo bar (baz)'
    assert data['BindsTo'] == 'foo.service bar.service'
    assert data['JobTimeoutUSec'] == '99999999999'

    lines = '''Description=Foo {bar
(baz)
}
BindsTo=foo.service bar.service
JobTimeoutUSec=99999999999
'''.split('\n')
    data = parse_systemctl_show(lines)
    assert data['Description'] == 'Foo {bar\n(baz)\n}'

# Generated at 2022-06-23 04:36:47.188752
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:54.193720
# Unit test for function is_running_service
def test_is_running_service():
    stopped = {'ActiveState': 'inactive'}
    started = {'ActiveState': 'active'}
    active = {'ActiveState': 'activating'}
    assert not is_running_service(stopped)
    assert is_running_service(started)
    assert is_running_service(active)



# Generated at 2022-06-23 04:37:02.448764
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert request_was_ignored("ignoring command ignoring request")
    assert not request_was_ignored("= ignored request")
    assert not request_was_ignored("= ignored command")
    assert not request_was_ignored("=ignoring request")
    assert not request_was_ignored("=ignoring command")



# Generated at 2022-06-23 04:37:07.866987
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('srvc:\n-systemctl-'), 'Failed to detect request was ignored'  # NOQA
    assert not request_was_ignored('A start job is running for srvc'), 'False positive for request being ignored'  # NOQA



# Generated at 2022-06-23 04:37:14.540428
# Unit test for function request_was_ignored
def test_request_was_ignored():
    _in = [
        'ignoring request',
        '= ignoring command',
        'ignoring command and answer',
        '= ignoring another command',
        'ignoring the last command',
    ]
    _out = [
        '= ignoring the last command',
    ]
    for out in _in:
        assert request_was_ignored(out)
    for out in _out:
        assert not request_was_ignored(out)



# Generated at 2022-06-23 04:37:20.619518
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request: user systemd request.')
    assert request_was_ignored('Ignoring command: user systemd request.')
    assert not request_was_ignored('= not in this output')
    assert not request_was_ignored('And this output does not contain "ignoring"')



# Generated at 2022-06-23 04:37:22.992382
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {"ActiveState": "deactivating"}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:37:36.433829
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Job for httpd.service failed because the control process exited with error code.\n'
                               'See "systemctl status httpd.service" and "journalctl -xe" for details.\n') is False
    assert request_was_ignored('Failed to execute operation: Too many levels of symbolic links\n') is False

# Generated at 2022-06-23 04:37:39.802103
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {
        'ActiveState': 'deactivating'
    }
    assert is_deactivating_service(service_status) is True  # NOQA

# Generated at 2022-06-23 04:37:42.519678
# Unit test for function is_running_service
def test_is_running_service():
    status = dict(
        ActiveState='active',
        SubState='running',
    )
    assert is_running_service(status)



# Generated at 2022-06-23 04:37:48.455670
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'active'}) is False
    # It is most likely a bug to have a service in any state that should
    # not occur in systemd, but it is better we preserve the old behavior
    # of not erroring out on unexpected states, and instead assume the service
    # is not deactivating.
    assert is_deactivating_service({'ActiveState': 'foo'}) is False


# Generated at 2022-06-23 04:37:51.055095
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('asgn=foo ignoring command') is False



# Generated at 2022-06-23 04:37:56.149969
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:38:00.777515
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({"ActiveState": "inactive"}) is False
    assert is_running_service({"ActiveState": "active"}) is True
    assert is_running_service({"ActiveState": "activating"}) is True



# Generated at 2022-06-23 04:38:05.810606
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_running_service(
        {'ActiveState': 'inactive', 'SubState': 'dead'}
    )
    assert is_deactivating_service(
        {'ActiveState': 'deactivating', 'SubState': 'dead'}
    )
    assert not is_deactivating_service(
        {'ActiveState': 'inactive', 'SubState': 'dead'}
    )



# Generated at 2022-06-23 04:38:10.107342
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'any_other'}) is False



# Generated at 2022-06-23 04:38:20.265772
# Unit test for function main
def test_main():
    unit = "cron.service"
    systemctl = "systemctl"

# Generated at 2022-06-23 04:38:25.300542
# Unit test for function main
def test_main():
    result = main()
    assert result == dict(
        name=unit,
        changed=False,
        status=dict(),
    )

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:32.169426
# Unit test for function is_running_service
def test_is_running_service():
    for state in ['active', 'activating']:
        assert is_running_service({'ActiveState': state})
    for state in ['inactive', 'deactivating', 'failed', 'failed-start', 'failed-restart', 'failed-start-post', 'failed-mount', 'failed-stop', 'failed-stop-post']:
        assert not is_running_service({'ActiveState': state})



# Generated at 2022-06-23 04:38:34.828594
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('requested operation is already queued')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('some other message')



# Generated at 2022-06-23 04:38:51.171139
# Unit test for function main
def test_main():
    # Test domain has been registered
    from ansible.module_utils.basic import AnsibleModule

    class FakeOut(object):
        def __init__(self):
            pass

        def write(obj, string):
            pass

    sys.stdout = FakeOut()
    sys.stderr = FakeOut()

    # Mock for AnsibleModule.debug()
    import ansible.module_utils.basic

    ansible.module_utils.basic.debug = lambda obj, msg: None


# Generated at 2022-06-23 04:38:54.936138
# Unit test for function main
def test_main():
    from . import sysvinit
    ret = main()
    assert ret["name"] == 'test'
    assert ret["changed"] == True
    assert ret["enabled"] == False



# Generated at 2022-06-23 04:39:00.094075
# Unit test for function is_running_service
def test_is_running_service():
    good_outputs = set([
        'ActiveState=active',
        'ActiveState=activating',
        'ActiveState=active\nSubState=running'
    ])
    bad_output = 'ActiveState=inactive'

    service_status = dict()
    service_status['ActiveState'] = 'active'
    assert is_running_service(service_status)

    service_status['ActiveState'] = 'activating\nSubState=running'
    assert is_running_service(service_status)

    service_status['ActiveState'] = 'inactive'
    assert not is_running_service(service_status)

    service_status['ActiveState'] = 'activating'
    service_status['SubState'] = 'running'
    assert is_running_service(service_status)


# Generated at 2022-06-23 04:39:01.762617
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:39:03.974169
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:39:06.031715
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('= ignoring command') is False



# Generated at 2022-06-23 04:39:15.355207
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert(parse_systemctl_show(['X=foo']) == {'X': 'foo'})
    assert(parse_systemctl_show(['X=foo', 'Y=bar', 'Z=baz']) == {'X': 'foo', 'Y': 'bar', 'Z': 'baz'})
    assert(parse_systemctl_show(['X=foo', 'Y=', 'Z=baz']) == {'X': 'foo', 'Y': '', 'Z': 'baz'})
    assert(parse_systemctl_show(['X=foo', 'Y=']) == {'X': 'foo', 'Y': ''})
    assert(parse_systemctl_show(['X=foo', 'Y', 'Z=baz']) == {'X': 'foo', 'Z': 'baz'})


# Generated at 2022-06-23 04:39:23.328628
# Unit test for function main
def test_main():
    # pylint: disable=unused-argument,subprocess-popen-preexec-fn,subprocess-popen-preexec-fn
    # Mock module input parameters
    mock_params = {
        'name': 'nfs.service',
        'state': 'stopped',
        'enabled': None,
        'masked': None,
        'daemon_reload': None,
        'daemon_reexec': None,
        'scope': 'system',
        'no_block': False,
    }

# Generated at 2022-06-23 04:39:27.791305
# Unit test for function is_running_service
def test_is_running_service():
    assert(is_running_service({'ActiveState': 'active'}))
    assert(is_running_service({'ActiveState': 'activating'}))
    assert(not is_running_service({'ActiveState': 'inactive'}))



# Generated at 2022-06-23 04:39:36.698730
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'deactivating'}) == False
    assert is_running_service({'ActiveState': 'failed'}) == False
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'not-found'}) == False
