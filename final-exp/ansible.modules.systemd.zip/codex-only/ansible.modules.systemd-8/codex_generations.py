

# Generated at 2022-06-23 04:29:47.236794
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    parsed = parse_systemctl_show('''Description=Command Scheduler
AssertPathExists=!/etc/audit/audit.rules
AssertPathExists=!/etc/audit/auditd.conf
AssertPathExists=!/etc/audit/auditd.conf.d
AssertPathExists=!/etc/audit/audit.rules.d
AssertPathExists=!/etc/audit/rules.d
'''.split('\n'))
    assert parsed['Description'] == 'Command Scheduler'

# Generated at 2022-06-23 04:29:53.632305
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("foo ignoring command")
    assert request_was_ignored("foo ignoring request")
    assert request_was_ignored("foo again ignoring request")
    assert not request_was_ignored("foo completed")
    assert not request_was_ignored("foo=bar")



# Generated at 2022-06-23 04:29:58.851282
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('not ignoring request')
    assert not request_was_ignored('not ignoring request=foo')
    assert not request_was_ignored('')



# Generated at 2022-06-23 04:30:03.362525
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(['ignoring request'])
    assert not request_was_ignored(['ActiveState=inactive'])
    assert request_was_ignored(['ignoring command'])
    assert not request_was_ignored(['ActiveState=inactive'])



# Generated at 2022-06-23 04:30:12.472989
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_input = '''
ActiveEnterTimestampMonotonic=555
ActiveExitTimestampMonotonic=0
ActiveState=active
Description=Example service
ExecStart=/usr/bin/example_service
ExecStart={ path=/usr/bin/example_service ; argv[]=/usr/bin/example_service ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
ExecStop=
ExecStopPost={ path=/usr/bin/kill ; argv[]=/usr/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
Foo=bar'''

# Generated at 2022-06-23 04:30:17.067493
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('''Many lines of boring output
          some more output
          ''') is False
    assert request_was_ignored('''Job for nginx.service failed. See "systemctl status nginx.service" and "journalctl -xe" for details.
          Job for nginx.service failed because the control process exited with error code. See "systemctl status nginx.service" and "journalctl -xe" for details.
          ''') is False

# Generated at 2022-06-23 04:30:30.942683
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    input = '''Description={
        Service for foo.
        }
        ExecStart={
            /bin/bash -c "echo 1"
        }
        ExecReload=
        {
        /bin/bash -c "echo 2"
        }
        OtherKey=OtherValue
        OtherMultiKey={
        OtherMultiValue. Line 1
        OtherMultiValue. Line 2
        }'''.split('\n')
    expected = {
        'Description': 'Service for foo.',
        'ExecStart': '/bin/bash -c "echo 1"',
        'ExecReload': '/bin/bash -c "echo 2"',
        'OtherKey': 'OtherValue',
        'OtherMultiKey': 'OtherMultiValue. Line 1\nOtherMultiValue. Line 2',
    }

# Generated at 2022-06-23 04:30:35.671967
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})
    assert not is_running_service({'ActiveState': 'failed'})


# Generated at 2022-06-23 04:30:46.463080
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    description = '''
Description={ path=/usr/local/bin/application ; argv[]=/bin/sh -c sh -c 'set -e
         exec some-command arg1 arg2' ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
'''
    execstart = '''
ExecStart={ path=/usr/local/bin/application ; argv[]=/bin/sh -c sh -c 'set -e
         exec some-command arg1 arg2' ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
'''

# Generated at 2022-06-23 04:30:59.184709
# Unit test for function main
def test_main():
  from ansible.module_utils.basic import AnsibleModule
  from ansible.module_utils._text import to_bytes
  AnsibleModule.run_command = lambda *args, **kwargs: (0, b'state', b'')
  assert main() == {
    'changed': True,
    'state': 'started',
    'name': 'test-service',
    'status': {
      'ActiveState': 'running',
      'LoadState': 'loaded',
      'UnitFileState': 'enabled'
    }
  }


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:08.684744
# Unit test for function request_was_ignored
def test_request_was_ignored():
    ignored_message = '''
    Running in chroot, ignoring request.
    Inside a chroot and ignoring command.
    Running in chroot, ignoring request.
    '''
    assert all(request_was_ignored(line) for line in ignored_message.split('\n'))
    non_ignored_message = '''
    Running in chroot, ignoring request.
    Running in chroot, ignoring request.
    The unit files have no installation config
    '''
    assert not any(request_was_ignored(line) for line in non_ignored_message.split('\n'))



# Generated at 2022-06-23 04:31:14.442776
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert is_deactivating_service({'ActiveState': 'whatever', 'SubState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'deactivating', 'SubState': 'deactivating'})



# Generated at 2022-06-23 04:31:26.568403
# Unit test for function is_running_service
def test_is_running_service():
    '''Test the is_running_service function'''
    active_state = {}
    active_state['ActiveState'] = 'active'
    inactive_state = {}
    inactive_state['ActiveState'] = 'inactive'
    activating_state = {}
    activating_state['ActiveState'] = 'activating'
    inactive_state = {}
    inactive_state['ActiveState'] = 'inactive'
    failed_state = {}
    failed_state['ActiveState'] = 'failed'

    assert(is_running_service(active_state) == True)
    assert(is_running_service(activating_state) == True)
    assert(is_running_service(inactive_state) == False)
    assert(is_running_service(failed_state) == False)


# Generated at 2022-06-23 04:31:40.418106
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-23 04:31:41.457530
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:43.784398
# Unit test for function main
def test_main():
    # This function is too messy to test. We should break it up a bit.
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:52.125871
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:00.040442
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': u'deactivating'}
    assert is_deactivating_service(service_status)
    service_status = {'ActiveState': u'active'}
    assert not is_deactivating_service(service_status)
    service_status = {'ActiveState': u'active (exited)'}
    assert not is_deactivating_service(service_status)
    service_status = {'ActiveState': u'ActiveState'}
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-23 04:32:06.274089
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert not is_deactivating_service({'ActiveState': 'otherstate'})



# Generated at 2022-06-23 04:32:11.460629
# Unit test for function main
def test_main():
    def test_exceptions(e):
        assert e.args[0] == 'Error loading unit file \'unit\': No such file or directory'
    with pytest.raises(AnsibleFailJson, match=test_exceptions):
        main()

# import module snippets
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:32:16.937543
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:32:29.401771
# Unit test for function main
def test_main():
    global module

# Generated at 2022-06-23 04:32:37.269753
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request')
    assert request_was_ignored('some garbage ignoring garbage ignoring garbage ignoring garbage ignoring garbage')
    assert request_was_ignored('some garbage ignoring garbage ignoring garbage ignoring command garbage')
    assert not request_was_ignored('some garbage ignoring garbage ignoring garbage ignoring garbage ignoring garbage = blah blah blah')


# Generate a user-friendly message from a systemd status output

# Generated at 2022-06-23 04:32:38.414461
# Unit test for function main
def test_main():
    print("Unit test for main")


# Generated at 2022-06-23 04:32:43.095156
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:32:47.380216
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) == True
    assert is_running_service({'ActiveState': 'activating'}) == True
    assert is_running_service({'ActiveState': 'inactive'}) == False
    assert is_running_service({'ActiveState': 'deactivating'}) == False



# Generated at 2022-06-23 04:32:55.607295
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring request\n')
    assert not request_was_ignored('= 1 2 3')
    assert not request_was_ignored('= stdout')
    assert not request_was_ignored('\nignoring command')
    assert not request_was_ignored('=stderr')
    assert not request_was_ignored('= status 1')
    assert not request_was_ignored('= status 0')



# Generated at 2022-06-23 04:33:08.210938
# Unit test for function main
def test_main():
    from ansible.module_utils.six import StringIO
    import ansible.module_utils.basic

    class CustomModule(AnsibleModule):
        def __init__(self, args, **kwargs):
            super(CustomModule, self).__init__(args, **kwargs)
            self.run_command_checked = False

        def run_command(self, cmd, check_rc=True):
            self.run_command_checked = check_rc
            if cmd.startswith('systemctl show'):
                return 0, '', ''
            return 0, '', ''


# Generated at 2022-06-23 04:33:17.921142
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({}) is False
    assert is_running_service({'ActiveState': 'running'}) is False
    assert is_running_service({'ActiveState': 'stopped'}) is False



# Generated at 2022-06-23 04:33:21.906714
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = dict()
    service_status['ActiveState'] = 'deactivating'
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:33:32.614134
# Unit test for function main

# Generated at 2022-06-23 04:33:47.134074
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:33:49.319074
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:34:02.265610
# Unit test for function main
def test_main():
    import json
    import tempfile
    import shutil
    import os
    import random
    import string

    random_string = lambda: ''.join([random.choice(string.ascii_letters) for x in range(10)])


# Generated at 2022-06-23 04:34:05.877251
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    res = is_deactivating_service(service_status)
    assert res == True

# Generated at 2022-06-23 04:34:11.203040
# Unit test for function main
def test_main():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    m = MagicMock(return_value=(0, '', ''))
    with patch.dict(systemd.__salt__, {'cmd.retcode': m}):
        systemd.main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:34:24.771961
# Unit test for function main
def test_main():
    test_systemd_chroot = '/var/lib/mock/fedora-21-x86_64'
    with pkg_resources.resource_stream(__name__, "test-host.service") as test_host_service:
        with tempfile.NamedTemporaryFile('w') as test_host_service_file:
            test_host_service_file.write(test_host_service.read())
            test_host_service_file.flush()

            shutil.copy2(test_host_service_file.name, os.path.join(test_systemd_chroot, 'etc/systemd/system/test-host.service'))

            # Test state=started
            args = dict(
                name='test-host',
                state='started',
                no_block=True
            )


# Generated at 2022-06-23 04:34:37.853026
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Single-line service
    lines = ['Id=crond.service',
             'Names=crond.service',
             'Description=Command Scheduler',
             'LoadState=loaded',
             'ActiveState=active']
    assert parse_systemctl_show(lines) == {
        'Id': 'crond.service',
        'Names': 'crond.service',
        'Description': 'Command Scheduler',
        'LoadState': 'loaded',
        'ActiveState': 'active',
    }

    # Multi-line service

# Generated at 2022-06-23 04:34:50.638056
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show([
        'Description=Foobar',
        'ExecStart=/bin/foobar',
        'ExecStart=/bin/barfoo {',
        '  ExecStartPost=/bin/baz',
        '}',
        'ExecStart=/bin/foobaz {',
        '  ExecStartPost=/bin/baz',
    ]) == {
        'Description': 'Foobar',
        'ExecStart': '/bin/foobar',
        'ExecStart=/bin/barfoo': 'ExecStartPost=/bin/baz',
        'ExecStart=/bin/foobaz': 'ExecStartPost=/bin/baz',
    }



# Generated at 2022-06-23 04:34:54.789450
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:34:58.883802
# Unit test for function is_running_service
def test_is_running_service():
    if not isinstance(is_running_service({}), bool):
        raise AssertionError('is_running_service() should return a boolean if supplied with dictionary')


# Generated at 2022-06-23 04:35:03.270095
# Unit test for function is_running_service
def test_is_running_service():
    """
    Test

    >>> test_running = dict(
    ...     ActiveState='active',
    ...     ExecMainStatus=1)
    >>> is_running_service(test_running)
    True
    >>> test_dying = dict(
    ...     ActiveState='exited',
    ...     ExecMainStatus=2)
    >>> is_running_service(test_dying)
    True
    >>> is_running_service(dict(
    ...     ActiveState='inactive',
    ...     ExecMainStatus=2))
    False
    """
    pass



# Generated at 2022-06-23 04:35:16.751373
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:35:25.135293
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('ipv6test.service loaded active running')
    assert not request_was_ignored('ipv6test.service loaded inactive dead')
    assert request_was_ignored('Job for ipv6test.service failed. See "systemctl status ipv6test.service" and "journalctl -xe" for details.')
    assert request_was_ignored('ipv6test.service could not be found')



# Generated at 2022-06-23 04:35:28.841666
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": "deactivating"}) == True
    assert is_deactivating_service({"ActiveState": "not-deactivating"}) == False


# Generated at 2022-06-23 04:35:42.139762
# Unit test for function main

# Generated at 2022-06-23 04:35:55.018027
# Unit test for function main
def test_main():
    from units.modules.utils import set_module_args, AnsibleFailJson, AnsibleExitJson
    from ansible.module_utils import basic
    import os
    import sys
    import json

    cur_dir = os.path.dirname(os.path.realpath(__file__))

    with open(cur_dir + '/systemctl_test.json') as data_file:
        test_data = json.load(data_file)


# Generated at 2022-06-23 04:35:58.932201
# Unit test for function is_running_service
def test_is_running_service():
    running = dict(ActiveState='active')
    not_running = dict(ActiveState='inactive')
    assert(is_running_service(running))
    assert(not is_running_service(not_running))


# Generated at 2022-06-23 04:36:06.934073
# Unit test for function is_running_service
def test_is_running_service():
    for status in ['active', 'activating']:
        result = is_running_service({'ActiveState': status})
        assert result is True
    for status in ['inactive', 'deactivating', 'failed']:
        result = is_running_service({'ActiveState': status})
        assert result is False


# Generated at 2022-06-23 04:36:16.323256
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'deactivating'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'invalid'}) is False



# Generated at 2022-06-23 04:36:24.781573
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Normal single-line value
    lines = [ 'ActiveState=active\n' ]
    assert parse_systemctl_show(lines) == { 'ActiveState' : 'active' }

    # Single-line value that starts with { but doesn't end with }
    lines = [ 'Description={foo\n' ]
    assert parse_systemctl_show(lines) == { 'Description' : '{foo' }

    # Single-line value that is empty
    lines = [ 'Description=\n' ]
    assert parse_systemctl_show(lines) == { 'Description' : '' }

    # Multi-line value

# Generated at 2022-06-23 04:36:26.725493
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    from ansible.module_utils import basic
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:36:30.376128
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request") is True
    assert request_was_ignored("ignoring command") is True
    assert request_was_ignored("UNIT LOAD ACTIVE SUB") is False
    assert request_was_ignored("An unknown error") is False



# Generated at 2022-06-23 04:36:35.003839
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:42.708821
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = "Job for smb.service failed because the control process exited with error code.\nSee \"systemctl status smb.service\" and \"journalctl -xe\" for details.\n"
    assert request_was_ignored(out) == False
    out = "ignoring request"
    assert request_was_ignored(out) == True
    out = "ignoring command"
    assert request_was_ignored(out) == True



# Generated at 2022-06-23 04:36:46.784176
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = { 'ActiveState': 'deactivating' }
    assert is_deactivating_service(service_status)
    service_status = { 'ActiveState': 'inactive' }
    assert not is_deactivating_service(service_status)



# Generated at 2022-06-23 04:36:48.690703
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:36:54.190355
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Request was ignored')
    assert request_was_ignored('Request was ignored, nothing to do')
    assert not request_was_ignored('This does not look like the Request was ignored')



# Generated at 2022-06-23 04:37:05.554252
# Unit test for function main
def test_main():
    import pytest

    class ReturnValue:
        pass

    return_value = ReturnValue()
    return_value.return_code = 0
    return_value.stdout = '''
Unit dummy.service could not be found.
'''
    return_value.stderr = ''

    module = ReturnValue()
    module.run_command = pytest.Mock(return_value=return_value)
    module.exit_json = pytest.Mock()
    module.fail_json = pytest.Mock()
    module.get_bin_path = pytest.Mock(return_value="/bin/systemctl")

    params = ReturnValue()
    params.name = "dummy"
    params.state = "started"
    params.enabled = True
    params.force = True
    params.masked = False


# Generated at 2022-06-23 04:37:12.896586
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(dict(ActiveState='deactivating'))
    assert not is_deactivating_service(dict(ActiveState='inactive'))
    assert not is_deactivating_service(dict(ActiveState='active'))
    assert not is_deactivating_service(dict(ActiveState='activating'))
    assert not is_deactivating_service(dict(ActiveState='failed'))



# Generated at 2022-06-23 04:37:18.354442
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:37:27.659369
# Unit test for function main
def test_main():
    # Make sure systemctl returns with rc 1
    is_enabled_cmd = ("systemctl is-enabled systemd-tmpfiles-clean.timer", "", "", 1)
    is_active_cmd = ("systemctl is-active systemd-tmpfiles-clean.timer", "", "", 1)

    # is_enabled shouldn't be valid
    valid_enabled_states = [
        "enabled",
        "enabled-runtime",
        "linked",
        "linked-runtime",
        "masked",
        "masked-runtime",
        "static",
        "indirect",
        "disabled",
        "generated",
        "transient"]

    # Make sure unit exists

# Generated at 2022-06-23 04:37:32.608858
# Unit test for function main
def test_main():
    data = {}
    import tempfile
    fd, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write('test', 'w')
        f.write('test', 'w')
        f.write('test', 'w')

    # Test case 1
    data['params'] = {'name': 'test', 'state': 'started'}
    res = main(data)
    assert res['status'] == 'SUCCESS'

    # Test case 2
    data['params'] = {'name': 'test', 'state': 'stopped'}
    res = main(data)
    assert res['status'] == 'SUCCESS'

    # Test case 3
    data['params'] = {'name': 'test', 'state': 'reloaded'}
    res = main

# Generated at 2022-06-23 04:37:44.484113
# Unit test for function main
def test_main():
    import sys
    import json
    namelist = ['service', 'unit']
    statelist = ['reloaded', 'restarted', 'started', 'stopped']
    enabledlist = ['0', '1']
    maskedlist = ['0', '1']
    daemon_reloadlist = ['0', '1']
    daemon_reexeclist = ['0', '1']
    scalist = ['system', 'user', 'global']
    no_blocklist = ['0', '1']

# Generated at 2022-06-23 04:37:51.378821
# Unit test for function main
def test_main():
    units = [
        'test_unit_1.service',
        'test_unit_2.service',
    ]
    def run_command_mock(module, cmd, check_rc=False):
        # fail only 'test_unit_2.service'
        if cmd.find(units[1]) != -1:
            return 1, '', 'failed'
        else:
            return 0, '', ''


# Generated at 2022-06-23 04:38:02.251075
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring request to reload')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring command to reload')
    # systemd-cgls output on fedora
    assert request_was_ignored('ignoring SIGCHLD')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo ignoring SIGCHLD')
    assert not request_was_ignored('foo ignoring request')
    assert not request_was_ignored('foo ignoring command')



# Generated at 2022-06-23 04:38:04.515898
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    result = is_deactivating_service({"ActiveState": "deactivating"})
    assert result is True



# Generated at 2022-06-23 04:38:16.133676
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:20.550333
# Unit test for function is_running_service
def test_is_running_service():
    service_status_running = {
        'ActiveState': 'active'
    }
    service_status_not_running = {
        'ActiveState': 'inactive'
    }
    assert is_running_service(service_status_running)
    assert not is_running_service(service_status_not_running)



# Generated at 2022-06-23 04:38:34.564000
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:50.828296
# Unit test for function main
def test_main():
    import tempfile
    test_directory = tempfile.gettempdir()
    real_test_file = "/etc/foo.conf"
    fake_test_file = os.path.join(test_directory, "test-systemd-file")
    systemctl_bin = "systemctl"

    #initialize some params
    params = {}

    def mock_exists(path):
        if path == fake_test_file:
            return True
        if path == real_test_file:
            return False
        return os.path.exists(path)

    def mock_rename(src, dest):
        assert os.path.exists(src)
        assert not os.path.exists(dest)
        open(dest, 'a').close()

    def mock_get_bin_path(cmd, required):
        return

# Generated at 2022-06-23 04:39:05.234605
# Unit test for function main
def test_main():
    """
    Unit testing for main()
    """

# Generated at 2022-06-23 04:39:14.932275
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    service_status = {}

    # Standard case.
    lines = '''
        Id=foo.service
        ActiveState=active
        ActiveEnterTimestampMonotonic=123'''.split('\n')
    service_status = parse_systemctl_show(lines)
    assert service_status['Id'] == 'foo.service'
    assert service_status['ActiveState'] == 'active'
    assert service_status['ActiveEnterTimestampMonotonic'] == '123'

    # Single line value with { starting the value.
    lines = '''
        Id=foo.service
        Description={some string without }
        ActiveState=active
        ActiveEnterTimestampMonotonic=123'''.split('\n')
    service_status = parse_systemctl_show(lines)
    assert service_status['Id'] == 'foo.service'

# Generated at 2022-06-23 04:39:18.306967
# Unit test for function is_running_service
def test_is_running_service():
    running_status = {'ActiveState': "active"}
    not_running_status = {'ActiveState': "inactive"}
    assert is_running_service(running_status)
    assert not is_running_service(not_running_status)


# Generated at 2022-06-23 04:39:20.862203
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    if is_deactivating_service("deactivating"):
       return True
    else:
       return False



# Generated at 2022-06-23 04:39:27.635427
# Unit test for function main
def test_main():
    print("Running unit test for main")
    argv = ['main']
    target = '/tmp/ansible_test'
    os.makedirs(target)


# Generated at 2022-06-23 04:39:36.227054
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(
        '[  OK  ] Reached target Graphical Interface.\n') is False
    assert request_was_ignored(
        'Job for abc.service failed because the control process exited '
        'with error code. See "systemctl status abc.service" and '
        '"journalctl -xe" for details.'
    ) is False
    assert request_was_ignored(
        'Job for abc.service failed because a timeout was exceeded. '
        'See "systemctl status abc.service" and "journalctl -xe" for details.'
    ) is False
    assert request_was_ignored(
        '[  OK  ] Started abc.service.\n') is False
    assert request_was_ignored(
        '[  OK  ] Stopped abc.service.\n')

# Generated at 2022-06-23 04:39:44.199297
# Unit test for function main
def test_main():
    # Test with parameters
    # Should succeed with non-empty response
    response = main(dict(argument_spec={}, params={}))
    assert len(response) > 0

    # Test with fail
    # Should fail
    try:
        main(dict(argument_spec={}, params={'daemon_reload': True, 'force': True}))
        assert False
    except Exception as e:
        assert e.message == 'No action detected in task or no service name provided'
