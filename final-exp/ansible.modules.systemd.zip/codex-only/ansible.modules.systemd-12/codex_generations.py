

# Generated at 2022-06-23 04:29:38.505853
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request") is True
    assert request_was_ignored("executing command") is False
    assert request_was_ignored("") is False



# Generated at 2022-06-23 04:29:43.005076
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored(
        'Job for foo.service failed because the control process exited with error code.\n'
        'See "systemctl status foo.service" and "journalctl -xe" for details.\n'
    ) is True
    assert request_was_ignored('') is False



# Generated at 2022-06-23 04:30:02.291740
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:14.183978
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:30:20.353421
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test a multi-line value
    parsed = parse_systemctl_show([
        "Id=crond.service",
        "ExecStart=",
        "{ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"])
    assert 'Id' in parsed
    assert parsed['Id'] == 'crond.service'
    assert 'ExecStart' in parsed

# Generated at 2022-06-23 04:30:24.507327
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('=    ignoring command')
    assert not request_was_ignored('=    changed')



# Generated at 2022-06-23 04:30:31.455915
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert(is_deactivating_service({'ActiveState': 'deactivating'})) is True
    assert(is_deactivating_service({'ActiveState': 'deactivating'})) is True
    assert(is_deactivating_service({'ActiveState': 'foo'})) is False
    assert(is_deactivating_service({'ActiveState': 'bar'})) is False



# Generated at 2022-06-23 04:30:35.503568
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('= Foo')
    assert not request_was_ignored('ignored')
    assert not request_was_ignored('ignorance')



# Generated at 2022-06-23 04:30:43.791102
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    test_input = {'ActiveState':'deactivating'}
    test_output = is_deactivating_service(test_input)
    # The function should return true if the Unit's current state is deactivating
    assert test_output == True
    # Input: No deactivating state
    test_no_input = {'ActiveState':'active'}
    test_no_output = is_deactivating_service(test_no_input)
    # We should get False when the state is not deactivating
    assert test_no_output == False


# Generated at 2022-06-23 04:30:46.884408
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'failed'})



# Generated at 2022-06-23 04:30:50.381062
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:31:06.440898
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('') is False
    assert request_was_ignored('foo') is False
    assert request_was_ignored('foo=bar') is False
    assert request_was_ignored('foo=bar baz=bat') is False
    assert request_was_ignored('foo=bar=baz') is False
    assert request_was_ignored('=bar') is False
    assert request_was_ignored('foo=') is False
    assert request_was_ignored('foo= ') is False
    assert request_was_ignored('foo= ') is False
    assert request_was_ignored('foo= ') is False
    assert request_was_ignored('foo= ') is False
    assert request_was_ignored('foo= ') is False
    assert request_was_

# Generated at 2022-06-23 04:31:12.341907
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring request:')
    assert request_was_ignored('ignoring command:')
    assert not request_was_ignored('ignoring')



# Generated at 2022-06-23 04:31:17.159910
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    sample_output = '''
    Description=Foo
    ExecStart={ path=/foo ; argv[]=/some/command ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
    ExecStart={ path=/foo ; argv[]=/some/other/command ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
    ExecReload=
    '''

# Generated at 2022-06-23 04:31:21.915031
# Unit test for function main
def test_main():
    ansible_module_main({
        'name': 'my_service',
        'state': 'started',
        'enabled': True,
        'masked': False,
        'daemon_reload': True
    })

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:27.943062
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'not_running'})
    assert not is_running_service({'ActiveState': 'not_running', 'WantedBy': 'SomethingElse'})



# Generated at 2022-06-23 04:31:34.043639
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False
    assert is_deactivating_service({'ActiveState': 'active'}) is False



# Generated at 2022-06-23 04:31:35.941276
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service(service_status = {"ActiveState": "deactivating"}) == True



# Generated at 2022-06-23 04:31:40.500327
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:31:42.299423
# Unit test for function main
def test_main():
    assert True
# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
  main()

# Generated at 2022-06-23 04:31:55.093404
# Unit test for function main
def test_main():
    # Unit test collection starts here
    # Putting test_name as a function parameter allows us to use the standard unittest-style assert* methods.
    def test_module_arguments(self):
        """ test module arguments """
        args = dict(
            name='ntp',
            enabled='no',
            daemon_reload='yes',
            daemon_reexec='yes',
            state='stopped',
            scope='user',
            no_block='yes',
            force='no',
        )
        p = ModuleArgsParser(args)
        assert p.get('name') == 'ntp'
        assert p.get('enabled') is False
        assert p.get('daemon_reload') is True
        assert p.get('daemon_reexec') is True

# Generated at 2022-06-23 04:31:56.587948
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:31:59.285787
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({"ActiveState": 'deactivating'})
    assert not is_deactivating_service({"ActiveState": 'active'})



# Generated at 2022-06-23 04:32:04.563930
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'reloading'})


# Generated at 2022-06-23 04:32:07.546173
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request.\n')
    assert not request_was_ignored('something else')



# Generated at 2022-06-23 04:32:11.411496
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:32:17.213991
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status) is True
    service_status = {'ActiveState': 'inactive'}
    assert is_deactivating_service(service_status) is False
    service_status = {'ActiveState': 'dead'}
    assert is_deactivating_service(service_status) is False



# Generated at 2022-06-23 04:32:29.734031
# Unit test for function main
def test_main():
    import json
    from ansible.module_utils.common.collections import Mapping

    args = dict(
        name='httpd',
        state='started',
        enabled=False,
        force=False,
        masked=False,
        daemon_reload=False,
        daemon_reexec=False,
        scope='system',
        no_block=False,
    )

# Generated at 2022-06-23 04:32:35.538708
# Unit test for function is_running_service
def test_is_running_service():
    service_status = {
        'ActiveState': 'active',
    }
    assert is_running_service(service_status)

    service_status = {
        'ActiveState': 'activating',
    }
    assert is_running_service(service_status)


# Generated at 2022-06-23 04:32:44.528621
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('got message type=method_call sender=:1.66 path=/org/freedesktop/systemd1')
    assert not request_was_ignored('ActiveState=inactive')
    assert not request_was_ignored('LoadState=loaded')
    assert not request_was_ignored('UnitFileState=enabled')
    assert not request_was_ignored('SubState=running')



# Generated at 2022-06-23 04:32:55.450173
# Unit test for function main

# Generated at 2022-06-23 04:32:59.974170
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'loaded'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'unknown'})



# Generated at 2022-06-23 04:33:01.427892
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState':'active'}) == True



# Generated at 2022-06-23 04:33:05.487863
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('Ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-23 04:33:14.212421
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Check the handling of a multi-line value
    s = '''Description=test

ExecStart={test}'''.splitlines(True)
    assert parse_systemctl_show(s) == {'Description': 'test', 'ExecStart': '{test}'}

    # Check the handling of a single-line value that starts with { but does not end with }
    s = 'Description={test'
    assert parse_systemctl_show(s.splitlines(True)) == {'Description': '{test'}

    # Check the handling of a single-line value that starts and ends with {
    s = 'Description={test}'
    assert parse_systemctl_show(s.splitlines(True)) == {'Description': '{test}'}

    # Check the handling of a value that does not start with { or end with }
   

# Generated at 2022-06-23 04:33:23.244085
# Unit test for function main
def test_main():
    test_args = { "scope": "system", "force": False, "state": "reloaded", "daemon_reexec": False, "daemon_reload": False, "name": "sshd", "no_block": False, "enabled": False, "masked": False }

# Generated at 2022-06-23 04:33:33.255765
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = '''
       ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT
       ActiveEnterTimestampMonotonic=8135942
       '''
    assert parse_systemctl_show(lines.splitlines()) == {
        'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT',
        'ActiveEnterTimestampMonotonic': '8135942',
    }

# Generated at 2022-06-23 04:33:35.705453
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert not is_deactivating_service({'ActiveState': 'other_state'})
# Test for function is_running_service

# Generated at 2022-06-23 04:33:49.263669
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that it returns the correct values for a service that has no multi-line values
    test1 = '''Type=simple
Id=crond.service
Names=crond.service
Requires=basic.target
Wants=system.slice
Before=shutdown.target multi-user.target
After=auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice
Conflicts=shutdown.target'''.split('\n')

# Generated at 2022-06-23 04:33:55.526794
# Unit test for function request_was_ignored

# Generated at 2022-06-23 04:33:57.777631
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState':'deactivating'})



# Generated at 2022-06-23 04:34:06.177609
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('= Static hostname: fedora23.example.com\n') is False
    assert request_was_ignored('ignoring command.  unit is masked.') is True


# this code is over-complicated because:
# - systemd-run does not support --scope (pre-230)
# - systemd-run does not support --user (pre-229)
# - systemd-run does not support --global (not sure when it was added)

# Generated at 2022-06-23 04:34:11.589798
# Unit test for function is_running_service
def test_is_running_service():
    test_obj = {'ActiveState': 'inactive'}
    assert is_running_service(test_obj) == False
    test_obj = {'ActiveState': 'activating'}
    assert is_running_service(test_obj) == True
    test_obj = {'ActiveState': 'unknown'}
    assert is_running_service(test_obj) == False



# Generated at 2022-06-23 04:34:18.237583
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service(dict(ActiveState='active'))
    assert is_running_service(dict(ActiveState='activating'))
    assert not is_running_service(dict(ActiveState='inactive'))
    assert not is_running_service(dict(ActiveState='deactivating'))
    assert not is_running_service(dict(ActiveState='unknown'))



# Generated at 2022-06-23 04:34:31.813942
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    line1 = "ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
    line2 = "ExecStartPost={ path=/usr/bin/touch ; argv[]=/usr/bin/touch /etc/cron.d/lastrun ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
    line3 = "ExecStartPost=/usr/sbin/service-in-chroot-env.sh -s crond"

# Generated at 2022-06-23 04:34:40.185577
# Unit test for function is_running_service
def test_is_running_service():
    status_dict = {"ActiveState": "active"}
    assert is_running_service(status_dict)

    status_dict = {"ActiveState": "activating"}
    assert is_running_service(status_dict)

    status_dict = {"ActiveState": "deactivating"}
    assert not is_running_service(status_dict)

    status_dict = {"ActiveState": "inactive"}
    assert not is_running_service(status_dict)

    status_dict = {"ActiveState": "failed"}
    assert not is_running_service(status_dict)



# Generated at 2022-06-23 04:34:44.319216
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'other'})


# Generated at 2022-06-23 04:34:51.539448
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState':'deactivating'}) is True
    assert is_deactivating_service({'ActiveState':'active'}) is False
    assert is_deactivating_service({'ActiveState':'activating'}) is False
    assert is_deactivating_service({'ActiveState':'inactive'}) is False


# Generated at 2022-06-23 04:34:57.321079
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('= 0') is False
    assert request_was_ignored('=') is False
    assert request_was_ignored('=1 OK') is False
    assert request_was_ignored('"status"') is False



# Generated at 2022-06-23 04:35:07.607626
# Unit test for function is_running_service
def test_is_running_service():
    s = dict(ActiveState='active', SubState='running')
    assert is_running_service(s)
    s = dict(ActiveState='activating', SubState='running')
    assert is_running_service(s)
    s = dict(ActiveState='reloading', SubState='running')
    assert is_running_service(s)
    s = dict(ActiveState='inactive', SubState='dead')
    assert not is_running_service(s)
    s = dict(ActiveState='failed', SubState='dead')
    assert not is_running_service(s)



# Generated at 2022-06-23 04:35:16.445577
# Unit test for function request_was_ignored
def test_request_was_ignored():
    success = 'succeeded'
    failure = 'failed'
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('=' + success) is False
    assert request_was_ignored('=' + failure) is False
    assert request_was_ignored('Unit dummy.service could not be found.') is False
    assert request_was_ignored('Unit foo.service could not be found.') is False



# Generated at 2022-06-23 04:35:22.754531
# Unit test for function main
def test_main():
    #
    # Unit test
    #

    print("Running unit test")
    print("=================\n")

    print("Test case: no flags or service")

if __name__ == '__main__':
    # Unit tests
    if sys.argv[1] == 'test':
        test_main()
    else:
        main()

# Generated at 2022-06-23 04:35:26.804618
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert not is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:35:29.604679
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo=bar')



# Generated at 2022-06-23 04:35:43.000304
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    res = parse_systemctl_show([
        'Id=crond.service',
        'Description=Command Scheduler',
        'After=auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice',
        'Requires=basic.target'
    ])
    assert res == {
        'Id': 'crond.service',
        'Description': 'Command Scheduler',
        'After': 'auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice',
        'Requires': 'basic.target'
    }

# Generated at 2022-06-23 04:35:46.665959
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = dict()
    service_status['ActiveState'] = 'deactivating'
    assert(is_deactivating_service(service_status) == True)


# Generated at 2022-06-23 04:35:49.916235
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert ((is_deactivating_service({'ActiveState':'deactivating'})))
    assert not ((is_deactivating_service({'ActiveState':''})))



# Generated at 2022-06-23 04:36:02.423308
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:36:13.561755
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 04:36:19.411491
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': None})
    assert not is_running_service({'ActiveState': ''})
    assert not is_running_service({})


# ===========================================
# unitinfo support code


# Generated at 2022-06-23 04:36:23.112578
# Unit test for function is_running_service
def test_is_running_service():
    status_active = {'ActiveState': 'active'}
    status_activating = {'ActiveState': 'activating'}
    status_inactive = {'ActiveState': 'inactive'}
    assert is_running_service(status_active)
    assert is_running_service(status_activating)
    assert not is_running_service(status_inactive)



# Generated at 2022-06-23 04:36:25.696852
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'testing'}) is False



# Generated at 2022-06-23 04:36:28.013411
# Unit test for function is_running_service
def test_is_running_service():
    test_status = dict(ActiveState='active')
    assert is_running_service(test_status)



# Generated at 2022-06-23 04:36:33.309561
# Unit test for function is_running_service
def test_is_running_service():
    assert(is_running_service({'ActiveState': 'active'}))
    assert(is_running_service({'ActiveState': 'activating'}))
    assert(not is_running_service({'ActiveState': 'inactive'}))


# Generated at 2022-06-23 04:36:40.016374
# Unit test for function request_was_ignored
def test_request_was_ignored():
    from ansible.module_utils.systemd import request_was_ignored
    assert request_was_ignored("invalid operation 'bogus'")
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert not request_was_ignored("running")
    assert not request_was_ignored("failed")



# Generated at 2022-06-23 04:36:49.824137
# Unit test for function is_deactivating_service

# Generated at 2022-06-23 04:36:55.933053
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:37:08.052556
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:37:20.563787
# Unit test for function is_deactivating_service

# Generated at 2022-06-23 04:37:24.922716
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'})
    assert is_deactivating_service({'ActiveState': 'active'})
    assert is_deactivating_service({'ActiveState': 'activating'})
    assert not is_deactivating_service({'ActiveState': 'inactive'})



# Generated at 2022-06-23 04:37:29.883885
# Unit test for function request_was_ignored
def test_request_was_ignored():
    return request_was_ignored('Job for xxx.service failed because the control process exited with error code. See "systemctl status xxx.service" and "journalctl -xe" for details.')



# Generated at 2022-06-23 04:37:39.120767
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert not request_was_ignored('Active: active (running)')
    assert not request_was_ignored('Active: active (running)\n  ...')
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert request_was_ignored('ignoring request, unit is masked')
    assert request_was_ignored('ignoring command, unit is masked')
    assert not request_was_ignored('Active: active (running)\n  ignoring request')
    assert not request_was_ignored('Active: active (running)\n  ignoring command')



# Generated at 2022-06-23 04:37:44.252233
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request') is True
    assert request_was_ignored('ignoring command') is True
    assert request_was_ignored('0 loaded units listed.') is False
    assert request_was_ignored('0 loaded units listed. Pass --all to see loaded but inactive units') is False



# Generated at 2022-06-23 04:37:49.185464
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("foo bar baz") is False
    assert request_was_ignored("foo=bar baz") is False
    assert request_was_ignored("foo bar=baz") is False
    assert request_was_ignored("foo bar baz=qux") is False
    assert request_was_ignored("foo=ignoring request") is True
    assert request_was_ignored("foo=ignoring command") is True



# Generated at 2022-06-23 04:37:51.110508
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:37:55.266405
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('foo=bar')



# Generated at 2022-06-23 04:38:06.161873
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:16.729492
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    output = '''\
Description=Test
ExecStart={
    # comment
    /usr/bin/test
}
ExecReload={
    # comment
    /usr/bin/test
}
Description=Another test
ExecStart={
    # comment
    /usr/bin/anothertest
}
'''.split('\n')
    expected = {
        'ExecStart': '''\
{
    # comment
    /usr/bin/test
}''',
        'Description': 'Test',
        'ExecReload': '''\
{
    # comment
    /usr/bin/test
}''',
    }
    actual = parse_systemctl_show(output)
    assert expected == actual

# Generated at 2022-06-23 04:38:19.719271
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState':'active'}) == True
    assert is_running_service({'ActiveState':'activating'}) == True
    assert is_running_service({'ActiveState':'inactive'}) == False


# Generated at 2022-06-23 04:38:24.825329
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('some information ignoring request to start')
    assert request_was_ignored('some information ignoring command to start')
    assert not request_was_ignored('some information, nothing on ignore')



# Generated at 2022-06-23 04:38:30.418647
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'})
    assert is_running_service({'ActiveState': 'activating'})
    assert not is_running_service({'ActiveState': 'inactive'})
    assert not is_running_service({'ActiveState': 'deactivating'})



# Generated at 2022-06-23 04:38:32.169264
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:38:35.354904
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    assert is_deactivating_service({'ActiveState': 'deactivating'}) is True
    assert is_deactivating_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:38:40.571944
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:38:46.675470
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test the success case where the data is contained on a single line
    test_data = '''foo=bar'''
    expected_result = {
        'foo': 'bar',
    }
    assert parse_systemctl_show(test_data.splitlines()) == expected_result

    # Test the case where there's a single-line value that starts with { but does not end with }
    test_data = '''foo=bar
Description={this is a test}'''
    expected_result = {
        'foo': 'bar',
        'Description': '{this is a test}',
    }
    assert parse_systemctl_show(test_data.splitlines()) == expected_result

    # Test the case where there's a multi-line value that starts with { and ends with }

# Generated at 2022-06-23 04:38:51.426216
# Unit test for function is_running_service
def test_is_running_service():
    assert is_running_service({'ActiveState': 'active'}) is True
    assert is_running_service({'ActiveState': 'activating'}) is True
    assert is_running_service({'ActiveState': 'failed'}) is False
    assert is_running_service({'ActiveState': 'inactive'}) is False



# Generated at 2022-06-23 04:39:05.812809
# Unit test for function main
def test_main():
    '''
    Run module and tests
    python library/systemd.py
    '''

    # Globals
    global MODULE_ARGS
    global MODULE_COMMAND
    global MODULE_COMPLEX_ARGS
    global MODULE_EXPECT
    global MODULE_FAIL_JSON
    global MODULE_HAS_ARGS
    global MODULE_JSON
    global MODULE_PARAMS
    global MODULE_RC

    # set up the test environment
    MODULE_ARGS = {'daemon_reload': False, 'masked': None, 'force': False, 'enabled': None, 'daemon_reexec': False, 'scope': 'system', 'no_block': False, 'name': None, 'state': None}

# Generated at 2022-06-23 04:39:08.469736
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert not request_was_ignored("= ignoring request")
    assert not request_was_ignored("ignoring command")



# Generated at 2022-06-23 04:39:16.699702
# Unit test for function parse_systemctl_show

# Generated at 2022-06-23 04:39:18.223132
# Unit test for function is_deactivating_service
def test_is_deactivating_service():
    service_status = {'ActiveState': 'deactivating'}
    assert is_deactivating_service(service_status)



# Generated at 2022-06-23 04:39:30.718282
# Unit test for function main

# Generated at 2022-06-23 04:39:43.190906
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    input_lines = [
        'SomeKey=SomeValue',
        'SomeOtherKey=SomeOtherValue',
        'MultiLineValue=value1',
        '  value2',
        '  value3',
        'AKey=AValue',
        'ExecStart={\n   ExecStart=value1\n   ExecStart=value2\n}',
        'MultiLineValue=value1',
        'ExecStart=value1',
        'value2',
        'AKey=AValue',
        'MultiLineValue={\nvalue1\nvalue2\n}',
    ]