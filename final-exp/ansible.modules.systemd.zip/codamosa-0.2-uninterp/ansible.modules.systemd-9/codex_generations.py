

# Generated at 2022-06-17 05:28:52.872598
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:04.790997
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:16.748869
# Unit test for function main

# Generated at 2022-06-17 05:29:22.785858
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:29:26.330841
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:29:39.016893
# Unit test for function main

# Generated at 2022-06-17 05:29:43.086540
# Unit test for function main

# Generated at 2022-06-17 05:29:55.733704
# Unit test for function main

# Generated at 2022-06-17 05:30:03.533417
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a single-line value is parsed correctly
    lines = ['Description=Command Scheduler']
    assert parse_systemctl_show(lines) == {'Description': 'Command Scheduler'}
    # Test that a multi-line value is parsed correctly
    lines = ['ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }']

# Generated at 2022-06-17 05:30:15.409875
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a single-line value is parsed correctly
    lines = ['Description=foo']
    expected = {'Description': 'foo'}
    assert parse_systemctl_show(lines) == expected
    # Test that a multi-line value is parsed correctly
    lines = ['ExecStart={', '  foo', '}']
    expected = {'ExecStart': '{\n  foo\n}'}
    assert parse_systemctl_show(lines) == expected
    # Test that a multi-line value that is not surrounded by {} is parsed correctly
    lines = ['ExecStart=foo', '  bar']
    expected = {'ExecStart': 'foo\n  bar'}
    assert parse_systemctl_show(lines) == expected
    # Test that a multi-line value that is not surrounded by {} is parsed correctly

# Generated at 2022-06-17 05:30:39.129233
# Unit test for function main

# Generated at 2022-06-17 05:30:45.669804
# Unit test for function main

# Generated at 2022-06-17 05:30:52.410389
# Unit test for function main

# Generated at 2022-06-17 05:31:00.468272
# Unit test for function main

# Generated at 2022-06-17 05:31:10.577679
# Unit test for function main

# Generated at 2022-06-17 05:31:18.692313
# Unit test for function main

# Generated at 2022-06-17 05:31:29.923217
# Unit test for function main

# Generated at 2022-06-17 05:31:39.545286
# Unit test for function main

# Generated at 2022-06-17 05:31:51.862877
# Unit test for function main

# Generated at 2022-06-17 05:32:03.443557
# Unit test for function main