

# Generated at 2022-06-17 05:28:54.728153
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:29:05.762340
# Unit test for function main

# Generated at 2022-06-17 05:29:17.906519
# Unit test for function main

# Generated at 2022-06-17 05:29:31.624449
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test with a single-line value
    lines = [
        'Id=crond.service',
        'Names=crond.service',
        'Description=Command Scheduler',
        'LoadState=loaded',
        'ActiveState=active',
        'SubState=running',
        'UnitFileState=enabled',
    ]
    parsed = parse_systemctl_show(lines)
    assert parsed == {
        'Id': 'crond.service',
        'Names': 'crond.service',
        'Description': 'Command Scheduler',
        'LoadState': 'loaded',
        'ActiveState': 'active',
        'SubState': 'running',
        'UnitFileState': 'enabled',
    }
    # Test with a multi-line value

# Generated at 2022-06-17 05:29:44.774146
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:57.073939
# Unit test for function main

# Generated at 2022-06-17 05:30:05.976230
# Unit test for function main

# Generated at 2022-06-17 05:30:17.443893
# Unit test for function main

# Generated at 2022-06-17 05:30:24.254633
# Unit test for function main

# Generated at 2022-06-17 05:30:35.277046
# Unit test for function main

# Generated at 2022-06-17 05:31:09.653752
# Unit test for function main

# Generated at 2022-06-17 05:31:23.496308
# Unit test for function main

# Generated at 2022-06-17 05:31:31.348326
# Unit test for function main

# Generated at 2022-06-17 05:31:44.359480
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a single-line value is parsed correctly
    assert parse_systemctl_show(['Description=foo']) == {'Description': 'foo'}
    # Test that a multi-line value is parsed correctly
    assert parse_systemctl_show(['ExecStart={', '  foo', '}']) == {'ExecStart': '{\n  foo\n}'}
    # Test that a multi-line value that spans multiple lines is parsed correctly
    assert parse_systemctl_show(['ExecStart={', '  foo', '  bar', '}']) == {'ExecStart': '{\n  foo\n  bar\n}'}
    # Test that a multi-line value that spans multiple lines is parsed correctly, even if the
    # first line does not end with a newline

# Generated at 2022-06-17 05:31:56.924742
# Unit test for function main

# Generated at 2022-06-17 05:32:04.668514
# Unit test for function main

# Generated at 2022-06-17 05:32:14.505614
# Unit test for function main

# Generated at 2022-06-17 05:32:25.139471
# Unit test for function main

# Generated at 2022-06-17 05:32:33.159738
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:32:44.761802
# Unit test for function main

# Generated at 2022-06-17 05:33:10.522759
# Unit test for function main

# Generated at 2022-06-17 05:33:15.881138
# Unit test for function main

# Generated at 2022-06-17 05:33:23.378152
# Unit test for function main

# Generated at 2022-06-17 05:33:36.298805
# Unit test for function main

# Generated at 2022-06-17 05:33:48.106536
# Unit test for function main

# Generated at 2022-06-17 05:33:57.895028
# Unit test for function main

# Generated at 2022-06-17 05:34:07.550831
# Unit test for function main

# Generated at 2022-06-17 05:34:15.771311
# Unit test for function main
def test_main():
    # Test with no params
    args = dict(
        daemon_reload=False,
        daemon_reexec=False,
        enabled=False,
        masked=False,
        name=None,
        no_block=False,
        scope='system',
        state=None,
    )
    result = dict(
        changed=False,
        name=None,
        status=dict(),
    )

# Generated at 2022-06-17 05:34:22.199327
# Unit test for function main

# Generated at 2022-06-17 05:34:32.967373
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils.systemd import sysv_exists
    from ansible.module_utils.systemd import sysv_is_enabled
    from ansible.module_utils.systemd import is_running_service
    from ansible.module_utils.systemd import is_deactivating_service
    from ansible.module_utils.systemd import is_chroot
    from ansible.module_utils.systemd import fail_if_missing
    from ansible.module_utils.systemd import request_was_ignored
    from ansible.module_utils.systemd import parse_systemctl_show
    from ansible.module_utils.systemd import to_native

# Generated at 2022-06-17 05:34:58.111809
# Unit test for function main

# Generated at 2022-06-17 05:35:03.161675
# Unit test for function main

# Generated at 2022-06-17 05:35:09.030895
# Unit test for function main

# Generated at 2022-06-17 05:35:23.453846
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:35:31.438608
# Unit test for function main

# Generated at 2022-06-17 05:35:38.655285
# Unit test for function main

# Generated at 2022-06-17 05:35:46.073082
# Unit test for function main

# Generated at 2022-06-17 05:35:55.196422
# Unit test for function main

# Generated at 2022-06-17 05:36:03.367218
# Unit test for function main

# Generated at 2022-06-17 05:36:11.387080
# Unit test for function main