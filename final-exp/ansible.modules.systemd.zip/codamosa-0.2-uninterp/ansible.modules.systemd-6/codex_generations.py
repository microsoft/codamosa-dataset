

# Generated at 2022-06-17 05:28:33.548610
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:28:36.397305
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:28:44.256829
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    from ansible.module_utils.systemd import _parse_systemctl_show
    from ansible.module_utils.systemd import _is_running_service
    from ansible.module_utils.systemd import _is_deactivating_service
    from ansible.module_utils.systemd import _is_chroot
    from ansible.module_utils.systemd import _fail_if_missing
    from ansible.module_utils.systemd import _sysv_exists
    from ansible.module_utils.systemd import _sysv_is_enabled
    from ansible.module_utils.systemd import _request_was_ignored
    from ansible.module_utils.systemd import _parse

# Generated at 2022-06-17 05:28:53.858161
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:05.056595
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test a single-line value
    lines = ['Description=foo']
    assert parse_systemctl_show(lines) == {'Description': 'foo'}
    # Test a multi-line value
    lines = ['ExecStart={\n', '  foo\n', '  bar\n', '}']
    assert parse_systemctl_show(lines) == {'ExecStart': '{\n  foo\n  bar\n}'}
    # Test a multi-line value that spans multiple lines
    lines = ['ExecStart={\n', '  foo\n', '  bar\n', '}\n', 'Description=baz']
    assert parse_systemctl_show(lines) == {'ExecStart': '{\n  foo\n  bar\n}', 'Description': 'baz'}
    # Test a multi-line value

# Generated at 2022-06-17 05:29:17.078163
# Unit test for function main

# Generated at 2022-06-17 05:29:27.552919
# Unit test for function main

# Generated at 2022-06-17 05:29:29.213891
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:29:41.962095
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:47.200260
# Unit test for function main

# Generated at 2022-06-17 05:30:13.741443
# Unit test for function main

# Generated at 2022-06-17 05:30:21.525062
# Unit test for function main

# Generated at 2022-06-17 05:30:29.405684
# Unit test for function main

# Generated at 2022-06-17 05:30:37.167359
# Unit test for function main

# Generated at 2022-06-17 05:30:50.334215
# Unit test for function main

# Generated at 2022-06-17 05:30:59.419607
# Unit test for function main

# Generated at 2022-06-17 05:31:10.335671
# Unit test for function main

# Generated at 2022-06-17 05:31:18.509411
# Unit test for function main

# Generated at 2022-06-17 05:31:26.416121
# Unit test for function main

# Generated at 2022-06-17 05:31:36.779932
# Unit test for function main