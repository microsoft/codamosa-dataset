

# Generated at 2022-06-17 05:28:49.824749
# Unit test for function main

# Generated at 2022-06-17 05:28:55.781916
# Unit test for function main

# Generated at 2022-06-17 05:29:06.074530
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    from ansible.module_utils.systemd import _parse_systemctl_show, _parse_systemctl_list_unit_files, _parse_systemctl_list_unit_files_2
    from ansible.module_utils.systemd import _parse_systemctl_list_unit_files_3, _parse_systemctl_list_unit_files_4, _parse_systemctl_list_unit_files_5
    from ansible.module_utils.systemd import _parse_systemctl_list_unit_files_6, _parse_systemctl_list_unit_files_7
    from ansible.module_utils.systemd import _parse_systemctl_list_unit_files_8, _parse_system

# Generated at 2022-06-17 05:29:18.330377
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:31.846236
# Unit test for function main

# Generated at 2022-06-17 05:29:36.464548
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a single-line value is parsed correctly
    lines = ['Description=Foo']
    parsed = parse_systemctl_show(lines)
    assert parsed['Description'] == 'Foo'

    # Test that a multi-line value is parsed correctly
    lines = ['ExecStart={\n', '  Path=/foo\n', '  Args=bar\n', '}']
    parsed = parse_systemctl_show(lines)
    assert parsed['ExecStart'] == '{\n  Path=/foo\n  Args=bar\n}'

    # Test that a multi-line value that starts with { but does not end with } is parsed correctly
    lines = ['Description={Foo']
    parsed = parse_systemctl_show(lines)
    assert parsed['Description'] == '{Foo'

    # Test that a multi-line

# Generated at 2022-06-17 05:29:47.800985
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:53.873106
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('ignoring')



# Generated at 2022-06-17 05:30:02.432561
# Unit test for function main

# Generated at 2022-06-17 05:30:14.809709
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:30:42.974160
# Unit test for function main

# Generated at 2022-06-17 05:30:56.198262
# Unit test for function main

# Generated at 2022-06-17 05:31:08.345237
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['foo=bar']) == {'foo': 'bar'}
    assert parse_systemctl_show(['foo=bar', 'baz=qux']) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_systemctl_show(['foo=bar', 'baz=qux', 'quux=corge']) == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}
    assert parse_systemctl_show(['foo=bar', 'baz=qux', 'quux=corge', 'grault=garply']) == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge', 'grault': 'garply'}

# Generated at 2022-06-17 05:31:22.938434
# Unit test for function main

# Generated at 2022-06-17 05:31:31.024312
# Unit test for function main

# Generated at 2022-06-17 05:31:39.606876
# Unit test for function main

# Generated at 2022-06-17 05:31:51.903510
# Unit test for function main

# Generated at 2022-06-17 05:32:01.994635
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test with a single-line value
    lines = ['Description=Command Scheduler']
    assert parse_systemctl_show(lines) == {'Description': 'Command Scheduler'}

    # Test with a multi-line value
    lines = [
        'ExecStart={',
        'path=/usr/sbin/crond ;',
        'argv[]=/usr/sbin/crond -n $CRONDARGS ;',
        'ignore_errors=no ;',
        'start_time=[n/a] ;',
        'stop_time=[n/a] ;',
        'pid=0 ;',
        'code=(null) ;',
        'status=0/0',
        '}',
    ]

# Generated at 2022-06-17 05:32:12.214363
# Unit test for function main

# Generated at 2022-06-17 05:32:23.599566
# Unit test for function main

# Generated at 2022-06-17 05:33:09.814363
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import main
    from ansible.module_utils.systemd import sysv_exists
    from ansible.module_utils.systemd import sysv_is_enabled
    from ansible.module_utils.systemd import is_running_service
    from ansible.module_utils.systemd import is_deactivating_service
    from ansible.module_utils.systemd import is_chroot
    from ansible.module_utils.systemd import request_was_ignored
    from ansible.module_utils.systemd import fail_if_missing
    from ansible.module_utils.systemd import parse_systemctl_show
    from ansible.module_utils.systemd import to_native

# Generated at 2022-06-17 05:33:23.402641
# Unit test for function main

# Generated at 2022-06-17 05:33:36.342105
# Unit test for function main

# Generated at 2022-06-17 05:33:48.138027
# Unit test for function main

# Generated at 2022-06-17 05:34:00.053478
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import AnsibleModule
    from ansible.module_utils.systemd import is_running_service
    from ansible.module_utils.systemd import is_deactivating_service
    from ansible.module_utils.systemd import sysv_exists
    from ansible.module_utils.systemd import sysv_is_enabled
    from ansible.module_utils.systemd import fail_if_missing
    from ansible.module_utils.systemd import is_chroot
    from ansible.module_utils.systemd import parse_systemctl_show
    from ansible.module_utils.systemd import request_was_ignored
    from ansible.module_utils.systemd import to_native

# Generated at 2022-06-17 05:34:08.958240
# Unit test for function main

# Generated at 2022-06-17 05:34:16.220972
# Unit test for function main

# Generated at 2022-06-17 05:34:25.879688
# Unit test for function main

# Generated at 2022-06-17 05:34:35.076227
# Unit test for function main

# Generated at 2022-06-17 05:34:44.196758
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 05:37:08.369113
# Unit test for function main

# Generated at 2022-06-17 05:37:21.977648
# Unit test for function main

# Generated at 2022-06-17 05:37:33.744299
# Unit test for function main

# Generated at 2022-06-17 05:37:42.258169
# Unit test for function main

# Generated at 2022-06-17 05:37:51.060144
# Unit test for function main

# Generated at 2022-06-17 05:38:01.406797
# Unit test for function main

# Generated at 2022-06-17 05:38:09.355570
# Unit test for function main

# Generated at 2022-06-17 05:38:23.350191
# Unit test for function main