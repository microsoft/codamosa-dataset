

# Generated at 2022-06-17 05:28:53.083938
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:04.860868
# Unit test for function main

# Generated at 2022-06-17 05:29:06.382231
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:29:18.572123
# Unit test for function main

# Generated at 2022-06-17 05:29:31.714719
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a value that spans multiple lines is parsed correctly
    lines = [
        'Id=foo.service',
        'Description=This is a test',
        'ExecStart={',
        '  /bin/true',
        '}',
        'ExecStop={',
        '  /bin/false',
        '}',
        'ExecReload={',
        '  /bin/true',
        '}',
    ]
    parsed = parse_systemctl_show(lines)
    assert parsed['Id'] == 'foo.service'
    assert parsed['Description'] == 'This is a test'
    assert parsed['ExecStart'] == '/bin/true'
    assert parsed['ExecStop'] == '/bin/false'
    assert parsed['ExecReload'] == '/bin/true'

    # Test that a value that starts with { but

# Generated at 2022-06-17 05:29:44.816658
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    import os
    import sys

    # Mock module

# Generated at 2022-06-17 05:29:57.118721
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:30:06.064267
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:30:10.331522
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    import sys
    import os
    import shutil
    import tempfile
    import subprocess
    import json

    def _run_module(module_name, module_args):
        module_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules', 'system', module_name + '.py')
        module_args = json.dumps(module_args)
        if PY3:
            module_args = to_bytes(module_args, errors='surrogate_or_strict')

# Generated at 2022-06-17 05:30:22.560278
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:30:49.698314
# Unit test for function main

# Generated at 2022-06-17 05:30:59.068460
# Unit test for function main

# Generated at 2022-06-17 05:31:10.103563
# Unit test for function main

# Generated at 2022-06-17 05:31:18.316589
# Unit test for function main

# Generated at 2022-06-17 05:31:29.710760
# Unit test for function main

# Generated at 2022-06-17 05:31:39.320084
# Unit test for function main
def test_main():
    from ansible.module_utils.systemd import main
    from ansible.module_utils.systemd import sysv_exists
    from ansible.module_utils.systemd import sysv_is_enabled
    from ansible.module_utils.systemd import is_running_service
    from ansible.module_utils.systemd import is_deactivating_service
    from ansible.module_utils.systemd import is_chroot
    from ansible.module_utils.systemd import request_was_ignored
    from ansible.module_utils.systemd import parse_systemctl_show
    from ansible.module_utils.systemd import fail_if_missing
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 05:31:51.574788
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import AnsibleModuleTestCase

    class TestSystemdModule(AnsibleModuleTestCase):
        def test_systemd_module(self):
            module = self.mock_module_helper(
                params=dict(
                    name='foo',
                    state='started',
                    enabled=True,
                    masked=False,
                    daemon_reload=False,
                    daemon_reexec=False,
                    scope='system',
                    no_block=False,
                ),
                check_mode=False,
            )

            # Mock the module
            module.run_command = self.mock_run_command
            module.fail_json = self.mock_fail_json
            module.warn = self.mock_

# Generated at 2022-06-17 05:32:03.985354
# Unit test for function main

# Generated at 2022-06-17 05:32:15.979016
# Unit test for function main

# Generated at 2022-06-17 05:32:24.849133
# Unit test for function main

# Generated at 2022-06-17 05:33:08.016722
# Unit test for function main

# Generated at 2022-06-17 05:33:23.014667
# Unit test for function main

# Generated at 2022-06-17 05:33:35.708086
# Unit test for function main

# Generated at 2022-06-17 05:33:47.572579
# Unit test for function main

# Generated at 2022-06-17 05:33:56.369133
# Unit test for function main

# Generated at 2022-06-17 05:34:07.099152
# Unit test for function main

# Generated at 2022-06-17 05:34:15.446466
# Unit test for function main

# Generated at 2022-06-17 05:34:25.719585
# Unit test for function main

# Generated at 2022-06-17 05:34:35.076038
# Unit test for function main

# Generated at 2022-06-17 05:34:44.196407
# Unit test for function main