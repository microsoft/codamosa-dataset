

# Generated at 2022-06-17 05:28:46.539501
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:28:55.005989
# Unit test for function main

# Generated at 2022-06-17 05:29:05.927350
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:18.143856
# Unit test for function main

# Generated at 2022-06-17 05:29:23.062912
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:29:26.474352
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:29:39.181386
# Unit test for function main

# Generated at 2022-06-17 05:29:43.551453
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:29:55.823854
# Unit test for function main

# Generated at 2022-06-17 05:30:03.582126
# Unit test for function main

# Generated at 2022-06-17 05:30:28.722751
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:30:41.222029
# Unit test for function main

# Generated at 2022-06-17 05:30:54.366035
# Unit test for function main

# Generated at 2022-06-17 05:31:00.917566
# Unit test for function main

# Generated at 2022-06-17 05:31:08.685474
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a single-line value is parsed correctly
    lines = ['Description=My service']
    parsed = parse_systemctl_show(lines)
    assert parsed == {'Description': 'My service'}

    # Test that a multi-line value is parsed correctly
    lines = ['ExecStart={', '  /bin/true', '}']
    parsed = parse_systemctl_show(lines)
    assert parsed == {'ExecStart': '/bin/true'}

    # Test that a multi-line value with a blank line is parsed correctly
    lines = ['ExecStart={', '  /bin/true', '', '}']
    parsed = parse_systemctl_show(lines)
    assert parsed == {'ExecStart': '/bin/true'}

    # Test that a multi-line value with a blank line is parsed correctly

# Generated at 2022-06-17 05:31:23.133755
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert parse_systemctl_show(['foo=bar']) == {'foo': 'bar'}
    assert parse_systemctl_show(['foo=bar', 'baz=qux']) == {'foo': 'bar', 'baz': 'qux'}
    assert parse_systemctl_show(['foo=bar', 'baz=qux', 'quux=corge']) == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge'}
    assert parse_systemctl_show(['foo=bar', 'baz=qux', 'quux=corge', 'grault=garply']) == {'foo': 'bar', 'baz': 'qux', 'quux': 'corge', 'grault': 'garply'}

# Generated at 2022-06-17 05:31:34.792538
# Unit test for function main

# Generated at 2022-06-17 05:31:43.092723
# Unit test for function main

# Generated at 2022-06-17 05:31:54.811928
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:32:03.907983
# Unit test for function main

# Generated at 2022-06-17 05:32:30.260060
# Unit test for function main

# Generated at 2022-06-17 05:32:41.698637
# Unit test for function main

# Generated at 2022-06-17 05:32:49.819498
# Unit test for function main

# Generated at 2022-06-17 05:32:57.259887
# Unit test for function main

# Generated at 2022-06-17 05:33:08.187385
# Unit test for function main

# Generated at 2022-06-17 05:33:23.109164
# Unit test for function main

# Generated at 2022-06-17 05:33:35.862969
# Unit test for function main

# Generated at 2022-06-17 05:33:47.685397
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:33:56.875603
# Unit test for function main

# Generated at 2022-06-17 05:34:07.940807
# Unit test for function main