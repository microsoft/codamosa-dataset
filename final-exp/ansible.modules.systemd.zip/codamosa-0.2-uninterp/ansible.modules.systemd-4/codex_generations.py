

# Generated at 2022-06-17 05:28:39.215295
# Unit test for function main
def test_main():
    # Test with no parameters
    args = dict(
        daemon_reload=True,
    )
    result = dict(
        changed=False,
    )
    module = AnsibleModule(argument_spec=dict())
    module.exit_json(**result)

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 05:28:49.499402
# Unit test for function main

# Generated at 2022-06-17 05:29:01.681830
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a single-line value is parsed correctly
    lines = ['Description=Foo']
    assert parse_systemctl_show(lines) == {'Description': 'Foo'}
    # Test that a multi-line value is parsed correctly
    lines = ['ExecStart={', '  path=/bin/bar', '}']
    assert parse_systemctl_show(lines) == {'ExecStart': '{\n  path=/bin/bar\n}'}
    # Test that a single-line value that starts with { is parsed correctly
    lines = ['Description={Foo']
    assert parse_systemctl_show(lines) == {'Description': '{Foo'}
    # Test that a multi-line value that starts with { is parsed correctly
    lines = ['ExecStart={', '  path=/bin/bar', '}']

# Generated at 2022-06-17 05:29:10.995860
# Unit test for function main

# Generated at 2022-06-17 05:29:24.871036
# Unit test for function main

# Generated at 2022-06-17 05:29:36.297511
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    from ansible.module_utils.systemd import _parse_systemctl_show
    from ansible.module_utils.systemd import _parse_systemctl_list_unit_files
    from ansible.module_utils.systemd import _parse_systemctl_list_units
    from ansible.module_utils.systemd import _parse_systemctl_list_dependencies
    from ansible.module_utils.systemd import _parse_systemctl_show_property
    from ansible.module_utils.systemd import _parse_systemctl_list_unit_files
    from ansible.module_utils.systemd import _parse_systemctl_list_unit_files

# Generated at 2022-06-17 05:29:47.619141
# Unit test for function main

# Generated at 2022-06-17 05:29:59.877278
# Unit test for function main

# Generated at 2022-06-17 05:30:13.635817
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test that a single-line value is parsed correctly
    lines = ['ActiveState=active']
    parsed = parse_systemctl_show(lines)
    assert parsed == {'ActiveState': 'active'}

    # Test that a multi-line value is parsed correctly
    lines = ['ExecStart={', 'path=/usr/bin/foo', 'argv[]=/usr/bin/foo', '}']
    parsed = parse_systemctl_show(lines)
    assert parsed == {'ExecStart': '{\npath=/usr/bin/foo\nargv[]=/usr/bin/foo\n}'}

    # Test that a multi-line value is parsed correctly even if the first line doesn't end with }
    lines = ['ExecStart={', 'path=/usr/bin/foo', 'argv[]=/usr/bin/foo', '}']


# Generated at 2022-06-17 05:30:17.657773
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('ignoring')



# Generated at 2022-06-17 05:30:43.308966
# Unit test for function main

# Generated at 2022-06-17 05:30:56.453534
# Unit test for function main

# Generated at 2022-06-17 05:31:08.689731
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test single-line value
    assert parse_systemctl_show(['Description=foo']) == {'Description': 'foo'}
    # Test multi-line value
    assert parse_systemctl_show(['ExecStart={\n    foo\n}']) == {'ExecStart': '{\n    foo\n}'}
    # Test multi-line value with a single-line value following it
    assert parse_systemctl_show(['ExecStart={\n    foo\n}', 'Description=bar']) == {'ExecStart': '{\n    foo\n}', 'Description': 'bar'}
    # Test multi-line value with a multi-line value following it

# Generated at 2022-06-17 05:31:23.133375
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import sysv_exists
    from ansible.module_utils.systemd import sysv_is_enabled
    from ansible.module_utils.systemd import is_running_service
    from ansible.module_utils.systemd import is_deactivating_service
    from ansible.module_utils.systemd import is_chroot
    from ansible.module_utils.systemd import request_was_ignored
    from ansible.module_utils.systemd import fail_if_missing
    from ansible.module_utils.systemd import parse_systemctl_show
    from ansible.module_utils.systemd import to_native
    from ansible.module_utils.systemd import main

# Generated at 2022-06-17 05:31:31.138223
# Unit test for function main

# Generated at 2022-06-17 05:31:44.218608
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import main
    from ansible.module_utils.systemd import sysv_exists
    from ansible.module_utils.systemd import sysv_is_enabled
    from ansible.module_utils.systemd import is_running_service
    from ansible.module_utils.systemd import is_deactivating_service
    from ansible.module_utils.systemd import is_chroot
    from ansible.module_utils.systemd import request_was_ignored
    from ansible.module_utils.systemd import fail_if_missing
    from ansible.module_utils.systemd import parse_systemctl_show
    from ansible.module_utils.systemd import to_native

# Generated at 2022-06-17 05:31:56.821010
# Unit test for function main

# Generated at 2022-06-17 05:32:07.494553
# Unit test for function main

# Generated at 2022-06-17 05:32:14.566419
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    import sys
    import os

    # set up mock module

# Generated at 2022-06-17 05:32:24.434333
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:32:54.889959
# Unit test for function main

# Generated at 2022-06-17 05:33:07.973799
# Unit test for function main

# Generated at 2022-06-17 05:33:22.982381
# Unit test for function main

# Generated at 2022-06-17 05:33:35.603668
# Unit test for function main

# Generated at 2022-06-17 05:33:47.799129
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    from ansible.module_utils.systemd import main as systemd_main
    import sys

    if not sys.version_info[0] == 2:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

    # Load test data
    with open('systemd_test_data.json') as data_file:
        test_data = json.load(data_file)

    # Load test results
    with open('systemd_test_results.json') as data_file:
        test_results = json.load(data_file)

    # Run tests
    for test in test_data:
        # Create a mock module
        module

# Generated at 2022-06-17 05:33:57.387622
# Unit test for function main

# Generated at 2022-06-17 05:34:07.310310
# Unit test for function main

# Generated at 2022-06-17 05:34:17.431591
# Unit test for function main

# Generated at 2022-06-17 05:34:22.012076
# Unit test for function main

# Generated at 2022-06-17 05:34:29.745075
# Unit test for function main

# Generated at 2022-06-17 05:35:26.675226
# Unit test for function main
def test_main():
    unit = 'sshd.service'

# Generated at 2022-06-17 05:35:36.924497
# Unit test for function main

# Generated at 2022-06-17 05:35:46.917197
# Unit test for function main

# Generated at 2022-06-17 05:35:55.416328
# Unit test for function main

# Generated at 2022-06-17 05:36:03.392864
# Unit test for function main

# Generated at 2022-06-17 05:36:08.933277
# Unit test for function main

# Generated at 2022-06-17 05:36:22.943136
# Unit test for function main

# Generated at 2022-06-17 05:36:31.761342
# Unit test for function main

# Generated at 2022-06-17 05:36:41.768755
# Unit test for function main

# Generated at 2022-06-17 05:36:52.066125
# Unit test for function main