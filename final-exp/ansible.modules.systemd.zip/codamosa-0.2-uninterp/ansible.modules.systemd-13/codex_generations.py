

# Generated at 2022-06-17 05:28:56.348971
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test a multi-line value
    lines = [
        'Id=crond.service',
        'ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
        'ExecReload={ path=/bin/kill ; argv[]=/bin/kill -HUP $MAINPID ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }',
    ]
    parsed = parse_systemctl_show(lines)
    assert parsed['Id'] == 'crond.service'
   

# Generated at 2022-06-17 05:29:06.519075
# Unit test for function main

# Generated at 2022-06-17 05:29:18.628721
# Unit test for function main

# Generated at 2022-06-17 05:29:25.133244
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:29:36.518463
# Unit test for function main

# Generated at 2022-06-17 05:29:41.218264
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored('ignoring request')
    assert request_was_ignored('ignoring command')
    assert not request_was_ignored('=')
    assert not request_was_ignored('foo')



# Generated at 2022-06-17 05:29:53.923217
# Unit test for function main

# Generated at 2022-06-17 05:30:02.462704
# Unit test for function main

# Generated at 2022-06-17 05:30:14.678320
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:30:23.493313
# Unit test for function main

# Generated at 2022-06-17 05:30:46.000479
# Unit test for function main

# Generated at 2022-06-17 05:30:56.939319
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:31:09.159864
# Unit test for function main

# Generated at 2022-06-17 05:31:23.376687
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:31:31.300481
# Unit test for function main

# Generated at 2022-06-17 05:31:44.360675
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = [
        'Id=foo.service',
        'Description=This is a test',
        'ExecStart={',
        '  /bin/true',
        '}',
        'ExecReload={',
        '  /bin/true',
        '}',
        'ExecStop={',
        '  /bin/true',
        '}',
        'ExecStartPost={',
        '  /bin/true',
        '}',
        'ExecStartPre={',
        '  /bin/true',
        '}',
        'ExecStopPost={',
        '  /bin/true',
        '}',
        'ExecStopPre={',
        '  /bin/true',
        '}',
    ]

# Generated at 2022-06-17 05:31:56.919315
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:32:04.641731
# Unit test for function main

# Generated at 2022-06-17 05:32:17.597069
# Unit test for function main

# Generated at 2022-06-17 05:32:29.667827
# Unit test for function main

# Generated at 2022-06-17 05:33:56.478895
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test with a single-line value
    lines = ['Description=Command Scheduler']
    assert parse_systemctl_show(lines) == {'Description': 'Command Scheduler'}

    # Test with a multi-line value
    lines = ['ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }']

# Generated at 2022-06-17 05:34:05.878571
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    from ansible.module_utils.systemd import _parse_systemctl_show
    from ansible.module_utils.systemd import _parse_systemctl_list_unit_files
    from ansible.module_utils.systemd import _parse_systemctl_list_units
    from ansible.module_utils.systemd import _parse_systemctl_show_property
    from ansible.module_utils.systemd import _parse_systemctl_list_dependencies
    from ansible.module_utils.systemd import _parse_systemctl_list_sockets
    from ansible.module_utils.systemd import _parse_systemctl_list_timers
    from ansible.module_utils.systemd import _

# Generated at 2022-06-17 05:34:17.334044
# Unit test for function main

# Generated at 2022-06-17 05:34:28.657650
# Unit test for function main

# Generated at 2022-06-17 05:34:35.507505
# Unit test for function main

# Generated at 2022-06-17 05:34:44.474036
# Unit test for function main

# Generated at 2022-06-17 05:34:54.723969
# Unit test for function main

# Generated at 2022-06-17 05:35:03.184985
# Unit test for function main

# Generated at 2022-06-17 05:35:08.205649
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:35:15.334997
# Unit test for function main

# Generated at 2022-06-17 05:36:01.842716
# Unit test for function main

# Generated at 2022-06-17 05:36:10.552317
# Unit test for function main

# Generated at 2022-06-17 05:36:20.559629
# Unit test for function main

# Generated at 2022-06-17 05:36:26.989059
# Unit test for function main

# Generated at 2022-06-17 05:36:38.075172
# Unit test for function main

# Generated at 2022-06-17 05:36:50.025015
# Unit test for function main

# Generated at 2022-06-17 05:37:01.676770
# Unit test for function main

# Generated at 2022-06-17 05:37:11.333788
# Unit test for function parse_systemctl_show

# Generated at 2022-06-17 05:37:17.880423
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.systemd import *
    module = AnsibleModule(argument_spec={})
    assert main() == module.exit_json(**result)

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 05:37:24.284109
# Unit test for function main