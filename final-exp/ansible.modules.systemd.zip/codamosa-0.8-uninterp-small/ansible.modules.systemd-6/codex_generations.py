

# Generated at 2022-06-25 03:27:51.296711
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    print('=== Test: test_parse_systemctl_show ===')


# Generated at 2022-06-25 03:27:55.251913
# Unit test for function request_was_ignored
def test_request_was_ignored():
    var_0 = "maintenance"
    assert("ignoring request" in var_0)


# Generated at 2022-06-25 03:28:03.860076
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:28:09.360972
# Unit test for function main
def test_main():
    # TODO: Add the test cases for other functions in the file once test cases have been written
    test_case_0()

if __name__ == '__main__':
    unit_test = unittest.main(exit=False)

    # Unit test for function main
    test_main()

    sys.modules.clear()

    # Run the main function
    main()

# Generated at 2022-06-25 03:28:20.202016
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:28:23.893094
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        import traceback
        print(traceback.format_exc())


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:28:25.119763
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:35.626620
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():

    # Set up test data
    lines = ['ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT']
    lines.append('ActiveEnterTimestampMonotonic=8135942')
    lines.append('ActiveExitTimestampMonotonic=0')
    lines.append('ActiveState=active')
    lines.append('After=auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice')
    lines.append('AllowIsolate=no')
    lines.append('Before=shutdown.target multi-user.target')
    lines.append('BlockIOAccounting=no')
    lines.append('BlockIOWeight=1000')
    lines.append('CPUAccounting=no')
    lines.append('CPUSchedulingPolicy=0')
    lines

# Generated at 2022-06-25 03:28:36.519488
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        raise


# Generated at 2022-06-25 03:28:46.529306
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        import traceback
        traceback.print_exc()

# main() idiom for importing into REPL for debugging
if __name__ == "__main__":
    # main() idiom for importing into REPL for debugging
    try:
        if sys.argv[1] == '-t':
            test_main()
        else:
            main()
    except:
        import traceback
        traceback.print_exc()
        # main() idiom for importing into REPL for debugging
        try:
            sys.stderr.flush()
            sys.stdout.flush()
        except:
            pass
        sys.stderr.write("\nexit code 1\n")
        sys.exit(1)
    sys.exit(0)

# Generated at 2022-06-25 03:29:08.842666
# Unit test for function main
def test_main():
    test_cases = [0]
    for test_case in test_cases:
        print("Starting unit test for case " + str(test_case))
        if test_case == 0:
            test_case_0()
        else:
            print("Unknown test case specified " + str(test_case))


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:29:18.002787
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    module_dummy_args = dict(
        name='crond.service',
        state='started',
        daemon_reload=False,
        daemon_reexec=False,
        changed=False,
        enabled=True,
        force=False,
        masked=False,
    )
    module_dummy = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Test case 1

# Generated at 2022-06-25 03:29:26.877861
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:29:29.729719
# Unit test for function main
def test_main():
    failure_count, test_count = doctest.testmod()
    assert test_count > 0
    # assert failure_count == 0, "Doc tests failed."
    # assert failure_count == 0, "Doc tests failed."

if __name__ == '__main__':
    #test_main()
    #test_case_0()
    main()

# Generated at 2022-06-25 03:29:33.427004
# Unit test for function main
def test_main():
    global ansibullbot_debug
    global ansibullbot_message
    # Set the test specific variables
    try:
        del os.environ['ANSIBLE_ROLES_PATH']
    except KeyError:
        pass

    ansibullbot_debug = True
    ansibullbot_message = "Missing module docstring"

    # Call test case function
    test_case_main(0)


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:29:40.136034
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Read input file
    input_file = open("test_input/test0_input.txt", 'r')
    lines = input_file.readlines()
    # Run function
    result = parse_systemctl_show(lines)
    # Drop first line
    del lines[0]
    # Read expected output file
    expected_output_file = open("test_input/test0_expected_output.txt", 'r')
    expected_output = expected_output_file.read().rstrip()
    # Compare result and expected output
    result_str = str(result).strip() == expected_output
    # Return boolean result
    return result_str


# Generated at 2022-06-25 03:29:46.641076
# Unit test for function main
def test_main():
    mocked_ansible_module = AnisbleMock(mocked_module_args, exit_json=exit_json, fail_json=fail_json)
    mocked_ansible_module.run_command = MagicMock(side_effect=run_command)
    mocked_ansible_module.get_bin_path = MagicMock(side_effect=get_bin_path)
    mocked_ansible_module.run_command.return_value = 0, "", ""
    mocked_ansible_module.parse_systemctl_show = MagicMock(side_effect=parse_systemctl_show)
    mocked_ansible_module.sysv_exists = MagicMock(side_effect=sysv_exists)

# Generated at 2022-06-25 03:29:54.513548
# Unit test for function main
def test_main():
    my_list = ['ansible.modules.system.service']
    import ansible.modules.system.service
    my_list.append(ansible.modules.system.service)
    if main() != my_list:
        return False
    return True

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:29:56.252281
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:30:04.340509
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")
    assert request_was_ignored("ignoring command")
    assert request_was_ignored("= ignoring command")
    assert request_was_ignored("a= ignoring command")
    assert request_was_ignored("a=b ignoring command")
    assert request_was_ignored("a=bignoring command")
    assert request_was_ignored("a=b c ignoring command")
    assert request_was_ignored("a=b c=d ignoring command")
    assert request_was_ignored("/etc/systemd/system/display-manager.service:7 ignoring request")
    assert request_was_ignored("b/c/ddd=eef/g/h=i ignoring command")

    assert not request_was_ignored("a=b")

# Generated at 2022-06-25 03:30:28.700896
# Unit test for function main
def test_main():
    print('Running unit test for main')
    main()


# Generated at 2022-06-25 03:30:30.381237
# Unit test for function main
def test_main():
    result = main()
    assert result == 0

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 03:30:34.765548
# Unit test for function main
def test_main():
    # test case 0
    test_case_0()

'''
test_main()
'''

main()

# Generated at 2022-06-25 03:30:37.000857
# Unit test for function main
def test_main():
    # Run main function
    var_0 = main()
    # Assertions
    assert True

# Generated at 2022-06-25 03:30:41.220761
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except AnsibleModule.AnsibleModuleStub.UnsupportedVersion as f:
        if f.args[0] == 71528:
            return
        raise


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:30:46.578488
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:30:49.486503
# Unit test for function main
def test_main():
    assert main() == None


if __name__ == '__main__':
    # test_case_0()
    test_main()

# Generated at 2022-06-25 03:31:01.912374
# Unit test for function main

# Generated at 2022-06-25 03:31:12.909823
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:31:23.028088
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    value_0 = (parse_systemctl_show(['LoadState=loaded','Id=who.service','Description=Who Dat','ActiveState=inactive','UnitFileState=enabled'])["UnitFileState"] == 'enabled')
    if (value_0):
        value_0 = (parse_systemctl_show(['LoadState=loaded','Id=who.service','Description=Who Dat','ActiveState=inactive','UnitFileState=enabled'])["UnitFileState"] != 'disabled')
        if (value_0):
            value_0 = True
        else:
            value_0 = False
    return value_0


# Generated at 2022-06-25 03:31:54.130864
# Unit test for function main
def test_main():
    var_0 = main()
    assert isinstance(var_0, dict)
    assert len(var_0) == 3


# Generated at 2022-06-25 03:31:59.708354
# Unit test for function main
def test_main():
    with patch('os.path.exists'):
        with patch('os.stat'):
            with patch('ansible.module_utils.basic.AnsibleModule.run_command') as patched_run_command:
                patched_run_command.return_value = (0, 'stdout', 'stderr')

# Generated at 2022-06-25 03:32:05.619977
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print ("Exception caught in main unit test")
        return False
    else:
        return True

if __name__ == '__main__':
    if not test_main():
        sys.exit(1)

# Generated at 2022-06-25 03:32:13.789821
# Unit test for function main
def test_main():
    pass

#unit_test = unittest.TestSuite()
#unit_test.addTest(unittest.makeSuite(test_case_0))
#unit_test.addTest(unittest.makeSuite(test_main))
#runner = unittest.TextTestRunner()
#runner.run(unit_test)

# Generated at 2022-06-25 03:32:22.174495
# Unit test for function main
def test_main():
    # Stub out a class for the main return value
    class StubMainRet(object):
        def __init__(self, state=None, enabled=None, masked=None, daemon_reload=None, daemon_reexec=None, scope=None, no_block=None):
            self.state = state
            self.enabled = enabled
            self.masked = masked
            self.daemon_reload = daemon_reload
            self.daemon_reexec = daemon_reexec
            self.scope = scope
            self.no_block = no_block

    # Create instance of class
    main_ret = StubMainRet()

    # Create mock module
    mock_module = MagicMock()

    # Create mock class
    mock_AnsibleModule = MagicMock()

# Generated at 2022-06-25 03:32:26.575846
# Unit test for function main
def test_main():
    # Test case 0
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:32:30.945333
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # file = open('/home/system-init/workspace/ansible/module_utils/systemd/service.py', 'r')
    file = open('/home/system-init/workspace/ansible/module_utils/systemd/service.py', 'r')
    parsed = parse_systemctl_show(file)
    print(parsed)


# Generated at 2022-06-25 03:32:42.625404
# Unit test for function main
def test_main():
    ansible_options = {'_ansible_check_mode': False, '_ansible_no_log': False}
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_module.params = {
        'name': 'zabbix-agent',
        'state': 'started',
        'enabled': True,
        'force': True,
        'masked': False,
        'daemon_reload': True,
        'daemon_reexec': False,
        'scope': 'system',
    }
    test_module.run_command = mock_run_command
    test_module.get_bin_path = mock_get_bin_path
    test_module.get_service_paths = mock_get_service_paths
    test_module.warn

# Generated at 2022-06-25 03:32:47.277545
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    var_0 = parse_systemctl_show(["ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT", "ActiveEnterTimestampMonotonic=8135942"])
    if var_0 != {'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT', 'ActiveEnterTimestampMonotonic': '8135942'}:
        raise Exception('Incorrect return value for test_parse_systemctl_show()')
    var_1 = parse_systemctl_show(["ActiveExitTimestampMonotonic=0", "ActiveState=active"])
    if var_1 != {'ActiveExitTimestampMonotonic': '0', 'ActiveState': 'active'}:
        raise Exception('Incorrect return value for test_parse_systemctl_show()')
    var_2 = parse_systemctl

# Generated at 2022-06-25 03:32:52.481005
# Unit test for function main
def test_main():
    var_0 = OrderedDict()
    var_0['name'] = "/etc/init.d/systemd-logind"
    var_0['state'] = "reloaded"
    var_0['enabled'] = None
    var_0['masked'] = None
    var_0['daemon_reload'] = False
    var_0['daemon_reexec'] = False
    var_0['scope'] = "system"
    var_0['no_block'] = False
    var_0['force'] = None
    var_1 = main(argument_spec=var_0)


# Generated at 2022-06-25 03:33:24.162691
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:33:25.859006
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:33:31.395037
# Unit test for function main
def test_main():
    pass

# Entry point for program
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:33:37.302692
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print("Exception: %s" % e)
        import traceback
        traceback.print_exc()
        assert False


# Generated at 2022-06-25 03:33:48.010126
# Unit test for function main
def test_main():
    with open(os.devnull, "w") as fnull:
        with mock.patch('ansible.module_utils.basic.AnsibleModule.exit_json', side_effect=None) as mock_exit_json:
            with mock.patch('ansible.module_utils.basic.AnsibleModule.fail_json', side_effect=None) as mock_fail_json:
                with mock.patch('ansible.module_utils.basic.AnsibleModule.run_command') as mock_run_command:
                    test_case_0(mock_exit_json, mock_fail_json, mock_run_command)
                    mock_exit_json.assert_called_with(**{
                        "name": None,
                        "changed": False,
                        "status": {}
                    })


# Generated at 2022-06-25 03:33:58.073130
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:33:58.851128
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_case_0()

# Generated at 2022-06-25 03:34:01.760526
# Unit test for function main
def test_main():
    testvar = 'test'
    assert testvar == main()


# Generated at 2022-06-25 03:34:05.222875
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    with open(os.path.dirname(os.path.realpath(__file__)) + '/systemctl_show_output.txt', 'r') as f:
        lines = f.read().splitlines()
        parsed = parse_systemctl_show(lines)
        assert 'Description' in parsed
        assert 'ExecStart' in parsed
        assert 'ExecMainPID' in parsed

# Actual code execution

# Generated at 2022-06-25 03:34:07.598498
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        return 1

# Unit test execution
if __name__ == "__main__":
    ret = test_main()
    sys.exit(ret)

# Generated at 2022-06-25 03:35:03.512613
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:35:10.893749
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:35:20.031419
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:35:33.875339
# Unit test for function main
def test_main():
    # Mock the systemctl binary
    if sys.version_info >= (3, 0):
        mock_module = mock.MagicMock()
    else:
        mock_module = mock.Mock()
    mock_module.get_bin_path.return_value = 'systemctl'

    # Mock the module.run_command
    if sys.version_info >= (3, 0):
        mock_module.run_command = mock.MagicMock()
    else:
        mock_module.run_command = mock.Mock()

    # Mock the result of the module.run_command

# Generated at 2022-06-25 03:35:36.393520
# Unit test for function main

# Generated at 2022-06-25 03:35:44.143859
# Unit test for function main
def test_main():
    var_0= {}
    os.environ['MANPAGER'] = '/usr/bin/less -r'
    os.environ['LANG'] = 'en_GB.UTF-8'
    os.environ['LESS'] = '-R'
    os.environ['XDG_RUNTIME_DIR'] = '/run/user/1000'
    os.environ['LC_PAPER'] = 'en_GB.UTF-8'
    os.environ['COLORTERM'] = 'truecolor'
    os.environ['LC_ADDRESS'] = 'en_GB.UTF-8'
    os.environ['LC_MONETARY'] = 'en_GB.UTF-8'

# Generated at 2022-06-25 03:35:52.886793
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    Test_case_0 = {}
    Test_case_0['lines'] = [ 'LoadState=loaded', 'ActiveState=active', 'SubState=running', 'UnitFileState=enabled', 'Description=Ansible module test 0', 'ExecStart=/usr/bin/pwd' ]
    Expected_output_0 = { 'LoadState': 'loaded', 'ActiveState': 'active', 'SubState': 'running', 'UnitFileState': 'enabled', 'Description': 'Ansible module test 0', 'ExecStart': '/usr/bin/pwd' }
    Actual_output_0 = parse_systemctl_show(Test_case_0['lines'])

# Generated at 2022-06-25 03:36:02.022634
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as err:
        print("Error: exception occurred: " + str(err))
        traceback.print_exc()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:36:03.960437
# Unit test for function main
def test_main():
    main()
    
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:36:08.322543
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Uncomment this line to save the output of the test to a file
    # parse_systemctl_show_output = open("/tmp/parse_systemctl_show_output", "w")
    # file.write(str(parse_systemctl_show(lines))) # NOQA
    # file.close() # NOQA
    # lines = ""
    pass
