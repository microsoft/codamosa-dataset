

# Generated at 2022-06-25 03:27:43.795786
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:27:49.907370
# Unit test for function main
def test_main():
    test_case_0()


# -------------------------------------------
# Recursive call stack:
# (most recent call first)
#
# AnsibleModule.exit_json
# test_main
# main
#   fail_if_missing
#
# AnsibleModule.fail_json
#   AnsibleModule._load_params
#     AnsibleModule._load_params_defaults
#       _load_params_defaults_missing
#         AnsibleModule.fail_json
#         fail_if_missing
#
# AnsibleModule.fail_json
#   AnsibleModule._load_params
#     AnsibleModule._load_params_defaults
#       _load_params_defaults_missing
#         AnsibleModule.fail_json
#         fail_if_missing
#
# AnsibleModule.fail_json
#   AnsibleModule

# Generated at 2022-06-25 03:28:01.641826
# Unit test for function main
def test_main():
    # Define a dictionary containing command line arguments
    input0 = {'masked': False, 'scope': 'system', 'no_block': False, 'enabled': True, 'daemon_reload': False, 'daemon_reexec': False, 'state': None, 'force': False, 'name': 'Inventory service'}
    input1 = {'masked': False, 'scope': 'system', 'no_block': False, 'enabled': False, 'daemon_reload': False, 'daemon_reexec': False, 'state': 'stopped', 'force': False, 'name': 'Inventory service'}

# Generated at 2022-06-25 03:28:03.507362
# Unit test for function main
def test_main():
    var_0 = main()
    # AssertionError: unexpected return code -1 != 0
    assert var_0 == 0, "Unexpected return code %s" % var_0


# Generated at 2022-06-25 03:28:09.426656
# Unit test for function request_was_ignored
def test_request_was_ignored():
    out = 'Synchronizing state of httpd.service with SysV service script with /usr/lib/systemd/systemd-sysv-install.Executing: /usr/lib/systemd/systemd-sysv-install enable httpd'
    assert request_was_ignored(out) == False
    out = 'Synchronizing state of httpd.service with SysV service script with /usr/lib/systemd/systemd-sysv-install.Executing: /usr/lib/systemd/systemd-sysv-install enable httpdIgnoring operation, unit httpd.service failed to load.'
    assert request_was_ignored(out) == True

# Generated at 2022-06-25 03:28:17.090595
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    if(case_parse_systemctl_show_0()):
        print("Test case 0 passed")
        return True
    else:
        print("Test case 0 failed")
        return False

# Generated at 2022-06-25 03:28:20.097922
# Unit test for function main
def test_main():
    try:
        var_0 = main()
    except Exception as e:
        print('Exception: ' + str(e))
        exit(1)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print('Exception: ' + str(e))
        exit(1)

# Generated at 2022-06-25 03:28:25.267798
# Unit test for function main
def test_main():
    # Setup
    test_dir = os.path.dirname(__file__)
    test_file = os.path.join(test_dir, 'unit/main.yml')
    test_result = 'result.yml'
    test_run = AnsibleModule(
        argument_spec=load_yaml(test_file),
    )

    # Execute
    test_run.mock_executor(True)

    # Verify
    assert test_run.is_executed
    assert test_run.result == load_yaml(test_result)


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:28:35.740717
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    output = ['{ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }', 'Description=Command Scheduler', 'Requires=basic.target']
    expected = {'ExecStart': '{ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }', 'Description': 'Command Scheduler', 'Requires': 'basic.target'}
    actual = parse_systemctl_show(output)


# Generated at 2022-06-25 03:28:36.499005
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:28:58.867216
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:29:09.842762
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:29:11.269583
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:29:14.719030
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    file = open('systemd_test.json', 'r')
    var_0 = file.readlines()
    var_1 = parse_systemctl_show(var_0)
    print(var_1)

# main

# Generated at 2022-06-25 03:29:18.104042
# Unit test for function request_was_ignored
def test_request_was_ignored():
    test_case_0()

# vim:ts=4:sts=4:sw=4:et

# Generated at 2022-06-25 03:29:26.975042
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    service_status = open('ansible/test_cases/ansible_builtin_systemd/parse_systemctl_show_test_case', 'r').readlines()

# Generated at 2022-06-25 03:29:30.547779
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Test case #0
    test_case_0()



# Generated at 2022-06-25 03:29:31.494967
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert callable(parse_systemctl_show)


# Generated at 2022-06-25 03:29:35.059807
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None, "Expected value: None"

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:29:35.842848
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 03:30:17.581662
# Unit test for function main
def test_main():
    var = main(module=[], name=None, state=None, enabled=None, masked=None, daemon_reload=False, daemon_reexec=False, scope=u'system', no_block=False)
    assert var == 0

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:30:19.671390
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:30:26.151895
# Unit test for function main
def test_main():
    # Arrange
    arg0 = type('arg0', (), {'params': {'no_block': False, 'masked': False, 'unit': None, 'enabled': False, 'force': False, 'scope': 'system', 'state': 'reloaded', 'daemon_reload': False, 'daemon_reexec': False}})

    # Act
    var_0 = main(arg0)

    # Assert
    assert var_0 is None


# Generated at 2022-06-25 03:30:36.001156
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Read contents of file f_1_1 into a string
    test_file_0 = open("test_files/test_file_parse_systemctl_show", "r")
    f_1_1_string = test_file_0.read()
    test_file_0.close()
    var_1 = parse_systemctl_show(f_1_1_string)
    # var_1 should be a dict
    var_2 = True
    if not isinstance(var_1, dict):
        var_2 = False
    if not var_2:
        raise Exception("Test case 1 failed: expected {}, got {}".format(True, var_2))
    var_3 = var_1['ExecStart']
    # var_3 should be equal to "{ path=/usr/bin/httpd ; argv[]=/usr/

# Generated at 2022-06-25 03:30:46.072743
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        pass

if __name__ == '__main__':
    from ansible.module_utils.basic import *

    # Main module processing
    #
    # Note:
    # ValueError: invalid task action
    # 原因是在： ansible/playbook/play_iterator.py: 中
    # self.action._load_actions()
    # 'systemd': AnsibleModule(argument_spec=dict(
    #     name=dict(type='str', aliases=['service', 'unit']),
    #     state=dict(type='str', choices=['reloaded', 'restarted', 'started', 'stopped']),
    #     enabled=dict(type='bool'),
    #     force=dict(type='bool'),
   

# Generated at 2022-06-25 03:30:47.979613
# Unit test for function main
def test_main():
    print("test_main")
    test_case_0()


# Generated at 2022-06-25 03:30:56.124133
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:31:10.065500
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:31:13.094108
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        pass

# Main function
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:31:20.830960
# Unit test for function request_was_ignored
def test_request_was_ignored():
    var_0 = compile("")
    var_1 = compile("")
    var_2 = compile("")
    var_3 = compile("")

# Generated at 2022-06-25 03:32:41.888712
# Unit test for function main
def test_main():
    import doctest
    from ansible.module_utils.basic import AnsibleModule

    test = doctest.testmod(verbose=True, optionflags=(doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS))
    assert test.failed == 0, "Failed: %s" % test.failed

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:32:47.857228
# Unit test for function request_was_ignored
def test_request_was_ignored():
    var_0 = '=' not in out
    var_1 = ('ignoring request' in out or 'ignoring command' in out)
    var_2 = '=' in out
    var_3 = ('ignoring request' not in out) and ('ignoring command' not in out)

    if var_0 == True:
        if var_1 == True:
            return True
        else:
            return False
    else:
        if var_2 == True:
            if var_3 == True:
                return False
            else:
                return True
        else:
            return False


# Generated at 2022-06-25 03:32:50.441543
# Unit test for function main
def test_main():
    try:
        assert(main() == None)
    except AssertionError as e:
        raise(e)


# Test runner for test_main()

# Generated at 2022-06-25 03:32:58.634938
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():

    var_1 = 'ActiveEnterTimestamp'
    var_2 = 'Sun 2016-05-15 18:28:49 EDT'
    var_3 = 'ActiveEnterTimestampMonotonic'
    var_4 = '8135942'
    var_5 = 'ActiveExitTimestampMonotonic'
    var_6 = '0'
    var_7 = 'ActiveState'
    var_8 = 'active'
    var_9 = 'After'
    var_10 = 'auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice'
    var_11 = 'AllowIsolate'
    var_12 = 'no'
    var_13 = 'Before'
    var_14 = 'shutdown.target multi-user.target'
    var_

# Generated at 2022-06-25 03:33:03.814922
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print(str(e).rstrip('\r\n'))
        return(1)

# Run unit tests
if __name__ == '__main__':
    sys.exit(test_main())

# Generated at 2022-06-25 03:33:04.568864
# Unit test for function main
def test_main():
  assert(True)


# Generated at 2022-06-25 03:33:11.046851
# Unit test for function main

# Generated at 2022-06-25 03:33:19.062827
# Unit test for function main
def test_main():
    var_1 = {
        'check_mode': False,
        'daemon_reexec': False,
        'daemon_reload': False,
        'enabled': None,
        'force': False,
        'masked': None,
        'name': 'thin.service',
        'no_block': False,
        'scope': 'system',
        'state': 'reloaded',
    }

# Generated at 2022-06-25 03:33:28.544875
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    print("test")

# Generated at 2022-06-25 03:33:36.026917
# Unit test for function main
def test_main():
    var_0 = {'unit': 'test', 'mask': 'test'}
    os.environ['XDG_RUNTIME_DIR'] = 'test'
    if not os.path.exists('/usr/bin/systemctl'):
        with open('/usr/bin/systemctl', 'w'):
            pass

    if not os.path.exists('/usr/sbin/service'):
        with open('/usr/sbin/service', 'w'):
            pass

    if not os.path.exists('/usr/sbin/chkconfig'):
        with open('/usr/sbin/chkconfig', 'w'):
            pass


# Generated at 2022-06-25 03:35:08.912091
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:35:11.001388
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # file_path = 'systemctl-show.txt'
    # lines = open(file_path).readlines()
    # result = parse_systemctl_show(lines)
    # assert result
    # assert isinstance(result, dict)
    assert True



# Generated at 2022-06-25 03:35:16.494424
# Unit test for function main
def test_main():
    with patch(__name__+".main") as mocked_main:
        mocked_main.return_value = None
        test_case_0()
        mocked_main.assert_called()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:35:18.069405
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as _ex:
        print('Test system_main.py failed to call sys.exit')



# Generated at 2022-06-25 03:35:25.057156
# Unit test for function main
def test_main():
    # First test case
    args = (
        'systemctl',
        {'daemon_reload': False, 'no_block': False, 'enabled': None, 'daemon_reexec': False, 'state': None, 'force': False, 'name': None, 'masked': None, 'scope': 'system'}
    )
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:35:25.882712
# Unit test for function main
def test_main():
    var_0 = main()
    assert True == True


# Generated at 2022-06-25 03:35:33.430559
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    var_0 = parse_systemctl_show(["ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT"])
    if str(var_0) != "{'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT'}":
        print('Failed test_parse_systemctl_show')
        print('Expected: ' + str({'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT'}) + '; Received: ' + str(var_0))


# Generated at 2022-06-25 03:35:36.819948
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    lines = '''
    MainPID=595
    MemoryAccounting=no
    MemoryLimit=18446744073709551615
    '''
    res_0 = parse_systemctl_show(lines)
    assert res_0 == {
        'MainPID': '595',
        'MemoryAccounting': 'no',
        'MemoryLimit': '18446744073709551615'
    }

if __name__ == '__main__':
    test_parse_systemctl_show()



# Generated at 2022-06-25 03:35:44.447787
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:35:49.922524
# Unit test for function main
def test_main():

    class AnsibleModule(object):
        module = None
        arguments = None
        fail_json = None
        exit_json = None
        fail_on_missing_params = None
        check_mode = None

    def fail_json(*args, **kwargs):
        raise Exception()

    def exit_json(*args, **kwargs):
        return_value = {'changed': False, 'ansible_facts': {}}
        if 'rc' in kwargs:
            return_value.update({'rc': kwargs['rc']})
        raise SystemExit(json.dumps(return_value))

    main.AnsibleModule = AnsibleModule
    main.exit_json = exit_json
    main.fail_json = fail_json
    main.main()



# Generated at 2022-06-25 03:37:10.889050
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    with open('./data/unit_test_data/parse_systemctl_show', 'r') as f:
        lines = f.read().splitlines()

    case_res = parse_systemctl_show(lines)