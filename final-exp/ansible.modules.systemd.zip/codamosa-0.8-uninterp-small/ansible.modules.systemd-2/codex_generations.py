

# Generated at 2022-06-25 03:27:37.626937
# Unit test for function main

# Generated at 2022-06-25 03:27:39.781302
# Unit test for function request_was_ignored
def test_request_was_ignored():
    var_0 = main()
    assert var_0 == 1, "1"


# Generated at 2022-06-25 03:27:51.274551
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Correct return if input is a string
    lines = '''ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT
ActiveEnterTimestampMonotonic=8135942
ActiveExitTimestampMonotonic=0'''
    expected_out = {'ActiveEnterTimestamp': 'Sun 2016-05-15 18:28:49 EDT', 'ActiveExitTimestampMonotonic': '0', 'ActiveEnterTimestampMonotonic': '8135942'}
    parsed = parse_systemctl_show(lines)
    assert parsed == expected_out, to_native(parsed)

    # Correct return if input is a list

# Generated at 2022-06-25 03:27:56.242521
# Unit test for function request_was_ignored
def test_request_was_ignored():
    var_0 = '=' not in None and ('ignoring request' in None or 'ignoring command' in None)
    assert var_0 == True


# Generated at 2022-06-25 03:28:05.078507
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # str -> dict
    # single line key, single line value
    result = parse_systemctl_show(['key1=value1'])
    assert result == {'key1': 'value1'}

    # single line key, multiple line value
    result = parse_systemctl_show(['key1=value1\nvalue2\nvalue3'])
    assert result == {'key1': 'value1\nvalue2\nvalue3'}

    # multiple line key, single line value
    result = parse_systemctl_show(['key1=value1', 'key2=value2'])
    assert result == {'key1': 'value1', 'key2': 'value2'}

    # multiple line key, single line value starting with '{' but not ending with '}'
    result = parse_systemctl_

# Generated at 2022-06-25 03:28:08.527477
# Unit test for function main
def test_main():
    var_1 = AnsibleModule([
        'name=foo',
        'state=started',
        'scope=system',
        'enabled=no',
        'masked=yes',
        'daemon_reload=yes',
        'daemon_reexec=yes',
        'no_block=yes',
    ])
    result = main(var_1)
    assert result[0] == 0


# Generated at 2022-06-25 03:28:10.618060
# Unit test for function main
def test_main():
    '''
    Unit test for function main
    '''
    assert True == False

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 03:28:17.154619
# Unit test for function main
def test_main():
    with mock.patch.object(AnsibleModule, 'run_command', return_value=(0, b'', b'')):
        test_case_0()

if __name__ == '__main__':
    # Unit test for function main
    test_main()

# Generated at 2022-06-25 03:28:19.099294
# Unit test for function main
def test_main():
    var_0 = 'linux'
    var_1 = main()
    # assert var_1 == 'linux'

main()

# Generated at 2022-06-25 03:28:21.872011
# Unit test for function request_was_ignored
def test_request_was_ignored():
    # Setup
    out = '='

    # Exercise
    var_0 = request_was_ignored(out)

    # Verify
    var_0 = False


# Generated at 2022-06-25 03:28:35.455144
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 03:28:46.099631
# Unit test for function main

# Generated at 2022-06-25 03:28:56.923850
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:29:08.934670
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:29:18.929607
# Unit test for function main
def test_main():
    # Mock AnsibleModule
    module = MagicMock(version="ansible 2.11.0")
    module.run_command.return_value = (0, 'foo', 'bar')
    module.check_mode = False
    module.debug = False
    module.fail_json = MagicMock(side_effect=AnsibleExitJson(msg='fail', rc=5, changed=False))
    module.exit_json = MagicMock(side_effect=AnsibleExitJson(msg='done', changed=False))

    # Mock os.path.exists
    mock_exists = MagicMock(return_value=False)
    monkeypatch.setattr('os.path.exists', mock_exists)

    # Mock os.path.isdir

# Generated at 2022-06-25 03:29:27.402615
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    module = AnsibleModule({})

# Generated at 2022-06-25 03:29:28.415320
# Unit test for function main
def test_main():
    var_0 = main()
    assert True == var_0

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:29:29.787574
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():

    # Set up test inputs
    lines = []

    retval = parse_systemctl_show(lines)


###
# Testcases for main execution sequence.
###


# Generated at 2022-06-25 03:29:38.378448
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:29:39.909044
# Unit test for function main
def test_main():
    var_0 = main()
    print(var_0)

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:30:04.668565
# Unit test for function main
def test_main():
    # Test that the main function returns the expected value
    module_args = {
        "name": "test_service",
        "state": None,
        "enabled": False,
        "force": False,
        "masked": False,
        "daemon_reload": False,
        "daemon_reexec": False,
        "scope": "system",
        "no_block": False
    }
    sys.modules['ansible.module_utils.basic'] = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule = Mock()
    sys.modules['ansible.module_utils.basic'].AnsibleModule.side_effect = [AnsibleModule]


# Generated at 2022-06-25 03:30:09.833452
# Unit test for function request_was_ignored
def test_request_was_ignored():
    result = request_was_ignored(out)
    print(result)

if __name__ == '__main__':
    test_case_0()
    test_request_was_ignored()


# Generated at 2022-06-25 03:30:10.640397
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored("ignoring request")


# Generated at 2022-06-25 03:30:11.982427
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    assert func_0() == func_1()


# Generated at 2022-06-25 03:30:22.121759
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_case_0()

# Generated by the gcovr tool.
# To use it, install gcovr (e.g. via pip) and run
#
#   gcovr -r . -e ".*python.*"
#
# in this directory.
#
# Also see:
#
#   http://lcov.sourceforge.net/
#
# Total objects considered:
#   52
#
# Total functions:
#   52
#
# Total executed lines:
#   573
#
# Total executable lines:
#   707
#
# Total sum of executed lines:
#   840
#
# GCOV report for "modules/systemd/systemd.py"
# Created by gcovr v4.1-25

# Generated at 2022-06-25 03:30:24.470758
# Unit test for function main
def test_main():
    var_0 = main()


# ----

# Generated at 2022-06-25 03:30:30.417339
# Unit test for function main
def test_main():
    var_0 = "systemd"
    var_1 = "show"
    var_2 = "Minion"
    var_3 = "systemd"
    var_4 = "is-active"
    var_5 = "Minion"
    var_6 = "Minion"
    var_7 = "systemd"
    var_8 = "is-enabled"
    var_9 = "/etc/systemd/system/kubelet.service"

    def dummy_fun():
        pass

    class AnsibleModule:
        def __init__(self, argument_spec, supports_check_mode, required_one_of, required_by):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.required_one_of = required_one_of


# Generated at 2022-06-25 03:30:34.700994
# Unit test for function request_was_ignored
def test_request_was_ignored():
    """
    Test request_was_ignored
    """
    var_0 = request_was_ignored('=')
    assert False == var_0
    var_0 = request_was_ignored('ignoring request')
    assert True == var_0
    var_0 = request_was_ignored('ignoring command')
    assert True == var_0


# Generated at 2022-06-25 03:30:45.436777
# Unit test for function main
def test_main():
    # ansible-playbook test/test-service.yml -vvv
    from ansible.module_utils.basic import *
    import argparse
    parser = argparse.ArgumentParser()
    for arg in __argspec_list():
        parser.add_argument(arg)
    args = parser.parse_args()

    # For unit testing, this file needs to be available
    # on the path. Let's make it so.
    import sys, os
    test_dir = os.path.abspath(os.path.dirname(__file__))
    module_path = os.path.join(test_dir, '..')
    if module_path not in sys.path:
        sys.path.insert(0, module_path)

    # Now load up the module

# Generated at 2022-06-25 03:30:46.817964
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:31:04.017827
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 03:31:07.459126
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    from ansible.module_utils.basic import *
    from ansible.module_utils.pycompat24 import get_exception
    main()

# Generated at 2022-06-25 03:31:16.583061
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:31:21.809464
# Unit test for function main
def test_main():
    test_case_0()

# To run unit tests.
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:31:29.877482
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:31:34.978881
# Unit test for function main
def test_main():
    # Replace the arguments in the following method call with the appropriate
    # arguments for the function you are testing.
    test_case_0()

if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-25 03:31:35.794011
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 03:31:37.356459
# Unit test for function main
def test_main():
    main()

# Entrypoint for the wrapper
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:31:41.804030
# Unit test for function main
def test_main():
    with patch.object(builtins, 'open', mock_open(read_data='data')):
        with patch('os.path.exists', return_value=True):
            test_case_0()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 03:31:43.809662
# Unit test for function main
def test_main():
    test_case_0()


# Run unit test
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:32:27.873898
# Unit test for function main
def test_main():
    var_0 = test_case_0()
    print(var_0)

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:32:34.934117
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:32:45.558078
# Unit test for function main
def test_main():
    # Control the systemctl binary location
    module = AnsibleModule(argument_spec=dict(systemctl_path=dict(required=False, type='str')))
    os.environ['SYSTEMCTL_PATH'] = module.params['systemctl_path']

    # Control the systemctl binary version
    os.environ['SYSTEMCTL_VERSION'] = str(1)

    # Ensure that the systemd-tmpfiles binary exists
    os.environ['SYSTEMD_TMPFILES_PATH'] = '/bin/systemd-tmpfiles'

    # Control the systemctl status output

# Generated at 2022-06-25 03:32:52.354545
# Unit test for function main
def test_main():

    mock_1 = MagicMock(side_effect=[{'message': 'failure 0 during daemon-reload: No such file or directory\n'},
                                    {'message': 'failure 0 during daemon-reload: No such file or directory\n'},
                                    {'message': 'failure 0 during daemon-reload: No such file or directory\n'},
                                    {'message': 'failure 0 during daemon-reload: No such file or directory\n'}])
    mock_2 = MagicMock(return_value={'message': 'failure 0 during daemon-reload: No such file or directory\n'})
    mock_3 = MagicMock(return_value={'message': 'failure 0 during daemon-reload: No such file or directory\n'})


# Generated at 2022-06-25 03:32:56.577862
# Unit test for function main
def test_main():
    # Verifying of the execution of main() function
    test_case_0()

if __name__ == "__main__":

    # Set up logging
    # import logging
    # logging.basicConfig(filename="test.log", level=logging.DEBUG)
    # logging.info('Start of test')

    # Run test
    test_main()

    # logging.info('End of test')

# Generated at 2022-06-25 03:33:03.226537
# Unit test for function main

# Generated at 2022-06-25 03:33:04.634240
# Unit test for function main
def test_main():
    var_0 = main()
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:33:09.907437
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Line test 1
    line_list_1 = """ExecStart={ path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"""
    parsed_1 = parse_systemctl_show(line_list_1)
    assert parsed_1["ExecStart"] == line_list_1

if __name__ == '__main__':
    test_case_0()
    test_parse_systemctl_show()

# Generated at 2022-06-25 03:33:11.133757
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:33:24.133552
# Unit test for function main
def test_main():
    class MockAnsibleModule:
        def __init__(self, params, check_rc=True):
            self.params = params
            self.check_rc = check_rc
            self.called_with = []
            self.exit_json = lambda x: sys.exit()

        def get_bin_path(self, name, required):
            return name

        def run_command(self, args, check_rc=True, **kw):
            if self.check_rc:
                assert 0 == kw['rc']
            self.called_with.append(args)
            if name == 'systemctl':
                out = b"\n".join(['LoadState=not-found', 'ActiveState=inactive'])
            elif 'daemon-reload' in args:
                out = b'Reloading.'
           

# Generated at 2022-06-25 03:34:14.080340
# Unit test for function main
def test_main():
    from io import StringIO
    print(StringIO.getvalue())

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:34:16.532597
# Unit test for function main
def test_main():
    var_0 = main()
    if var_0 == None:
        print("Error: test_main() caused an error. Line 35")
    else:
        print(var_0)


# Generated at 2022-06-25 03:34:19.567556
# Unit test for function main
def test_main():
    var_0 = AnsibleModule()

    var_1 = main()
    assert var_1 == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:34:21.556577
# Unit test for function main
def test_main():
    out1_1 = {}
    assert main() == out1_1
    
if __name__ == '__main__':
    main()


# Generated at 2022-06-25 03:34:22.721636
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == "i"


# Generated at 2022-06-25 03:34:33.790661
# Unit test for function main
def test_main():
    var_0 = {'password': None, 'state': 'stopped', 'username': None, 'scope': 'system', 'masked': False, 'force': False, 'systemctl': 'systemctl', 'daemon_reload': False, 'unit': 'httpd', 'enabled': False, 'binary_path': None, 'daemon_reexec': False}
    var_1 = {'password': None, 'state': None, 'username': None, 'scope': 'system', 'masked': False, 'force': False, 'systemctl': 'systemctl', 'daemon_reload': False, 'unit': 'httpd', 'enabled': False, 'binary_path': None, 'daemon_reexec': False}

# Generated at 2022-06-25 03:34:36.003825
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        raise

if __name__ == '__main__':
    # Unit test for function main
    test_main()

# pylama:ignore=W0621

# Generated at 2022-06-25 03:34:41.080105
# Unit test for function main
def test_main():
    var_0 = './systemctl'
    var_1 = '''enabled'''
    var_2 = '''system'''

    test_case_0()

main()

# Generated at 2022-06-25 03:34:44.157470
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        import traceback
        traceback.print_exc()
        assert False

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:34:45.771210
# Unit test for function main
def test_main():
    try:
        import ansible
    except ImportError:
        raise AssertionError("ansible is not installed")

    return
# Unit tests for function sysv_exists

# Generated at 2022-06-25 03:36:58.638947
# Unit test for function main
def test_main():
    mock_argv = [ "ansible-test", "--check" ]
    with patch('sys.argv', mock_argv):
        with patch.object(AnsibleModule, 'run_command', return_value=(0, "", "")):
            with patch.object(AnsibleModule, 'get_bin_path', return_value="/bin/systemctl"):
                with patch.object(os, 'geteuid', return_value=0):
                    with patch.object(os, 'getenv', return_value="/var/run/user/0"):
                        test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:37:03.170866
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit:
        pass

if __name__ == '__main__':
    from run import run_test
    run_test(test_suite_name = '__main__', func_name = 'test_main')

# Generated at 2022-06-25 03:37:07.115533
# Unit test for function main
def test_main():
    # Test that the unit test is working by calling test_case_0

    # Test that the unit test is working by calling test_case_0
    test_case_0()


if __name__ == '__main__':
    main()