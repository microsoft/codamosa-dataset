

# Generated at 2022-06-25 03:27:58.948651
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    # Check if list size is 0
    assert 0 == len(parse_systemctl_show({}))
    # Check if type is dictionary
    assert isinstance(parse_systemctl_show({}), dict)


# Generated at 2022-06-25 03:28:05.252105
# Unit test for function main
def test_main():
    assert True
    var_0_0 = test_case_0()
    assert var_0_0.get('name', None) == None
    assert var_0_0.get('changed', None) == False
    assert var_0_0.get('status', None) == {}

# Run tests
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:13.001043
# Unit test for function main
def test_main():
    var_0 = main()

    # test invalid service
    fh = open(os.path.sep.join([os.getcwd(),"unit-test","systemd","ansible.v0.6.8.test"]), 'w')
    fh.write("""
[Unit]
Description=Ansible Test
Documentation=https://github.com/ansible/ansible
After=network.target

[Service]
Type=oneshot
RemainAfterExit=yes

ExecStart=/bin/false
ExecStop=/bin/true
""")
    fh.close()

    assert var_0 == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:28:20.706328
# Unit test for function request_was_ignored
def test_request_was_ignored():
    var_0 = "hello world"
    var_1 = "hello=world"
    var_2 = "hello/world"
    var_3 = "hello: world"
    var_4 = "hello, world"
    var_5 = "hello - world"
    var_6 = "hello + world"
    var_7 = "hello \n world"
    var_8 = "hello %s world" % "dummy"
    var_9 = "hello # world"
    var_10 = "hello ! world"
    var_11 = "hello * world"
    var_12 = "hello & world"
    var_13 = "hello | world"
    var_14 = "hello \ world"
    var_15 = "hello ^ world"
    var_16 = "hello $ world"

# Generated at 2022-06-25 03:28:30.759012
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:28:43.942206
# Unit test for function main
def test_main():

    # try to replace main() with this function and run this single test case by:
    # python -m test.test_systemd --name test_main

    import unittest

    # define test case class
    class TestCase(unittest.TestCase):

        def runTest(self):
            test_case_0()

    # create test suite
    suite = unittest.TestSuite()
    suite.addTest(TestCase())

    # run test suite
    runner = unittest.TextTestRunner()
    runner.run(suite)

# Test this module by directly calling 'python -m test.test_systemd'
if __name__ == '__main__':

    import sys

    # check if option '--name' is given

# Generated at 2022-06-25 03:28:45.995225
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:28:47.501933
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:28:57.416722
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:29:01.863034
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as e:
        print("Exception in test case: %s" % e)
        traceback.print_exc()
        assert False


if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-25 03:29:51.797778
# Unit test for function main
def test_main():
    var_0 = units_to_sysv['foo.service']
    assert var_0 == 'foo'


# Generated at 2022-06-25 03:29:56.950224
# Unit test for function main
def test_main():
    var_0 = main()
    print(var_0)


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:30:04.722911
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:30:15.302254
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:30:23.709665
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:30:33.389884
# Unit test for function main
def test_main():
    os.environ['AM_I_IN_A_CONTAINER'] = 'true'
    systemctl_dict = {}
    systemctl_dict['systemctl'] = 'systemctl'
    systemctl_dict['state'] = 'started'
    systemctl_dict['name'] = 'iotop.service'
    systemctl_dict['_ansible_check_mode'] = False
    set_ansible_module_args(systemctl_dict)
    test_case_0()

# Entry point
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:30:34.472678
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:30:40.137870
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    filename = './test_data/test_parse_systemctl_show.txt'
    f = open(filename, 'r')
    data = parse_systemctl_show(f.readlines())
    assert(isinstance(data, dict))
    assert(data['ActiveState'] == 'active')
    assert(data['Type'] == 'simple')
    assert(data['ExecStart'] == '{ path=/usr/bin/dockerd ; argv[]=/usr/bin/dockerd -H fd:// ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }')


# Generated at 2022-06-25 03:30:45.675275
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    input_str_0 = """
[Service]
User=
Environment=
ExecReload=/bin/kill -HUP $MAINPID
ExecStart=/usr/sbin/crond -n $CRONDARGS { path=/usr/sbin/crond ; argv[]=/usr/sbin/crond -n $CRONDARGS ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }
TimeoutStopSec=90s
TimeoutStartSec=90s
MemoryLimit=
TasksMax=
LimitNOFILE=4096
LimitNPROC=3902
"""

# Generated at 2022-06-25 03:30:46.779236
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 03:31:42.709745
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    line_list_0 = []
    line_list_0.append("ActiveEnterTimestamp=Sun 2016-05-15 18:28:49 EDT")
    line_list_0.append("ActiveEnterTimestampMonotonic=8135942")
    line_list_0.append("ActiveExitTimestampMonotonic=0")
    line_list_0.append("ActiveState=active")
    line_list_0.append("After=auditd.service systemd-user-sessions.service time-sync.target systemd-journald.socket basic.target system.slice")
    line_list_0.append("AllowIsolate=no")
    line_list_0.append("Before=shutdown.target multi-user.target")
    line_list_0.append("BlockIOAccounting=no")
    line_list_

# Generated at 2022-06-25 03:31:45.299363
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:31:52.970481
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:31:58.542210
# Unit test for function main
def test_main():
    var_1 = AnsibleModule(argument_spec=dict(), required_one_of=[['state', 'enabled', 'masked', 'daemon_reload', 'daemon_reexec']], required_by=dict(), supports_check_mode=True)
    var_2 = {
        'enabled': None,
        'masked': None,
        'name': None,
        'state': None,
        'daemon_reload': False,
        'daemon_reexec': False,
        'force': False,
        'no_block': False,
        'scope': 'system'}
    var_3 = 'systemctl'
    var_4 = var_1.get_bin_path(var_3, True)
    var_5 = 'system'
    if var_5 != 'system':
        var

# Generated at 2022-06-25 03:32:02.640984
# Unit test for function main
def test_main():
    with patch('sys.argv', ["ansible_service"]):
        assert not main()
#    main()


# Generated at 2022-06-25 03:32:11.691348
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-25 03:32:16.354435
# Unit test for function request_was_ignored
def test_request_was_ignored():
    assert request_was_ignored({"ignoring command stop. Type=idle/inactive"}) == True
    assert request_was_ignored({"Unable to find a system bus connection: Did not receive a reply"}) == False


# Generated at 2022-06-25 03:32:22.111840
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    import os
    # Define input parameters to test function

# Generated at 2022-06-25 03:32:27.081277
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    var_0 = main()
    assert type(var_0) == dict
    assert var_0 == {'name': None, 'changed': False, 'status': {}}

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 03:32:29.056996
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        test_case_1()
        test_case_0()
        # test_main()

# Generated at 2022-06-25 03:33:26.973538
# Unit test for function main

# Generated at 2022-06-25 03:33:31.588243
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Exception")

test_main()

# Generated at 2022-06-25 03:33:37.303811
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except BaseException as e:
        print("Exception in test case 0")
        raise e

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-25 03:33:39.586894
# Unit test for function main
def test_main():
    # create a dummy ansible module
    module = AnsibleModule({
        "NAME": "test.service",
        "PARAM_1": [
            True,
            False
        ],
        "PARAM_2": "test.service"
    })
    test_case_0_main(module)


# Generated at 2022-06-25 03:33:50.231253
# Unit test for function main
def test_main():
    var_0 = dict(
        state = "started",
        enabled = None,
        masked = None,
        daemon_reload = False,
        daemon_reexec = False,
        scope = 'system',
        no_block = False,
        name = 'docker',
    )
    var_0 = dict(
        state = "reloaded",
        enabled = None,
        masked = None,
        daemon_reload = False,
        daemon_reexec = False,
        scope = 'system',
        no_block = False,
        name = 'docker',
    )

# Generated at 2022-06-25 03:33:53.108568
# Unit test for function main
def test_main():
    # Try to execute main() and verify its result
    # TODO: Add asserts according to the logic
    main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:34:01.745590
# Unit test for function parse_systemctl_show

# Generated at 2022-06-25 03:34:09.320348
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    """
    Unit test of function parse_systemctl_show
    """

# Generated at 2022-06-25 03:34:15.886072
# Unit test for function main
def test_main():
    unit_test_results = []
    # unit test 1
    try:
        var_0 = main()
        unit_test_results.append("SUCCESS")
    except Exception as var_1:
        unit_test_results.append("FAILED")

    return unit_test_results


# Generated at 2022-06-25 03:34:18.678159
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:36:08.712009
# Unit test for function main

# Generated at 2022-06-25 03:36:16.489607
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    out = """
        Loaded=/usr/lib/systemd/system/sshd.service
        ActiveState=active
        After=sysinit.target
        Before=user@myuser.service
        Test_case=systemctl_case # comment
        ExecMain={ path=/path/; foo=bar; home=myhome; }
    """.splitlines()
    assert parse_systemctl_show(out) == {
        'Loaded': '/usr/lib/systemd/system/sshd.service',
        'ActiveState': 'active',
        'After': 'sysinit.target',
        'Before': 'user@myuser.service',
        'Test_case': 'systemctl_case',
        'ExecMain': '{ path=/path/; foo=bar; home=myhome; }',
    }


# Generated at 2022-06-25 03:36:20.159970
# Unit test for function main
def test_main():
    try:
        test_case_0()
    # exception to catch
    except Exception as e:
        print("Error:", e)

# main function
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:36:21.907120
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 03:36:24.402585
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:36:26.922487
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print ("Error during test run.\n")

# Run test case functions
test_main()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 03:36:30.542931
# Unit test for function main
def test_main():
    os.environ['SYSTEMD_OFFLINE'] = '1'
    test_case_0()

# Run unit test if invoked
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:36:31.473668
# Unit test for function main
def test_main():
    # Call function main with arguments
    assert main() == 0


# Generated at 2022-06-25 03:36:44.387471
# Unit test for function parse_systemctl_show
def test_parse_systemctl_show():
    print('In test_parse_systemctl_show()')

# Generated at 2022-06-25 03:36:52.480608
# Unit test for function parse_systemctl_show