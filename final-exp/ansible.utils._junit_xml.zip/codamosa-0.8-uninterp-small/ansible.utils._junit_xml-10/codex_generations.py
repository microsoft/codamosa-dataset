

# Generated at 2022-06-25 12:40:09.820456
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_1 = TestSuite(name='test suite 1')
    test_suite_2 = TestSuite(name='test suite 2')
    test_suites_1 = TestSuites()
    test_suites_1.suites.append(test_suite_1)
    test_suites_1.suites.append(test_suite_2)
    test_cases_1 = []
    test_cases_1.append(TestCase(name='test case 0a'))
    test_cases_1.append(TestCase(name='test case 0b'))
    test_suite_1.cases = test_cases_1
    test_cases_2 = []
    test_cases_2.append(TestCase(name='test case 1a'))

# Generated at 2022-06-25 12:40:15.142080
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('TestName')
    xml_element = test_suite_0.get_xml_element()
    assert(xml_element.tag == 'testsuite')
    assert(xml_element.attrib['name'] == 'TestName')
    assert(xml_element.attrib['tests'] == '0')


# Generated at 2022-06-25 12:40:26.110030
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:40:35.008939
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('Test case one', assertions=2, classname='TestSuite.test_case_one', status='Error', time=decimal.Decimal(0.0123))
    # TODO: Should get_xml_element return an element or a string?
    test_case_xml = test_case.get_xml_element()
    assert test_case_xml.tag == 'testcase'
    test_case_xml_str = ET.tostring(test_case_xml, encoding='unicode')
    assert test_case_xml_str == '<testcase assertions="2" classname="TestSuite.test_case_one" name="Test case one" status="Error" time="0.0123"></testcase>'


# Generated at 2022-06-25 12:40:38.347681
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    TEST_RESULT = TestResult(output=None,
                             message=None,
                             type=None)
    assert TEST_RESULT.get_xml_element() is not None


# Generated at 2022-06-25 12:40:44.525173
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult(output=None,  message=None,  type=None)
    attr_result_0 = test_result_0.get_attributes()
    assert attr_result_0 == {}

    test_result_1 = TestResult(output='output_0',  message='message_0',  type='type_0')
    attr_result_1 = test_result_1.get_attributes()
    assert attr_result_1 == {'message': 'message_0',  'type': 'type_0'}


# Generated at 2022-06-25 12:40:47.126299
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    expected = {'message': None, 'type': 'result'}
    assert test_result_0.get_attributes() == expected


# Generated at 2022-06-25 12:40:54.043893
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test_result_0.type = "Error"
    test_result_0.message = "Invalid test case"
    test_result_0.output = "Cannot find error"

    assert test_result_0.get_xml_element().tag == 'error'
    assert test_result_0.get_xml_element().text == "Cannot find error"


# Generated at 2022-06-25 12:41:02.118364
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Instantiate objects for class TestSuite
    test_suite_0, test_suite_1 = TestSuite(hostname=None, id=None, name=None, package=None, timestamp=None), TestSuite(hostname=None, id=None, name=None, package=None, timestamp=None)
    # Run method get_xml_element of class TestSuite
    suite_xml = test_suite_0.get_xml_element()
    assert suite_xml is not None
    assert ET.tostring(suite_xml, encoding = 'unicode') == '<testsuite><testcase classname="None" name="None" /></testsuite>'



# Generated at 2022-06-25 12:41:08.539609
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult(output='output_0', message='message_0', type='type_0')
    assert test_result_0.get_xml_element() == ET.Element(
        'pass',
        attrib={
            'message': 'message_0',
            'type': 'type_0'
        }
    )



# Generated at 2022-06-25 12:41:17.997419
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('name_0')
    test_case_0 = TestCase('name_0')
    test_suite_0.cases.append(test_case_0)
    assert ET.tostring(test_suite_0.get_xml_element()) == b'<testsuite name="name_0" tests="1" time="0.0" />'

# Generated at 2022-06-25 12:41:28.098432
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_cases_0 = [
        (
            [decimal.Decimal('0E-1074')],
            {'message': None, 'type': 'error'},
        ),
        (
            [decimal.Decimal('0E+2')],
            {'message': '', 'type': None},
        ),
        (
            [decimal.Decimal('0E+1')],
            {},
        ),
        (
            [decimal.Decimal('0E+0')],
            {},
        ),
        (
            [1],
            {'message': None, 'type': 'error'},
        ),
        (
            [0],
            {'message': '', 'type': None},
        ),
        (
            [],
            {},
        ),
    ]

# Generated at 2022-06-25 12:41:31.445476
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    name_0 = "TestCase"
    test_case_0 = TestCase(name_0)

    result = test_case_0.get_xml_element()
    expected = f'<testcase name="{name_0}"/>'

    assert _pretty_xml(result) == expected



# Generated at 2022-06-25 12:41:37.215151
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Initialize 
    test_case0 = TestCase(name="test_case_0")
    test_suite0 = TestSuite(name="test_suite_0")
    test_suite0.cases.append(test_case0)
    test_suites0 = TestSuites()
    test_suites0.suites.append(test_suite0)

    # Test case
    test_case0.output = "output_case_0"
    test_case0.message = "message_case_0"
    test_case0.type = "type_case_0"
    test_case0.get_xml_element()



# Generated at 2022-06-25 12:41:38.772112
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()


# Generated at 2022-06-25 12:41:41.101499
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element() == ET.Element('TestResult', {})


# Generated at 2022-06-25 12:41:52.595526
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0_suite = TestSuite(
        cases=[
            TestCase(
                classname='a',
                name='b',
                time=decimal.Decimal('0.3'),
            ),
        ],
        errors=1,
        failures=2,
        hostname='d',
        id='e',
        name='f',
        package='g',
        properties={'h': 'i'},
        skipped=3,
        system_err='j',
        system_out='k',
        tests=4,
        time=decimal.Decimal('0.5'),
        timestamp=datetime.datetime(2020, 10, 10, 22, 15, 00),
    )
    result = test_case_0_suite.get_xml_element()


# Generated at 2022-06-25 12:41:58.536597
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == {}
    assert test_result_0.get_attributes() == {}
    test_result_1 = TestResult(message='some message', type='some type')
    assert test_result_1.get_attributes() == {'message': 'some message', 'type': 'some type'}
    assert test_result_1.get_attributes() == {'message': 'some message', 'type': 'some type'}
    test_result_2 = TestResult(message=None, type=None)
    assert test_result_2.get_attributes() == {}
    assert test_result_2.get_attributes() == {}
    test_result_3 = TestResult(output='some output')
    assert test_result_

# Generated at 2022-06-25 12:42:03.697020
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    instance = TestResult(output='output_0', message='message_0', type='type_0')
    actual = instance.get_attributes()
    assert actual == {'message': 'message_0', 'type': 'type_0'}



# Generated at 2022-06-25 12:42:09.187057
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result_0 = TestResult(message='Message', output='Output!', type='passed')
    assert result_0.get_attributes() == {'message':'Message', 'type':'passed'}

    result_1 = TestResult(message='Message', output='Output!', type=None)
    assert result_1.get_attributes() == {'message':'Message'}


# Generated at 2022-06-25 12:42:17.295252
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert(TestResult(output="output_0", message="message_0", type="type_0").get_attributes()) == {'message': 'message_0', 'type': 'type_0'}


# Generated at 2022-06-25 12:42:24.967043
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test with a valid xml structure
    test_suite = TestSuite("testsuite1")
    test_case = TestCase("testcase1")
    test_case.failures.append(TestFailure("testcase1", "failure message"))
    test_case.errors.append(TestError("testcase1", "error message"))
    test_suite.cases.append(test_case)
    assert test_suite.get_xml_element().attrib['failures'] == "1", "Test failed for TestSuite.get_xml_element() method"
    assert test_suite.get_xml_element().attrib['errors'] == "1", "Test failed for TestSuite.get_xml_element() method"

# Generated at 2022-06-25 12:42:27.914679
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_1 = TestError('test.test_hbp_junit', 'Encountered an error during the test run.')

    element_1 = test_1.get_xml_element()
    print(element_1.tag)



# Generated at 2022-06-25 12:42:35.600107
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    error_0 = TestError(message='test message 0', output='test output 0', type='test type 0')
    ET.Element('test type 0', {'message': 'test message 0'})
    assert error_0.get_xml_element().tag == 'test type 0'
    assert error_0.get_xml_element().attrib == {'message': 'test message 0'}
    assert error_0.get_xml_element().text == 'test output 0'

    failure_0 = TestFailure(message='test message 1', output='test output 1', type='test type 1')
    ET.Element('failure', {'message': 'test message 1'})
    assert failure_0.get_xml_element().tag == 'failure'

# Generated at 2022-06-25 12:42:46.505713
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    data = ['t0','t1','t2']
    expected = """<testsuite errors="0" failures="0" disabled="0" tests="3" skipped="0" time="0" name="t0">
  <properties>
    <property name="" value=""/>
    <property name="" value=""/>
    <property name="" value=""/>
  </properties>
  <testcase assertions="" classname="" name="" time="" status=""/>
  <system-out></system-out>
  <system-err></system-err>
</testsuite>
"""

    ts = TestSuite(name=data[0])
    for i in range(len(data)):
        ts.properties[data[i]] = ''

# Generated at 2022-06-25 12:42:48.020463
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    error_0 = TestError()
    assert error_0.get_attributes() == dict(type='error')


# Generated at 2022-06-25 12:42:52.250431
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_case_0 = TestCase("test_case_0")
    assert test_case_0.get_xml_element() != None
    test_case_1 = TestCase("test_case_1", output="error")
    assert test_case_1.get_xml_element() != None
    

# Generated at 2022-06-25 12:42:57.733536
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    output_0 = 'out'
    message_0 = 'message'
    type_0 = 'type'
    result = TestResult(output_0, message_0, type_0)
    result_0 = TestResult(output_0)
    result_1 = TestResult(output_0)

    assert result_0.get_xml_element() == result_1.get_xml_element()



# Generated at 2022-06-25 12:43:03.213081
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():

    # Create a TestResult object
    test_result_0 = TestResult()

    # Call method get_xml_element on TestResult object
    output_xml_element = test_result_0.get_xml_element()

    # Check if the output XML element is formatted correctly
    assert output_xml_element.tag == 'testresult'
    assert output_xml_element.attrib == {}
    assert output_xml_element.text is None



# Generated at 2022-06-25 12:43:11.196597
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    element = test_result_0.get_xml_element()
    assert element.tag == 'testResult'
    assert element.text == None
    assert element.tail == None
    assert element.attrib == {}

    test_result_0 = TestResult(output='output')
    element = test_result_0.get_xml_element()
    assert element.tag == 'testResult'
    assert element.text == 'output'
    assert element.tail == None
    assert element.attrib == {}

    test_result_0 = TestResult(output='output', message='message')
    element = test_result_0.get_xml_element()
    assert element.tag == 'testResult'
    assert element.text == 'output'
    assert element.tail == None
    assert element

# Generated at 2022-06-25 12:43:19.708564
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case0 = TestCase(
        name='test_case',
        assertions=2
    )
    xml = ET.fromstring(ET.tostring(test_case0.get_xml_element()))
    assert xml.tag == 'testcase'
    assert xml.attrib == {'name': 'test_case', 'assertions': '2'}
    assert xml.text == None
    assert len(xml) == 0


# Generated at 2022-06-25 12:43:29.708366
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='python_unittest', classname='junitxml')
    assert str(ET.tostring(test_case_0.get_xml_element())) == b"<testcase name='python_unittest' classname='junitxml' />"
    test_case_1 = TestCase(name='python_unittest', classname='junitxml', time='3.3')
    assert str(ET.tostring(test_case_1.get_xml_element())) == b"<testcase name='python_unittest' classname='junitxml' time='3.3' />"
    test_case_2 = TestCase(name='python_unittest', classname='junitxml', status='success')

# Generated at 2022-06-25 12:43:36.287758
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('')
    test_suites_0 = TestSuites()
    test_suite_0.cases.append(TestCase(''))
    test_suites_0.suites.append(test_suite_0)
    results = test_suites_0.get_xml_element()
    expected = '<testsuites disabled="0" errors="0" failures="0" name="" tests="1" time="0.0" />\n'
    actual = _pretty_xml(results)
    assert expected == actual


# Generated at 2022-06-25 12:43:38.157088
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_2 = TestCase(name="create_user")
    test_case_2.get_xml_element()


# Generated at 2022-06-25 12:43:40.002993
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    test_case = TestCase(name="test01")

    _ = test_case.get_xml_element()

# Generated at 2022-06-25 12:43:50.073548
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        hostname=None,
        id=None,
        name='',
        package=None,
        properties={},
        system_err=None,
        system_out=None,
        timestamp=None,
        cases=[],
        disabled=0,
        errors=0,
        failures=0,
        skipped=0,
        tests=0,
        time=decimal.Decimal('0'),
    )

    expected = """\
<testsuite disabled="0" errors="0" failures="0" name="" skipped="0" tests="0" time="0" />"""

    actual = test_suite_0.get_xml_element().tostring(encoding='unicode')

    assert expected == actual



# Generated at 2022-06-25 12:43:58.301801
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name = "test", hostname = "test", id = "test", package = "test", timestamp = datetime.datetime.now(), properties = dict(), cases = [], system_out = "system-out", system_err = "system-err")
    test_case_0 = test_suite_0.get_xml_element()
    assert test_case_0.tag == 'testsuite'
    assert test_case_0.find('testcase').tag == 'testcase'
    assert test_case_0.find('properties').tag == 'properties'
    assert test_case_0.find('system-out').text == 'system-out'
    assert test_case_0.find('system-err').text == 'system-err'


# Generated at 2022-06-25 12:44:01.367383
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='example.tests.test_example')
    # TestCase(name='example.tests.test_example').get_xml_element()


# Generated at 2022-06-25 12:44:04.412391
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('test_name')
    assert test_case_0.get_xml_element().tag == 'testcase'
    assert test_case_0.get_xml_element().attrib.keys() == {'name'}


# Generated at 2022-06-25 12:44:14.243607
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    class Test1(object):
        def get_attributes(self):
            return _attributes(
                disabled=self.disabled,
                errors=self.errors,
                failures=self.failures,
                hostname=self.hostname,
                id=self.id,
                name=self.name,
                package=self.package,
                skipped=self.skipped,
                tests=self.tests,
                time=self.time,
                timestamp=self.timestamp.isoformat(timespec='seconds') if self.timestamp else None,
            )
        @property
        def disabled(self) -> int:
            """The number of disabled test cases."""
            return sum(case.is_disabled for case in self.cases)

# Generated at 2022-06-25 12:44:27.184739
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="TestSuite0")
    test_case_0 = TestCase(name="TestCase0", assertions=2)
    test_case_1 = TestCase(name="TestCase1", assertions=3)
    test_suite_0.cases.append(test_case_0)
    test_suite_0.cases.append(test_case_1)
    root = test_suite_0.get_xml_element()
    assert str(root.get('name')) == "TestSuite0"
    assert str(root.get('tests')) == "2"
    assert str(root.get('time')) == "0.00"
    assert len(root) == 2
    test_case0 = root[0]

# Generated at 2022-06-25 12:44:35.843086
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:44:40.148606
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name='Test Suite',
    )
    xml_element = ET.Element('testsuite', _attributes(
        name='Test Suite',
        disabled=0,
        errors=0,
        failures=0,
        skipped=0,
        tests=0,
    ))
    assert test_suite.get_xml_element().tag == xml_element.tag
    assert test_suite.get_xml_element().attrib == xml_element.attrib
    assert test_suite.get_xml_element() == xml_element



# Generated at 2022-06-25 12:44:42.483105
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name_0')
    assert test_suite_0.get_xml_element() is not None


# Generated at 2022-06-25 12:44:47.118185
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_TestCase_get_xml_element")
    result = test_case_0.get_xml_element()
    expected_result = ET.Element('testcase', {'name': 'test_TestCase_get_xml_element'})
    assert result == expected_result


# Generated at 2022-06-25 12:44:49.081395
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    assert test_case_0.get_xml_element() == ET.Element('testcase', {'name': 'test_case_0'})


# Generated at 2022-06-25 12:44:57.276491
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:45:03.378582
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='foo', cases=[TestCase(name=1)])
    expected_xml_element = ET.fromstring('''
            <testsuite name="foo" tests="1">
            <testcase classname="None" name="1"/>
            </testsuite>
            ''')
    assert expected_xml_element == test_suite_0.get_xml_element(), 'Expected testsuite get_xml_element to match with expected'


# Generated at 2022-06-25 12:45:12.094876
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='name0', assertions=1, classname='classname0', status='status0', time=1, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)
    test_suite_0 = TestSuite(name='name0', hostname='hostname0', id='id0', package='package0', timestamp=datetime.datetime(2018, 3, 31, 0, 0), properties={}, cases=[test_case_0], system_out=None, system_err=None)

# Generated at 2022-06-25 12:45:20.921875
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create a test suite
    test_suite_0 = TestSuite(
        hostname='localhost',
        name='testsuite_name_0',
        package='testsuite_package_0',
        timestamp=datetime.datetime.now(),
        id='testsuite_id',
    )
    # Create a test case
    test_case_0 = TestCase(
        assertions=10,
        classname='testcase_classname_0',
        name='testcase_name_0',
        status='testcase_status_0',
        time=decimal.Decimal('10.1'),
    )
    # Add the test case to the test suite
    test_suite_0.cases.append(test_case_0)
    # Create another test case

# Generated at 2022-06-25 12:45:28.618472
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    tc = TestCase(name='Test Name')
    element = ET.Element('testcase', _attributes(name='Test Name'))
    xml = ET.tostring(element, encoding='unicode')
    assert tc.get_xml_element().__eq__(ET.fromstring(xml))

# Generated at 2022-06-25 12:45:38.043553
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # TestCase instance with all attributes assigned
    test_case = TestCase(
        classname='class_name',
        name='name',
        status='status',
        time=decimal.Decimal('1001.0'),
        assertions='2',
        errors=[TestError()],
        failures=[TestFailure()],
        skipped='skipped',
        system_err='stderr',
        system_out='stdout',
        is_disabled=True,
    )

    # Expected XML doc

# Generated at 2022-06-25 12:45:42.001593
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name_0')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert ET.tostring(test_suite.get_xml_element()) == b'<testsuite name="test_suite_name_0" tests="0" disabled="0" errors="0" failures="0" time="0.0"/>'


# Generated at 2022-06-25 12:45:53.084727
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="TestSuites")
    test_case_0 = TestCase(name="TestSuite 1")
    test_case_1 = TestCase(name="TestSuite 2")
    test_case_2 = TestCase(name="TestSuite 3")
    test_suite_0.cases.append(test_case_0)
    test_suite_0.cases.append(test_case_1)
    test_suite_0.cases.append(test_case_2)
    test_error_0 = TestError()
    test_case_2.errors.append(test_error_0)
    test_failure_0 = TestFailure()
    test_case_1.failures.append(test_failure_0)
    tests = test_suite_

# Generated at 2022-06-25 12:46:01.544870
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    timestamp = datetime.datetime(2020, 5, 19, 10, 55)
    test_suite = TestSuite(
        name='test_suite',
        hostname='test_hostname',
        id='test_id',
        package='test_package',
        timestamp=timestamp,
        properties={'key': 'value'},
    )

# Generated at 2022-06-25 12:46:11.071455
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Arrange
    ts0 = TestSuite(name='TestSuite 0')
    ts0.cases.append(TestCase(name='TestCase 0'))

    # Act
    xml_string = _pretty_xml(ts0.get_xml_element())

    # Assert

# Generated at 2022-06-25 12:46:19.759164
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions ='1',
        classname ='TestCaseClassnameExample',
        name ='TestCaseNameExample',
        status ='run',
        time ='0.001'
    )
    xml_elem_0_actual = test_case_0.get_xml_element()
    test_case_0_expected_attrs = {'assertions':'1', 'classname':'TestCaseClassnameExample', 'name':'TestCaseNameExample', 'status':'run', 'time':'0.001'}
    assert_xml_elem_attrs(xml_elem_0_actual, test_case_0_expected_attrs)


# Generated at 2022-06-25 12:46:25.335557
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_0")
    test_case_0.time = decimal.Decimal(1)
    test_case_0.message = "test_case_0 is not implemented"

    test_error_0 = TestError(message="test_case_0 is not implemented")
    test_case_0.errors.append(test_error_0)

    print(test_case_0.get_xml_element())
    print(_pretty_xml(test_case_0.get_xml_element()))


# Generated at 2022-06-25 12:46:29.743752
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('test_case_0')
    assert (ET.tostring(test_case_0.get_xml_element()).decode('utf-8')) == '<testcase name="test_case_0" />'


# Generated at 2022-06-25 12:46:37.191241
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    expected_attribute_dict = {'name': 'test name', 'assertions': '1', 'classname': 'test class', 'status': 'test status', 'time': '1.0'}
    expected_tag = 'testcase'
    expected_test_message = 'test message'
    expected_case_output = 'test output'
    expected_test_type = 'test type'
    expected_test_error_message = 'error message'
    expected_error_output = 'error output'
    expected_test_error_type = 'error type'
    test_case_0 = TestCase(expected_attribute_dict['name'], expected_attribute_dict['assertions'], expected_attribute_dict['classname'], expected_attribute_dict['status'], expected_attribute_dict['time'])

    actual_element = test_case

# Generated at 2022-06-25 12:46:57.440607
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite_0 = TestSuite(name='test_suite', hostname='localhost',
            id='1',  package='test',
            timestamp=datetime.datetime(2020, 9, 17, 21, 54, 25))
    suite_1 = TestSuite(name='test_suite', hostname='localhost',
            id='1',  package='test',
            timestamp=datetime.datetime(2020, 9, 17, 21, 54, 25))
    suite_2 = TestSuite(name='test_suite', hostname='localhost',
            id='1',  package='test',
            timestamp=datetime.datetime(2020, 9, 17, 21, 54, 25))

# Generated at 2022-06-25 12:47:01.121635
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # arrange
    expected = """<testsuite name="name" tests="1" disabled="0" errors="0" failures="0" time="1.0"><testcase name="name" classname="classname" time="1"/></testsuite>"""

    test_case_1 = TestCase(name="name", classname="classname", time=decimal.Decimal("1.0"))
    test_suite_1 = TestSuite(name="name", suites=[test_case_1])

    # act
    actual = _pretty_xml(test_suite_1.get_xml_element())

    # assert
    assert actual.strip() == expected.strip()



# Generated at 2022-06-25 12:47:11.328455
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    assert test_case_0.get_xml_element().attrib == {'name': 'test_case_0'}
    test_case_1 = TestCase(name='test_case_1', assertions=1, classname='test.case.1', status='ok', time=1.0)
    assert test_case_1.get_xml_element().attrib == {'name': 'test_case_1', 'assertions': '1', 'classname': 'test.case.1', 'status': 'ok', 'time': '1.0'}

# Generated at 2022-06-25 12:47:19.679267
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    
    test_case_0 = TestCase(name='test_case_0')

    test_result_xml = ET.tostring(test_case_0.get_xml_element(), encoding='unicode')

    class_attributes = {'name': 'test_case_0',
    'assertions': 'None',
    'classname': 'None',
    'status': 'None',
    'time': 'None'}

    class_xml = '<testcase '
    for key, value in class_attributes.items():
        class_xml += f'{key}="{value}" '

    class_xml += '/>'

    assert test_result_xml == class_xml



# Generated at 2022-06-25 12:47:29.935961
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:47:37.612889
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    case0 = TestCase(name='case0')
    case1 = TestCase(name='case1')
    case2 = TestCase(name='case2')
    case3 = TestCase(name='case3')
    case4 = TestCase(name='case4')
    case5 = TestCase(name='case5')
    suite0 = TestSuite(name='suite0')
    suite1 = TestSuite(name='suite1')
    suite2 = TestSuite(name='suite2')

    assert suite0.get_xml_element() == ET.fromstring('''\
<testsuite disabled="0" errors="0" failures="0" hostname="" id="" name="suite0" package="" skipped="0" tests="0" time="0" timestamp=""/>\
''')
    assert suite1.get

# Generated at 2022-06-25 12:47:44.931580
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    test_case_0 = TestCase(name='Case_0') 

    test_error_0 = TestError(message='Error_0', type='Error_0', output='Error_0')    
    test_error_1 = TestError(message='Error_1', type='Error_1', output='Error_1')
    test_case_0.errors.append(test_error_0)
    test_case_0.errors.append(test_error_1)

    test_failure_0 = TestFailure(message='Failure_0', type='Failure_0', output='Failure_0')
    test_case_0.failures.append(test_failure_0)
    
    test_case_0.skipped = 'Skipped_0'

# Generated at 2022-06-25 12:47:50.678444
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_1 = TestCase(name='test_case_1')
    test_suite_1 = TestSuite(name='test_suite_1')
    test_suite_1.cases.append(test_case_1)
    expected_result = '<testsuite name="test_suite_1" tests="1"><testcase name="test_case_1"></testcase></testsuite>'
    actual_result = test_suite_1.get_xml_element()
    assert expected_result == ET.tostring(actual_result, encoding='unicode')

# Generated at 2022-06-25 12:47:56.553572
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='Test')
    xml_element = test_case.get_xml_element()
    assert xml_element.attrib['name'] == 'Test'
    assert xml_element.attrib['classname'] == None
    assert xml_element.attrib['time'] == None
    assert xml_element.attrib['assertions'] == None
    assert xml_element.attrib['status'] == None
    assert len(xml_element) == 0
    assert xml_element[0].text == None
    assert xml_element[0].tag == 'skipped'
    assert xml_element[1].tag == 'error'
    assert xml_element[1].text == None
    assert xml_element[1].attrib['type'] == 'error'

# Generated at 2022-06-25 12:47:58.018412
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase()
    assert test_case_0.get_xml_element() != None

# Generated at 2022-06-25 12:48:32.913826
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_0", classname="TestCase", assertions=0, status="failures", time=decimal.Decimal(0), errors=[], failures=[])
    root = ET.fromstring(test_case_0.get_xml_element().tostring(encoding='unicode'))

    assert root.get('name') == "test_case_0"
    assert root.get('classname') == "TestCase"
    assert root.get('assertions') == "0"
    assert root.get('status') == "failures"
    assert root.get('time') == "0"


# Generated at 2022-06-25 12:48:42.166883
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('test_case_0')
    test_case_1 = TestCase('test_case_1', time=0.12345, assertions=1)
    test_case_2 = TestCase('test_case_2', classname='TestClass', status='NotRun')
    test_case_3 = TestCase('test_case_3', time=0.12345, assertions=1, classname='TestClass', status='NotRun')

    test_error_0 = TestError()
    test_error_1 = TestError('output', 'message', 'type')
    test_failure_0 = TestFailure()
    test_failure_1 = TestFailure('output', 'message', 'type')

    test_case_0.errors.append(test_error_0)

# Generated at 2022-06-25 12:48:49.810080
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0', assertions=1, classname='test.case.0', status='PASS', time=decimal.Decimal('0.3'))
    xml_str = _pretty_xml(test_case_0.get_xml_element())
    assert xml_str == '<testcase assertions="1" classname="test.case.0" name="test_case_0" status="PASS" time="0.3"></testcase>\n'
                

# Generated at 2022-06-25 12:48:53.143158
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name', classname='test_classname')
    xml_element = test_case.get_xml_element()
    assert xml_element.tag == 'testcase'
    assert xml_element.attrib.get('name') == 'test_name'
    assert xml_element.attrib.get('classname') == 'test_classname'

# Generated at 2022-06-25 12:48:57.003570
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # TestCase: Tests get_xml_element method
    # TestCase: This method returns a list of test cases
    # TestCase: <testcase assertions="..." classname="..." name="..." status="..." time="...">
    # TestCase: </testcase>
    test_case_0 = TestCase(name="test_case_0")
    assert test_case_0.get_xml_element().tag == "testcase"


# Generated at 2022-06-25 12:49:00.520007
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    print('Testing get_xml_element of class TestCase')
    assert TestError.get_xml_element(test_error_0)[1] == 'failure'
    print('Success: get_xml_element of class TestCase')


# Generated at 2022-06-25 12:49:09.109049
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testcase1 = TestCase(name='TestCase1')
    testcase2 = TestCase(name='TestCase2')

    testcase1.failures.append(TestFailure(output='Test output 1', message='Test message 1', type='Test type 1'))
    testcase1.failures.append(TestFailure(output='Test output 2', message='Test message 2', type='Test type 2'))

    testcase2.errors.append(TestError(output='Test output 3', message='Test message 3', type='Test type 3'))
    testcase2.errors.append(TestError(output='Test output 4', message='Test message 4', type='Test type 4'))

    testsuite = TestSuite(name='TestSuite1')

# Generated at 2022-06-25 12:49:12.021905
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_1")
    test_case_0.get_xml_element()
    assert test_case_0 is not None


# Generated at 2022-06-25 12:49:18.520925
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test-suite', timestamp = datetime.datetime.now())

    test_case = TestCase(name='test-case')
    suite.cases.append(test_case)
    test_xml_element = suite.get_xml_element()
    assert test_xml_element.tag == 'testsuite'
    assert test_xml_element.attrib['name'] == 'test-suite'
    assert len(test_xml_element.attrib) == 6
    assert len(test_xml_element) == 1
    assert test_xml_element[0].tag == 'testcase'


# Generated at 2022-06-25 12:49:22.427557
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test1', time=decimal.Decimal('0.5'))
    root = ET.Element('testsuites')
    root.append(test_case_0.get_xml_element())

    # Test case should display total time taken by unit tests
    assert _pretty_xml(root) == b"""<?xml version="1.0" ?>
<testsuites>
\t<testcase assertions="None" classname="None" name="test1" status="None" time="0.5"/>
</testsuites>
"""


# Generated at 2022-06-25 12:49:43.315871
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite('Example1')
    suite_xml = ET.Element('testsuite', _attributes(
            disabled=0,
            errors=0,
            failures=0,
            hostname=None,
            id=None,
            name='Example1',
            package=None,
            skipped=0,
            tests=0,
            time=None,
            timestamp=None ))
    suite_xml_string = _pretty_xml(suite_xml)
    suite_xml_string_new = _pretty_xml(suite.get_xml_element())
    assert suite_xml_string == suite_xml_string_new



# Generated at 2022-06-25 12:49:50.789920
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    test_case_0 = TestCase(name="test_case_0")

    test_error_0 = TestError(output = "output",
                             message = "message",
                             type = "type")

    test_case_0.errors.append(test_error_0)
    test_case_0.failures.append(None)
    test_case_0.skipped = "skipped"
    test_case_0.system_out = None
    test_case_0.system_err = "system_err"

    test_case_0_attributes = test_case_0.get_xml_element()

    assert test_case_0_attributes.tag == 'testcase'
    assert test_case_0_attributes.text == None

    childrens = test_case_0_attributes.get