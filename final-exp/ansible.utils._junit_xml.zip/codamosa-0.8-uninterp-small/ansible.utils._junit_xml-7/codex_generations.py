

# Generated at 2022-06-25 12:40:01.643760
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    result = test_result.get_attributes()
    assert result == {'type': 'TestResult'}


# Generated at 2022-06-25 12:40:08.505790
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    instance = TestResult(output="output", type="type", message="message")
    attrs = instance.get_attributes()
    expected = {
        "message": "message",
        "type": "type"
    }
    for key, value in attrs.items():
        assert key in expected
        assert value == expected[key]
    for key, value in expected.items():
        assert key in attrs
        assert value == attrs[key]



# Generated at 2022-06-25 12:40:12.996815
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    object_TestResult_0 = TestResult()
    assert getattr(object_TestResult_0, "message") == None
    assert getattr(object_TestResult_0, "type") == None
    assert getattr(object_TestResult_0, "output") == None


# Generated at 2022-06-25 12:40:16.004996
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    output = 'output'
    message = 'message'
    type_ = 'type'
    result = TestResult(output=output, message=message, type=type_)
    assert len(result.get_attributes()) == 2
    assert result.get_attributes()['message'] == message
    assert result.get_attributes()['type'] == type_
    assert result.get_xml_element().text == output


# Generated at 2022-06-25 12:40:19.483743
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()
    assert test_suites_0.get_xml_element() == ET.Element('testsuites', {})


# Generated at 2022-06-25 12:40:21.470863
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():

    test_result = TestResult(message="Test message",
                             type="Test type",
                             output="Test output")
    assert test_result.get_attributes() == {"message": "Test message", "type": "Test type"}



# Generated at 2022-06-25 12:40:26.730380
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(message = "This is a message", output = "This is the output", type = "This is the type")
    attr_dict = test_result.get_attributes()
    assert attr_dict['message'] == "This is a message"
    assert attr_dict['type'] == "This is the type"


# Generated at 2022-06-25 12:40:31.132940
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}

    test_result = TestResult(message="This is a message", type="failure")
    assert test_result.get_attributes() == {"message": "This is a message", "type": "failure"}


# Generated at 2022-06-25 12:40:37.848906
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    first_element = TestError(output="myoutput", message="mymessage", type="mytype")
    first_xml = first_element.get_xml_element()
    assert first_xml.tag == "error"
    assert first_xml.text == "myoutput"
    assert first_xml.get("message") == "mymessage"
    assert first_xml.get("type") == "mytype"
    #Default values for TestFailure
    second_element = TestFailure()
    second_xml = second_element.get_xml_element()
    assert second_xml.tag == "failure"
    assert second_xml.text == None
    assert second_xml.get("message") == None
    assert second_xml.get("type") == "failure"



# Generated at 2022-06-25 12:40:41.645745
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(message='msg', output='out', type='error')
    result_attributes = result.get_attributes()

    assert result_attributes['message'] == 'msg'
    assert result_attributes['type'] == 'error'
    assert len(result_attributes) == 2


# Generated at 2022-06-25 12:40:57.194931
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:41:04.732089
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('name_0')
    test_suite_0.hostname = 'hostname_0'
    test_suite_0.id = 'id_0'
    test_suite_0.package = 'package_0'
    test_suite_0.timestamp = datetime.datetime(2020, 1, 22, 10, 33, 43, 575983)
    test_suite_0.properties = {'name_0': 'value_0', 'name_1': 'value_1', 'name_2': 'value_2'}
    test_case_0 = TestCase('name_0')
    test_case_0.assertions = -1
    test_case_0.classname = 'classname_0'

# Generated at 2022-06-25 12:41:12.231853
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="name_0")
    expected = ET.fromstring("<testsuite name=\"name_0\" tests=\"0\" errors=\"0\" failures=\"0\" disabled=\"0\" skipped=\"0\" time=\"0\"/>")

    assert ET.tostring(test_suite_0.get_xml_element(), encoding="unicode") == ET.tostring(expected, encoding="unicode")


# Generated at 2022-06-25 12:41:15.885557
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname')
    ET.fromstring(test_suite.get_xml_element().tostring().decode('utf-8'))



# Generated at 2022-06-25 12:41:17.514691
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 12:41:27.642836
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:41:32.532463
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=0,
        classname='classname',
        name='name',
        status='status',
        time=0,
        errors=[TestError(
            message='message',
            output='output',
            type='type',
        )],
        failures=[TestFailure(
            message='message',
            output='output',
            type='type',
        )],
        skipped='skipped',
        system_err='system_err',
        system_out='system_out',
    )
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:41:43.524781
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TS0 = TestSuite("TS0", "xxx")
    TS1 = TestSuite("TS1", "xxx")
    TS2 = TestSuite("TS2", "xxx")
    TS3 = TestSuite("TS3", "xxx")
    TS4 = TestSuite("TS4", "xxx")

    # assert element tags and attributes
    assert TS3.get_xml_element().tag == "testsuite"
    assert TS3.get_xml_element().attrib["tests"] == "0"
    assert len(TS3.get_xml_element().attrib) == 7
    
    
    TS0.addTest(TestCase("TC0", time = 0.00))
    TS1.addTest(TestCase("TC1", time = 0.01))

# Generated at 2022-06-25 12:41:54.126456
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    my_test_case = TestCase(name="test_name", assertions="0", classname="test_class", status="test_status", time="1")
    my_test_suite = TestSuite(name="test_name", hostname="test_host", id="test_id", package="test_package",
                              timestamp=datetime.datetime.now(), properties={"test_property": "test_value"},
                              cases= [my_test_case])
    root = my_test_suite.get_xml_element()
    xml_obj = ET.tostring(root)
    assert (b"test_name" in xml_obj)
    assert (b"test_status" in xml_obj)
    assert (b"test_package" in xml_obj)

# Generated at 2022-06-25 12:41:59.232119
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('test_suite_0')
    test_suites_0 = TestSuites('test_suites_0')
    test_suites_0.suites.append(test_suite_0)
    result = test_suites_0.to_pretty_xml()
    expected_result = '<?xml version="1.0" ?>\n<testsuites disabled="" errors="" failures="" name="test_suites_0" tests="" time="0.0"></testsuites>'
    assert result == expected_result


# Generated at 2022-06-25 12:42:06.037267
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_Suite_0 = TestSuite('name')
    assert_equals(ET.tostring(test_Suite_0.get_xml_element()), xml_0)


# Generated at 2022-06-25 12:42:16.055042
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:42:17.841816
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='foo name')
    # Assert
    assert _pretty_xml(test_suite_0.get_xml_element()) == '"""<testsuite name="foo name" tests="0"/>"""\n'



# Generated at 2022-06-25 12:42:19.944664
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name='name', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now())
    assert ts.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-25 12:42:26.213174
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_1 = TestSuite(name='name_1', hostname='hostname_1', id='id_1', package='package_1')
    xml_element = test_case_1.get_xml_element()
    assert xml_element.tag == 'testsuite' and len(xml_element) == 0 and xml_element.attrib['hostname'] == 'hostname_1'
    xml_element.tag = 'testsuite_1'
    assert xml_element.tag == 'testsuite_1'


# Generated at 2022-06-25 12:42:34.391304
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
	test_suites_0 = TestSuites()
	test_suites_0.name = "test_suites 0"
	test_suite_0 = TestSuite()
	test_suite_0.name = "test_suite 0"
	test_suites_0.suites.append(test_suite_0)
	test_case_0 = TestCase()
	test_case_0.name = "test_case 0"
	test_case_0.time = decimal.Decimal('0.001')
	test_case_1 = TestCase()
	test_case_1.name = "test_case 1"
	test_case_1.time = decimal.Decimal('0.002')
	test_suite_0.cases.append(test_case_1)
	test_case_

# Generated at 2022-06-25 12:42:42.948186
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_suite_0 = TestSuite(
        cases=[
            TestCase(name='Test Case 0')
        ],
        name='Test Suite 0'
    )

    xml = _pretty_xml(test_suite_0.get_xml_element())

    expected = '''\
<?xml version="1.0" ?>
<testsuite failures="0" hostname="" id="" name="Test Suite 0" package="" skipped="0" tests="1" time="0">
  <testcase assertions="" classname="" name="Test Case 0" status="" time="0"/>
</testsuite>
'''

    assert xml == expected


# Generated at 2022-06-25 12:42:48.848548
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('/opt/jenkins/workspace/demo-java/build/reports/tests/test/index.html')
    test_suites_0 = TestSuites()
    test_suites_0.suites.append(test_suite_0)
    assert str(test_suites_0.get_xml_element()) == '<testsuites disabled="0" errors="0" failures="0" name="" tests="0" time="0"></testsuites>'


# Generated at 2022-06-25 12:42:52.018066
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite("name_0")
    test_suite_0.get_xml_element().tag == 'testsuite'



# Generated at 2022-06-25 12:42:59.403423
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="test_suite_0")
    xml_element_0 = test_suite_0.get_xml_element()
    xml_element_0_string = ET.tostring(xml_element_0, encoding='unicode')
    assert xml_element_0_string == "<testsuite disabled='0' errors='0' failures='0' hostname='' id='' name='test_suite_0' package='' skipped='0' tests='0' time='0.0' timestamp='' />"


# Generated at 2022-06-25 12:43:10.950536
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestSuite(name='name_0')
    test_case_0.system_out = 'system_out_0'
    test_case_0.system_err = 'system_err_0'
    test_case_0.packages = 'packages_0'
    test_case_0.ids = 'ids_0'
    test_case_0.hostnames = 'hostnames_0'
    test_case_0.disabled = 'disabled_0'
    test_case_0.errors = 'errors_0'
    test_case_0.failures = 'failures_0'
    test_case_0.skipped = 'skipped_0'
    test_case_0.tests = 'tests_0'
    test_case_0.time = 'time_0'
    test

# Generated at 2022-06-25 12:43:20.429446
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        assertions=0,
        classname='String',
        name='Test',
        status='TIMED_OUT',
        time=0.10000000149011612,
        errors=[],
        failures=[],
        skipped= 'private void junit.framework.TestResult.run(TestCase)(TestCase)',
        system_out=None,
        system_err=None)


# Generated at 2022-06-25 12:43:30.385213
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:43:37.607753
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # Arrange
    expectedXml = '<testsuite disabled="0" errors="0" failures="0" hostname="localhost" id="0" name="TestSuite 1" package="" skipped="0" tests="0" time="0.0" timestamp="1970-01-01T00:00:00+00:00"><properties></properties>' \
                  '</testsuite>'

    test_suite = TestSuite(name='TestSuite 1')

    # Act
    test_suite_element = test_suite.get_xml_element()

    # Assert
    xml = ET.tostring(test_suite_element, encoding='unicode')
    assert expectedXml == xml



# Generated at 2022-06-25 12:43:47.408205
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='test')
    element_0 = test_suite_0.get_xml_element()
    assert element_0.tag == 'testsuite'
    assert element_0.attrib == {'name': 'test', 'tests': '0', 'skipped': '0', 'failures': '0', 'errors': '0'}

    test_suite_1 = TestSuite(name='test', id='id', package='pkg', hostname='host')
    element_1 = test_suite_1.get_xml_element()
    assert element_1.tag == 'testsuite'

# Generated at 2022-06-25 12:43:51.678023
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite_0 = TestSuite(
        name='foo',
        system_out='bar')
    xml_string = ET.tostring(testsuite_0.get_xml_element(), method='html', encoding='unicode')
    assert xml_string


# Generated at 2022-06-25 12:43:59.298982
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite_0 = TestSuite(name='org.junit.platform.launcher.listeners.SummaryGeneratingListenerTests')

    element = suite_0.get_xml_element()

    assert True == isinstance(element, ET.Element)
    assert True == isinstance(ET.tostring(element), bytes)
    assert True == suite_0.get_xml_element().tag == "testsuite"
    assert True == suite_0.get_xml_element().attrib["name"] == "org.junit.platform.launcher.listeners.SummaryGeneratingListenerTests"
    assert True == suite_0.get_xml_element().attrib["hostname"] == "localhost"

# Generated at 2022-06-25 12:44:04.721149
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite('test_suite_1')
    test_case_1 = TestCase('test_case_1')
    test_case_2 = TestCase('test_case_2')

    test_suite.cases.append(test_case_1)
    test_suite.cases.append(test_case_2)

    xml = test_suite.get_xml_element()
    print(xml)


# Generated at 2022-06-25 12:44:14.526376
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='Test Suite 0 Name')

    assert _pretty_xml(test_suite_0.get_xml_element()) == '''<testsuite disabled="0" errors="0" failures="0" hostname="None" id="None" name="Test Suite 0 Name" package="None" skipped="0" tests="0" time="0.0" timestamp="None">\n</testsuite>\n'''

    test_suite_0.id = 'test-suite-0-id'
    test_suite_0.hostname = 'test-suite-0-hostname'
    test_suite_0.package = 'test-suite-0-package'
    test_suite_0.timestamp = datetime.datetime.now()
    test_suite

# Generated at 2022-06-25 12:44:21.877687
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()

    test_suite_1 = TestSuite(
        name="testsuite_name_1",
        hostname="testsuite_hostname_1",
        id="testsuite_id_1",
        package="testsuite_package_1",
        timestamp=datetime.datetime.now(),
    )

    test_case_1 = TestCase(
        name="testcase_name_1",
        assertions=1,
        classname="testcase_classname_1",
        status="testcase_status_1",
        time=decimal.Decimal(1),
    )
    test_suite_1.cases.append(test_case_1)

    test_suites_0.suites.append(test_suite_1)

   

# Generated at 2022-06-25 12:44:35.739638
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name="test_case_name_0", assertions=1, classname="test_class_name_0", status="test_status_0", time=1.1)
    test_suite_0 = TestSuite(name="test_name_0", hostname="test_hostname_0", id="test_id_0", package="test_package_0", timestamp=datetime.datetime(2000, 1, 1), properties={"test_property_0": "test_property_value_0"}, cases=[test_case_0], system_out="test_system_out_0", system_err="test_system_err_0")
    test_suite_element_0 = test_suite_0.get_xml_element()

# Generated at 2022-06-25 12:44:41.188941
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Set up
    test_suite = TestSuite('test_suite')
    test_suite.hostname = 'localhost'
    test_suite.id = 'testsuite-id'
    test_suite.package = 'testpackage'
    test_suite.timestamp = datetime.datetime.now()
    test_suite.properties = {'test_property': 'test_value'}
    test_suite.cases = [TestCase('test_case')]
    test_suite.system_out = 'test system out'
    test_suite.system_err = 'test system err'

    # Execute
    test_suite_element = test_suite.get_xml_element()

    # Assert

# Generated at 2022-06-25 12:44:48.755124
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_cases = [TestCase("case 1"),TestCase("case 2"),TestCase("case 3")]
    test_suite = TestSuite("test suite", cases = test_cases)
    root = test_suite.get_xml_element()
    test_cases_new = []
    for child in root:
        name = child.attrib['name']
        test_cases_new.append(TestCase(name))
    test_suite_new = TestSuite("test suite", cases = test_cases_new)
    assert test_suite == test_suite_new


# Generated at 2022-06-25 12:44:55.727670
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='test_case_0', classname='unittest.TestCase', assertions=1, time=decimal.Decimal('0.001'), status='PASS')

    test_suite_0 = TestSuite(name='unittest', cases=[test_case_0])

    xml_element = test_suite_0.get_xml_element()

    # Assert that attributes and sub-elements were generated correctly
    assert xml_element.attrib == {'name': 'unittest', 'tests': '1', 'failures': '0', 'errors': '0', 'disabled': '0', 'time': '0.001', 'skipped': '0'}

# Generated at 2022-06-25 12:45:05.039081
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite("name", "hostname", "id", "package", datetime.datetime.now())
    assert test_suite_0.get_xml_element().tag == "testsuite"
    assert test_suite_0.get_xml_element().attrib['name'] == "name"
    assert test_suite_0.get_xml_element().attrib['hostname'] == "hostname"
    assert test_suite_0.get_xml_element().attrib['id'] == "id"
    assert test_suite_0.get_xml_element().attrib['package'] == "package"
    assert test_suite_0.get_xml_element().attrib['tests'] == "0"
    assert test_suite_0.get_xml_element().att

# Generated at 2022-06-25 12:45:13.327787
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        assertions=5,
        classname="module_name.module_name2.class_name",
        errors=[TestError(
            message="Error message",
            output="Standard error output",
        )],
        failures=[TestFailure(
            message="Failure message",
            output="Standard error output",
        )],
        is_disabled=True,
        name="Test name",
        skipped="Skipped reason",
        system_err="Standard error output",
        system_out="Standard output",
        time=decimal.Decimal('0.2'),
    )


# Generated at 2022-06-25 12:45:21.921004
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=[
        ],
        hostname='Hostname_29508422',
        id='Id_1280551539',
        name='Name_1379756883',
        package='Package_1445423162'
    )
    expected_output = ET.Element('testsuite', {
        'disabled': '0',
        'errors': '0',
        'failures': '0',
        'hostname': 'Hostname_29508422',
        'id': 'Id_1280551539',
        'name': 'Name_1379756883',
        'package': 'Package_1445423162',
        'skipped': '0',
        'tests': '0',
        'time': '0'
    })

# Generated at 2022-06-25 12:45:25.019482
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="test_suite_name")

    expected = ET.fromstring("<testsuite name=\"test_suite_name\"></testsuite>")

    assert(ET.tostring(test_suite_0.get_xml_element()) == ET.tostring(expected))



# Generated at 2022-06-25 12:45:34.060589
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name = 'name_0')
    test_case_0 = TestCase(name = 'name_0')
    test_case_0.skipped = 'skipped_0'
    test_case_0.time = decimal.Decimal('0.00')
    test_suite_0.cases = [test_case_0]

# Generated at 2022-06-25 12:45:40.173552
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # data assignment
    test_suite_0 = TestSuite(name="test", hostname="hostname")
    # test
    test_suite_0_get_xml_element = test_suite_0.get_xml_element()
    assert test_suite_0_get_xml_element == ET.fromstring('<testsuite name="test" hostname="hostname" tests="0" disabled="0" errors="0" failures="0" time="0" />')


# Generated at 2022-06-25 12:45:53.431300
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='a')
    str_0 = test_suite_0.get_xml_element().tostring()
    assert str_0 == b'<testsuite name="a" tests="0" errors="0" disabled="0" failures="0" skipped="0" time="0.0" timestamp="" hostname="" id="" package=""></testsuite>'


# Generated at 2022-06-25 12:45:55.793479
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Test the method get_xml_element of class TestSuite"""
    test_case_0 = TestSuite()
    print(test_case_0.get_xml_element())


# Generated at 2022-06-25 12:45:56.832208
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()



# Generated at 2022-06-25 12:46:00.773008
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create an instance of TestSuite
    testSuite = TestSuite(name='name_0')
    actual = testSuite.get_xml_element()
    expected = ET.fromstring('<testsuite name="name_0" tests="0" failures="0" errors="0" />')
    assert actual == expected


# Generated at 2022-06-25 12:46:03.552826
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite("name", "hostname", "id", "package", "timestamp")
    # No value returned
    test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:46:12.862059
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name = "name1", hostname = "hostname1", id = "id1", package = "package1", timestamp = None, properties = {"a":"b"}, cases = [TestCase(name = "name1", assertions = 1, classname = "classname1", status = "status1", time = decimal.Decimal(".1"), errors = [], failures = [], skipped = None, system_out = "system_out1", system_err = "system_err1", is_disabled = True)], system_out = "system_out1", system_err = "system_err1")

# Generated at 2022-06-25 12:46:22.246629
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """
    Test the get_xml_element method of class TestSuite
    """
    ts1 = TestSuite(name='TestSuite1', hostname='host1.test.testhost.com', timestamp=datetime.datetime.utcnow())
    ts1.properties['test_property1'] = 'test_value1'
    ts1.system_out = 'test_system_out1'
    ts1.system_err = 'test_system_err1'

    tc1 = TestCase(name='TestCase1')
    tc1.classname = 'test_classname1'
    tc1.time = decimal.Decimal(1.1)

    tc2 = TestCase(name='TestCase2')
    tc2.time = decimal.Decimal(2.2)

# Generated at 2022-06-25 12:46:24.855119
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=[],
        hostname=None,
        id=None,
        name='name_0',
        package=None,
        properties={'key_0': 'value_0'},
        system_err=None,
        system_out=None,
        timestamp=None,
    )

    test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:46:33.826787
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name = 'my-suite',
        hostname = 'my-hostname',
        id = 'my-id',
        package = 'my-package',
        timestamp = datetime.datetime.now()
    )

# Generated at 2022-06-25 12:46:37.022237
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='test')
    assert "test=&quot;test&quot;" in _pretty_xml(test_suite_0.get_xml_element())


# Generated at 2022-06-25 12:46:58.563712
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test case 1
    test_suite_1 = TestSuite(name='airport')
    test_suite_1_expected_result = (
        '<testsuite disabled="0" errors="0" failures="0" '
        'hostname="unknown" id="unknown" name="airport" '
        'package="unknown" skipped="0" tests="0" '
        'time="0.0" timestamp="unknown"></testsuite>'
    )
    test_suite_1_result = test_suite_1.get_xml_element()
    assert test_suite_1_result == test_suite_1_expected_result, 'expected: %s \nactual: %s' % (test_suite_1_expected_result, test_suite_1_result)

    # Test case 2

# Generated at 2022-06-25 12:47:00.693165
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite_0 = TestSuite(name='Test', timestamp=None)
    element_0 = testSuite_0.get_xml_element()


# Generated at 2022-06-25 12:47:02.386427
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="")
    test_suite_0.get_xml_element()



# Generated at 2022-06-25 12:47:12.989354
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create expected result
    expected = ET.Element('testsuite')
    expected.attrib['errors'] = '0'
    expected.attrib['failures'] = '0'
    expected.attrib['tests'] = '1'
    expected.attrib['time'] = '0.000'

    test_case_0 = ET.Element('testcase', {'name': 'test_case_0'})
    expected.append(test_case_0)

    test_case_1 = ET.Element('testcase', {'name': 'test_case_1'})
    expected.append(test_case_1)

    # Create actual result
    test_suite_0 = TestSuite(name='test_suite_0')


# Generated at 2022-06-25 12:47:23.325613
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="")
    test_suite_0.suites = []
    test_suite_0.tests = 0
    test_suite_0.properties = {}
    test_suite_0.errors = 0
    test_suite_0.time = decimal.Decimal("0")
    test_suite_0.failures = 0
    test_suite_0.disabled = 0
    test_suite_0.skipped = 0
    test_suite_0.system_err = ""
    test_suite_0.timestamp = datetime.datetime(1, 1, 1, 1, 1, 1, tzinfo=datetime.timezone.utc)
    test_suite_0.hostname = ""

# Generated at 2022-06-25 12:47:32.648594
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='tc_0')
    test_case_0 = TestCase(name='name')
    test_suite_0.cases.append(test_case_0)
    test_suite_et_element = test_suite_0.get_xml_element()
    assert test_suite_et_element.tag == 'testsuite'
    assert test_suite_et_element.attrib.get('name') == 'tc_0'
    assert test_suite_et_element.attrib.get('tests') == '1'
    assert test_suite_et_element.attrib.get('failures') == '0'
    assert test_suite_et_element.attrib.get('errors') == '0'

# Generated at 2022-06-25 12:47:39.196758
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    expected_xml = """
<testsuite disabled="0" errors="0" failures="0" hostname="" id="" name="" package="" skipped="0" tests="0" time="0.0" timestamp="">
</testsuite>
""".lstrip()

    test_suite_0 = TestSuite(name="")
    actual = test_suite_0.get_xml_element()

    assert expected_xml == _pretty_xml(actual)


# Generated at 2022-06-25 12:47:41.341401
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite_0 = TestSuite(None, None, None, None, None)
    xml_element_0 = testSuite_0.get_xml_element()
    xml_element_0.tag



# Generated at 2022-06-25 12:47:46.406875
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestSuite(cases=[], errors=0, failures=0, name='', skipped=0, tests=0, time=0.0)
    assert ET.tostring(test_case_0.get_xml_element(), encoding='utf-8') == b'<testsuite errors="0" failures="0" name="" skipped="0" tests="0" time="0.0"><system-out /><system-err /></testsuite>'



# Generated at 2022-06-25 12:47:48.223346
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='')
    test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:48:05.723231
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name_0')
    test_suite_0.id = 'id_0'
    test_suite_0.hostname = 'hostname_0'
    test_suite_0.package = 'package_0'
    # test_suite_0.timestamp = datetime.datetime()
    test_suite_0.tests = 0
    test_suite_0.errors = 0
    test_suite_0.disabled = 0
    test_suite_0.failures = 0
    test_suite_0.skipped = 0
    test_suite_0.time = decimal.Decimal()


# Generated at 2022-06-25 12:48:12.618159
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:48:23.689173
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create a new test suite
    s = TestSuite(name="OpenMDAO Unit Tests",
                  hostname="localhost",
                  id="1",
                  package="openmdao.api",
                  timestamp=datetime.datetime(2020, 9, 30, 11, 13, 12),
                  properties={"key1": "value1",
                              "key2": "value2"},

                  )
    # Create a new test case
    t = TestCase(name="test_name",
                 assertions=3,
                 classname="test_classname",
                 status="success",
                 time=decimal.Decimal(5.6),
                 )

    # Add errors to test case
    e = TestError(output="error output",
                  message="error message",
                  type="error type",
                  )
    t.errors.append

# Generated at 2022-06-25 12:48:31.591346
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test for initializing of data attributes
    testsuite_0_attributes = {
        'disabled' : '0',
        'errors' : '0',
        'failures' : '0',
        'name' : 'Lorem ipsum',
        'tests' : '0',
        'time' : '0.0',
    }

    # Test for TestSuite class
    test_suite_0 = TestSuite(
        name='Lorem ipsum',
    )
    assert test_suite_0.get_xml_element().attrib == testsuite_0_attributes

    # Test for TestSuite class with default values

# Generated at 2022-06-25 12:48:40.994525
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    print("Test - TestSuite get_xml_element")
    test_suites_0 = TestSuites()
    test_suites_0.name = 'test_suites_0'
    test_suite_0 = TestSuite()
    test_suite_0.name = 'test_suite_0'
    test_suite_0.cases.append(TestCase('test_case_0', classname='class_0', time=1.2345))
    test_suites_0.suites.append(test_suite_0)
    # print(str(test_suites_0.get_xml_element()))
    assert test_suites_0.get_xml_element().tag == 'testsuites'

# Generated at 2022-06-25 12:48:51.644758
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='test_suite_0')
    test_case_0 = TestCase(name='test_case_0')
    test_suite_0.cases.append(test_case_0)
    test_suite_0_get_xml_element = test_suite_0.get_xml_element()
    #print(ET.dump(test_suite_0_get_xml_element))
    assert test_suite_0_get_xml_element.tag == 'testsuite'
    assert test_suite_0_get_xml_element.get('name') == 'test_suite_0'
    assert test_suite_0_get_xml_element.get('tests') == '1'
    assert test_suite_0_get_xml_

# Generated at 2022-06-25 12:48:58.474038
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:49:07.081547
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    MockTestSuite = TestSuite('name', hostname='127.0.0.1', id='1', package='package', timestamp='2020-01-01T01:01:01')
    MockTestCase = TestCase('case_name', assertions=2, classname='classname', status='status', time=3)
    MockTestSuite.add(MockTestCase)
    MockTestSuite.properties['property_name'] = 'property_value'
    MockTestSuite.system_out = 'system_out'
    MockTestSuite.system_err = 'system_err'

# Generated at 2022-06-25 12:49:13.772327
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    element = ET.Element('testsuite', {'tests': '10', 'disabled': '2', 'errors': '3', 'failures': '4', 'time': '5.4', 'name': 'TestSuite'})
    xml_element = ET.tostring(element, encoding='unicode')
    test_suite_0 = TestSuite(tests='10', disabled='2', errors='3', failures='4', time='5.4', name="TestSuite")
    assert xml_element == ET.tostring(test_suite_0.get_xml_element(), encoding='unicode')


# Generated at 2022-06-25 12:49:19.949769
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite("test0", "test1", "test2", "test3", "test4", "test5", "test6", "test7")
    assert test_suite_0.get_xml_element() == ET.Element('testsuite', {'name': 'test0', 'disabled': 'test1', 'errors': 'test2', 'failures': 'test3', 'hostname': 'test4', 'id': 'test5', 'package': 'test6', 'skipped': 'test7', 'tests': '0', 'time': '0'})


# Generated at 2022-06-25 12:49:42.583308
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # Test for when the class TestSuite is called with no parameters
    test_suite_0 = TestSuite(name="")
    output = test_suite_0.get_xml_element()
    expected = '<testsuite name=""></testsuite>'
    assert(output == expected)



# Generated at 2022-06-25 12:49:50.274066
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_a = TestSuite(name='test_module_a')
    test_suite_a_xml = test_suite_a.get_xml_element()
    test_suite_a_expected_xml = '''<testsuite name="test_module_a" tests="0" disabled="0" errors="0" failures="0" skipped="0" time="0"/>'''
    assert (test_suite_a_xml.tag == 'testsuite')
    assert (test_suite_a_xml.attrib == {'name': 'test_module_a', 'tests': '0', 'disabled': '0', 'errors': '0', 'failures': '0', 'skipped': '0', 'time': '0'})