

# Generated at 2022-06-25 12:39:59.473084
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(
        output='lol', message='weee', type='some_tag'
    )
    assert result.get_attributes() == {'message': 'weee', 'type': 'some_tag'}


# Generated at 2022-06-25 12:40:03.506092
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    test_result.message = None
    test_result.output = None
    test_result.type = None

    exp_attributes = {
        'message': None,
        'type': None,
    }

    assert test_result.get_attributes() == exp_attributes


# Generated at 2022-06-25 12:40:15.020007
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    string_0 = 'w}1vj|Wt%8.'
    string_1 = 'kv'
    string_2 = 'N'
    string_3 = 'qj7$'
    string_4 = 'ZQ]<'
    string_5 = 'JhU'
    string_6 = 'O&J'
    string_7 = '{3q+'
    decimal_0 = decimal.Decimal(string_4)
    decimal_1 = decimal.Decimal(string_6)
    datetime_0 = datetime.datetime.now()
    key = string_3
    value = string_3
    is_in = (key) in (value)
    string_8 = 'A'
    string_9 = 'g'
    string_10 = 's'

# Generated at 2022-06-25 12:40:18.863123
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_case_0 = TestCase("name", "assertions", "classname", "status", "time")
    expected = _attributes(
        assertions='assertions',
        classname='classname',
        name='name',
        status='status',
        time='time',
    )
    assert(expected == test_case_0.get_attributes())



# Generated at 2022-06-25 12:40:26.035032
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Test if get_attributes returns the correct object
    result = TestResult(output='string', message='string', type='string')
    assert all(item in result.get_attributes().items() for item in ({'message':'string'}, {'type':'string'}))
    # Test that error is raised if type is not set
    result = TestResult(output='string', message='string', type=None)
    with pytest.raises(TypeError):
        result.get_attributes()


# Generated at 2022-06-25 12:40:34.139381
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite('__main__')
    xml_element = test_suite.get_xml_element()
    assert xml_element.attrib == {'name': '__main__', 'disabled': '0', 'errors': '0', 'failures': '0', 'hostname': None, 'id': None, 'package': None, 'skipped': '0', 'tests': '0', 'time': '0', 'timestamp': None}
    assert ET.tostring(xml_element, encoding='unicode').startswith(b'\n<testsuite name="__main__" disabled="0" errors="0" failures="0"')


# Generated at 2022-06-25 12:40:40.160600
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Getting an instance of TestCase
    str_0 = 'omhc^'
    test_case_0 = TestCase(str_0, str_0, str_0, str_0, str_0)
    # Getting an instance of Element
    test_case_0_xml_element = test_case_0.get_xml_element()
    # Asserting the equality of two strings
    assert test_case_0_xml_element.tag, 'testcase'


# Generated at 2022-06-25 12:40:42.950974
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    str_0 = 'omhc^'
    test_result_0 = TestResult(str_0, str_0, str_0)
    assert_0 = {'output': str_0, 'message': str_0, 'type': str_0}
    assert test_result_0.get_attributes() == assert_0


# Generated at 2022-06-25 12:40:48.455468
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    message_0 = '^c@,l~&#yiX'
    type_0 = 'z5'
    test_result_0 = TestError(message_0, type_0)
    result_0 = test_result_0.get_attributes()
    assert {'message': message_0, 'type': type_0} == result_0, "Expected:\n<{'message': message_0, 'type': type_0}>\nGot:\n<%s>" % result_0


# Generated at 2022-06-25 12:40:54.298944
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    output = 'Output'
    message = 'Message'
    type = 'Type'
    tr = TestResult(output, message, type)
    element = tr.get_xml_element()
    assert element.text == output
    assert element.attrib == {'message': message, 'type': type}


# Generated at 2022-06-25 12:41:02.992257
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    element = TestResult(
        output='output_0',
        message='message_0',
        type='type_0',
    ).get_xml_element()
    assert element.tag == 'TestResult'
    assert element.attrib == {
        'message': 'message_0',
        'type': 'type_0',
    }
    assert element.text == 'output_0'
    assert list(element) == []


# Generated at 2022-06-25 12:41:11.109846
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="test_suite_0")
    expected = '<testsuite disabled="0" errors="0" failures="0" hostname="None" id="None" name="test_suite_0" package="None" skipped="0" tests="0" time="None" timestamp="None"></testsuite>'
    actual = _pretty_xml(test_suite_0.get_xml_element())
    assert expected == actual


# Generated at 2022-06-25 12:41:21.120736
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name='TestSuite0')
    ts.properties = {'key': 'value'}
    ts.timestamp = datetime.datetime(1970, 1, 1, 0, 0, 0)
    ts_element = ts.get_xml_element()
    assert ts_element.tag == 'testsuite'
    assert set(ts_element.attrib) == {'name', 'tests', 'time', 'disabled', 'errors', 'failures', 'skipped', 'timestamp'}

    assert len(ts_element) == 1
    ts_element_properties = ts_element[0]
    assert ts_element_properties.tag == 'properties'
    assert len(ts_element_properties) == 1
    ts_element_properties_property = ts_element_properties[0]
    assert ts_element

# Generated at 2022-06-25 12:41:28.419194
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_case_0 = TestCase()
    test_failure_0 = TestFailure()
    test_failure_0.message = 'message'
    test_failure_0.type = 'type'
    test_failure_0.output = 'output'

    Expected = ET.Element('failure', _attributes(message='message', type='type'))
    Expected.text = 'output'

    Actual = test_failure_0.get_xml_element()
    assert ET.tostring(Actual) == ET.tostring(Expected)


# Generated at 2022-06-25 12:41:34.948924
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test_result_1 = TestResult()
    test_result_2 = TestResult()
    test_result_3 = TestResult()
    test_result_4 = TestResult()
    test_result_5 = TestResult()
    test_result_6 = TestResult()
    test_result_7 = TestResult()
    test_result_8 = TestResult()
    test_result_9 = TestResult()
    test_result_10 = TestResult()
    test_result_11 = TestResult()
    test_result_12 = TestResult()
    test_result_13 = TestResult()
    test_result_14 = TestResult()
    test_result_15 = TestResult()
    test_result_16 = TestResult()
    test_result_17 = TestResult()
   

# Generated at 2022-06-25 12:41:38.817704
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name = "name")
    assert(test_suite_0.get_xml_element() == ET.Element('testsuite', {"name" : "name"}))


# Generated at 2022-06-25 12:41:41.025135
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult(error=None, output=None, type='test_type', message='test_message') 
    expected = ET.Element('failure', {'message':'test_message', 'type':'test_type'})
    assert test_result_0.get_xml_element() == expected


# Generated at 2022-06-25 12:41:48.876377
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Preconditions
    # Create an object of class TestSuite
    test_suite_0 = TestSuite()

    # Invoke method get_xml_element of object test_suite_0
    assert(ET.fromstring(ET.tostring(test_suite_0.get_xml_element(), encoding='unicode')) == ET.fromstring(
        '<testsuite errors="0" failures="0" tests="0" time="0" />'))

    # Postconditions


# Generated at 2022-06-25 12:41:50.803062
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test = TestResult()
    assert test.get_xml_element().tag == 'result'


# Generated at 2022-06-25 12:41:58.636790
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """This tests whether the method of class TestResult works properly, by 
    asserting that the XML element generated by get_xml_element is equal to 
    the expected value calculated from the value of the instance attributes.
    """

# Generated at 2022-06-25 12:42:07.289599
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    # Case 1: All of the data attributes and text attributes are set in the test case
    test_case = TestCase(
        name="TestCase",
        assertions=1,
        classname="TestSuite",
        status="run",
        time=0.001,
        errors=[
            TestError(
                output="There is an error",
                message="Error",
                type="error"
            )
        ],
        failures=[
            TestFailure(
                output="There is a failure",
                message="Fail",
                type="fail"
            )
        ],
        skipped="Skipped",
        system_out="System out",
        system_err="System err"
    )

    # Assert that the attributes in the outputted xml element are the same as those in the test case
    assert test_case.get_xml_element

# Generated at 2022-06-25 12:42:11.381787
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite_0 = TestSuite(name='', hostname='', id='', package='', timestamp=None)
    suite_0.properties = {}
    suite_0.cases = []
    suite_0.system_out = ''
    suite_0.system_err = ''

    xml = suite_0.get_xml_element()



# Generated at 2022-06-25 12:42:20.207063
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_1 = TestSuites()
    test_suite_1 = TestSuite(name="test_suite")
    test_suites_1.suites.append(test_suite_1)
    test_suite_1.timestamp = datetime.datetime.now()
    test_suite_1.hostname = 'hostname'
    test_suite_1.id = 'id'
    test_suite_1.package = 'package'
    test_suite_1.properties = {"key1": "value1"}
    test_case_1 = TestCase(name="test_case")
    test_suite_1.cases.append(test_case_1)
    test_case_1.time = decimal.Decimal(10)
    test_case_1.classname

# Generated at 2022-06-25 12:42:28.191722
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test 1
    test_suite_1 = TestSuite('test_suite_1')
    assert test_suite_1.get_attributes() == {'errors': '0', 'failures': '0', 'tests': '0', 'disabled': '0', 'skipped': '0', 'name': 'test_suite_1', 'time': '0'}
    assert test_suite_1.get_xml_element().tag == 'testsuite'
    assert test_suite_1.get_xml_element().attrib == {'time': '0', 'tests': '0', 'errors': '0', 'disabled': '0', 'skipped': '0', 'name': 'test_suite_1', 'failures': '0'}

    # Test 2
    test_suite_2 = Test

# Generated at 2022-06-25 12:42:35.329302
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    expected = """\
<testsuite disabled="1" errors="0" failures="0" hostname="fake hostname" id="fake id" name="fake name" package="fake package" skipped="0" tests="1" time="11.00">
  <properties>
    <property name="fake name" value="fake value"/>
  </properties>
  \
<testcase assertions="1" classname="fake classname" name="fake name" status="fake status" time="11.00">
  <failure message="fake message" type="fake type">fake output</failure>
</testcase>
  \
<system-out>fake output</system-out>
  \
<system-err>fake error</system-err>
</testsuite>"""

# Generated at 2022-06-25 12:42:46.246465
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name = "TestCase 1")
    test_case_0.name = "TestCase 1"
    test_case_0.assertions = "1"
    test_case_0.classname = "TestClass_0"
    test_case_0.status = "Passed"
    test_case_0.time = "4.55"
    test_case_0.output = "output 001"
    test_case_0.message = "message 1"
    test_case_0.type = "type 1"

    test_case_1 = TestCase(name = "TestCase 2")
    test_case_1.name = "TestCase 2"
    test_case_1.assertions = "2"
    test_case_1.classname = "TestClass_1"

# Generated at 2022-06-25 12:42:51.862350
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    name = 'name'
    test_case_0 = TestCase(name)

    def xml_element_equal(xml_element, expected_xml):
        assert ET.tostring(xml_element, encoding='unicode') == expected_xml

    xml_element_equal(test_case_0.get_xml_element(), '<testcase assertions="0" classname="" name="name" status="0" time="0.0"></testcase>')
    test_case_0.assertions = 1
    test_case_0.classname = "classname"
    test_case_0.status = 1
    test_case_0.time = decimal.Decimal(1.0)
    test_case_0.skipped = "skipped"

# Generated at 2022-06-25 12:43:01.770995
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestSuite()
    test_case_0.name = "test_suite_name"
    test_case_0.hostname = "hostname"
    test_case_0.time = decimal.Decimal(1.2)
    test_case_0.tests = 2
    test_case_0.errors = 3
    test_case_0.disabled = 4
    test_case_0.system_out = ""
    test_case_0.system_err = ""
    test_case_0.id = "id"
    test_case_0.package = "com.package"
    test_case_0.timestamp = datetime.datetime(2020, 10, 22, 17, 54, 51, tzinfo=datetime.timezone.utc)


# Generated at 2022-06-25 12:43:07.958001
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    obj = TestSuite(name="test_case")
    obj.cases = [TestCase(name="test_case_0", classname="test_case_name_0")]
    root = obj.get_xml_element()
    assert root.tag == "testsuite"
    testsuite = root.getchildren()[0]
    assert testsuite.tag == "testcase"
    test_case_0 = testsuite.getchildren()[0]
    assert test_case_0.tag == "testcase"



# Generated at 2022-06-25 12:43:11.237222
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="", timestamp=datetime.datetime.fromisoformat("1970-01-01T00:00:00"))
    xml_element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:43:24.032735
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test Case 1:
    test_suite = TestSuite(
        name = "testSuiteName"
    )
    actual = test_suite.get_xml_element()
    expected = ET.Element('testsuite', {
        'name': 'testSuiteName',
    })
    assert actual == expected
    # Test Case 2:
    test_suite = TestSuite(
        name = "testSuiteName",
        hostname = "unitTestHostname"
    )
    actual = test_suite.get_xml_element()
    expected = ET.Element('testsuite', {
        'hostname': 'unitTestHostname',
        'name': 'testSuiteName',
    })
    assert actual == expected
    # Test Case 3:

# Generated at 2022-06-25 12:43:34.480288
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Test the method get_xml_element of class TestSuite"""
    # Test 1: no properties, test, system_out or system_err
    test_suite_0 = TestSuite()
    test_suite_0.name = "python_junit_dataclasses"
    test_suite_0.hostname = "localhost"
    test_suite_0.id = "0000001"
    test_suite_0.package = "junit-dataclasses"
    test_suite_0.timestamp = "2020-12-08T13:21:33"

    test_case_0 = TestCase()
    test_case_0.name = "test_case_0"
    test_case_0.classname = "class0"
    test_case_0.status = "status0"

# Generated at 2022-06-25 12:43:44.928369
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    element = ET.Element('testsuite', {'disabled':'0', 'errors':'0', 'failures':'0', 'hostname':'DESKTOP-H2QQJ4C', 'id':'2', 'name':'mkdir.mkdir', 'package':'mkdir', 'skipped':'0', 'tests':'4', 'time':'0.0', 'timestamp':'2020-07-13T13:05:34'})
    testsuite_0 = TestSuite('mkdir.mkdir', hostname='DESKTOP-H2QQJ4C', id='2', package='mkdir', timestamp=datetime.datetime(2020, 7, 13, 13, 5, 34), disabled=0, errors=0, failures=0, skipped=0, tests=4, time=0.0)


# Generated at 2022-06-25 12:43:52.349553
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case_0 = TestCase('validado', None, None, 'None', 0)
    test_suite_0 = TestSuite('validado', None, None, None, None)
    test_suites_0 = TestSuites()
    test_suite_0.cases.append(case_0)
    test_suites_0.suites.append(test_suite_0)
    assert test_suites_0.get_xml_element().findall('testsuite/testcase/[@name="validado"]')[0].attrib['time'] == '0'

# Generated at 2022-06-25 12:43:59.767552
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites = TestSuites()
    test_suites.suites = [
        TestSuite(
            id='0',
            name='TestSuite 0',
            tests=3,
            time=3,
            timestamp=datetime.datetime(2019, 1, 1, 0, 0, 0),
            cases=[
                TestCase(
                    name='TestCase 0',
                    time=1,
                ),
                TestCase(
                    name='TestCase 1',
                    time=2,
                ),
                TestCase(
                    name='TestCase 2',
                    time=3,
                ),
            ],
        ),
    ]


# Generated at 2022-06-25 12:44:09.398960
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name="1",hostname="2", id=3, package = "4", timestamp=datetime.datetime.now(),properties={"p1": "v1", "p2": "v2"}, cases=[TestCase(name="name_1")])

# Generated at 2022-06-25 12:44:12.396931
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_instance = get_TestSuite_instance()
    xml_element = test_suite_instance.get_xml_element()
    assert(ET.tostring(xml_element))


# Generated at 2022-06-25 12:44:20.533423
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    test_case_0 = TestCase(
        name="Test Name",
        assertions=20,
        classname="Test Class Name",
        status="Test Status",
        time=0.000,
        skipped="Test Skipped",
        system_out="Test System Out",
        system_err="Test System Err",
    )

    xml_element = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:44:27.207264
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='TestCase0')

    element = test_case_0.get_xml_element()

    assert element.get('name') == 'TestCase0'
    assert element.get('classname') is None
    assert element.get('assertions') is None
    assert element.get('status') is None
    assert element.get('time') is None
    assert element.find('skipped') is None
    assert element.find('error') is None
    assert element.find('failure') is None
    assert element.find('system-out') is None
    assert element.find('system-err') is None



# Generated at 2022-06-25 12:44:31.740050
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    name = "test_case_name"
    test_case_0 = TestCase(name)
    test_case_1 = test_case_0.get_xml_element()
    expected_string = "<testcase name=\"" + name + "\" />"
    assert _pretty_xml(test_case_1) == expected_string


# Generated at 2022-06-25 12:44:45.774423
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite('name',hostname='hostname',id='id',package='package',timestamp=datetime.datetime(2020, 1, 1, 12, 0, 0))
    ts.system_out = 'system_out'
    ts.system_err = 'system_err'
    ts.properties['a'] = 'b'
    tc = TestCase(name='name2',classname='classname',status='status',time=decimal.Decimal(1.2))
    tc.system_out = 'system_out2'
    tc.system_err = 'system_err2'
    tc.skipped = 'skipped'
    tc.is_disabled = True
    tf = TestFailure(message='message',output='output', type='type')

# Generated at 2022-06-25 12:44:51.122117
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case0 = TestCase(name='test-case-0')
    case0.assertions = 1
    case0.classname = 'test_class'
    case0.status = 'FAILURE'
    case0.time = decimal.Decimal('0.2')
    case0.skipped = 'skipped test'

    case0.failures.append(TestFailure(message='it failed'))
    case0.errors.append(TestError(message='it errored', type='my-error-type'))

    case0.system_out = 'this is the system_out'
    case0.system_err = 'this is the system_err'


# Generated at 2022-06-25 12:44:54.364756
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name=1)
    expected_xml_string = "<testcase name=\"1\"/>"
    result = test_case_0.get_xml_element()
    assert ET.tostring(result, encoding='unicode') == expected_xml_string



# Generated at 2022-06-25 12:45:04.299366
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()
    test_suite_0 = TestSuite(name=None)
    test_suites_0.suites.append(test_suite_0)
    result = _pretty_xml(test_suite_0.get_xml_element())
    assert result == "<testsuite errors=\"0\" failures=\"0\" name=\"None\" skipped=\"0\" tests=\"0\" time=\"0\"></testsuite>"
    test_suite_1 = TestSuite(name="", assertions=None, classname=None, status=None, time=None)
    test_suite_0.cases.append(test_suite_1)
    result = _pretty_xml(test_suite_0.get_xml_element())

# Generated at 2022-06-25 12:45:12.815969
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    system_err = None
    system_out = None
    skipped = None
    errors = []
    failures = []
    classname = None
    status = None
    time = None
    assertions = None
    name = "check_health"

    test_case_0 = TestCase(name=name, assertions=assertions, classname=classname, status=status, time=time, errors=errors, failures=failures, skipped=skipped, system_out=system_out, system_err=system_err)
    test_case_0_xml = ET.tostring(test_case_0.get_xml_element()).decode("utf-8")
    assert test_case_0_xml == '<testcase assertions="None" classname="None" name="check_health" status="None" time="None" />'


# Generated at 2022-06-25 12:45:21.594755
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
        ts1 = TestSuite(hostname=None, id="123", name="ts1", package="com.example", cases=[], timestamp="2012-01-01T01:00:01")
        et_ts1 = ET.Element("testsuite", attrib=_attributes(
            disabled="0", errors="0", failures="0", hostname=None, id="123",
            name="ts1", package="com.example", skipped="0", tests="0", time="0", 
            timestamp="2012-01-01T01:00:01"))
        assert ts1.get_xml_element() == et_ts1

        ts2 = TestSuite(hostname="localhost", id="123", name="ts1", package="com.example", cases=[], timestamp="2012-01-01T01:00:01")
        et_

# Generated at 2022-06-25 12:45:23.952958
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite("TestSuite")
    assert _pretty_xml(test_suite.get_xml_element()) == """<?xml version="1.0" ?>
<testsuite />
"""


# Generated at 2022-06-25 12:45:32.883463
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name = "testcase0", assertions = 1, classname = "testclass0", status = "status0", time = decimal.Decimal("0.0"))
    assert (test_case_0.get_xml_element().get("name") == "testcase0")
    assert (test_case_0.get_xml_element().get("assertions") == "1")
    assert (test_case_0.get_xml_element().get("classname") == "testclass0")
    assert (test_case_0.get_xml_element().get("status") == "status0")
    assert (test_case_0.get_xml_element().get("time") == "0.0")


# Generated at 2022-06-25 12:45:41.346382
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=[
            TestCase(
            name='test_case_1_0',
            ),
        ],
        hostname='string_0',
        name='string_1',
        id='string_2',
        package='string_3',
        timestamp=datetime.datetime.now(),
        properties={'test_property_0': 'test_value_0', },
        system_out='string_4',
        system_err='string_5',
    )
    xml_0 = ET.tostring(test_suite_0.get_xml_element(), encoding='unicode')
    # print(xml_0)
    assert xml_0.find('<testsuite') == 0
    assert xml_0.find('<testsuite disabled=') > 0

# Generated at 2022-06-25 12:45:52.421707
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test suite
    test_suite_0 = TestSuite('test_suite_0')
    assert test_suite_0.get_xml_element() == ET.Element('testsuite', {
        'disabled': '0',
        'errors': '0',
        'failures': '0',
        'name': 'test_suite_0',
        'tests': '0',
        'time': '0.0',
    })

    # Test suite with properties
    test_suite_1 = TestSuite('test_suite_1')
    test_suite_1.properties['foo'] = 'bar'

# Generated at 2022-06-25 12:46:00.555247
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite0 = TestSuite(name="TestSuite1")
    result_xml = test_suite0.get_xml_element()
    expected_xml = ET.Element('testsuite', dict(name='TestSuite1'))
    assert(expected_xml.attrib == result_xml.attrib)


# Generated at 2022-06-25 12:46:03.916069
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_suite_0 = TestSuite("name_0", "hostname_0", "id_0", "package_0", datetime.datetime.now())
    assert test_suite_0.get_xml_element() is not None


# Generated at 2022-06-25 12:46:13.398968
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    hostname = 'ABC'
    package = 'org.company.autotest.MyClass'
    testsuite_0 = TestSuite(name='test_case_0', hostname=hostname, package=package)
    system_err = 'This is test case 0'
    testsuite_0.system_err = system_err

    hostname = 'DEF'
    test_case_0 = TestCase(name='test_case_0', classname=hostname)
    status = 'PASS'
    test_case_0.status = status
    time = 1.0
    test_case_0.time = time
    system_out = 'This is test case 0'
    test_case_0.system_out = system_out
    testsuite_0.cases.append(test_case_0)

    host

# Generated at 2022-06-25 12:46:16.905130
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase("name")
    actual = test_case_0.get_xml_element()
    expected = ET.Element("testcase",{"name":"name"})
    assert(actual == expected)



# Generated at 2022-06-25 12:46:25.069594
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="Test 0")
    test_case_1 = TestCase(name="Test 1", time=datetime.datetime.now())
    test_case_2 = TestCase(name="Test 2 with error", time=datetime.datetime.now(), errors=[TestError(output="Error output", message="Error message")])
    test_case_3 = TestCase(name="Test 3 with failure", time=datetime.datetime.now(), failures=[TestFailure(output="Failure output", message="Failure message")])
    test_case_4 = TestCase(name="Test 4 with error and failure", time=datetime.datetime.now(), errors=[TestError(output="Error output", message="Error message")], failures=[TestFailure(output="Failure output", message="Failure message")])

# Generated at 2022-06-25 12:46:29.298288
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('TestCase 0')
    test_case.time = 1.99
    xml = test_case.get_xml_element()
    assert xml.attrib['time'] == '1.99'


# Generated at 2022-06-25 12:46:36.533928
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='test_case_0', name=None, classname=None, status=None, time=None, assertions=None, errors=None, failures=None, skipped=None, system_out=None, system_err=None, is_disabled=False)
    test_suite_0 = TestSuite(name='test_suite_0', id=None, package=None, timestamp=None, hostname=None, properties=None, cases=[test_case_0], system_out=None, system_err=None, name=None, disabled=0, errors=0, failures=0, skipped=0, tests=1, time=None)
    output = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:46:43.159413
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test1')
    # test case without any additional info
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase name="test1"></testcase>'

    # test case with errors and failures
    test_case = TestCase(name='test2', errors=[TestError(message="test error message")], failures=[TestFailure(message="test failure message")])
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase name="test2"><error message="test error message"/><failure message="test failure message"/></testcase>'

    # test case with errors and failures  where the error element was omitted by providing an empty string for message

# Generated at 2022-06-25 12:46:55.754283
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Setup
    test_suite_0 = TestSuite(name='test_suite_0')
    test_case_0 = TestCase(name='test_case_0', assertions=0, classname='test_case_0', status='test_case_0', time=0)
    test_suite_0.cases.append(test_case_0)
    test_case_1 = TestCase(name='test_case_1', assertions=1, classname='test_case_1', status='test_case_1', time=1)
    test_suite_0.cases.append(test_case_1)
    test_case_2 = TestCase(name='test_case_2', assertions=2, classname='test_case_2', status='test_case_2', time=2)
    test_

# Generated at 2022-06-25 12:47:03.764301
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite_0 = TestSuite(name='suite_name', hostname='host_name', id='5', package='package_name', timestamp=datetime.datetime(2008, 7, 2, 11, 52, 31, tzinfo=datetime.timezone.utc))
    suite_0.properties = {'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3'}
    test_case_0 = TestCase(name='test_case_name_0', assertions=6, classname='test_class_name_0', status='status_0', time=decimal.Decimal('0.008'))

# Generated at 2022-06-25 12:47:10.773980
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite_3 = TestSuite(name="",id="",hostname="",package="",timestamp=None,properties=dict(),cases=[],system_out="",system_err="")
    testSuite_3.get_xml_element()

# Generated at 2022-06-25 12:47:20.488197
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case0 = TestCase(
        assertions=12,
        classname="class",
        errors=[
            TestError(
                message="message",
                output="output",
                type="type"
            )
        ],
        failures=[
            TestFailure(
                message="message",
                output="output",
                type="type"
            )
        ],
        name="name",
        skipped="skipped",
        status="status",
        system_err="system_err",
        system_out="system_out",
        time=123
    )
    print(test_case0.get_attributes())
    assert test_case0.get_attributes() == {'assertions': '12', 'classname': 'class', 'name': 'name', 'status': 'status', 'time': '123'}
   

# Generated at 2022-06-25 12:47:30.677804
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test empty suite
    test_suite_0 = TestSuite('TestSuite 0')

    assert test_suite_0.get_xml_element().attrib == {
        'errors': '0',
        'disabled': '0',
        'tests': '0',
        'name': 'TestSuite 0',
        'failures': '0',
        'time': '0.0',
        'skipped': '0',
    }
    assert test_suite_0.get_xml_element().text is None

    # Test suite with properties
    properties_0 = {
        'prop_0': 'value_0',
        'prop_1': 'value_1',
        'prop_2': 'value_2',
    }

# Generated at 2022-06-25 12:47:38.095846
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        name='test_name_0'
    )
    test_suite_0.cases = [ TestCase(
        name='test_name_0'
    ) ]
    test_suite_0.system_out = 'test_system_out_0'
    test_suite_0.system_err = 'test_system_err_0'
    test_suite_0.hostname = 'test_hostname_0'
    test_suite_0.id = 'test_id_0'
    test_suite_0.package = 'test_package_0'
    test_suite_0.timestamp = datetime.datetime(1, 1, 1)

    test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:47:43.775174
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('Test case 0')
    test_case_0.assertions = "0"
    test_case_0.classname = "TestCase0"
    test_case_0.status = "True"
    test_case_0.time = decimal.Decimal("3.0")
    test_case_0.errors = [TestError()]
    test_case_0.failures = [TestFailure()]
    test_case_0.skipped = "False"
    test_case_0.system_out = "False"
    test_case_0.system_err = "False"


# Generated at 2022-06-25 12:47:51.630401
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test = TestSuite('name', 'hostname', 'id', 'package', 'timestamp')
    test.cases.append(TestCase('case1'))
    test.cases.append(TestCase('case2'))
    expected = '<testsuite assertions="0" classname="" disabled="0" errors="0" failures="0" hostname="hostname" id="id" name="name" package="package" skipped="0" tests="2" time="0" timestamp="timestamp"><testcase assertions="0" classname="" name="case1" status="" time="0" /><testcase assertions="0" classname="" name="case2" status="" time="0" /></testsuite>'
    assert ET.tostring(test.get_xml_element(), encoding='unicode') == expected



# Generated at 2022-06-25 12:47:59.372937
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test 0: Normal execution
    test_suites_0 = TestSuites()
    test_suite_0 = TestSuite(name='name')
    test_suites_0.suites.append(test_suite_0)
    assert test_suites_0.to_pretty_xml() == '<?xml version="1.0" ?>\n<testsuites disabled="0" errors="0" failures="0" name="" tests="0" time="0">\n<testsuite disabled="0" errors="0" failures="0" hostname="" id="" name="name" package="" skipped="0" tests="0" time="0" timestamp="">\n</testsuite>\n</testsuites>'
    # Test 1: Normal execution
    test_suites_1 = TestSuites()
    test_su

# Generated at 2022-06-25 12:48:01.467041
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='test suite')
    assert test_suite_0.get_xml_element().text == ''


# Generated at 2022-06-25 12:48:09.494568
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # TestCase TestCase class instance with one of each possible TestResult
    test_case_0 = TestCase("get_xml_element_test0")
    test_case_0.time = decimal.Decimal("0.31")
    test_case_0.failures.append(TestFailure("get_xml_element_TestFailure"))
    test_case_0.errors.append(TestError("get_xml_element_TestError"))

    # TestCase TestCase class instance with default values
    test_case_1 = TestCase("get_xml_element_test1")
    test_case_1.time = decimal.Decimal("0.32")

    # TestCase TestCase class instance with results and system output
    test_case_2 = TestCase("get_xml_element_test2")
    test_case_2.time = decimal

# Generated at 2022-06-25 12:48:12.574666
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    """Test if an XML Element is returned with the desired tag."""

    validation = True

    test_suite_0 = TestSuite(name="test suite 0")

    element = test_suite_0.get_xml_element()

    if element.tag != "testsuite":
        validation = False

    assert (validation == True)



# Generated at 2022-06-25 12:48:26.414250
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name = "Hello World!")
    test_case_xml_element = test_case_0.get_xml_element()
    assert test_case_xml_element.tag == 'testcase', 'Assertion Error'
    assert test_case_xml_element.items() == [('name', 'Hello World!')], 'Assertion Error'


if __name__ == '__main__':
    # test_TestCase_get_xml_element()
    test_case_0()

# Generated at 2022-06-25 12:48:33.522726
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create a TestCase
    test_case_0 = TestCase(name='test_case_0', time=decimal.Decimal('0.1'))
    test_case_0.failures.append(TestFailure(message='test_case_0 failed', output='test-0 output'))
    # Create a TestSuite using the TestCase
    test_suite_0 = TestSuite(name='test_suite_0', timestamp=datetime.datetime(2020, 5, 7, 11, 17, 59))
    test_suite_0.cases.append(test_case_0)
    # Create a TestCase
    test_case_1 = TestCase(name='test_case_1', time=decimal.Decimal('0.2'))

# Generated at 2022-06-25 12:48:42.250926
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Init object
    suite = TestSuite('A test suite')
    suite.name = None
    suite.hostname = None
    suite.id = None
    suite.package = None
    suite.timestamp = None

    suite.properties = {}
    suite.system_out = None
    suite.system_err = None

    # get the xml element
    element = suite.get_xml_element()
    
    assert element.tag == 'testsuite'
    assert element.attrib['tests'] == '0'
    assert element.attrib['disabled'] == '0'
    assert element.attrib['errors'] == '0'
    assert element.attrib['failures'] == '0'
    assert element.attrib['time'] == '0.0000'


# Generated at 2022-06-25 12:48:48.632879
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Instantiate a test case
    test_case_2 = TestCase(
        classname='test_case_classname',
        name='test_case_name'
    )

    xml_str_0 = test_case_2.get_xml_element().tostring()

    assert b"test_case_name" in xml_str_0


# Generated at 2022-06-25 12:48:52.316961
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_suite_0 = TestSuite(name='')
    xml = ET.tostring(test_suite_0.get_xml_element(), encoding='unicode')
    assert xml == '<testsuite disabled="0" errors="0" failures="0" hostname="None" id="None" name="" package="None" skipped="0" tests="0" time="0.0" timestamp="None"></testsuite>'

# Generated at 2022-06-25 12:48:59.071138
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite("name", hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'properties': 'properties'}, cases=[TestCase('name', assertions='1', classname='classname', status='status', time=decimal.Decimal(1), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system-out', system_err='system-err')], system_out='system-out', system_err='system-err')

# Generated at 2022-06-25 12:49:04.464713
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_cases_0 = []
    test_case_name_0 = []
    test_case_name_0.append("test case name 0")
    for test_case_name in test_case_name_0:
        test_case = TestCase(
            name=test_case_name,
        )
        test_cases_0.append(test_case)
    assert test_cases_0[0].name == "test case name 0"


# Generated at 2022-06-25 12:49:13.172926
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite_0 = TestSuite(name="name", hostname=None, id=None, package=None, timestamp=None, properties=dict(), cases=None, system_out=None, system_err=None)
    testSuite_1 = TestSuite(name="name", hostname=None, id=None, package=None, timestamp=None, properties=dict(), cases=None, system_out=None, system_err=None)
    testSuite_2 = TestSuite(name="name", hostname=None, id=None, package=None, timestamp=None, properties=dict(), cases=None, system_out=None, system_err=None)

# Generated at 2022-06-25 12:49:20.972041
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites = TestSuites(name="Jenkins JUnit")


# Generated at 2022-06-25 12:49:26.482210
# Unit test for method get_xml_element of class TestCase

# Generated at 2022-06-25 12:49:41.951094
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()
    assert test_suites_0 is not None
    test_suite_0 = TestSuite(
        'test',
        hostname='localhost',
        id='0.0',
        package='mypackage',
        timestamp=datetime.datetime(2019, 1, 2, 16, 43, 18, 782818),
        time=decimal.Decimal('1.0'),
        tests=1,
    )
    assert test_case_0 is not None

    test_suite_0.cases.append(TestCase(
        name='test_case_0',
        classname='mypackage.test_case_0',
        assertions=1,
        status='PASSED',
        time=decimal.Decimal('1.0'),
    ))

    test_su

# Generated at 2022-06-25 12:49:48.898398
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=1,
        classname='TestCase',
        name='TestCase',
        status='success',
        time=decimal.Decimal('1.0'),
        errors=[],
        failures=[],
        skipped=None,
        system_out=None,
        system_err=None,
        is_disabled=False,
    )
    test_case_0_result = test_case_0.get_xml_element()
    assert _pretty_xml(test_case_0_result) == '<testcase assertions="1"\n          classname="TestCase"\n          name="TestCase"\n          status="success"\n          time="1.0"/>\n'
