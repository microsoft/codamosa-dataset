

# Generated at 2022-06-25 12:40:03.546712
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite_0 = TestSuite()
    test_case_0 = TestCase()
    test_case_1 = TestCase()
    testsuite_0.cases = [test_case_0, test_case_1]
    str_0 = testsuite_0.get_xml_element().tostring()


# Generated at 2022-06-25 12:40:09.153311
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:40:12.749917
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    dict_0 = test_result_0.get_attributes()
    assert dict_0 == {}
    assert test_result_0.type == 'result'



# Generated at 2022-06-25 12:40:15.426897
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    element_0 = test_result_0.get_xml_element()
    assert element_0 == xml.etree.ElementTree.Element()


# Generated at 2022-06-25 12:40:20.466580
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=[
            TestCase(
                classname='',
                errors=[],
                failures=[],
                name='',
                time=decimal.Decimal('0'),
            ),
        ],
        hostname='hostname',
        name='name',
        package='package',
        timestamp=datetime.datetime.now(),
    )
    element_0 = test_suite_0.get_xml_element()
    xml_string = _pretty_xml(element_0)


# Generated at 2022-06-25 12:40:25.082161
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult(output='',
                               message='',
                               type='')
    element_0 = test_result_0.get_xml_element()
    assert element_0.text == test_result_0.output


# Generated at 2022-06-25 12:40:34.406705
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_cases_0 = []
    test_suite_0 = TestSuite('test_name_0', 'test_hostname_0', 'test_id_0', 'test_package_0', None, test_cases_0)
    test_case_0 = TestCase('test_name_1', 'test_classname_0', 'test_status_0', 'test_time_0', [], [], 'test_skipped_0', 'test_system_out_0', 'test_system_err_0')
    test_cases_0.append(test_case_0)
    result_0 = test_suite_0.get_xml_element()

# Generated at 2022-06-25 12:40:36.355811
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    TestCase_instance_0 = TestCase(0.0)
    TestCase_instance_0.get_xml_element()


# Generated at 2022-06-25 12:40:40.458798
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Init a TestResult instance.
    test_result_0 = TestResult()
    # Assert the result of method get_xml_element of test_result_0.
    assert isinstance(test_result_0.get_xml_element(), ET.Element)


# Generated at 2022-06-25 12:40:41.308825
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element() is not None


# Generated at 2022-06-25 12:40:50.842488
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test_result_1 = TestResult()
    assert test_result_0 != test_result_1
    assert test_result_0.get_xml_element() != test_result_1.get_xml_element()


# Generated at 2022-06-25 12:40:54.455730
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():

    test_failure_0 = TestFailure()
    assert test_failure_0.get_xml_element().tag == 'failure'



# Generated at 2022-06-25 12:41:01.433649
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=[],
        name="name",
    )
    try:
        assert ET.tostring(test_suite_0.get_xml_element()) == b'<testsuite disabled="0" errors="0" failures="0" hostname="None" id="None" name="name" package="None" skipped="0" tests="0" time="0" timestamp="None" />'
    except AssertionError:
        raise AssertionError(test_suite_0.get_xml_element())


# Generated at 2022-06-25 12:41:13.307907
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestFailure()
    assert _pretty_xml(test_result_0.get_xml_element()) == '<?xml version="1.0" ?>\n<failure />\n'
    test_failure_0 = TestFailure(
        output = '2lX9nOs8xnLFc7Vk1dz4',
        type = 'HPTc7ZnPnI',
        message = 'LAnH1iZIaTgRn',
    )

# Generated at 2022-06-25 12:41:23.673781
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestFailure(
        message="""
      <b>This is a message</b>
      """,
        output="""
      <b>This is an output</b>
      """,
        type="""
      <b>This is a type</b>
      """,
    )
    class_name = 'TestResult'
    method_name = 'get_attributes'
    result = test_result_0.get_attributes()
    assert isinstance(result, dict)
    assert len(result) == 2
    expected = {'message': """
      <b>This is a message</b>
      """, 'type': """
      <b>This is a type</b>
      """}
    assert sorted(result.items()) == sorted(expected.items())


# Generated at 2022-06-25 12:41:26.223876
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element().get('type') == 'TestResult'


# Generated at 2022-06-25 12:41:30.711464
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_failure_0 = TestFailure(output='foo', message='bar', type='baz')
    assert 'foo' == test_failure_0.get_xml_element().text
    assert 'bar' == test_failure_0.get_xml_element().attrib['message']
    assert 'baz' == test_failure_0.get_xml_element().attrib['type']


# Generated at 2022-06-25 12:41:35.669080
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    testResult = TestResult()
    assert testResult.get_xml_element().tag == testResult.tag
    assert testResult.get_xml_element().attrib == {}
    assert testResult.get_xml_element().text == testResult.output


# Generated at 2022-06-25 12:41:38.349843
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_failure_0 = TestFailure()
    assert test_failure_0.get_attributes() == {}


# Generated at 2022-06-25 12:41:43.050894
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_failure_0 = TestFailure(message='test_message', type='test_type')
    return_value = test_failure_0.get_xml_element()
    assert str(return_value) == '<failure message="test_message" type="test_type"></failure>'


# Generated at 2022-06-25 12:41:49.871179
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='TestCase-0')
    assert test_case_0.get_xml_element().tag == 'testcase'


# Generated at 2022-06-25 12:41:58.034992
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0_0 = TestCase(
        assertions=None,
        classname=None,
        errors=[],
        failures=[],
        is_disabled=False,
        name='test_TestSuite_get_xml_element',
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None,
    )

# Generated at 2022-06-25 12:42:01.649793
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('test_case_0')
    test_case_0.time = 0.0

    expected_xml = '<testcase assertions="0" classname="None" name="test_case_0" time="0.0" />'

    actual_xml = test_case_0.get_xml_element()

    assert _pretty_xml(actual_xml) == expected_xml


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 12:42:13.223607
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        assertions = 0,
        classname = "classname",
        errors = [],
        failures = [],
        name = "name",
        skipped = "skipped",
        system_err = "system_err",
        system_out = "system_out",
        time = 0.01,
    )

# Generated at 2022-06-25 12:42:20.541471
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name="TestCase0")

    test_suite_0 = TestSuite(name="TestSuite0")
    test_suite_0.cases = [test_case_0]
    assert _pretty_xml(test_suite_0.get_xml_element()) == '<testsuite disabled="0" errors="0" failures="0" hostname="None" id="None" name="TestSuite0" package="None" skipped="0" tests="1" time="0.0" timestamp="None">\n  <testcase assertions="None" classname="None" name="TestCase0" status="None" time="None"/>\n</testsuite>\n'


# Generated at 2022-06-25 12:42:28.447348
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    test_case_0 = TestCase(name="test_case_0")

    # Test that method get_xml_element() on TestCase works
    test_case_0_element = ET.fromstring(test_case_0.get_xml_element().toxml())

    # Test that attribute classname is '' when one was not specified.
    assert test_case_0_element.get('classname') == ''

    # Test that the value of attribute name is set properly in the XML.
    assert test_case_0_element.get('name') == 'test_case_0'

    # Test that the value of attribute status is set properly in the XML.
    assert test_case_0_element.get('status') == '0'

    # Test that the value of attribute time is set properly in the XML.
    assert test_case_

# Generated at 2022-06-25 12:42:35.968228
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Preconditions
    test_name = 'test_name'
    test_timestamp = datetime.datetime.now()
    test_properties = {
        'property0': 'value0',
        'property1': 'value1',
    }

# Generated at 2022-06-25 12:42:40.898193
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    s = '<testcase name="test_case_0" assertions="0" classname="__main__" status="run" time="0.0"></testcase>'
    test_case = TestCase('test_case_0', 0, '__main__', 'run', 0.0)
    assert _pretty_xml(test_case.get_xml_element()) == s


# Generated at 2022-06-25 12:42:48.148374
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TestSuite_0 = TestSuite(name='TestSuite_0', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)
    TestCase_0 = TestCase(name='TestCase_0', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)
    TestSuite_0.cases.append(TestCase_0)


# Generated at 2022-06-25 12:42:58.097730
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(hostname=None, errors=0, time=decimal.Decimal('0E-17'), name='name_value', skipped='skipped_value', tests=0, disabled=0, id=None, failures=0, package='package_value', timestamp=None)

    expected_value = '''<testsuite disabled="0" errors="0" failures="0" name="name_value" skipped="skipped_value" tests="0" time="0E-17"><skipped>skipped_value</skipped></testsuite>'''

    actual_value = ET.tostring(test_suite_0.get_xml_element(), encoding='unicode')

    assert actual_value == expected_value


# Generated at 2022-06-25 12:43:14.316530
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    startTime = datetime.datetime.now().isoformat(timespec='seconds')
    test_suite_1 = TestSuite(name="FirstSuite", timestamp=startTime, hostname="hostname", id="1")
    test_case_1 = TestCase(name="FirstCase", time=3.0, assertions=2, classname="TestCase", status="First")
    test_case_2 = TestCase(name="FirstCase", time=4.0, assertions=4, classname="TestCase", status="Done")
    test_suite_1.cases.append(test_case_1)
    test_suite_1.cases.append(test_case_2)
    xmlElement = test_suite_1.get_xml_element()

# Generated at 2022-06-25 12:43:23.448070
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        classname='test_test_case_0.py',
        name='test_test_case_0',
        time=decimal.Decimal('1.234')
    )
    test_case_0.errors.append(TestError(message='An error occurred'))
    test_case_0.failures.append(TestFailure(message='A failure occurred'))
    test_case_0.skipped = "SkippedTestCase"

    xml_element = test_case_0.get_xml_element()
    assert xml_element.tag == "testcase"
    assert xml_element.attrib["name"] == "test_test_case_0"
    assert xml_element.attrib["classname"] == "test_test_case_0.py"
    assert xml_

# Generated at 2022-06-25 12:43:27.030365
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name = None)
    xml = ET.tostring(test_suite_0.get_xml_element())
    assert xml == b'<testsuite />'


# Generated at 2022-06-25 12:43:29.541334
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='foo')
    assert test_case_0.get_xml_element().tag == 'testcase'



# Generated at 2022-06-25 12:43:37.759187
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    assert '<testcase name="test_case_0" />' == ET.tostring(test_case_0.get_xml_element()).decode('utf-8')

    test_case_1 = TestCase(name='test_case_1', assertions='1')
    assert '<testcase assertions="1" name="test_case_1" />' == ET.tostring(test_case_1.get_xml_element()).decode('utf-8')

    test_case_2 = TestCase(name='test_case_2', classname='TestCase')

# Generated at 2022-06-25 12:43:47.605150
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    expected_output = '''
<?xml version="1.0" ?>
<testsuite disabled="1" errors="0" failures="0" hostname="hostname" id="id" name="name" package="package" skipped="2" tests="3" time="1.23" timestamp="1970-01-01T00:00:01">
<testcase assertions="4" classname="classname" name="name" status="status" time="1.23">
<failure message="message" type="type"><![CDATA[output]]></failure>
</testcase>
</testsuite>
    '''

    testCase = TestCase(name="name", assertions=4, classname="classname", status="status", time=decimal.Decimal('1.23'))
    testCase.output="output"
    testCase

# Generated at 2022-06-25 12:43:57.014147
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name="test_case0")
    test_case_1 = TestCase(name="test_case1")
    test_case_2 = TestCase(name="test_case2")
    test_suite_0 = TestSuite(name="test_suite0", cases=[test_case_0, test_case_1, test_case_2])
    test_suite_2 = TestSuite(name="test_suite2", cases=[test_case_0])

    test_suites_0 = TestSuites(suites=[test_suite_0, test_suite_2])

    # Actual output
    pretty_xml = test_suites_0.to_pretty_xml()

    # Expected output

# Generated at 2022-06-25 12:44:05.687765
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts1 = TestSuite(name='TestSuite1',hostname='hostname1',id='0',package='package1',timestamp=datetime.datetime(2020, 1, 1, 0, 0, 0),properties={'p1':'v1'},cases=[TestCase(name='TestCase1',classname='classname1',time=0),TestCase(name='TestCase2',classname='classname2',time=1),TestCase(name='TestCase3',classname='classname3',time=2)],system_out='system_out1',system_err='system_err1')

# Generated at 2022-06-25 12:44:08.621516
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    ET.tostring(test_case_0.get_xml_element())


# Generated at 2022-06-25 12:44:17.882094
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:44:33.379862
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="test0")
    assert ET.tostring(test_suite_0.get_xml_element(), encoding='unicode') == '<testsuite name="test0" tests="0" time="0" />'


# Generated at 2022-06-25 12:44:36.646028
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Test get_xml_element."""
    # Arrange
    suite_0 = TestSuite(cases=[
        TestCase(name="test_case_0")
    ])

    # Act
    element = suite_0.get_xml_element()

    # Assert
    assert element.find("testcase").attrib["name"] == "test_case_0"


# Generated at 2022-06-25 12:44:41.871958
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="suite name", timestamp=datetime.datetime.now(), cases=[TestCase(name="case name", assertions=1, classname="class name", status="status", time=2), TestCase(name="case name", assertions=1, classname="class name", status="status", time=2)])

    test_case1 = TestCase(name="case name", assertions=1, classname="class name", status="status", time=2)
    test_case2 = TestCase(name="case name", assertions=1, classname="class name", status="status", time=2)

    test_suite.cases.append(test_case1)
    test_suite.cases.append(test_case2)

    xml_element = test_suite.get_xml_element()


# Generated at 2022-06-25 12:44:42.790433
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    assert True



# Generated at 2022-06-25 12:44:50.307041
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(assertions=5,
                           classname='org.sonar.batch.phases.PhasesCountConsumerTest',
                           name='testNoEvents',
                           status='FAILURE',
                           time=0.0)
    xml_string = test_case_0.get_xml_element().tostring(encoding='unicode')
    assert xml_string == """<testcase assertions="5" classname="org.sonar.batch.phases.PhasesCountConsumerTest" name="testNoEvents" status="FAILURE" time="0.0"/>"""


# Generated at 2022-06-25 12:44:52.891487
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase()
    test_suite_0 = TestSuite()
    test_suites_0 = TestSuites()
    assert test_suite_0.get_xml_element() is not None


# Generated at 2022-06-25 12:45:02.829831
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    timestamp = datetime.datetime.now()

    test_case_0 = TestCase(name="sample_case", assertions=3, classname="sample_class", status="sample_status", time=0.2, skipped="sample_skipped", system_out="sample_system_out", system_err="sample_system_err")
    test_case_1 = TestCase(name="sample_case_1", assertions=4, classname="sample_class_1", status="sample_status_1", time=0.3, skipped="sample_skipped_1", system_out="sample_system_out_1", system_err="sample_system_err_1")


# Generated at 2022-06-25 12:45:05.553182
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case = TestCase("case 0")
    xml = case.get_xml_element()
    assert xml.tag == 'testcase'
    assert xml.attrib['name'] == 'case 0'


# Generated at 2022-06-25 12:45:13.650026
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test a testsuite with empty testcases
    test_suite_0 = TestSuite("Test1.py", hostname = "TestHost", package = "TestPackage", timestamp = datetime.datetime(2005, 10, 31, 18, 23))
    element = ET.fromstring(test_suite_0.get_xml_element().tostring("utf-8"))
    assert element.tag == 'testsuite'
    assert element.attrib == {'hostname' : 'TestHost', 'name' : 'Test1.py', 'package' : 'TestPackage', 'timestamp' : '2005-10-31T18:23:00'}
    assert element[0].tag == 'properties'
    assert element[1].tag == 'system-out'
    assert element[1].text == 'None'
    assert element

# Generated at 2022-06-25 12:45:22.163315
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(assertions=None, classname=None, errors=[], failures=[],is_disabled=False, name='test_case_0', skipped=None, status=None, system_err=None, system_out=None, time=None)
    test_suite_0 = TestSuite(cases=[test_case_0], disabled=None, errors=None, failures=None,hostname=None, id=None, name='test_suite_0', package=None, skipped=None,system_err=None, system_out=None, tests=None, time=None, timestamp=None)
    actual_test_suite_0_get_xml_element = test_suite_0.get_xml_element()

# Generated at 2022-06-25 12:45:55.643779
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Create a test case.
    test_case_0 = TestCase(name='test_case_0')

    # Add a failure to the test case.
    test_failure_0 = TestFailure(
        message='Test failure 0',
        output='Failure output 0',
    )
    test_case_0.failures.append(test_failure_0)

    # Add an error to the test case.
    test_error_0 = TestError(
        message='Test error 0',
        output='Error output 0',
    )
    test_case_0.errors.append(test_error_0)

    test_case_xml = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:45:58.079829
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_name')
    assert test_case_0.get_xml_element().tag == 'testcase'
    assert test_case_0.get_xml_element().get('name') == 'test_name'



# Generated at 2022-06-25 12:46:05.550177
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testcase_instance_0 = TestCase(classname="MyTestClass", name="testMethod", time=1.0)
    testcase_instance_1 = TestCase(classname="MyTestClass2", name="testMethod2", time=2.0)
    testcase_instance_2 = TestCase(classname="MyTestClass3", name="testMethod3", time=3.0)
    testsuite_instance_0 = TestSuite(name="MyTestSuite", cases=[testcase_instance_0, testcase_instance_1, testcase_instance_2], timestamp=datetime.datetime(2020, 5, 20, 14, 25, 0, 91254))

# Generated at 2022-06-25 12:46:15.582188
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # Test testsuite

    # Test Suite
    test_suite_0 = TestSuite(name='TestSuite0')
    # Test Case
    test_case_0 = TestCase(name='testCase0', assertions=10, classname='class0', status='status0', time=decimal.Decimal(time_0))
    
    # Optional
    test_case_0.errors      = [TestError(output='error0')]
    test_case_0.failures    = [TestFailure(output='failure0')]
    test_case_0.skipped     = 'skipped0'
    test_case_0.system_out  = 'systemOut0'
    test_case_0.system_err  = 'systemErr0'
    # Append test case to test suite
    test_su

# Generated at 2022-06-25 12:46:24.061262
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # assertEqual(self, first, second, msg=None)
    # assertEqual(a, b, msg=None)
    assertEqual(TestSuite(name = "test suite").get_xml_element(), 'testsuite')
    assertEqual(TestCase(name = "test case").get_xml_element(), 'testcase') #test case
    assertEqual(TestCase(name = "test case", time = 0.0).get_xml_element(), 'testcase')
    assertEqual(TestCase(name = "test case", time = 0.0, errors = [1]).get_xml_element(), 'testcase') #with errors
    assertEqual(TestCase(name = "test case", time = 0.0, failures = [1]).get_xml_element(), 'testcase') #with failures
    assertE

# Generated at 2022-06-25 12:46:33.059431
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    x = datetime.datetime.now()
    y = TestSuite(name='test', id='1', timestamp=x)
    y.cases.append(TestCase(output='out.txt', message='ok', name='test1', assertions=1, classname='test',
                            status='test', time=0.001, errors=[], failures=[], is_disabled=True))
    y.cases.append(TestCase(output='out2.txt', message='ok', name='test2', assertions=1, classname='test',
                            status='test', time=0.002, errors=[], failures=[], is_disabled=False))

    y.system_out = 'System out'
    y.system_err = 'System err'

    # Tests to see if the method returns an XML Element

# Generated at 2022-06-25 12:46:40.791354
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Create test suite
    test_suite_0 = TestSuite(name='foo', hostname='bar')

    # Create test case
    test_case_0 = TestCase(
        name='foo',
        assertions=1,
        classname='bar',
        status='foo',
        time=0.0,
        failures=[],
        errors=[],
        skipped='foo',
        system_out='foo',
        system_err='foo',
    )

    # Add test case to test suite
    test_suite_0.cases.append(test_case_0)

    # Create XML element
    xml_element = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:46:46.601480
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # instantiation
    test_case_0 = TestCase()
    test_case_0.name = "TestCase0"
    test_case_1 = TestCase()
    test_case_1.name = "TestCase1"
    test_suite_0 = TestSuite()
    test_suite_0.name = "TestSuite0"
    test_suite_0.timestamp = datetime.datetime(2020, 7, 1, 6, 50, 47, 812875)
    test_suite_0.cases = [test_case_0, test_case_1]
    # call function
    result = test_suite_0.get_xml_element()

# Generated at 2022-06-25 12:46:51.736207
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        name='test_case_0',
        assertions=1,
        classname='Test_class',
        status='success',
        time=decimal.Decimal(1.25),
    )
    test_case_1 = TestCase(
        name='test_case_1',
        assertions=1,
        classname='Test_class',
        status='error',
        time=decimal.Decimal(1.25),
    )
    test_case_2 = TestCase(
        name='test_case_2',
        assertions=1,
        classname='Test_class',
        status='failure',
        time=decimal.Decimal(1.25),
    )

# Generated at 2022-06-25 12:47:00.922452
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    testsuite_name = "TestSuiteName"
    testsuite_time = decimal.Decimal(0.0)

    # build a test case
    testcase_name = "testcase_name"
    testcase_message = "testcase_message"
    testcase_time = decimal.Decimal(0.0)
    testcase = TestCase(testcase_name)
    testcase.errors.append(TestError(testcase_message, testcase_message, testcase_message))
    testcase.time = testcase_time

    # build the test suite
    testsuite = TestSuite(testsuite_name)
    testsuite.cases.append(testcase)
    testsuite.time = testsuite_time

    element = testsuite.get_xml_element()

    # perform the comparison

# Generated at 2022-06-25 12:47:36.984452
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    text = """<?xml version="1.0" ?>
<testsuite name="suite" tests="1" failures="1" errors="0" skipped="0" disabled="0" time="0.000" timestamp="2020-09-05T16:26:20">
    <testcase name="test" time="0.000"></testcase>
</testsuite>
"""
    testcase = TestCase("test")
    testcase.failures.append(TestFailure("Fail"))
    suite = TestSuite("suite")
    suite.cases.append(testcase)
    suites = TestSuites("test")
    suites.suites.append(suite)
    assert _pretty_xml(suites.get_xml_element()) == text

# Generated at 2022-06-25 12:47:44.044967
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    package_name = "org.junit.platform.commons.util"
    hostname = "localhost"
    timestamp = datetime.datetime(
        year=2020, month=1, day=1,
        hour=13, minute=15, second=0
    )
    test_suite = TestSuite(
        package=package_name, hostname=hostname,
        timestamp=timestamp, name="TestSuite"
    )
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == "testsuite"
    assert xml_element.attrib["name"] == "TestSuite"
    assert xml_element.attrib["package"] == package_name
    assert xml_element.attrib["hostname"] == hostname

# Generated at 2022-06-25 12:47:51.873332
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """
    Test the result of get_xml_element of class TestSuite

    """

    test_case = TestCase(name='test_case_0')
    test_suite = TestSuite(name='test_suite_0', cases=[test_case])

    test_suite_xml = test_suite.get_xml_element()


# Generated at 2022-06-25 12:47:55.839976
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='')
    xml_element = test_case_0.get_xml_element()
    expected_xml_element = ET.fromstring("<testcase name=''></testcase>")
    assert(xml_element.tag == expected_xml_element.tag)
    assert(xml_element.attrib == expected_xml_element.attrib)


# Generated at 2022-06-25 12:48:03.833939
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:48:09.310679
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # TestCase to be tested
    test_case_actual = TestCase(name = 'test_case_name_actual')

    # TestCase expected
    test_case_expected = ET.Element('testcase', _attributes(name='test_case_name_actual'))

    # Testing whether the expected is equal to actual
    assert ET.tostring(test_case_expected, encoding='unicode') == ET.tostring(test_case_actual.get_xml_element(), encoding='unicode')



# Generated at 2022-06-25 12:48:13.080493
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    name = "Test Suite 1"
    id = "ID"
    hostname = "127.0.0.1"
    package = "Test Package 1"
    timestamp = "2020-04-29T14:34:24"

    test_suite_0 = TestSuite(name, id, hostname, package, timestamp)

    #Test Case 1: empty test suite
    assert( True )

    #Test Case 2: test suite with one testcase



# Generated at 2022-06-25 12:48:23.613614
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TestSuite_get_xml_element_value = '''<testsuite disabled="0" errors="0" failures="0" hostname="None" id="None" name="None" package="None" skipped="0" tests="0" time="0.0" timestamp="None">
<properties />
<system-out />
<system-err />
</testsuite>
'''
    TestSuite_get_xml_element_instance = TestSuite(name = 'None')
    TestSuite_get_xml_element_result = _pretty_xml(TestSuite_get_xml_element_instance.get_xml_element())
    assert TestSuite_get_xml_element_value == TestSuite_get_xml_element_result


# Generated at 2022-06-25 12:48:30.773395
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    ts = TestSuite(name = "TestSuite_pytest_plugin")

    xml_element = ts.get_xml_element()

    assert xml_element.tag == "testsuite"
    assert xml_element.get("name") == "TestSuite_pytest_plugin"
    assert xml_element.get("errors") == "0"
    assert xml_element.get("failures") == "0"
    assert xml_element.get("skipped") == "0"
    assert xml_element.get("tests") == "0"
    assert xml_element.get("time") == "0.0"
    assert xml_element.get("disabled") == "0"
    

# Generated at 2022-06-25 12:48:40.209792
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name = 'TestSuite0'
    )
    xml_element = test_suite.get_xml_element()
    assert isinstance(xml_element, ET.Element)
    assert xml_element.tag == 'testsuite'
    assert len(xml_element.attrib) == 6
    assert 'name' in xml_element.attrib
    assert 'tests' in xml_element.attrib
    assert 'failures' in xml_element.attrib
    assert 'disabled' in xml_element.attrib
    assert 'errors' in xml_element.attrib
    assert 'time' in xml_element.attrib
    assert xml_element.attrib['name'] == 'TestSuite0'
    assert xml_element.attrib['tests'] == '0'

# Generated at 2022-06-25 12:49:45.599439
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='test_class_0.test_method_0', time=decimal.Decimal('0.040'))
    test_case_1 = TestCase(name='test_class_0.test_method_1', time=decimal.Decimal('0.040'))
    test_suite = TestSuite(name = 'test_class_0', cases=[test_case_0, test_case_1])
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_class_0'
    assert test_suite.get_xml_element().attrib['tests'] == '2'

#Unit test for method get_xml_element of class testSuites

# Generated at 2022-06-25 12:49:50.402878
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    tc = TestCase(name='foo')
    elem = tc.get_xml_element()
    assert elem.tag == 'testcase'
    assert elem.attrib['name'] == 'foo'
    assert len(elem.getchildren()) == 0

