

# Generated at 2022-06-25 12:40:05.818098
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result_0 = TestResult(output=None, message=None, type=None)
    result_0_result = result_0.get_xml_element()
    assert isinstance(result_0_result, ET.Element)
    assert result_0_result.tag == "testresult"
    assert result_0_result.text is None
    assert len(result_0_result.attrib) == 0


# Generated at 2022-06-25 12:40:08.909644
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult('test_output')
    assert result.get_xml_element().findall('.') is None


# Generated at 2022-06-25 12:40:18.405620
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:40:22.102384
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    xml_string = '<failure type="AssertionError" message="Test Failure Message">Output</failure>'
    expected_dict = {'message': 'Test Failure Message', 'type': 'AssertionError'}
    actual_attributes = TestFailure(message='Test Failure Message', output='Output', type='AssertionError').get_attributes()
    assert expected_dict == actual_attributes, 'TestResult.get_attributes() not returning the correct dictionary'


# Generated at 2022-06-25 12:40:25.289602
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == _attributes(
        message=None,
        type=None,
    )



# Generated at 2022-06-25 12:40:32.793495
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_TestResult_0 = TestResult(output='test_TestResult_0')
    assert test_TestResult_0.get_attributes() == {}
    test_TestResult_0.message = 'test_TestResult_0'
    assert test_TestResult_0.get_attributes() == {'message': 'test_TestResult_0'}
    test_TestResult_0.type = 'test_TestResult_0'
    assert test_TestResult_0.get_attributes() == {'message': 'test_TestResult_0', 'type': 'test_TestResult_0'}


# Generated at 2022-06-25 12:40:35.111812
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_suites0 = TestSuites()

    assert test_suites0.get_attributes() == {'disabled':'','errors':'','failures':'','name':'','tests':'','time':''}

# Generated at 2022-06-25 12:40:39.558364
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case_0 = TestCase(name = 'my_first_test_case')
    assert case_0.get_xml_element().tag == 'testcase'
    assert case_0.get_xml_element().attrib['name'] == 'my_first_test_case'



# Generated at 2022-06-25 12:40:44.412620
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    dummy = TestResult(
        output = "dummy",
        message = "dummy",
        type = "dummy"
    )
    output = dummy.get_attributes()
    assert(isinstance(output, dict))
    assert("message" in output)
    assert("type" in output)
    assert(output["message"] == "dummy")
    assert(output["type"] == "dummy")


# Generated at 2022-06-25 12:40:55.774988
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_1 = TestResult()
    assert test_result_1.get_attributes() == {'type': 'TestResult'}

    test_result_2 = TestResult(message='Test message.')
    assert test_result_2.get_attributes() == {'message': 'Test message.', 'type': 'TestResult'}

    test_result_3 = TestResult(type='Test type.')
    assert test_result_3.get_attributes() == {'type': 'Test type.'}

    test_result_4 = TestResult(message='Test message.', type='Test type.')
    assert test_result_4.get_attributes() == {'message': 'Test message.', 'type': 'Test type.'}


# Generated at 2022-06-25 12:41:05.330648
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_to_test = TestCase(name = 'TestName')
    xml_test_case = test_case_to_test.get_xml_element()
    assert xml_test_case.attrib['name'] == 'TestName'


# Generated at 2022-06-25 12:41:15.372575
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name = 'test-suite', hostname = 'hostname', id = 'id', package = 'package', timestamp = datetime.datetime(year=2020, month=1, day=1, hour=1), properties = {'key':'value'}, cases = [], system_out = 'system-out', system_err = 'system-err')
    test_suite_element = test_suite.get_xml_element()
    assert test_suite_element.tag == 'testsuite'
    assert len(test_suite_element) == 3
    assert test_suite_element.find('properties').find('property').find('property') == None
    assert test_suite_element.find('system-out').find('system-out') == None
    assert test_suite_element

# Generated at 2022-06-25 12:41:16.705360
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    a = TestCase(name="Test Case Name")
    assert a.get_xml_element().tag == 'testcase'


# Generated at 2022-06-25 12:41:18.695083
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    result = ET.Element(test_result_0.tag)
    assert result is not None



# Generated at 2022-06-25 12:41:28.743557
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    expected_result = """<testsuite name="test" disabled="0" errors="0" failures="0" hostname="host" id="id" package="package" skipped="0" tests="1" time="1.0" timestamp="2019-12-24T12:00:00">
  <testcase assertions="1" classname="classname" name="test" status="status" time="1.0" />
</testsuite>"""
    suite = TestSuite(name="test",
                      hostname="host",
                      id="id",
                      package="package",
                      timestamp=datetime.datetime(2019, 12, 24, 12),
                      tests=1,
                      time=1.0)

# Generated at 2022-06-25 12:41:30.702749
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult(output="output", message="message", type="type")
    assert test_result_0.get_xml_element().tag == "result"


# Generated at 2022-06-25 12:41:33.663812
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestSuite()
    assert result.get_xml_element() == []


# Generated at 2022-06-25 12:41:36.226662
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='JRMP')
    ET.ElementTree(test_suite_0.get_xml_element())


# Generated at 2022-06-25 12:41:48.126386
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="TestSuite1")
    test_case_0 = TestCase(name="TestCase1", classname="classname1", time=decimal.Decimal('0.01'))
    test_suite_0.cases.append(test_case_0)

    assert _pretty_xml(test_suite_0.get_xml_element()) == """\
<?xml version="1.0" ?>
<testsuite errors="0" failures="0" name="TestSuite1" disabled="0" tests="1" hostname="" time="0.01" skipped="0">
  <testcase classname="classname1" assertions="None" name="TestCase1" status="" time="0.01"/>
</testsuite>
"""


# Generated at 2022-06-25 12:41:57.024681
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name = "TestSuite", hostname = "localhost", id = "1", package = "package", timestamp = "2019-08-13T21:43:21", properties = {"property" : "value"}, cases = [TestCase(name = "TestCase-0", classname = "class", status = "status", time = "0.0", errors = [], failures = [], skipped = "", system_out = "", system_err = "")], system_out = "", system_err = "")
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['disabled'] == '0'
    assert xml_element.attrib['errors'] == '0'

# Generated at 2022-06-25 12:42:05.314491
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions = 0,
        classname = "TestCase.classname",
        errors = [],
        failures = [],
        name = "TestCase.name",
        skipped = "TestCase.skipped",
        status = "TestCase.status",
        system_err = "TestCase.system_err",
        system_out = "TestCase.system_out",
        time = 0,
    )
    expected = ET.Element('testcase', {'assertions': '0', 'classname': 'TestCase.classname', 'name': 'TestCase.name', 'status': 'TestCase.status', 'time': '0'})

# Generated at 2022-06-25 12:42:12.601989
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # instantiate a TestResult object
    test_result_0 = TestResult(
        type='Error',
        output='Test Error',
        message='Test Error - 0'
    )

    expected_xml_substring = "Error"
    actual_xml = test_result_0.get_xml_element().tostring(encoding='unicode')

    assert expected_xml_substring in actual_xml, f"Expected substring '{expected_xml_substring}' not in XML output: {actual_xml}"


# Generated at 2022-06-25 12:42:16.636025
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite = TestSuite(name="some_suite_name")
    xml_string = ET.tostring(testSuite.get_xml_element(), encoding='unicode')
    assert xml_string == '<testsuite failures="0" name="some_suite_name" tests="0" />'


# Generated at 2022-06-25 12:42:19.178139
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase("test case name", 1, 'test class name', 'test status', .1)
    assert test_case_0.get_xml_element().attrib == {'assertions': '1', 'classname': 'test class name', 'name': 'test case name', 'status': 'test status', 'time': '0.1'}



# Generated at 2022-06-25 12:42:21.625766
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name = "name")
    element = test_case_0.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == test_case_0.name


# Generated at 2022-06-25 12:42:24.624375
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='TestSuite-name0')
    assert "<testsuite name=\"TestSuite-name0\" tests=\"0\" disabled=\"0\" errors=\"0\" failures=\"0\" time=\"0.0\" />" == ET.tostring(test_suite_0.get_xml_element(), encoding="unicode")


# Generated at 2022-06-25 12:42:33.146431
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Test case where self.output is None
    test_result_0 = TestResult(output=None, message=None, type=None)
    xml_element = ET.Element("testresult")
    assert test_result_0.get_xml_element().attrib == xml_element.attrib
    assert test_result_0.get_xml_element().text == xml_element.text

    # Test case where self.message is None
    test_result_1 = TestResult(output="", message=None, type=None)
    xml_element = ET.Element("testresult")
    xml_element.text = ""
    assert test_result_1.get_xml_element().attrib == xml_element.attrib
    assert test_result_1.get_xml_element().text == xml_element.text

    # Test case where

# Generated at 2022-06-25 12:42:35.179700
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    testResult_0 = TestResult()
    assert testResult_0.get_xml_element() is not None


# Generated at 2022-06-25 12:42:39.837658
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('<test_case name>')
    expected = '<testcase assertions="" classname="" name="&lt;test_case name&gt;" status="" time=""></testcase>'
    actual = _pretty_xml(test_case_0.get_xml_element())
    assert actual == expected


# Generated at 2022-06-25 12:42:44.980519
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
	failure0 = TestFailure(output='this is an Output', message='this is a message', type='this is a type');
	assert failure0.get_xml_element() == ET.Element('failure', {'message':'this is a message', 'type':'this is a type'});


# Generated at 2022-06-25 12:43:00.031236
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_1 = TestCase(name='TestClass.test_method')
    test_case_2 = TestCase(name='TestClass.test_method', classname='TestClass', time=2.0)
    test_case_3 = TestCase(name='TestClass.test_method', assertion=3)
    test_case_4 = TestCase(name='TestClass.test_method', system_err='This is the error output')
    test_case_5 = TestCase(name='TestClass.test_method', system_out='This is the standard output')
    test_case_6 = TestCase(name='TestClass.test_method', errors=[TestError()])
    test_case_7 = TestCase(name='TestClass.test_method', failures=[TestFailure()])

    assert test_case_1.get_xml

# Generated at 2022-06-25 12:43:07.364219
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite('test')
    test_case = TestCase('test')
    test_case.errors.append(TestError())
    test_case.system_err = 'Error!'
    test_suite.cases.append(test_case)
    root = test_suite.get_xml_element()
    assert root[0][0].text == 'test'
    assert root[0][1].text == '0'
    assert root[0][2].text == '0'
    assert root[0][3].text == '1'
    assert root[0][4].text == '1'



# Generated at 2022-06-25 12:43:16.897279
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=[TestCase(name='TestCase 0')],
        hostname="TestHostname 0",
        id="TestId 0",
        name="TestName 0",
        package="TestPackage 0",
        properties={"TestProperty 0": "TestPropertyValue 0"},
        system_err="TestSystemErr 0",
        system_out="TestSystemOut 0",
        timestamp=datetime.datetime(2020, 6, 28, 18, 0)
    )

# Generated at 2022-06-25 12:43:22.263119
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name_0')
    expected = ET.fromstring(
        '<testsuite name="name_0" tests="0" errors="0" failures="0" disabled="0" skipped="0" time="0.0"/>')
    actual = test_suite_0.get_xml_element()
    assert _pretty_xml(actual) == _pretty_xml(expected)


# Generated at 2022-06-25 12:43:27.643741
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite("name", "hostname", "id", "package", datetime.datetime.now(),
                             {"a": "b"}, [TestCase("name", "classname", "status", "2.2")], "system_out",
                             "system_err")
    assert test_suite_0.get_xml_element() is not None


# Generated at 2022-06-25 12:43:33.330444
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=[TestCase(
            assertions=1,
            name='test_case_0',
            time=decimal.Decimal(1.0),
        )],
        name='test_suite_0',
        tests=1,
    )

    assert test_suite_0.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-25 12:43:44.544565
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        assertions=None,
        classname=None,
        errors=[ ],
        failures=[ ],
        is_disabled=False,
        name='test_case_0',
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None
    )
    test_suite_0 = TestSuite(
        cases=[ test_case_0 ],
        errors=None,
        failures=None,
        hostname=None,
        id=None,
        name=None,
        package=None,
        properties={ },
        skipped=None,
        system_err=None,
        system_out=None,
        timestamp=None,
        tests=None,
        time=None
    )
    element = ET

# Generated at 2022-06-25 12:43:50.514651
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    expected = ET.Element('testcase', {'name': 'test_case_0'})
    actual = test_case_0.get_xml_element()

    assert expected.tag == actual.tag
    assert expected.attrib == actual.attrib
    assert expected.text == actual.text
    assert expected.tail == actual.tail



# Generated at 2022-06-25 12:43:58.602774
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('TestCase_name')
    xml_element_0 = ET.Element('testcase', test_case_0.get_attributes())

    if test_case_0.skipped is not None:
        xml_element_0.append(ET.Element('skipped', test_case_0.skipped))

    for error_0 in test_case_0.errors:
        xml_element_0.append(error_0.get_xml_element())

    for failure_0 in test_case_0.failures:
        xml_element_0.append(failure_0.get_xml_element())

    if test_case_0.system_out is not None:
        xml_element_0.append(ET.Element('system-out', test_case_0.system_out))



# Generated at 2022-06-25 12:44:08.420576
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Test that get_xml_element returns a testcase element with attributes that match the testcase"""
    test_case = TestCase(
        name="TestCase_test_name",
        assertions=1,
        classname="TestCase_test_classname",
        status="TestCase_test_status",
        time=decimal.Decimal('1.1'),
    )
    root = test_case.get_xml_element()
    assert root.tag == "testcase"
    assert len(root.attrib) == 5
    assert root.attrib["name"] == "TestCase_test_name"
    assert root.attrib["assertions"] == "1"
    assert root.attrib["classname"] == "TestCase_test_classname"

# Generated at 2022-06-25 12:44:20.853949
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    xmltest = ET.fromstring('<testsuite name="testname" tests="1" errors="0" failures="0" hostname="hostname" time="0" timestamp="2020-04-10T20:25:17" id="id" skipped="1" disabled="1" />')
    temp = TestSuite(name="testname", hostname="hostname", id="id", timestamp=datetime.datetime(2020,4,10,20,25,17))
    test_case_0 = TestCase(name="testname", time=0)
    temp.cases.append(test_case_0)
    temp.time = 0
    temp.tests = 1
    temp.disabled = 1
    temp.errors = 0
    temp.failures = 0
    temp.skipped = 1


# Generated at 2022-06-25 12:44:27.932740
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_suites_1 = TestSuites()
    test_suite_1 = TestSuite(name='name', package='package')
    test_suites_1.suites.append(test_suite_1)
    test_case_1_1 = TestCase(name='name_1')
    test_suite_1.cases.append(test_case_1_1)
    test_case_1_2 = TestCase(name='name_2')
    test_suite_1.cases.append(test_case_1_2)
    test_case_1_3 = TestCase(name='name_3')
    test_suite_1.cases.append(test_case_1_3)
    test_suite_2 = TestSuite(name='name')
    test_suites_1

# Generated at 2022-06-25 12:44:32.485340
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name0')
    test_suite_element_0 = test_suite_0.get_xml_element()
    assert test_suite_element_0.tag == 'testsuite'
    assert test_suite_element_0.get('name') == 'name0'


# Generated at 2022-06-25 12:44:38.475597
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_1 = TestCase('test_case_1')

    test_suite_2 = TestSuite('test_suite_2')
    test_suite_2.cases.append(test_case_1)

    expected_xml = '<testsuite/>'
    actual_xml = _pretty_xml(test_suite_2.get_xml_element())
    
    assert actual_xml == expected_xml


# Generated at 2022-06-25 12:44:43.011828
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='my-test-suite')
    expected = '<testsuite errors="0" failures="0" name="my-test-suite" skipped="0" tests="0" time="0" />'
    actual = _pretty_xml(test_suite_0.get_xml_element())
    assert actual == expected


# Generated at 2022-06-25 12:44:52.359920
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Arrange
    test_suite = TestSuite(name='name_0', hostname='hostname_0', id='id_0', package='package_0', timestamp='2016-10-16T21:29:31')

    # Act
    result = test_suite.get_xml_element()

    # Assert
    print(result.tag)
    print(result.get('name'))
    print(result.get('hostname'))
    print(result.get('id'))
    print(result.get('package'))
    print(result.get('timestamp'))
    assert result.tag == 'testsuite'
    assert result.get('name') == 'name_0'
    assert result.get('hostname') == 'hostname_0'

# Generated at 2022-06-25 12:45:01.372177
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase('test_case_name')
    test_case.skipped = 'skipped_reason'
    test_suite_0 = TestSuite('test_suite_name')
    test_suite_0.cases.append(test_case)
    test_suite_0_xml = test_suite_0.get_xml_element()
    assert test_suite_0_xml.get('name') == 'test_suite_name'
    assert test_suite_0_xml.find('testcase').get('name') == 'test_case_name'
    assert test_suite_0_xml.find('testcase').find('skipped').text == 'skipped_reason'


# Generated at 2022-06-25 12:45:04.857664
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.name == 'test_case'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-25 12:45:13.179108
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0_instance = TestSuite(
        cases = [
            TestCase(
                classname = "my.package.MyClass",
                name = "myMethod(my.package.MyClass)",
                time = decimal.Decimal("0.055"),
            ),
            TestCase(
                classname = "my.package.MyClass",
                name = "myMethod2(my.package.MyClass)",
                time = decimal.Decimal("0.003"),
            ),
        ],
        name = "my.package.MyClass",
        package = "my.package",
        tests = 2,
        time = decimal.Decimal("0.058"),
    )
    assert test_case_0_instance.get_xml_element().tag == 'testsuite'

# Generated at 2022-06-25 12:45:20.322904
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('test_1')
    
    assert ET.tostring(test_case.get_xml_element()) == b'<testcase name="test_1" />'

    test_case.is_disabled = True
    assert ET.tostring(test_case.get_xml_element()) == b'<testcase name="test_1" />'

    test_case.time = 1.0
    assert ET.tostring(test_case.get_xml_element()) == b'<testcase assertions="0" classname="" name="test_1" status="RUN" time="1.0" />'



# Generated at 2022-06-25 12:45:31.382282
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()
    xml = _pretty_xml(test_suites_0.get_xml_element())
    xml = xml.replace('\r\n', '\n').replace('\r', '\n')
    lines = ["<?xml version '1.0' encoding='UTF-8'?>",
             '<testsuites tests="0"/>']                      # No tests
    assert xml == '\n'.join(lines)



# Generated at 2022-06-25 12:45:40.414384
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    import tempfile
    import os

    testsuite_0 = TestSuite(name='testsuite_name_0')
    test_case_0 = TestCase(name='test_case_name_0')
    testsuite_0.cases.append(test_case_0)
    with tempfile.NamedTemporaryFile(mode='wt', suffix='.xml', delete=False) as temp:
        temp.write(testsuite_0.to_pretty_xml())

# Generated at 2022-06-25 12:45:46.523981
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    expected_out = '<testcase name="test_case_0" />'
    test_case_0 = TestCase(name="test_case_0")
    out = test_case_0.get_xml_element().tostring(encoding='unicode')
    assert out == expected_out

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 12:45:50.109569
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='TestSuite')
    # isinstance(object, class-or-type-or-tuple)
    assert isinstance(test_suite_0.get_xml_element(), ET.Element)


# Generated at 2022-06-25 12:45:54.138863
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='MyTest')
    xml_string = test_suite.get_xml_element().decode()
    assert xml_string == '<testsuite name="MyTest" tests="0" disabled="0" errors="0" failures="0" skipped="0" time="0"/>'


# Generated at 2022-06-25 12:46:00.248489
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        name = "test_suite_0",
        hostname= "localhost",
        id = "1",
        package = "package",
        timestamp = datetime.datetime.fromtimestamp(1599492243),
        properties = {},
        cases = [],
        system_out = "",
        system_err = "",
        disabled=0,
        errors=0,
        failures=0,
        skipped=0,
        tests=0,
        time=0,
    )

# Generated at 2022-06-25 12:46:06.868068
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:46:10.865822
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='foo')
    result = test_case.get_xml_element()

    expected = ET.fromstring('<testcase assertions="0" classname="None" name="foo" status="None" time="None"></testcase>')
    assert result == expected


# Generated at 2022-06-25 12:46:20.544698
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('name_0')
    result_0 = test_suite_0.get_xml_element()
    assert result_0 == ET.Element('testsuite', _attributes(
        id=None,
        name='name_0',
        tests=0,
        disabled=0,
        errors=0,
        failures=0,
        skipped=0,
        hostname=None,
        package=None,
        time=0,
    ))
    test_suite_1 = TestSuite('name_1', hostname='hostname_0')
    result_1 = test_suite_1.get_xml_element()

# Generated at 2022-06-25 12:46:27.298207
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    test_suite_0.name = 'name'
    test_suite_0.hostname = 'hostname'
    test_suite_0.id = 'id'
    test_suite_0.package = 'package'
    test_suite_0.timestamp = datetime.datetime(2020, 3, 12, 0, 0)
    test_suite_0.properties = {'key': 'value'}
    test_case_1 = TestCase()
    test_case_1.name = 'name'
    test_case_1.assertions = 8
    test_case_1.classname = 'classname'
    test_case_1.status = 'status'

# Generated at 2022-06-25 12:46:39.807324
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite_attributes = {'name': 'name', 'hostname': 'hostname', 'id': 'id', 'package': 'package', 'timestamp': 'timestamp', 'disabled': 'disabled', 'errors': 'errors', 'failures': 'failures', 'skipped': 'skipped', 'tests': 'tests', 'time': 'time', }
    suite_attributes = _attributes(**suite_attributes)
    xml_element = ET.Element('testsuite', suite_attributes)
    test_suite_0 = TestSuite('name')
    test_suite_0.get_xml_element()
    assert test_suite_0.get_xml_element() == xml_element


# Generated at 2022-06-25 12:46:44.338681
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()
    test_suite_0 = TestSuite('', '', '', '', '', properties={})
    test_case_0 = TestCase('', '', '', '', '')
    test_suite_0.cases.append(test_case_0)
    test_suite_0.get_xml_element()
    test_suites_0.suites.append(test_suite_0)
    assert type(test_suite_0.get_xml_element()) == ET.Element


# Generated at 2022-06-25 12:46:53.666835
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_1 = TestCase(name='test_case_1')
    test_case_1_xml_element = test_case_1.get_xml_element()
    test_case_1_xml_element_string = ET.tostring(test_case_1_xml_element, encoding='unicode')
    assert test_case_1_xml_element_string == '<testcase name="test_case_1" />'


# Generated at 2022-06-25 12:47:02.353025
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="my_name", hostname="my_hostname", id="my_id", package="my_package", timestamp=datetime.datetime.now())
    assert (ET.tostring(test_suite_0.get_xml_element()).decode("utf-8")) == '<testsuite disabled="0" errors="0" failures="0" hostname="my_hostname" id="my_id" name="my_name" package="my_package" skipped="0" tests="0" time="0">\n</testsuite>'
    test_suite_1 = TestSuite(name="my_name", hostname="my_hostname", id="my_id", package="my_package", timestamp=datetime.datetime.now())
    test_suite_

# Generated at 2022-06-25 12:47:05.525671
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite("name_0")
    et_element_0 = test_suite_0.get_xml_element()
    assert et_element_0.tag == "testsuite"
    assert et_element_0.attrib['name'] == "name_0"

# Test xml output for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:47:14.933311
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        classname="classname",
        name="name"
    )

    name_attr = "name"
    test_case_0_attr = test_case_0.get_attributes()
    # check that name attribute is in the test_case_0.get_attributes()
    assert name_attr in test_case_0_attr
    # check that the name field value is reflected in the name attribute value
    assert test_case_0_attr[name_attr] is test_case_0.name

    classname_attr = "classname"
    # check that classname attribute is in the test_case_0.get_attributes()
    assert classname_attr in test_case_0_attr
    # check that the classname field value is reflected in the classname attribute value
   

# Generated at 2022-06-25 12:47:25.847039
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name = "test_name",
        hostname = "test_hostname",
        id = "test_id",
        package = "test_package",
        timestamp = datetime.datetime(2020, 1, 7, 14, 24, 10),
        properties = {"test_property1" : "test_value1", "test_property2" : "test_value2"},
        cases = [TestCase(name="test_name1",assertions=10,classname="test_classname",status="test_status",time=0.5, system_out="test_output1")],
        system_out = "test_output",
        system_err = "test_error",
    )
    assert test_suite.name == "test_name"
    assert test_suite.host

# Generated at 2022-06-25 12:47:29.747809
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('TestCase_0')
    actual_0 = test_case_0.get_xml_element()
    expected_0 = ET.Element('testcase', {'name': 'TestCase_0'})
    assert actual_0 == expected_0


# Generated at 2022-06-25 12:47:37.503284
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    print("\n\nTest 1 : get_xml_element for TestSuite\n")
    test_suite_0 = TestSuite(name="name_0", errors=0, failures=0, id="id_0", timestamp=datetime.datetime.utcnow(), disabled=0, hostname="hostname_0", package="package_0", skipped=0, tests=0, time=0, system_err="system_err_0", system_out="system_out_0")
    root = ET.Element("root")
    root.append(test_suite_0.get_xml_element())
    print("\nFollowing is the input to get_xml_element method : ")
    print("\n", ET.dump(root))
    print("\nFollowing is the output of get_xml_element method : ")

# Generated at 2022-06-25 12:47:42.571430
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('test_case_0')

    test_case_0_xml_element_0 = test_case_0.get_xml_element()

    assert test_case_0_xml_element_0.tag == 'testcase'
    assert test_case_0_xml_element_0.attrib == {'name': 'test_case_0'}
    assert test_case_0_xml_element_0.text == ''
    assert len(test_case_0_xml_element_0) == 0



# Generated at 2022-06-25 12:47:51.450607
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TestSuite_0 = TestSuite(name='name_0')
    TestSuite_0.cases.append(TestCase(name='name_1'))
    TestSuite_0.cases.append(TestCase(name='name_2'))
    TestSuite_0.cases.append(TestCase(name='name_3'))

    print(TestSuite_0.get_xml_element())


# Generated at 2022-06-25 12:47:56.955876
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    assert ET.tostring(test_suite_0.get_xml_element(), encoding='unicode') == \
           '<testsuite tests="0" disabled="0" errors="0" failures="0" time="0" />'
    test_suite_1 = TestSuite(name='test_name',
                             hostname='test_hostname',
                             id='test_id',
                             package='test_package',
                             timestamp=datetime.datetime(2020, 1, 2, 3, 4, 5),
                             system_out='system out',
                             system_err='system err')

# Generated at 2022-06-25 12:48:05.551736
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_1 = TestCase(
        name='test_case_1',
        assertions=2,
        classname='foo.Bar',
        status='success',
        time=decimal.Decimal('0.1234'),
    )

    test_suite_0 = TestSuite(
        name='test_suite_0',
        hostname='hostname0',
        id='id0',
        package='package0',
        timestamp=datetime.datetime.now(),
    )

    test_suite_0.properties['propA'] = 'abc'
    test_suite_0.properties['propB'] = '123'

    test_suite_0.cases.append(test_case_1)

# Generated at 2022-06-25 12:48:12.463677
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite('testSuite')
    suite.errors = 1
    suite.failures = 2
    suite.time = decimal.Decimal(3)
    suite.cases = [
        TestCase('testCase0', time=decimal.Decimal(0)),
        TestCase('testCase1', time=decimal.Decimal(1)),
        TestCase('testCase2', time=decimal.Decimal(2)),
    ]
    element = suite.get_xml_element()
    assert suite.errors == int(element.get('errors'))
    assert suite.failures == int(element.get('failures'))
    assert str(suite.time) == element.get('time')
    assert 'testsuite' == element.tag

# Generated at 2022-06-25 12:48:18.075106
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test')
    assert test_case_0.get_xml_element().tag == 'testcase'
    assert test_case_0.get_xml_element().attrib == {'name': 'test'}
    assert test_case_0.get_xml_element().text == None


# Generated at 2022-06-25 12:48:27.310699
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """
    <testcase classname="UnitTest.A" name="test_A" time="0.1">
      <error type="unittest.case.SkipTest" message="Skipped!">…</error>
      <failure type="ValueError" message="Error!">…</failure>
      <skipped message="Skipped!">…</skipped>
      <system-err/>
      <system-out/>
    </testcase>
    """


# Generated at 2022-06-25 12:48:34.102371
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        'test1',
        hostname='hostname_0',
        id='id_0',
        package='package_0',
        properties={
            'key_0': 'value_0',
            'key_1': 'value_1',
            'key_2': 'value_2',
        },
        timestamp=datetime.datetime(2000, 2, 1, 0, 29, 41, 538000),
    )


# Generated at 2022-06-25 12:48:42.862759
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    
    test_suite_0  = TestSuite(name="JUnitXmlReporter")
    test_case_0   = TestCase(classname="JUnitXmlReporter", name="JUnitXmlReporter should allow the use of mocha describe", time=0.005)
    test_result_0 = TestError()
    test_suite_0.cases.append(test_case_0)
    test_case_0.errors.append(test_result_0)
    result_0 = test_case_0.get_xml_element()
    assert result_0.tag == 'testcase'
    assert result_0.attrib['classname'] == 'JUnitXmlReporter'

# Generated at 2022-06-25 12:48:46.208725
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()
    test_case_0 = TestCase(name = "")
    test_suite_0 = TestSuite(name = "", cases = [test_case_0])
    test_suite_0.get_xml_element()
    assert True # TODO: implement your test here

#Unit test for method get_pretty_xml of class TestSuite

# Generated at 2022-06-25 12:48:52.123056
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_suite_0 = TestSuite(name='name_0')
    test_suite_1 = TestSuite(name='name_1')
    test_suite_2 = TestSuite(name='name_2')
    test_case_0 = TestCase(name='name_0')
    test_case_1 = TestCase(name='name_1')
    test_case_2 = TestCase(name='name_2')
    test_case_3 = TestCase(name='name_3')
    test_case_4 = TestCase(name='name_4')
    test_suite_0.cases.append(test_case_0)
    test_suite_1.cases.append(test_case_1)
    test_suite_2.cases.append(test_case_2)


# Generated at 2022-06-25 12:49:06.471214
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:49:14.977686
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testCase_0 = TestCase("testCase_0")
    testCase_0.time = 2
    testCase_0.is_disabled = True
    testCase_0.classname = "testCase_0_class"
    testCase_0.status = "testCase_0_status"
    testCase_0.output = "testCase_0_output"
    testCase_0.failures = []
    testCase_0.errors = []

    testCase_1 = TestCase("testCase_1")
    testCase_1.time = 3
    testCase_1.classname = "testCase_1_class"
    testCase_1.status = "testCase_1_status"
    testCase_1.output = "testCase_1_output"
    testCase_1.failures = []
   

# Generated at 2022-06-25 12:49:19.097770
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()
    test_suite_0 = TestSuite("name", timestamp=datetime.datetime.now())
    test_suites_0.suites.append(test_suite_0)
    xml_element = test_suite_0.get_xml_element()
    assert xml_element.tag == "testsuite"

# Generated at 2022-06-25 12:49:22.988472
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TestSuite_0 = TestSuite(
        cases=[],
        hostname='Amsterdam',
        id='0',
        name='TestSuite 0',
        package='nl.amsterdam',
        timestamp=datetime.datetime(2020, 1, 17, 20, 24, 43),
        system_out='',
        system_err='',
    )
    TestSuite_xml_element = TestSuite_0.get_xml_element()
    print(TestSuite_xml_element)



# Generated at 2022-06-25 12:49:29.968680
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="name_0")
    test_suite_0.id = "id_0"
    test_suite_0.package= "package_0"
    test_suite_0.timestamp = "timestamp_0"
    test_suite_0.properties = {"properties_key_0": "properties_value_0"}

    test_case_0 = TestCase(name="name_0")
    test_case_0.classname = "classname_0"
    test_case_0.status = "status_0"
    test_case_0.system_out = "system_out_0"
    test_case_0.system_err = "system_err_0"

    test_case_1 = TestCase(name="name_1")
   

# Generated at 2022-06-25 12:49:36.455433
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    assert ET.tostring(test_case_0.get_xml_element()) == b'<testcase name="test_case_0" />'

    test_case_1 = TestCase(
        name='test_case_1',
        assertions=0,
        classname='Foo',
        status='failed',
        time=decimal.Decimal('1.2'),
    )
    assert ET.tostring(test_case_1.get_xml_element(), encoding='unicode') == '<testcase assertions="0" classname="Foo" name="test_case_1" status="failed" time="1.2" />'


# Generated at 2022-06-25 12:49:44.985140
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_suite_0 = TestSuite(name="test_suite_0")
    test_case_0 = TestCase(name="test_case_0")
    test_suite_0.cases.append(test_case_0)
    test_suites_0 = TestSuites()
    test_suites_0.suites.append(test_suite_0)
    test_suites_0_actual = test_suites_0.get_xml_element()

# Generated at 2022-06-25 12:49:50.210590
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('name_0')
    ET.SubElement(ET.Element('testcase', test_case_0.get_attributes()), 'skipped').text = test_case_0.skipped
