

# Generated at 2022-06-25 12:40:16.799348
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:40:27.412559
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_suite_0 = TestSuite(name='name0')
    test_suite_1 = TestSuite(name='name1')

    test_suite_0_element = test_suite_0.get_xml_element()
    test_suite_1_element = test_suite_1.get_xml_element()

    if not (test_suite_0_element.tag == 'testsuite' and test_suite_1_element.tag == 'testsuite'):
        print('test_TestSuite_get_xml_element: FAIL - test_suite_0_element.tag: {0}, test_suite_1_element.tag: {1}'.format(test_suite_0_element.tag, test_suite_1_element.tag))

# Generated at 2022-06-25 12:40:34.460142
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()
    assert TestSuite(name='noname', cases=[]).get_xml_element().attrib == {'name': 'noname', 'tests': '0', 'failures': '0', 'skipped': '0', 'errors':'0', 'time': '0.0000000', 'disabled': '0'}
    testSuite = TestSuite(name='noname')
    testSuite.cases.append(TestCase(name='noname'))
    assert testSuite.get_xml_element().attrib == {'name': 'noname', 'tests': '1', 'failures': '0', 'skipped': '0', 'errors': '0', 'time': '0.0000000', 'disabled': '0'}


# Generated at 2022-06-25 12:40:39.143475
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert test_case.get_xml_element().tag == "testcase"
    assert test_case.get_xml_element().attrib['name'] == "test_name"
    assert len(test_case.get_xml_element().attrib) == 1


# Generated at 2022-06-25 12:40:42.839296
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_0")
    xml_element = test_case_0.get_xml_element()
    assert ET.tostring(xml_element, encoding='unicode') == '<testcase name="test_case_0" />'


# Generated at 2022-06-25 12:40:46.604299
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite('name')
    expected = ET.Element('testsuite', {'name': 'name', 'errors': '0', 'time': '0.00', 'tests': '0'})
    assert ET.tostring(test_suite.get_xml_element()) == ET.tostring(expected)



# Generated at 2022-06-25 12:40:56.380436
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test a full coverage of the method resulting in no errors
    test_case_list = [TestCase(
        name='testCaseName',
        assertions=28,
        classname='testClassName',
        status='success',
        time=100
    )]
    test_suite_0 = TestSuite(
        name='testSuiteName',
        hostname='testHostname',
        timestamp=datetime.datetime.now()
    )
    test_suite_0.cases = test_case_list

    assert test_suite_0.get_xml_element() is not None


# Generated at 2022-06-25 12:41:03.587450
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """
    Unit test for method get_xml_element of class TestSuite
    """
    test_case_0 = TestCase('test_case_0', is_disabled=False, errors=[], failures=[], skipped=None, system_out=None, system_err=None)
    test_suite_0 = TestSuite('test_suite_0', disabled=0, errors=0, failures=0, hostname=None, id=None, name='test_suite_0', package=None, skipped=0, tests=1, time=0, timestamp=None, system_out=None, system_err=None, cases=[test_case_0], properties=dict())

# Generated at 2022-06-25 12:41:14.724552
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:41:20.040057
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        name='test_case_0',
        assertions=None,
        classname='testclass_0',
        status='Error',
        time=None,
        errors=[TestError()],
        failures=[TestFailure()],
        skipped=None,
        system_out=None,
        system_err='testsuiterr_0',
        is_disabled=False
        )

    test_suite_0 = TestSuite(
        name='testsuite_0',
        hostname=None,
        id=None,
        package=None,
        timestamp=None,
        properties=dict(),
        cases=[test_case_0],
        system_out='testsuiteout_0',
        system_err=None
        )


# Generated at 2022-06-25 12:41:26.897017
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name = "test_name", hostname = "test_hostname", id = "test_id", package = "test_package", timestamp = datetime.datetime.now())
    test_suite.get_xml_element()


# Generated at 2022-06-25 12:41:32.460830
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # Test Normal Case
    test_suite = TestSuite(name="test_suite_name")
    actual_result = test_suite.get_xml_element()
    expected_result = ET.Element('testsuite', {'disabled': '0', 'errors': '0', 
        'failures': '0', 'name': 'test_suite_name', 'tests': '0', 'time': '0'})

    # Check if the actual result matches the expected result
    assert str(actual_result) == str(expected_result)



# Generated at 2022-06-25 12:41:43.479816
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite('name', 'hostname', 'id', 'package', datetime.datetime.now(), {}, [], 'system_out', 'system_err')
    test_xml = test_suite.get_xml_element()
    assert test_xml.attrib["name"] == "name"
    assert test_xml.attrib["hostname"] == "hostname"
    assert test_xml.attrib["id"] == "id"
    assert test_xml.attrib["package"] == "package"
    assert test_xml.attrib["tests"] == "0"
    assert test_xml.attrib["failures"] == "0"
    assert test_xml.attrib["errors"] == "0"
    assert test_xml.attrib["skipped"] == "0"
    assert test_xml

# Generated at 2022-06-25 12:41:54.046458
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:41:58.730099
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(
        classname = 'test_class',
        name = 'test_name',
        status = 'test_status',
        time = 'test_time',
    )
    test_case.errors.append(TestError(
        output = 'test_output',
        message = 'test_message',
        type = 'test_type',
    ))
    test_case.failures.append(TestError(
        output = 'test_output',
        message = 'test_message',
        type = 'test_type',
    ))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'


# Generated at 2022-06-25 12:42:10.401847
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:42:17.725800
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        hostname=None,
        id=None,
        name=None,
        package=None,
        properties={},
        system_err=None,
        system_out=None,
        timestamp=None,
    )
    expected = ET.fromstring(
        '<testsuite disabled="0" errors="0" failures="0" name="" skipped="0" tests="0" time="0.00">'
        '</testsuite>'
    )
    assert test_suite_0.get_xml_element() == expected



# Generated at 2022-06-25 12:42:25.819061
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:42:32.625457
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='TestSuite-0')
    actual = test_suite_0.get_xml_element()
    expected_str = \
        '<testsuite disabled="0" errors="0" failures="0" name="TestSuite-0" skipped="0" tests="0" time="0">\n' + \
        '  <properties/>\n' + \
        '</testsuite>'
    expected = ET.fromstring(expected_str)
    assert(actual == expected)
    print(actual)
    print(_pretty_xml(actual))


# Generated at 2022-06-25 12:42:42.416269
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # test 1
    test_case_0 = TestCase(name='name')
    test_suite_0 = TestSuite(name='name', cases=[test_case_0])
    # The expected value
    expected_value = """<testsuite time="0" tests="1" failures="0" errors="0" disabled="0" name="name" hostname="None" id="None" package="None" timestamp="None">
  <testcase time="-1" assertions="-1" classname="None" name="name" status="None">
  </testcase>
</testsuite>"""
    # The actual value
    actual_value = _pretty_xml(test_suite_0.get_xml_element())
    assert actual_value == expected_value


# Generated at 2022-06-25 12:42:51.797574
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test_name',
                      hostname='test_hostname',
                      id='test_id',
                      package='test_package',
                      timestamp=datetime.datetime(2020, 5, 9, 12, 30),
                      properties={'key': 'value'},
                      cases=[TestCase(name='pytest')],
                      system_out='test_system_out',
                      system_err='test_system_err')


# Generated at 2022-06-25 12:43:01.686291
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_case = TestCase(name='Test1', assertions=1, classname='Class1', status='Stopped', time=0.0)
    test_suite = TestSuite(name='TestSuite1', hostname='Host1', id='ID1', package='Package1', timestamp='0',
                           properties=[['Property1', 'Value1']], cases=[[test_case]])
    test_suites = TestSuites(name='TestSuites1', suites=[[test_suite]])

    assert (test_suites.get_xml_element().tag == 'testsuites')

# Generated at 2022-06-25 12:43:10.213492
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite("testsuite-name")
    test_suite_0.system_out = "testsuite-stdout"
    test_suite_0.system_err = "testsuite-stderr"
    test_suite_0.timestamp = datetime.datetime.now()

    test_case_0 = TestCase("testcase-name")
    test_case_0.classname = "testcase-classname"
    test_case_0.time = decimal.Decimal(12345)

    test_error_0 = TestError(output="test error output", message="test error message")
    test_case_0.errors.append(test_error_0)

    test_failure_0 = TestFailure(output="test failure output", message="test failure message")


# Generated at 2022-06-25 12:43:19.874514
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_failure_0 = TestFailure()
    test_case_0 = TestCase(name='name_18', assertions=38, classname='classname_16', status='status_8', time=decimal.Decimal('0.015'), errors=[test_error_0], failures=[test_failure_0], skipped='skipped_17', system_out='system_out_12', system_err='system_err_18')

# Generated at 2022-06-25 12:43:24.566923
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite_0 = TestSuite(name='suite_0')
    suite_element = suite_0.get_xml_element()
    pretty_element = _pretty_xml(suite_element)
    suite_element_str = suite_element.attrib.get('name')
    assert suite_element_str == 'suite_0'


# Generated at 2022-06-25 12:43:33.920596
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name')
    test_case_0 = TestCase(name='name')
    test_suite_0.cases.append(test_case_0)
    test_suite_0_xml = test_suite_0.get_xml_element()
    test_suite_0_xml_str = str(test_suite_0_xml)
    assert test_suite_0_xml_str == """<testsuite disabled="0" errors="0" failures="0" name="name" skipped="0" tests="1" time="0"> <testcase assertions="" classname="" name="name" status="" time=""/> </testsuite>"""



# Generated at 2022-06-25 12:43:44.586569
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=[TestCase('test_case_0')],
        hostname='test_suite_0_hostname',
        id='test_suite_0_id',
        name='test_suite_0_name',
        package='test_suite_0_package',
        properties={'test_suite_0_property': 'test_suite_0_property'},
        system_err='test_suite_0_system_err',
        system_out='test_suite_0_system_out',
        timestamp=datetime.datetime(2019, 5, 26, 1, 2, 3))
    # This tests the correct attributes are rendered.

# Generated at 2022-06-25 12:43:54.359071
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test 1
    suite = TestSuite('TestSuite1')
    suite.timestamp = datetime.datetime.now()
    suite.hostname = 'localhost'
    suite.properties = {'some_property': 'some_value'}

    case = TestCase('TestCase1')
    case.time = 1.23
    case.classname = 'class.one'
    # case.failures = [TestFailure('failed')]
    # case.errors = [TestError('error')]
    case.system_out = 'some text'
    case.system_err = 'some more text'
    suite.cases.append(case)

    suite_xml = suite.get_xml_element()
    assert suite_xml.tag == 'testsuite'

# Generated at 2022-06-25 12:44:01.736798
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_01')
    assert isinstance(test_case_0, TestCase)
    test_case_0.assertions = 0
    test_case_0.classname = 'test_suite_01'
    test_case_0.status = 'status'
    test_case_0.time = '12.345'
    test_error_0 = TestError()
    test_error_0.type = 'System.Exception'
    test_error_0.message = 'Exception'
    test_case_0.errors = [test_error_0]
    test_failure_0 = TestFailure()
    test_failure_0.type = 'System.Exception'
    test_failure_0.message = 'Exception'
    test_case_0.fail

# Generated at 2022-06-25 12:44:04.798983
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    result = test_case.get_xml_element()
    assert result.tag == 'testcase'
    assert result.attrib['name'] == 'test_case'
    assert result.text == 'None'


# Generated at 2022-06-25 12:44:17.411059
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_1 = TestCase(name = 'foo', classname = 'foo.bar', time = decimal.Decimal('0.1'))
    test_case_1.errors.append(TestError(message = 'message_0'))
    test_case_1.failures.append(TestFailure(message = 'message_1'))
    test_case_1.errors.append(TestError(message = 'message_2'))
    test_case_1.failures.append(TestFailure(message = 'message_3'))
    test_case_1.errors.append(TestError(message = 'message_4'))
    test_case_1.failures.append(TestFailure(message = 'message_5'))


# Generated at 2022-06-25 12:44:21.897906
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    assert test_case_0().get_xml_element() == '<?xml version="1.0" ?><TestSuite></TestSuite>'


# Generated at 2022-06-25 12:44:25.137248
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    tc = TestCase(name='TestCase', classname='TestCase')
    tc_xml = tc.get_xml_element()
    tc_xml = ET.tostring(tc_xml, encoding='unicode')
    assert tc_xml == '<testcase assertions="None" classname="TestCase" name="TestCase" status="None" time="None"/>'



# Generated at 2022-06-25 12:44:34.139133
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    suite = TestSuite(
        name='suite',
        cases=[
            TestCase(
                name='suite.testcase',
                errors=[TestError()],
                failures=[TestFailure()],
                skipped='skipped',
                system_out='out',
                system_err='err',
            ),
        ],
        properties={'property': 'value'},
        system_out='out',
        system_err='err',
    )

    assert suite.get_xml_element().find('properties').find('property').attrib['name'] == 'property'
    assert suite.get_xml_element().find('properties').find('property').attrib['value'] == 'value'

    # TODO: assert suite.get_xml_element().find('testcase').find('failure').attrib['message'] == ''
    #

# Generated at 2022-06-25 12:44:41.360551
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    test_case_1 = TestCase(name='test_case_1')
    test = TestSuite('test_suite_0')
    test.cases.append(test_case_0)
    test.cases.append(test_case_1)
    assert test.get_xml_element().find('testcase').get('name') == 'test_case_0'


# Generated at 2022-06-25 12:44:50.970781
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0_classname = "TestCase"
    test_case_0_name = "test_name"
    test_case_0_time = "100"
    test_case_0 = TestCase(classname=test_case_0_classname, name=test_case_0_name, time=test_case_0_time)
    test_case_1_classname = "TestCase1"
    test_case_1_name = "test_name1"
    test_case_1_time = "101"
    test_case_1 = TestCase(classname=test_case_1_classname, name=test_case_1_name, time=test_case_1_time)

    test_case_list_0 = [test_case_0, test_case_1]
    test

# Generated at 2022-06-25 12:45:00.117330
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_0")
    test_case_1 = TestCase(name="test_case_1")
    test_case_2 = TestCase(name="test_case_2")
    test_case_3 = TestCase(name="test_case_3")
    suite_0 = TestSuite(name="suite_0")
    suite_1 = TestSuite(name="suite_1")
    test_suites = TestSuites(name="junit_test")

    test_error_0 = TestError()
    test_error_0.output = "test_error_0"
    test_error_0.type = "Error_type"

    test_failure_0 = TestFailure()

# Generated at 2022-06-25 12:45:09.675169
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # test code here
    test_case_1 = TestCase(name="test_1")
    test_case_2 = TestCase(name="test_2")

    test_suite_0 = TestSuite(name="suite_1")

    test_suite_0.cases.append(test_case_1)
    test_suite_0.cases.append(test_case_2)

    test_suite_0.properties = {"key_1": "value_1",
                               "key_2": "value_2"}

    test_suite_0.system_out = "system output"
    test_suite_0.system_err = "system error"

    res = test_suite_0.get_xml_element()
    res_string = _pretty_xml(res)

# Generated at 2022-06-25 12:45:16.020212
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('name_0')
    # Create a TestCase element
    element_0 = test_case_0.get_xml_element()
    # TestCase element should be a debugging string with testcase tag
    assert str(element_0) == '<Element testcase at 0x7f9b240ed0a8>'
    # Check that TestCase element has correct attributes
    assert element_0.items() == [('name', 'name_0')]
    # Check that TestCase element has correct tag name
    assert element_0.tag == 'testcase'
    # Check that TestCase element does not contain any subelements
    assert len(list(element_0)) == 0


# Generated at 2022-06-25 12:45:23.990697
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('name')
    test_case_0.assertions = 1
    test_case_0.classname = 'classname'
    test_case_0.status = 'status'
    test_case_0.time = 3.2
    test_case_0.errors = [TestError('msg', 'type', 'output'), TestError('msg', 'type', 'output')]
    test_case_0.failures = [TestFailure('msg', 'type', 'output'), TestFailure('msg', 'type', 'output')]
    test_case_0.skipped = 'skipped'
    test_case_0.system_out = 'system_out'
    test_case_0.system_err = 'system_err'

# Generated at 2022-06-25 12:45:39.857568
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:45:50.841436
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_1 = TestCase(name='test_case_1')
    test_suite_0 = TestSuite(name='test_suite_0', disabled=1, errors=1, failures=1, hostname='test_host', skipped=1, tests=1, time=1, cases=[test_case_1])
    str0 = '''<testsuite disabled="1" errors="1" failures="1" hostname="test_host" id="" name="test_suite_0" package="" skipped="1" tests="1" time="1">
  <testcase assertions="" classname="" name="test_case_1" status="" time="None"></testcase>
</testsuite>'''
    
    assert _pretty_xml(test_suite_0.get_xml_element()) == str0


# Unit

# Generated at 2022-06-25 12:45:53.707576
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    tTestCase0 = TestCase('name0')
    assert tTestCase0.get_xml_element().attrib['name'] == 'name0'
    assert tTestCase0.get_xml_element().text is None


# Generated at 2022-06-25 12:46:00.620787
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name="test_case_0")
    test_suite_0 = TestSuite(name="test_suite_0", cases=[test_case_0])
    expected_xml_element = ET.Element('testsuite', attrib=_attributes(disabled=0, errors=0, failures=0, name="test_suite_0", tests=1, time="0.0"))
    expected_xml_element.extend([test_case_0.get_xml_element()])
    assert(expected_xml_element == test_suite_0.get_xml_element())



# Generated at 2022-06-25 12:46:09.812333
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Test XML Created by get_xml_element method"""
    test_suite = TestSuite(name="test_suite_name", hostname="test_suite_hostname", id="test_suite_id", package="test_suite_package", timestamp=None)
    test_suite_attributes = test_suite.get_attributes()
    test_suite.properties = {"name": "value"}
    test_suite_cases = [TestCase(name="test_case_name", assertions=0, classname="test_suite_classname", status="test_case_status", time=None), TestCase(name="another_test_case_name", assertions=0, classname="another_test_suite_classname", status="another_test_case_status", time=None)]
    test_suite

# Generated at 2022-06-25 12:46:19.513347
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        assertions = 0,
        classname = "test_suite_1",
        errors = [],
        failures = [],
        name = "test_case_0",
        skipped = None,
        status = "",
        system_err = None,
        system_out = None,
        time = None,
    )

# Generated at 2022-06-25 12:46:26.688993
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Unit test for method get_xml_element of class TestSuite"""
    name = 'name'
    time = 123.123
    classname = 'package.class'
    name_case = 'name_case'
    assertions = 12
    time_case = 456.456

    errors = []
    failures = [TestFailure()]
    skipped = 'skipped'
    system_out = 'system_out'
    system_err = 'system_err'

    test_suite = TestSuite(name='name')
    test_case = TestCase(name=name_case)

    test_suite.cases.append(test_case)
    test_case.assertions = assertions
    test_case.classname = classname
    test_case.errors = errors
    test_case.failures = failures
    test

# Generated at 2022-06-25 12:46:36.230523
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Unit test for method get_xml_element of class TestSuite"""
    test_case_0 = TestCase(
        assertions=None,
        classname=None,
        errors=[],
        failures=[],
        name='test_case_0',
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None,
    )

# Generated at 2022-06-25 12:46:42.516987
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        assertions=0,
        classname='classname',
        name='name',
        status='status',
        time=0.0,
        is_disabled=True,
    )
    test_suite_0 = TestSuite(
        disabled=0,
        errors=0,
        failures=0,
        hostname='hostname',
        id='id',
        name='name',
        package='package',
        skipped=0,
        tests=0,
        time=0.0,
        timestamp=datetime.datetime(2019, 12, 2, 14, 2, 12),
        cases=[test_case_0],
        system_out='system_out',
        system_err='system_err',
    )
    assert test_suite_0.get_

# Generated at 2022-06-25 12:46:53.203309
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
	test_suite_0 = TestSuite(cases=[TestCase(name='test_0', assertions=1, classname='mock_test', status='pass'),TestCase(name='test_1', assertions=2, classname='mock_test', status='pass')], hostname='mock_host', id='mock_id', name='mock_test_name', package='mock_package', timestamp=datetime.datetime.now(), properties={'name': 'value'}, system_out='mock_system_out', system_err='mock_system_err')
	assert(test_suite_0.get_xml_element())


# Generated at 2022-06-25 12:47:10.856450
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_1 = TestCase(name='test_case_1')
    element = test_case_1.get_xml_element()
    assert element.tag == 'testcase'
    assert element.get('name') == 'test_case_1'
    assert len(element) == 0
    assert element.text == 'None'
    assert element.tail == None



# Generated at 2022-06-25 12:47:20.535585
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="suite0",
                             hostname="localhost",
                             id="1.2.3.4",
                             package="tests",
                             timestamp=datetime.datetime.now(),
                             properties={"os": "linux", "os.version": "5.6"},
                             cases=[TestCase(name="case0")],
                             system_out="stdout",
                             system_err="stderr")


# Generated at 2022-06-25 12:47:30.732190
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:47:41.306443
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    test_case_0 = TestCase(
        name="test_case_0",
        classname="class_name",
        time=1.1
    )

    test_error_0 = TestError(
        message="test_message_0",
        type="test_type_0",
        output="test_output_0"
    )

    test_case_0.errors.append(test_error_0)

    test_failure_0 = TestFailure(
        message="test_message_0",
        type="test_type_0",
        output="test_output_0"
    )

    test_case_0.failures.append(test_failure_0)


# Generated at 2022-06-25 12:47:48.867492
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase()
    test_case_0.name = 'test_case_0'
    test_case_1 = TestCase()
    test_case_1.name = 'test_case_1'
    test_suite_0 = TestSuite()
    test_suite_0.name = 'test_suite_0'
    test_suite_0.cases = [test_case_0, test_case_1]
    test_suite_0_tree = test_suite_0.get_xml_element()
    test_suite_0_xml = ET.tostring(test_suite_0_tree, encoding='unicode')
    assert len(test_suite_0_xml) > 0

# Generated at 2022-06-25 12:47:55.398844
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """
    Return an XML element representing this instance.
    """
    print("Testing: test_TestSuite_get_xml_element")
    test_suite_0 = TestSuite(name='', hostname='', id='', package='', timestamp=datetime.datetime(2020,6,24,17,52,52), properties={}, cases=[], system_out='', system_err='')
    result = test_suite_0.get_xml_element()
    assert isinstance(result, ET.Element)
    assert result.get('name') == ''
    assert result.get('tests') == '0'
    assert result.get('disabled') == '0'
    assert result.get('errors') == '0'
    assert result.get('failures') == '0'

# Generated at 2022-06-25 12:47:57.749634
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    xml_element = test_suite.get_xml_element()
    assert (xml_element is not None)


# Generated at 2022-06-25 12:48:02.482714
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts_1 = TestSuite(name='test suite 1')
    xml_1 = ET.tostring(ts_1.get_xml_element()).decode('utf-8')
    assert xml_1 == '<testsuite disabled="0" errors="0" failures="0" hostname="None" id="None" name="test suite 1" package="None" skipped="0" tests="0" time="0" timestamp="None"/>'


# Generated at 2022-06-25 12:48:10.391953
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite('TestSuiteName')
    xml_element = ts.get_xml_element()

    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'TestSuiteName'

    ts = TestSuite(name = 'TestSuiteName', hostname = 'TestSuiteHostname', id = 'TestSuiteID', package = 'TestSuitePackage', timestamp = datetime.datetime.now())
    xml_element = ts.get_xml_element()

    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'TestSuiteName'
    assert xml_element.attrib['hostname'] == 'TestSuiteHostname'
    assert xml_element.attrib['id'] == 'TestSuiteID'


# Generated at 2022-06-25 12:48:20.472748
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0', classname=None, status=None, time=None,
                           errors=test_error_0, failures=test_failure_0, skipped=None,
                           is_disabled=False)

    assert test_case_0.get_xml_element().tag == "testcase"
    assert test_case_0.get_xml_element().attrib == {"name": "test_case_0"}
    assert test_case_0.get_xml_element().text == None
    assert test_case_0.get_xml_element().tail == None
    assert test_case_0.get_xml_element()[0].tag == "failure"
    assert test_case_0.get_xml_element()[1].tag == "error"

# Generated at 2022-06-25 12:48:38.412193
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite = TestSuite(name = 'testSuite',id = '1', hostname = 'localhost', package = 'test', timestamp = datetime.datetime.now())
    output_testSuite = testSuite.get_xml_element()
    assert(output_testSuite[0] == 'testsuite')


# Generated at 2022-06-25 12:48:45.243384
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_suite = TestSuite(name = "TestSuiteName")
    test_case = TestCase(name = "TestCaseName", classname = "TestCaseClass", is_disabled = True,
                         status = "status", time = decimal.Decimal(1))
    test_suite.cases.append(test_case)
    assert test_suite.get_xml_element().attrib == {'disabled':'1', 'errors':'0', 'failures':'0', 'name':'TestSuiteName', 'tests':'1', 'time':'1.0'}
    assert test_case.get_xml_element().attrib == {'classname': 'TestCaseClass', 'name': 'TestCaseName', 'status': 'status', 'time': '1.0'}

#Unit tests for System-Out and

# Generated at 2022-06-25 12:48:50.567718
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase()
    test_suite_0 = TestSuite()
    test_suite_0.cases.append(test_case_0)
    expected_0 = ET.fromstring(
        '<testsuite tests="1" disabled="0" errors="0" failures="0" time="0" name="">\n'
        '  <testcase></testcase>\n'
        '</testsuite>'
    )
    assert test_suite_0.get_xml_element() == expected_0



# Generated at 2022-06-25 12:48:57.413690
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    print("Test: TestSuite_get_xml_element")
    suite = TestSuite(
        name='sample',
        disabled=1,
        hostname=None,
        id='id_test',
        errors=1,
        failures=1,
        skipped=1,
        tests=1,
        timestamp=datetime.datetime.now(),
        cases=[
            TestCase(
                name='sample name',
                assertions=1,
                classname='sample class name',
                time=decimal.Decimal('1.0'),
                errors=2,
                failures=2,
                skipped=True,
                system_out='out',
                system_err='error'
            )
        ]
    )
    print(_pretty_xml(suite.get_xml_element()))

# Generated at 2022-06-25 12:49:04.703471
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase("test_case_0", assertion=0)
    test_failure_0 = TestFailure("Test failure of test_case_0")
    test_case_0.failures.append(test_failure_0)

    xml_test_case_0 = test_case_0.get_xml_element()
    assert (ET.tostring(xml_test_case_0, encoding='unicode') == """<testcase assertions="0" name="test_case_0"><failure>Test failure of test_case_0</failure></testcase>""")


# Generated at 2022-06-25 12:49:10.705334
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=1,
        classname='tests.TestClass',
        name='test_case',
        status='PASSED',
        time=0.01,
    )

    assert _pretty_xml(test_case_0.get_xml_element()) == """\
<?xml version="1.0" ?>
<testcase assertions="1" classname="tests.TestClass" name="test_case" status="PASSED" time="0.01" />
"""

# Generated at 2022-06-25 12:49:16.529941
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Arrange
    name = "name"
    test_error_1 = TestError( output= "output", message = "message", type = "type")
    test_error_2 = TestError( output= "output", message = "message", type = "type")
    test_failure_1 = TestFailure( output= "output", message = "message", type = "type")
    expected_result = '<testcase assertions="None" classname="None" name="name" status="None" time="None"><failure message="message" type="type">output</failure><error message="message" type="type">output</error></testcase>'
    test_case_0 = TestCase( name = name, errors = [test_error_1, test_error_2], failures = [test_failure_1], is_disabled = True)

# Generated at 2022-06-25 12:49:19.583429
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_0")
    element = test_case_0.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == dict(name='test_case_0')


# Generated at 2022-06-25 12:49:21.619582
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    try:
        obj = TestCase('test_name')
        get_xml_element_test_passed = True
    except:
        get_xml_element_test_passed = False

    assert get_xml_element_test_passed == True


# Generated at 2022-06-25 12:49:29.938518
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # <empty TestSuite object>
    string_value = "<testsuite disabled=\"0\" errors=\"0\" failures=\"0\" tests=\"0\" time=\"0\"/>"
    test_suite_empty = TestSuite("")
    assert (ET.tostring(test_suite_empty.get_xml_element()) == string_value.encode())
    # <TestSuite object with valid name>
    string_value = "<testsuite disabled=\"0\" errors=\"0\" failures=\"0\" hostname=\"example_hostname\" id=\"example_id\" name=\"example_name\" package=\"example_package\" skipped=\"0\" tests=\"0\" time=\"0\" timestamp=\"example_timestamp\"/>"
    test_suite_with_valid_attributes = TestSuite("example_name")
    test_suite_with_valid