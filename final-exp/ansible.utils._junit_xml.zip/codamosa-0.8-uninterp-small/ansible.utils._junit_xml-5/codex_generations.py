

# Generated at 2022-06-25 12:40:07.469205
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_Result_0 = TestFailure()
    test_xml_0 = test_Result_0.get_xml_element()
    assert test_xml_0.tag == 'failure'


# Generated at 2022-06-25 12:40:10.853398
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult(None, None, None)
    test_result_expected = ET.Element('testresult', {})

    assert test_result_0.get_xml_element() == test_result_expected


# Generated at 2022-06-25 12:40:19.811410
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test_result_1 = TestResult(output='string', message='string', type='string')

    # Test parameter: output
    assert test_result_0.output == None
    assert test_result_1.output == 'string'

    # Test parameter: message
    assert test_result_0.message == None
    assert test_result_1.message == 'string'

    # Test parameter: type
    assert test_result_0.type == None
    assert test_result_1.type == 'string'

    # Test attribute: tag
    try:
        assert test_result_0.tag != None
    except NotImplementedError:
        pass

    # Test method get_attributes
    assert test_result_0.get_attributes() == {'type': None}
   

# Generated at 2022-06-25 12:40:24.091248
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert TestResult(
        message = 'testmessage',
        type = 'testtype',
        output = 'testoutput'
    ).get_attributes() == {'message': 'testmessage', 'type': 'testtype'}



# Generated at 2022-06-25 12:40:33.161710
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():

    # Test case without message
    test_case = TestResult()
    element = test_case.get_xml_element()

    assert element.tag == 'UNKNOWN'

    # Test case with message
    test_case = TestResult(message='message')
    element = test_case.get_xml_element()

    assert element.tag == 'UNKNOWN'
    assert element.text == 'message'
    assert element.get('message') == 'message'

    # Test case with output
    test_case = TestResult(output='output')
    element = test_case.get_xml_element()

    assert element.tag == 'UNKNOWN'
    assert element.text == 'output'

    # Test case with type
    test_case = TestResult(type='type')
    element = test_case.get_xml_element()

   

# Generated at 2022-06-25 12:40:35.180961
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    d = test_result_0.get_attributes()
    assert d == {'type': 'testresult'}



# Generated at 2022-06-25 12:40:36.868544
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert(test_result.get_attributes() == {})


# Generated at 2022-06-25 12:40:41.686154
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='name_0')
    result = test_case_0.get_xml_element()
    assert ET.tostring(result).decode('utf-8') == '<testcase name="name_0"/>', "TestCase.get_xml_element() failed"


# Generated at 2022-06-25 12:40:47.217844
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='name',hostname='hostname',id='id',package='package',timestamp='timestamp',
    properties={'properties':'properties'},system_out='system_out',system_err='system_err',cases=[])

    xml_element = suite.get_xml_element()
    #Assert if the XML elements got the expected name
    assert(xml_element.tag == 'testsuite')
    #Assert if the XML element got the expected attributes
    assert(xml_element.attrib['name'] == 'name')
    assert(xml_element.attrib['hostname'] == 'hostname')
    assert(xml_element.attrib['id'] == 'id')
    assert(xml_element.attrib['package'] == 'package')

# Generated at 2022-06-25 12:40:58.246566
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    print("Testing method TestResult.get_xml_element")
    test_result_0 = TestResult(message = "message_0", output = "output_0", type = "type_0")
    expected_0 = """\
<testresult message="message_0" output="output_0" type="type_0" />"""
    actual_0 = _pretty_xml(test_result_0.get_xml_element())
    assert actual_0 == expected_0
    test_result_1 = TestResult()
    expected_1 = """\
<testresult />"""
    actual_1 = _pretty_xml(test_result_1.get_xml_element())
    assert actual_1 == expected_1



# Generated at 2022-06-25 12:41:13.878767
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        name = 'TestSuite_name',
        hostname = 'TestSuite_hostname',
        id = 'TestSuite_id',
        package = 'TestSuite_package',
        timestamp = datetime.datetime.now()
    )
    test_suite_0_xml_element = test_suite_0.get_xml_element()
    assert test_suite_0_xml_element.tag == 'testsuite'
    for attr in test_suite_0_xml_element.attrib:
        if attr == 'name':
            assert test_suite_0_xml_element.attrib[attr] == test_suite_0.name
        elif attr == 'hostname':
            assert test_suite_0_xml

# Generated at 2022-06-25 12:41:24.340659
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """
    Create an XML test case element and check it's contents

    """
    test_case_0 = TestCase(
        assertions=23,
        classname="MyClass",
        is_disabled=False,
        errors=[],
        failures=[],
        message="This is the message text.",
        name="MyTestName",
        output="This is the test output.",
        skipped=None,
        status="unknown",
        system_err="This is the test error output.",
        system_out="This is the test output log.",
        time=decimal.Decimal("0.01"),
        type="failure"
    )

    element = test_case_0.get_xml_element()
    assert(element.tag == 'testcase')


# Generated at 2022-06-25 12:41:30.353095
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:41:41.016238
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Initialize the test case.
    test_case_0 = TestCase(
        assertions = 1,
        classname = "TestCase",
        name = "TestCase_get_xml_element",
        status = "status",
        time = 1.23
        )

    # Create test case element
    test_case_element = test_case_0.get_xml_element()

    # Validate result is as expected
    assert test_case_element.attrib == {
        'classname': 'TestCase',
        'assertions': '1',
        'name': 'TestCase_get_xml_element',
        'status': 'status',
        'time': '1.23'
    }


# Generated at 2022-06-25 12:41:47.814553
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite('name')
    test_case = TestCase('name')
    suite.cases.append(test_case)
    result = suite.get_xml_element()
    assert result.tag == 'testsuite'
    assert len(result) == 1
    assert result[0].tag == 'testcase'
    assert result[0].get('name') == 'name'


# Generated at 2022-06-25 12:41:52.044816
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name = 'TestSuite0', cases = [TestCase(name = "TestCase0")])
    assert test_suite.get_xml_element().findall("./testcase")[0].get('name') == 'TestCase0'


# Generated at 2022-06-25 12:41:54.859589
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_some_things')
    xml_element = test_case.get_xml_element()
    assert xml_element.get('name') == 'test_some_things'


# Generated at 2022-06-25 12:42:01.201193
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="name_0")
    test_suite_0_xml_element = test_suite_0.get_xml_element()
    assert test_suite_0_xml_element.attrib["name"] == "name_0"
    assert test_suite_0_xml_element.attrib["disabled"] == "0"
    assert test_suite_0_xml_element.attrib["errors"] == "0"
    assert test_suite_0_xml_element.attrib["failures"] == "0"
    assert test_suite_0_xml_element.attrib["skipped"] == "0"
    assert test_suite_0_xml_element.attrib["tests"] == "0"
    assert test_suite_0_xml_element

# Generated at 2022-06-25 12:42:11.423689
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
   test_suite_0 = TestSuite('test_suite_0', None, None, None, None)
   test_case_0 = TestCase('test_case_0', None, None, None, None)
   test_failure_0 = TestFailure(None, None, None)
   test_case_0.failures.append(test_failure_0)

   test_suite_0.cases.append(test_case_0)

   # Test attribute errors and failures
   assert test_suite_0.failures == 1
   assert test_suite_0.errors == 0

   # Test attribute tests
   assert test_suite_0.tests == 1



# Generated at 2022-06-25 12:42:14.633411
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_name = "TestCase_get_xml_element"
    test_case_result = TestCase(name=test_name)
    test_case_xml_string = ET.tostring(test_case_result.get_xml_element(), encoding='unicode')
    expected_xml_string = f'<testcase name="{test_name}"/>'
    assert test_case_xml_string == expected_xml_string


# Generated at 2022-06-25 12:42:20.961358
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_0 = TestCase(name="my_Test")
    assert test_0.get_xml_element() == ET.Element('testcase', {'assertions': None, 'classname': None, 'name': 'my_Test', 'status': None, 'time': None})


# Generated at 2022-06-25 12:42:28.124970
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:42:35.218239
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:42:46.128828
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testcase = TestCase(name='test_case_1', classname='class_1', assertions=2, status='pass', time=1.5)
    testcase.errors = [TestError(output='error_1', message='error_message_1', type='exception'),
                       TestError(output='error_2', message='error_message_2', type='exception')]
    testcase.failures = [TestFailure(output='failure_1', message='failure_message_1', type='assertion')]
    testsuite = TestSuite(name='test_suite_1', hostname='localhost', id='suite_id_1', package='package_1',
                          timestamp=datetime.datetime.now())

# Generated at 2022-06-25 12:42:51.842978
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # TestCase with all defaults. Should be empty.
    tc = TestCase(name='test_case_0')
    assert tc.get_xml_element() == ET.Element('testcase', {'name': 'test_case_0'})

    # TestCase with all defaults except name. Should be empty.
    tc = TestCase(name=None)
    assert tc.get_xml_element() == ET.Element('testcase', {})

    # TestCase with assertions, classname, status and time. Should only have 'case' data.
    tc = TestCase(name='test_case_1', assertions=1, classname='TestCase', status='status', time=1.0)

# Generated at 2022-06-25 12:43:01.729497
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Generate values
    # test_case_0_name
    test_case_0_name = '<testcase name=\'\'/>'
    # test_case_0_status
    test_case_0_status = '<testcase status=\'\'/>'
    test_case_0_status = '<testcase status=\'success\'/>'
    test_case_0_status = '<testcase status=\'fail\'/>'
    test_case_0_status = '<testcase status=\'error\'/>'
    test_case_0_status = '<testcase status=\'skipped\'/>'
    # test_case_1_name
    test_case_1_name = '<testcase name=\'test_case_1_name\'/>'
    # test_case_1_assertions


# Generated at 2022-06-25 12:43:07.271315
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts_0 = TestSuite(name='TestSuite_0')
    assert ET.tostring(ts_0.get_xml_element(), encoding='unicode') == '<testsuite name="TestSuite_0"/>'

    ts_1 = TestSuite(name='TestSuite_1', hostname='HostName_1', package='Package_1', timestamp=datetime.datetime(2020, 1, 1, 0, 0, 0))
    assert ET.tostring(ts_1.get_xml_element(), encoding='unicode') == '<testsuite name="TestSuite_1" hostname="HostName_1" package="Package_1" timestamp="2020-01-01T00:00:00"/>'

    ts_1.properties['Property_0'] = 'Value_0'
    assert ET.t

# Generated at 2022-06-25 12:43:16.773045
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('name')
    test_case_0 = TestCase('test_name')
    test_case_1 = TestCase('test_name')
    test_case_0.failures = [TestFailure('test_output', 'test_message', 'test_type')]
    test_case_0.errors = [TestError('test_output', 'test_message', 'test_type')]
    test_case_0.system_out = 'test_system_out'
    test_case_0.system_err = 'test_system_err'
    test_case_1.failures = [TestFailure('test_output', 'test_message', 'test_type')]

# Generated at 2022-06-25 12:43:26.252992
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(id=0, name="TestSuite_name")
    test_case_0 = TestCase(name="TestCase_name")
    test_suite_0.cases.append(test_case_0)
    expected = '<testsuite disabled="0" errors="0" failures="0" hostname="None" id="0" name="TestSuite_name" package="None" skipped="0" tests="1" time="0.0" timestamp="None">\n  <testcase assertions="None" classname="None" name="TestCase_name" status="None" time="None">\n  </testcase>\n</testsuite>\n'
    actual = _pretty_xml(test_suite_0.get_xml_element())
    assert expected == actual

#

# Generated at 2022-06-25 12:43:33.803283
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=None,
        classname=None,
        errors=[],
        failures=[],
        name='test_simple',
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None,
    )

    expected = ET.Element('testcase', {
        'name': 'test_simple',
    })

    actual = test_case_0.get_xml_element()

    assert _pretty_xml(expected) == _pretty_xml(actual)



# Generated at 2022-06-25 12:43:49.583878
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_0')
    test_suite = TestSuite(name='test_suite_0')
    test_suite.cases.append(test_case)
    test_suite_xml_element = test_suite.get_xml_element()
    assert test_suite_xml_element.tag == 'testsuite'
    assert test_suite_xml_element.attrib['name'] == 'test_suite_0'
    assert test_suite_xml_element.attrib['tests'] == '1'



# Generated at 2022-06-25 12:43:53.065269
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TestSuite = TestSuite(name = "", hostname = "", id = "", package = "", timestamp = "", error = "", system_out = "", system_err = "")
    assert TestSuite.get_xml_element() == None


# Generated at 2022-06-25 12:43:55.241825
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="TestCase 0")
    assert test_case_0.get_xml_element().tag == 'testcase'


# Generated at 2022-06-25 12:43:58.782154
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name = 'test_case_0')
    expected_result = ET.fromstring('<testcase name = "test_case_0"/>')
    actual_result = test_case_0.get_xml_element()
    assert ET.tostring(expected_result) == ET.tostring(actual_result)



# Generated at 2022-06-25 12:44:08.624165
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """
    TestCase.get_xml_element() should return an XML element for the given test case.
    xml = <testcase classname="TestSuite.test_case_0" name="test_case_0" time="0.0"></testcase>
    """
    test_case_0 = TestCase(name='test_case_0', classname='TestSuite.test_case_0', time=decimal.Decimal(0))
    xml_test_case_0 = test_case_0.get_xml_element()
    assert len(xml_test_case_0) == 0, "Expected len(xml_test_case_0) == 0"
    assert xml_test_case_0.tag == 'testcase', "Expected xml_test_case_0.tag == 'testcase'"
    assert xml_

# Generated at 2022-06-25 12:44:12.273282
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='n')
    test_ElementTree_0 = test_suite_0.get_xml_element()
    assert test_ElementTree_0 == ET.Element('testsuite', {'name': 'n'})


# Generated at 2022-06-25 12:44:17.519043
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_1 = TestSuite(name='Name')
    etree_element = test_suite_1.get_xml_element()
    assert etree_element.tag == 'testsuite'
    assert etree_element.attrib == {'name': 'Name'}
    assert etree_element.text == '\n'
    assert len(list(etree_element)) == 0


# Generated at 2022-06-25 12:44:24.038230
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name')
    test_suite_0_xml = test_suite_0.get_xml_element()
    assert '<testsuite name="name" errors="0" failures="0" disabled="0" skipped="0" tests="0" time="0" ' \
           'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"' in test_suite_0_xml


# Generated at 2022-06-25 12:44:31.325465
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Given
    test_suite_0 = TestSuite(timestamp=datetime.datetime(year=2020, month=4, day=3, hour=8, minute=13, second=58), hostname='host', id='id', name='name', package='package')

    # When
    actual = test_suite_0.get_xml_element()

    # Then
    expected = ET.Element('testsuite', {'timestamp': '2020-04-03T08:13:58', 'hostname': 'host', 'id': 'id', 'name': 'name', 'package': 'package'})
    assert actual == expected


# Generated at 2022-06-25 12:44:40.225562
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_object = TestCase()
    test_suite_object = TestSuite()
    test_suite_object.cases.append(test_case_object)
    assert test_suite_object.get_xml_element().tag == 'testsuite'
    # Testing assertion
    test_case_object.assertions = 1
    assert test_suite_object.get_xml_element().get('assertions') == '1'
    # Testing classname
    test_case_object.classname = ''
    assert test_suite_object.get_xml_element().get('classname') == ''
    # Testing name
    test_case_object.name = 'adssa'
    assert test_suite_object.get_xml_element().get('name') == 'adssa'
    # Testing status

# Generated at 2022-06-25 12:44:54.169257
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()
    timestamp_0 = datetime.datetime.now()
    test_suite_0 = TestSuite('name',
                             hostname='name_0',
                             id='name_1',
                             package='name_2',
                             timestamp=timestamp_0)
    # test for all values
    test_suite_0.cases.append(TestCase('name',
                                       assertions=1,
                                       classname='name_0',
                                       status='name_1',
                                       time=decimal.Decimal('1.1')))
    # test for all values

# Generated at 2022-06-25 12:44:57.949903
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    expected = '<testcase name="test1" />'
    test_case = TestCase('test1')
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == expected


# Generated at 2022-06-25 12:45:06.139359
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    TestCase_0 = TestCase(name = "TestCase_0")
    TestCase_0.name = "TestCase_0"
    TestCase_0.assertions = None
    TestCase_0.classname = None
    TestCase_0.status = None
    TestCase_0.time = None
    TestCase_0.is_disabled = False
    TestCase_0.errors = None
    TestCase_0.failures = None
    TestCase_0.skipped = None
    TestCase_0.system_out = None
    TestCase_0.system_err = None
    assert TestCase_0.get_xml_element().tag == 'testcase'
    return True



# Generated at 2022-06-25 12:45:14.035858
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='', hostname='')
    xml_element = test_suite_0.get_xml_element()
    assert xml_element.find('.').find('properties').find('.') is None
    assert xml_element.find('.').find('system-err') is None
    assert xml_element.find('.').find('system-out') is None
    assert xml_element.get('failures') == '0'
    assert xml_element.get('errors') == '0'
    assert xml_element.get('tests') == '0'
    assert xml_element.get('disabled') == '0'
    assert xml_element.get('skipped') == '0'
    assert xml_element.get('name') == ''
    assert xml_element.get('package')

# Generated at 2022-06-25 12:45:21.108175
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="TestCase0")
    test_suite_0 = TestSuite(name="TestSuite0")
    test_suite_0.cases.append(test_case_0)
    test_suites_0 = TestSuites()
    test_suites_0.suites.append(test_suite_0)

    assert test_suites_0.tests == 1
    assert test_suites_0.time == 0
    assert test_suites_0.get_xml_element() != None
    assert test_suites_0.to_pretty_xml() != None


# Generated at 2022-06-25 12:45:21.921088
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()

# Generated at 2022-06-25 12:45:27.002166
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites_0 = TestSuites()
    test_suite_1 = TestSuite('test_suite_0')
    test_suites_0.suites.append(test_suite_1)

    test_case_2 = TestCase(name='test_case_0')
    test_suite_1.cases.append(test_case_2)

    xml_element_3 = test_suite_1.get_xml_element()
    return xml_element_3



# Generated at 2022-06-25 12:45:36.860249
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Setup
    test_suite_0 = TestSuite(id='id_0',
                             name='name_0',
                             properties={'key_0': 'value_0'},
                             )
    test_suite_0.cases.append(TestCase(name='name_1',
                                       ))
    test_suite_0.cases.append(TestCase(name='name_2',
                                       ))
    test_suite_0.system_out='system_out_0'
    test_suite_0.system_err='system_err_0'

    # Invoke method
    xml_element = test_suite_0.get_xml_element()

    # Check result
    assert xml_element.tag == 'testsuite'

# Generated at 2022-06-25 12:45:39.821086
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testcase_0 = TestCase('test_case_name')
    testcase_0_element = testcase_0.get_xml_element()
    assert testcase_0_element.tag == 'testcase'



# Generated at 2022-06-25 12:45:50.808824
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_1 = TestCase(
        name='test_case_1',
        failures=[
            TestFailure(
                output='output 1',
                message='message 1',
                type='type 1',
            )
        ]
    )

    root = test_case_1.get_xml_element()
    # Extract children of the root element
    children = [child for child in root]

    # Test whether the test case has attributes from the TestCase class and from the TestFailure class
    assert root.attrib['name'] == 'test_case_1'
    assert root.attrib['time'] == 'None'
    assert children[0].attrib['message'] == 'message 1'
    assert children[0].attrib['type'] == 'type 1'
    assert children[0].text == 'output 1'

# Unit

# Generated at 2022-06-25 12:46:03.390073
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase("testName", assertions=0, classname="className", status="status", time=0)
    test_suite_0 = TestSuite("name", hostname="hostname", id="id", package="package", timestamp=datetime.datetime.now(), properties=dict(), cases=[test_case_0], system_out=None, system_err=None)
    assert test_suite_0.get_xml_element() is not None


# Generated at 2022-06-25 12:46:09.444979
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name')
    assert ('<testsuite disabled="0" errors="0" failures="0" hostname="none" id="none" name="name" package="none"'
            + ' skipped="0" tests="0" time="0.0" timestamp="None"><system-err /><system-out /></testsuite>' ==
            test_suite_0.get_xml_element().tostring().decode(encoding='UTF-8'))



# Generated at 2022-06-25 12:46:13.336596
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    output = """\
<?xml version="1.0" ?>
<testsuites>
</testsuites>
"""
    test_suites_0 = TestSuites()
    test_suites = test_suites_0.get_xml_element()
    assert _pretty_xml(test_suites) == output

# Generated at 2022-06-25 12:46:22.616071
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_case_0_xml_element = """<testsuite errors="0" failures="0" tests="1" time="0.0" timestamp="2020-11-12T20:18:20" name="Sample Test Suite">
  <testcase assertions="1" name="Sample Test Case 0" time="0.0"></testcase>
</testsuite>"""

    test_case_0 = TestSuite(
        name="Sample Test Suite",
        timestamp=datetime.datetime(2020, 11, 12, 20, 18, 20),
        tests=1,
        time=decimal.Decimal('0.0'),
        cases=[
            TestCase(
                name="Sample Test Case 0",
                assertions=1,
                time=decimal.Decimal('0.0'),
            ),
        ]
    )

    assert ET

# Generated at 2022-06-25 12:46:28.562599
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    '''
    check the returned xml is as expected
    '''
    test_suite_0 = TestSuite(name='test_suite_0')
    # TestCase(): errors=[]
    e1 = TestCase(name='test_case_1', assertions=1, classname='class_0', status='PASS', time=0.123456)
    test_suite_0.cases.append(e1)
    # TestCase(): errors=[TestError()]
    e2 = TestCase(name='test_case_2', assertions=2, classname='class_1', status='FAIL', time=0.234567)
    e2.errors.append(TestError(output='output_2', message='message_2', type='type_2'))

# Generated at 2022-06-25 12:46:36.559993
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name_0', hostname='hostname_0', id='id_0', package='package_0', timestamp=datetime.datetime(year=1975, month=4, day=10, hour=14, minute=8, second=30))

    assert test_suite_0.get_xml_element().tag == 'testsuite'

    test_suite_0.name = 'name_1'
    test_suite_0.hostname = 'hostname_1'
    test_suite_0.id = 'id_1'
    test_suite_0.package = 'package_1'

# Generated at 2022-06-25 12:46:39.675283
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name = 'test_case_0')
    assert test_case_0.get_xml_element().tag == 'testcase'
    assert test_case_0.get_xml_element().attrib['name'] == 'test_case_0'
    assert test_case_0.get_xml_element().text == None


# Generated at 2022-06-25 12:46:40.641859
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()
    
    
    

# Generated at 2022-06-25 12:46:46.479463
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=list(),
        disabled=0,
        errors=0,
        failures=0,
        hostname='',
        id='',
        name='name_0',
        package='',
        skipped=0,
        system_err='system_err_0',
        system_out='system_out_0',
        tests=0,
        time=decimal.Decimal('0'),
        timestamp=datetime.datetime(2020, 7, 15, 16, 49, 57),
    )


# Generated at 2022-06-25 12:46:52.045249
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0.get_xml_element
    assert test_case_0.get_xml_element() == ET.Element('testcase', {'name': 'test_case_0'})


# Generated at 2022-06-25 12:47:11.267849
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite('test-suite-name')

    print(test_suite.get_xml_element())


# Generated at 2022-06-25 12:47:14.088876
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(assertions=0, classname='', name='', status='', time='')
    assert ET.fromstring(ET.tostring(test_case_0.get_xml_element()))


# Generated at 2022-06-25 12:47:24.629866
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='Name1',
                           hostname='localhost',
                           id='id',
                           package='package',
                           timestamp=datetime.datetime.now(),
                           cases=None,
                           properties={'Name': 'Value'},
                           system_out='system_out',
                           system_err='system_err')
    element = test_suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.get('disabled') == None
    assert element.get('errors') == None
    assert element.get('failures') == None
    assert element.get('hostname') == 'localhost'
    assert element.get('id') == 'id'
    assert element.get('name') == 'Name1'
    assert element.get

# Generated at 2022-06-25 12:47:28.042020
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_2 = TestSuite(name='TestSuite')
    xml_string_1 = _pretty_xml(test_suite_2.get_xml_element())
    print(xml_string_1)


# Generated at 2022-06-25 12:47:36.329135
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:47:41.992807
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    TestCase_inst = TestCase("name")
    TestCase_inst.assertions = 2
    TestCase_inst.classname = "classname"
    TestCase_inst.status = "status"
    TestCase_inst.time = decimal.Decimal("3.14")
    TestCase_inst.errors.append(TestError("output", "message", "type"))
    TestCase_inst.failures.append(TestFailure("output", "message", "type"))
    TestCase_inst.skipped = "skipped"
    TestCase_inst.system_out = "system_out"
    TestCase_inst.system_err = "system_err"
    TestCase_inst.is_disabled = False


# Generated at 2022-06-25 12:47:46.792770
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    classname = "class"
    name = "test_method"
    exp_xml_content = "<testcase classname='" + classname + "' name='" + name + "'></testcase>"

    test_result = TestCase(classname=classname, name=name)
    assert str(ET.tostring(test_result.get_xml_element(), encoding="unicode")) == str(exp_xml_content)



# Generated at 2022-06-25 12:47:50.388807
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('xyz')
    assert(test_suite_0.get_xml_element().tag == 'testsuite')
    assert(test_suite_0.get_xml_element().attrib['name'] == test_suite_0.get_attributes()['name'])


# Generated at 2022-06-25 12:47:54.159828
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    a_testcase = TestCase('test_name')
    actual_result = a_testcase.get_xml_element()
    exepected_result = ET.Element('testcase', {'name': 'test_name'})
    assert actual_result.tag == exepected_result.tag
    assert actual_result.attrib == exepected_result.attrib
    assert len(actual_result) == len(exepected_result)


# Generated at 2022-06-25 12:47:59.446423
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name_0')

    test_case_0 = TestCase(name='name_1')

    test_suite_0.cases.append(test_case_0)

    element = test_suite_0.get_xml_element()

    assert ET.tostring(element, encoding='unicode') == '<testsuite name="name_0" tests="1"><testcase name="name_1" /></testsuite>'


# Generated at 2022-06-25 12:48:26.235329
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()
    print("Test class TestSuite executed")


# Generated at 2022-06-25 12:48:28.384770
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # set up the test
    test_case_xml = TestCase(name="test")
    # run the test
    test_case_xml.get_xml_element()


# Generated at 2022-06-25 12:48:32.676574
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="TEST-file.file_test.TestFile1.test_load_from_file_path")
    actual = test_case_0.get_xml_element()
    expected = '<testcase assertions="None" classname="None" name="TEST-file.file_test.TestFile1.test_load_from_file_path" status="None" time="None"></testcase>'
    assert actual == expected


# Generated at 2022-06-25 12:48:38.719092
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="test_suite_0")
    test_suite_0_xml_element = test_suite_0.get_xml_element()
    assert test_suite_0_xml_element.tag == "testsuite"
    assert test_suite_0_xml_element.attrib == {'name': "test_suite_0", 'tests': '0', 'time': '0'}


# Generated at 2022-06-25 12:48:43.167256
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name_0', id='id_0')
    assert test_suite_0.get_xml_element().get('id') == 'id_0'
    assert test_suite_0.get_xml_element().get('name') == 'name_0'
    assert test_suite_0.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-25 12:48:48.830207
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name='TestSuite')

    ts.cases.append(TestCase(
        name='TestCase1',
        assertions=1,
        classname='TestSuite',
        status='STATUS',
        time=decimal.Decimal(123),
        errors=[TestError(message='TestError1'), TestError(message='TestError2')],
        failures=[TestFailure(message='TestFailure1'), TestFailure(message='TestFailure2')],
        skipped='TestCase1 is skipped',
        system_out='TestCase1 output',
        system_err='TestCase1 error')
    )


# Generated at 2022-06-25 12:48:52.047070
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Initialize instance
    test_case_0 = TestCase("")
    # Get the in-memory XML element for instance
    element = test_case_0.get_xml_element()
    # Get the pretty XML string version of the XML element
    # and compare it to the expected XML string
    assert _pretty_xml(element) == "<testcase></testcase>"



# Generated at 2022-06-25 12:48:54.690493
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="name_0")
    assert test_case_0.get_xml_element().text == None
    assert test_case_0.get_xml_element().attrib == {'name': 'name_0'}


# Generated at 2022-06-25 12:49:00.905491
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case = TestCase(
        name = "TestCase name",
        assertions = "123",
        classname = "TestCase classname",
        status = "TestCase status",
        time = "123.456",
        errors = [TestError(
            output = "TestError output",
            message = "TestError message",
            type = "TestError type",
        )],
        failures = [TestFailure(
            output = "TestFailure output",
            message = "TestFailure message",
            type = "TestFailure type",
        )],
        skipped = "TestCase skipped",
        system_out = "TestCase system-out",
        system_err = "TestCase system-err",
        is_disabled = True,
    )
    print(_pretty_xml(case.get_xml_element()))


# Generated at 2022-06-25 12:49:05.456914
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # arrange
    test_case_0 = TestCase(name='test_case_0')

    # act
    actual = test_case_0.get_xml_element()

    # assert
    assert actual.tag == 'testcase'
    assert actual.attrib['name'] == test_case_0.name
    assert len(actual) == 0
    assert actual.text == None



# Generated at 2022-06-25 12:49:26.805950
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase('test_case_0')
    test_suite_0 = TestSuite('test_suite_0')
    test_suite_0.cases.append(test_case_0)
    test_suite_0_get_xml_element_actual = ET.tostring(test_suite_0.get_xml_element())
    test_suite_0_get_xml_element_expected = b'<testsuite name="test_suite_0" tests="1"><testcase name="test_case_0" /></testsuite>'
    assert test_suite_0_get_xml_element_actual == test_suite_0_get_xml_element_expected


# Generated at 2022-06-25 12:49:33.609892
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites = TestSuites()

# Generated at 2022-06-25 12:49:40.830474
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test = TestSuite(name = "TestSuiteName")
    test.hostname = "TestHostname"
    test.id = "TestId"
    test.package = "TestPackage"
    test.timestamp = datetime.datetime.now()
    test.properties['TestPropertyKey'] = "TestPropertyValue"
    test_case_0 = TestCase(name = "TestCaseName")
    test_case_0.assertions = 10
    test_case_0.classname = "TestClassname"
    test_case_0.status = "TestStatus"
    test_case_0.time = decimal.Decimal('10.0')
    test_case_0.errors.append(TestError(output = "TestTestErrorOutput"))

# Generated at 2022-06-25 12:49:48.460850
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:49:51.862554
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_1 = TestSuite(name='name_0')
    assert ET.tostring(var_1.get_xml_element(), method='xml') == b'<testsuite name="name_0" tests="0" errors="0" failures="0" disabled="0" skipped="0" hostname="None" id="None" timestamp="None" time="0.0" package="None"><system-out /><system-err /></testsuite>'

