

# Generated at 2022-06-25 12:40:09.093406
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('name_0', hostname='hostname_0', id='id_0', package='package_0', timestamp=datetime.datetime(2020, 5, 12, 14, 43, 20, 147732))
    test_case_0 = TestCase(name='name_0', assertions=0, classname='classname_0', status='status_0', time=0.0, errors=[], failures=[], skipped='skipped_0', system_out='system_out_0', system_err='system_err_0', is_disabled=False)
    test_suite_0.cases.append(test_case_0)
    test_suite_0.system_out = 'system_out_0'
    test_suite_0.system_err = 'system_err_0'

# Generated at 2022-06-25 12:40:15.831187
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_case = TestCase(
        name="TestCase",
        classname="Class",
        status="status",
        time=1.1,
        system_err="system_err",
        system_out="system_out",
    )

    test_case_element = test_case.get_xml_element()

    assert test_case_element.find("system-err").text == "system_err"
    assert test_case_element.find("system-out").text == "system_out"


# Generated at 2022-06-25 12:40:17.611066
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element().tag == 'result'


# Generated at 2022-06-25 12:40:19.523894
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element() == ET.fromstring("<result type='result'/>")


# Generated at 2022-06-25 12:40:22.726756
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element().tag == 'result'


# Generated at 2022-06-25 12:40:27.355073
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()
    suite_0 = TestSuite(name='test_suite_0')
    element_0 = suite_0.get_xml_element()
    assert element_0.tag == 'testsuite'
    assert len(element_0) == 0
    assert element_0.attrib == {'name': 'test_suite_0'}


# Generated at 2022-06-25 12:40:30.320411
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    if test_result_0.get_attributes() != {}:
        raise AssertionError()


# Generated at 2022-06-25 12:40:33.795136
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_0")
    assert test_case_0.get_xml_element().tag == "testcase"
    assert test_case_0.get_xml_element().attrib == {'name': 'test_case_0'}


# Generated at 2022-06-25 12:40:35.523912
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    attr_dict = test_result_0.get_attributes()
    assert attr_dict == {}


# Generated at 2022-06-25 12:40:39.061808
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="test")
    assert_equals(test_suite_0.get_xml_element().attrib['name'], "test")


# Generated at 2022-06-25 12:40:46.281946
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == {'type': 'TestResult'}


# Generated at 2022-06-25 12:40:55.563232
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
        test_result_0 = TestResult()
        assert test_result_0.get_xml_element() != ET.Element('failure', {'message': None, 'type': 'result'}), 'Wrong output'
        assert test_result_0.get_xml_element() != ET.Element('error', {'message': None, 'type': 'result'}), 'Wrong output'
        assert test_result_0.get_xml_element() == ET.Element('result', {'message': None, 'type': 'result'}), 'Wrong output'


# Generated at 2022-06-25 12:41:04.709728
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:41:08.848211
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_1 = TestCase('test_case_1')
    result = test_case_1.get_xml_element()
    assert result.tag == 'testcase'


# Generated at 2022-06-25 12:41:16.986784
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:41:27.150505
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test_result_1 = TestResult(output='output')
    test_result_2 = TestResult(output='output', message='message')
    test_result_3 = TestResult(output='output', message='message', type='TestFailure')

    test_suite_0 = TestSuite(name='TestSuite')

# Generated at 2022-06-25 12:41:29.133555
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    result = test_result_0.get_xml_element()
    assert result == ET.Element(test_result_0.tag)


# Generated at 2022-06-25 12:41:31.711874
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    expected_value = {}
    actual_value = test_result_0.get_attributes()
    assert expected_value == actual_value, 'incorrect value for get_attributes of TestResult(): expected {}, actual {}'.format(expected_value, actual_value)


# Generated at 2022-06-25 12:41:36.344225
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_case_0()
    #
    # def get_xml_element(self) -> ET.Element:
    #     """Return an XML element representing this instance."""
    #     element = ET.Element(self.tag, self.get_attributes())
    #     element.text = self.output
    #
    #     return element
    #
    # assert False, "No tests run"
    #
    assert True, "Unit test of method get_xml_element of class TestResult"


# Generated at 2022-06-25 12:41:44.548623
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Setup
    class result:
        def __init__(self,tag, attr, text):
            self.tag = tag
            self.attr = attr
            self.text = text
    testResult = TestResult()
    testResult.output = 'Output'
    result_0 = result('Test', {}, 'Output')
    # Test
    result = testResult.get_xml_element()
    # Output
    assert result.tag == result_0.tag
    assert result.attrib == result_0.attr
    assert result.text == result_0.text

# Generated at 2022-06-25 12:41:52.998767
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    import xml.etree.ElementTree as ET
    import dataclasses
    # TestCase
    # Inherited from dataclasses.dataclass
    testResult = TestResult()
    testResult.output = "TestOutput"
    testResult.message = "TestMessage"
    testResult.type = "TestType"
    # Expected Output
    testResultElement = ET.Element("TestResult")
    testResultElement.text = testResult.output
    testResultElement.set("message", testResult.message)
    testResultElement.set("type", testResult.type)
    assert testResult.get_xml_element() == testResultElement



# Generated at 2022-06-25 12:41:54.820156
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element().tag == "testresult"


# Generated at 2022-06-25 12:42:01.177739
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Scenario 1: Testcase has no errors or failures
    # Setup
    name = 'name'
    hostname = 'hostname'
    id = 'id'
    package = 'package'
    timestamp = '2020-02-02T00:00:00'
    status = 'status'
    time = 3.2
    assertions = 2
    classname = 'classname'
    message = 'message'
    type = 'type'
    output = 'output'
    properties = {'key': 'value'}
    test_case_0 = TestCase(name=name,
                            assertions=assertions,
                            classname=classname,
                            status=status,
                            time=time)
    
    # Test

# Generated at 2022-06-25 12:42:06.119318
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_1 = TestResult()
    get_attributes_test_result_1 = test_result_1.get_attributes()
    assert isinstance(get_attributes_test_result_1, dict)
    


# Generated at 2022-06-25 12:42:08.540430
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element() == ET.Element('result')


# Generated at 2022-06-25 12:42:17.923017
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test case data
    name = 'Test suites name'
    hostname = 'Test suites hostname'
    id = 'Test suites id'
    package = 'Test suites package'
    timestamp = datetime.datetime(2019, 12, 16, 19, 15, 39)
    properties = {'key1': 'value1', 'key2': 'value2'}
    suites = list()
    test_case_0 = TestCase(name='test case 0 name',
                           assertions='test case 0 assertion',
                           classname='test case 0 classname',
                           status='test case 0 status',
                           time=decimal.Decimal('1.2'))

# Generated at 2022-06-25 12:42:24.305680
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    assert test_suite_0.get_xml_element() == '''<testsuite/>'''

    test_suite_1 = TestSuite(_time=5, disabled=5, errors=5, failures=5, tests=5)
    assert test_suite_1.get_xml_element() == '''<testsuite tests="5" errors="5" disabled="5" failures="5" time="5.00"/>'''

    test_suite_2 = TestSuite(name='test-name')
    assert test_suite_2.get_xml_element() == '''<testsuite name="test-name"/>'''


# Generated at 2022-06-25 12:42:26.284847
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_1 = TestResult()
    assert test_result_1.get_xml_element() is not None


# Generated at 2022-06-25 12:42:31.220180
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    expected = t.Dict[str, str]
    test_result_0 = TestResult()
    result = test_result_0.get_attributes()
    assert(result == expected)

    expected = t.Dict[str, str]
    test_result_0 = TestResult(output='output', message='message', type='type')
    result = test_result_0.get_attributes()
    assert(result == expected)



# Generated at 2022-06-25 12:42:34.070271
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult(None, None, None)

    root = test_result_0.get_xml_element()
    # XML header
    assert root.tag == 'result'
    assert root.tag == 'result'
    assert root.text == None


# Generated at 2022-06-25 12:42:47.694863
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Create test object
    test_object_0 = TestResult()

    # Call method under test
    retval_1 = test_object_0.get_attributes()

    # Check results
    assert retval_1 == {
        'message': None,
        'type': 'testresult',
    }


# Generated at 2022-06-25 12:42:57.733864
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Unit test for TestSuite.get_xml_element()."""
    my_testsuite = TestSuite(name ='my_testsuite', hostname='my_hostname', id='my_id', package='my_package', timestamp='2018-01-01 00:00:00', system_out='my_system_out', system_err='my_system_err')
    result = my_testsuite.get_xml_element()
    expected_result = ET.fromstring('<testsuite name="my_testsuite" hostname="my_hostname" id="my_id" package="my_package" timestamp="2018-01-01T00:00:00" tests="0" failures="0" errors="0" disabled="0" time="0.0" />')
    assert result == expected_result

#

# Generated at 2022-06-25 12:42:58.732315
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == {}


# Generated at 2022-06-25 12:43:00.745347
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert {} == test_result_0.get_attributes()


# Generated at 2022-06-25 12:43:09.493657
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert ET.tostring(test_result_0.get_xml_element()) == b'<TestResult />'

    test_result_1 = TestResult(output="some output")
    assert ET.tostring(test_result_1.get_xml_element()) == b'<TestResult>some output</TestResult>'

    test_result_2 = TestResult(output="some output", message="some message")
    assert ET.tostring(test_result_2.get_xml_element()) == b'<TestResult message="some message">some output</TestResult>'

    test_result_3 = TestResult(output="some output",  message="some message", type="some type")

# Generated at 2022-06-25 12:43:11.596788
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_case_0()
    assert(test_result_0.get_attributes() is None)


# Generated at 2022-06-25 12:43:19.028541
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    expected_dict = {}
    test_result_0 = TestResult()
    assert_dict = test_result_0.get_attributes()
    assert assert_dict == expected_dict

    expected_dict = {
        'message': 'test_message',
        'type': 'test_type'
    }
    message = 'test_message'
    type = 'test_type'
    test_result_1 = TestResult(
        message = message,
        type = type
    )
    assert_dict = test_result_1.get_attributes()
    assert assert_dict == expected_dict


# Generated at 2022-06-25 12:43:22.643148
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_1 = TestResult()
    assert ET.tostring(test_result_1.get_xml_element(), encoding='unicode') == '<__main__.TestResult object at 0x7f8ca81842e0>'


# Generated at 2022-06-25 12:43:33.176397
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_0")
    expected_1 = """<testcase name="test_case_0"/>"""
    actual_1 = _pretty_xml(test_case_0.get_xml_element())
    assert actual_1 == expected_1

    test_case_0 = TestCase(name="test_case_0", assertions=1)
    expected_1 = """<testcase assertions="1" name="test_case_0"/>"""
    actual_1 = _pretty_xml(test_case_0.get_xml_element())
    assert actual_1 == expected_1

    test_case_0 = TestCase(name="test_case_0", classname="foo")
    expected_1 = """<testcase classname="foo" name="test_case_0"/>"""
   

# Generated at 2022-06-25 12:43:39.137840
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Creation of an instance of class TestResult without parameter
    test_result_0 = TestResult()
    assert test_result_0.__class__ == TestResult

    test_result_1 = TestResult(output='test case output 1', message='test case message 1', type='test case type 1')
    assert test_result_1.__class__ == TestResult
    assert test_result_1.output == 'test case output 1'
    assert test_result_1.message == 'test case message 1'
    assert test_result_1.type == 'test case type 1'

    # Creation of an instance of class TestResult
    test_result_2 = TestResult(output='test case output 2', message=None, type='test case type 2')
    assert test_result_2.__class__ == TestResult
    assert test_result_2

# Generated at 2022-06-25 12:43:50.297702
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    assert TestResult().get_xml_element() is not None



# Generated at 2022-06-25 12:43:54.359150
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name_0')
    xml = test_suite_0.get_xml_element()
    assert (xml.tag == 'testsuite')
    assert (xml.get('name') == 'name_0')
    assert (xml.get('tests') == '0')



# Generated at 2022-06-25 12:43:55.756225
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert type(test_result_0.get_xml_element()) == ET._ElementInterface


# Generated at 2022-06-25 12:43:58.286088
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    print("Test: get_xml_element")
    test_result_0 = TestResult()
    element = ET.Element('testcase')
    assert test_result_0.get_xml_element() == element
    assert test_result_0.get_xml_element() == element


# Generated at 2022-06-25 12:44:00.499114
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    expected = '<result></result>'
    assert _pretty_xml(TestResult().get_xml_element()) == expected



# Generated at 2022-06-25 12:44:01.529058
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_case_0()


# Generated at 2022-06-25 12:44:06.989330
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase('test_case_0')

    test_suite_0 = TestSuite('test_suite_0')
    test_suite_0.cases.append(test_case_0)

    xml_0 = test_suite_0.get_xml_element()

    assert xml_0.get('tests') == '1'
    assert len(xml_0.findall('testcase')) == 1



# Generated at 2022-06-25 12:44:09.369428
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == _attributes()


# Generated at 2022-06-25 12:44:11.128977
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    assert TestResult().get_xml_element() == ET.fromstring('<TestResult />')


# Generated at 2022-06-25 12:44:15.220938
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult(output="output", message="message", type="type")
    tests = [
        ("<type>output</type>", test_result_0)
    ]
    for expected, example in tests:
        assert _pretty_xml(example.get_xml_element()) == expected


# Generated at 2022-06-25 12:44:26.108712
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    assert TestResult().get_xml_element().tag == 'result'


# Generated at 2022-06-25 12:44:27.832167
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element() == ET.Element('testresult')


# Generated at 2022-06-25 12:44:32.028528
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    print(
    '''
    Test Case 0

    Expected Result: "testcase" tag

    Actual Result:
    '''
    )

    test_case_0 = TestCase(name='test_case_0')
    print(test_case_0.get_xml_element())



# Generated at 2022-06-25 12:44:33.579498
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    expected = {}
    actual = TestResult().get_attributes()
    assert expected == actual


# Generated at 2022-06-25 12:44:34.417548
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_case_0()


# Generated at 2022-06-25 12:44:40.313113
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite_obj = TestSuite()
    root = suite_obj.get_xml_element()
    root1 = ET.Element('testsuite', {})
    if root == root1:
        print("TestSuite_get_xml_element Passed")
    else:
        print("TestSuite_get_xml_element Failed")


# Generated at 2022-06-25 12:44:43.316099
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    element = test_suite_0.get_xml_element()
    assert ET.tostring(element) == b'<testsuite tests="0" />'



# Generated at 2022-06-25 12:44:44.644853
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='some output')
    # TODO


# Generated at 2022-06-25 12:44:53.542280
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        name='FreqSync_SyncOnStartup_SpuriousFreqResponse',
    )
    expected = ET.fromstring(
        '<testcase name="FreqSync_SyncOnStartup_SpuriousFreqResponse" />'
    )

    actual = test_case_0.get_xml_element()

    assert ET.tostring(expected, encoding='unicode') == ET.tostring(actual, encoding='unicode')


# Generated at 2022-06-25 12:45:00.198447
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test_result_element_0 = test_result_0.get_xml_element()
    assert 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"' in test_result_element_0.attrib
    assert test_result_element_0.attrib['output'] == ''
    assert test_result_element_0.text == ''
    assert test_result_element_0.tag == 'testresult'


# Generated at 2022-06-25 12:45:22.921690
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == {}
    test_result_1 = TestResult(message="message", output="output", type="type")
    assert test_result_1.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-25 12:45:24.818490
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert _attributes(
        message=None,
        type=None,
    ) == {'message': 'None', 'type': 'None'}


# Generated at 2022-06-25 12:45:34.543977
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase('test_case_0_name')
    test_case_1 = TestCase('test_case_1_name')
    test_case_2 = TestCase('test_case_2_name')
    test_suite_0 = TestSuite('test_suite_0_name')
    test_suite_0.cases.append(test_case_0)
    test_suite_0.cases.append(test_case_1)
    test_suite_0.cases.append(test_case_2)
    suite_xml_element = test_suite_0.get_xml_element()
    assert len(suite_xml_element) == 4

# Generated at 2022-06-25 12:45:37.425336
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == {'type': 'testresult'}


# Generated at 2022-06-25 12:45:40.208783
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testcase = TestCase()
    expected = '<testcase></testcase>'
    actual = testcase.get_xml_element()
    assert expected == ET.tostring(actual, encoding='unicode')



# Generated at 2022-06-25 12:45:44.026081
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Create instance
    test_result_0 = TestResult()

    # Create expected result
    expectedResult = dict()

    # Retrieve the result
    result = test_result_0.get_attributes()

    # Assert that the two results are equal
    assert result == expectedResult



# Generated at 2022-06-25 12:45:53.392407
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="TestCase0")
    assert test_case_0.get_xml_element().attrib == ET.Element('testcase', {'name':'TestCase0'}).attrib
    assert test_case_0.get_xml_element().tag == ET.Element('testcase', {'name':'TestCase0'}).tag
    assert test_case_0.get_xml_element().text == ET.Element('testcase', {'name':'TestCase0'}).text
    assert test_case_0.get_xml_element() is not ET.Element('testcase', {'name':'TestCase0'})


# Generated at 2022-06-25 12:45:55.842521
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name = 'test_name')
    assert isinstance(test_suite_0.get_xml_element(), ET.Element)


# Generated at 2022-06-25 12:46:03.942933
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Test 1
    expected = ET.fromstring("""
    <testcase name="System.ServiceModel.Description.MetadataExchangeClientSection.BehaviorUrlTemplateProperty">
      <failure message="The key 'BehaviorUrlTemplate' cannot be found in the appSettings configuration section" type="System.Collections.Generic.KeyNotFoundException">
        Expected: not null
        But was:  null
        at StoneFruit.Engine.Configuration.AppSettingsConfiguration.ReadSettingValue&amp;#40;&amp;#41; in C:\code\stonefruit\StoneFruit.Engine\Configuration\AppSettingsConfiguration.cs:line 22
      </failure>
    </testcase>
    """)

# Generated at 2022-06-25 12:46:05.890583
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == {'type': 'testResult'}


# Generated at 2022-06-25 12:46:29.715331
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    assert str(TestResult().get_xml_element()) == '<TestResult></TestResult>'


# Generated at 2022-06-25 12:46:32.295123
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    test_attributes = test_result_0.get_attributes()
    assert test_attributes == {}


# Generated at 2022-06-25 12:46:34.349313
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()

    assert test_result_0.get_xml_element().tag == 'result'


# Generated at 2022-06-25 12:46:39.999371
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name = "name_0")
    test_xml_element_0 = test_suite_0.get_xml_element()
    test_xml_element_1 = ET.Element('testsuite', {'name':'name_0', 'tests':'0', 'failures':'0', 'errors':'0', 'disabled':'0', 'skipped':'0', 'time':'0'})
    assert test_xml_element_0 == test_xml_element_1


# Generated at 2022-06-25 12:46:43.397029
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    class TestResult_TestImpl(TestResult):
        @property
        def tag(self) -> str:
            return None
    # Test 0: Default args
    test_result_0 = TestResult_TestImpl()
    # Verify
    assert test_result_0.get_xml_element().attrib == {}
    assert test_result_0.get_xml_element().text == None


# Generated at 2022-06-25 12:46:48.932127
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element().tag == 'result'
    assert test_result_0.get_xml_element().attrib == {}
    assert test_result_0.get_xml_element().text == ''


# Generated at 2022-06-25 12:46:58.718787
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_case_0_result = set()
    test_case_0 = TestResult(output=None, message=None, type=None)
    test_case_0_result.add(test_case_0.get_attributes() == {'message': 'None', 'type': 'None'})
    test_case_1_result = set()
    test_case_1 = TestResult(output='test_output', message='test_message', type='test_type')
    test_case_1_result.add(test_case_1.get_attributes() == {'message': 'test_message', 'type': 'test_type'})
    assert {True} == test_case_0_result == test_case_1_result


# Generated at 2022-06-25 12:47:01.445441
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    arg_ts = TestSuite(name="test1", hostname="test2", id="test3", package="test4", timestamp=datetime.datetime.now())
    assert arg_ts.get_xml_element() is not None


# Generated at 2022-06-25 12:47:11.766017
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Unit test for method get_xml_element of class TestSuite."""

    # Test that an empty test suite with only the required attributes returns a valid XML element.
    test_suite_1 = TestSuite('Unittest')
    xml_element_1 = test_suite_1.get_xml_element()
    assert xml_element_1.tag == 'testsuite'
    assert xml_element_1.attrib == _attributes(
        disabled=0,
        errors=0,
        failures=0,
        name='Unittest',
        tests=0,
        time=0.0,
    )

    # Test a test suite containing all possible attributes.
    test_suite_0 = TestSuite('0.0.0.0')

# Generated at 2022-06-25 12:47:13.597804
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == {}


# Generated at 2022-06-25 12:48:40.167588
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # test_suite_0
    test_case_0_0 = TestCase(
        assertions=None,
        classname=None,
        errors=[],
        failures=[],
        is_disabled=False,
        name='test_case_0_0',
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None
    )

# Generated at 2022-06-25 12:48:45.984174
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    print( "Method test_TestSuite_get_xml_element: start")
    test_suite = TestSuite(name = "MyTestSuite")
    xml_element = test_suite.get_xml_element()
    print(xml_element)
    #print(xml_element.tag)
    # TODO: test that xml_element is of type xml.etree.ElementTree.Element
    #print(xml_element.attrib)
    #print(xml_element.attrib['name'])
    print( "Method test_TestSuite_get_xml_element: end")
    return xml_element


# Generated at 2022-06-25 12:48:49.812470
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite = TestSuite(name=None,
                          hostname=None,
                          id=None,
                          package=None,
                          timestamp=None,
                          properties=None,
                          cases=None,
                          system_out=None,
                          system_err=None)

    assert testSuite.get_xml_element().tag == 'testsuite'



# Generated at 2022-06-25 12:48:53.424828
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('test_case_0')
    test_suite = TestSuite('test_suite_0', timestamp=datetime.datetime.now())
    test_suites = TestSuites()

    assert test_case.get_xml_element().attrib == test_case.get_attributes()
    assert test_suite.get_xml_element().attrib == test_suite.get_attributes()
    assert test_suites.get_xml_element().attrib == test_suites.get_attributes()



# Generated at 2022-06-25 12:48:55.599097
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case = TestCase(name='test_testsuites_created_from_scratch')

    expected = """<testcase assertions="None" classname="None" name="test_testsuites_created_from_scratch" status="None" time="None"></testcase>"""
    assert _pretty_xml(case.get_xml_element()) == expected



# Generated at 2022-06-25 12:48:59.541286
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    assert _pretty_xml(TestSuite('testsuite_name').get_xml_element()) == "<?xml version=\"1.0\" ?>\n" + \
                                                                         "<testsuite name=\"testsuite_name\">\n" + \
                                                                         "</testsuite>\n"



# Generated at 2022-06-25 12:49:08.033688
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_0")
    test_case_1 = TestCase(name="test_case_1", assertions=1)
    test_case_2 = TestCase(name="test_case_2", classname="classname")
    test_case_3 = TestCase(name="test_case_3", status="status")
    test_case_4 = TestCase(name="test_case_4", time=1.1)
    test_case_5 = TestCase(name="test_case_5", time=1.1)
    test_case_6 = TestCase(name="test_case_6")
    test_case_7 = TestCase(name="test_case_7")
    test_case_8 = TestCase(name="test_case_8")
    test

# Generated at 2022-06-25 12:49:12.888695
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """TestCase.get_xml_element should return an Element that has the same name as TestCase.tag."""
    test_case_0 = TestCase(name = "test_case_0")
    assert test_case_0.get_xml_element().tag == "testcase", "TestCase.get_xml_element() should return an Element that has the same name as TestCase.tag."


# Generated at 2022-06-25 12:49:20.794814
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_case_0 = TestCase(
        assertions=1,
        classname='com.example.SomeTest',
        name='someMethod',
        status='FAILED',
        time=datetime.datetime(2017, 10, 16, 7, 10, 0),
        is_disabled=False,
    )

    test_suite_0 = TestSuite(
        name='SomeSuite',
        hostname='qe-server.example.com',
        id='1',
        package='com.example',
        timestamp=datetime.datetime(2017, 10, 16, 7, 10, 0),
        properties={'key0': 'value0', 'key1': 'value1'},
        cases=[test_case_0],
        system_out='simple out',
        system_err='simple err',
    )

# Generated at 2022-06-25 12:49:26.053264
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=0,
        classname='classname_0',
        errors=[
            TestError(),
            TestError(
                message='message_1',
                type='type_1',
            ),
        ],
        failures=[
            TestFailure(),
            TestFailure(
                message='message_1',
                type='type_1',
            ),
        ],
        name='name_0',
        skipped='skipped_0',
        status='status_0',
        system_out='system_out_0',
        system_err='system_err_0',
        time=decimal.Decimal(0),
    )
    print(test_case_0.get_attributes())

