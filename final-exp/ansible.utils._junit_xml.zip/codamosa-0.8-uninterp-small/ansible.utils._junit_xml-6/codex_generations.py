

# Generated at 2022-06-25 12:40:13.830942
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        name = 'name',
        hostname = 'hostname',
        id = 'id',
        package = 'package',
        timestamp = datetime.datetime(2020, 4, 1, 14, 38, 15),
        properties = {'key0': 'value0', 'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'},
        cases = [],
        system_out = 'system_out',
        system_err = 'system_err'
    )
    et_Element_0 = test_suite_0.get_xml_element( )
    str_0 = _pretty_xml(et_Element_0)


# Generated at 2022-06-25 12:40:16.031055
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case0 = TestCase(
        name='foo',
    )
    assert test_case0.get_xml_element().tag == 'testcase'


# Generated at 2022-06-25 12:40:20.057288
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('name')
    res = test_case.get_xml_element()
    assert res.tag == 'testcase'
    assert res.get('name') == 'name'


# Generated at 2022-06-25 12:40:26.295663
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        "test_0",
        package="package_0",
        timestamp="2020-12-01T10:01:00Z",
        hostname="hostname_0",
        id="id_0",
    )
    xml_element_0 = test_suite_0.get_xml_element()
    str_0 = _pretty_xml(xml_element_0)


# Generated at 2022-06-25 12:40:35.337555
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite()
    test_suite.name = 'name'
    test_case = TestCase()
    test_case.name = 'case_name'
    test_case.time = 0.100
    test_case.classname = 'classname'
    test_case.assertions = 1
    error = TestError(type='error_type', output='output', message='error')
    failure = TestFailure(type='failure_type', output='output', message='failure')
    test_case.errors.append(error)
    test_case.failures.append(failure)
    test_case.skipped = 'skipped'
    test_case.system_out = 'system_out'
    test_case.system_err = 'system_err'
    test_suite.cases

# Generated at 2022-06-25 12:40:41.058232
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='0')
    test_case_0 = TestCase(name='1')
    test_case_0.errors.append(TestError(message='2', output='3', type='4'))
    test_suite_0.cases.append(test_case_0)
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:40:42.928528
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:40:47.837902
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testCase_0 = TestCase(
        assertion = int(),
        classname = "classname_0",
        name = "name_0",
        status = "status_0",
        time = decimal.Decimal(),
        errors = [],
        failure = [],
        skipped = "skipped_0",
        system_out = "system_out_0",
        system_err = "system_err_0",
        is_disabled = False,
        is_failure = False,
        is_error = False,
        is_skipped = False,
    )
    element_0 = testCase_0.get_xml_element()

# Generated at 2022-06-25 12:40:56.232237
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    element_1 = test_case_0.get_xml_element()
    str_0 = ET.tostring(element_1, encoding='unicode', method='xml')
    if str_0 == '<testcase name="test_case_0" />':
        str_0 = 'pass'
    else:
        str_0 = 'fail'
    print(str_0)


# Generated at 2022-06-25 12:40:59.414571
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="name_0")
    xml_element_0 = test_suite_0.get_xml_element()
    str_0 = _pretty_xml(xml_element_0)


# Generated at 2022-06-25 12:41:14.356296
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_case_0 = TestCase()

    test_result_0 = TestFailure()
    test_result_0.message = 'test_message'
    test_result_0.output = 'test_output'
    test_result_0.type = 'test_type'
    test_case_0.failures.append(test_result_0)

    test_case_0.is_disabled = False

    test_case_0.name = 'test_name'
    test_case_0.time = datetime.timedelta(microseconds=1)
    test_case_0.skipped = 'test_skipped'
    test_case_0.system_out = 'test_system_out'
    test_case_0.system_err = 'test_system_err'


# Generated at 2022-06-25 12:41:18.907488
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case")
    root_node = ET.fromstring(test_case_0.get_xml_element().tostring())
    assert root_node.tag == 'testcase'
    assert root_node.attrib == {'name': 'test_case'}


# Generated at 2022-06-25 12:41:23.283195
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    xmltestsuite_0 = ET.Element('testsuite')
    result = test_suite_0.get_xml_element()
    assert result.tag == xmltestsuite_0.tag


# Generated at 2022-06-25 12:41:28.824251
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        disabled=0,
        errors=0,
        failures=0,
        hostname='hostname',
        id='id',
        name='name',
        package='package',
        skipped=0,
        tests=0,
        time=decimal.Decimal('0.0000'),
        timestamp=datetime.datetime.now(datetime.timezone.utc),
    )


# Generated at 2022-06-25 12:41:30.321825
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase()
    assert test_case_0.get_xml_element().tag == 'testcase'


# Generated at 2022-06-25 12:41:38.813979
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    test_suite_1 = TestSuite(name="test_suite_1")
    test_suite_1.timestamp = datetime.datetime.now()

    assert test_suite_0.get_xml_element().attrib['name'] == ''
    assert test_suite_1.get_xml_element().attrib['timestamp'] == test_suite_1.timestamp.isoformat(timespec='seconds')



# Generated at 2022-06-25 12:41:40.775883
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    attrs = dict(name='test-case-0', assertions=1)
    test_case_0 = TestCase(**attrs)
    expected = ET.Element('testcase', attrs)
    assert test_case_0.get_xml_element() == expected


# Generated at 2022-06-25 12:41:52.305606
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase("Test Name")
    test_suite_0 = TestSuite("Test Suite Name")
    test_suite_1 = TestSuite("Test Suite Name", cases=[test_case_0])
    assert test_suite_1.get_xml_element() == ET.Element("testsuite", {'tests':'1', 'failures':'0', 'name':'Test Suite Name', 'disabled':'0', 'errors':'0', 'skipped':'0', 'time':'0'})

if __name__ == '__main__':
    import sys
    import nose

    argv = sys.argv[:]
    argv.append('--verbose')
    argv.append('--nocapture')

# Generated at 2022-06-25 12:41:59.523593
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('Name')
    test_suite_1 = TestSuite('Name', hostname='Hostname', id='Id', package='Package', timestamp=datetime.datetime(2019, 2, 3, 12, 34, 56))
    test_suite_2 = TestSuite('Name', properties={'Key': 'Value'}, cases=[TestCase('Case'), TestCase('Case', assertions=1, classname='Class', status='Status', time=decimal.Decimal('1.234'), errors=[TestError('Error', message='Error message', type='Error type')], failures=[TestFailure('Failure', message='Failure message', type='Failure type')], system_out='System out', system_err='System err')], system_out='System out', system_err='System err')

    # Base case
    assert _pretty

# Generated at 2022-06-25 12:42:07.265503
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0_0 = TestSuite(name='test_suite_0', timestamp=datetime.datetime.now(), properties={
        'property_0': 'value_0',
    }, system_out='system_out_0')

    ET.tostring(test_suite_0_0.get_xml_element())



# Generated at 2022-06-25 12:42:15.081731
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    a = TestCase(name='test1', time=1.2)
    assert _pretty_xml(a.get_xml_element()) == '<?xml version="1.0" ?>\n<testcase assertions="None" classname="None" name="test1" status="None" time="1.2" />\n'

# Generated at 2022-06-25 12:42:19.948647
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name=None, hostname=None, id=None, package=None, timestamp=None, properties=None, cases=None, system_out=None, system_err=None)
    ET.tostring(test_suite_0.get_xml_element()) == b'<testsuite disabled="0" errors="0" failures="0" name="" tests="0" time="0.00" />'


# Generated at 2022-06-25 12:42:28.024984
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    success_xml = """
    <testsuite disabled="0" errors="0" failures="0" hostname="localhost" id="0" name="A testsuite" package="test" skipped="0" tests="1" time="0.0" timestamp="2020-08-31T20:04:58">
        <properties></properties>
        <testcase assertions="1" classname="A testcase" name="A testcase" status="passed" time="1.0"/>
        <system-out></system-out>
        <system-err></system-err>
    </testsuite>
    """
    success_xml = _pretty_xml(ET.fromstring(success_xml))
    test_suite = TestSuite(name='A testsuite')

# Generated at 2022-06-25 12:42:34.913270
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create test data for the test
    test_case_1 = TestCase(
        assertions=1,
        classname='test_class',
        errors=[
            TestError(
                message='Error message',
                output='Error output',
                type='type'
            )
        ],
        failures=[
            TestFailure(
                message='Failure message',
                output='Failure output',
                type='type'
            )
        ],
        name='Test case 1',
        skipped='Skipped',
        status='status',
        system_err='stderr',
        system_out='stdout',
        time=2.0
    )


# Generated at 2022-06-25 12:42:45.803190
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite()
    test_suite.name = "Test Suite Name"
    test_suite.hostname = "Test Suite Host Name"
    test_suite.id = "Test Suite Id"
    test_suite.package = "Test Suite Package"
    test_suite.timestamp = datetime.datetime.now()

    test_suite.properties['Property 1'] = "Property Value 1"
    test_suite.properties['Property 2'] = "Property Value 2"

    test_case_0 = TestCase()
    test_case_0.name = "TestCase 0"
    test_case_0.assertions = 0
    test_case_0.classname = "TestCase 0 ClassName"
    test_case_0.status = "TestCase 0 Status"
    test_case

# Generated at 2022-06-25 12:42:49.090459
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    suite = TestSuite(name='ExampleTestSuite')
    element = suite.get_xml_element()

    assert element.tag == 'testsuite'
    assert element.attrib['name'] == 'ExampleTestSuite'
    assert 'time' not in element.attrib
    assert 'tests' not in element.attrib


# Generated at 2022-06-25 12:42:59.803356
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="name_0")
    root = test_suite_0.get_xml_element()
    assert root.tag == 'testsuite'
    assert root.get('disabled') == '0'
    assert root.get('errors') == '0'
    assert root.get('failures') == '0'
    assert root.get('hostname') is None
    assert root.get('id') is None
    assert root.get('name') == 'name_0'
    assert root.get('package') is None
    assert root.get('skipped') == '0'
    assert root.get('tests') == '0'
    assert root.get('time') == '0'
    assert root.get('timestamp') is None



# Generated at 2022-06-25 12:43:04.437244
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create instance of TestSuite
    test_suite_0 = TestSuite()

    # Call get_xml_element
    element = test_suite_0.get_xml_element()

    # Get value of element.tag
    tag = element.tag

    # Check if tag is equal to testsuite
    assert(tag == 'testsuite')


# Generated at 2022-06-25 12:43:11.477258
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite()
    ts.name = "TestSuite"
    ts.hostname = "host"
    ts.id = "123"
    ts.package = "package"
    ts.timestamp = datetime.datetime.now()

    ts_elem = ts.get_xml_element()
    assert ts.get_attributes() == ts_elem.attrib
    assert ts_elem.find('properties') is None
    assert ts_elem.find('testcase') is None
    assert ts_elem.find('system-out') is None
    assert ts_elem.find('system-err') is None

    ts.properties = {"A": "Value of A", "B": "Value of B"}
    ts_elem = ts.get_xml_element()
    assert ts.get_

# Generated at 2022-06-25 12:43:15.203310
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    test_xml = test_suite_0.get_xml_element()
    expected_xml = ET.Element("testsuite")

    assert test_xml == expected_xml


# Generated at 2022-06-25 12:43:22.180384
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TestSuite_0 = TestSuite()
    assert TestSuite_0.get_xml_element().tag == "testsuite", "Incorrect return from TestSuite_0.get_xml_element()"


# Generated at 2022-06-25 12:43:28.313049
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    expected_result = '<testsuite disabled="0" errors="0" failures="0" hostname="" id="" name="" package="" skipped="0" tests="0" time="0" timestamp="" />'

    test_suite_0 = TestSuite()
    xml_element = test_suite_0.get_xml_element()
    actual_result = ET.tostring(xml_element, encoding='unicode')

    assert actual_result == expected_result


# Generated at 2022-06-25 12:43:37.058793
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        assertions=1,
        classname='test_TestCase',
        name='test_TestCase_get_xml_element',
        status='Passed',
        time=1
    )
    test_suite_0 = TestSuite(
        name='test_TestSuite_get_xml_element',
        hostname='localhost',
        id='1',
        package='test_TestSuite_get_xml_element',
        timestamp=datetime.datetime.now()
    )
    test_suite_0.cases.append(test_case_0)
    test_suite_0.system_err = 'Error:'
    test_suite_0.system_out = 'Output:'
    test_xml = test_suite_0.get_xml_element()

# Generated at 2022-06-25 12:43:46.794411
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name='test_suite_0',
        cases=[
            TestCase(
                name='test_case_0',
                status='error',
                time=None,
            ),
            TestCase(
                name='test_case_1',
                status='fail',
                time=decimal.Decimal('0.1'),
            ),
            TestCase(
                name='test_case_2',
                status='pass',
                time=decimal.Decimal('0.2'),
            ),
            TestCase(
                name='test_case_3',
                status='skip',
                time=None,
            ),
        ]
    )


# Generated at 2022-06-25 12:43:51.845001
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # TestCase setup
    test_case_0 = TestCase()
    expected_1 = "<testcase name='None'></testcase>"
    # Call the method to test
    result_1 = test_case_0.get_xml_element()
    # Verify the results
    assert result_1.tag == expected_1


# Generated at 2022-06-25 12:43:56.609733
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Arrange
    test_suite = TestSuite('class_name')
    # Act
    result = test_suite.get_xml_element()
    # Assert
    assert result.get('name') == test_suite.name
    assert result.get('errors') == str(test_suite.errors)
    assert result.get('time') == str(test_suite.time)
    assert result.get('tests') == str(test_suite.tests)
    assert result.get('failures') == str(test_suite.failures)
    assert result.get('disabled') == str(test_suite.disabled)


# Generated at 2022-06-25 12:43:58.107134
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name="Test Case 1")
    test_case.get_xml_element()
    assert True


# Generated at 2022-06-25 12:44:03.638020
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Testing default case
    test_case_1 = TestCase(name='test_case_name')
    test_case_1_xml_element = test_case_1.get_xml_element()
    assert test_case_1_xml_element.tag == 'testcase'
    assert test_case_1_xml_element.attrib == {'name': 'test_case_name'}
    assert list(test_case_1_xml_element) == []


# Generated at 2022-06-25 12:44:06.283158
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='test_suite_0')
    assert isinstance(test_suite_0.get_xml_element(), ET.Element)


# Generated at 2022-06-25 12:44:11.861288
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="test_case_0", assertions=1)
    test_case_0_xml = test_case_0.get_xml_element()
    assert test_case_0_xml.tag == "testcase" and test_case_0_xml.attrib == {'assertions': '1', 'name': 'test_case_0'}


# Generated at 2022-06-25 12:44:21.843337
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name="TestCase", assertions = None, classname = None, status = "success", time = None)
    ET.ElementTree(test_case.get_xml_element()).write('test_case_0.xml',encoding='unicode')



# Generated at 2022-06-25 12:44:24.668881
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="TestCase_0")

    result = test_case_0.get_xml_element()
    expected_result = b'<testcase name="TestCase_0" />'

    assert result == expected_result


# Generated at 2022-06-25 12:44:26.973411
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    expected = '<testsuite />'
    assert _pretty_xml(test_suite_0.get_xml_element()) == expected


# Generated at 2022-06-25 12:44:34.708649
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testCase_0 = TestCase('testCase_0', 2, 'testCaseClass_0', 'testCaseStatus_0', 3.14)
    assert testCase_0.get_xml_element().get('assertions') == '2'
    assert testCase_0.get_xml_element().get('classname') == 'testCaseClass_0'
    assert testCase_0.get_xml_element().get('name') == 'testCase_0'
    assert testCase_0.get_xml_element().get('status') == 'testCaseStatus_0'
    assert testCase_0.get_xml_element().get('time') == '3.14'

# Generated at 2022-06-25 12:44:41.008147
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase("my name", classname="my classname")
    result_0 = test_case_0.get_xml_element()
    # Expected result: '<testcase classname="my classname" name="my name" />'
    print(result_0)
    assert result_0 == '<testcase classname="my classname" name="my name" />'


# Generated at 2022-06-25 12:44:42.610667
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    assert get_xml_element == '<testsuite name="testsuite_0"></testsuite>'

# Generated at 2022-06-25 12:44:47.682535
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='name_0')
    expected = "<testcase name='name_0'/>"
    actual = _pretty_xml(test_case_0.get_xml_element())
    assert expected == actual, 'Expected [{expected}] but got [{actual}]'.format(expected=expected, actual=actual)


# Generated at 2022-06-25 12:44:55.133410
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('test')
    test_case.assertions = '3'
    test_case.classname = 'test_class'
    test_case.status = 'passed'
    test_case.time = '4.4'

    test_failure0 = TestFailure('output_failure', 'message_failure')
    test_failure0.type = 'type_failure'
    test_failure1 = TestFailure('output_failure')
    test_failure2 = TestFailure('output_failure')
    test_case.failures = [test_failure0, test_failure1, test_failure2]

    test_error0 = TestError('output_error', 'message_error')
    test_error0.type = 'type_error'

# Generated at 2022-06-25 12:44:59.004379
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testcase = TestCase(
        name='test1'
    )
    assert testcase.get_xml_element().tag == 'testcase'
    assert testcase.get_xml_element().attrib == {'name': 'test1'}


# Generated at 2022-06-25 12:45:08.435502
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase()
    test_case_1 = TestCase()


# Generated at 2022-06-25 12:45:15.085913
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test = TestCase('test')
    assert test.get_xml_element().tag == 'testcase'
    assert test.get_xml_element().attrib['name'] == 'test'


# Generated at 2022-06-25 12:45:22.861857
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_expected = ET.fromstring("""<testsuite disabled="0" errors="0" failures="0" name="empty" tests="0" time="0"></testsuite>""")
    test_suite = TestSuite("empty")
    test_suite_actual = test_suite.get_xml_element()
    assert test_suite_expected.tag == test_suite_actual.tag
    assert test_suite_expected.attrib == test_suite_actual.attrib
    assert test_suite_expected.text == test_suite_actual.text

if __name__ == '__main__':
    test_case_0()
    test_TestSuite_get_xml_element()

# Generated at 2022-06-25 12:45:26.202071
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    test_suite_0 = TestSuite(optional_0, optional_1, optional_2, optional_3, optional_4)

    r = test_suite_0.get_xml_element()
    assert str(r) == "testsuite"


# Generated at 2022-06-25 12:45:35.667194
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # The following code test the method get_xml_element of class TestSuite
    suite_0=TestSuite('suite_0')
    case_0=TestCase('case_0')
    case_1=TestCase('case_1')
    case_1.is_disabled=True
    error_0=TestError('error_0')
    error_1=TestError('error_1')
    error_2=TestError('error_2')
    case_1.errors.append(error_0)
    case_1.errors.append(error_1)
    case_1.errors.append(error_2)
    suite_0.cases.append(case_0)
    suite_0.cases.append(case_1)
    suite_0.system_err='system_err'

# Generated at 2022-06-25 12:45:42.933682
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # TestCase_0
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    testsuite_0 = TestSuite(optional_0, optional_1, optional_2, optional_3, optional_4)
    # TestCase_1
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    testsuite_1 = TestSuite(optional_0, optional_1, optional_2, optional_3, optional_4)
    # TestCase_2
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    testsuite_2 = TestSu

# Generated at 2022-06-25 12:45:53.747971
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    optional_5 = None
    optional_6 = None
    optional_7 = None
    optional_8 = None
    optional_9 = None
    optional_10 = None
    optional_11 = None
    optional_12 = None
    test_case_0 = TestCase(optional_0, optional_1, optional_2, optional_3, optional_4)
    test_case_1 = TestCase(optional_5, optional_6, optional_7, optional_8, optional_9)
    test_suite_0 = TestSuite(optional_10, optional_11, optional_12)

# Generated at 2022-06-25 12:45:57.265282
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()

    test_suite_0 = TestSuite(name='name')
    test_suite_0.get_xml_element()
    test_suite_0.get_xml_element()
    return test_suite_0.get_xml_element()

# Generated at 2022-06-25 12:45:59.286312
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    assert ET.tostring(TestCase('hello').get_xml_element()) == b'<testcase name="hello" />'


# Generated at 2022-06-25 12:46:04.099738
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('test_case_name_0')
    test_case_0.is_disabled = False
    test_case_0.skipped = 'test_case_skipped_0'
    test_case_0.system_out = 'test_case_systemout_0'
    test_case_0.system_err = 'test_case_systemerr_0'
    assert test_case_0.get_xml_element() is not None




# Generated at 2022-06-25 12:46:13.617635
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    optional_0 = None
    test_case_0 = TestCase(optional_0)
    optional_0 = None
    test_case_0.time = optional_0
    test_case_0.time
    ret_1 = test_case_0.get_xml_element()
    str_0 = "<testcase assertions=\"None\" classname=\"None\" name=\"None\" status=\"None\" time=\"None\">\n        </testcase>"
    assert(str(ET.tostring(ret_1)) == str_0)

    test_case_0.name = "test_case_0"
    ret_1 = test_case_0.get_xml_element()

# Generated at 2022-06-25 12:46:25.341778
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    element_0 = ET.Element('testcase', {'name': 'a', 'time': '3', 'classname': 'b', 'status': 'Pass'})
    element_0.extend([ET.Element('skipped', {'message': 'c'})])
    element_0.extend([ET.Element('error', {'type': 'd', 'message': 'e'})])
    element_0.extend([ET.Element('failure')])
    element_0.extend([ET.Element('system-out')])
    element_0.extend([ET.Element('system-err')])
    optional_0 = None
    test_error_0 = TestError(optional_0)
    optional_1 = None
    test_failure_0 = TestFailure(optional_1)
    test_case_0

# Generated at 2022-06-25 12:46:29.731857
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    optional_0 = None
    test_case_0 = TestCase('test_case_0', optional_0)
    result = test_case_0.get_xml_element()
    assert result == ET.Element('testcase', {'name': 'test_case_0'})


# Generated at 2022-06-25 12:46:37.191214
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    case_0_0_0 = TestCase('', None, None, None, None)
    suite_0_0 = TestSuite('', None, None, None, None, [case_0_0_0])
    case_0_1_0 = TestCase('', None, None, None, None)
    case_0_1_1 = TestCase('', None, None, None, None)
    suite_0_1 = TestSuite('', None, None, None, None, [case_0_1_0, case_0_1_1])
    case_0_2_0 = TestCase('', None, None, None, None)
    case_0_2_1 = TestCase('', None, None, None, None)
    case_0_2_2 = TestCase('', None, None, None, None)

# Generated at 2022-06-25 12:46:43.724868
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Setup
    optional_0 = None
    test_error_0 = TestError(optional_0)
    optional_1 = None
    test_failure_0 = TestFailure(optional_1)
    optional_2 = None
    test_case_0 = TestCase(optional_2, test_error_0, test_failure_0)
    optional_3 = None
    test_suite_0 = TestSuite(optional_3, test_case_0)

    # Invocation
    result = test_suite_0.get_xml_element()

    # Verification

# Generated at 2022-06-25 12:46:56.678473
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    foo = TestCase('test_name', assertions=40, classname='TestClass', status='failed', time='1.23456')
    bar = TestCase('test_name', assertions=40, classname='TestClass', status='failed', time='1.23456')
    test_suite = TestSuite('test_name', hostname='localhost', id='123', package='com.example.foo.bar', timestamp=datetime.datetime.fromtimestamp(1))
    test_suite.cases.append(foo)
    test_suite.cases.append(bar)
    element = test_suite.get_xml_element()
    assert element.tag == 'testsuite'

# Generated at 2022-06-25 12:47:04.346783
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Case: No attribute
    test_suite = TestSuite(name="name_0")
    element = test_suite.get_xml_element()

    assert element.tag == "testsuite"
    assert element.attrib == {
        "name": "name_0",
    }
    assert element.text == None
    assert element.tail == None
    assert element.getchildren() == []

    # Case: All attributes

# Generated at 2022-06-25 12:47:14.866426
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    optional_0 = None
    optional_1 = None
    optional_2 = None
    test_case_0 = TestCase(optional_0, optional_1, optional_2)
    test_case_1 = TestCase(optional_0, optional_1, optional_2)
    test_case_2 = TestCase(optional_0, optional_1, optional_2)
    test_case_3 = TestCase(optional_0, optional_1, optional_2)
    optional_0 = 3
    test_case_0.assertions = optional_0
    optional_0 = None
    test_case_0.classname = optional_0
    optional_0 = None
    test_case_0.status = optional_0
    optional_0 = None
    test_case_0.time = optional_0
    test_case

# Generated at 2022-06-25 12:47:25.815907
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    optional_5 = None
    optional_6 = None
    optional_7 = None
    optional_8 = None
    optional_9 = None
    optional_10 = None
    optional_11 = None
    optional_12 = None
    optional_13 = None
    optional_14 = None
    optional_15 = None
    optional_16 = None
    optional_17 = None
    optional_18 = None
    optional_19 = None
    optional_20 = None
    optional_21 = None
    optional_22 = None
    optional_23 = None
    optional_24 = None
    optional_25 = None
    optional_26 = None
    optional_27 = None
    optional_

# Generated at 2022-06-25 12:47:34.733264
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    classname_0 = "em3qwYVeZ"
    optional_0 = None
    test_error_0 = TestError(optional_0)
    optional_1 = None
    type_0 = None
    test_failure_0 = TestFailure(optional_1, type_0)
    optional_2 = None
    test_case_0 = TestCase("g6URX9eR5", optional_2, classname_0)
    optional_3 = None
    optional_4 = None
    optional_5 = None
    optional_6 = None
    test_suite_0 = TestSuite("1eHS0KcOg", optional_3, optional_4, optional_5, optional_6)
    optional_7 = None
    test_suites_0 = TestSuites(optional_7)
   

# Generated at 2022-06-25 12:47:37.107808
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Initializing test fixture
    test_suite_0 = TestSuite("",None,None,None,None)
    
    # Calling method under test
    test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:47:49.362912
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    test_case_0 = TestCase(
        assertions=optional_0,
        classname=optional_1,
        errors=[],
        failures=[],
        name="test",
        status=optional_2,
        time=optional_3,
        is_disabled=optional_4,
    )
    test_case_1 = TestCase(
        assertions=optional_0,
        classname=optional_1,
        errors=[],
        failures=[],
        name="test",
        status=optional_2,
        time=optional_3,
        is_disabled=optional_4,
    )


# Generated at 2022-06-25 12:47:55.751905
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Declare variables
    optional_0 = None
    optional_1 = 'Test system_out'
    optional_2 = 'Test system_err'
    optional_3 = 'Test name'
    optional_4 = 'Test hostname'
    optional_5 = 'Test id'
    optional_6 = 'Test package'
    optional_7 = t.Optional[datetime.datetime](datetime.datetime.now())
    optional_8 = t.Dict[str, str]({'test': '1'})
    test_case_0 = TestCase('Test case')
    optional_9 = t.List[TestCase]([test_case_0])
    # Create instance

# Generated at 2022-06-25 12:47:57.828904
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    optional_0 = None
    test_case_0 = TestCase(optional_0)
    property__0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:48:06.286846
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    option_1 = 0
    option_2 = 0
    test_case_0 = TestCase('test_case_0')
    option_0 = [test_case_0]
    test_suite_0 = TestSuite('test_suite_0', option_0)
    test_suite_0.get_xml_element()
    assert test_suite_0.errors == option_1, 'Expected value is equal to one'
    assert test_suite_0.failures == option_2, 'Expected value is equal to one'
    assert test_suite_0.disabled == option_1, 'Expected value is equal to one'
    assert test_suite_0.skipped == option_2, 'Expected value is equal to one'
    assert test_suite_0.tests == option_1

# Generated at 2022-06-25 12:48:09.692876
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name = "name")
    test_case_0.time = decimal.Decimal('0')
    test_case_1 = TestCase(name = "name")
    test_case_1.time = decimal.Decimal('0')
    test_case_1.classname = "classname"


# Generated at 2022-06-25 12:48:19.116312
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Input
    #data case 1
    name1 = 'TestSuite1'
    hostname1 = 'hostname01'
    id1 = 'id01'
    package1 = 'package1'
    #timestamp1 = datetime.datetime(2019, 10, 16, 17, 4, 32, 472617)
    timestamp1 = datetime.datetime(2019, 10, 16, 17, 4, 32)
    properties1 = {'a': 'b'}
    cases1 = [TestCase('A', assertions = None, classname = None, status = None, time = 0)]
    system_out1 = None
    system_err1 = None
    #data case 2
    name2 = 'TestSuite2'
    hostname2 = 'hostname02'
    id2 = 'id02'
    package2

# Generated at 2022-06-25 12:48:26.542879
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite_0 = TestSuite('<property value="module_name" name="module_name"/>', None, None, None)
    actual_xml = testsuite_0.get_xml_element().tostring()
    expected_xml = '<testsuite disabled="0" errors="0" failures="0" name="&lt;property value=&quot;module_name&quot; name=&quot;module_name&quot;/&gt;" skipped="0" tests="0" time="0">\n  <properties />\n</testsuite>'
    assert actual_xml == expected_xml


# Generated at 2022-06-25 12:48:33.631663
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    optional_5 = None
    optional_6 = None
    optional_7 = None
    test_case_0 = TestCase(
        assertions=optional_0,
        classname=optional_1,
        errors=[],
        failures=[],
        is_disabled=False,
        name='',
        skipped=optional_2,
        status=optional_3,
        system_err=optional_4,
        system_out=optional_5,
        time=optional_6,
    )

    optional_8 = None
    optional_9 = None
    optional_10 = None
    optional_11 = None
    optional_12 = None
    optional_13 = None
    optional_

# Generated at 2022-06-25 12:48:42.510414
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_case_1 = TestCase("test_case_1",
        0,
        "test_case_1",
        "test_case_1",
        0.1,
        [TestError("first error"), TestError("second error")],
        [TestFailure("first failure"), TestFailure("second failure")],
        "skipped",
        "system_out",
        "system_err",
        False
    )

# Generated at 2022-06-25 12:48:51.668630
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Capture the contents of testsuite_0.xml
    with open('./testsuite_0.xml', 'r') as file:
        testsuite_0_xml = file.read()

    # Create the expected value of the get_xml_element() return
    testsuite_0_element = ET.fromstring(testsuite_0_xml)

    # Create the TestSuite
    testsuite_0 = TestSuite(
        'failure.test.simple',
        packages=1,
        tests=3,
        errors=1,
        failures=1,
        disabled=1,
        timestamp=datetime.datetime.now()
        )

    # Verify the contents of the returned XML element
    assert testsuite_0_element.tag == 'testsuite'
    assert testsuite_0

# Generated at 2022-06-25 12:49:04.820513
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    name = ['Name']
    hostname = ['Hostname']
    id = ['ID']
    package = ['Package']
    timestamp = [datetime.datetime(2014, 1, 2, 3, 4, 5)]
    properties = [{'key': 'value'}]
    cases = [TestCase(name=name[0])]
    system_out = ['System output']
    system_err = ['System error']
    test_suite = TestSuite(name=name[0], hostname=hostname[0], id=id[0], package=package[0], timestamp=timestamp[0], properties=properties[0], cases=cases, system_out=system_out[0], system_err=system_err[0])
    get_xml_element_result = test_suite.get_xml_element()
    get

# Generated at 2022-06-25 12:49:13.549438
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    name_0 = 'name_0'
    test_suite_0 = TestSuite(name_0)
    test_case_0_0 = TestCase('name_0', None, 'classname_0', 'status_0', decimal.Decimal('3.3'))
    test_case_0_0.skipped = 'skipped_0'
    test_case_0_0.system_out = 'system_out_0'
    test_case_0_0.system_err = 'system_err_0'
    test_suite_0.cases = [test_case_0_0]
    test_suite_0.system_out = 'system_out_0'
    test_suite_0.system_err = 'system_err_0'

# Generated at 2022-06-25 12:49:16.349513
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_name')
    assert test_case_0.name == 'test_name'
    assert test_case_0.get_xml_element().get('name') == 'test_name'


# Generated at 2022-06-25 12:49:23.014592
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite = TestSuite(name="TestSuite", hostname="TestHost", id="TestID", package="TestPackage", timestamp=datetime.datetime.now(), properties={"TestKey0": "TestValue0"})

    test_case_0 = TestCase(name="TestCase_0", assertions=0, classname="TestClassName", status="TestStatus", time=decimal.Decimal(1.0), skipped="TestSkipped0", system_out="SystemOutString0", system_err="SystemErrString0")
    test_error_0 = TestError(output="ErrorOutputString0", message="ErrorMessage0", type="ErrorType0")
    test_error_1 = TestError(output="ErrorOutputString1", message="ErrorMessage1", type="ErrorType1")

# Generated at 2022-06-25 12:49:29.998456
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_1 = TestCase('name_1')
    assert str(test_case_1.get_xml_element()) == '<testcase name="name_1" />'
    test_case_2 = TestCase('name_2', assertions=2)
    assert str(test_case_2.get_xml_element()) == '<testcase assertions="2" name="name_2" />'
    test_case_3 = TestCase('name_3', classname='classname_3')
    assert str(test_case_3.get_xml_element()) == '<testcase classname="classname_3" name="name_3" />'
    test_case_4 = TestCase('name_4', status='status_4')

# Generated at 2022-06-25 12:49:36.515324
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    optional_0 = None
    optional_1 = None
    optional_2 = None
    optional_3 = None
    optional_4 = None
    optional_5 = None
    optional_6 = None
    optional_7 = None
    optional_8 = None
    optional_9 = None
    optional_10 = None
    optional_11 = None
    optional_12 = None
    optional_13 = None
    optional_14 = None

    property_0 = dict(name=optional_0,value=optional_1)
    properties = [ET.Element(optional_2,optional_3)]

# Generated at 2022-06-25 12:49:38.997545
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 12:49:47.166823
# Unit test for method get_xml_element of class TestCase

# Generated at 2022-06-25 12:49:49.850547
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('name')
    assert test_case_0.get_xml_element().find('testcase').attrib == {'name': 'name'}
