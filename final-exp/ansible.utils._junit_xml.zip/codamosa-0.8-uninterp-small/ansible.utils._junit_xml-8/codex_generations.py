

# Generated at 2022-06-25 12:40:00.307908
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    var_0 = test_result_0.get_attributes()


# Generated at 2022-06-25 12:40:10.943618
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=None,
        classname=None,
        errors=[],
        failures=[],
        name='Test case name',
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None,
    )
    test_case_1 = TestCase(
        assertions=None,
        classname=None,
        errors=[],
        failures=[],
        name='Test case name',
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None,
    )

# Generated at 2022-06-25 12:40:13.785536
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase()
    var_1 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:40:15.600233
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # TODO: Figure out correct assert value
    test_suite_0 = TestSuite()
    assert type(test_suite_0.get_xml_element()) == ET.Element


# Generated at 2022-06-25 12:40:22.777444
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_case = TestCase(
        name='test',
        classname='module.TestClass',
        time=decimal.Decimal('0.2'),
        assertions=1,
    )

    assert test_case.get_attributes() == {
        'assertions': '1',
        'classname': 'module.TestClass',
        'name': 'test',
        'time': '0.2'
    }



# Generated at 2022-06-25 12:40:24.701517
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    attribute_0 = TestResult()
    attribute_1 = attribute_0.get_attributes()


# Generated at 2022-06-25 12:40:27.144705
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    var_0 = dict()
    var_0 = test_result_0.get_attributes()
    assert var_0.items() == {}.items()


# Generated at 2022-06-25 12:40:29.945707
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    retval_0 = test_result_0.get_attributes()


# Generated at 2022-06-25 12:40:31.801711
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    var_0 = test_result_0.get_attributes()


# Generated at 2022-06-25 12:40:38.278717
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Test positive
    test_case_1 = TestCase('test name')
    test_case_1.is_disabled = True

    test_xml_1 = test_case_1.get_xml_element()
    assert test_xml_1.tag == 'testcase'
    assert test_xml_1.find('skipped') is not None
    assert test_xml_1.attrib['disabled'] == '1'
    assert test_xml_1.attrib['name'] == 'test name'
    assert test_xml_1.attrib['tests'] == '1'

    # Test negative
    try:
        test_case_1 = TestCase(None)
    except TypeError:
        assert True
    except:
        assert False


# Generated at 2022-06-25 12:40:47.767431
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert(test_result_0.get_attributes() == {})
    test_result_0.message = 'message'
    assert(test_result_0.get_attributes() == {'message': 'message'})
    test_result_0.type = 'type'
    assert(test_result_0.get_attributes() == {'message': 'message', 'type': 'type'})


# Generated at 2022-06-25 12:40:50.656153
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element() == ET.fromstring("<TestResult></TestResult>")


# Generated at 2022-06-25 12:40:57.751959
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    a = TestResult()
    assert a.get_attributes() == {}, "Attributes of TestResult should be empty after initialization"
    a.message = "a"
    a.output = "a"
    a.type = "a"
    assert a.get_attributes() == {"message": "a", "type": "a"}, "Attributes of TestResult should be correctly updated"


# Generated at 2022-06-25 12:41:03.161361
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    test_result_1 = TestResult(output='output', message='message', type='type')
    output_result_0 = test_result_0.get_attributes()
    output_result_1 = test_result_1.get_attributes()
    assert len(output_result_0) == 0
    assert len(output_result_1) == 3
    assert output_result_1['output'] == 'output'
    assert output_result_1['message'] == 'message'
    assert output_result_1['type'] == 'type'



# Generated at 2022-06-25 12:41:14.485437
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='a')
    xml_str = ET.tostring(test_case_0.get_xml_element(), encoding='unicode')
    assert xml_str == '<testcase name="a" />'

    test_case_0 = TestCase(name='a', time=1.0)
    xml_str = ET.tostring(test_case_0.get_xml_element(), encoding='unicode')
    assert xml_str == '<testcase assertions="0" classname="" name="a" status="run" time="1.0" />'

    test_case_0 = TestCase(name='a', time=1.0, status='pass')
    xml_str = ET.tostring(test_case_0.get_xml_element(), encoding='unicode')


# Generated at 2022-06-25 12:41:15.852303
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert test_result_0.get_attributes() == _attributes(output=None, message=None, type='testresult')


# Generated at 2022-06-25 12:41:21.292604
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    expect = {}
    actual = test_result_0.get_attributes()
    assert expect == actual

    test_result_1 = TestResult(output='A test error occurred', message='A test message')
    expect = {'message': 'A test message'}
    actual = test_result_1.get_attributes()
    assert expect == actual


# Generated at 2022-06-25 12:41:26.266960
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult(output='Error: Expected 1 but got 99',
                               message='Assertion failed',
                               type='AssertionError')
    answer = {'message': 'Assertion failed',
              'type': 'AssertionError'}
    assert test_result_0.get_attributes() == answer


# Generated at 2022-06-25 12:41:29.423809
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    xml_element_0 = test_result_0.get_xml_element()
    assert xml_element_0.tag == 'result'
    assert _pretty_xml(xml_element_0) == '<result/>'


# Generated at 2022-06-25 12:41:30.645259
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_1 = TestResult()
    print('\nTest method get_attributes of class TestResult')
    print(test_result_1.get_attributes())


# Generated at 2022-06-25 12:41:49.833188
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    element_0 = ET.Element('test_result')
    output_0 = element_0.text
    assert element_0.text == output_0
    assert test_result_0.output == output_0
    assert test_result_0.message == output_0
    test_failure_0 = TestFailure()
    type_0 = test_failure_0.tag
    assert test_failure_0.type == type_0
    test_error_0 = TestError()
    tag_0 = test_error_0.tag
    assert test_error_0.tag == tag_0
    assert test_error_0.tag == tag_0
    #assert test_result_0.type == tag_0



# Generated at 2022-06-25 12:41:54.937235
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test_result_0.output = "output"
    test_result_0.message = "message"
    test_result_0.type = "type"
    test_result_0.tag = "tag"
    test_result_0.get_attributes()
    try:
        test_result_0.get_xml_element()
        assert False
    except:
        assert True


# Generated at 2022-06-25 12:41:56.127918
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    expected = '<output/>'
    assert ET.tostring(TestResult().get_xml_element(), encoding='unicode').strip().replace('\n', '') == expected


# Generated at 2022-06-25 12:42:00.244147
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test_result_1 = TestResult()

    assert test_result_0.get_xml_element().tag == 'rerun'
    assert test_result_1.get_xml_element().tag == 'rerun'
    test_result_0.output = 'test_output'
    test_result_0.message = 'test_message'
    test_result_0.type = 'test_type'

    assert test_result_0.get_xml_element().text == 'test_output'
    assert test_result_0.get_xml_element().get('message') == 'test_message'
    assert test_result_0.get_xml_element().get('type') == 'test_type'

# Generated at 2022-06-25 12:42:05.153854
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    obj = TestResult()
    result = obj.get_attributes()
    expected = {'type': 'TestResult'}
    assert result == expected


# Generated at 2022-06-25 12:42:09.185158
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == {'type': 'testresult'}, f'Expected: {test_result_0.get_attributes()} to be {{"type": "testresult"}}'


# Generated at 2022-06-25 12:42:18.481609
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Create a TestResult
    test_result_0 = TestResult()

    # Assign test_result_0[output]
    test_result_0.output = (
        'test_result_0[output]')
    # Assign test_result_0[message]
    test_result_0.message = (
        'test_result_0[message]')
    # Assign test_result_0[type]
    test_result_0.type = (
        'test_result_0[type]')

    # Call method get_xml_element of test_result_0
    test_result_0_get_xml_element_call: ET.Element = (
        test_result_0.get_xml_element()
    )
    # Assert _pretty_xml(test_result_0_get_xml_

# Generated at 2022-06-25 12:42:20.828929
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():

    test_result_0 = TestResult()
    expected_value = ET.Element('testresult')

    assert _pretty_xml(expected_value) == _pretty_xml(test_result_0.get_xml_element())



# Generated at 2022-06-25 12:42:23.983313
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element() is not None
    assert type(test_result_0.get_xml_element()) is ET.Element


# Generated at 2022-06-25 12:42:32.467209
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite = TestSuite(name = 'Batch_Test_Suite', hostname = 'Manoj', id = '1', package = 'Test_Package', timestamp = datetime.datetime.now())
    testSuite.properties = {'test': 'Manoj'}
    testCase1 = TestCase(name = 'Test_Case_1', assertions = 5, classname = 'Manoj', status = 'Pass', time = 5)
    testSuite.cases.append(testCase1)
    testSuiteElement = testSuite.get_xml_element()

    testSuiteXmlElement = ET.fromstring(ET.tostring(testSuiteElement))


# Generated at 2022-06-25 12:43:03.604494
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('TestSuite')
    test_xml = test_suite_0.get_xml_element()
    assert test_xml.tag == 'testsuite'
    assert test_xml.get('name') == 'TestSuite'


# Generated at 2022-06-25 12:43:09.617148
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:43:18.943990
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=0,
        classname='org.example.Test',
        errors=[],
        failures=[],
        name='test',
        skipped=None,
        status='PASSED',
        system_err=None,
        system_out=None,
        time=decimal.Decimal('0.001'),
    )

    assert test_case_0.get_xml_element().attrib == {
        'time': '0.001',
        'name': 'test',
        'classname': 'org.example.Test',
        'status': 'PASSED',
    }
    assert len(test_case_0.get_xml_element()) == 0



# Generated at 2022-06-25 12:43:28.850125
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    xml_string = '''
    <testsuites>
        <testsuite>
            <testcase name="test_case_0" assertions="1"/>
        </testsuite>
    </testsuites>
    '''
    test_suites_args = {
        'name': 'test_suites_0',
        'suites': [
            {
                'name': 'test_suite_0',
                'cases': [
                    {
                        'assertions': '1',
                        'name': 'test_case_0',
                    }
                ]
            }
        ]
    }

    test_suites = TestSuites(**test_suites_args)
    test_suites_xml = test_suites.get_xml_element()

# Generated at 2022-06-25 12:43:37.367024
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_result_0 = TestFailure(output='', message='hello', type='failure')
    test_case_0 = TestCase(name='hello', assertions=0, classname='', status='', time=0, errors=[], failures=[], skipped='', system_out='', system_err='', is_disabled=False)
    test_suite_0 = TestSuite(name='hello', hostname='', id='', package='', timestamp=datetime.datetime.now(), properties={}, cases=[], system_out='', system_err='')
    assert type(test_suite_0.get_xml_element()) == ET.Element

# Generated at 2022-06-25 12:43:45.767402
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite (

        name="test_suite_0"
    )

    element = test_suite_0.get_xml_element()

    assert element.tag == "testsuite"
    assert element.attrib["name"] == "test_suite_0"
    assert element.attrib["disabled"] == "0"
    assert element.attrib["errors"] == "0"
    assert element.attrib["failures"] == "0"
    assert element.attrib["skipped"] == "0"
    assert element.attrib["tests"] == "0"
    assert element.attrib["time"] == "0"

# Generated at 2022-06-25 12:43:54.529173
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    test_suite_0 = TestSuite(name='test_suite_0')
    test_suite_0.cases.append(test_case_0)

    test_suites_0 = TestSuites(name='test_suites_0')
    test_suites_0.suites.append(test_suite_0)

    test_xml = test_suites_0.to_pretty_xml()

    # print('\n')
    # print(test_xml)

    # validate XML
    assert ET.XML(test_xml).tag == 'testsuites'



# Generated at 2022-06-25 12:43:59.445000
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name="test_name_0")
    test_case_1 = TestCase(name="test_name_1")
    test_suite_0 = TestSuite(name="test_name_0", cases=[test_case_0, test_case_1], timestamp=datetime.datetime(2015,10,17,16,38,23))
    test_suite_xml = test_suite_0.get_xml_element()
    assert test_suite_xml.attrib['tests'] == '2'

# Generated at 2022-06-25 12:44:05.108946
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name = 'TestSuite1', hostname = 'localhost')
    assert  _pretty_xml(test_suite.get_xml_element()) == '''
<?xml version="1.0" ?>
<testsuite name="TestSuite1" tests="0" failures="0" errors="0" disabled="0" errors="0" failures="0" hostname="localhost" time="0"/>
'''


# Generated at 2022-06-25 12:44:15.438270
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name_0')
    assert '<testsuite name="name_0" errors="0" disabled="0" skipped="0" failures="0" tests="0" time="0.0"><properties /></testsuite>' == _pretty_xml(test_suite_0.get_xml_element())
    test_suite_0.properties = {'name_0': 'value_0'}
    assert '<testsuite name="name_0" errors="0" disabled="0" skipped="0" failures="0" tests="0" time="0.0"><properties><property name="name_0" value="value_0" /></properties></testsuite>' == _pretty_xml(test_suite_0.get_xml_element())

# Generated at 2022-06-25 12:44:32.736693
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="name")
    test_suite_0.cases = [TestCase(name="name")]
    test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:44:39.140467
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    expected_output = """<testsuite name="TestSuite" disabled="0" errors="0" failures="0" tests="0" time="0">
  <properties>
    <property name="name_0" value="TestSuite" />
    <property name="name_1" value="TestSuite" />
  </properties>
  <testcase classname="class_name" name="test_name" time="0">
    <error message="" />
  </testcase>
  <testcase classname="class_name" name="test_name" time="0">
    <failure message="" />
  </testcase>
</testsuite>"""
    TestSuite_0 = TestSuite("TestSuite")
    TestSuite_0.properties["name_0"] = "TestSuite"
    TestSuite

# Generated at 2022-06-25 12:44:48.181827
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='MySuite')
    assert len(test_suite.cases) == 0
    test_case_0 = TestCase(name='TestCase0')
    test_suite.cases.append(test_case_0)
    test_case_1 = TestCase(name='TestCase1')
    test_suite.cases.append(test_case_1)
    assert len(test_suite.cases) == 2
    test_suites = TestSuites(name='MyTestSuites')
    assert len(test_suites.suites) == 0
    test_suites.suites.append(test_suite)
    assert len(test_suites.suites) == 1


# Generated at 2022-06-25 12:44:55.295250
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    import xml.etree.ElementTree as ET
    from datetime import datetime

    time = datetime.now().replace(microsecond=0)


# Generated at 2022-06-25 12:45:05.009091
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    prop = {
        "p1": "v1",
        "p2": "v2",
        "p3": "v3"
    }

# Generated at 2022-06-25 12:45:12.026071
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    assert TestSuite('test_name').get_xml_element() == ET.fromstring('''\
<testsuite name="test_name" tests="0" />
''')

    assert TestSuite('test_name', disabled=1, errors=2, failures=3, skipped=4,
                     tests=1, time=decimal.Decimal('10.20')).get_xml_element() == ET.fromstring('''\
<testsuite name="test_name" disabled="1" errors="2" failures="3" skipped="4" tests="1" time="10.2" />
''')


# Generated at 2022-06-25 12:45:20.796583
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite = TestSuite(name="Suite", hostname="localhost", id="1", package="package", timestamp="timestamp")
    setattr(testSuite, "properties", {"key":"value"})
    setattr(testSuite, "cases", {"case0", "case1", "case2"})
    setattr(testSuite, "system-out", "test")
    setattr(testSuite, "system-err", "test")

    testSuite.get_xml_element()
    assert testSuite.cases[0] == "case0"
    assert testSuite.cases[1] == "case1"
    assert testSuite.cases[2] == "case2"
    assert testSuite.disabled == 0
    assert testSuite.errors == 0

# Generated at 2022-06-25 12:45:26.405796
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='test_suite_0')
    test_case_0 = TestCase(name='test_case_0', classname='test_class_0')
    test_suite_0.cases.append(test_case_0)
    expected = '<testsuite disabled="0" errors="0" failures="0" name="test_suite_0" skipped="0" tests="1" time="0" />'
    result = _pretty_xml(test_suite_0.get_xml_element())
    assert expected == result


# Generated at 2022-06-25 12:45:30.322298
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name')
    element = test_suite_0.get_xml_element()
    # assert
    assert element.attrib == {'name': 'name'}
    assert element.text is None


# Generated at 2022-06-25 12:45:39.670797
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        classname="org.openqa.selenium.safari.SafariDriverTestSuite.",
        name="testFirefoxBinary",
        time=0.976,
    )
    test_case_1 = TestCase(
        classname="org.openqa.selenium.safari.SafariDriverTestSuite.",
        name="testFirefoxBinary",
        time=0.976,
    )

# Generated at 2022-06-25 12:45:59.723160
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    test_case_0 = TestCase()
    test_suite_1 = TestSuite(cases=[test_case_0])
    result = test_suite_1.get_xml_element()
    assert isinstance(result, ET.Element)
    assert result.attrib == {'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '0', 'time': '0'}
    assert result[0].attrib == {'time': 'None', 'name': 'None'}
    assert result[0].text is None



# Generated at 2022-06-25 12:46:08.149917
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:46:18.091571
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    from datetime import datetime
    from decimal import Decimal
    test_result_0 = TestResult(output = 'Some text', message = 'Some message', type = 'pass')
    test_result_1 = TestResult(output = 'Some other text', message = 'Some other message', type = 'fail')
    test_case_0 = TestCase(name = 'test_case_0', assertions = 0, classname = 'test_class_0', status = 'pass', time = Decimal(15))
    test_case_1 = TestCase(name = 'test_case_1', assertions = 1, classname = 'test_class_1', status = 'fail', time = Decimal(25))

# Generated at 2022-06-25 12:46:25.827397
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:46:34.285930
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_result_0 = TestResult()
    test_failure_0 = TestFailure()
    test_error_0 = TestError()
    test_case_0 = TestCase(name = 'TEST NAME')
    test_case_0.errors.append(test_result_0)
    test_case_0.errors.append(test_failure_0)
    test_case_0.failures.append(test_result_0)
    test_case_0.failures.append(test_error_0)
    test_suite_0 = TestSuite(name = 'TEST SUITE NAME', timestamp = datetime.datetime.now())
    test_suite_0.cases.append(test_case_0)
    test_suites_0 = TestSuites()

# Generated at 2022-06-25 12:46:37.809883
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(assertions=1, name='name', time=0.004)
    test_suite_0 = TestSuite(cases=[test_case_0], name='name')
    _pretty_xml(test_suite_0.get_xml_element())

# Generated at 2022-06-25 12:46:42.183435
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='test_case_name')
    test_case_1 = TestCase(name='test_case_name')

    test_suite_0 = TestSuite(name='test_suite_name', cases=[test_case_0, test_case_1])

    assert test_suite_0.get_xml_element() == ET.Element(
        'testsuite',
        {'name': 'test_suite_name', 'tests': '2'}
    )


# Generated at 2022-06-25 12:46:54.047560
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='foo', hostname='bar', id='baz', package='test_xml', timestamp=datetime.datetime(2019,9,21,10,0,0))
    test_suite.properties['foo'] = 'bar'
    test_suite.system_out = 'out'
    test_suite.system_err = 'err'

    test_case_0 = TestCase(name='test_case_0', assertions=2, classname='TestFoo', status='success', time=0.02)

    test_suite.cases.append(test_case_0)
    test_suite.cases.append(TestCase(name='test_case_1', assertions=3, classname='TestBar', status='success', time=0.03))

    element = test_su

# Generated at 2022-06-25 12:46:59.240911
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        cases = [],
        name = 'test_suite',
        id = '1',
        timestamp = datetime.datetime(2020, 6, 1, 3, 17, 29, 771250),
        hostname = 'test_hostname',
        package = 'test_package',
    )
    xml_element = test_suite.get_xml_element()
    attributes = xml_element.attrib
    assert (attributes['disabled'] == '0')
    assert (attributes['errors'] == '0')
    assert (attributes['failures'] == '0')
    assert (attributes['tests'] == '0')
    assert (attributes['time'] == '0')
    assert (attributes['name'] == 'test_suite')

# Generated at 2022-06-25 12:47:04.561162
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test no test case
    test_case_0 = TestCase(name='test_case_0')
    test_suite_0 = TestSuite(name='test_suite_0', cases=[test_case_0])
    xml_element_0 = test_suite_0.get_xml_element()
    assert xml_element_0.attrib['errors'] == '0'

if __name__ == "__main__":
    # Unit test for method get_xml_element of class TestSuite
    test_TestSuite_get_xml_element()

# Generated at 2022-06-25 12:47:31.327894
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:47:40.237955
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=None,
        classname=None,
        errors=[],
        failures=[],
        name="name_0",
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None,
    )
    assert '<testcase assertions="None" classname="None" name="name_0" status="None" time="None">' \
           '<system-out />' \
           '</testcase>' == _pretty_xml(test_case_0.get_xml_element())


# Generated at 2022-06-25 12:47:42.845766
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name = "testsuite-test")
    element = suite.get_xml_element()
    print(element)
    assert element is not None
    assert element.tag == 'testsuite'


# Generated at 2022-06-25 12:47:50.755160
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite = TestSuite('suite_name', 'hostname', 'id', 'package', datetime.datetime.now(), {'name': 'value'}, [TestCase('case_name', 'classname', 'status', 0.1, [TestError('error_output', 'error_message', 'error_type')], [TestFailure('failure_output', 'failure_message', 'failure_type')], 'skipped', 'system_out', 'system_err')], 'system_out', 'system_err')


# Generated at 2022-06-25 12:47:56.592903
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ##################################################
    # Test Case 1:
    ##################################################
    # Arrange
    test_suite_0 = TestSuite('ts0', id='id0', hostname='hostname0', package='package0', timestamp=datetime.datetime.now(), name='name0',
                             properties={'prop0': 'propvalue0', 'prop1': 'propvalue1'}, cases=[TestCase('tc0', assertions=1, classname='class0', status='s0', time=1),
                                                                                                 TestCase('tc1', assertions=2, classname='class0', status='s1', time=2)],
                             system_out='syso', system_err='syse')
    # Act
    actual = test_suite_0.get_xml_element()
    # Assert


# Generated at 2022-06-25 12:48:03.216218
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Given
    test_suite_0 = TestSuite(
        name='name'
    )

    # When
    xml_element_0 = test_suite_0.get_xml_element()

    # Then
    assert xml_element_0.tag == 'testsuite'
    assert len(xml_element_0.attrib) == 7
    assert xml_element_0.attrib['errors'] == '0'
    assert xml_element_0.attrib['name'] == 'name'
    assert xml_element_0.attrib['tests'] == '0'
    assert xml_element_0.text is None


# Generated at 2022-06-25 12:48:07.837505
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    print('Testing TestCase.get_xml_element')
    test_case_0 = TestCase(
        name = 'TestCase_get_xml_element',
    )
    assert test_case_0.get_xml_element() == ET.Element(
        'testcase',
        _attributes(
            classname=None,
            name='TestCase_get_xml_element',
        ),
    )


# Generated at 2022-06-25 12:48:11.555229
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    myTestCase = TestCase('test.name', 1, 'test.classname', 'test', 0.1, [TestError('test.errormessage', "test.me", "test.type")])
    assertETEqual(myTestCase.get_xml_element(),
        '<testcase assertions="1" classname="test.classname" name="test.name" status="test" time="0.1">'
        '<error message="test.errormessage" type="test.type">test.me</error>'
        '</testcase>')


# Generated at 2022-06-25 12:48:22.041406
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(
        cases=[
            TestCase(
                name='test_case_0',
            ),
        ],
        name='test_suite_0',
    )
    xml_element_0 = test_suite_0.get_xml_element()

    try:
        assert xml_element_0.tag == 'testsuite'
    except AssertionError:
        print(f'Expected: {["testsuite"]}')
        print(f'Actual:   {[xml_element_0.tag]}')
        return
    try:
        assert xml_element_0.get('name') == 'test_suite_0'
    except AssertionError:
        print(f'Expected: {["test_suite_0"]}')

# Generated at 2022-06-25 12:48:30.470429
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase("name")
    test_case_1 = TestCase("name2")
    xml = test_case_0.get_xml_element()
    print(xml)
    assert (ET.tostring(xml) == ET.tostring(test_case_1.get_xml_element()))

    test_case_0 = TestCase("name",status="true")
    test_case_1 = TestCase("name",status="false")

    xml = test_case_0.get_xml_element()
    print(xml)
    assert (ET.tostring(xml) != ET.tostring(test_case_1.get_xml_element()))

    test_case_0 = TestCase("name",is_disabled=True)

# Generated at 2022-06-25 12:49:07.548803
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='suite_name')
    suite.cases.append(TestCase(name='case_name'))

# Generated at 2022-06-25 12:49:12.163408
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    expected = '<testcase assertions="2" classname="foo" name="bar" status="passed" time="1.0"/>'
    assert _pretty_xml(TestCase(name='bar', assertions=2, classname='foo', status='passed', time=decimal.Decimal('1.0')).get_xml_element().getroot()) == expected


# Generated at 2022-06-25 12:49:19.574414
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        name='test_name_0',
    )
    expected = """<testcase assertions="None" classname="None" name="test_name_0" status="None" time="None">
  <failure message="None" type="failure">None</failure>
  <error message="None" type="error">None</error>
</testcase>"""
    expected = expected.replace('\n', '').replace(' ', '')
    actual = test_case_0.get_xml_element()
    actual = ET.tostring(actual, encoding='unicode')
    actual = actual.replace('\n', '').replace(' ', '')
    assert expected == actual


# Generated at 2022-06-25 12:49:24.155307
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name = "TestSuite name",
        hostname = "TestSuite hostname",
        id = "TestSuite id",
        package = "TestSuite package",
        timestamp = datetime.datetime.now(),
        system_out = "TestSuite system_out",
        system_err = "TestSuite system_err",
    )
    print("Result: ", test_suite.get_xml_element())


# Generated at 2022-06-25 12:49:25.470398
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    assert str(TestSuite(name="name").get_xml_element()) == '<testsuite name="name" tests="0" time="0" />'


# Generated at 2022-06-25 12:49:27.496570
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = dataclasses.replace(TestSuite(), name="bob", timestamp=datetime.datetime.now())
    element = suite.get_xml_element()
    print(_pretty_xml(element))


# Generated at 2022-06-25 12:49:34.119674
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    tc_xml = '<testcase assertions="1" classname="test_case" name="test_case" time="0.01"><failure message="failure" type="failure">output</failure></testcase>'
    ts_xml = '<testsuite time="0.01" tests="1" name="test_suite"><testcase assertions="1" classname="test_case" name="test_case" time="0.01"><failure message="failure" type="failure">output</failure></testcase></testsuite>'
    ts_0 = TestSuite('test_suite')
    tc_0 = TestCase('test_case', classname='test_case', assertions=1, output='output', time=decimal.Decimal('0.01'))

# Generated at 2022-06-25 12:49:37.306227
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="test1", hostname="localhost", id="0", package="hello",
                           timestamp=datetime.datetime.now(), properties={"name": "value"}, cases=None,
                           system_out=None, system_err=None)
    result = test_suite.get_xml_element()
    assert result != None



# Generated at 2022-06-25 12:49:39.008999
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    assert TestSuite(name='my_suite').get_xml_element().tag == 'testsuite'

# Generated at 2022-06-25 12:49:47.150008
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite('TestSuite')
    suite.id = 202
    suite.name = 'TestSuiteName'
    suite.hostname = 'TestSuiteHostname'
    suite.package = 'TestSuitePackage'
    suite.timestamp = datetime.datetime.now()
    suite.properties = {'prop1': 'val1', 'prop2': 'val2'}