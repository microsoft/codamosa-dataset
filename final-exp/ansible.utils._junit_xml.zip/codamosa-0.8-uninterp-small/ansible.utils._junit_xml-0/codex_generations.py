

# Generated at 2022-06-25 12:40:02.526136
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    result = """<?xml version="1.0" ?><testcases><testcase assertions="1" classname="foo" name="bar" status="passed" time="0.1"></testcase><testcases>"""
    test_0 = TestCase(name="bar", assertions=1, classname="foo", status="passed", time=decimal.Decimal(0.1))
    test_suite = TestSuite(name="foo", cases=[test_0])
    output = _pretty_xml(test_suite.get_xml_element())
    assert output == result


# Generated at 2022-06-25 12:40:14.048425
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='TestSuite0')
    test_case_0 = TestCase(name='TestCase0')
    test_suite_0.cases.append(test_case_0)
    element = test_suite_0.get_xml_element()
    #Empty XML document
    expected_result = '''<?xml version="1.0" ?>
<testsuite disabled="0" errors="0" failures="0" hostname="None" id="None" name="TestSuite0" package="None" skipped="0" tests="1" time="0">
</testsuite>
'''
    #[Returns] <class 'xml.etree.ElementTree.Element'>
    assert str(ET.tostring(element,encoding='unicode')) == expected_result



# Generated at 2022-06-25 12:40:18.147819
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    expected_output_0 = '<results></results>'
    output_0 = test_result_0.get_xml_element()
    if output_0 != expected_output_0:
        raise Exception("Test case 0 failed")


# Generated at 2022-06-25 12:40:20.569237
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    expected = """<testresult output="None" type="testresult" message="None"></testresult>"""
    assert expected == _pretty_xml(TestResult().get_xml_element())


# Generated at 2022-06-25 12:40:23.680130
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    assert test_result_0.get_xml_element() == ET.Element('testresult')


# Generated at 2022-06-25 12:40:31.391450
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase("name_0")
    element = test_case_0.get_xml_element()
    expected_element = ET.fromstring('<testcase name="name_0"><system-out></system-out><system-err></system-err></testcase>')
    assert element == expected_element

    test_case_1 = TestCase("name_1", classname="classname_1", time=0, assertions=1, status="status_1")
    element = test_case_1.get_xml_element()
    expected_element = ET.fromstring('<testcase assertions="1" classname="classname_1" name="name_1" status="status_1" time="0"><system-out></system-out><system-err></system-err></testcase>')
    assert element == expected

# Generated at 2022-06-25 12:40:33.281015
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase()
    assert test_case_0.get_xml_element() == None


# Generated at 2022-06-25 12:40:35.688876
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test = ET.Element('test')
    test.extend([test_result_0.get_xml_element()])
    assert(test.text is None)
    assert(test.attrib == {})



# Generated at 2022-06-25 12:40:38.099486
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    assert test_result_0.get_attributes() == {}


# Generated at 2022-06-25 12:40:46.685679
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_1 = TestCase(name='test_case_0')
    test_suite_0 = TestSuite(name='test_suite_0', hostname='localhost', id='test_suite_0', package='io.github.stewilondanga.junit_xml_dataclass', timestamp=datetime.datetime.now())

# Generated at 2022-06-25 12:41:01.328284
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()
    test_result_0.message = "TestError -b- <span>Test Error</span>"
    test_result_0.output = "TestError -b- <span>Test Error</span>"
    test_result_0.type = "TestError -b-"

    test_result_1 = TestError()
    test_result_1.message = "TestError -b- <span>Test Error</span>"
    test_result_1.output = "TestError -b- <span>Test Error</span>"
    test_result_1.type = "TestError -b-"

    test_result_2 = TestFailure()
    test_result_2.message = "TestFailure -b- <span>Test Failure</span>"

# Generated at 2022-06-25 12:41:04.624655
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    test_result_0_dict = {}
    assert test_result_0.get_attributes() == test_result_0_dict


# Generated at 2022-06-25 12:41:14.026407
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    sample_test_case_1 = TestCase(
        assertions=0,
        classname="",
        errors=None,
        failures=None,
        name="Test name",
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=0.0
    )
    expected_xml_str = r"""
<testcase assertions="0" classname="" name="Test name" time="0.0">
</testcase>
""".strip()
    assert _pretty_xml(sample_test_case_1.get_xml_element()) == expected_xml_str


# Generated at 2022-06-25 12:41:18.610804
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult(message='message_0', type='type_0', output='output_0')
    # Test the attributes of the method get_attributes of class TestResult
    assert _attributes(message='message_0', type='type_0') == test_result_0.get_attributes()


# Generated at 2022-06-25 12:41:21.952410
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    expected_0 = {}
    actual_0 = test_result_0.get_attributes()
    assert actual_0 == expected_0


# Generated at 2022-06-25 12:41:26.224191
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='123')

    xml_element_0 = test_case_0.get_xml_element()

    pretty_xml_0 = _pretty_xml(xml_element_0)

    assert pretty_xml_0 == "<testcase name=\"123\" />"


# Generated at 2022-06-25 12:41:28.844483
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_1 = TestResult()

    xml_element = test_result_1.get_xml_element()
    assert xml_element._attrib == {'type': 'test-result'}
    assert xml_element._children == []
    assert xml_element._parent is None


# Generated at 2022-06-25 12:41:29.340553
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    pass


# Generated at 2022-06-25 12:41:34.107210
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
  test_case_0 = TestCase(
    assertions = None,
    classname = None,
    errors = None,
    failures = None,
    name = "0.0.0.0",
    skipped = None,
    status = None,
    system_err = None,
    system_out = None,
    time = None,
  )
  assert _pretty_xml(test_case_0.get_xml_element()) == '<?xml version="1.0" ?>\n<testcase name="0.0.0.0" />\n'


# Generated at 2022-06-25 12:41:38.432831
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name="")
    expected = '<testcase assertions="0" classname="" name="" status="0" time="0.0" />'
    result = test_case_0.get_xml_element()
    assert expected == result


# Generated at 2022-06-25 12:41:52.979407
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suites = TestSuites('test_suites_0')
    test_suites.errors = 5
    test_suites.disabled = 2
    test_suites.failures = 3
    test_suites.tests = 8
    test_suites.time = decimal.Decimal(24.0)
    test_suite = TestSuite('test_suite_0')
    test_suite.errors = 1
    test_suite.disabled = 0
    test_suite.failures = 2
    test_suite.tests = 3
    test_suite.time = decimal.Decimal(8.0)
    test_suites.suites.append(test_suite)
    test_suite = TestSuite('test_suite_1')
    test_suite.errors = 4


# Generated at 2022-06-25 12:41:53.932774
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert _attributes(message=None, type=None) == {}


# Generated at 2022-06-25 12:41:57.078712
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    string_0 = 'Unit test.'
    test_case_0 = TestCase(string_0, assertions=None, classname=None, status=None, time=None)
    test_suite_0 = TestSuite(string_0, hostname='hostname', id='id1', package='package', timestamp=datetime.datetime.now())
    test_suite_0.cases.append(test_case_0)
    element_0 = test_suite_0.get_xml_element()



# Generated at 2022-06-25 12:42:00.083030
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    str_0 = '123'
    str_1 = 'ABC'
    str_2 = 'def'
    test_result_0 = TestFailure(str_1, str_0, str_2)
    dict_0 = test_result_0.get_attributes()
    assert dict_0['type'] == str_2
    assert dict_0['message'] == str_1


# Generated at 2022-06-25 12:42:05.491835
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    str_0 = '123'
    test_suite_0 = TestSuite(str_0)
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:42:09.785064
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestError(None)
    test_result_0.type = 'test_type'
    test_result_0.output = 'test_output'
    element_0 = test_result_0.get_xml_element()
    assert 'output' == element_0.tag


# Generated at 2022-06-25 12:42:13.137772
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    str_0 = '123'
    test_result_0 = TestResult(str_0)
    element_0 = test_result_0.get_xml_element()
    

# Generated at 2022-06-25 12:42:15.714689
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    str_0 = '123'
    test_result_0 = TestResult(str_0)
    assert isinstance(test_result_0.get_xml_element(), ET.Element)


# Generated at 2022-06-25 12:42:18.482104
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    str_0 = '123'
    TestResult_test_0 = TestResult(
        output = str_0,
    )
    attrs_0 = TestResult_test_0.get_attributes()


# Generated at 2022-06-25 12:42:20.795106
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    str_1 = None
    str_0 = '123'
    test_result_0 = TestResult(str_0, str_1, str_0)
    dict_0 = test_result_0.get_attributes()


# Generated at 2022-06-25 12:42:27.124031
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_suite_0 = TestSuite(var_0)
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:42:31.044964
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    # Arrange
    test_case = TestCase('test_case')

    # Act
    element = test_case.get_xml_element()

    # Assert
    assert element.tag == 'testcase'
    assert element.attrib == {'name':'test_case'}
    assert element.text == None


# Generated at 2022-06-25 12:42:33.144973
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('abc')

    assert test_case_0.get_xml_element().find('testcase').attrib.get('name') == 'abc'



# Generated at 2022-06-25 12:42:41.009035
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    var_1 = None
    test_case_0 = TestCase(var_0, assertions=var_1)
    var_2 = None
    test_suite_0 = TestSuite(var_0, hostname=var_1, id=var_2, package=var_1, timestamp=var_1)
    test_suite_0.cases.append(test_case_0)
    test_suite_0.system_err = var_0
    test_suite_0.system_out = var_0
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:42:49.729901
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_42 = None
    var_43 = None
    var_44 = None
    var_45 = str()
    var_46 = decimal.Decimal()
    var_47 = datetime.datetime()
    test_case_0 = TestCase(var_42,var_43,var_44,var_45,var_46,var_47)
    var_48 = None
    var_49 = None
    var_50 = None
    var_51 = None
    var_52 = None
    test_suite_0 = TestSuite(var_48,var_49,var_50,var_51,var_52)
    test_suite_0.cases.append(test_case_0)
    var_53 = None
    test_suite_0.properties["key"] = var_53
   

# Generated at 2022-06-25 12:42:52.788874
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    test_case_0 = TestCase(var_0)
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:43:02.814869
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Setup
    test_case_0 = TestCase('name', None)
    test_case_0.errors.append(TestError('message', 'type'))
    test_case_0.failures.append(TestFailure('output', 'message', 'type'))
    test_case_0.system_err = 'system_err'
    test_case_0.system_out = 'system_out'
    # Test
    element_0 = test_case_0.get_xml_element()
    # Verify
    assert element_0.tag == 'testcase'
    assert element_0.attrib.get('assertions') == 'None'
    assert element_0.attrib.get('classname') == 'None'
    assert element_0.attrib.get('name') == 'name'
    assert element_0

# Generated at 2022-06-25 12:43:08.405156
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    var_1 = dict()
    var_2 = datetime.datetime.now()
    test_suite_0 = TestSuite(var_0, hostname=var_0, id=var_0, package=var_0, timestamp=var_2, properties=var_1, cases=var_1, system_out=var_0, system_err=var_0)
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:43:09.146264
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()

# Generated at 2022-06-25 12:43:11.111385
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # This method is defined so that it can be called, but currently there are no tests.
    pass


# Generated at 2022-06-25 12:43:16.450936
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = TestSuite('str_0')
    var_1 = var_0.get_xml_element()


# Generated at 2022-06-25 12:43:25.873841
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_18 = "kZpR"
    var_19 = "KzJH"
    var_20 = "r5r9"
    var_21 = None
    var_22 = "tjJH"
    var_23 = "jKAv"
    var_24 = ""
    var_25 = datetime.datetime(year=2000, month=1, day=1)
    var_26 = "jn1W"
    var_27 = "F6vj"
    var_28 = None
    var_29 = "qx7j"
    var_30 = "uVi4"
    var_31 = None
    var_32 = None
    var_33 = "EXlu"
    var_34 = None
    var_35 = None
    var_36 = "Vo1Z"

# Generated at 2022-06-25 12:43:35.610642
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_1 = None
    test_case_1 = TestCase(var_1)
    int_1 = 1
    test_case_2 = TestCase(var_1, int_1)
    test_case_3 = TestCase(var_1, int_1, var_1)
    test_case_4 = TestCase(var_1, int_1, var_1, var_1)
    test_case_5 = TestCase(var_1, int_1, var_1, var_1, var_1)
    list_1 = [test_case_1, test_case_2, test_case_3, test_case_4, test_case_5]
    string_1 = 'This is a test'

# Generated at 2022-06-25 12:43:38.280536
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = TestCase(1, None, None, None, None)
    elements_0 = var_0.get_xml_element()


# Generated at 2022-06-25 12:43:43.945832
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="name")

    # mocking
    class MockTestCase:
        def get_xml_element(self):
            return
    mock_test_case_0 = MockTestCase()
    test_suite_0.cases = [mock_test_case_0]

    element = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:43:53.064900
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_3 = None
    var_4 = None
    case_0 = TestCase(var_3, var_4)
    var_0 = None
    var_1 = None
    error_0 = TestError(var_0, var_1)
    var_2 = None
    error_1 = TestError(var_2)
    case_0.errors.append(error_0)
    case_0.errors.append(error_1)
    var_5 = None
    var_6 = None
    failure_0 = TestFailure(var_5, var_6)
    case_0.failures.append(failure_0)
    element_0 = case_0.get_xml_element()


# Generated at 2022-06-25 12:43:55.909324
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Test the function `get_xml_element`."""
    var_0 = None
    test_case_0 = TestCase(var_0)
    var_1 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:43:57.398625
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_suite_0 = TestSuite(var_0)
    element_0 = test_suite_0.get_xml_element()

# Generated at 2022-06-25 12:44:00.965934
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_suite_0 = TestSuite(var_0, id='', name='', timestamp=datetime.datetime(1, 1, 1, 0, 0, 7))
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:44:10.218928
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    root = ET.Element('testsuite', {'name': 'test'})
    var_0 = TestCase(name='test_test')
    var_0.is_disabled = True
    root.append(var_0.get_xml_element())
    var_1 = TestCase(name='test_test')
    var_1.is_disabled = True
    root.append(var_1.get_xml_element())
    var_2 = TestCase(name='test_test')
    var_2.errors.append(TestError('error'))
    root.append(var_2.get_xml_element())
    var_3 = TestCase(name='test_test')
    var_3.failures.append(TestFailure('failure'))
    root.append(var_3.get_xml_element())

# Generated at 2022-06-25 12:44:21.448796
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    test_case_0 = TestCase(var_0, var_1, var_2, var_3)
    var_4 = None
    var_5 = None
    var_6 = None
    test_error_0 = TestError(var_4, var_5, var_6)
    test_case_0.errors.append(test_error_0)
    var_7 = None
    var_8 = None
    var_9 = None
    test_failure_0 = TestFailure(var_7, var_8, var_9)
    test_case_0.failures.append(test_failure_0)
    var_10 = None

# Generated at 2022-06-25 12:44:28.846343
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # Create a test suite
    test_suite = TestSuite(name = "name", status = "status", timestamp = datetime(2019, 1, 1), disabled = 0, errors = 0, failures = 0, hostname = "hostname", id = "id", package = "package", skipped = 0, tests = 0, time = 0)

    # Create test case 1
    test_case_1 = TestCase(assertions = 0, classname = "classname", is_disabled = False, is_error = False, is_failure = False, is_skipped = False, name = "name", status = "status", time = 0)

    # Add test case 1 to the test suite
    test_suite.cases.append(test_case_1)

    # Create test case 2

# Generated at 2022-06-25 12:44:36.744928
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    instance = TestSuite(
        cases=None,
        disabled=None,
        errors=None,
        failures=None,
        hostname=None,
        id=None,
        name=None,
        package=None,
        skipped=None,
        system_err=None,
        system_out=None,
        tests=None,
        time=None,
        timestamp=None,
    )
    element = instance.get_xml_element()
    assert element is not None
    for suite in instance.suites:
        if suite.is_disabled:
            element.append(ET.Element(
                'disabled',
                dict(
                    count=str(suite.disabled),
                ),
            ))


# Generated at 2022-06-25 12:44:42.482746
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_case_0 = TestCase(var_0)
    cases_0 = [test_case_0]
    var_1 = datetime.datetime.now()
    test_suite_0 = TestSuite(var_0, var_0, var_0, var_0, cases_0, var_0, var_1)
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:44:51.938882
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    test_error_0 = TestError(var_0)
    element_0 = test_error_0.get_xml_element()
    assert None is not element_0.get('message')
    if not assertNone(element_0.get('type')):
        return
    element_1 = test_error_0.get_xml_element()
    assert None is not element_1.get('message')
    if not assertNone(element_1.get('type')):
        return
    test_error_1 = TestError(var_0)
    element_0 = test_error_1.get_xml_element()
    assert None is not element_0.get('message')
    if not assertNone(element_0.get('type')):
        return
    element_1 = test_error_

# Generated at 2022-06-25 12:44:57.358105
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    test_case_0 = TestCase(var_0)
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    test_case_0.__init__(var_1, var_2, var_3, var_4)
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:45:01.698590
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name = "moo", assertions = None, classname = "moo", status = None, time = None, skipped = None, errors = [], failures = [], system_out = None, system_err = None, is_disabled = False)
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:45:04.083664
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = TestSuite(name = 'test')
    var_1 = var_0.get_xml_element()


# Generated at 2022-06-25 12:45:07.638879
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_1 = None
    test_failure_0 = TestFailure(var_1)
    var_2 = None
    test_case_0 = TestCase(var_2, [test_failure_0])
    element_1 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:45:15.064840
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    prop_0 = {'a': '1', 'b': '2'}
    var_0 = TestSuite('name_0', timestamp=datetime.datetime.fromisoformat('2020-07-08T21:30:00'), properties=prop_0)
    var_1 = ElementTree.parse(var_0.get_xml_element()).getroot()
    prop_1 = var_1.find('properties')
    assert prop_1.find('property', {'name': 'a'}).get('value') == '1'
    assert prop_1.find('property', {'name': 'b'}).get('value') == '2'
    assert var_1.find('testsuite').find('timestamp').text == '2020-07-08T21:30:00'
    assert var_1.get

# Generated at 2022-06-25 12:45:19.106088
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    pass



# Generated at 2022-06-25 12:45:20.600554
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Test get_xml_element of the TestCase class"""
    var_0 = TestCase('scalars.TestCase')
    element_0 = var_0.get_xml_element()


# Generated at 2022-06-25 12:45:27.075197
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    #
    # Unit test for get_xml_element of class TestSuite
    #
    # Test case for get_xml_element of TestSuite
    #
    # Test case for get_xml_element of TestSuite
    testcase_0 = TestCase(None)
    testsuite_0 = TestSuite(None)
    testsuite_0.timestamp = None
    testsuite_0.properties = {}
    testsuite_0.cases = [testcase_0]
    testsuite_0.system_out = None
    testsuite_0.system_err = None
    element_0 = testsuite_0.get_xml_element()


# Generated at 2022-06-25 12:45:37.153948
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    cases_0 = []
    hostname_0 = None
    id_0 = None
    package_0 = None
    name_0 = 'gQ_'
    timestamp_0 = None
    testsuite_0 = TestSuite(cases_0, hostname_0, id_0, package_0, name_0, timestamp_0)
    var_0 = testsuite_0.get_xml_element()
    assert var_0.tag == 'testsuite'
    assert var_0.get('disabled') == '0'
    assert var_0.get('errors') == '0'
    assert var_0.get('failures') == '0'
    assert var_0.get('name') == 'gQ_'
    assert var_0.get('tests') == '0'
    assert var_0

# Generated at 2022-06-25 12:45:42.667595
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = TestError()
    var_1 = TestSuite()
    test_case_0 = TestCase(
        assertions=5,
        classname='BLUEJAY',
        errors=[var_0],
        failures=[TestFailure()],
        name='Test of the TestCase class',
        skipped='Not yet implemented',
        status='PASS',
        system_err='Here are the most common causes',
        system_out='Test passed!',
        time=10.5,
    )
    element_0 = test_case_0.get_xml_element()
    var_2 = var_1.get_xml_element()


# Generated at 2022-06-25 12:45:53.073677
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    '''
    <testcase name="test_case_0" time="0.001" assertions="0" />
    '''
    var_0 = 'test_case_0'
    var_1 = decimal.Decimal('0.001')
    var_2 = 0
    test_case_0 = TestCase(name=var_0, time=var_1, assertions=var_2)
    element = test_case_0.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'assertions': str(var_2), 'name': var_0, 'time': str(var_1)}
    assert element.text is None
    assert len(element) == 0



# Generated at 2022-06-25 12:46:00.309043
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = TestSuites('a')
    var_1 = TestSuite('a', 'b', 'c', 'd', datetime.datetime.strptime('2018-08-27T00:00:00', '%Y-%m-%dT%H:%M:%S'))
    var_1.system_err = 'aa'
    var_1.system_out = 'a'
    var_0.suites.append(var_1)
    element_0 = var_0.get_xml_element()
    element_1 = var_0.get_xml_element()
    assert element_1.tag == 'testsuites'


# Generated at 2022-06-25 12:46:03.552308
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = TestCase(name='var_0')
    element_0 = var_0.get_xml_element()
    assert isinstance(element_0, ET.Element)
    assert element_0.attrib == {'name': 'var_0'}


# Generated at 2022-06-25 12:46:06.114432
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_suite_0 = TestSuite(var_0)
    var_1 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:46:09.812304
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_1 = None
    test_case_0 = TestCase(var_1)
    var_0 = None
    test_case_0.name = var_0
    var_2 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:46:16.875152
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Test case
    test_case_0 = TestCase(name='1')

    assert ET.tostring(test_case_0.get_xml_element(), encoding='unicode') == '<testcase name="1" />'


# Generated at 2022-06-25 12:46:21.581021
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    output = StringIO()
    suite_0 = TestSuite("test_name", "test_hostname", "test_id", "test_package", "test_timestamp", "test_properties", "test_cases")
    var_0 = None
    test_case_0 = TestCase(suite_0, var_0)
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:46:23.957551
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_suite_0 = TestSuite(var_0)
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:46:25.224675
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    instance_0 = TestCase()
    element_0 = instance_0.get_xml_element()


# Generated at 2022-06-25 12:46:31.474201
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    hostname = 'hostname'
    id = 'id'
    name = 'name'
    package = 'package'
    timestamp = datetime.datetime.now()
    properties = dict(key='value')
    cases = list()
    system_out = 'system_out'
    system_err = 'system_err'
    var_0 = TestSuite(name, hostname, id, package, timestamp, properties, cases, system_out, system_err)
    element_0 = var_0.get_xml_element()


# Generated at 2022-06-25 12:46:34.593354
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    interface_0 = TestSuite(var_0, var_0, var_0, var_0)
    element_0 = interface_0.get_xml_element()
    print("%s: %s" % (element_0, element_0.text))


# Generated at 2022-06-25 12:46:41.013005
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_1 = None
    test_error_1 = TestError(var_1)
    var_2 = None
    test_case_0 = TestCase(var_2, var_1, errors=[test_error_1])
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    test_case_1 = TestCase(var_6, var_5, var_4, var_3, [test_error_1])

    assert (test_case_0.get_xml_element() == test_case_1.get_xml_element())


# Generated at 2022-06-25 12:46:45.097030
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """
    TestCase.get_xml_element() -> ET.Element
    """
    # TestCase.get_xml_element() should return an ET.Element
    # TestCase.get_xml_element() should return an ET.Element containing a testcase element
    # TestCase.get_xml_element() should return an ET.Element containing a testcase element with the correct attributes
    test_case_0 = TestCase(name='name_0')
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:46:54.014832
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(assertions=None, classname=None, errors=[], failures=[], name='', skipped=None, status=None, system_err=None, system_out=None, time=None)
    str_0: str = test_case_0.get_xml_element().tag
    str_1 = 'testcase'
    assert str_0 == str_1


# Generated at 2022-06-25 12:46:57.017465
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_suite_0 = TestSuite(var_0)
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:47:02.753208
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    test_case_0 = TestCase(var_0)
    assert test_case_0.get_xml_element() is not None



# Generated at 2022-06-25 12:47:13.457754
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test 1: Create test case and verify
    test_case_1 = TestCase(name='Test case 1', assertions='1')
    test_case_1_element = test_case_1.get_xml_element()

    assert test_case_1_element.tag == 'testcase'
    assert test_case_1_element.attrib['name'] == 'Test case 1'
    assert test_case_1_element.attrib['assertions'] == '1'

    # Test 2: Create test suite, add test case, verify
    test_suite_2 = TestSuite(name='Test suite 2')
    test_suite_2.cases.append(test_case_1)
    test_suite_2_element = test_suite_2.get_xml_element()

    assert test_suite_2

# Generated at 2022-06-25 12:47:19.510550
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=None,
        classname=None,
        errors=[],
        failures=[],
        is_disabled=False,
        name='test_case_0',
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None,
    )
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:47:29.037739
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = 'name'
    var_1 = None
    var_2 = 'hostname'
    var_3 = 'id'
    var_4 = 'package'
    var_5 = datetime.datetime(1970, 1, 1, 0, 0)
    var_6 = dict()
    var_7 = (TestCase(name=var_0),)
    var_8 = None
    var_9 = None
    test_suite_0 = TestSuite(var_0, hostname=var_1, id=var_1, package=var_1, timestamp=var_1, properties=var_1, cases=var_1, system_out=var_1, system_err=var_1)


# Generated at 2022-06-25 12:47:31.714719
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_suite_0 = TestSuite(var_0)
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:47:41.109459
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None

    test_error_0 = TestError(var_0)
    var_1 = None
    test_failure_0 = TestFailure(var_1)

    test_case_0 = TestCase(var_0, 0, var_0, var_1, 0, [test_error_0], [test_failure_0], var_0, var_0, var_0, False)

    var_2 = None
    var_3 = None
    test_suite_0 = TestSuite(var_0, var_2, var_3, var_3, var_3, [], [test_case_0], var_0, var_0)

    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:47:43.967601
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    test_case_0 = TestCase(var_0)
    var_1 = test_case_0.get_xml_element()
    assert(var_1 is not None)


# Generated at 2022-06-25 12:47:51.806725
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        assertions=123,
        classname='classname',
        errors=[
            TestError(
                message='message',
                output='output',
                type='type',
            ),
        ],
        failures=[
            TestFailure(
                message='message',
                output='output',
                type='type',
            ),
        ],
        name='name',
        skipped='skipped',
        status='status',
        time=decimal.Decimal('123'),
    )

# Generated at 2022-06-25 12:47:59.692645
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    import xml.etree.ElementTree as ET
    var_0 = 'var_0'
    var_1 = 'var_1'
    var_2 = 'var_2'
    var_3 = 'var_3'
    var_4 = 'var_4'
    var_5 = 'var_5'
    var_6 = 'var_6'
    var_7 = 'var_7'
    var_8 = 'var_8'
    var_9 = 'var_9'
    var_10 = 'var_10'
    var_11 = 'var_11'
    var_12 = 'var_12'
    var_13 = 'var_13'
    var_14 = 'var_14'
    var_15 = decimal.Decimal(1234)
    var_16 = decimal.Dec

# Generated at 2022-06-25 12:48:02.517217
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = TestSuite('var_0')
    test_case_0 = TestCase('test_case_0')
    var_0.cases.append(test_case_0)
    element_0 = var_0.get_xml_element()


# Generated at 2022-06-25 12:48:08.646752
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test')
    element = suite.get_xml_element()
    assert element.tag == 'testsuite'
    print(ET.tostring(element))



# Generated at 2022-06-25 12:48:11.417352
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    test_case_0 = TestCase(var_0, var_1, var_2, var_3, var_4)
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:48:21.835358
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    name_0 = 'name'
    status_0 = 'status'
    assertions_0 = 2
    classname_0 = 'classname'
    parent_0 = TestCase(name_0, assertions_0, classname_0, status_0)

    system_out_0 = 'system_out'
    system_err_0 = 'system_err'

    output_0 = 'error_output'
    message_0 = 'error_message'
    tag_0 = 'error'

    error_0 = TestError(output_0, message_0, tag_0)
    error_1 = TestError()
    error_2 = TestError()
    error_3 = TestError()
    error_4 = TestError()


# Generated at 2022-06-25 12:48:24.919228
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Initialize the data
    var_0 = None
    test_suite_0 = TestSuite(var_0)

    # Call the function under test
    element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:48:27.719404
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_1 = None
    test_case_0 = TestCase(var_1)

    element_1 = test_case_0.get_xml_element()
    assert element_1.attrib == {"name": var_1}


# Generated at 2022-06-25 12:48:30.546199
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test')
    
    assert _pretty_xml(test_case_0.get_xml_element()) == """<testcase assertions="" classname="" name="test" status="" time=""/>"""


# Generated at 2022-06-25 12:48:32.455954
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case_0 = TestCase(name='name')
    element_0 = case_0.get_xml_element()


# Generated at 2022-06-25 12:48:35.428006
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Test TestCase.get_xml_element method"""
    var_0 = TestCase(name="Test case")
    element_0 = var_0.get_xml_element()


# Generated at 2022-06-25 12:48:43.718930
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Test case data
    name_0 = 'Test'
    assertions_0 = None
    classname_0 = 'a'
    status_0 = None
    time_0 = decimal.Decimal(0)
    errors_0 = []
    failures_0 = []
    skipped_0 = None
    system_out_0 = 'Test'
    system_err_0 = 'Test'
    is_disabled_0 = True
    test_case_0 = TestCase(name_0, assertions_0, classname_0, status_0, time_0, errors_0, failures_0, skipped_0, system_out_0, system_err_0, is_disabled_0)

    # Invoke method
    result_0 = test_case_0.get_xml_element()

    # Check for expected result
    expected

# Generated at 2022-06-25 12:48:47.257398
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_1 = TestSuite(name='test_name_0',hostname='hostname_0',id='test_id_0',package='test_package_0',timestamp=TestSuite(),properties={'test_key0':'test_value0',},cases=[],system_out='test_system_out_0',system_err='test_system_err_0',)
    var_1.get_xml_element()


# Generated at 2022-06-25 12:48:50.348235
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    assert True


# Generated at 2022-06-25 12:48:51.851122
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_1 = TestSuite(var_0, var_0)
    element_2 = var_1.get_xml_element()

# Generated at 2022-06-25 12:48:56.379891
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        'name-0',
        assertions=1,
        classname='classname-0',
        errors=[],
        failures=[],
        is_disabled=False,
        skipped='skipped-0',
        status='status-0',
        system_err='system_err-0',
        system_out='system_out-0',
        time=1,
    )
    element_0 = test_case_0.get_xml_element()

# Generated at 2022-06-25 12:49:03.088139
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    test_error_0 = TestError()
    test_case_0 = TestCase('', var_0, var_1, var_2, var_3, [test_error_0], [], var_4, var_5, var_6, var_7)
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:49:05.261296
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    test_case_0 = TestCase(var_0)
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:49:09.187626
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    test_error_0 = TestError(var_0)
    var_1 = None
    var_2 = None
    test_case_0 = TestCase(var_1, var_2, var_0)
    element_0 = test_case_0.get_xml_element()



# Generated at 2022-06-25 12:49:12.375943
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_suite_0 = TestSuite(var_0, var_0, var_0, var_0, var_0)
    element_0 = test_suite_0.get_xml_element()

# Generated at 2022-06-25 12:49:20.320619
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # assertEqual(self, first, second, msg=None)
    # self.assertEqual(1, 1, msg='Not equal')
    # test_case_0 = TestCase('name_0', assertions=None, classname=None, status=None, time=None, errors=None, failures=None, skipped=None, system_out=None, system_err=None, is_disabled=None)
    test_case_0 = TestCase('name_0')

    # var_0 = None
    # test_error_0 = TestError(var_0)
    # assertEqual(self, first, second, msg=None)
    # self.assertEqual(1, 1, msg='Not equal')
    # element_0 = test_error_0.get_xml_element()
    element_0 = test_case

# Generated at 2022-06-25 12:49:24.595253
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = None
    test_case_0 = TestCase(var_0, None, None, None, None)
    test_case_0.errors.append(TestError(None))
    test_case_0.failures.append(TestFailure(None))
    test_case_0.skipped = None
    test_case_0.system_out = None
    test_case_0.system_err = None
    element_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:49:26.266909
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    var_0 = {'output': '', 'message': '', 'type': ''}
    TestCase_0 = TestCase(**var_0)
    TestCase_1 = TestCase_0.get_xml_element()


# Generated at 2022-06-25 12:49:31.333082
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    name_0 = 'rEkTjOhSm'
    var_0 = name_0
    var_1 = TestSuite(var_0)
    var_2 = var_1.get_xml_element()


# Generated at 2022-06-25 12:49:33.429128
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_suite_0 = TestSuite(var_0)
    var_1 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:49:36.570045
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    var_0 = None
    test_case_0 = TestCase(var_0)
    test_suite_0 = TestSuite('', cases=[test_case_0])
    element_0 = test_suite_0.get_xml_element()

    assert hasattr(element_0, 'text')
    assert hasattr(element_0, 'tag')


# Generated at 2022-06-25 12:49:41.694999
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create test objects
    var_0 = None
    test_case_0 = TestCase(var_0)
    var_1 = None
    test_case_1 = TestCase(var_1)
    cases = [test_case_0, test_case_1]
    var_2 = None
    test_suite_0 = TestSuite(var_2, cases=cases)
    # Run method
    element = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:49:45.134300
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite_0 = TestSuite('name_0')
    testsuite_0.cases.append(TestCase('name_1'))
    res_0 = testsuite_0.get_xml_element()
