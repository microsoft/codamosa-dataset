

# Generated at 2022-06-25 12:40:03.411195
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('bX9/Rg\x02\x16O\x0c')
    test_case_0 = TestCase('c(\x01\x14\x1c\'')


# Generated at 2022-06-25 12:40:14.893445
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    qualified_name_0 = '".G\x0b'
    test_case_1 = TestCase(qualified_name_0)
    test_case_1.type = 'L>`\x0b'
    test_case_1.message = '\x0e\x0c\n\t/\x0b'
    test_case_1.status = '\x0e\x0c\n\t/\x0b'
    test_case_1.output = '\x0e\x0c\n\t/\x0b'
    time_0 = decimal.Decimal('0.3367')
    test_case_1.time = time_0
    list_0 = [test_case_1]

# Generated at 2022-06-25 12:40:24.746571
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = 'akkL5\x0bP'
    test_error_0 = TestError(str_0)
    test_case_0 = TestCase('test_case_0')
    test_case_0.errors.append(test_error_0)
    test_case_element = test_case_0.get_xml_element()

    if test_case_element.tag == 'testcase':
        if len(test_case_element) == 1:
            child_element = test_case_element[0]
            if child_element.tag == 'error':
                if child_element.text == str_0:
                    return True

    return False


# Generated at 2022-06-25 12:40:34.040242
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = '\x14\x04\x1e\n'
    test_failure_0 = TestFailure(str_0)
    int_0 = -12
    test_case_0 = TestCase('\x1a&%', int_0, '\x10\x0cT\x0e', '\x0e\t\x16\x1c', '\x02\x03\x18\x07\x00\x14\x18')
    test_case_0.failures.append(test_failure_0)
    str_1 = 'testsuites'

# Generated at 2022-06-25 12:40:38.439851
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite('suite')
    test_case = TestCase('case')
    test_error = TestError('error')
    test_case.errors.append(test_error)
    test_suite.cases.append(test_case)
    xml = test_suite.get_xml_element().to_string()
    expected_xml = """\
<testsuite tests="1" errors="1"><testcase name="case"><error>error</error></testcase></testsuite>"""
    assert xml == expected_xml



# Generated at 2022-06-25 12:40:41.850063
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('test_name_0')
    assert test_case_0.get_xml_element().items() == [('assertions', None), ('classname', None), ('name', 'test_name_0'), ('status', None), ('time', None)]

# Generated at 2022-06-25 12:40:47.237816
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='c', time=decimal.Decimal('3.3'), assertions=3, classname='b', status='a')
    test_error_0 = TestError()
    test_case_0.errors = [test_error_0]
    test_failure_0 = TestFailure()
    test_case_0.failures = [test_failure_0]
    test_case_0.skipped = 'i'
    test_case_0.system_out = 'g'
    test_case_0.system_err = 'h'
    test_case_0.is_disabled = True

    actual = test_case_0.get_xml_element()

# Generated at 2022-06-25 12:40:59.293561
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('akkL5\x0bP')
    str_0 = 'akkL5\x0bP'
    test_error_0 = TestError(str_0)
    test_case_0 = TestCase('akkL5\x0bP')
    test_case_0.errors.append(test_error_0)
    test_suite_0.cases.append(test_case_0)
    str_1 = 'akkL5\x0bP'
    test_error_1 = TestError(str_1)
    test_case_1 = TestCase('akkL5\x0bP')
    test_case_1.errors.append(test_error_1)

# Generated at 2022-06-25 12:41:01.548957
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """
    Verify that when method get_xml_element of class TestSuite is called
    then output is returned.
    """

    test_suite = TestSuite(name='Sample test suite')
    assert test_suite.get_xml_element() is not None



# Generated at 2022-06-25 12:41:13.386025
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_suite_0 = TestSuite('qw')

# Generated at 2022-06-25 12:41:24.905485
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0_obj = test_case_0()
    test_case_0_obj_get_xml_element_retval = test_case_0_obj.get_xml_element()
    print('test_case_0:', test_case_0_obj_get_xml_element_retval)



# Generated at 2022-06-25 12:41:32.049797
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    assert TestCase('', '').get_xml_element().tag == "testcase"
    assert TestCase(classname='', name='').get_xml_element().attrib["classname"] == ''
    assert TestCase(classname='', name='').get_xml_element().attrib["name"] == ''
    str_0 = 'x\x00\x0c\x00\x0c\x00\x00\x00\x0c\x00\x0c\x00\x0c\x00\x00\x00\x0c\x00'
    assert TestCase(classname='', name='').get_xml_element().text == str_0


# Generated at 2022-06-25 12:41:43.143156
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('Jai', 'sejrJu', 'id')
    str_0 = '\x07\x0f\x0f\x1b\x1c\x0f\x06+&\x07\x1d\x1e'
    test_suite_0.system_err = str_0
    test_suite_0._TestSuite__name = '<?xml version="1.0" ?>'

# Generated at 2022-06-25 12:41:44.026706
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()


# Generated at 2022-06-25 12:41:50.336934
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    _case_suite = TestSuite(name='All cases')
    _case_suite.cases.append(TestCase(name='Case 1'))
    xml = _case_suite.get_xml_element()
    assert xml.tag == 'testsuite'
    assert xml.attrib["name"] == 'All cases'
    assert xml[0].tag == 'testcase'


# Generated at 2022-06-25 12:41:58.400580
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = 'akkL5\x0bP'
    test_case_0 = TestCase(str_0)
    test_case_0.message = str_0
    test_case_0.classname = str_0
    test_case_0.output = str_0
    test_case_0.type = str_0
    test_error_0 = TestError(str_0)
    test_case_0.errors.append(test_error_0)
    test_failure_0 = TestFailure(str_0)
    test_case_0.failures.append(test_failure_0)
    test_case_0.skipped = str_0
    test_case_0.system_out = str_0
    test_case_0.system_err = str_0
   

# Generated at 2022-06-25 12:41:58.994097
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    assert 1 == 1


# Generated at 2022-06-25 12:42:10.862068
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = 'akkL5\x0bP'
    test_error_0 = TestError(str_0)

    str_0 = '8{ P'
    str_1 = ' e]A'
    str_2 = 'tj3|t'
    str_3 = 'aD\n!\x16k'
    str_4 = '\tY3|t'
    str_5 = '\rK\x13\x17\x1bI'
    str_6 = '\tC\x0e\x1f\x16k'
    str_7 = '\x1c\x1e\x0f\x1f\x1e\\\x1b'

# Generated at 2022-06-25 12:42:19.304735
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = '\x7f\x9f\x1d\x0b\x84p\x15\x9f\x90\xbd\x04\x9b\x0b\xf5'
    str_1 = '\x97\xe5\x96\xa5\xba\xdd\x02\x1f\x8a\x8f'
    test_case_0 = TestCase(str_0, assertions=1, classname=str_1, status='passed', time=1.0)
    test_case_0.skipped = 'skip'
    test_case_0.system_out = 'out'
    test_case_0.system_err = 'err'


# Generated at 2022-06-25 12:42:27.614192
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    print('TestCase.get_xml_element')
    test_case_0 = TestCase('testCase0')
    test_case_0.time = 9.0
    test_case_0.classname = 'MyTestCase'
    test_case_0.skipped = 'Skipped message'

    error_0 = TestError('Error0')
    error_0.type = 'TypeA'
    error_1 = TestError('Error1')
    error_1.type = 'TypeB'
    test_case_0.errors.append(error_0)
    test_case_0.errors.append(error_1)

    failure_0 = TestFailure('Failure0')
    failure_0.type = 'TypeA'
    failure_1 = TestFailure('Failure1')

# Generated at 2022-06-25 12:42:40.352751
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    str_0 = 'aaa'
    str_1 = 'bbb'
    str_2 = 'ccc'
    str_3 = 'ddd'
    str_4 = 'eee'
    str_5 = 'fff'
    str_6 = 'ggg'
    str_7 = 'hhh'
    str_8 = 'iii'
    str_9 = 'jjj'
    str_10 = 'kkk'
    str_11 = 'lll'
    str_12 = 'mmm'
    str_13 = 'nnn'
    str_14 = 'ooo'
    str_15 = 'ppp'
    str_16 = 'qqq'
    str_17 = 'rrr'
    str_18 = 'sss'
    str_19 = 'ttt'

# Generated at 2022-06-25 12:42:49.351843
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TestSuite_0 = TestSuite('sandy')
    TestSuite_0.get_xml_element()
    TestSuite_0.get_attributes()
    TestSuite_0.get_xml_element()
    TestSuite_0.get_attributes()
    TestSuite_0.get_xml_element()
    TestSuite_0.get_attributes()
    TestSuite_0.get_xml_element()
    TestSuite_0.get_attributes()
    TestSuite_0.get_xml_element()
    TestSuite_0.get_attributes()
    TestSuite_0.get_xml_element()
    TestSuite_0.get_attributes()
    TestSuite_0.get_xml_element()
    TestSuite_0.get

# Generated at 2022-06-25 12:42:56.643709
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    list_0 = []
    test_case_0 = TestCase('akkL5\x0bP', assertions=None, classname=None, status=None, time=None, errors=list_0, failures=list_0, skipped=None, system_out=None, system_err=None, is_disabled=False)
    assert test_case_0.get_xml_element().text == None, "Expected False, but got " + str(test_case_0.get_xml_element().text == None)



# Generated at 2022-06-25 12:43:04.996938
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TestSuite_0 = TestSuite("JUnitXmlReporter.constructor",
                            properties={'browsers': 'IE'},
                            timestamp=datetime.datetime(1970, 1, 1))
    TestSuite_1 = TestSuite("JUnitXmlReporter.constructor",
                            properties={'browsers': 'IE'},
                            timestamp=datetime.datetime(1970, 1, 1))
    TestSuite_0.cases.append(TestCase("2 should report a suite without a duration"))
    TestSuite_1.cases.append(copy.copy(TestSuite_0.cases[0]))



# Generated at 2022-06-25 12:43:12.423855
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    name_0 = '~3'
    str_0 = 'o'
    test_case_0 = TestCase(name_0, None, str_0, None, None, None)
    test_error_0 = TestError(str_0)
    test_failure_0 = TestFailure(str_0)
    bool_0 = bool(str_0)
    bool_1 = bool(str_0)
    bool_2 = bool(str_0)
    bool_3 = bool(str_0)
    test_case_0.is_disabled = bool_0
    test_case_0.is_error = bool_1
    test_case_0.is_failure = bool_2
    test_case_0.is_skipped = bool_3

# Generated at 2022-06-25 12:43:22.386795
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = '\x1d\x03\x1f\x0bJ\x0f\x11\x00M2\x15'
    int_0 = 433
    decimal_0 = decimal.Decimal('-0.32')
    TestError_0 = TestError()
    TestError_1 = TestError()
    list_0 = [TestError_0, TestError_1]
    str_1 = '\x03\x0b\x00P\x0f\x15\x1dJ\x1fM\x11'
    str_2 = '\x0bJ\x1fM\x11\x0f\x1d\x00P\x03\x15'

# Generated at 2022-06-25 12:43:27.361313
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='ueUSJ\x03Ol')
    test_suite_1 = TestSuite(name='5\x06\x05\x0f\x0b\x0bD')
    assert test_suite_0.get_xml_element() != test_suite_1.get_xml_element()


# Generated at 2022-06-25 12:43:28.360883
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()



# Generated at 2022-06-25 12:43:35.086929
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    _test_class2_0 = TestSuite('Gibed', timestamp=datetime.datetime(2009, 1, 2, 3, 4, 5))
    str_0 = 'Q@\x10\x18\x17\x08'
    _test_class2_0.system_err = str_0
    str_1 = '\x16G\x0b\x0c'
    _test_class2_0.system_out = str_1
    _test_class2_0.get_xml_element()


# Generated at 2022-06-25 12:43:45.271976
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('test_suite_0', 'test_hostname_0', 'test_id_0', 'test_package_0', datetime.datetime.now())
    test_case_0 = TestCase('test_case_0', 0, 'test_classname_0', 'test_status_0', 0.1)
    test_case_1 = TestCase('test_case_1', 0, 'test_classname_1', 'test_status_1', 0.1)
    test_case_2 = TestCase('test_case_2', 0, 'test_classname_2', 'test_status_2', 0.1)
    test_suite_0.cases = [test_case_0, test_case_1, test_case_2]


# Generated at 2022-06-25 12:43:58.475951
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='tTfy8R', id='gIo27k', package='KvlJVO', timestamp=datetime.datetime(2019, 3, 16, 4, 8, 15, 3130000))
    test_case_0 = TestCase(name='XG1Ihi', classname='4PfWxC', assertions=786341805, status='q1mKj1', time=decimal.Decimal('0.848778'))
    test_case_1 = TestCase(name='GsZmn9', classname='hKG3qL', assertions=632715700, status='nYn5rQ', time=decimal.Decimal('0.477877'))

# Generated at 2022-06-25 12:44:07.772006
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('test_name', 'test_hostname', 'test_id', 'test_package', 'test_timestamp')
    test_case_0 = TestCase('test_name', 'test_assertions', 'test_classname', 'test_status', 'test_time')

    test_suite_0.cases.append(test_case_0)


# Generated at 2022-06-25 12:44:17.377644
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = 'C\\\x15'
    str_1 = '\x1c'
    decimal_0 = decimal.Decimal('7.747383027199157E+22')
    str_2 = 'rU'
    str_3 = 'A\x02'
    num_0 = -7.6E+27
    str_4 = 'A\x02'
    decimal_1 = decimal.Decimal('3.3E+2')
    decimal_2 = decimal.Decimal('-3.3E+2')
    num_1 = 7.292464932735506E+17
    str_5 = '\x1c'

# Generated at 2022-06-25 12:44:19.008604
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    element_0 = TestSuite('Px'.lower())
    str_0 = element_0.get_xml_element()


# Generated at 2022-06-25 12:44:26.953359
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    int_0 = 0
    str_0 = 'a\x14\x17g'
    str_1 = '_\x1f\x0e'
    str_2 = '\x1a\x15\x0eD'
    decimal_0 = decimal.Decimal(0)
    test_result_0 = TestError('')
    test_case_0 = TestCase(str_1, int_0, str_0, str_2, decimal_0)
    test_case_0.errors.append(test_result_0)
    test_case_0.get_xml_element()


# Generated at 2022-06-25 12:44:35.652855
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite_0 = TestSuite('suite_0', 'hostname_0', 'id_0', 'package_0', datetime.datetime.utcnow())
    suite_0.properties = {'name_0': 'value_0', 'name_1': 'value_1'}

# Generated at 2022-06-25 12:44:45.771864
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    str_0 = '2Hl?S]WFA'
    test_suite_0 = TestSuite(str_0)
    test_suite_0.name = '/_$m,mT'
    str_1 = 'sn'
    test_suite_0.tests = str_1
    test_suite_0.system_err = 'uPq3\x7f$X'
    str_2 = 'x'
    test_suite_0.id = str_2
    test_suite_0.hostname = 'l^1'
    test_suite_0.system_out = '=8|$4'
    str_3 = 'P\x0b'
    test_suite_0.timestamp = str_3

# Generated at 2022-06-25 12:44:54.188155
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = 'tFmm\t'
    test_error_0 = TestError(str_0)
    str_0 = '7Za9p'
    test_result_0 = TestResult(str_0)
    list_0 = [test_error_0, test_result_0]
    str_1 = 'aG%l1'
    test_case_0 = TestCase(str_1, assertions=0, classname='\x1b1V\x0b', status='\x00\x1fO\x0e\x01', time=0.0007142857142857143, errors=list_0, failures=[test_result_0], skipped='U6', system_out='0\x11\x03\x18', system_err='cQP', is_disabled=True)

# Generated at 2022-06-25 12:44:59.371974
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('abc')
    assert test_case_0.get_xml_element() == ET.Element('testcase', {'name': 'abc'})
    assert test_case_0.get_xml_element().attrib == {'name': 'abc'}
    assert test_case_0.get_xml_element().text is None


# Generated at 2022-06-25 12:45:05.473766
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('y_Q6y\x07H')
    xml_element_0 = test_suite_0.get_xml_element()
    xml_element_1 = ET.Element('testsuite')
    attrs = _attributes(name = 'y_Q6y\x07H')
    for name, value in attrs.items():
        xml_element_1.set(name, value)
    assert xml_element_0 == xml_element_1


# Generated at 2022-06-25 12:45:28.891045
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = 'akkL5\x0bP'
    test_error_0 = TestError(str_0)

    test_case_0 = TestCase(name='b4d2')
    assert test_case_0.get_xml_element().get('name') == 'b4d2'

    str_1 = '\x0b\x12\x03'
    test_error_1 = TestError(str_1)

    test_case_1 = TestCase(name='9X')
    test_case_1.failures.append(test_error_1)
    assert test_case_1.get_xml_element().get('name') == '9X'
    assert test_case_1.get_xml_element().getchildren()[0].tag == 'failure'

    str_2

# Generated at 2022-06-25 12:45:34.301439
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create the object used to test the method.
    test_suite = TestSuite(name='test name')

    # Create the xml element that is the method's target.
    test_xml_element = test_suite.get_xml_element()

    # Assert that the element created has the correct tag and name.
    assert test_xml_element.tag == 'testsuite'
    assert test_xml_element.attrib['name'] == 'test name'


# Generated at 2022-06-25 12:45:42.197749
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('\x7f\x1c\x0f\x18\x04\x0c!\x0c\x1d\x1f\x0f\x06O\x0c')
    str_0 = '\x15\x0b\x02\x14\x15\x08\x01.\t\x07'
    test_failure_0 = TestFailure(str_0)
    test_case_0.failures = [test_failure_0]

# Generated at 2022-06-25 12:45:53.271045
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('name_0')
    test_case_0 = TestCase(str_0)
    test_suite_0.cases.append(test_case_0)
    int_0 = 0
    test_suite_0.disabled = int_0
    int_1 = 0
    test_suite_0.errors = int_1
    int_2 = 0
    test_suite_0.failures = int_2
    int_3 = 0
    test_suite_0.skipped = int_3
    int_4 = 0
    test_suite_0.tests = int_4
    decimal_0 = decimal.Decimal()
    test_suite_0.time = decimal_0
    str_1 = 'name_0'
    test_suite

# Generated at 2022-06-25 12:45:57.070955
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = 'akkL5\x0bP'
    test_case_0 = TestCase(str_0)

    xml_0 = test_case_0.get_xml_element()
    str_1 = xml_0.tag
    str_2 = 'testcase'

    assert str_1 == str_2



# Generated at 2022-06-25 12:46:04.758499
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    str_0 = 'akkL5\x0bP'
    int_0 = 766598610
    int_1 = 886343874
    int_2 = 665354782
    int_3 = 995888116
    str_1 = '\x1e;\x1dz\x11\x15\x0f'
    str_2 = '\x1f\x02\x0e\x15\x14l'
    int_4 = 335661945
    decimal_0 = decimal.Decimal(164551.0)
    test_suite_test_case_test_error_0 = TestError(str_0)
    test_case_test_error_0 = TestError(str_0)
    test_case_disabled_0 = False
    test_case_

# Generated at 2022-06-25 12:46:13.565372
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Arrange
    module_name_0 = 'test_junit_xml'
    test_case_name_0 = 'test_TestSuite_get_xml_element'
    name_0 = 'Sample Test Suite'
    test_suite_0 = TestSuite(name_0)

    # Act
    output_0 = test_suite_0.get_xml_element()

    # Assert
    assert output_0.tag == 'testsuite'
    assert output_0.attrib == {'name': name_0, 'tests': '0', 'skipped': '0', 'time': '0', 'failures': '0', 'disabled': '0', 'errors': '0'}


# Generated at 2022-06-25 12:46:17.065086
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('It is a test suite')
    name_0 = test_suite_0.get_xml_element().get('name')
    assert name_0 == 'It is a test suite'



# Generated at 2022-06-25 12:46:23.297512
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = 'akkL5\x0bP'
    test_error_0 = TestError(str_0)
    test_case_0 = TestCase(str_0)
    test_case_0.errors.append(test_error_0)
    # assert test_case_0.get_xml_element() == ET.Element('testcase', {})
    # assert test_case_0.get_xml_element().tag == 'testcase'
    assert test_case_0.get_xml_element().tag == 'testcase'


# Generated at 2022-06-25 12:46:31.836515
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    str_0 = 'l!\x1f\x03\x05\x0b\x00\x0f\x1d\x0e\x1c\x0f\x05\x1b\x1c\x0b\r\r\r\r\x04\t\x10\x03\t\x1d\x1a\x0e\x0e\x0c\x0e\x05'
    str_1 = '9ss>v#8x|Ww'

# Generated at 2022-06-25 12:46:51.804991
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    properties_0 = {}
    cases_0 = []
    test_suite_0 = TestSuite("_testSuite-test_TestSuite_get_xml_element", properties=properties_0, cases=cases_0)
    element_0 = test_suite_0.get_xml_element()
    assert element_0._children == []
    assert (str(element_0.attrib) == "{'disabled': '0', 'errors': '0', 'failures': '0', 'name': '_testSuite-test_TestSuite_get_xml_element', 'tests': '0', 'time': '0'}")
    assert element_0.tag == "testsuite"

# Generated at 2022-06-25 12:47:00.960821
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    timestamp_0 = datetime.datetime(year=2020, month=7, day=23, hour=22, minute=44, second=22)

# Generated at 2022-06-25 12:47:01.406017
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    pass


# Generated at 2022-06-25 12:47:07.599635
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(
        name='TEST',
        testsuiteid='TEST',
        timestamp=datetime.datetime.now(),
        package='com.example.tests',
        hostname='localhost',
        system_out='Successful',
        system_err='Successful')
    #Adding cases to the test suite
    suite.cases.append(TestCase(name='Test Case 1',
                                time=decimal.Decimal(2.0),
                                classname='com.example.tests',
                                skipped='OK'))
    suite.cases.append(TestCase(name='Test Case 2',
                                time=decimal.Decimal(3.0),
                                classname='com.example.tests',
                                skipped='OK'))

# Generated at 2022-06-25 12:47:15.583074
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_cases = [
        TestSuite(
            name="test_name",
            id=None
        ),
        TestSuite(
            name="test_name",
            id="test_id"
        ),
    ]
    str_0 = "test_name"
    str_1 = "test_id"
    tree_0 = ET.fromstring(ET.tostring(test_suite_cases[0].get_xml_element(), encoding='unicode'))
    tree_1 = ET.fromstring(ET.tostring(test_suite_cases[1].get_xml_element(), encoding='unicode'))
    assert tree_0.get('name') == str_0
    assert tree_0.get('id') == str_0

# Generated at 2022-06-25 12:47:26.704257
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    str_0 = '\x1c\x06\x1a\x02\x1a\x00\x16\x02\r\x00\x00\x01\x00\x00\x04\x01\x00\x00'
    str_1 = '\x00\x00\x07\x00\x00\x00\x04\x00\n\x00\x00\x1d\x02\x05\x03\x00\x00'
    str_2 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x01\x00\x00\x00\x00\x00\x02\x01\x00\x00\x00'

# Generated at 2022-06-25 12:47:35.466358
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test variables
    test_suite_0 = TestSuite('name', 'hostname', 'id', 'package', datetime.datetime(2020, 2, 19, 2, 49, 2, 669501), {'property': 'value'}, [TestCase('name', 'output', 'classname', 'status', 3.2, [TestError('error_output', 'error message'), TestError('error_output', 'error message')], [TestFailure('failure_output', 'failure message'), TestFailure('failure_output', 'failure message')], 'skipped', 'system_out', 'system_err')], 'system_out', 'system_err')
    # Testing

# Generated at 2022-06-25 12:47:39.683676
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0_instance = TestCase()
    test_case_0_instance.name = 'test_TestCase_get_xml_element'
    test_case_0_instance.time = 100.0
    xml_element_0_instance = test_case_0_instance.get_xml_element()
    print(xml_element_0_instance.tag)
    print(xml_element_0_instance.text)
    print(xml_element_0_instance.get('time'))


# Generated at 2022-06-25 12:47:42.805127
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=0,
        classname='test_class',
        name='test_name',
        status='test_status',
        time=0.04
    )
    assert test_case_0.get_xml_element() is not None


# Generated at 2022-06-25 12:47:45.829586
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Setup
    test_suite_0 = TestSuite('test_name')
    # Verify
    assert test_suite_0.get_xml_element() == ET.Element('testsuite', {'name': 'test_name', 'tests': '0'})


# Generated at 2022-06-25 12:48:29.737877
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    str_0 = 'b'
    decimal_0 = decimal.Decimal('81.9')
    str_1 = 'j'
    list_0 = []
    datetime_0 = datetime.datetime(2231, 9, 18, 23, 2, 54, 813138)

# Generated at 2022-06-25 12:48:39.058544
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    str_0 = 'LPN\x0e2r\x7f'
    str_1 = 'AM\x0b\x07'
    int_0 = -1527
    decimal_0 = decimal.Decimal('9.932917')
    decimal_1 = decimal.Decimal('0.06')
    test_error_0 = TestError(str_0, str_1)
    test_failure_0 = TestFailure(str_1)
    test_case_0 = TestCase(str_0, int_0, str_1, str_1, decimal_0)
    test_case_0.errors.append(test_error_0)
    test_case_0.failures.append(test_failure_0)
    test_case_0.time = decimal_1

# Generated at 2022-06-25 12:48:45.975296
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    timestamp_0 = datetime.datetime(1, 1, 1, 1, 1)
    str_0 = 'xmlns'
    str_1 = 'http://maven.apache.org/POM/4.0.0'
    test_suite_0 = TestSuite(str_0, timestamp_0)
    str_2 = 'http://maven.apache.org/POM/4.0.0'
    str_3 = 'xmlns'
    str_4 = 'name'
    str_5 = 'id'
    str_6 = 'hostname'
    str_7 = 'package'
    str_8 = 'tests'
    str_9 = 'timestamp'
    str_10 = 'time'
    str_11 = 'skipped'
    str_12 = 'failures'
   

# Generated at 2022-06-25 12:48:52.191957
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('test_0')
    str_0 = 'akkL5\x0bP'
    test_error_0 = TestError(str_0)
    test_case_0.errors.append(test_error_0)
    str_0 = 'e\x1d\x1f\x0c"'
    test_failure_0 = TestFailure(str_0)
    test_case_0.failures.append(test_failure_0)
    str_0 = 'z\x15h\x1f\x0e'
    test_case_0.output = str_0
    str_0 = '[\x14\x05\x1c\x1a'
    test_case_0.system_out = str_0

# Generated at 2022-06-25 12:48:55.909499
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite('test-name',hostname="hostname")
    xml = _pretty_xml(suite.get_xml_element())
    assert xml == "<testsuite disabled='0' errors='0' failures='0' hostname='hostname' name='test-name' skipped='0' tests='0' time='0.0'>\n</testsuite>\n"


# Generated at 2022-06-25 12:49:01.796936
# Unit test for method get_xml_element of class TestCase

# Generated at 2022-06-25 12:49:10.821353
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    name_0 = 'N\x00\x1f-\x04\x1d\n\x07\x03\x00\x15\x00\x1a\x00\x10\x00\x05\x00\x02\x00'
    test_case_0 = TestCase(name_0)
    attributes_0 = test_case_0.get_attributes()
    tag_0 = 'testcase'
    # Verify method call
    assert len(attributes_0) == 2
    element_0 = test_case_0.get_xml_element()
    assert element_0.tag == tag_0
    for attribute_0 in element_0.keys():
        # Verify that attributes are present and have correct value
        assert attribute_0 in attributes_0.keys()
        assert element_0

# Generated at 2022-06-25 12:49:16.638012
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('case name')
    int_0 = 10
    test_case_0.assertions = int_0
    test_case_0.classname = 'class name'
    test_case_0.status = 'status'
    dec_0 = decimal.Decimal('0.12')
    test_case_0.time = dec_0
    str_0 = 'akkL5\x0bP'
    test_error_0 = TestError(str_0)
    test_case_0.errors.append(test_error_0)
    str_1 = 'zR\n>\x1c'
    test_error_1 = TestError(str_1)
    test_case_0.errors.append(test_error_1)

# Generated at 2022-06-25 12:49:21.694203
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    str_0 = 'akkL5\x0bP'
    int_0 = -28260
    decimal_0 = decimal.Decimal('0.0')
    float_0 = float(0.0)
    datetime_0 = datetime.datetime(2007, 12, 20, 21, 29, 14)
    datetime_1 = datetime.datetime(2010, 5, 6, 18, 51, 5)
    datetime_2 = datetime.datetime(1999, 2, 4, 2, 14, 29)
    dict_0 = dict()
    dict_1 = dict()
    dict_1['name'] = 'name'
    dict_0['properties'] = dict_1
    dict_0['system-out'] = 'system-out'
    dict_0['timestamp'] = 'timestamp'
   

# Generated at 2022-06-25 12:49:26.690513
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('name0')
    test_suite_1 = TestSuite('name1')
    test_suite_2 = TestSuite('name2')

    test_case_0 = TestCase('name2')
    test_case_1 = TestCase('name1')
    test_case_2 = TestCase('name0')

    test_suite_0.cases.append(test_case_0)
    test_suite_1.cases.append(test_case_1)
    test_suite_2.cases.append(test_case_2)

    test_suite_0.system_out = 'system-out0'
    test_suite_1.system_out = 'system-out1'