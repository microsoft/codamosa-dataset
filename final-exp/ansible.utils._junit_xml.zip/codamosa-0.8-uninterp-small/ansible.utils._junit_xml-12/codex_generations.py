

# Generated at 2022-06-25 12:40:09.722650
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    attrs = {'assertions': '1', 'classname': 'test_class', 'name': 'test_name', 'status': 'test_status', 'time': '1.2'}
    cases = [TestCase(**attrs), TestCase(**attrs), TestCase(**attrs)]

# Generated at 2022-06-25 12:40:11.450100
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    var_0 = test_result.get_xml_element()


# Generated at 2022-06-25 12:40:15.265029
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Test for Class TestCase
    test_case_0 = TestCase('name_0')
    # Test for method get_xml_element
    var_0 = test_case_0.get_xml_element()


# Generated at 2022-06-25 12:40:17.058958
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert TestResult().get_attributes() == {
        "type": "TestResult"
    }, "Incorrect attributes"


# Generated at 2022-06-25 12:40:21.162646
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_0 = TestResult()

    # Test case 1
    try:
        var_0 = test_result_0.get_xml_element()
        var_0_0 = var_0.__class__.__name__
        assert var_0_0 == 'Element'
    except Exception as e:
        raise Exception("AssertError: Failed to assert the return type of 'get_xml_element' of class 'TestResult'.") from e


# Generated at 2022-06-25 12:40:24.343033
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult()
    var_0 = test_result_0.get_attributes()


# Generated at 2022-06-25 12:40:33.399831
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_1 = TestResult()
    var_1 = test_result_1.get_attributes()
    assert var_1 == {}

    test_result_2 = TestResult()
    var_2 = test_result_2.get_attributes()
    assert var_2 == {}

    test_result_3 = TestResult()
    var_3 = test_result_3.get_attributes()
    assert var_3 == {}

    test_result_4 = TestResult()
    var_4 = test_result_4.get_attributes()
    assert var_4 == {}

    test_result_5 = TestResult()
    var_5 = test_result_5.get_attributes()
    assert var_5 == {}

    test_result_6 = TestResult()
    var_6 = test_result

# Generated at 2022-06-25 12:40:34.699964
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='name_0')
    var_0 = test_suite_0.get_xml_element()

# Generated at 2022-06-25 12:40:38.305937
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    # Call method
    if test_result.get_attributes() == {}:
        print('get_attributes successful')
    else:
        print('get_attributes not successful')


# Generated at 2022-06-25 12:40:41.392857
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result_0 = TestResult(type=None)
    var_0 = test_result_0.get_attributes()
    assert var_0 == {'message': None, 'type': 'testresult'}


# Generated at 2022-06-25 12:41:02.602601
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        name='test_case_0',
    )
    actual = test_case_0.get_xml_element()
    element = ET.fromstring(
        '''
        <testcase
            name="test_case_0"
        />
        '''
    )
    assert _pretty_xml(actual) == _pretty_xml(element)

    test_case_1 = TestCase(
        assertions=1,
        classname='TestCase',
        name='test_case_1',
        status='status',
        time=1.1,
    )
    actual = test_case_1.get_xml_element()

# Generated at 2022-06-25 12:41:05.328735
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    TESTSUITE = TestSuite(name = "TestSuite")
    TESTSUITE.get_xml_element()

# Generated at 2022-06-25 12:41:15.372683
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:41:20.474271
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')

    e_test_case_0 = ET.Element('testcase',
                            test_case_0.get_attributes())

    assert(ET.tostring(e_test_case_0) == ET.tostring(test_case_0.get_xml_element()))


# Generated at 2022-06-25 12:41:21.776530
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Test for method get_xml_element of class TestSuite"""


# Generated at 2022-06-25 12:41:27.067031
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # create test object
    test_object = TestCase(name='test-name')
    # create expected result
    expected_result = ET.Element('testcase', {'name': 'test-name'})
    # assert that expected and actual result are equal
    assert ET.tostring(test_object.get_xml_element()) == ET.tostring(expected_result)


# Generated at 2022-06-25 12:41:29.978522
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase('test_case',
                         is_disabled=True
                         )

    test_suites = TestSuites(name=None)

    element = test_suites.get_xml_element()


# Generated at 2022-06-25 12:41:37.851830
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='hello')
    test_suite_0 = TestSuite(name='goodbye')
    test_suite_0.cases = [test_case_0]
    test_suites_0 = TestSuites()
    test_suites_0.suites = [test_suite_0]

# Generated at 2022-06-25 12:41:49.002125
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """
    Test case for the get_xml_element method of class TestSuite
    """
    xml = '<testsuites errors="1" failures="0" name="test-suite-name" skipped="0" tests="1" time="0.001" disabled="0"><testsuite errors="1" failures="0" hostname="127.0.0.1" id="1" name="test-suite-name" package="test-suite-package" skipped="0" tests="1" time="0.001" timestamp="2019-12-26T17:46:07"><properties></properties></testsuite></testsuites>'

# Generated at 2022-06-25 12:41:57.600803
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')

    xml = test_case_0.get_xml_element()
    assert xml.tag == 'testcase'
    assert xml.attrib['name'] == 'test_case_0'

    test_case_0.system_out = 'A test case output\nAnother line'
    xml = test_case_0.get_xml_element()
    assert xml.find('system-out').text == 'A test case output\nAnother line'

    test_case_0.system_err = 'An error text\nAnother line'
    xml = test_case_0.get_xml_element()
    assert xml.find('system-err').text == 'An error text\nAnother line'

    test_case_0.skipped = 'reason'
   

# Generated at 2022-06-25 12:42:13.222863
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # Parameters for TestSuite
    test_suite_0 = TestSuite(
            name='test_suite_0',
            hostname='localhost',
            id='test-suite-0',
            package='unit_test',
            timestamp=datetime.datetime.now(),
    )
    test_suite_0.properties['language'] = 'python'
    test_suite_0.properties['python.version'] = '3.7.9'

    # Parameters for TestCase
    test_case_0 = TestCase(
            name='test_case_0',
            assertions=1,
            classname='TestSuite',
            status='passed',
            time=1.0
    )
    # Parameters for TestCase

# Generated at 2022-06-25 12:42:17.697640
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Test for method get_xml_element of class TestSuite"""

# Generated at 2022-06-25 12:42:24.120513
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:42:32.665971
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_0 = TestSuite(name = "test_name", hostname = "test_hostname", id = "test_id", package = "test_package", timestamp = datetime.datetime(2020, 6, 29, 21, 33, 50, 728267))
    assert test_0.get_xml_element().tag == "testsuite"
    assert test_0.get_xml_element().attrib == {'id': 'test_id', 'name': 'test_name', 'timestamp': '2020-06-29T21:33:50.728267', 'tests': '0', 'disabled': '0', 'failures': '0', 'errors': '0', 'skipped': '0', 'time': '0', 'package': 'test_package', 'hostname': 'test_hostname'}
    assert test_0

# Generated at 2022-06-25 12:42:42.904044
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:42:49.250648
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    mock_TestSuites = TestSuites()
    mock_TestSuite = TestSuite(name='name')
    TestCase_0 = TestCase(name='name')
    mock_TestSuite.cases.append(TestCase_0)
    mock_TestSuites.suites.append(mock_TestSuite)
    xml_element = mock_TestSuites.get_xml_element()
    assert ElementTree.tostring(xml_element) == b'<testsuites disabled="0" errors="0" failures="0" name="" tests="1" time="0" />'


# Generated at 2022-06-25 12:42:55.561580
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_suite_0 = TestSuite(cases=[TestCase(name='name_0')])
    element_0 = test_suite_0.get_xml_element()
    
    assert element_0.get('name') == "name_0"
    assert ET.tostring(element_0) == b'<testsuite tests="1"><testcase name="name_0"></testcase></testsuite>'
    

# Generated at 2022-06-25 12:43:05.340092
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:43:12.060457
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    _TestCase__input_str = "testcase"
    test_case_1 = TestCase(name="testCase", classname="testClass", time=0, status="passed")
    element_expected = ET.Element(_TestCase__input_str, {"name": "testCase", "classname": "testClass", "time": "0", "status": "passed"})
    element_actual = test_case_1.get_xml_element()
    assert element_actual.tag == element_expected.tag, "Failed because element tag attibute not equal"
    assert element_actual.attrib == element_expected.attrib, "Failed because element attibute not equal"


# Generated at 2022-06-25 12:43:15.851639
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite("name")
    xml_element_0 = test_suite_0.get_xml_element()
    assert xml_element_0.attrib.get("name") == "name"


# Generated at 2022-06-25 12:43:29.963304
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='name')
    test_case.errors.append(TestError(output='error output', message='error message'))
    test_case.failures.append(TestFailure(output='failure output', message='failure message'))
    test_case.skipped = 'skipped reason'
    test_case.system_out = 'system-out output'
    test_case.system_err = 'system-err output'

    test_suite = TestSuite(name='name', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'})
    test_suite.cases.append(test_case)
    test_suite.system_out = 'system-out output'
    test_suite.system_err

# Generated at 2022-06-25 12:43:36.227853
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    def _expected_output(result):
        return """<testsuite disabled="0" errors="0" failures="0" hostname="" id="" name="" package="" skipped="0" tests="0" time="0.0" timestamp="">
    {}
</testsuite>""".format(result)

    test_case_0 = TestSuite(
        name='test_case_0',
    )

    result = _pretty_xml(test_case_0.get_xml_element())
    assert result == _expected_output('')



# Generated at 2022-06-25 12:43:45.894457
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='name', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, system_out='system_out', system_err='system_err')
    suite.cases = [TestCase(name='name', assertions=1, classname='classname', status='status', time=decimal.Decimal(1), errors=[], failures=[], skipped='skipped', system_out='system_out', system_err='system_err')]

# Generated at 2022-06-25 12:43:55.641049
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-25 12:44:01.463002
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='test_case_0',
                           errors=[],
                           failures=[],
                           skipped=None,
                           system_out=None,
                           system_err=None,
                           assertions=None,
                           classname=None,
                           status=None,
                           time=None)
    test_suite_0 = TestSuite(name='test_suite_0',
                             hostname=None,
                             id=None,
                             package=None,
                             timestamp=None,
                             properties={},
                             cases=[test_case_0],
                             system_out=None,
                             system_err=None)


# Generated at 2022-06-25 12:44:03.907359
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test-case-0', assertions=None)

    assert test_case_0.get_xml_element().tag == 'testcase'


# Generated at 2022-06-25 12:44:10.260030
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    expected_result = '<testsuite disabled="0" errors="0" failures="0" hostname="None" id="None" name="test_suite" package="None" skipped="0" tests="0" time="0.00000"/>'
    test_suite_0 = TestSuite(name="test_suite")
    actual_result = ET.tostring(test_suite_0.get_xml_element(), encoding='unicode')
    assert expected_result == actual_result


# Generated at 2022-06-25 12:44:13.544335
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    try:
        result = test_case_0.get_xml_element()
    except:
        print(test_case_0.get_xml_element())


# Generated at 2022-06-25 12:44:21.435190
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """
    Method get_xml_element of class TestSuite
    """
    test_suite = TestSuite(name = 'TestSuite', timestamp=datetime.datetime(2016, 10, 31, 11, 22, 33, tzinfo=datetime.timezone.utc), cases = [TestCase('Test1')])
    test_suite_element = test_suite.get_xml_element()
    print(test_suite_element)
    assert test_suite_element.tag == 'testsuite'

# Generated at 2022-06-25 12:44:22.130644
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()



# Generated at 2022-06-25 12:44:35.298294
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase("TestCase_0", time="0.0")
    test_case_1 = TestCase("TestCase_1", time="10.0")
    test_case_2 = TestCase("TestCase_2", time="-1.0")
    test_case_3 = TestCase("TestCase_3", time="1.0")
    test_case_4 = TestCase("TestCase_4", time="0.1")
    test_case_5 = TestCase("TestCase_5", time="0.0")

    test_cases = [test_case_0, test_case_1, test_case_3, test_case_4, test_case_5]


# Generated at 2022-06-25 12:44:41.658296
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name="Example test suite", hostname="localhost", tests=2, time=decimal.Decimal('0.02'))
    assert ts.name == "Example test suite"
    element = ts.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.attrib == {'hostname': 'localhost', 'name': 'Example test suite', 'time': '0.02', 'tests': '2'}

# Generated at 2022-06-25 12:44:51.208222
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_suite = TestSuite('junit-test-suite')

    test_case = TestCase('junit-test-case')

    test_suite.tests += 1
    test_suite.cases.append(test_case)

    xml_element = test_suite.get_xml_element()

    xml_string = ET.tostring(xml_element, encoding='unicode')
    print(xml_string)

    assert xml_string == '<testsuite disabled="0" errors="0" failures="0" name="junit-test-suite" skipped="0" tests="1" time="0"><testcase assertions="None" classname="None" name="junit-test-case" status="None" time="None" /><system-out /><system-err /></testsuite>'

# Generated at 2022-06-25 12:45:00.493184
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # Test suite
    case_0 = TestCase(
        assertions=1,
        classname='TestClassZero',
        errors=[],
        failures=[],
        name='test_case_0',
        skipped=None,
        status=None,
        time=decimal.Decimal('1.000'),
    )

    case_1 = TestCase(
        assertions=None,
        classname='TestClassOne',
        errors=[
            TestError(
                message='There was an error',
                output='test_case_1_error_output',
                type='test_case_1_error_type',
            ),
        ],
        failures=[],
        name='test_case_1',
        skipped=None,
        status=None,
        time=decimal.Decimal('2.000'),
    )

   

# Generated at 2022-06-25 12:45:08.775008
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    disabled = True
    actual = TestCase('TestCase 1',
                        assertions = 1,
                        classname = 'classname',
                        status = 'status',
                        time = decimal.Decimal(1.1),
                        is_disabled = disabled).get_xml_element()
    assert actual.tag == 'testcase'
    assert actual.attrib == {'assertions': '1', 'classname': 'classname', 'name': 'TestCase 1', 'status': 'status', 'time': '1.1'}
    assert actual.text == None
    assert actual[0].tag == 'disabled'
    assert actual[0].text == 'True'


# Generated at 2022-06-25 12:45:15.425015
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(
        assertions=None,
        classname=None,
        errors=[],
        failures=[],
        name='test_case_name',
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=None
    )
    test_suite_0 = TestSuite(
        cases=[test_case_0],
        disabled=None,
        errors=None,
        failures=None,
        hostname=None,
        id=None,
        name='test_suite_name',
        package=None,
        properties={},
        skipped=None,
        system_err=None,
        system_out=None,
        tests=None,
        time=None,
        timestamp=None
    )
   

# Generated at 2022-06-25 12:45:17.142446
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0()
    test_case_1()
    test_case_2()

# Generated at 2022-06-25 12:45:19.438883
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase()
    assert "[Element: 'testcase']" in test_case_0.get_xml_element()


# Generated at 2022-06-25 12:45:22.349856
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name='test name', cases=[])
    assert ET.tostring(test_suite_0.get_xml_element(), encoding='unicode')==b'<testsuite disabled="0" errors="0" failures="0" name="test name" skipped="0" tests="0" time="0.000000"><system-out></system-out><system-err></system-err></testsuite>'


# Generated at 2022-06-25 12:45:31.546514
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    test_case_0 = TestCase(
        assertions = 1
        , classname = "com.github.sangupta.junit.JUnitReportTest"
        , errors = []
        , failures = []
        , name = "testGetXmlElement"
        , skipped = None
        , status = "success"
        , system_err = None
        , system_out = None
        , time = Decimal(0.079)
    )


# Generated at 2022-06-25 12:45:40.173742
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite('name', 'hostname', 'id', 'package', 'timestamp', 'properties', 'cases', 'system_out', 'system_err')
    result = test_suite_0.get_xml_element()
    assert isinstance(result, ET.Element)


# Generated at 2022-06-25 12:45:48.535422
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    case_0 = TestCase("case_0", status=2, time=2.0)
    case_1 = TestCase("case_1", status=1, time=1.0)
    # create object TestSuite
    suite_0 = TestSuite("suite_0", timestamp=datetime.datetime.now(), cases=[case_0, case_1])
    assert suite_0.timestamp is not None
    assert suite_0.get_attributes() is not None
    assert suite_0.get_xml_element() is not None


# Generated at 2022-06-25 12:45:57.305271
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testResult = TestResult()
    testCase = TestCase('1')
    testSuite = TestSuite('test_suite')

    # Test with no errors, failures, skipped, system-out, system-err and no name
    assert testSuite.get_xml_element().attrib == {
        'name': 'test_suite',
        'tests': '0',
        'failures': '0',
        'errors': '0',
        'disabled': '0',
        'skipped': '0',
        'time': '0.0'
    }

    # Test with errors, failures, skipped, system-out, system-err and no name
    testSuite.system_err = ''
    testSuite.system_out = ''
    testCase.errors.append(testResult)
    testCase.failures

# Generated at 2022-06-25 12:46:01.934438
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    t1 = TestCase("TC01", assertions = 1, classname = "TestCase01", status = "Run", time = decimal.Decimal('1.2'))
    assert t1.get_xml_element().tag == 'testcase'
    assert t1.get_xml_element().get("assertions") == "1"
    assert t1.get_xml_element().get("classname") == "TestCase01"
    assert t1.get_xml_element().get("name") == "TC01"
    assert t1.get_xml_element().get("status") == "Run"
    assert t1.get_xml_element().get("time") == "1.2"


# Generated at 2022-06-25 12:46:11.704362
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    #testcase1
    xml_string_expected='\n<testsuite\n\tdisabled="0"\n\terrors="0"\n\tfailures="0"\n\thostname=""\n\tid=""\n\tname="file_name"\n\tpackage=""\n\tskipped="0"\n\ttests="5"\n\ttime="0.0"\n\ttimestamp="2020-08-18T02:00:00"\n\t>\n</testsuite>'
    assert _pretty_xml(TestSuite(name='file_name',timestamp=datetime.datetime(2020,8,18,2)).get_xml_element()) == xml_string_expected, 'failed'

    #testcase2

# Generated at 2022-06-25 12:46:21.276176
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Arrange
    # Act
    test_suite = TestSuite(
        name='name_0',
        hostname='hostname_0',
        id='id_0',
        package='package_0',
        timestamp=datetime.datetime(2019, 11, 14, 18, 14, 37, 916347),
        properties={'name_0': 'value_0'},
        cases=[TestCase(
            name='name_0',
            assertions='assertions_0',
            classname='classname_0',
            status='status_0',
            time=decimal.Decimal('1.1'),
        )],
        system_out='system_out_0',
        system_err='system_err_0',
    )

    # Assert
    assert test_suite.get_xml_element

# Generated at 2022-06-25 12:46:27.868892
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_TestSuite_get_xml_element_suite = TestSuite(name='TestSuite1')
    test_TestSuite_get_xml_element_case = TestCase(name = 'TestCaes1')
    test_TestSuite_get_xml_element_case.is_disabled = True
    test_TestSuite_get_xml_element_case.time = decimal.Decimal(3)
    test_TestSuite_get_xml_element_suite.cases.append(test_TestSuite_get_xml_element_case)
    test_TestSuite_get_xml_element_case = TestCase(name = 'TestCaes2')
    test_TestSuite_get_xml_element_case.time = decimal.Decimal(4)
    test_TestSuite_get_xml_

# Generated at 2022-06-25 12:46:32.522302
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Arrange
    # Act
    testsuite = TestSuite(name='test_name')
    # Assert
    assert testsuite.get_xml_element().tag == 'testsuite'
    names = testsuite.get_xml_element().get('name')
    assert names == 'test_name'


# Generated at 2022-06-25 12:46:34.382477
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('name')
    assert test_case_0.get_xml_element().tag == 'testcase'


# Generated at 2022-06-25 12:46:42.037779
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(
        assertions=1,
        classname='c',
        errors=[
            TestError()
            ],
        failures=[
            TestFailure()
            ],
        name='n',
        status='s',
        system_err='se',
        system_out='so',
        time=1.1
    )
    xml_element = test_case_0.get_xml_element()
    assert xml_element.attrib == {'assertions': '1', 'classname': 'c', 'name': 'n', 'status': 's', 'time': '1.1'}
    assert xml_element[0].tag == 'error'
    assert xml_element[1].tag == 'failure'
    assert xml_element[2].tag == 'system-err'
    assert xml_

# Generated at 2022-06-25 12:46:58.797355
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts=TestSuite('testsuite_2',
                 'localhost',
                 'some_id',
                 'com.ignitirx.tests.some_package',
                 datetime.datetime.now(datetime.timezone.utc)
                 )
    tc1=TestCase('testcase_1',
                 'testclass_1',
                 'pass',
                 '0.01'
                 )
    tc2=TestCase('testcase_2',
                 'testclass_1',
                 'pass',
                 '0.01'
                 )
    ts.cases.append(tc1)
    ts.cases.append(tc2)
    pretty = _pretty_xml(ts.get_xml_element())
    assert_equals(pretty.count('testsuite'), 1)

# Generated at 2022-06-25 12:47:05.827407
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    name = 'testsuite'
    hostname = 'localhost'
    id = 'id'
    package = 'package'
    timestamp = datetime.datetime.now()

    properties = {
        'property1': 'value1',
        'property2': 'value2',
    }
    system_out = 'system_out'
    system_err = 'system_err'

    errors = [
        TestError(message='message0', output='output0'),
        TestError(message='message1', output='output1'),
    ]
    failures = [
        TestFailure(message='message2', output='output2'),
        TestFailure(message='message3', output='output3'),
    ]


# Generated at 2022-06-25 12:47:11.179439
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test the method with a TestSuite with no attributes set
    test_suite = TestSuite(name='A')
    assert test_suite.get_xml_element().attrib == {'name': 'A'}
    
    # Test the method with a TestSuite with all attributes set
    test_suite = TestSuite(
        name='A',
        hostname='B',
        id='C',
        package='D',
        timestamp=datetime.datetime.fromisoformat('2020-01-23 12:34:56.7890')
    )

# Generated at 2022-06-25 12:47:13.384255
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    assert test_case_0.get_xml_element().tag == 'testcase'



# Generated at 2022-06-25 12:47:19.127128
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name = '', hostname = '', id = '', package = '', timestamp = '', properties = '', cases = '', system_out='', system_err='')
    assert ts.get_xml_element() == '<testsuite disabled="0" errors="0" failures="0" hostname="" id="" name="" package="" skipped="0" tests="0" time="0"><properties /></testsuite>'

# Generated at 2022-06-25 12:47:27.046045
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite(name="", hostname="", id="", package="", timestamp="2020-08-05T17:30:14.234637", disabled=75, errors=45, failures=51, skipped=28, tests=99, time=32.35)
    test_case_0 = TestCase(name="", assertions=4, classname="", status="", time=0)
    test_suite_0.cases.append(test_case_0)
    test_xml_element_0 = test_suite_0.get_xml_element()


# Generated at 2022-06-25 12:47:35.785756
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test case 0
    suite = TestSuite(
        name='Suite',
        cases=[
            TestCase(name='Case 0'),
            TestCase(name='Case 1'),
        ],
    )

    element = suite.get_xml_element()
    assert element is not None
    assert element.tag == 'testsuite'
    assert element.attrib == {'name': 'Suite', 'tests': '2', 'time': '0.0'}
    assert element.find('testcase') is not None
    assert element.find('testcase').attrib == {'name': 'Case 0'}
    assert element.find('testcase').getnext() is not None
    assert element.find('testcase').getnext().attrib == {'name': 'Case 1'}

    xml = suite.to_pretty_xml

# Generated at 2022-06-25 12:47:41.786465
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # test_junit_xml_0
    test_case_0 = TestSuite(name="Test suite name")
    assert(ET.tostring(test_case_0.get_xml_element()).decode("utf-8") == """<testsuite disabled="0" errors="0" failures="0" name="Test suite name" skipped="0" tests="0" time="0"></testsuite>""")

    # test_junit_xml_1
    test_case_1 = TestSuite(name="Test suite name", timestamp=datetime.datetime(2018, 1, 1))

# Generated at 2022-06-25 12:47:49.945028
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name="Test name", assertions=2, classname="TestClass", status="status", time=1.1)
    test_suite_0 = TestSuite(name="TestSuiteName", hostname="TestHostName", id="TestSuiteId", package="TestPackage", timestamp=datetime.datetime.now())
    test_suite_0.tests = 3
    test_suite_0.time = 2.1
    test_suite_0.cases.append(test_case_0)
    assert "<testsuite" in test_suite_0.get_xml_element().tag
    assert test_suite_0.get_xml_element().get("name") == "TestSuiteName"

# Generated at 2022-06-25 12:47:56.115784
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_case_0 = TestCase(name="test_case_0")
    test_suite_0 = TestSuite(name="test_suite_0")
    test_suite_0.cases.append(test_case_0)
    test_suites_0 = TestSuites(name="test_suite_0")
    test_suites_0.suites.append(test_suite_0)

    test_suite_1 = TestSuite(name="test_suite_1")
    test_suites_0.suites.append(test_suite_1)

    root_element = test_suites_0.get_xml_element()

    assert root_element.tag == "testsuites"
    assert root_element.attrib["name"] == "test_suite_0"

# Generated at 2022-06-25 12:48:08.897774
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test fixture: Create a test suite object with a single test case
    name = 'Test Suite'
    timestamp = datetime.datetime(2020, 6, 4, 15, 9, 41, 423000)
    properties = {'Test': '1.0', 'Server': 'localhost', 'Port': '12345'}
    system_out = 'Output'
    system_err = 'Error'
    status = 'success'
    test_case = TestCase(
        name='Test Case',
        assertions=3,
        time=datetime.timedelta(milliseconds=500),
        system_out=system_out,
        system_err=system_err,
        status=status,
    )

# Generated at 2022-06-25 12:48:17.061317
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_class_1 = TestSuite(name='TestSuite_0', timestamp=datetime.datetime(2020, 12, 25, 13, 30, 30))
    test_case_2 = TestCase(name='TestCase_0', classname='TestClass_0', time=0.5)
    test_suite_3 = TestSuite(name='TestSuite_0')
    test_failure_4 = TestFailure(type='TestType_0', message='TestMessage_0', output='TestOutput_0')
    test_result_5 = TestResult()
    test_suites_6 = TestSuites(name='TestSuites_0')
    test_case_7 = TestCase(name='TestCase_1', classname='TestClass_1', time=0.5)
    test_result_8 = TestResult

# Generated at 2022-06-25 12:48:22.278768
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    # test dataclass instantiation
    test_case_0 = TestCase("name_0")

    # test tag of xml element
    assert test_case_0.get_xml_element().tag == 'testcase'

    # test attributes
    assert test_case_0.get_xml_element().attrib == _attributes(name='name_0')


# Generated at 2022-06-25 12:48:25.746676
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    import xml.etree.ElementTree as ET
    root = ET.Element("root")
    a = ET.SubElement(root, "a")
    b = ET.SubElement(a, "b")
    print(ET.tostring(root))


# Generated at 2022-06-25 12:48:29.767141
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase('test_case_0')
    test_xml = _pretty_xml(test_case_0.get_xml_element())
    assert test_xml == """\
<?xml version="1.0" ?>
<testcase classname="None" name="test_case_0"/>
"""


# Generated at 2022-06-25 12:48:33.013061
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite('name')
    xml = suite.get_xml_element()
    assert isinstance(xml, ET.Element)
    assert xml.tag == 'testsuite'
    assert xml.attrib['name'] == 'name'


# Generated at 2022-06-25 12:48:41.659281
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    e = TestSuite(name='name', id='id', properties={'key': 'value'}, cases=[], system_out='', system_err='')
    xml = e.get_xml_element()
    assert '<testsuite errors="0" failures="0" name="name" skipped="0" tests="0" time="0">' in xml
    assert '<properties>' in xml
    assert '<property name="key" value="value"/>' in xml
    assert '<system-out><![CDATA[]]></system-out>' in xml
    assert '<system-err><![CDATA[]]></system-err>' in xml
    assert '</testsuite>' in xml


# Generated at 2022-06-25 12:48:49.581240
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase(errors=[TestError(), TestError()], name='name_0', time=decimal.Decimal(1))
    expected = _pretty_xml(ET.Element('testcase', _attributes(name='name_0', time=str(decimal.Decimal(1))), [ET.Element('error'), ET.Element('error')]))
    assert expected == _pretty_xml(test_case_0.get_xml_element())


# Generated at 2022-06-25 12:48:56.146749
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name = "The name of the TestSuite",
        hostname = "The hostname",
        id = "The ID",
        package = "The package",
        timestamp = datetime.datetime(2020,1,1,12,30,22),
        properties = {'property0': 'value0', 'property1': 'value1'},
        cases = [
            TestCase(
                name = "TestCase name",
                assertions = 2,
                classname = "TestCase classname",
                status = "TestCase status",
                time = decimal.Decimal("0.123"),
            )
        ],
        system_out = "TestSuite system out",
        system_err = "TestSuite system error",
    )

    element = test_suite.get_xml_

# Generated at 2022-06-25 12:49:05.060458
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case_0 = TestCase("example_name", assertions=7, classname="example-class", time=decimal.Decimal("7.003"),
                           status="FR(" + str(TestCase.errors) + "), " + "F(" + str(TestCase.failures) + ")" +
                                  "I(" + str(TestCase.is_disabled) + ")")
    t_case = TestCase("example_name", assertions=7, classname="example-class", time=decimal.Decimal("7.003"),
                           status="FR(" + str(TestCase.errors) + "), " + "F(" + str(TestCase.failures) + ")" +
                                  "I(" + str(TestCase.is_disabled) + ")")
    assert test_case_0.get_xml_element

# Generated at 2022-06-25 12:49:18.116643
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    #Mocked function get_attributes
    def mock_TestSuite_get_attributes(self):
        return t.Dict[str, str]({'disabled':'0', 'errors':'2', 'failures':'3',
        'hostname':'c1017.ambari.apache.org', 'id':'1', 'name':'test_suite',
        'package':'org.apache.ambari.server.checks', 'skipped':'0', 'tests':'5',
        'time':'0', 'timestamp':'2019-09-01T16:01:47'})

    #Mocked function get_xml_element of class TestCase

# Generated at 2022-06-25 12:49:19.536514
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    assert ' ' in _pretty_xml(TestCase('name_example').get_xml_element())



# Generated at 2022-06-25 12:49:20.287970
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    assert False


# Generated at 2022-06-25 12:49:23.232219
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    try:
        ts = TestSuite("TestSuite1",None,None,None,None)
        print("TestCase1 is:", ts.get_xml_element())
    except NameError as e:
        print("Exception: ", e)
        assert False


# Generated at 2022-06-25 12:49:26.030855
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name = "test1", tests = 3, failures = 1, errors = 0, hostname = "testHost", timestamp = datetime.date(2020, 3, 3))
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-25 12:49:32.910539
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case_0 = TestCase(name='test_case_0')
    test_suite_0 = TestSuite(name='test_suite_0', id='test_suite_0_id')
    test_suite_0.cases.append(test_case_0)
    test_suites_0 = TestSuites(name='test_suites_0')
    test_suites_0.suites.append(test_suite_0)


# Generated at 2022-06-25 12:49:39.858190
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_0 = TestSuite()
    assert test_suite_0 == TestSuite(assertions=None, cases=[], classname=None, errors=0, failures=0, hostname=None, id=None, is_disabled=False, is_error=False, is_failure=False, is_skipped=False, message=None, name='', output=None, package=None, properties={}, skipped=0, status=None, system_err=None, system_out=None, tag=None, time=None, timestamp=None, type=None)
    assert test_suite_0.cases == []
    assert test_suite_0.disabled == 0
    assert test_suite_0.errors == 0
    assert test_suite_0.failures == 0

# Generated at 2022-06-25 12:49:45.359674
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_xml_string = '<testsuite disabled="0" errors="0" failures="0" name="testsuite_name" tests="0" time="0.0"></testsuite>'
    test_suite = TestSuite(name='testsuite_name')
    test_xml_element = test_suite.get_xml_element()
    assert ET.tostring(test_xml_element, encoding='unicode') == test_xml_string


# Generated at 2022-06-25 12:49:54.605805
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    classname_0 = 'classname_0'
    name_0 = 'name_0'
    time_0 = 1.2345
    test_case_0 = TestCase(
        assertions=None,
        classname=classname_0,
        errors=[],
        failures=[],
        name=name_0,
        skipped=None,
        status=None,
        system_err=None,
        system_out=None,
        time=time_0
    )
    hostname_0 = 'hostname_0'
    id_0 = 'id_0'
    package_0 = 'package_0'