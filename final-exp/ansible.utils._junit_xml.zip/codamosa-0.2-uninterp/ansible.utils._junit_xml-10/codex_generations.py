

# Generated at 2022-06-17 14:32:59.836384
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element() == ET.Element('testresult')


# Generated at 2022-06-17 14:33:08.414628
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:11.720530
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    element = result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.attrib == {'message': 'message', 'type': 'type'}
    assert element.text == 'output'


# Generated at 2022-06-17 14:33:14.277374
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:33:15.849891
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:20.033222
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:25.586439
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:27.511323
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:33:37.357283
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:41.584396
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:51.317051
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:55.059154
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:56.092374
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element() is not None


# Generated at 2022-06-17 14:34:01.718891
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases.append(TestCase(name='test_case_3'))
    test_suite.cases.append(TestCase(name='test_case_4'))
    test_suite.cases.append(TestCase(name='test_case_5'))
    test_suite.cases.append(TestCase(name='test_case_6'))
    test_suite.cases.append(TestCase(name='test_case_7'))
    test_suite.cases.append(TestCase(name='test_case_8'))

# Generated at 2022-06-17 14:34:04.452391
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:09.851065
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:34:12.555588
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:15.631182
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:34:24.146148
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:27.782487
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test', message='test', type='test')
    assert test_result.get_attributes() == {'message': 'test', 'type': 'test'}


# Generated at 2022-06-17 14:34:46.468426
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:56.321407
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now())
    test_suite.properties = {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-17 14:35:00.100939
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_name'


# Generated at 2022-06-17 14:35:03.577725
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:35:07.412193
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_xml_element().tag == "TestResult"


# Generated at 2022-06-17 14:35:11.308620
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:14.994267
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output="output", message="message", type="type")
    assert result.get_xml_element().tag == "testresult"
    assert result.get_xml_element().text == "output"
    assert result.get_xml_element().attrib == {"message": "message", "type": "type"}


# Generated at 2022-06-17 14:35:21.629575
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test output', message='test message', type='test type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'test output'
    assert test_result.get_xml_element().attrib == {'message': 'test message', 'type': 'test type'}


# Generated at 2022-06-17 14:35:25.260779
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:30.942191
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:56.843163
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().get('message') == 'message'
    assert result.get_xml_element().get('type') == 'type'
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:36:05.220666
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Test method get_xml_element of class TestResult."""
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:11.309944
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now())
    test_suite.properties = {'key': 'value'}
    test_suite.cases = [TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'


# Generated at 2022-06-17 14:36:16.824319
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:19.469006
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:23.342238
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_1')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_1'


# Generated at 2022-06-17 14:36:26.805191
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:36:30.320183
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:36:33.901604
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:37.216800
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:50.445568
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal('1.0'))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    element = test_suite.get_xml_element()

    assert element.tag == 'testsuite'

# Generated at 2022-06-17 14:38:02.062159
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:12.392441
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', id='1', timestamp=datetime.datetime.now())
    test_suite.cases.append(TestCase(name='test_case_1', time=1.0))
    test_suite.cases.append(TestCase(name='test_case_2', time=2.0))
    test_suite.cases.append(TestCase(name='test_case_3', time=3.0))
    test_suite.cases.append(TestCase(name='test_case_4', time=4.0))
    test_suite.cases.append(TestCase(name='test_case_5', time=5.0))
    test_suite.cases.append(TestCase(name='test_case_6', time=6.0))

# Generated at 2022-06-17 14:38:23.275401
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:27.714542
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:37.703558
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:44.965204
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:52.474432
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:00.823948
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:11.901310
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now())
    test_suite.properties['property1'] = 'value1'
    test_suite.properties['property2'] = 'value2'
    test_suite.cases.append(TestCase(name='TestCase1', assertions=1, classname='com.example.TestCase1', status='PASSED', time=1.0))
    test_suite.cases.append(TestCase(name='TestCase2', assertions=2, classname='com.example.TestCase2', status='FAILED', time=2.0))

# Generated at 2022-06-17 14:40:57.349255
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal('1.0'))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().att

# Generated at 2022-06-17 14:41:03.136718
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite_name'


# Generated at 2022-06-17 14:41:11.005268
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    test_suite_xml_element = test_suite.get_xml_element()
    assert test_suite_xml_element.tag == 'testsuite'
    assert test_suite_xml_element.attrib['name'] == 'test_suite_name'
    assert test_suite_xml_element[0].tag == 'testcase'
    assert test_suite_xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:41:18.447093
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_case = TestCase(name='test_case')
    test_suite.cases.append(test_case)
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite'
    assert test_suite.get_xml_element()[0].tag == 'testcase'
    assert test_suite.get_xml_element()[0].attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:41:28.624825
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:30.419970
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:41:39.130923
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:45.812352
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:54.906010
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:05.180402
# Unit test for method get_xml_element of class TestSuite