

# Generated at 2022-06-17 14:33:04.643410
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:11.993898
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=1.0)
    test_case.errors.append(TestError(output='test_error_output', message='test_error_message', type='test_error_type'))
    test_case.failures.append(TestFailure(output='test_failure_output', message='test_failure_message', type='test_failure_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.is_disabled = True

    test_case_xml_element = test_case.get_xml_

# Generated at 2022-06-17 14:33:21.802901
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name="test_case_1", assertions=1, classname="test_class", status="status", time=1.0)
    test_suite = TestSuite(name="test_suite_1", hostname="hostname", id="id", package="package", timestamp=datetime.datetime.now())
    test_suite.cases.append(test_case)
    test_suite.properties["property_1"] = "value_1"
    test_suite.system_out = "system_out"
    test_suite.system_err = "system_err"
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == "testsuite"
    assert xml_element.attrib["name"] == "test_suite_1"

# Generated at 2022-06-17 14:33:32.906854
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'property1': 'value1', 'property2': 'value2'}
    test_suite.cases = [TestCase(name='test_case1', assertions=1, classname='test_class1', status='passed', time=decimal.Decimal('1.0')),
                        TestCase(name='test_case2', assertions=2, classname='test_class2', status='passed', time=decimal.Decimal('2.0'))]
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'

    test_su

# Generated at 2022-06-17 14:33:44.721883
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now(), properties={'test_key': 'test_value'}, cases=[TestCase(name='test_case', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1), errors=[TestError(output='test_output', message='test_message', type='test_type')], failures=[TestFailure(output='test_output', message='test_message', type='test_type')], skipped='test_skipped', system_out='test_system_out', system_err='test_system_err')], system_out='test_system_out', system_err='test_system_err')
    assert test

# Generated at 2022-06-17 14:33:52.904913
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name', assertions=1, classname='test_class', status='test_status', time=1.0)
    test_case.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    test_case.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.is_disabled = True


# Generated at 2022-06-17 14:34:02.769643
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_case.time = decimal.Decimal(1.0)
    test_case.classname = 'test_case_classname'
    test_case.status = 'test_case_status'
    test_case.assertions = 1
    test_case.system_out = 'test_case_system_out'
    test_case.system_err = 'test_case_system_err'
    test_case.skipped = 'test_case_skipped'

    test_case_error = TestError(output='test_case_error_output', message='test_case_error_message', type='test_case_error_type')
    test_case.errors.append(test_case_error)


# Generated at 2022-06-17 14:34:10.430831
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_name',
        assertions=1,
        classname='test_class',
        status='test_status',
        time=1.0,
        errors=[TestError(output='test_output', message='test_message', type='test_type')],
        failures=[TestFailure(output='test_output', message='test_message', type='test_type')],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
        is_disabled=True,
    )


# Generated at 2022-06-17 14:34:20.186655
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:31.764309
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'

    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='status', time=1.0)
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
    assert test_case.get_xml_element().attrib['assertions'] == '1'
    assert test_case.get_xml_element().attrib['classname'] == 'test_class_name'

# Generated at 2022-06-17 14:34:43.674126
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    xml_element = test_case.get_xml_element()
    assert xml_element.tag == 'testcase'
    assert xml_element.attrib['name'] == 'test_case_name'
    assert len(xml_element) == 0


# Generated at 2022-06-17 14:34:51.890219
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:03.551582
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:16.093852
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:27.222554
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:37.687867
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:43.194540
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:53.285935
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:57.718860
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'
    test_suite_xml_element = test_suite.get_xml_element()

# Generated at 2022-06-17 14:36:02.619424
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:36:36.617283
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:44.476454
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases.append(TestCase(name='test_case_3'))
    test_suite.cases.append(TestCase(name='test_case_4'))
    test_suite.cases.append(TestCase(name='test_case_5'))
    test_suite.cases.append(TestCase(name='test_case_6'))
    test_suite.cases.append(TestCase(name='test_case_7'))
    test_suite.cases.append(TestCase(name='test_case_8'))

# Generated at 2022-06-17 14:36:50.265025
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:54.612244
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:04.288350
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase name="test_case" />'

    test_case = TestCase(name='test_case', assertions=1, classname='test_class', status='status', time=1.0)
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase assertions="1" classname="test_class" name="test_case" status="status" time="1.0" />'

    test_case = TestCase(name='test_case', errors=[TestError(output='output', message='message', type='type')])

# Generated at 2022-06-17 14:37:15.278650
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:24.490310
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert len(xml_element) == 1
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:32.481353
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:36.408082
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:45.751370
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:24.989806
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:34.380406
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="test_suite_name")
    test_case = TestCase(name="test_case_name")
    test_suite.cases.append(test_case)

    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '1'

    test_case_element = xml_element[0]
    assert test_case_element.tag == 'testcase'
    assert test_case_element.attrib['name'] == 'test_case_name'

# Generated at 2022-06-17 14:38:45.543681
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:50.754723
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    assert test_suite.get_xml_element().find('testcase').get('name') == 'test_case_name'


# Generated at 2022-06-17 14:39:00.033496
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'property1': 'value1', 'property2': 'value2'}
    test_suite.cases = [TestCase(name='test_case1', assertions=1, classname='test_class1', status='passed', time=1.0),
                        TestCase(name='test_case2', assertions=2, classname='test_class2', status='passed', time=2.0)]
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'
    test_suite_xml = test_suite.get_xml_element()

# Generated at 2022-06-17 14:39:09.313682
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite'
    assert xml_element.attrib['tests'] == '0'
    assert xml_element.attrib['disabled'] == '0'
    assert xml_element.attrib['errors'] == '0'
    assert xml_element.attrib['failures'] == '0'
    assert xml_element.attrib['time'] == '0'


# Generated at 2022-06-17 14:39:16.214930
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="test_suite_name", hostname="test_hostname", id="test_id", package="test_package", timestamp=datetime.datetime.now())
    test_suite.properties = {"test_property_name": "test_property_value"}
    test_suite.cases = [TestCase(name="test_case_name", assertions=1, classname="test_classname", status="test_status", time=decimal.Decimal(1.0))]
    test_suite.system_out = "test_system_out"
    test_suite.system_err = "test_system_err"
    test_suite_xml_element = test_suite.get_xml_element()

# Generated at 2022-06-17 14:39:21.036859
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:29.250591
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_suite = TestSuite(name='test_suite_name', cases=[test_case])
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:38.583244
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_suite = TestSuite(name='test_suite_name', cases=[test_case])
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element.attrib['time'] == '0'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:14.162273
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:21.546146
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:30.485236
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name="test_case_name", assertions=1, classname="test_class_name", status="test_status", time=1.0)
    test_suite = TestSuite(name="test_suite_name", hostname="test_hostname", id="test_id", package="test_package", timestamp=datetime.datetime.now(), cases=[test_case])
    test_suite_xml_element = test_suite.get_xml_element()
    assert test_suite_xml_element.tag == "testsuite"
    assert test_suite_xml_element.attrib["name"] == "test_suite_name"
    assert test_suite_xml_element.attrib["hostname"] == "test_hostname"
    assert test_suite_xml_

# Generated at 2022-06-17 14:40:36.597735
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name2'))
    test_suite.cases.append(TestCase(name='test_case_name3'))
    test_suite.cases.append(TestCase(name='test_case_name4'))
    test_suite.cases.append(TestCase(name='test_case_name5'))
    test_suite.cases.append(TestCase(name='test_case_name6'))
    test_suite.cases.append(TestCase(name='test_case_name7'))

# Generated at 2022-06-17 14:40:44.651234
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases.append(TestCase(name='test_case_3'))
    test_suite.cases.append(TestCase(name='test_case_4'))
    test_suite.cases.append(TestCase(name='test_case_5'))
    test_suite.cases.append(TestCase(name='test_case_6'))
    test_suite.cases.append(TestCase(name='test_case_7'))
    test_suite.cases.append(TestCase(name='test_case_8'))

# Generated at 2022-06-17 14:40:54.516521
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:06.779590
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='TestCase', assertions=1, classname='com.example.TestCase', status='PASSED', time=decimal.Decimal('0.001'), errors=[TestError(output='error output', message='error message', type='error type')], failures=[TestFailure(output='failure output', message='failure message', type='failure type')], skipped='skipped', system_out='system out', system_err='system err')], system_out='system out', system_err='system err')
    assert test_suite.get_xml_element().tag == 'testsuite'

# Generated at 2022-06-17 14:41:14.730772
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now())
    suite.properties = {'key1': 'value1', 'key2': 'value2'}
    suite.cases = [TestCase(name='TestCase1', classname='com.example.TestCase1', status='PASSED', time=decimal.Decimal('1.234')),
                   TestCase(name='TestCase2', classname='com.example.TestCase2', status='PASSED', time=decimal.Decimal('2.345'))]
    suite.system_out = 'System out'
    suite.system_err = 'System err'
    element = suite.get_xml_element()
    assert element.tag == 'testsuite'

# Generated at 2022-06-17 14:41:23.893050
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='name', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now())
    test_suite.properties = {'key': 'value'}
    test_suite.cases = [TestCase(name='name', assertions=1, classname='classname', status='status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'name'
    assert xml_element.attrib['hostname'] == 'hostname'

# Generated at 2022-06-17 14:41:32.284549
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key1': 'value1', 'key2': 'value2'}, cases=[TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal(1), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err')], system_out='system_out', system_err='system_err')
    xml_element = test_suite.get_xml_element()

# Generated at 2022-06-17 14:42:28.213891
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name2'))
    test_suite.cases[0].errors.append(TestError(output='test_error_output', message='test_error_message', type='test_error_type'))
    test_suite.cases[0].failures.append(TestFailure(output='test_failure_output', message='test_failure_message', type='test_failure_type'))
    test_suite.cases[0].skipped = 'test_skipped'
    test_suite.cases[0].system_out = 'test_system_out'


# Generated at 2022-06-17 14:42:37.864976
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    test_suite_xml_element = test_suite.get_xml_element()
    assert test_suite_xml_element.tag == 'testsuite'
    assert test_suite_xml_element.attrib['name'] == 'test_suite_name'
    assert test_suite_xml_element[0].tag == 'testcase'
    assert test_suite_xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:42:48.109144
# Unit test for method get_xml_element of class TestSuite