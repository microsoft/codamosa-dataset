

# Generated at 2022-06-17 14:32:54.025447
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:32:55.756935
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:01.868753
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:03.896929
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element().tag == 'result'


# Generated at 2022-06-17 14:33:11.374389
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:14.726377
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:23.250439
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:26.757013
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='TestSuite')
    assert suite.get_xml_element().tag == 'testsuite'
    assert suite.get_xml_element().attrib['name'] == 'TestSuite'


# Generated at 2022-06-17 14:33:32.372160
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:37.440955
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:47.260865
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:49.444793
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:33:52.364543
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:55.690084
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:57.637040
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:34:00.759431
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:11.498026
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:15.182000
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:24.068275
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=2, classname='test_class_name', status='test_status', time=decimal.Decimal(1.2))
    test_case.errors.append(TestError(output='test_error_output', message='test_error_message', type='test_error_type'))
    test_case.failures.append(TestFailure(output='test_failure_output', message='test_failure_message', type='test_failure_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.is_disabled = True


# Generated at 2022-06-17 14:34:34.450866
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:44.718110
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert TestResult(output='output', message='message', type='type').get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:50.634525
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:01.680331
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:05.752072
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib['message'] == 'message'
    assert test_result.get_xml_element().attrib['type'] == 'type'


# Generated at 2022-06-17 14:35:14.928253
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:19.449846
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_name'


# Generated at 2022-06-17 14:35:22.940574
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:26.114922
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:30.586548
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:37.038153
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:53.485245
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(message='Test message', type='Test type', output='Test output')
    assert test_result.get_attributes() == {'message': 'Test message', 'type': 'Test type'}


# Generated at 2022-06-17 14:35:57.240354
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_1')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_1'


# Generated at 2022-06-17 14:36:04.773281
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    element = test_result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.text == 'test_output'
    assert element.attrib['message'] == 'test_message'
    assert element.attrib['type'] == 'test_type'


# Generated at 2022-06-17 14:36:07.945854
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:19.509667
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:21.833575
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:36:28.719384
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:32.898909
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:40.234971
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:36:41.740317
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}


# Generated at 2022-06-17 14:36:58.428427
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:02.934506
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:08.056919
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().attrib == {'message': 'test_message', 'type': 'test_type'}
    assert test_result.get_xml_element().text == 'test_output'


# Generated at 2022-06-17 14:37:11.388861
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_xml_element().tag == "TestResult"


# Generated at 2022-06-17 14:37:15.547867
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    element = result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.attrib == {'message': 'message', 'type': 'type'}
    assert element.text == 'output'


# Generated at 2022-06-17 14:37:20.183153
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib == {'name': 'test_case_name'}


# Generated at 2022-06-17 14:37:22.269625
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:37:24.005271
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element() == ET.Element('testresult')


# Generated at 2022-06-17 14:37:32.376259
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_name',
        assertions=1,
        classname='test_class',
        status='test_status',
        time=1.0,
        errors=[TestError(output='test_output', message='test_message', type='test_type')],
        failures=[TestFailure(output='test_output', message='test_message', type='test_type')],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
        is_disabled=True,
    )
    xml_element = test_case.get_xml_element()
    assert xml_element.tag == 'testcase'

# Generated at 2022-06-17 14:37:39.110693
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Test with all attributes
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'

    # Test with no attributes
    test_result = TestResult()
    assert test_result.get_xml_element().attrib == {}
    assert test_result.get_xml_element().text == ''


# Generated at 2022-06-17 14:37:57.009392
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal('1.0'))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'
    test_suite_xml_element = test_suite.get_xml_element()

# Generated at 2022-06-17 14:38:07.564847
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:15.679683
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:26.343872
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:36.669116
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:45.324459
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(
        name='test_case_1',
        assertions=1,
        classname='test_class_1',
        status='status_1',
        time=1.0,
        errors=[TestError(output='error_1')],
        failures=[TestFailure(output='failure_1')],
        skipped='skipped_1',
        system_out='system_out_1',
        system_err='system_err_1',
        is_disabled=True
    )

# Generated at 2022-06-17 14:38:55.224838
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:01.926924
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now())
    test_suite.properties = {'key': 'value'}
    test_suite.cases = [TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'

    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite'
    assert xml_element.attrib['hostname']

# Generated at 2022-06-17 14:39:12.992883
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:20.502754
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:08.997712
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert len(xml_element) == 1
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:16.984767
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    element = test_suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.attrib['name'] == 'test_suite_name'
    assert element.attrib['tests'] == '1'
    assert element[0].tag == 'testcase'
    assert element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:27.769084
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='testsuite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'name': 'value'}, system_out='system_out', system_err='system_err')
    suite.cases.append(TestCase(name='testcase', assertions=1, classname='classname', status='status', time=decimal.Decimal(1.0), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err'))

# Generated at 2022-06-17 14:40:35.351465
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:40.132011
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name_2'))
    test_suite.cases.append(TestCase(name='test_case_name_3'))
    test_suite.cases.append(TestCase(name='test_case_name_4'))
    test_suite.cases.append(TestCase(name='test_case_name_5'))
    test_suite.cases.append(TestCase(name='test_case_name_6'))
    test_suite.cases.append(TestCase(name='test_case_name_7'))

# Generated at 2022-06-17 14:40:50.828356
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:58.170124
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:09.276694
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:19.077431
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:28.805527
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    element = test_suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.attrib == {'name': 'test_suite_name', 'tests': '1', 'time': '0'}
    assert len(element) == 3
    assert element[0].tag == 'testcase'
    assert element[0].attrib == {'name': 'test_case_name'}
    assert element[1].tag == 'system-out'

# Generated at 2022-06-17 14:42:16.683855
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite_name'


# Generated at 2022-06-17 14:42:24.934013
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now())
    test_suite.properties = {'property1': 'value1', 'property2': 'value2'}
    test_suite.cases = [TestCase(name='test_case1', assertions=1, classname='classname', status='status', time=decimal.Decimal('1.1')),
                        TestCase(name='test_case2', assertions=2, classname='classname', status='status', time=decimal.Decimal('2.2'))]
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'
    assert test_suite.get_xml_

# Generated at 2022-06-17 14:42:35.529831
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'property': 'value'}, cases=[TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal(1), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err')], system_out='system_out', system_err='system_err')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name']

# Generated at 2022-06-17 14:42:47.212648
# Unit test for method get_xml_element of class TestSuite