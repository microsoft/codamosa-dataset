

# Generated at 2022-06-17 14:32:59.704045
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:03.216257
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:06.216708
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='test', message='test', type='test')
    assert result.get_attributes() == {'message': 'test', 'type': 'test'}


# Generated at 2022-06-17 14:33:09.282467
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:14.865135
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:18.576264
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes() == {}
    result = TestResult(message="message", type="type")
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:23.860108
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:34.606563
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:37.991919
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:43.697463
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:55.438277
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:34:04.061080
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=1.1)
    test_case.errors.append(TestError(output='test_error_output', message='test_error_message', type='test_error_type'))
    test_case.failures.append(TestFailure(output='test_failure_output', message='test_failure_message', type='test_failure_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'

    element = test_case.get_xml_element()

    assert element.tag == 'testcase'
    assert element

# Generated at 2022-06-17 14:34:14.539379
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}

# Generated at 2022-06-17 14:34:17.966035
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:20.677466
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:24.092854
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:29.654330
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output = 'test_output', message = 'test_message', type = 'test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:34:36.941118
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:39.834665
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:49.615959
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:18.668261
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:21.867866
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:30.811451
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:44.805562
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:49.126833
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:53.168153
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output="output", message="message", type="type")
    assert result.get_xml_element().tag == "testresult"
    assert result.get_xml_element().text == "output"
    assert result.get_xml_element().attrib == {"message": "message", "type": "type"}


# Generated at 2022-06-17 14:35:56.903669
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:36:02.250224
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:06.131441
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:36:08.649130
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:52.875450
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:58.016427
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:02.849764
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:07.329496
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite'


# Generated at 2022-06-17 14:37:17.069580
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case',
        assertions=1,
        classname='TestClass',
        status='PASSED',
        time=decimal.Decimal('1.234'),
        errors=[TestError(output='error output', message='error message', type='error type')],
        failures=[TestFailure(output='failure output', message='failure message', type='failure type')],
        skipped='skipped',
        system_out='system out',
        system_err='system err',
    )


# Generated at 2022-06-17 14:37:21.469063
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case')
    test_suite = TestSuite(name='test_suite', cases=[test_case])
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:37:29.429523
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal('1.0'), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err', is_disabled=True)], system_out='system_out', system_err='system_err')

# Generated at 2022-06-17 14:37:39.767922
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_suite = TestSuite(name='test_suite_name', cases=[test_case])
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite_name'
    assert test_suite.get_xml_element().attrib['tests'] == '1'
    assert test_suite.get_xml_element().attrib['time'] == '0'
    assert test_suite.get_xml_element()[0].tag == 'testcase'
    assert test_suite.get_xml_element()[0].attrib['name'] == 'test_case_name'
    assert test_suite.get

# Generated at 2022-06-17 14:37:50.021695
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:01.843243
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_case = TestCase(name='test_case')
    test_suite.cases.append(test_case)
    test_suite_element = test_suite.get_xml_element()
    assert test_suite_element.tag == 'testsuite'
    assert test_suite_element.attrib['name'] == 'test_suite'
    assert test_suite_element.attrib['tests'] == '1'
    assert test_suite_element.attrib['time'] == '0'
    assert test_suite_element.attrib['failures'] == '0'
    assert test_suite_element.attrib['errors'] == '0'
    assert test_suite_element.attrib['skipped']

# Generated at 2022-06-17 14:38:23.323741
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == 'test_case_name'
    assert element.text == None
    assert len(element) == 0


# Generated at 2022-06-17 14:38:34.563349
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:40.377590
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:47.242030
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:52.580804
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name="test_case_name")
    assert test_case.get_xml_element().tag == "testcase"
    assert test_case.get_xml_element().attrib["name"] == "test_case_name"


# Generated at 2022-06-17 14:38:56.854708
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:00.972858
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:06.638398
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case_name'}
    assert element.text is None
    assert len(element) == 0


# Generated at 2022-06-17 14:39:15.058357
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='test_package', timestamp=datetime.datetime.now(), properties={'prop1': 'value1'}, cases=[TestCase(name='test_case', assertions=1, classname='test_class', status='passed', time=1.0, errors=[TestError(output='error_output', message='error_message', type='error_type')], failures=[TestFailure(output='failure_output', message='failure_message', type='failure_type')], skipped='skipped_reason', system_out='system_out', system_err='system_err')], system_out='system_out', system_err='system_err')
    xml_element = test_suite.get_xml_element()
    assert xml_

# Generated at 2022-06-17 14:39:26.874127
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:57.705652
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:40:07.146181
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:11.505873
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:20.269242
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name_2'))
    test_suite.cases.append(TestCase(name='test_case_name_3'))
    test_suite.cases.append(TestCase(name='test_case_name_4'))
    test_suite.cases.append(TestCase(name='test_case_name_5'))
    test_suite.cases.append(TestCase(name='test_case_name_6'))
    test_suite.cases.append(TestCase(name='test_case_name_7'))

# Generated at 2022-06-17 14:40:29.761113
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_case.time = decimal.Decimal('1.234')
    test_case.classname = 'test_case_classname'
    test_case.status = 'test_case_status'
    test_case.assertions = 1
    test_case.errors.append(TestError(output='test_case_error_output', message='test_case_error_message', type='test_case_error_type'))
    test_case.failures.append(TestFailure(output='test_case_failure_output', message='test_case_failure_message', type='test_case_failure_type'))
    test_case.skipped = 'test_case_skipped'

# Generated at 2022-06-17 14:40:36.312112
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:44.164496
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(
        name="test_case_name",
        assertions=1,
        classname="test_class_name",
        status="test_status",
        time=decimal.Decimal(1.0),
        errors=[TestError(output="test_output", message="test_message", type="test_type")],
        failures=[TestFailure(output="test_output", message="test_message", type="test_type")],
        skipped="test_skipped",
        system_out="test_system_out",
        system_err="test_system_err",
    )

# Generated at 2022-06-17 14:40:46.727735
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:56.031636
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:00.837333
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases = [TestCase(name='test_case')]
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:41:46.100722
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test', hostname='localhost', id='1', package='test', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='test', assertions=1, classname='test', status='passed', time=1.0, errors=[TestError(output='error', message='error', type='error')], failures=[TestFailure(output='failure', message='failure', type='failure')], skipped='skipped', system_out='system_out', system_err='system_err', is_disabled=False)], system_out='system_out', system_err='system_err')

# Generated at 2022-06-17 14:41:49.555499
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_name'


# Generated at 2022-06-17 14:42:00.705617
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:12.953649
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:22.355237
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_1')
    test_suite = TestSuite(name='test_suite_1', cases=[test_case])
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite_1'
    assert test_suite.get_xml_element().attrib['tests'] == '1'
    assert test_suite.get_xml_element()[0].tag == 'testcase'
    assert test_suite.get_xml_element()[0].attrib['name'] == 'test_case_1'


# Generated at 2022-06-17 14:42:33.425301
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:46.482719
# Unit test for method get_xml_element of class TestSuite