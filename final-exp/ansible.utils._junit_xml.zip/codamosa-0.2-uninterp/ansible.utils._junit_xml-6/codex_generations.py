

# Generated at 2022-06-17 14:32:58.956065
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:08.134855
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:15.426771
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name="test_name", assertions=1, classname="test_class", status="test_status", time=1.0)
    test_case.errors.append(TestError(output="test_output", message="test_message", type="test_type"))
    test_case.failures.append(TestFailure(output="test_output", message="test_message", type="test_type"))
    test_case.skipped = "test_skipped"
    test_case.system_out = "test_system_out"
    test_case.system_err = "test_system_err"
    test_case.is_disabled = True


# Generated at 2022-06-17 14:33:18.501663
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:21.788867
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:26.192570
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:33:32.001436
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:34.638291
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:37.640955
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite')
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'TestSuite'


# Generated at 2022-06-17 14:33:43.670352
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output="Test output", message="Test message", type="Test type")
    assert result.get_xml_element().tag == "TestResult"
    assert result.get_xml_element().text == "Test output"
    assert result.get_xml_element().attrib["message"] == "Test message"
    assert result.get_xml_element().attrib["type"] == "Test type"


# Generated at 2022-06-17 14:33:52.427053
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'result'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:57.351227
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:00.639259
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:06.163691
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}

    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}



# Generated at 2022-06-17 14:34:09.122052
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:12.174974
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:13.895246
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:34:23.249438
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:34.054288
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:38.509688
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:56.524278
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:01.499691
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:06.160177
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:35:09.844907
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'



# Generated at 2022-06-17 14:35:15.112752
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:26.816504
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name2'))
    test_suite.cases.append(TestCase(name='test_case_name3'))
    test_suite.cases.append(TestCase(name='test_case_name4'))
    test_suite.cases.append(TestCase(name='test_case_name5'))
    test_suite.cases.append(TestCase(name='test_case_name6'))
    test_suite.cases.append(TestCase(name='test_case_name7'))

# Generated at 2022-06-17 14:35:31.138387
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:44.893446
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:54.384903
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:02.484614
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:22.540160
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:29.214051
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    test_suite_element = test_suite.get_xml_element()
    assert test_suite_element.tag == 'testsuite'
    assert test_suite_element.attrib['name'] == 'test_suite_name'
    assert test_suite_element.attrib['tests'] == '1'
    assert test_suite_element.attrib['time'] == '0'
    assert test_suite_element.attrib['errors'] == '0'
    assert test_suite_element.attrib['failures'] == '0'

# Generated at 2022-06-17 14:36:32.485257
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:35.549079
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:39.791896
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:42.223022
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:44.514934
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:46.534837
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:36:53.013292
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:03.648598
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.2'),
        errors=[TestError(output='test_error_output', message='test_error_message', type='test_error_type')],
        failures=[TestFailure(output='test_failure_output', message='test_failure_message', type='test_failure_type')],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
        is_disabled=True,
    )


# Generated at 2022-06-17 14:37:56.444514
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_1')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_1'


# Generated at 2022-06-17 14:38:00.847688
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:05.118579
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case')
    test_suite = TestSuite(name='test_suite', cases=[test_case])
    assert test_suite.get_xml_element().find('testcase').attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:38:14.136983
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.0'),
        errors=[
            TestError(
                output='test_error_output',
                message='test_error_message',
                type='test_error_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_failure_output',
                message='test_failure_message',
                type='test_failure_type',
            ),
        ],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )


# Generated at 2022-06-17 14:38:24.953052
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_name',
        assertions=1,
        classname='test_class',
        status='test_status',
        time=decimal.Decimal(1.0),
        errors=[TestError(output='test_output', message='test_message', type='test_type')],
        failures=[TestFailure(output='test_output', message='test_message', type='test_type')],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )


# Generated at 2022-06-17 14:38:29.161567
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:36.088453
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:43.899163
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:53.384449
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:03.079632
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name2'))
    test_suite.cases.append(TestCase(name='test_case_name3'))
    test_suite.cases.append(TestCase(name='test_case_name4'))
    test_suite.cases.append(TestCase(name='test_case_name5'))
    test_suite.cases.append(TestCase(name='test_case_name6'))
    test_suite.cases.append(TestCase(name='test_case_name7'))

# Generated at 2022-06-17 14:40:16.462891
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:19.430432
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:40:29.273208
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now(), properties={'property_name': 'property_value'}, cases=[TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1), errors=[TestError(output='test_output', message='test_message', type='test_type')], failures=[TestFailure(output='test_output', message='test_message', type='test_type')], skipped='test_skipped', system_out='test_system_out', system_err='test_system_err')], system_out='test_system_out', system_err='test_system_err')

# Generated at 2022-06-17 14:40:36.114961
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:43.011468
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_case = TestCase(name='test_case')
    test_suite.cases.append(test_case)
    test_suite_xml_element = test_suite.get_xml_element()
    assert test_suite_xml_element.tag == 'testsuite'
    assert test_suite_xml_element.attrib['name'] == 'test_suite'
    assert test_suite_xml_element[0].tag == 'testcase'
    assert test_suite_xml_element[0].attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:40:46.789605
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite'


# Generated at 2022-06-17 14:40:56.061781
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element.attrib['time'] == '0'
    assert xml_element.attrib['failures'] == '0'
    assert xml_element.attrib['errors'] == '0'
    assert xml_element.attrib['skipped'] == '0'

# Generated at 2022-06-17 14:41:02.068017
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib == {'name': 'test_suite'}


# Generated at 2022-06-17 14:41:11.102586
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases.append(TestCase(name='test_case_3'))
    test_suite.cases.append(TestCase(name='test_case_4'))
    test_suite.cases.append(TestCase(name='test_case_5'))
    test_suite.cases.append(TestCase(name='test_case_6'))
    test_suite.cases.append(TestCase(name='test_case_7'))
    test_suite.cases.append(TestCase(name='test_case_8'))

# Generated at 2022-06-17 14:41:15.103010
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
