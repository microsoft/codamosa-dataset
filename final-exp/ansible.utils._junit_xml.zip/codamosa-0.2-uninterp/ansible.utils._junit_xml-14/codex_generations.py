

# Generated at 2022-06-17 14:32:53.801088
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:32:57.045290
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:01.324262
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:05.668940
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:09.445135
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:16.023613
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Test method get_xml_element of class TestResult."""
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:20.694590
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:22.917115
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:30.024696
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result.message = 'message'
    assert test_result.get_attributes() == {'message': 'message'}
    test_result.type = 'type'
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:32.743182
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element() == ET.Element('testresult')


# Generated at 2022-06-17 14:33:40.373137
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:45.686607
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:49.011885
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:53.121276
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}

    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:33:57.985752
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:00.916519
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:08.440217
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert test_result.get_xml_element().tag == "TestResult"
    assert test_result.get_xml_element().text == "test_output"
    assert test_result.get_xml_element().attrib["message"] == "test_message"
    assert test_result.get_xml_element().attrib["type"] == "test_type"


# Generated at 2022-06-17 14:34:10.916710
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:12.776349
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:34:22.225815
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuiteName')
    test_suite.cases.append(TestCase(name='TestCaseName'))
    test_suite.system_out = 'SystemOut'
    test_suite.system_err = 'SystemErr'
    test_suite.properties['PropertyName'] = 'PropertyValue'

    xml_element = test_suite.get_xml_element()

    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib == {
        'name': 'TestSuiteName',
        'tests': '1',
    }

    assert len(xml_element) == 4
    assert xml_element[0].tag == 'properties'
    assert xml_element[0][0].tag == 'property'

# Generated at 2022-06-17 14:34:30.589719
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:42.797219
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Unit test for method get_xml_element of class TestResult"""
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib['message'] == 'test_message'
    assert test_result.get_xml_element().attrib['type'] == 'test_type'


# Generated at 2022-06-17 14:34:53.939371
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:04.118932
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal(1), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err', is_disabled=True)], system_out='system_out', system_err='system_err')

# Generated at 2022-06-17 14:35:09.581462
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:19.750942
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:31.422788
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:37.767439
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:44.127955
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:48.932654
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output="test output", message="test message", type="test type")
    assert result.get_xml_element().tag == "testresult"
    assert result.get_xml_element().attrib == {'message': 'test message', 'type': 'test type'}
    assert result.get_xml_element().text == "test output"


# Generated at 2022-06-17 14:35:57.754406
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='test', message='test', type='test')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'test'
    assert result.get_xml_element().attrib['message'] == 'test'
    assert result.get_xml_element().attrib['type'] == 'test'


# Generated at 2022-06-17 14:36:04.612273
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:07.870759
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:13.395662
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:16.912399
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:24.887665
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal(1.0),
        errors=[
            TestError(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )


# Generated at 2022-06-17 14:36:28.500868
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:36:32.999208
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().get('message') == 'message'
    assert result.get_xml_element().get('type') == 'type'
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:36:36.652873
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes() == {}
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:39.792609
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes() == {}
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:46.049095
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:49.462816
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:55.874517
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert test_result.get_xml_element().tag == "testresult"
    assert test_result.get_xml_element().attrib == {'message': 'test_message', 'type': 'test_type'}
    assert test_result.get_xml_element().text == "test_output"


# Generated at 2022-06-17 14:37:00.826442
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:04.917245
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite_name'


# Generated at 2022-06-17 14:37:15.621440
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:21.272092
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:26.098744
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:37:28.142908
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:37:31.992174
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:42.995624
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib['message'] == 'message'
    assert result.get_xml_element().attrib['type'] == 'type'


# Generated at 2022-06-17 14:37:46.433633
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='test_output', message='test_message', type='test_type')
    assert result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:37:50.193551
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}

    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:52.514600
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:56.444546
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_name'


# Generated at 2022-06-17 14:38:03.265501
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    test_suite_xml = test_suite.get_xml_element()
    assert test_suite_xml.tag == 'testsuite'
    assert test_suite_xml.attrib['name'] == 'test_suite_name'
    assert test_suite_xml.attrib['tests'] == '1'
    assert test_suite_xml[0].tag == 'testcase'
    assert test_suite_xml[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:07.778562
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:10.322509
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:16.292867
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:26.744897
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case', assertions=1, classname='test_class', status='passed', time=1.0)
    test_suite = TestSuite(name='test_suite', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now(), cases=[test_case])

# Generated at 2022-06-17 14:38:37.504089
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:41.981432
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:44.500273
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="test output", message="test message", type="test type")
    assert test_result.get_attributes() == {'message': 'test message', 'type': 'test type'}


# Generated at 2022-06-17 14:38:51.089775
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib['message'] == 'test_message'
    assert test_result.get_xml_element().attrib['type'] == 'test_type'


# Generated at 2022-06-17 14:38:55.016753
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="test", message="test", type="test")
    assert test_result.get_attributes() == {'message': 'test', 'type': 'test'}


# Generated at 2022-06-17 14:39:04.183819
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='com.example.test', timestamp=datetime.datetime.now())
    suite.properties['foo'] = 'bar'
    suite.cases.append(TestCase(name='test_case', assertions=1, classname='com.example.test.TestCase', status='PASSED', time=decimal.Decimal('1.234')))
    suite.system_out = 'system out'
    suite.system_err = 'system err'

    xml = suite.get_xml_element()
    assert xml.tag == 'testsuite'
    assert xml.attrib['name'] == 'test_suite'
    assert xml.attrib['hostname'] == 'localhost'
    assert xml.attrib['id'] == '1'


# Generated at 2022-06-17 14:39:09.525746
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:13.612716
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test output', message='test message', type='test type')
    assert test_result.get_attributes() == {'message': 'test message', 'type': 'test type'}


# Generated at 2022-06-17 14:39:15.317186
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}


# Generated at 2022-06-17 14:39:19.156903
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:39.355146
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:39:43.099924
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:47.372871
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:51.734087
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Test with no output
    result = TestResult()
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == None

    # Test with output
    result = TestResult(output='output')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:39:55.801756
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == None
    assert result.get_xml_element().attrib == {}


# Generated at 2022-06-17 14:40:04.590780
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_suite = TestSuite(name='test_suite_name', cases=[test_case])
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite_name'
    assert test_suite.get_xml_element().attrib['tests'] == '1'
    assert test_suite.get_xml_element()[0].tag == 'testcase'
    assert test_suite.get_xml_element()[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:08.872342
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:40:12.857832
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:19.960383
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Test with no output
    test_result = TestResult()
    assert test_result.get_xml_element().text == None
    # Test with output
    test_result = TestResult(output="output")
    assert test_result.get_xml_element().text == "output"
    # Test with message
    test_result = TestResult(message="message")
    assert test_result.get_xml_element().attrib["message"] == "message"
    # Test with type
    test_result = TestResult(type="type")
    assert test_result.get_xml_element().attrib["type"] == "type"


# Generated at 2022-06-17 14:40:23.754192
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test', message='test', type='test')
    assert test_result.get_xml_element().tag == 'test'
    assert test_result.get_xml_element().text == 'test'
    assert test_result.get_xml_element().attrib['message'] == 'test'
    assert test_result.get_xml_element().attrib['type'] == 'test'


# Generated at 2022-06-17 14:41:17.668947
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:27.844323
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="TestSuite1", hostname="localhost", id="1", package="package1", timestamp=datetime.datetime.now())
    test_suite.properties = {"property1": "value1", "property2": "value2"}
    test_suite.cases = [TestCase(name="TestCase1", assertions=1, classname="class1", status="status1", time=1.1),
                        TestCase(name="TestCase2", assertions=2, classname="class2", status="status2", time=2.2)]
    test_suite.system_out = "system_out"
    test_suite.system_err = "system_err"

    xml_element = test_suite.get_xml_element()

# Generated at 2022-06-17 14:41:38.028681
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:44.996914
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:54.372552
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:59.586413
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:07.281957
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:17.516288
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:28.710108
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:33.470821
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib == {'name': 'test_suite_name'}
