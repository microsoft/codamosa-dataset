

# Generated at 2022-06-17 14:33:00.202207
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib['message'] == 'message'
    assert result.get_xml_element().attrib['type'] == 'type'


# Generated at 2022-06-17 14:33:04.339903
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:33:08.534555
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:15.648348
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:18.682426
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:21.985892
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:32.994203
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:35.158324
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:42.225978
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:47.016991
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes() == {}
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:59.060972
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:34:10.247664
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:13.840061
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:34:18.185890
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib['message'] == 'test_message'
    assert test_result.get_xml_element().attrib['type'] == 'test_type'


# Generated at 2022-06-17 14:34:25.346055
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', classname='test_case_classname', time=0.1)
    test_case.errors.append(TestError(output='error_output', message='error_message', type='error_type'))
    test_case.failures.append(TestFailure(output='failure_output', message='failure_message', type='failure_type'))
    test_case.skipped = 'skipped_reason'
    test_case.system_out = 'system_out'
    test_case.system_err = 'system_err'


# Generated at 2022-06-17 14:34:35.001092
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:39.379965
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:42.450240
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:46.285785
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:50.083897
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:15.233263
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:35:19.349764
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:23.725569
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:30.231135
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    element = result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.attrib['message'] == 'message'
    assert element.attrib['type'] == 'type'
    assert element.text == 'output'


# Generated at 2022-06-17 14:35:32.209113
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_xml_element().tag == "TestResult"


# Generated at 2022-06-17 14:35:39.280711
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:41.736640
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:35:46.969436
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:51.647356
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:54.840904
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:52.167821
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_name'


# Generated at 2022-06-17 14:36:59.925259
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases[1].errors.append(TestError(output='error_output'))
    test_suite.cases[1].failures.append(TestFailure(output='failure_output'))
    test_suite.cases[1].skipped = 'skipped_reason'
    test_suite.cases[1].system_out = 'system_out'
    test_suite.cases[1].system_err = 'system_err'
    test_suite.system_out = 'system_out'
    test_suite.system_err

# Generated at 2022-06-17 14:37:04.378361
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite'


# Generated at 2022-06-17 14:37:08.624573
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:16.514637
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_1', assertions=1, classname='test_class_1', status='status_1', time=1.0)
    test_suite = TestSuite(name='test_suite_1', hostname='hostname_1', id='id_1', package='package_1', timestamp=datetime.datetime.now(), properties={'key_1': 'value_1'}, cases=[test_case], system_out='system_out_1', system_err='system_err_1')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:37:27.303570
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case',
        assertions=1,
        classname='TestCase',
        status='passed',
        time=decimal.Decimal('0.001'),
        errors=[
            TestError(
                output='error output',
                message='error message',
                type='error type',
            ),
        ],
        failures=[
            TestFailure(
                output='failure output',
                message='failure message',
                type='failure type',
            ),
        ],
        skipped='skipped',
        system_out='system out',
        system_err='system err',
    )

    assert test_case.get_xml_element().tag == 'testcase'

# Generated at 2022-06-17 14:37:30.930976
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == 'test_case_name'
    assert element.text == None
    assert element.tail == None
    assert len(element) == 0


# Generated at 2022-06-17 14:37:34.613876
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:44.837834
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:56.395167
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:35.829791
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:40.308089
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:46.691130
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:58.442939
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='tests', timestamp=datetime.datetime.now())
    suite.properties['key'] = 'value'
    suite.cases.append(TestCase(name='test_case', assertions=1, classname='TestCase', status='PASS', time=decimal.Decimal(1.0)))
    suite.system_out = 'system_out'
    suite.system_err = 'system_err'

    element = suite.get_xml_element()
    assert element.tag == 'testsuite'

# Generated at 2022-06-17 14:39:01.582533
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:12.882332
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases[1].errors.append(TestError(output='error_output', message='error_message'))
    test_suite.cases[1].failures.append(TestFailure(output='failure_output', message='failure_message'))
    test_suite.cases[1].skipped = 'skipped_message'
    test_suite.cases[1].system_out = 'system_out_message'
    test_suite.cases[1].system_err = 'system_err_message'
    test_suite.system_

# Generated at 2022-06-17 14:39:20.442420
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:24.608697
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:30.580262
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite'
    assert len(xml_element) == 1
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:39:34.638206
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:44.104889
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case'

# Generated at 2022-06-17 14:40:52.671884
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert len(xml_element) == 1
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'

# Generated at 2022-06-17 14:40:55.945858
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_name'


# Generated at 2022-06-17 14:41:07.901568
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:17.912229
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:23.979702
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite_xml = test_suite.get_xml_element()
    assert test_suite_xml.tag == 'testsuite'
    assert test_suite_xml.attrib['name'] == 'test_suite_name'
    assert test_suite_xml.attrib['tests'] == '0'


# Generated at 2022-06-17 14:41:34.518672
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=decimal.Decimal(1.0))
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.cases.append(test_case)
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'
    test_suite.properties = {'test_property_name': 'test_property_value'}


# Generated at 2022-06-17 14:41:45.901660
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:55.207880
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:05.390721
# Unit test for method get_xml_element of class TestCase