

# Generated at 2022-06-17 14:32:58.610072
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='suite', hostname='localhost', id='1', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='case', assertions=1, classname='class', status='status', time=decimal.Decimal('1.0'), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err', is_disabled=True)], system_out='system_out', system_err='system_err')
    assert suite.get_xml_element().tag == 'testsuite'
    assert suite.get_xml_element().attrib['name'] == 'suite'
   

# Generated at 2022-06-17 14:33:03.345924
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:33:11.138233
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:20.964265
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_suite_hostname', id='test_suite_id', package='test_suite_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'key1': 'value1', 'key2': 'value2'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_case_classname', status='test_case_status', time=decimal.Decimal('1.0')), TestCase(name='test_case_name2', assertions=2, classname='test_case_classname2', status='test_case_status2', time=decimal.Decimal('2.0'))]
    test_suite.system

# Generated at 2022-06-17 14:33:25.193430
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:33:30.386750
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'



# Generated at 2022-06-17 14:33:44.209794
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal('1.0'), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err')], system_out='system_out', system_err='system_err')

# Generated at 2022-06-17 14:33:52.627163
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case', assertions=1, classname='classname', status='status', time=1.0)
    test_case.errors.append(TestError(output='output', message='message', type='type'))
    test_case.failures.append(TestFailure(output='output', message='message', type='type'))
    test_case.skipped = 'skipped'
    test_case.system_out = 'system_out'
    test_case.system_err = 'system_err'

    assert test_case.get_xml_element().attrib == {'assertions': '1', 'classname': 'classname', 'name': 'test_case', 'status': 'status', 'time': '1.0'}
    assert test_case.get_xml_element().find

# Generated at 2022-06-17 14:34:02.598022
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_case_classname',
        status='test_case_status',
        time=decimal.Decimal('1.0'),
        errors=[TestError(output='error_output', message='error_message', type='error_type')],
        failures=[TestFailure(output='failure_output', message='failure_message', type='failure_type')],
        skipped='test_case_skipped',
        system_out='test_case_system_out',
        system_err='test_case_system_err',
    )


# Generated at 2022-06-17 14:34:07.497121
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:23.842858
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name='test_suite',
        hostname='localhost',
        id='1',
        package='test_package',
        timestamp=datetime.datetime.now(),
        properties={'key': 'value'},
        cases=[TestCase(name='test_case')],
        system_out='system_out',
        system_err='system_err',
    )


# Generated at 2022-06-17 14:34:28.430991
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:32.387449
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:38.584149
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:48.453885
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:52.319159
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:57.294827
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib == {'name': 'test_case_name'}


# Generated at 2022-06-17 14:35:02.025315
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_case = TestCase(name='test_case')
    test_suite.cases.append(test_case)
    assert test_suite.get_xml_element().find('testcase').get('name') == 'test_case'


# Generated at 2022-06-17 14:35:10.579263
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.0'),
        errors=[
            TestError(
                output='test_error_output',
                message='test_error_message',
                type='test_error_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_failure_output',
                message='test_failure_message',
                type='test_failure_type',
            ),
        ],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )


# Generated at 2022-06-17 14:35:15.592513
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case_name'}
    assert element.text == None
    assert len(element) == 0


# Generated at 2022-06-17 14:35:23.530139
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name="test_case_name")
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:27.585424
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:35:32.399175
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:38.894490
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case')
    test_suite = TestSuite(name='test_suite', cases=[test_case])
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:35:43.407731
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:35:53.320681
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name', assertions=1, classname='test_classname', status='test_status', time=1.0)
    test_case.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    test_case.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'

    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['assertions'] == '1'
    assert test_

# Generated at 2022-06-17 14:35:55.357057
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:01.017777
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.23'),
        errors=[
            TestError(
                output='error_output',
                message='error_message',
                type='error_type',
            ),
        ],
        failures=[
            TestFailure(
                output='failure_output',
                message='failure_message',
                type='failure_type',
            ),
        ],
        skipped='skipped_message',
        system_out='system_out_message',
        system_err='system_err_message',
    )


# Generated at 2022-06-17 14:36:08.639730
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    element = test_suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.attrib['name'] == 'test_suite_name'
    assert element.attrib['tests'] == '1'
    assert element[0].tag == 'testcase'
    assert element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:19.940829
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name', assertions=1, classname='test_class', status='test_status', time=1.0)
    test_case.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    test_case.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.is_disabled = True

    assert test_case.get_xml_element().tag == 'testcase'

# Generated at 2022-06-17 14:36:30.544054
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test_suite')
    suite.cases.append(TestCase(name='test_case'))
    suite.system_out = 'system_out'
    suite.system_err = 'system_err'
    suite.properties['property_name'] = 'property_value'
    suite.timestamp = datetime.datetime.now()

    element = suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.attrib['name'] == 'test_suite'
    assert element.attrib['tests'] == '1'
    assert element.attrib['timestamp'] == suite.timestamp.isoformat(timespec='seconds')

    assert element[0].tag == 'properties'
    assert element[0][0].tag == 'property'
    assert element

# Generated at 2022-06-17 14:36:34.100671
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:36:39.613026
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:45.514971
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:48.709664
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:36:52.265211
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:36:55.877600
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:04.800999
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case'}
    assert element.text is None
    assert len(element) == 0

    test_case = TestCase(name='test_case', assertions=1, classname='TestCase', status='status', time=decimal.Decimal('1.234'))
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'assertions': '1', 'classname': 'TestCase', 'name': 'test_case', 'status': 'status', 'time': '1.234'}
    assert element.text is None

# Generated at 2022-06-17 14:37:08.134132
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().get('name') == 'test_case'


# Generated at 2022-06-17 14:37:17.562279
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'
    test_suite_xml = test_suite.get_xml_element()
    assert test_suite_xml.tag == 'testsuite'
    assert test_suite_xml.attrib['name'] == 'test_suite_name'
    assert test_suite_xml.attrib['tests'] == '1'
    assert test_suite_xml.attrib['time'] == '0.0'

# Generated at 2022-06-17 14:37:27.016144
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:33.541769
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:40.277611
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='TestCase')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'TestCase'}
    assert element.text is None
    assert len(element) == 0


# Generated at 2022-06-17 14:37:50.258848
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'property1': 'value1', 'property2': 'value2'}
    test_case1 = TestCase(name='test_case1', assertions=1, classname='test_class1', status='passed', time=decimal.Decimal(1.0))
    test_case2 = TestCase(name='test_case2', assertions=2, classname='test_class2', status='failed', time=decimal.Decimal(2.0))
    test_case2.failures.append(TestFailure(output='failure_output', message='failure_message', type='failure_type'))
   

# Generated at 2022-06-17 14:37:54.649629
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name="test_case_name")
    assert test_case.get_xml_element().tag == "testcase"
    assert test_case.get_xml_element().attrib["name"] == "test_case_name"


# Generated at 2022-06-17 14:37:57.018723
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:37:59.151631
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_name'


# Generated at 2022-06-17 14:38:09.110364
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:13.775254
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:24.690514
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:41.775706
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:44.593502
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == 'test_case_name'
    assert element.text is None


# Generated at 2022-06-17 14:38:48.222548
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:58.752959
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='TestCase', assertions=1, classname='TestClass', status='PASSED', time=decimal.Decimal('0.1'), errors=[TestError(output='Error', message='Error message', type='ErrorType')], failures=[TestFailure(output='Failure', message='Failure message', type='FailureType')], skipped='Skipped', system_out='System out', system_err='System err')], system_out='System out', system_err='System err')
    assert test_suite.get_xml_element().tag == 'testsuite'

# Generated at 2022-06-17 14:39:02.409035
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
    assert test_case.get_xml_element().text is None


# Generated at 2022-06-17 14:39:07.026336
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:10.899376
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:12.597735
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:19.723000
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    test_case.time = decimal.Decimal(1.23)
    test_case.classname = 'test_classname'
    test_case.status = 'test_status'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.skipped = 'test_skipped'
    test_case.errors.append(TestError(output='test_error_output', message='test_error_message', type='test_error_type'))
    test_case.failures.append(TestFailure(output='test_failure_output', message='test_failure_message', type='test_failure_type'))


# Generated at 2022-06-17 14:39:22.557620
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:39.857445
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib == {'name': 'test_case_name'}


# Generated at 2022-06-17 14:39:42.433246
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:53.597609
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testcase = TestCase(name='test_name', assertions=1, classname='test_class', status='test_status', time=1.0)
    testcase.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    testcase.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    testcase.skipped = 'test_skipped'
    testcase.system_out = 'test_system_out'
    testcase.system_err = 'test_system_err'
    testcase.is_disabled = True

    assert testcase.get_xml_element().tag == 'testcase'
    assert testcase.get_xml_element().attrib['assertions'] == '1'
    assert test

# Generated at 2022-06-17 14:40:03.881623
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element() == ET.Element('testcase', {'name': 'test_case_name'})

    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='status', time=1.0)
    assert test_case.get_xml_element() == ET.Element('testcase', {'assertions': '1', 'classname': 'test_class_name', 'name': 'test_case_name', 'status': 'status', 'time': '1.0'})

    test_case = TestCase(name='test_case_name', errors=[TestError(output='output', message='message', type='type')])
    assert test_case.get_xml

# Generated at 2022-06-17 14:40:06.951091
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:10.988293
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:40:15.024269
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    xml_element = test_case.get_xml_element()
    assert xml_element.tag == 'testcase'
    assert xml_element.attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:21.848718
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case'}
    assert element.text is None
    assert len(element) == 0

    test_case = TestCase(name='test_case', assertions=1, classname='TestCase', status='status', time=1.0)
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case', 'assertions': '1', 'classname': 'TestCase', 'status': 'status', 'time': '1.0'}
    assert element.text is None
    assert len(element) == 0



# Generated at 2022-06-17 14:40:30.700666
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_case.time = decimal.Decimal('1.234')
    test_case.classname = 'test_class_name'
    test_case.status = 'test_status'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.skipped = 'test_skipped'
    test_case.assertions = 1

    error = TestError(output='test_error_output', message='test_error_message', type='test_error_type')
    test_case.errors.append(error)

    failure = TestFailure(output='test_failure_output', message='test_failure_message', type='test_failure_type')


# Generated at 2022-06-17 14:40:37.370322
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:49.996836
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:40:55.421327
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:41:00.386924
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:41:10.513015
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.2'),
        errors=[TestError(output='test_output', message='test_message', type='test_type')],
        failures=[TestFailure(output='test_output', message='test_message', type='test_type')],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
        is_disabled=True,
    )


# Generated at 2022-06-17 14:41:14.519033
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == 'test_case_name'
    assert element.text == None
    assert element.tail == None
    assert len(element) == 0


# Generated at 2022-06-17 14:41:15.932457
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:41:18.827623
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:41:22.478759
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:41:28.218111
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=decimal.Decimal('1.0'))
    test_case.errors.append(TestError(output='test_error_output', message='test_error_message', type='test_error_type'))
    test_case.failures.append(TestFailure(output='test_failure_output', message='test_failure_message', type='test_failure_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'

    element = test_case.get_xml_element()


# Generated at 2022-06-17 14:41:32.397254
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_name'


# Generated at 2022-06-17 14:41:52.402931
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case',
        assertions=1,
        classname='TestCase',
        status='status',
        time=decimal.Decimal('1.0'),
        errors=[TestError(output='error_output', message='error_message', type='error_type')],
        failures=[TestFailure(output='failure_output', message='failure_message', type='failure_type')],
        skipped='skipped',
        system_out='system_out',
        system_err='system_err',
    )


# Generated at 2022-06-17 14:41:55.460558
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:42:05.567270
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_name',
        assertions=1,
        classname='test_classname',
        status='test_status',
        time=decimal.Decimal('1.1'),
        errors=[TestError(output='test_output', message='test_message', type='test_type')],
        failures=[TestFailure(output='test_output', message='test_message', type='test_type')],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
        is_disabled=True,
    )


# Generated at 2022-06-17 14:42:08.696093
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:42:12.636243
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:42:16.975843
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:42:25.245163
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case',
        assertions=1,
        classname='TestCase',
        status='status',
        time=1.0,
        errors=[
            TestError(
                output='output',
                message='message',
                type='type',
            ),
        ],
        failures=[
            TestFailure(
                output='output',
                message='message',
                type='type',
            ),
        ],
        skipped='skipped',
        system_out='system_out',
        system_err='system_err',
    )

    assert test_case.get_xml_element().tag == 'testcase'

# Generated at 2022-06-17 14:42:30.102432
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', classname='test_case_classname', time=1.0)
    assert test_case.get_xml_element().attrib == {'name': 'test_case_name', 'classname': 'test_case_classname', 'time': '1.0'}


# Generated at 2022-06-17 14:42:34.300520
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:42:40.720049
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name="test_case_name")
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
