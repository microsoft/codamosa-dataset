

# Generated at 2022-06-17 14:32:54.766105
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:32:58.373500
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:07.999189
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:09.474669
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element() is not None


# Generated at 2022-06-17 14:33:12.084544
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test output', message='test message', type='test type')
    assert test_result.get_attributes() == {'message': 'test message', 'type': 'test type'}


# Generated at 2022-06-17 14:33:21.832851
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name='test_suite',
        hostname='hostname',
        id='id',
        package='package',
        timestamp=datetime.datetime.now(),
        properties={'key': 'value'},
        cases=[TestCase(name='test_case')],
        system_out='system_out',
        system_err='system_err',
    )

    assert test_suite.get_xml_element().tag == 'testsuite'

# Generated at 2022-06-17 14:33:25.002854
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:31.615558
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert test_result.get_xml_element().tag == "testresult"
    assert test_result.get_xml_element().text == "test_output"
    assert test_result.get_xml_element().attrib == {"message": "test_message", "type": "test_type"}


# Generated at 2022-06-17 14:33:33.402478
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(message='message', type='type', output='output')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:39.012320
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=1.0)
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now(), properties={'test_property': 'test_value'}, cases=[test_case], system_out='test_system_out', system_err='test_system_err')
    test_suites = TestSuites(name='test_suites_name', suites=[test_suite])

# Generated at 2022-06-17 14:33:55.058575
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:56.773352
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:05.268460
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_name',
        assertions=1,
        classname='test_class',
        status='test_status',
        time=1.0,
        errors=[TestError(output='test_output', message='test_message', type='test_type')],
        failures=[TestFailure(output='test_output', message='test_message', type='test_type')],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
        is_disabled=True,
    )


# Generated at 2022-06-17 14:34:14.987916
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_case.time = decimal.Decimal('1.234')
    test_case.classname = 'test_case_classname'
    test_case.status = 'test_case_status'
    test_case.assertions = 123
    test_case.system_out = 'test_case_system_out'
    test_case.system_err = 'test_case_system_err'
    test_case.skipped = 'test_case_skipped'
    test_case.errors.append(TestError(output='test_case_error_output', message='test_case_error_message', type='test_case_error_type'))

# Generated at 2022-06-17 14:34:19.205762
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:24.883808
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test output', message='test message', type='test type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'test message', 'type': 'test type'}
    assert test_result.get_xml_element().text == 'test output'


# Generated at 2022-06-17 14:34:28.599296
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}



# Generated at 2022-06-17 14:34:35.936839
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    test_suite_xml = test_suite.get_xml_element()
    assert test_suite_xml.tag == 'testsuite'
    assert test_suite_xml.attrib['name'] == 'test_suite_name'
    assert len(test_suite_xml) == 1
    assert test_suite_xml[0].tag == 'testcase'
    assert test_suite_xml[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:44.675322
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="test_suite")
    test_case = TestCase(name="test_case")
    test_suite.cases.append(test_case)
    test_suite_xml = test_suite.get_xml_element()
    assert test_suite_xml.tag == "testsuite"
    assert test_suite_xml.attrib["name"] == "test_suite"
    assert test_suite_xml[0].tag == "testcase"
    assert test_suite_xml[0].attrib["name"] == "test_case"


# Generated at 2022-06-17 14:34:49.529097
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:02.676844
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:05.820400
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:08.590512
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:11.960124
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:35:14.129228
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:18.896301
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:22.057919
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:25.993558
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:35:30.435482
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:34.485822
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib['message'] == 'message'
    assert result.get_xml_element().attrib['type'] == 'type'


# Generated at 2022-06-17 14:36:07.099810
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:12.283606
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:21.987529
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:28.845457
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case_name'}
    assert element.text is None
    assert len(element) == 0

    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='status', time=1.1)
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case_name', 'assertions': '1', 'classname': 'test_class_name', 'status': 'status', 'time': '1.1'}
    assert element

# Generated at 2022-06-17 14:36:31.575939
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:36:43.504013
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_suite = TestSuite(name='test_suite_name', cases=[test_case])
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:51.329660
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=decimal.Decimal(1.1))
    test_case.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    test_case.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.is_disabled = True


# Generated at 2022-06-17 14:36:59.550709
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases.append(TestCase(name='test_case_3'))
    test_suite.cases.append(TestCase(name='test_case_4'))
    test_suite.cases.append(TestCase(name='test_case_5'))
    test_suite.cases.append(TestCase(name='test_case_6'))
    test_suite.cases.append(TestCase(name='test_case_7'))
    test_suite.cases.append(TestCase(name='test_case_8'))

# Generated at 2022-06-17 14:37:07.611022
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:11.622852
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:37:28.637260
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:34.491540
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    xml_element = test_case.get_xml_element()
    assert xml_element.tag == 'testcase'
    assert xml_element.attrib['name'] == 'test_name'
    assert xml_element.text == None
    assert len(xml_element) == 0


# Generated at 2022-06-17 14:37:44.791925
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:56.339849
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name2'))
    test_suite.cases.append(TestCase(name='test_case_name3'))
    test_suite.cases.append(TestCase(name='test_case_name4'))
    test_suite.cases.append(TestCase(name='test_case_name5'))
    test_suite.cases.append(TestCase(name='test_case_name6'))
    test_suite.cases.append(TestCase(name='test_case_name7'))

# Generated at 2022-06-17 14:38:07.014277
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib

# Generated at 2022-06-17 14:38:15.221013
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:19.492515
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:30.241937
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_case_classname',
        status='test_case_status',
        time=1.1,
        errors=[TestError(output='test_case_error_output', message='test_case_error_message', type='test_case_error_type')],
        failures=[TestFailure(output='test_case_failure_output', message='test_case_failure_message', type='test_case_failure_type')],
        skipped='test_case_skipped',
        system_out='test_case_system_out',
        system_err='test_case_system_err',
    )

# Generated at 2022-06-17 14:38:36.659265
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:44.234471
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_name',
        assertions=1,
        classname='test_class',
        status='test_status',
        time=1.0,
        errors=[TestError(output='test_output', message='test_message', type='test_type')],
        failures=[TestFailure(output='test_output', message='test_message', type='test_type')],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
        is_disabled=True
    )


# Generated at 2022-06-17 14:39:14.328153
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:21.104193
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:30.471504
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:43.867739
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=1.0)
    test_case.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    test_case.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.is_disabled = True

    element = test_case.get_xml_element()

    assert element.tag == 'testcase'

# Generated at 2022-06-17 14:39:54.952385
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:59.304472
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_suite = TestSuite(name='test_suite_name', cases=[test_case])
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:03.421147
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib == {'name': 'test_suite_name'}


# Generated at 2022-06-17 14:40:10.581724
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:16.254053
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:27.607367
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case',
        assertions=1,
        classname='test_class',
        status='passed',
        time=decimal.Decimal('1.234'),
        errors=[
            TestError(
                output='error_output',
                message='error_message',
                type='error_type',
            ),
        ],
        failures=[
            TestFailure(
                output='failure_output',
                message='failure_message',
                type='failure_type',
            ),
        ],
        skipped='skipped_output',
        system_out='system_out',
        system_err='system_err',
    )


# Generated at 2022-06-17 14:41:05.694925
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_case = TestCase(name='test_case')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:41:13.864660
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    test_case.errors.append(TestError(output='error_output', message='error_message', type='error_type'))
    test_case.failures.append(TestFailure(output='failure_output', message='failure_message', type='failure_type'))
    test_case.skipped = 'skipped_message'
    test_case.system_out = 'system_out'
    test_case.system_err = 'system_err'


# Generated at 2022-06-17 14:41:23.386662
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'
    test_suite_xml_element = test_suite.get_xml_element()

# Generated at 2022-06-17 14:41:31.933775
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:43.943088
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:41:53.843029
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal('1.0'))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().att

# Generated at 2022-06-17 14:41:56.949037
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:42:06.522685
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase name="test_case_name" />'

    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='status', time=1.0)
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase assertions="1" classname="test_class_name" name="test_case_name" status="status" time="1.0" />'


# Generated at 2022-06-17 14:42:17.031863
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.234'),
        errors=[
            TestError(
                output='test_error_output',
                message='test_error_message',
                type='test_error_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_failure_output',
                message='test_failure_message',
                type='test_failure_type',
            ),
        ],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )


# Generated at 2022-06-17 14:42:20.938678
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
