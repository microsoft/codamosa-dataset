

# Generated at 2022-06-17 14:33:01.758812
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert test_result.get_xml_element().tag == "testresult"
    assert test_result.get_xml_element().text == "test_output"
    assert test_result.get_xml_element().attrib == {"message": "test_message", "type": "test_type"}


# Generated at 2022-06-17 14:33:06.352294
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == 'test_case_name'
    assert element.text == None
    assert element.tail == None
    assert len(element) == 0


# Generated at 2022-06-17 14:33:10.113507
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:33:12.843876
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:33:15.628019
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='test', message='test', type='test')
    assert result.get_attributes() == {'message': 'test', 'type': 'test'}


# Generated at 2022-06-17 14:33:23.589910
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:29.575226
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'TestResult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib['message'] == 'message'
    assert result.get_xml_element().attrib['type'] == 'type'


# Generated at 2022-06-17 14:33:33.801100
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:33:38.069891
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:48.968842
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_case_classname', status='test_case_status', time=1.0)
    test_suite = TestSuite(name='test_suite_name', hostname='test_suite_hostname', id='test_suite_id', package='test_suite_package', timestamp=datetime.datetime.now())
    test_suite.cases.append(test_case)
    test_suite.system_out = 'test_suite_system_out'
    test_suite.system_err = 'test_suite_system_err'
    test_suite.properties = {'test_suite_property_name': 'test_suite_property_value'}
    xml_element = test_

# Generated at 2022-06-17 14:33:57.130659
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:34:01.693928
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'result'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:34:13.014344
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '0'
    assert xml_element.attrib['errors'] == '0'
    assert xml_element.attrib['failures'] == '0'
    assert xml_element.attrib['disabled'] == '0'
    assert xml_element.attrib['skipped'] == '0'
    assert xml_element.attrib['time'] == '0'
    assert xml_element.attrib['timestamp'] == ''
    assert xml_element.attrib['hostname'] == ''

# Generated at 2022-06-17 14:34:16.353497
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().attrib == {'message': 'test_message', 'type': 'test_type'}
    assert test_result.get_xml_element().text == 'test_output'


# Generated at 2022-06-17 14:34:20.761606
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output="output", message="message", type="type")
    assert result.get_xml_element().tag == "testresult"
    assert result.get_xml_element().text == "output"
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:24.153314
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:31.361217
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib['message'] == 'test_message'
    assert test_result.get_xml_element().attrib['type'] == 'test_type'


# Generated at 2022-06-17 14:34:44.936945
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name', assertions=1, classname='test_class', status='test_status', time=1.0)
    test_case.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    test_case.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'

    element = test_case.get_xml_element()

    assert element.tag == 'testcase'

# Generated at 2022-06-17 14:34:50.493331
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    element = result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.text == 'output'
    assert element.attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:59.581518
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.0'),
        errors=[
            TestError(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )


# Generated at 2022-06-17 14:35:11.153648
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:35:20.744539
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:23.670969
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:35.478402
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:43.114617
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:47.099539
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:50.875276
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:59.963442
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='test_output')
    assert test_result.get_attributes() == {}
    test_result = TestResult(message='test_message')
    assert test_result.get_attributes() == {'message': 'test_message'}
    test_result = TestResult(type='test_type')
    assert test_result.get_attributes() == {'type': 'test_type'}
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:36:04.007919
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:07.458503
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:27.232668
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:31.796303
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_xml_element().tag == "TestResult"
    assert test_result.get_xml_element().text == "output"
    assert test_result.get_xml_element().attrib["message"] == "message"
    assert test_result.get_xml_element().attrib["type"] == "type"


# Generated at 2022-06-17 14:36:41.011949
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', classname='test_case_classname', time=0.1)
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib == {'name': 'test_case_name', 'classname': 'test_case_classname', 'time': '0.1'}


# Generated at 2022-06-17 14:36:44.413942
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:47.063003
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:36:53.804669
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_xml_element().tag == "TestResult"
    assert test_result.get_xml_element().text == "output"
    assert test_result.get_xml_element().attrib == {"message": "message", "type": "type"}


# Generated at 2022-06-17 14:37:00.458013
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib['message'] == 'test_message'
    assert test_result.get_xml_element().attrib['type'] == 'test_type'


# Generated at 2022-06-17 14:37:05.377548
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert test_result.get_xml_element().tag == "testresult"
    assert test_result.get_xml_element().text == "test_output"
    assert test_result.get_xml_element().attrib["message"] == "test_message"
    assert test_result.get_xml_element().attrib["type"] == "test_type"


# Generated at 2022-06-17 14:37:10.268568
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:37:13.425066
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:40.788796
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='test_package', timestamp=datetime.datetime.now(), properties={'property_name': 'property_value'}, cases=[TestCase(name='test_case', assertions=1, classname='test_class', status='test_status', time=decimal.Decimal(1), errors=[TestError(output='test_output', message='test_message', type='test_type')], failures=[TestFailure(output='test_output', message='test_message', type='test_type')], skipped='test_skipped', system_out='test_system_out', system_err='test_system_err')], system_out='test_system_out', system_err='test_system_err')
    assert test_suite.get_

# Generated at 2022-06-17 14:37:46.549669
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib['message'] == 'message'
    assert test_result.get_xml_element().attrib['type'] == 'type'


# Generated at 2022-06-17 14:37:49.807814
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(message='message', output='output', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:53.511982
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:58.695543
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:02.101123
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:05.468839
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:14.364949
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:21.411743
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Test method get_xml_element of class TestResult"""
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'TestResult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib['message'] == 'message'
    assert test_result.get_xml_element().attrib['type'] == 'type'


# Generated at 2022-06-17 14:38:24.907501
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:02.854516
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:06.596471
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:12.575621
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib['message'] == 'test_message'
    assert test_result.get_xml_element().attrib['type'] == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'


# Generated at 2022-06-17 14:39:15.423702
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:22.135974
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib == {'name': 'test_case'}
    assert test_case.get_xml_element().text == None
    assert test_case.get_xml_element().tail == None


# Generated at 2022-06-17 14:39:28.681170
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib['message'] == 'test_message'
    assert test_result.get_xml_element().attrib['type'] == 'test_type'


# Generated at 2022-06-17 14:39:36.456336
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib['message'] == 'test_message'
    assert test_result.get_xml_element().attrib['type'] == 'test_type'


# Generated at 2022-06-17 14:39:43.583876
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Test the method get_xml_element of class TestResult"""
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:39:47.949903
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:52.011994
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output="test", message="test", type="test")
    assert result.get_xml_element().tag == "testresult"
    assert result.get_xml_element().text == "test"
    assert result.get_xml_element().attrib["message"] == "test"
    assert result.get_xml_element().attrib["type"] == "test"


# Generated at 2022-06-17 14:41:12.522335
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    element = test_result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.attrib == {'message': 'message', 'type': 'type'}
    assert element.text == 'output'


# Generated at 2022-06-17 14:41:14.362011
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element() == ET.Element('testresult')


# Generated at 2022-06-17 14:41:17.331348
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:41:21.634986
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:41:27.811040
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:32.706467
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:41:41.476464
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'result'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:41:45.078754
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:41:50.372742
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib['message'] == 'message'
    assert result.get_xml_element().attrib['type'] == 'type'


# Generated at 2022-06-17 14:41:54.563040
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}

    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}

