

# Generated at 2022-06-17 14:33:08.239471
# Unit test for method get_xml_element of class TestResult

# Generated at 2022-06-17 14:33:10.668757
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:20.665335
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:25.868418
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'result'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:31.450594
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:39.845669
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'key1': 'value1', 'key2': 'value2'}
    test_case1 = TestCase(name='test_case1', assertions=1, classname='test_class', status='status', time=decimal.Decimal(1.0))
    test_case1.errors = [TestError(output='output', message='message', type='type')]
    test_case1.failures = [TestFailure(output='output', message='message', type='type')]
    test_case1.skipped = 'skipped'
    test_case1.system_out = 'system_out'
    test

# Generated at 2022-06-17 14:33:45.643987
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:54.987508
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.23'),
        errors=[
            TestError(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )


# Generated at 2022-06-17 14:34:03.820261
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'property1': 'value1', 'property2': 'value2'}

# Generated at 2022-06-17 14:34:07.644712
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:31.462859
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:44.936818
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', classname='test_case_classname', time=decimal.Decimal('1.23'))
    test_case.errors.append(TestError(output='test_error_output', message='test_error_message'))
    test_case.failures.append(TestFailure(output='test_failure_output', message='test_failure_message'))
    test_case.skipped = 'test_case_skipped'
    test_case.system_out = 'test_case_system_out'
    test_case.system_err = 'test_case_system_err'


# Generated at 2022-06-17 14:34:55.375167
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:04.913952
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now())
    test_suite.properties = {'key1': 'value1', 'key2': 'value2'}
    test_suite.cases = [TestCase(name='test_case1', assertions=1, classname='classname', status='status', time=decimal.Decimal(1.0)),
                        TestCase(name='test_case2', assertions=2, classname='classname', status='status', time=decimal.Decimal(2.0))]
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'

    xml_element = test_suite.get_xml

# Generated at 2022-06-17 14:35:15.792605
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    test_suite_xml_element = test_suite.get_xml_element()
    assert test_suite_xml_element.tag == 'testsuite'
    assert test_suite_xml_element.attrib['name'] == 'test_suite_name'
    assert test_suite_xml_element[0].tag == 'testcase'
    assert test_suite_xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:27.190874
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:37.687598
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:46.732392
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:57.795389
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:07.645465
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert len(xml_element) == 1
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:33.069267
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:41.376131
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:49.321535
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:58.970754
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:08.143802
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase name="test_case"/>'

    test_case = TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal(1))
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase assertions="1" classname="classname" name="test_case" status="status" time="1"/>'

    test_case = TestCase(name='test_case', skipped='skipped')

# Generated at 2022-06-17 14:37:17.562610
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:20.134782
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:37:28.904662
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:39.692432
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:49.950251
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:13.216110
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:23.940531
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:34.735454
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:40.636242
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test_suite_name')
    assert suite.get_xml_element().tag == 'testsuite'
    assert suite.get_xml_element().attrib['name'] == 'test_suite_name'


# Generated at 2022-06-17 14:38:43.387220
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:38:52.818401
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:02.510152
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now(), properties={'test_property': 'test_value'}, cases=[TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1), errors=[TestError(output='test_output', message='test_message', type='test_type')], failures=[TestFailure(output='test_output', message='test_message', type='test_type')], skipped='test_skipped', system_out='test_system_out', system_err='test_system_err')], system_out='test_system_out', system_err='test_system_err')

# Generated at 2022-06-17 14:39:13.063823
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:19.881475
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    xml_element = test_suite.get_xml_element()

    assert xml_element.tag == 'testsuite'
    assert xml_element

# Generated at 2022-06-17 14:39:26.475142
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:48.355088
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:55.624388
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now())
    test_suite.properties = {'property1': 'value1', 'property2': 'value2'}
    test_case1 = TestCase(name='test_case1', assertions=1, classname='classname', status='status', time=decimal.Decimal(1.0))
    test_case1.errors = [TestError(output='output', message='message', type='type')]
    test_case1.failures = [TestFailure(output='output', message='message', type='type')]
    test_case1.skipped = 'skipped'
    test_case1.system_out = 'system_out'
    test_case

# Generated at 2022-06-17 14:40:05.522115
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=decimal.Decimal('1.0'))
    test_case.errors.append(TestError(output='test_error_output', message='test_error_message', type='test_error_type'))
    test_case.failures.append(TestFailure(output='test_failure_output', message='test_failure_message', type='test_failure_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'


# Generated at 2022-06-17 14:40:10.502413
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:19.799712
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:25.969789
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal(1.0),
        errors=[
            TestError(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )

    element = test_case.get_xml_element()

    assert element.tag == 'testcase'

# Generated at 2022-06-17 14:40:32.857012
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:34.631582
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:40.168930
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:50.828740
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:08.394556
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_suite = TestSuite(name='test_suite_name', cases=[test_case])
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:41:18.447380
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now())
    test_suite.properties = {'key': 'value'}
    test_suite.cases = [TestCase(name='TestCase', assertions=1, classname='com.example.TestCase', status='PASSED', time=decimal.Decimal('0.001'))]
    test_suite.system_out = 'System out'
    test_suite.system_err = 'System err'

    assert test_suite.get_xml_element().tag == 'testsuite'

# Generated at 2022-06-17 14:41:28.625280
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Unit test for method get_xml_element of class TestSuite"""

# Generated at 2022-06-17 14:41:34.960762
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'
    test_suite_xml_element = test_suite.get_xml_element()
    assert test_suite_xml_element.tag == 'testsuite'
    assert test_suite_xml_element.attrib['name'] == 'test_suite_name'
    assert test_suite_xml_element.attrib['tests'] == '1'
    assert test_suite_xml_element.attrib['time'] == '0'

# Generated at 2022-06-17 14:41:43.066633
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:47.817457
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:41:56.046446
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:42:04.710149
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_suite = TestSuite(name='test_suite_name', cases=[test_case])
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite_name'
    assert test_suite.get_xml_element().attrib['tests'] == '1'
    assert test_suite.get_xml_element()[0].tag == 'testcase'
    assert test_suite.get_xml_element()[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:42:09.964610
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:20.696914
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case_name'}
    assert element.text is None
    assert len(element) == 0

    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=1.1)
    element = test_case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case_name', 'assertions': '1', 'classname': 'test_class_name', 'status': 'test_status', 'time': '1.1'}

# Generated at 2022-06-17 14:42:47.184980
# Unit test for method get_xml_element of class TestSuite