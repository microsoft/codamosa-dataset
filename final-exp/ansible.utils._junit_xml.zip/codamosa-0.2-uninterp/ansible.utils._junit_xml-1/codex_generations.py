

# Generated at 2022-06-17 14:32:58.500526
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output="output", message="message", type="type")
    assert result.get_xml_element().tag == "testresult"
    assert result.get_xml_element().text == "output"
    assert result.get_xml_element().attrib == {"message": "message", "type": "type"}


# Generated at 2022-06-17 14:33:08.027133
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0)),
                        TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'test_system_out'

# Generated at 2022-06-17 14:33:11.065797
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:33:20.903301
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite1', hostname='localhost', id='1', package='com.example.test', timestamp=datetime.datetime.now())
    test_suite.properties = {'prop1': 'value1', 'prop2': 'value2'}
    test_suite.cases = [TestCase(name='TestCase1', assertions=1, classname='com.example.test.TestCase1', status='PASSED', time=decimal.Decimal('1.23')),
                        TestCase(name='TestCase2', assertions=2, classname='com.example.test.TestCase2', status='FAILED', time=decimal.Decimal('2.34'))]
    test_suite.system_out = 'System out'

# Generated at 2022-06-17 14:33:23.959267
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:28.815685
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:33:34.164243
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'result'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:36.552646
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:39.672430
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element() == ET.Element('testresult')


# Generated at 2022-06-17 14:33:43.296463
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:51.021735
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:33:59.853674
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case')
    test_suite = TestSuite(name='test_suite', cases=[test_case])
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case'

# Generated at 2022-06-17 14:34:10.921381
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:20.758922
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:26.187117
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:34:31.461504
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:40.179026
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:34:45.479939
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="TestSuite")
    test_suite.cases = [TestCase(name="TestCase1"), TestCase(name="TestCase2")]
    test_suite.properties = {"property1": "value1", "property2": "value2"}
    test_suite.system_out = "system_out"
    test_suite.system_err = "system_err"
    test_suite.hostname = "hostname"
    test_suite.id = "id"
    test_suite.package = "package"
    test_suite.timestamp = datetime.datetime.now()
    test_suite.cases[0].time = decimal.Decimal(1.0)

# Generated at 2022-06-17 14:34:49.382731
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:58.642601
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now())
    test_suite.properties = {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-17 14:35:11.416655
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:15.023175
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:19.151052
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output="output", message="message", type="type")
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:28.487954
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:31.981125
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:40.276357
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:35:45.245703
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().get('message') == 'test_message'
    assert test_result.get_xml_element().get('type') == 'test_type'


# Generated at 2022-06-17 14:35:47.525937
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:35:52.981991
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    xml_element = test_case.get_xml_element()
    assert xml_element.tag == 'testcase'
    assert xml_element.attrib == {'name': 'test_case'}
    assert xml_element.text == None
    assert len(xml_element) == 0


# Generated at 2022-06-17 14:35:58.025324
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='test output', message='test message', type='test type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'test output'
    assert result.get_xml_element().attrib == {'message': 'test message', 'type': 'test type'}


# Generated at 2022-06-17 14:36:07.215366
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:18.425786
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    test_suite_xml = test_suite.get_xml_element()
    assert test_suite_xml.tag == 'testsuite'
    assert test_suite_xml.attrib['name'] == 'test_suite_name'
    assert test_suite_xml.attrib['tests'] == '1'
    assert test_suite_xml[0].tag == 'testcase'
    assert test_suite_xml[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:26.168000
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase name="test_name" />'

    test_case = TestCase(name='test_name', assertions=1, classname='test_class', status='test_status', time=decimal.Decimal('1.0'))
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == '<testcase assertions="1" classname="test_class" name="test_name" status="test_status" time="1.0" />'


# Generated at 2022-06-17 14:36:28.606704
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:31.690259
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output="output", message="message", type="type")
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:44.541210
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='TestCase', assertions=1, classname='com.example.TestCase', status='PASSED', time=decimal.Decimal(1.0), errors=[TestError(output='error', message='error message', type='error')], failures=[TestFailure(output='failure', message='failure message', type='failure')], skipped='skipped', system_out='system out', system_err='system err')], system_out='system out', system_err='system err')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:36:52.353524
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now(), properties={'test_property': 'test_value'}, system_out='test_system_out', system_err='test_system_err')

# Generated at 2022-06-17 14:36:56.271205
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    element = result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.attrib == {'message': 'message', 'type': 'type'}
    assert element.text == 'output'


# Generated at 2022-06-17 14:37:01.668143
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert test_result.get_xml_element().text == "test_output"
    assert test_result.get_xml_element().attrib["message"] == "test_message"
    assert test_result.get_xml_element().attrib["type"] == "test_type"


# Generated at 2022-06-17 14:37:05.106416
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:18.123081
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:23.589021
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:27.301493
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:29.638342
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:34.579347
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:39.850146
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:37:45.015171
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:37:56.601139
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:07.198760
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal('1.0'))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_

# Generated at 2022-06-17 14:38:11.012371
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:32.300795
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:35.351919
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output="output", message="message", type="type")
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:39.765431
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:41.523874
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element().tag == 'testresult'


# Generated at 2022-06-17 14:38:46.619283
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case')
    test_suite = TestSuite(name='test_suite', cases=[test_case])
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:38:51.006378
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:56.494228
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:38:59.934056
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:02.942291
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:13.314215
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:37.320609
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:38.940890
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}


# Generated at 2022-06-17 14:39:42.349991
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:39:48.448892
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:39:51.601538
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:55.334503
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element() == ET.fromstring('<testcase name="test_case_name" />')


# Generated at 2022-06-17 14:40:06.415665
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name_2'))
    test_suite.cases.append(TestCase(name='test_case_name_3'))
    test_suite.cases.append(TestCase(name='test_case_name_4'))
    test_suite.cases.append(TestCase(name='test_case_name_5'))
    test_suite.cases.append(TestCase(name='test_case_name_6'))
    test_suite.cases.append(TestCase(name='test_case_name_7'))

# Generated at 2022-06-17 14:40:12.060774
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
    assert test_case.get_xml_element().text == None


# Generated at 2022-06-17 14:40:17.065468
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_xml_element().tag == "TestResult"
    assert test_result.get_xml_element().text == "output"
    assert test_result.get_xml_element().attrib == {"message": "message", "type": "type"}


# Generated at 2022-06-17 14:40:27.847363
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.1'),
        errors=[
            TestError(
                output='test_error_output',
                message='test_error_message',
                type='test_error_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_failure_output',
                message='test_failure_message',
                type='test_failure_type',
            ),
        ],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )


# Generated at 2022-06-17 14:40:54.627289
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:41:06.955693
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_case_classname',
        status='test_case_status',
        time=decimal.Decimal('1.0'),
        errors=[
            TestError(
                output='test_error_output',
                message='test_error_message',
                type='test_error_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_failure_output',
                message='test_failure_message',
                type='test_failure_type',
            ),
        ],
        skipped='test_case_skipped',
        system_out='test_case_system_out',
        system_err='test_case_system_err',
    )

    expected_

# Generated at 2022-06-17 14:41:17.626683
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name='test_suite',
        hostname='hostname',
        id='id',
        package='package',
        timestamp=datetime.datetime.now(),
        properties={'key': 'value'},
        cases=[TestCase(name='test_case')],
        system_out='system_out',
        system_err='system_err',
    )

    xml_element = test_suite.get_xml_element()

    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite'
    assert xml_element.attrib['hostname'] == 'hostname'
    assert xml_element.attrib['id'] == 'id'
    assert xml_element.attrib['package'] == 'package'

# Generated at 2022-06-17 14:41:27.844421
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:33.053027
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().attrib == {'message': 'test_message', 'type': 'test_type'}
    assert test_result.get_xml_element().text == 'test_output'


# Generated at 2022-06-17 14:41:40.958975
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:41:44.021784
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:41:47.639818
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:41:49.713407
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element().tag == 'TestResult'


# Generated at 2022-06-17 14:41:55.980156
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Test with no output
    test_result = TestResult()
    assert test_result.get_xml_element().text is None

    # Test with output
    test_result = TestResult(output='output')
    assert test_result.get_xml_element().text == 'output'

    # Test with message
    test_result = TestResult(message='message')
    assert test_result.get_xml_element().attrib['message'] == 'message'

    # Test with type
    test_result = TestResult(type='type')
    assert test_result.get_xml_element().attrib['type'] == 'type'



# Generated at 2022-06-17 14:42:46.288042
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert test_result.get_xml_element().tag == "test_type"
    assert test_result.get_xml_element().text == "test_output"
    assert test_result.get_xml_element().attrib["message"] == "test_message"
    assert test_result.get_xml_element().attrib["type"] == "test_type"
