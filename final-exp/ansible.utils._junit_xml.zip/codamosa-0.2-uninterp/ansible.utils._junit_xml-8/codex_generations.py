

# Generated at 2022-06-17 14:32:52.813047
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:32:56.577273
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output = 'output', message = 'message', type = 'type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:02.264597
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:05.162290
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}



# Generated at 2022-06-17 14:33:12.329536
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal('1.0'))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_

# Generated at 2022-06-17 14:33:21.579850
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:24.896786
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:30.515581
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    element = result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.attrib == {'message': 'message', 'type': 'type'}
    assert element.text == 'output'


# Generated at 2022-06-17 14:33:36.950707
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:33:41.464164
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes() == {}
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:49.690821
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='test_package', timestamp=datetime.datetime.now())
    test_suites = TestSuites(name='test_suites', suites=[test_suite])
    assert test_suites.get_xml_element().tag == 'testsuites'


# Generated at 2022-06-17 14:33:58.158857
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='package', timestamp=datetime.datetime.now())
    test_suite.properties = {'key': 'value'}
    test_suite.cases = [TestCase(name='test_case', assertions=1, classname='class', status='status', time=decimal.Decimal('1.0'))]
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'


# Generated at 2022-06-17 14:34:02.877993
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:08.819212
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert len(xml_element) == 1
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:18.571789
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case', assertions=1, classname='TestCase', status='status', time=1.0)
    test_case.errors.append(TestError(output='output', message='message', type='type'))
    test_case.failures.append(TestFailure(output='output', message='message', type='type'))
    test_case.skipped = 'skipped'
    test_case.system_out = 'system_out'
    test_case.system_err = 'system_err'

    assert test_case.get_xml_element().tag == 'testcase'

# Generated at 2022-06-17 14:34:22.410138
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'TestResult'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:34:27.063028
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name')
    xml_element = test_case.get_xml_element()
    assert xml_element.tag == 'testcase'
    assert xml_element.attrib['name'] == 'test_name'


# Generated at 2022-06-17 14:34:31.372458
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:44.911431
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:55.337870
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case', assertions=1, classname='TestCase', status='status', time=1.0)
    test_case.errors.append(TestError(output='error output', message='error message', type='error type'))
    test_case.failures.append(TestFailure(output='failure output', message='failure message', type='failure type'))
    test_case.skipped = 'skipped'
    test_case.system_out = 'system out'
    test_case.system_err = 'system err'
    test_case.is_disabled = True


# Generated at 2022-06-17 14:35:05.212490
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Create a TestResult object
    test_result = TestResult(output='output', message='message', type='type')
    # Get the XML element
    element = test_result.get_xml_element()
    # Check the tag name
    assert element.tag == 'testresult'
    # Check the attributes
    assert element.attrib == {'message': 'message', 'type': 'type'}
    # Check the text
    assert element.text == 'output'


# Generated at 2022-06-17 14:35:09.276430
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:12.796648
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:18.422302
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:20.523849
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}


# Generated at 2022-06-17 14:35:23.431690
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:26.497493
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:37.340411
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:41.938201
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:46.684410
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:54.196947
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:35:57.160547
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:08.604531
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_suite_hostname', id='test_suite_id', package='test_suite_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'property_name': 'property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_case_classname', status='test_case_status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'test_suite_system_out'
    test_suite.system_err = 'test_suite_system_err'
    test_suite_xml_element = test_suite.get_xml_element()

# Generated at 2022-06-17 14:36:12.134432
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_1')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:36:17.898231
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}
    assert test_result.get_xml_element().text == 'output'


# Generated at 2022-06-17 14:36:22.016745
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:26.274348
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:36:28.090986
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    assert test_result.get_xml_element() == ET.Element('testresult')


# Generated at 2022-06-17 14:36:36.971868
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal(1), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err', is_disabled=True)], system_out='system_out', system_err='system_err')

# Generated at 2022-06-17 14:36:39.475522
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:36:58.886871
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:03.404231
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:07.544495
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:17.211659
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now())
    test_suite.properties = {'key': 'value'}
    test_suite.cases = [TestCase(name='TestCase', assertions=1, classname='TestClass', status='PASSED', time=decimal.Decimal(0.1))]
    test_suite.system_out = 'System out'
    test_suite.system_err = 'System err'

    element = test_suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.attrib['name'] == 'TestSuite'
    assert element.attrib['hostname'] == 'localhost'
    assert element.attrib

# Generated at 2022-06-17 14:37:27.575133
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:30.322648
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:37:40.433128
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:50.320809
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.system_out = 'test_suite_system_out'
    test_suite.system_err = 'test_suite_system_err'

    test_suite_xml_element = test_suite.get_xml_element()
    assert test_suite_xml_element.tag == 'testsuite'
    assert test_suite_xml_element.attrib == {'name': 'test_suite_name', 'tests': '1'}
    assert test_suite_xml_element[0].tag == 'testcase'

# Generated at 2022-06-17 14:37:57.093981
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case', assertions=1, classname='TestCase', status='status', time=1.0)
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'property': 'value'}, cases=[test_case], system_out='system_out', system_err='system_err')

# Generated at 2022-06-17 14:38:07.646071
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:34.332367
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now())
    test_suite.properties = {'key1': 'value1', 'key2': 'value2'}
    test_suite.cases = [TestCase(name='TestCase1', assertions=1, classname='com.example.TestCase1', status='PASSED', time=1.0),
                        TestCase(name='TestCase2', assertions=2, classname='com.example.TestCase2', status='FAILED', time=2.0)]
    test_suite.system_out = 'System out'
    test_suite.system_err = 'System err'

    test_suite_xml = test_suite.get_xml_

# Generated at 2022-06-17 14:38:45.546804
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:49.515678
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    expected_xml = '<testcase name="test_case"></testcase>'
    assert ET.tostring(test_case.get_xml_element(), encoding='unicode') == expected_xml


# Generated at 2022-06-17 14:38:59.297934
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:02.964864
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    assert test_suite.get_xml_element().find('testcase').get('name') == 'test_case_name'

# Generated at 2022-06-17 14:39:06.331780
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:39:11.024195
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
    assert test_case.get_xml_element().text == None


# Generated at 2022-06-17 14:39:13.853008
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib == {'name': 'test_case_name'}


# Generated at 2022-06-17 14:39:20.099006
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:28.049209
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    element = test_suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.attrib['name'] == 'test_suite_name'
    assert element[0].tag == 'testcase'
    assert element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:57.149234
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:01.012798
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:09.830890
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:19.453992
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:25.718577
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:29.549002
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name="test_case_name")
    test_suite = TestSuite(name="test_suite_name", cases=[test_case])
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == "testsuite"
    assert xml_element.attrib["name"] == "test_suite_name"
    assert xml_element.attrib["tests"] == "1"
    assert xml_element[0].tag == "testcase"
    assert xml_element[0].attrib["name"] == "test_case_name"


# Generated at 2022-06-17 14:40:32.269002
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:40:45.032414
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:54.774088
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:07.131917
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:15.915372
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_case = TestCase(name='test_case_name')
    test_suite.cases.append(test_case)
    test_suite_xml_element = test_suite.get_xml_element()
    assert test_suite_xml_element.tag == 'testsuite'
    assert test_suite_xml_element.attrib['name'] == 'test_suite_name'
    assert test_suite_xml_element[0].tag == 'testcase'
    assert test_suite_xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:42:24.559972
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:28.546210
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:42:39.362249
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:42:44.427261
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
