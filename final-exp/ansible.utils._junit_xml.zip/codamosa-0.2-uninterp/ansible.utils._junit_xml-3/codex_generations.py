

# Generated at 2022-06-17 14:32:56.189799
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes() == {'type': 'testresult'}

    result = TestResult(message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:32:59.066866
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:33:02.486280
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(message="message", type="type", output="output")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:06.239504
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    element = result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.attrib == {'message': 'message', 'type': 'type'}
    assert element.text == 'output'


# Generated at 2022-06-17 14:33:10.303898
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite_name'


# Generated at 2022-06-17 14:33:13.350328
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='test', message='test', type='test')
    assert result.get_xml_element().tag == 'test'


# Generated at 2022-06-17 14:33:22.374055
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    # Create a test suite
    test_suite = TestSuite(name='TestSuite1', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now())
    # Create a test case
    test_case = TestCase(name='TestCase1', assertions=1, classname='com.example.TestCase1', status='PASS', time=decimal.Decimal(0.1))
    # Add test case to test suite
    test_suite.cases.append(test_case)
    # Create a test suites
    test_suites = TestSuites(name='TestSuites1')
    # Add test suite to test suites
    test_suites.suites.append(test_suite)
    # Get XML element
    element = test_suites.get_xml_element()


# Generated at 2022-06-17 14:33:25.868172
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:30.134066
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:32.780182
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:33:43.050842
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:46.807614
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}



# Generated at 2022-06-17 14:33:49.798996
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:33:52.634505
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:00.023449
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_xml_element().tag == 'test_type'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib['message'] == 'test_message'
    assert test_result.get_xml_element().attrib['type'] == 'test_type'


# Generated at 2022-06-17 14:34:09.080431
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Test with no output
    result = TestResult()
    assert result.get_xml_element().text is None

    # Test with output
    result = TestResult(output='output')
    assert result.get_xml_element().text == 'output'

    # Test with message
    result = TestResult(output='output', message='message')
    assert result.get_xml_element().attrib['message'] == 'message'

    # Test with type
    result = TestResult(output='output', type='type')
    assert result.get_xml_element().attrib['type'] == 'type'



# Generated at 2022-06-17 14:34:17.694506
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_case = TestCase(name='test_case')
    test_suite.cases.append(test_case)
    test_suite_element = test_suite.get_xml_element()
    assert test_suite_element.tag == 'testsuite'
    assert test_suite_element.attrib['name'] == 'test_suite'
    assert test_suite_element.attrib['tests'] == '1'
    assert test_suite_element[0].tag == 'testcase'
    assert test_suite_element[0].attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:34:22.038083
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_xml_element().tag == 'TestResult'
    assert test_result.get_xml_element().text == 'output'
    assert test_result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:33.178574
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_1': 'test_value_1', 'test_property_2': 'test_value_2'}
    test_suite.cases = [TestCase(name='test_case_name_1', assertions=1, classname='test_classname_1', status='test_status_1', time=decimal.Decimal('1.0')),
                        TestCase(name='test_case_name_2', assertions=2, classname='test_classname_2', status='test_status_2', time=decimal.Decimal('2.0'))]
   

# Generated at 2022-06-17 14:34:37.765249
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='output', message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:34:59.061942
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:02.911267
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='test_output', message='test_message', type='test_type')
    assert test_result.get_attributes() == {'message': 'test_message', 'type': 'test_type'}


# Generated at 2022-06-17 14:35:04.609997
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:35:10.790454
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    assert result.get_xml_element().tag == 'testresult'
    assert result.get_xml_element().text == 'output'
    assert result.get_xml_element().attrib == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:14.387070
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output="output", message="message", type="type")
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-17 14:35:26.076155
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name', classname='test_case_classname', time=1.0)
    test_suite = TestSuite(name='test_suite_name', hostname='test_suite_hostname', id='test_suite_id', package='test_suite_package', timestamp=datetime.datetime.now(), cases=[test_case])
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element.attrib['hostname'] == 'test_suite_hostname'
    assert xml_element.attrib['id'] == 'test_suite_id'
    assert xml_element

# Generated at 2022-06-17 14:35:31.679907
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='output', message='message', type='type')
    element = result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.attrib == {'message': 'message', 'type': 'type'}
    assert element.text == 'output'


# Generated at 2022-06-17 14:35:45.034362
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_name',
        assertions=1,
        classname='test_classname',
        status='test_status',
        time=1.0,
        errors=[TestError(output='test_output', message='test_message', type='test_type')],
        failures=[TestFailure(output='test_output', message='test_message', type='test_type')],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )

    assert test_case.get_xml_element().tag == 'testcase'

# Generated at 2022-06-17 14:35:54.452252
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_case.time = decimal.Decimal('1.234')
    test_case.classname = 'test_case_classname'
    test_case.status = 'test_case_status'
    test_case.assertions = 1
    test_case.system_out = 'test_case_system_out'
    test_case.system_err = 'test_case_system_err'
    test_case.skipped = 'test_case_skipped'
    test_case.errors.append(TestError(output='test_case_error_output', message='test_case_error_message', type='test_case_error_type'))

# Generated at 2022-06-17 14:35:58.199725
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}

    test_result = TestResult(message='message', type='type')
    assert test_result.get_attributes() == {'message': 'message', 'type': 'type'}

    test_result = TestResult(message='message', type=None)
    assert test_result.get_attributes() == {'message': 'message', 'type': 'TestResult'}



# Generated at 2022-06-17 14:36:14.242606
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:22.950108
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:30.837829
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_key': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element

# Generated at 2022-06-17 14:36:40.141749
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:48.226139
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:58.826940
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_case_classname',
        status='test_case_status',
        time=1.0,
        errors=[TestError(output='test_case_error_output', message='test_case_error_message', type='test_case_error_type')],
        failures=[TestFailure(output='test_case_failure_output', message='test_case_failure_message', type='test_case_failure_type')],
        skipped='test_case_skipped',
        system_out='test_case_system_out',
        system_err='test_case_system_err',
    )

# Generated at 2022-06-17 14:37:08.054903
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:17.294074
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal('1.0'), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err')], system_out='system_out', system_err='system_err')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:37:27.633917
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name2'))
    test_suite.cases.append(TestCase(name='test_case_name3'))
    test_suite.cases.append(TestCase(name='test_case_name4'))
    test_suite.cases.append(TestCase(name='test_case_name5'))
    test_suite.cases.append(TestCase(name='test_case_name6'))
    test_suite.cases.append(TestCase(name='test_case_name7'))

# Generated at 2022-06-17 14:37:38.369894
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:04.887015
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases.append(TestCase(name='test_case_3'))
    test_suite.cases.append(TestCase(name='test_case_4'))
    test_suite.cases.append(TestCase(name='test_case_5'))
    test_suite.cases.append(TestCase(name='test_case_6'))
    test_suite.cases.append(TestCase(name='test_case_7'))
    test_suite.cases.append(TestCase(name='test_case_8'))

# Generated at 2022-06-17 14:38:14.020154
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="test_suite", hostname="hostname", id="id", package="package", timestamp=datetime.datetime.now(), properties={"name1":"value1", "name2":"value2"}, cases=[TestCase(name="test_case", assertions=1, classname="classname", status="status", time=decimal.Decimal(1), errors=[TestError(output="output", message="message", type="type")], failures=[TestFailure(output="output", message="message", type="type")], skipped="skipped", system_out="system_out", system_err="system_err")], system_out="system_out", system_err="system_err")
    assert test_suite.get_xml_element().tag == "testsuite"


# Generated at 2022-06-17 14:38:23.233888
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_case = TestCase(name='test_case')
    test_suite.cases.append(test_case)
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib == {'name': 'test_suite', 'tests': '1'}
    assert test_suite.get_xml_element()[0].tag == 'testcase'
    assert test_suite.get_xml_element()[0].attrib == {'name': 'test_case'}


# Generated at 2022-06-17 14:38:34.476343
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:45.599383
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:55.549721
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:02.154602
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:13.029223
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name_2'))
    test_suite.cases.append(TestCase(name='test_case_name_3'))
    test_suite.cases.append(TestCase(name='test_case_name_4'))
    test_suite.cases.append(TestCase(name='test_case_name_5'))
    test_suite.cases.append(TestCase(name='test_case_name_6'))
    test_suite.cases.append(TestCase(name='test_case_name_7'))

# Generated at 2022-06-17 14:39:20.564496
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    test_suite_xml_element = test_suite.get_xml_element()


# Generated at 2022-06-17 14:39:30.113276
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:08.314779
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_suite = TestSuite(name='test_suite_name', cases=[test_case])
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:18.667889
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:25.222291
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:32.411737
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_property_name': 'test_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'test_system_out'
    test_suite.system_err = 'test_system_err'

    test_suite_xml_element = test_suite.get_xml_element()


# Generated at 2022-06-17 14:40:45.057392
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases.append(TestCase(name='test_case_3'))
    test_suite.cases.append(TestCase(name='test_case_4'))
    test_suite.cases.append(TestCase(name='test_case_5'))
    test_suite.cases.append(TestCase(name='test_case_6'))
    test_suite.cases.append(TestCase(name='test_case_7'))
    test_suite.cases.append(TestCase(name='test_case_8'))

# Generated at 2022-06-17 14:40:47.456728
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:40:56.514932
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:08.360249
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal('1.0'), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err')], system_out='system_out', system_err='system_err')
    test_suite_xml = test_suite.get_xml_element()
    assert test_suite_xml.tag == 'testsuite'


# Generated at 2022-06-17 14:41:18.412695
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:27.306112
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now())
    test_suite.properties = {'key': 'value'}
    test_suite.cases = [TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal(1.0))]
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'

    assert test_suite.get_xml_element().tag == 'testsuite'
