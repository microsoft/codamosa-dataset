

# Generated at 2022-06-17 14:33:08.082922
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    test_case.assertions = 1
    test_case.classname = 'test_class_name'
    test_case.status = 'test_status'
    test_case.time = decimal.Decimal(1.0)

    test_case.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    test_case.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'

    test_case_xml = test_case.get

# Generated at 2022-06-17 14:33:15.406472
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="TestSuite", hostname="localhost", id="1", package="com.example.test", timestamp=datetime.datetime.now())
    test_suite.properties = {"key1": "value1", "key2": "value2"}
    test_suite.cases = [TestCase(name="TestCase1", assertions=1, classname="com.example.test.TestCase1", status="PASSED", time=1.0),
                        TestCase(name="TestCase2", assertions=2, classname="com.example.test.TestCase2", status="PASSED", time=2.0)]
    test_suite.system_out = "system out"
    test_suite.system_err = "system err"

    element = test_suite.get_xml_element()

# Generated at 2022-06-17 14:33:23.487746
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_class_name',
        status='test_status',
        time=decimal.Decimal('1.234'),
        errors=[
            TestError(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        failures=[
            TestFailure(
                output='test_output',
                message='test_message',
                type='test_type',
            ),
        ],
        skipped='test_skipped',
        system_out='test_system_out',
        system_err='test_system_err',
    )


# Generated at 2022-06-17 14:33:34.563190
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:33:37.614635
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    xml_element = test_case.get_xml_element()
    assert xml_element.tag == 'testcase'
    assert xml_element.attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:33:48.497745
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name', assertions=1, classname='test_class', status='test_status', time=1.0)
    test_case.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    test_case.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.is_disabled = True


# Generated at 2022-06-17 14:33:51.326329
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:33:59.542064
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name', assertions=1, classname='test_class_name', status='test_status', time=1.0)
    test_case.errors.append(TestError(output='test_output', message='test_message', type='test_type'))
    test_case.failures.append(TestFailure(output='test_output', message='test_message', type='test_type'))
    test_case.skipped = 'test_skipped'
    test_case.system_out = 'test_system_out'
    test_case.system_err = 'test_system_err'
    test_case.is_disabled = True

    element = test_case.get_xml_element()

    assert element.tag == 'testcase'

# Generated at 2022-06-17 14:34:04.080677
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:34:12.059682
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:31.722478
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:44.964115
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:34:49.884604
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name="test_case_name")
    assert test_case.get_xml_element().tag == "testcase"
    assert test_case.get_xml_element().attrib["name"] == "test_case_name"


# Generated at 2022-06-17 14:34:55.366993
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.cases.append(TestCase(name='test_case_3'))
    test_suite.cases.append(TestCase(name='test_case_4'))
    test_suite.cases.append(TestCase(name='test_case_5'))
    test_suite.cases.append(TestCase(name='test_case_6'))
    test_suite.cases.append(TestCase(name='test_case_7'))
    test_suite.cases.append(TestCase(name='test_case_8'))

# Generated at 2022-06-17 14:35:00.180467
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'


# Generated at 2022-06-17 14:35:04.781599
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    xml_element = test_case.get_xml_element()
    assert xml_element.tag == 'testcase'
    assert xml_element.attrib == {'name': 'test_case_name'}
    assert xml_element.text == None
    assert len(xml_element) == 0


# Generated at 2022-06-17 14:35:16.554698
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:35:25.704320
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite'
    assert xml_element.attrib['tests'] == '1'
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:35:35.789522
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_case = TestCase(name='test_case')
    test_suite.cases.append(test_case)
    test_suite_xml = test_suite.get_xml_element()
    assert test_suite_xml.tag == 'testsuite'
    assert test_suite_xml.attrib['name'] == 'test_suite'
    assert test_suite_xml.attrib['tests'] == '1'
    assert test_suite_xml[0].tag == 'testcase'
    assert test_suite_xml[0].attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:35:46.270116
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case',
        assertions=1,
        classname='TestCase',
        status='passed',
        time=decimal.Decimal('1.234'),
        errors=[
            TestError(
                output='error output',
                message='error message',
                type='error type',
            ),
        ],
        failures=[
            TestFailure(
                output='failure output',
                message='failure message',
                type='failure type',
            ),
        ],
        skipped='skipped message',
        system_out='system out',
        system_err='system err',
    )


# Generated at 2022-06-17 14:36:00.171166
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name2'))
    test_suite.cases.append(TestCase(name='test_case_name3'))
    test_suite.cases.append(TestCase(name='test_case_name4'))
    test_suite.cases.append(TestCase(name='test_case_name5'))
    test_suite.cases.append(TestCase(name='test_case_name6'))
    test_suite.cases.append(TestCase(name='test_case_name7'))

# Generated at 2022-06-17 14:36:09.413226
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal('1.0'), errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err')], system_out='system_out', system_err='system_err')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:36:12.133660
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:21.948541
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name'))

# Generated at 2022-06-17 14:36:30.458077
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:36:33.376327
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:36:38.896999
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib == {'name': 'test_case'}


# Generated at 2022-06-17 14:36:46.728546
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='test_case_name', assertions=1, classname='test_classname', status='test_status', time=decimal.Decimal(1.0), errors=[TestError(output='test_output', message='test_message', type='test_type')], failures=[TestFailure(output='test_output', message='test_message', type='test_type')], skipped='test_skipped', system_out='test_system_out', system_err='test_system_err')], system_out='test_system_out', system_err='test_system_err')
   

# Generated at 2022-06-17 14:36:57.649234
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:07.744532
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case_1', assertions=1, classname='test_class', status='status', time=1)
    test_suite = TestSuite(name='test_suite_1', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), cases=[test_case])
    test_suites = TestSuites(name='test_suites_1', suites=[test_suite])

# Generated at 2022-06-17 14:37:20.952543
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'



# Generated at 2022-06-17 14:37:29.204350
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:37:31.728159
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:37:43.883200
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime(2020, 1, 1, 0, 0, 0))
    test_suite.properties = {'key1': 'value1', 'key2': 'value2'}
    test_case = TestCase(name='test_case', assertions=1, classname='classname', status='status', time=decimal.Decimal(1.0))
    test_case.errors = [TestError(output='output', message='message', type='type')]
    test_case.failures = [TestFailure(output='output', message='message', type='type')]
    test_case.skipped = 'skipped'
    test_case.system_out = 'system_out'


# Generated at 2022-06-17 14:37:46.185316
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case'


# Generated at 2022-06-17 14:37:57.751077
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name', hostname='test_suite_hostname', id='test_suite_id', package='test_suite_package', timestamp=datetime.datetime.now())
    test_suite.properties = {'test_suite_property_name': 'test_suite_property_value'}
    test_suite.cases = [TestCase(name='test_case_name', assertions=1, classname='test_case_classname', status='test_case_status', time=decimal.Decimal('1.0'))]
    test_suite.system_out = 'test_suite_system_out'
    test_suite.system_err = 'test_suite_system_err'


# Generated at 2022-06-17 14:38:08.159417
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:19.790123
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:30.598279
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:38:43.822022
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case = TestCase(name='test_case')
    element = case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'test_case'}
    assert element.text is None
    assert len(element) == 0

    case = TestCase(name='test_case', assertions=1, classname='TestCase', status='status', time=1.0)
    element = case.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib == {'assertions': '1', 'classname': 'TestCase', 'name': 'test_case', 'status': 'status', 'time': '1.0'}
    assert element.text is None
    assert len(element) == 0


# Generated at 2022-06-17 14:39:14.556101
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:26.526628
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:39:35.681232
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="test_suite_name")
    test_case = TestCase(name="test_case_name")
    test_suite.cases.append(test_case)
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == "testsuite"
    assert xml_element.attrib["name"] == "test_suite_name"
    assert xml_element[0].tag == "testcase"
    assert xml_element[0].attrib["name"] == "test_case_name"


# Generated at 2022-06-17 14:39:39.494619
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:42.055149
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:39:44.375142
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element().tag == 'testcase'


# Generated at 2022-06-17 14:39:48.842978
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    assert test_suite.get_xml_element().tag == 'testsuite'
    assert test_suite.get_xml_element().attrib['name'] == 'test_suite_name'


# Generated at 2022-06-17 14:39:54.158938
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
    assert test_case.get_xml_element().text == None


# Generated at 2022-06-17 14:40:04.378607
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite')
    test_suite.cases.append(TestCase(name='test_case'))
    test_suite.cases.append(TestCase(name='test_case_2'))
    test_suite.system_out = 'system_out'
    test_suite.system_err = 'system_err'
    test_suite.properties['property'] = 'value'
    test_suite.properties['property_2'] = 'value_2'

    test_suite_element = test_suite.get_xml_element()

    assert test_suite_element.tag == 'testsuite'

# Generated at 2022-06-17 14:40:09.450941
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'


# Generated at 2022-06-17 14:40:50.995221
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:40:59.160078
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:09.668487
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:19.226111
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:28.921986
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:38.239904
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='TestSuite', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now(), properties={'key': 'value'}, cases=[TestCase(name='TestCase', assertions=1, classname='TestCase', status='status', time=1.0, errors=[TestError(output='output', message='message', type='type')], failures=[TestFailure(output='output', message='message', type='type')], skipped='skipped', system_out='system_out', system_err='system_err', is_disabled=True)], system_out='system_out', system_err='system_err')
    assert test_suite.get_xml_element().tag == 'testsuite'


# Generated at 2022-06-17 14:41:46.928058
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-17 14:41:55.544136
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_name')
    test_suite.cases.append(TestCase(name='test_case_name'))
    test_suite.cases.append(TestCase(name='test_case_name_2'))
    test_suite.cases.append(TestCase(name='test_case_name_3'))
    test_suite.cases.append(TestCase(name='test_case_name_4'))
    test_suite.cases.append(TestCase(name='test_case_name_5'))
    test_suite.cases.append(TestCase(name='test_case_name_6'))
    test_suite.cases.append(TestCase(name='test_case_name_7'))

# Generated at 2022-06-17 14:42:06.249298
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test_suite', timestamp=datetime.datetime.now())
    suite.cases.append(TestCase(name='test_case'))
    suite.cases.append(TestCase(name='test_case_2'))
    suite.cases.append(TestCase(name='test_case_3'))
    suite.cases[0].errors.append(TestError(output='error_output'))
    suite.cases[1].failures.append(TestFailure(output='failure_output'))
    suite.cases[2].skipped = 'skipped_output'
    suite.system_out = 'system_out'
    suite.system_err = 'system_err'
    suite.properties['key1'] = 'value1'
    suite.properties['key2'] = 'value2'

# Generated at 2022-06-17 14:42:11.241883
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.get_xml_element().attrib['name'] == 'test_case_name'
