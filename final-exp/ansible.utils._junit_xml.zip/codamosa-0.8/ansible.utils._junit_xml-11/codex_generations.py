

# Generated at 2022-06-11 17:24:12.408922
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    _case = TestCase(name="test_case_name")
    _case.errors.append(TestError(message="some message", type="some type"))
    _case.failures.append(TestFailure(message="some message", type="some type"))
    assert _case.get_xml_element().tag == "testcase"
    assert _case.get_xml_element().find("error").tag == "error"
    assert _case.get_xml_element().find("failure").tag == "failure"



# Generated at 2022-06-11 17:24:23.296850
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Unit test for method get_xml_element of class TestCase"""

    tc = TestCase(
        name="test_something",
        assertions=1,
        classname="SomeClass",
        status="passed",
        time=decimal.Decimal('0.5'),
        errors=[
            TestError(message="Some error", output="The output of the error"),
        ],
        failures=[
            TestFailure(message="Some failure", output="The output of the failure"),
        ],
        skipped="It was skipped",
        system_out="This is the output of the test",
        system_err="This is the error of the test",
        is_disabled=True
    )


# Generated at 2022-06-11 17:24:36.070750
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    from xml.dom.minidom import parseString
    assert(parseString(TestResult().get_xml_element().toxml('utf-8')).toprettyxml(indent="    ") == \
           """<result>
</result>
""")
    assert(parseString(TestResult(type='mytype').get_xml_element().toxml('utf-8')).toprettyxml(indent="    ") == \
           """<result type="mytype">
</result>
""")
    assert(parseString(TestResult(output='myoutput').get_xml_element().toxml('utf-8')).toprettyxml(indent="    ") == \
           """<result>
    myoutput
</result>
""")

# Generated at 2022-06-11 17:24:39.213062
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    assert TestResult(output='foo bar', message='fail', type='value').get_xml_element().tag == 'result'


# Generated at 2022-06-11 17:24:45.388310
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Unit test get_xml_element of TestResult class."""
    assert TestError(output=None, message=None, type=None).get_xml_element().tag == 'error'
    assert TestError(output='output', message='message', type=None).get_xml_element().get('message') == 'message'
    assert TestError(output='output', message=None, type=None).get_xml_element().get('message') == None
    assert TestError(output='output', message='message', type='type').get_xml_element().get('type') == 'type'

    assert TestFailure(output=None, message=None, type=None).get_xml_element().tag == 'failure'

# Generated at 2022-06-11 17:24:48.216096
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    testcase = TestResult("errors", "error", type="error")
    assert testcase.get_attributes() == {
        "type": "error",
        "message": "errors"
    }


# Generated at 2022-06-11 17:24:54.915153
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult("output")
    element = test_result.get_xml_element()
    assert element.text == "output"
    assert element.attrib == {}

    test_result = TestResult("output", message="message", type="type")
    element = test_result.get_xml_element()
    assert element.text == "output"
    assert element.attrib == {"message": "message", "type": "type"}


# Generated at 2022-06-11 17:25:02.067830
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    import xml.etree.ElementTree as ET
    from xml.dom import minidom
    t = TestResult()
    t.output = 'output'
    t.type = 'type'
    t.message = 'message'
    e = ET.Element(t.tag, t.get_attributes())
    e.text = t.output
    assert e.tag == t.tag
    assert e.attrib['message'] == t.message
    assert e.attrib['type'] == t.type
    assert e.text == t.output
    assert ET.tostring(e, encoding='unicode') == ET.tostring(t.get_xml_element(), encoding='unicode')


# Generated at 2022-06-11 17:25:12.014037
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    error = TestSuite(name='errorTestSuite')

    errorAttrib = error.get_xml_element().attrib

    for key, value in _attributes(name=error.name, errors=error.errors, failures=error.failures, disabled=error.disabled).items():
        assert errorAttrib[key] == value

    case1 = TestCase(name='errorTestCase1', assertions=5, classname='errorClassName', time=decimal.Decimal('0.3'))
    case1.errors.append(TestError(output='error output', message='error message', type='error type'))

    case2 = TestCase(name='errorTestCase2', assertions=3, classname='errorClassName', time=decimal.Decimal('0.2'))

# Generated at 2022-06-11 17:25:22.305178
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    failures = [TestFailure("This is a failure"), TestFailure("This is another failure")]
    errors = [TestError("This is an error"), TestError("This is another error")]
    cases = [TestCase("This is a test case")]
    cases.extend([TestCase("This is another test case", failures=failures), TestCase("This is yet another test case", errors=errors)])
    test_suite = TestSuite("This is a test suite", id="TestSuiteId", package="TestSuitePackage", cases=cases)
    test_suite_element = test_suite.get_xml_element()
    print(test_suite_element)
    print(_pretty_xml(test_suite_element))
    assert test_suite_element is not None

# Generated at 2022-06-11 17:25:36.953812
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-11 17:25:43.799142
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name="suite_name")
    expected_output = "<testsuite disabled=\"0\" errors=\"0\" failures=\"0\" hostname=\"None\" id=\"None\" name=\"suite_name\" package=\"None\" skipped=\"0\" tests=\"0\" time=\"0\" timestamp=\"None\"/>"
    assert _pretty_xml(test_suite.get_xml_element()) == expected_output


# Generated at 2022-06-11 17:25:51.981228
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    case = TestCase('test_case')
    suite = TestSuite('test_suite')
    suite.cases.append(case)

    case_element = case.get_xml_element()
    suite_element = suite.get_xml_element()

    assert case_element.tag == 'testcase'
    assert case_element.attrib == {'name': 'test_case'}

    assert suite_element.tag == 'testsuite'
    assert suite_element.attrib == {'tests': '1', 'name': 'test_suite'}
    assert suite_element.findall('testcase')[0].tag == 'testcase'

# Generated at 2022-06-11 17:26:01.210168
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """
    Write test for method get_xml_element of class TestCase
    """
    # Test 1
    # Inputs
    test_case1 = TestCase(
        name='name',
        assertions=1,
        classname='classname',
        status='status',
        time=1,
        errors=[TestError(output='output1'), TestError(output='output2')],
        failures=[TestFailure(output='output1'), TestFailure(output='output2')],
        skipped='skipped',
        system_out='system_out',
        system_err='system_err',
        is_disabled=True
    )

    # Output

# Generated at 2022-06-11 17:26:05.975045
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Arrange
    testcase = TestCase(name="Test 1")

    # Act
    xml_element = testcase.get_xml_element()

    # Assert
    assert xml_element.tag == 'testcase'
    assert xml_element.attrib['name'] == 'Test 1'

    # Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-11 17:26:12.428224
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite('test_suite_1')
    assert ET.tostring(ts.get_xml_element()) == b'<testsuite errors="0" failures="0" hostname="None" id="None" name="test_suite_1" package="None" skipped="0" tests="0" time="0" timestamp="None" />'
    ts.name = 'test_suite_2'
    assert ET.tostring(ts.get_xml_element()) == b'<testsuite errors="0" failures="0" hostname="None" id="None" name="test_suite_2" package="None" skipped="0" tests="0" time="0" timestamp="None" />'



# Generated at 2022-06-11 17:26:23.040757
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    my_test_case = TestCase(name="my_name")
    assert(ET.tostring(my_test_case.get_xml_element()) == b"<testcase name=\"my_name\" />")
    my_test_case.classname = "my_classname"
    my_test_case.time = decimal.Decimal(12.2)
    my_test_case.errors.append(TestError(type = "my_type", message = "my_message", output = "my_output"))
    my_test_case.system_out = "my_system_out"
    my_test_case.system_err = "my_system_err"

# Generated at 2022-06-11 17:26:31.434772
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Unit test for method TestSuite.get_xml_element()"""
    test_suite = TestSuite(name="test_TestSuite_get_xml_element", hostname="localhost", id="1", package="junitxml", timestamp=datetime.datetime.now())  # noqa: E501

    test_case = TestCase(name="test_TestCase_get_xml_element", assertions=0, classname="TestSuite", status="RUN", time=0.0)  # noqa: E501

    test_failure = TestFailure(output="test_TestFailure_get_xml_element", message="failure message", type="failure")  # noqa: E501
    test_case.failures.append(test_failure)


# Generated at 2022-06-11 17:26:40.262908
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite('test',
                           'myhostname',
                           'suite1',
                           'mypackagename',
                           datetime.datetime.now())
    test_case = TestCase('test_case1')
    test_case.add_result(TestError('error message'))
    test_suite.add_test_case(test_case)
    xml_element = test_suite.get_xml_element()
    print(xml_element)
    assert xml_element.attrib.get('name') == test_suite.name

# Generated at 2022-06-11 17:26:52.809238
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    tc = TestCase(name="Test", assertions="1", classname="class_Test", status="Failed to run")
    root = tc.get_xml_element()
    assert root.tag == "testcase"
    assert root.attrib.get("name") == "Test"
    assert root.attrib.get("assertions") == "1"
    assert root.attrib.get("classname") == "class_Test"
    assert root.attrib.get("status") == "Failed to run"

    # add a test failure
    tf = TestFailure(output="failure output", message="failure message", type="failure")
    tc.failures.append(tf)
    root = tc.get_xml_element()
    assert root.tag == "testcase"
    assert root.attrib.get("name")

# Generated at 2022-06-11 17:27:16.199670
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
        test_case = TestCase(name="test_case",
                             time=0.12345,
                             classname="test_class",
                             assertions=10
                             )

        test_suite = TestSuite(name="test_suite",
                               time=0.12345,
                               timestamp=datetime.datetime.now(),
                               hostname="localhost",
                               id="1",
                               package="test_package"
                               )
        test_suite.cases.append(test_case)

        test_suites = TestSuites(name="test_suites")
        test_suites.suites.append(test_suite)

        # create test file
        file = open("test.xml", "w")
        file.write(test_suites.to_pretty_xml())

# Generated at 2022-06-11 17:27:23.813437
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite("first_test", timestamp=datetime.datetime.now())
    xml_element = test_suite.get_xml_element()
    assert xml_element.tag == "testsuite", "The function doesn't return a testsuite element"
    assert xml_element.attrib["timestamp"] != "", "The function doesn't return timestamp attribute it should be"
    assert xml_element.attrib["name"] == test_suite.name, "The function doesn't return name attribute it should be"



# Generated at 2022-06-11 17:27:26.891368
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    assert TestCase(
        name='test_TestCase_get_xml_element',
        assertions=5,
        classname='TestCase',
        status='pass',
        time=1.234567
    ).get_xml_element().to_string() == '<testcase assertions="5" classname="TestCase" name="test_TestCase_get_xml_element" status="pass" time="1.234567"/>'


# Generated at 2022-06-11 17:27:34.610631
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('test.TestCase.test_method', time=0.123, classname='test.TestCase', status='PASS',
                         assertions=1, system_err='this is stderr', system_out='this is stdout')
    test_case.errors.append(TestError('this is error'))
    test_case.failures.append(TestFailure('this is failure'))
    test_case.skipped = 'this is skipped'

    result = test_case.get_xml_element()

    expected = ET.Element('testcase', attrib={'name': 'test.TestCase.test_method', 'time': '0.123',
                                              'classname': 'test.TestCase', 'status': 'PASS', 'assertions': '1'})

# Generated at 2022-06-11 17:27:44.790916
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    standard_TestCase = TestCase(name="TestCase")
    assert pretty_xml(standard_TestCase.get_xml_element()) == '''\
<?xml version="1.0" ?>
<testcase name="TestCase"/>
'''

    full_TestCase = TestCase(
        name="TestCase",
        assertions=123,
        classname="TestValue",
        status="skipped",
        time=4.5,
        errors=[TestError(output="Error output", message="Error message", type="Error type")],
        failures=[TestFailure(output="Failure output", message="Failure message", type="Failure type")],
        skipped="skipped message",
        system_out="system out message",
        system_err="system err message",
    )

# Generated at 2022-06-11 17:27:47.441681
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name='TestSuite1')
    print(ET.tostring(ts.get_xml_element(), encoding='unicode'))

# Generated at 2022-06-11 17:27:55.630755
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case_name',
        assertions=1,
        classname='test_case_class',
        status='test_case_status',
        time=decimal.Decimal(1.0),
    )
    element = test_case.get_xml_element()
    assert element.get('name') == 'test_case_name'
    assert element.get('assertions') == '1'
    assert element.get('classname') == 'test_case_class'
    assert element.get('status') == 'test_case_status'
    assert element.get('time') == '1.0'

# Generated at 2022-06-11 17:28:07.268524
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    c = TestCase(name="test_name", assertions="5", classname="TestClass", status="status", time="2.2", is_disabled=False, skipped="skipped", system_out="system out", system_err="system error")
    c.errors.append(TestError("error message", "error output", "error type"))
    c.failures.append(TestFailure("failure message", "failure output", "failure type"))

    assert c.get_xml_element().tag == "testcase"
    assert c.get_xml_element().attrib['name'] == "test_name"
    assert c.get_xml_element().attrib['assertions'] == "5"
    assert c.get_xml_element().attrib['classname'] == "TestClass"
    assert c.get_xml_element().att

# Generated at 2022-06-11 17:28:19.212378
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        cases=[
            TestCase(name='TestCase1')
        ],
        name='TestSuite1',
        timestamp=datetime.datetime(
            year=2020,
            month=2,
            day=27,
        )
    )
    assert _pretty_xml(test_suite.get_xml_element()) == """<?xml version="1.0" ?>
<testsuite errors="0" failures="0" disabled="0" tests="1" name="TestSuite1" time="0" timestamp="2020-02-27T00:00:00">
    <testcase assertions="None" classname="None" name="TestCase1" status="None" time="None"/>
</testsuite>
"""


# Generated at 2022-06-11 17:28:25.893264
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testcase = TestCase(name="test")
    testsuite = TestSuite(name="foo", cases=[testcase])
    element = testsuite.get_xml_element()
    assert isinstance(element, ET.Element)
    assert element.tag == "testsuite"
    assert element.get('name') == "foo"
    assert element.get('tests') == "1"
    assert len(element) == 1
    assert element[0].tag == "testcase"



# Generated at 2022-06-11 17:28:40.755441
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Check the XML element produced by a complete instance of TestCase."""
    test_output = 'Test output'
    test_message = 'Test message'
    test_type = 'Test type'
    test_result_type = 'Test result type'


# Generated at 2022-06-11 17:28:52.243097
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name="DummyName")
    ts.hostname = "DummyHostname"
    ts.id = "DummyID"
    ts.package = "DummyPackage"
    ts.timestamp = datetime.datetime.now()
    ts.properties["DummyProperty"] = "DummyValue"
    ts.system_out = "DummySystemOut"
    ts.system_err = "DummySystemErr"
    ts.cases.append(TestCase(name="DummyName"))
    ts.cases[0].assertions = 1
    ts.cases[0].classname = "DummyClassname"
    ts.cases[0].status = "DummyStatus"
    ts.cases[0].time = decimal.Decimal("1.1")
    ts.cases[0].errors.append

# Generated at 2022-06-11 17:29:04.139504
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Unit test for method get_xml_element of class TestSuite."""
    # Given
    timestamp = datetime.datetime.now()

# Generated at 2022-06-11 17:29:11.500850
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    result = TestCase(name='a', assertions=1, classname='b', status='c', time=1.23,
                      errors=[TestError(output='d')],
                      failures=[TestFailure(output='e')],
                      skipped='f',
                      system_out='g',
                      system_err='h',
                      is_disabled=True)

    element = result.get_xml_element()

    assert element.tag == 'testcase'
    assert element.attrib == {'name': 'a', 'classname': 'b', 'status': 'c', 'time': '1.23', 'assertions': '1'}

    assert element[0].tag == 'error'
    assert element[0].text == 'd'
    assert element[1].tag == 'failure'
    assert element[1].text == 'e'

# Generated at 2022-06-11 17:29:21.090877
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite = TestSuite('TestSuite name', 'host name', 'package name', datetime.datetime.now(), {'test': 'test'},
                          [TestCase('TestCase name', 123, 'class name', 'status', 123, [TestError('error output',
                                                                                                   'error message',
                                                                                                   'error type')],
                                    [TestFailure('failure output', 'failure message', 'failure type')],
                                    'skipped', 'system-out', 'system-err')], 'system-out', 'system-err')
    assert testSuite.get_xml_element()


# Generated at 2022-06-11 17:29:30.870845
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('test1', time=1.0)
    element = test_case.get_xml_element()
    assert str(element) == '<testcase assertions="None" classname="None" name="test1" status="None" time="1.0" />'

    test_case = TestCase('test1', time=1.0, classname='c')
    element = test_case.get_xml_element()
    assert str(element) == '<testcase assertions="None" classname="c" name="test1" status="None" time="1.0" />'

    test_case = TestCase('test1', time=1.0, classname='c', assertions=1)
    element = test_case.get_xml_element()

# Generated at 2022-06-11 17:29:42.434743
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    output = """<testcase name="test_TestCase_get_xml_element" assertions="0" classname="test_TestCase_get_xml_element" status="_test_status" time="1.0">
    <skipped>_skipped</skipped>
    <error message="_error_message" type="_error_type">_error_output</error>
    <failure message="_failure_message" type="_failure_type">_failure_output</failure>
    <system-out>_system_out</system-out>
    <system-err>_system_err</system-err>
</testcase>"""

    status = "_test_status"
    time = decimal.Decimal("1.0")

    skipped = "_skipped"

    error_message = "_error_message"


# Generated at 2022-06-11 17:29:46.230071
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test = TestCase('Test Case')
    root = ET.Element('root')
    root.append(test.get_xml_element())
    xml = ET.tostring(root, encoding='utf-8')

    assert b'<testcase name="Test Case" />' in xml


# Generated at 2022-06-11 17:29:51.716295
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    tcase = TestCase(name='name', time=decimal.Decimal('0.1'))
    test_case_element = ET.parse('test_files/test_case.xml').getroot()
    assert tcase.get_xml_element() == test_case_element


# Generated at 2022-06-11 17:29:56.697090
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    a = TestSuite(name='test', assertions=5)
    a_xml = a.get_xml_element()
    assert a_xml.attrib['name'] == 'test'
    assert a_xml.attrib['assertions'] == '5'
    assert_xml_equal(a_xml, '<testsuite assertions="5" name="test" />')


# Generated at 2022-06-11 17:30:10.432276
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(
        name="test_case_1",
        assertions=2,
        classname="test_case_1_class",
        status="finished",
        time=decimal.Decimal(0.03)
    )


# Generated at 2022-06-11 17:30:22.765859
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(
        name='test_suite',
        timestamp=datetime.datetime(year=2020, month=6, day=6, hour=6, minute=6, second=6),
        properties={
            'key1': 'value1',
            'key2': 'value2',
        },
        system_out='system_out',
        system_err='system_err',
        cases=[],
    )
    element = suite.get_xml_element()


# Generated at 2022-06-11 17:30:26.567092
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='to_pretty_xml')
    assert_equals(test_suite.get_xml_element(), ET.Element('testsuite', {'name': 'to_pretty_xml', 'tests': '0', 'errors': '0', 'disabled': '0', 'skipped': '0', 'failures': '0', 'time': '0.0'}))
    # Unit test for method _pretty_xml

# Generated at 2022-06-11 17:30:31.558259
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='TestSuiteName')
    element = suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.get('name') == 'TestSuiteName'
    assert ET.tostring(element, encoding='unicode') == '<testsuite name="TestSuiteName"></testsuite>'



# Generated at 2022-06-11 17:30:41.890915
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test_suite_name')
    xml_element = suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'

    suite.cases.append(TestCase(name='test_case_name'))
    xml_element = suite.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib['name'] == 'test_suite_name'
    assert len(xml_element) == 1
    assert xml_element[0].tag == 'testcase'
    assert xml_element[0].attrib['name'] == 'test_case_name'


# Generated at 2022-06-11 17:30:54.035310
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name='testsuite_name',
        hostname='testsuite_hostname',
        id='testsuite_id',
        package='testsuite_package',
        timestamp=datetime.datetime.now()
    )
    test_suite.properties['test_property'] = 'test_value'

    test_case = TestCase(
        name='testcase_name',
        assertions=1,
        classname='testcase_classname',
        status='testcase_status',
        time=decimal.Decimal(1)
    )
    test_case.errors.append(TestError(output='test_error_output'))
    test_case.failures.append(TestFailure(output='test_failure_output'))
    test_case.skipped

# Generated at 2022-06-11 17:31:05.236324
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-11 17:31:14.637965
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    s = TestSuite(name='s1')
    expected = '''\
<?xml version="1.0" ?>
<testsuite disabled="0" errors="0" failures="0" hostname="" id="" name="s1" package="" skipped="0" tests="0" time="0" timestamp=""/>
'''
    assert expected == _pretty_xml(s.get_xml_element())
    expected = '''\
<?xml version="1.0" ?>
<testsuite disabled="0" errors="0" failures="0" hostname="" id="" name="s1" package="" skipped="0" tests="0" time="0" timestamp=""/>
'''
    assert expected == _pretty_xml(s.get_xml_element())

# Generated at 2022-06-11 17:31:20.214866
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name='test_suite',
        errors=5,
        failures=6,
        disabled=7,
        tests=8,
        time=1.2,
    )
    result_string = test_suite.get_xml_element()
    assert result_string.tag == 'testsuite'


# Generated at 2022-06-11 17:31:31.022822
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name = 'foo')
    ts.hostname = 'hostname'
    ts.timestamp = datetime.datetime(2020, 5, 26, 12, 12, 0)
    ts.properties = {'foo': 'foo', 'bar': 'bar'}
    tc = TestCase(name='test.bar')
    tc.classname = 'test.foo'
    tc.status = 'status'
    tc.time = '123.45'
    ts.cases.append(tc)
    ts.system_out = 'system.out'
    ts.system_err = 'system.err'
    xml = ts.get_xml_element()
    assert xml.tag == 'testsuite'

# Generated at 2022-06-11 17:31:43.450284
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testcase = TestCase('TestFindOutlier',
                        assertions=1,
                        classname='test_Box',
                        time=decimal.Decimal(1),
                        failures=[TestFailure(message='Failure 1'), TestFailure(message='Failure 2')],
                        errors=[TestError(message='Error 1'), TestError(message='Error 2')],
                        system_out='System out',
                        system_err='System err')


# Generated at 2022-06-11 17:31:53.731446
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    failures = [TestFailure(), TestFailure()]
    failures[0].output = 'output1'
    failures[1].output = 'output2'
    # invalid:
    #   failures[0].type = 'Error'
    #   failures[1].type = 'Error'
    errors = [TestError(), TestError()]
    errors[0].output = 'error1'
    errors[1].output = 'error2'
    # invalid:
    #   errors[0].type = 'Failure'
    #   errors[1].type = 'Failure'
    test_cases = [TestCase('case1', time=1, classname='class', status='status', assertions=1), TestCase('case2')]
    test_cases[0].failures.extend(failures)
    test_cases[0].errors.extend

# Generated at 2022-06-11 17:32:01.405427
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite_new = TestSuite(
        name="testsuite_new test",
        id="id",
        package="package",
        timestamp=datetime.datetime.now(),
        hostname="hostname",
        properties={
            "a": "1",
            "b": "2"
        },
        system_out="system_out",
        system_err="system_err"
    )

# Generated at 2022-06-11 17:32:11.247592
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    c = TestSuite(
        name = "TestSuite_name",
        hostname = "TestSuite_hostname",
        id = "TestSuite_id",
        package = "TestSuite_package",
        timestamp = datetime.datetime.now(),
        properties = {
            "TestSuite_properties_key_1" : "TestSuite_properties_value_1",
            "TestSuite_properties_key_2" : "TestSuite_properties_value_2"
        }
    )

    tc1 = TestCase(
        name = "TestCase_name_1",
        assertions = 1,
        classname = "TestCase_classname_1",
        status = "TestCase_status_1",
        time = decimal.Decimal(1.2)
    )

# Generated at 2022-06-11 17:32:22.808554
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Instantiate a TestCase (classname, time, skipped, errors, failures)
    tc = TestCase('tc1', classname='tc1', time=1.23, skipped='skipped', errors='errors', failures='failures')
    # Instantiate a TestSuite (name, timestamp, cases)
    ts = TestSuite('ts1', timestamp=datetime.datetime.now(), cases=[tc])
    ts_xml = ET.fromstring(ts.get_xml_element())
    tc_xml = ET.fromstring(tc.get_xml_element())
    xml_string = ET.tostring(tc_xml, 'unicode')
    # If a test case exists
    if et.test_case_exists(ts_xml):
        # A test case exists
        pass
        # Add a test case to the test suite

# Generated at 2022-06-11 17:32:31.400666
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    print('Testing TestSuite.get_xml_element...')

# Generated at 2022-06-11 17:32:33.546849
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test = TestSuite(name = "TestSuiteName", timestamp = datetime.datetime.now())
    test.get_xml_element()


# Generated at 2022-06-11 17:32:36.272855
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Test name = TestSuite()
    test_result = TestSuite()

    # Assert name = TestSuite()
    assert repr(test_result) == "TestSuite()"


# Generated at 2022-06-11 17:32:42.646927
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    # Create a TestSuite instance
    test_suite = TestSuite(name="TestSuiteName", timestamp=None)

    # Generate the XML element of the TestSuite instance
    xml_element = test_suite.get_xml_element()

    # Add a test case to the TestSuite instance
    test_case = TestCase(name = "TestCaseName", time = 1.2)
    test_suite.cases.append(test_case)

    # Add a test error to the test case of the TestSuite instance
    test_error = TestError(output="Test case error message", message="Test case error message", type="Test error type")
    test_case.errors.append(test_error)

    # Create an XML string representing the TestSuite instance
    xml_string = _pretty_xml(xml_element)

# Generated at 2022-06-11 17:32:53.021888
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(
        name="test_name",
        classname="class_name",
        status="status",
        time=10
    )
    test_case.errors.append(TestError(
        output="error_output",
        message="error_message",
        type="error_type"
    ))
    test_case.failures.append(TestFailure(
        output="failure_output",
        message="failure_message",
        type="failure_type"
    ))
    test_case.skipped = "skipped"
    test_case.system_out = "system_output"
    test_case.system_err = "system_error"


# Generated at 2022-06-11 17:33:04.379169
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name = 'test_suite'
                            ,hostname = 'hostname'
                            ,id = 'id'
                            ,package = 'package'
                            ,timestamp = 'timestamp'
                            )
    test_suite.get_xml_element() == '<testsuite disabled="0" errors="0" failures="0" hostname="hostname" id="id" name="test_suite" package="package" skipped="0" tests="0" time="0.00" timestamp="timestamp"></testsuite>'


# Generated at 2022-06-11 17:33:12.214052
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name='TestSuite')
    xml_element = ts.get_xml_element()
    assert xml_element.tag == 'testsuite'
    assert xml_element.attrib == {'name': 'TestSuite'}
    assert xml_element.text is None
    assert xml_element.tail is None
    assert xml_element[:] == []
    assert xml_element.getchildren() == []
    assert xml_element.getroottree() is None
    assert xml_element.getiterator() == [xml_element]


# Generated at 2022-06-11 17:33:22.613479
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    def _get_xml(failure):
        suite = TestSuite(name='abc')
        suite.cases.append(TestCase(name='def'))
        suite.cases[0].failures.append(failure)

        return suite.get_xml_element()

    assert _get_xml(TestFailure(output='<b>foo</b>')).find('failure').text == '&lt;b&gt;foo&lt;/b&gt;'
    assert _get_xml(TestFailure(output='foo', message='bar')).find('failure').attrib == {'type': 'failure', 'message': 'bar'}
    assert _get_xml(TestFailure(output='foo', type='bar')).find('failure').attrib == {'type': 'bar'}

# Generated at 2022-06-11 17:33:32.983460
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-11 17:33:43.198534
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Unit test for method get_xml_element of class TestSuite."""

    test_suite = TestSuite(
        name='test_suite',
        timestamp=datetime.datetime(2020, 1, 1, 0, 0, 0),
        hostname='test_host',
    )
    test_suite.cases.append(
        TestCase(
            name='test_case',
            time=1.234,
            classname='test_class',
            status='test_status',
            assertions=5,
        )
    )
    test_suite.cases[0].errors.append(TestError(output='test_output', message='test_message', type='test_type'))

# Generated at 2022-06-11 17:33:54.253227
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Create a test case
    test_case = TestCase(name='test_case',
        classname='test_class',
        time=decimal.Decimal(0.001),
        status='test_status',
        assertions=10,
        skipped='test_skipped',
        is_disabled=False
    )
    test_case.errors.append(
        TestError(
            output='test_error_output',
            message='test_error_message',
            type='test_error_type',
        ))
    test_case.failures.append(
        TestFailure(
            output='test_failure_output',
            message='test_failure_message',
            type='test_failure_type',
        ))
    test_case.system_out='test_system_out'

# Generated at 2022-06-11 17:34:02.611874
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    print("Executing test_TestSuite_get_xml_element...")