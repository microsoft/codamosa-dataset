

# Generated at 2022-06-21 08:01:22.517565
# Unit test for constructor of class TestResult
def test_TestResult():
    test_class = TestResult
    test_instance = TestResult('test_output')
    assert test_instance.output == 'test_output'


# Generated at 2022-06-21 08:01:25.339242
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    testResult1 = TestResult(None, None, None)
    testResult2 = TestResult(None, None, None)
    assert testResult1 == testResult2


# Generated at 2022-06-21 08:01:27.546570
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_subject = TestFailure()
    output = test_subject.__repr__()
    assert output == 'TestFailure()'



# Generated at 2022-06-21 08:01:35.283681
# Unit test for constructor of class TestCase
def test_TestCase():
    test_case1 = TestCase("test_case")
    test_case2 = TestCase("test_case2", classname="class1")
    test_case3 = TestCase("test_case3", status="pass")
    test_case4 = TestCase("test_case4", time="0.01")
    test_case5 = TestCase("test_case5", assertions=1)
    assert test_case1.name == "test_case"
    assert test_case1.classname is None
    assert test_case1.status is None
    assert test_case1.time is None
    assert test_case1.assertions is None
    assert test_case2.classname == "class1"
    assert test_case3.status == "pass"

# Generated at 2022-06-21 08:01:47.859753
# Unit test for constructor of class TestSuites
def test_TestSuites():
    TestSuite(name="test_suite1", hostname=None, id=None, package=None, timestamp=None)
    TestSuite(name="test_suite2", hostname="localhost", id="1", package=None, timestamp=None)
    TestSuite(name="test_suite3", hostname=None, id=None, package="package1", timestamp=None)
    TestSuite(name="test_suite4", hostname=None, id=None, package=None, timestamp=datetime.datetime.now())

    TestSuites(name=None, hostname=None, id=None, package=None, timestamp=None)
    TestSuites(name="test_suites1", hostname=None, id=None, package=None, timestamp=None)


# Generated at 2022-06-21 08:01:48.848737
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    value = TestSuite(name="test_name")

    assert repr(value) == "TestSuite(name='test_name')"


# Generated at 2022-06-21 08:01:52.527910
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_suites = TestSuites(name='foobar', suites=[])
    assert test_suites.to_pretty_xml() == '<?xml version="1.0" ?>\n<testsuites name="foobar"/>\n'


# Generated at 2022-06-21 08:01:53.088380
# Unit test for constructor of class TestError
def test_TestError():
    TestError()

# Generated at 2022-06-21 08:01:56.026720
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    # Given
    e = TestError("testError")
    # When
    actual = repr(e)
    # Then
    assert actual == "TestError(output='testError')"


# Generated at 2022-06-21 08:01:59.901219
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(
        output='output_test'
    )

    # Get xml element
    xml_element = test_result.get_xml_element()
    assert xml_element.text == 'output_test'


# Generated at 2022-06-21 08:02:14.699032
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    testSuite = TestSuite(name="testSuiteName",
                          hostname="testHostname",
                          id="1",
                          package="testPackage",
                          timestamp="2015-01-01T01:01:01",
                          disabled=2,
                          errors=3,
                          failures=4,
                          skipped=5,
                          tests=6,
                          time=7)

    attributes = testSuite.get_attributes()
    assert attributes["disabled"] == '2'
    assert attributes["errors"] == '3'
    assert attributes["failures"] == '4'
    assert attributes["hostname"] == 'testHostname'
    assert attributes["id"] == '1'
    assert attributes["name"] == 'testSuiteName'
    assert attributes["package"] == 'testPackage'


# Generated at 2022-06-21 08:02:22.902452
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase('TestCase', assertions=1, classname='classname', status='status', time=None)
    test_case_attributes = {
		'name': 'TestCase',
		'assertions': '1',
		'classname': 'classname',
        'status': 'status'
	}
    assert test_case.get_attributes() == test_case_attributes


# Generated at 2022-06-21 08:02:28.245788
# Unit test for constructor of class TestError
def test_TestError():

    name="TestError"
    message="Error message"
    output="Error output"
    type="Error type"

    # Test constructor
    test_error = TestError(output, message, type)

    # Test setting of class attributes
    assert test_error.output == output
    assert test_error.message == message
    assert test_error.type == type


# Generated at 2022-06-21 08:02:35.926466
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # TestCase 1
    tcase1 = TestSuite(
        name= 'TestSuite1',
        id= '1',
        time= '1.0',
    )
    tcase2 = TestSuite(
        name= 'TestSuite1',
        id= '1',
        time= '1.0',
    )
    assert tcase1 == tcase2

    # TestCase 2
    tcase1.name = 'TestSuite2'
    tcase2.name = 'TestSuite2'
    assert tcase1 == tcase2

    # TestCase 3
    tcase1.id = '2'
    tcase2.id = '2'
    assert tcase1 == tcase2

    # TestCase 4
    tcase1.time = '2.0'
    tcase2

# Generated at 2022-06-21 08:02:43.196825
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite1 = TestSuite(name='suite_name', hostname='host_name')
    suite2 = TestSuite(name='suite_name', hostname='host_name')
    assert suite1 == suite2

    suite1 = TestSuite(name='suite_name', hostname='host_name')
    suite2 = TestSuite(name='suite_name', hostname='host_name2')
    assert suite1 != suite2

# Generated at 2022-06-21 08:02:47.249747
# Unit test for constructor of class TestCase
def test_TestCase():
    case = TestCase(name='test_case_name', classname='test_classname', time=1.5, assertions=3)
    assert case.name == 'test_case_name'
    assert case.classname == 'test_classname'
    assert case.time == 1.5
    assert case.assertions == 3



# Generated at 2022-06-21 08:02:49.069837
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    # Pretty test name
    test_name = '__eq__'
    # Assert the equality of two TestError classes
    test_object = TestError(None)
    assert test_object == test_object


# Generated at 2022-06-21 08:02:51.955205
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult(output = "error",message="Fatal Error",type="Error")
    assert result.__post_init__() == "error"

# Generated at 2022-06-21 08:03:03.576114
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    expected = '''<testcase assertions="2" classname="test_class" name="test_name" time="0.123">
  <failure message="failure_message" type="failure_type">failure_output</failure>
  <error message="error_message" type="error_type">error_output</error>
  <skipped>skipped_message</skipped>
  <system-out>system_out</system-out>
  <system-err>system_err</system-err>
</testcase>'''


# Generated at 2022-06-21 08:03:08.476753
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    test_result = TestResult(output='1', message='2', type='3')
    expected_result = 'TestResult(output=\'1\', message=\'2\', type=\'3\')'
    assert(repr(test_result) == expected_result)


# Generated at 2022-06-21 08:03:19.737868
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-21 08:03:31.665213
# Unit test for constructor of class TestFailure
def test_TestFailure():
    import sys

    stdout=sys.stdout
    sys.stdout=sys.stderr

# Generated at 2022-06-21 08:03:41.288702
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    t = TestSuite(name="TestName", hostname="TestHostname", id="TestID", package="TestPackage",
                  timestamp=datetime.datetime(2020, 3, 29, 13, 30, 30, 30, datetime.timezone(datetime.timedelta(seconds=3600))),
                  properties={"TestProperty": "TestValue"},
                  cases=[TestCase(name="TestCaseName", assertions=2, classname="TestClassName", status="TestStatus", time=decimal.Decimal(10))],
                  system_out="TestSystemOut", system_err="TestSystemErr")
    t.disabled = 1
    t.errors = 2
    t.failures = 3
    t.skipped = 4
    t.tests = 5
    t.time = decimal.Decimal(6)

    assert t.get

# Generated at 2022-06-21 08:03:44.220756
# Unit test for constructor of class TestFailure
def test_TestFailure():
    obj = TestFailure()
    assert(obj.output == None)
    assert(obj.message == None)
    assert(obj.type == None)
    assert(obj.tag == 'failure')


# Generated at 2022-06-21 08:03:48.658665
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    inst = TestResult()
    dic = inst.get_attributes()

    assert dic == {
        "output": None,
        "message": None,
        "type": "TestResult"
    }


# Generated at 2022-06-21 08:03:51.452777
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    result = TestFailure()
    expected = '<TestFailure output=None message=None type=failure>'
    assert result.__repr__() == expected


# Generated at 2022-06-21 08:03:53.973906
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    tr = TestResult()
    tr_str = str(tr)
    assert tr_str == "TestResult(output=None, message=None, type=None)"


# Generated at 2022-06-21 08:04:02.481067
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite(
        name="test_name",
        hostname="test_hostname",
        id="test_id",
        package="test_package",
        timestamp=datetime.datetime.now()
    )
    attributes = test_suite.get_attributes()
    assert attributes.get('name') == "test_name"
    assert attributes.get('hostname') == "test_hostname"
    assert attributes.get('id') == "test_id"
    assert attributes.get('package') == "test_package"
    assert attributes.get('timestamp') == test_suite.timestamp.isoformat(timespec='seconds')


# Generated at 2022-06-21 08:04:04.552076
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    obj = TestCase('myname')
    assert _attributes(name='myname') == obj.get_attributes()


# Generated at 2022-06-21 08:04:05.841065
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    t = TestSuites()
    t.__repr__


# Generated at 2022-06-21 08:04:21.549267
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    date_time = datetime.datetime(2020, 9, 13, 13, 15, 46, tzinfo=datetime.timezone.utc)
    test_suite = TestSuite(
        hostname='host',
        id='id',
        name='test_suite_name',
        package='package',
        timestamp=date_time,
        properties={
            'key': 'value'
        },
        cases=[TestCase(
            name='test_case_name1',
            assertions=3,
            classname='class_name',
            status='status',
            time=1
        )],
        system_out='Out text',
        system_err='Err text'
    )

# Generated at 2022-06-21 08:04:23.324968
# Unit test for constructor of class TestResult
def test_TestResult():
	assert TestResult(output = None, message = None , type = None)



# Generated at 2022-06-21 08:04:24.819019
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes()

# Generated at 2022-06-21 08:04:27.323117
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test = TestFailure(type='type', message='message', output='output')
    assert test.__repr__() == "TestFailure(output='output', message='message', type='type')"


# Generated at 2022-06-21 08:04:37.865497
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testCase = TestCase(name="testCase",classname="testClass",time=decimal.Decimal(1.234))
    expected = ET.Element('testcase')
    expected.set('name',"testCase")
    expected.set('classname',"testClass")
    expected.set('time',"1.234")
    result = testCase.get_xml_element()
    assert result.tag == expected.tag
    assert result.get('name') == expected.get('name')
    assert result.get('classname') == expected.get('classname')
    assert result.get('time') == expected.get('time')


# Generated at 2022-06-21 08:04:43.183055
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    """
    Test __eq__ method of class TestError
    """
    # Create a test_obj1
    test_obj1 = TestError(message = "Github")
    try:
        assert test_obj1.__eq__(test_obj1)
    except AssertionError:
        print("TEST FAILED: TestError.__eq__")


# Generated at 2022-06-21 08:04:48.465081
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    myclass = TestCase()
    myclass.name = 'mytest'
    assert repr(myclass) == "TestCase(name='mytest', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"

# Generated at 2022-06-21 08:04:59.324975
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    testsuite_1 = TestSuite(name='Test1')
    case_1 = TestCase(name='TestCase1')
    case_1.failures.append(TestFailure(output='Something failed'))
    testsuite_1.cases.append(case_1)
    testsuite_2 = TestSuite(name='Test2')
    testsuite_2.cases.append(TestCase(name='TestCase2'))
    testsuites = TestSuites(suites=[testsuite_1, testsuite_2])

# Generated at 2022-06-21 08:05:05.907629
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    """Test that the __repr__ of the class TestSuite is valid."""
    element = TestSuite(name='name', timestamp=None).__repr__()
    assert element == 'TestSuite(name=name, hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)'


# Generated at 2022-06-21 08:05:11.384838
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    # Arrange
    name = "test_name"
    classname = "test_classname"
    status = "test_status"
    time = 1
    test_case_1 = TestCase(name=name, classname=classname, status=status, time=time)
    test_case_2 = TestCase(name=name, classname=classname, status=status, time=time)

    # Act
    result = test_case_1 == test_case_2

    # Assert
    assert result == True


# Generated at 2022-06-21 08:05:20.429088
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    """Test that the get_xml_element method on a TestSuites instance raises a ValueError if no suites are present."""
    suites = TestSuites()
    with pytest.raises(ValueError):
        suites.get_xml_element()



# Generated at 2022-06-21 08:05:23.211404
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    error = TestError(message="test message", type="test type")
    error_element = error.get_xml_element()
    assert(error_element.tag == "error")



# Generated at 2022-06-21 08:05:26.826522
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    """Test that __repr__ produces an XML element representing the given instance."""
    result = TestResult(output='failure output')
    assert repr(result) == "<failure>failure output</failure>"

# Generated at 2022-06-21 08:05:30.300191
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_first = TestCase('case_1')
    test_case_second = TestCase('case_1')

    assert test_case_first == test_case_second


# Generated at 2022-06-21 08:05:38.156270
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Input
    test_case = TestCase('test_case_name')
    test_case.classname = 'test.class'
    test_case.time = decimal.Decimal('0.01')
    test_case.skipped = 'skipped'
    test_case.system_out = 'system out'
    test_case.system_err = 'system err'

    # Expected result
    expected_result = """<testcase name="test_case_name" classname="test.class" time="0.01">
  <skipped>skipped</skipped>
  <system-out>system out</system-out>
  <system-err>system err</system-err>
</testcase>"""

    # Result
    result = _pretty_xml(test_case.get_xml_element())

    #

# Generated at 2022-06-21 08:05:41.207450
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    testcase1 = TestCase('test_testcase')
    testcase2 = TestCase('test_testcase')
    assert testcase1 == testcase2


# Generated at 2022-06-21 08:05:53.351004
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    output = None
    message = None
    type = None
    obj = TestResult(output)
    assert hasattr(obj, 'output')
    assert hasattr(obj, 'message')
    assert hasattr(obj, 'type')
    assert obj.output == output
    assert obj.message == message
    assert obj.type == type
    output = None
    message = None
    type = 'failure'
    obj = TestResult(output, message, type)
    assert hasattr(obj, 'output')
    assert hasattr(obj, 'message')
    assert hasattr(obj, 'type')
    assert obj.output == output
    assert obj.message == message
    assert obj.type == type
    output = 'Output'
    message = 'Message'
    type = None

# Generated at 2022-06-21 08:06:04.664695
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult()) == 'TestResult()'
    assert repr(TestResult(output='output')) == "TestResult(message='output')"
    assert repr(TestResult(message='message')) == "TestResult(message='message')"
    assert repr(TestResult(type='type')) == "TestResult(type='type')"
    assert repr(TestResult(output='output', message='message')) == "TestResult(message='message')"
    assert repr(TestResult(output='output', type='type')) == "TestResult(message='output', type='type')"
    assert repr(TestResult(message='message', type='type')) == "TestResult(message='message', type='type')"

# Generated at 2022-06-21 08:06:13.942208
# Unit test for constructor of class TestSuite
def test_TestSuite():
    suite = TestSuite('TestBatch')
    suite.timestamp = datetime.datetime.strptime('14-08-2020T13:41:07', '%d-%m-%YT%H:%M:%S')
    suite.hostname = 'localhost'
    suite.name = 'TestBatch'
    suite.id = '1'
    suite.package = 'TestStuff'
    suite.timestamp = datetime.datetime.strptime('14-08-2020T13:41:07', '%d-%m-%YT%H:%M:%S')
    suite.properties = {'p1': 'v1', 'p2': 'v2'}

    suite2 = TestSuite('TestSuite2')
    suite2.timestamp = datetime.datetime

# Generated at 2022-06-21 08:06:23.796096
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    """Test method __repr__ of class TestError"""
    error = TestError(type='Foo')
    assert str(error) == 'TestError(type=\'Foo\')'

    error = TestError(type='Foo', output='Bar')
    assert str(error) == 'TestError(type=\'Foo\', output=\'Bar\')'

    error = TestError(type='Foo', output='Bar', message='Baz')
    assert str(error) == 'TestError(type=\'Foo\', output=\'Bar\', message=\'Baz\')'



# Generated at 2022-06-21 08:06:42.899551
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    classname = 'myClass'
    error_message = 'I am error'
    failure_message = 'I am failure'
    failure_output = 'I am failure output'
    name = 'myName'
    output = 'I am output'
    package = 'myPackage'
    skipped = 'I am skipped'
    skipped_output = 'I am skipped output'
    status = 'myStatus'
    system_err = 'I am system err'
    system_out = 'I am system out'
    timestamp = datetime.datetime.utcnow()
    type = 'myType'

    properties = {
        'myProperty1': 'myProperty1Value',
        'myProperty2': 'myProperty2Value',
    }

# Generated at 2022-06-21 08:06:44.581836
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    a = TestError()
    b = TestError()
    assert a == b


# Generated at 2022-06-21 08:06:47.342828
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    element = TestFailure()
    assert "output=None, message=None, type='failure'" == element.__repr__()


# Generated at 2022-06-21 08:06:57.349468
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    suite1 = TestSuite('suite1')
    suite2 = TestSuite('suite2')
    suites = TestSuites(name='foo', suites=[suite1, suite2])


# Generated at 2022-06-21 08:07:09.516491
# Unit test for constructor of class TestSuite
def test_TestSuite():

    test_suite_name = "TestSuiteOne"
    test_case_name1 = "TestCaseOne"
    test_case_name2 = "TestCaseTwo"
    test_case_failure_message = "TestCaseOne Failed"

    test_case1 = TestCase(name=test_case_name1, time=1.3)
    test_case1.failures.append(TestFailure(output="TestCaseOne Failed", message=test_case_failure_message))

    test_case2 = TestCase(name=test_case_name2, time=0.0)

    test_suite = TestSuite(name=test_suite_name)

    test_suite.cases.append(test_case1)
    test_suite.cases.append(test_case2)

    assert test_

# Generated at 2022-06-21 08:07:12.266390
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test = TestSuite("name1", "hostname", "id", "package", datetime.datetime.now(), {"prop1": "prop1"}, [], "output", "error")
    assert test.get_attributes()

# Generated at 2022-06-21 08:07:22.073809
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
  import sys
  import inspect
  import dataclasses
  from . import TestResult
  from . import TestFailure
  from . import TestError

  # Check that all data fields are used
  assert 'TestResult' == TestResult.__name__
  assert 'TestFailure' == TestFailure.__name__
  assert 'TestError' == TestError.__name__
  assert 'output' in dataclasses.fields_dict(TestResult)
  assert 'output' in dataclasses.fields_dict(TestFailure)
  assert 'output' in dataclasses.fields_dict(TestError)
  assert 'message' in dataclasses.fields_dict(TestResult)
  assert 'message' in dataclasses.fields_dict(TestFailure)
  assert 'message' in dataclasses.fields_dict(TestError)

# Generated at 2022-06-21 08:07:32.244309
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    """Prove that our __repr__ method works correctly."""

    case = TestCase(
        name='TheName',
        assertions=1,
        classname='A::B::C',
        status='done',
        time=1.234,
        errors=[TestError(output='Test Error')],
        failures=[TestFailure(output='Test Failure')],
        skipped='Test Skipped',
        system_out='System Out',
        system_err='System Err',
        is_disabled=True,
    )

    expected = """<TestCase(name='TheName', assertions=1, classname='A::B::C', status='done', time=1.234, errors=1, failures=1, skipped=True, system_out='System Out', system_err='System Err')>"""
    assert repr(case) == expected




# Generated at 2022-06-21 08:07:37.545727
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:07:40.874241
# Unit test for constructor of class TestResult
def test_TestResult():
    test_result = TestResult(None, None, None)
    assert test_result.output == None
    assert test_result.message == None
    assert test_result.type == None


# Generated at 2022-06-21 08:07:59.610563
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(message='error message', output='error output', type='error type')
    assert test_result.get_attributes() == {'message': 'error message', 'type': 'error type'}


# Generated at 2022-06-21 08:08:11.575633
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    properties = {'a': 'b'}
    now = datetime.datetime.now()
    timestamp = now.isoformat()
    class TestSuite1(TestSuite):
        name = 'testsuite'
        hostname = 'localhost'
        id = '1'
        package = 'test'
        timestamp = now
        properties = properties
        errors = 1
        failures = 2
        tests = 3
        time = 4.0

# Generated at 2022-06-21 08:08:14.479401
# Unit test for constructor of class TestFailure
def test_TestFailure():
    obj = TestFailure(output='output', message='message', type='type')
    assert obj.output == 'output'
    assert obj.message == 'message'
    assert obj.type == 'type'

# Generated at 2022-06-21 08:08:18.556160
# Unit test for constructor of class TestSuite
def test_TestSuite():
    test_suite = TestSuite("suite 1")
    assert test_suite.name == "suite 1"



# Generated at 2022-06-21 08:08:29.134607
# Unit test for constructor of class TestSuite
def test_TestSuite():
    testcase = TestCase(name="t1", \
                        assertions=1, \
                        classname="t2", \
                        status="t3", \
                        time=1.1, \
                        errors=[TestError("t4", "t5")], \
                        failures=[TestFailure("t6", "t7")], \
                        skipped="t8", \
                        system_out="t9", \
                        system_err="t10")

# Generated at 2022-06-21 08:08:35.106576
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    class TestResult_test(TestResult):
        @property
        def tag(self):
            return 'test'

    assert TestResult_test(message='test_message', output='test_output', type='test_type') == TestResult_test(message='test_message', output='test_output', type='test_type')


# Generated at 2022-06-21 08:08:39.409916
# Unit test for constructor of class TestResult
def test_TestResult():
    class mock(TestResult):
        @property
        def tag(self) -> str:
            """Tag name for the XML element created by this result type."""
            return "mock"

    result = mock()
    assert result.type == result.tag

    result = mock(type="tag")
    assert result.type == "tag"


# Generated at 2022-06-21 08:08:43.861524
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(
        output='foo',
        message='bar',
        type='failure',
    )
    expected = '''
    <failure message="bar" type="failure">foo</failure>
    '''.strip()
    assert _pretty_xml(result.get_xml_element()) == expected



# Generated at 2022-06-21 08:08:49.677169
# Unit test for constructor of class TestFailure
def test_TestFailure():
    new_failure = TestFailure(output="This is output", message="This is a message", type="failure")
    assert new_failure.tag == "failure"
    assert new_failure.output == "This is output"
    assert new_failure.message == "This is a message"
    assert new_failure.type == "failure"



# Generated at 2022-06-21 08:08:58.174736
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    """Unit test for method __repr__ of class TestError"""
    assert repr(TestError()) == 'TestError(output=None, message=None, type=None)'
    assert repr(TestError(output='message')) == 'TestError(output="message", message=None, type=None)'
    assert repr(TestError(output='message', message='message')) == 'TestError(output="message", message="message", type=None)'
    assert repr(TestError(output='message', message='message', type='message')) == 'TestError(output="message", message="message", type="message")'


# Generated at 2022-06-21 08:09:39.887131
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    """Unit test for method __eq__ of class TestCase"""
    test_case1 = TestCase('name1', assertions=1, classname='classname1', status='status1', time=decimal.Decimal(1), errors=[TestError(output='output1', message='message1', type='type1')], failures=[TestFailure(output='output2', message='message2', type='type2')], skipped='skipped1', system_out='system_out1', system_err='system_err1')

# Generated at 2022-06-21 08:09:42.198268
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    x = TestFailure(output="my output")
    y = TestFailure(output="my output")
    assert x == y


# Generated at 2022-06-21 08:09:44.046988
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    a = TestCase("test_1")
    b = TestCase("test_1")
    assert a == b


# Generated at 2022-06-21 08:09:48.409734
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    some_testcase = TestCase(name = 'this is the test name')
    some_testcase.__repr__()
    assert some_testcase.__repr__() == 'TestCase(name=\'this is the test name\', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'


# Generated at 2022-06-21 08:09:52.883764
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    kwargs = {
        'name': 'all_suites',
        'suites': [TestSuite(name='suite_1')],
    }
    suite_a = TestSuites(**kwargs)
    suite_b = TestSuites(**kwargs)
    print(suite_a == suite_b)
    assert suite_a == suite_b


# Generated at 2022-06-21 08:10:02.249275
# Unit test for method __eq__ of class TestSuite

# Generated at 2022-06-21 08:10:06.523327
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    o1 = TestResult()
    o2 = TestResult(output='message')
    o3 = TestResult(output='message', message='message', type='type')
    assert o1.get_attributes() == {}
    assert o2.get_attributes() == {}
    assert o3.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-21 08:10:12.019332
# Unit test for constructor of class TestFailure
def test_TestFailure():
    f = TestFailure(output="output",
                    message="message",
                    type="type")
    assert f.output == "output"
    assert f.message == "message"
    assert f.type == "type"
    assert f.tag == "failure"
    assert f.get_attributes() == {'message': 'message',
                                  'type': 'type'}
    assert f.get_xml_element().tag == 'failure'


# Unit tests for constructor of class TestError

# Generated at 2022-06-21 08:10:19.983435
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    """
    Test the method get_attributes of class TestSuites
    """
    suite = TestSuites(name='test')
    suite.suites.append(TestSuite(name='suite1'))
    assert suite.get_attributes() == {
        'name': 'test',
        'tests': 1,
        'disabled': 0,
        'failures': 0,
        'time': 0,
        'errors': 0,
        }


# Generated at 2022-06-21 08:10:27.070849
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(
        name="TestSuite",
        hostname="Hostname",
        id="1",
        package="Package",
        timestamp=datetime.datetime.now(),
        properties={"Prop1": "Value1"},
        cases = [
            TestCase(name="TestCase1"),
            TestCase(name="TestCase2"),
        ],
        system_out="SystemOut",
        system_err="SystemErr",
    )
    xml_element = test_suite.get_xml_element()
    assert isinstance(xml_element, ET.Element)



# Generated at 2022-06-21 08:10:48.097011
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # Instantiating two different instances of TestSuite
    test_suite_1 = TestSuite(name='Suite')
    test_suite_2 = TestSuite(name='Suite')

    # Checking that they are equal
    assert test_suite_1 == test_suite_2
    return test_suite_1, test_suite_2



# Generated at 2022-06-21 08:10:49.714549
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError(output="abc", message="abc") == TestError(output="abc", message="abc")


# Generated at 2022-06-21 08:10:59.691928
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # define variables
    name = "name"
    hostname = "hostname"
    id = "123"
    package = "package"
    timestamp = datetime.datetime.now()
    properties = {'name': 'value'}
    cases = [TestCase("name")]
    system_out = "system_out"
    system_err = "system_err"

    # expected result

# Generated at 2022-06-21 08:11:04.954882
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase('test_name', classname='test_classname', time=3.45)
    target = "TestCase(name='test_name', assertions=None, classname='test_classname', status=None, time=3.45, errors=[], failures=[], skipped=None, system_out=None, system_err=None)"
    assert repr(test_case) == target


# Generated at 2022-06-21 08:11:09.950576
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    _output = "output"
    _message = "message"
    _type = "type"
    _result = TestFailure(output=_output, message=_message, type=_type)
    assert _result.__repr__() != _result.__repr__()


# Generated at 2022-06-21 08:11:12.601021
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    obj = TestSuite(name='name')

    expected = 'TestSuite(name=name)'
    returned = repr(obj)

    assert returned == expected
