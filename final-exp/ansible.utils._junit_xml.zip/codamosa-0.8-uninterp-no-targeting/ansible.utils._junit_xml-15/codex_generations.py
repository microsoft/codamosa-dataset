

# Generated at 2022-06-21 08:01:40.118926
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    classname = 'MyClass'
    name = 'MyName'
    test_suite = TestSuite(classname, name, None, None, None, None)

    assert test_suite.get_attributes() == _attributes(classname=classname, name=name)

# Generated at 2022-06-21 08:01:46.239540
# Unit test for constructor of class TestFailure
def test_TestFailure():
    # Create the values used for the test
    output = 'output'
    message = 'message'
    type = 'type'

    # Create the test object
    tf = TestFailure(output=output, message=message, type=type)

    # Check that the values have been set correctly
    assert tf.output == output
    assert tf.message == message
    assert tf.type == type


# Generated at 2022-06-21 08:01:51.078602
# Unit test for constructor of class TestFailure
def test_TestFailure():
    output = "This is some text"
    message = "This is an error"
    type = "No such file"
    t = TestFailure(output, message, type)
    assert(t.output == output)
    assert(t.message == message)
    assert(t.type == type)


# Generated at 2022-06-21 08:01:55.192067
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    """Test the equal method for TestResult class."""
    class test_class(TestResult):
        @property
        def tag(self):
            return "test"

    test_obj = test_class()
    test_obj_comp = test_class()
    assert test_obj == test_obj_comp
    assert not test_obj != test_obj_comp



# Generated at 2022-06-21 08:01:58.262052
# Unit test for constructor of class TestFailure
def test_TestFailure():
    testFailure = TestFailure("output", "message", "type")
    assert testFailure.output is "output"
    assert testFailure.message is "message"
    assert testFailure.type is "type"


# Generated at 2022-06-21 08:02:03.981098
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    # Arrange
    test_suite = TestSuites(name="Test Suites from Unit Test")

    # Act
    test_suite_attributes = test_suite.get_attributes()

    # Assert
    assert test_suite_attributes == {'name':'Test Suites from Unit Test'}


# Generated at 2022-06-21 08:02:09.507951
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    """Test if __eq__ function compare two objects"""
    tc = TestError('output', 'message', 'type')
    tc2 = TestError('output', 'message', 'type')
    tc3 = TestError('output', 'message', 'type2')
    assert tc == tc2
    assert tc != tc3


# Generated at 2022-06-21 08:02:11.043628
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult(output="The output of the test", type=None)) == 'TestResult(output=\'The output of the test\', message=None, type=None)'


# Generated at 2022-06-21 08:02:12.678000
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert TestResult().get_attributes() == {}


# Generated at 2022-06-21 08:02:16.120574
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    tc1 = TestCase(name="TestCase1")
    tc2 = TestCase(name="TestCase1")
    tc3 = TestCase(name="TestCase2")

    assert tc1 == tc2
    assert tc1 != tc3
    assert tc1 != "TestCase1"

# Generated at 2022-06-21 08:02:31.735304
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test_suite = TestSuite(
        name = "test_name",
        hostname = "test_hostname",
        id = "test_id",
        package = "test_package",
        timestamp = datetime.datetime.now(),
        disabled = 5,
        errors = 1,
        failures = 2,
        skipped = 2,
        tests = 5,
        time = 2.0,
        properties = {"prop_1": "value_1"}
    )

# Generated at 2022-06-21 08:02:35.940813
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    t1 = TestCase(name="test_case_1")
    t2 = TestCase(name="test_case_2")

    assert t1 == t1
    assert t1 != t2


# Generated at 2022-06-21 08:02:41.309979
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    output = 'output'
    message = 'message'
    type = 'type'

    result = TestResult(output=output, message=message, type=type)

    attributes = result.get_attributes()
    assert attributes['message'] == message
    assert attributes['type'] == type


# Generated at 2022-06-21 08:02:49.594743
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name="test case one",
        classname="TestCase",
        assertions=1,
        status="1",
        time=1.2,
        errors=[TestError(
            message="error",
            type="ERROR",
            output="Error occurred",
        )],
        failures=[TestFailure(
            message="failure",
            type="FAILURE",
            output="Failure occurred",
        )],
        skipped="skipped",
        system_out="system out",
        system_err="system err",
        is_disabled=True,
    )

# Generated at 2022-06-21 08:02:57.723356
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    failure_expected = ET.Element('failure', message='message', type='type')
    failure_expected.text = 'output'
    failure_actual = TestFailure(output='output', message='message', type='type').get_xml_element()
    assert failure_actual == failure_expected

    error_expected = ET.Element('error', message='message', type='type')
    error_expected.text = 'output'
    error_actual = TestError(output='output', message='message', type='type').get_xml_element()
    assert error_actual == error_expected


# Generated at 2022-06-21 08:03:09.922552
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite = TestSuite(name = "name",
                      hostname = "hostname",
                      id = "id",
                      package = "package",
                      timestamp = datetime.datetime(year = 2005, month = 1, day = 1),
                      properties = {"key1":"value1","key2":"value2","key3":"value3"},
                      cases = [TestCase(name = "name1"),TestCase(name = "name2"),TestCase(name = "name3")],
                      system_out = "system_out",
                      system_err = "system_err")


# Generated at 2022-06-21 08:03:13.749733
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    classname = 'Hex.Test.Unit.Foo'
    name = 'FooTest'
    time = 3.14159265359

    test_case = TestCase(classname=classname, name=name, time=time)
    actual = test_case.get_attributes()

    expected = {
        'classname': classname,
        'name': name,
        'time': str(time),
    }

    assert expected == actual



# Generated at 2022-06-21 08:03:15.118392
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    """ __eq__() return value equality """
    assert TestFailure() == TestFailure()


# Generated at 2022-06-21 08:03:19.098961
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    testCase = TestCase('test_name')
    assert testCase.__repr__() == 'TestCase(name=test_name, assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'


# Generated at 2022-06-21 08:03:27.598156
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    class test_TestResult(TestResult):
        tag = "test_tag"

    test_result = test_TestResult(
    output="test_output",
    message="test_message",
    type="test_type"
    )

    output = test_result.get_xml_element()

    assert(output.tag == "test_tag")
    assert(output.attrib["message"] == "test_message")
    assert(output.attrib["type"] == "test_type")
    assert(output.text == "test_output")


# Generated at 2022-06-21 08:03:41.179004
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:03:50.871104
# Unit test for constructor of class TestError
def test_TestError():
    error = "Error Message"
    type = "Type Message"

    err = TestError(error, type)
    assert err.type == type
    assert err.message == error
    assert err.output == error
    assert err.tag == "error"

    err = TestError(message=error, type=type)
    assert err.type == type
    assert err.message == error
    assert err.output == error
    assert err.tag == "error"

    err = TestError(output=error, type=type)
    assert err.type == type
    assert err.message == error
    assert err.output == error
    assert err.tag == "error"



# Generated at 2022-06-21 08:03:54.215956
# Unit test for constructor of class TestFailure
def test_TestFailure():
    test_failure = TestFailure("output", "message", "type")
    assert test_failure.output == "output"
    assert test_failure.message == "message"
    assert test_failure.type == "type"


# Generated at 2022-06-21 08:03:59.145728
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase('test_case_name')
    assert test_case.__repr__() == "TestCase(name='test_case_name', assertions=None, classname=None, status=None, time=None, errors=(), failures=(), skipped=None, system_out=None, system_err=None, is_disabled=False)"



# Generated at 2022-06-21 08:04:03.232158
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
	a = TestCase("pippo")
	b = TestCase("pippo")
	assert a == b
	assert not a == TestCase("pluto")

	a = TestCase("pippo")
	b = TestCase("pippo")
	c = TestCase("pluto")
	assert not a == c


# Generated at 2022-06-21 08:04:10.905124
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:04:17.111841
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError(message="Diese Nachricht ist ein Test", output="FooBar", type="Test")
    assert type(error) == TestError
    assert error.message == "Diese Nachricht ist ein Test"
    assert error.output == "FooBar"
    assert error.type == "Test"


# Generated at 2022-06-21 08:04:26.809499
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    suite1 = TestSuite(name='suite1', timestamp=datetime.datetime(2020, 8, 1, 12, 0, 0))
    suite2 = TestSuite(name='suite2', timestamp=datetime.datetime(2020, 8, 2, 12, 0, 0))

    suites = TestSuites(suites=[suite1, suite2])

    assert suites.__repr__() == 'TestSuites(suites=[TestSuite(name=\'suite1\', timestamp=datetime.datetime(2020, 8, 1, 12, 0)), TestSuite(name=\'suite2\', timestamp=datetime.datetime(2020, 8, 2, 12, 0))])'

# Generated at 2022-06-21 08:04:36.663679
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    ts=TestSuites(suites=[TestSuite(name='test', cases=[TestCase(name='test_case', time=1.0), TestCase(name='test_case_two', time=5.5)])])
    ts_dict=ts.get_attributes()
    assert ts_dict['tests']==2
    assert 'time' in ts_dict.keys()
    assert ts_dict['failures']==0
    assert ts_dict['errors']==0
    assert ts_dict['disabled']==0
    assert 'name' in ts_dict.keys()


# Generated at 2022-06-21 08:04:39.847337
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():

    # Setup
    test_result = TestFailure()

    # Test
    result = test_result.__eq__(None)

    # Verify
    assert result == NotImplemented


# Generated at 2022-06-21 08:04:52.412799
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    instance = TestResult()
    assert repr(instance) == 'TestResult(output=None, message=None, type=None)'

    instance = TestResult(output='Output', message='Message', type='Type')
    assert repr(instance) == 'TestResult(output=\'Output\', message=\'Message\', type=\'Type\')'



# Generated at 2022-06-21 08:04:58.491465
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    n1:str = "name"
    n2:str = "name2"
    ts1: TestSuites = TestSuites(n1)
    ts2: TestSuites = TestSuites(n1)
    ts3: TestSuites = TestSuites(n2)
    assert ts1 == ts2
    assert not ts1 == ts3
    assert not ts1 == None


# Generated at 2022-06-21 08:05:01.727872
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():

    result = TestResult("output")

    assert result.__repr__() == '<TestResult: output>'




# Generated at 2022-06-21 08:05:09.981648
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    class TestTestCase:
        @staticmethod
        def assert_element(element):
            assert element.tag == 'testcase'
            assert element.attrib == {'name': 'test_case'}
            assert element.text is None
            assert len(element) == 0

    test_case = TestCase('test_case')
    test_case.assertions = 0
    test_case.classname = 'TestCase'
    test_case.status = 'passed'
    test_case.time = decimal.Decimal('0.2')
    TestTestCase.assert_element(test_case.get_xml_element())



# Generated at 2022-06-21 08:05:20.889306
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    new_TestsSuite = TestSuite("name", "hostname", "id", "package", "timestamp")
    new_TestsSuite.tests=1
    new_TestsSuite.failures=1
    new_TestsSuite.errors=1
    new_TestsSuite.skipped=1
    new_TestsSuite.time=1.0
    new_TestsSuite.disabled=1
    new_TestSuite = TestSuite("name", "hostname", "id", "package", "timestamp")
    assert new_TestSuite == new_TestsSuite

# Generated at 2022-06-21 08:05:23.333281
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    failure = TestResult(type='test type')
    assert failure.type == 'test type'
    failure = TestResult()
    assert failure.type == 'TestResult'


# Generated at 2022-06-21 08:05:32.658568
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    test_cases = [
        {"name": "name", "id": "id", "hostname": "hostname", "package": "package", "timestamp": datetime.datetime(2020, 1, 2, 3, 4, 5, 60000), "system_out": "system_out", "system_err": "system_err", "properties": {"property_name": "property_value"}, "cases": [TestCase("name")]},
    ]
    for test_case in test_cases:
        test_suite = TestSuite(**test_case)
        actual = repr(test_suite)
        assert actual == f'<TestSuite {test_case}>'

# Generated at 2022-06-21 08:05:43.725438
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    """
    Test if the method __repr__ of TestError return the expected value.
    """
    from dataclasses import replace
    from datetime import datetime
    from decimal import Decimal
    from unittest import TestCase

    from ocrd_utils.classifier.dataclasses_junit import TestError, TestCase, TestSuite

    time = Decimal('0.3')
    timestamp = datetime(2020, 4, 8, 17, 41, 10)
    classname = 'ocrd_utils.classifier.dataclasses_junit'
    name = 'test_TestError___repr__'
    test_suite = TestSuite(name=name, timestamp=timestamp)
    test_case = TestCase(name=name, classname=classname, time=time)
    test_error = TestError

# Generated at 2022-06-21 08:05:48.927127
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    a = TestError(message='This is a test error message.',
                  output='This is the output.',
                  type='TestError')
    b = TestError(message='This is a test error message.',
                  output='This is the output.',
                  type='TestError')

    assert a == b



# Generated at 2022-06-21 08:05:53.126784
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    test_result1 = TestError(output="test", message="first message", type="error")
    test_result2 = TestError(output="test", message="first message", type="error")
    assert test_result1 == test_result2

# Generated at 2022-06-21 08:06:05.307763
# Unit test for constructor of class TestResult
def test_TestResult():
    output = "output test"
    message = "message test"
    type = "type test"
    result = TestResult(output, message, type)
    assert output == result.output
    assert message == result.message
    assert type == result.type



# Generated at 2022-06-21 08:06:08.296436
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase(name="PythonPower-UnitTest")
    assert tc.name == "PythonPower-UnitTest"

if __name__ == '__main__':
    test_TestCase()

# Generated at 2022-06-21 08:06:09.896973
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    pass


# Generated at 2022-06-21 08:06:18.900167
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    print('TestResult.__repr__')
    # __repr__
    # No args
    test_result = TestFailure(None, None, None)
    assert test_result.__repr__() == "TestFailure(output=None, message=None, type='failure')"


    # One arg
    test_result = TestFailure(None, None, None)
    assert test_result.__repr__() == "TestFailure(output=None, message=None, type='failure')"


    # Two args
    test_result = TestFailure(None, None, None)
    assert test_result.__repr__() == "TestFailure(output=None, message=None, type='failure')"


    # Three args
    test_result = TestFailure(None, None, None)
    assert test_

# Generated at 2022-06-21 08:06:24.410521
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    actual = _attributes(
            disabled=0,
            name='name',
            tests=0,
            time=0,
    )
    expected = {
            'disabled': '0',
            'name': 'name',
            'tests': '0',
            'time': '0',
    }
    assert actual == expected


# Generated at 2022-06-21 08:06:32.985458
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    print("test_TestSuite___eq__(): START")
    # Test for __eq__ method
    ts1 = TestSuite('Suite1')
    ts2 = TestSuite('Suite2')
    ts3 = TestSuite('Suite1')
    assert ts1 == ts1
    assert ts1 == ts3
    assert not ts1 == ts2
    assert ts1 != ts2
    assert ts2 != ts1
    del ts1
    del ts2
    del ts3
    print("test_TestSuite___eq__(): END")


# Generated at 2022-06-21 08:06:34.021408
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    result = TestError()
    assert result.type == 'error'



# Generated at 2022-06-21 08:06:40.871471
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    # Create an instance of TestError with initial values
    error_instance = TestError(output="line1\nline2", message="message", type="type")

    # Get the expected result
    expected = "TestError(output='line1\\nline2', message='message', type='type')"

    # Perform the test
    assert repr(error_instance) == expected



# Generated at 2022-06-21 08:06:52.540871
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    print("#### Unit test for method __eq__ of class TestSuite ####\n")

    properties = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
        'key4': 'value4'
    }
    properties2 = {
        'key1': 'value1',
        'key2': 'value2',
        'key4': 'value4'
    }
    testcase1 = TestCase(
        'TestCase1',
        assertions=2,
        classname='TestClass',
        status='success'
    )
    testcase2 = TestCase(
        'TestCase2',
        assertions=2,
        classname='TezstClass',
        status='success'
    )

# Generated at 2022-06-21 08:06:56.061689
# Unit test for constructor of class TestFailure
def test_TestFailure():
    output = "Test";
    message = "Failed"

    result = TestFailure(output=output, message=message);

    assert result.output == "Test"
    assert result.message == "Failed"
    assert result.type == "failure"


# Generated at 2022-06-21 08:07:09.056798
# Unit test for constructor of class TestResult
def test_TestResult():
    test_output = "test_output"
    test_message = "test_message"
    test_type = "test_type"
    test_result = TestResult(test_output, test_message, test_type)
    assert test_result.output == test_output
    assert test_result.message == test_message
    assert test_result.type == test_type


# Generated at 2022-06-21 08:07:13.029239
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    val1 = TestError()
    val2 = TestError(
        output='output',
        message='message',
    )
    assert repr(val1) == 'TestError()'
    assert repr(val2) == "TestError(output='output', message='message')"


# Generated at 2022-06-21 08:07:23.653826
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    date = datetime.datetime(year=2020, month=1, day=1, hour=13, minute=30, second=15, microsecond=0)

# Generated at 2022-06-21 08:07:27.678391
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a = TestSuites()
    b = TestSuites()

    assert a == b

    a.name = 'name1'
    b.name = 'name1'

    assert a == b

    a.name = 'name2'

    assert a != b



# Generated at 2022-06-21 08:07:33.126374
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase("name", 1, "classname", "status", decimal.Decimal(1.234))
    attributes = test_case.get_attributes()
    assert attributes["assertions"] == "1"
    assert attributes["classname"] == "classname"
    assert attributes["name"] == "name"
    assert attributes["status"] == "status"
    assert attributes["time"] == "1.234"


# Generated at 2022-06-21 08:07:39.207284
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    TestCase = TestCase(name='test_name')
    root = TestCase.get_xml_element()

    #asserts
    assert root.tag == 'testcase'
    assert root.attrib == {'name': 'test_name'}
    assert root.text == None



# Generated at 2022-06-21 08:07:45.633997
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    output = "exception"
    message = "error message"
    type = "error type"
    

    et_element = ET.Element(TestError(output, message, type).tag, TestError(output, message, type).get_attributes())
    et_element.text = TestError(output, message, type).output
    
    assert TestError(output, message, type).get_xml_element() == et_element


# Generated at 2022-06-21 08:07:48.875807
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    assert repr(TestCase(name='test')) == 'TestCase(name=test, assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)', 'Wrong TestCase.__repr__'


# Generated at 2022-06-21 08:07:51.147985
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    """get_attributes is not implemented"""
    with pytest.raises(NotImplementedError):
        TestResult().get_attributes()


# Generated at 2022-06-21 08:07:56.909041
# Unit test for constructor of class TestSuite
def test_TestSuite():
    timestamp = datetime.datetime.strptime("2019-10-09T12:12:38", "%Y-%m-%dT%H:%M:%S")
    suite = TestSuite("testsuite_name", timestamp=timestamp, tests="1")
    # Test constructor
    assert suite.name == "testsuite_name"
    # Test method get_xml_element
    assert suite.get_xml_element().tag == "testsuite"
    # Test method get_attributes
    assert suite.get_attributes()['name'] == "testsuite_name"
    assert suite.get_attributes()['tests'] == "1"


# Generated at 2022-06-21 08:08:09.078324
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    # Assert that the test result type is derived from the class name by default.
    assert TestError().type == 'error'

    # Assert that the test result type is not overridden if already set.
    assert TestError(type='foobar').type == 'foobar'


# Generated at 2022-06-21 08:08:12.945676
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    actual = TestError(message="a", type="b", output="c")
    expected = TestError(output="c", type="b", message="a")
    assert actual == expected


# Generated at 2022-06-21 08:08:19.835825
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure() == TestFailure()
    assert TestFailure('a') == TestFailure('a')
    assert TestFailure('a') != TestFailure('aa')
    assert TestFailure('a') != TestFailure(type='a')
    assert TestFailure('a') != TestFailure(output='a')
    assert TestFailure(type='a') == TestFailure(type='a')
    assert TestFailure(type='a') != TestFailure(type='aa')
    assert TestFailure(type='a') != TestFailure('a')
    assert TestFailure(type='a') != TestFailure(output='a')
    assert TestFailure(output='a') == TestFailure(output='a')
    assert TestFailure(output='a') != TestFailure(output='aa')
    assert TestFailure(output='a') != TestFailure('a')

# Generated at 2022-06-21 08:08:21.404569
# Unit test for constructor of class TestCase
def test_TestCase():
    assert TestCase(name='test_output')


# Generated at 2022-06-21 08:08:31.610729
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_1 = TestCase(name = 'test_case_1')
    test_case_2 = TestCase(name = 'test_case_2')
    test_case_3 = TestCase(name = 'test_case_3')
    test_case_4 = TestCase(name = 'test_case_3')

    # Test case 1 assert statement
    assert test_case_1 != test_case_2, "test_case_1 != test_case_2"
    assert test_case_1 != test_case_3, "test_case_1 != test_case_3"
    assert test_case_1 != test_case_4, "test_case_1 != test_case_4"

# Generated at 2022-06-21 08:08:35.228050
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    suites = TestSuites(name='test')
    assert 'name="test"' in suites.get_attributes()


# Generated at 2022-06-21 08:08:38.144320
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError("error", message="error_message")
    assert (error.output == "error")
    assert (error.message == "error_message")
    assert (error.type == "error")


# Generated at 2022-06-21 08:08:45.823325
# Unit test for constructor of class TestError
def test_TestError():
    error1 = TestError("hi", "hi")
    assert error1.output == "hi"
    assert error1.message == "hi"
    assert error1.type == "error"

    error2 = TestError("hi")
    assert error2.output == "hi"
    assert error2.message is None
    assert error2.type == "error"

    error3 = TestError("hi", "hi", "hi")
    assert error3.output == "hi"
    assert error3.message == "hi"
    assert error3.type == "hi"


# Generated at 2022-06-21 08:08:51.056057
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    assert TestCase(name='Test') == TestCase(name='Test')
    assert TestCase(name='Test') != TestCase(name='Hello')
    assert TestCase(name='Test') != TestCase(name='Test', assertions=0)
    assert TestCase(name='Test', assertions=0) == TestCase(name='Test', assertions=0)

# Generated at 2022-06-21 08:08:55.761824
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    print('Testing get_attributes for TestResult')
    result = TestResult(message='Test Message', output='Test Output', type='Test Type')
    assert result.get_attributes() == {'message': 'Test Message', 'type': 'Test Type'}
    print('Testing passed!')


# Generated at 2022-06-21 08:09:23.684113
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    """Unit test for method __repr__ of class TestError"""
    test_error = TestError(
        output='',
        message=None,
        type=None,
    )

    assert str(test_error) == "TestError(output='', message=None, type=None)"
    assert test_error.__repr__() == "TestError(output='', message=None, type=None)"


# Generated at 2022-06-21 08:09:25.423592
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    _repr = "<TestResult(output='', message=None, type=None)>"
    assert TestResult().__repr__() == _repr


# Generated at 2022-06-21 08:09:28.553119
# Unit test for constructor of class TestResult
def test_TestResult():
    test1 = TestResult(output='test info', message='test message')
    assert test1.output == 'test info'
    assert test1.message == 'test message'
    assert test1.type is None



# Generated at 2022-06-21 08:09:39.739560
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure(output='error output') == TestFailure(output='error output')
    assert TestFailure(output='error output') == TestFailure(output='error output', message='error message')
    assert TestFailure(output='error output') == TestFailure(output='error output', type='error type')
    assert TestFailure(output='error output') == TestFailure(output='error output', message='error message', type='error type')

    assert TestFailure(output='error output') != TestFailure(output='error output 2')
    assert TestFailure(output='error output') != TestFailure(message='error message')
    assert TestFailure(output='error output') != TestFailure(type='error type')
    assert TestFailure(output='error output') != TestFailure(message='error message', type='error type')


# Generated at 2022-06-21 08:09:48.266022
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Create a TestCase instance and set all values
    testcase = TestCase('TestCase1')
    testcase.assertions = '1'
    testcase.classname = 'TestClass'
    testcase.system_err = 'SystemErr'
    testcase.system_out = 'SystemOut'
    testcase.time = decimal.Decimal(3.4)
    
    # Create a TestSuite instance and add TestCase instance
    testsuite = TestSuite('TestSuite1')
    testsuite.cases.append(testcase)

    # Create a TestSuite instance
    testsuites = TestSuites('TestSuites1')
    testsuites.suites.append(testsuite)

    # Create a XML element from the TestSuites instance
    root = testsuites.get_xml_element()

# Generated at 2022-06-21 08:09:53.068361
# Unit test for constructor of class TestCase
def test_TestCase():
    test = TestCase(name = 'test_test_case', assertions = 2, \
                    classname = 'TestCase', status = 'passed', time = 2.3)
    assert(test.name == 'test_test_case')
    assert(test.assertions == 2)
    assert(test.classname == 'TestCase')
    assert(test.status == 'passed')
    assert(test.time == 2.3)


# Generated at 2022-06-21 08:10:02.424976
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # Test case 1
    ts1 = TestSuite(name="Test suite name")
    ts2 = TestSuite(name="Test suite name")
    assert ts1 == ts2

    # Test case 2
    ts1 = TestSuite(name="Test suite name", timestamp=datetime.datetime(2001, 2, 3, 4, 5, 6))
    ts2 = TestSuite(name="Test suite name", timestamp=datetime.datetime(2001, 2, 3, 4, 5, 6))
    assert ts1 == ts2

    # Test case 3
    ts1 = TestSuite(name="Test suite name", timestamp=datetime.datetime(2001, 2, 3, 4, 5, 6))

# Generated at 2022-06-21 08:10:04.232484
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite('foo')
    assert suite.get_attributes() == {'name': 'foo'}


# Generated at 2022-06-21 08:10:08.014087
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Test method get_xml_element in class TestResult"""
    # Test whether tag and attributes are correctly extracted
    test_result = TestResult('test_output')
    assert 'failure' == test_result.get_xml_element().tag
    assert test_result.output == test_result.get_xml_element().text


# Generated at 2022-06-21 08:10:09.990304
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    expected = """<?xml version="1.0" ?>
<testsuites disabled="0" errors="0" failures="0" tests="0" time="0.0"/>
"""
    testsuites = TestSuites(name=None)
    assert ET.tostring(testsuites.get_xml_element(), encoding="unicode") == expected


# Generated at 2022-06-21 08:10:42.367839
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    # Test composition of output in result
    expected_output = 'some other output'
    assert TestFailure(output='some output') == TestFailure(output='some output')
    assert TestFailure(output='some output') != TestFailure(output=expected_output)
    assert TestError(output='some output') == TestError(output='some output')
    assert TestError(output='some output') != TestError(output=expected_output)

    # Test composition of message in result
    expected_message = 'some other message'
    assert TestFailure(message='some message') == TestFailure(message='some message')
    assert TestFailure(message='some message') != TestFailure(message=expected_message)
    assert TestError(message='some message') == TestError(message='some message')

# Generated at 2022-06-21 08:10:44.696420
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    """Unit test for method __post_init__ of class TestResult"""
    testresult = TestResult()
    assert testresult.type == testresult.tag


# Generated at 2022-06-21 08:10:46.698548
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    name = None
    suites = []
    expected = TestSuites(name,suites)
    actual = TestSuites(name,suites)
    assert expected == actual


# Generated at 2022-06-21 08:10:51.747580
# Unit test for constructor of class TestSuite
def test_TestSuite():
    """Test for the instantiation of TestSuite"""
    test1=TestSuite(name="test_case_name",hostname="localhost", id="id", package="package", timestamp=datetime.datetime.now())
    test2=TestSuite(name="test_name_2")
    assert test1.hostname == "localhost" and test2.name == "test_name_2"

# Generated at 2022-06-21 08:10:55.033285
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    a = TestCase('a')
    expected = {'name': 'a'}
    actual = a.get_attributes()
    assert expected == actual


# Generated at 2022-06-21 08:11:00.568433
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase('example_case')
    assert tc.assertions == None
    assert tc.classname == None
    assert tc.status == None
    assert tc.time == None
    assert tc.errors == []
    assert tc.failures == []
    assert tc.skipped == None
    assert tc.system_out == None
    assert tc.system_err == None

test_TestCase()

# Generated at 2022-06-21 08:11:08.692312
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    expected = "TestSuite(name='Test Suite name', hostname='Test Hostname', id='Test ID', package='Test Package', timestamp=datetime.now, properties={'test': 'test'}, cases=[], system_out='Test System Out', system_err='Test System Error')"
    actual = repr(TestSuite(name='Test Suite name', hostname='Test Hostname', id='Test ID', package='Test Package', timestamp=datetime.now, properties={'test': 'test'}, cases=[], system_out='Test System Out', system_err='Test System Error'))
    assert expected == actual


# Generated at 2022-06-21 08:11:11.789202
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    TS1 = TestSuite('TS1')
    TS2 = TestSuite('TS2')

    assert TS1 == TS1
    assert TS1 != TS2


# Generated at 2022-06-21 08:11:18.163186
# Unit test for method get_xml_element of class TestSuite