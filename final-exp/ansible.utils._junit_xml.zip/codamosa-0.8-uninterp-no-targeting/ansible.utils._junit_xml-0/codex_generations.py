

# Generated at 2022-06-21 08:01:30.303496
# Unit test for constructor of class TestSuites

# Generated at 2022-06-21 08:01:32.700849
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    """Unit test for method __repr__ of class TestResult."""
    assert repr(TestResult()) == '<TestResult>'



# Generated at 2022-06-21 08:01:35.261220
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult()

    assert result.output is None
    assert result.message is None
    assert result.type == 'TestResult'


# Generated at 2022-06-21 08:01:47.379775
# Unit test for constructor of class TestSuite
def test_TestSuite():
    testSuite = TestSuite(name='TestSuite')

    assert testSuite.name == 'TestSuite'
    assert testSuite.hostname is None
    assert testSuite.id is None
    assert testSuite.package is None
    assert testSuite.timestamp is None

    assert testSuite.properties == {}
    assert testSuite.cases == []
    assert testSuite.system_out is None
    assert testSuite.system_err is None

    assert testSuite.disabled == 0
    assert testSuite.errors == 0
    assert testSuite.failures == 0
    assert testSuite.skipped == 0
    assert testSuite.tests == 0
    assert testSuite.time == decimal.Decimal(0)


# Generated at 2022-06-21 08:01:52.986511
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    suite = TestSuites(name='sample_suite')
    testcases = []

    testcase1 = TestCase(
        name='sample_testcase',
        assertions=None,
        classname='sample_classname',
        status='sample_status',
        time=None,
        errors=[
            TestError(output='sample_error_output', message='sample_error_message', type='sample_error_type')
        ],
        failures=[
            TestFailure(output='sample_failure_output', message='sample_failure_message', type='sample_failure_type')
        ],
        skipped='sample_skipped',
        system_out='sample_system_out',
        system_err='sample_system_err',
        is_disabled=False
    )


# Generated at 2022-06-21 08:02:04.407434
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='a_test_case', classname="class_name", assertions="1", status="2", time="0.25")
    test_case.skipped = "skipped"
    test_case.system_out = "system_out"
    test_case.system_err = "system_err"
    test_case.errors.append(TestError(output="error_output"))
    test_case.failures.append(TestFailure(output="failure_output"))

    xml_element = test_case.get_xml_element()

    assert xml_element.tag == "testcase"

# Generated at 2022-06-21 08:02:09.456427
# Unit test for constructor of class TestResult
def test_TestResult():
    new_TestResult = TestResult(
        output='None',
        message='None',
        type='None')
    assert new_TestResult.output == 'None'
    assert new_TestResult.message == 'None'
    assert new_TestResult.type == 'None'


# Generated at 2022-06-21 08:02:14.173187
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testcase = TestCase(name='test_case', assertions='10', classname='tests.test_case')
    attributes = testcase.get_attributes()
    assert attributes['name'] == 'test_case'
    assert attributes['assertions'] == '10'
    assert attributes['classname'] == 'tests.test_case'


# Generated at 2022-06-21 08:02:17.090754
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError(output = "Testing", message = "Message", type = "Type")
    assert error.output == "Testing"
    assert error.message == "Message"
    assert error.type == "Type"


# Generated at 2022-06-21 08:02:20.545175
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
	assert TestFailure(output, message, type).__repr__() == 'TestFailure(output=output, message=message, type=type)'


# Generated at 2022-06-21 08:02:28.516683
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    output_var = None
    message_var = None
    type_var = None
    test_var = TestResult(output=output_var, message=message_var, type=type_var)
    assert test_var.__repr__() == "TestResult(output=None, message=None, type=None)"

# Generated at 2022-06-21 08:02:39.603941
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    # Arrange
    test_suites = TestSuites(
        name="TestSuite",
        suites=[
            TestSuite(
                name="TestCase1",
                cases=[TestCase(name="TestCase1")]
            ),
            TestSuite(
                name="TestCase2",
                cases=[TestCase(name="TestCase2")]
            )
        ]
    )


# Generated at 2022-06-21 08:02:48.828043
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    assert TestSuite(name='name', id='id') == TestSuite(name='name', id='id')
    assert TestSuite(name='name', id='id') == TestSuite(name='name', id='id', properties=dict(a='a'), cases=[TestCase(name='name', classname='classname')])
    assert TestSuite(name='name', id='id') != TestSuite(name='name', id='id1')
    assert TestSuite(name='name', id='id') != TestSuite(name='name1', id='id')
    assert TestSuite(name='name', id='id') != TestSuite(name='name', id='id', properties=dict(a='a'))

# Generated at 2022-06-21 08:02:50.041148
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    # Create instance of TestFailure
    test_object1 = TestFailure()
    test_object2 = TestFailure()
    assert test_object1 == test_object2


# Generated at 2022-06-21 08:02:58.177577
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Unit test for method get_xml_element of class TestResult"""

    # Initialize a TestResult
    test_result = TestResult(
        output='Unit Test Output',
        message='Unit Test Message',
        type='Unit Test Type'
    )

    # Test the TestResult
    assert test_result.get_xml_element() == ET.Element('testresult', {
        'message': 'Unit Test Message',
        'type': 'Unit Test Type'
    })
    assert test_result.get_xml_element().text == 'Unit Test Output'



# Generated at 2022-06-21 08:03:02.107617
# Unit test for constructor of class TestFailure
def test_TestFailure():
    errorSample = TestFailure(type='a', message='message', output='output')
    assert errorSample.output == 'output'
    assert errorSample.message == 'message'
    assert errorSample.type == 'a'


# Generated at 2022-06-21 08:03:04.638039
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a = TestSuites(name='name')
    b = TestSuites(name='name')
    assert a == b


# Generated at 2022-06-21 08:03:15.718673
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    xml_elem = TestSuites(name="Great Testsuites", suites=[TestSuite(name="Outstanding testsuite", hostname="localhost", id="1", package="com.example.tests", timestamp=datetime.datetime.now(), properties={}, cases=[TestCase(name="Great case", assertions=1, classname="ClassX", status="5", time=decimal.Decimal(1.0), errors=[], failures=[], skipped=None, system_out="All clear", system_err=None, is_disabled=False)], system_out="All systems operational", system_err=None)], disabled=0, errors=0, failures=0, tests=1, time=1).get_xml_element()
    assert xml_elem.find('testsuite').find('testcase').attrib['name'] == "Great case"




# Generated at 2022-06-21 08:03:20.662485
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    assert ET.tostring(TestError(message='msg', type='tyt'), encoding='unicode') == '<error message="msg" type="tyt" />'
    assert ET.tostring(TestFailure(message='msg', type='tyt'), encoding='unicode') == '<failure message="msg" type="tyt" />'


# Generated at 2022-06-21 08:03:25.056575
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    # Fixture
    TestSuite_ = TestSuite('name')

    # Test
    TestSuite___repr__ = TestSuite_.__repr__()

    # Verify
    assert TestSuite___repr__ == '<TestSuite \'name\'>'


# Generated at 2022-06-21 08:03:58.257141
# Unit test for method __eq__ of class TestSuites

# Generated at 2022-06-21 08:04:07.155948
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    t0 = TestSuite(
        name="name",
        hostname="hostname",
        id="id",
        package="package",
        timestamp=datetime.datetime(2020, 1, 1, 0, 0, 0),
        properties={"0": "0"},
        cases=[TestCase(name="1", assertions=1, classname="2", status="3", time=decimal.Decimal(4), errors=[TestError(output="5", message="6", type="7")], failures=[TestFailure(output="8", message="9", type="10")], skipped="11", system_out="12", system_err="13", is_disabled=True)],
        system_out="system_out",
        system_err="system_err"
    )

# Generated at 2022-06-21 08:04:10.817564
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    class CustomTestResult(TestResult):
        tag = 'custom_tag'
    r = CustomTestResult()
    assert r.type == 'custom_tag'
    r = CustomTestResult(type='test_test')
    assert r.type == 'test_test'


# Generated at 2022-06-21 08:04:13.796338
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    testcase_result = TestResult()

    element = testcase_result.get_xml_element().tag
    assert element == 'result'



# Generated at 2022-06-21 08:04:17.822079
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    """Unit testing of method __eq__(other) of class TestCase"""
    instance = TestCase("test_case_name")
    other = TestCase("test_case_name")
    assert intance == other


# Generated at 2022-06-21 08:04:24.557961
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    class MyResult(TestResult): tag = 'result'

    o = MyResult()

    message = "Message"
    o.message = message

    output = "Output"
    o.output = output

    type = "Type"
    o.type = type

    assert repr(o) == "MyResult(message={}, output={}, type={})".format(repr(message), repr(output), repr(type))


# Generated at 2022-06-21 08:04:27.945090
# Unit test for constructor of class TestSuite
def test_TestSuite():
    car = TestSuite("name","hostname",1,"package","timestamp")
    assert car.name == "name"
    assert car.hostname == "hostname"
    assert car.id == 1
    assert car.package == "package"
    assert car.timestamp == "timestamp"



# Generated at 2022-06-21 08:04:30.108465
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    with pytest.raises(Exception) as e:
        TestSuites.__eq__()
    

# Generated at 2022-06-21 08:04:33.532676
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult('output', 'message', 'type')
    assert result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-21 08:04:35.395295
# Unit test for constructor of class TestCase
def test_TestCase():
    case = TestCase(name='test_name')
    assert case.name == 'test_name'


# Generated at 2022-06-21 08:05:05.960813
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    result = TestSuites('foo').__repr__()
    assert result == 'TestSuites(name=foo, suites=[])'


# Generated at 2022-06-21 08:05:06.937887
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    try:
        TestResult()
    except:
        error = True
    else:
        error = False

    assert error


# Generated at 2022-06-21 08:05:10.297667
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert TestSuites(name='name', suites=[TestSuite(name='suite name', cases=[TestCase(name='case name')])]).__repr__() == "TestSuites(name='name', suites=[TestSuite(name='suite name', cases=[TestCase(name='case name')])])"

# Generated at 2022-06-21 08:05:20.803380
# Unit test for constructor of class TestSuite
def test_TestSuite():
    test_case = TestCase('name', 'classname', 1, 'status', 2.3)
    test_suite = TestSuite('name', 'hostname', 'id', 'package', test_case, 'system_out', 'system_err')
    assert test_suite.name == 'name' and test_suite.hostname == 'hostname' and test_suite.id == 'id' and test_suite.package == 'package' and test_suite.system_out == 'system_out' and test_suite.system_out == 'system_out'


# Generated at 2022-06-21 08:05:31.718106
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-21 08:05:38.156329
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    TestFailure = dataclasses.dataclass(frozen=True, init=True, repr=True, eq=True, order=False, unsafe_hash=False,
                                        metadata={}, default=None, init_kwargs=False)(TestFailure)

    test_output = 'output'
    test_message = 'message'
    test_type = 'type'

    test_instance = TestFailure(output=test_output, message=test_message, type=test_type)
    expected_string = f'TestFailure(output=\'{test_output}\', message=\'{test_message}\', type=\'{test_type}\')'
    assert repr(test_instance) == expected_string

# Generated at 2022-06-21 08:05:44.305569
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult(output = 'This is output', message = 'This is message', type = 'This is type')
    assert result.output == 'This is output'
    assert result.message == 'This is message'
    assert result.type == 'This is type'

    result2 = TestResult()
    assert result2.output is None
    assert result2.message is None
    assert result2.type is None


# Generated at 2022-06-21 08:05:48.045196
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():

    a = TestFailure(message='message', output='output', type='type')
    b = TestFailure(message='message', output='output', type='type')

    assert a == b


# Generated at 2022-06-21 08:05:51.934429
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    testError = TestError("Message", "Type", "Output")
    assert testError.__repr__() == "TestError(output='Output', message='Message', type='Type')"


# Generated at 2022-06-21 08:05:53.448270
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    assert TestFailure().type == 'failure'
    assert TestError().type == 'error'

# Generated at 2022-06-21 08:06:48.465394
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    ts = TestSuites()
    ts.suites = [TestSuite('My_first_TestSuite')]
    element = ts.get_xml_element()
    assert element.tag == 'testsuites'
    assert element.attrib == {'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '0', 'time': '0.00'}
    assert len(element) == 1
    # sub element 'testsuite'
    assert element[0].tag == 'testsuite'

# Generated at 2022-06-21 08:06:57.937252
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    # Test 1 equals test 2
    test_1_result = TestResult(output="test_output", message="test_message", type="test_type")
    test_2_result = TestResult(output="test_output", message="test_message", type="test_type")
    assert (test_1_result == test_2_result)
    # Test 1 not equals test 3
    test_3_result = TestResult(output="test_output", message="test_message", type="test_type_3")
    assert (not test_1_result == test_3_result)
    # Test 1 not equals test 4
    test_4_result = TestResult(output="test_output_4", message="test_message", type="test_type")
    assert (not test_1_result == test_4_result)
    # Test

# Generated at 2022-06-21 08:07:09.100299
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    tc = TestCase('test1', assertions=1, classname='fake', status='passed', time=decimal.Decimal(1.2))
    tc.errors = [TestError('error1', message='m1')]
    tc.failures = [TestFailure('failure1', message='m2')]
    tc.skipped = 'Skipped'
    tc.system_out = 'sysout'
    tc.system_err = 'syserr'
    tc.is_disabled = False

    e = tc.get_xml_element()

    assert e.tag == 'testcase'
    assert e.attrib['name'] == 'test1'
    assert e.attrib['assertions'] == '1'
    assert e.attrib['classname'] == 'fake'

# Generated at 2022-06-21 08:07:11.905250
# Unit test for constructor of class TestError
def test_TestError():
    errors = TestError('type', 'message', 'output')
    assert errors.type == 'type'
    assert errors.message == 'message'
    assert errors.output == 'output'


# Generated at 2022-06-21 08:07:13.676137
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    testResult = TestResult()
    assert(testResult.type == None)


# Generated at 2022-06-21 08:07:15.017742
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    result = TestResult()
    assert result.type == 'TestResult'


# Generated at 2022-06-21 08:07:19.978591
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase(name = "test_TestCase___repr__")
    assert str(test_case) == "TestCase(name='test_TestCase___repr__', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"


# Generated at 2022-06-21 08:07:21.621841
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    obj = TestSuites()
    assert 'TestSuites(name=None, suites=[])' == repr(obj)

# Generated at 2022-06-21 08:07:31.842210
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_case = TestCase(
        name='test_TestSuite_get_xml_element',
    )
    test_suite = TestSuite(
        name='test_TestSuites_get_xml_element',
        cases=[test_case],
    )
    packages = TestSuites(
        name='test_TestSuites_get_xml_element',
        suites=[test_suite],
    )

    element = packages.get_xml_element()

    assert element.tag == 'testsuites'
    assert element.attrib == _attributes(
        disabled=0,
        errors=0,
        failures=0,
        name='test_TestSuites_get_xml_element',
        tests=1,
        time=0,
    ), element.attrib

# Generated at 2022-06-21 08:07:35.545229
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase("TestMe")
    assert tc.name == "TestMe"
    assert tc.classname is None
    assert tc.status is None
    assert tc.time is None

    tc = TestCase("TestMe", classname="Math", status="pass")
    assert tc.name == "TestMe"
    assert tc.classname == "Math"
    assert tc.status == "pass"
    assert tc.time is None



# Generated at 2022-06-21 08:08:19.517801
# Unit test for constructor of class TestError
def test_TestError():
    assert TestError()


# Generated at 2022-06-21 08:08:30.059458
# Unit test for constructor of class TestSuite
def test_TestSuite():
    t1 = TestSuite(name='test',hostname='hostname',id='id',package='package',timestamp=datetime.datetime.now(),system_out='out',system_err='err')
    t1.cases.append(TestCase(name='case1'))
    t1.cases.append(TestCase(name='case2'))
    # assertions=self.assertions,
    # classname=self.classname,
    # name=self.name,
    # status=self.status,
    # time=self.time,
    # errors=self.errors,
    # failures=self.failures,
    # skipped=self.skipped,
    # system_out=self.system_out,
    # system_err=self.system_err,
    # properties=self.properties,
   

# Generated at 2022-06-21 08:08:40.190399
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_values = ['', 'some text']
    expected_tags = ['failure', 'error']
    test_result = TestError()
    # assertions = 1 if cdata section is found, 0 if cdata not found
    assertions = 0
    for tv in test_values:
        test_result.message = tv
        element = test_result.get_xml_element()
        # check if cdata section is present
        if (element.text is not None) and (tv != ''):
            assertions = assertions+1
        assert element.tag == expected_tags[1]
        assert len(element.attrib) == len(test_result.get_attributes())
    assert assertions == len(test_values)


# Generated at 2022-06-21 08:08:44.584765
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase(None, None, None, None, "assertions", "classname", "name", "status", "time")
    assert test_case.get_attributes() == {"assertions": "assertions", "classname": "classname", "name": "name", "status": "status", "time": "time"}

# Generated at 2022-06-21 08:08:46.554792
# Unit test for constructor of class TestSuites
def test_TestSuites():
    TestSuites("name", "value")
    TestSuites("name", "value")


# Generated at 2022-06-21 08:08:48.906137
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert "TestSuites(name=None, suites=[])" == repr(TestSuites())


# Generated at 2022-06-21 08:08:52.481898
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    d = TestFailure(message='hello', type='hi')
    attributes = d.get_attributes()
    assert attributes == {'message': 'hello', 'type': 'hi'}


# Generated at 2022-06-21 08:09:01.934330
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase('test_name')
    assert test_case.get_attributes() == {}

    test_case = TestCase('test_name', assertions=0)
    assert test_case.get_attributes() == {'assertions': '0'}

    test_case = TestCase('test_name', assertions=0, classname='test_class')
    assert test_case.get_attributes() == {'assertions': '0', 'classname': 'test_class'}

    test_case = TestCase('test_name', assertions=0, classname='test_class', status='status')
    assert test_case.get_attributes() == {'assertions': '0', 'classname': 'test_class', 'status': 'status'}


# Generated at 2022-06-21 08:09:04.118370
# Unit test for constructor of class TestResult
def test_TestResult():
    testresult = TestResult()
    assert testresult.output == None
    assert testresult.message == None
    assert testresult.type == None

# Generated at 2022-06-21 08:09:14.036748
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    # Create a TestSuites object.
    test_suites = TestSuites()

    # Get the xml element of the TestSuites object.
    xml_element = test_suites.get_xml_element()

    # Check if the xml element is correct.
    assert xml_element.attrib['disabled'] == '0'
    assert xml_element.attrib['errors'] == '0'
    assert xml_element.attrib['failures'] == '0'
    assert xml_element.attrib['tests'] == '0'
    assert xml_element.attrib['time'] == '0'
    assert xml_element.tag == 'testsuites'


# Generated at 2022-06-21 08:10:05.387032
# Unit test for constructor of class TestCase
def test_TestCase():
  test_case = TestCase(name = 'test1')
  assert test_case.name == 'test1'
  assert test_case.is_disabled == False
  assert test_case.is_failure == False
  assert test_case.is_error == False
  assert test_case.is_skipped == False


# Generated at 2022-06-21 08:10:10.312253
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    suites = TestSuites(name='something')
    element = suites.get_xml_element()

    expected = """\
<?xml version="1.0" ?>
<testsuites disabled="0" errors="0" failures="0" name="something" tests="0" time="0.0">
</testsuites>
"""

    print(element)
    assert ET.tostring(element, encoding='unicode') == expected

    return

# Generated at 2022-06-21 08:10:11.241445
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert repr(TestFailure()) == 'TestFailure(output=None, message=None, type=None)'


# Generated at 2022-06-21 08:10:23.685401
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    a = TestResult(output='output_a', message='message_a', type='type_a')
    b = TestResult(output='output_b', message='message_b', type='type_b')
    c = TestResult(output='output_a', message='message_b', type='type_b')
    d = TestResult(output='output_a', message='message_a', type='type_b')
    e = TestResult(output='output_b', message='message_a', type='type_a')
    f = TestResult(output='output_a', message='message_a', type='type_a')

    assert a == b
    assert a != c
    assert a != d
    assert a != e
    assert a == f

# Generated at 2022-06-21 08:10:31.700422
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    ts = TestSuites(name="my_suite_name")
    ts.suites += [TestSuite(name="my_test_suite_name",
                            hostname="my_host_name",
                            id="my_suite_id",
                            package="my_package_name",
                            timestamp=datetime.datetime(2019, 1, 3, 17, 10, 0)),
                  TestSuite(name="my_second_test_suite_name",
                            hostname="my_second_host_name",
                            id="my_second_suite_id",
                            package="my_second_package_name",
                            timestamp=datetime.datetime(2020, 1, 3, 17, 10, 0))]

# Generated at 2022-06-21 08:10:43.160367
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-21 08:10:49.884976
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    testSuite_1 = TestSuite(name="a name", hostname="a host name", id="a id", package="a package", timestamp=datetime.datetime.now(), properties={}, cases=[], system_out="a system out", system_err="a system err")
    testSuite_2 = TestSuite(name="a name", hostname="a host name", id="a id", package="a package", timestamp=datetime.datetime.now(), properties={}, cases=[], system_out="a system out", system_err="a system err")
    testSuites = TestSuites(name="a name", suites=[testSuite_1, testSuite_2])

# Generated at 2022-06-21 08:10:53.648284
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Arrange
    tr = TestResult(output= 'output', message= 'message')

    # Assert
    assert tr.get_attributes() == {'output': 'output', 'message': 'message'}


# Generated at 2022-06-21 08:11:03.612055
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:11:12.007628
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    cases = [TestCase(name="Foo")]
    suite = TestSuite(name="Bar", cases=cases)
    suites = TestSuites(name="FooBar", suites=[suite])
    attrs = suites.get_attributes()
    assert attrs['disabled'] == '0'
    assert attrs['errors'] == '0'
    assert attrs['failures'] == '0'
    assert attrs['name'] == 'FooBar'
    assert attrs['tests'] == '1'
    assert attrs['time'] == '0'