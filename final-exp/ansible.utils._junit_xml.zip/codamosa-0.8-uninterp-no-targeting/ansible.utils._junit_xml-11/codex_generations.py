

# Generated at 2022-06-21 08:01:29.644105
# Unit test for constructor of class TestError
def test_TestError():
    try:
        TestError(output = "Test Output")
    except:
        raise RuntimeError('Failed to construct TestError')

# Generated at 2022-06-21 08:01:32.076357
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestFailure(message='test')) == "TestFailure(message='test')"


# Generated at 2022-06-21 08:01:37.714934
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    testresult1 = TestResult(output='testoutput', message='testmessage', type='testtype')
    assert testresult1.tag == 'testresult'

    testresult2 = TestResult(output='testoutput', message='testmessage')
    assert testresult2.tag == 'testresult'


# Generated at 2022-06-21 08:01:39.730452
# Unit test for constructor of class TestCase
def test_TestCase():
    # TODO: Code here
    print("TestCase constructor is OK")
    return True


# Generated at 2022-06-21 08:01:42.961938
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
  t = TestFailure(output='output', message='message', type='type')
  assert repr(t) == "TestFailure(output='output', message='message', type='type')"
  

# Generated at 2022-06-21 08:01:47.800375
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    from textwrap import dedent

    assert repr(TestError(message='foo', type='bar', output='baz')) == dedent("""\
        TestError(
            message='foo',
            output='baz',
            type='bar',
        )""")

# Generated at 2022-06-21 08:01:52.013514
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testCase = TestCase(name='test_case')
    xml_element = testCase.get_xml_element()

    assert xml_element.tag == 'testcase'
    assert xml_element.attrib.get('name') == 'test_case'
    assert len(xml_element) == 0


# Generated at 2022-06-21 08:01:53.588203
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    tc = TestCase('test_1')
    assert 'test_1' == str(tc)

# Generated at 2022-06-21 08:02:03.034810
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    t = TestSuites(name="TestSuite1", suites=[TestSuite(name="TestSuite2")])
    assert t.to_pretty_xml() == """<?xml version="1.0" ?>
<testsuites disabled="0" errors="0" failures="0" name="TestSuite1" tests="0" time="0.00">
\t<testsuite disabled="0" errors="0" failures="0" hostname="TestSuite2" id="" name="TestSuite2" package="" skipped="0" tests="0" time="0.00">
\t</testsuite>
</testsuites>
"""

# Generated at 2022-06-21 08:02:05.004770
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    actual = TestSuites(name="name")
    assert repr(actual) == "<TestSuites name=name>"

# Generated at 2022-06-21 08:02:16.483541
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    TestFailure = type('TestFailure', (), {'__repr__': TestFailure.__repr__})
    test_case = TestFailure(type = 'type')
    expected = "TestFailure(output=None, message=None, type='type')"
    actual = repr(test_case)
    assert actual == expected


# Generated at 2022-06-21 08:02:19.720681
# Unit test for constructor of class TestResult
def test_TestResult():
    expected = TestResult()
    assert expected.output is None
    assert expected.message is None
    assert expected.type is None

# Generated at 2022-06-21 08:02:31.079510
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    """
    Unit test for method __eq__ of class TestResult
    """
    assert TestError(output="output1", message="message1", type="type1") == \
        TestError(output="output1", message="message1", type="type1")
    assert TestError(output="output1", message="message2", type="type1") != \
        TestError(output="output1", message="message1", type="type1")
    assert TestError(output="output2", message="message1", type="type1") != \
        TestError(output="output1", message="message1", type="type1")
    assert TestError(output="output1", message="message1", type="type2") != \
        TestError(output="output1", message="message1", type="type1")

# Generated at 2022-06-21 08:02:32.108018
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure() == TestFailure()


# Generated at 2022-06-21 08:02:39.191157
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    """__eq__ should return True when the other object has the same attributes"""
    type = 'my_type'
    attributes = {'message': 'my_message', 'type': type}
    result = TestResult(**attributes)
    other = TestResult(**attributes)
    assert result == other
    # Unit test coverage report
    # 100% branch coverage
    #     | 0% condition coverage


# Generated at 2022-06-21 08:02:42.948397
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    expected = """
        TestError(
            output=None,
            message=None,
            type=None,
        )
    """
    actual = repr(TestError())
    assert actual == expected



# Generated at 2022-06-21 08:02:48.594749
# Unit test for constructor of class TestSuite
def test_TestSuite():
    suite = TestSuite('name_of_suite', 'hostname', 'id_of_suite', 'package', 'timestamp', 'a:b,c:d')
    assert suite.name == 'name_of_suite'
    assert suite.hostname == 'hostname'
    assert suite.id == 'id_of_suite'
    assert suite.package == 'package'
    assert suite.timestamp == 'timestamp'
    assert suite.properties == 'a:b,c:d'


# Generated at 2022-06-21 08:02:55.021137
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
  """Unit test for method __eq__ of class TestResult"""
  # Define a TestResult instance
  tr1 = TestResult('Some error', 'Some message', 'Some type')
  # Define a TestResult instance with the same attributes as tr1
  tr2 = TestResult('Some error', 'Some message', 'Some type')
  # Check whether two TestResult instances are equal
  assert tr1 == tr2


# Generated at 2022-06-21 08:03:00.071815
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test_T1 = TestSuite("test1")
    test_T2 = TestSuite("test2")
    test_T3 = TestSuite("test2")

    assert test_T1 == test_T1
    assert test_T2 == test_T3
    assert test_T1 != test_T2


# Generated at 2022-06-21 08:03:12.087837
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Test the get_xml_element of class TestSuite.
    """
    # Test case data
    name = "TestSuite"
    hostname = "localhost"
    id = 0
    package = "test"
    timestamp = datetime.datetime(2020, 1, 21, 11, 55, 33)
    properties = {"Doe": "name"}
    cases = [TestCase("TestCase")]
    system_out = "Test Output"
    system_err = "Test Error"
    # Define a TestSuite object
    test_suite = TestSuite(name=name, hostname=hostname, id=id, package=package, timestamp=timestamp)
    test_suite.properties = properties
    test_suite.cases = cases
    test_suite.system_out = system_out
    test

# Generated at 2022-06-21 08:03:23.292286
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult(output="hello world", message="test message", type="result")
    assert result.output == "hello world"
    assert result.message == "test message"
    assert result.type == "result"



# Generated at 2022-06-21 08:03:26.950020
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    r = TestResult(output='some output', message='some message', type='some type')
    assert repr(r) == "TestResult(output='some output', message='some message', type='some type')"


# Generated at 2022-06-21 08:03:38.088744
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_instance = TestResult()
    test_instance.output = 'test_output'
    test_instance.message = 'test_message'
    test_instance.type = 'test_type'
    test_instance.tag = 'test_tag'

    assert test_instance.output == 'test_output'
    assert test_instance.message == 'test_message'
    assert test_instance.type == 'test_type'
    assert test_instance.tag == 'test_tag'
    assert test_instance.get_attributes() == {'message': 'test_message', 'type': 'test_type'}
    assert ET.tostring(test_instance.get_xml_element()) == b'<test_tag message="test_message" type="test_type">test_output</test_tag>'
#
# Unit

# Generated at 2022-06-21 08:03:42.627261
# Unit test for constructor of class TestSuite
def test_TestSuite():
    t1 = TestSuite()
    assert t1.cases == []
    assert t1.system_out == None
    assert t1.system_err == None
    assert t1.properties == {}

    assert t1.disabled == 0
    assert t1.errors == 0
    assert t1.failures == 0
    assert t1.skipped == 0
    assert t1.tests == 0
    assert t1.time == 0


# Generated at 2022-06-21 08:03:47.674365
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_value = TestFailure(output="output value",message="message value",type="type value")
    actual = repr(test_value)
    expected = 'TestFailure(output=\'output value\', message=\'message value\', type=\'type value\')'
    assert actual == expected


# Generated at 2022-06-21 08:03:50.154939
# Unit test for constructor of class TestError
def test_TestError():
    t=TestError("error")
    assert t.type=="error"
    assert t.output=="error"


# Generated at 2022-06-21 08:04:00.163489
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('test-case-name')
    test_case.assertions = 10
    test_case.classname = 'TestCaseClassName'
    test_case.status = 'status'
    test_case.time = decimal.Decimal('1.234')

    errors = [
        TestError(output='foo', message='message', type='type'),
        TestError(type='bar'),
    ]
    for error in errors:
        test_case.errors.append(error)

    failures = [
        TestFailure(output='foo', message='message', type='type'),
        TestFailure(type='bar'),
    ]
    for failure in failures:
        test_case.failures.append(failure)

    test_case.skipped = 'Skipped'

# Generated at 2022-06-21 08:04:05.684494
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite = TestSuite('testsuite', 'testhost', 'testid', 'testpackage', datetime.datetime.now(), {'propertykey':'propertyvalue'}, None, 'testsystemout', 'testsystemerr')
    xml_string = testsuite.get_xml_element().tostring()
    print(xml_string)
    xml_string = _pretty_xml(testsuite.get_xml_element())
    print(xml_string)


# Generated at 2022-06-21 08:04:15.593756
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite_1 = TestSuite(name='suite_1', hostname='hostname_1', id='id_1', package='package_1', timestamp=datetime.datetime(2020, 8, 8, 13, 30, 30))
    suite_2 = TestSuite(name='suite_2', hostname='hostname_2', id='id_2', package='package_2', timestamp=datetime.datetime(2020, 8, 8, 13, 30, 31))
    assert suite_1 != suite_2

    # timestamp is not used for comparison
    suite_2 = TestSuite(name='suite_1', hostname='hostname_1', id='id_1', package='package_1', timestamp=datetime.datetime(2020, 8, 8, 13, 30, 31))
    assert suite_1 == suite_2

# Generated at 2022-06-21 08:04:18.424878
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    fail1 = TestFailure(output='Dummy output')
    fail2 = TestFailure(output='Dummy output')

    assert fail1 == fail2



# Generated at 2022-06-21 08:04:28.726955
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    test_suites1 = TestSuites()
    test_suites2 = TestSuites()
    test_suites3 = TestSuites(name='pytest')
    assert test_suites1 == test_suites2
    assert test_suites1 != test_suites3


# Generated at 2022-06-21 08:04:29.859359
# Unit test for constructor of class TestSuite
def test_TestSuite():
    assert TestSuite('bar')


# Generated at 2022-06-21 08:04:33.799408
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    testResult1 = TestError(message="error_message", output="output")
    testResult2 = TestError(message="error_message", output="output")
    assert(testResult1 == testResult2)


# Generated at 2022-06-21 08:04:38.025161
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    object1 = TestSuites(name = 'a')
    object2 = TestSuites(name = 'a')
    object3 = TestSuites(name = 'b')
    assert object1 == object2
    assert object1 != object3



# Generated at 2022-06-21 08:04:41.726266
# Unit test for constructor of class TestResult
def test_TestResult():
    t1 = TestError(output='error!', message='General error', type='unknown')
    assert t1.output == 'error!'
    assert t1.message == 'General error'
    assert t1.type == 'unknown'



# Generated at 2022-06-21 08:04:47.819285
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    testsuites = TestSuites('Suite 1, Suite 2')
    # Get the XML string
    result = testsuites.get_xml_element()
    
    # Assert
    assert result.tag == 'testsuites'
    assert result.attrib == {'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '0', 'time': '0'}

# Generated at 2022-06-21 08:04:52.463356
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError('my_message') == TestError('my_message')
    assert TestError('my_message') != TestError('my_message_2')
    assert TestError('my_message') != TestResult('my_message_2')
    assert TestError('my_message').__eq__(TestResult('my_message_2'))


# Generated at 2022-06-21 08:05:04.614696
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    """
    Test the repr of TestSuites, it's pretty much all a smoke test.
    """
    assert repr(TestSuites('test suites')) == '<TestSuites name="test suites">'
    assert repr(TestSuites('test suites', [])) == '<TestSuites name="test suites" suites=[]>'
    assert repr(TestSuites('test suites', [TestSuite('test suite')])) == \
        '<TestSuites name="test suites" suites=[<TestSuite name="test suite">]>'
    assert repr(TestSuites('test suites', [TestSuite('test suite', [TestCase('test case')])])) == \
        '<TestSuites name="test suites" suites=[<TestSuite name="test suite" cases=[<TestCase name="test case">]>]>'


# Generated at 2022-06-21 08:05:08.133721
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    ts = TestSuites(name='name')
    assert ts.__repr__() == '{}(name=\'name\')'.format(TestSuites.__name__)

# Generated at 2022-06-21 08:05:11.938841
# Unit test for constructor of class TestCase
def test_TestCase():
    name = "Valid_TestCase_Name_01"
    testcase = TestCase(name)
    assert testcase.name == name
    assert testcase.assertions == None
    assert testcase.classname == None
    assert testcase.status == None
    assert testcase.time == None
    assert testcase.is_disabled == False
    assert testcase.errors == []
    assert testcase.failures == []


# Generated at 2022-06-21 08:05:27.784374
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test = TestSuite("testname")
    expected_dict = {'name':'testname'}
    output_dict = test.get_attributes()
    assert expected_dict == output_dict


# Generated at 2022-06-21 08:05:36.717219
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name="test_name",
        errors=[TestError()],
        failures=[TestFailure()],
        skipped="skipped",
        system_err="system_err",
        system_out="system_out",
    )

    xml_element = test_case.get_xml_element()

    assert xml_element.tag == 'testcase'
    assert xml_element.attrib == {'name': "test_name"}
    assert xml_element.find('error').tag == 'error'
    assert xml_element.find('failure').tag == 'failure'
    assert xml_element.find('skipped').tag == 'skipped'
    assert xml_element.find('skipped').text == 'skipped'

# Generated at 2022-06-21 08:05:41.635850
# Unit test for constructor of class TestFailure
def test_TestFailure():
  result = TestResult(output="test message", message="test message", type="test type")
  T1Result = result.get_attributes()
  T1test_result = T1Result["type"]
  assert T1test_result == "test type"


# Generated at 2022-06-21 08:05:48.624676
# Unit test for constructor of class TestCase
def test_TestCase():
    """
    Test if a TestCase is well created
    """
    # Create a TestCase and test its attributes
    name = 'test_TestCase'
    source = './tests/test_dataclasses.py'
    duration = 1.0
    attributes = {
        'name': name,
    }
    test_case = TestCase(name)
    # Test if its attributes are correct
    assert name == test_case.name
    assert None == test_case.assertions
    assert None == test_case.classname
    assert None == test_case.status
    assert None == test_case.time
    assert [] == test_case.errors
    assert [] == test_case.failures
    assert None == test_case.skipped
    assert None == test_case.system_out

# Generated at 2022-06-21 08:06:00.460015
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_xml_element(self):
            test_case1 = TestCase(
                name='test_case1',
                assertions=None,
                classname=None,
                status=None,
                time=None
            )

            test_case2 = TestCase(
                name='test_case2',
                assertions=None,
                classname=None,
                status=None,
                time=None
            )
            test_case2.errors = [
                TestError(output='error message')
            ]

            test_case3 = TestCase(
                name='test_case3',
                assertions=None,
                classname=None,
                status=None,
                time=None
            )

# Generated at 2022-06-21 08:06:02.287768
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert repr(TestSuites()) == f"TestSuites(name=None, suites=[])"

# Generated at 2022-06-21 08:06:09.590637
# Unit test for constructor of class TestSuite
def test_TestSuite():
    suite = TestSuite(
        name = "TestSuite1",
        hostname = "host1",
        id = "id1",
        package = "package1",
        timestamp = "2020-04-10T15:16:17",
        properties = {"name1":"value1","name2":"value2"},
        cases = [TestCase(name="TestCase1"),TestCase(name="TestCase2")],
        system_out = "System_out",
        system_err = "System_err",
    )


# Generated at 2022-06-21 08:06:12.207637
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    testcase1 = TestCase(name='test_1')
    testcase2 = TestCase(name='test_2')

    assert testcase1 != testcase2, 'TestCase objects are not equal'

# Generated at 2022-06-21 08:06:23.846671
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():

    test_suite1 = TestSuites()
    test_suite1.name = 'TestSuite name'
    test_suite1.suites = [
        TestSuite(name='TestSuite name', hostname='TestSuite hostname', id='TestSuite id', package='TestSuite package', timestamp=datetime.datetime.now(), 
        properties={}, cases=[], system_out='', system_err='')
        ]
    test_suite2 = TestSuites()
    test_suite2.name = 'TestSuite name'

# Generated at 2022-06-21 08:06:34.834284
# Unit test for constructor of class TestFailure
def test_TestFailure():
    t1 = TestFailure(
        output='this is the output',
        message='this is the message',
        type='this is the type'
    )
    assert t1.output == 'this is the output'
    assert t1.message == 'this is the message'
    assert t1.type == 'this is the type'
    assert t1.tag == 'failure'
    assert t1.get_attributes() == {'message': 'this is the message', 'type': 'this is the type'}
    assert str(t1.get_xml_element()) == '<failure message="this is the message" type="this is the type">this is the output</failure>'
    assert t1.get_xml_element().text == 'this is the output'

# Generated at 2022-06-21 08:06:59.745099
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    com_example_demo_tests_TestFailure_instance_0 = dataclasses.replace(TestFailure(), output=None)
    assert 'output: None\ntype: failure\n' == com_example_demo_tests_TestFailure_instance_0.__repr__()



# Generated at 2022-06-21 08:07:10.474061
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    name = "some-testsuite"
    hostname = "some-hostname"
    id = "some-id"
    package = "some-package"
    timestamp = datetime.datetime.now()

    properties = {"some-key": "some-value"}
    cases = [
        TestCase(
            name="some-case-1",
            classname="some-classname-1",
        ),
        TestCase(
            name="some-case-2",
            classname="some-classname-2",
        ),
    ]
    system_out = "some-system-out"
    system_err = "some-system-err"


# Generated at 2022-06-21 08:07:17.114897
# Unit test for constructor of class TestSuites
def test_TestSuites():
    class_name='TestSuites'
    test_name='test_TestSuites'
    output = """[{0}] {1} - {2} ({3})
Test #1: Testing constructor of class 'TestSuites'
Output: """.format(get_now(), 'OK', class_name, test_name)
    try:
        ts = TestSuites()
        output += 'Pass\n'
        return output, True
    except:
        output += 'Fail\n'
        return output, False


# Generated at 2022-06-21 08:07:23.031076
# Unit test for constructor of class TestCase
def test_TestCase():
    name = 'TestCase'
    assertions = 1
    classname = 'TestClass'
    status = 'Success'
    time = 1.123
    tc = TestCase(name, assertions, classname, status, time)
    assert(tc.name == name)
    assert (tc.assertions == assertions)
    assert (tc.classname == classname)
    assert (tc.status == status)
    assert (tc.time == time)


# Generated at 2022-06-21 08:07:33.056454
# Unit test for constructor of class TestCase

# Generated at 2022-06-21 08:07:45.465738
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    assert """<testcase assertions="1" classname="com.mycompany.EmpBusinessLogic" name="testCalculateYearlySalary" time="0.00">
  <failure message="test failure" type="Failure">test failure output</failure>
  <system-out>system out</system-out>
  <system-err>system err</system-err>
</testcase>
""" == _pretty_xml(dataclasses.replace(TestCase(name="testCalculateYearlySalary", classname="com.mycompany.EmpBusinessLogic", time="0.00", assertions=1), failures=[TestFailure(message="test failure", output="test failure output")], system_out="system out", system_err="system err").get_xml_element())


# Generated at 2022-06-21 08:07:47.748794
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite("test_suite_1")
    assert isinstance(test_suite, TestSuite)

# Unit tests for method get_attributes of class TestCase

# Generated at 2022-06-21 08:07:49.131704
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert isinstance(repr(TestResult()), str)


# Generated at 2022-06-21 08:07:51.058613
# Unit test for constructor of class TestFailure
def test_TestFailure():
    """TestCase for constructor of class TestFailure."""
    s = TestFailure()
    assert s is not None


# Generated at 2022-06-21 08:07:53.665794
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase(name='test')
    print('test_case', test_case, '\n')
    assert test_case.__repr__() == 'test_case TestCase(name=test) \n'


# Generated at 2022-06-21 08:08:22.726292
# Unit test for constructor of class TestFailure
def test_TestFailure():
    failure = TestFailure(output='failure text')
    assert failure.output == 'failure text', 'Failure text must match'


# Generated at 2022-06-21 08:08:25.659716
# Unit test for constructor of class TestSuites
def test_TestSuites():
    ts = TestSuites(name = 'string', suites = [])
    print(ts)
    assert isinstance(ts,TestSuites)



# Generated at 2022-06-21 08:08:31.225689
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    import sys
    try:
        t_result = TestResult('output')
    except Exception:
        e = sys.exc_info()[1]
        print('FAILURE: [test_TestResult___post_init__] ' + str(e))
        sys.exit(-1)
    else:
        print('SUCCESS: [test_TestResult___post_init__]')
        sys.exit(0)


# Generated at 2022-06-21 08:08:39.003689
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Check if the method get_xml_element of class TestCase returns the expected output"""
    s = '''<?xml version="1.0" ?>
<testcase name="test_name" assertions="0">
    <failure type="type_name">failure_message</failure>
</testcase>'''

    xml_output = TestCase(name='test_name', assertions=0, failures=None).get_xml_element()
    assert _pretty_xml(xml_output) == s



# Generated at 2022-06-21 08:08:49.904695
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    TestCase(
        name="test_test_case_1",
        assertions=2,
        classname="test_class",
        status="run",
        time=0.05,
        errors=[
            TestError(
                output="Error Output",
                message="Error Message",
                type="error_type"
            )
        ],
        failures=[
            TestFailure(),
        ],
        skipped="Not Applicable",
        system_out="Standard output",
        system_err="Standard error"
    ).get_xml_element().attrib == {'assertions': '2',
                                   'name': 'test_test_case_1',
                                   'time': '0.05',
                                   'classname': 'test_class',
                                   'status': 'run'}

# Generated at 2022-06-21 08:08:52.529836
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    testResult1 = TestError()
    testResult2 = TestError()
    assert testResult1 == testResult2


# Generated at 2022-06-21 08:09:01.966016
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    name = 'REPLACE_ME'
    time = decimal.Decimal('1.12')

    testsuite_name = 'testsuite_name'
    testsuite_timestamp = datetime.datetime(2020, 6, 30, 13, 4, 49)
    testsuite_errors = 1
    testsuite_failures = 2
    testsuite_tests = 3
    testsuite_time = decimal.Decimal('4.56')

    testcase_name = 'testcase_name'
    testcase_time = decimal.Decimal('7.89')


# Generated at 2022-06-21 08:09:07.026039
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    """Unit test for method __repr__ of class TestSuite"""
    assert(str(TestSuite(name='foo')) == 'TestSuite(name=\'foo\', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)')


# Generated at 2022-06-21 08:09:12.065299
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    error = TestFailure(
        output=None,
        message=None,
        type=None
    )
    actual = error == TestFailure(
        output=None,
        message=None,
        type=None
    )
    assert actual == True


# Generated at 2022-06-21 08:09:21.487098
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    a = TestSuite('', '', '', '', '', [], [], [], '', '', [])
    a1 = TestSuite('', '', '', '', '', [], [], [], '', '', [])
    b = TestSuite('noise', '', '', '', '', [], [], [], '', '', [])   
    c = TestSuite('', 'noise', '', '', '', [], [], [], '', '', [])
    d = TestSuite('', '', 'noise', '', '', [], [], [], '', '', [])
    e = TestSuite('', '', '', 'noise', '', [], [], [], '', '', [])

# Generated at 2022-06-21 08:09:55.860248
# Unit test for constructor of class TestSuite
def test_TestSuite():
    ts = TestSuite("test1")
    f = TestFailure("test_fail", "error")
    e = TestError("test_error", "error")
    testcase1 = TestCase("test1", 11, "classname", "time", [e], [f])
    testcase2 = TestCase("test2", 12, "classname2", "time2")
    ts.cases.append(testcase1)
    ts.cases.append(testcase2)


# Generated at 2022-06-21 08:09:59.438674
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    assert (TestSuite('my_suite').to_pretty_xml() == '<testsuite name="my_suite" disabled="0" errors="0" failures="0" hostname="None" id="None" package="None" skipped="0" tests="0" time="0" timestamp="None"></testsuite>')

# Generated at 2022-06-21 08:10:06.630860
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    testCase1 = TestCase(name="test_case", assertions=1, classname="test_class", status="false", time=1.2)
    testCase2 = TestCase(name="test_case", assertions=1, classname="test_class", status="false", time=1.2)
    testCase3 = TestCase(name="test_case", assertions=1, classname="test_class", status="false", time=1.2)

    assert (testCase1 == testCase2) == True
    assert (testCase1 == testCase3) == True
    assert (testCase2 == testCase3) == True
    assert (testCase1 == testCase1) == True


# Generated at 2022-06-21 08:10:09.472626
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='TestCase')
    element = ET.Element('testcase', dict(name='TestCase'))
    assert test_case.get_xml_element() == element


# Generated at 2022-06-21 08:10:20.513880
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    class testFail(TestResult):
        tag = 'testFail'
        output = 'test case'
        message = 'test message'
        type = 'test type'

    class testError(TestResult):
        tag = 'testError'
        output = 'test case'
        message = 'test message'
        type = 'test type'

    class testFail2(TestResult):
        tag = 'testFail2'
        output = 'test case2'
        message = 'test message2'
        type = 'test type2'

    class testError2(TestResult):
        tag = 'testError2'
        output = 'test case2'
        message = 'test message2'
        type = 'test type2'


# Generated at 2022-06-21 08:10:23.684558
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert 'TestFailure()' == repr(TestFailure())


# Generated at 2022-06-21 08:10:25.320173
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    assert repr(TestCase('name',)) == "TestCase(name='name')"

# Generated at 2022-06-21 08:10:29.158675
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite_obj = TestSuite(name='test_suite_name')
    attribute_dict = {
        'name': 'test_suite_name',
        'tests': '0',
        'errors': '0',
        'failures': '0',
        'skipped': '0',
        'time': '0.00'
    }
    assert test_suite_obj.get_attributes() == attribute_dict

# Generated at 2022-06-21 08:10:30.770822
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    TestSuites.__repr__(TestSuites(name=None, suites=[]))

# Generated at 2022-06-21 08:10:41.756094
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_case_1 = TestCase(name='TestCases.test_upper', assertions=1, classname='tests.test_cases.TestCases', status='success', time=decimal.Decimal('0.000'))
    test_case_2 = TestCase(name='TestCases.test_lower', assertions=1, classname='tests.test_cases.TestCases', status='success', time=decimal.Decimal('0.000'))
    test_case_3 = TestCase(name='TestRaises.test_upper', assertions=1, classname='tests.test_cases.TestRaises', status='success', time=decimal.Decimal('0.000'))