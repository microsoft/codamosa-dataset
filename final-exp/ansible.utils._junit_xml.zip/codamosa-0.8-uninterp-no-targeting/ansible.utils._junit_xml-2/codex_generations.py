

# Generated at 2022-06-21 08:01:27.027295
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    error = TestError(output='', message='', type='')
    assert repr(error) == "<TestError output: '', message: '', type: ''>"

# Generated at 2022-06-21 08:01:31.375144
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite = TestSuite('name', failures = 2, errors = 3, disabled = 6, timestamp = datetime.datetime.now())
    suite2 = TestSuite('name', failures = 2, errors = 3, disabled = 8, timestamp = datetime.datetime.now())

    assert suite == suite
    assert suite != suite2

# Generated at 2022-06-21 08:01:33.976798
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    item1 = TestError(output='Test Error')
    item2 = TestError(output='Test Error')

    assert item1 == item2


# Generated at 2022-06-21 08:01:46.131472
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    from dataclasses import field
    from dataclasses import fields
    from dataclasses import FrozenInstanceError
    from typing import Any
    from typing import Dict
    from typing import List
    from typing import Optional
    from typing import Type
    from typing import TypeVar
    from typing import Union
    from xml.dom import minidom
    # noinspection PyPep8Naming
    from xml.etree import ElementTree as ET
    import dataclasses
    import decimal
    import inspect
    import typing as t
    import unittest
    import uuid

    import Source.test1 as test1
    import Source.test2 as test2

    def assert_equal(expected: Any, actual: Any):
        assert expected == actual, 'expected: {0}\nactual: {1}'.format(expected, actual)


# Generated at 2022-06-21 08:01:52.057453
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    testResult1 = TestResult()
    testResult2 = TestResult()

    testResult1.output = 'output'
    testResult1.message = 'message'
    testResult1.type = 'type'

    testResult2.output = 'output'
    testResult2.message = 'message'
    testResult2.type = 'type'

    assert (testResult1 == testResult2) is True


# Generated at 2022-06-21 08:01:52.804520
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure() == TestFailure()


# Generated at 2022-06-21 08:02:04.184587
# Unit test for constructor of class TestSuites
def test_TestSuites():
    testcases = [
        TestCase(name='test_case_1'),
        TestCase(name='test_case_2'),
    ]

    suite_2 = TestSuite(name='suite_2', cases=testcases)

    testsuites = TestSuites(name='testsuites', suites=[
        TestSuite(name='suite_1', cases=[
            TestCase(name='test_case_1'),
            TestCase(name='test_case_2'),
        ]),
        TestSuite(name='suite_2', cases=testcases),
    ])

    # Output XML to a file
    with open('test_TestSuites.xml', 'w', encoding='utf-8') as f:
        f.write(testsuites.to_pretty_xml())

    # Verify
    assert testsuites

# Generated at 2022-06-21 08:02:05.401762
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    assert TestResult() == TestResult()


# Generated at 2022-06-21 08:02:11.712711
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    output = 'test_output'
    message = 'test_message'
    test_type = 'test_type'

    test_result = TestResult(output=output, message=message, type=test_type)
    element = ET.Element('unknown')
    actual  = ET.dump(test_result.get_xml_element())
    expected = ET.dump(element)

    assert actual == expected


# Generated at 2022-06-21 08:02:16.284441
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    testSuites = TestSuites(name="TestSuites", suites=[TestSuite(name="TestSuite")])
    assert testSuites.get_attributes() == {'errors': '0', 'name': 'TestSuites', 'disabled': '0', 'failures': '0', 'tests': '1', 'time': '0'}



# Generated at 2022-06-21 08:02:22.585001
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite1 = TestSuite()
    suite2 = TestSuite()
    assert suite1 == suite2


# Generated at 2022-06-21 08:02:27.195876
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    assert TestCase(name='parallel_success') == TestCase(name='parallel_success')
    assert TestCase(name='is_disabled') != TestCase(name='is_disabled')
    assert TestCase(name='is_error') != TestCase(name='is_error')


# Generated at 2022-06-21 08:02:29.687491
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    class_1 = TestFailure()
    class_2 = TestFailure()
    assert (class_1 == class_2)

# Generated at 2022-06-21 08:02:30.958535
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    failure = TestFailure()
    assert failure.type == 'failure'


# Generated at 2022-06-21 08:02:40.334090
# Unit test for constructor of class TestSuite
def test_TestSuite():
    # Test without entries
    tests_suite = TestSuite(name = "TestName", hostname = "TestHostName", id = "TestID", package = "TestPackage", timestamp = datetime.datetime.now())

    # Test our properties
    assert tests_suite.name == 'TestName'
    assert tests_suite.hostname == 'TestHostName'
    assert tests_suite.id == 'TestID'
    assert tests_suite.package == 'TestPackage'
    assert tests_suite.timestamp == datetime.datetime.now()

# Generated at 2022-06-21 08:02:49.187382
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    classname = "testSuite1"
    name = "testCase1"
    time = "1.5"
    test_result_message = "test_result_message"
    test_result_output = "test_result_output"
    system_out = "system_out"
    system_err = "system_err"

    test_case = TestCase(name=name, time=decimal.Decimal(time))
    test_case.classname = classname
    test_case.system_out = system_out
    test_case.system_err = system_err

    error = TestError(message=test_result_message, output=test_result_output)
    test_case.errors.append(error)

    test_suite = TestSuite(name=name)

# Generated at 2022-06-21 08:02:54.413464
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    a = TestFailure(output='out', message='msg', type='type')
    b = TestFailure(output='out', message='msg', type='type')
    c = TestFailure(output='out', message='msg1')
    assert a == b, 'equal objects'
    assert a != c, 'equal objects'



# Generated at 2022-06-21 08:02:59.435844
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    """Testing method get_attributes of class TestResult"""
    
    result = TestResult()
    assert (result.get_attributes()) == _attributes()

    result = TestResult("output", "message", "type")
    assert (result.get_attributes()) == _attributes(message="message", type="type")



# Generated at 2022-06-21 08:03:09.512423
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    testResult = TestResult()
    output = 'output'
    message = 'message'
    type_ = 'type'
    testResult.output = output
    testResult.message = message
    testResult.type = type_

    result = testResult.get_xml_element()
    assert result.tag == 'result'
    assert result.text == output
    assert result.attrib['message'] == message
    assert result.attrib['type'] == type_

# This is the unit test for method get_xml_element of class TestCase.
# First, make sure that the output of this method does not contain message, type, or output


# Generated at 2022-06-21 08:03:18.399825
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    def foo():
        pass

    def bar():
        pass

    def baz():
        pass

    def test_case(a: TestResult, b: TestResult):
        assert a == b and b == a
        c = a
        assert a == c and c == a

    test_case(
        TestResult(
            output=None,
            message=None,
            type=None
        ),
        TestResult(
            output=None,
            message=None,
            type=None
        )
    )

    test_case(
        TestResult(
            output='output',
            message='message',
            type='type'
        ),
        TestResult(
            output='output',
            message='message',
            type='type'
        )
    )


# Generated at 2022-06-21 08:03:32.801670
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # creating a TestSuite object with all non-optional arguments
    x = TestSuite('testSuite1', 'localhost', '1', 'ui', datetime.datetime.now())
    y = TestSuite('testSuite2', 'localhost', '1', 'ui', datetime.datetime.now())
    assert x == y
    y.name = 'testSuite1'
    assert not (x == y)

# Generated at 2022-06-21 08:03:41.987525
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    from unittest.mock import Mock
    class TestResult_mock(TestResult):
        @property
        def tag(self):
            return 'testresult'
    # test of empty object
    obj = TestResult_mock()
    assert obj.get_xml_element() == ET.Element('testresult', {'type': 'testresult'})
    # test of an object with output
    obj = TestResult_mock(output='message_output')
    assert obj.get_xml_element().text == 'message_output'
    # test of an object with message
    obj = TestResult_mock(message='message_message')
    assert obj.get_xml_element() == ET.Element('testresult', {'message': 'message_message', 'type': 'testresult'})
    # test of an object with type


# Generated at 2022-06-21 08:03:46.199152
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    failure1 = TestFailure(output="output", message=" message", type="type")
    failure2 = TestFailure(output="output", message="message", type="type")
    assert(failure1.__eq__(failure2))

# Unit test method __eq__ of class TestError

# Generated at 2022-06-21 08:03:57.011910
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    # create sample TestSuite
    new_suite = TestSuite("test_suite")
    new_suite.hostname = "host"
    new_suite.id = "id_1"
    new_suite.package = "package_1"
    new_suite.timestamp = datetime.datetime(2020, 9, 17)

    new_suite.properties = {"name": "host", "value": "host"}
    new_suite.system_out = "system out"
    new_suite.system_err = "system in"

    # create sample TestCase
    new_case = TestCase("test_case")
    new_case.assertions = 23
    new_case.classname = "test_class"
    new_case.status = "status"
    new_case.time

# Generated at 2022-06-21 08:04:06.257689
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    case = TestCase(
        name="test_TestCase___repr__",
        assertions=1,
        classname="dataclass",
        status="success",
        time=decimal.Decimal("0.0")
    )
    expected = (
        "TestCase("
        "name='test_TestCase___repr__', "
        "assertions=1, "
        "classname='dataclass', "
        "status='success', "
        "time=Decimal('0.0'), "
        "errors=[], "
        "failures=[], "
        "skipped=None, "
        "system_out=None, "
        "system_err=None, "
        "is_disabled=False)"
    )
    assert str(case) == expected



# Generated at 2022-06-21 08:04:16.195434
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    testsuite_instance = TestSuite('testsuite', '', '', '', datetime.datetime(2020, 6, 19, 16, 47, 54))
    attributes = testsuite_instance.get_attributes()
    assert attributes['name'] == 'testsuite'
    assert attributes['disabled'] == 0
    assert attributes['errors'] == 0
    assert attributes['failures'] == 0
    assert attributes['hostname'] == ''
    assert attributes['id'] == ''
    assert attributes['package'] == ''
    assert attributes['skipped'] == 0
    assert attributes['tests'] == 0
    assert attributes['time'] == 0
    assert attributes['timestamp'] == '2020-06-19T16:47:54'


# Generated at 2022-06-21 08:04:27.039893
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
  test_case_1 = TestCase(
      name = "test_1",
      assertions = 5,
      classname = "Class_1",
      status = "pass",
      time = decimal.Decimal(1.234),
      errors = [],
      failures = [],
      skipped = "skipped",
      system_out = "out",
      system_err = "err",
      is_disabled = True
      )

  test_case_2 = TestCase(
      name = "test_2",
      status = "fail",
      )
  test_case_3 = TestCase(
      name = "test_3",
      status = "pass",
      )
  test_case_4 = TestCase(
      name = "test_4",
      status = "fail",
      )

  test_suite

# Generated at 2022-06-21 08:04:27.946003
# Unit test for constructor of class TestError
def test_TestError():
    TestError()

# Generated at 2022-06-21 08:04:33.798823
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure(output="test") == TestFailure(output="test")
    assert TestFailure(output="test") != TestFailure(output="test2")
    assert TestFailure(output="test") != TestFailure(output="test", message="test")
    assert TestFailure(output="test") != TestFailure(output="test", type="test")


# Generated at 2022-06-21 08:04:40.714669
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    f_test_suites = TestSuites()
    assert f_test_suites.get_attributes() == {'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '0', 'time': '0'}

    f_test_suites = TestSuites(name="Test suite name")
    assert f_test_suites.get_attributes() == {'name': 'Test suite name', 'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '0', 'time': '0'}

# Generated at 2022-06-21 08:05:01.843067
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testCase = TestCase(name='MyFirstTest', assertions=2, classname='my.test.classname')
    attributes = testCase.get_attributes()
    assert attributes['name'] == 'MyFirstTest'
    assert attributes['classname'] == 'my.test.classname'
    assert attributes['assertions'] == '2'


# Generated at 2022-06-21 08:05:08.880399
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    value_1 = '1'
    value_2 = '2'
    a = TestResult(output=value_2)
    b = TestResult(output=value_1)
    c = TestResult(output=value_2)

    assert (a == c) == True
    assert (a != c) == False
    assert (a == b) == False
    assert (a != b) == True

    assert (a == value_2) == False
    assert (a != value_2) == True



# Generated at 2022-06-21 08:05:21.971149
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_output = "some output"
    test_message = "some message"
    test_type = "some type"


    results = [
        TestError(
            output=test_output,
            message=test_message,
            type=test_type
        ),
        TestFailure(
            output=test_output,
            message=test_message,
            type=test_type
        )
    ]

    for result in results:
        assert result.output == test_output
        assert result.message == test_message
        assert result.type == test_type

        element = result.get_xml_element()

        assert element.attrib["message"] == test_message
        assert element.attrib["type"] == test_type
        assert element.text == test_output



# Generated at 2022-06-21 08:05:25.735693
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    t1 = TestSuite('test1')
    t2 = TestSuite('test1')
    if t1 != t2:
        raise AssertionError('TestSuite fail')
    else:
        print('TestSuite passed')


# Generated at 2022-06-21 08:05:27.829473
# Unit test for constructor of class TestSuites
def test_TestSuites():
    assert isinstance(TestSuites(name='test', suites=[]), TestSuites)

# Generated at 2022-06-21 08:05:29.797797
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase(name="foo")
    assert repr(test_case) == "TestCase(name='foo')"



# Generated at 2022-06-21 08:05:32.910247
# Unit test for constructor of class TestCase
def test_TestCase():
	case = TestCase(name='abc')

	assert case.name == 'abc'
	assert case.assertions == None
	assert case.classname == None
	assert case.status == None
	assert case.time == None


# Generated at 2022-06-21 08:05:44.022473
# Unit test for constructor of class TestCase
def test_TestCase():
    testcase = TestCase("name", 1, "classname", "status", 2.0, TestError(), TestFailure())
    testcase = TestCase("name", 1, "classname", "status", 2.0, TestError(), TestFailure())
    testcase = TestCase("name", 1, "classname", "status", 2.0, TestError(), TestFailure())
    testcase = TestCase("name", 1, "classname", "status", 2.0, TestError(), TestFailure())
    testcase = TestCase("name", 1, "classname", "status", 2.0, TestError(), TestFailure())
    testcase = TestCase("name", 1, "classname", "status", 2.0, TestError(), TestFailure())

# Generated at 2022-06-21 08:05:46.558355
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    assert dataclasses.astuple(TestCase('name')) == dataclasses.astuple(TestCase('name'))


# Generated at 2022-06-21 08:05:58.608230
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    test_suite_1 = TestSuite(name='unitTest_1')
    test_suite_2 = TestSuite(name='unitTest_2')

    test_suites = TestSuites(name='unit_tests', suites=[test_suite_1, test_suite_2])

    assert repr(test_suites) == "TestSuites(name='unit_tests', suites=[TestSuite(name='unitTest_1', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None), TestSuite(name='unitTest_2', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)])"



# Generated at 2022-06-21 08:06:53.013776
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    expected = TestSuite('test_name')

    actual = TestSuite('test_name')

    assert expected == actual

# Generated at 2022-06-21 08:06:54.131639
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
	ts = TestSuites()
	assert str(ts) == '<TestSuites(name=None, suites=[])>'

# Generated at 2022-06-21 08:06:59.495513
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    ts = TestSuite(name='test-suite')
    ts.timestamp = datetime.datetime(2008, 10, 23, 17, 48, 35)
    ts.hostname = 'test-host'
    ts.id = 'test-id'
    ts.package = 'test-package'
    assert ts.get_attributes() == {
        'name': 'test-suite',
        'timestamp': '2008-10-23T17:48:35',
        'hostname': 'test-host',
        'id': 'test-id',
        'package': 'test-package',
    }

# Generated at 2022-06-21 08:07:08.106639
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    from datetime import datetime
    from datetime import timedelta

    result = TestResult(output="test", message="test")
    result2 = TestResult(output="test", message="test")
    result3 = TestResult(output="test", message="test2")
    result4 = TestResult(output="test2", message="test")
    assert result == result2
    assert result != result3
    assert result != result4


# Generated at 2022-06-21 08:07:11.624050
# Unit test for constructor of class TestSuite
def test_TestSuite():
    testSuite = TestSuite(name="test", timestamp=datetime.datetime.now())
    assert testSuite.name == "test"
    assert testSuite.isinstance(testSuite.timestamp, datetime.datetime)


# Generated at 2022-06-21 08:07:13.073679
# Unit test for constructor of class TestSuites
def test_TestSuites():
    ts1 = TestSuites()
    assert ts1.suites == []

# Generated at 2022-06-21 08:07:14.766517
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    testcase = TestResult()
    assert testcase.__repr__() is not None



# Generated at 2022-06-21 08:07:17.366179
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    name = "TestCase.__repr__"
    testcase = TestCase(name=name)
    assert testcase.__repr__() == name


# Generated at 2022-06-21 08:07:19.220464
# Unit test for constructor of class TestError
def test_TestError():
    test = TestError(test)
    assert test.tag == 'error'



# Generated at 2022-06-21 08:07:21.907627
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    instance = TestFailure(output='output', message='message', type='type')
    assert repr(instance) == "TestFailure(output='output', message='message', type='type')"


# Generated at 2022-06-21 08:08:49.718008
# Unit test for constructor of class TestSuites
def test_TestSuites():
    test_suite_1 = TestSuite(name='test1', timestamp=datetime.datetime.now())
    test_suite_2 = TestSuite(name='test2', timestamp=datetime.datetime.now())
    test_suite_3 = TestSuite(name='test3', timestamp=datetime.datetime.now())

    test_suites = TestSuites(name='test', suites=[test_suite_1, test_suite_2, test_suite_3])

    test_xml = test_suites.to_pretty_xml()

    assert test_xml.startswith('<?xml version="1.0" ?>\n')
    assert 'testsuites' in test_xml
    assert 'testsuite' in test_xml
    assert test_xml.count('testsuite')

# Generated at 2022-06-21 08:09:00.322861
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Unit test for method to_pretty_xml of class TestSuites"""

# Generated at 2022-06-21 08:09:01.817561
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    t1 = TestSuites()
    t2 = TestSuites()
    assert t1==t2

# Generated at 2022-06-21 08:09:13.356432
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():

    testFailure1 = TestFailure(output='output', message='message', type='type')
    testFailure2 = TestFailure(output='output', message='message', type='type')
    testFailure3 = TestFailure(output='output', message='message', type='type')

    # Check that testFailure1 is equal to itself
    assert testFailure1 == testFailure1

    # Check that testFailure1 is equal to testFailure2 and testFailure3
    assert testFailure1 == testFailure2 and testFailure1 == testFailure3
    # Check that testFailure2 is equal to testFailure1 and testFailure3
    assert testFailure2 == testFailure1 and testFailure2 == testFailure3
    # Check that testFailure3 is equal to testFailure1 and testFailure2
    assert testFailure3 == testFailure1 and testFailure3 == testFailure2


# Generated at 2022-06-21 08:09:18.991270
# Unit test for constructor of class TestResult
def test_TestResult():
    # Create TestResult object
    test_result = TestResult(output='TestResult output', message='TestResult message', type='TestResult type')
    assert(test_result.output == 'TestResult output')
    assert(test_result.message == 'TestResult message')
    assert(test_result.type == 'TestResult type')
    assert(test_result.tag == 'testresult')


# Generated at 2022-06-21 08:09:21.073512
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    test_case = TestError('The error message')
    assert repr(test_case) == 'TestError(message="The error message", output=None, type=None)'

# Generated at 2022-06-21 08:09:24.946179
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    class TestSuites_:

        def __init__(self, name = "my_name"):
            self.name = name

        def __repr__(self):
            return self.name

    ts = TestSuites_("my_name")
    assert repr(ts) == "my_name"


# Generated at 2022-06-21 08:09:35.420140
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    name = 'name_test_case'
    assertions = '3'
    classname = 'class_test_case'
    status = 'status'
    time = (1.2).__round__(2)

    # Testcase info
    TestCase_info = TestCase(name, assertions, classname, status, time)

    # Testcase xml
    TestCase_xml = TestCase_info.get_xml_element()

    # Asserting Testcase attributes
    assert TestCase_info.get_attributes() == {'name': name, 'assertions': assertions, 'classname': classname,
                                              'status': status, 'time': str(time)}
    assert TestCase_xml.get('name') == name
    assert TestCase_xml.get('assertions') == assertions

# Generated at 2022-06-21 08:09:40.621808
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    suite_1 = TestSuites(name="TestSuites_name_abc")
    suite_2 = TestSuites(name="TestSuites_name_def")
    suite_3 = TestSuites(name="TestSuites_name_abc")

    assert suite_1 != suite_2
    assert suite_1 == suite_3

# Generated at 2022-06-21 08:09:46.504723
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    err = TestError()
    assert err.get_attributes() == {'type': 'error'}

    err2 = TestError(type='test_type')
    assert err2.get_attributes() == {'type': 'test_type'}

    fail = TestFailure()
    assert fail.get_attributes() == {'type': 'failure'}

    fail2 = TestFailure(type='test_type')
    assert fail2.get_attributes() == {'type': 'test_type'}
