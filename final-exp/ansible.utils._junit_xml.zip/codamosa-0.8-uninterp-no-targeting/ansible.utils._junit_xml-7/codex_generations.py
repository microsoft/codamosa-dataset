

# Generated at 2022-06-21 08:01:42.095106
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    from datetime import datetime
    from collections import OrderedDict
    first = TestSuites()
    second = TestSuites()
    assert first == second
    assert second == first
    first.name = None
    second.name = None
    assert first == second
    assert second == first
    first.name = 'Test Name'
    second.name = None
    assert first != second
    assert second != first
    first.name = None
    second.name = 'Test Name'
    assert first != second
    assert second != first
    first.name = 'Default Test Name'
    second.name = 'Test Name'
    assert first != second
    assert second != first
    first.name = 'Default Test Name'
    second.name = 'Test Name'
    assert first != second
    assert second != first
    first.name

# Generated at 2022-06-21 08:01:53.225705
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testcase1 = TestCase(
        name='test_1',
        assertions=1,
        classname='Foo',
        status='PASS',
        time=decimal.Decimal(1.234)
    )
    testcase2 = TestCase(
        name='test_2',
        assertions=1,
        classname='Foo',
        status='FAIL',
        time=decimal.Decimal(1.234),
        errors=[TestError(
            output='some output',
            message='some message',
            type='Fail'
        )]
    )

# Generated at 2022-06-21 08:01:56.278506
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    class_ = TestResult
    first = class_()
    second = class_()
    assert first == second, 'Method __eq__ of class TestResult must return True if the two objects are equal'


# Generated at 2022-06-21 08:02:01.359413
# Unit test for constructor of class TestResult
def test_TestResult():
    test1 = TestResult(output="Test output", message="Test message", type="Test type")
    assert test1.output == "Test output"
    assert test1.message == "Test message"
    assert test1.type == "Test type"
    assert test1.tag == "Error tag"


# Generated at 2022-06-21 08:02:09.660650
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    test_output: str = "test_output"
    test_message: str = "test_message"
    test_type: str = "test_type"

    # Call the method to be tested
    test_result: TestError = TestError(test_output, test_message, test_type)
    returned: str = test_result.__repr__()


    # Check the returned value
    assert returned == f"TestError(output={test_output}, message={test_message}, type={test_type})"



# Generated at 2022-06-21 08:02:16.120575
# Unit test for constructor of class TestCase
def test_TestCase():
    testCase = TestCase("Test")
    assert testCase.name == "Test"
    assert testCase.assertions == None
    assert testCase.classname == None
    assert testCase.status == None
    assert testCase.time == None
    assert testCase.errors == []
    assert testCase.failures == []
    assert testCase.skipped == None
    assert testCase.system_out == None
    assert testCase.system_err == None
    assert testCase.is_disabled == False


# Generated at 2022-06-21 08:02:17.902598
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    pass


# Generated at 2022-06-21 08:02:24.501978
# Unit test for constructor of class TestFailure
def test_TestFailure():
    test_failure = TestFailure(output = 'out', message = 'msg', type = 'type')
    assert test_failure.type == 'failure'
    assert test_failure.tag == 'failure'
    assert isinstance(test_failure.get_attributes(), dict)
    assert isinstance(test_failure.get_xml_element(), ET.Element)

# Generated at 2022-06-21 08:02:34.034399
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    from ddt import ddt, unpack, data
    import json

    @ddt
    class TestErrorTestCase(unittest.TestCase):

        def setUp(self):
            self.TestError = TestError(output="output", message="message", type="type")
            self.TestError_same = TestError(output="output", message="message", type="type")


# Generated at 2022-06-21 08:02:39.239766
# Unit test for constructor of class TestSuite
def test_TestSuite():
    suite = TestSuite('name', 'hostname', 'id', 'package', datetime.datetime.now(), {'prop1': 'value1'}, [], 'system_out', 'system_err')
    assert len(suite.cases) == 0



# Generated at 2022-06-21 08:02:48.781974
# Unit test for constructor of class TestFailure
def test_TestFailure():
    value = TestFailure('test', message='test_failure', type='failure')
    assert value.tag == 'failure'
    assert value.get_attributes() == {'message': 'test_failure', 'type': 'failure'}

# Generated at 2022-06-21 08:02:53.457173
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    tSuites = TestSuites()
    tSuites.name = 'nameSuites'
    tSuites.tests = 123

    assert tSuites.get_attributes() == {'name': 'nameSuites', 'tests': '123'}


# Generated at 2022-06-21 08:02:55.335069
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    case = TestCase(name='example')
    assert 'example' in repr(case)


# Generated at 2022-06-21 08:02:58.520950
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    error1 = TestError(output="error output", message="error message", type="error type")
    error2 = TestError(output="error output", message="error message", type="error type")
    assert error1 == error2

# Generated at 2022-06-21 08:03:04.103070
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_1 = TestCase('TestCase_1')
    test_case_2 = TestCase('TestCase_2')
    test_case_3 = TestCase('TestCase_1')

    assert test_case_1 == test_case_3
    assert not test_case_1 == test_case_2



# Generated at 2022-06-21 08:03:08.531482
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    r = TestResult('output', 'message', 'type')
    a = r.get_attributes()
    assert( a['type'] == 'failure' )
    assert( a['message'] == 'message' )



# Generated at 2022-06-21 08:03:10.799218
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    result = repr(TestFailure())
    assert isinstance(result, str)
    assert 'TestFailure(' in result




# Generated at 2022-06-21 08:03:16.903318
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite(name='test1', hostname='localhost', id='1', package='std', timestamp=datetime.datetime.now().replace(microsecond=0))
    assert test_suite.get_attributes()
    assert test_suite.get_attributes() == {'name': 'test1', 'hostname': 'localhost', 'id': '1', 'package': 'std', 'timestamp': test_suite.timestamp.isoformat(timespec='seconds')}



# Generated at 2022-06-21 08:03:28.304581
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    assert TestSuites(name='One', suites=[TestSuite(name='two')]) == TestSuites(name='One', suites=[TestSuite(name='two')])
    assert TestSuites(name='One', suites=[TestSuite(name='two')]) != TestSuites(name='One', suites=[TestSuite(name='three')])
    assert TestSuites(name='One', suites=[TestSuite(name='two')]) != TestSuites(name='One', suites=[TestSuite(name='two'), TestSuite(name='three')])
    assert TestSuites(name='One', suites=[TestSuite(name='two')]) != TestSuites(name='One', suites=[TestSuite(name='two'), TestSuite(name='two')])

# Generated at 2022-06-21 08:03:31.663780
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    exp_repr = "TestError(output=None, message=None, type=None)"
    assert repr(TestError()) == exp_repr


# Generated at 2022-06-21 08:03:43.324611
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    testsuites = TestSuites()
    element = testsuites.get_xml_element()
    testsuites.to_pretty_xml()

# Generated at 2022-06-21 08:03:51.556329
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase(name = "My test")
    assert tc.assertions == None
    assert tc.classname == None
    assert tc.status == None
    assert tc.time == None
    assert tc.errors == []
    assert tc.failures == []
    assert tc.skipped == None
    assert tc.system_out == None
    assert tc.system_err == None
    assert tc.is_disabled == False

# Unit tests for is_failure, is_error, is_skipped, get_attributes and get_xml_element

# Generated at 2022-06-21 08:03:56.377303
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite_instanced = TestSuite(name='AwesomeTest')
    test_suites_instanced = TestSuites()
    test_suites_instanced.suites.append(test_suite_instanced)
    print(test_suite_instanced.get_xml_element())
    print(test_suites_instanced.get_xml_element())

# Generated at 2022-06-21 08:04:00.420859
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    ts1 = TestSuite(name="Suite 1")
    ts1.cases.append(TestCase(name="Case 1"))

    ts2 = TestSuite(name="Suite 1")
    ts2.cases.append(TestCase(name="Case 1"))

    assert ts1 == ts2



# Generated at 2022-06-21 08:04:05.924161
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    attributes = test_result.get_attributes()
    assert attributes == {}

    output = "XXX"
    message = "XXX"
    type = "XXX"
    test_result = TestResult(output=output, message=message, type=type)
    attributes = test_result.get_attributes()
    assert attributes == {
            'type': type,
            'message': message, 
            }


# Generated at 2022-06-21 08:04:10.645070
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    testsuite1 = TestSuite(
        name='testSuite',
        hostname='hostname',
        id='id',
        package='package',
        timestamp=datetime.datetime.now(),
    )

    testsuite2 = TestSuite(
        name='testSuite',
        hostname='hostname',
        id='id',
        package='package',
        timestamp=datetime.datetime.now(),
    )

    assert testsuite1 == testsuite2


# Generated at 2022-06-21 08:04:14.932965
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():

    test1 = TestResult()
    assert test1.get_attributes() == {}

    test2 = TestResult("test", "test", "test")
    assert test2.get_attributes() == {"type" : "success"}


# Generated at 2022-06-21 08:04:26.285032
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite('name')
    suite.package = 'com.mycompany.myproject'
    suite.timestamp = datetime.datetime.now()
    suite.properties['java.runtime.name'] = 'Java HotSpot(TM) 64-Bit Server VM'
    suite.properties['sun.boot.library.path'] = '/Library/Java/JavaVirtualMachines/jdk1.8.0_251.jdk/Contents/Home/jre/lib'
    suite.properties['java.vm.version'] = '25.251-b08'

    # Create a test case
    case = TestCase('test01')

    # Add an error
    error = TestError('error message')
    error.output = 'error output'
    error.type = 'error type'
    case.errors.append(error)

    #

# Generated at 2022-06-21 08:04:29.652785
# Unit test for constructor of class TestFailure
def test_TestFailure():
    # Initialize TestFailure object
    testCase_info = TestFailure()
    # Test object type
    assert type(testCase_info) == TestFailure


# Generated at 2022-06-21 08:04:31.586538
# Unit test for constructor of class TestSuites
def test_TestSuites():
    assert _attributes(name="Test") == {"name": "Test"}

# Generated at 2022-06-21 08:04:53.956506
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    test_result = TestFailure(output='Some Output', message='Some Message')
    assert test_result.output == 'Some Output'
    assert test_result.message == 'Some Message'
    assert test_result.type == 'failure'


# Generated at 2022-06-21 08:05:06.489210
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    import datetime
    test_suite1 = TestSuites()
    test_suite1.name = 'test_suites'
    # suite1
    suite1 = TestSuite()
    suite1.name = 'suite1'
    suite1.id = '1'
    suite1.hostname = 'localhost'
    suite1.package = 'io.github.kings1990.rapidframework.demo'
    suite1.timestamp = datetime.datetime(2020,12,5,5,5,5)
    suite1.properties = {"java.version":"11", "pycharm.version":"2020.1"}

    case1 = TestCase()
    case1.name = 'testcase1'
    case1.classname = 'TestCase1'
    case1.status = 'PASS'
    case

# Generated at 2022-06-21 08:05:13.220758
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_case = TestCase(
        assertions=None,
        classname="test_TestSuite",
        name="test_method",
        status=None,
        time="0.0"
    )
    test_suite = TestSuite(
        name = "suite_name",
        hostname=None,
        id=None,
        package="my.package",
        timestamp="2020-01-01T01:01:01"
    )
    property = {
    }
    test_suite.properties = property
    test_suite.cases.append(test_case)
    test_suite.system_out = "stdout"
    test_suite.system_err = "stderr"
    test_suites = TestSuites(
        name = "test_suites"
    )

# Generated at 2022-06-21 08:05:19.530965
# Unit test for constructor of class TestCase
def test_TestCase():
    case = TestCase(name="test-001", assertions=0, classname="test-class", status="success", time=0.1)
    assert case.name == "test-001"
    assert case.assertions == 0
    assert case.classname == "test-class"
    assert case.status == "success"
    assert case.time == 0.1


# Generated at 2022-06-21 08:05:20.183886
# Unit test for constructor of class TestSuite
def test_TestSuite():
    TestSuite(name = "TestMachineLearning")
    

# Generated at 2022-06-21 08:05:21.559416
# Unit test for constructor of class TestError
def test_TestError():
    assert TestError().type == 'error'


# Generated at 2022-06-21 08:05:27.626113
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    result = TestResult(
                        output="this is the output",
                        message="this is the message",
                        type="this is the type"
                        )
    assert result.type == "this is the type"
    result2 = TestResult(
                        output="this is the output",
                        message="this is the message",
                        )
    assert result2.type == "testResult"


# Generated at 2022-06-21 08:05:32.615998
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    expected_result = {'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '0', 'time': '0'}
    assert _attributes(
        disabled=0,
        errors=0,
        failures=0,
        tests=0,
        time=0,
    ) == expected_result, "The attributes are not correct"

# Generated at 2022-06-21 08:05:34.966809
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    first = TestSuite(name="name")
    second = TestSuite(name="name2")
    assert first == first
    assert second == second
    assert first != second


# Generated at 2022-06-21 08:05:45.914942
# Unit test for method __repr__ of class TestSuite

# Generated at 2022-06-21 08:06:35.381661
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    test_case_id = 5

# Generated at 2022-06-21 08:06:37.127714
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert 1 == 1

# Generated at 2022-06-21 08:06:43.794260
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    case = TestCase('TestCase_name',assertions=1, classname='TestCase_classname', status='TestCase_status', time=2.3)
    expected_output = {'assertions': '1', 'classname': 'TestCase_classname', 'name': 'TestCase_name', 'status': 'TestCase_status', 'time': '2.3'}
    output = case.get_attributes()
    assert output == expected_output


# Generated at 2022-06-21 08:06:55.266536
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    suites = TestSuites()
    suite = TestSuite(name='My Suite')
    suite.cases.append(TestCase(name='My Test'))
    suites.suites.append(suite)

# Generated at 2022-06-21 08:07:02.911191
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
	test_case = TestCase('test_case')
	test_case.time = "10"
	test_suite = TestSuite('test_suite')
	test_suite.cases.append(test_case)
	test_suite.timestamp = datetime.datetime.now()
	print(test_suite.get_xml_element())

if __name__ == "__main__":
	test_TestSuite_get_xml_element()

# Generated at 2022-06-21 08:07:13.029304
# Unit test for constructor of class TestCase
def test_TestCase():
    name = 'TestCase'
    assertions = 2
    classname = 'name'
    status = 'status'
    time = decimal.Decimal(2.2)
    errors = [TestError(output='output', message='message', type='type')]
    failures = [TestFailure(output='output', message='message', type='type')]
    skipped = 'skipped'
    system_out = 'system_out'
    system_err = 'system_err'
    is_disabled = True
    test_case = TestCase(name,assertions,classname,status,time,errors,failures,skipped,system_out,system_err,is_disabled)

    assert test_case.name == name
    assert test_case.assertions == assertions
    assert test_case.classname == classname
    assert test_case

# Generated at 2022-06-21 08:07:15.770920
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert TestError.__repr__.__doc__ is not None

    # Default test
    test_case = TestError()
    assert test_case.__repr__() is not None



# Generated at 2022-06-21 08:07:17.759765
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    test_a = TestSuites()

    assert test_a == test_a


# Generated at 2022-06-21 08:07:24.116501
# Unit test for constructor of class TestSuite
def test_TestSuite():
    hc_suite = TestSuite(
        name='hc_suite',
        hostname='hc_host',
        id='hc_id',
        package='hc_package',
        # timestamp = 'hc_timestamp',
        disabled=1,
        errors=1,
        failures=3,
        skipped=4,
        tests=2
    )
    print(hc_suite)
    print(hc_suite.get_attributes())



# Generated at 2022-06-21 08:07:30.946025
# Unit test for constructor of class TestError
def test_TestError():
    te = TestError()
    te.message = "TestError"
    te.output = "TestError"
    te.type = "TestError"
    te.tag = "TestError"

    attr = te.get_attributes()
    assert attr['message'] == 'TestError'
    assert attr['type'] == 'TestError'

    element = te.get_xml_element()
    assert element.tag == 'TestError'
    assert element.text == 'TestError'


# Generated at 2022-06-21 08:08:50.904257
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test = TestSuites(name = 'test', suites = [])
    assert test.get_attributes() == { 'name':'test' }



# Generated at 2022-06-21 08:08:54.131409
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    testError_1 = TestError()
    testError_2 = TestError()
    assert testError_1.__eq__(testError_2) == NotImplemented


# Generated at 2022-06-21 08:08:57.513905
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite(name='TestSuite', timestamp=datetime.datetime.now())
    attributes = test_suite.get_attributes()
    assert 'name' in attributes
    assert 'timestamp' in attributes



# Generated at 2022-06-21 08:09:03.278175
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite(
        name="TestSuite",
        hostname="TestHost",
        id="1",
        package="Package",
        timestamp=datetime.datetime.now(),
    )
    expected = {
        "disabled": "0",
        "errors": "0",
        "failures": "0",
        "hostname": "TestHost",
        "id": "1",
        "name": "TestSuite",
        "package": "Package",
        "skipped": "0",
        "tests": "0",
        "time": "0",
        "timestamp": suite.timestamp.isoformat(timespec='seconds'),
    }
    assert suite.get_attributes() == expected


# Generated at 2022-06-21 08:09:05.791094
# Unit test for constructor of class TestError
def test_TestError():
    ele = TestError()
    assert ele.message == None
    assert ele.output == None
    assert ele.type == 'error'


# Generated at 2022-06-21 08:09:11.335866
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    attrs = ['output', 'message', 'type']
    for attr in attrs:
        value = 'value'
        result = TestResult(**{attr: value})
        assert getattr(result, attr) == value

    result = TestResult()
    assert result.type == 'failure'



# Generated at 2022-06-21 08:09:13.987748
# Unit test for method __eq__ of class TestSuites

# Generated at 2022-06-21 08:09:24.945781
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    # Method Setup
    test_suite = TestSuite(
        name = 'test', 
        hostname = 'localhost', 
        id = '1', 
        package = 'io.integral', 
        timestamp = '2020-07-27T10:51:25-06:00', 
        properties = {'1': '2'},
        tests = 10
    )
    expected_output = {
        'hostname': "localhost",
        'id': "1",
        'name': "test",
        'package': "io.integral",
        'tests': "10",
        'timestamp': "2020-07-27T10:51:25-06:00"
    }
    # Test code
    actual_output = test_suite.get_attributes()
    assert actual_output == expected

# Generated at 2022-06-21 08:09:28.515097
# Unit test for constructor of class TestResult
def test_TestResult():
    # case 1: without output, without message
    test_case = TestSuite(name='Test_Suite',
                          timestamp=None,
                          cases=None)
    assert test_case.output == None
    assert test_case.message == None


# Generated at 2022-06-21 08:09:29.740332
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    pass


# Generated at 2022-06-21 08:11:08.346988
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    suites = TestSuites()
    assert str(suites) == '<TestSuites()>'

    suites = TestSuites(name='foo')
    assert str(suites) == '<TestSuites(name=foo)>'

# Generated at 2022-06-21 08:11:14.255476
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    suites = TestSuites(name='My Test Suites')
    suites.suites = [
        TestSuite(name='My Test Suite', timestamp=datetime.datetime.now()),
        TestSuite(name='My Other Test Suite', timestamp=datetime.datetime.now()),
    ]
    expected = '<TestSuites name="My Test Suites" tests=2>'
    assert repr(suites) == expected