

# Generated at 2022-06-21 08:01:27.368542
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_a= TestCase('name')
    test_case_b= TestCase('name')
    assert test_case_a == test_case_b

if __name__ == '__main__':
    test_TestCase___eq__()

# Generated at 2022-06-21 08:01:32.823003
# Unit test for constructor of class TestSuites
def test_TestSuites():

	# Constructor for class TestSuites works
	testsuites = TestSuites()
	assert testsuites != None
	assert testsuites.name == None
	assert testsuites.suites == []

	# Constructor for class TestSuites works
	testsuites = TestSuites('test')
	assert testsuites != None
	assert testsuites.name == 'test'
	assert testsuites.suites == []



# Generated at 2022-06-21 08:01:45.091816
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-21 08:01:49.583000
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    expected_dict =  {'message': 'some_message', 'type': 'some_type'}
    actual_dict = TestResult(message='some_message', type='some_type').get_attributes()
    assert actual_dict == expected_dict



# Generated at 2022-06-21 08:01:57.224047
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    test_result_instance = TestResult()
    test_result_instance.is_failure = False
    test_result_instance.is_error = False
    assert str(test_result_instance.get_attributes()) == "{'message': None, 'type': 'TestResult'}"
    assert str(test_result_instance.get_xml_element()) == "<Element 'TestResult' at 0x10b12af88>"
    assert test_result_instance.tag == "TestResult"
    assert not test_result_instance.is_disabled
    assert not test_result_instance.is_failure
    assert not test_result_instance.is_error
    assert test_result_instance.skipped == None
    assert test_result_instance.system_out == None
    assert test_result_instance.system_err == None




# Generated at 2022-06-21 08:02:09.508625
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:02:10.841694
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    expected = \
"""TestError(output=None, message=None, type='error')"""
    actual = repr(TestError())
    assert actual == expected


# Generated at 2022-06-21 08:02:13.588128
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test1 = TestSuite(name='test_name')
    test2 = TestSuite(name='test_name')
    assert test1 == test2



# Generated at 2022-06-21 08:02:17.473547
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    # Given
    outout = 'output'
    message = 'message'
    test_error = TestError(outout, message)

    # When
    result = test_error.__repr__()

    # Then
    assert result == f'<TestError output="{outout}" message="{message}">'


# Generated at 2022-06-21 08:02:29.982553
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    xml_output1 = 'The following expected exception was not thrown: junit.framework.AssertionFailedError'
    junit_failure1 = TestFailure(output=xml_output1, message=xml_output1, type=xml_output1)
    element1 = junit_failure1.get_xml_element()
    assert element1.text == xml_output1
    assert element1.attrib['message'] == xml_output1
    assert element1.attrib['type'] == xml_output1

    xml_output2 = 'Invalid test case name: \'[123] Test\''
    junit_failure2 = TestFailure(output=xml_output2, message=xml_output2)
    element2 = junit_failure2.get_xml_element()
    assert element2.text == xml_output2


# Generated at 2022-06-21 08:02:40.135434
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testcase = TestCase(name='TestCaseA')
    assert testcase.get_attributes() == {'name':'TestCaseA'}


# Generated at 2022-06-21 08:02:42.998784
# Unit test for constructor of class TestFailure
def test_TestFailure():
  output = TestFailure('output')

  assert output.output == 'output'
  assert output.tag == 'failure'


# Generated at 2022-06-21 08:02:44.079035
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert TestError(type='', message='').get_attributes() == {'type': '', 'message': ''}


# Generated at 2022-06-21 08:02:54.327397
# Unit test for constructor of class TestSuites
def test_TestSuites():
    # Test when valid inputs are given
    obj = TestSuites(name='n', suites=['s'])
    assert obj.name == 'n' and obj.suites == ['s']
    # Test when invalid inputs are given
    try:
        obj = TestSuites(name=[1])
    except TypeError:
        assert True
    except:
        assert False
    try:
        obj = TestSuites(suites='s')
    except TypeError:
        assert True
    except:
        assert False


# Generated at 2022-06-21 08:02:58.708882
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # Given
    test_cases = [TestCase(name='test1'), TestCase(name='test2')]
    test_suites = TestSuites(suites=[TestSuite(name="suite1", cases=test_cases)])

# Generated at 2022-06-21 08:03:04.286842
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    """
    Unit test for method get_attributes of class TestResult
    """
    test_result = TestResult(output='output', message='message', type='type')
    attributes = test_result.get_attributes()
    assert attributes['message'] == 'message'
    assert attributes['type'] == 'type'



# Generated at 2022-06-21 08:03:13.639059
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    dt = datetime.datetime(2020, 7, 3, 13, 37, 58)
    suite = TestSuite('Test Succeeded', timestamp=dt)
    suites = TestSuites(
        name='TestSucceeded',
        suites=[suite],
    )
    assert suites.get_attributes() == {
        'errors': '0',
        'failures': '0',
        'name': 'TestSucceeded',
        'tests': '1',
        'time': '0',
        'timestamp': '2020-07-03T13:37:58',
    }


# Generated at 2022-06-21 08:03:15.632330
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(output="test output")
    assert result.get_attributes() == {'type': 'TestResult'}



# Generated at 2022-06-21 08:03:26.406664
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # pylint: disable=line-too-long
    validate_repr(TestFailure(output='test', message='test', type='test'), 'TestFailure(output="test", message="test", type="test")')
    validate_repr(TestError(output='test', message='test', type='test'), 'TestError(output="test", message="test", type="test")')
    validate_repr(TestCase(name='test', assertions=1, classname='test', status='test', time=decimal.Decimal('1.2')), 'TestCase(name="test", assertions=1, classname="test", status="test", time=Decimal("1.2"))')

# Generated at 2022-06-21 08:03:27.505901
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    Error = TestError("Failed")

    if 'Failed' not in repr(Error):
        raise AssertionError("Error in representation")


# Generated at 2022-06-21 08:03:47.986460
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    output = TestSuites(name='test').get_attributes()
    assert output == {'name': 'test', 'tests': 0, 'time': '0.0', 'errors': 0, 'disabled': 0, 'failures': 0}

# Generated at 2022-06-21 08:03:52.892808
# Unit test for constructor of class TestSuites
def test_TestSuites():
    suite = TestSuites(name = 'Mark', suites = [TestSuite('Leo', cases = [TestCase('John')])])
    assert suite.name == 'Mark'
    assert suite.suites[0].cases[0].name == 'John'
    assert suite.suites[0].name == 'Leo'


# Generated at 2022-06-21 08:04:00.380500
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    class Temp:
        def __eq__(self, other):
            if isinstance(other, Temp):
                return True
            return NotImplemented
    class1 = TestSuite('name',id='id1')
    class2 = TestSuite('name',id='id2')
    assert(class1 != class2)
    class1 = TestSuite('name',id='id1')
    class2 = TestSuite('name',id='id1')
    assert(class1==class2)
    assert(class1 != Temp())
    assert(class1 == class1)


# Generated at 2022-06-21 08:04:04.119503
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    case = TestCase('TestCase1')
    expected = "<TestSuite name='TestSuite1' tests='0' errors='0' failures='0' skipped='0' time='0'>"
    suite = TestSuite('TestSuite1')
    assert repr(suite) == expected


# Generated at 2022-06-21 08:04:10.136874
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    case1 = TestCase(
        assertions=11,
        classname='x',
        errors=[TestError(
            message='Message',
            output='Output',
            type='Type',
        )],
        failures=[TestFailure(
            message='Message',
            output='Output',
            type='Type',
        )],
        is_disabled=False,
        name='x',
        skipped='Skippped',
        system_err='Error',
        system_out='Out',
        time=decimal.Decimal(1.0),
        status='Status',
    )

# Generated at 2022-06-21 08:04:20.117294
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    """
    noinspection PyUnboundLocalVariable
    test that type of the result is set to the tag name when it is not given in __init__
    """
    class test_result(TestResult):
        """
        This class is used to test the __post_init__ method of the superclass TestResult.
        The tag property is overridden to be 'test'.
        """
        @property
        def tag(self) -> str:
            return 'test'
    # check that type of the result is set to the tag name when it is not given in __init__
    result = test_result()
    assert result.type == 'test'


# Generated at 2022-06-21 08:04:25.853886
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    suites = TestSuites()
    assert suites.get_attributes() == _attributes(
        disabled=suites.disabled,
        errors=suites.errors,
        failures=suites.failures,
        name=suites.name,
        tests=suites.tests,
        time=suites.time,
    )

# Test for method get_xml_element of class TestSuites

# Generated at 2022-06-21 08:04:38.287129
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # Initializing the test parameters
    package_name = 'com.example.project'
    suite_name = 'TestSuite'
    timestamp = datetime.datetime.now().replace(microsecond=0)
    hostname = 'localhost'
    properties = {'user.name': 'user'}

    test_name = 'TestCase1'
    test_message = 'failure message'
    test_output = 'output'

    # Creating test instances
    properties = {'user.name': 'user'}
    test_case = TestCase(name=test_name, output=test_output, failures=[TestFailure(message=test_message)])

# Generated at 2022-06-21 08:04:39.847156
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    assert TestResult() == TestResult()


# Generated at 2022-06-21 08:04:43.752227
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    obj = TestError()
    params = (
        obj.output,
        obj.message,
    )
    assert repr(obj) == 'TestError(output=%r, message=%r)' % params


# Generated at 2022-06-21 08:05:05.716242
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite(name='name')
    assert suite.get_attributes() == {'name': 'name'}

    suite = TestSuite(name='name', id='id')
    assert suite.get_attributes() == {'name': 'name', 'id': 'id'}

    suite = TestSuite(name='name', timestamp=datetime.datetime.now())
    assert suite.get_attributes() == {'name': 'name', 'timestamp': suite.timestamp.isoformat(timespec='seconds')}



# Generated at 2022-06-21 08:05:07.967444
# Unit test for constructor of class TestFailure
def test_TestFailure():
    failure = TestFailure(
        "output.txt",
        "this is an error message",
        "error type",
    )


# Generated at 2022-06-21 08:05:13.576688
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    name = 'name'
    classname = 'classname'
    time = decimal.Decimal('.123')
    case = TestCase(name=name, classname=classname, time=time)
    assert case == TestCase(name=name, classname=classname, time=time)
    assert case != TestCase(name=name, classname=classname, time=time * 2)
    assert case != TestCase(name=name, classname=classname)
    assert case != TestCase(name=name, classname=classname * 2)
    assert case != TestCase(name=name * 2, classname=classname)
    assert case != TestCase(name=name * 2, classname=classname * 2)


# Generated at 2022-06-21 08:05:21.696282
# Unit test for constructor of class TestError
def test_TestError():
    error_message = 'Example Error'
    type_error = 'Example Type Error'
    output = 'Example Output'
    test_error = TestError(message=error_message, type=type_error, output=output)
    #test_error = TestError(message='Example Error')

    assert test_error.message == error_message
    assert test_error.type == type_error
    assert test_error.output == output
    assert test_error.tag == 'error'


# Generated at 2022-06-21 08:05:27.182702
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    """Test for method get_attributes of class TestSuites"""
    attributes = _attributes(
        disabled=0,
        errors=0,
        failures=0,
        name="test-name",
        tests=0,
        time=None,
    )
    obj = TestSuites("test-name")
    assert obj.get_attributes() == attributes

# Generated at 2022-06-21 08:05:29.708674
# Unit test for constructor of class TestSuites
def test_TestSuites():
    try:
        test_suite = TestSuites()
    except Exception as e:
        print(e)


# Generated at 2022-06-21 08:05:35.431160
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    # Setup
    obj = TestCase(name='First name')
    obj2 = TestCase(name='Second name')
    obj3 = TestCase(name='First name')
    # Exercise
    result = obj == obj2
    # Verify
    assert result == False

    # Setup
    obj = TestCase(name='First name')
    obj3 = TestCase(name='First name')
    # Exercise
    result = obj == obj3
    # Verify
    assert result == True



# Generated at 2022-06-21 08:05:39.043801
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    TestResult.__post_init__(TestError())
    TestError.__post_init__(TestError(type="Something"))

# Generated at 2022-06-21 08:05:41.154992
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert repr(TestError()) == 'TestError(output=None, message=None, type=None)'


# Generated at 2022-06-21 08:05:48.444464
# Unit test for method __repr__ of class TestSuite

# Generated at 2022-06-21 08:06:23.974678
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    """Test the method get_attributes of the class TestResult"""
    # Fixture
    test_result = TestResult(message="Test",type="TypeTest")

    # Test
    attr = test_result.get_attributes()

    # Assertion
    assert len(attr) == 2



# Generated at 2022-06-21 08:06:33.952107
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult()) == "TestResult(output=None, message=None, type=None)"
    assert repr(TestResult(output='output text')) == "TestResult(output='output text', message=None, type=None)"
    assert repr(TestResult(message='error message')) == "TestResult(output=None, message='error message', type=None)"
    assert repr(TestResult(type='assert error')) == "TestResult(output=None, message=None, type='assert error')"
    assert repr(TestResult(output='output text', message='error message', type='assert error')) == "TestResult(output='output text', message='error message', type='assert error')"


# Generated at 2022-06-21 08:06:36.338612
# Unit test for constructor of class TestError
def test_TestError():
    result = TestError(output='output', message='message', type='failure')
    assert result.output == "output"
    assert result.message == "message"
    assert result.type == "failure"


# Generated at 2022-06-21 08:06:48.509057
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    print("\ntest_TestSuites_get_attributes")
    test_suites = TestSuites()
    test_suite_1 = TestSuite(name="test_suite_1")
    test_suite_2 = TestSuite(name="test_suite_2")
    test_case_1 = TestCase(name="test_case_1")
    test_case_2 = TestCase(name="test_case_2")
    test_case_3 = TestCase(name="test_case_3")
    test_suite_1.cases.append(test_case_1)
    test_suite_1.cases.append(test_case_2)
    test_suite_2.cases.append(test_case_3)

# Generated at 2022-06-21 08:06:56.944287
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    current = TestCase("LoginTest", assertions=5, classname="com.example.tests", status="PASSED", time=decimal.Decimal("0.01"), errors=[], failures=[], skipped="false", system_out="some_text", system_err="some_text", is_disabled=False)
    expected = TestCase("LoginTest", assertions=5, classname="com.example.tests", status="PASSED", time=decimal.Decimal("0.01"), errors=[], failures=[], skipped="false", system_out="some_text", system_err="some_text", is_disabled=False)
    actual = current.__eq__(expected)
    assert actual == True


# Generated at 2022-06-21 08:07:08.304640
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    TestCase_data = [{"name": "test_1",
                  "classname": "class_1",
                  "status": "status_1",
                  "time": decimal.Decimal(1.0),
                  "errors": [],
                  "failures": [],
                  "skipped": None,
                  "system_out": None,
                  "system_err": None},
                 {"name": "test_2",
                  "classname": "class_2",
                  "status": "status_2",
                  "time": decimal.Decimal(2.0),
                  "errors": [],
                  "failures": [],
                  "skipped": "skipped_2",
                  "system_out": "system_out_2",
                  "system_err": "system_err_2"}]


# Generated at 2022-06-21 08:07:14.321689
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    a = TestFailure()
    b = TestFailure()
    c = TestFailure(output='abc', message='abc', type='abc')
    d = TestFailure(output='def')
    e = TestFailure(message='def')
    f = TestFailure(type='def')
    g = TestError()

    assert a == b
    assert a == c
    assert a != d
    assert a != e
    assert a != f
    assert a != g
    assert a != object()


# Generated at 2022-06-21 08:07:18.706012
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():

    """Test get_attributes method of class TestResult"""

    failure_obj = TestResult(output = "",
                             message = None,
                             type = "")
    attributes = failure_obj.get_attributes()
    assert attributes == {'type' : 'testresult'}



# Generated at 2022-06-21 08:07:24.984643
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    """
    Test __eq__ of TestCase class
    """
    tc1 = TestCase(name="tc1")
    tc2 = TestCase(name="tc2")
    tc3 = TestCase(name="tc1")
    assert tc1.__eq__(tc3)
    assert not tc1.__eq__(tc2)


# Generated at 2022-06-21 08:07:34.267608
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    from datetime import datetime
    from decimal import Decimal
    invalid_value = TestResult('output', 'message', 'type')
    result_output = TestResult('output')
    result_message = TestResult(message='message')
    result_type = TestResult(type='type')
    result_all = TestResult('output', 'message', 'type')
    invalid_dict = _attributes(output=invalid_value, message=invalid_value, type=invalid_value)
    output_dict = _attributes(output=result_output.output)
    message_dict = _attributes(message=result_message.message)
    type_dict = _attributes(type=result_type.type)

# Generated at 2022-06-21 08:08:11.806358
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError(output='Some output', message='Some message', type='Some type') == TestError(output='Some output', message='Some message', type='Some type')
    assert not TestError(output='Some output', message='Some message', type='Some type') == TestError(output='Some output', message='Some message', type='Some type1')
    assert not TestError(output='Some output', message='Some message', type='Some type') == TestError(output='Some output', message='Some message1', type='Some type')
    assert not TestError(output='Some output', message='Some message', type='Some type') == TestError(output='Some output1', message='Some message', type='Some type')
    assert not TestError(output='Some output', message='Some message', type='Some type') == 'Some output'

# Generated at 2022-06-21 08:08:16.134257
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    """Test method __repr__ of class TestSuites"""

    test_suites = TestSuites()
    assert repr(test_suites) == "TestSuites(name=None, suites=[])"

    test_suites.name = "unit_test"
    assert repr(test_suites) == "TestSuites(name='unit_test', suites=[])"



# Generated at 2022-06-21 08:08:27.491137
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():

    testsuites = TestSuites()
    testsuite = TestSuite("Name")
    testcase1 = TestCase("Name")
    testcase2 = TestCase("Name2")
    testcase3 = TestCase("Name3")
    testcase4 = TestCase("Name4")
    testcase5 = TestCase("Name5")
    testsuite.cases.append(testcase1)
    testsuite.cases.append(testcase2)
    testsuite.cases.append(testcase3)
    testsuite.cases.append(testcase4)
    testsuite.cases.append(testcase5)
    testsuites.suites.append(testsuite)
    #assert testsuites.to_pretty_xml() == str("")
    print(testsuites.to_pretty_xml())

# Generated at 2022-06-21 08:08:32.265603
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    import datetime
    ts = TestSuites(name='TestSuite')
    ts.suites.append(TestSuite('TestSuite1', hostname='localhost', id='1', package='mypackage', timestamp=datetime.datetime.now()))
    ts.suites[0].cases.append(TestCase('testcase1'))
    ts.suites[0].cases[0].errors.append(TestError('someerror', type='sometype', message='somemessage'))
    ts.suites[0].cases.append(TestCase('testcase2'))
    ts.suites[0].cases[1].failures.append(TestFailure('someerror'))
    ts.suites[0].cases[1].errors.append(TestError('someerror'))

# Generated at 2022-06-21 08:08:36.533563
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    # Preparation
    obj1 = TestResult()
    obj2 = TestResult(output=None, message=None, type=None)
    assert obj1.__eq__(obj2) == True


# Generated at 2022-06-21 08:08:40.924438
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output = 'Test output', message = 'Test message', type = 'Test type')
    assert test_result.get_xml_element().attrib == { 'message': 'Test message', 'type': 'Test type' }
    assert test_result.get_xml_element().text == 'Test output'


# Generated at 2022-06-21 08:08:46.058345
# Unit test for constructor of class TestCase
def test_TestCase():
    expected_parsed_results = {'classname': 'TestCase', 'name': 'A', 'output': 'C', 'message': 'B'}
    actual_parsed_results = TestCase('A', classname='TestCase', output='C', message='B')
    assert expected_parsed_results == actual_parsed_results


# Generated at 2022-06-21 08:08:57.429813
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    # test empty object
    test_obj = TestSuite()
    assert repr(test_obj) == 'TestSuite(name=None, hostname=None, id=None, package=None, timestamp=None, properties=None, cases=None, system_out=None, system_err=None)'

    # test full object

# Generated at 2022-06-21 08:09:04.554102
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    raw_xml = """<?xml version="1.0" ?>
        <testsuites disabled="0" errors="0" failures="0" name="null" tests="2" time="0.000">
            <testsuite assertions="0" classname="null" disabled="0" errors="0" failures="0" hostname="null" id="null" name="null" package="null" skipped="0" tests="2" time="0.000" timestamp="null">
                <testcase assertions="0" classname="null" name="null" status="null" time="0.000"/>
                <testcase assertions="0" classname="null" name="null" status="null" time="0.000"/>
            </testsuite>
        </testsuites>"""
    expected = ET.fromstring(raw_xml)
    ts = Test

# Generated at 2022-06-21 08:09:06.980243
# Unit test for constructor of class TestSuite
def test_TestSuite():
    assert TestSuite('TestSuiteName').name == 'TestSuiteName'


# Generated at 2022-06-21 08:09:38.744143
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name="sample of testsuite")
    element = suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.attrib['name'] == 'sample of testsuite'


# Generated at 2022-06-21 08:09:39.982996
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    pass


# Generated at 2022-06-21 08:09:42.319455
# Unit test for constructor of class TestSuites
def test_TestSuites():
    test_suites = TestSuites(name="TestSuites")
    assert test_suites.name == "TestSuites"


# Generated at 2022-06-21 08:09:49.639933
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    test_result1 = TestResult("output1", "message1", "type1")
    assert test_result1.output == "output1"
    assert test_result1.message == "message1"
    assert test_result1.type == "type1"

    test_result2 = TestResult("output2", "message2")
    assert test_result2.output == "output2"
    assert test_result2.message == "message2"
    assert test_result2.type == "TestResult"

    test_result3 = TestResult("output3")
    assert test_result3.output == "output3"
    assert test_result3.message == None
    assert test_result3.type == "TestResult"

    test_result4 = TestResult()
    assert test_result4.output == None
    assert test_

# Generated at 2022-06-21 08:09:57.404824
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite('myTestsuite', 'localhost', '1', 'com.example.tests', datetime.datetime.now())
    actual = suite.get_xml_element()
    expected = ET.fromstring('<testsuite disabled="0" errors="0" failures="0" hostname="localhost" id="1" name="myTestsuite" package="com.example.tests" tests="0" time="0" timestamp="' + datetime.datetime.now().isoformat(timespec='seconds') + '"/>')
    assert actual.tag == expected.tag
    assert actual.attrib == expected.attrib


# Generated at 2022-06-21 08:10:02.749169
# Unit test for constructor of class TestCase
def test_TestCase():
    test_case = TestCase(name='test_test_case', assertions=1, classname='TestCase', status='', time=0.1)
    assert test_case.get_xml_element().tag == 'testcase'
    assert test_case.name == 'test_test_case'
    assert test_case.assertions == 1
    assert test_case.classname == 'TestCase'
    assert test_case.status == ''
    assert test_case.time == 0.1


# Generated at 2022-06-21 08:10:05.263277
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    # Setup
    result = TestError(output="...", message="...")
    # Exercise
    actual = str(result)
    # Verify
    assert actual == "<TestError message='...' output='...' type='error'>"


# Generated at 2022-06-21 08:10:08.340947
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    tc1 = TestCase("test_method_name")
    attr = tc1.get_attributes()
    assert attr['name'] == "test_method_name"
    assert attr['classname'] == None


# Generated at 2022-06-21 08:10:19.140255
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    # test_case_suite_1 is instance of TestSuite class
    test_case_suite_1 = TestSuite(name='test_suite_1', hostname='test_host_name')
    # test_case_suite_2 is instance of TestSuite class
    test_case_suite_2 = TestSuite(name='test_suite_2', hostname='test_host_name_2')
    # test_case_suite_3 is instance of TestSuite class
    # test_case_suite_3 = TestSuite(name='test_suite_3', hostname=None)

    test_case_1 = TestCase(name='test_1')
    test_case_2 = TestCase(name='test_2')

# Generated at 2022-06-21 08:10:27.995459
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_suite1 = TestSuite(
        name="Test Suite 1",
        hostname="localhost",
        id="id",
        package="package",
        timestamp=datetime.datetime(2020, 10, 10, 16, 23, 0, 0),
        properties={
            "property1": "value1",
            "property2": "value2",
        },
        system_out="Test relevant output",
        system_err="Test relevant error",
    )


# Generated at 2022-06-21 08:11:10.404352
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-21 08:11:13.415792
# Unit test for constructor of class TestResult
def test_TestResult():
    tr = TestResult('output', 'message', 'type')
    assert tr.output == 'output'
    assert tr.message == 'message'
    assert tr.type == 'type'


# Generated at 2022-06-21 08:11:23.591994
# Unit test for constructor of class TestCase
def test_TestCase():
    error = TestError(message="Test Error Message")
    failure = TestFailure(message="Test Failure Message")
    skipped = "Test Skipped"
    system_out = "Test System Out"
    system_err = "Test System Err"

    new_TestCase = TestCase(name="Test Case")
    assert new_TestCase.name == "Test Case"
    assert new_TestCase.assertions == None
    assert new_TestCase.classname == None
    assert new_TestCase.status == None
    assert new_TestCase.time == None
    assert new_TestCase.errors == []
    assert new_TestCase.failures == []
    assert new_TestCase.skipped == None
    assert new_TestCase.system_out == None
    assert new_TestCase.system_err == None
    assert new_TestCase