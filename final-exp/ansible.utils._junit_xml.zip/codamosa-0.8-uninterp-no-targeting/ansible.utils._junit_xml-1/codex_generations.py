

# Generated at 2022-06-21 08:01:22.743974
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult()) == 'TestResult()'


# Generated at 2022-06-21 08:01:26.026988
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    test_suites = TestSuites(name='name')
    expected = 'TestSuites(name=\'name\', suites=[])'
    assert test_suites.__repr__() == expected

# Generated at 2022-06-21 08:01:33.725592
# Unit test for constructor of class TestCase
def test_TestCase():
    tester = TestCase(name='test_Test')
    assert tester.name == 'test_Test'
    assert tester.assertions == None
    assert tester.classname == None
    assert tester.status == None
    assert tester.time == None
    assert tester.errors == []
    assert tester.failures == []
    assert tester.skipped == None
    assert tester.system_out == None
    assert tester.system_err == None
    assert tester.is_disabled == False
    assert tester.is_failure == False
    assert tester.is_error == False
    assert tester.is_skipped == False


# Generated at 2022-06-21 08:01:37.238863
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    """Return a string representation for a unit test."""
    assert repr(TestResult()) == "TestResult(output=None, message=None, type=None)"


# Generated at 2022-06-21 08:01:49.050353
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('name', 1, 'classname', 'status', 1.0)
    test_case.errors = [TestError('output', 'message', 'type')]
    test_case.failures = [TestFailure('output', 'message', 'type')]
    test_case.skipped = 'skipped'
    test_case.system_out = 'system.out'
    test_case.system_err = 'system.err'


# Generated at 2022-06-21 08:01:57.048306
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    testsuite = TestSuite(name='test_name')
    assert testsuite.get_attributes() == {'name': 'test_name'}
    testsuite.name = 'test_name_new'
    assert testsuite.get_attributes() == {'name': 'test_name_new'}
    testsuite.hostname = 'test_hostname'
    assert testsuite.get_attributes() == {'name': 'test_name_new', 'hostname': 'test_hostname'}
    testsuite.package = 'test_package'
    assert testsuite.get_attributes() == {'name': 'test_name_new', 'hostname': 'test_hostname', 'package': 'test_package'}

# Generated at 2022-06-21 08:02:04.031472
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    test_case1 = TestCase(name='test_case1')
    test_case2 = TestCase(name='test_case2')
    test_suite = TestSuite(name='test_suite', cases=[test_case1, test_case2])
    assert repr(test_suite) == "<TestSuite 'test_suite': [TestCase('test_case1'), TestCase('test_case2')]>"


# Generated at 2022-06-21 08:02:07.660568
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    obj = TestError(message='message', type='type')
    expected_result = {'message': 'message', 'type': 'type'}
    assert expected_result == obj.get_attributes()


# Generated at 2022-06-21 08:02:17.507918
# Unit test for method __eq__ of class TestSuite

# Generated at 2022-06-21 08:02:29.201615
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    """
    # Test 1
    # function : test_TestSuites_get_attributes
    # method   : get_attributes
    # class    : TestSuites
    # Test to see if output dictionary is equal to expected one
    """
    actual_output = _attributes(disabled="disabled",
        errors="errors",
        failures="failures",
        name="name",
        tests="tests",
        time="time"
    )

    expected_output = {
        "disabled":"disabled",
        "errors":"errors",
        "failures":"failures",
        "name":"name",
        "tests":"tests",
        "time":"time"
    }

    assert actual_output == expected_output


# Generated at 2022-06-21 08:02:46.181956
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase(name="TestCase")
    assert(str(test_case) == "<TestCase name='TestCase'>")
    test_case.assertions = 1
    assert(str(test_case) == "<TestCase assertions='1' name='TestCase'>")
    test_case.time = decimal.Decimal(2)
    assert(str(test_case) == "<TestCase assertions='1' name='TestCase' time='2.0'>")
    test_case.skipped = 'Skipped'
    assert(str(test_case) == "<TestCase assertions='1' name='TestCase' skipped='Skipped' time='2.0'>")
    test_case.errors.append(TestError())

# Generated at 2022-06-21 08:02:54.312614
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    """Test that __eq__ method works correctly for TestFailure class."""
    # Create 2 test failure objects with the same attributes
    test_failure1 = TestFailure(
        output='output',
        message='message',
        type='type'
    )
    test_failure2 = TestFailure(
        output='output',
        message='message',
        type='type'
    )

    assert test_failure1.__eq__(test_failure2)


# Generated at 2022-06-21 08:02:56.692519
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    instance = TestCase(name="This is a test case")
    assert repr(instance) == "TestCase(name='This is a test case')"

# Generated at 2022-06-21 08:03:08.906007
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite(
        name='test_suite',
        id=1,
        hostname='localhost',
        timestamp=datetime.datetime.now(),
        package='test_package',
        tests=1,
        failures=0,
        disabled=0,
        errors=0,
        skipped=0,
        time=1,
    )
    xml_attr = {
        'id': '1',
        'name': 'test_suite',
        'package': 'test_package',
        'tests': '1',
        'failures': '0',
        'disabled': '0',
        'errors': '0',
        'skipped': '0',
        'time': '1',
    }
    assert suite.get_attributes() == xml_attr


# Generated at 2022-06-21 08:03:18.097329
# Unit test for method get_attributes of class TestSuite

# Generated at 2022-06-21 08:03:19.522055
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert TestFailure(output='stdout', message='test message', type='Error')

# Generated at 2022-06-21 08:03:24.316089
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    # Arrange
    class TestResultExtended(TestResult):
        tag = 'tag'

    testResultExtended = TestResultExtended()

    # Act
    testResultExtended.__post_init__()

    # Assert
    assert testResultExtended.type == 'tag'



# Generated at 2022-06-21 08:03:29.101845
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite('TestSuite1', timestamp=datetime.datetime.now())
    assert test_suite.get_attributes() == {'name': 'TestSuite1', 'timestamp': test_suite.timestamp.isoformat(timespec='seconds')}



# Generated at 2022-06-21 08:03:39.778394
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_name',
        assertions=1,
        classname='test_class',
        status='test_status',
        time=decimal.Decimal('1.23'),
        errors=[TestError(output='test_output', message='test_message', type='test_type')],
        failures=[TestFailure(output='test_output1', message='test_message1', type='test_type1')],
        skipped='skipped',
        system_out='system_out',
        system_err='system_err',
    )

    root = test_case.get_xml_element()
    assert root.tag == 'testcase'
    assert root.get('assertions') == '1'
    assert root.get('classname') == 'test_class'
    assert root.get

# Generated at 2022-06-21 08:03:49.427411
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test_suite_1 = TestSuite(name="suite 1", hostname="hostname 1", id="id 1", package="package 1", timestamp=datetime.datetime(2020, 4, 11, 15, 58, 31), properties=dict(), cases=[], system_out="", system_err="")
    test_suite_2 = TestSuite(name="suite 1", hostname="hostname 1", id="id 1", package="package 1", timestamp=datetime.datetime(2020, 4, 11, 15, 58, 31), properties=dict(), cases=[], system_out="", system_err="")
    assert test_suite_1 == test_suite_2, "Should be true"


# Generated at 2022-06-21 08:04:00.504627
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    t.assertEqual(repr(TestError()), 'TestError(output=None, type=None)')


# Generated at 2022-06-21 08:04:06.007352
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    test_output = "test_output"
    test_message = "test_message"
    test_type = "test_type"

    obj_A = TestFailure(output=test_output, message=test_message, type=test_type)
    obj_B = TestFailure(output=test_output, message=test_message, type=test_type)

    assert obj_A == obj_B, "TestFailure method __eq__ failed"


# Generated at 2022-06-21 08:04:07.343838
# Unit test for constructor of class TestResult
def test_TestResult():
    assert TestResult(
        output="output",
        message="message",
        type="type"
    )


# Generated at 2022-06-21 08:04:16.348703
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult()
    xml_element = test_result.get_xml_element()
    assert xml_element.tag == 'testresult'
    assert xml_element.attrib == {}
    assert xml_element.text == None

    test_result = TestResult(type='value', message='message', output='output')
    xml_element = test_result.get_xml_element()
    assert xml_element.tag == 'testresult'
    assert xml_element.attrib == {'type': 'value', 'message': 'message'}
    assert xml_element.text == 'output'



# Generated at 2022-06-21 08:04:23.760295
# Unit test for constructor of class TestFailure
def test_TestFailure():
    test_failure = TestFailure(output='This is an err')
    assert test_failure.tag == 'failure'
    assert test_failure.output == 'This is an err'
    assert test_failure.get_xml_element().tag == 'failure'
    assert test_failure.get_xml_element().text == 'This is an err'


# Generated at 2022-06-21 08:04:25.949133
# Unit test for constructor of class TestSuites
def test_TestSuites():
    testSuites = TestSuites(name='testSuites')
    assert testSuites.name == 'testSuites'


# Generated at 2022-06-21 08:04:29.088717
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert repr(TestFailure('output', 'message', 'type')) == "TestFailure(output='output', message='message', type='type')"



# Generated at 2022-06-21 08:04:38.542808
# Unit test for constructor of class TestResult
def test_TestResult():
    tr = TestResult()
    assert tr.output == None
    assert tr.message == None
    assert tr.type == None
    tr = TestResult(output = 'a')
    assert tr.output == 'a'
    assert tr.message == None
    assert tr.type == None
    tr = TestResult(message = 'a')
    assert tr.output == None
    assert tr.message == 'a'
    assert tr.type == None
    tr = TestResult(type = 'a')
    assert tr.output == None
    assert tr.message == None
    assert tr.type == 'a'


# Generated at 2022-06-21 08:04:43.183077
# Unit test for constructor of class TestResult
def test_TestResult():
    output = "Output of this test"
    type = "Type of this test"
    message = "Message of this test"

    test = TestResult(output, message, type)
    assert test.output == output
    assert test.message == message
    assert test.type == type


# Generated at 2022-06-21 08:04:54.153783
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite = TestSuite(
            name='testsuite_name',
            timestamp=datetime.datetime.now(),
            hostname='testsuite_hostname',
            package='testsuite_package')

    testcase = TestCase(
            name='testcase_name',
            classname='testcase_classname',
            time=decimal.Decimal(1.0))

    error = TestError(
            message='error_message',
            output='error_output')

    testcase.errors.append(error)
    testsuite.cases.append(testcase)

    xml = ET.tostring(testsuite.get_xml_element(), encoding='unicode').replace('xmlns="http://maven.apache.org/POM/4.0.0"', '')

# Generated at 2022-06-21 08:05:02.456716
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_TestFailure = TestFailure("Failure message" , "Failure output")
    assert test_TestFailure.__repr__() == f'TestFailure("Failure message" , "Failure output")'


# Generated at 2022-06-21 08:05:11.520488
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Test with data
    result_obj = TestFailure(
        message='This is a message',
        output='This is the output',
        type='This is the type')
    xml_element = result_obj.get_xml_element()
    assert xml_element.tag == 'failure'
    assert xml_element.text == 'This is the output'
    assert xml_element.attrib == {
        'message': 'This is a message',
        'type': 'This is the type'
    }

    # Test without data
    result_obj = TestFailure()
    xml_element = result_obj.get_xml_element()
    assert xml_element.tag == 'failure'
    assert xml_element.text == ''
    assert xml_element.attrib == {
    }



# Generated at 2022-06-21 08:05:23.978848
# Unit test for method __repr__ of class TestSuites

# Generated at 2022-06-21 08:05:28.280357
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    type = 'info'
    message = 'hello'
    tr = TestResult(type = type, message = message)
    assert tr.type == type
    tr = TestResult(message = message)
    assert tr.type == tr.tag


# Generated at 2022-06-21 08:05:36.963466
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    suite1 = TestSuite(name="suite1")
    suite2 = TestSuite(name="suite2")
    suite3 = TestSuite(name="suite3")

    suites1 = TestSuites(name="suites1",suites=[suite1, suite2])
    suites2 = TestSuites(name="suites2",suites=[suite1, suite2])
    suites3 = TestSuites(name="suites3",suites=[suite1, suite3])
    suites4 = TestSuites(name="suites4",suites=[suite3, suite2])
    suites5 = TestSuites(name="suites5",suites=[suite1, suite2, suite3])
    suites6 = TestSuites(name="suites6",suites=[suite1, suite2])
   

# Generated at 2022-06-21 08:05:42.274891
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    test_data = TestError(output = "The test has failed", message = "Test error message", type = "java.lang.Exception")
    expected = TestError(output = "The test has failed", message = "Test error message", type = "java.lang.Exception")
    assert test_data == expected


# Generated at 2022-06-21 08:05:46.417906
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    t1 = TestFailure(output='test', message='test', type='test')
    t2 = TestFailure(output='test', message='test', type='test')

    assert t1 == t2
    assert t2 == t1


# Generated at 2022-06-21 08:05:47.884668
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure() == TestFailure()


# Generated at 2022-06-21 08:05:57.990592
# Unit test for constructor of class TestResult
def test_TestResult():
    testResult = TestResult()
    assert testResult.output is None
    assert testResult.message is None
    assert testResult.type is None

    testResult = TestResult(output='')
    assert testResult.output == ''
    assert testResult.message is None
    assert testResult.type is None

    testResult = TestResult(output='', message='')
    assert testResult.output == ''
    assert testResult.message == ''
    assert testResult.type is None

    testResult = TestResult(output='', message='', type='')
    assert testResult.output == ''
    assert testResult.message == ''
    assert testResult.type == ''


# Generated at 2022-06-21 08:06:02.428677
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
	failure = TestFailure(output='output')
	assert failure == TestFailure(output='output')
	assert failure != TestFailure(output='other')

	error = TestError(output='output')
	assert error == TestError(output='output')
	assert error != TestError(output='other')


# Generated at 2022-06-21 08:06:10.379460
# Unit test for constructor of class TestSuites
def test_TestSuites():
    ts = TestSuites()
    assert ts.name is None
    assert ts.suites == []
    assert ts.disabled == 0
    assert ts.errors == 0
    assert ts.failures == 0
    assert ts.tests == 0
    assert ts.time == 0



# Generated at 2022-06-21 08:06:12.974831
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    value = "TestSuite(name='test', id='1')"
    obj = TestSuite(name='test', id='1')
    assert repr(obj) == value


# Generated at 2022-06-21 08:06:15.378028
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError("Error Message")
    assert error.message == "Error Message"
    assert error.type == "error"


# Generated at 2022-06-21 08:06:25.209054
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    tc = TestCase(
        name="Test 1",
        assertions=3,
        classname="Test Case Example 1",
        status="passed",
        time=1
    )
    actual = tc.get_attributes()
    expected = {
        'assertions': '3',
        'classname': 'Test Case Example 1',
        'name': 'Test 1',
        'status': 'passed',
        'time': '1'
    }
    assert actual == expected, f"Error in get_attributes() of TestCase, expected {expected} but got {actual}"


# Generated at 2022-06-21 08:06:26.269595
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    assert TestResult() == TestResult()


# Generated at 2022-06-21 08:06:36.217004
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-21 08:06:48.465426
# Unit test for constructor of class TestSuite
def test_TestSuite():
    suite = TestSuite(name='TestSuite1')
    assert suite.name == 'TestSuite1'

    # Unit test for method get_attributes() of class TestSuite
    def test_TestSuite_get_attributes():
        suite1 = TestSuite(name='TestSuite1')
        assert suite1.get_attributes() == {'name': 'TestSuite1'}

        suite2 = TestSuite(name='TestSuite2', hostname='TestHost', id='TestID', package='TestPackage',
                           timestamp=datetime.datetime.strptime('2019-04-01T12:00:00', '%Y-%m-%dT%H:%M:%S'))

# Generated at 2022-06-21 08:06:54.742671
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result_no_message = TestResult()
    assert not test_result_no_message.message
    assert test_result_no_message.get_xml_element().get('message')

    test_result_with_message = TestResult(message='test message')
    assert test_result_with_message.message
    assert test_result_with_message.get_xml_element().get('message') == 'test message'


# Generated at 2022-06-21 08:06:59.535297
# Unit test for constructor of class TestCase
def test_TestCase():
    testcase = TestCase(name='test_test')
    assert testcase.name == 'test_test'
    assert testcase.classname is None
    assert testcase.status is None
    assert testcase.time is None



# Generated at 2022-06-21 08:07:10.347238
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-21 08:07:25.092150
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    expected = '<testsuite disabled="0" errors="0" failures="0" hostname="localhost" id="0" name="suite" package="package" skipped="0" tests="1" time="0.01" timestamp="2020-03-01T12:00:00"><properties><property name="prop1" value="value1"/><property name="prop2" value="value2"/></properties><testcase assertions="1" classname="class" name="case" status="PASS" time="0.01"><failure message="Failure Message" type="FailureType">Failure Output</failure><error message="Error Message" type="ErrorType">Error Output</error></testcase><system-out>System Out Info</system-out><system-err>System Err Info</system-err></testsuite>'

# Generated at 2022-06-21 08:07:28.592445
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    sut = TestError("error_a", "message_a", "type_a")
    other = TestError("error_a", "message_a", "type_a")
    assert(sut == other)


# Generated at 2022-06-21 08:07:30.257458
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    TestResult.__repr__(TestResult)


# Generated at 2022-06-21 08:07:33.404571
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
  ts=TestSuites(name="name",suites=[TestSuite(name="suite_name")])
  ts2=TestSuites(name="name",suites=[TestSuite(name="suite_name")])
  assert ts==ts2


# Generated at 2022-06-21 08:07:41.815702
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    """Test method get_attributes of TestSuites class."""
    result = _attributes(
        disabled=100,
        errors=200,
        failures=300,
        name='Test Suites',
        tests=400,
        time=500)
    expected = {'disabled': '100', 'errors': '200', 'failures': '300',\
                'name': 'Test Suites', 'tests': '400', 'time': '500'}
    assert result == expected


# Generated at 2022-06-21 08:07:51.529695
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    def test_missing_value(original_value):
        ts = TestSuite(
            name='foo',
            disabled=original_value,
            errors=original_value,
            failures=original_value,
            hostname=original_value,
            id=original_value,
            package=original_value,
            skipped=original_value,
            tests=original_value,
            time=original_value,
            timestamp=original_value,
        )
        attrs = ts.get_attributes()

        assert original_value is not None or 'disabled' not in attrs
        assert original_value is not None or 'errors' not in attrs
        assert original_value is not None or 'failures' not in attrs
        assert original_value is not None or 'hostname' not in attrs

# Generated at 2022-06-21 08:07:52.676120
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    assert TestFailure().get_xml_element().tag == 'failure'


# Generated at 2022-06-21 08:07:55.711248
# Unit test for constructor of class TestSuite
def test_TestSuite():
    import datetime 
    test_suite = TestSuite(name='TestSuiteDemo', 
        hostname='host1', 
        id='ID1', 
        package='Package1', 
        timestamp=datetime.datetime.now())
    print(test_suite)


# Generated at 2022-06-21 08:08:01.438512
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    suite = TestSuite('test')
    suite.cases.append(TestCase('testcase1'))
    suites = TestSuites('suites')
    suites.suites.append(suite)
    assert repr(suites) == 'TestSuites(name=suites, suites=[TestSuite(name=test, cases=[TestCase(name=testcase1)])])'

# Generated at 2022-06-21 08:08:04.846115
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite(name="test_suite")
    assert test_suite.get_attributes() == _attributes(name="test_suite")



# Generated at 2022-06-21 08:08:13.396619
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite1 = TestSuite(name='tests')
    suite2 = TestSuite(name='tests')
    assert suite1 == suite2

    suite3 = TestSuite(name='tests3')
    assert suite1 != suite3



# Generated at 2022-06-21 08:08:15.422974
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    test_result = TestResult()
    assert "TestResult(output=None, message=None, type=None)" == repr(test_result)


# Generated at 2022-06-21 08:08:19.110937
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    dataclass = TestSuites()
    repr = dataclass.__repr__()
    assert repr == "TestSuites(name=None, suites=[])"
    

# Generated at 2022-06-21 08:08:29.607036
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # happy-path cases
    assert TestFailure().get_xml_element() is not None
    assert TestError().get_xml_element() is not None

    # sad-path cases
    # no attributes
    assert TestFailure(None, "No attributes").get_xml_element() is not None
    # only message attribute
    assert TestFailure('Only message', 'Only message').get_xml_element() is not None
    # only type attribute
    assert TestFailure(None, 'Only type', 'Only type').get_xml_element() is not None
    # only output attribute
    assert TestFailure('Only output').get_xml_element() is not None
    # message and type attributes
    assert TestFailure('Message and type', 'Message and type', 'Message and type').get_xml_element() is not None
    # message and output attributes
    assert Test

# Generated at 2022-06-21 08:08:33.361205
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    # "get_attributes of TestSuites"
    result = TestSuites(name="test_name")
    assert result.get_attributes() == {'name': 'test_name'}


# Generated at 2022-06-21 08:08:39.131248
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase('test_case', assertions=1, classname='TestCase', status='status', time=1.1)
    expected_attributes = {'assertions': '1', 'classname': 'TestCase', 'name': 'test_case', 'status': 'status', 'time': '1.1'}
    assert test_case.get_attributes() == expected_attributes


# Generated at 2022-06-21 08:08:50.038599
# Unit test for constructor of class TestSuite
def test_TestSuite():
    t1=TestCase(name='aaa')
    p={'a':'b'}
    t2=TestSuite(name='aaa',hostname='bbb',id='ccc',package='ddd',timestamp=datetime.datetime.utcnow(),properties=p,cases=p,system_out='aaa',system_err='aaa')
    assert t2.name == 'aaa'
    assert t2.hostname == 'bbb'
    assert t2.id == 'ccc'
    assert t2.package == 'ddd'
    assert t2.timestamp == datetime.datetime.utcnow()
    assert t2.properties == p
    assert t2.cases == p
    assert t2.system_out == 'aaa'
    assert t2.system_err == 'aaa'

# Unit

# Generated at 2022-06-21 08:08:55.148837
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    result_one = TestError(output="output_one",
                           message="message_one",
                           type="type_one")
    
    result_two = TestError(output="output_one",
                           message="message_one",
                           type="type_one")
    assert result_one == result_two



# Generated at 2022-06-21 08:08:56.803123
# Unit test for constructor of class TestError
def test_TestError():
    testError1 = TestError()
    assert testError1.type == "error"



# Generated at 2022-06-21 08:08:59.563841
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    error = TestError(output='output', message='message')
    assert error.__repr__() == "TestError(output='output', message='message', type='error')"

# Generated at 2022-06-21 08:09:12.398877
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    r = TestResult()
    a = r.get_attributes()
    assert a == {'type': r.tag}

    r = TestResult('output', 'message')
    a = r.get_attributes()
    assert a == {'type': r.tag, 'message': 'message'}

    r = TestResult('output', 'message', 'type')
    a = r.get_attributes()
    assert a == {'type': 'type', 'message': 'message'}


# Generated at 2022-06-21 08:09:20.312781
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    """
    Assert that :meth:`lib.dataclasses.TestCase.__eq__` is implemented correctly.
    """
    tc1 = TestCase('Test Case Name',classname='Test Case Class', assertions = 1, status = "Success",time =1.0) 
    tc2 = TestCase('Test Case Name',classname='Test Case Class', assertions = 1, status = "Success",time =1.0)
    tc3 = TestCase('Test Case Name',classname='Test Case Class', assertions = 1, status = "Success",time =2.0)

    assert tc1 == tc2
    assert tc1 != tc3


# Generated at 2022-06-21 08:09:21.152458
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert repr(TestSuites()) == 'TestSuites(name=None, suites=[])'



# Generated at 2022-06-21 08:09:29.784793
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    assert (TestCase(name="test_case")).get_xml_element()==ET.Element("testcase", {"name":"test_case"})
    assert (TestCase(name="test_case", assertions=1)).get_xml_element()==ET.Element("testcase", {"name":"test_case", "assertions":'1'})
    assert (TestCase(name="test_case", time=decimal.Decimal(1.0))).get_xml_element()==ET.Element("testcase", {"name":"test_case", "time":'1.0'})
    assert (TestCase(name="test_case", classname="classname")).get_xml_element()==ET.Element("testcase", {"name":"test_case", "classname":"classname"})

# Generated at 2022-06-21 08:09:36.633270
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite = TestSuite(name='test tp', hostname='localhost', id='0', package='tp1', timestamp=datetime.datetime.now())
    xml = testSuite.get_xml_element()
    xml2 = ET.fromstring(open('xmltest.xml', 'r').read())

    assert(ET.tostring(xml, 'unicode') == ET.tostring(xml2, 'unicode'))


test_TestSuite_get_xml_element()

# Generated at 2022-06-21 08:09:41.950364
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Unit test for method get_xml_element of class TestResult."""
    result = TestResult(message="msg", type="type", output="output")
    assert result.get_xml_element().attrib == {'message': 'msg', 'type': 'type'}
    assert result.get_xml_element().text == "output"

# Generated at 2022-06-21 08:09:42.543454
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    TestResult()

# Generated at 2022-06-21 08:09:46.868200
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    case = TestCase(name='test_name', assertions=0, classname='class_name', status='status', time=0)
    assert case.get_attributes() == {'name': 'test_name',
                                     'assertions': '0',
                                     'classname': 'class_name',
                                     'status': 'status',
                                     'time': '0'}


# Generated at 2022-06-21 08:09:48.421900
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert _attributes(output = 'some output') == {'output':'some output'}


# Generated at 2022-06-21 08:09:54.520298
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
  # Test 1
  assert _attributes(foo=None,bar=1,baz=2,quux=None)=={'bar':'1','baz':'2'}
  # Test 2
  assert _attributes(foo=None,bar=None,baz=None,quux=None)=={}
  # Test 3
  assert _attributes(foo=1,bar=1,baz=2,quux=None)=={'foo':'1','bar':'1','baz':'2'}


# Generated at 2022-06-21 08:10:01.414947
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert repr(TestSuites()) == '<TestSuites(name=None, suites=[])>'

# Generated at 2022-06-21 08:10:07.939857
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError(output="Output", message="Message", type="Type") == TestError(output="Output", message="Message", type="Type")
    assert TestError(output="Output", message="Message", type="Type") != TestError(output="Output", message="Message", type="Type1")
    assert TestError(output="Output", message="Message", type="Type") != TestError(output="Output", message="Message1", type="Type")
    assert TestError(output="Output", message="Message", type="Type") != TestError(output="Output1", message="Message", type="Type")


# Generated at 2022-06-21 08:10:10.307798
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    # create an instance of class TestResult
    testresult = TestResult(None, None)
    # compare values of class attributes
    assert testresult.type == 'result'


# Generated at 2022-06-21 08:10:11.674102
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    e1 = TestError()
    e2 = TestError()
    assert e1 == e2



# Generated at 2022-06-21 08:10:13.291797
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    tf = TestFailure()
    assert tf.__repr__() is not None


# Generated at 2022-06-21 08:10:18.170802
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # test the repr() method of the class
    test_suites = TestSuites(name='test')
    assert repr(test_suites) == 'TestSuites(name=test, suites=[])'



# Generated at 2022-06-21 08:10:24.179919
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    t = TestSuite("name", hostname="hostname", id="id", package="package", timestamp=datetime.datetime.now())
    d = t.get_attributes()
    print(d)
    assert d == {'hostname': 'hostname', 'id': 'id', 'name': 'name', 'package': 'package', 'timestamp': t.timestamp.isoformat(timespec='seconds')}


# Generated at 2022-06-21 08:10:30.503680
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    test_cases = [TestCase('test1'), TestCase('test2')]
    test_case = TestSuite('suite', name='name', hostname='hostname', timestamp=datetime.datetime(2800, 1, 1), cases=test_cases)
    expected = 'TestSuite(name=\'suite\', hostname=\'hostname\', timestamp=datetime.datetime(2800, 1, 1, 0, 0), cases=[TestCase(name=\'test1\'), TestCase(name=\'test2\')])'

    assert test_case.__repr__() == expected



# Generated at 2022-06-21 08:10:36.464137
# Unit test for constructor of class TestFailure
def test_TestFailure():
    #Test case 1
    expected_result1 = TestFailure(output=None, message=None, type=None)
    assert expected_result1.__post_init__()== None
    #Test case 2
    expected_result2 = TestFailure(output= 'test_output', message='test_message', type='test_type')
    assert expected_result2.__post_init__()== 'test_type'
    

# Generated at 2022-06-21 08:10:43.739126
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    assert TestCase('TestCase_1').get_attributes() == {'name': 'TestCase_1'}
    assert TestCase('TestCase_1', '1.2').get_attributes() == {'name': 'TestCase_1', 'time': '1.2'}
    assert TestCase('TestCase_1', '1.2', 'TestCase').get_attributes() == {'name': 'TestCase_1', 'time': '1.2', 'classname': 'TestCase'}


# Generated at 2022-06-21 08:11:00.033222
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():

    assert len(t.get_type_hints(TestSuite)) == len({'name': str, 'hostname': t.Optional[str], 'id': t.Optional[str], 'package': t.Optional[str], 'timestamp': t.Optional[datetime.datetime], 'properties': t.Dict[str, str], 'cases': t.List[TestCase], 'system_out': t.Optional[str], 'system_err': t.Optional[str]})

    assert TestSuite(name="test", hostname="none", id="1", package="nl.amis.test", timestamp=datetime.datetime.now()) == TestSuite(name="test", hostname="none", id="1", package="nl.amis.test", timestamp=datetime.datetime.now())

# Generated at 2022-06-21 08:11:02.592157
# Unit test for constructor of class TestSuite
def test_TestSuite():
    testSuite = TestSuite("TestSuite")
    assert testSuite.name=="TestSuite"


# Generated at 2022-06-21 08:11:05.125987
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    expected_1 ='TestSuites(name=None, suites=[])'
    actual_1 = repr(TestSuites())
    assert actual_1 == expected_1

# Generated at 2022-06-21 08:11:15.346473
# Unit test for method to_pretty_xml of class TestSuites