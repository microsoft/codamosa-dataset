

# Generated at 2022-06-21 08:01:34.901397
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():

    testcase1_name = 'testcase1_name'
    testcase1_classname = 'testcase1_classname'
    testcase1_status = 'testcase1_status'
    testcase1_time = decimal.Decimal(1.11)

    testcase2_name = 'testcase2_name'
    testcase2_classname = 'testcase2_classname'
    testcase2_status = 'testcase2_status'
    testcase2_time = decimal.Decimal(2.22)

    testcase1 = TestCase(name=testcase1_name, classname=testcase1_classname, status=testcase1_status, time=testcase1_time)

# Generated at 2022-06-21 08:01:43.866790
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():

    obj = TestSuites()
    assert obj.get_attributes() == {}

    obj = TestSuites(disabled=1)
    assert obj.get_attributes() == {'disabled': '1'}

    obj = TestSuites(disabled=1, errors=2, failures=3, name="test name", tests=4, time=5)
    assert obj.get_attributes() == {'disabled': '1', 'errors': '2', 'failures': '3', 'name': 'test name', 'tests': '4', 'time': '5'}


# Generated at 2022-06-21 08:01:47.189386
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    res = TestResult(None, None, None)
    attr = res.get_attributes()
    assert attr['type'] == res.tag


# Generated at 2022-06-21 08:01:50.073175
# Unit test for constructor of class TestFailure
def test_TestFailure():
    TC = TestFailure(
        output='error message'
    )
    assert TC.output == 'error message'
    assert TC.tag == 'failure'


# Generated at 2022-06-21 08:01:52.143380
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    instance = TestFailure()
    assert repr(instance) == "TestFailure(output=None, message=None, type='failure')"


# Generated at 2022-06-21 08:01:52.915570
# Unit test for constructor of class TestError
def test_TestError():
    error=TestError("Error")
    print(error)

# Generated at 2022-06-21 08:01:53.864067
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    TestSuite('test')

# Generated at 2022-06-21 08:01:58.739527
# Unit test for constructor of class TestSuites
def test_TestSuites():
    testsuites = TestSuites()

    assert len(testsuites.suites) == 0
    assert testsuites.disabled == 0
    assert testsuites.errors == 0
    assert testsuites.failures == 0
    assert testsuites.tests == 0
    assert testsuites.time == 0


# Generated at 2022-06-21 08:02:03.504770
# Unit test for constructor of class TestResult
def test_TestResult():
    tc1 = TestResult(['hello'])
    assert tc1.output == ['hello']
    assert tc1.type == 'test_result'
    # type check
    with pytest.raises(TypeError):
        TestResult([1, 2, 3])


# Generated at 2022-06-21 08:02:04.673676
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError() == TestError()


# Generated at 2022-06-21 08:02:15.149473
# Unit test for constructor of class TestSuites
def test_TestSuites():
    # Create a new test suites
    test_suites = TestSuites(
        suites=[],
        name="test name"
    )
    assert test_suites.name == "test name"
    assert test_suites.suites == []

    # Create a new test suites
    test_suites = TestSuites(
        suites=[],
        name=None
    )
    assert test_suites.name is None
    assert test_suites.suites == []



# Generated at 2022-06-21 08:02:18.933918
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Test for TestResult.get_xml_element
    test_result = TestResult('This is an error', None, None)
    test_result_element = test_result.get_xml_element()
    assert test_result_element.tag == 'testresult'
    assert test_result_element.attrib == {}
    assert test_result_element.text == 'This is an error'



# Generated at 2022-06-21 08:02:24.599544
# Unit test for constructor of class TestResult
def test_TestResult():
    test_result = TestResult(output="Something went wrong", message="This is a message", type="Error")
    assert (test_result.output == "Something went wrong" and test_result.message == "This is a message" and test_result.tag == "testresult" and test_result.type == "Error")


# Generated at 2022-06-21 08:02:30.753919
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert repr([
        TestError('output1'),
        TestError('output2', type='type1'),
        TestError('output3', type='type2', message='message1'),
    ]) == "[TestError(output='output1', message=None, type='error'), TestError(output='output2', message=None, type='type1'), TestError(output='output3', message='message1', type='type2')]"


# Generated at 2022-06-21 08:02:33.691680
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    testcase_1 = TestCase("test1")
    testcase_2 = TestCase("test1")
    assert testcase_1 == testcase_2
    testcase_2.name = "test2"
    assert testcase_1 != testcase_2


# Generated at 2022-06-21 08:02:36.192355
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    instance = TestResult()
    assert isinstance(instance.__repr__(), str)


# Generated at 2022-06-21 08:02:38.630168
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    assert TestSuite(name='TestSuite') == TestSuite(name='TestSuite')


# Generated at 2022-06-21 08:02:43.248678
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    assert repr(TestCase('name')) == 'TestCase(name=name, assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'


# Generated at 2022-06-21 08:02:45.481200
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    case = TestFailure()
    assert case.type == 'failure'
    case = TestError()
    assert case.type == 'error'

# Generated at 2022-06-21 08:02:48.621208
# Unit test for constructor of class TestResult
def test_TestResult():
    with pytest.raises(NotImplementedError):
        TestResult().tag



# Generated at 2022-06-21 08:03:01.233334
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Test with all optional arguments
    test_result_with_all_optional_arguments = TestResult(output="Example of output",
                                                         message="Example of message",
                                                         type="Example of type")
    assert test_result_with_all_optional_arguments.get_attributes() == {'message': 'Example of message',
                                                                        'type': 'Example of type'}
    # Test without optional arguments
    test_result_without_optional_arguments = TestResult()
    assert test_result_without_optional_arguments.get_attributes() == {}


# Generated at 2022-06-21 08:03:13.250318
# Unit test for method get_xml_element of class TestSuite

# Generated at 2022-06-21 08:03:15.118307
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    t = TestCase(name="TestCase1")
    print(ET.tostring(t.get_xml_element(), encoding='unicode'))


# Generated at 2022-06-21 08:03:15.999832
# Unit test for constructor of class TestError
def test_TestError():
    assert True


# Generated at 2022-06-21 08:03:23.136581
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    # Test with no values        
    attributes = {}
    testCase = TestCase(name="TestCase1")
    assert testCase.get_attributes() == attributes

    # Test with some values
    testCase.classname = "TestClass"
    testCase.time = decimal.Decimal(1.23)
    attributes = {
        "classname": "TestClass",
        "name": "TestCase1",
        "time": "1.23",
    }
    assert testCase.get_attributes() == attributes



# Generated at 2022-06-21 08:03:25.846281
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase('name')
    assert test_case.get_attributes() == _attributes(name='name')


# Generated at 2022-06-21 08:03:31.609003
# Unit test for constructor of class TestSuites
def test_TestSuites():
    test = TestSuites()
    test.suites.extend([TestSuite('history')])
    assert test.suites == [TestSuite('history')]

    test.suites.extend([TestSuite('events')])
    assert test.suites == [TestSuite('history'), TestSuite('events')]

# Generated at 2022-06-21 08:03:41.252463
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    failures=['fail1','fail2']
    errors=['error1','error2']
    test_result=TestResult(output="test_output")
    assert test_result.get_attributes()=={}
    test_result=TestResult(output="test_output",message="test_message")
    assert test_result.get_attributes()=={'message': 'test_message'}
    test_result=TestResult(output="test_output",type="test_type")
    assert test_result.get_attributes()=={'type': 'test_type'}
    test_result=TestResult(output="test_output",message="test_message",Type="test_type")
    assert test_result.get_attributes()=={'message': 'test_message', 'type': 'test_type'}



# Generated at 2022-06-21 08:03:44.221238
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    result1 = TestFailure("error1")
    result2 = TestFailure("error2")

    assert result1 == result1
    assert result1 != result2
    assert result1 != None           # noqa

# Generated at 2022-06-21 08:03:46.501391
# Unit test for constructor of class TestSuite
def test_TestSuite():
    t = TestSuite(name='test')
    assert t.name == 'test'


# Generated at 2022-06-21 08:03:59.705293
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    tc1 = TestCase(name="test_TestCase___eq__")
    tc2 = TestCase(name="test_TestCase___eq__")
    assert tc1 == tc2
    tc2.classname = "test_TestCase___eq__"
    assert tc1 != tc2    
    

# Generated at 2022-06-21 08:04:02.744354
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    one = TestFailure(output='output', message='message', type='failure')
    two = TestFailure(output='output', message='message', type='failure')
    assert one == one
    assert one == two


# Generated at 2022-06-21 08:04:10.618716
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Unit test for method to_pretty_xml of class TestSuites"""

    junit_cases = [
        TestCase(name='test_method_1'),
        TestCase(name='test_method_2'),
    ]

    junit_suite = TestSuite(
        name='TestSuite',
        hostname='localhost',
        id='testsuite_id',
        package='testpackage',
        timestamp=datetime.datetime.now(),
        properties={
            'testproperty_1': 'testvalue_1',
            'testproperty_2': 'testvalue_2',
        },
        cases=junit_cases,
        system_out='system_out',
        system_err='system_err',
    )


# Generated at 2022-06-21 08:04:13.696945
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    result = _attributes(a=None, b=2)
    expected = {'b': '2'}

    assert result == expected


# Generated at 2022-06-21 08:04:17.212447
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    """Unit test for method __eq__ of class TestCase."""
    assert TestCase('Test Case 1') != TestCase('Test Case 2')
    assert TestCase('Test Case') == TestCase('Test Case')


# Generated at 2022-06-21 08:04:20.323336
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    class TestTestResult(TestResult):
        tag = 'test_tag'
    test_result = TestTestResult()
    print(test_result.type)


# Generated at 2022-06-21 08:04:25.274457
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    e1 = TestError(message="message 1", output="output 1", type="Type")
    e2 = TestError(message="message 1", output="output 1", type="Type")
    assert e1 == e2

# Generated at 2022-06-21 08:04:31.379015
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    a_datetime = datetime.datetime(2019, 10, 10, 15, 5)
    a_TestCase = TestCase('a_TestCase_name')
    a_TestSuite = TestSuite('a_TestSuite_name', hostname='a_hostname', id='a_id', package='a_package', timestamp=a_datetime, cases=[a_TestCase], system_out='a_system_out')

# Generated at 2022-06-21 08:04:31.956415
# Unit test for constructor of class TestError
def test_TestError():
  err = TestError()
  assert err is not None

# Generated at 2022-06-21 08:04:41.370310
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case = TestCase(name='sample_case')
    assert case.get_xml_element() == ET.fromstring('<testcase name="sample_case"/>')

    case2 = TestCase(name='sample_case2', assertions=3, classname='sample_class', status='sample_status', time=1.0)
    assert case2.get_xml_element() == ET.fromstring('<testcase assertions="3" classname="sample_class" name="sample_case2" status="sample_status" time="1.0"/>')

    error = TestError(type='sample_type', output='sample_output')
    case3 = TestCase(name='sample_case3')
    case3.errors.append(error)

# Generated at 2022-06-21 08:04:56.908283
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    cases = [TestCase(name='my_function')]
    suite = TestSuite(name='my_module', cases=cases)
    suites = TestSuites(name='my_project', suites=[suite])

    assert suites.get_xml_element().attrib == {
        'name': 'my_project',
        'tests': '1',
        'disabled': '0',
        'errors': '0',
        'failures': '0',
        'time': '0'
    }
    assert suites.get_xml_element()[0].attrib == {
        'name': 'my_module',
        'tests': '1',
        'disabled': '0',
        'errors': '0',
        'failures': '0',
        'time': '0'
    }
    assert suites.get_

# Generated at 2022-06-21 08:04:59.232202
# Unit test for constructor of class TestResult
def test_TestResult():
    test_result = TestResult(type='type', message='message', output='output')
    assert test_result


# Generated at 2022-06-21 08:05:07.157737
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case1 = TestCase('decode_base64_string', assertions=2, classname='string_utils', status='passed',
                          time='0.02')
    expected_output = {'assertions': '2', 'name': 'decode_base64_string', 'status': 'passed', 'time': '0.02',
                       'classname': 'string_utils'}
    assert expected_output == test_case1.get_attributes()



# Generated at 2022-06-21 08:05:13.170395
# Unit test for constructor of class TestCase
def test_TestCase():
    try:
        # empty name
        testCase = TestCase("")
    except:
        print("TestCase constructor with empty name was successful !")

    try:
        # name="None"
        testCase = TestCase("None")
        print("TestCase constructor with name=\"None\" was successful !")
    except:
        print("TestCase constructor with name=\"None\" failed !")

    try:
        # name="test_TestCase"
        testCase = TestCase("test_TestCase")
        print("TestCase constructor with name=\"test_TestCase\" was successful !")
    except:
        print("TestCase constructor with name=\"test_TestCase\" failed !")

#test if adding a testcase is working

# Generated at 2022-06-21 08:05:24.833346
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:05:33.831892
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    suite1 = TestSuite(name='test', id=1, hostname='host', package="package", timestamp='2020-11-01T23:01:00')
    suite2 = TestSuite(name='test', id=1, hostname='host', package="package", timestamp='2020-11-01T23:01:00')
    suiten = TestSuite(name='test', id=1, hostname='host', package="package", timestamp='2020-11-01T23:02:00')
    assert suite1 == suite2
    assert suite2 == suite1
    assert not (suite1 == suiten)
    assert not (suiten == suite2)


# Generated at 2022-06-21 08:05:44.943449
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """Test case docstring."""

    # Setup
    suite = TestSuite(name='Pass', id='Pass', timestamp=datetime.datetime(year=2020, month=5, day=5, hour=11, minute=59, second=0))
    suite.cases.append(TestCase(name='Pass', assertions=1))
    suite.cases.append(TestCase(name='Fail', assertions=1, failures=[TestFailure(message='Fail', type='java.lang.AssertionError: Fail', output='java.lang.AssertionError: Fail')]))

    # Exercise
    xml = suite.get_xml_element()

    # Verify

# Generated at 2022-06-21 08:05:56.988190
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    cases = [
        TestCase(
            name='test1',
            assertions=2,
            classname='com.company.Test1',
            status='passed',
            time=decimal.Decimal('0.005'),
            failures=[
                TestFailure(
                    message='Something went wrong',
                    output='Exception',
                    type='Error',
                ),
            ],
        ),
    ]

# Generated at 2022-06-21 08:06:02.988157
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    error1 = TestError(message="test error 1")
    error2 = TestError(message="test error 2")
    error3 = TestError(message="test error 1")
    error4 = TestError(message="test error 1")
    # Check if method __eq__ works as intended
    assert error1 != error2
    assert error1 == error3
    assert error1 == error4


# Generated at 2022-06-21 08:06:04.305249
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    pass


# Generated at 2022-06-21 08:06:25.440960
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():

    test_suites = TestSuites(name="TestSuites")
    test_suite = TestSuite(hostname="localhost", name="TestSuite", timestamp=datetime.datetime(2020, 1, 7, 13, 34, 49))
    test_case = TestCase(name="TestCase", time=0.01)
    failure = TestFailure(output="Test failure", type="TestFailureType")
    test_case.failures.append(failure)
    test_suite.cases.append(test_case)
    test_suites.suites.append(test_suite)


# Generated at 2022-06-21 08:06:27.199284
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    ts1 = TestSuite(name='foo')
    ts2 = TestSuite(name='foo')
    ts3 = TestSuite(name='bar')
    assert(ts1 == ts2)
    assert(ts1 != ts3)


# Generated at 2022-06-21 08:06:30.537652
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    testcase = TestCase('name')
    assert testcase.__repr__() == "TestCase(name='name', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"


# Generated at 2022-06-21 08:06:32.688362
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    """Test the __repr__ method of TestSuites."""
    assert TestSuites.__repr__(TestSuites)

# Generated at 2022-06-21 08:06:35.449416
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    try:
        instance = TestResult('output', 'message', 'type')
    except Exception as err:
        assert False

    assert isinstance(instance.__repr__(), str)
test_TestResult___repr__()



# Generated at 2022-06-21 08:06:47.975696
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:06:52.147718
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    import datetime

    # Setup
    error = TestFailure(message='This is a message', type='This is a type')

    # Exercise and Verify
    assert repr(error) == "TestFailure(message='This is a message', type='This is a type')"


# Generated at 2022-06-21 08:06:54.141778
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    test_result = TestResult()
    assert test_result.__repr__() is not None


# Generated at 2022-06-21 08:07:00.571366
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    label_name = 'name'
    label_tests = 'tests'
    label_disabled = 'disabled'
    label_failures = 'failures'
    label_errors = 'errors'
    label_time = 'time'

    test_suites = TestSuites(name='All Tests')

    case_name = 'case1'
    test_case = TestCase(name=case_name)
    test_suites.suites.append(TestSuite(name='suite1', cases=[test_case]))

    element = test_suites.get_xml_element()
    assert element.get(label_name) == test_suites.name
    assert int(element.get(label_tests)) == test_suites.tests
    assert int(element.get(label_disabled)) == test_suites.disabled


# Generated at 2022-06-21 08:07:05.939714
# Unit test for constructor of class TestFailure
def test_TestFailure():
	assert TestFailure(output="Test output", message="Test message", type="Test type").output == "Test output"
	assert TestFailure(output="Test output", message="Test message", type="Test type").message == "Test message"
	assert TestFailure(output="Test output", message="Test message", type="Test type").type == "Test type"


# Generated at 2022-06-21 08:07:33.580936
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    # Input data
    suite_1 = TestSuite(
        name='suite-1',
        timestamp=datetime.datetime.fromisoformat('1901-01-01T00:00:00'),
    )
    suite_2 = TestSuite(
        name='suite-2',
        timestamp=datetime.datetime.fromisoformat('1901-01-01T00:00:00'),
    )
    test_suites_1 = TestSuites(
        name='test-suites-1',
    )
    test_suites_2 = TestSuites(
        name='test-suites-2',
    )
    test_suites_1.suites.append(suite_1)
    test_suites_2.suites.append(suite_2)

    # Expectations

# Generated at 2022-06-21 08:07:38.265113
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    ts = TestSuites()
    assert ts.get_attributes() == {'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '0', 'time': '0'}


# Generated at 2022-06-21 08:07:42.834764
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    testsuite1 = TestSuite(name="TestSuite1")
    testsuite2 = TestSuite(name="TestSuite2")
    assert testsuite1 == testsuite1
    assert testsuite1 != testsuite2
    assert testsuite1 != 1
    

# Generated at 2022-06-21 08:07:46.716597
# Unit test for constructor of class TestCase
def test_TestCase():
    test_case = TestCase('test_demo', 'demo_case')
    assert test_case.name == 'test_demo'
    assert test_case.classname == 'demo_case'
    assert test_case.assertions is None


# Generated at 2022-06-21 08:07:51.188557
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_cases = [TestCase('name')]
    for test_case in test_cases:
        expected = {'name': 'name'}
        actual = test_case.get_attributes()
        assert expected == actual, 'test_TestCase_get_attributes Failed'
    print('test_TestCase_get_attributes Passed')


# Generated at 2022-06-21 08:07:52.927046
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    err1 = TestError(message="fofo")
    err2 = TestError(message="fofo")
    assert err1 == err2



# Generated at 2022-06-21 08:07:54.592825
# Unit test for constructor of class TestResult
def test_TestResult():
    expected = 'test_output'
    result = TestResult(output = expected)
    assert result.output == expected



# Generated at 2022-06-21 08:07:58.972779
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test_suites = TestSuites(name='test')
    assert test_suites.get_attributes() == {
        'name': 'test',
        'disabled': '0',
        'errors': '0',
        'failures': '0',
        'tests': '0',
        'time': '0'
    }



# Generated at 2022-06-21 08:08:11.046465
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """
    Test the method to_pretty_xml of class TestSuites
    """
    # run test
    test_result = TestSuites(
        name="Name",
        suites=[TestSuite(
            name="TestSuite",
            hostname="hostname",
            id="id",
            package="package",
            timestamp=datetime.datetime.now(),
            properties={"a": "1", "b": "2"},
            cases=[TestCase(
                name="TestCase",
                assertions="assertions",
                classname="classname",
                status="status",
                time=decimal.Decimal(1),
                skipped="skipped",
            )],
            system_out="system_out",
            system_err="system_err",
        )]
    )

    # compare
    assert test_result

# Generated at 2022-06-21 08:08:11.724274
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    pass

# Generated at 2022-06-21 08:09:05.695386
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert TestFailure().output == None
    assert TestFailure().type == None
    assert TestFailure().message == None
    assert TestFailure(output="failure").output == "failure"
    assert TestFailure(output="failure").tag == "failure"
    assert TestFailure(type="testtype").type == "testtype"
    assert TestFailure(message="testmessage").message == "testmessage"
    assert TestFailure(output="failure", message="testmessage", type="testtype").output == "failure"
    assert TestFailure(output="failure", message="testmessage", type="testtype").message == "testmessage"
    assert TestFailure(output="failure", message="testmessage", type="testtype").type == "testtype"
    result = TestFailure(output="failure", message="testmessage", type="testtype")
   

# Generated at 2022-06-21 08:09:10.315336
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    output = "Dummy"
    message = "Dummy"
    testCase = TestError(output,message)
    assert testCase.__repr__() == "TestError(output='Dummy', message='Dummy')"


# Generated at 2022-06-21 08:09:12.677788
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    tests = TestSuites()
    assert tests.get_attributes() == {'tests': '0', 'name':'None'}


# Generated at 2022-06-21 08:09:13.327202
# Unit test for constructor of class TestError
def test_TestError():
    a = TestError()
    assert a is not None


# Generated at 2022-06-21 08:09:17.061520
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    tc1 = TestCase(name='test_case')
    tc2 = TestCase(name='test_case')
    assert tc1 == tc2
    tc1.name = 'test_case_other'
    assert tc1 != tc2


# Generated at 2022-06-21 08:09:19.766366
# Unit test for constructor of class TestResult
def test_TestResult():
	result = TestResult("output", "message", "type")
	
	assert result.output == "output"
	assert result.message == "message"
	assert result.type == "type"



# Generated at 2022-06-21 08:09:26.280906
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase()
    assert ET.tostring(test_case.get_xml_element()) == b'<testcase />'

    test_case = TestCase(name='foo_name')
    assert ET.tostring(test_case.get_xml_element()) == b'<testcase name="foo_name" />'

    test_case = TestCase(name='foo_name', assertions=123, classname='foo_class', status='foo_status', time=12.34)
    assert ET.tostring(test_case.get_xml_element()) == b'<testcase assertions="123" classname="foo_class" name="foo_name" status="foo_status" time="12.34" />'


# Generated at 2022-06-21 08:09:36.716638
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    # Test type
    assert TestFailure() == TestFailure()

    # Test equal class name
    assert TestFailure(type="test_case") == TestFailure(type="test_case")

    # Test different class name
    assert TestFailure(type="test") != TestFailure(type="test_case")
    assert TestFailure(type="test_case") != TestFailure(type="test")

    # Test equal class name, different output
    assert TestFailure(type="test_case", output="Output") == TestFailure(type="test_case", output="Output")

    # Test equal class name, different output
    assert TestFailure(type="test_case", output="Output") != TestFailure(type="test_case", output="")
    assert TestFailure(type="test_case", output="") != TestFailure(type="test_case", output="Output")



# Generated at 2022-06-21 08:09:39.941250
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    t = TestSuites("TestSuite")
    attributes = t.get_attributes()
    assert attributes["name"] == "TestSuite"



# Generated at 2022-06-21 08:09:40.761934
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    pass

# Generated at 2022-06-21 08:11:14.172158
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    classname = str()
    name = str()
    assertions = int()
    status = str()
    time = str()
    skipped = str()
    system_out = str()
    system_err = str()
    output = str()
    message = str()
    test_case = TestCase(classname, name, assertions, status, time, skipped, output, message, system_out, system_err)
    expected_output = '<testcase assertions="0" classname="" name=""><skipped>False</skipped><system-out></system-out><system-err></system-err></testcase>'
    output = ET.tostring(test_case.get_xml_element(), encoding='utf-8').decode('utf-8')
    assert output == expected_output
