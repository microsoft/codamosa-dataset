

# Generated at 2022-06-21 08:01:34.858549
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    name = "TestSuite"
    id = "id"
    timestamp = "timestamp"
    properties = {
        "property_1": "value_1",
        "property_2": "value_2"
    }
    cases = []
    cases.append(TestCase(
        name = "TestCase 1",
        assertions = 1,
        classname = "classname",
        status = "status",
        time = 0.001,
        skipped = "skipped",
        system_out = "system_out",
        system_err = "system_err"
    ))


# Generated at 2022-06-21 08:01:47.379091
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
	output1 = "output1"
	message1 = "message1"
	type1 = "type1"
	name1 = "name1"
	assertions1 = 1
	classname1 = "classname1"
	status1 = "status1"
	time1 = 1.0  
	errors1 = [TestError(output1, message1, type1)]
	failures1 = [TestFailure(output1, message1, type1)]
	skipped1 = "skipped1"
	system_out1 = "system_out1"
	system_err1 = "system_err1"
	is_disabled1 = False

	output2 = "output2"
	message2 = "message2"
	type2 = "type2"
	name2 = "name2"
	assertions2 = 2

# Generated at 2022-06-21 08:01:53.745763
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    ts = TestSuite(name='testsuite1', hostname=None, id=None, package=None, timestamp=None, properties=None, cases=None, system_out=None, system_err=None)
    assert ts.get_attributes() == _attributes(disabled=0, errors=0, failures=0, hostname=None, id=None, name='testsuite1', package=None, skipped=0, tests=0, time=0,timestamp=None)


# Generated at 2022-06-21 08:01:56.428221
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
  my_TestSuite=TestSuite("name")
  assert repr(my_TestSuite) == 'TestSuite(name=name)'


# Generated at 2022-06-21 08:02:03.858717
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    x = TestFailure
    x.output = "x"
    x.message = "x"
    x.type = "x"

    y = TestFailure
    y.output = "y"
    y.message = "y"
    y.type = "y"

    z = TestFailure
    z.output = "x"
    z.message = "x"
    z.type = "x"

    assert x == z
    assert not x == y


# Generated at 2022-06-21 08:02:14.968480
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    print('test_TestSuites_to_pretty_xml')
    import random
    
    testsuites = TestSuites(name = 'TestSuites')
    testsuite1 = TestSuite(name = 'TestSuite1')
    testcase1 = TestCase(name = 'TestCase1')
    testcase2 = TestCase(name = 'TestCase2')
    testcase3 = TestCase(name = 'TestCase3')
    testcase4 = TestCase(name = 'TestCase4')
    testcase5 = TestCase(name = 'TestCase5')
    testcase1.is_disabled = True
    testcase2.is_disabled = True
    testcase2.failures = [TestFailure(output = 'test', message = 'test', type = 'test')]

# Generated at 2022-06-21 08:02:28.069157
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    """Unit test for method get_attributes of class TestSuites."""
    print('Running unit test for method get_attributes of class TestSuites...')


# Generated at 2022-06-21 08:02:35.857335
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    # Setup
    test_case = TestCase(
        name='test_name',
        test_case_assertions=None,
        test_case_classname=None,
        test_case_status=None,
        test_case_time=None,
        test_case_errors=None,
        test_case_failures=None,
        test_case_skipped=None,
        test_case_system_out=None,
        test_case_system_err=None,
        test_case_is_disabled=False,
    )
    # Test

# Generated at 2022-06-21 08:02:40.569234
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    obj = TestSuite('test_name')
    assert repr(obj) == "TestSuite(name='test_name', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)"

# Generated at 2022-06-21 08:02:46.064052
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    xml = TestError(output="The test error message",
                    message="The test error message",
                    type="The error type").get_xml_element()
    print(xml)
    print(ET.tostring(xml))
    assert ET.tostring(xml) == b"<error message=\"The test error message\" type=\"The error type\">The test error message</error>"

# Generated at 2022-06-21 08:02:57.469685
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    classname = 'foo'
    name = 'bar'
    time = decimal.Decimal('0.5')
    expected_get_attributes = {'classname': 'foo', 'name': 'bar', 'time': '0.5'}
    test_case = TestCase(classname=classname, name=name, time=time)
    assert test_case.get_attributes() == expected_get_attributes


# Generated at 2022-06-21 08:03:09.683324
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-21 08:03:12.806898
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    class DummyTestCase(TestCase):
        name = 'DummyTestCase'

    assert repr(DummyTestCase()) == 'TestCase(name="DummyTestCase")'


# Generated at 2022-06-21 08:03:19.998851
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    """Test XML format of class TestSuites."""
    suites = TestSuites(name='example')
    suite = TestSuite(name='suite')
    case = TestCase(name='case')
    
    suite.cases.append(case)
    suites.suites.append(suite)

    xml_string = suites.to_pretty_xml()

    assert '<testsuites disabled="0" errors="0" failures="0" name="example" tests="1" time="0">' in xml_string
    assert '<testsuite disabled="0" errors="0" failures="0" hostname="example" name="suite" package="example" skipped="0" tests="1" timestamp="1970-01-01T00:00:00">' in xml_string    

# Generated at 2022-06-21 08:03:25.202007
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    """Test case for method __eq__ of class TestFailure."""
    test_failure_1 = TestFailure(message = 'a', type = 'b')
    test_failure_2 = TestFailure(message = 'a', type = 'b')
    assert test_failure_1 == test_failure_2


# Generated at 2022-06-21 08:03:36.782416
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # create a new test case
    test_case = TestCase(name="test0", assertions=1, classname="class1", status="Success", time=0.0)
    
    case_element = test_case.get_xml_element()
    print(ET.tostring(case_element, encoding="utf-8", method="xml"))

    # create a new test suite
    test_suite = TestSuite(name="test_suite", hostname="test_hostname", package="test_package", timestamp=datetime.datetime.now())
    test_suite.cases.append(test_case)
    test_suite.system_out="test_system_out"
    test_suite.system_err="test_system_err"

    suite_element = test_suite.get_xml_element()

# Generated at 2022-06-21 08:03:42.230334
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    print("testing __eq__ of TestSuite")
    test_cases1 = [TestCase("name1")]
    test_cases2 = [TestCase("name2")]
    test_suite1 = TestSuite("name1")
    test_suite1.cases = test_cases1
    test_suite2 = TestSuite("name1")
    test_suite2.cases = test_cases2
    assert test_suite1 == test_suite2


# Generated at 2022-06-21 08:03:44.359975
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    xml_element = TestSuites(

    ).get_xml_element()

    assert xml_element.tag == 'testsuites'

# Generated at 2022-06-21 08:03:50.974102
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_failure = TestFailure(output='sample output', message='sample message', type='sample type')
    assert test_failure.get_xml_element().tag == 'failure'
    assert test_failure.get_xml_element().attrib == {'message': 'sample message', 'type': 'sample type'}
    assert test_failure.get_xml_element().text == 'sample output'


# Generated at 2022-06-21 08:03:56.193375
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    """
    This method tests the method get_attributes of class TestCase
    """
    attr = _attributes(
            assertions=3,
            classname='classname',
            name='name',
            status='status',
            time=1.2,
        )
    t = TestCase('name', 3, 'classname', 'status', 1.2)
    assert t.get_attributes() == attr

# Generated at 2022-06-21 08:04:03.760621
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    tc = TestResult()
    assert tc.get_attributes() == {}



# Generated at 2022-06-21 08:04:11.201635
# Unit test for method __repr__ of class TestSuites

# Generated at 2022-06-21 08:04:14.823898
# Unit test for constructor of class TestCase
def test_TestCase():
    test_case = TestCase(name='test_case')
    assert test_case.get_xml_element() == ET.Element('testcase', attrib={'name': 'test_case'})



# Generated at 2022-06-21 08:04:26.243029
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test_suite_1 = TestSuite(
        name = "test_suite_1",
        hostname = "localhost",
        id = "id_123",
        package = "package_1",
        timestamp = datetime.datetime.now(),
        properties = {"key1": "value1"},
        cases = [TestCase(name="case_1", time=0.1),
                 TestCase(name="case_2", time=0.2)],
        system_out = "some testsuite output",
        system_err = "some testsuite error"
    )

# Generated at 2022-06-21 08:04:29.512654
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test_suites = TestSuites(
        name='UnitTest',
        suites=[TestSuite(
            name="test_case_1",
            timestamp=datetime.datetime.now(),
            cases=[TestCase(name="test_case_1")]
        )]
    )
    assert isinstance(test_suites.get_attributes(), dict)



# Generated at 2022-06-21 08:04:34.245880
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    a = TestSuite('name')
    for i in range(2):
        a.cases.append(TestCase('name-t'+str(i)))
    xmlstr = _pretty_xml(a.get_xml_element())
    print(xmlstr)


# Generated at 2022-06-21 08:04:42.226393
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element() == ET.fromstring('<testresult />')

    result = TestResult(output='This is the output.')
    assert result.get_xml_element() == ET.fromstring('<testresult>This is the output.</testresult>')

    result = TestResult(output='This is the output.', message='This is the message.')
    assert result.get_xml_element() == ET.fromstring('<testresult message="This is the message.">This is the output.</testresult>')

    result = TestResult(output='This is the output.', message='This is the message.', type='MyResult')

# Generated at 2022-06-21 08:04:43.284482
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    pass


# Generated at 2022-06-21 08:04:51.714257
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a=TestSuites(name="a", suites=[TestSuite(name="TestSuite a")])
    b=TestSuites(name="a", suites=[TestSuite(name="TestSuite a")])
    c=TestSuites(name="a", suites=[TestSuite(name="TestSuite b")])
    d=TestSuites(name="a", suites=[])
    e=TestSuites(name="c", suites=[TestSuite(name="TestSuite a")])
    assert a==b
    assert not a==c
    assert not a==d
    assert not a==e


# Generated at 2022-06-21 08:04:55.513357
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    expected = """\
TestError(
    output='None', 
    message='None', 
    type='error',
)"""
    value = TestError()
    actual = repr(value)

    assert expected == actual



# Generated at 2022-06-21 08:05:07.400664
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    myTestCase = TestCase(
        name = 'TestCase1',
        assertions = 1,
        classname = 'TestClassname',
        status = 'SUCCESS',
        time = decimal.Decimal(5.5)
    )

    assert myTestCase.get_attributes() == {
        'assertions': '1',
        'classname': 'TestClassname',
        'name': 'TestCase1',
        'status': 'SUCCESS',
        'time': '5.5',
    }


# Generated at 2022-06-21 08:05:19.090421
# Unit test for constructor of class TestCase
def test_TestCase():
    # Declare variables
    name = 'TestCase1'
    assertions = 5
    classname = 'test.test_testcase.TestCase'
    status = 'passed'
    time = '0.001'
    errors = [TestError(output='error1', message='error1', type=None), TestError(output='error2', message='error2', type=None)]
    failures = [TestFailure(output='failure1', message='failure1', type=None), TestFailure(output='failure2', message='failure2', type=None)]
    skipped = 'Skipped'
    system_out = 'This is system out'
    system_err = 'This is system err'
    is_disabled = False

    # Create an instance of TestCase

# Generated at 2022-06-21 08:05:30.447860
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    # Create a suite
    suite = TestSuite(name = "name",
                      hostname = "hostname",
                      id = "id",
                      package = "package",
                      timestamp = datetime.datetime(year=2020, month=7, day=1, hour=12, minute=30, second=0),
                      properties = {"properties1": "value1", "properties2": "value2"},
                      cases = [],
                      system_out = "system_out",
                      system_err = "system_err")

    # Create a suite containing the suite
    suites = TestSuites(name = "name",
                        suites = [suite])

    # Get the attributes of the suites
    result = suites.get_attributes()

    # Check if it is as expected

# Generated at 2022-06-21 08:05:33.432432
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    output = 'foo test'
    message = 'failed test'
    result = TestResult(output, message)
    assert result.__repr__() == '<TestResult message="failed test" output="foo test" type="TestResult" >'

# Generated at 2022-06-21 08:05:38.470907
# Unit test for constructor of class TestFailure
def test_TestFailure():
    print("Running unit tests")
    output = "Test output"
    message = "Test message"
    type = "Test type"

    failure = TestFailure(output, message, type)

    assert failure.output == output
    assert failure.message == message
    assert failure.type == type



# Generated at 2022-06-21 08:05:47.278380
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    """Test TestSuite.get_attributes()."""
    suite = TestSuite(name='my-suite',
                        hostname='host1',
                        id='id1',
                        package='package1',
                        timestamp=datetime.datetime(2020, 9, 10, 1, 2, 3),
                        properties={'a': 'b'},
                        system_out='some stdout',
                        system_err='some stderr')
    assert len(suite.get_attributes()) == 9
    assert suite.get_attributes()['name'] == suite.name
    assert suite.get_attributes()['hostname'] == suite.hostname
    assert suite.get_attributes()['id'] == suite.id

# Generated at 2022-06-21 08:05:53.902151
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestFailure(message='Test message', output='Test output', type='Test type')
    root = ET.Element(result.tag, result.get_attributes())
    root.text = result.output
    assert result.get_xml_element().tag == root.tag
    assert result.get_xml_element().text == root.text
    assert result.get_xml_element().items() == root.items()


# Generated at 2022-06-21 08:05:57.147784
# Unit test for constructor of class TestResult
def test_TestResult():
    assert TestResult()
    assert TestResult(output='test')
    assert TestResult(output='test', message='test')
    assert TestResult(output='test', message='test', type='test')


# Generated at 2022-06-21 08:06:01.342644
# Unit test for constructor of class TestSuite
def test_TestSuite():
    properties = {"key1": "value1", "key2": "value2"}
    test_suite = TestSuite("CIFAR", properties=properties)
    assert test_suite.properties == properties
    assert test_suite.name == "CIFAR"


# Generated at 2022-06-21 08:06:06.265993
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    a = TestSuite('hello', None, None, None, None)
    b = {'name': 'hello', 'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '0', 'time': '0.0'}
    assert a.get_attributes() == b


# Generated at 2022-06-21 08:06:14.014465
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    TestSuites() == TestSuites()


# Generated at 2022-06-21 08:06:15.724169
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert(TestError() == TestError())


# Generated at 2022-06-21 08:06:25.105017
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_tag = "tag"
    test_output = "output"
    test_message = "message"
    test_type = "type"
    value = TestFailure(output=test_output, message=test_message, type=test_type)
    expected = 'TestFailure(output="{output}", message="{message}", type="{type}", tag="{tag}")'.format(
        output=test_output, message=test_message, type=test_type, tag=test_tag)
    actual = repr(value)
    assert expected == actual


# Generated at 2022-06-21 08:06:30.401237
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    print(TestSuites.__repr__())
    # assert TestSuites.__repr__() == "dataclasses.dataclass(<class '__main__.TestSuites'>, init=True, repr=True, eq=True, order=False, unsafe_hash=False, frozen=False)"



# Generated at 2022-06-21 08:06:34.871827
# Unit test for constructor of class TestSuites
def test_TestSuites():
    testsuit1 = TestSuite(name='unit test1')
    testsuit2 = TestSuite(name='unit test2')

    testsuites = TestSuites(name='UnitTest')
    testsuites.suites.append(testsuit1)
    testsuites.suites.append(testsuit2)

    assert isinstance(testsuites, TestSuites)

# Generated at 2022-06-21 08:06:39.548354
# Unit test for constructor of class TestError
def test_TestError():
    t = TestError("output", "message", "type")
    assert t.output == "output"
    assert t.message == "message"
    assert t.type == "type"


# Generated at 2022-06-21 08:06:51.323630
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:06:59.470884
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    # Initialize datetime object
    cur_time = datetime.datetime.now()

    # Initialize an instance of TestSuites

# Generated at 2022-06-21 08:07:07.785847
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    class TestResult_SubClass(TestResult):
        tag = 'tag-name'

    test_result = TestResult_SubClass(output='output value',
                                      message='message value',
                                      type='type value')

    xml_element = test_result.get_xml_element()

    assert xml_element.tag == 'tag-name'
    assert xml_element.attrib['message'] == 'message value'
    assert xml_element.attrib['type'] == 'type value'
    assert xml_element.text == 'output value'


# Generated at 2022-06-21 08:07:10.555252
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    tc1=TestCase('test1')
    tc2=TestCase('test1')
    assert tc1==tc2
    tc3=TestCase('test3')
    assert tc1!=tc3

# Generated at 2022-06-21 08:07:36.089417
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    test_failure = TestFailure(output='error!', message='error', type='error')
    assert test_failure == test_failure

    test_failure_2 = TestFailure(output='error!', message='error', type='error')
    assert test_failure_2 == test_failure

    test_failure_3 = TestFailure(output='error!', message='error', type='different')
    assert not test_failure_3 == test_failure



# Generated at 2022-06-21 08:07:40.131941
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    class TestResultMock(TestResult):
        @property
        def tag(self):
            return "tag"

    test_result_mock = TestResultMock()

    assert test_result_mock.type == "tag"



# Generated at 2022-06-21 08:07:44.506317
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test1 = TestResult(output='test1 output', message='test1 message', type='test1 type')
    assert test1.get_attributes() == {
        'message': 'test1 message',
        'type': 'test1 type',
    }



# Generated at 2022-06-21 08:07:52.604318
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite =TestSuite('name',
                          'hostname',
                          'id',
                          properties = {'name':'val'},
                          timestamp=datetime.datetime.now())
    # test_suite.get_attributes()
    assert test_suite.get_attributes() == {'name':'name',
                                           'hostname':'hostname',
                                           'id':'id',
                                           'disabled':'0',
                                           'errors':'0',
                                           'failures':'0',
                                           'skipped':'0',
                                           'tests':'0',
                                           'time':'0'}


# Generated at 2022-06-21 08:07:55.966731
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test = TestCase(name="My test case")
    testsuite = TestSuite(name="My test suite", cases=[test])
    attributes = testsuite.get_attributes()

    assert attributes == {'name': 'My test suite', 'tests': 1, 'disabled': 0,
                          'failures': 0, 'errors': 0, 'time': 0}



# Generated at 2022-06-21 08:07:59.964596
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    atr = dataclasses.asdict(TestCase(name="test_test_test"))
    assert sorted(atr.keys()) == sorted(["name"])
    assert atr["name"] == "test_test_test"


# Generated at 2022-06-21 08:08:11.762650
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    ts_str = str(TestSuite(name='TestSuiteName', hostname='TestHostname', id='TestId', package='TestPackage', timestamp='TestTimestamp', properties={'property1': 'value1'}, cases=[TestCase(name='TestCaseName', assertions=1, classname='TestClassname', status='TestStatus', time=1.0, errors=[TestError(output='TestOutput', message='TestMessage', type='TestType')], failures=[TestFailure(output='TestOutput', message='TestMessage', type='TestType')], skipped='TestSkipped', system_out='TestSystemOut', system_err='TestSystemErr')], system_out='TestSystemOut', system_err='TestSystemErr'))


# Generated at 2022-06-21 08:08:19.282534
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    # Arrange
    test_case = TestCase(name='test_TestCase___repr__', assertions=1, classname='test_junit_xml', status='COMPLETED', time=1, output='output')

    # Act
    result = test_case.__repr__()
    xml = test_case.get_xml_element()

    # Assert
    assert result == f"TestCase(\n    name='test_TestCase___repr__',\n    assertions=1,\n    classname='test_junit_xml',\n    status='COMPLETED',\n    time=1,\n    output='output',\n)"
    assert xml.tag == 'testcase'
    assert len(xml.attrib) == 5
    assert xml.attrib.get('assertions') == '1'
    assert xml

# Generated at 2022-06-21 08:08:29.805232
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    suite1 = TestSuite.__new__(TestSuite)
    suite2 = TestSuite.__new__(TestSuite)

    suite1.name = "TestSuite1"
    suite2.name = "TestSuite1"

    case1_1 = TestCase.__new__(TestCase)
    case1_2 = TestCase.__new__(TestCase)
    case2_1 = TestCase.__new__(TestCase)
    case2_2 = TestCase.__new__(TestCase)

    case1_1.name = "Test1.1"
    case1_1.is_disabled = True
    case1_2.name = "Test1.2"
    case1_2.is_disabled = True
    case2_1.name = "Test2.1"
    case

# Generated at 2022-06-21 08:08:31.224614
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    result = TestError()
    assert result == result


# Generated at 2022-06-21 08:09:00.054110
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_suites = TestSuites(name="foo")
    test_suites_element = test_suites.get_xml_element()
    assert test_suites_element.tag == "testsuites"


# Generated at 2022-06-21 08:09:03.497083
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    """Unit test for method __repr__ of class TestCase."""
    msg = 'TestCase(classname=\'Test\', name=\'test_case\', time=1, failures=[], errors=[], skipped=None)'
    actual = TestCase(
        classname='Test',
        name='test_case',
        time=1,
    ).__repr__()
    assert actual == msg



# Generated at 2022-06-21 08:09:14.399560
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    # Arrange
    def_val = None

    test_suite = TestSuite(name=def_val,
                           hostname=def_val,
                           id=def_val,
                           package=def_val,
                           timestamp=def_val,
                           properties=def_val,
                           cases=def_val,
                           system_out=def_val,
                           system_err=def_val)

    # Act
    actual = test_suite.__repr__()

    # Assert
    assert actual == 'TestSuite(name=None, hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)'

# Generated at 2022-06-21 08:09:19.141139
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testcase = TestCase(name="testname", assertions=20, classname='test', status='teststatus', time=5)
    assert testcase.get_attributes() == {'name':'testname', 'assertions': '20', 'classname':'test', 'status':'teststatus', 'time':'5'}


# Generated at 2022-06-21 08:09:21.857738
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    tf1 = TestFailure(output="Nothing", message="Oops")
    tf2 = TestFailure(output="Nothing", message="Oops")
    assert tf1 == tf2, "Fail: TestFailure __eq__ test failed."


# Generated at 2022-06-21 08:09:26.565781
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    err1 = TestError()
    err2 = TestError()
    assert(err1 == err2)

    err1.type = "type1"
    assert(err1 != err2)

    err2.type = "type1"
    assert(err1 == err2)

    err1.message = "message1"
    assert(err1 != err2)

    err2.message = "message1"
    assert(err1 == err2)

    err1.output = "output1"
    assert(err1 != err2)

    err2.output = "output1"
    assert(err1 == err2)



# Generated at 2022-06-21 08:09:36.944789
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    # Test the method __repr__ of class TestSuite
    # Create two test cases
    tCase1 = TestCase("TC001", time=1)
    tCase2 = TestCase("TC002", time=2)
    # Create a TestSuite with two test cases
    tSuite = TestSuite("TestSuite 1", hostname="hostname", id="tcID", package="package", timestamp=datetime.datetime.now(), cases=[tCase1, tCase2])

    assert "TestSuite(name='TestSuite 1', hostname='hostname', id='tcID', package='package', timestamp=" in repr(tSuite)
    assert "tests=2, time=3, properties=" in repr(tSuite)

# Generated at 2022-06-21 08:09:46.652625
# Unit test for method __repr__ of class TestCase

# Generated at 2022-06-21 08:09:49.595112
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    suites = TestSuites()
    name = 'name'
    suites.name = name
    assert suites.get_attributes() == {'failures' : 0, 'tests' : 0, 'name' : name }

# Generated at 2022-06-21 08:09:53.371579
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    # Given
    suite = TestSuite(name='suite')
    # When
    actual = suite.__repr__()
    # Then
    assert actual == "<TestSuite(name='suite', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)>"

# Generated at 2022-06-21 08:10:29.209780
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():

    ts = TestSuite('name', 'hostname', 'id', 'package', 'timestamp')

    attributes = ts.get_attributes()

    assert attributes['disabled'] == ''
    assert attributes['errors'] == ''
    assert attributes['failures'] == ''
    assert attributes['hostname'] == 'hostname'
    assert attributes['id'] == 'id'
    assert attributes['name'] == 'name'
    assert attributes['package'] == 'package'
    assert attributes['skipped'] == ''
    assert attributes['tests'] == ''
    assert attributes['time'] == ''
    assert attributes['timestamp'] == 'timestamp'


# Generated at 2022-06-21 08:10:39.382860
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Test method to_pretty_xml"""

# Generated at 2022-06-21 08:10:48.440249
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:10:58.502310
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    import unittest

    class TestTestSuites___eq__(unittest.TestCase):
        def test_equal_attributes(self) -> None:
            self.assertEqual(
                TestSuites(name='foo', suites=[TestSuite(name='bar')]),
                TestSuites(name='foo', suites=[TestSuite(name='bar')]),
            )

        def test_different_name(self) -> None:
            self.assertNotEqual(
                TestSuites(name='foo', suites=[TestSuite(name='bar')]),
                TestSuites(name='baz', suites=[TestSuite(name='bar')]),
            )


# Generated at 2022-06-21 08:11:06.143688
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # Case 1: Base Case
    assert repr(TestSuites()) == "TestSuites(name=None, suites=[])"

    # Case 2: With test suites
    assert repr(TestSuites(suites=[TestSuite(name="Testing")])) == "TestSuites(name=None, suites=[TestSuite(name='Testing', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None, disabled=0, errors=0, failures=0, skipped=0, tests=0, time=0)])"


# Generated at 2022-06-21 08:11:09.803618
# Unit test for constructor of class TestError
def test_TestError():
    obj = TestError(output="Testing")
    obj.__init__(output="Testing")
    obj.__init__(message="AssertionError")
    obj.__init__(type="error")


# Generated at 2022-06-21 08:11:12.141919
# Unit test for constructor of class TestSuite
def test_TestSuite():
    ts = TestSuite(name='pipenv.lock')
    assert ts.name == 'pipenv.lock'


# Generated at 2022-06-21 08:11:15.192803
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(message="test")


    assert result.get_xml_element().tag == "testResult"
    assert result.get_xml_element().attrib == {"message": "test"}

test_TestResult_get_xml_element()


# Generated at 2022-06-21 08:11:21.275613
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='test output', message='test message', type='test type')
    xml_element = result.get_xml_element()
    element = ET.Element('testResult')
    element.text = 'test output'
    element.set('message',"test message")
    element.set('type',"test type")
    assert ET.tostring(xml_element,"unicode") == ET.tostring(element,"unicode")
