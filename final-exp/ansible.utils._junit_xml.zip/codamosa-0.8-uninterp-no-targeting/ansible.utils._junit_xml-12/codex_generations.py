

# Generated at 2022-06-21 08:01:26.509120
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    t4 = TestFailure(output="")
    t1 = TestFailure(output="")
    assert t1 == t4


# Generated at 2022-06-21 08:01:29.497106
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    t1 = TestResult("my_output","my_message","my_type")
    assert t1.get_attributes() == {"type": "my_type", "message": "my_message"}



# Generated at 2022-06-21 08:01:33.577117
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():

    assert str(TestError(output='foo', message='bar', type='baz')) == 'TestError(output=\'foo\', message=\'bar\', type=\'baz\')'


# Generated at 2022-06-21 08:01:37.062893
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    obj = TestSuites()
    assert obj == TestSuites()

    obj.suites = [TestSuite()]
    assert obj != TestSuites()



# Generated at 2022-06-21 08:01:39.571517
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    kwargs = {}

    result = TestError.__repr__(**kwargs)
    assert result is not None


# Generated at 2022-06-21 08:01:42.867155
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='result output')

    # noinspection PyTypeChecker
    assert result.get_xml_element() == ET.fromstring('<testresult output="result output"/>')


# Generated at 2022-06-21 08:01:45.089675
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert TestFailure(output="Failed!", message="Message text", type="failure")


# Generated at 2022-06-21 08:01:47.975583
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    tc1 = TestCase(name = "TestCase1")
    assert tc1 == TestCase(name = "TestCase1")


# Generated at 2022-06-21 08:01:56.507514
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase("case1")
    test_case.is_disabled = True
    test_case.errors.append(TestError("Error 1!", "Error Type1!", "Error Output 1!"))
    test_case.errors.append(TestError("Error 2!", "Error Type2!", "Error Output 2!"))
    test_case.failures.append(TestFailure("Failure 1!", "Failure Type1!", "Failure Output 1!"))
    test_case.failures.append(TestFailure("Failure 2!", "Failure Type2!", "Failure Output 2!"))
    test_case.skipped = "Skipped 1!"
    test_case.system_out = "System Out 1!"
    test_case.system_err = "System Err 1!"

# Generated at 2022-06-21 08:02:05.816501
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    result1 = TestError()
    result2 = TestError()
    assert result1 == result2
 
    result1.output = 'test'
    assert result1 != result2
    result2.output = 'test'
    assert result1 == result2
 
    result1.message = 'test'
    assert result1 != result2
    result2.message = 'test'
    assert result1 == result2
 
    result1.type = 'test'
    assert result1 != result2
    result2.type = 'test'
    assert result1 == result2
 

# Generated at 2022-06-21 08:02:13.542828
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult("", type='testtype', message='testmessage')
    attributes_dict = result.get_attributes()
    assert attributes_dict['type'] == 'testtype'
    assert attributes_dict['message'] == 'testmessage'



# Generated at 2022-06-21 08:02:20.269179
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    # Test 1
    first_TestResult = TestResult()
    second_TestResult = TestResult()

    assert first_TestResult == second_TestResult

    # Test 2
    first_TestResult = TestResult(
        output="output TestResult",
        message="message TestResult",
        type="type TestResult",
    )
    second_TestResult = TestResult(
        output="output TestResult",
        message="message TestResult",
        type="type TestResult",
    )

    assert first_TestResult == second_TestResult

    # Test 3
    first_TestResult = TestResult()
    second_TestResult = TestResult(
        output="output TestResult",
        message="message TestResult",
        type="type TestResult",
    )

    assert first_TestResult != second_TestResult

    # Test 4
    first

# Generated at 2022-06-21 08:02:29.394675
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test1 = TestSuite(name="1",hostname="0",id="23",package="2",timestamp=None, cases=[TestCase(name="1"),TestCase(name="2")],system_out="hello",system_err="hi",properties={"hi":"there"})
    test2 = TestSuite(name="1",hostname="0",id="23",package="2",timestamp=None, cases=[TestCase(name="1"),TestCase(name="2")],system_out="hello",system_err="hi",properties={"hi":"there"})
    return test1 == test2


# Generated at 2022-06-21 08:02:31.363631
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    instance = TestResult()
    assert instance.__repr__() == '<TestResult output=None message=None type=None>'


# Generated at 2022-06-21 08:02:37.304084
# Unit test for constructor of class TestSuite
def test_TestSuite():
    testSuite = TestSuite(name="test-suite", failures=1, time=2.3)
    actual = testSuite.__dict__

# Generated at 2022-06-21 08:02:47.761741
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_result_output = '1 + 1 = 3'
    test_result_message = 'Arithmetic Error'
    test_result_type = 'ArithmeticException'
    test_case_name = 'arithmetic'
    test_case_assertions = 1
    test_case_classname = 'package.module.Class'
    test_case_status = 'Failure'
    test_case_time = decimal.Decimal(1.0)
    test_case_errors = TestError(output=test_result_output, message=test_result_message, type=test_result_type)
    test_case_failures = TestFailure(output=test_result_output, message=test_result_message, type=test_result_type)
    test_case_skipped = 'Skipped'
    test_case_system_out

# Generated at 2022-06-21 08:02:53.507160
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    """
    Unit test for method __eq__ of class TestCase
    """
    test_case1 = TestCase(name="test_case")
    test_case2 = TestCase(name="test_case")
    assert test_case1 == test_case2
    assert not test_case1 != test_case2


# Generated at 2022-06-21 08:03:00.175922
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # Setup
    msg = message = 'this is a message'
    output = 'this is some output'
    t = type = 'type of result'
    exp_repr = 'TestResult(output=%r, message=%r, type=%r)' % (output, msg, t)

    # Exercise
    actual = TestResult(output=output, message=msg, type=t)

    # Verify
    assert repr(actual) == exp_repr


# Generated at 2022-06-21 08:03:12.186682
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    from dataclasses import dataclass
    from typing import List
    from nbqa.__main__ import TestCase
    @dataclass
    class TestResult(metaclass=abc.ABCMeta):
        """Base class for the result of a test case."""

        @property
        @abc.abstractmethod
        def tag(self) -> str:
            """Tag name for the XML element created by this result type."""


    @dataclass
    class TestFailure(TestResult):
        """Failure info for a test case."""
        @property
        def tag(self) -> str:
            """Tag name for the XML element created by this result type."""
            return 'failure'


    @dataclass
    class TestError(TestResult):
        """Error info for a test case."""

# Generated at 2022-06-21 08:03:17.829431
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    a = TestSuite(name="a", hostname="b", id="c", package="d", timestamp=datetime.datetime.now(), properties={"k": "v"}, cases=[], system_out="o", system_err="e")
    b = TestSuite(name="a", hostname="b", id="c", package="d", timestamp=datetime.datetime.now(), properties={"k": "v"}, cases=[], system_out="o", system_err="e")
    assert a == b


# Generated at 2022-06-21 08:03:23.705747
# Unit test for constructor of class TestError
def test_TestError():
    assert TestError(output="Error", message="Error Message", type="Test") is not None


# Generated at 2022-06-21 08:03:35.542576
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    """Example unit test for method get_xml_element of class TestSuites """
    my_test_suites = TestSuites(name = 'suites')
    my_test_suite = TestSuite(name = 'a_test_suite', id = '1')
    my_test_case = TestCase(name = 'a_test_case')
    my_test_case.time = 1
    my_test_failure = TestFailure(output = 'failure')
    my_test_case.failures.append(my_test_failure)
    my_test_suite.cases.append(my_test_case)
    my_test_suites.suites.append(my_test_suite)
    test_suites_xml_string = my_test_suites.get_xml_element()


# Generated at 2022-06-21 08:03:37.650356
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError(type="type")
    assert error.type == "type"
    assert error.tag == "error"


# Generated at 2022-06-21 08:03:44.130614
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    new_tc = TestCase("test1", "case1", "fail", 2, "output")
    new_suite = TestSuite("test2", "case2", 'fail')
    new_suite.cases.append(new_tc)
    xml_element = new_suite.get_xml_element()
    str_xml = ET.tostring(xml_element)
    assert str_xml == b'<testsuite disabled="0" errors="0" failures="0" hostname="case2" id="fail" name="test2" package="" skipped="0" tests="0" time="0" timestamp="None"></testsuite>'

# Generated at 2022-06-21 08:03:47.622785
# Unit test for constructor of class TestError
def test_TestError():
    x = TestError()
    assert(x.output == None)
    assert(x.message == None)
    assert(x.type == 'error')


# Generated at 2022-06-21 08:03:53.343570
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
	t = TestSuites()
	t.suites.append(TestSuite())
	t_repr = t.__repr__()
	t_repr_expected = 'TestSuites(suites=[TestSuite(name=None)])'
	assert t_repr_expected in t_repr, f"expected {t_repr_expected} but got {t_repr}"


# Generated at 2022-06-21 08:04:02.926165
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert not TestFailure(output='accidentally removing the entire database', type='error') == None
    assert TestFailure(output='accidentally removing the entire database', type='error') == TestFailure(output='accidentally removing the entire database', type='error')
    assert not TestFailure(output='accidentally removing the entire database', type='error') == TestFailure(output='accidentally removing the entire database', type='failure')
    assert not TestFailure(output='accidentally removing the entire database', type='error') == TestFailure(output='accidentally removing the entire database', type='error', message='check credentials')
    assert not TestFailure(output='accidentally removing the entire database', type='error') == TestFailure(message='check credentials')
    assert not TestFailure(output='accidentally removing the entire database', type='error') == TestFailure(message='check credentials', type='error')

# Generated at 2022-06-21 08:04:10.727470
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes(): 
    """Unit test for method get_attributes of class TestSuite """
    ts = TestSuite(name="test", hostname="localhost", id="ID-1", package="com.github.jenkins-junit-tester", timestamp="2020-08-10T22:50:05.888731")
    
    assert ts.get_attributes()["disabled"] == "0"
    assert ts.get_attributes()["errors"] == "0"
    assert ts.get_attributes()["failures"] == "0"
    assert ts.get_attributes()["hostname"] == "localhost"
    assert ts.get_attributes()["id"] == "ID-1"
    assert ts.get_attributes()["name"] == "test"

# Generated at 2022-06-21 08:04:23.190087
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    import os
    import json

    with open(os.path.join(os.path.dirname(__file__), 'test_NUnitRunner.json')) as json_data_file:
        data = json.load(json_data_file)

    date = datetime.datetime(2020, 2, 20, 7, 55, 2)

# Generated at 2022-06-21 08:04:29.311612
# Unit test for constructor of class TestSuite
def test_TestSuite():
    test_suite=TestSuite(name="test", hostname="localhost", id="1", package="aaa", timestamp=None)
    assert test_suite.name=="test"
    assert test_suite.hostname=="localhost"
    assert test_suite.id=="1"
    assert test_suite.package=="aaa"
    assert test_suite.timestamp==None
    assert test_suite.properties=={}
    assert test_suite.cases==[]
    assert test_suite.system_out==None
    assert test_suite.system_err==None


# Generated at 2022-06-21 08:04:45.402009
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    c =  TestCase(name="test_TestCase_get_attributes")
    assert c.get_attributes() == {}
    c2 = TestCase(name="test_TestCase_get_attributes", assertions=1, classname="mytestclass", status="PASS", time=0.0)
    assert c2.get_attributes() == {'name': 'test_TestCase_get_attributes', 'assertions': '1', 'classname': 'mytestclass', 'status': 'PASS', 'time': '0.0'}


# Generated at 2022-06-21 08:04:47.360386
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_suites = TestSuites()

    test_suites.to_pretty_xml()

# Generated at 2022-06-21 08:04:53.704593
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    from datetime import datetime
    from decimal import Decimal
    from junit_xml import TestFailure

    test_failure = TestFailure(output='I failed!',
                               message='because I felt like it',
                               type='IError')
    # noinspection PyUnresolvedReferences
    expected = "TestFailure(output='I failed!', message='because I felt like it', type='IError')"
    assert repr(test_failure) == expected



# Generated at 2022-06-21 08:05:06.239561
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    x = TestSuites(name='test',
                   suites=[
                       TestSuite(name='test',
                                 timestamp=datetime.datetime.now(),
                                 cases=[
                                     TestCase(output="test",
                                              name="test",
                                              status="test",
                                              classname="test",
                                              time=1.3)
                                 ])
                   ])


# Generated at 2022-06-21 08:05:08.306859
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    actual=TestFailure("Log or error message displayed on failure")
    expected=TestFailure("Log or error message displayed on failure")
    assert actual == expected

# Generated at 2022-06-21 08:05:20.932962
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Test class TestSuites and its method to_pretty_xml."""
    test_suite = TestSuite(name='suite', id='0', timestamp=datetime.datetime(2020, 10, 31, 0, 0, 0))
    test_suite.system_err = 'error'
    test_suite.system_out = 'output'
    test_suite.cases.extend([
        TestCase(name='case' + str(case_number), time=decimal.Decimal(case_number + 0.1), classname='class', assertions=case_number)
        for case_number in range(10)
    ])

    test_suites = TestSuites(name='suites')
    test_suites.suites.append(test_suite)

    xml = test_suites.to_pretty

# Generated at 2022-06-21 08:05:25.435707
# Unit test for constructor of class TestCase
def test_TestCase():
    test_case_good = TestCase(name = 'test name')
    test_case_bad = TestCase()

    assert test_case_bad.name == '', 'Test name is expected to be empty string'
    assert test_case_good.name == 'test name', 'Test name is expected to be test name'


# Generated at 2022-06-21 08:05:30.643126
# Unit test for constructor of class TestError
def test_TestError():
    print('Start Unit test for constructor of class TestError')
    testError = TestError()
    testError.message = 'message'
    testError.output = 'output'
    testError.type = 'Error'
    print('End Unit test for constructor of class TestError')
    return


# Generated at 2022-06-21 08:05:38.166825
# Unit test for constructor of class TestSuites

# Generated at 2022-06-21 08:05:45.457987
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError() == TestError()
    assert TestError(output='output') == TestError(output='output')
    assert TestError(message='message') == TestError(message='message')
    assert TestError(type='type') == TestError(type='type')
    assert TestError(output='output', message='message', type='type') == TestError(output='output', message='message', type='type')

    assert TestError() != TestError(output='output')
    assert TestError(output='output') != TestError(message='message')
    assert TestError(message='message') != TestError(type='type')
    assert TestError(type='type') != TestError(output='output', message='message')
    assert TestError(output='output', message='message') != TestError(output='output', type='type')
    assert Test

# Generated at 2022-06-21 08:06:05.263672
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    testResult = TestResult("test", "message", "type")
    result = testResult.get_attributes()
    expected = {"message": "message", "type": "type"}
    assert result == expected    


# Generated at 2022-06-21 08:06:09.025340
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult("output", "message")
    assert result.output == "output"
    assert result.message == "message"
    assert result.type == "result"
    result = TestResult("output", "message", "type")
    assert result.type == "type"

# Generated at 2022-06-21 08:06:13.050514
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    result = TestFailure()
    assert repr(result) == "TestFailure(output=None, message=None, type=None)"

    result = TestFailure(output='output', message='message', type='type')
    assert repr(result) == "TestFailure(output='output', message='message', type='type')"


# Generated at 2022-06-21 08:06:20.870561
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # Create two TestSuite instances with the same attributes
    a = TestSuite(name='name', hostname='hostname', id='id', package='package', timestamp=datetime.datetime(2020, 8, 2, 15, 2, 22))
    b = TestSuite(name='name', hostname='hostname', id='id', package='package', timestamp=datetime.datetime(2020, 8, 2, 15, 2, 22))

    # Test that they are equal
    assert(a == b)


# Generated at 2022-06-21 08:06:24.511574
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(type = 'type', message = 'message')
    assert result.get_attributes() == {'type' : 'type', 'message' : 'message'}


# Generated at 2022-06-21 08:06:35.276999
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    classname = "sample.TestSuite"
    name = "test1"
    errors = 5
    failures = 3
    skipped = 1
    tests = errors + failures + skipped
    time = 1.01

    test_case = TestCase(name=name, classname=classname)
    test_suite = TestSuite(
        name=classname,
        errors=errors,
        failures=failures,
        skipped=skipped,
        tests=tests,
        cases=[test_case],
        time=time,
    )

    # Create the XML element
    element = test_suite.get_xml_element()

    # Check the name of the element
    assert element.tag == 'testsuite'

    # Check the attributes of the element

# Generated at 2022-06-21 08:06:46.690348
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    ts = TestSuites(name='TestSuites')
    ts.suites.append(TestSuite(
        name='TestSuite1',
        hostname='host1',
        timestamp=datetime.datetime.now()
    ))
    ts.suites.append(TestSuite(
        name='TestSuite2',
        hostname='host2',
        timestamp=datetime.datetime.now()
    ))
    assert ts.get_attributes() == {
        'disabled': 0,
        'errors': 0,
        'failures': 0,
        'name': 'TestSuites',
        'tests': 0,
        'time': 0
    }



# Generated at 2022-06-21 08:06:50.826719
# Unit test for constructor of class TestResult
def test_TestResult():
    output = "output"
    message = "message"
    type = "type"

    result = TestResult(output, message, type)

    assert result != None
    assert result.output == output
    assert result.message == message
    assert result.type == type


# Generated at 2022-06-21 08:06:55.117646
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(message="test message", output="test output", type="test type")
    assert result.get_attributes() == {'message': 'test message', 'type': 'test type'}


# Generated at 2022-06-21 08:07:07.380239
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # Output, message and type

    result = TestResult(output="Output", message="Message", type="Type")
    assert repr(result) == "TestResult(output='Output', message='Message', type='Type')"

    # Only output

    result = TestResult(output="Output", message=None, type="Type")
    assert repr(result) == "TestResult(output='Output', message=None, type='Type')"

    result = TestResult(output="Output")
    assert repr(result) == "TestResult(output='Output')"

    # Only message

    result = TestResult(output=None, message="Message")
    assert repr(result) == "TestResult(output=None, message='Message')"

    result = TestResult(message="Message")

# Generated at 2022-06-21 08:07:45.065961
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    # arrange
    expected = "TestError(output='output', message='message', type='error')"
    my_test_error = TestError("output","message","error")

    # act
    actual = my_test_error.__repr__()

    # assert
    assert actual == expected


# Generated at 2022-06-21 08:07:52.175871
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='TestCase')
    assert _pretty_xml(test_case.get_xml_element()) == '''\
<?xml version="1.0" ?>
<testcase name="TestCase"/>
'''

    test_error = TestError(message='error message')
    test_case.errors.append(test_error)
    assert _pretty_xml(test_case.get_xml_element()) == '''\
<?xml version="1.0" ?>
<testcase name="TestCase">
    <error message="error message"/>
</testcase>
'''

    test_failure = TestFailure(message='failure message')
    test_case.failures.append(test_failure)

# Generated at 2022-06-21 08:07:54.276133
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestError(output='foo', type='bar', message='baz')
    assert result.get_attributes() == {'message': 'baz', 'type': 'bar'}


# Generated at 2022-06-21 08:07:55.845784
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert _attributes(message='the message', type='the type') == {'message': 'the message', 'type': 'the type'}



# Generated at 2022-06-21 08:07:59.800510
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    abc = TestFailure()
    assert abc.__repr__() == '(output=' + str(
        abc.output) + ', message=' + str(abc.message) + ', type=' + str(abc.type) + ')'


# Generated at 2022-06-21 08:08:06.319550
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    attr = _attributes(
        assertions=10,
        classname="class_name",
        name="name",
        status="status",
        time="time"
    )
    test_case = TestCase("name", 10, "class_name", "status", "time")
    ret_attr = test_case.get_attributes()
    assert attr == ret_attr


# Generated at 2022-06-21 08:08:08.425253
# Unit test for constructor of class TestError
def test_TestError():
    assert TestError(message = "Error1", output = "Error1", type = "Error1")


# Generated at 2022-06-21 08:08:16.406293
# Unit test for constructor of class TestCase
def test_TestCase():
    classname = "my_class"
    testname = "my_test"
    time = decimal.Decimal(1)
    status = "FAILED"
    assertions = 0

    my_case = TestCase(name=testname,
               classname=classname,
               time=time,
               status=status,
               assertions=assertions)
    assert (my_case.name == testname)
    assert (my_case.classname == classname)
    assert (my_case.time == time)
    assert (my_case.status == status)
    assert (my_case.assertions == assertions)


# Generated at 2022-06-21 08:08:23.034483
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    # Test TypeError
    testSuites = TestSuites()
    element = ET.Element('testsuites', _attributes(
            disabled=0,
            errors=0,
            failures=0,
            name=None,
            tests=0,
            time=0,
        ))
    assert testSuites.get_xml_element() == element
    print("Test method get_xml_element of class TestSuites passed!")


# Generated at 2022-06-21 08:08:34.473755
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_suites = TestSuites(name='TestSuites')
    test_suites.suites.append(TestSuite(name='TestSuite'))
    test_suites.suites[0].cases.append(TestCase(name='TestCase'))

    element = test_suites.get_xml_element()
    expected = ET.Element('testsuites', {'disabled': '0', 'errors': '0', 'failures': '0', 'name': 'TestSuites', 'tests': '1', 'time': '0'})

# Generated at 2022-06-21 08:10:11.873662
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    tc = TestCase("test", "is ok")
    assert tc.get_xml_element() is not None
    tc.testMethod = "test"
    assert tc.get_xml_element() is not None

# Generated at 2022-06-21 08:10:14.209581
# Unit test for constructor of class TestResult
def test_TestResult():
    assert TestResult().__str__() is not None
    assert TestResult().__repr__() is not None


# Generated at 2022-06-21 08:10:25.753097
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-21 08:10:29.054480
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    def call_function_under_test():
        return TestFailure(
            output='output',
            message='message',
            type='type',
        ).__repr__()

    answer = None
    try:
        the_answer = call_function_under_test()
    except Exception as e:
        answer = str(e)
    assert answer == 'output=output message=message type=type'


# Generated at 2022-06-21 08:10:31.999175
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure(message='') == TestFailure(message='')
    assert TestFailure() == TestFailure()
    assert TestFailure(output='') == TestFailure(output='')


# Generated at 2022-06-21 08:10:37.728850
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    assert TestFailure('FAILURE') == TestFailure('FAILURE')
    assert TestError('ERROR') == TestError('ERROR')
    assert TestFailure('FAILURE') != TestError('ERROR')
    assert TestFailure('FAILURE') != TestFailure('FAILURE1')
    assert TestError('ERROR') != TestError('ERROR1')
    assert TestFailure('FAILURE') != TestError('ERROR')


# Generated at 2022-06-21 08:10:47.584176
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    timestamp = datetime.datetime.now()

# Generated at 2022-06-21 08:10:56.858688
# Unit test for constructor of class TestCase
def test_TestCase():
    c1 = TestCase(name='example.class.TestFun', classname='example.class', assertions=1, status='run', time=2)
    c2 = TestCase(name='example.class.TestSecond', classname='example.class', assertions=2, status='run', time=3)
    c3 = TestCase(name='example.class.TestThird', classname='example.class', assertions=3, status='run', time=4)
    c4 = TestCase(name='example.class.TestFour', classname='example.class', assertions=4, status='run', time=5)
    c5 = TestCase(name='example.class.TestFifth', classname='example.class', assertions=5, status='run', time=6)

    assert c1.classname == 'example.class'
    assert c2

# Generated at 2022-06-21 08:11:04.775018
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    import xml.etree.ElementTree as ET
    output = "ERROR: connection failure: timed out"
    message = "Connection timed out"
    type = "failed"
    element = TestResult(output, message, type).get_xml_element()
    assert element.tag == "testresult"
    assert element.attrib['message'] == message
    assert element.attrib['type'] == type
    assert element.text == output
    assert ET.tostring(element) == b'<testresult message="Connection timed out" type="failed">ERROR: connection failure: timed out</testresult>'


# Generated at 2022-06-21 08:11:15.100215
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
  properties = {'key1': 'value1', 'key2': 'value2'}
  test_suite = TestSuite('TestSuite1', 'localhost', 'ID123', 'package1', datetime.datetime.now(), properties)
  test_case1 = TestCase('TestCase1', 23, 'TestCase1.java', '', '1.23', [TestError(), TestError()], [TestFailure(), TestFailure()], 'Reason1', 'stdout1', 'stderr1')
  test_case2 = TestCase('TestCase2', 12, 'TestCase2.java', '', '2.34', [TestError()], [TestFailure(), TestFailure(), TestFailure()], 'Reason2', 'stdout2', 'stderr2')