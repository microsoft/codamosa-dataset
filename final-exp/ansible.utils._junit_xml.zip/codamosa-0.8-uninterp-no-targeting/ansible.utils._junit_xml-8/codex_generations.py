

# Generated at 2022-06-21 08:01:26.382172
# Unit test for constructor of class TestFailure
def test_TestFailure():
    name = 'test_TestFailure_case'
    testFail = TestFailure(name)

    assert testFail.output == name


# Generated at 2022-06-21 08:01:34.801064
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    from datetime import datetime
    from decimal import Decimal


# Generated at 2022-06-21 08:01:36.313644
# Unit test for constructor of class TestSuite
def test_TestSuite():
    TestSuite()


# Generated at 2022-06-21 08:01:48.450801
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:01:56.734789
# Unit test for constructor of class TestSuite
def test_TestSuite():
    test = TestSuite(name = 'test-suite-name')
    print("TestSuite Name is: " + test.name)

    """test = TestSuite(
        name = 'test-suite-name',
        timestamp = datetime.datetime.utcnow(),
        cases = [
            TestCase(
                name = 'test-case-1',
                classname = 'test.class.name.1',
                time = 0.5
            ),
            TestCase(
                name = 'test-case-2',
                classname = 'test.class.name.2',
                time = 0.7
            )
        ]
    )
    print("TestSuite Name is: " + test.name)
    print("TestSuite Time is: " + str(test.time))"""


# Generated at 2022-06-21 08:02:08.987311
# Unit test for constructor of class TestResult
def test_TestResult():
    # test with no arguments
    with pytest.raises(TypeError):
        TestResult()
    with pytest.raises(TypeError):
        TestResult(output=None, message=None, type=None)

    # test with output
    test_output = "test output"
    test_message = "test message"
    test_tag = "test tag"
    result = TestResult(output=test_output, message=test_message, type=test_tag)
    assert result.output == test_output
    assert result.message == test_message
    assert result.type == test_tag

    # test with output, no message, no type
    test_output = "test output"
    result = TestResult(output=test_output)
    assert result.output == test_output
    assert result.message == None

# Generated at 2022-06-21 08:02:18.221318
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case = TestCase(
        name='my_name',
        assertions=1,
        classname='my_class',
        status='my_status',
        time=decimal.Decimal('1.1'),
        errors=[
            TestError(output='Test error output'),
        ],
        failures=[
            TestFailure(output='Test failure output'),
        ],
        skipped='skipped',
        system_out='Test system out',
        system_err='Test system err',
        is_disabled=True,
    )

    assert test_case == test_case

# Generated at 2022-06-21 08:02:21.307074
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    s3 = TestSuite(name = "ABC")
    assert repr(s3) == 'TestSuite(name=ABC)'

# Generated at 2022-06-21 08:02:25.072480
# Unit test for constructor of class TestFailure
def test_TestFailure():
    x = TestFailure(output="output", message="message", type="type")
    assert x.output == "output"
    assert x.message == "message"
    assert x.type == "type"


# Generated at 2022-06-21 08:02:34.260605
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    assert_TestSuites = TestSuites(name = 'test',
        suites = [TestSuite(name = 'test',
            hostname = 'test',
            id = 'test',
            package = 'test',
            timestamp = datetime.datetime(2020,7,11,23,53,53),
            properties = {'test_key': 'test_value'},
            cases = [TestCase(name = 'test',
                assertions = 3,
                classname = 'test',
                status = 'test',
                time = decimal.Decimal('5.5'),
                system_out = 'test',
                system_err = 'test')],
            system_out = 'test',
            system_err = 'test')])

    assert_TestSuites.__eq__(assert_TestSuites)

    assert_TestSu

# Generated at 2022-06-21 08:02:38.287483
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    pass


# Generated at 2022-06-21 08:02:48.230986
# Unit test for constructor of class TestSuite
def test_TestSuite():
    suite = TestSuite(
        'test_suite_name',
        timestamp=datetime.datetime.now(),
        cases=[
            TestCase('test_case_1'),
            TestCase('test_case_2'),
        ],
    )
    element = suite.get_xml_element()

# Generated at 2022-06-21 08:02:54.327568
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    class TestResult_T(TestResult):
        tag = 'tag'
    assert repr(TestResult_T(output='output', message='message', type='type')) == "TestResult_T(output='output', message='message', type='type')"


# Generated at 2022-06-21 08:02:58.727151
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Test with all attributes and nested elements
    test_case = TestCase(name='test_method_name',
                         assertions=2,
                         classname='TestClass',
                         status='FAILED',
                         time=decimal.Decimal('1.23'),
                         errors=[TestError(output='error_output',
                                           message='error_message',
                                           type='error_type')],
                         failures=[TestFailure(output='failure_output',
                                               message='failure_message',
                                               type='failure_type')],
                         skipped='skipped_text',
                         system_out='out_text',
                         system_err='err_text')


# Generated at 2022-06-21 08:03:01.682696
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert repr(TestError(output='output', message='message', type='type')) == "TestError(output='output', message='message', type='type')"


# Generated at 2022-06-21 08:03:07.813404
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    class TestResultSubClass(TestResult):
        tag = 'subclass'

    test_result = TestResultSubClass()
    assert 'subclass' == test_result.type

if __name__ == '__main__':
    # Unit test for method __post_init__ of class TestResult
    test_TestResult___post_init__()

# Generated at 2022-06-21 08:03:13.818413
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # Init
    output = "test"
    type = "class"
    tag = "test"
    message = "test"
    expected_result = f'TestResult(output="test", message="test", type="class")'
    # Exercise
    actual_result = TestResult(output=output, message=message, type=type).__repr__()
    # Verify
    assert actual_result == expected_result



# Generated at 2022-06-21 08:03:20.270080
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output=123, message=456, type=789)
    xml_element = test_result.get_xml_element()
    print(_pretty_xml(xml_element))
    assert xml_element.tag == 'testresult'
    assert 'message' in xml_element.attrib
    assert xml_element.attrib['message'] == '456'
    assert 'type' in xml_element.attrib
    assert xml_element.attrib['type'] == '789'
    assert xml_element.text == '123'



# Generated at 2022-06-21 08:03:25.845065
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    # Arrange
    test_case = TestCase(name='test_sample', classname='test_class')
    # Act
    result = test_case.get_attributes()
    # Assert
    expected = {
        'name': 'test_sample',
        'classname': 'test_class'
    }
    assert result == expected


# Generated at 2022-06-21 08:03:31.131946
# Unit test for constructor of class TestSuites
def test_TestSuites():
    p = TestSuites(name='name')
    assert p.name == 'name'
    assert p.suites == []
    assert p.disabled == 0
    assert p.errors == 0
    assert p.failures == 0
    assert p.tests == 0
    assert p.time == 0


# Generated at 2022-06-21 08:03:44.665161
# Unit test for constructor of class TestSuite
def test_TestSuite():
   Test_Suite_sample = TestSuite()
   Test_Suite_sample.name = "Test1"
   Test_Suite_sample.hostname = "Hostname1"
   Test_Suite_sample.id = "ID1"
   Test_Suite_sample.package = "Package1"
   Test_Suite_sample.timestamp = "2019-03-06T19:11:58"
   Test_Suite_sample.system_out = "systemout1"
   Test_Suite_sample.system_err = "systemerr1"
   assert Test_Suite_sample.name == "Test1"
   assert Test_Suite_sample.hostname == "Hostname1"
   assert Test_Suite_sample.id == "ID1"

# Generated at 2022-06-21 08:03:55.878809
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts1 = TestSuite(
        name='Complete',
        hostname='localhost',
        id='1',
        package='Test Suite',
        timestamp=datetime.datetime.now(),
        properties={'Version': '1.0', 'Branch': 'master'},
        system_out='Standard output',
        system_err='Standard error'
    )


# Generated at 2022-06-21 08:03:59.973514
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes() == {}

    result = TestResult(
        message='Message',
        type='Type',
    )

    assert result.get_attributes() == {
        'message': 'Message',
        'type': 'Type',
    }


# Generated at 2022-06-21 08:04:08.312187
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    ts1 = TestSuites()
    ts2 = TestSuites()
    ts1.suites.append(TestSuite('TestSuite1', 'host1', 'id1', 'package1', datetime.datetime.now()))
    ts1.suites.append(TestSuite('TestSuite2', 'host2', 'id2', 'package2', datetime.datetime.now()))
    ts2.suites.append(TestSuite('TestSuite1', 'host1', 'id1', 'package1', datetime.datetime.now()))
    ts2.suites.append(TestSuite('TestSuite2', 'host2', 'id2', 'package2', datetime.datetime.now()))
    assert ts1 == ts2

# Generated at 2022-06-21 08:04:11.535440
# Unit test for constructor of class TestSuites
def test_TestSuites():
	name = "test1"
	suites = []
	testSuites = TestSuites(name, suites)
	assert testSuites 


# Generated at 2022-06-21 08:04:15.887240
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testcase1 = TestCase('', '', '', '', 1, ['error1', 'error2'], ['failure1', 'failure2'])
    assert isinstance(testcase1, t.Dict[str, str])



# Generated at 2022-06-21 08:04:23.760543
# Unit test for constructor of class TestResult
def test_TestResult():
    # Test default values
    tr = TestResult()
    assert tr.output is None
    assert tr.message is None
    assert tr.type is None

    # Test values when set
    tr = TestResult("Output", "Message", "Type")
    assert tr.output == "Output"
    assert tr.message == "Message"
    assert tr.type == "Type"


# Generated at 2022-06-21 08:04:25.719133
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    expect = False
    error1 = TestError()
    error2 = TestError()
    assert error1.__eq__(error2) == expect


# Generated at 2022-06-21 08:04:38.064864
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Unit test for method get_xml_element of class TestCase"""
    test_case = TestCase(
        name='test name',
    )
    test_case.system_err = 'system err'
    test_case.system_out = 'system out'
    test_case.failures.append(TestFailure(
        message='failure message',
    ))

    test_case_element = test_case.get_xml_element()
    assert test_case_element.tag == 'testcase'
    assert test_case_element.attrib == {'name': 'test name'}
    assert len(test_case_element) == 3
    assert len(test_case_element.getchildren()) == 3


# Generated at 2022-06-21 08:04:40.709868
# Unit test for constructor of class TestFailure
def test_TestFailure():
    output='sample output'
    message='sample message'
    type='sample type'
    result=TestFailure(output, message, type)
    assert result.type == type


# Generated at 2022-06-21 08:05:22.758184
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Test with simple values
    TestResult(output='Test', message='Test Message').get_xml_element()

    # Test with valid values
    TestResult(output='Test', message='Test Message', type='test type').get_xml_element()

    # Test with invalid values
    # Type must be a string
    with pytest.raises(TypeError) as execinfo:
        TestResult(output='Test', message='Test Message', type=123).get_xml_element()
    assert 'Output attribute must be a string' in str(execinfo.value)



# Generated at 2022-06-21 08:05:23.886481
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert True == (True)

# Generated at 2022-06-21 08:05:28.118259
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    tc = TestCase(name='my_test_case', assertions=5)
    assert tc.get_attributes() == {
        'name': 'my_test_case',
        'assertions': '5'
    }


# Generated at 2022-06-21 08:05:36.841339
# Unit test for method __repr__ of class TestResult

# Generated at 2022-06-21 08:05:41.741329
# Unit test for constructor of class TestSuites
def test_TestSuites():   
    ts = TestSuites(name = 'suites name', suites = [TestSuite(name = 'suite name')])
    assert ts.name == 'suites name'
    assert ts.suites[0].name == 'suite name'
    return ts

# Generated at 2022-06-21 08:05:43.226322
# Unit test for constructor of class TestError
def test_TestError():
    assert TestError().type == "error"


# Generated at 2022-06-21 08:05:49.217166
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_case_name')
    xmltree = ET.ElementTree(test_case.get_xml_element())
    xmlstring = ET.tostring(xmltree, encoding='utf-8')
    assert xmlstring == b'<testcase name="test_case_name" />'


# Generated at 2022-06-21 08:05:54.166143
# Unit test for constructor of class TestFailure
def test_TestFailure():
    '''
    This function test the constructor of TestFailure by passing in 
    all the parameters.
    '''
    b = TestFailure('output', 'message', 'type')
    assert b.output == 'output'
    assert b.message == 'message'
    assert b.type == 'type'


# Generated at 2022-06-21 08:06:01.143558
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    print("TESTING TestResult.__repr__")
    output = "Hello World"
    message = "This is a message"
    type = "This is a type"
    data = TestResult(output=output, message=message, type=type)
    print("TestResult.__repr__: " + str(data))
    assert str(data) == "TestResult(output='Hello World', message='This is a message', type='This is a type')"


# Generated at 2022-06-21 08:06:05.419828
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert repr(TestSuites()).startswith('<JUnitXml.TestSuites object at 0x')
    assert repr(TestSuites(name='test')).startswith('<JUnitXml.TestSuites object at 0x')



# Generated at 2022-06-21 08:06:34.289631
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    TestSuites(name="Test", suites=[]) == TestSuites(name="Test", suites=[])

    TestSuites(name="Test", suites=[])

    TestSuites(name="Test", suites=[]) == TestSuites(name="Test", suites=[])

    TestSuites(name="Test", suites=[]) == TestSuites(name="Test", suites=[])

# Generated at 2022-06-21 08:06:37.557049
# Unit test for constructor of class TestSuite
def test_TestSuite():
    class_name = TestSuite('Testing class')
    assert class_name.name == 'Testing class'


# Generated at 2022-06-21 08:06:41.367929
# Unit test for constructor of class TestSuite
def test_TestSuite():
    timestamp = datetime.datetime.now()
    test_suite = TestSuite(name="Test", timestamp=timestamp)

    assert test_suite.name == "Test"
    assert test_suite.timestamp == timestamp


# Generated at 2022-06-21 08:06:48.596291
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase('name')
    assert tc.name == 'name'
    assert tc.assertions is None
    assert tc.classname is None
    assert tc.status is None
    assert tc.time is None
    assert tc.errors == []
    assert tc.failures == []
    assert tc.skipped is None
    assert tc.system_out is None
    assert tc.system_err is None
    assert tc.is_disabled is False


# Generated at 2022-06-21 08:06:50.959162
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    result1 = TestFailure()
    result2 = TestFailure()
    assert result1 == result2
    del result1
    del result2


# Generated at 2022-06-21 08:06:54.338577
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    inst = TestFailure(
        output='output',
        message='message',
        type='type',
    )

    assert repr(inst) == "TestFailure(output='output', message='message', type='type')"

# Generated at 2022-06-21 08:06:57.217215
# Unit test for constructor of class TestSuites
def test_TestSuites():
	with pytest.raises(Exception):
		testSuite = TestSuites()


# Generated at 2022-06-21 08:06:58.300638
# Unit test for constructor of class TestSuites
def test_TestSuites():
    TestSuites()


# Generated at 2022-06-21 08:07:08.629530
# Unit test for constructor of class TestFailure
def test_TestFailure(): 
    msg = 'foo'
    tp = 'bar'
    tcss = 'foo_class'
    output = 'baz'
    test_failure = TestFailure(message=msg, type=tp, output=output)
    assert(_attributes(message=msg, type=tp) == test_failure.get_attributes())
    assert(msg == test_failure.message)
    assert(output == test_failure.output)
    assert(tp == test_failure.type)
    assert(test_failure.get_xml_element().text == output)
    assert(test_failure.get_xml_element().tag =='failure')
    assert(test_failure.tag == 'failure')



# Generated at 2022-06-21 08:07:16.779826
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    testsuite = TestSuite("My Test Suite", "Hostname", "0", "Package0", datetime.datetime.now())
    kwargs = testsuite.get_attributes()
    assert(kwargs['disabled'] == str(0))
    assert(kwargs['hostname'] == "Hostname")
    assert(kwargs['id'] == "0")
    assert(kwargs['name'] == "My Test Suite")
    assert(kwargs['package'] == "Package0")
    assert(kwargs['skipped'] == str(0))
    assert(kwargs['tests'] == str(0))
    assert(kwargs['time'] == str(0))

# Generated at 2022-06-21 08:08:10.561173
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    testSuites = TestSuites()
    testSuites.name = 'testSuites1'
    testSuites.suites = [TestSuite()]
    assert testSuites.get_attributes() == {'name':'testSuites1', 'tests':0, 'disabled':0, 'errors':0, 'failures':0, 'time':0}

# Generated at 2022-06-21 08:08:13.995109
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    atributes = dict()
    atributes['name'] = 'test'
    suite = TestSuite('testsuite',**atributes)
    value = TestSuites('testsuites',[suite])
    assert value == value


# Generated at 2022-06-21 08:08:16.283306
# Unit test for constructor of class TestSuite
def test_TestSuite():
    assert TestSuite


# Generated at 2022-06-21 08:08:27.633841
# Unit test for constructor of class TestResult
def test_TestResult():

    with assert_raises(TypeError):
        x = TestResult()

    with assert_raises(TypeError):
        x = TestResult(output=1234)

    with assert_raises(TypeError):
        x = TestResult(output="1234", message=1234)

    with assert_raises(TypeError):
        x = TestResult(output="1234", message="1234", type=1234)

    try:
        x = TestResult(output="1234", message="1234", type="1234")
    except:
        raise AssertionError

    try:
        x = TestResult(output=None, message="1234", type="1234")
    except:
        raise AssertionError


# Generated at 2022-06-21 08:08:35.403155
# Unit test for constructor of class TestSuites
def test_TestSuites():
    test_suites = TestSuites()
    assert test_suites.name == None
    assert test_suites.suites == []
    assert test_suites.disabled == 0
    assert test_suites.errors == 0
    assert test_suites.failures == 0
    assert test_suites.tests == 0
    assert test_suites.time == 0
    assert test_suites.get_attributes() == {}
    print('Test TestSuites passed!')


# Generated at 2022-06-21 08:08:37.383552
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    suite = TestSuite(name='test name')
    assert repr(suite) == '<TestSuite(name=test name)>'

# Generated at 2022-06-21 08:08:41.432838
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    testResult = TestResult();
    testResult.output = 'output';
    testResult.message = 'message';
    testResult.type = 'type';
    assert testResult.__repr__() == 'TestResult(output=\'output\', message=\'message\', type=\'type\')'



# Generated at 2022-06-21 08:08:52.884059
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    class_name = 'TestSuites'
    method_name = 'to_pretty_xml'
    
    # Setup

# Generated at 2022-06-21 08:08:56.628497
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    testsuite1 = TestSuite("A")
    testsuite2 = TestSuite("A")
    assert testsuite1 == testsuite2
    testsuite2 = TestSuite("B")
    assert testsuite1 != testsuite2


# Generated at 2022-06-21 08:09:04.253525
# Unit test for method get_attributes of class TestSuites

# Generated at 2022-06-21 08:11:01.280299
# Unit test for constructor of class TestSuites
def test_TestSuites():
    try:
        assert TestSuites
        assert TestSuites.name
        assert TestSuites.suites
        assert TestSuites.disabled
        assert TestSuites.errors
        assert TestSuites.failures
        assert TestSuites.tests
        assert TestSuites.time
    except:
        print("test_TestSuites failed")
        raise


# Generated at 2022-06-21 08:11:02.893025
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    test_result = TestResult()

    assert test_result.type is None


# Generated at 2022-06-21 08:11:13.770207
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase('test_case_name')
    assert tc.name == 'test_case_name'
    assert tc.assertions is None
    assert tc.classname is None
    assert tc.status is None
    assert tc.time is None
    assert tc.errors is None
    assert tc.failures is None
    assert tc.skipped is None
    assert tc.system_out is None
    assert tc.system_err is None
    assert tc.is_disabled == False

    tc_2 = TestCase('another_test_case_name',
        1, 'test_class_name', 'success', decimal.Decimal(1),
        [TestError(), TestError()],
        [TestFailure(), TestFailure()],
        "Skipped reason", "System out output", "System err output", True
        )
    assert tc

# Generated at 2022-06-21 08:11:25.317750
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # 1. Arrange
    str_MockClassname = "MockClassname"
    str_MockName = "MockName"
    str_MockOutput = "MockOutput"
    str_MockSystemErr = "MockSystemErr"
    str_MockSystemOut = "MockSystemOut"
    str_MockType = "MockType"
    str_MockType2 = "MockType2"
    str_MockType3 = "MockType3"
    str_MockType4 = "MockType4"
    str_MockType5 = "MockType5"
    str_MockType6 = "MockType6"
    str_MockType7 = "MockType7"
    str_MockType8 = "MockType8"
   