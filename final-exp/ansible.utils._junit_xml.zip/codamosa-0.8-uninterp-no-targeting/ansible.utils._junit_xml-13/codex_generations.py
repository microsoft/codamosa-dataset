

# Generated at 2022-06-21 08:01:34.773642
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    from datetime import datetime

    test_suites = TestSuites()
    test_suite = TestSuite(name='test_suite', timestamp=datetime(2019, 1, 2, 3, 4, 5))
    test_suites.suites.append(test_suite)
    test_case = TestCase(name='test_case')
    test_case.errors.append(TestError(output='error_output'))
    test_case.failures.append(TestFailure(output='failure_output'))
    test_suite.cases.append(test_case)

    expected = '<TestSuites(disabled=0, errors=1, failures=1, name=None, tests=1, time=0.0)>'

    assert repr(test_suites) == expected

# Generated at 2022-06-21 08:01:47.318867
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_suites = TestSuites(name='Super test suites')
    test_suite1 = TestSuite(name='Super test suite', hostname='localhost', id='1')
    test_case1 = TestCase(name='Super test case', classname='SuperTest', status='EXECUTED', time=decimal.Decimal('1.7'))
    test_case1.errors.append(TestError(message='Super error', type='Super type', output='Super output'))
    test_suite1.cases.append(test_case1)
    test_suite2 = TestSuite(name='Super test suite two', hostname='localhost', id='2')
    test_suites.suites.append(test_suite1)
    test_suites.suites.append(test_suite2)

# Generated at 2022-06-21 08:01:56.211917
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:02:08.424144
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    p1 = TestSuite(name='TestSuite1', hostname='hostname1', id='id1', package='package1', timestamp=datetime.datetime.now())
    p2 = TestSuite(name='TestSuite2', hostname='hostname2', id='id2', package='package2', timestamp=datetime.datetime.now())
    p3 = TestSuite(name='TestSuite3', hostname='hostname3', id='id3', package='package3', timestamp=datetime.datetime.now())
    

# Generated at 2022-06-21 08:02:16.120603
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    testResult = TestResult(output='<![CDATA[Test1]]>', message = "Test1 message", type = 'Test type')
    x = testResult.get_xml_element()
    x = minidom.parseString(ET.tostring(x, encoding='unicode')).toprettyxml()
    print(x)
    assert x == '<?xml version="1.0" ?>\n<testResult message="Test1 message" type="Test type">&lt;![CDATA[Test1]]&gt;</testResult>\n', "TestResult get_xml_element Failed"


# Generated at 2022-06-21 08:02:22.639513
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    s = TestCase('test_name')
    assert repr(s) == 'TestCase(name=test_name, assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'


# Generated at 2022-06-21 08:02:28.540672
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    # Create test instance
    test_instance = TestCase(name="TestCase")
    # Create expected string
    expected = "TestCase(name='TestCase')"
    # Get actual string
    actual = test_instance.__repr__()
    # Assert that the actual string is equal to the expected string
    assert actual == expected


# Generated at 2022-06-21 08:02:36.939804
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    t1 = TestSuite(name="test_suite_1",hostname="hostname_1",id="id_1",package="package_1",timestamp=datetime.datetime.now())
    t2 = TestSuite(name="test_suite_1",hostname="hostname_1",id="id_1",package="package_1",timestamp=datetime.datetime.now())
    if t1 == t2:
        print("test_TestSuite___eq__: PASS")
    else:
        print("test_TestSuite___eq__: FAIL")
test_TestSuite___eq__()


# Generated at 2022-06-21 08:02:39.875772
# Unit test for constructor of class TestResult
def test_TestResult():
    assert TestResult().output == None
    assert TestResult().message == None
    assert TestResult().type == None


# Generated at 2022-06-21 08:02:44.789328
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    class Result(TestResult):
        @property
        def tag(self):
            return 'result'

    expected = '<result>output</result>'
    result = Result(output='output')
    assert ET.tostring(result.get_xml_element(), encoding='unicode') == expected


# Generated at 2022-06-21 08:03:08.638581
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    suite_kwargs = {
        'name': 'test_suites_name',
        'enabled': 1,
        'errors': 3,
        'failures': 4,
        'hostname': 'test_suites_hostname',
        'id': 'test_suites_id',
        'name': 'test_suites_name',
        'package': 'test_suites_package',
        'skipped': 5,
        'tests': 6,
        'time': 1.234,
        'timestamp': datetime.datetime.now()
    }
    suite = TestSuite(**suite_kwargs)
    result = suite.get_attributes()
    assert result['disabled'] == '1'
    assert result['errors'] == '3'
    assert result['failures'] == '4'
   

# Generated at 2022-06-21 08:03:17.924641
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name = "NX5",
                   hostname = "nx5.astro.rug.nl",
                   id = "123",
                   package = "nx5",
                   timestamp = datetime.datetime.now())
    properties = {"name": "value"}
    tc = TestCase(name = "test_name",
                  assertions = 1,
                  classname = "test_class",
                  status = "SUCCESS",
                  time =  0.0)
    ts.properties = properties
    ts.cases.append(tc)
    ts.system_err = "Error"
    ts.system_out = "Testing"

    assert ts.get_xml_element().tag == 'testsuite'
    assert ts.get_xml_element()[0].tag == 'properties'
    assert ts.get

# Generated at 2022-06-21 08:03:19.272354
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    suite = TestSuites()
    print(suite.get_attributes())

# Generated at 2022-06-21 08:03:26.356594
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    t1 = TestSuite(name='test', hostname='test', id='test', package='test', timestamp='test')
    t2 = TestSuite(name='test', hostname='test', id='test', package='test', timestamp='test')
    assert t1 == t2
    t3 = TestSuite(name='test', hostname='test4', id='test', package='test', timestamp='test')
    assert t1 != t3


# Generated at 2022-06-21 08:03:30.021137
# Unit test for constructor of class TestSuites
def test_TestSuites():
    ts = TestSuites(name='testSuites', suites=[])
    assert isinstance(ts, TestSuites)
    assert isinstance(ts.suites, t.List[TestSuite])


# Generated at 2022-06-21 08:03:30.918868
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    test_result = TestResult();
    assert(test_result.type == test_result.tag)



# Generated at 2022-06-21 08:03:40.827820
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    testcase = TestCase(name='test_foo')
    assert testcase.__repr__() == 'TestCase(name=\'test_foo\', assertions=None, classname=None, status=None, ' + \
        'time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, ' + \
        'is_disabled=False)'

    testcase = TestCase(name='test_foo', assertions=1)
    assert testcase.__repr__() == 'TestCase(name=\'test_foo\', assertions=1, classname=None, status=None, ' + \
        'time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, ' + \
        'is_disabled=False)'

    testcase = Test

# Generated at 2022-06-21 08:03:52.262881
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Returns a pretty formatted XML string representing this instance."""
    suites = TestSuites(name="suites.xml")
    suites.suites.append(TestSuite(name="suite1", hostname="localhost", timestamp=datetime.datetime.now()))
    suites.suites[0].cases.append(TestCase(name="case1", time=decimal.Decimal('25.3')))
    suites.suites[0].cases[0].errors.append(TestError(output="test error 1", message="error message 1", type="type1"))


# Generated at 2022-06-21 08:03:55.082838
# Unit test for constructor of class TestError
def test_TestError():
    error_msg="Error Message"
    test_error = TestError(error_msg)
    assert test_error.output == error_msg


# Generated at 2022-06-21 08:04:04.469157
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    file = 'test.py'
    tc1 = TestCase(name=file,
                   classname='test.py',
                   time=100,
                   status='toto')
    tc1_copy = TestCase(name=file,
                        classname='test.py',
                        time=100,
                        status='toto')
    tc1_diff = TestCase(name=file,
                        classname=file,
                        time=100,
                        status='toto')
    tc2 = TestCase(name=file + 'a',
                   classname='test.py',
                   time=100,
                   status='toto')
    tc3 = TestCase(name=file,
                   classname='test.py',
                   time=101,
                   status='toto')

# Generated at 2022-06-21 08:04:18.808207
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    '''TestResult: testing the method get_xml_element'''

    result = TestError(message='error', output='No error')
    element = result.get_xml_element()
    assert element.tag == 'error'
    assert element.text == 'No error'
    assert len(element.attrib) == 1
    assert element.attrib == {'message': 'error'}



# Generated at 2022-06-21 08:04:23.759896
# Unit test for constructor of class TestCase
def test_TestCase():
    testcase = TestCase(
        name="testCase 1",
        assertions=1,
        classname="testClass",
        status="PASSED",
        time=0.001
        )

    assert testcase.name == "testCase 1"
    assert testcase.assertions == 1
    assert testcase.classname == "testClass"
    assert testcase.status == "PASSED"
    assert testcase.time == 0.001


# Generated at 2022-06-21 08:04:25.648517
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    case = TestSuite(name='test')
    r = _attributes(**case.__dict__)
    assert r == {'name': 'test'}

# Generated at 2022-06-21 08:04:26.849270
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure('text') == TestFailure('text')


# Generated at 2022-06-21 08:04:31.885381
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    """Test for jenkins_junit/dataclasses.py test_TestResult___eq__()."""

    # Create two instances
    instance1 = TestResult()
    instance2 = TestResult()

    # Check that they are equal
    assert instance1 == instance2



# Generated at 2022-06-21 08:04:41.320818
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    from xml.etree import ElementTree as ET
    from datetime import datetime

    #test for with no param.
    test_result = TestFailure()
    assert test_result.get_xml_element() == ET.fromstring("<failure></failure>")

    #test for with one-param.
    test_result = TestFailure("this is a failure test")
    assert test_result.get_xml_element() == ET.fromstring("<failure>this is a failure test</failure>")

    #test for with two-param.
    test_result = TestFailure("this is a failure test", "this is an error message")
    assert test_result.get_xml_element() == ET.fromstring("<failure message=\"this is an error message\">this is a failure test</failure>")

    #test for

# Generated at 2022-06-21 08:04:44.143281
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    testSuites = TestSuites("name")
    assert repr(testSuites) == "TestSuites(name='name', suites=[])"



# Generated at 2022-06-21 08:04:54.747897
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    pkg1 = "package-1"
    id1 = "id-1"
    name1 = "name-1"
    hostname1 = "hostname-1"
    test1 = 10
    error1 = 3
    failure1 = 5
    skipped1 = 1
    ts1 = datetime.datetime.now().replace(microsecond=0)
    time1 = decimal.Decimal("3.14")
    properties1 = {"prop1":"value1", "prop2":"value2"}
    system_out1 = "stdout-1"
    system_err1 = "stderr-1"
    cases1 = [TestCase("testcase-1-1"), TestCase("testcase-1-2")]

    pkg2 = "package-2"
    id2 = "id-2"

# Generated at 2022-06-21 08:05:08.133669
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():

    # Positive test case: case 1
    test_case1 = TestCase(name='test1')
    test_case2 = TestCase(name='test1')
    assert test_case1 == test_case2

    # Positive test case: case 2
    test_case1 = TestCase(name='test1', classname='class1')
    test_case2 = TestCase(name='test1', classname='class1')
    assert test_case1 == test_case2

    # Positive test case: case 3
    test_case1 = TestCase(name='test1', classname='class1', time=1.23)
    test_case2 = TestCase(name='test1', classname='class1', time=1.23)
    assert test_case1 == test_case2

    # Negative test case: case 1
   

# Generated at 2022-06-21 08:05:19.138505
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    error = TestError(message = "Something is wrong",
                      type = "NotFound",
                      output = "No message found")
    test = TestCase(name = "My test case",
                    assertions = "5",
                    classname = "TestCase",
                    status = "OK",
                    time = "0.3")
    test.errors.append(error)
    xml = test.get_xml_element()
    assert ET.tostring(xml, encoding='unicode') == '<testcase assertions="5" classname="TestCase" name="My test case" status="OK" time="0.3"><error message="Something is wrong" type="NotFound">No message found</error></testcase>'


# Generated at 2022-06-21 08:05:30.795686
# Unit test for constructor of class TestFailure
def test_TestFailure():
    test_fail = TestFailure('Test!')
    assert test_fail.output == 'Test!'
    assert test_fail.tag == 'failure'
    assert test_fail.type == 'failure'
    assert test_fail.get_attributes() == {}


# Generated at 2022-06-21 08:05:38.204454
# Unit test for constructor of class TestCase
def test_TestCase():
    error = TestError(
        output = 'test.test_testcase.TestCaseFailed',
        message = 'Traceback (most recent call last):\n  File "test/test_testcase.py", line 36, in test_simple\n    raise TestCaseFailed()\n__main__.TestCaseFailed\n',
        type = 'TestError',
    )
    test_case = TestCase(
        name = 'test_simple',
        assertions = 0,
        classname = 'test.test_testcase.TestCaseTest',
        status = 'Successful',
        time = decimal.Decimal('0.125'),
    )
    test_case.errors.append(error)
    assert test_case.get_xml_element().tag == "testcase"
    assert test_case.get_xml_element

# Generated at 2022-06-21 08:05:47.176388
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    from datetime import datetime

    ts = TestSuite(name = 'name', timestamp = datetime(2020,1,1))
    attrb = ts.get_attributes()
    assert(attrb['errors'] == '0')
    assert(attrb['name'] == 'name')
    assert(attrb['timestamp'] == '2020-01-01T00:00:00')
    assert(attrb['time'] == '0.0')

    ts = TestSuite(name = 'name1', timestamp = datetime(2020,1,1))
    ts.cases = [ TestCase(
                        name = 'name1',
                        classname = 'classname1',
                        time = 5.4
                    )]
    ts.system_out = 'System output'
    attrb = ts.get_attributes()

# Generated at 2022-06-21 08:05:51.372858
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult('actual output', 'failure message', 'failure type')
    assert result.get_attributes() == {'message': 'failure message', 'type': 'failure type'}

# Generated at 2022-06-21 08:05:52.923708
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    result = TestFailure()
    assert result.type == 'failure'



# Generated at 2022-06-21 08:06:04.256355
# Unit test for method __eq__ of class TestSuite

# Generated at 2022-06-21 08:06:08.443009
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():

    from apitest import TestError

    # Arrange
    expected = "<TestError message=hello output=world>"

    # Act
    error = TestError(message="hello", output="world")
    result = error.__repr__()

    # Assert
    assert(result == expected)



# Generated at 2022-06-21 08:06:15.391501
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    # Create TestSuite
    test_suite = TestSuite(
        name='my-name',
    )
    # Check __repr__
    assert test_suite.__repr__().startswith('TestSuite(') is True
    # Check __repr__
    assert test_suite.__repr__().endswith(')') is True
    # Check __repr__
    assert test_suite.__repr__() == 'TestSuite(name=my-name, hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)'


# Generated at 2022-06-21 08:06:25.613958
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    def __eq__(self):
        """Returns True if all of the attributes match"""

        return self.name == other.name & self.assertions == other.assertions \
               & self.classname == other.classname & self.status == other.status \
               & self.time == other.time & self.errors == other.errors \
               & self.failures == other.failures & self.skipped == other.skipped \
               & self.system_out == other.system_out & self.system_err == other.system_err \
               & self.is_disabled == other.is_disabled

    assert "true"


# Generated at 2022-06-21 08:06:35.850576
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testcase_1 = TestCase(name="first_TestCase")
    testcase_2 = TestCase(name="second_TestCase")
    testcases = [testcase_1, testcase_2]
    testsuite_1 = TestSuite(name="TestSuite_1", timestamp="2020-09-08T12:00:00")
    testsuite_2 = TestSuite(name="TestSuite_2")
    testsuites = [testsuite_1, testsuite_2]
    for testcase in testcases:
        for testsuite in testsuites:
            testsuite.cases.append(testcase)
    root = ET.Element('testsuites')
    [root.append(testsuite.get_xml_element()) for testsuite in testsuites]

# Generated at 2022-06-21 08:06:46.943535
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_instance = TestFailure()
    expected_result = 'TestFailure(output=None, message=None, type=None)'
    assert test_instance.__repr__() == expected_result


# Generated at 2022-06-21 08:06:53.843154
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    error = TestError(message='Message', output='Output', type='Type')

    # Default case
    assert error == error

    # Not equal on message
    assert error != TestError(message='Not equal', output='Output', type='Type')

    # Not equal on output
    assert error != TestError(message='Message', output='Not equal', type='Type')

    # Not equal on type
    assert error != TestError(message='Message', output='Output', type='Not equal')


# Generated at 2022-06-21 08:07:00.115921
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    from xml.dom import minidom
    from xml.etree import ElementTree as ET
    expected_output = '<?xml version="1.0" ?><failure message="M" type="T">O</failure>'
    expected_element = ET.Element("failure", message="M", type="T")
    expected_element.text = "O"
    test_result = TestFailure("O", "M", "T")
    test_element = test_result.get_xml_element()
    test_output = ET.tostring(test_element, encoding='unicode')
    test_output = minidom.parseString(test_output).toprettyxml()
    assert test_output == expected_output


# Generated at 2022-06-21 08:07:02.195571
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    test = TestError()
    assert test.tag == 'error'
    assert test.type == 'error'

# Generated at 2022-06-21 08:07:12.226871
# Unit test for constructor of class TestError
def test_TestError():
    testSuite = TestSuite('testSuite')
    testSuite.failures = 1
    testCase = TestCase('testCase')
    testCase.failures = 1
    testCase.errors = 1
    testCase.errors.append(TestError(output='testErrorOutput'))
    testCase.failures.append(TestFailure(output='testFailureOutput'))
    testSuite.cases = [testCase]
    testSuites = TestSuites('testSuites')
    testSuites.suites = [testSuite]
    assert(testSuite.failures == 1)
    assert(testCase.errors == 1)
    assert(testCase.errors[0].output == 'testErrorOutput')
    assert(testCase.failures[0].output == 'testFailureOutput')

# Generated at 2022-06-21 08:07:17.487558
# Unit test for constructor of class TestCase
def test_TestCase():
    name = 'test'
    a = TestCase(name, 0, 'a', 'b', 1.1)
    assert a.name == name
    assert a.assertions == 0
    assert a.classname == 'a'
    assert a.status == 'b'
    assert a.time == 1.1
    assert a.output == None
    assert a.is_disabled == False


# Generated at 2022-06-21 08:07:24.212558
# Unit test for constructor of class TestSuite
def test_TestSuite():
    ts = TestSuite('CollectionsTest')
    ts = TestSuite('CollectionsTest', 'localhost')
    ts = TestSuite('CollectionsTest', 'localhost', 'i-12345')
    ts = TestSuite('CollectionsTest', 'localhost', 'i-12345', 'com.example')
    ts = TestSuite('CollectionsTest', 'localhost', 'i-12345', 'com.example', datetime.datetime.now())


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 08:07:29.870831
# Unit test for constructor of class TestResult
def test_TestResult():
    testResult = TestResult()
    assert testResult.output is None
    assert testResult.message is None
    assert testResult.type is None

    testResult = TestResult(output="some output", message="some message", type="some type")
    assert testResult.output == "some output"
    assert testResult.message == "some message"
    assert testResult.type == "some type"



# Generated at 2022-06-21 08:07:36.309451
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase(name='MyTest', assertions=10, classname='MyClass', status='PASSED', time=1.0)
    tc_xml = tc.get_xml_element()
    assert tc_xml.get('name') == 'MyTest'
    assert tc_xml.get('assertions') == '10'
    assert tc_xml.get('classname') == 'MyClass'
    assert tc_xml.get('status') == 'PASSED'
    assert tc_xml.get('time') == '1.0'
    tc_xml_out = tc_xml.find('system-out')
    assert tc_xml_out is None
    tc_xml_err = tc_xml.find('system-err')
    assert tc_xml_err is None


# Generated at 2022-06-21 08:07:47.313060
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-21 08:08:15.912751
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase(
        name="test_name",
        assertions=1,
        classname="test_classname",
        status="test_status",
        time=1.3,
        errors=[TestError(output="test_output", message="test_message", type="test_type")],
        failures=[TestFailure(output="test_output", message="test_message", type="test_type")],
        skipped="test_skipped",
        system_out="test_system_out",
        system_err="test_system_err",
        is_disabled=True
    )

# Generated at 2022-06-21 08:08:19.566184
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    a = TestCase('test_test')
    b = TestCase('test_test')
    c = TestCase('test_test1')
    assert a==b
    assert not a==c


# Generated at 2022-06-21 08:08:23.648717
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    # Arrange
    obj = TestFailure(output="test", message="test", type="test")
    # Act
    result = obj.__repr__()
    # Assert
    assert result == 'TestFailure(output="test", message="test", type="test")'


# Generated at 2022-06-21 08:08:27.846864
# Unit test for constructor of class TestFailure
def test_TestFailure():
    test_result = TestFailure(output="AAA", message="BBB", type="CCC")
    assert test_result.output == "AAA"
    assert test_result.message == "BBB"
    assert test_result.type == "CCC"


# Generated at 2022-06-21 08:08:35.611015
# Unit test for constructor of class TestCase
def test_TestCase():
    out = TestCase('name')
    assert out.name == 'name'
    assert out.assertions == None
    assert out.classname == None
    assert out.status == None
    assert out.time == None
    assert out.is_disabled == False
    assert out.errors == []
    assert out.failures == []
    assert out.skipped == None
    assert out.system_out == None
    assert out.system_err == None
    assert out.get_attributes() == {}
    


# Generated at 2022-06-21 08:08:45.533310
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    import datetime
    import decimal
    import typing as t

# Generated at 2022-06-21 08:08:52.431501
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case', assertions=1, classname='classname', status='status', time=1.1)
    test_suite = TestSuite(name='test_suite', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), cases=[test_case]);
    xml_element = test_suite.get_xml_element()
    assert True


# Generated at 2022-06-21 08:08:56.246053
# Unit test for constructor of class TestFailure
def test_TestFailure():
    err = TestFailure(
        type='test_failure',
        message='failure message',
        output='output of the failure')

    # print the xml element
    print(ET.tostring(err.get_xml_element(), encoding='unicode'))


# Generated at 2022-06-21 08:09:04.025732
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    # Create test objects
    testcase_1 = TestCase('Test 1', 'TestClass', 'passed',
                          10.0)
    testcase_2 = TestCase('Test 2', 'TestClass', 'passed',
                          10.0)
    testsuite = TestSuite('TestSuite', '12.34.56.78', 'id', 'package',
                          datetime.datetime(1969, 7, 21, 2, 56, 15, tzinfo=datetime.timezone.utc),
                          [testcase_1, testcase_2])

    # Compare attributes to expected values

# Generated at 2022-06-21 08:09:06.758841
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult();
    assert sorted(test_result.get_attributes().items()) == []


# Generated at 2022-06-21 08:09:42.033353
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # Initialized variables for testing
    suites = TestSuites(suites=[TestSuite(errors=1, failures=2, name="Test")])
    test = TestSuite(errors=1, failures=2, name="Test")
    # Testing
    assert suites.suites[0] == test


# Generated at 2022-06-21 08:09:49.456443
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite('My name', hostname = 'My host', id = 'My id', package = 'My package', properties = {'foo': 'bar'}, system_out = 'My system out', system_err = 'My system err')

# Generated at 2022-06-21 08:09:58.471476
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    suite = TestSuite(
        name='name',
        hostname='hostname',
        id='id',
        package='package',
        timestamp=datetime.datetime(year=2018, month=1, day=1, hour=0, minute=0, second=0, microsecond=0),
        properties={'key': 'value'},
        cases=[TestCase(name='name', assertions=1)],
        system_out='system_out',
        system_err='system_err'
    )
    assert repr(suite) == 'TestSuite(name=\'name\', hostname=\'hostname\', id=\'id\', properties={\'key\': \'value\'}, cases=[TestCase(name=\'name\', assertions=1)])'


# Generated at 2022-06-21 08:10:05.053573
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result1 = TestResult(
        output = 'simple string',
        message = 'simple string 2',
        type = 'simple string 3',
    ) 
    result1_xml = result1.get_xml_element()
    print(ET.tostring(result1_xml, encoding='unicode'))

    result2 = TestResult(
        output = 'simple string 4',
        message = 'simple string 5',
        type = 'simple string 6',
    ) 
    result2_xml = result2.get_xml_element()
    print(ET.tostring(result2_xml, encoding='unicode'))


# Generated at 2022-06-21 08:10:07.175104
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert repr(TestError('a', 'b', 'c')) == "TestError(output='a', message='b', type='c', tag='error')"


# Generated at 2022-06-21 08:10:11.501143
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # Given
    class TestResultSubclass(TestResult):
        tag = 'example'

    test_result = TestResultSubclass()

    # When
    result = test_result.__repr__()

    # Then
    assert isinstance(result, str)
    assert result == 'TestResultSubclass(message=None, output=None, type=\'example\')'


# Generated at 2022-06-21 08:10:18.894584
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    expected_result = '<testcase assertions="23" classname=".TestClass" name="test_method" status="RESOLVED" time="0.001234"/>'
    test_case = TestCase(name="test_method", assertions=23, classname=".TestClass", status="RESOLVED", time=0.001234)
    assert _pretty_xml(test_case.get_xml_element()) == expected_result


# Generated at 2022-06-21 08:10:23.754003
# Unit test for constructor of class TestFailure
def test_TestFailure():
    with pytest.raises(TypeError) as excinfo:
        assert None == TestFailure()
        assert None == TestError()
        assert None == TestCase()
        assert None == TestSuite()
        assert None == TestSuites()
    assert "__init__() missing 2 required positional arguments" in str(excinfo.value)

# Generated at 2022-06-21 08:10:30.152702
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    testsuite1 = TestSuite(name='testsuite1', hostname='hostname1', id='id1', package='package1', timestamp='timestamp1')
    testsuite1.cases.append(TestCase(name='testcase1', assertions='assertions1', classname='classname1', status='status1', time='time1'))
    testsuite1.cases.append(TestCase(name='testcase2', assertions='assertions2', classname='classname2', status='status2', time='time2'))
    testsuite2 = TestSuite(name='testsuite2', hostname='hostname2', id='id2', package='package2', timestamp='timestamp2')

# Generated at 2022-06-21 08:10:40.724763
# Unit test for method to_pretty_xml of class TestSuites