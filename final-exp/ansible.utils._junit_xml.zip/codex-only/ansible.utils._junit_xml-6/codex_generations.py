

# Generated at 2022-06-23 13:33:22.234182
# Unit test for constructor of class TestSuites

# Generated at 2022-06-23 13:33:31.022278
# Unit test for method get_attributes of class TestSuites

# Generated at 2022-06-23 13:33:41.886841
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError(output="error output", message="error message", type="type") == TestError(output="error output", message="error message", type="type")
    assert TestError(output=None, message="error message", type="type") == TestError(output=None, message="error message", type="type")
    assert not (TestError(output=None, message="error message", type="type") != TestError(output=None, message="error message", type="type"))
    assert TestError(output="error output", message=None, type="type") == TestError(output="error output", message=None, type="type")
    assert not (TestError(output="error output", message=None, type="type") != TestError(output="error output", message=None, type="type"))

# Generated at 2022-06-23 13:33:47.731851
# Unit test for constructor of class TestResult
def test_TestResult():
    expected_output = "Error message"
    expected_message = "Failure"
    expected_type = "FailureType"
    test = TestResult(expected_output, expected_message, expected_type)
    assert expected_output == test.output
    assert expected_message == test.message
    assert expected_type == test.type


# Generated at 2022-06-23 13:33:57.549781
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    ts = TestSuite('name')
    attr = ts.get_attributes()
    assert attr == {'name': 'name', 'tests': '0', 'time': '0.0'}

    ts = TestSuite('name', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now())
    attr = ts.get_attributes()
    assert 'name' in attr.keys()
    assert 'tests' in attr.keys()
    assert 'time' in attr.keys()
    assert 'hostname' in attr.keys()
    assert 'id' in attr.keys()
    assert 'package' in attr.keys()
    assert 'timestamp' in attr.keys()



# Generated at 2022-06-23 13:34:01.588474
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    classname = 'test_classname'
    expected_repr = f'TestCase(classname={classname!r})'
    test_case = TestCase(classname=classname)
    assert repr(test_case) == expected_repr


# Generated at 2022-06-23 13:34:10.436237
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suiteA = TestSuite(name="a", hostname="localhost", id="1", package="1", timestamp="2019-03-17T02:23+01:00", properties={"a": "1", "b": "2"}, cases=[TestCase(name="1", assertions="1", classname="1", status="1", time="1", errors=[TestError()], failures=[TestFailure()], skipped="1", system_out="1", system_err="1", is_disabled="1")], system_out="1", system_err="1")

# Generated at 2022-06-23 13:34:22.868742
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    """Test Suite XML code generation is correct."""
    x = TestSuite(
        name='Test',
        cases=[TestCase(
            name='TestCase',
            failures=[TestFailure(
                message='Message',
            )],
        )],
        errors=1,
        failures=1,
        tests=1,
    )

    test_xml = x.get_xml_element()
    expected_xml = ET.Element('testsuite', {
        'failures': '1',
        'tests': '1',
        'errors': '1',
        'name': 'Test',
    })

    test_case_xml = TestCase(
        name='TestCase',
        failures=[TestFailure(
            message='Message',
        )],
    )

    test_case_xml = test_case_xml.get

# Generated at 2022-06-23 13:34:31.651224
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    # Test that objects are equal if they are the same object.
    tc1 = TestCase("TestCase")
    assert tc1 == tc1

    # Test that objects are equal if all fields are identical.
    tc2 = TestCase("TestCase", assertions=1, classname="Name", status="pass", time=1.5)
    tc3 = TestCase("TestCase", assertions=1, classname="Name", status="pass", time=1.5)
    assert tc2 == tc3

    # Test that objects are not equal if one has an extra field.
    tc4 = TestCase("TestCase", assertions=1, classname="Name", status="pass", time=1.5, extra="foo")
    assert tc2 != tc4

    # Test that objects are not equal if fields are different.

# Generated at 2022-06-23 13:34:34.385478
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test = TestSuite(name = "test")
    test_suite = TestSuite(name = "test")
    assert (test == test_suite)

# Generated at 2022-06-23 13:34:37.092590
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    value_1 = TestSuites()
    value_2 = TestSuites()
    assert value_1 == value_2


# Generated at 2022-06-23 13:34:44.545521
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_case = TestCase(name = "TestCase", assertions = "3", classname = "class", 
    status = "status", time = datetime.datetime.now())
    test_suites = TestSuites(name = "TestSuites", suites = [TestSuite(name="TestSuite", hostname="hostname", 
    id="id", package="package", timestamp=datetime.datetime.now(), properties = {"a":"b", "c":"d"}, 
    cases=[test_case], system_out="system_out", system_err="system_err")])
    assert(test_suites.get_xml_element() is not None)


# Generated at 2022-06-23 13:34:45.520318
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    assert TestResult().type == 'testresult'


# Generated at 2022-06-23 13:34:48.237732
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    t1 = TestError(output="output", message="message", type="type")
    a1 = dict(message="message", type="type")
    assert t1.get_attributes() == a1

# Generated at 2022-06-23 13:34:55.115606
# Unit test for constructor of class TestCase
def test_TestCase():
    name = 'test1'
    classname = 'TestCase'
    assertions = 0
    status = 'pass'
    time = 0

    testcase = TestCase(name, assertions, classname, status, time)

    assert testcase.name == 'test1'
    assert testcase.assertions == 0
    assert testcase.classname == 'TestCase'
    assert testcase.status == 'pass'
    assert testcase.time == 0


# Generated at 2022-06-23 13:35:02.067020
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testcase1 = TestCase(name="test_case1", time=1, status="passed")
    testcase2 = TestCase(name="test_case2", time=2, status="failed")
    testcase3 = TestCase(name="test_case3", time=3, status="disabled")

    testsuite = TestSuite(name="test_suite1", time=6, tests=3, errors=2, disabled=1, failures=1)
    testsuite.cases.extend([testcase1, testcase2, testcase3])


# Generated at 2022-06-23 13:35:12.235415
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite = TestSuite('test')
    assert suite == suite
    # Attribute __dict__ is ignored
    assert suite == TestSuite(**suite.__dict__)
    assert suite == TestSuite(**suite.__dict__, name='test')
    assert suite != TestSuite(**suite.__dict__, name='test2')
    assert suite != TestSuite(**suite.__dict__, name='test', hostname='hostname')
    assert suite != TestSuite(**suite.__dict__, name='test', id='1')
    assert suite != TestSuite(**suite.__dict__, name='test', package='test')

# Generated at 2022-06-23 13:35:20.540416
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    expected_xml = """\
<?xml version="1.0" ?>
<testsuites errors="0" failures="2" tests="2" time="0.01"/>
"""
    test = TestSuites()
    test.suites.append(TestSuite(
        name='test_suite_1',
        errors=0,
        failures=1,
        tests=1,
        time=decimal.Decimal('0.01'),
    ))
    test.suites.append(TestSuite(
        name='test_suite_2',
        errors=0,
        failures=1,
        tests=1,
    ))
    assert test.to_pretty_xml() == expected_xml

# Generated at 2022-06-23 13:35:25.884485
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase('test_name')
    assert test_case.__repr__() == 'TestCase(assertions=None, classname=None, errors=[], failures=[], name=\'test_name\', skipped=None, status=None, system_err=None, system_out=None, time=None)'


# Generated at 2022-06-23 13:35:35.423053
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError(message="Message",output="Output",type="Type") == TestError(message="Message",output="Output",type="Type")
    assert TestError(message="Message",output="Output",type="Type") != TestError(message="Message",output="Wrong",type="Wrong")
    assert TestError(message="Message",output="Output",type="Type") != TestError(message="Message",output="Output",type="Wrong")
    assert TestError(message="Message",output="Output",type="Type") != TestError(message="Wrong",output="Wrong",type="Wrong")
    assert TestError(message="Message",output="Output",type="Type") != TestError(message="Message",output="Wrong",type="Type")

# Generated at 2022-06-23 13:35:40.747456
# Unit test for constructor of class TestCase
def test_TestCase():
    assert TestCase('testCaseName')
    assert TestCase('testCaseName', 123)
    assert TestCase('testCaseName', 123, 'testClassName')
    assert TestCase('testCaseName', 123, 'testClassName', 'status')
    assert TestCase('testCaseName', 123, 'testClassName', 'status', 123.123)

# Generated at 2022-06-23 13:35:41.885012
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
  TestError()



# Generated at 2022-06-23 13:35:50.362636
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-23 13:35:52.302161
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    test_class = TestError()
    assert test_class == TestError(), "Test has failed"


# Generated at 2022-06-23 13:35:53.726409
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    test = TestResult()
    assert test.type == 'result'

# Generated at 2022-06-23 13:35:55.027802
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output='hello world')
    assert result.get_xml_element().text == 'hello world'


# Generated at 2022-06-23 13:36:08.477542
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    name = "TestLink XML Results Exporter"
    # Time is in milliseconds (as per XML schema)
    time = 4000
    disabled = 1
    errors = 2
    failures = 3
    tests = 10
    test_suite = TestSuite(
        name="TestLink XML Results Exporter",
        tests=tests
    )
    test_suite.failures = failures
    test_suite.errors = errors
    test_suite.disabled = disabled
    test_suite.time = time
    test_suites = TestSuites(name=name)
    test_suites.suites.append(test_suite)
    result = test_suites.get_attributes()
    assert result["name"] == name
    assert result["time"] == str(time)
    assert result["disabled"] == str(disabled)

# Generated at 2022-06-23 13:36:13.017218
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # "testsuite" element attributes
    t_name = "MyTestSuite"
    t_id = "123"
    t_package = "testsuite"
    t_timestamp = datetime.datetime.now().isoformat(timespec='seconds')
    t_hostname = "host1"
    t_tests = "4"
    t_failures = "0"
    t_disabled = "1"
    t_errors = "0"
    t_time = "2.0"

    # "testcase" element attributes
    tc_name = "MyTestCase"
    tc_classname = "testcase"
    tc_status = "RUN"
    tc_time = "1.0"
    tc_assertions = "4"

    # "failure" element attributes
    f_message

# Generated at 2022-06-23 13:36:20.343572
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    from unittest.mock import patch
    mock_cls_attr = patch.object(TestResult, 'tag', 'mock_tag')

    with mock_cls_attr:
        # Call __repr__()
        result = TestResult('mock_output', 'mock_message', 'mock_type')
        repr_reuslt = result.__repr__()

    # Verify the result
    assert repr_reuslt == 'TestResult(output=\'mock_output\', message=\'mock_message\', type=\'mock_type\')'


# Generated at 2022-06-23 13:36:29.374576
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite = TestSuite(name="MyDummyTestSuite", cases=[None], properties={"cluster": "myCluster"})

    assert suite == suite
    assert suite == TestSuite(name="MyDummyTestSuite", cases=[None], properties={"cluster": "myCluster"})
    assert suite != TestSuite(name="MyDummyTestSuite", cases=[None])
    assert suite != TestSuite(name="MyDummyTestSuite", cases=[None], properties={"dummy": "dummy"})
    assert suite != TestSuite(name="MyDummyTestSuite", cases=[None], properties={"dummy": "myCluster"})

# Generated at 2022-06-23 13:36:30.838734
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert(result.get_xml_element() == None)


# Generated at 2022-06-23 13:36:38.483625
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testCase = TestCase(name = 'test', assertions = '1', classname = 'com.example.testing.Test', status = 'passed', time = '0.01')

    if (testCase.get_attributes() != {'assertions': '1', 'classname': 'com.example.testing.Test', 'name': 'test', 'status': 'passed', 'time': '0.01'}):
        raise Exception('Error! Function get_attributes for class TestCase is wrong!')

# Generated at 2022-06-23 13:36:43.507254
# Unit test for constructor of class TestCase
def test_TestCase():
    test = TestCase("Test", assertions=1, classname="Class", status="pass")
    assert test.name == "Test"
    assert test.assertions == 1
    assert test.classname == "Class"
    assert test.status == "pass"

# Generated at 2022-06-23 13:36:47.912247
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test_suites = TestSuites(name='test')

    assert test_suites.get_attributes() == {'disabled': '0', 'errors': '0', 'failures': '0', 'name': 'test', 'tests': '0', 'time': '0'}



# Generated at 2022-06-23 13:36:50.468720
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    tc = TestCase(name='fn_name')
    assert f'{tc}' == '<TestCase name: fn_name>'



# Generated at 2022-06-23 13:37:00.749399
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_name', classname='test_classname', time=decimal.Decimal('10.5'))
    test_case.failures.append(TestFailure(output='failure_output1'))
    test_case.failures.append(TestFailure(output='failure_output2'))
    test_case.errors.append(TestError(output='error_output1'))
    test_case.errors.append(TestError(output='error_output2'))
    test_case.skipped = 'skipped'
    test_case.system_out = 'system_out'
    test_case.system_err = 'system_err'

    xml_element = test_case.get_xml_element()

# Generated at 2022-06-23 13:37:05.022513
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    error = TestError(output='Error', message='Test Error', type='error')
    assert _attributes(message='Test Error', type='error') == error.get_attributes()



# Generated at 2022-06-23 13:37:14.984738
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_suites = TestSuites(name='MyTestSuites')
    test_suite = TestSuite(name='TestSuite1')
    test_suite.cases.append(TestCase(name='TestCase1', time=1.23))
    test_suite.cases.append(TestCase(name='TestCase2', time=0.1))
    test_suites.suites.append(test_suite)
    test_suite = TestSuite(name='TestSuite2')
    test_suite.cases.append(TestCase(name='TestCase3', time=1.234))
    test_suites.suites.append(test_suite)


# Generated at 2022-06-23 13:37:24.291425
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    """Test Case of method __repr__"""
    # Setup
    parameters = {"name": "test_TestCase_repr_1", "output": "This is testcase", "assertions": 10, "classname": "foo.test", "status": "STATUS", "time": 4.6, "is_disabled": True, "errors": [TestError(type = "error", message="Error Message", output = "error")], "failures": []}
    test_case = TestCase(**parameters)
    # Exercise and Verify

# Generated at 2022-06-23 13:37:29.494310
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    obj1 = TestSuite(
            name = "suite1"
        )
    obj2 = TestSuite(
            name = "suite1"
        )
    assert obj1 == obj2
    # assert obj1 != obj2
    return


# Generated at 2022-06-23 13:37:40.874725
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    classname = 'classname'
    error = TestError(output='error output', message='error message', type='error type')
    failure = TestFailure(output='failure output', message='failure message', type='failure type')
    name = 'name'
    system_err = 'system err'
    system_out = 'system out'
    skipped = 'skipped'
    status = 'status'
    package = 'package'
    time = decimal.Decimal('1.23456')
    timestamp = datetime.datetime(1970, 1, 2, 3, 4, 5, 678901)

    case = TestCase(classname=classname, name=name, status=status, time=time)
    case.errors = [error]
    case.failures = [failure]
    case.skipped = skipped
   

# Generated at 2022-06-23 13:37:43.657751
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    TestSuites.__eq__(TestSuites.__new__(TestSuites), TestSuites.__new__(TestSuites))
    # test for instance method of class TestSuites


# Generated at 2022-06-23 13:37:46.011183
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
  #t = TestResult()
  test_result = TestResult()
  result = test_result.get_attributes()
  assert result == None


# Generated at 2022-06-23 13:37:53.322008
# Unit test for constructor of class TestError
def test_TestError():
    te = TestError("message", "output", "type")
    assert te.message == "message"
    assert te.output == "output"
    assert te.type == "type"
    te = TestError()
    assert te.message is None
    assert te.output is None
    assert te.type is None


# Generated at 2022-06-23 13:38:01.417548
# Unit test for method __eq__ of class TestSuites

# Generated at 2022-06-23 13:38:11.292789
# Unit test for method __eq__ of class TestCase

# Generated at 2022-06-23 13:38:17.029366
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    suite = TestSuite(name='my-name')
    assert repr(suite) == "TestSuite(name='my-name', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)"


# Generated at 2022-06-23 13:38:24.625514
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Case 1
    testResult = TestResult('output', 'message', 'type')
    expected_output = {'message': 'message', 'type': 'type'}
    output = testResult.get_attributes()
    assert output == expected_output
    # Case 2
    testResult = TestResult('output', 'message', 'type')
    expected_output = {'message': 'message', 'type': 'type'}
    output = testResult.get_attributes()
    assert output == expected_output
    # Case 3
    testResult = TestResult()
    expected_output = {}
    output = testResult.get_attributes()
    assert output == expected_output


# Generated at 2022-06-23 13:38:35.631633
# Unit test for constructor of class TestSuite
def test_TestSuite():
    name = 'TestSuite'
    hostname = 'localhost'
    id = '12345'
    package = 'test'
    time = decimal.Decimal('0.01')

    cases = [TestCase(name='TestCase', classname='TestClass', time=time),
             TestCase(name='TestCase2', classname='TestClass2', time=time)]

    suite = TestSuite(name, hostname, id, package, time, cases)
    assert suite.name == name
    assert suite.hostname == hostname
    assert suite.id == id
    assert suite.package == package
    assert suite.time == time
    assert suite.cases == cases
    assert suite.disabled == 0
    assert suite.errors == 0
    assert suite.failures == 0
    assert suite.skipped == 0

# Generated at 2022-06-23 13:38:39.807432
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    ins = TestResult(output = 'output',
                     message = 'message',
                     type = 'type')
    assert str(ins) == 'TestResult(output=output, message=message, type=type)'

# Generated at 2022-06-23 13:38:50.064591
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    case = TestCase('test')
    assert repr(case) == 'TestCase(name=test, assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'

    case = TestCase('test', assertions=1)
    assert repr(case) == 'TestCase(name=test, assertions=1, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'

    case = TestCase('test', classname='foo')

# Generated at 2022-06-23 13:38:54.036618
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    r = TestError()
    if r.type != "error":
        raise AssertionError("Failed")


# Generated at 2022-06-23 13:38:57.239606
# Unit test for constructor of class TestResult
def test_TestResult():
    tr = TestResult(output="OUTPUT", message="MESSAGE", type="TYPE")
    assert tr.output == "OUTPUT"
    assert tr.message == "MESSAGE"
    assert tr.type == "TYPE"


# Generated at 2022-06-23 13:39:00.751096
# Unit test for constructor of class TestSuites
def test_TestSuites():
    test = TestSuites()
    assert test.name is None
    assert isinstance(test.suites, t.List)


# Generated at 2022-06-23 13:39:04.565735
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    fail = TestFailure(output="output", message="message", type="type")
    assert repr(fail) == "TestFailure(output='output', message='message', type='type')"


# Generated at 2022-06-23 13:39:17.975563
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-23 13:39:22.496359
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure(output='failure output', message='failure message', type="failure type") == TestFailure(output='failure output', message='failure message', type="failure type")



# Generated at 2022-06-23 13:39:26.905150
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testcase = TestCase(name="test_get_attributes", time=1.0, classname="TestCase", status="End")
    assert testcase.get_attributes() == {"assertions": None, "classname": "TestCase", "name": "test_get_attributes", "status": "End", "time": "1.0"}


# Generated at 2022-06-23 13:39:29.553304
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase('foo_test', assertions=1)
    assert tc.name == 'foo_test'
    assert tc.assertions == 1


# Generated at 2022-06-23 13:39:35.200418
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase('Testing', classname='TestClass', assertions=5,
            status='Failed', time='10.0')
    assert test_case.get_attributes() == {'name': 'Testing',
            'classname': 'TestClass', 'assertions': '5', 'status': 'Failed',
            'time': '10.0'}

# Generated at 2022-06-23 13:39:40.386889
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    result = TestFailure(output='spam')
    assert result.__repr__() == "<TestFailure output='spam'>"

    result.message = 'eggs'
    result.type = 'ham'
    assert result.__repr__() == "<TestFailure message='eggs' output='spam' type='ham'>"



# Generated at 2022-06-23 13:39:44.291135
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_case_failure1 = TestFailure(output='output', message='message', type='type')
    assert test_case_failure1.__repr__() == "<TestFailure output='output', message='message', type='type'>"

    test_case_failure2 = TestFailure()
    assert test_case_failure2.__repr__() == "<TestFailure output=None, message=None, type=failure>"


# Generated at 2022-06-23 13:39:51.607725
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a = TestSuites()

    b = TestSuites()
    assert a == b

    b = TestSuites(suites=[
        TestSuite(name="testsuite1"),
        TestSuite(name="testsuite2"),
    ])
    assert a != b

    a = TestSuites(suites=[
        TestSuite(name="testsuite1"),
    ])
    assert a != b

# Generated at 2022-06-23 13:39:53.543317
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    assert repr(TestSuite('test')).startswith('TestSuite(name=')

# Generated at 2022-06-23 13:40:00.618839
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    TestSuite1 = TestSuite(name='TestSuite1', timestamp='2020-02-11T09:30:00-00:00', hostname='localhost')
    assert TestSuite1.__repr__() == 'TestSuite(name=\'TestSuite1\', hostname=\'localhost\', timestamp=datetime.datetime(2020, 2, 11, 9, 30, tzinfo=datetime.timezone.utc), cases=[], properties={}, errors=0, failures=0, skipped=0, tests=0, time=0, disabled=0)'

# Generated at 2022-06-23 13:40:04.467206
# Unit test for constructor of class TestSuites
def test_TestSuites():
    """
    Make a new TestSuites and check that all attrs are properly assigned.
    """
    suites = TestSuites(name="TestSuites name")

    assert suites.name == "TestSuites name"
    assert isinstance(suites.suites, list)


# Generated at 2022-06-23 13:40:10.884357
# Unit test for constructor of class TestSuites
def test_TestSuites():
    suites = TestSuites('TestSuites')
    assert suites.name == 'TestSuites'
    assert suites.suites == []
    assert suites.disabled == 0
    assert suites.errors == 0
    assert suites.failures == 0
    assert suites.tests == 0
    assert suites.time == 0

# Generated at 2022-06-23 13:40:21.069459
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-23 13:40:24.047620
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite1 = TestSuite(name='test suite')
    suite2 = TestSuite(name='test suite')

    assert suite1 == suite2


# Generated at 2022-06-23 13:40:34.902747
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    import pytest
    import xml.etree.ElementTree as ET
    import re


# Generated at 2022-06-23 13:40:44.020325
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testcase = TestCase('testcase1', classname = "class1")
    suite = TestSuite('suite1', id = "1")
    suite.cases.append(testcase)

    expected = '<testsuite disabled="0" errors="0" failures="0" hostname="None" id="1" name="suite1" package="None" skipped="0" tests="1" time="0.0" timestamp="None"><testcase assertions="None" classname="class1" name="testcase1" status="None" time="None"></testcase></testsuite>'
    assert _pretty_xml(suite.get_xml_element()) == expected


# Generated at 2022-06-23 13:40:46.777066
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    a = TestError()
    b = TestError()
    assert a == b


# Generated at 2022-06-23 13:40:57.535158
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    time1 = decimal.Decimal(1)
    time2 = decimal.Decimal(2)

    test_case1 = TestCase(name="t1", time=time1)
    test_case2 = TestCase(name="t2", time=time2)

    test_suite = TestSuite(
        name="First test suite",
        id=1,
        hostname="localhost",
        cases=[test_case1, test_case2],
        timestamp=datetime.datetime(2019, 9, 8, 0, 0, 31),
        system_out='system-out',
        system_err='system-err',
    )

    repr = test_suite.__repr__()

# Generated at 2022-06-23 13:41:01.795235
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError('message','type','output')
    
    assert(error.message == 'message')
    assert(error.type == 'type')
    assert(error.output == 'output')


# Generated at 2022-06-23 13:41:02.481093
# Unit test for constructor of class TestCase
def test_TestCase():
  assert True

# Generated at 2022-06-23 13:41:04.254106
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    suites = TestSuites()
    assert suites.to_pretty_xml() == '<testsuites />\n'

# Generated at 2022-06-23 13:41:07.282790
# Unit test for constructor of class TestFailure
def test_TestFailure():
    new = TestFailure(output = '3.1', message = 'hello', type = 'hello')
    assert new.output == '3.1'
    assert new.message == 'hello'
    assert new.type == 'hello'


# Generated at 2022-06-23 13:41:15.536452
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    list1 = []
    list2 = []
    list3 = []
    list4 = []
    list5 = []
    list6 = []
    list7 = []
    list8 = []
    list9 = []
    list10 = []
    list11 = []
    list12 = []
    list13 = []
    suites = TestSuites(list1, list2, list3, list4, list5, list6, list7, list8, list9, list10, list11, list12, list13)
    suites.get_attributes()


# Generated at 2022-06-23 13:41:19.302842
# Unit test for constructor of class TestFailure
def test_TestFailure():
    result = TestResult("", "", "", None)
    assert isinstance(result, TestResult)

    error_tag = result.tag

    assert error_tag == 'error'

if __name__ == '__main__':
    test_TestFailure()

# Generated at 2022-06-23 13:41:23.264441
# Unit test for constructor of class TestSuites
def test_TestSuites():
    assert TestSuites(name='test name', suites=[TestSuite('test suite')])
    assert TestSuites(name='test name')
    assert not TestSuites()


# Generated at 2022-06-23 13:41:26.162788
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    test_suites = TestSuites()
    assert str(test_suites) == 'TestSuites(name=None, suites=[])'

# Generated at 2022-06-23 13:41:28.926169
# Unit test for constructor of class TestError
def test_TestError():
    result = TestError()

    assert result.output is None
    assert result.message is None
    assert result.type is None



# Generated at 2022-06-23 13:41:37.808293
# Unit test for constructor of class TestSuite
def test_TestSuite():
    testSuite = TestSuite(name='name', hostname='hostname', id='id', package='package', timestamp=datetime.datetime.now(), properties={'key':'value'}, cases=[], system_out='system_out', system_err='system_err')
    assert testSuite.name == 'name'
    assert testSuite.hostname == 'hostname'
    assert testSuite.id == 'id'
    assert testSuite.package == 'package'
    assert testSuite.timestamp == datetime.datetime.now()
    assert testSuite.properties['key'] == 'value'
    assert not testSuite.cases
    assert testSuite.system_out == 'system_out'
    assert testSuite.system_err == 'system_err'

# Generated at 2022-06-23 13:41:41.018602
# Unit test for constructor of class TestSuites
def test_TestSuites():
    ts = TestSuites()
    assert ts.name == None
    #assert ts.suites == list()
    assert ts.tests == 0
    assert ts.time == 0


# Generated at 2022-06-23 13:41:43.213656
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    tr1 = TestFailure(type='t')
    tr2 = TestFailure(type='t')
    assert tr1 == tr2

# Generated at 2022-06-23 13:41:55.071362
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    # Checks if the method __repr__ of class TestCase is working correctly
    from src.test.test_junit import TestCase
    t1 = TestCase('Test Method')
    assert t1.__repr__() == 'TestCase(name="Test Method", assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'
    t1 = TestCase('Test Method', 10, 'Class', 'PASS', '10.0')

# Generated at 2022-06-23 13:41:59.029316
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    expected = 'TestFailure(output=None, message=None, type=None)'
    actual = TestFailure.__repr__()
    assert expected == actual


# Generated at 2022-06-23 13:42:04.214630
# Unit test for constructor of class TestSuite
def test_TestSuite():
    t1 = TestSuite("Jack", hostname="Mac", id="123", package="test", timestamp=datetime.datetime.now())
    t1.properties = {"a": "b"}
    t1.cases.append(TestCase("Amy"))
    t1.cases.append(TestCase("Bob"))
    t1.cases.append(TestCase("Chris"))
    t1.cases.append(TestCase("Diana"))
    t1.system_out = "output"
    t1.system_err = "err"
    assert t1.name == "Jack"
    assert t1.hostname == "Mac"
    assert t1.id == "123"
    assert t1.package == "test"
    assert t1.timestamp
    assert t1.properties
    assert t1.cases
    assert t1

# Generated at 2022-06-23 13:42:09.609027
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    """Test method TestCase.__repr__."""
    assert repr(TestCase('a')) == "TestCase(name='a', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"


# Generated at 2022-06-23 13:42:18.514174
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    some_test_case = TestCase(name="test",
                              assertions=2,
                              classname="a",
                              status="passed",
                              time=decimal.Decimal("5.5"))

    # Testing the case when the input contains None
    assert some_test_case.get_attributes() == \
        {'assertions': '2', 'classname': 'a', 'name': 'test', 'status': 'passed', 'time': '5.5'}

    # Testing the case when the input is empty
    some_test_case.assertions = None
    assert some_test_case.get_attributes() == \
        {'classname': 'a', 'name': 'test', 'status': 'passed', 'time': '5.5'}



# Generated at 2022-06-23 13:42:24.337052
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    testsuites = TestSuites() # name=None
    assert testsuites.get_attributes() == {} # expected: empty dictionary

    testsuites = TestSuites(name='TestSuitesName')
    assert testsuites.get_attributes() == {'name': 'TestSuitesName'} # expected: name is 'TestSuitesName'



# Generated at 2022-06-23 13:42:31.538670
# Unit test for method __eq__ of class TestSuite

# Generated at 2022-06-23 13:42:42.211031
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    suite = TestSuite('pytest')
    assert str(suite) == "TestSuite(name='pytest', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)"

    suite = TestSuite('pytest', 'localhost', '1.0.0', 'Package Name', datetime.datetime.now(), dict(), [], 'system_out', 'system_err')
    assert str(suite) == "TestSuite(name='pytest', hostname='localhost', id='1.0.0', package='Package Name', timestamp=%s, properties={}, cases=[], system_out='system_out', system_err='system_err')" % suite.timestamp



# Generated at 2022-06-23 13:42:53.158354
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    message = 'testmessage'
    output = 'testoutput'
    type = 'testtype'
    exceptiontype = 'TestException'
    errorexceptionmessage = 'error exception message'
    errorexception = Exception(errorexceptionmessage)

    result = TestResult(output, message, type)
    _check_TestResult___repr__(result, message, output, type)

    result = TestResult(output, message)
    _check_TestResult___repr__(result, message, output, result.tag)

    result = TestResult(output)
    _check_TestResult___repr__(result, None, output, result.tag)



# Generated at 2022-06-23 13:43:01.438905
# Unit test for constructor of class TestSuite
def test_TestSuite():
    # Test successful construction
    test_suite = TestSuite(name = 'test_suite')
    assert test_suite.name == 'test_suite'

    # Test unsuccessful construction
    try:
        test_suite = TestSuite(name = None)
    except TypeError:
        assert True
        test_suite = TestSuite(name = "new_name")
    else:
        assert False

    # Test successful construction
    test_suite = TestSuite(name = 'test_suite', hostname = 'test_suite_hostname', id = 'test_suite_id', package = 'test_suite_package', timestamp = datetime.datetime(2020,7,28,18,0))
    assert test_suite.name == 'test_suite'
    assert test_suite

# Generated at 2022-06-23 13:43:05.328439
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    testFailure1 = TestFailure(output="output", message="message", type="type")
    testFailure2 = TestFailure(output="output", message="message", type="type")

    assert testFailure1 == testFailure2


# Generated at 2022-06-23 13:43:06.276848
# Unit test for constructor of class TestError
def test_TestError():
    test_error = TestError("lala")
    assert test_error.tag == "error"

# Generated at 2022-06-23 13:43:11.320648
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    # Setup
    data = {"message": "test_message", "output": "test_output", "type": "test_type"}
    # Exercise
    obj = TestFailure(**data)
    # Verify
    assert obj.message == data["message"]
    assert obj.output == data["output"]
    assert obj.type == data["type"]
    # Cleanup - none necessary



# Generated at 2022-06-23 13:43:16.174632
# Unit test for constructor of class TestCase
def test_TestCase():
	test_case = TestCase('myname', 1, 'myclassname', 'mystatus', 3.2)
	assert test_case.name == 'myname'
	assert test_case.assertions == 1
	assert test_case.classname == 'myclassname'
	assert test_case.status == 'mystatus'
	assert test_case.time == 3.2
