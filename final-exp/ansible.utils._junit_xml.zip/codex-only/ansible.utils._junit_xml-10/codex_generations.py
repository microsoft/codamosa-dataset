

# Generated at 2022-06-23 13:33:20.796017
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    # Arrange
    class Test:
        def __eq__(self, other):
            return isinstance(other, Test)
    test_result = Test()

    # Act
    obj_1 = TestFailure(test_result, test_result, test_result)
    obj_2 = TestFailure(test_result, test_result, test_result)

    # Assert
    assert obj_1 == obj_2


# Generated at 2022-06-23 13:33:22.762917
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    tf = TestFailure()
    te = TestError()
    assert tf.type == 'failure'
    assert te.type == 'error'

# Generated at 2022-06-23 13:33:24.954909
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    ts = TestSuites(suites=[])
    expected = {}
    assert ts.get_attributes() == expected


# Generated at 2022-06-23 13:33:32.646393
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-23 13:33:36.664182
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult('test_output', 'test_message', 'test_type')
    assert result.output=='test_output'
    assert result.message=='test_message'
    assert result.type=='test_type'


# Generated at 2022-06-23 13:33:38.925202
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    tc1 = TestCase('test_case_name')
    tc2 = TestCase('test_case_name')

    assert tc1 == tc2


# Generated at 2022-06-23 13:33:40.922852
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure(output=None, message=None, type=None) == TestFailure(output=None, message=None, type=None)



# Generated at 2022-06-23 13:33:44.216635
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    failure1 = TestFailure()
    failure2 = TestFailure()
    assert failure1 == failure2
    assert id(failure1) != id(failure2)



# Generated at 2022-06-23 13:33:49.287664
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # Arrange
    my_TestSuites = TestSuites(
        name = 'test'
    )

    # Act
    result = my_TestSuites.__repr__()

    # Assert
    assert isinstance(result, str)
    assert result != ''


# Generated at 2022-06-23 13:33:52.286595
# Unit test for constructor of class TestSuite
def test_TestSuite():
    "This function is used to test whether the class TestSuite has been initialized successfully"
    suite = TestSuite('TestSuite')
    assert len(suite.properties) == 0
    assert len(suite.cases) == 0



# Generated at 2022-06-23 13:34:03.264692
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    class TestClass:
        def __repr__(self):
            return 'TestClass()'

    class TestSuiteGetAttr:
        def __getattr__(self, item):
            if item == 'name':
                return 'TestSuiteGetAttr.name'
            elif item == 'disabled':
                return 'TestSuiteGetAttr.disabled'
            elif item == 'errors':
                return 'TestSuiteGetAttr.errors'
            elif item == 'failures':
                return 'TestSuiteGetAttr.failures'
            elif item == 'tests':
                return 'TestSuiteGetAttr.tests'
            elif item == 'time':
                return 'TestSuiteGetAttr.time'


# Generated at 2022-06-23 13:34:13.424586
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-23 13:34:16.086921
# Unit test for constructor of class TestFailure
def test_TestFailure():
    test = TestResult(output='output', message='message', type='type')


# Generated at 2022-06-23 13:34:20.360560
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    expected = "TestFailure(output='test output', message='test message', type='test type')"
    result = TestFailure(output='test output', message='test message', type='test type')
    assert expected == repr(result)
    expected = "TestFailure(output='test output', message='test message', type='failure')"
    result = TestFailure(output='test output', message='test message')
    assert expected == repr(result)


# Generated at 2022-06-23 13:34:21.824247
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert TestFailure("Failure output", "Failure message", "Failure type") is not None

# Generated at 2022-06-23 13:34:30.811049
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase(
        name="ExampleTestCase",
        assertions=1,
        classname="ExampleClass",
        status="success",
        time=decimal.Decimal(1.5)
    )

    expected_attributes = {
        "name" : "ExampleTestCase",
        "assertions" : "1",
        "classname" : "ExampleClass",
        "status" : "success",
        "time" : "1.5"
    }

    result = test_case.get_attributes()

    assert result == expected_attributes


# Generated at 2022-06-23 13:34:34.334694
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():

    # get test case class
    test_case = TestError("output", "message", "type")

    # __repr__
    test_case.__repr__()

    assert True == True


# Generated at 2022-06-23 13:34:37.039786
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    assert TestSuite("", "", "", None, None) == TestSuite("", "", "", None, None)


# Generated at 2022-06-23 13:34:40.737600
# Unit test for constructor of class TestError
def test_TestError():
    err = TestError(output="Wrong Value", message="Wrong Value", type="Wrong Value")
    assert err.output == "Wrong Value"
    assert err.message == "Wrong Value"
    assert err.type == "Wrong Value"



# Generated at 2022-06-23 13:34:46.351075
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    testcase = TestCase(name='test')
    assert repr(testcase) == 'TestCase(name=\'test\', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'


# Generated at 2022-06-23 13:34:52.810352
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    first = TestFailure(output='first', message='firstmessage', type='firsttype')
    assert first == first
    assert first != TestFailure(output='first', message='firstmessage', type='firsttype')

    assert first == TestFailure(output='first', message='firstmessage',)
    assert first == TestFailure(output='first', type='firsttype')
    assert first == TestFailure(message='firstmessage', type='firsttype')

    assert first != TestFailure(output='second', message='firstmessage', type='firsttype')
    assert first != TestFailure(output='first', message='secondmessage', type='firsttype')
    assert first != TestFailure(output='first', message='firstmessage', type='secondtype')

# Generated at 2022-06-23 13:34:56.847387
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    suites = TestSuites(name = 'test_name', suites = [])
    assert suites.get_attributes() == {'disabled': '0', 'errors': '0', 'failures': '0', 'name': 'test_name', 'tests': '0', 'time': '0'}

# Generated at 2022-06-23 13:35:09.734245
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    now = datetime.datetime.now()
    test_case = TestSuite(name="TestCase",
                          hostname='localhost',
                          id='0',
                          package='junit',
                          timestamp=now,
                          properties={"Author": "Jeremy",
                                      "Date": now.strftime("%m-%d-%Y %H:%M")})

# Generated at 2022-06-23 13:35:16.183816
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    assert TestCase('a') == TestCase('a')
    assert TestCase('a') != TestCase('b')

    assert TestCase('a', assertions=1) == TestCase('a', assertions=1)
    assert TestCase('a', assertions=1) != TestCase('a', assertions=2)

    assert TestCase('a', classname='b') == TestCase('a', classname='b')
    assert TestCase('a', classname='b') != TestCase('a', classname='c')

    assert TestCase('a', status='b') == TestCase('a', status='b')
    assert TestCase('a', status='b') != TestCase('a', status='c')

    assert TestCase('a', time=0.1) == TestCase('a', time=0.1)

# Generated at 2022-06-23 13:35:26.940478
# Unit test for constructor of class TestCase
def test_TestCase():
    testcase1 = TestCase("do_something")
    assert testcase1.name == "do_something"
    assert not testcase1.assertions
    assert not testcase1.classname
    assert not testcase1.status
    assert not testcase1.time
    assert not testcase1.errors
    assert not testcase1.failures
    assert not testcase1.skipped
    assert not testcase1.system_out
    assert not testcase1.system_err
    assert not testcase1.is_disabled
    assert not testcase1.is_failure
    assert not testcase1.is_error
    assert not testcase1.is_skipped
    assert testcase1.get_xml_element()
    assert testcase1.get_attributes()


# Generated at 2022-06-23 13:35:32.601931
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    j = TestCase(name='test_TestCase___repr__')
    s = repr(j)
    assert (s == "TestCase(name='test_TestCase___repr__', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)")


# Generated at 2022-06-23 13:35:36.636124
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    tag = 'tag'
    test_result = TestResult()
    test_result.tag = tag
    test_result.__post_init__()
    assert test_result.type == tag


# Generated at 2022-06-23 13:35:47.542455
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    
    ##### Default Test Case ######
    TestCase1 = TestCase(name=None, assertions=None, classname=None, status=None, time=None)

    assert TestCase1.get_attributes() == dict(assertions=None, classname=None, name=None, status=None, time=None)

    ##### Valid Test Case ######
    TestCase2 = TestCase(name="Test for JP", assertions=12, classname="test.test_module.test_method", status="run", time=1.2)

    assert TestCase2.get_attributes() == dict(assertions='12', classname='test.test_module.test_method', name='Test for JP', status='run', time='1.2')

    ##### Invalid Test Case ######

# Generated at 2022-06-23 13:35:52.358216
# Unit test for constructor of class TestResult
def test_TestResult():
    t = TestFailure(
        output='test output',
        message='test message',
        type='test type'
    )
    assert t.output == 'test output'
    assert t.message == 'test message'
    assert t.type == 'test type'
    assert t.tag == 'failure'


# Generated at 2022-06-23 13:35:57.380665
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    #Test for empty objects
    suite1 = TestSuite()
    suite2 = TestSuite()
    assert suite1 == suite2

    #Test for testcases
    cases = [TestCase(name='testcase_name', assertions=10, classname='testcase_classname', status='testcase_status')]
    suite3 = TestSuite(name='suite_name', hostname='hostname', id='testsuite_id', package='test_package', timestamp=datetime.datetime(2019, 10, 10, 20, 40), cases=cases)
    suite4 = TestSuite(name='suite_name', hostname='hostname', id='testsuite_id', package='test_package', timestamp=datetime.datetime(2019, 10, 10, 20, 40), cases=cases)
    assert suite3 == suite4

# Generated at 2022-06-23 13:35:59.203313
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    """return bool"""
    pass


# Generated at 2022-06-23 13:36:02.401012
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    TestCase("some_name", "some_status", "some_time", TestSuite("some_name"))


# Generated at 2022-06-23 13:36:09.834876
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_case = TestFailure()
    assert repr(test_case) == 'TestFailure()'
    test_case = TestFailure(output='output')
    assert repr(test_case) == "TestFailure(output='output')"
    test_case = TestFailure(message='message')
    assert repr(test_case) == "TestFailure(message='message')"
    test_case = TestFailure(type='type')
    assert repr(test_case) == "TestFailure(type='type')"


# Generated at 2022-06-23 13:36:14.635541
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(message="Hello", type="Test")
    assert test_result.get_attributes() == {'message': 'Hello', 'type': 'Test'}


# Generated at 2022-06-23 13:36:17.378794
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a = TestSuites(name='foo')
    b = TestSuites(name='foo')
    
    assert a == b

# Generated at 2022-06-23 13:36:20.444355
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    # Setup
    output = 'output'
    message = 'message'
    type = 'type'
    # Exercise
    actual = TestFailure(output, message, type)
    # Verify
    assert actual.__repr__() == "TestFailure(output='output', message='message', type='type')"


# Generated at 2022-06-23 13:36:25.060277
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert repr(TestError()) == 'TestError(output=None, message=None, type=None)'
    assert repr(TestError(output='some output', message='some message', type='some type')) == "TestError(output='some output', message='some message', type='some type')"


# Generated at 2022-06-23 13:36:36.622218
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    t1 = TestResult('type_error', 'the test failed')
    t2 = TestFailure('fail_type', 'the test failed again')
    t3 = TestError('type_error', 'the test failed again')
    assert t1.get_xml_element().tag == 'result'
    assert t2.get_xml_element().tag == 'failure'
    assert t3.get_xml_element().tag == 'error'
    assert t1.get_xml_element().text == 'the test failed'
    assert t2.get_xml_element().text == 'the test failed again'
    assert t3.get_xml_element().text == 'the test failed again'


# Generated at 2022-06-23 13:36:42.794829
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    def test_get_attributes_with_default_values():
        result = TestCase("foo").get_attributes()
        expected = {"name":"foo"}
        assert result == expected, "Erreur dans la méthode get_attributes de TestCase avec les valeurs par défaut"


# Generated at 2022-06-23 13:36:54.326554
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    test_result1 = TestError()
    test_result2 = TestError(output="this is an error")
    test_result3 = TestError(output="this is an error")
    test_result4 = TestError(output="this is an error", message="error message", type="error type")
    test_result5 = TestError(output="this is an error", message="error message", type="error type")
    test_result6 = TestError(output="this is an error", message="error message", type="error type")
    assert test_result1 != test_result2
    assert test_result2 == test_result3
    assert test_result3 != test_result4
    assert test_result4 == test_result5
    assert test_result5 == test_result6


# Generated at 2022-06-23 13:37:02.425358
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite = TestSuite("TestSuite_name", "hostname")
    testsuite.properties = {"key1": "value1", "key2": "value2"}
    testsuite.system_err = "system err"
    testsuite.system_out = "system out"

    testcase = TestCase("TestCase_name")
    testcase.classname = "classname"
    testcase.time = 1
    testcase.system_err = "system err"
    testcase.system_out = "system out"

    failure = TestFailure("failure out")
    failure.message = "failure message"
    failure.type = "failure type"
    testcase.failures.append(failure)

    error = TestError("error out")
    error.message = "error message"
    error

# Generated at 2022-06-23 13:37:04.275998
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert TestFailure(output=None, message=None, type=None)


# Generated at 2022-06-23 13:37:06.363258
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    pass
    # TODO: Implement unit test for method __eq__ of class TestCase


# Generated at 2022-06-23 13:37:15.830871
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    exampleData = TestCase('TestCase1', 1, 'class1', 'passed', 1.0)
    assert exampleData == TestCase('TestCase1', 1, 'class1', 'passed', 1.0)
    assert not exampleData == TestCase('TestCase2', 1, 'class1', 'passed', 1.0)
    assert not exampleData == TestCase('TestCase1', 2, 'class1', 'passed', 1.0)
    assert not exampleData == TestCase('TestCase1', 1, 'class2', 'passed', 1.0)
    assert not exampleData == TestCase('TestCase1', 1, 'class1', 'failed', 1.0)
    assert not exampleData == TestCase('TestCase1', 1, 'class1', 'passed', 2.0)
    assert not exampleData == Test

# Generated at 2022-06-23 13:37:19.684158
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    te = TestError(message="test_message", output="test_output", type="test_type")
    assert te.__repr__() == "TestError(message='test_message', output='test_output', type='test_type')"


# Generated at 2022-06-23 13:37:22.395222
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    value1 = TestCase('name')
    value2 = TestCase('name')
    value3 = TestCase('other_name')
    assert value1 == value2 == value2
    assert value1 != value3 != value3

# Generated at 2022-06-23 13:37:29.018797
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test_case',
        classname='test_classname',
        time=1.1,
        errors=[
            TestError(
                output='output_error',
                message='message_error',
                type='type_error'
            )],
        failures=[
            TestFailure(
                output='output_failure',
                message='message_failure',
                type='type_failure'
            )],
        skipped='skipped',
        system_out='system_out',
        system_err='system_err',
    )


# Generated at 2022-06-23 13:37:39.944096
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-23 13:37:45.712842
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    tcase = TestCase(name="test_case1")
    assert tcase.get_attributes() == {"name":"test_case1"}

    tcase = TestCase(name="test_case2", classname="classname2", time=0, assertions=3)
    assert tcase.get_attributes() == {"name":"test_case2", "classname":"classname2", "assertions":"3", "time":"0"}



# Generated at 2022-06-23 13:37:56.458644
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    """
    Unit test for method __repr__ of class TestCase
    """
    # Create an instance of TestCase
    test_case = TestCase(
        name='test_case_1',
        assertions=0,
        classname='TestCase',
        status='0',
        time=decimal.Decimal(0.0),
        errors=[],
        failures=[],
        skipped=None,
        system_out=None,
        system_err=None,
        is_disabled=False
    )
    # Check if the repr of a testcase is the expected repr
    assert repr(test_case) == '<TestCase(name=test_case_1)>'

# Generated at 2022-06-23 13:38:07.994085
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    testsuite = TestSuite(name='Test Name')
    testsuites = TestSuites(name='Test Suite Name')
    testsuites.suites.append(testsuite)

    xml_element = testsuites.get_xml_element()
    assert xml_element.tag == 'testsuites'
    assert xml_element.attrib == {
        'disabled': '0',
        'errors': '0',
        'failures': '0',
        'name': 'Test Suite Name',
        'tests': '0',
        'time': '0'
    }
    assert len(xml_element) == 1
    assert xml_element[0].tag == 'testsuite'

# Generated at 2022-06-23 13:38:12.622689
# Unit test for constructor of class TestError
def test_TestError():

    output = "This is the output"
    message = "This is the message"
    error_type = "This is the error type"

    error = TestError(output, message, error_type)
    assert error.output == output
    assert error.message == message
    assert error.type == error_type

# Generated at 2022-06-23 13:38:18.259996
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    # arrange
    ts = TestSuites()

    # act
    xml = ts.to_pretty_xml()

    # assert
    # print(xml)
    assert isinstance(xml, str)
    assert xml.startswith('<?xml ')
    assert xml.endswith('\n</testsuites>\n')

# Generated at 2022-06-23 13:38:22.224403
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_1 = TestCase(name='TestCase', classname='TestClass')
    test_case_2 = TestCase(name='TestCase', classname='TestClass')
    assert test_case_1 == test_case_2



# Generated at 2022-06-23 13:38:23.581995
# Unit test for constructor of class TestSuites
def test_TestSuites():
    TestSuites()


# Generated at 2022-06-23 13:38:27.987296
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    result1 = TestResult(type='test_type')
    assert result1.type == 'test_type'
    
    result2 = TestResult()
    assert result2.type == 'testresult'

# Generated at 2022-06-23 13:38:33.860942
# Unit test for constructor of class TestCase
def test_TestCase():
    testcase = TestCase('testCaseName', output, message, type)
    assert testcase.name == 'testCaseName'
    assert testcase.output == output
    assert testcase.message == message
    assert testcase.type == type
    testcase.type = 'suite'
    assert testcase.type == 'suite'


# Generated at 2022-06-23 13:38:39.799343
# Unit test for constructor of class TestCase
def test_TestCase():
    test_case = TestCase("TestCase")
    assert test_case.name == "TestCase"
    assert test_case.classname == None
    assert test_case.assertions == None
    assert test_case.status == None
    assert test_case.time == None
    assert test_case.is_disabled == False
    assert test_case.failures == []
    assert test_case.skipped == None
    assert test_case.system_out == None
    assert test_case.system_err == None
    assert test_case.errors == []


# Generated at 2022-06-23 13:38:44.532101
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result1 = TestResult()
    assert result1.get_attributes() == {}
    result2 = TestResult(output='output', message='message', type='type')
    assert result2.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-23 13:38:47.621575
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test = TestResult("output", "message", "type")
    result = test.get_xml_element()
    assert result.tag == 'testcase' and result.text == 'output'



# Generated at 2022-06-23 13:38:58.607821
# Unit test for constructor of class TestCase
def test_TestCase():
    # Given
    test_case = TestCase(name="KIRI")
    # When
    test_case.failures.append(TestFailure(message="Something went wrong"))
    test_case.errors.append(TestError(message="RuntimeError"))
    test_case.system_err = "Error traceback"
    test_case.skipped = "skipped"
    # Then
    assert test_case.name == "KIRI"
    assert test_case.get_attributes() == {"name": "KIRI"}
    assert len(test_case.get_xml_element()) == 5
    assert test_case.is_skipped
    assert test_case.errors
    assert test_case.failures
    assert test_case.system_err


# Generated at 2022-06-23 13:39:02.493274
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    t1 = TestSuite(name='test')
    t2 = TestSuite(name='test')
    assert(t1 == t2)


# Generated at 2022-06-23 13:39:06.552935
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    """Unit test for method get_xml_element of class TestSuites."""
    assert TestSuite(name='name', timestamp=datetime.datetime(2020, 1, 1)).get_xml_element().attrib['timestamp'] == '2020-01-01T00:00:00'



# Generated at 2022-06-23 13:39:13.690777
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    expected = {'name': 'test_case', 'assertions': '2', 'classname': 'TestCase', 'status': 'passed', 'time': '3.14159'}
    actual = TestCase(name='test_case', assertions=2, classname='TestCase', status='passed', time=decimal.Decimal('3.14159')).get_attributes()
    assert expected == actual


# Generated at 2022-06-23 13:39:22.743969
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_method',
                         assertions=2,
                         classname='TestClass',
                         status='timeout',
                         time=decimal.Decimal('3.14'))

    expected_attributes = {'assertions': '2',
                           'classname': 'TestClass',
                           'name': 'test_method',
                           'status': 'timeout',
                           'time': '3.14'}

    result = test_case.get_xml_element()

    assert result.tag == 'testcase'
    assert result.attrib == expected_attributes
    assert result.text == None
    assert len(result) == 3
    assert result[0].tag == 'failure'

# Generated at 2022-06-23 13:39:31.809790
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a = TestSuites(name='a')
    b = TestSuites(name='b')
    c = TestSuites(name='a')
    d = TestSuites(name='a')

    d.suites.append(TestSuite(name='testsuite'))
    e = TestSuites(name='a')
    e.suites.append(TestSuite(name='testsuite'))

    assert a == c
    assert hash(a) == hash(c)
    assert a != b
    assert hash(a) != hash(b)
    assert a != d
    assert hash(a) != hash(d)
    assert d == e
    assert hash(d) == hash(e)

# Generated at 2022-06-23 13:39:38.479901
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    class_ = TestSuites
    assert class_.__repr__.__name__ == '__repr__'
    assert class_.__repr__.__qualname__ == 'TestSuites.__repr__'
    assert class_.__repr__.__doc__ == 'Return repr(self).'
    assert class_.__repr__.__module__ == __name__
    assert class_.__repr__.__annotations__ == {}


# Generated at 2022-06-23 13:39:43.037494
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    cases = [TestCase(name="test1"), TestCase(name="test2")]
    suite = TestSuite(name="suite1", cases=cases)
    assert suite.__repr__() == "TestSuite(name='suite1', cases=[TestCase(name='test1'), TestCase(name='test2')])"


# Generated at 2022-06-23 13:39:50.782332
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    data = TestFailure(output='Eternal loop')
    # Expected result
    res = b"""<failure>Eternal loop</failure>"""
    assert _pretty_xml(data.get_xml_element()) == ET.tostring(ET.fromstring(res), encoding='unicode')
    assert data.get_xml_element().tag == 'failure'


# Generated at 2022-06-23 13:39:55.125810
# Unit test for constructor of class TestError
def test_TestError():
    test_result = TestError()
    assert(test_result.type is not None)
    assert(test_result.output is None)
    assert(test_result.message is None)
    assert(test_result.tag == 'error')


# Generated at 2022-06-23 13:39:56.414565
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    assert TestResult(output='test output') == TestResult()

    assert not TestResult(output='test output') == TestFailure(output='test output')



# Generated at 2022-06-23 13:40:01.849520
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Arrange 
    my_test_result = TestResult('expected_output','expected_message','expected_type')
    
    # Act
    result = my_test_result.get_xml_element()
    
    # Assert
    assert result.text == 'expected_output'
    assert result.attrib['message'] == 'expected_message'
    assert result.attrib['type'] == 'expected_type'
    assert result.tag == 'testResult'


# Generated at 2022-06-23 13:40:04.339960
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    result =TestSuites(None)
    assert result.get_xml_element(), "Test get_xml_element() of class TestSuites failed. No data"
    

# Generated at 2022-06-23 13:40:15.369383
# Unit test for constructor of class TestSuite
def test_TestSuite():
  properties = {'test1': 'test1', 'test2': 'test2'}
  cases = test_TestCase()
  system_out = "System out"
  system_err = "System err"
  
  suite = TestSuite("TestSuite", "hostname", "id", "package", datetime.datetime.now(), properties, cases, system_out, system_err)

  assert suite.name == "TestSuite"
  assert suite.hostname == "hostname"
  assert suite.id == "id"
  assert suite.package == "package"
  assert suite.properties == properties
  assert suite.cases == cases
  assert suite.system_out == system_out
  assert suite.system_err == system_err


# Generated at 2022-06-23 13:40:17.781755
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase('test_case_1')
    assert 'test_case_1 with 0 failures and 0 errors' == test_case.__repr__()

# Generated at 2022-06-23 13:40:20.983710
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test_suites = TestSuites(name='TestSuites')
    assert test_suites.get_attributes() == {'name': 'TestSuites'}

# Generated at 2022-06-23 13:40:32.335680
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    from datetime import datetime


# Generated at 2022-06-23 13:40:41.375320
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert TestError().__repr__() == 'TestError()'
    assert TestError(type='My Error').__repr__() == "TestError(type='My Error')"
    assert TestError(type='My Error', output='The error message').__repr__() == "TestError(type='My Error', output='The error message')"
    assert TestError(output='The error message').__repr__() == "TestError(output='The error message')"
    assert TestFailure().__repr__() == 'TestFailure()'
    assert TestSuite().__repr__() == 'TestSuite()'
    assert TestSuites().__repr__() == 'TestSuites()'
    assert TestSuites(name='My Test').__repr__() == "TestSuites(name='My Test')"
    assert Test

# Generated at 2022-06-23 13:40:45.736534
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    a = TestResult(output = "output", message = "message", type = "type")
    b = TestResult(output = "output", message = "message", type = "type")
    if a == b:
        return
    else:
        raise Exception

# Generated at 2022-06-23 13:40:50.096220
# Unit test for constructor of class TestResult
def test_TestResult():
    failure = TestResult('output', 'message', 'type')
    assert failure.output == 'output'
    assert failure.message == 'message'
    assert failure.type == 'type'


# Generated at 2022-06-23 13:40:53.185359
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    case = TestCase(name='test_1')
    element = case.get_xml_element()
    assert element.tag == 'testcase'


# Generated at 2022-06-23 13:40:55.655584
# Unit test for constructor of class TestFailure
def test_TestFailure():
    # Create class instance
    TestFailure_instance = TestFailure()

    # Check value of field tag
    TestFailure_instance_tag = TestFailure_instance.tag



# Generated at 2022-06-23 13:40:58.718562
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    obj = TestSuites()
    assert repr(obj) == 'TestSuites(name=None, suites=[])'


# Generated at 2022-06-23 13:41:01.987030
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    assert TestCase('name') == TestCase('name')
    assert TestCase('name1') != TestCase('name2')


# Generated at 2022-06-23 13:41:09.133636
# Unit test for constructor of class TestSuites
def test_TestSuites():

    ts = TestSuites(name="test_TestSuite")
    assert ts.name == "test_TestSuite"

    ts = TestSuites(name="test_TestSuite", suites=[])
    assert ts.name == "test_TestSuite"

    ts = TestSuites(name="test_TestSuite", suites=[TestSuite(name="TestSuite")])
    assert ts.name == "test_TestSuite"

    try:
        ts = TestSuites(name="test_TestSuite", suites=[TestSuite(name="TestSuite")], hostname="test_hostname")
        assert False
    except TypeError:
        pass


# Generated at 2022-06-23 13:41:16.297146
# Unit test for constructor of class TestCase
def test_TestCase():
    """Test the constructor of class TestCase."""
    tc = TestCase('Name of test case')
    assert tc.name == 'Name of test case'
    assert tc.assertions is None
    assert tc.classname is None
    assert tc.status is None
    assert tc.time is None
    assert tc.errors == []
    assert tc.failures == []
    assert tc.skipped is None
    assert tc.system_out is None
    assert tc.system_err is None
    assert tc.is_disabled is False


# Generated at 2022-06-23 13:41:18.850783
# Unit test for constructor of class TestSuites
def test_TestSuites():
    testsuites = TestSuites()
    assert testsuites.name is None
    assert len(testsuites.suites) == 0


# Generated at 2022-06-23 13:41:22.076504
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    a = TestResult(message='error', output='output message', type='error type')
    b = TestResult(message='error', output='output message', type='error type')
    c = a
    assert a == b
    assert a == c
    assert b == c


# Generated at 2022-06-23 13:41:26.191803
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    # Given
    testcase = TestCase(name="test case", classname="testClass", time=0.2)

    # When
    element = testcase.get_xml_element()

    # Then
    expected_text = '<testcase assertions="None" classname="testClass" name="test case" status="None" time="0.2"/>'
    assert ET.tostring(element, encoding='unicode') == expected_text



# Generated at 2022-06-23 13:41:28.974702
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    myCase = TestResult()
    elem = myCase.get_xml_element()
    assert elem.tag == '@tag'


# Generated at 2022-06-23 13:41:38.248918
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    ts = TestSuites()
    ts.suites.append(TestSuite(
        name='test-suite-1',
        properties={
            'foo': 'bar',
        },
        system_out='baz',
        system_err='qux',
    ))


# Generated at 2022-06-23 13:41:43.008762
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_suites = TestSuites('TCP unit tests')
    test_suite = TestSuite('TCP test suite')

    test_suites.suites.append(test_suite)

    assert test_suites.get_xml_element() == ET.Element(
        'testsuites',
        attrib=_attributes(
            name='TCP unit tests',
            disabled=0,
            errors=0,
            failures=0,
            tests=0,
            time=0,
        )
    )


# Generated at 2022-06-23 13:41:47.959467
# Unit test for constructor of class TestFailure
def test_TestFailure():
    tf = TestFailure(output = "This is my output", message = "This is my message", type = "Something")
    assert tf.output == "This is my output"
    assert tf.message == "This is my message"
    assert tf.type == "Something"


# Generated at 2022-06-23 13:41:50.433500
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert repr(TestSuites()) == 'TestSuites(name=None, suites=[])'



# Generated at 2022-06-23 13:41:51.890728
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    suites = TestSuites()
    assert suites == TestSuites()


# Generated at 2022-06-23 13:41:54.198206
# Unit test for constructor of class TestSuites
def test_TestSuites():
    testsuites = TestSuites()
    print(testsuites.suites)
    print(testsuites.name)


# Generated at 2022-06-23 13:42:01.997653
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():

    testcase = TestCase(name='name',
                        assertions=1,
                        classname='classname',
                        status='status',
                        time=1.1)

    # Test if values in dictionary match attributes of TestCase
    assert testcase.get_attributes() == {'assertions':'1', 'classname':'classname', 'name':'name', 'status':'status', 'time':'1.1'}


# Generated at 2022-06-23 13:42:07.799390
# Unit test for constructor of class TestCase
def test_TestCase():
    """Constructor of TestCase"""
    tc1 = TestCase('tc1')
    assert tc1.name == 'tc1'
    assert tc1.is_disabled == False
    assert tc1.is_error == False
    assert tc1.is_failure == False
    assert tc1.is_skipped == False



# Generated at 2022-06-23 13:42:16.917082
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Test when no arguments are passed in
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    assert test_result.get_attributes() == _attributes()

    # Test when an argument is passed in
    test_result = TestResult("output")
    assert test_result.get_attributes() == _attributes(message=None, type="error")

    # Test when all arguments are passed in
    test_result = TestResult("output", "message", "type")
    assert test_result.get_attributes() == _attributes(message="message", type="type")

    # Test when an argument is passed in as None
    test_result = TestResult("output", "message", None)

# Generated at 2022-06-23 13:42:27.282271
# Unit test for constructor of class TestFailure
def test_TestFailure():
    failure = TestFailure(output="out", message="msg", type="type")
    assert failure.__post_init__() is None
    assert failure.output == "out"
    assert failure.message == "msg"
    assert failure.type == "failure"
    assert failure.tag == "failure"
    assert failure.get_attributes() == {
        "message": "msg",
        "type": "failure",
    }
    expected_element = ET.Element('failure', {
        "message": "msg",
        "type": "failure",
    })
    expected_element.text = "out"
    assert failure.get_xml_element() == expected_element
    failure = TestFailure(output="out", message="msg", type="type2")
    assert failure.__post_init__() is None


# Generated at 2022-06-23 13:42:30.861909
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(message="Message", output="Output", type="Type")
    attributes = result.get_attributes()
    assert (len(attributes) == 2)
    assert (attributes['message'] == "Message")
    assert (attributes['type'] == "Type")


# Generated at 2022-06-23 13:42:42.168926
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # TestSuite(name='', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)
    t1 = TestSuite('', None, None, None, None, {}, [], None, None)
    t2 = TestSuite('', None, None, None, None, {}, [], None, None)
    assert (t1 == t2)

    t1 = TestSuite('', None, None, None, None, {}, [], None, None)
    t2 = TestSuite(' ', None, None, None, None, {}, [], None, None)
    assert (not (t1 == t2))

    t1 = TestSuite('', '', None, None, None, {}, [], None, None)
    t

# Generated at 2022-06-23 13:42:48.325462
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase('name', assertions=123)
    assert str(test_case) == 'TestCase(name=name, assertions=123, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None)'


# Generated at 2022-06-23 13:42:49.443848
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    TestCase.__repr__()


# Generated at 2022-06-23 13:42:55.935882
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    ts = TestSuites(
        suites=[
            TestSuite(
                name='TestSuite1',
                time=1.1
            )
        ]
    )
    assert ts.get_attributes() == {
        'disabled': '0',
        'errors': '0',
        'failures': '0',
        'tests': '0',
        'time': '1.1'
    }


# Generated at 2022-06-23 13:43:04.035512
# Unit test for constructor of class TestSuites
def test_TestSuites():
    suites = TestSuites(suites = [TestSuite(name='test', cases=[TestCase(name='case')])])
    assert suites.name is None
    assert suites.suites[0].name == 'test'
    assert len(suites.suites) == 1
    assert suites.suites[0].cases[0].name == 'case'
    assert len(suites.suites[0].cases) == 1

if __name__ == "__main__":
    test_TestSuites()

# Generated at 2022-06-23 13:43:13.211614
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    with pytest.raises(AttributeError):
        TestSuite.__eq__('this')

    with pytest.raises(AttributeError):
        TestSuite.__eq__(1)

    with pytest.raises(AttributeError):
        TestSuite.__eq__(None)

    with pytest.raises(AttributeError):
        TestSuite.__eq__({})

    with pytest.raises(AttributeError):
        TestSuite.__eq__([])

    with pytest.raises(AttributeError):
        TestSuite.__eq__(set())


# Generated at 2022-06-23 13:43:14.502637
# Unit test for constructor of class TestError
def test_TestError():
    test =  TestError()
    assert test.tag == 'error'
