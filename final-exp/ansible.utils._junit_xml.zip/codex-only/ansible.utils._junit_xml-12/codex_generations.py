

# Generated at 2022-06-23 13:33:14.626130
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    # Call function without type, so that it will set the tag as the type
    tr = TestError('')
    assert type(tr).__name__ == tr.tag


# Generated at 2022-06-23 13:33:19.391762
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Test a pretty formatted XML string representing this instance."""

# Generated at 2022-06-23 13:33:20.969012
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    subject = TestSuites()
    result = subject.__repr__()
    print(result)


# Generated at 2022-06-23 13:33:23.647301
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert repr(TestFailure(output="a",
                            message="b",
                            type="c")) == "TestFailure(output='a', message='b', type='c')"


# Generated at 2022-06-23 13:33:24.526974
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    classname = 'TestSuite'


# Generated at 2022-06-23 13:33:31.247784
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError() == TestError()
    assert TestError(output='Something\nwent\nwrong') == TestError(output='Something\nwent\nwrong')
    assert TestError(message='Something went wrong') == TestError(message='Something went wrong')
    assert TestError(type='org.example.Error') == TestError(type='org.example.Error')
    assert TestError(output='Something\nwent\nwrong', message='Something went wrong') == TestError(output='Something\nwent\nwrong', message='Something went wrong')
    assert TestError(output='Something\nwent\nwrong', type='org.example.Error') == TestError(output='Something\nwent\nwrong', type='org.example.Error')

# Generated at 2022-06-23 13:33:38.233172
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
   Testcase=TestCase(name="test_case1",classname="dummy",status="Pass")
   f=Testcase.__repr__()
   assert f=="TestCase(name='test_case1', assertions=None, classname='dummy', status='Pass', time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"


# Generated at 2022-06-23 13:33:40.379185
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output="output", message="message", type="type")
    test_result.get_xml_element()

# Generated at 2022-06-23 13:33:45.833080
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    instance = TestResult()
    xml_element = instance.get_xml_element()
    assert xml_element.tag == instance.tag
    assert xml_element.text == instance.output
    assert xml_element.attrib.get('message') == instance.message
    assert xml_element.attrib.get('type') == instance.type



# Generated at 2022-06-23 13:33:52.168641
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    class TestResultSubclass(TestResult):
        @property
        def tag(self):
            return 'testResultSubclass'

    test_result = TestResultSubclass(output='test_output')
    assert test_result.get_xml_element().tag == 'testResultSubclass'
    assert test_result.get_xml_element().text == 'test_output'
    assert test_result.get_xml_element().attrib == {}


# Generated at 2022-06-23 13:33:54.380988
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    assert TestSuite('test-suite') == TestSuite('test-suite')
    assert TestSuite('test-suite-1') != TestSuite('test-suite-2')


# Generated at 2022-06-23 13:33:57.832404
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # Setup
    # Exercise
    test_suites = TestSuites(name='Suites Name')
    # Verify
    assert repr(test_suites) == "TestSuites(name='Suites Name', suites=[])"

# Generated at 2022-06-23 13:34:07.720439
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():

    assert TestFailure("") == TestFailure("")
    assert TestFailure("", "") == TestFailure("", "")
    assert TestFailure("", "", "") == TestFailure("", "", "")
    assert TestFailure(output="") == TestFailure("")
    assert TestFailure(output="", message="") == TestFailure("", "")
    assert TestFailure(output="", message="", type="") == TestFailure("", "", "")
    assert TestFailure(message="", type="") == TestFailure("", "")

    assert TestFailure("a") == TestFailure("a")
    assert TestFailure("a", "b") == TestFailure("a", "b")
    assert TestFailure("a", "b", "c") == TestFailure("a", "b", "c")
    assert TestFailure(output="a") == TestFailure("a")

# Generated at 2022-06-23 13:34:10.143671
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert _attributes(message="test", type="test", x=None) == {'message': 'test', 'type': 'test'}


# Generated at 2022-06-23 13:34:13.387830
# Unit test for constructor of class TestResult
def test_TestResult():
    test = TestResult(
        output='foo',
        message='bar',
        type='baz'
    )
    assert test.output == 'foo'
    assert test.message == 'bar'
    assert test.type == 'baz'



# Generated at 2022-06-23 13:34:15.728253
# Unit test for constructor of class TestSuites
def test_TestSuites():
    test_suites = TestSuites()



# Generated at 2022-06-23 13:34:16.819263
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    # arrange
    test_suite = TestSuite()



# Generated at 2022-06-23 13:34:20.840369
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a = TestSuites()
    b = TestSuites()
    a.suites = [TestSuite()]
    b.suites = [TestSuite()]
    assert a == b

# test_TestSuite___eq__: Unit test for method __eq__ of class TestSuite

# Generated at 2022-06-23 13:34:22.526638
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    su = TestSuites(name='Test suite')
    su1 = TestSuites(name='Test suite')
    assert su == su1
    assert (su == 'Test1') is False


# Generated at 2022-06-23 13:34:30.989551
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    attr = {
        'errors': 0,
        'skipped': 0,
        'failures': 0,
        'tests': 0,
        'timestamp': '',
        'time': 0,
        'name': '',
        'package': '',
        'id': '',
        'hostname': '',
        'disabled': 0
    }
    suite = TestSuite('test1')
    print(suite.get_xml_element().items())
    assert suite.get_xml_element().items() == attr.items()


# Generated at 2022-06-23 13:34:36.130025
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    tp = TestSuites('WILD-LIFE')
    print(tp.get_attributes())
    assert tp.get_attributes() == {'name': 'WILD-LIFE', 'errors': '0', 'time': '0', 'disabled': '0', 'tests': '0', 'failures': '0'}


# Generated at 2022-06-23 13:34:41.844551
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    from pytest import raises
    from hypothesis import given, settings
    from .strategies import valid_TestSuite

    @settings(max_examples=5000, deadline=None)
    @given(valid_TestSuite())
    def test_TestSuite___repr__(suite: TestSuite):
        assert eval(repr(suite)) == suite

    test_TestSuite___repr__()


# Generated at 2022-06-23 13:34:51.250489
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_suites = TestSuites(name='generated-by-Python')

    test_suite = TestSuite(name='A Test Suite (1)', timestamp=datetime.datetime.now())
    test_suite.system_out = 'output'
    test_suite.system_err = 'error'
    test_suite.properties = {'prop1': 'value1'}

    test_case = TestCase(name='A Test Case (1.1)', assertions=1, classname='class.name.1', status='PASSED', time=decimal.Decimal('1.0'), is_disabled=False)
    test_case.system_out = 'output'
    test_case.system_err = 'error'

# Generated at 2022-06-23 13:35:00.783592
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-23 13:35:11.728499
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    dummy_output = 'dummy'
    dummy_message = 'dummy'
    dummy_type = 'dummy'
    dummy_name = 'dummy'
    dummy_assertions = 'dummy'
    dummy_classname = 'dummy'
    dummy_status = 'dummy'
    dummy_time = 'dummy'
    dummy_errors = [dummy_output, dummy_message, dummy_type]
    dummy_failures = [dummy_output, dummy_message, dummy_type]
    dummy_skipped = 'dummy'
    dummy_system_out = 'dummy'
    dummy_system_err = 'dummy'
    dummy_is_disabled = 'dummy'
    # Invoke method

# Generated at 2022-06-23 13:35:14.411484
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError('foo')
    assert error.output == 'foo'


# Generated at 2022-06-23 13:35:17.062333
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    """
    TestCase.__repr__() return the name of the test case
    """
    test_case = TestCase('test_name')
    assert repr(test_case) == 'test_name'

# Generated at 2022-06-23 13:35:20.461857
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    """Test for method get_attributes of class TestSuite"""

    ts = TestSuite(name='test_name')

    ts_attributes = ts.get_attributes();
    assert ts_attributes['name'] == 'test_name'


# Generated at 2022-06-23 13:35:24.233203
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    r1 = TestError(output=None, message=None, type=None)
    r2 = TestError(output=None, message=None, type=None)
    assert r1 == r2


# Generated at 2022-06-23 13:35:33.949066
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():

    system_out = '<testcase name="test_testcase_name" assertions="1" classname="TestCaseClassname" status="pass" time="42.42"><system-out>Passed</system-out></testcase>'
    testcase = TestCase(name='test_testcase_name', assertions=1, classname='TestCaseClassname', status='pass', time=42.42, system_out='Passed')
    testcase_xml = testcase.get_xml_element()
    testcase_xml_doc = minidom.parseString(ET.tostring(testcase_xml, encoding='unicode'))
    testcase_pretty_xml = testcase_xml_doc.toprettyxml()
    assert testcase_pretty_xml == system_out


# Generated at 2022-06-23 13:35:37.744677
# Unit test for constructor of class TestError
def test_TestError():
    a = TestError(output='output', message='message')

    assert a.output == 'output'
    assert a.message == 'message'
    assert a.type == 'error'



# Generated at 2022-06-23 13:35:43.847617
# Unit test for constructor of class TestSuite
def test_TestSuite():
    TestSuite(name = 'name', hostname = 'hostname', id = 'id', package = 'package', timestamp = datetime.datetime.now())
    TestSuite(name = 'name', properties = {"prop1" : "val1"}, cases = [TestCase(name = "Case1")], system_out = "system_out", system_err = "system_err")


# Generated at 2022-06-23 13:35:46.852107
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test = TestCase('test_valid',classname='unittest.TestCase',time='0.0',status='1')
    print(test.get_attributes())

# Generated at 2022-06-23 13:35:56.814789
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
	# Create an instance of TestSuites
	test_suites = TestSuites(
		name="sample"
	)
	
	# Adding an instance of TestSuite to the TestSuites object
	test_suites.suites.append(
		TestSuite(
			name="sample_test_suite",
			hostname="localhost",
			id="1",
			package="sample_package",
			timestamp=datetime.datetime.now(),
			properties={"a" : "b"},
		)
	)
	
	# Adding an instance of TestCase to the TestSuite object

# Generated at 2022-06-23 13:36:08.856154
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    testsuites = TestSuites()

    # New testsuite with name 'test'
    ts1 = TestSuite('test')
    # New testsuite with name 'test'
    ts2 = TestSuite('test')

    # New testsuite with name 'test2'
    ts3 = TestSuite('test2')

    # Append the testsuites to TestSuites
    testsuites.suites.append(ts1)
    testsuites.suites.append(ts2)
    testsuites.suites.append(ts3)

    # Test suites with name 'test' are equal
    assert ts1 == ts2
    # Test suites with different names are not equal
    assert ts1 != ts3

# Generated at 2022-06-23 13:36:16.557872
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():

    test_result1 = TestResult(
        output='output1',
        message='message1',
        type='type1',
    )
    assert test_result1.__repr__() == '<TestResult output="output1" message="message1" type="type1">'

    test_result2 = TestResult(
        output=None,
        message='message2',
        type='type2',
    )
    assert test_result2.__repr__() == '<TestResult message="message2" type="type2">'

    test_result3 = TestResult(
        output=None,
        message=None,
        type='type3',
    )
    assert test_result3.__repr__() == '<TestResult type="type3">'


# Generated at 2022-06-23 13:36:17.758972
# Unit test for constructor of class TestError
def test_TestError():
    tester = TestError(type='typeTest')
    assert tester.get_attributes() == {'message': None, 'type': 'typeTest'}


# Generated at 2022-06-23 13:36:25.845322
# Unit test for method __repr__ of class TestSuites

# Generated at 2022-06-23 13:36:28.580013
# Unit test for constructor of class TestSuites
def test_TestSuites():
    testsuites = TestSuites(name="test")
    assert testsuites.name == "test"


# Generated at 2022-06-23 13:36:39.672054
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(
        name='test_something',
        hostname='example.com',
        id='123',
        package='com.example.tests',
        timestamp=datetime.datetime(year=2020, month=2, day=4, hour=14, minute=8, second=12),
        properties={'key': 'value'},
        cases=[
            TestCase(name='test_something_else', classname='com.example.tests.TestSomething', time=decimal.Decimal(17.43))
        ],
        system_out='Output\n',
        system_err='Errors\n',
    )


# Generated at 2022-06-23 13:36:44.819128
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    # Initialize local variables
    test_error = TestError()
    instance = TestError()
    test_case = TestCase()
    instance.errors.append(test_error)
    test_case.errors.append(test_error)
    assert instance.errors == test_case.errors


# Generated at 2022-06-23 13:36:46.297681
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    assert not TestResult() == TestResult()


# Generated at 2022-06-23 13:36:49.803162
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    assert TestSuites().to_pretty_xml() == '''<?xml version="1.0" ?>
<testsuites disabled="0" errors="0" failures="0" tests="0" time="0"/>'''

# Generated at 2022-06-23 13:36:54.745852
# Unit test for constructor of class TestError
def test_TestError():
    testResult = TestError("Wrong Result")
    assert testResult.message == "Wrong Result"
    assert testResult.output is None
    assert testResult.tag == 'error'
    assert testResult.type == 'error'
    
    

# Generated at 2022-06-23 13:36:59.625144
# Unit test for constructor of class TestSuites
def test_TestSuites():
    testSuites = TestSuites(name = 'Test_Result.xml')
    assert testSuites.name == 'Test_Result.xml'
    assert testSuites.suites == []
    assert testSuites.disabled == 0
    assert testSuites.errors == 0
    assert testSuites.failures == 0
    assert testSuites.tests == 0
    assert testSuites.time == 0



# Generated at 2022-06-23 13:37:02.619009
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    test_output = "test_output"
    test_message = "test_message"
    test_type = "test_type"

    a_test_error = TestError(test_output, test_message, test_type)
    assert a_test_error == eval(a_test_error.__repr__())


# Generated at 2022-06-23 13:37:13.419396
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    testcase1 = TestCase(name='test_add', time=0.319)
    testcase2 = TestCase(name='test_sub', time=0.234)
    testcase3 = TestCase(name='test_mul', is_disabled=True)
    testcase4 = TestCase(name='test_div', is_disabled=True)

    testsuite = TestSuite(name='math', id='math', timestamp=datetime.datetime.now())
    testsuite.cases.append(testcase1)
    testsuite.cases.append(testcase2)
    testsuite.cases.append(testcase3)
    testsuite.cases.append(testcase4)

    testsuites = TestSuites(name='test_math')
    testsuites.suites.append(testsuite)

# Generated at 2022-06-23 13:37:18.872259
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    first = TestFailure(output='output', message='message', type='type')
    second = TestFailure(output='output', message='message', type='type')
    third = TestFailure(output='output_1', message='message_1', type='type_1')
    
    assert first == second
    assert first != third


# Generated at 2022-06-23 13:37:21.572787
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    x = TestError("unit_error1")
    y = TestError("unit_error2")
    z = TestError("unit_error1")

    assert x == z
    assert x != y


# Generated at 2022-06-23 13:37:28.631261
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_suites = TestSuites(name='TestSuites')
    test_suite = TestSuite(name='TestSuite1')
    test_suite1 = TestSuite(name='TestSuite2')
    test_suites.suites.append(test_suite)
    test_suites.suites.append(test_suite1)
    test_case = TestCase(name='TestCase')
    test_case1 = TestCase(name='TestCase1')
    test_suite.cases.append(test_case)
    test_suite1.cases.append(test_case1)
    error = TestError(type='TypeError', message='Message', output='Output')
    test_case.errors.append(error)
    print(test_suites.to_pretty_xml())
   

# Generated at 2022-06-23 13:37:39.678642
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    print('Test de la méthode __repr__ de TestError')
    print()
    # Test de la méthode __repr__ sans valeurs par défaut
    test_error = TestError(None, None, None)
    assert test_error.__repr__() == None, "__repr__ ne fonctionne pas sans valeurs par défaut"

    # Test de la méthode __repr__ avec tous les paramètres
    test_error = TestError('output', 'message', 'type')
    assert test_error.__repr__() == "TestError(output='output', message='message', type='type')", "__repr__ ne fonctionne pas avec tous les paramètres valides"


# Generated at 2022-06-23 13:37:49.277107
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    datetime_test = datetime.datetime.now()
    test_case = TestCase(name="Test_Name", assertions=1, classname="class", status="done", time=0.001, errors=[], failures=[], system_out="system_out", system_err="system_err")
    test_suite = TestSuite(name="Suite_Name", hostname="hostname", id="0", package="package", timestamp=datetime_test, properties={"key":"value"}, cases=[test_case], system_out="system_out", system_err="system_err")
    
    root = test_suite.get_xml_element()
    assert root.tag == "testsuite"

# Generated at 2022-06-23 13:37:50.398475
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure() == TestFailure()

# Generated at 2022-06-23 13:37:54.954817
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testcase  = TestCase('test_name')
    element = testcase.get_xml_element()
    assert element.tag == 'testcase'
    assert element.attrib['name'] == 'test_name'


# Generated at 2022-06-23 13:38:01.786808
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    from pprint import pformat
    from unittest.mock import patch

    value = TestFailure(output='foo', message='bar', type='baz')
    expected = ("""TestFailure(
    output='foo',
    message='bar',
    type='baz',
)""")

    with patch('builtins.print') as mock_print:
        print(value)
    mock_print.assert_called_once_with(expected)

    with patch.object(pformat, 'pformat', wraps=pformat.pformat) as mock_pformat:
        print(pformat(value))
    mock_pformat.assert_called_once_with(value, indent=4, width=1)

    assert repr(value) == expected


# Generated at 2022-06-23 13:38:06.896716
# Unit test for constructor of class TestCase
def test_TestCase():
    case = TestCase("Test")
    assert case.is_failure is False
    assert case.is_error is False
    assert case.is_skipped is False
    assert case.get_attributes() is not None
    assert case.get_xml_element() is not None
    assert len(case.errors) == 0
    assert len(case.failures) == 0


# Generated at 2022-06-23 13:38:08.239501
# Unit test for constructor of class TestResult
def test_TestResult():
    test_result = TestResult()
    assert test_result is not None



# Generated at 2022-06-23 13:38:13.436768
# Unit test for constructor of class TestResult
def test_TestResult():
  t1 = TestResult(output="1", message="1", type="1")
  assert t1.output == "1"
  assert t1.message == "1"
  assert t1.type == "1"
  assert t1.tag == "error"
  assert t1.get_attributes() == {"message": "1", "type": "1"}



# Generated at 2022-06-23 13:38:18.813144
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
	instance = TestSuites()
	assert instance.get_attributes() == {}

	instance.tests = 3
	assert instance.get_attributes() == {'tests': '3'}

	instance.time = 10
	assert instance.get_attributes() == {'tests': '3', 'time': '10'}

# Generated at 2022-06-23 13:38:20.149718
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    return result.get_attributes() == {}


# Generated at 2022-06-23 13:38:26.539215
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """
    This is a test of the method get_xml_element for the class TestCase
    """
    test_case = TestCase('test_case_name', 'test_case_classname', 'test_case_status', 'test_case_time')
    test_errors = TestError('test_error_output', 'test_error_message', 'test_error_type')
    test_failures = TestFailure('test_failure_output', 'test_failure_message', 'test_failure_type')  
    test_case.errors.append(test_errors)
    test_case.failures.append(test_failures)
    test_case.system_out = 'test_case_system_out'
    test_case.system_err = 'test_case_system_err'
    test_case_xml

# Generated at 2022-06-23 13:38:35.066327
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # ARRANGE #
    testsuites = TestSuites(name="MyTestSuite",
                            suites=[TestSuite(name="MyTestSuitePart1",
                                              cases=[TestCase(name="MyTestCasePart1",
                                                              classname="MyTestClassPart1",
                                                              time=3.5)])])

    # ACT #
    result = testsuites.__repr__()

    # ASSERT #
    assert result == "TestSuites(name='MyTestSuite', suites=[TestSuite(name='MyTestSuitePart1', " \
                    "cases=[TestCase(name='MyTestCasePart1', classname='MyTestClassPart1', time=3.5)])])"

# Generated at 2022-06-23 13:38:47.014356
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test_suite_1 = TestSuite(name='test_suite_1')
    test_suite_2 = TestSuite(name='test_suite_2', disabled=2, errors=4, failures=4, skipped=4, timestamp=datetime.datetime.now(), tests=13, time=5.5)
    test_suites = TestSuites(name='test_suites')
    test_suites.suites.append(test_suite_1)
    test_suites.suites.append(test_suite_2)

    assert test_suites.get_attributes() == {'disabled': 6, 'errors': 8, 'failures': 8, 'name': 'test_suites', 'tests': 26, 'time': 11.0}


# Generated at 2022-06-23 13:38:50.029468
# Unit test for constructor of class TestError
def test_TestError():
    result_type = 'test '
    result_message = 'result message'
    result_output = 'result output'
    assert TestError(type=result_type, message=result_message, output=result_output)


# Generated at 2022-06-23 13:38:53.484852
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == dict()


# Generated at 2022-06-23 13:39:01.179302
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """
    Test method get_xml_element of class TestCase.
    The test consists of the instantiation of a test case
    and the comparison of the expected XML file corresponding
    to the input with the one obtained from the method.
    """
    # Creation of a test case
    name = 'check_factoring'
    assertions = 20
    classname = 'CheckFactoring'
    status = 'status'
    time = decimal.Decimal(0.003)
    output = 'output'
    message = 'message'
    type = 'type'
    error = TestError(output=output, message=message, type=type)
    failure = TestFailure(output=output, message=message, type=type)

# Generated at 2022-06-23 13:39:06.697426
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    test_suite = TestSuite(name='test_suite_name', timestamp= datetime.datetime.now())
    test_suites = TestSuites(name='test_suites_name', suites=[test_suite])
    test_suites2 = TestSuites(name='test_suites_name', suites=[test_suite])
    assert test_suites == test_suites2

# Generated at 2022-06-23 13:39:11.265364
# Unit test for method __repr__ of class TestSuites

# Generated at 2022-06-23 13:39:18.862665
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    some_TestCase = TestCase(
        name='some_name',
        assertions=123,
        classname='some_classname',
        status='some_status',
        time=0.123,
        errors=[TestError()],
        failures=[TestFailure()],
        skipped='some_skipped',
        system_out='some_system_out',
        system_err='some_system_err',
        is_disabled=True
    )

    assert some_TestCase.get_xml_element().tag == 'testcase'



# Generated at 2022-06-23 13:39:21.985613
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    assert TestCase(name='test_name').__repr__() == '<TestCase name=test_name>'


# Generated at 2022-06-23 13:39:25.011848
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    v100 = TestError(output="output", message="message", type="type")
    v101 = eval(repr(v100))
    assert v100 == v101



# Generated at 2022-06-23 13:39:27.080564
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    assert repr(TestSuite(name='test_name')) == 'TestSuite(name=\'test_name\')'

# Generated at 2022-06-23 13:39:29.010462
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult()) == "<TestResult object at 0x7f6413ece590>"


# Generated at 2022-06-23 13:39:32.817909
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testcase = TestCase(name="test_testcase")
    element = testcase.get_xml_element()
    expect = """\
<testcase assertions="None" classname="None" name="test_testcase" status="None" time="None"></testcase>\
"""
    assert _pretty_xml(element) == expect



# Generated at 2022-06-23 13:39:33.889110
# Unit test for constructor of class TestSuites
def test_TestSuites():
    TestSuites()


# Generated at 2022-06-23 13:39:44.102627
# Unit test for constructor of class TestCase
def test_TestCase():
    assert TestCase('testCaseName').name == 'testCaseName', 'TestCase constructor should set name of the test case to testCaseName'
    assert TestCase('testCaseName').assertions == None, 'TestCase constructor should have no assertions by default'
    assert TestCase('testCaseName').classname == None, 'TestCase constructor should have no classname by default'
    assert TestCase('testCaseName').status == None, "TestCase constructor should have no status by default"
    assert TestCase('testCaseName').time == None, 'TestCase constructor should have no time by default'
    assert TestCase('testCaseName').errors == [], 'TestCase constructor should have no errors by default'
    assert TestCase('testCaseName').failures == [], 'TestCase constructor should have no failures by default'

# Generated at 2022-06-23 13:39:48.861012
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    obj = TestFailure(output="This is output", message="This is message", type="This is type")
    obj2 = TestFailure(output="This is output", message="This is message", type="This is type")
    assert obj == obj2


# Generated at 2022-06-23 13:39:51.407367
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    obj = TestResult()
    assert repr(obj) == 'TestResult(None, None, None)'


# Generated at 2022-06-23 13:39:54.137357
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert _attributes(message=None,type=None) == test_result.get_attributes()



# Generated at 2022-06-23 13:39:58.764104
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    # Test with different values of attributes
    suites = TestSuites(name='name')
    other = TestSuites(name='Other')

    assert not suites == other

    # Test with different values of attributes
    suites = TestSuites()
    other = TestSuites(name='Other')

    assert not suites == other


# Generated at 2022-06-23 13:39:59.990217
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    pass


# Generated at 2022-06-23 13:40:02.274668
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    """Unit test for method __eq__ of class TestError."""
    assert TestError() == TestError()


# Generated at 2022-06-23 13:40:05.387448
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    test_2 = TestSuites()
    test_2.name = "TEST"
    test_3 = TestSuites()
    test_3.name = "TEST"
    assert test_3 == test_2



# Generated at 2022-06-23 13:40:16.442342
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    classname = "CompilerCfgTest"
    errors = ["error1", "error2"]
    failures = []
    is_disabled = False
    message = "message"
    name = "test_compiler_cfg_existing_value"
    output = "output"
    skipped = "skipped"
    status = "status"
    system_err = "system_err"
    system_out = "system_out"
    tag = "failure"
    time = 1.5
    type = "type"
    test_result1 = TestFailure(output, message, type)

# Generated at 2022-06-23 13:40:21.934644
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    output = "some test output"
    message = "some test message"
    type = "some test type"
    assert TestResult(output=output, message=message, type=type).get_xml_element() == ET.fromstring("""<test-result type="some test type" message="some test message">some test output</test-result>""")

# Generated at 2022-06-23 13:40:24.099093
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    a = TestCase("test_foo")
    b = TestCase("test_foo")
    assert a == b

# Generated at 2022-06-23 13:40:25.188588
# Unit test for constructor of class TestSuite
def test_TestSuite():
    assert TestSuite(name='test')

# Generated at 2022-06-23 13:40:29.616479
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    name = "test_name"
    disabled = 10
    errors = 20
    failures = 30
    tests = 40
    time = 50

    test_suites = TestSuites(
        name=name,
        disabled=disabled,
        errors=errors,
        failures=failures,
        tests=tests,
        time=time)

    expected_result = {
        'disabled': str(disabled),
        'errors': str(errors),
        'failures': str(failures),
        'name': name,
        'tests': str(tests),
        'time': str(time)
    }

    # Check if attributes are set
    assert test_suites.get_attributes() == expected_result

# Generated at 2022-06-23 13:40:33.991481
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    expected = "<class '__main__.TestFailure'>:\n{'output': 'output', 'message': 'message', 'type': 'type'}"
    test = TestFailure(output='output', message='message', type='type')
    actual = test.__repr__()
    assert actual == expected

# Generated at 2022-06-23 13:40:44.407510
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError(message='test_message', output='test_output', type='test_type')
    assert error.message == 'test_message'
    assert error.output == 'test_output'
    assert error.type == 'test_type'
    assert error.tag == 'error'

    error = TestError(message='test_message', type='test_type')
    assert error.message == 'test_message'
    assert error.output == None
    assert error.type == 'test_type'
    assert error.tag == 'error'

    error = TestError(type='test_type')
    assert error.message == None
    assert error.output == None
    assert error.type == 'test_type'
    assert error.tag == 'error'

    error = TestError(message='test_message')
    assert error

# Generated at 2022-06-23 13:40:48.523014
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite("test_name", hostname="host_name")
    assert_equal(ts.get_xml_element().tag, 'testsuite')
    print("Test - OK")


# Generated at 2022-06-23 13:40:56.427054
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    aTestCase = TestCase(name="test_name", classname="test_class", assertions="test_assertions", status="test_status", time="test_time")
    attr = aTestCase.get_attributes()
    print(attr)
    assert attr["name"] == "test_name"
    assert attr["classname"] == "test_class"
    assert attr["assertions"] == "test_assertions"
    assert attr["status"] == "test_status"
    assert attr["time"] == "test_time"


# Generated at 2022-06-23 13:41:07.646249
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # Case 1: given a TestSuite with a name, hostname, id, package, timestamp, properties, cases, system_out, system_err and another TestSuite with the same values,
    # the __eq__ method should return True.
    if TestSuite('name', 'hostname', 'id', 'package', datetime.datetime.now().timestamp(), {'property': 'value'}, [TestCase('name')], 'system_out', 'system_err') == TestSuite('name', 'hostname', 'id', 'package', datetime.datetime.now().timestamp(), {'property': 'value'}, [TestCase('name')], 'system_out', 'system_err'):
        print('Case 1: Passed')
    else:
        print('Case 1: Failed')

    # Case 2: given a TestSuite with

# Generated at 2022-06-23 13:41:14.566622
# Unit test for constructor of class TestResult
def test_TestResult():
   print("Test for TestResult constructor")
   def test_TestResult_constructor():
      try:
         assert TestResult(output="my output", message="my message", type="my type")
      except AssertionError as err:
         print("AssertionError encountered")
         print(err)
         return False
      return True
   if not test_TestResult_constructor():
      return False

   return True


# Generated at 2022-06-23 13:41:16.829552
# Unit test for constructor of class TestFailure
def test_TestFailure():
    failure_object = TestFailure('test_TestFailure')
    assert(failure_object.output == 'test_TestFailure')


# Generated at 2022-06-23 13:41:22.917782
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite('Test')
    suite.hostname = 'localhost'
    suite.tests = 1
    suite.failures = 1
    suite.disabled = 1
    suite.time = 5.5
    attributes = suite.get_attributes()
    assert attributes['hostname'] == 'localhost'
    assert attributes['tests'] == '1'
    assert attributes['failures'] == '1'
    assert attributes['disabled'] == '1'
    assert attributes['time'] == '5.5'

# Generated at 2022-06-23 13:41:28.657842
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite('suite', 'localhost')
    assert str(suite.get_attributes()['hostname']) == "localhost", 'test_TestSuite_get_attributes: hostname'
    assert str(suite.get_attributes()['name']) == 'suite', 'test_TestSuite_get_attributes: suite'
    assert str(suite.get_attributes()['errors']) == '0', 'test_TestSuite_get_attributes: errors'
    assert str(suite.get_attributes()['skipped']) == '0', 'test_TestSuite_get_attributes: skipped'
    assert str(suite.get_attributes()['failures']) == '0', 'test_TestSuite_get_attributes: failures'

# Generated at 2022-06-23 13:41:31.490517
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
  result1 = TestError('error','message','type','output')
  result2 = TestError('error','message','type','output')
  assert(result1 == result2)


# Generated at 2022-06-23 13:41:40.042894
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    """
    This function will test __eq__ method of class TestSuite with different parameters
    """
    s1 = TestSuite('s1')
    s2 = TestSuite('s1')
    assert s1 == s2
    s3 = TestSuite('s3')
    assert (s1 == s3) == False
    s4 = TestSuite('s1', 's4')
    assert s4 == s2
    s4 = TestSuite('s1', 's4', id='s4')
    assert (s4 == s2) == False
    s4 = TestSuite('s1', 's4', id='s4', package='s4')
    assert (s4 == s2) == False

# Generated at 2022-06-23 13:41:51.437389
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_suite1 = TestSuite(name='suite1', tests=1)
    test_suite2 = TestSuite(name='suite2', tests=2)
    test_suites = TestSuites(name='test_cases', suites=[test_suite1, test_suite2])
    assert test_suites.to_pretty_xml() == '''<?xml version="1.0" ?>
<testsuites name="test_cases" tests="3">
	<testsuite name="suite1" tests="1"/>
	<testsuite name="suite2" tests="2"/>
</testsuites>
'''
    test_suite1.cases=[TestCase(name='case1')]

# Generated at 2022-06-23 13:41:54.856668
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    expected = 'TestFailure(output=None, message=None, type=None)'

    test_object = TestFailure()

    # Check if output is correct
    assert test_object.__repr__() == expected


# Generated at 2022-06-23 13:42:08.065930
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    from datetime import datetime
    from decimal import Decimal

    # Build test suite
    suites = TestSuites(name='demo')
    suite = TestSuite(
        name='suite',
        timestamp=datetime(2017, 7, 14, 3, 37, 7, 333000),
    )
    suite.properties = {
        'key': 'value'
    }
    suite.system_out = 'This is stdout.'
    suite.system_err = 'This is stderr.'
    error = TestError.__new__(TestError)
    error.output = 'This is an error.'
    suite.cases.append(
        TestCase(
            name='case',
            classname='Class',
        )
    )

# Generated at 2022-06-23 13:42:10.988115
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    suite = TestSuites(name='test_suite_1')
    assert suite.get_attributes() == {'name': 'test_suite_1'}


# Generated at 2022-06-23 13:42:15.200266
# Unit test for constructor of class TestError
def test_TestError():
    TE = TestError(output='test Error message',type='JUnit test')
    assert TE.output == 'test Error message'
    assert TE.type == 'JUnit test'
    assert TE.tag == 'error'


# Generated at 2022-06-23 13:42:26.317462
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    result = []
    test_case_a = TestCase(name = "test_case_name_1", classname = "test_case_classname_1", time = datetime.datetime.now(), errors = [], failures = [])
    result.append(test_case_a == test_case_a)
    test_case_b = TestCase(name = "test_case_name_2", classname = "test_case_classname_2", time = datetime.datetime.now(), errors = [], failures = [])
    result.append(test_case_a == test_case_b)
    test_case_c = TestCase(name = "test_case_name_1", classname = "test_case_classname_1", time = datetime.datetime.now(), errors = [], failures = [])

# Generated at 2022-06-23 13:42:28.910486
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    """Unit test for method __post_init__ of class TestResult"""
    test_result = TestResult()
    assert test_result.type == test_result.tag


# Generated at 2022-06-23 13:42:33.238859
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # Test 1
    suite1 = TestSuite(name='foo', hostname='bar')
    suite2 = TestSuite(name='foo', hostname='bar')

    assert suite1 == suite2


# Generated at 2022-06-23 13:42:36.732350
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    assert TestSuites(name='name', suites=[TestSuite(name='suite')]) == TestSuites(name='name', suites=[TestSuite(name='suite')])

# Generated at 2022-06-23 13:42:44.080885
# Unit test for constructor of class TestSuites
def test_TestSuites():
    ts = TestSuites(name="Test1")
    assert ts.name == "Test1", "Name should be Test1"
    assert ts.suites == [], "Suites should be empty"
    assert ts.disabled == 0, "No tests suite, so disabled should be 0"
    assert ts.errors == 0, "No tests suite, so errors should be 0"
    assert ts.failures == 0, "No tests suite, so failures should be 0"
    assert ts.tests == 0, "No tests suite, so tests should be 0"
    assert ts.time == 0, "No tests suite, so time should be 0"


# Generated at 2022-06-23 13:42:51.382823
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """This function tests the output of the method get_xml_element of class TestResult."""
    result = TestResult(type='type of result', message='message of result', output='output of result')
    element = result.get_xml_element()
    assert element.tag == 'testresult'
    assert element.text == 'output of result'
    assert element.attrib['message'] == 'message of result'
    assert element.attrib['type'] == 'type of result'



# Generated at 2022-06-23 13:42:54.426982
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    ts = TestSuite('test1')
    assert str(ts) == "<__main__.TestSuite object at 0x7f4d35c1cef0>"

# Generated at 2022-06-23 13:42:55.616424
# Unit test for constructor of class TestSuites
def test_TestSuites():
    assert TestSuites() is not None


# Generated at 2022-06-23 13:43:04.035831
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    # Create two instances with the same attributes.
    a = TestSuites(name='foo')
    b = TestSuites(name='foo')
    assert a == b

    # Create two instances with different attributes.
    a = TestSuites(name='foo')
    b = TestSuites(name='bar')
    assert a != b

    # Create two instances with different types.
    a = TestSuites(name='foo')
    b = 'foo'
    assert a != b



# Generated at 2022-06-23 13:43:06.317687
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    # TestResult.__eq__(self, other)
    # TestResult.__eq__(self, other)
    assert True

# Generated at 2022-06-23 13:43:10.375457
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    a = TestSuite(name='a', hostname='b', id='c', package='d')
    assert repr(a) == "TestSuite(name='a', hostname='b', id='c', package='d', properties={}, cases=[], system_out=None, system_err=None)"



# Generated at 2022-06-23 13:43:11.192734
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    pass



# Generated at 2022-06-23 13:43:14.241180
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    tc1 = TestCase('foo')
    tc2 = TestCase('foo')
    tc3 = TestCase('bar')

    assert tc1 == tc2
    assert not tc1 == tc3
    assert not tc1 == 'foo'

