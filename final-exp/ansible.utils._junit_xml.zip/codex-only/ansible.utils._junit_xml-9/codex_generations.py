

# Generated at 2022-06-23 13:33:24.716165
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite('test suite name', id='id_name', hostname='host', timestamp=datetime.datetime.now())
    ts.properties['property_key'] = 'property_value'
    ts.cases.append(TestCase('test_name'))
    ts.system_out = 'system_out'
    ts.system_err = 'system_err'
    ts_xml = ts.get_xml_element()
    assert ts_xml.tag == 'testsuite'
    assert ts_xml.attrib.get('name') == 'test suite name'
    assert ts_xml.attrib.get('id') == 'id_name'
    assert ts_xml.attrib.get('hostname') == 'host'
    assert ts_xml.attrib.get('tests') == '1'
    assert len

# Generated at 2022-06-23 13:33:28.763138
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # test with empty input
    result = TestResult()
    assert result.get_attributes() == {}

    # test with a valid input
    result = TestResult(output=None, message="unit test message", type="unit")
    assert result.get_attributes() == {'message': 'unit test message', 'type': 'unit'}



# Generated at 2022-06-23 13:33:40.122669
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
  assert TestFailure() == TestFailure()
  assert TestFailure(message='Message') == TestFailure(message='Message')
  assert TestFailure(output='Output') == TestFailure(output='Output')
  assert TestFailure(type='Type') == TestFailure(type='Type')
  assert TestFailure(message='Message', output='Output') == TestFailure(message='Message', output='Output')
  assert TestFailure(message='Message', type='Type') == TestFailure(message='Message', type='Type')
  assert TestFailure(output='Output', type='Type') == TestFailure(output='Output', type='Type')
  assert TestFailure(message='Message', output='Output', type='Type') == TestFailure(message='Message', output='Output', type='Type')
  assert TestFailure(message='Message1') != TestFailure(message='Message2')
  assert Test

# Generated at 2022-06-23 13:33:47.908497
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output="This is an error", message="Testing output", type="Not an error")
    result_xml = result.get_xml_element()
    assert result_xml.tag == "error"
    assert result_xml.attrib.get("message") == "Testing output"
    assert result_xml.attrib.get("type") == "Not an error"
    assert result_xml.text == "This is an error"


# Generated at 2022-06-23 13:33:51.109551
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    a = TestSuites('a',[])
    b = TestSuites('b',[])
    if a.get_attributes() == b.get_attributes():
        assert True
    else:
        assert False


# Generated at 2022-06-23 13:33:55.897959
# Unit test for constructor of class TestSuite
def test_TestSuite():
    case1 = TestCase(name="test_fib_recurse")
    case2 = TestCase(name="test_fib_loop")
    suite = TestSuite(name="fibonacci", cases=[case1, case2])
    assert suite.time == 0
    assert suite.tests == 2
    assert suite.disabled == 0
    assert suite.errors == 0
    assert suite.failures == 0
    assert suite.skipped == 0

# Generated at 2022-06-23 13:34:01.345578
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    # Setup
    testFailure = TestFailure(output='This is an output text', message='This is a message text', type='typeText')

    # Act
    result = testFailure.__repr__()

    # Assert
    assert result == 'TestFailure(output=This is an output text, message=This is a message text, type=typeText)'


# Generated at 2022-06-23 13:34:08.164901
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    assert(_attributes() == {})
    assert(_attributes(disabled=1) == {'disabled': '1'})
    assert(_attributes(errors=1) == {'errors': '1'})
    assert(_attributes(failures=1) == {'failures': '1'})
    assert(_attributes(name='FakeName') == {'name': 'FakeName'})
    assert(_attributes(tests=1) == {'tests': '1'})
    assert(_attributes(time=1) == {'time': '1'})


# Generated at 2022-06-23 13:34:11.279948
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    failure = TestFailure(output='error message', message='error message', type='type')
    assert failure.get_attributes() == {'message': 'error message', 'type': 'type'}


# Generated at 2022-06-23 13:34:14.006307
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    assert TestError().type == 'error'
    assert TestFailure().type == 'failure'


# Generated at 2022-06-23 13:34:17.802099
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert eval(str(TestResult(output='out', message='msg', type='t'))) == eval(repr(TestResult(output='out', message='msg', type='t')))
    

# Generated at 2022-06-23 13:34:26.657486
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult(output='something', message='a message', type='a type')) == 'TestResult(output=\'something\', message=\'a message\', type=\'a type\')'
    assert repr(TestResult(output='something', message='a message')) == 'TestResult(output=\'something\', message=\'a message\', type=\'TestResult\')'
    assert repr(TestResult(output='something')) == 'TestResult(output=\'something\', message=None, type=\'TestResult\')'
    assert repr(TestResult()) == 'TestResult(output=None, message=None, type=\'TestResult\')'



# Generated at 2022-06-23 13:34:31.723128
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    a = TestCase(name = 'First', assertions = 2)
    b = TestCase(name = 'Second', assertions = 3)
    c = TestCase(name = 'First', assertions = 2)

    assert(a == b) is False
    assert(a == c) is True

# Generated at 2022-06-23 13:34:35.240341
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    failures = TestFailure(output="test output", message="test message", type="failure")
    assert failures.output == "test output"
    assert failures.message == "test message"
    assert failures.type == "failure"



# Generated at 2022-06-23 13:34:41.226511
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
     print("Test Case: Method __eq__")
     t = TestError()
     t.type = 'type1'
     t.message = 'message1'
     t.output = 'output1'
     t1 = TestError()
     t1.type = 'type1'
     t1.message = 'message1'
     t1.output = 'output1'
     assert t == t1
     print("Test Success")


# Generated at 2022-06-23 13:34:47.441307
# Unit test for constructor of class TestCase
def test_TestCase():
    test_class = TestCase('name', 'classname',  assertions=1, status='status', time=1.0)
    assert test_class.name == 'name'
    assert test_class.classname == 'classname'
    assert test_class.assertions == 1
    assert test_class.status == 'status'
    assert test_class.time == 1.0


# Generated at 2022-06-23 13:34:58.014205
# Unit test for constructor of class TestSuite

# Generated at 2022-06-23 13:35:10.066724
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """TestCase.get_xml_element() should return an XML element."""
    tci = TestCase('test01')
    assert tci.get_xml_element() == ET.fromstring('<testcase name="test01" />')

    tci.errors.append(TestError('Test error', type='test'))
    tci.failures.append(TestFailure('Test failure'))
    tci.skipped = 'Skipped'
    tci.system_out = 'Test\noutput'
    tci.system_err = 'Test\nerror'


# Generated at 2022-06-23 13:35:15.169700
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    assert repr(TestSuite('test_name')) == "TestSuite(name='test_name', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)"


# Generated at 2022-06-23 13:35:17.564707
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Create instance of TestResult
    test_result = TestResult(None)
    assert _attributes(type = None) == test_result.get_attributes()


# Generated at 2022-06-23 13:35:28.444319
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # create a TestResult instance
    test_result = TestResult(output='TestResult output', message='TestResult message', type='TestResult type')
    
    # create an XML element representing the TestResult instance
    xml_element = test_result.get_xml_element()

    # assert that the tag equals to the tag returned by the property tag
    assert xml_element.tag == test_result.tag
    
    # call the get_attributes method and assert that it returns a dictionary with the message and type attributes
    assert test_result.get_attributes() == {'message': 'TestResult message', 'type': 'TestResult type'}
    
    # assert that the text of the XML element equals to the output of the TestResult instance
    assert xml_element.text == test_result.output



# Generated at 2022-06-23 13:35:33.718474
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult(output="This is some output", message="This is some message", type="This is some type")
    element = result.get_xml_element()
    assert element.tag == "TestResult"
    assert element.attrib["type"] == "This is some type"
    assert element.attrib["message"] == "This is some message"
    assert element.text == "This is some output"


# Generated at 2022-06-23 13:35:45.166365
# Unit test for constructor of class TestResult
def test_TestResult():
    # Test for a test failure assertion
    # The message will be present
    # The type of the message will be failure
    # The output is presented
    test_result = TestResult("This is the message", "This is the output")
    assert test_result.type == "failure"
    assert test_result.message == "This is the message"
    assert test_result.output == "This is the output"

    # Test for a skipped test
    # The result type of the test will be skipped
    # The message will be present
    test_result = TestResult("This is the message", type="skipped")
    assert test_result.type == "skipped"
    assert test_result.message == "This is the message"

    # Check the post init method
    # If the type is not set, it will be set to the default
   

# Generated at 2022-06-23 13:35:48.088938
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    inst = TestError(output='test', type='test', message='test')
    assert repr(inst) == 'TestError(output=\'test\', message=\'test\', type=\'test\')'


# Generated at 2022-06-23 13:35:52.951956
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Test attributes that are None
    TestResult()
    # Test attributes that are string
    assert TestResult(
        output='Some text',
        message='A message',
        type='anType'
    ).get_attributes() == {
        'message': 'A message',
        'type': 'anType'
    }


# Generated at 2022-06-23 13:35:55.640749
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite("test_suite")
    assert test_suite.get_attributes() == {
        "errors": 0,
        "name": "test_suite",
        "tests": 0,
        "failures": 0,
        "disabled": 0,
        "skipped": 0,
    }


# Generated at 2022-06-23 13:36:09.049399
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    # Create TestSuite object with all attributes
    newTestSuite = TestSuite(
        'TestSuite1',
        hostname='localhost',
        id='test_id',
        package='default',
        timestamp=datetime.datetime.strptime('2020-06-09T11:26:00', '%Y-%m-%dT%H:%M:%S'),
        properties={'python':'3.7'},
        cases=[],
        system_out='The output of the test',
        system_err='The error of the test'
    )
    # Check if the ouput of get_attributes() is a dict
    assert type(newTestSuite.get_attributes()) == dict
    # Check if all attributes are in the dict

# Generated at 2022-06-23 13:36:20.005807
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    import os, sys

    sys.path.append("..")
    from junit_xml import TestCase

    # setup testcase
    simple_testcase = TestCase("simple testcase")

    # test with simple testcase
    xml_string = simple_testcase.get_xml_element()
    assert ET.tostring(xml_string, encoding="unicode") == """<testcase name="simple testcase" />"""

    # setup testcase with all fields
    testcase_all_fields = TestCase("name", 1, "classname", "status", 0.1, ["error"], ["failure"], "skipped", "system_out", "system_err")
    
    # test with testcase with all fields
    xml_string = testcase_all_fields.get_xml_element()

# Generated at 2022-06-23 13:36:24.663051
# Unit test for constructor of class TestResult
def test_TestResult():
    expected_output = 'Test error log.'
    expected_message = 'Test error message.'
    expected_type = 'Test error type.'
    test_result = TestResult(
        output=expected_output,
        message=expected_message,
        type=expected_type,
    )

    assert test_result.output == expected_output
    assert test_result.message == expected_message
    assert test_result.type == expected_type



# Generated at 2022-06-23 13:36:37.448175
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    class TestClass:
        def __init__(self):
            self.test = TestSuites("testName")
            self.test1 = TestSuites("testName")
            self.test2 = TestSuites("testName2")
            self.test3 = TestSuites("")
            self.test4 = TestSuites("")
            self.test5 = ""

        def TestMethod(self):
            return self.test.__eq__(self.test1)

        def TestMethod1(self):
            return self.test.__eq__(self.test2)

        def TestMethod2(self):
            return self.test3.__eq__(self.test4)

        def TestMethod3(self):
            return self.test.__eq__(self.test5)

    TestClass = TestClass()

    Test

# Generated at 2022-06-23 13:36:42.280880
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(message='mes', type='typ')
    assert result.get_attributes() == {'message': 'mes', 'type': 'typ'}


# Generated at 2022-06-23 13:36:54.270132
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    """
    Test get_attributes() method for class TestSuites
    """
    test_obj = TestSuite()
    test_obj.name = "TestSuite"
    test_obj.classes = [TestCase()]

    ts1 = TestSuites()
    ts1.name = "TestSuites"
    ts1.suites = [test_obj]
    assert (ts1.get_attributes()['name'] == "TestSuites")
    assert (ts1.get_attributes()['disabled'] == "0")
    assert (ts1.get_attributes()['errors'] == "0")
    assert (ts1.get_attributes()['failures'] == "0")
    assert (ts1.get_attributes()['tests'] == "0")

# Generated at 2022-06-23 13:37:00.514496
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    assert TestSuite('suite1').get_attributes() == {
                   'name': 'suite1', 'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0, 'time': 0}
    assert TestSuite('suite1', hostname='localhost').get_attributes() == {
                   'name': 'suite1', 'tests': 0, 'failures': 0, 'errors': 0, 'skipped': 0, 'time': 0, 'hostname': 'localhost'}


# Generated at 2022-06-23 13:37:05.226733
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_instance = TestFailure('output', 'message', 'type')
    expected = "TestFailure(output='output', message='message', type='type')"
    assert test_instance.__repr__() == expected


# Generated at 2022-06-23 13:37:08.791033
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult("output", "message", "type")
    assert result.output == "output"
    assert result.message == "message"
    assert result.type == "type"


# Generated at 2022-06-23 13:37:14.088777
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
	testcase = TestCase(
		name="TestCaseName",
		classname="TestCaseClassName",
		time=1.25
	)

	result = testcase.get_xml_element()
	expected = '<testcase assertions="None" classname="TestCaseClassName" name="TestCaseName" status="None" time="1.25"/>'

	assert str(result) == expected	


# Generated at 2022-06-23 13:37:15.596952
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert str(TestResult()) == 'TestResult(output=None, message=None, type=None)'


# Generated at 2022-06-23 13:37:18.711313
# Unit test for constructor of class TestFailure
def test_TestFailure():
    failure = TestFailure()

    assert failure.tag == 'failure'
    assert failure.get_attributes() == {}
    assert failure.get_xml_element().tag == 'failure'


# Generated at 2022-06-23 13:37:22.439019
# Unit test for constructor of class TestError
def test_TestError():

    output = "test"
    message = "message"
    testError = TestError(output,message)
    if (testError.type == testError.tag and testError.tag == 'error'):
        print("test_TestError PASS")
    else:
        print("test_TestError FAIL")


# Generated at 2022-06-23 13:37:25.234887
# Unit test for constructor of class TestFailure
def test_TestFailure():
    error = TestFailure(message='Dummy message',
                        output='Dummy output')

    assert isinstance(error, TestResult)

    assert error.message == 'Dummy message'
    assert error.output == 'Dummy output'


# Generated at 2022-06-23 13:37:29.281220
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    some_test = TestCase(name='some_test')
    assert some_test.get_attributes() == {'name': 'some_test'}


# Generated at 2022-06-23 13:37:32.169534
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    class_ = TestCase('name')
    x = repr(class_)
    assert x == "TestCase(name='name')"


# Generated at 2022-06-23 13:37:42.657598
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    assert (TestSuites(name=None, suites=[]) == TestSuites(name=None, suites=[]))

    assert (TestSuites(name=None, suites=[]) != TestSuites(name=None, suites=[TestSuite(name='a', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)]))


# Generated at 2022-06-23 13:37:47.778418
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    attribute = {'name': 'test_name', 'classname': 'class_name', 'time': '2.5', 'status': 'status_name'}
    test_case_sample = TestCase(name='test_name', classname='class_name', time=decimal.Decimal('2.5'), status='status_name')
    assert test_case_sample.get_attributes() == attribute


# Generated at 2022-06-23 13:37:49.523100
# Unit test for constructor of class TestFailure
def test_TestFailure():
    TestFailure(output="some_output.txt", message="some message")

# Generated at 2022-06-23 13:37:58.658998
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    for tag in ['failure', 'error']:
        result = TestFailure(message='Test message', type=tag) if tag == 'failure' else TestError(message='Test message', type=tag)
        assert result.get_attributes() == {'message': 'Test message', 'type': tag}

        result = TestFailure(message='Test message') if tag == 'failure' else TestError(message='Test message')
        assert result.get_attributes() == {'message': 'Test message', 'type': tag}

        result = TestFailure(type=tag) if tag == 'failure' else TestError(type=tag)
        assert result.get_attributes() == {'type': tag}

        result = TestFailure() if tag == 'failure' else TestError()

# Generated at 2022-06-23 13:38:07.593988
# Unit test for constructor of class TestCase
def test_TestCase():
    # Test case with no parameters
    tc = TestCase("Test")
    assert tc.name == "Test"
    assert tc.assertions is None
    assert tc.classname is None
    assert tc.status is None
    assert tc.time is None

    # Test case with all parameters
    tc = TestCase("Test", assertions=2, classname="Foo", status="FAILURE", time=1.1)
    assert tc.name == "Test"
    assert tc.assertions == 2
    assert tc.classname == "Foo"
    assert tc.status == "FAILURE"
    assert tc.time == 1.1

# Testing the function that creates attributes

# Generated at 2022-06-23 13:38:11.283896
# Unit test for constructor of class TestCase
def test_TestCase():
    test = TestCase('name', 3, 'class', 'success', 1)
    assert test.name == 'name'
    assert test.assertions == 3
    assert test.classname == 'class'
    assert test.status == 'success'
    assert test.time == 1

# Generated at 2022-06-23 13:38:23.228690
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        name='test',
        assertions=2,
        classname='TestClass',
        status='OK',
        time=decimal.Decimal(0.123),
        errors=[
            TestError(output='It failed', message='It failed', type='Failure'),
        ],
        failures=[
            TestFailure(output='It failed', message='It failed', type='Failure'),
        ],
    )

    output = test_case.get_xml_element()


# Generated at 2022-06-23 13:38:27.106015
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    try:
        result = TestError.__repr__()
    except Exception as e:
        result = False
        raise e
    return result


# Generated at 2022-06-23 13:38:32.138415
# Unit test for constructor of class TestCase
def test_TestCase():

    TestCase('add_three', assertions=3, classname='test_add_three', status='pass', time=2.1, \
        output='OK', message='error', type='error', is_disabled=True, errors=

        TestError(output='OK', message='error', type='error'))


# Generated at 2022-06-23 13:38:40.136200
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
	cases = [TestCase(name="TestCase")]
	suites = [TestSuite(name="TestSuite", cases=cases)]
	suites = TestSuites(suites=suites)
	suites_xml_element = suites.get_xml_element()
	assert suites_xml_element.tag == 'testsuites'
	assert len(suites_xml_element.getchildren()) == 1
	suite_xml_element = suites_xml_element[0]
	assert suite_xml_element.tag == 'testsuite'
	assert len(suite_xml_element.getchildren()) == 1
	case_xml_element = suite_xml_element[0]
	assert case_xml_element.tag == 'testcase'

# Generated at 2022-06-23 13:38:44.101877
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    test_result = TestResult(output='Error', message='Something wrong is going on', type='error')
    test_error = TestError('Error', message='Something wrong is going on', type='error')
    assert test_result == test_error


# Generated at 2022-06-23 13:38:48.326347
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Unit test for method get_xml_element of class TestCase"""
    test_case = TestCase(
        name="test",
        assertions=1,
        classname="test_class",
        status="test_failure",
        time=1
    )
    assert test_case.get_xml_element()

# Generated at 2022-06-23 13:38:59.078197
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_suites = TestSuites(
        name='Test Suites',
        suites=[
            TestSuite(
                name='Test Suite 1',
                timestamp=datetime.datetime(2020, 1, 1, 0, 0, 0),
                cases=[
                    TestCase(
                        name='Test Case 1',
                        classname='test_class',
                    ),
                    TestCase(
                        name='Test Case 2',
                        classname='test_class',
                    ),
                ],
            ),
        ],
    )

    # This XML string can be used to validate the XSD schema for JUnit XML files.

# Generated at 2022-06-23 13:39:08.650667
# Unit test for constructor of class TestSuite
def test_TestSuite():
	suite = TestSuite(name='test1', hostname='test2', id='test3', package='test4', timestamp='2019-02-03T04:05:06', properties={'name1': 'value1'}, cases=None, system_out=None, system_err=None)
	assert suite.name == 'test1'
	assert suite.hostname == 'test2'
	assert suite.id == 'test3'
	assert suite.package == 'test4'
	assert suite.timestamp == '2019-02-03T04:05:06'
	assert suite.properties == {'name1': 'value1'}
	assert suite.cases is None
	assert suite.system_out is None
	assert suite.system_err is None


# Generated at 2022-06-23 13:39:16.297730
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    tc = TestCase(
        name='test_add',
        assertions=1,
        classname='adder_test',
        status='notrun',
        time=2.5
    )
    
    assert tc.get_attributes() == {
        'name': 'test_add',
        'assertions': '1',
        'classname': 'adder_test',
        'status': 'notrun',
        'time': '2.5'
    }


# Generated at 2022-06-23 13:39:23.784928
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    # Init
    name1 = "name"
    classname1 = "classname"
    name2 = "name"
    classname2 = "classname2"
    name3 = "name2"
    classname3 = "classname"
    name4 = "name"
    classname4 = "classname"
    testCase1 = TestCase(name=name1, classname=classname1)
    testCase2 = TestCase(name=name2, classname=classname2)
    testCase3 = TestCase(name=name3, classname=classname3)
    testCase4 = TestCase(name=name4, classname=classname4)
    # Assert
    assert(testCase1.__eq__(testCase2) == False)

# Generated at 2022-06-23 13:39:26.741610
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert TestResult(
        output='Test error',
        message='Test error message',
        type='mytype'
    ).get_attributes() == {'message': 'Test error message', 'type': 'mytype'}



# Generated at 2022-06-23 13:39:29.174822
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    TestResult.__repr__ = 0
    try:
        TestResult.__repr__
    except AttributeError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 13:39:34.129536
# Unit test for constructor of class TestFailure
def test_TestFailure():
    message = "This is failing"
    type = "java.io.IOException"
    output = "Output"
    testFailure = TestFailure(output, message, type)
    assert testFailure.output == output
    assert testFailure.message == message
    assert testFailure.type == type
    assert testFailure.tag == 'failure'


# Generated at 2022-06-23 13:39:39.394176
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    testresult = TestResult('The output', 'The message')
    assert testresult.get_xml_element().attrib == {'message': 'The message', 'type': 'failure'}
    assert testresult.get_xml_element().text == 'The output'
    assert testresult.get_xml_element().tag == 'failure'



# Generated at 2022-06-23 13:39:41.245775
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():

    test_suite = TestSuite('name')

    assert test_suite == eval(repr(test_suite))

# Generated at 2022-06-23 13:39:47.106195
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult()) == 'TestResult(output=None, message=None, type=None)'
    assert repr(TestResult(output='output')) == 'TestResult(output=\'output\', message=None, type=None)'
    assert repr(TestResult(output='output', message='message')) == 'TestResult(output=\'output\', message=\'message\', type=None)'
    assert repr(TestResult(output='output', message='message', type='type')) == 'TestResult(output=\'output\', message=\'message\', type=\'type\')'



# Generated at 2022-06-23 13:39:52.623933
# Unit test for constructor of class TestSuites
def test_TestSuites():
   testSuites = TestSuites()
   assert testSuites.name is None
   assert testSuites.suites == []
   assert testSuites.disabled == 0
   assert testSuites.errors == 0
   assert testSuites.failures == 0
   assert testSuites.tests == 0
   assert testSuites.time == decimal.Decimal(0)
   assert testSuites.get_attributes() == {
               'disabled': '0',
               'errors': '0',
               'failures': '0',
               'tests': '0',
               'time': '0'
           }
   assert testSuites.get_xml_element().tag == 'testsuites'


# Generated at 2022-06-23 13:40:02.083073
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():

    t_cases = [
        TestCase('run_on_docker_file', classname='TestRunner', time=1.5),
        TestCase('run_on_docker_file', classname='TestRunner', time=2.0),
        TestCase('run_on_docker_file', classname='TestRunner', time=1.5),
    ]
    t_suite = TestSuite(
        name='TEST-org.junit.Test',
        timestamp=datetime.datetime(2020, 7, 29, 20, 54, 31),
        cases=t_cases,
        properties={'test': 'org.junit.Test', 'timestamp': '1596018671021'},
    )

# Generated at 2022-06-23 13:40:07.278728
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    result = TestCase("name").get_attributes()
    assert result == {'name': 'name'}

    result = TestCase("name", classname="classname").get_attributes()
    assert result == {'name': 'name', 'classname': 'classname'}


# Generated at 2022-06-23 13:40:14.198104
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    ts = TestSuite(name="test", errors=1, disabled=1, failures=1, skipped=1, hostname="hostname",
                   id="id", package="package", timestamp=datetime.datetime(2020, 10, 10, 0, 0, 0), tests=1, time=1)
    result = ts.get_attributes()
    assert result['name'] == "test"
    assert result['errors'] == "1"
    assert result['disabled'] == "1"
    assert result['failures'] == "1"
    assert result['skipped'] == "1"
    assert result['hostname'] == "hostname"
    assert result['id'] == "id"
    assert result['package'] == "package"
    assert result['timestamp'] == "2020-10-10T00:00:00"

# Generated at 2022-06-23 13:40:17.039016
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    class SubTestResult(TestResult):
        tag = 'sub'

    assert SubTestResult().type == 'sub'

# Generated at 2022-06-23 13:40:23.688392
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    from pytest import raises
    from datetime import datetime
    from decimal import Decimal
    x = TestFailure(output='12345', message='12345', type='12345')
    assert repr(x) == 'TestFailure(output=\'12345\', message=\'12345\', type=\'12345\')'
    x = TestFailure()
    assert repr(x) == 'TestFailure()'

# Generated at 2022-06-23 13:40:32.684092
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    class TestResultSubclass(TestResult):
        @property
        def tag(self):
            return 'testresult'

    test_result = TestResultSubclass(
        output='test output',
        message='test message',
        type='test type',
    )

    assert test_result.get_xml_element().tag == 'testresult'
    assert test_result.get_xml_element().text == 'test output'
    assert test_result.get_xml_element().attrib['message'] == 'test message'
    assert test_result.get_xml_element().attrib['type'] == 'test type'


# Generated at 2022-06-23 13:40:41.694907
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    testsuite1 = TestSuite(name='ExampleTests', errors=0, failures=0, tests=2, disabled=0, time=decimal.Decimal('0.0'), timestamp=datetime.datetime(2020, 8, 20, 17, 46, 45), hostname='localhost')
    testsuite2 = TestSuite(name='ExampleTests', errors=0, failures=0, tests=2, disabled=0, time=decimal.Decimal('0.0'), timestamp=datetime.datetime(2020, 8, 20, 17, 46, 45), hostname='localhost')
    testsuites1 = TestSuites(suites=[testsuite1, testsuite2])
    testsuites2 = TestSuites(suites=[testsuite1, testsuite2])
    assert testsuites1 == testsuites2

# Generated at 2022-06-23 13:40:44.720831
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    r = TestResult
    assert repr(r) == '<class \'__main__.TestResult\'>'


# Generated at 2022-06-23 13:40:49.524348
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    # Setup
    TestFailure1 = TestFailure(output="Failed")
    TestFailure2 = TestFailure(output="Failed")
    # Exercise
    Result = TestFailure1 == TestFailure2
    # Verify
    assert Result == True


# Generated at 2022-06-23 13:40:57.020220
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    """
    Testing __eq__ method of TestCase
    """
    first_testcase = TestCase('TestCase1', 1, 'ClassName1', 'status1', 2)
    second_testcase = TestCase('TestCase1', 1, 'ClassName1', 'status1', 2)
    third_testcase = TestCase('TestCase3', 2, 'ClassName3', 'status3', 3)
    # Testing True
    assert first_testcase == second_testcase
    # Testing False
    assert first_testcase != third_testcase


# Generated at 2022-06-23 13:41:07.997390
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test_case1 = TestCase(name='test_case1')
    test_case2 = TestCase(name='test_case2')
    test_suite1 = TestSuite(name='test_suite1', cases=[test_case1, test_case2])

    test_case3 = TestCase(name='test_case3')
    test_case4 = TestCase(name='test_case4')
    test_suite2 = TestSuite(name='test_suite2', cases=[test_case3, test_case4])

    test_suites = TestSuites(name='test_suites', suites=[test_suite1, test_suite2])
    test_suites_copy = TestSuites(name='test_suites', suites=[test_suite1, test_suite2])

   

# Generated at 2022-06-23 13:41:13.721249
# Unit test for constructor of class TestResult
def test_TestResult():
    _TestResult = TestResult("this is my output",
                             "this is my message",
                             "this is my type")
    assert _TestResult.output == "this is my output"
    assert _TestResult.message == "this is my message"
    assert _TestResult.type == "this is my type"


# Generated at 2022-06-23 13:41:19.056088
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    testResult = TestResult("test", message ="error", type="unittestError")
    element = testResult.get_xml_element()
    assert element.tag == "failure"
    assert element.text == "test"
    assert element.get("message") == "error"
    assert element.get("type") == "unittestError"



# Generated at 2022-06-23 13:41:32.115930
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    def check_instance(result, name, message, output, tag, type, xml):
        assert result.name == name
        assert result.message == message
        assert result.output == output
        assert result.tag == tag
        assert result.type == type
        assert result.xml == xml

    check_instance(TestFailure(name='name', message='message', output='output'),
                   name='name', message='message', output='output', tag='failure', type=None, xml='<failure message="message" type="failure">output</failure>')
    check_instance(TestError(name='name', message='message', output='output'),
                   name='name', message='message', output='output', tag='error', type=None, xml='<error message="message" type="error">output</error>')

# Generated at 2022-06-23 13:41:32.798499
# Unit test for constructor of class TestResult
def test_TestResult():
    pass


# Generated at 2022-06-23 13:41:37.714029
# Unit test for constructor of class TestSuites
def test_TestSuites():
    test_suites = TestSuites()
    test_suites.name = "Example"

    assert test_suites.name == "Example"
    assert test_suites.suites == []
    assert test_suites.disabled == 0
    assert test_suites.errors == 0
    assert test_suites.failures == 0
    assert test_suites.tests == 0
    assert test_suites.time == 0


# Generated at 2022-06-23 13:41:39.399325
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a = TestSuites()
    assert a == a


# Generated at 2022-06-23 13:41:46.337254
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """Tests method get_xml_element of class TestResult"""
    element = ET.Element('failure')
    element.text = 'Output'

    result = TestFailure(message='Message', output='Output', type='MyType')
    assert result.get_xml_element() == element

    result = TestFailure(message=None, output='Output', type='MyType')
    assert result.get_xml_element() == element

    result = TestFailure(message='Message', output=None, type='MyType')
    assert result.get_xml_element() == ET.Element('failure', {'message': 'Message', 'type': 'MyType'})


# Generated at 2022-06-23 13:41:51.247164
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    error_correct = TestError(type = "SystemError", message = "TEST_ERROR")
    error_incorrect = TestError(type = "SystemError", message = "TEST_ERROR")
    assert error_correct == error_incorrect

# Unit tests for method pretty_xml of class TestSuites

# Generated at 2022-06-23 13:41:55.348302
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    _o = TestResult()
    _exp = 'TestResult(output=None, message=None, type=None)'
    _res = repr(_o)
    assert _res == _exp, f'result: {_res!r} != expected: {_exp!r}'


# Generated at 2022-06-23 13:41:59.818577
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase(name='name', classname='classname', status='status', time=decimal.Decimal(1.2))
    attributes = test_case.get_attributes()
    assert attributes['name'] == 'name'
    assert attributes['classname'] == 'classname'
    assert attributes['status'] == 'status'
    assert attributes['time'] == '1.2'
    assert not 'assertions' in attributes


# Generated at 2022-06-23 13:42:03.185223
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    print("==Start test_TestCase___repr__==")
    TestCase(name="test_test_test")
    print("==End test_TestCase___repr__==")


# Generated at 2022-06-23 13:42:11.111859
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    tc = TestCase('test_sample')
    tc.time = decimal.Decimal("0.000001")
    tc.status = 'NotRun'
    
    xml_string = _pretty_xml(tc.get_xml_element())
    
    # Checking the output
    expected_string = """<?xml version="1.0" ?>
<testcase assertions="None" classname="None" name="test_sample" status="NotRun" time="0.000001"/>
"""
    assert xml_string == expected_string

# Generated at 2022-06-23 13:42:16.350171
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():

    obj = pytest.TestError()
    TestError_repr = repr(obj)
    assert isinstance(TestError_repr, str)
    assert TestError_repr.startswith("<pytest.TestError object")
    assert TestError_repr.endswith(">")


# Generated at 2022-06-23 13:42:22.615710
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    # Positive test
    assert TestResult() == TestResult()
    assert not TestResult() == TestResult(message='output')
    assert not TestResult() == TestResult(output='message')
    assert not TestResult() == TestResult(type='output')
    assert not TestResult() == TestResult(output='output', message='message')
    # Negative test
    assert not TestResult() == None
    assert not TestResult() == 'abc'


# Generated at 2022-06-23 13:42:24.919445
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError('Test output')
    assert error.output == 'Test output'


# Generated at 2022-06-23 13:42:25.800865
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # Codes to be tested
    pass

# Generated at 2022-06-23 13:42:28.909268
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    t_result = TestResult()
    assert t_result.get_attributes() == {'type' : 'testresult'}

# Test for method get_xml_element of class TestResult

# Generated at 2022-06-23 13:42:40.641328
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    t1 = TestResult(output="This is a get_attributes test output", message="This is a get_attributes test message", type="This is a get_attributes test type")
    t2 = TestResult(output="This is a get_attributes test output with no message", type="This is a get_attributes test type with no message")
    expected_output = {'message':'This is a get_attributes test message', 'type':'This is a get_attributes test type'}
    expected_output2 = {'type':'This is a get_attributes test type with no message'}
    assert t1.get_attributes() == expected_output
    assert t2.get_attributes() == expected_output2


# Generated at 2022-06-23 13:42:53.880557
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    assert TestCase(name='test_1').get_xml_element().tostring().decode('utf-8') == '<testcase name="test_1" />'
    assert (TestCase(name='test_1', classname='test_class').get_xml_element().tostring().decode('utf-8') ==
            '<testcase classname="test_class" name="test_1" />')
    assert (TestCase(name='test_1', status='success', assertions=1, time=0.1).get_xml_element().tostring().decode('utf-8') ==
            '<testcase assertions="1" name="test_1" status="success" time="0.1" />')

# Generated at 2022-06-23 13:42:56.240921
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    instance = TestFailure()
    result = instance.__repr__()
    assert isinstance(result, str)


# Generated at 2022-06-23 13:43:07.660594
# Unit test for constructor of class TestSuites
def test_TestSuites():
    testSuite = TestSuite.__new__(TestSuite)
    testSuite.name = "testSuite"
    testSuite.hostname = "localhost"
    testSuite.id = "123-456-789"
    testSuite.package = "test"
    testSuite.timestamp = datetime.datetime.now()
    testSuite.properties = {"property1": "value1", "property2": "value2"}
    testSuite.system_out = "test"
    testSuite.system_err = "test"
    testSuite.cases = [TestCase, TestCase]

    testSuites = TestSuites.__new__(TestSuites)
    testSuites.name = "testSuites"
    testSuites.suites = [testSuite, testSuite]

# Generated at 2022-06-23 13:43:14.790740
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert (TestError(output='foo', message='bar', type='baz')) == (TestError(output='foo', message='bar', type='baz'))
    assert (TestError(output='foo', message='bar', type='baz')) != (TestError(output='fooX', message='bar', type='baz'))
    assert (TestError(output='foo', message='bar', type='baz')) != (TestError(output='foo', message='barX', type='baz'))
    assert (TestError(output='foo', message='bar', type='baz')) != (TestError(output='foo', message='bar', type='bazX'))
