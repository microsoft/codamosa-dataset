

# Generated at 2022-06-23 13:33:13.993383
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert True



# Generated at 2022-06-23 13:33:19.186872
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestFailure(message='Error: the city was flooded', type='myTest')
    test_dict = {'message': 'Error: the city was flooded', 'type': 'myTest'}

    assert (result.get_attributes() == test_dict)

# Unit test method get_attribute of class TestCase

# Generated at 2022-06-23 13:33:27.073260
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    testsuite = TestSuite('name',
        hostname = 'hostname',
        id = 'id',
        package = 'package',
        timestamp = datetime.datetime.now(),
        disabled = 10,
        errors = 5,
        failures = 3,
        skipped = 6,
        tests = 20,
        time = 5.0,
        properties = {'prop1':'val1', 'prop2':'val2'}
    )

# Generated at 2022-06-23 13:33:33.844610
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    message = ['message1', 'message 2', 'message\n 3', 'message\t 4']
    output = ['output1', 'output 2', 'output\n 3', 'output\t 4']
    type_ = ['type1', 'type 2', 'type\n 3', 'type\t 4']

    for m in message:
        for o in output:
            for t in type_:
                error1 = TestError(message=m, output=o, type=t)
                error2 = TestError(message=m, output=o, type=t)

                assert error1 == error2
                assert not (error1 != error2)

                error1.message += 'x'

                assert error1 != error2
                assert not (error1 == error2)

                error1.message = m

                assert error1 == error2


# Generated at 2022-06-23 13:33:35.719486
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    assert TestResult().type is None
    assert TestFailure().type == TestFailure.tag
    assert TestError().type == TestError.tag


# Generated at 2022-06-23 13:33:37.389306
# Unit test for constructor of class TestFailure
def test_TestFailure():
    f = TestFailure(output=None, message=None, type=None)
    assert f.output == None
    assert f.message == None
    assert f.type == 'failure'


# Generated at 2022-06-23 13:33:42.259091
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # Test with default values
    obj = TestResult()
    assert repr(obj) == f'TestResult(output=None, message=None, type=None)'

    # Test with non-default values
    obj = TestResult(output='output', message='message', type='type')
    assert repr(obj) == f'TestResult(output=output, message=message, type=type)'


# Generated at 2022-06-23 13:33:47.959487
# Unit test for constructor of class TestFailure
def test_TestFailure():
    tFail = TestFailure('This is an error', 'This is a message', 'This is a type')
    assert tFail.output == 'This is an error'
    assert tFail.message == 'This is a message'
    assert tFail.type == 'This is a type'

if __name__ == "__main__":
    test_TestFailure()

# Generated at 2022-06-23 13:33:51.153000
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    testcase = TestSuite('name_property')
    expected_dict = {'name': 'name_property'}
    assert testcase.get_attributes() == expected_dict
    assert type(testcase.get_attributes()) == dict


# Generated at 2022-06-23 13:34:00.742504
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    """
    Tests the get_xml_element method of the TestSuite class and
    also the __post_init__ method of the TestResult base class.
    """


# Generated at 2022-06-23 13:34:09.229722
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    testsuite = TestSuite(
        name='TestSuite',
        hostname='Host',
        id=None,
        package='tests',
        timestamp=datetime.datetime.now(),
        properties={
            'key1': 'value1',
            'key2': 'value2',
            'key3': 'value3',
        })
    attributes = testsuite.get_attributes()
    assert attributes['name'] == 'TestSuite'
    assert attributes['hostname'] == 'Host'
    assert 'id' not in attributes
    assert attributes['package'] == 'tests'
    #assert attributes['timestamp'] == str(testsuite.timestamp.isoformat(timespec='seconds'))



# Generated at 2022-06-23 13:34:10.561806
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    t = TestSuites()
    assert t.get_attributes() == {}

# Generated at 2022-06-23 13:34:13.694666
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult()
    print(result)
    assert isinstance(result,TestResult)


# Generated at 2022-06-23 13:34:25.135625
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case = TestCase(
        name='test_case',
        assertions=1,
        classname='classname',
        status='status',
        time=1.5,

        errors=[
            TestError(
                output='output',
                message='message',
                type='type',
            ),
        ],

        failures=[
            TestFailure(
                output='output',
                message='message',
                type='type',
            ),
        ],

        skipped='skipped',
        system_out='system_out',
        system_err='system_err',
        is_disabled=True,
    )

    assert test_case == test_case
    assert test_case != TestCase(name='test_case')
    assert test_case != TestCase(name='test_case', assertions=1)
    assert test_

# Generated at 2022-06-23 13:34:28.778988
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    TestFailure(output='test_output',message='test_message',type='test_type') == TestFailure(output='test_output',message='test_message',type='test_type')


# Generated at 2022-06-23 13:34:38.377163
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    assert (TestSuite('name', hostname='hostname', id='id', package='package',
                          timestamp=datetime.datetime(year=2020, month=2, day=2, hour=2, minute=2,
                                                         second=2, microsecond=2)).get_attributes()
                == {'hostname': 'hostname', 'id': 'id', 'name': 'name',
                    'package': 'package', 'timestamp': '2020-02-02T02:02:02', 'errors': '0',
                    'tests': '0', 'failures': '0', 'skipped': '0', 'disabled': '0', 'time': '0'})

# Generated at 2022-06-23 13:34:46.244053
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    """Test method __repr__ of class TestCase."""
    name = 'test'
    assertions = 2
    classname = 'Test'
    status = 'test-status'
    time = 1.2
    errors = [TestError(type='type', message='message')]
    failures = [TestFailure(type='type', message='message')]
    skipped = 'reason'
    system_out = 'output'
    system_err = 'error'
    test_case = TestCase(name, assertions, classname, status, time, errors, failures, skipped, system_out, system_err)

# Generated at 2022-06-23 13:34:53.270382
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(
        assertions='4',
        name='TestCase',
        time='1.234',
        classname='Foo',
        system_err='stderr',
        system_out='stdout',
        status='bar',
    )
    test_case.errors.append(TestError(
        message='Oh no!',
        output='Something happened.',
        type='Error',
    ))
    test_case.failures.append(TestFailure(
        output='Something happened.',
        message='Oh no!',
        type='Failure',
    ))
    test_case.errors.append(TestError(
        message='Oh no!',
        output='Something happened.',
    ))

# Generated at 2022-06-23 13:34:59.464111
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    t = TestSuites(name ='TestSuite1',suites=[TestSuite(name='TestSuiteName')])
    assert t.get_xml_element().tag=='testsuites'
    assert t.get_xml_element().attrib['name']=='TestSuite1'
    assert t.get_xml_element()[0].tag=='testsuite'
    assert t.get_xml_element()[0].attrib['name']=='TestSuiteName'


# Generated at 2022-06-23 13:35:10.989911
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    # Test case 1: no attribute, blank
    # Expect
    expected = {}
    # Actual
    actual = TestSuite('name').get_attributes()
    assert actual == expected

    # Test case 2: have some attribute, below is just example
    # Expect
    expected = {'name': 'name', 'tests': 0, 'disabled': 0, 'errors': 0, 'failures': 0}
    # Actual
    actual = TestSuite('name').get_attributes()
    assert actual == expected

    # Test case 3: have some extra attribute, below is just example
    # Expect
    expected = {'name': 'name', 'tests': 0, 'disabled': 0, 'errors': 0, 'failures': 0, 'hostname': 'hostname', 'id': 'id', 'package': 'package', 'skipped': 0}


# Generated at 2022-06-23 13:35:20.942064
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Test the pretty XML string returned by TestSuites.to_pretty_xml()."""

    # Create suite instance

# Generated at 2022-06-23 13:35:32.221438
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    t1 = TestSuite(name='test_suite_1', timestamp=datetime.datetime.now())
    t2 = TestSuite(name='test_suite_2', timestamp=None)
    t3 = TestSuite(name='test_suite_3', timestamp=None, errors=3)
    t4 = TestSuite(name='test_suite_4', timestamp=None, tests=0)

    assert t1.get_attributes() == {'name': 'test_suite_1', 'timestamp': t1.timestamp.isoformat(timespec='seconds')}
    assert t2.get_attributes() == {'name': 'test_suite_2'}

# Generated at 2022-06-23 13:35:44.283717
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    xml = ET.fromstring(r"""<testsuites errors="0" failures="1" tests="1" disabled="0" name="" time="0.000"><testsuite errors="0" failures="1" tests="1" disabled="0" name="example" time="0.000"><testcase assertions="0" classname="example" name="test_me" status="run" time="0.000"><failure message="oops" type="failure">test failed</failure></testcase></testsuite></testsuites>""")
    test_suites = TestSuites(name='')
    test_suite = TestSuite(name='example')
    test_suite.cases.append(TestCase(name='test_me', assertions=0, classname='example', status='run', time=0.000))
    test_suite

# Generated at 2022-06-23 13:35:48.001420
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    testsuite1 = TestSuite('testsuite1')
    testsuite2 = TestSuite('testsuite2')
    assert testsuite1 == testsuite1
    assert testsuite1 != testsuite2


# Generated at 2022-06-23 13:35:52.452527
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    result = eval("TestCase(name='name', assertions=1, classname='classname', status='status', time=1)")
    expected = "TestCase(name='name', assertions=1, classname='classname', status='status', time=1)"
    assert result == expected


# Generated at 2022-06-23 13:36:00.505297
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite('name', hostname='hostname', package='package', timestamp=datetime.datetime(2020, 1, 1, 00, 10, 10))

    assert _attributes(
            disabled=test_suite.disabled,
            errors=test_suite.errors,
            failures=test_suite.failures,
            hostname=test_suite.hostname,
            id=test_suite.id,
            name=test_suite.name,
            package=test_suite.package,
            skipped=test_suite.skipped,
            tests=test_suite.tests,
            time=test_suite.time,
            timestamp='2020-01-01T00:10:10',
        ) == test_suite.get_attributes()

# Generated at 2022-06-23 13:36:04.523706
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert (TestFailure(message="msg1") == TestFailure(message="msg1"))
    assert (not(TestFailure(message="msg1") == TestFailure(message="msg2")))



# Generated at 2022-06-23 13:36:06.556330
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    case_a = TestCase(name='a')
    case_b = TestCase(name='b')

    assert case_a == case_a
    assert case_b == case_b

    assert case_a != case_b
    assert case_b != case_a


# Generated at 2022-06-23 13:36:08.569687
# Unit test for constructor of class TestSuite
def test_TestSuite():
    ts = TestSuite('Unit Test')

    assert ts.name == 'Unit Test'



# Generated at 2022-06-23 13:36:15.983207
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    class TestResult(metaclass=abc.ABCMeta):
        output = 'test'
        message = 'test'
        type = 'test'
        tag = 'test'
        def __post_init__(self):
            if self.type is None:
                self.type = self.tag
        def get_attributes(self):
            return _attributes(message=self.message, type=self.type)
        def get_xml_element(self):
            element = ET.Element(self.tag, self.get_attributes())
            element.text = self.output
            return element
    result = TestResult()
    expected_result = '<test message="test" type="test">test</test>'

    assert(result.get_xml_element() == expected_result)

# Generated at 2022-06-23 13:36:18.445898
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    TC = TestCase('test_TestCase___repr__')
    assert 'TestCase' == TC.__repr__()[:8]


# Generated at 2022-06-23 13:36:23.834686
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult()
    assert test_result.get_attributes() == {}
    assert TestResult(message="MESSAGE").get_attributes() == {'message': 'MESSAGE'}
    assert TestResult(output='OUTPUT').get_attributes() == {}
    assert TestResult(output='OUTPUT', message="MESSAGE").get_attributes() == {'message': 'MESSAGE'}



# Generated at 2022-06-23 13:36:28.934386
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    from datetime import datetime

    tr = TestResult(output='test output', message='test message', type='test type')
    assert tr.get_attributes() == {'message': 'test message', 'type': 'test type'}

    tr = TestResult(output='test output', message='test message', type=None)
    assert tr.get_attributes() == {'message': 'test message', 'type': 'testresult'}

# Generated at 2022-06-23 13:36:34.441282
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    obj = TestSuites()
    att = obj.get_attributes()
    assert att['disabled'] == '0'
    assert att['errors'] == '0'
    assert att['failures'] == '0'
    assert att['tests'] == '0'
    assert att['time'] == '0'


# Generated at 2022-06-23 13:36:35.868866
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    result = TestResult()
    assert result.type == 'unknown'



# Generated at 2022-06-23 13:36:42.253131
# Unit test for constructor of class TestSuite
def test_TestSuite():
    print("Testing constructor of class TestSuite")
    ts = TestSuite("foo")
    assert ts.name == "foo"
    assert ts.hostname == None
    assert ts.id == None
    assert ts.package == None
    assert ts.timestamp == None
    assert ts.properties == {}
    assert ts.cases == []
    assert ts.system_out == None
    assert ts.system_err == None
    assert ts.disabled == 0
    assert ts.errors == 0
    assert ts.failures == 0
    assert ts.skipped == 0
    assert ts.tests == 0
    assert ts.time == decimal.Decimal(0)


# Generated at 2022-06-23 13:36:49.961952
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    testcases = [TestCase(name='a'), TestCase(name='b')]
    suites = [TestSuite(name='c', cases=testcases,),
              TestSuite(name='d')]
    testsuites = TestSuites(name='e', suites=suites)
    assert testsuites.get_attributes() == {
        'disabled': 0,
        'errors': 0,
        'failures': 0,
        'name': 'e',
        'tests': 2,
        'time': 0
    }


# Generated at 2022-06-23 13:36:58.042432
# Unit test for constructor of class TestResult
def test_TestResult():
    # create a test result success
    result = TestResult()
    assert result.output is None
    assert result.message is None
    assert result.type is None

    # check the tag property
    assert result.tag == 'testresult'

    # check the is_success property
    assert result.is_success is True

    # create a test result failure
    result = TestResult()
    # check the tag property
    assert result.tag == 'testresult'

    # check the is_success property
    assert result.is_success is True


# Generated at 2022-06-23 13:36:59.320873
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    TestError.__repr__()

# Generated at 2022-06-23 13:37:02.946900
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    testcase = TestCase('Do something')
    assert repr(testcase) == 'TestCase(name="Do something")'


# Generated at 2022-06-23 13:37:10.511334
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase(
        name='test_case_name',
        assertions='20',
        classname='some_class_name',
        status='2',
        time='0.02'
    )

    assert test_case.get_attributes() == {
        'assertions': '20',
        'classname': 'some_class_name',
        'name': 'test_case_name',
        'status': '2',
        'time': '0.02'
    }



# Generated at 2022-06-23 13:37:11.969536
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    suite = TestSuite('UnitTest')
    suite.cases.append(TestCase('TestCase'))

    assert 'TestSuite' in str(suite)
    assert 'TestCase' in str(suite)

# Generated at 2022-06-23 13:37:15.672132
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite1 = TestSuite(name='name')
    suite2 = TestSuite(name='name')
    assert suite1 == suite2


# Generated at 2022-06-23 13:37:19.627000
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    assert _attributes(test=1) == {'test': '1'}
    assert _attributes(test=None) == {}
    assert _attributes(test1=1, test2=2) == {'test1': '1', 'test2': '2'}

# Generated at 2022-06-23 13:37:27.547239
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    tc = TestCase(
        name='test_case',
        assertions=0,
        classname='my_class',
        status='STATUS',
        time=1.5,

        errors=[TestError(
            output='ERROR_OUTPUT',
            message='ERROR_MESSAGE',
            type='ERROR_TYPE',
        )],

        failures=[TestFailure(
            output='FAILURE_OUTPUT',
            message='FAILURE_MESSAGE',
            type='FAILURE_TYPE',
        )],

        skipped='SKIPPED_MESSAGE',
        system_out='SYSTEM_OUT',
        system_err='SYSTEM_ERR',
    )


# Generated at 2022-06-23 13:37:38.592080
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Test to_pretty_xml method of class TestSuites"""

    suite = TestSuite(
        name='two-case-suite',
        hostname='localhost',
        id='1',
        package='one',
        timestamp=datetime.datetime.now(),
        properties={},
        system_out='test output',
        system_err='test error',
    )
    case1 = TestCase(
        name='one-case-one',
        assertions=10,
        classname='one.ClassOne',
        status='FAILURE',
        time=12.00,
    )
    case2 = TestCase(
        name='one-case-two',
        assertions=20,
        classname='one.ClassTwo',
        status='SUCCESS',
        time=42.00,
    )
   

# Generated at 2022-06-23 13:37:44.607797
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    t1 = TestSuite(name="TestSuite1")
    t2 = TestSuite(name="TestSuite1")
    assert t1 == t2
    
    t2.name = "TestSuite2"
    assert t1 != t2
    
    t2 = TestSuite(name="TestSuite1")
    t1.hostname = "NotThisOne"
    assert t1 != t2
    
    t2.hostname = "NotThisOne"
    assert t1 == t2
    
    t2.hostname = "NotThatOne"
    assert t1 != t2



# Generated at 2022-06-23 13:37:51.827531
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite(
        name="testsuite",
        hostname="example.com",
        id="1234",
        package="com.example",
        timestamp=datetime.datetime.now(),
    )
    attributes = test_suite.get_attributes()
    assert attributes.get('disabled') == '0'
    assert attributes.get('errors') == '0'
    assert attributes.get('failures') == '0'
    assert attributes.get('hostname') == 'example.com'
    assert attributes.get('id') == '1234'
    assert attributes.get('name') == 'testsuite'
    assert attributes.get('package') == 'com.example'
    assert attributes.get('skipped') == '0'
    assert attributes.get('tests') == '0'


# Generated at 2022-06-23 13:37:58.440120
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a = TestSuites(name='foo', suites=[TestSuite(name='bar', hostname='har', id='car', package='tar')])
    b = TestSuites(name='foo', suites=[TestSuite(name='bar', hostname='har', id='car', package='tar')])
    c = TestSuites(name='foo', suites=[TestSuite(name='bar', hostname='har', id='car', package='tar', timestamp=datetime.datetime.now())])
    assert a == b
    assert a != c

# Generated at 2022-06-23 13:38:04.810865
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    """
    Unit test for the __eq__ method of the TestSuites class
    """
    suite1 = TestSuites()
    suite1.suites = [TestSuite('suite 1')]
    suite2 = TestSuites()
    suite2.suites = [TestSuite('suite 1')]

    assert suite1 == suite2
    assert suite2 == suite1


# Generated at 2022-06-23 13:38:12.231581
# Unit test for constructor of class TestSuite
def test_TestSuite():
    ts = TestSuite(name = 'Example', hostname = 'Example host')
    print(ts.name, ts.hostname, ts.timestamp)

    if ts.name == 'Example':
        print('Name is correct')
    else:
        print('Name is incorrect')

    if ts.hostname == 'Example host':
        print('Hostname is correct')
    else:
        print('Hostname is incorrect')


# Generated at 2022-06-23 13:38:22.702810
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(name='test_1')
    ts.cases.append(TestCase(name='test_case_1'))
    ts.cases.append(TestCase(name='test_case_2'))
    assert ts.get_xml_element() == ET.Element('testsuite', {'name': 'test_1', 'tests': '2', 'time': '0', 'disabled': '0', 'skipped': '0', 'errors': '0', 'failures': '0'}, ET.Element('testcase', {'name': 'test_case_1'}), ET.Element('testcase', {'name': 'test_case_2'}))

# Generated at 2022-06-23 13:38:30.587997
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    a = TestFailure(output = 'some output', message = 'some message', type = 'some type')
    b = TestFailure(output = 'some output', message = 'some message', type = 'some type')
    c = TestFailure(output = 'c output', message = 'c message', type = 'c type')
    assert a == b
    assert b == a
    assert a != c
    assert c != a


# Generated at 2022-06-23 13:38:34.525060
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    expected = ET.Element('error', dict(message='message', type='type'))
    expected.text = 'output'
    assert expected == TestError(output='output', message='message', type='type').get_xml_element()


# Generated at 2022-06-23 13:38:41.446286
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    import unittest
    import sys
    if sys.version_info[0] == 2:
        import mock  # type: ignore
    else:
        from unittest import mock  # type: ignore
    a = TestResult("output", "message", "type")
    b = TestResult("output", "message", "type")
    c = TestResult("output", "message", "type")
    assert a == b
    assert hash(a) == hash(b)

    # The __eq__ function is defined.
    with mock.patch.object(TestResult, "__eq__", return_value=True) as mock_method:
        assert a == b
        mock_method.assert_called_once_with(c)


# Generated at 2022-06-23 13:38:45.357643
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """TestCase's get xml element."""
    testcase = TestCase('testcase')
    assert ET.tostring(testcase.get_xml_element()) == b'<testcase name="testcase" />'


# Generated at 2022-06-23 13:38:46.444298
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    TestSuites.__eq__

# Generated at 2022-06-23 13:38:54.205929
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase('test_case', time=1)
    test_case.errors = [TestError('error', message='error_message', output='error_output')]
    test_case.failures = [TestFailure('failure', message='failure_message', output='failure_output')]
    test_case.skipped = 'skipped'
    test_case.system_out = 'system_out'
    test_case.system_err = 'system_err'

    root = ET.Element('testsuite')
    root.append(test_case.get_xml_element())


# Generated at 2022-06-23 13:38:56.779206
# Unit test for constructor of class TestResult
def test_TestResult():
    a = TestResult("Output", "Message", "Type")
    assert a.output == "Output"
    assert a.message == "Message"
    assert a.type == "Type"


# Generated at 2022-06-23 13:38:59.188513
# Unit test for constructor of class TestError
def test_TestError():
    assert TestError(message="My message") is not None


# Generated at 2022-06-23 13:39:00.823829
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure() == TestFailure()



# Generated at 2022-06-23 13:39:03.879875
# Unit test for constructor of class TestError
def test_TestError():
    assert TestError().type == 'error'
    assert TestError('output', 'message', 'type').type == 'type'


# Generated at 2022-06-23 13:39:05.890584
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    a = TestFailure()
    b = TestFailure()
    assert a == b



# Generated at 2022-06-23 13:39:09.865678
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    t1 = TestCase('test1')
    t2 = TestCase('test1')
    assert t1 == t2


# Generated at 2022-06-23 13:39:15.541772
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    test_result_obj = TestSuites()
    print(f'Expected Value :')
    print(test_result_obj)
    # test_result_obj.__eq__()
    print(f'Actual outcome :')
    print(test_result_obj)
    assert test_result_obj == test_result_obj


# Generated at 2022-06-23 13:39:23.443172
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    failure1 = TestFailure(output='output', message='message', type='type')
    failure1_copy = TestFailure(output='output', message='message', type='type')
    output_diff = TestFailure(output='output_diff', message='message', type='type')
    message_diff = TestFailure(output='output', message='message_diff', type='type')
    type_diff = TestFailure(output='output', message='message', type='type_diff')

    assert failure1 == failure1_copy
    assert failure1 == failure1
    assert failure1 != output_diff
    assert failure1 != message_diff
    assert failure1 != type_diff

    error1 = TestError(output='output', message='message', type='type')
    error1_copy = TestError(output='output', message='message', type='type')
   

# Generated at 2022-06-23 13:39:24.700172
# Unit test for constructor of class TestSuite
def test_TestSuite():
    assert TestSuite(name='name')


# Generated at 2022-06-23 13:39:27.344856
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    testResult = TestResult(output='test output')
    res = testResult.get_xml_element()
    assert res.tag == 'testResult'
    assert res.text == 'test output'


# Generated at 2022-06-23 13:39:35.712412
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase(name="test_ok")
    attributes = test_case.get_attributes()
    assert attributes['name'] == "test_ok"
    assert 'assertions' not in attributes
    assert 'time' not in attributes
    assert 'status' not in attributes
    assert 'classname' not in attributes

    test_case = TestCase(name="test_ok", assertions="4")
    attributes = test_case.get_attributes()
    assert attributes['assertions'] == "4"
    assert attributes['name'] == "test_ok"
    assert 'time' not in attributes
    assert 'status' not in attributes
    assert 'classname' not in attributes

    test_case = TestCase(name="test_ok", time="1.23")
    attributes = test_case.get_attributes()
   

# Generated at 2022-06-23 13:39:43.236009
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test1 = TestCase(name="test1")
    test2 = TestCase(name="test2")
    test_suite = TestSuite(name="TestSuite")
    test_suite.cases.extend([test1,test2])
    test_result = TestSuite(name = "test_result")
    
    assert str(test_result.get_xml_element()) == str(test_suite.get_xml_element())


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-23 13:39:48.966780
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert repr(TestError()) == "TestError(output=None, message=None, type='error')"
    assert repr(TestError(output='foo', message='bar', type='baz')) == "TestError(output='foo', message='bar', type='baz')"

# Generated at 2022-06-23 13:39:57.375617
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_1 = TestCase("test_case_1")
    test_case_2 = TestCase("test_case_1")
    test_case_3 = TestCase("test_case_3")
    test_case_4 = TestCase("test_case_3")

    assert test_case_1 == test_case_1
    assert test_case_1 == test_case_2
    assert test_case_3 == test_case_4
    assert test_case_2 != test_case_3


# Generated at 2022-06-23 13:40:01.053629
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    suite = TestSuite(name = 'test_name')
    assert repr(suite) == 'TestSuite(name="test_name")'


# Generated at 2022-06-23 13:40:08.532573
# Unit test for constructor of class TestSuite
def test_TestSuite():

    aTestSuite = TestSuite(name='test', hostname='localhost', id=None,
                           package='zhang.yunxiang', timestamp=None)
    assert aTestSuite.name == 'test'
    assert aTestSuite.hostname == 'localhost'
    assert aTestSuite.id == None
    assert aTestSuite.package == 'zhang.yunxiang'
    assert aTestSuite.timestamp == None



# Generated at 2022-06-23 13:40:13.961887
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    """Test method __eq__ of class TestSuites."""
    assert TestSuites(name='name') == TestSuites(name='name')
    assert TestSuites(name='name') != TestSuites(name='name2')
    assert TestSuites(suites=[TestSuite(name='name')]) != TestSuites(suites=[TestSuite(name='name2')])


# Generated at 2022-06-23 13:40:17.206071
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    obj1 = TestCase("testcase_name")
    obj2 = TestCase("testcase_name")
    assert (obj1 == obj2) == True


# Generated at 2022-06-23 13:40:29.143351
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    # The class dataclasses.dataclass has been annotated as final
    # Cannot create a class TestSuiteFake that inherits from dataclasses.dataclass
    # test = TestSuiteFake(name='test_suite_name', hostname='test_hostname', id='test_id', package='test_package', properties={}, cases=[], system_out='', system_err='')

    # We use TestCase as a workaround for this issue (and for the unit test)
    test = TestCase(name='test_suite_name', classname='test_classname', status='test_status', time='test_time')

    test_attributes = test.get_attributes()

    assert test_attributes['name'] == 'test_suite_name'

# Generated at 2022-06-23 13:40:36.730934
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    tr1 = TestResult("out1")
    tr2 = TestError("out2", "message2")
    tr3 = TestFailure("out3", "message3", "type3")
    assert tr1.get_xml_element() == ET.Element("result", {"type": "result"})
    assert tr2.get_xml_element() == ET.Element("error", {"message": "message2", "type": "error"})
    assert tr3.get_xml_element() == ET.Element("failure", {"message": "message3", "type": "type3"})


# Generated at 2022-06-23 13:40:40.989061
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    expected = 'TestFailure(output="output", message="message", type="type")'
    actual = repr(TestFailure(output="output", message="message", type="type"))
    assert expected == actual


# Generated at 2022-06-23 13:40:53.914283
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    # Test 1
    first_case = TestCase('test_test_case__eq__', assertions=1, classname='test_test_case__eq__', status='OK', time=1.0, errors=[TestError('', '')], failures=[TestFailure('', '')], skipped=None, system_out=None, system_err=None)
    second_case = TestCase('test_test_case__eq__', assertions=1, classname='test_test_case__eq__', status='OK', time=1.0, errors=[TestError('', '')], failures=[TestFailure('', '')], skipped=None, system_out=None, system_err=None)
    assert first_case == second_case
    # Test 2

# Generated at 2022-06-23 13:40:57.737311
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_cases = [
        TestCase(name='test_0'),
        TestCase(name='test_1')
    ]
    test_suite = TestSuite(name='test_suite_0', cases=test_cases)
    result_text = test_suite.get_xml_element().text

    assert result_text is None

# Generated at 2022-06-23 13:41:02.798487
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    v1 = TestResult()
    v2 = TestResult()
    if not v1.__eq__(v2):
        print('Error:__eq__')
    if not v1.__eq__(v1):
        print('Error:__eq__')



# Generated at 2022-06-23 13:41:10.233791
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_1 = TestCase("Name1",1,"Class1","Status1",1.2)

    # TEST CASE 1
    # The input of __eq__ function is an instance of a class TestCase and the expected output is True
    test_case_2 = TestCase("Name1",1,"Class1","Status1",1.2)
    assert test_case_1 == test_case_2
    
    # TEST CASE 2
    # The input of __eq__ function is an instance of a class TestCase and the expected output is False
    test_case_2 = TestCase("Name1",1,"Class1","Status1",1.5)
    assert test_case_1 != test_case_2
    
    # TEST CASE 3
    # The input of __eq__ function is an instance of a class TestCase and the expected output is False

# Generated at 2022-06-23 13:41:19.876028
# Unit test for constructor of class TestSuite
def test_TestSuite():
    name = "test"
    hostname = "host"
    id = "id"
    package = "package"
    timestamp = datetime.datetime.now()

    properties_test = dict()
    properties_test["key"] = "value"
    cases_test = list()
    cases_test.append(TestCase(name="name",
                               assertions=1,
                               classname="class",
                               status="passed",
                               time=datetime.timedelta(seconds=1)))
    system_out_test = "system_out"
    system_err_test = "system_err"


# Generated at 2022-06-23 13:41:24.387009
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    result = TestError()
    assert result.type == 'error'

    result = TestError()
    result.type = 'foo'
    assert result.type == 'foo'


# Generated at 2022-06-23 13:41:35.129560
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Return an XML element representing this instance."""
    # Create a TestCase object with no errors and failures
    tc_no_errors_failures = TestCase(name='test_no_errors_failures', classname='test_class', time=decimal.Decimal(1.0))

    # Get the XML Element for tc_no_errors_failures
    xml_elem_no_errors_failures = tc_no_errors_failures.get_xml_element()

    # Create a TestCase object with errors but no failures
    tc_errors = TestCase(name='test_errors', classname='test_class', time=decimal.Decimal(1.0))
    errors = [TestError(message='error 1')]
    tc_errors.errors = errors

    # Get the XML Element for tc_errors
    xml_e

# Generated at 2022-06-23 13:41:45.387292
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    # Define error message for test
    error_msg = 'TestSuites.to_pretty_xml() does not return correct XML for {}'

    # Define expected XML for test

# Generated at 2022-06-23 13:41:48.369969
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert repr(TestError('output', 'message', 'type')) == \
        "TestError(output='output', message='message', type='type')"



# Generated at 2022-06-23 13:41:53.704891
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    f1 = TestFailure(output="output 1", message="message 1", type="type 1")
    f2 = TestFailure(output="output 1", message="message 1", type="type 1")
    assert (f1 == f2)


if __name__ == '__main__':
    test_TestFailure___eq__()

# Generated at 2022-06-23 13:41:55.762350
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    expected_type = 'failure'
    result = TestFailure()
    assert result.type == expected_type


# Generated at 2022-06-23 13:42:09.084604
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='test_suite_1',
                           hostname='localhost',
                           id='test_suite_1',
                           package='test_package_1',
                           timestamp=datetime.datetime.now(),
                           system_out='system_out_1',
                           system_err='system_err_1')

# Generated at 2022-06-23 13:42:14.435542
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():

    # Create two test case objets with the same fields
    test_object_1 = TestCase('test_case_1')
    test_object_2 = TestCase('test_case_1')

    # Verify that the two instances are equal
    assert test_object_1 == test_object_2


# Generated at 2022-06-23 13:42:17.599478
# Unit test for constructor of class TestSuites
def test_TestSuites():
    value = TestSuites(name="Test Suite Name")
    assert value.name == "Test Suite Name"
    assert value.suites == []


# Generated at 2022-06-23 13:42:19.861731
# Unit test for constructor of class TestSuites
def test_TestSuites():
    ts = TestSuites(name='TestSuitesTest')
    assert ts.name == 'TestSuitesTest'


# Generated at 2022-06-23 13:42:27.956605
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    testSuites = TestSuites()
    testSuites.name = "name"
    testSuites.disabled = 3
    testSuites.errors = 2
    testSuites.failures = 1
    testSuites.tests = 4
    testSuites.time = 5.5
    attributes = testSuites.get_attributes()
    assert attributes['name'] == 'name'
    assert attributes['disabled'] == '3'
    assert attributes['errors'] == '2'
    assert attributes['failures'] == '1'
    assert attributes['tests'] == '4'
    assert attributes['time'] == '5.5'


# Generated at 2022-06-23 13:42:30.385677
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError()
    assert error.type == 'error'

# Generated at 2022-06-23 13:42:32.459989
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert repr(TestFailure()) == 'TestFailure(output=None, message=None, type=None)'



# Generated at 2022-06-23 13:42:35.760104
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase(name='TestCase')
    assert test_case.__repr__() == 'TestCase(name=TestCase)'



# Generated at 2022-06-23 13:42:37.910647
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    xml = TestSuites(name="testsuites").get_xml_element()
    print(xml)
    assert xml.tag == "testsuites"
    assert xml.get("name") == "testsuites"


# Generated at 2022-06-23 13:42:44.352566
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    # Setup
    name = 'name'
    assertions = 'assertions'
    classname = 'classname'
    status = 'status'
    time = 'time'
    errors = ['errors']
    failures = ['failures']
    skipped = 'skipped'
    system_out = 'system_out'
    system_err = 'system_err'
    testcase = TestCase(name=name, assertions=assertions, classname=classname, status=status, time=time, errors=errors, failures=failures, skipped=skipped, system_out=system_out, system_err=system_err)
    # Exercise
    _repr = testcase.__repr__()
    # Verify

# Generated at 2022-06-23 13:42:50.764889
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    testFailure1 = TestFailure(output="output1", message="message1", type="type1")
    testFailure2 = TestFailure(output="output1", message="message1", type="type1")
    testFailure3 = TestFailure(output="output1", message="message1", type="type3")
    assert testFailure1 == testFailure2
    assert testFailure1 != testFailure3


# Generated at 2022-06-23 13:42:57.298793
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite = TestSuite('testsuite1')
    xml_string = testsuite.get_xml_element()
    # print(xml_string)
    # for line in xml_string:
    #     print(line)
    # print(xml_string)

    assert xml_string == '<testsuite disabled="0" errors="0" failures="0" name="testsuite1" skipped="0" tests="0" time="0.0" />'


# Generated at 2022-06-23 13:43:01.010170
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError('hello', type='error')
    expected = {'message': 'hello', 'type': 'error'}
    error_att = error.get_attributes()
    assert error_att == expected


# Generated at 2022-06-23 13:43:06.362809
# Unit test for constructor of class TestFailure
def test_TestFailure():
    output = "This is a failure"
    message = "Failed"
    type = "failure"
    test_failure = TestFailure(output, message, type)
    assert test_failure.output == output
    assert test_failure.message == message
    assert test_failure.type == type


# Generated at 2022-06-23 13:43:07.749875
# Unit test for constructor of class TestFailure
def test_TestFailure():
    res = TestFailure()
    assert isinstance(res, TestFailure)



# Generated at 2022-06-23 13:43:11.011005
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError("test_err")
    assert error.tag == 'error'
    assert error.message == None
    assert error.output == "test_err"
    assert error.type == 'error'



# Generated at 2022-06-23 13:43:13.704976
# Unit test for constructor of class TestResult
def test_TestResult():
    result_test = TestResult(output = "no output")
    assert result_test.output is not None
    assert result_test.message is None
    assert result_test.type == "testresult"
