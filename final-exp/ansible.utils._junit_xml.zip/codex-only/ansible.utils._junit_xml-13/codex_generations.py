

# Generated at 2022-06-23 13:33:23.803407
# Unit test for constructor of class TestCase
def test_TestCase():
    test_case = TestCase(
        name="test-case",
        assertions="123",
        classname="TestCase",
        status="Passed",
        time="123",
        errors=[TestError(output="Error")],
        failures=[TestFailure(output="Failure")],
        skipped="Test Skipped",
        system_out="OK",
        system_err="ERROR",
    )

    assert test_case.name == "test-case"
    assert test_case.assertions == "123"
    assert test_case.classname == "TestCase"
    assert test_case.status == "Passed"
    assert test_case.time == "123"
    assert test_case.errors[0].output == "Error"
    assert test_case.failures[0].output == "Failure"
    assert test_case

# Generated at 2022-06-23 13:33:26.365587
# Unit test for constructor of class TestSuite
def test_TestSuite():
    t_suite = TestSuite('TS1', hostname='localhost', id='ID123', name='TS1', package='org.package')
    assert t_suite.name == 'TS1'


# Generated at 2022-06-23 13:33:27.889622
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    suite = TestSuite(name="test_name")
    print(suite)


# Generated at 2022-06-23 13:33:29.700478
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    TestError(message=None, output=None) == TestError(message=None, output=None)

# Generated at 2022-06-23 13:33:40.801153
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    def _test(obj, expected):
        assert obj.get_attributes() == expected

    # Failure
    _test(TestFailure(), {})
    _test(TestFailure(type='type'), {'type': 'type'})
    _test(TestFailure(message='message'), {'message': 'message'})
    _test(TestFailure(output='output'), {})
    _test(TestFailure(type='type', message='message'), {'type': 'type', 'message': 'message'})
    _test(TestFailure(type='type', message='message', output='output'), {'type': 'type', 'message': 'message'})

    # Error
    _test(TestError(), {})
    _test(TestError(type='type'), {'type': 'type'})

# Generated at 2022-06-23 13:33:52.207405
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    from datetime import datetime
    from decimal import Decimal
    # All attributes are None
    tr = TestResult()
    assert tr.get_attributes() == {}

    # All attributes are not None
    tr = TestResult(message='Action data must be a dictionary', output='action data: 123', type='TypeError')
    assert tr.get_attributes() == {'message': 'Action data must be a dictionary', 'type': 'TypeError'}

    # All attributes are not None and output is not None and it is Decimal
    tr = TestResult(message='Action data must be a dictionary', output=Decimal('0.0001'), type='TypeError')
    assert tr.get_attributes() == {'message': 'Action data must be a dictionary', 'type': 'TypeError'}

    # All attributes are not None and output is not None

# Generated at 2022-06-23 13:33:56.402563
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    """Test if str method returns expected result."""
    result = str(TestResult())
    assert result == 'TestResult(output=None, message=None, type=TestResult)'


# Generated at 2022-06-23 13:34:05.098962
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    test_1 = TestError(
        output = 'Failed!!!', 
        message = 'You are wrong!', 
        type = 'failure'
    )
    test_2 = TestError(
        output = 'Failed!!!', 
        message = 'You are wrong!', 
        type = 'failure'
    )
    test_3 = TestError(
        output = 'Failed', 
        message = 'You are wrong!', 
        type = 'failure'
    )
    assert test_1.__eq__(test_2) == True
    assert test_3.__eq__(test_1) == False


# Generated at 2022-06-23 13:34:06.280361
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    pass


# Generated at 2022-06-23 13:34:12.499037
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test = TestSuites(disabled=0, errors=0, failures=0, name="name", tests=0, time=0)
    testAttr = test.get_attributes()
    expectedAttr = {"disabled": "0", "errors": "0", "failures": "0", "name": "name", "tests": "0", "time": "0"}
    assert testAttr == expectedAttr

test_TestSuites_get_attributes()


# Generated at 2022-06-23 13:34:13.694843
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    # TODO: Implement
    pass


# Generated at 2022-06-23 13:34:17.934538
# Unit test for constructor of class TestCase
def test_TestCase():
    test = TestCase("TestCase")
    assert test.name == "TestCase"
    assert test.assertions == None
    assert test.classname == None
    assert test.status == None
    assert test.time == None


# Generated at 2022-06-23 13:34:21.271781
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    test_suites = TestSuites(
        name='test_suites_name',
    )
    assert test_suites.__repr__() == 'TestSuites(name=\'test_suites_name\')'

# Generated at 2022-06-23 13:34:25.228139
# Unit test for constructor of class TestCase
def test_TestCase():
    testcase = TestCase('testcase1')
    assert testcase.name == 'testcase1'
    assert testcase.classname == None
    assert testcase.time == None
    assert testcase.status == None


# Generated at 2022-06-23 13:34:37.092627
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_cases = [('output', '', 'message', None, 'type', 'test_type',
                   0, 0, 
                   '<test_type message="message" type="test_type"/>'),
                  ('output', 'OUT', 'message', 'MSG', 'type', 'TYP', 
                   0, 0, 
                   '<test_type message="MSG" type="TYP">OUT</test_type>'),
                  ('output', '', 'message', None, 'type', 'test_type', 
                   1, 0, 
                   '<test_type message="message" type="test_type"/>'),
                  ('output', '', 'message', None, 'type', 'test_type', 
                   0, 1, 
                   '<test_type message="message" type="test_type"/>')]

# Generated at 2022-06-23 13:34:40.779828
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    a = TestCase(name='a', classname='b', status='c', time=1, assertions=2)
    b = TestCase(name='a', classname='b', status='c', time=1, assertions=2)

    assert a == b



# Generated at 2022-06-23 13:34:50.864283
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-23 13:35:00.568711
# Unit test for method __repr__ of class TestSuites

# Generated at 2022-06-23 13:35:08.087361
# Unit test for constructor of class TestError
def test_TestError():
    e = TestError("E", "Test.test1", "test1 failed")
    assert e.output == "E"
    assert e.message == "Test.test1"
    assert e.type == "test1 failed"
    assert e.get_xml_element().text == e.output
    assert e.get_xml_element().get("message") == e.message
    assert e.get_xml_element().get("type") == e.type



# Generated at 2022-06-23 13:35:12.024784
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    """Unit test for method __repr__ of class TestResult."""
    test_result = TestResult(output='Test output', message='Test message', type='Test type')
    assert repr(test_result) == 'TestResult(output=\'Test output\', message=\'Test message\', type=\'Test type\')'



# Generated at 2022-06-23 13:35:21.256319
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # Setup
    test_suite = TestSuite(name='1', hostname='2', id='3', package='4', timestamp=datetime.datetime.now(), properties={'a': 'A', 'b': 'B'}, cases=[TestCase('5'), TestCase('6')], system_out='7', system_err='8')

    # Test
    test_suite.cases[0] = TestCase('5')
    assert test_suite == TestSuite(name='1', hostname='2', id='3', package='4', timestamp=datetime.datetime.now(), properties={'a': 'A', 'b': 'B'}, cases=[TestCase('5'), TestCase('6')], system_out='7', system_err='8')

    # Test
    test_suite.cases[1] = TestCase

# Generated at 2022-06-23 13:35:22.723338
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    obj = TestResult('')
    assert obj.type == 'result'


# Generated at 2022-06-23 13:35:29.328998
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
	assert ET.tostring(TestCase(name='abc').get_xml_element(), encoding='unicode') == '<testcase name="abc" />'
	assert ET.tostring(TestCase(name='abc', assertions=1).get_xml_element(), encoding='unicode') == '<testcase assertions="1" name="abc" />'
	assert ET.tostring(TestCase(name='abc', classname='xyz').get_xml_element(), encoding='unicode') == '<testcase classname="xyz" name="abc" />'
	assert ET.tostring(TestCase(name='abc', status='skipped').get_xml_element(), encoding='unicode') == '<testcase name="abc" status="skipped" />'

# Generated at 2022-06-23 13:35:37.582511
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase('name_1', assertions=1, classname='classname_1', status='status_1', time=1.0)
    test_case2 = TestCase('name_2', assertions=2, classname='classname_2', status='status_2', time=2.0)
    assert test_case.get_attributes() == {'assertions': '1', 'classname': 'classname_1', 'name': 'name_1', 'status': 'status_1', 'time': '1.0'}
    assert test_case2.get_attributes() == {'assertions': '2', 'classname': 'classname_2', 'name': 'name_2', 'status': 'status_2', 'time': '2.0'}



# Generated at 2022-06-23 13:35:40.223324
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult()
    assert result.output is None
    assert result.message is None
    assert result.type is None


# Generated at 2022-06-23 13:35:43.487039
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    e1 = TestError(output='', message=None, type='')
    assert e1.type == 'error'
    e2 = TestError(output='', message='', type=None)


# Generated at 2022-06-23 13:35:46.684672
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    suite1 = TestSuite('test1')
    suite2 = TestSuite('test2')

    assert suite1 == suite1
    assert suite1 != suite2


# Generated at 2022-06-23 13:35:48.486277
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    t = TestSuite('testsuite')
    assert t.get_attributes() == {'name': 'testsuite'}

# Generated at 2022-06-23 13:35:50.309236
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    assert TestResult(output='Some output').get_xml_element().text == 'Some output'


# Generated at 2022-06-23 13:35:52.252501
# Unit test for constructor of class TestSuite
def test_TestSuite():
    ts = TestSuite(name="n1")
    assert ts.name == "n1"

# Generated at 2022-06-23 13:35:57.812466
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    name = "__main__.TestSomeThing"
    time = 1.4
    assertions = 5
    classname = "TestSomeThing"
    status = "success"
    temp = TestCase(name,time,assertions,classname,status)
    output = temp.get_attributes()
    expected = {'name': name, 'time': time, 'assertions': assertions, 'classname': classname, 'status': status}
    assert output == expected

# Generated at 2022-06-23 13:36:07.625555
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    case1 = TestError()
    case2 = TestError()
    assert case1 == case2
    case1.output = 'hello world'
    assert case1 != case2
    case2.output = 'hello world'
    assert case1 == case2
    case1.message = 'hello world'
    assert case1 != case2
    case2.message = 'hello world'
    assert case1 == case2
    case1.type = 'hello world'
    assert case1 != case2
    case2.type = 'hello world'
    assert case1 == case2


# Generated at 2022-06-23 13:36:12.633508
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_suites = TestSuites(
        suites=[
            TestSuite(
                cases=[
                    TestCase(name="TestCaseName", failures=[TestFailure()], errors=[TestError()], skipped="foo"),
                ],
                system_out="system_out",
                system_err="system_err",
            ),
        ]
    )

    assert test_suites.to_pretty_xml() == _pretty_xml(test_suites.get_xml_element())

# Generated at 2022-06-23 13:36:21.602147
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Unit test for method to_pretty_xml of class TestSuites"""
    suite_name = 'test_suite_1'
    test_case_name = 'test_case_1'
    test_failure_message = 'test_failure_message_1'
    test_failure_output = 'test_failure_output_1'
    test_failure = TestFailure(
        message=test_failure_message,
        output=test_failure_output
    )
    test_case = TestCase(
        name=test_case_name,
        failures=[test_failure]
    )
    test_suite = TestSuite(
        name=suite_name,
        cases=[test_case]
    )

# Generated at 2022-06-23 13:36:30.734314
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    expected = ET.Element('testsuites', _attributes(
        disabled=4,
        errors=0,
        failures=4,
        name='Error, failure, skipped and disabled tests',
        tests=8,
        time=1.0
    ))
    expected_suite_1 = ET.Element('testsuite', _attributes(
        errors=0,
        failures=1,
        name='Single failure test',
        skipped=0,
        tests=2,
        time=0.1
    ))
    expected_suite_1_testcase_1 = ET.Element('testcase', _attributes(
        assertions=1,
        name='Passing test',
        status='passed',
        time=0.1
    ))

# Generated at 2022-06-23 13:36:39.006729
# Unit test for constructor of class TestResult
def test_TestResult():
    t1 = TestResult()
    t2 = TestResult(output='output 1', message='message 1', type='error')
    t3 = TestResult(output='output 2', message='message 2', type='failure')

    print(t1.output)
    print(t1.message)
    print(t1.type)
    print(t2.output)
    print(t2.message)
    print(t2.type)
    print(t3.output)
    print(t3.message)
    print(t3.type)



# Generated at 2022-06-23 13:36:46.621301
# Unit test for constructor of class TestError
def test_TestError():
    error_1 = TestError("Error!")
    assert error_1.output == "Error!"
    error_2 = TestError("Error2!", "Error2")
    assert error_2.output == "Error2!"
    assert error_2.message == "Error2"
    error_3 = TestError("Error3!", "Error3", "Error3 Type")
    assert error_3.output == "Error3!"
    assert error_3.message == "Error3"
    assert error_3.type == "Error3 Type"



# Generated at 2022-06-23 13:36:53.673124
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    testResult = TestResult("hi", "hi", "hi")
    testResult2 = TestResult("hi", "hi", "hi")
    assert testResult == testResult2
    # testResult2 = TestResult("hi", "hi", "hi")
    # assert testResult == testResult2
    # testResult2 = TestResult("hello", "hello", "hello")
    # assert testResult != testResult2


# Generated at 2022-06-23 13:36:57.194987
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    output, message, type = 'output', 'message', 'type'

    result = TestResult(output=output, message=message, type=type)
    assert result.get_attributes() == {'message': message, 'type': type}



# Generated at 2022-06-23 13:37:08.844494
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    @dataclasses.dataclass
    class Value:
        value: str

    assert repr(TestResult()) == "TestResult(output=None, message=None, type=None)"
    assert repr(TestResult(output="output")) == "TestResult(output='output', message=None, type=None)"
    assert repr(TestResult(message="message")) == "TestResult(output=None, message='message', type=None)"
    assert repr(TestResult(type="type")) == "TestResult(output=None, message=None, type='type')"
    assert repr(TestResult(Value(value="value"))) == "TestResult(output='value', message=None, type=None)"


# Generated at 2022-06-23 13:37:11.086932
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert repr(TestError(message="can't find file")) == "TestError(message='can\\'t find file', type='error')"


# Generated at 2022-06-23 13:37:13.977761
# Unit test for constructor of class TestError
def test_TestError():
    testError = TestError("this is output")
    assert testError.output == "this is output"


# Generated at 2022-06-23 13:37:17.955052
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_one = TestCase(name='name', classname='classname', time=1)
    test_case_two = TestCase(name='name', classname='classname')

    assert test_case_one == test_case_two

# Generated at 2022-06-23 13:37:26.546185
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    # Test when all arguments are provided
    ts = TestSuite(
        name="TestSuite",
        hostname="HostName",
        id="ID",
        package="Package",
        timestamp=datetime.datetime.now(),
        properties={'key1': 'value1', 'key2': 'value2'},
        cases=[TestCase(name="TestCase", assertions=1, classname="ClassName", status="Status", time=decimal.Decimal(1.23))],
        system_out="SystemOut",
        system_err="SystemErr",
    )

# Generated at 2022-06-23 13:37:32.709543
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test = TestResult()

    attributes = test.get_attributes()
    assert attributes['type'] == 'testresult'
    assert attributes['message'] is None
    assert len(attributes) == 2

    test.message = 'message'
    test.type = 'type'
    attributes = test.get_attributes()

    assert attributes['message'] == 'message'
    assert attributes['type'] == 'type'
    assert len(attributes) == 2


# Generated at 2022-06-23 13:37:34.341823
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    assert 'output' in str(TestCase(name='name'))


# Generated at 2022-06-23 13:37:36.285453
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert repr(TestFailure(output='test')) == 'TestFailure(output="test")'


# Generated at 2022-06-23 13:37:46.096469
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    ts = TestSuite(
        name='My TestSuite',
        hostname='TestHost',
        id='test-id',
        package='test.package',
        timestamp=datetime.datetime.now(),
        properties={
            'foo': 'bar',
            'baz': 'buz'
        }
    )
    el = ts.get_xml_element()
    name = el.attrib['name']
    assert name == ts.name
    hostname = el.attrib['hostname']
    assert hostname == ts.hostname
    ident = el.attrib['id']
    assert ident == ts.id
    package = el.attrib['package']
    assert package == ts.package
    timestamp = el.attrib['timestamp']

# Generated at 2022-06-23 13:37:48.294914
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    pass


# Generated at 2022-06-23 13:37:57.333502
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    result = TestCase(name='MyTestCase')
    assert result.__repr__() == "TestCase(name='MyTestCase', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"

    result = TestCase(name='MyTestCase', is_disabled=True)
    assert result.__repr__() == "TestCase(name='MyTestCase', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=True)"


# Generated at 2022-06-23 13:38:08.161608
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """Unit test for method get_xml_element of class TestCase"""
    test = TestCase('test_name', classname='class')
    assert ET.tostring(test.get_xml_element()) == b'<testcase assertions="None" classname="class" name="test_name" status="None" time="None"></testcase>'
    test.time = 0.34
    assert ET.tostring(test.get_xml_element()) == b'<testcase assertions="None" classname="class" name="test_name" status="None" time="0.34"></testcase>'
    test.status = 'OK'

# Generated at 2022-06-23 13:38:09.286247
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert TestFailure()


# Generated at 2022-06-23 13:38:22.027540
# Unit test for constructor of class TestResult
def test_TestResult():
   # Create the object
   obj = TestResult("output", "message", "type")
   
   # Check whether the object is a TestResult
   assert isinstance(obj, TestResult)
   
   # Check the value of the output
   assert obj.output == "output"
   
   # Check the value of the message
   assert obj.message == "message"
   
   # Check the value of the type
   assert obj.type == "type"
   
   # Check the value of the tag
   with pytest.raises(Exception, match=r"No implementation for abstract method 'tag' on class 'TestResult'"):
      obj.tag
   
   # Check post init
   assert obj.type == "testresult"
   
   # Check the get attributes

# Generated at 2022-06-23 13:38:33.771064
# Unit test for constructor of class TestCase
def test_TestCase():
    t1 = TestCase()
    assert t1.name is None
    assert t1.classname is None
    assert t1.status is None
    assert t1.time is None
    assert isinstance(t1.errors,list)
    assert isinstance(t1.failures,list)
    assert t1.skipped is None
    assert t1.system_out is None
    assert t1.system_err is None
    assert t1.is_disabled == False
    assert t1.is_failure == False
    assert t1.is_error == False
    assert t1.is_skipped == False
    
    t1 = TestCase(name='name', classname='classname', status='status', time=1)
    assert t1.name == 'name'

# Generated at 2022-06-23 13:38:37.684417
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    class Error(TestResult):
        @property
        def tag(self) -> str:
            return 'error'

    error = Error(type='blah')
    assert error.tag == 'error'
    assert error.type == 'blah'

    error = Error()
    assert error.tag == 'error'
    assert error.type == 'error'

# Generated at 2022-06-23 13:38:44.271806
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # Create new TestCase objects
    test_case1 = TestCase(
        name="TestCase1"
    )
    test_case2 = TestCase(
        name="TestCase2"
    )
    # Create new TestSuite objects
    test_suite1 = TestSuite(
        name="TestSuite1",
        cases=[
            test_case1,
            test_case2
        ]
    )
    test_suite2 = TestSuite(
        name="TestSuite2",
        cases=[
            test_case1,
            test_case2
        ]
    )
    # Check if the TestSuite objects are equal
    assert test_suite1 == test_suite2, "TestSuites should be equal!"
    # Check if the TestSuite objects are not equal
    assert test_

# Generated at 2022-06-23 13:38:52.903767
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    # A test case.
    test_case = TestCase(
        name='test_case_1',
        assertions=1,
        classname='test_class_1',
        status='PASSED',
        time=1.0,
        errors=[TestError(output='output_1', message='message_1', type='type_1')],
        failures=[TestFailure(output='output_2', message='message_2', type='type_2')],
        skipped='skipped_1',
        system_out='system_out_1',
        system_err='system_err_1',
        is_disabled=True
    )
    # The expected string.

# Generated at 2022-06-23 13:38:54.123784
# Unit test for constructor of class TestSuite
def test_TestSuite():
    suite = TestSuite("TestCase")
    assert suite is not None

# Generated at 2022-06-23 13:38:57.420504
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(test_result="test message", type=TestResult.tag)
    expected_attribute = {
        'test_result': "test message",
        'type': TestResult.tag
    }
    assert expected_attribute == test_result.get_attributes()


# Generated at 2022-06-23 13:39:01.633618
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite(name= "New Test Suite")
    attr = suite.get_attributes()
    assert attr == {'name':'New Test Suite'}


# Generated at 2022-06-23 13:39:07.121718
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    from nose.tools import assert_equal

    assert_equal(
        repr(TestResult()),
        'TestResult()'
    )

    assert_equal(
        repr(TestFailure()),
        'TestFailure(output=None, message=None, type=None)'
    )

    assert_equal(
        repr(TestError()),
        'TestError(output=None, message=None, type=None)'
    )


# Generated at 2022-06-23 13:39:17.208385
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # Case 1: no argument provided
    # Expected result: the result of calling __repr__ with no argument
    _test_instance = TestResult(output='output', message='message', type='type')
    assert _test_instance.__repr__() == 'TestResult(output=\'output\', message=\'message\', type=\'type\')'

    # Case 2: argument provided
    # Expected result: the result of calling __repr__ with the argument
    assert _test_instance.__repr__('argument') == 'TestResult(output=\'output\', message=\'message\', type=\'type\')'


# Generated at 2022-06-23 13:39:18.038300
# Unit test for constructor of class TestResult
def test_TestResult():
    assert TestResult().type == 'result'


# Generated at 2022-06-23 13:39:27.971547
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    output = "output"
    message = "message"
    type = "type"
    res = TestResult(output, message, type)
    class_name = type(res).__name__
    repr_return = repr(res)
    repr_return = repr_return.split()
    assert repr_return[0] == f'<{class_name}'
    assert repr_return[1] == f'output={output!r},'
    assert repr_return[2] == f'message={message!r},'
    assert repr_return[3] == f'type={type!r}>'


# Generated at 2022-06-23 13:39:33.465601
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase(
        name='TestCaseName',
        assertions=2,
        classname='TestClassName',
        status='status',
        time=decimal.Decimal(0.03)
    )
    expected_attributes = {'name': 'TestCaseName', 'assertions': '2', 'classname': 'TestClassName', 'status': 'status', 'time': '0.03'}
    assert test_case.get_attributes() == expected_attributes


# Generated at 2022-06-23 13:39:35.507021
# Unit test for constructor of class TestCase
def test_TestCase():
  test = TestCase("name","error")
  assert test.errors[0].output == "error"

# Generated at 2022-06-23 13:39:40.272415
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    assert repr(TestCase('test_name')) == 'TestCase(name=test_name, assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'


# Generated at 2022-06-23 13:39:46.950441
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    ts = TestSuites()
    ts.suites.append(TestSuite(name='test'))
    ts.suites.append(TestSuite(name='test2'))
    ts.suites.append(TestSuite(name='test3'))
    ts.suites.append(TestSuite(name='test4'))
    ts.suites.append(TestSuite(name='test5'))
    ts.suites.append(TestSuite(name='test6'))
    assert ts.get_attributes() == {'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '6', 'time': '0'}

# Generated at 2022-06-23 13:39:54.038156
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    class TestResultImpl(TestResult):
        @property
        def tag(self) -> str:
            return 'failure'

    assert TestResultImpl(output='out') == TestResultImpl(output='out')
    assert TestResultImpl() == TestResultImpl()
    assert not TestResultImpl() == TestResultImpl(output='out')
    assert not TestResultImpl(output='out') == TestResultImpl()



# Generated at 2022-06-23 13:39:59.701772
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # One-line docstring.
    # Below is a unit test template.
    test_result = TestResult(output=None, message=None, type=None)

    # <BLANKLINE>
    # Arrange
    # Act
    actual = repr(test_result)

    # <BLANKLINE>
    # Assert
    expected = 'TestResult(output=None, message=None, type=None)'
    assert actual == expected



# Generated at 2022-06-23 13:40:01.980976
# Unit test for constructor of class TestCase
def test_TestCase():
    testcase = TestCase("name")
    assert testcase.name == "name"



# Generated at 2022-06-23 13:40:04.785597
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # Set up
    suites = TestSuites()

    # Exercise
    output = suites.__repr__()

    # Verify
    assert output == 'TestSuites(name=None, suites=[])'


# Generated at 2022-06-23 13:40:07.086969
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure() == TestFailure()


# Generated at 2022-06-23 13:40:16.796868
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    ts = TestSuites(name='TS')

# Generated at 2022-06-23 13:40:21.037659
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase('tname', classname='tcname', time=1.8)
    assert tc.disabled == False
    assert tc.errors == 0
    assert tc.failures == 0
    assert tc.skipped == None


# Generated at 2022-06-23 13:40:23.240532
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    test_case = TestResult()
    assert test_case.type == test_case.tag



# Generated at 2022-06-23 13:40:25.757468
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult(type="test type")
    assert {"message": "test type"} == result.get_attributes()


# Generated at 2022-06-23 13:40:32.054783
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    # Arrange
    test_case = TestCase(name='mytest')

    # Act
    result = repr(test_case)

    # Assert
    assert result == "TestCase(name='mytest', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None)"
    assert isinstance(result, str)
    return



# Generated at 2022-06-23 13:40:34.989968
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    s = "message='hello',output=None,type='error'"
    tr = TestError(output=None, message="hello",type='error')
    assert repr(tr) == s


# Generated at 2022-06-23 13:40:37.610129
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    test_case = TestSuite('test_name')
    assert eval(repr(test_case)) == test_case


# Generated at 2022-06-23 13:40:42.084197
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    output = 'output'
    message = 'message'
    type = 'type'
    result = TestError(output, message, type)
    assert _attributes(message=message, type=type) == result.get_attributes()


# Generated at 2022-06-23 13:40:45.672893
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    xml = TestSuites(name='foo').to_pretty_xml()

    # class TestSuite has a method __init__
    assert isinstance(xml, str)


# Generated at 2022-06-23 13:40:50.468717
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test_class_1 = TestSuite("test1")
    test_class_2 = TestSuite("test2")
    assert test_class_1 == TestSuite("test1") and test_class_2 == TestSuite("test2")


# Generated at 2022-06-23 13:40:57.836564
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    error1 = TestError(
        message="First test error message.",
        type="First test error type.",
    )
    error2 = TestError(
        message="Second test error message.",
        type="First test error type.",
    )
    error3 = TestError(
        message="First test error message.",
        type="Second test error type.",
    )
    error4 = TestError(
        message="First test error message.",
        type="First test error type.",
    )
    assert error1 == error4
    assert error1 != error2
    assert error1 != error3


# Generated at 2022-06-23 13:41:04.038960
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    from _pytest.monkeypatch import MonkeyPatch
    monkeypatch = MonkeyPatch()
    # BEGIN
    class TestSuites:
        _source = None
        _timestamp = None
        name = None
        suites = None

        def __repr__(self):
            pass
    # END
    actual = repr(TestSuites())
    assert isinstance(actual, str)

# Generated at 2022-06-23 13:41:06.085023
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testcase = TestCase("test_name")
    assert testcase.get_attributes() == _attributes(name="test_name")


# Generated at 2022-06-23 13:41:11.616126
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    t1 = TestError(
        output = "foo",
        message = "bar",
        type = "baz",
    )

    t2 = TestError(
        output = "foo",
        message = "bar",
        type = "baz",
    )

    assert t1 == t2



# Generated at 2022-06-23 13:41:13.748910
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    repr = "TestResult(output=None, message=None, type='success')"
    instance = TestResult()
    assert repr == repr(instance)


# Generated at 2022-06-23 13:41:18.280511
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    test_TestSuite = TestSuite()

    assert_equals(test_TestSuite.__repr__(), "TestSuite(name=None, hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)")

# Generated at 2022-06-23 13:41:21.969228
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test = TestFailure('output', 'message', 'type')
    expected = 'TestFailure(output=output, message=message, type=type)'
    actual = repr(test)
    assert actual == expected, f'\nExpected: {expected}\nActual:   {actual}'


# Generated at 2022-06-23 13:41:28.564443
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    """Test that the XML representation of the given test suites is rendered correctly.

    :return: None.
    """
    import datetime
    import decimal

    # noinspection PyUnusedLocal
    def equals_xml(expected: str, actual: str):
        """Determine if the given XML strings are equal.

        :param expected: The expected XML string.
        :param actual: The actual XML string.
        :return: None.
        """
        from xml.dom.minidom import parseString
        import os

        import logging
        logger = logging.getLogger('junit_xml')


# Generated at 2022-06-23 13:41:32.566567
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    '''
    Create two objects of class TestResult and check if the __eq__ method of the class works correctly
    '''
    test_result_1 = TestResult()
    test_result_2 = TestResult()
    assert test_result_1 == test_result_2


# Generated at 2022-06-23 13:41:37.522821
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    """Test the __post_init__ method of class TestResult."""
    test_result = TestResult()
    assert test_result.type is None
    test_result = TestResult(type="abc")
    assert test_result.type == 'abc'


# Generated at 2022-06-23 13:41:43.508599
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test_suites = TestSuites()
    assert test_suites.get_attributes() == {}

    test_suites = TestSuites(name="TestSuites")
    assert test_suites.get_attributes() == {'name': 'TestSuites'}

    test_suites = TestSuites(name="TestSuites", disabled=2, errors=1, failures=3, tests=10, time=decimal.Decimal('10.2'))
    assert test_suites.get_attributes() == {'name': 'TestSuites', 'disabled': '2', 'errors': '1', 'failures': '3', 'tests': '10', 'time': '10.2'}



# Generated at 2022-06-23 13:41:55.075391
# Unit test for method __repr__ of class TestFailure

# Generated at 2022-06-23 13:42:02.060188
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes() == _attributes(
            message=None,
            type=None,
        )
    result = TestResult(output="this is an error")
    assert result.get_attributes() == _attributes(
            message=None,
            type=None,
        )
    result = TestResult(output="this is an error", message="the is a message")
    assert result.get_attributes() == _attributes(
            message="the is a message",
            type=None,
        )
    result = TestResult(output="this is an error", message="the is a message", type="error")
    assert result.get_attributes() == _attributes(
            message="the is a message",
            type="error",
        )

# Generated at 2022-06-23 13:42:13.330009
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='test_case', assertions='1', classname='TestCase', status='pass', time='0.5')
    test_suite = TestSuite(name='test_suite', hostname='localhost', id='1', package='testing', timestamp='2020-01-01 00:00:00', properties={'key': 'value'}, cases=[test_case], system_out='abc', system_err='def')

    xml = test_suite.get_xml_element()
    assert xml.attrib['name'] == 'test_suite'
    assert xml[0].attrib['name'] == 'test_case'

# Generated at 2022-06-23 13:42:16.507530
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    element = TestFailure()
    assert element.type == 'failure'
    element = TestError()
    assert element.type == 'error'


# Generated at 2022-06-23 13:42:24.725530
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    suites = TestSuites()
    case1 = TestCase(name='test1')
    case2 = TestCase(name='test2')
    assert case1.name == 'test1'
    assert case2.name == 'test2'
    suite = TestSuite(name='suite', cases = [case1, case2])
    assert suite.name == 'suite'
    assert suite.cases == [case1, case2]
    suites.suites = [suite]
    assert suites.suites == [suite]
    result = suites.to_pretty_xml()

# Generated at 2022-06-23 13:42:31.757610
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """
    用例描述： 测试TestCase的get_xml_element函数
    :return:
    """
    tc = TestCase('Test_Case_name')
    c = tc.get_xml_element()
    print(c)
    # tc.get_xml_element()
    # assert c == '<testcase classname="None" name="Test_Case_name"/>'


# Generated at 2022-06-23 13:42:33.393080
# Unit test for constructor of class TestSuites
def test_TestSuites():
    suites = TestSuites(name = 'A')
    assert suites.name == 'A'

# Generated at 2022-06-23 13:42:43.728235
# Unit test for constructor of class TestSuites

# Generated at 2022-06-23 13:42:51.079863
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    error_message = 'default error message'
    error_type = 'default error type'
    error_output = 'default error message'
    error_instance = TestError(message=error_message, type=error_type, output=error_output)
    assert_string = 'TestError(message="' + error_message + '", type="' + error_type + '", output="' + error_output + '")'
    assert _repr(error_instance) == assert_string


# Generated at 2022-06-23 13:43:00.032980
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    testSuite = TestSuite(name = 'TestSuite1', hostname = '192.168.0.1', id = '1234', package = 'mypackage', timestamp = '2020-08-20 15:30:10')
    result = testSuite.get_attributes()
    expected = {'errors': '0', 'name': 'TestSuite1', 'failures': '0', 'disabled': '0', 'time': '0', 'skipped': '0', 'id': '1234', 'package': 'mypackage', 'hostname': '192.168.0.1', 'tests': '0', 'timestamp': '2020-08-20T15:30:10'}
    assert result == expected


# Generated at 2022-06-23 13:43:04.552205
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    x = TestResult(output = 'This is output', message = 'This is message', type = 'This is type')
    y = TestResult(output = 'This is output', message = 'This is message', type = 'This is type')
    assert x == y



# Generated at 2022-06-23 13:43:13.498100
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    import random
    import string
    import xml.etree.ElementTree as ET
