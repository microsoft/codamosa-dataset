

# Generated at 2022-06-23 13:33:14.332143
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    one = TestResult()
    # assert one.__eq__(None) == False
    assert one.__eq__(TestResult()) == True


# Generated at 2022-06-23 13:33:22.943991
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    # test class instance with all attributes
    test_result = TestFailure(
        output="output",
        message="message",
        type="type",
    )

    repr_value = repr(test_result)

    # split repr to remove trailing spaces after new line
    repr_list = repr_value.splitlines()
    repr_list = [item.strip() for item in repr_list]
    repr_list.sort()

    assert repr_list == [
        "TestFailure(",
        "    message='message',",
        "    output='output',",
        "    type='type',",
        ")",
    ]


# Generated at 2022-06-23 13:33:24.751963
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert repr(TestFailure()) == '<TestFailure errors=[] failures=[] skipped=None system_out=None system_err=None>'

# Generated at 2022-06-23 13:33:32.519247
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    obj1 = TestError(output=' ')
    obj2 = TestError(output=' ')
    assert obj1 == obj2
    assert not (obj1 != obj2)
    #when output is different
    obj1 = TestError(output=' ')
    obj2 = TestError(output='')
    assert obj1.__eq__(obj2) == False
    #when message is different
    obj1 = TestError(output=' ')
    obj2 = TestError(output=' ', message='XYZ')
    assert obj1.__eq__(obj2) == False
    #when type is different
    obj1 = TestError(output=' ')
    obj2 = TestError(output=' ', type='XYZ')
    assert obj1.__eq__(obj2) == False


# Generated at 2022-06-23 13:33:42.652845
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    errorA_message = 'This is a test message'
    errorA_type = 'ThisIsATestType'
    errorA = TestError(message=errorA_message, type=errorA_type)

    errorB_message = 'This is a test message'
    errorB_type = 'ThisIsATestType'
    errorB = TestError(message=errorB_message, type=errorB_type)

    errorC_message = 'This is a test message'
    errorC_type = 'ThisIsATestType'
    errorC = TestError(message=errorC_message, type=errorC_type)

    errorD_message = 'This is not a test message'
    errorD_type = 'ThisIsATestType'

# Generated at 2022-06-23 13:33:53.028638
# Unit test for method __eq__ of class TestSuite

# Generated at 2022-06-23 13:33:56.190935
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    result = TestResult()

    assert repr(result) == "TestResult(output='', message='', type='testresult')"



# Generated at 2022-06-23 13:34:06.414671
# Unit test for constructor of class TestSuite
def test_TestSuite():
    test_suite = TestSuite()
    test_suite == TestSuite()

    test_suite = TestSuite('name')
    test_suite == TestSuite('name')
    test_suite == TestSuite(name='name')

    test_suite = TestSuite('name', 'hostname')
    test_suite == TestSuite('name', 'hostname')
    test_suite == TestSuite('name', hostname='hostname')

# Generated at 2022-06-23 13:34:10.329877
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    """
    Test method __eq__ of class TestFailure
    """
    test_output = "test output"
    test_message = "test message"
    test_type = "test type"

    test_input = TestFailure(test_output, test_message, test_type)

    assert test_input.__eq__(test_input) == True


# Generated at 2022-06-23 13:34:17.715690
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    print_result1 = 0
    print_result2 = 0
    print_result3 = 0
    print_result4 = 0
    print_result5 = 0
    print_result6 = 0
    print_result7 = 0
    print_result8 = 0

    result1 = TestResult('hi', 'hello', 'something')
    result2 = TestResult(None, 'hello', 'something')
    result3 = TestResult('hi', None, 'something')
    result4 = TestResult('hi', 'hello', None)
    result5 = TestResult()
    result6 = TestError('hi', 'hello', 'something')
    result7 = TestError(None, 'hello', 'something')
    result8 = TestError('hi', None, 'something')


# Generated at 2022-06-23 13:34:21.404096
# Unit test for constructor of class TestFailure
def test_TestFailure():
    test = TestFailure(output="my_output", message="my_message", type="my_type")
    assert test.output == "my_output"
    assert test.message == "my_message"
    assert test.type == "my_type"


# Generated at 2022-06-23 13:34:25.358842
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    test_suites = TestSuites(name='')
    element = test_suites.get_xml_element()
    assert element.tag == 'testsuites'
    assert element.attrib['name'] == ''



# Generated at 2022-06-23 13:34:30.367933
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    # Test with name
    obj = TestSuite(name='example')
    assert obj.__repr__() == 'TestSuite(name=\'example\')'

    # Test without name
    obj = TestSuite()
    assert obj.__repr__() == 'TestSuite()'


# Generated at 2022-06-23 13:34:35.603506
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():

    # Call method __repr__ of class TestFailure
    test_failure___repr__ = TestFailure('output', 'message', 'type')

    # Assert test case
    assert test_failure___repr__.__repr__() == 'TestFailure(output=output, message=message, type=type, tag=failure)'


# Generated at 2022-06-23 13:34:39.369379
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    tc = TestCase(name ='TestCase1')
    get_attributes = tc.get_attributes()
    print(get_attributes)
    assert get_attributes['name'] == 'TestCase1'


# Generated at 2022-06-23 13:34:45.162368
# Unit test for constructor of class TestError
def test_TestError():
	error = TestError('error',  'An error occurred', 'Error Type')
	assert error.output == 'error'
	assert error.message == 'An error occurred'
	assert error.type == 'Error Type'
	assert error.tag == 'failure'


# Generated at 2022-06-23 13:34:46.124491
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    TestSuites.__eq__()

# Generated at 2022-06-23 13:34:48.114949
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    a = TestResult()
    b = TestResult()
    assert a.__eq__(b) == True


# Generated at 2022-06-23 13:34:58.707419
# Unit test for method __eq__ of class TestSuites

# Generated at 2022-06-23 13:35:02.453541
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
  assert TestSuites.get_attributes(1) == 1
  assert TestSuites.get_attributes(2) == 2

# Unit test if exceptions are thrown as expected

# Generated at 2022-06-23 13:35:12.474185
# Unit test for constructor of class TestResult
def test_TestResult():

    # Test case 1
    # function without argument
    # return not None
    test_case_01 = TestResult()
    assert test_case_01 is not None, 'Test case 1: returned ''None'' for a function with no argument'

    # Test case 2
    # function with argument
    # return 'failure'
    test_case_02 = TestResult()
    test_case_02.name = 'yazeed'
    assert test_case_02.tag == 'failure', 'Test case 2: returned ''None'' for a function with argument'

    # Test case 3
    # function with argument
    # return dictionary
    test_case_03 = TestResult()
    test_case_03.message = 'tester test'
    test_case_03.type = 'error'
    assert test_case_03.get_

# Generated at 2022-06-23 13:35:18.637295
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    failure = TestResult(output="FAILURE")
    assert failure.get_attributes() == {}

    failure = TestResult(output="FAILURE", message='MESSAGE')
    assert failure.get_attributes() == {'message': 'MESSAGE'}

    failure = TestResult(output="FAILURE", message='MESSAGE', type='TYPE')
    assert failure.get_attributes() == {'message': 'MESSAGE', 'type': 'TYPE'}


# Generated at 2022-06-23 13:35:29.671296
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    """Unit test for method get_xml_element of class TestSuites"""


# Generated at 2022-06-23 13:35:37.793262
# Unit test for constructor of class TestCase
def test_TestCase():
    output_expected = 'The output'
    message_expected = 'The message'
    error_type_expected = 'The error type'
    name_expected = 'The name'
    classname_expected = 'The classname'
    time_expected = decimal.Decimal('10.24')

    error = TestError(output=output_expected, message=message_expected, type=error_type_expected)
    case = TestCase(name=name_expected, classname=classname_expected, time=time_expected, errors=[error])

    assert case.name == name_expected
    assert case.classname == classname_expected

    assert len(case.errors) == 1
    assert case.errors[0].output == output_expected
    assert case.errors[0].message == message_expected

# Generated at 2022-06-23 13:35:47.664164
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    # arrange
    attr_expected = {'disabled': '1', 'errors': '0', 'failures': '1', 'name': 'name', 'tests': '2', 'time': '1.23'}

    # act
    test_suite_mock = TestSuite(name = 'suite1', disabled = 1, errors = 0, failures = 1, tests = 2, time = 1.23)
    test_suites = TestSuites(name = 'name')
    test_suites.suites.append(test_suite_mock)
    
    attr_retrieved = test_suites.get_attributes()

    # assert
    assert attr_expected == attr_retrieved


# Generated at 2022-06-23 13:35:52.852159
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    test_case = TestCase(name="test_name")
    assert test_case.__repr__() == "TestCase(name='test_name', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"


# Generated at 2022-06-23 13:35:56.689707
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    elem1 = TestFailure(output='output1', message='message1', type='failure')
    elem2 = TestFailure(output='output1', message='message1', type='failure')

    assert elem1 == elem2
    assert elem2 == elem1


# Generated at 2022-06-23 13:35:59.780204
# Unit test for constructor of class TestSuite
def test_TestSuite():
    suite = TestSuite(name='Test')
    assert suite.name == 'Test'



# Generated at 2022-06-23 13:36:04.358432
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    # get a new instance of TestError
    result = TestError()

    # get a new instance of TestError
    other = TestError()
    # assert the two TestError instances are equal
    assert result == other



# Generated at 2022-06-23 13:36:13.371915
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    """TestCase.__repr__ gives expected output for a complete test case."""
    test_case = TestCase(
        name='my_name',
        assertions=1,
        classname='my_class',
        status='my_status',
        time=1,
        errors=[TestError('error message')],
        failures=[TestFailure('failure message')],
        skipped='skipped reason',
        system_out='system out',
        system_err='system err'
    )


# Generated at 2022-06-23 13:36:17.352367
# Unit test for constructor of class TestFailure
def test_TestFailure():
    with pytest.raises(Exception) as e:
        assert TestFailure(10, "message", "type") == None
    assert str(e.value) == "__init__() takes 2 positional arguments but 3 were given"



# Generated at 2022-06-23 13:36:20.919219
# Unit test for constructor of class TestCase
def test_TestCase():
    """Test for validating attributes of class TestCase"""
    test_case = TestCase('test_case', classname='TestCase', status='status', time=1)
    assert test_case.name == 'test_case'
    assert test_case.classname == 'TestCase'
    assert test_case.status == 'status'
    assert test_case.time == 1


# Generated at 2022-06-23 13:36:22.840751
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError('test', 'error')
    assert error.output == 'test'
    assert error.message == 'error'



# Generated at 2022-06-23 13:36:23.765478
# Unit test for constructor of class TestFailure
def test_TestFailure():

    assert TestFailure().tag == 'failure'

# Generated at 2022-06-23 13:36:31.945361
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case1 = TestCase(name='t1')
    test_case2 = TestCase(name='t2')
    test_case3 = TestCase(name='t3')

    test_suite = TestSuite(
        name='s1',
        properties={'test': 'value'},
        cases=(test_case1, test_case2, test_case3)
    )

    element = test_suite.get_xml_element()
    assert element.tag == 'testsuite'
    assert element.attrib == {
        'name': 's1',
        'tests': '3',
    }

    system_out_element = element.find('system-out')
    assert system_out_element is None

    system_err_element = element.find('system-err')
    assert system_err

# Generated at 2022-06-23 13:36:35.238480
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    testsuites = TestSuites()
    assert testsuites.to_pretty_xml() == '<?xml version="1.0" ?>\n<testsuites/>\n'

# Generated at 2022-06-23 13:36:42.717392
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-23 13:36:50.471391
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    suite = TestSuite(name='test-suite')
    case = TestCase(name='test-case')
    case.failures.append(TestFailure(message='failure'))
    suite.cases.append(case)
    suites = TestSuites(suites=[suite])

    assert suites.get_xml_element().tag == 'testsuites'
    assert suites.get_xml_element().attrib['tests'] == '1'
    assert suites.get_xml_element().attrib['failures'] == '1'



# Generated at 2022-06-23 13:36:54.396599
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    """Unit test for method get_attributes of class TestResult."""
    result = TestResult(type="test_error", message="test_message", output="test_output")
    # Test get_attributes method
    assert result.get_attributes() == {"type": "test_error", "message": "test_message"}


# Generated at 2022-06-23 13:36:58.553768
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    assert TestCase("name") == TestCase("name")
    assert TestCase("name", classname="classname") == TestCase("name", classname="classname")
    assert TestCase("name", classname="classname") != TestCase("name", classname="classname2")

# Generated at 2022-06-23 13:37:02.739358
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testCase = TestCase('name')
    assert testCase.get_attributes() == _attributes(
            name='name'
        )


# Generated at 2022-06-23 13:37:09.145847
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
	xml_output = '<?xml version="1.0" ?><testsuite disabled="0" errors="0" failures="0" hostname="localhost" id="0" name="test1" package="test1" skipped="0" tests="0" time="0"/>'
	assert xml_output == _pretty_xml(TestSuite(name="test1").get_xml_element())
	

# Generated at 2022-06-23 13:37:18.246958
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    ts1 = TestSuite(
        assertions=None,
        cases=[],
        disabled=0,
        errors=0,
        failures=0,
        hostname=None,
        id=None,
        name="",
        package=None,
        properties={},
        skipped=0,
        system_err=None,
        system_out=None,
        tests=0,
        time=None,
        timestamp=None,
    )


# Generated at 2022-06-23 13:37:19.726062
# Unit test for constructor of class TestFailure
def test_TestFailure():

    test_failure = TestFailure('test_output')


# Generated at 2022-06-23 13:37:24.334890
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    testCase = TestCase(name='test_test_case')
    expected = 'TestCase(name=test_test_case, assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'
    assert repr(testCase) == expected



# Generated at 2022-06-23 13:37:28.464686
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite(name="Test", hostname="localhost")
    assert test_suite.get_attributes()['hostname'] == "localhost"



# Generated at 2022-06-23 13:37:34.541863
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite(name="test-suite")
    assert test_suite.get_attributes()["name"] == "test-suite"

    test_suite = TestSuite(name="test-suite-2", package="test")
    assert test_suite.get_attributes()["package"] == "test"


# Generated at 2022-06-23 13:37:38.862416
# Unit test for constructor of class TestError
def test_TestError():
    err = TestError(output="test", message="test message")
    assert(err.output == "test")
    assert(err.message == "test message")
    assert(err.type == "error")


# Generated at 2022-06-23 13:37:40.115758
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    x = TestFailure()
    assert repr(x) == 'TestFailure()'

# Generated at 2022-06-23 13:37:42.868093
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    testSuite = TestSuite(name = 'testSuite')
    assert testSuite.get_attributes()['name'] == str('testSuite')


# Generated at 2022-06-23 13:37:49.667828
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    test_suites = TestSuites()

    assert repr(test_suites) == '<TestSuites()>'


if __name__ == '__main__':
    # Unit test for method __repr__ of class TestCase
    test_TestCase___repr__()

    # Unit test for method __repr__ of class TestResult
    test_TestResult___repr__()

    # Unit test for method __repr__ of class TestSuite
    test_TestSuite___repr__()

    # Unit test for method __repr__ of class TestSuites
    test_TestSuites___repr__()

# Generated at 2022-06-23 13:37:56.212204
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    Test_result = TestResult(output = "Test Case Output", message="Test Case Message")
    assert Test_result.output == "Test Case Output"
    assert Test_result.message == "Test Case Message"
    assert Test_result.tag == "test_result"
    assert Test_result.type is None
    assert Test_result.get_attributes() == {"message": "Test Case Message", "type": "test_result"}


# Generated at 2022-06-23 13:38:01.063248
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test_suites = TestSuites(name='testsuite_name', suites=[])
    assert test_suites.get_attributes() == {'name': 'testsuite_name'}


# Generated at 2022-06-23 13:38:02.478034
# Unit test for constructor of class TestSuites
def test_TestSuites():
    assert TestSuites(name="TestSuite")



# Generated at 2022-06-23 13:38:05.713405
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    s1 = TestSuite('dummy')
    s2 = TestSuite('dummy')
    assert s1 == s2

    s3 = TestSuite('dummy', id='3')
    assert s3 != s2



# Generated at 2022-06-23 13:38:08.238945
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert repr(TestFailure) == "TestFailure(output=None, message=None, type=None)"

# Generated at 2022-06-23 13:38:15.005572
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    dut = TestResult()
    result = dut.get_xml_element()
    assert result.tag == 'testresult'
    assert result.attrib == {}
    assert result.text is None

    dut = TestResult(output='test output', message='test message', type='testtype')
    result = dut.get_xml_element()
    assert result.tag == 'testresult'
    assert result.attrib == {'message': 'test message', 'type': 'testtype' }
    assert result.text == 'test output'


# Generated at 2022-06-23 13:38:17.136794
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert result.get_xml_element().tag == result.tag


# Generated at 2022-06-23 13:38:22.337085
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert TestResult().get_attributes() == {}
    assert TestResult('', 'a message').get_attributes() == {
        'message': 'a message'
    }
    assert TestResult('', '', 'a type').get_attributes() == {
        'type': 'a type'
    }


# Generated at 2022-06-23 13:38:33.978261
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    t1 = TestCase('name')
    t2 = TestCase('name', assertions=1, classname='classname', status='status', time=3.3)
    t3 = TestCase('name', errors=[TestError('output', 'message', 'type')], skippped='skipped')
    t4 = TestCase('name', failures=[TestFailure('output', 'message', 'type')], disabled=True)
    t5 = TestCase('name', system_out='system_out')
    t6 = TestCase('name', system_err='system_err')

    assert repr(t1) == 'name'
    assert repr(t2) == 'name'
    assert repr(t3) == 'name'
    assert repr(t4) == 'name'
    assert repr(t5) == 'name'

# Generated at 2022-06-23 13:38:39.876664
# Unit test for constructor of class TestSuite
def test_TestSuite():
    suite = TestSuite(name='test')
    assert suite.name == 'test'
    assert suite.hostname == None
    assert suite.id == None
    assert suite.package == None
    assert suite.timestamp == None
    #assert suite.properties == {}
    assert suite.cases == []
    assert suite.system_out == None
    assert suite.system_err == None
    assert suite.disabled == 0
    assert suite.errors == 0
    assert suite.failures == 0
    assert suite.skipped == 0
    assert suite.tests == 0
    assert suite.time == 0

# Generated at 2022-06-23 13:38:48.197660
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    ts = TestSuite(name='testsuite', timestamp=datetime.datetime.now())
    attr = ts.get_attributes()
    assert list(attr.keys()) == ['disabled', 'errors', 'failures', 'name', 'tests', 'time', 'timestamp']
    assert attr['disabled'] == '0'
    assert attr['errors'] == '0'
    assert attr['failures'] == '0'
    assert attr['name'] == 'testsuite'
    assert attr['tests'] == '0'
    assert attr['time'] == '0'


# Generated at 2022-06-23 13:38:59.079238
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    """
    Unit test for function get_xml_element of class TestCase
    :return:
    """
    # Test default values
    test_result = TestResult()
    assert test_result.output == None
    assert test_result.message == None
    assert test_result.get_attributes() == dict()
    assert test_result.get_xml_element().tag == "TestResult"
    assert test_result.get_xml_element().get("message") == None
    assert test_result.get_xml_element().get("type") == None
    assert test_result.get_xml_element().text == None
    # Test value with several attributes
    test_result = TestResult(output="Some relevant output", message="A message", type="SomeType")
    assert test_result.output == "Some relevant output"
    assert test

# Generated at 2022-06-23 13:39:03.845704
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test', hostname='localhost', id='id', package='package',
                      timestamp=datetime.datetime(2020, 9, 5, 1, 3, 9))
    suite.properties['name'] = 'value'
    suite.cases.append(TestCase(name='name', assertions='1', classname='classname', status='status', time='2.3'))
    suite.cases[0].errors.append(TestError(output='errors', message='message', type='type'))
    suite.cases[0].failures.append(TestFailure(output='failures', message='message', type='type'))
    suite.cases[0].skipped = 'reason'
    suite.cases[0].system_out = 'system-out'

# Generated at 2022-06-23 13:39:10.136451
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    test_result1 = TestFailure(
        message="message",
        output="output",
        type="type"
    )
    test_result2 = TestFailure(
        message="message",
        output="output",
        type="type"
    )
    assert test_result1 == test_result2

# Generated at 2022-06-23 13:39:15.748086
# Unit test for constructor of class TestFailure
def test_TestFailure():
    testfailure_instance = TestFailure(message='hello', output='world', type='type')
    attributes = testfailure_instance.get_attributes()
    assert attributes['message'] == 'hello'
    assert attributes['type'] == 'type'
    assert testfailure_instance.get_xml_element().text == 'world'


# Generated at 2022-06-23 13:39:23.544115
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    """Unit testing for method __eq__ of class TestSuites
    """
    t1 = TestSuites()
    t1.suites.append(TestSuite('test1'))
    t1.suites.append(TestSuite('test2'))
    t1.suites.append(TestSuite('test3'))

    t2 = TestSuites()
    t2.suites.append(TestSuite('test1'))
    t2.suites.append(TestSuite('test2'))
    t2.suites.append(TestSuite('test3'))

    t3 = TestSuites()
    t3.suites.append(TestSuite('test4'))
    t3.suites.append(TestSuite('test5'))

# Generated at 2022-06-23 13:39:33.014162
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    # Arrange
    test_cases = [
        TestCase(
            name='test_case_1',
            time=decimal.Decimal('1.23'),
            system_out='System out for test case 1',
            system_err='System err for test case 1',
        ),
        TestCase(
            name='test_case_2',
            time=decimal.Decimal('2.34'),
        ),
        TestCase(
            name='test_case_3',
            time=decimal.Decimal('3.45'),
        ),
    ]

# Generated at 2022-06-23 13:39:35.047260
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    error = TestError()
    assert error.__repr__() != ''


# Generated at 2022-06-23 13:39:38.325581
# Unit test for constructor of class TestSuite
def test_TestSuite():
        errors = []
        failures = []
        cases = []
        #TODO: test to see if after assignment of variables, if the instance is created correctly
        assert True == True


# Generated at 2022-06-23 13:39:46.917006
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    name = 'A most excellent test suite'

    case_name = 'A most excellent test case'
    case_classname = 'A most excellent test class'
    case_time = decimal.Decimal('3.14159')

    case = TestCase(
        name=case_name,
        classname=case_classname,
        time=case_time,
    )

    suite = TestSuite(
        name=name,
    )
    suite.cases.append(case)

    suites = TestSuites()
    suites.suites.append(suite)

    element = suites.get_xml_element()

    assert element.tag == 'testsuites'

    assert element.attrib['tests'] == '1'
    assert element.attrib['time'] == '3.14159'


# Generated at 2022-06-23 13:39:52.730030
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """Create a JUnit XML file"""
    test_suites = TestSuites()
    test_suite = TestSuite(name='Some test suite', timestamp=datetime.datetime(2019, 6, 19, 10, 45))
    test_suites.suites = [test_suite]

    test_case = TestCase(name='Some test case', classname='SomeClass', time=decimal.Decimal('1.234'))
    test_case.system_out = "Some stdout"
    test_case.system_err = "Some stderr"
    test_case.failures.append(TestFailure())
    test_case.failures.append(TestFailure(output='Some dirty output'))
    test_case.errors.append(TestError())

# Generated at 2022-06-23 13:39:55.076670
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    suite1 = TestSuites()
    suite2 = TestSuites()
    assert(suite1==suite2)


# Generated at 2022-06-23 13:39:57.135051
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    result_1 = TestFailure()
    result_2 = TestFailure()

    assert result_1 == result_2

# Generated at 2022-06-23 13:40:09.435779
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    t1 = TestError(output = "", message = None, type = None)
    t2 = TestError(output = "", message = None, type = None)
    assert(t1 == t2)

    t3 = TestError(output = "", message = None, type = "")
    assert not(t1 == t3)

    t4 = TestError(output = "", message = "", type = None)
    assert not(t1 == t4)

    t5 = TestError(output = "", message = "", type = "")
    assert not(t1 == t5)

    t6 = TestError(output = "", message = "", type = "")
    assert (t5 == t6)


# Generated at 2022-06-23 13:40:17.738293
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
  s = TestSuites()
  s.name = "testsuites"
  s.disabled = 0
  s.errors = 1
  s.failures = 0
  s.tests = 1
  s.time = 0.1
  s.suites = []

  ts = TestSuite()
  ts.name = "testsuite"
  ts.hostname = None
  ts.id = None
  ts.package = None
  ts.timestamp = None
  ts.properties = {}
  ts.system_out = None
  ts.system_err = None
  ts.disabled = 0
  ts.errors = 1
  ts.failures = 0
  ts.tests = 1
  ts.time = 0.1
  ts.cases = []

  tc = TestCase()

# Generated at 2022-06-23 13:40:29.409697
# Unit test for method __repr__ of class TestCase

# Generated at 2022-06-23 13:40:38.709300
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case = TestCase('TestCase')
    assert (test_case==TestCase('TestCase'))
    test_case.errors.append(TestError('Test error'))
    assert (test_case==TestCase('TestCase'))
    test_case.failures.append(TestFailure('Test failure'))
    assert (test_case==TestCase('TestCase'))
    test_case.skipped = 'Test skipped'
    assert (test_case==TestCase('TestCase'))
    test_case.system_out = 'Test system output'
    assert (test_case==TestCase('TestCase'))
    test_case.system_err = 'Test system error'
    assert (test_case==TestCase('TestCase'))

# Generated at 2022-06-23 13:40:46.440687
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_suite = TestSuite(name='fake_name', timestamp=datetime.datetime.now())
    test_case = TestCase(name='fake_name', classname='fake_classname', status='fake_status', time=decimal.Decimal('1'))
    test_suite.cases.append(test_case)
    expected = '<testsuite disabled="" errors="" failures="" hostname="" id="" name="fake_name" package="" skipped="" tests="" time="" timestamp="">\n' \
               '    <testcase assertions="" classname="fake_classname" name="fake_name" status="fake_status" time="1.0"></testcase>\n' \
               '</testsuite>\n'
    actual = _pretty_xml(test_suite.get_xml_element())
    assert actual

# Generated at 2022-06-23 13:40:48.383265
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    """Test that two TestFailure instances are equal if their attributes are equal."""
    assert TestFailure(output='hello', message='world', type='error') == TestFailure(output='hello', message='world', type='error')


# Generated at 2022-06-23 13:40:55.087506
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    result = TestResult()
    assert result.get_attributes() == {}

    result = TestResult(output='Some output', message='Some message')
    assert result.get_attributes() == {'message': 'Some message'}

    result = TestResult(output='Some output', message='Some message', type='Some type')
    assert result.get_attributes() == {'type': 'Some type', 'message': 'Some message'}


# Generated at 2022-06-23 13:41:06.965316
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    name = 'name'
    hostname = 'hostname'
    id = 'id'
    package = 'package'
    timestamp = datetime.datetime.today()
    cases = [TestCase(1, 2, '3', '4', 5), TestCase(6, 7, '8', '9', 10)]
    system_out = 'system out!'
    system_err = 'system err!'
    properties = {'a':'1', 'b':'2', 'c':'3'}
    suite = TestSuite(name, hostname, id, package, timestamp, cases, system_out, system_err, properties)

# Generated at 2022-06-23 13:41:10.437760
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert TestFailure(type="fail", message="Test failed").get_xml_element().attrib == {'message': 'Test failed', 'type': 'fail'}


# Generated at 2022-06-23 13:41:20.091594
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase("MyTest")
    element = test_case.get_xml_element()
    assert ET.tostring(element) == b"<testcase name=\"MyTest\" />"

    test_case = TestCase("MyTest", assertions=2)
    element = test_case.get_xml_element()
    assert ET.tostring(element) == b"<testcase assertions=\"2\" name=\"MyTest\" />"

    test_case = TestCase("MyTest", classname="MyClass")
    element = test_case.get_xml_element()
    assert ET.tostring(element) == b"<testcase classname=\"MyClass\" name=\"MyTest\" />"

    test_case = TestCase("MyTest", status="Success")
    element = test_case.get_xml_element()

# Generated at 2022-06-23 13:41:24.811963
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    failure = TestError(output='foo', message='bar')
    assert failure.__repr__() == 'TestError(output=\'foo\', message=\'bar\', type=\'error\')'



# Generated at 2022-06-23 13:41:33.834512
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    case = TestCase(name='test')
    attributes = case.get_attributes()
    assert attributes['name'] == 'test'
    assert not attributes.get('classname')
    assert not attributes.get('status')
    assert not attributes.get('time')

    case = TestCase(name='test2', classname='testClass', status='success', time=5.5)
    attributes = case.get_attributes()
    assert attributes['name'] == 'test2'
    assert attributes['classname'] == 'testClass'
    assert attributes['status'] == 'success'
    assert attributes['time'] == '5.5'



# Generated at 2022-06-23 13:41:36.975303
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite(name='foo')
    assert {'name': 'foo'} == suite.get_attributes()

# Generated at 2022-06-23 13:41:42.019278
# Unit test for constructor of class TestResult
def test_TestResult():
    tag = 'tag'
    output = 'output'
    message = 'message'
    type = 'type'
    
    test = TestResult(output=output, message=message, type=type)
    assert test.output == output
    assert test.message == message
    assert test.type == type
    assert test.tag == tag
    

# Generated at 2022-06-23 13:41:45.489969
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    suite = TestSuite(
        name='foo',
    )
    assert repr(suite) == '<TestSuite(name=foo)>'


# Generated at 2022-06-23 13:41:49.232419
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    testError=TestError(output="TestError output", message="TestError message", type="TestError type")
    assert str(testError)=="TestError(output='TestError output', message='TestError message', type='TestError type')"


# Generated at 2022-06-23 13:41:59.008609
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test = TestSuites()
    test.suites.append(TestSuite(name="name1"))
    test.suites.append(TestSuite(name="name2"))
    test.suites[1].cases.append(TestCase(name="name2_1"))
    test.suites[1].cases[0].time = decimal.Decimal(1.0)
    test.suites[1].cases.append(TestCase(name="name2_2"))
    test.suites[1].cases[1].time = decimal.Decimal(2.0)
    test.suites.append(TestSuite(name="name3"))
    test.suites[2].cases.append(TestCase(name="name3_1"))

# Generated at 2022-06-23 13:42:04.774529
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    assert TestResult(None, None, None) == TestResult(None, None, None)
    assert TestResult('a', None, None) == TestResult('a', None, None)
    assert TestResult(None, 'a', None) == TestResult(None, 'a', None)
    assert TestResult(None, None, 'a') == TestResult(None, None, 'a')
    assert TestResult('a', 'a', 'a') == TestResult('a', 'a', 'a')
    assert TestResult('a', 'a', 'a') != TestResult('a', None, None)
    assert TestResult('a', 'a', 'a') != TestResult(None, 'a', None)
    assert TestResult('a', 'a', 'a') != TestResult(None, None, 'a')

# Generated at 2022-06-23 13:42:07.513447
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testcase = TestCase(name="TestCase_name01", assertions=1, classname="TestCase_classname01", status="TestCase_status01", time=0.01)

    assert testcase.get_attributes() == {'name': 'TestCase_name01', 'assertions': 1, 'classname': 'TestCase_classname01', 'status': 'TestCase_status01', 'time': 0.01}


# Generated at 2022-06-23 13:42:17.851801
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_results = [
        (TestError(output="The explosion exceeded the lookahead buffer", message="The explosion exceeded the lookahead buffer"), "<error message=\"The explosion exceeded the lookahead buffer\" type=\"error\">The explosion exceeded the lookahead buffer</error>"),
        (TestFailure(output="Line 1 column 8: expected &lt;foo&gt;, got &lt;bar&gt;", message="Line 1 column 8: expected &lt;foo&gt;, got &lt;bar&gt;"), "<failure message=\"Line 1 column 8: expected &amp;lt;foo&amp;gt;, got &amp;lt;bar&amp;gt;\" type=\"failure\">Line 1 column 8: expected &lt;foo&gt;, got &lt;bar&gt;</failure>"),
    ]

# Generated at 2022-06-23 13:42:19.708512
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    TestFailure = TestFailure()
    TestFailure.__repr__()
    assert True


# Generated at 2022-06-23 13:42:27.849852
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    # test equality of objects created with different constructors
    failure_1 = TestFailure()
    failure_2 = TestFailure(output=None, message=None, type=None)
    assert failure_1 == failure_2

    # test equality of objects with different attribute values
    failure_1 = TestFailure(output='some text')
    failure_2 = TestFailure(output='some different text')
    assert failure_1 != failure_2

    # test equality of objects with different tag values
    failure_1 = TestFailure(type='failure')
    failure_2 = TestFailure(type='error')
    assert failure_1 != failure_2



# Generated at 2022-06-23 13:42:29.489486
# Unit test for constructor of class TestResult
def test_TestResult():
    """Test constructor of class TestResult."""
    test_result = TestResult()



# Generated at 2022-06-23 13:42:34.513965
# Unit test for constructor of class TestResult
def test_TestResult():
    tes = TestError(output="testOutPut", message="testMessage", type="testType")
    assert tes.output == "testOutPut"
    assert tes.message == "testMessage"
    assert tes.type == "testType"


# Generated at 2022-06-23 13:42:37.289447
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    """Test for method __repr__ of class TestCase"""
    testcase = TestCase("Test")

    print(repr(testcase))

# Generated at 2022-06-23 13:42:40.503715
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_Result = TestResult(output='output', message='message', type='type')
    assert test_Result.get_attributes() == {'message': 'message', 'type': 'type'}


# Generated at 2022-06-23 13:42:47.327327
# Unit test for method to_pretty_xml of class TestSuites

# Generated at 2022-06-23 13:42:51.028577
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    TestResult(output="TestString") == TestResult(output="Test") # True
    TestResult(message="TestString") == TestResult(message="Test") # True
    TestResult(type="TestString") == TestResult(type="Test") # True

# Generated at 2022-06-23 13:42:55.800700
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    """TestCase class get_xml_element method unit test"""
    tc = TestCase("mytest",time=5)
    ETest = ET.Element('testcase', {'name':'mytest','time':'5'})
    assert(tc.get_xml_element()==ETest)


# Generated at 2022-06-23 13:43:00.556141
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    test_suite_1 = TestSuite(name="test_suite_1")
    test_suite_2 = TestSuite(name="test_suite_1")
    assert test_suite_1 == test_suite_2


# Generated at 2022-06-23 13:43:04.291614
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    test = TestFailure(output='output', message='message', type='type')
    other = TestFailure(output='output', message='message', type='type')
    assert test == other



# Generated at 2022-06-23 13:43:05.682948
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    a = TestSuites('name')
    b = TestSuites('name')
    assert a == b


# Generated at 2022-06-23 13:43:07.511947
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    assert TestFailure().type == TestFailure.tag == 'failure'
    assert TestError().type == TestError.tag == 'error'


# Generated at 2022-06-23 13:43:16.675165
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    """
    """
    testsuites = TestSuites('sample_name')
    testsuite = TestSuite('sample_name2')
    testsuites.suites.append(testsuite)
    testcase = TestCase('sample_name3')
    testsuite.cases.append(testcase)
    testcase.time = decimal.Decimal('2.3')
    testcase.is_disabled = False
    testcase.classname = "test_class"
    testcase.errors = []
    testcase.system_err = "foo"
    testcase.failures = []
    testcase.skipped = None
    testcase.system_out = "bar"
    testcase.status = "test_status"


    xmlString = testsuites.to_pretty_xml()