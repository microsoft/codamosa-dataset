

# Generated at 2022-06-23 13:33:19.052439
# Unit test for constructor of class TestSuites
def test_TestSuites():
    s = TestSuites()
    assert (s.name is None) and (s.suites == [])
    s = TestSuites('aa')
    assert (s.name is 'aa') and (s.suites == [])
    s = TestSuites(name='aa')
    assert (s.name is 'aa') and (s.suites == [])
    s = TestSuites(name='aa', suites=[])
    assert (s.name is 'aa') and (s.suites == [])
    s = TestSuites(name='aa', suites=[{'a': 'b'}])
    assert (s.name is 'aa') and (s.suites == [{'a': 'b'}])


# Generated at 2022-06-23 13:33:21.687205
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    error = TestError(output="test output", message="test message", type="test type")

    assert repr(error) == "TestError(output='test output', message='test message', type='test type')"


# Generated at 2022-06-23 13:33:29.407520
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testsuite = TestSuite(
        name="myTestSuite",
        properties={'db': 'postgres'},
        cases=[
            TestCase(
                name="MyTestCaseName",
                classname="MyTestCaseClass",
                status="TEST",
                time=decimal.Decimal("1.2345"),
                errors=[TestError(message="test error message")],
                skipped="some reason",
                system_out="test system out",
                system_err="test system err",
            )
        ]
    )


# Generated at 2022-06-23 13:33:31.944375
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult(type='type')) == 'TestResult(type=\'type\')'
    assert repr(TestResult()) == 'TestResult()'


# Generated at 2022-06-23 13:33:42.618562
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    assert TestSuite(name='a', hostname='b', id='c', package='d', timestamp=datetime.datetime(2020,1,1,0,0,0), properties={'c': 'd'}, cases=[], system_out='h', system_err='i') == TestSuite(name='a', hostname='b', id='c', package='d', timestamp=datetime.datetime(2020,1,1,0,0,0), properties={'c': 'd'}, cases=[], system_out='h', system_err='i')

# Generated at 2022-06-23 13:33:45.522378
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    element = TestCase(name='name',
                       assertions=1,
                       classname='classname',
                       status='status',
                       time=0.0)
    expected = "TestCase(name='name', assertions=1, classname='classname', status='status', time=0.0, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"
    assert (element.__repr__() == expected)


# Generated at 2022-06-23 13:33:48.340676
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    """Unit test for method __repr__ of class TestResult."""
    pass


# Generated at 2022-06-23 13:33:52.351946
# Unit test for constructor of class TestSuite
def test_TestSuite():
    test_case1 = TestCase(name='test_case_a', classname='TestCaseA', time=0.1, skippe=None)
    test_suite = TestSuite(name='test_suite_a', id='1', hostname='localhost',timestamp=datetime.datetime.now(), cases=[test_case1])
    assert test_suite is not None

# Generated at 2022-06-23 13:33:53.178527
# Unit test for constructor of class TestSuite
def test_TestSuite():
    assert(True)

# Generated at 2022-06-23 13:33:56.610041
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    testresult_one = TestResult('some string')
    testresult_two = TestResult('some string')
    assert testresult_one == testresult_two


# Generated at 2022-06-23 13:33:59.594612
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite("name", "AAAA", "0", "text", "@@@", "2019-06-06T00:00:00")
    print(test_suite.get_attributes())

# Generated at 2022-06-23 13:34:05.822120
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    a = TestResult()
    assert a.get_attributes() == {}

    b = TestResult(output="test output")
    assert b.get_attributes() == {}

    c = TestResult(message="test message")
    assert c.get_attributes() == {"message": "test message"}

    d = TestResult(output="test output", message="test message")
    assert d.get_attributes() == {"message": "test message"}



# Generated at 2022-06-23 13:34:06.464439
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    failure1 = TestFailure()
    failure2 = TestFailure()



# Generated at 2022-06-23 13:34:07.956257
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
  sut = TestResult()
  assert str(sut) == 'TestResult()'



# Generated at 2022-06-23 13:34:10.294293
# Unit test for constructor of class TestError
def test_TestError():
    e = TestError("output", "message", "type")
    assert e.output == "output"
    assert e.message == "message"
    assert e.type == "type"


# Generated at 2022-06-23 13:34:19.472311
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    # Arrange
    result = TestResult(
        output="This is the output",
        message="This is the message",
        type="This is the type"
    )

    # Act
    xml_element = result.get_xml_element()

    # Assert
    assert xml_element.tag == result.tag

    for attribute_name in result.get_attributes():
        assert xml_element.attrib[attribute_name] == str(result.get_attributes()[attribute_name])

    assert xml_element.text == result.output

# Generated at 2022-06-23 13:34:20.795350
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    tr = TestResult()
    assert tr.type == tr.tag


# Generated at 2022-06-23 13:34:32.520760
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    testCase1 = TestCase(name="test1", assertions=1, classname="test class", status="ok", time=1.0,
                         errors=[TestError(output="output", message="message", type="type")],
                         failures=[TestFailure(output="output", message="message", type="type")],
                         skipped="skipped", system_out="system out", system_err="system err")

    testCase2 = TestCase(name="test1", assertions=1, classname="test class", status="ok", time=1.0,
                         errors=[TestError(output="output", message="message", type="type")],
                         failures=[TestFailure(output="output", message="message", type="type")],
                         skipped="skipped", system_out="system out", system_err="system err")

    assert testCase1 == testCase2

# Generated at 2022-06-23 13:34:34.915333
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    result = TestResult()
    assert str(result) == "output = None, message = None, type = None"



# Generated at 2022-06-23 13:34:37.641594
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    obj_0=TestSuite(name='hello')
    obj_1=TestSuite(name='hello')
    assert obj_0==obj_1

# Generated at 2022-06-23 13:34:43.309209
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    ts = TestSuite(name='The name', hostname='local', id='id_test', package='test_package', timestamp=datetime.datetime(2020, 10, 12, 10, 44, 14))
    assert ts.get_attributes() == {'name': 'The name', 'hostname': 'local', 'id': 'id_test', 'package': 'test_package', 'timestamp': '2020-10-12T10:44:14'}


# Generated at 2022-06-23 13:34:47.168238
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert repr(TestFailure(message='test', output='test', type='test')) == "TestFailure(output='test', message='test', type='test')"
    assert repr(TestFailure(message='test', output='test')) == "TestFailure(output='test', message='test')"
    assert repr(TestFailure(message='test')) == "TestFailure(message='test')"
    assert repr(TestFailure()) == "TestFailure()"


# Generated at 2022-06-23 13:34:57.715900
# Unit test for constructor of class TestSuite
def test_TestSuite():
    test_case1 = TestCase(name='test1.py')
    test_case2 = TestCase(name='test2.py')

    test_suite = TestSuite(
        name='Tests',
        hostname='localhost',
        id='2',
        package='Example',
        timestamp=datetime.datetime.now(),
        cases=[test_case1, test_case2]
    )

    assert test_suite.name == 'Tests'
    assert test_suite.hostname == 'localhost'
    assert test_suite.id == '2'
    assert test_suite.package == 'Example'
    assert test_suite.timestamp.date() == datetime.datetime.now().date()
    assert test_suite.cases == [test_case1, test_case2]



# Generated at 2022-06-23 13:35:02.284300
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    testResult1 = TestResult()
    assert testResult1.type == 'str'
    testResult2 = TestResult('str')
    assert testResult2.type == 'str'


# Generated at 2022-06-23 13:35:06.044405
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_result = TestResult(output='TEST', message='message',  type='type')
    attributes = {'message': 'message', 'type': 'type'}
    assert test_result.get_attributes() == attributes

# Generated at 2022-06-23 13:35:13.677412
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    import io
    import sys
    # Capture the output of the default stream
    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput
    # Run function __repr__ of class TestResult
    test_result_instance = TestResult(output="output1", message="message1", type="type1")
    output_value = repr(test_result_instance)
    # Reset the default stream
    sys.stdout = sys.__stdout__
    # Assert
    assert capturedOutput.getvalue() == "TestResult(output='output1', message='message1', type='type1')\n"
    assert output_value == "TestResult(output='output1', message='message1', type='type1')"


# Generated at 2022-06-23 13:35:16.230057
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase("test name")
    assert test_case.get_xml_element().attrib == {"name": "test name"}



# Generated at 2022-06-23 13:35:19.922605
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    # Arrange
    result1 = TestResult(None, None, None)
    result2 = TestResult(None, None, None)

    # Act
    actual = result1 == result2

    # Assert
    assert actual == True



# Generated at 2022-06-23 13:35:24.041327
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    err1 = TestError(output="output", message="message", type="type")
    err2 = TestError(output="output", message="message", type="type")
    assert err1.__eq__(err2)


# Generated at 2022-06-23 13:35:30.557981
# Unit test for constructor of class TestCase
def test_TestCase():
    test_case = TestCase(name = 'Test case', assertions = 3, classname='Blah', status = 'Passed', time = 5)
    assert test_case.name == 'Test case'
    assert test_case.assertions == 3
    assert test_case.classname == 'Blah'
    assert test_case.status == 'Passed'
    assert test_case.time == 5
    return

if __name__ == '__main__':
    test_TestCase()

# Generated at 2022-06-23 13:35:37.795227
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult(None)) == 'TestResult(output=None, message=None, type=None)'
    assert repr(TestResult('', '', '')) == 'TestResult(output=\'\', message=\'\', type=\'\')'
    assert repr(TestResult('output', 'message', 'type')) == 'TestResult(output=\'output\', message=\'message\', type=\'type\')'



# Generated at 2022-06-23 13:35:48.272807
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    xml = TestSuites(name='TestSuites', suites=[
        TestSuite(name='TestSuite1', tests=1, time=1.0),
        TestSuite(name='TestSuite2', tests=2, time=2.0),
    ]).get_xml_element()

    assert ET.tostring(xml) == b'<testsuites disabled="0" errors="0" failures="0" name="TestSuites" tests="3" time="3.0"><testsuite disabled="0" errors="0" failures="0" name="TestSuite1" skipped="0" tests="1" time="1.0" /><testsuite disabled="0" errors="0" failures="0" name="TestSuite2" skipped="0" tests="2" time="2.0" /></testsuites>'


# Generated at 2022-06-23 13:35:50.553785
# Unit test for constructor of class TestFailure
def test_TestFailure():
    result = TestFailure()
    assert result.__dict__ == {'output': None, 'message': None, 'type': 'failure'}


# Generated at 2022-06-23 13:35:59.513900
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():

    test_suite = TestSuite(name = 'test_suite_1', properties = {'property1' : 'value1', 'property2' : 'value2'}, cases = [TestCase(name = 'testcase_1', failures = [TestFailure(output = 'some failure')]), TestCase(name = 'testcase_2', failures = [TestFailure(output = 'some failure')])])
    element = test_suite.get_xml_element()

# Generated at 2022-06-23 13:36:09.877253
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    assert TestResult(output = 'output', message = 'message', type = 'type') == TestResult(output = 'output', message = 'message', type = 'type')
    assert TestResult(output = 'output', message = 'message', type = 'type') != TestResult(output = None, message = 'message', type = 'type')
    assert TestResult(output = 'output', message = 'message', type = 'type') != TestResult(output = 'output', message = None, type = 'type')
    assert TestResult(output = 'output', message = 'message', type = 'type') != TestResult(output = 'output', message = 'message', type = None)


# Generated at 2022-06-23 13:36:18.625523
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    print("\nTesting method __post_init__ of class TestResult")
    e = TestError()
    isinstance(e, TestResult)

    # For assert statements see https://docs.python.org/3/library/unittest.html#assert-methods
    # Tests if e is instance of TestResult, if that's the case it should have a tag attribute and it should have the value of TestError.tag
    assert isinstance(e, TestResult)
    assert hasattr(e, 'tag')
    assert e.tag == TestError.tag



# Generated at 2022-06-23 13:36:23.306331
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase(name='test', assertions=10, classname='MyClass', status='success', time=1.2)
    result = test_case.get_attributes()
    expected = {'name': 'test', 'assertions': '10', 'classname': 'MyClass', 'status': 'success', 'time': '1.2'}
    assert expected == result


# Generated at 2022-06-23 13:36:26.948846
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError(message = "Error", type = "Error", output = "Error")
    assert error.message == "Error"
    assert error.type == "Error"
    assert error.output == "Error"


# Generated at 2022-06-23 13:36:30.815419
# Unit test for constructor of class TestError
def test_TestError():
	err = TestError(output="Test failed")
	assert err.tag == "error"
	err = TestError(output="Test failed", message="Message", type="Type")
	assert err.tag == "error"


# Generated at 2022-06-23 13:36:35.868800
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    expected_xml = '''<?xml version="1.0" ?>
<testsuites disabled="0" errors="0" failures="0" tests="0" time="0.0"/>
'''
    test_suites = TestSuites()
    assert expected_xml == test_suites.to_pretty_xml()

# Generated at 2022-06-23 13:36:40.494781
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    ts = TestSuites()
    ts.name = 'test_name'
    suite = TestSuite()
    suite.name = 'suite_name'
    ts.suites.append(suite)
    tc = TestCase()
    tc.name = 'test_case'
    suite.cases.append(tc)
    assert 1 == ts.failures
    print(ts.to_pretty_xml())

# Generated at 2022-06-23 13:36:48.709772
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    xml_element = TestSuites().get_xml_element()
    print(ET.tostring(xml_element, encoding='unicode'))

    # from xml.etree import ElementTree as ET
    #
    #
    # tree = ET.parse("xml/test_suite_sample.xml")
    # root = tree.getroot()
    # print(root.tag)
    # print(root.attrib)
    # print(root.text)
    #
    # for child in root:
    #     print('\t', child.tag, child.attrib)
    #     for gc in child:
    #         print('\t\t', gc.tag, gc.attrib, gc.text)
    #
    # tree2 = ET.ElementTree(xml_element)
    #

# Generated at 2022-06-23 13:36:56.350657
# Unit test for constructor of class TestResult
def test_TestResult():
    testFailure = TestFailure(output='failed', message='message', type='failure')

    assert testFailure.output == 'failed'
    assert testFailure.message == 'message'
    assert testFailure.type == 'failure'

    testError = TestError(output='error', message='message', type='error')

    assert testError.output == 'error'
    assert testError.message == 'message'
    assert testError.type == 'error'


# Generated at 2022-06-23 13:36:57.488519
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    assert TestSuites(name='', suites=[]) == TestSuites(name='', suites=[])



# Generated at 2022-06-23 13:37:04.326378
# Unit test for constructor of class TestResult
def test_TestResult():
    # Test the case that all fields were initialized in constructor
    test_result = TestResult('failure', 'error', 'message')
    # Test the case that all fields are valid
    assert test_result.output == 'failure'
    assert test_result.message == 'error'
    assert test_result.type == 'message'


# Generated at 2022-06-23 13:37:05.479143
# Unit test for constructor of class TestResult
def test_TestResult():
    result = TestResult('test_output')
    assert result.output == 'test_output'


# Generated at 2022-06-23 13:37:07.860474
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # GIVEN
    testResult_dict = {'message': 'a', 'type': 'b', 'output': 'c'}
    testResult_object = TestResult(**testResult_dict)

    # WHEN
    attributes = testResult_object.get_attributes()

    # THEN
    assert attributes == {'message': 'a', 'type': 'b'}
    

# Generated at 2022-06-23 13:37:17.307345
# Unit test for constructor of class TestSuite
def test_TestSuite():

    errors = []
    failures = []
    cases = []
    # Creating and appending errors, failures and cases to their respective lists
    errors.append(TestError(output='I am an error', message='to', type='ErrorType'))
    failures.append(TestFailure(output='I am a failure', message='to', type='FailureType'))
    cases.append(TestCase(name='testCase', assertions=2, classname='testClass', status='pass', time=0.9, errors=errors, failures=failures, skipped='Failed', system_out='out', system_err='err'))

    # Creating object of class TestSuite

# Generated at 2022-06-23 13:37:19.471544
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    xml = '<error/>'
    assert ET.tostring(TestError().get_xml_element(), encoding='unicode') == xml


# Generated at 2022-06-23 13:37:21.794403
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    x = TestError()
    expected = "TestError(output=None, message=None, type='error')"
    assert(str(x) == expected)


# Generated at 2022-06-23 13:37:23.463691
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    ts = TestSuites(name="TestSuites", suites=[])
    ts.get_attributes()

# Generated at 2022-06-23 13:37:27.385932
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():    
    # Create a TestResult object
    testResult = TestResult()
    
    # Get XML Element of the object
    element = testResult.get_xml_element()
    
    # Assert that the element has 'result' as its tag
    assert(element.tag == 'result')
    # Assert that the element has no child elements
    assert(len(element) == 0)
    # Assert that the element is not empty    
    assert(element.text is not None)



# Generated at 2022-06-23 13:37:32.365941
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    class TestResultImpl(TestResult):
        def __init__(self, output, message, type):
            super().__init__(output, message, type)

        @property
        def tag(self):
            return 'tag'

    result = TestResultImpl('output', 'message', 'type')
    assert repr(result) == "TestResultImpl(output='output', message='message', type='type')"



# Generated at 2022-06-23 13:37:42.826691
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    # Arrange
    hostname: str = 'host'
    id: str = 'id'
    name: str = 'name'
    package: str = 'package'
    timestamp: datetime.datetime = datetime.datetime.now()
    disabled: int = 1
    errors: int = 2
    failures: int = 3
    skipped: int = 4
    tests: int = 5
    time: decimal.Decimal = decimal.Decimal('6.00')
    properties: t.Dict[str, str] = {
        'a': 'b',
        'c': 'd'
    }
    system_out: str = 'out'
    system_err: str = 'err'

    # Act

# Generated at 2022-06-23 13:37:49.378844
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    assert repr(TestFailure()) in {
        'TestFailure(output=None, message=None, type=\'failure\')',
        'TestFailure(message=None, output=None, type=\'failure\')',
    }
    assert repr(TestFailure(output='output', message='message', type='type')) in {
        'TestFailure(output=\'output\', message=\'message\', type=\'type\')',
        'TestFailure(message=\'message\', output=\'output\', type=\'type\')',
    }



# Generated at 2022-06-23 13:37:51.126143
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    test_result = TestError(message='test message')
    assert test_result.__repr__() == "TestError(message='test message', output=None, type='error')"


# Generated at 2022-06-23 13:37:59.875953
# Unit test for constructor of class TestFailure
def test_TestFailure():
    t1 = TestFailure()
    assert t1.output is None
    assert t1.message is None
    assert t1.type == 'failure'
    t2 = TestFailure(output='output', type='type')
    assert t2.output == 'output'
    assert t2.type == 'type'
    t3 = TestFailure(output='output', message='message', type='type')
    assert t3.output == 'output'
    assert t3.message == 'message'
    assert t3.type == 'type'
    t4 = TestFailure(message='message')
    assert t4.message == 'message'
    assert t4.type == 'failure'


# Generated at 2022-06-23 13:38:01.942840
# Unit test for constructor of class TestFailure
def test_TestFailure():
  TestFailure(output="test output", message="test message")


# Generated at 2022-06-23 13:38:11.803424
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    test_cases: t.List[t.Tuple[str, TestResult, t.Dict[str, str]]] = [
        (
            'TestResult',
            TestResult(),
            {},
        ),
        (
            'TestResult_output',
            TestResult(output='test'),
            {},
        ),
        (
            'TestResult_message',
            TestResult(message='test'),
            {'message': 'test'},
        ),
        (
            'TestResult_type',
            TestResult(type='test'),
            {'type': 'test'},
        ),
        (
            'TestResult_message_type',
            TestResult(message='test', type='test'),
            {'message': 'test', 'type': 'test'},
        ),
    ]


# Generated at 2022-06-23 13:38:23.415119
# Unit test for method __repr__ of class TestSuite

# Generated at 2022-06-23 13:38:30.960333
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    """
    Testing the get_attributes method of class TestCase using dataclasses
    """
    testcase = TestCase(name='TestCase', assertions='10', classname='Classname', status='Status', time='10')
    assert testcase.get_attributes() == {'assertions': '10', 'classname': 'Classname', 'name': 'TestCase', 'status': 'Status', 'time': '10'}



# Generated at 2022-06-23 13:38:33.416533
# Unit test for constructor of class TestFailure
def test_TestFailure():
    test_failure = TestFailure()
    assert test_failure is not None


# Generated at 2022-06-23 13:38:35.921251
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    # Code coverage for no-op case
    assert TestError() == TestError()

    # Code coverage for self != other object
    assert TestError() != object()


# Generated at 2022-06-23 13:38:37.777973
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    result = TestResult()
    assert result.type == "result"



# Generated at 2022-06-23 13:38:41.237625
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    """__eq__"""
    obj = TestError(output='test.output', message='test.message', type='test.type')
    obj2 = TestError(output='test.output', message='test.message', type='test.type')
    obj.__dict__.pop('type')
    obj2.__dict__.pop('type')
    assert obj == obj2


# Generated at 2022-06-23 13:38:47.934072
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    fixture = TestSuites(suites=[TestSuite(name='Suite1'), TestSuite(name='Suite2')])
    result = fixture.get_xml_element()
    assert result.tag == 'testsuites'
    assert result[0].attrib['name'] == 'Suite1'
    assert result[1].attrib['name'] == 'Suite2'


if __name__ == '__main__':
    test_TestSuites_get_xml_element()

# Generated at 2022-06-23 13:38:56.446777
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    e = TestSuites()
    e.name = 'My Test Suites'
    e.disabled = 2
    e.errors = 3
    e.failures = 4
    e.tests = 5
    e.time = 6.7
    print(e)
    assert "TestSuites(name='My Test Suites', disabled=2, errors=3, failures=4, tests=5, time=6.7, suites=[])" == repr(e)


# Generated at 2022-06-23 13:39:08.128076
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-23 13:39:17.160078
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    test_result1 = TestResult(output="OUTPUT_1")
    test_result2 = TestResult(output="OUTPUT_1")
    test_result3 = TestResult(output="OUTPUT_2")

    print("test_result1 == test_result2: " + str(test_result1 == test_result2))
    print("test_result1 == test_result3: " + str(test_result1 == test_result3))
    print("test_result2 == test_result3: " + str(test_result2 == test_result3))


# Generated at 2022-06-23 13:39:29.283234
# Unit test for constructor of class TestSuites

# Generated at 2022-06-23 13:39:31.518304
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    testcase = TestCase(name='test_case')

    assert 'test_case' == testcase.__repr__()

# Generated at 2022-06-23 13:39:33.727062
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError("Error", "A stack trace", "some_type") == TestError("Error", "A stack trace", "some_type")


# Generated at 2022-06-23 13:39:39.809901
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    from unittest.mock import Mock, patch

    class MyTestResult(TestResult):
        @property
        def tag(self) -> str:
            return 'my-test-result'

    my_test_result_mock = Mock(spec=MyTestResult)

    assert TestResult!=my_test_result_mock
    assert MyTestResult==my_test_result_mock


# Generated at 2022-06-23 13:39:41.504450
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    failure1 = TestFailure("")
    failure2 = TestFailure("")
    assert failure1 != failure2


# Generated at 2022-06-23 13:39:47.773228
# Unit test for constructor of class TestCase
def test_TestCase():
    message = "this is an error"
    type = "error"
    test_case = TestCase(name="test_TestCase")
    assert test_case.name == "test_TestCase"
    assert test_case.assertions is None
    assert test_case.classname is None
    assert test_case.status is None
    assert test_case.time is None
    assert not test_case.errors
    assert not test_case.failures
    assert test_case.skipped is None
    assert test_case.system_out is None
    assert test_case.system_err is None
    assert not test_case.is_disabled


# Generated at 2022-06-23 13:39:57.590295
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    time = decimal.Decimal(1.234)
    assertions = 5
    classname = 'class'
    name = 'name'
    status = 'status'

    test_case = TestCase(name=name, assertions=assertions, classname=classname, status=status, time=time)
    attributes = test_case.get_attributes()

    assert len(attributes) == 4
    assert attributes['time'] == str(time)
    assert attributes['assertions'] == str(assertions)
    assert attributes['classname'] == classname
    assert attributes['name'] == name
    assert attributes['status'] == status



# Generated at 2022-06-23 13:39:59.991477
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    v = TestResult()
    assert isinstance(v.__repr__(), str)


# Generated at 2022-06-23 13:40:04.627872
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    ts = TestSuite(name='test_suite')
    ts_dict = ts.get_attributes()
    assert ts_dict['name'] == 'test_suite'
    assert ts_dict['tests'] == '0'
    assert ts_dict['errors'] == '0'
    assert ts_dict['failures'] == '0'
    assert ts_dict['disabled'] == '0'
    assert ts_dict['skipped'] == '0'
    assert ts_dict['time'] == '0'


# Generated at 2022-06-23 13:40:07.226419
# Unit test for constructor of class TestSuites
def test_TestSuites():
    ts = TestSuites()
    assert ts.suites == []


# Generated at 2022-06-23 13:40:08.229118
# Unit test for constructor of class TestSuite
def test_TestSuite():
    x = TestSuite("TestSuite")
    assert x.name == "TestSuite"


# Generated at 2022-06-23 13:40:17.338155
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    suite = TestSuites(name = 'TestSuite1')
    suite.suites.append(TestSuite(name = 'suite_name', package = 'suite_package'))
    suite.suites[0].cases.append(TestCase(name = 'case_name', classname = 'class_name'))
    suite.suites[0].cases[0].errors.append(TestError(message = 'error_message', output = 'error_output'))
    suite.suites[0].cases[0].failures.append(TestFailure(message = 'failure_message', output = 'failure_output'))
    suite.suites[0].system_err = 'system_err_text'
    suite.suites[0].system_out = 'system_out_text'

# Generated at 2022-06-23 13:40:22.764916
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # Arrange
    message = "message"
    type = "type"
    test_result = TestResult(message=message, type=type)
    expected = {'message': message, 'type': type}

    # Act
    actual = test_result.get_attributes()

    # Assert
    assert actual == expected


# Generated at 2022-06-23 13:40:25.411911
# Unit test for constructor of class TestError
def test_TestError():
    a = TestError("error", "A")
    assert a.output == "error"
    assert a.message == "A"


# Generated at 2022-06-23 13:40:35.848133
# Unit test for constructor of class TestCase
def test_TestCase():
    # Test Method with all fields defined
    test_case = TestCase(name = "test_name", assertions = 1, classname = "test_class", status = "test_status", time = decimal.Decimal(2), errors = [], failures = [], skipped = "test_skipped", system_out = "test_output_out", system_err = "test_output_err", is_disabled = False)
    # Test Method with only required field defined
    test_case_required = TestCase(name = "test_name")

# Generated at 2022-06-23 13:40:38.000172
# Unit test for constructor of class TestResult
def test_TestResult():
    with pytest.raises(AttributeError):
        TestResult(tag = 'tag_name')


# Generated at 2022-06-23 13:40:41.266544
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    element = TestSuite('test')
    assert element.__repr__() == 'TestSuite(name=test, properties=[])'


# Generated at 2022-06-23 13:40:44.602254
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_instance = TestFailure()
    assert test_instance.__repr__() == 'TestFailure(output=None, message=None, type=\'failure\')'


# Generated at 2022-06-23 13:40:56.466753
# Unit test for method __eq__ of class TestSuites

# Generated at 2022-06-23 13:41:07.646317
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    test_suites = TestSuites()
    test_suites.name = 'test_suites_name'
    test_suites.disabled = 5
    test_suites.errors = 6
    test_suites.failures = 7
    test_suites.tests = 8
    test_suites.time = 9
    test_suites_attr = test_suites.get_attributes()
    assert test_suites_attr['name'] == 'test_suites_name'
    assert test_suites_attr['disabled'] == '5'
    assert test_suites_attr['errors'] == '6'
    assert test_suites_attr['failures'] == '7'
    assert test_suites_attr['tests'] == '8'
    assert test_suites_attr['time'] == '9'

# Generated at 2022-06-23 13:41:10.127788
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert TestSuites.__repr__ == dataclasses.__repr__



# Generated at 2022-06-23 13:41:19.787967
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    """Test for method __eq__ of class TestSuites"""
    test_suite1 = TestSuite(name="test_suite1", hostname="test_host", id="test_id",
                            package="test_package",
                            timestamp=datetime.datetime.now())
    test_suite_list = [test_suite1]
    test_suites = TestSuites(name="test_suites_name", suites=test_suite_list)

    test_suite2 = TestSuite(name="test_suite1", hostname="test_host", id="test_id",
                            package="test_package",
                            timestamp=datetime.datetime.now())

    test_suite_list2 = [test_suite2]


# Generated at 2022-06-23 13:41:32.652571
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    from pytest import raises
    
    assert TestResult() == TestResult()

    assert TestResult(output=None) == TestResult()
    assert TestResult(output="foo") == TestResult(output="foo")
    assert TestResult(output="foo") != TestResult(output="bar")
    
    assert TestResult(message=None) == TestResult()
    assert TestResult(message="foo") == TestResult(message="foo")
    assert TestResult(message="foo") != TestResult(message="bar")
    
    assert TestResult(type=None) == TestResult()
    assert TestResult(type="foo") == TestResult(type="foo")
    assert TestResult(type="foo") != TestResult(type="bar")
    
    with raises(Exception) as excinfo:
        TestResult() == None

# Generated at 2022-06-23 13:41:33.586405
# Unit test for constructor of class TestSuite
def test_TestSuite():
    assert TestSuite('name')



# Generated at 2022-06-23 13:41:44.903861
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    name = 'UnitTest'
    hostname = 'UnitTest'
    suite_id = 'UnitTest'
    package_name = 'UnitTest'
    timestamp = datetime.datetime.now()
    properties = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    case_name = 'UnitTest'
    classname = 'UnitTest'
    assertions = 10
    status = 'UnitTest'
    time = decimal.Decimal(10.0)
    message = 'UnitTest'
    type = 'UnitTest'
    skipped = 'UnitTest'
    output = 'UnitTest'

    test_suite = TestSuite(name=name, hostname=hostname, id=suite_id, package=package_name, timestamp=timestamp)
    test_su

# Generated at 2022-06-23 13:41:47.452391
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    ts = TestSuite("test", "hostname", "id", "package", datetime.datetime.now())
    ts.get_attributes()

# Generated at 2022-06-23 13:41:54.006573
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    failure1 = TestFailure()
    failure2 = TestFailure()
    failure3 = TestFailure(output='some error')

    assert failure1 == failure1
    assert failure1 == failure2
    assert failure1 != failure3

    assert failure2 == failure1
    assert failure2 == failure2
    assert failure2 != failure3

    assert failure3 != failure1
    assert failure3 != failure2
    assert failure3 == failure3


# Generated at 2022-06-23 13:42:07.275817
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case = TestCase(name='TestCase_get_xml_element', classname='TestCase', time=1.2345)
    test_suite = TestSuite(name='TestSuite_get_xml_element', hostname='localhost', id='12345', package='pack', timestamp=datetime.datetime(2020,5,5,5,5,5), cases=[test_case], system_out='This is a test', system_err='Another test')
    test_suites = TestSuites(name='TestSuites_get_xml_element', suites=[test_suite])
    test_suites_xml_element = test_suites.get_xml_element()

# Generated at 2022-06-23 13:42:11.573618
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    testsuite_name = "my_test_suite"
    testsuite = TestSuite(name=testsuite_name, hostname=None, id="123", package=None, timestamp=None)
    junit_xml = TestSuites(name=None, suites=[testsuite])
    attributes = junit_xml.get_attributes()
    assert(len(attributes) == 5)
    assert(attributes['name'] == None)
    assert(attributes['disabled'] == "0")
    assert(attributes['errors'] == "0")
    assert(attributes['failures'] == "0")
    assert(attributes['tests'] == "0")
    assert(attributes['time'] == "0")


# Generated at 2022-06-23 13:42:23.242417
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-23 13:42:31.174110
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-23 13:42:37.092038
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    print('Testing method get_attributes of class TestSuites')
    suite = TestSuites()
    attributes = {
        "disabled":0,
        "errors":0,
        "failures":0,
        "tests":0,
        "time":0
    }
    assert attributes == suite.get_attributes()

# Generated at 2022-06-23 13:42:45.573503
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    testcase = TestCase(name='testname', assertions=1, classname='classname', status='status', time=decimal.Decimal('1.1'))
    testcase.errors.append(TestError(output='erroroutput', message='errormessage', type='errortype'))
    testcase.failures.append(TestFailure(output='failureoutput', message='failuremessage', type='failuretype'))
    testcase.skipped = 'skipped'
    testcase.system_out = 'systemout'
    testcase.system_err = 'systemerr'
    xml = testcase.get_xml_element()

# Generated at 2022-06-23 13:42:56.326132
# Unit test for constructor of class TestSuite
def test_TestSuite():
    """Test constructor of class TestSuite"""
    test_cases = [TestCase('foo')]
    suite = TestSuite('bar', hostname='localhost', id='1', package='baz', timestamp=datetime.datetime.now(), properties={'test': '1'}, cases=test_cases, system_out='test', system_err='test')
    assert suite.name == 'bar'
    assert suite.hostname == 'localhost'
    assert suite.id == '1'
    assert suite.package == 'baz'
    assert suite.timestamp
    assert suite.properties['test'] == '1'
    assert suite.cases == test_cases
    assert suite.system_out == 'test'
    assert suite.system_err == 'test'


# Generated at 2022-06-23 13:43:02.404670
# Unit test for constructor of class TestError
def test_TestError():
    output = "some output"
    message = "some message"
    type = "some type"

    error = TestError(output=output, message=message, type=type)

    assert(error.output == output)
    assert(error.message == message)
    assert(error.type == type)
    assert(error.tag != "")



# Generated at 2022-06-23 13:43:12.147608
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    null = None
    assert TestFailure(output = "message", message = "value", type = "type") == TestFailure(output = "message", message = "value", type = "type")
    assert TestFailure(output = "message", message = null, type = "type") == TestFailure(output = "message", message = null, type = "type")
    assert TestFailure(output = null, message = "value", type = "type") == TestFailure(output = null, message = "value", type = "type")
    assert TestFailure(output = null, message = null, type = "type") == TestFailure(output = null, message = null, type = "type")
    assert TestFailure(output = "message", message = "value", type = null) == TestFailure(output = "message", message = "value", type = null)
    assert TestFailure

# Generated at 2022-06-23 13:43:14.196263
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    assert TestSuite(name='foo').__repr__() == "TestSuite(name='foo')"


# Generated at 2022-06-23 13:43:18.208448
# Unit test for constructor of class TestSuite
def test_TestSuite():
    test = TestSuite(
        name = "TEST_NAME",
        hostname="TEST_HOSTNAME",
        id="TEST_ID",
        package="TEST_PACKAGE",
        timestamp="TEST_TIMESTAMP"
    )
    print(test)
