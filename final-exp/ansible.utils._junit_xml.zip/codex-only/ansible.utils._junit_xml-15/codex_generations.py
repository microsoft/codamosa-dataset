

# Generated at 2022-06-23 13:33:22.251571
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    suite = TestSuite
    suite.name = 'example'
    suite.timestamp = datetime.datetime.now()
    suite.id = 'id'
    suite.hostname = 'host'
    suite.package = 'pack'
    suite.properties = {'prop_key': 'prop_value'}
    suite.system_out = 'out'
    suite.system_err = 'err'

    test_case = TestCase
    test_case.name = 'test_name'
    test_case.assertions = 1
    test_case.classname = 'test_class'
    test_case.status = 'st'
    test_case.time = datetime.timedelta(seconds=10).total_seconds()
    test_case.errors = [TestError]

# Generated at 2022-06-23 13:33:23.949939
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    assert 'TestSuite(name=' in str(TestSuite(name='name'))

# Generated at 2022-06-23 13:33:26.110991
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    r = repr(TestFailure('message'))
    assert isinstance(r, str)
    assert r == "TestFailure(output=None, message='message', type='failure')"



# Generated at 2022-06-23 13:33:29.283846
# Unit test for constructor of class TestCase
def test_TestCase():
    case_one = TestCase('sample')
    case_two = TestCase('sample', assertions=1, classname='Class', status='FAILED', time=1)
    print(case_one)
    print(case_two)
    print(case_two.__dict__)


# Generated at 2022-06-23 13:33:31.162920
# Unit test for constructor of class TestResult
def test_TestResult():
    assert TestResult(output = "output", message = "message", type = "type") != None


# Generated at 2022-06-23 13:33:34.089849
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    obj = TestSuites("name")
    assert isinstance(obj.get_xml_element(), ET.Element)

# Generated at 2022-06-23 13:33:41.924684
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():

    test_assertions = 2
    test_classname = 'TestClass'
    test_name = 'test_case'
    test_status = 'passed'
    test_time = 0.01

    tc = TestCase(assertions=test_assertions, classname=test_classname, name=test_name, status=test_status, time=test_time)

    assert f'{tc!r}' == f'TestCase(assertions={test_assertions!r}, classname={test_classname!r}, name={test_name!r}, status={test_status!r}, time={test_time!r})'


# Generated at 2022-06-23 13:33:44.892356
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    obj = TestSuites()
    repr_str = repr(obj)
    assert repr_str == 'TestSuites(name=None, suites=[])'


# Generated at 2022-06-23 13:33:48.003254
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    actual = repr(TestFailure())
    assert actual == "TestFailure(output=None, message=None, type=None)"


# Generated at 2022-06-23 13:33:52.840797
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    suite = TestSuite(
        name='WebFlaskTestSuite',
        cases=[
            TestCase(
                name='HomePageTest',
                classname='TestSuite.HomePageTest',
                time=1
            )
        ]
    )
    suites = TestSuites(suites=[suite])
    assert suites.get_xml_element().tag == 'testsuites'



# Generated at 2022-06-23 13:33:54.172680
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes(): 
    TestCase.get_attributes()

# Generated at 2022-06-23 13:33:57.015741
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    obj = TestResult()
    repr_ = repr(obj)
    assert repr_ == 'TestResult(output=None, message=None, type=None)'

# Generated at 2022-06-23 13:34:04.226171
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    assert TestSuites() == TestSuites(name=None)
    assert TestSuites() != TestSuites(name='foo')
    assert TestSuites(name='bar') == TestSuites(name='bar')
    assert TestSuites(suites=[TestSuite(name='bar')]) == TestSuites(suites=[TestSuite(name='bar')])
    assert TestSuites(suites=[TestSuite(name='bar')]) != TestSuites(suites=[TestSuite(name='baz')])


# Generated at 2022-06-23 13:34:14.107805
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    now = datetime.datetime.now()

    testSuite = TestSuite(
        hostname='Foo',
        id='Bar',
        name='TestSuite',
        package='TestPackage',
        timestamp=now,
    )

    testCase = TestCase(
        classname='TestSuite',
        name='TestCase',
        time=datetime.timedelta(seconds=1.0).total_seconds(),
    )

    testSuite.cases.append(testCase)

    attributes = testSuite.get_attributes()

    assert attributes['hostname'] == 'Foo'
    assert attributes['id'] == 'Bar'
    assert attributes['name'] == 'TestSuite'
    assert attributes['package'] == 'TestPackage'

# Generated at 2022-06-23 13:34:18.643983
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    """Function to test TestSuites.get_xml_element."""
    test_suites = TestSuites()
    test_suites_element = test_suites.get_xml_element()
    assert test_suites_element.tag == "testsuites"


# Generated at 2022-06-23 13:34:19.388651
# Unit test for constructor of class TestSuites
def test_TestSuites():
    TestSuites()

# Generated at 2022-06-23 13:34:30.724805
# Unit test for constructor of class TestSuites

# Generated at 2022-06-23 13:34:34.572100
# Unit test for constructor of class TestSuites
def test_TestSuites():
    # test the constructor
    test_suites = TestSuites(name="test_test_suites")
    #test the object attributes
    assert test_suites.name == "test_test_suites"



# Generated at 2022-06-23 13:34:39.695995
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # noinspection PyProtectedMember
    assert "TestResult(" \
           "output='', " \
           "message='', " \
           "type='', " \
           "tag='testresult')" == dataclasses.asdict.__repr__(dataclasses.asdict(TestResult()))


# Generated at 2022-06-23 13:34:45.254211
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    tr = TestResult()
    assert tr.get_attributes() == {}
    tr = TestResult(type='Test', output='test', message='test')
    assert tr.get_attributes() == {'type': 'Test', 'message': 'test'}


# Generated at 2022-06-23 13:34:51.730659
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='test', timestamp=datetime.datetime(1969, 7, 20, 3, 0, 0, tzinfo=datetime.timezone.utc))
    etree = suite.get_xml_element()
    etree_xml = ET.tostring(etree, encoding='unicode')
    expected = """\
<testsuite errors="0" failures="0" tests="0" disabled="0" skipped="0" hostname="None" name="test" time="0.0" timestamp="1969-07-20T03:00:00+00:00" />"""
    assert etree_xml == expected


# Generated at 2022-06-23 13:34:58.055372
# Unit test for constructor of class TestResult
def test_TestResult():
    test_output = 'This is the test output'
    test_message = 'This is the test message'
    test_type = 'fatal'

    test_result = TestResult(output = test_output, message = test_message, type = test_type)
    
    assert test_output == test_result.output
    assert test_message == test_result.message
    assert test_type == test_result.type


# Generated at 2022-06-23 13:35:06.388853
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    # Create instance of class TestCase
    test_case = TestCase(name='test_TestCase___repr__')

    # Check if the object representation is correct
    assert repr(test_case) == "TestCase(name='test_TestCase___repr__', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"


# Generated at 2022-06-23 13:35:09.926233
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    testcase = TestCase("name")
    assert testcase.__repr__() == "<TestCase(name)>"

    testcase = TestCase("name", assertions=1)
    assert testcase.__repr__() == "<TestCase(name, assertions='1')>"



# Generated at 2022-06-23 13:35:13.507155
# Unit test for constructor of class TestFailure
def test_TestFailure():
    t_1 = TestFailure()
    assert t_1.output == None
    assert t_1.message == None
    assert t_1.type == 'failure'


# Generated at 2022-06-23 13:35:14.271454
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    print(TestResult().__repr__())


# Generated at 2022-06-23 13:35:16.003884
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    test_suites = TestSuites()
    assert (test_suites.__repr__() == "TestSuites(name=None, suites=[])")

# Generated at 2022-06-23 13:35:21.125686
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():

    # Create the test case
    test_case = TestCase(
        name="test_name",
        assertions=10,
        classname="test_classname"
    )

    # Use the get_attributes method and verify the returned dictionary
    assert test_case.get_attributes() == {"name": "test_name", "assertions": "10", "classname": "test_classname"}



# Generated at 2022-06-23 13:35:26.516938
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # Setup
    testsuites = TestSuites(
        name=None,
        suites=[],
    )
    # Exercise
    repr_string = repr(testsuites)
    # Verify
    assert repr_string == "TestSuites(name=None, suites=[])"
    # Cleanup - none necessary



# Generated at 2022-06-23 13:35:30.220992
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    TestError1=TestError(output='output', message='message', type='type')
    TestError2=TestError(output='output', message='message', type='type')
    assert(TestError1 == TestError2)


# Generated at 2022-06-23 13:35:36.510746
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    failure1 = TestFailure(message="message1", type="type1", output="output1")
    failure2 = TestFailure(message="message1", type="type1", output="output1")
    failure3 = TestFailure(message="message1", type="type2", output="output1")
    failure4 = TestFailure(message="message2", type="type1", output="output1")
    failure5 = TestFailure(message="message1", type="type1", output="output2")

    assert failure1 == failure2
    assert failure1 != failure3
    assert failure1 != failure4
    assert failure1 != failure5

# Generated at 2022-06-23 13:35:37.744916
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert TestFailure()


# Generated at 2022-06-23 13:35:48.237383
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    hostname: str
    hostname = "any_hostname"
    id: str
    id = "any_id"
    name: str
    name = "any_name"
    package: str
    package = "any_package"
    timestamp: datetime
    timestamp: datetime.datetime
    timestamp = datetime.datetime.now()
    test_suite: dataclasses.TestSuite
    test_suite = TestSuite(
        name,
        hostname,
        id,
        package,
        timestamp
    )

# Generated at 2022-06-23 13:35:57.931584
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    suite = TestSuite(name='testsuite', cases=[TestCase(name='testcase'), TestCase(name='testcase2')])
    element = ET.Element('testsuite', _attributes(
        disabled='0',
        errors='0',
        failures='0',
        hostname='None',
        id='None',
        name='testsuite',
        package='None',
        skipped='0',
        tests='2',
        time='None',
        timestamp='None'
    ))

# Generated at 2022-06-23 13:36:09.919416
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():

    t1 = TestSuite('t1', None, None, None, None)
    assert t1 == t1

    t1.failures = 1
    t1.errors = 2
    t1.disabled = 3
    t1.skipped = 4
    t1.tests = 5

    t2 = TestSuite('t1', None, None, None, None)
    assert t1 != t2

    t2.failures = 1
    assert t1 != t2

    t2.errors = 2
    assert t1 != t2

    t2.disabled = 3
    assert t1 != t2

    t2.skipped = 4
    assert t1 != t2

    t2.tests = 5
    assert t1 == t2


# Generated at 2022-06-23 13:36:15.091218
# Unit test for constructor of class TestSuites
def test_TestSuites():
    name = "test_name"
    test_suites = TestSuites(name)
    assert test_suites is not None
    assert name == test_suites.name
    assert test_suites.suites == []


# Generated at 2022-06-23 13:36:22.792725
# Unit test for constructor of class TestSuite
def test_TestSuite():
    now = datetime.datetime.now()
    ts = TestSuite(name="TestSuite-1", hostname="localhost", id="8", package="package", timestamp=now, system_out="System_out", system_err="System_err")

    assert ts.name == "TestSuite-1"
    assert ts.hostname == "localhost"
    assert ts.id == "8"
    assert ts.package == "package"
    assert ts.timestamp == now
    assert ts.system_out == "System_out"
    assert ts.system_err == "System_err"


# Generated at 2022-06-23 13:36:27.138654
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():

    test_failure = TestFailure(message="message_1", type="type_1", output="output_1")
    test_failure_1 = TestFailure(message="message_1", type="type_1", output="output_1")
    assert test_failure == test_failure_1


# Generated at 2022-06-23 13:36:39.006784
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    test_cases = [
        ('TestFailure()', TestFailure()),
        ('TestFailure(output="output")', TestFailure(output='output')),
        ('TestFailure(message="message")', TestFailure(message='message')),
        ('TestFailure(type="type")', TestFailure(type='type')),
        ('TestFailure(output="output", message="message")', TestFailure(output='output', message='message')),
        ('TestFailure(output="output", type="type")', TestFailure(output='output', type='type')),
        ('TestFailure(message="message", type="type")', TestFailure(message='message', type='type')),
        ('TestFailure(output="output", message="message", type="type")', TestFailure(output='output', message='message', type='type')),
    ]


# Generated at 2022-06-23 13:36:47.329329
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():

    testsuite1 = TestSuite(
                            name='test1',
                            hostname='localhost',
                            id='4',
                            package='testsuite',
                            timestamp=datetime.datetime(2020, 9, 14, 12, 0, 0),)

    testsuite2 = TestSuite(
                            name='test2',
                            hostname='localhost',
                            id='4',
                            package='testsuite',
                            timestamp=datetime.datetime(2020, 9, 14, 12, 0, 0),)


    assert testsuite1 == testsuite2


# Generated at 2022-06-23 13:36:51.748618
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testresult = TestResult()
    testresult.type = 'test_type'
    testresult.message = 'test_message'
    testresult.output = 'test_output'

    testfailure = TestFailure()
    testfailure.type = 'testfailure_type'
    testfailure.message = 'testfailure_message'
    testfailure.output = 'testfailure_output'

    testerror = TestError()
    testerror.type = 'testerror_type'
    testerror.message = 'testerror_message'
    testerror.output = 'testerror_output'

    testcase = TestCase()
    testcase.name = 'test_name'
    testcase.classname = 'test_classname'
    testcase.assertions = 'test_assertions'

# Generated at 2022-06-23 13:37:00.050569
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    message = None
    type = None
    result = TestResult(output=None, message=message, type=type)
    assert result.get_attributes() == {'type': 'testresult'}

    message = "test error"
    type = "test type"
    result = TestResult(output=None, message=message, type=type)
    assert result.get_attributes() == {'message': message, 'type': type}

    message = "test error"
    type = None
    result = TestResult(output=None, message=message, type=type)
    assert result.get_attributes() == {'message': message, 'type': 'testresult'}
    message = None
    type = "test type"
    result = TestResult(output=None, message=message, type=type)

# Generated at 2022-06-23 13:37:10.313667
# Unit test for constructor of class TestFailure
def test_TestFailure():
    assert TestFailure('Test output', 'Test message').output == 'Test output'
    assert TestFailure('Test output', 'Test message').message == 'Test message'
    assert TestFailure('Test output', 'Test message').type == 'failure'
    assert TestFailure(output='Test output', message='Test message').output == 'Test output'
    assert TestFailure(output='Test output', message='Test message').message == 'Test message'
    assert TestFailure(output='Test output', message='Test message').type == 'failure'
    assert TestFailure(type='TEST_TYPE', output='Test output', message='Test message').type == 'TEST_TYPE'


# Generated at 2022-06-23 13:37:19.483700
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    T1 = TestFailure(output = "test1", message = "testMessage", type = "testType")
    T2 = TestFailure(output = "test1", message = "testMessage", type = "testType")
    T3 = TestFailure(output = "test2", message = "testMessage", type = "testType")
    T4 = TestFailure(output = "test1", message = "testMessage1", type = "testType")
    T5 = TestFailure(output = "test1", message = "testMessage", type = "testType1")

    assert(T1 == T2)
    assert(T1 != T3)
    assert(T1 != T4)
    assert(T1 != T5)
    assert(T2 == T1)
    assert(T3 != T1)

# Generated at 2022-06-23 13:37:25.408722
# Unit test for constructor of class TestError
def test_TestError():
    error1 = TestError()
    assert error1 != None
    assert error1.output == None
    assert error1.message == None
    assert error1.type == 'error'
    error2 = TestError(output = 'output', message = 'message')
    assert error2 != None
    assert error2.output == 'output'
    assert error2.message == 'message'
    assert error2.get_attributes() == {'message':'message'}
    assert error2.get_xml_element() != None


# Generated at 2022-06-23 13:37:29.408891
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    assert TestSuites(name = "All tests").__repr__() == '''TestSuites(name = 'All tests', suites = [])'''


# Generated at 2022-06-23 13:37:40.781758
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    '''

    :return:
    '''
    # test data
    c_name = "test_TestCase_accept"
    c_classname = "test_TestCase"
    c_output = "message"
    c_type = "type"
    c_time = decimal.Decimal("0.01")
    c_skip_message = "skipped"
    c_system_out = "system_out"
    c_system_err = "system_err"

    e_name = "test_TestCase_get_xml_element"
    e_classname = "test_TestCase"
    e_output = "message"
    e_type = "type"
    e_time = decimal.Decimal("0.02")
    e_skip_message = "skipped"

# Generated at 2022-06-23 13:37:43.971447
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    expected = {'message' : 'ERR', 'type' : 'error'}
    t_error = TestError('', message='ERR')

    assert(t_error.get_attributes() == expected)


# Generated at 2022-06-23 13:37:51.585691
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    TestSuites1 = TestSuites()
    assert TestSuites1 == TestSuites1
    TestSuites2 = TestSuites()
    assert TestSuites2 == TestSuites2
    TestSuites3 = TestSuites()
    assert TestSuites3 == TestSuites3
    TestSuites4 = TestSuites()
    assert TestSuites4 == TestSuites4
    TestSuites5 = TestSuites()
    assert TestSuites5 == TestSuites5
    TestSuites6 = TestSuites()
    assert TestSuites6 == TestSuites6
    TestSuites7 = TestSuites()
    assert TestSuites7 == TestSuites7
    TestSuites8 = TestSuites()
    assert TestSuites8 == TestSuites8
    TestSuites9 = TestSuites()
    assert TestSu

# Generated at 2022-06-23 13:38:00.762358
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    testSuites = TestSuites("name1", "name2")
    assert testSuites.suites[0].name == "name1"
    assert testSuites.suites[1].name == "name2"
    assert testSuites.name == None
    assert testSuites.suites[0].timestamp is None 
    assert testSuites.suites[1].timestamp is None 
    assert testSuites.suites[0].classes is None 
    assert testSuites.suites[1].classes is None 
    assert testSuites.suites[0].tests is 0
    assert testSuites.suites[1].tests is 0
    assert testSuites.suites[0].disabled is 0
    assert testSuites.suites[1].disabled is 0

# Generated at 2022-06-23 13:38:06.908537
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    class TestTestResult(TestResult):

        def __init__(self, output, message, type, tag):
            self.output = output
            self.message = message
            self.type = type
            self.tag = tag

    test_test_result = TestTestResult(output="test", message="test", type="test", tag="test")
    assert test_test_result.get_attributes() == {"message": "test", "type": "test"}



# Generated at 2022-06-23 13:38:15.788911
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    suites = TestSuites(name='TestSuites')
    suite = TestSuite(name='TestSuite1', hostname='localhost', id='id1', package='com.example', timestamp=datetime.datetime.now())
    suite.properties = {'country': 'india', 'state': 'tamilnadu'}

    case = TestCase(name='TestCase1', classname='TestCase1', time=decimal.Decimal(1.23), assertions=0)
    case.errors.append(TestError(output='In test case 1', message='Message in test case 1', type='TestErrorType'))
    case.failures.append(TestFailure(output='In test case 1', message='Message in test case 1', type='TestFailureType'))
    case.skipped = 'Skipped reason 1'
    case

# Generated at 2022-06-23 13:38:18.918749
# Unit test for constructor of class TestResult
def test_TestResult():
    test_result = TestResult()
    assert test_result.output == None
    assert test_result.message == None
    assert test_result.type == None


# Generated at 2022-06-23 13:38:25.069847
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    testSuite=TestSuite(name="MyTestSuite", timestamp=datetime.datetime.now())
    testSuite.cases.append(TestCase(name="MyTestCase", assertsion=2, time=0.101642))
    testSuite.cases[0].errors.append(TestError(type="MyTestSuite.MyTestCaseException", output="Test Exception"))
    testSuite.cases[0].failures.append(TestFailure(type="MyTestSuite.MyTestCaseException", output="Test Failure"))

    print(_pretty_xml(testSuite.get_xml_element()))


if __name__ == "__main__":
    test_TestSuite_get_xml_element()

# Generated at 2022-06-23 13:38:35.844771
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # If the method __repr__ is implemented correctly, then if the arguments used for creating a TestResult instance
    #  are the same, the result __repr__ should be the same.
    output1 = 'ERROR: [ACS:29:48:0] ERROR: [COMPILER:24:42] invalid assignment'
    output2 = 'ERROR: [ACS:37:48:0] ERROR: [COMPILER:24:42] invalid assignment'
    message1 = 'ERROR: [COMPILER:24:42] invalid assignment'
    message2 = 'ERROR: [COMPILER:24:45] invalid assignment'
    type1 = 'type1'
    type2 = 'type2'
    result1 = TestResult(output1, message1, type1)

# Generated at 2022-06-23 13:38:47.713707
# Unit test for constructor of class TestFailure
def test_TestFailure():
    obj = TestFailure()
    assert isinstance(obj, TestFailure)
    assert isinstance(vars(obj)['output'], type(None))
    assert isinstance(vars(obj)['message'], type(None))
    assert isinstance(vars(obj)['type'], type(None))
    assert isinstance(obj.output, type(None))
    assert isinstance(obj.message, type(None))
    assert isinstance(obj.type, type(None))
    assert obj.output is None
    assert obj.message is None
    assert obj.type == 'failure'
    obj = TestFailure(output = 'This is output')
    assert isinstance(obj, TestFailure)
    assert isinstance(vars(obj)['output'], str)

# Generated at 2022-06-23 13:38:51.647773
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    TestCase.__repr__ = lambda TestCase: "repr-text"
    assert TestCase.__repr__ is not None


# Generated at 2022-06-23 13:39:00.089788
# Unit test for constructor of class TestFailure
def test_TestFailure():
    tc1 = TestFailure()
    assert tc1.output is None
    assert tc1.message is None
    assert tc1.type is None

    tc2 = TestFailure("Some error message")
    assert tc2.output == "Some error message"
    assert tc2.message is None
    assert tc2.type is None

    tc3 = TestFailure("Some error message", type="test-error")
    assert tc3.output == "Some error message"
    assert tc3.message is None
    assert tc3.type == "test-error"

    tc4 = TestFailure("Some error message", message="Some message")
    assert tc4.output == "Some error message"
    assert tc4.message == "Some message"
    assert tc4.type is None


# Generated at 2022-06-23 13:39:05.706867
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    test = TestSuites()
    test.name = 'testSuite'
    test.suites.append(TestSuite('firstTestSuite'))
    test.suites.append(TestSuite('secondTestSuite'))
    test.suites[0].cases.append(TestCase('firstTestCase'))
    test.suites[0].cases.append(TestCase('secondTestCase'))
    test.suites[1].cases.append(TestCase('thirdTestCase'))
    test.suites[1].cases.append(TestCase('fourthTestCase'))
    test.suites[1].cases[0].failures.append(TestFailure('failure'))
    test.suites[1].cases[1].failures.append(TestFailure('failure'))

# Generated at 2022-06-23 13:39:18.738194
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    from dataclasses import dataclass
    from xml.etree import ElementTree as ET
    # noinspection PyPep8Naming
    from xml.dom import minidom
    # noinspection PyPep8Naming

    @dataclass
    class Result(TestResult):
        tag: str
        message: t.Optional[str] = None

    element = Result('error', 'This is an error').get_xml_element()
    assert element.tag == 'error'
    assert element.text == 'This is an error'
    assert minidom.parseString(ET.tostring(element, encoding='unicode')).toprettyxml() == '''\
<?xml version="1.0" ?>
<error message="This is an error">This is an error</error>
'''



# Generated at 2022-06-23 13:39:22.373842
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite = TestSuite(name = 'Ganesh')
    attrib = suite.get_attributes()
    assert attrib['name'] == 'Ganesh'


# Generated at 2022-06-23 13:39:23.723678
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError() == TestError()


# Generated at 2022-06-23 13:39:27.343714
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    a = TestCase(name="test_case_name_foo")
    b = TestCase(name="test_case_name_foo")
    assert(a == b)

    b = TestCase(name="test_case_name_bar")
    assert(a != b)


# Generated at 2022-06-23 13:39:31.336219
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    valid_message = 'Message'
    valid_type = 'ErrorType'

    result = TestResult(message=valid_message, type=valid_type)
    attributes = result.get_attributes()
    assert attributes['message'] == valid_message
    assert attributes['type'] == valid_type


# Generated at 2022-06-23 13:39:34.326323
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # Given
    a = []
    # When
    su = TestSuites(a)
    # Then
    assert isinstance(su, TestSuites)
    assert isinstance(su.suites, list)

# Generated at 2022-06-23 13:39:36.328069
# Unit test for constructor of class TestSuites
def test_TestSuites():
    test = TestSuites()
    assert type(test) == TestSuites


# Generated at 2022-06-23 13:39:45.626816
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    assert TestError() == TestError()
    assert TestError(output='a') == TestError(output='a')
    assert TestError(message='a') == TestError(message='a')
    assert TestError(type='a') == TestError(type='a')
    assert TestError(output='a', message='a') == TestError(output='a', message='a')
    assert TestError(output='a', type='a') == TestError(output='a', type='a')
    assert TestError(message='a', type='a') == TestError(message='a', type='a')
    assert TestError(output='a', message='a', type='a') == TestError(output='a', message='a', type='a')
    assert TestError() != TestError(output='a')

# Generated at 2022-06-23 13:39:49.913380
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    failure1 = TestFailure(output="error",message="error",type="error")
    failure2 = TestFailure(output="error",message="error",type="error")
    assert failure1 == failure2


# Generated at 2022-06-23 13:39:53.189538
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    result = TestResult()
    assert '<TestResult />' == ET.tostring(result.get_xml_element(), encoding='unicode')



# Generated at 2022-06-23 13:39:57.236907
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    assert repr(TestResult(output='output', message='message', type='type')) == "TestResult(output='output', message='message', type='type')"
    assert repr(TestResult(output='output')) == "TestResult(output='output')"



# Generated at 2022-06-23 13:40:01.522214
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    a = TestResult(output="Test", message="error", type="error")
    b = TestResult(output="Test", message="error", type="error")
    assert a == b


# Generated at 2022-06-23 13:40:05.152472
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    # set up object
    test_result = TestResult(output = 'hello', message = 'world', type = 'xyz')
    assert test_result.get_attributes() == {'message': 'world', 'type': 'xyz'}


# Generated at 2022-06-23 13:40:10.026861
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    first = TestResult("output", "message", "type")
    second = TestResult("output", "message", "type")
    assert first == second
    assert not first != second


# Generated at 2022-06-23 13:40:14.362267
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    assert TestCase(name="My Test Case") == TestCase(name="My Test Case", classname="Tests")
    assert not TestCase(name="My Test Case") == TestCase(name="My Test Case", classname="Other Tests")
    assert not TestCase(name="My Test Case") == TestCase(name="Other Test Case", classname="Tests")


# Generated at 2022-06-23 13:40:18.786352
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    name = 'name'
    tc = TestCase(name)
    assert repr(tc) == f'TestCase(name={name!r}, assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'


# Generated at 2022-06-23 13:40:20.930189
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    one = TestFailure()
    two = TestFailure()

    assert one == two


# Generated at 2022-06-23 13:40:32.277801
# Unit test for constructor of class TestSuite
def test_TestSuite():
    name = "name"
    hostname = "hostname"
    id = "id"
    package = "package"
    timestamp = datetime.datetime.now()
    properties = {"one": "one", "two": "two"}
    cases = [TestCase("One")]
    system_out = "system_out"
    system_err = "system_err"

    test_suite = TestSuite(name, hostname, id, package, timestamp, properties, cases, system_out, system_err)

    assert test_suite.name == name
    assert test_suite.hostname == hostname
    assert test_suite.id == id
    assert test_suite.package == package
    assert test_suite.timestamp == timestamp
    assert test_suite.properties == properties
    assert test_su

# Generated at 2022-06-23 13:40:33.323914
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    TestResult_object = TestResult()



# Generated at 2022-06-23 13:40:42.202868
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    ts = TestSuites()
    ts.name = 'Tests'

    ts1 = TestSuite()
    ts1.name = 'Unit tests'
    ts1.hostname = 'hostname'
    ts1.id = '1'
    ts1.package = 'com.example'
    ts1.timestamp = '2018-07-07T08:38:29.000'
    ts1.properties.update({
        'key1': 'value1',
        'key2': 'value2',
    })
    ts1.system_out = 'stdout'
    ts1.system_err = 'stderr'

    tc1 = TestCase()
    tc1.name = 'test_Unit_1'
    tc1.assertions = '1'
    tc1.classname = 'UnitTest'


# Generated at 2022-06-23 13:40:55.142406
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
   suite = TestSuite("TestSuite", "hostname", "id", "package", datetime.now(), properties={"key": "val"},
                     system_out="system_out", system_err="system_err")
   suite.cases = [TestCase("TestCase", 1, "classname", "status", 2, [TestError("error")],
                           [TestFailure("failure")], "skipped", "system_out", "system_err")]

# Generated at 2022-06-23 13:41:07.006866
# Unit test for constructor of class TestSuites

# Generated at 2022-06-23 13:41:17.270536
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case1 = TestCase('name')
    test_case2 = TestCase('name')
    test_case3 = TestCase('name1')
    test_case4 = TestCase('name', assertions=0)
    test_case5 = TestCase('name', assertions=10)
    test_case6 = TestCase('name', classname='classname')
    test_case7 = TestCase('name', classname='classname1')
    test_case8 = TestCase('name', status='status')
    test_case9 = TestCase('name', status='status1')
    test_case10 = TestCase('name', time=decimal.Decimal('0'))
    test_case11 = TestCase('name', time=decimal.Decimal('1'))

# Generated at 2022-06-23 13:41:25.657588
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    classname = 'TestSuite'
    name = 'get_attributes'
    ts = TestSuite(name = 'foo', classname = classname,
                    tests = 2, failures = 1, errors = 1,
                    skipped = 0, disabled = 0,
                    hostname = 'localhost', timestamp = datetime.datetime.now())
    assert(ts.get_attributes().get('classname') == classname)
    assert(ts.get_attributes().get('name') == name)
    assert(ts.get_attributes().get('tests') == '2')
    assert(ts.get_attributes().get('failures') == '1')
    assert(ts.get_attributes().get('errors') == '1')
    assert(ts.get_attributes().get('skipped') == '0')

# Generated at 2022-06-23 13:41:28.563865
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    x = TestError()
    assert str(x) == 'TestError(output=None, message=None, type=None)'


# Generated at 2022-06-23 13:41:31.009240
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    t = TestSuites()

    assert t.get_attributes() == {'disabled': '0', 'errors': '0', 'failures': '0', 'name': None, 'tests': '0', 'time': '0'}

# Generated at 2022-06-23 13:41:32.188043
# Unit test for constructor of class TestError
def test_TestError():
    try:
        x=ET.Element('testcase')
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-23 13:41:39.169168
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    error1 = TestError(message='message', output='output', type='type')
    error2 = TestError(message='message', output='output', type='type')
    error3 = TestError(message='message1', output='output', type='type')
    error4 = TestError(message='message', output='output1', type='type')
    assert error1 == error2
    assert error1 != error3
    assert error1 != error4


# Generated at 2022-06-23 13:41:44.970805
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # TestSuites()
    e = TestSuites()
    assert repr(e) == "TestSuites(name=None, suites=[])"
    # TestSuites(name='some_name')
    e = TestSuites(name='some_name')
    assert repr(e) == "TestSuites(name='some_name', suites=[])"
    # TestSuites(name=None, suites=[TestSuite(name='some_name')])
    # TODO: Fix dataclasses import.
    # e = TestSuites(name=None, suites=[TestSuite(name='some_name')])
    # assert repr(e) == "TestSuites(name=None, suites=[TestSuite(name='some_name', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[

# Generated at 2022-06-23 13:41:50.527232
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    e = TestResult
    assert repr(e)  == '<class \'__main__.TestResult\'>', f'Got {repr(e)}, expecting <class \'__main__.TestResult\'>'
    assert type(e) == type, f'Got {type(e)}, expecting <class \'Type\'>'


# Generated at 2022-06-23 13:41:52.419111
# Unit test for constructor of class TestError
def test_TestError():
    test_error = TestError()
    assert test_error.tag == "error"


# Generated at 2022-06-23 13:41:54.986740
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    """Unit test for method __post_init__ of class TestResult."""
    res = TestResult()

    assert res.type == 'TestResult.__post_init__'

# Generated at 2022-06-23 13:42:01.977907
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    error1 = TestError(output='This is the error output')
    error2 = TestError(output='This is an another error output')
    failure1 = TestFailure(output='This is the failure output')
    failure2 = TestFailure(output='This is a another failure output')

    test_case_1 = TestCase(
        name='TestCase1',
        time=1.2,

        errors=[error1, error2],
        failures=[failure1],
        skipped='This is a skipped test case',
        system_out='This is the system out',
        system_err='This is the system err',
    )

# Generated at 2022-06-23 13:42:06.100087
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():    
    tf1 = TestFailure(message="error message", output="ouput",type="type")
    tf2 = TestFailure(message="error message", output="ouput",type="type")
    assert tf1 == tf2

# Generated at 2022-06-23 13:42:06.683172
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    assert True


# Generated at 2022-06-23 13:42:11.192737
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    testcase = TestCase("test1")
    attrib = testcase.get_attributes()

    assert attrib == {}

    testcase.assertions = "1"
    attrib = testcase.get_attributes()
    assert attrib == {"assertions": "1"}



# Generated at 2022-06-23 13:42:15.201748
# Unit test for constructor of class TestFailure
def test_TestFailure():
    failure = TestFailure(type='failure', output='output', message='message')
    assert(failure.type == 'failure')
    assert(failure.output == 'output')
    assert(failure.message == 'message')


# Generated at 2022-06-23 13:42:20.300494
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    assert TestError().get_attributes() == {'type': 'error'}
    assert TestError(type='foo').get_attributes() == {'type': 'foo'}
    assert TestError(message='bar').get_attributes() == {'type': 'error', 'message': 'bar'}



# Generated at 2022-06-23 13:42:23.242944
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    test = TestError()
    assert test == TestError()
    # Changing the value of TestError
    test.message = 'Value'
    assert test != TestError()


# Generated at 2022-06-23 13:42:25.478340
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    """Unit test for method get_attributes of class TestSuites."""
    assert _attributes(disabled=2, errors=3, failures=2) == {'disabled': '2', 'errors': '3', 'failures': '2'}


# Generated at 2022-06-23 13:42:32.344830
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    # TestError(output=None, message=None, type=None)
    test_error_1 = TestError()

    # TestError(output=None, message=None, type=None)
    test_error_2 = TestError()

    # TestError(output=None, message=None, type=None)
    test_error_3 = TestError()

    assert test_error_1 == test_error_2
    assert test_error_2 == test_error_3
    assert test_error_1 == test_error_3


# Generated at 2022-06-23 13:42:33.600967
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    assert TestFailure() == TestFailure()



# Generated at 2022-06-23 13:42:35.488338
# Unit test for constructor of class TestFailure
def test_TestFailure():
    tf = TestFailure()
    assert tf.output == None


# Generated at 2022-06-23 13:42:38.880575
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    a = TestSuites()
    assert a.to_pretty_xml() == '<testsuites disabled="0" errors="0" failures="0" tests="0" time="0"/>'


# Generated at 2022-06-23 13:42:44.117493
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    # Arrange
    test_suite = TestSuite(
        name="name",
        cases=[TestCase(name="name")]
    )

    # Act
    attributes = test_suite.get_attributes()

    # Assert
    assert len(attributes) == 2
    assert 'name' in attributes
    assert attributes['name'] == test_suite.name
    assert 'tests' in attributes
    assert attributes['tests'] == str(test_suite.tests)

# Generated at 2022-06-23 13:42:48.239682
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    test_case_1 = TestCase(name = "test_name_1")
    test_case_2 = TestCase(name = "test_name_2")
    test_failure_1 = TestFailure(output = "test_output_1")
    test_failure_2 = TestFailure(output = "test_output_2")
    test_failure_3 = TestFailure()
    test_failure_4 = TestFailure()
    assert test_failure_1 != test_failure_2
    assert test_failure_3 != test_failure_4


# Generated at 2022-06-23 13:42:58.376578
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    assert repr(TestError()) == '<TestError output=None message=None type=error>'
    assert repr(TestError(output="Some text: hello world")) == '<TestError output=\'Some text: hello world\' message=None type=error>'
    assert repr(TestError(output="Some text: hello world", message="This test is a disaster")) == '<TestError output=\'Some text: hello world\' message=\'This test is a disaster\' type=error>'
    assert repr(TestError(output="Some text: hello world", message="This test is a disaster", type="custom")) == '<TestError output=\'Some text: hello world\' message=\'This test is a disaster\' type=\'custom\'>'


# Generated at 2022-06-23 13:43:09.408602
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_obj1 = TestCase(name = "TestCaseName", assertions = 1, classname = "TestClassName", status = "passed", time = 2.0)
    test_obj2 = TestCase(name = "TestCaseName", assertions = 1, classname = "TestClassName", status = "passed", time = 2.0)
    test_obj3 = TestCase(name = "TestCaseName", assertions = 1, classname = "TestClassName", status = "passed", time = 2.0)

    # Test if two objects are equal
    assert test_obj1 == test_obj2

    # Test if three objects are equal
    assert test_obj1 == test_obj2 and test_obj2 == test_obj3 and test_obj1 == test_obj3

    # Test if two objects are not equal by changing one property


# Generated at 2022-06-23 13:43:14.403261
# Unit test for constructor of class TestResult
def test_TestResult():
    test_result = TestResult(
        output='Output text',
        message='Testing 123',
        type='Encountered an error',
    )

    assert test_result.tag == 'result'
    assert test_result.output == 'Output text'
    assert test_result.message == 'Testing 123'
    assert test_result.type == 'Encountered an error'
    assert test_result.get_attributes() == {
        'message': 'Testing 123',
        'type': 'Encountered an error',
    }
