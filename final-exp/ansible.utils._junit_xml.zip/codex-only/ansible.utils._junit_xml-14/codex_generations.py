

# Generated at 2022-06-23 13:33:16.860655
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    t_result = TestResult(type='TestType')
    t_result.get_attributes()
    assert t_result.get_attributes() == {'type': 'TestType'}


# Generated at 2022-06-23 13:33:19.144223
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    assert TestResult().get_xml_element() == ET.Element('result')


# Generated at 2022-06-23 13:33:27.046997
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_1 = TestCase("name","classname",None,None,None,None,None,None)
    test_case_2 = TestCase("name","classname",None,None,None,None,None,None)
    assert (test_case_1 == test_case_2) == True
    test_case_2 = TestCase("name1","classname",None,None,None,None,None,None)
    assert (test_case_1 == test_case_2) == False
    test_case_2 = TestCase("name","classname1",None,None,None,None,None,None)
    assert (test_case_1 == test_case_2) == False
    test_case_2 = TestCase("name","classname",1,None,None,None,None,None)

# Generated at 2022-06-23 13:33:31.999989
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    """Test class TestSuites method get_attributes."""
    new_suite = TestSuite(name='TestSuite')
    new_suite.cases = [TestCase(classname='test_classes', name='test_case')]

    expected = {'tests': '1', 'name': 'TestSuite', 'time': '0', 'failures': '0', 'errors': '0', 'disabled': '0'}
    assert expected == new_suite.get_attributes()



# Generated at 2022-06-23 13:33:34.972890
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    """Test for the __post_init__ method of class TestResult"""
    # Test if type is set correctly in __post_init__
    f = TestFailure()
    assert f.type == 'failure'
    e = TestError()
    assert e.type == 'error'


# Generated at 2022-06-23 13:33:36.859073
# Unit test for constructor of class TestCase
def test_TestCase():
    case = TestCase(name="test_name")
    print(case)


# Generated at 2022-06-23 13:33:41.531237
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    # Initialize a new testsuite
    testsuite = TestSuites()
    # Create a dictionary that should be returned
    expected = {'disabled': '0', 'errors': '0', 'failures': '0', 'tests': '0', 'time': '0'}
    # Assert that the original method returns the expected result
    assert testsuite.get_attributes() == expected

# Generated at 2022-06-23 13:33:44.575578
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    s = TestSuites()
    assert s.get_attributes().keys() == {'disabled', 'errors', 'failures', 'tests', 'time'}


# Generated at 2022-06-23 13:33:47.681261
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    c = TestCase(name='__repr__')
    assert repr(c) == '<TestCase: name=__repr__>'

# Generated at 2022-06-23 13:33:50.578532
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    obj = TestFailure(output="The result of the test")
    assert (obj == TestFailure(output="The result of the test"))
    assert not (obj == TestFailure(output="A different result"))


# Generated at 2022-06-23 13:33:51.825625
# Unit test for constructor of class TestResult
def test_TestResult():
    test = TestResult()
    print(test.__dict__)


# Generated at 2022-06-23 13:34:00.007613
# Unit test for constructor of class TestSuites
def test_TestSuites():
    my_test = TestSuites()
    assert my_test.name is None
    assert my_test.suites == []
    assert my_test.disabled == 0
    assert my_test.errors == 0
    assert my_test.failures == 0
    assert my_test.tests == 0
    assert my_test.time == 0
    assert my_test.get_attributes() == {}
    assert my_test.get_xml_element().tag == 'testsuites'
    assert my_test.to_pretty_xml() == '<testsuites/>\n'


# Generated at 2022-06-23 13:34:07.195566
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    actual = TestSuites(
        suites=[TestSuite(
            name='TestSuite1',
            cases=[TestCase(
                name='TestCase1'
            )]
        )]
    ).get_xml_element()

    expected = '''<testsuites>
        <testsuite name="TestSuite1">
            <testcase name="TestCase1"/>
        </testsuite>
    </testsuites>'''

    assert ET.tostring(actual, encoding='unicode', short_empty_elements=True) == expected


# Generated at 2022-06-23 13:34:10.429359
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    test_case = TestCase(name='test_case', assertions=1)
    assert test_case.get_attributes() == {'name': 'test_case', 'assertions': '1'}

# Generated at 2022-06-23 13:34:15.925897
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name = "test_test", assertions = "1", classname = "TestCase", status = "status", time = "1.000", 
    errors = "error", failures = "failure", skipped = "skipped", system_out = "sys_out", system_err = "sys_err")
    assert test_case.get_xml_element().attrib == {'assertions': '1', 'classname': 'TestCase', 'name': 'test_test', 
    'status': 'status', 'time': '1.000'}


# Generated at 2022-06-23 13:34:18.466870
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    # Create an instance of TestResult.
    test_result = TestResult()

    # Verify the __repr__ return value.
    assert test_result.__repr__() == "<TestResult object>"


# Unit tests for method get_attributes of class TestResult.

# Generated at 2022-06-23 13:34:24.518655
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    test_input = {
        'output': 'output',
        'message': 'message',
        'type': 'type'
    }
    expected_output = \
        "TestResult" + \
        "(output='output'," + \
        " message='message'," + \
        " type='type')"
    actual_output = TestError(**test_input).__repr__()
    assert expected_output == actual_output


# Generated at 2022-06-23 13:34:27.117309
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    error1 = TestError(message="message", output="", type="type")
    error2 = TestError(message="message", output="", type="type")

    assert error1 == error2

# Generated at 2022-06-23 13:34:29.804840
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    x = TestFailure()
    assert repr(x) == 'TestFailure(output=None, message=None, type=None)'

# Generated at 2022-06-23 13:34:31.902140
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    class_ = TestResult()
    type = class_.type
    assert type == class_.tag



# Generated at 2022-06-23 13:34:42.143280
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    testSuites = TestSuites()
    testSuites.suites.append(TestSuite("Name 1"))
    testSuites.suites[0].cases.append(TestCase("Name 1.1"))
    testSuites.suites[0].cases[0].failures.append(TestFailure("Output 1", "Message 1", "Type 1"))
    testSuites.suites[0].cases[0].errors.append(TestError("Output 2", "Message 2", "Type 2"))
    testSuites.suites[0].cases.append(TestCase("Name 1.2"))
    testSuites.suites[0].cases[1].failures.append(TestFailure("Output 3", "Message 3", "Type 3"))

# Generated at 2022-06-23 13:34:51.279797
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    """Unit test for method __eq__ of class TestCase"""
    # Assert
    assert TestCase(name='1') == TestCase(name='1')
    assert TestCase(name='1') != TestCase(name='2')
    assert TestCase(name='1', assertions=2) == TestCase(name='1', assertions=2)
    assert TestCase(name='1', assertions=2) != TestCase(name='1', assertions=3)
    assert TestCase(name='1', classname='2') == TestCase(name='1', classname='2')
    assert TestCase(name='1', classname='2') != TestCase(name='1', classname='3')
    assert TestCase(name='1', status='2') == TestCase(name='1', status='2')

# Generated at 2022-06-23 13:34:55.100985
# Unit test for constructor of class TestError
def test_TestError():
    error = TestError()
    assert error.type == 'error'
    assert error.get_attributes() == {}
    assert error.get_xml_element().tag == 'error'

# Generated at 2022-06-23 13:34:56.996060
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    try:
        assert True
    except AssertionError:
        raise AssertionError()

# Generated at 2022-06-23 13:35:01.960641
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    # Create test data
    error1 = TestError()
    error2 = TestError()
    # Compare instance variables of instances
    assert error1.__eq__(error2)


# Generated at 2022-06-23 13:35:12.172332
# Unit test for constructor of class TestFailure
def test_TestFailure():
    # Inputs
    tagList = ["failure", "error"]
    numAttributes = 3
    attributesList = [["output", "message", "type"], ["output", "message", "type"]]
    attrNameList = ["output", "message", "type"]
    attrValList = ["output", "message", "type"]
    numAttributesFail = -1
    attributesFailList = [["output", "message"], ["output", "message"]]
    attrNameFailList = ["output", "message"]
    attrValFailList = ["output", "message"]

    # Loop through each tag, create a class instance and check that all attributes are set correctly
    tagIndex = 0
    while tagIndex < len(tagList):
        if tagList[tagIndex] == "failure":
            obj = TestFailure()
            assert obj.tag

# Generated at 2022-06-23 13:35:21.352360
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    """Unit test for method get_attributes of class TestCase"""
    tc = TestCase(name="TestName", assertions=1, classname="TestClass", status="Completed", time="0.0123")
    tc.output = "test_output"
    tc.message = "test_message"
    tc.type = "test_type"
    tc.is_disabled = True
    tc.errors = [TestError()]
    tc.failures = [TestFailure()]
    tc.skipped = "test_skipped"
    tc.system_out = "test_system_out"
    tc.system_err = "test_system_err"
    # Check all attributes of the object get_attributes returns
    assert len(tc.get_attributes()) == 16, "Failed to get all attributes"



# Generated at 2022-06-23 13:35:25.068144
# Unit test for constructor of class TestFailure
def test_TestFailure():
    test = TestFailure(output='output', message='message', type='type')
    assert test.output == 'output'
    assert test.message == 'message'
    assert test.type == 'type'


# Generated at 2022-06-23 13:35:29.869138
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    error1 = TestError(message="something_bad", output="0", type="example")
    error2 = TestError(message="something_bad", output="0", type="example")
    error3 = TestError(message="something_bad", output="0", type="example")
    assert error1 == error2
    assert error1 != error3


# Generated at 2022-06-23 13:35:33.472229
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    # Initialize some test data
    a = TestSuite('a')
    b = TestSuite('b')
    c = TestSuite('a')

    # Test the method
    assert a == c and a != b

test_TestSuite___eq__()

# Generated at 2022-06-23 13:35:37.847310
# Unit test for constructor of class TestSuite
def test_TestSuite():
    TestSuite(name="test", hostname="localhost", id="1", package="com.foo.bar", timestamp=datetime.datetime.now(), cases=[], system_out="test output", system_err="test error")


# Generated at 2022-06-23 13:35:39.709267
# Unit test for constructor of class TestFailure
def test_TestFailure():
    tf = TestResult("error")
    assert tf is not None


# Generated at 2022-06-23 13:35:49.234393
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    test_suites = TestSuites(name='test-results', suites=[TestSuite(name='test-suite', cases=[TestCase(name='test-case')])])

# Generated at 2022-06-23 13:35:51.585004
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
    TestError(
        message='Test error message.',
        output='Test error output.',
        type='Test error type.')


# Generated at 2022-06-23 13:36:00.069594
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test1 = TestCase('test1')
    test2 = TestCase('test2')
    assert not test1.__eq__(test2)

    test1 = TestCase('test1')
    test2 = TestCase('test1')
    assert test1.__eq__(test2)

    test1 = TestCase('test1', 1)
    test2 = TestCase('test1')
    assert not test1.__eq__(test2)

    test1 = TestCase('test1', 1)
    test2 = TestCase('test1', 1)
    assert test1.__eq__(test2)

    test1 = TestCase('test1', 'test_class')
    test2 = TestCase('test1')
    assert not test1.__eq__(test2)


# Generated at 2022-06-23 13:36:02.154601
# Unit test for constructor of class TestSuite
def test_TestSuite():
    assert TestSuite(name='example')


# Generated at 2022-06-23 13:36:12.314967
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    test_suite1 = TestSuite(
        name="Test Suites 1",
        hostname="localhost",
        id="1",
        package="Test package",
        timestamp=datetime.datetime(2008, 8, 8, 8, 8, 8),
    )
    test_suite2 = TestSuite(
        name="Test Suites 2",
        hostname="localhost",
        id="1",
        package="Test package",
        timestamp=datetime.datetime(2008, 8, 8, 8, 8, 8),
    )
    test_suites = TestSuites(
        name="Test Suites",
        suites=[test_suite1, test_suite2],
    )
    assert test_suites == test_suites
    assert not (test_suites != test_suites)


# Generated at 2022-06-23 13:36:15.766270
# Unit test for constructor of class TestError
def test_TestError():
    test_error = TestError()
    assert test_error.output is None
    assert test_error.message is None
    assert test_error.type is None



# Generated at 2022-06-23 13:36:18.699321
# Unit test for constructor of class TestSuite
def test_TestSuite():
    input_value = 'UnitTest1'
    testsuite = TestSuite(name=input_value)
    assert testsuite.name == input_value


# Generated at 2022-06-23 13:36:26.400153
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    r = TestError()
    assert r.get_attributes() == {'type': r.tag}
    r = TestFailure()
    assert r.get_attributes() == {'type': r.tag}

    r = TestError(type='', message='', output='')
    assert r.get_attributes() == {'type': r.tag}
    r = TestFailure(type='', message='', output='')
    assert r.get_attributes() == {'type': r.tag}

    r = TestError(type=None, message=None, output=None)
    assert r.get_attributes() == {'type': r.tag}
    r = TestFailure(type=None, message=None, output=None)
    assert r.get_attributes() == {'type': r.tag}

# Generated at 2022-06-23 13:36:29.794186
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    result = TestFailure()
    assert result.type == 'failure'
    assert result.output is None
    assert result.message is None



# Generated at 2022-06-23 13:36:37.435301
# Unit test for method __repr__ of class TestSuites

# Generated at 2022-06-23 13:36:39.858895
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    e = TestError(type='Type', message='Message', output='Output')
    e2 = TestError(type='Type', message='Message', output='Output')
    assert (e==e2)



# Generated at 2022-06-23 13:36:42.548693
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    # Implement unit test here
    raise NotImplementedError("Test not implemented")


# Generated at 2022-06-23 13:36:45.016974
# Unit test for constructor of class TestSuites
def test_TestSuites():
    suites = TestSuites()
    assert isinstance(suites, TestSuites)
    print(suites)


# Generated at 2022-06-23 13:36:46.875698
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    test_result = TestFailure()

    assert test_result.type == test_result.tag


# Generated at 2022-06-23 13:36:49.115236
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    error = TestError("error")
    error2 = TestError("error")
    assert error == error2


# Generated at 2022-06-23 13:36:56.974747
# Unit test for constructor of class TestFailure
def test_TestFailure():
    # Next block of code is for testing constructor of class TestFailure
    test_failure = TestFailure()
    test_failure_1 = TestFailure(output="Test output", message="Test message", type="Test type")
    assert test_failure_1.output == "Test output"
    assert test_failure_1.message == "Test message"
    assert test_failure_1.type == "Test type"
    assert test_failure_1.tag == 'failure'


# Generated at 2022-06-23 13:37:02.510240
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    from testplan.testing.multitest.driver.junit import TestFailure

    obj = TestFailure(output='Test output')
    assert obj.__repr__() == '<TestFailure: Test output>'
    obj.output = None
    assert obj.__repr__() == '<TestFailure: None>'
    obj.output = 'Test output'
    obj.message = 'Test message'
    assert obj.__repr__() == '<TestFailure: Test message>'
    obj.message = None
    assert obj.__repr__() == '<TestFailure: Test output>'



# Generated at 2022-06-23 13:37:05.178136
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    testsuites = TestSuites(name="testsuites", suites=[])
    print(testsuites.to_pretty_xml())

# Generated at 2022-06-23 13:37:14.484051
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case_1 = TestCase('test_name_1')
    test_case_1.assertions = '10'
    test_case_1.time = '0.123'
    test_case_1.system_err = 'Hello world'
    test_case_1.system_out = 'Hello world'
    test_case_2 = TestCase('test_name_1')
    test_case_2.assertions = '10'
    test_case_2.time = '0.123'
    test_case_2.system_err = 'Hello world'
    test_case_2.system_out = 'Hello world'
    assert (test_case_1 == test_case_2)



# Generated at 2022-06-23 13:37:21.014913
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    # Constructor TestResult(output=None, message=None, type=None) calls __post_init__
    # Nested method tag of class TestResult is abstract
    # Initialize variables for the test
    output = 'output'
    message = 'message'
    type = 'type'
    # Call method __post_init__ of class TestResult
    obj = TestResult(output=output, message=message, type=type)
    # Check attribute type of class TestResult
    assert obj.type == 'error'



# Generated at 2022-06-23 13:37:23.740715
# Unit test for method get_attributes of class TestResult
def test_TestResult_get_attributes():
    testResult = TestResult("This is the output", "This is the message")
    assert(testResult.get_attributes() == {"message": "This is the message", "type": "TestResult"})



# Generated at 2022-06-23 13:37:27.484857
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    obj = TestSuites()
    expected = 'TestSuites(name=None, suites=[])'
    assert obj.__repr__() == expected


# Generated at 2022-06-23 13:37:36.129390
# Unit test for method get_xml_element of class TestSuite
def test_TestSuite_get_xml_element():
    test_case1 = TestCase(name='test_case1', classname='TestClass')
    test_case1_xml = """<testcase name="test_case1" classname="TestClass"/>"""

    test_case2 = TestCase(name='test_case2', classname='TestClass', assertions=1, status='Passed', time=1.1)
    test_case2_xml = """<testcase name="test_case2" classname="TestClass" assertions="1" status="Passed" time="1.1"/>"""

    test_case3 = TestCase(name='test_case3', classname='TestClass', assertions=1, status='Passed', time=1.1)
    test_case3.failures.append(TestFailure(output='failure', message='nope'))
    test_case3

# Generated at 2022-06-23 13:37:44.770461
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    """TestCase.__eq__()"""
    result = True

# Generated at 2022-06-23 13:37:48.586368
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase("test_case")
    assert str(test_case.get_xml_element()) == '<testcase name="test_case"/>'


# Generated at 2022-06-23 13:37:53.878355
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    expected_result = "TestSuites(name=None, hostname=None, id=None, package=None, timestamp=None, properties={}, cases=0)"
    actual_result = TestSuites.__repr__()
    assert actual_result == expected_result

# Generated at 2022-06-23 13:37:58.371383
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    testcase = TestCase('some-name')
    # Test the method __repr__ of class TestCase
    assert testcase.__repr__() == "TestCase(name='some-name', assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)"


# Generated at 2022-06-23 13:38:02.399052
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    instance = TestResult(output='asdf', message='something', type='failure')
    assert repr(instance) == 'TestResult(output="asdf", message="something", type="failure")'


# Generated at 2022-06-23 13:38:07.293861
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name = "test_name")
    test_root = ET.Element(test_case.get_xml_element())
    assert(test_root.tag=='testcase')
    assert(list(test_root.attrib.keys())[0]=='name')
    assert(list(test_root.attrib.values())[0]=='test_name')

# Generated at 2022-06-23 13:38:14.601412
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase("TestCase1",1,"test","test",3.3)
    assert tc.__class__.__name__ == "TestCase"
    assert tc.name == "TestCase1"
    assert tc.assertions == 1
    assert tc.classname == "test"
    assert tc.status == "test"
    assert tc.time == 3.3
    assert tc.errors == []
    assert tc.failures == []
    assert tc.skipped == None
    assert tc.system_out == None
    assert tc.system_err == None
    assert tc.is_disabled == False


# Generated at 2022-06-23 13:38:19.328654
# Unit test for method __eq__ of class TestResult
def test_TestResult___eq__():
    x = TestResult()
    y = TestResult()
    z = TestResult()

    assert x == y
    assert not x != y

    assert x == z
    assert not x != z

    assert y == z
    assert not y != z



# Generated at 2022-06-23 13:38:24.786274
# Unit test for method get_xml_element of class TestCase
def test_TestCase_get_xml_element():
    test_case = TestCase(name='test_testcase')
    test_case.output = 'test_output'
    test_case.message = 'test_message'
    test_case.type = 'test_type'
    result = test_case.get_xml_element()
    xmlString = ET.tostring(result, encoding='utf-8', method='xml')
    assert xmlString == b'<testcase name="test_testcase">failure test_output</testcase>'


if __name__ == '__main__':
    test_TestCase_get_xml_element()

# Generated at 2022-06-23 13:38:30.544426
# Unit test for method __post_init__ of class TestResult
def test_TestResult___post_init__():
    for tagname in ['failure', 'error']:
        TC_obj = TestFailure()
        assert TC_obj.tag == tagname
        TC_obj.tag = 'nothing'
        TC_obj.__post_init__()
        assert TC_obj.tag == tagname
        assert TC_obj.type == tagname
    return True

# Generated at 2022-06-23 13:38:39.763718
# Unit test for method get_xml_element of class TestSuites

# Generated at 2022-06-23 13:38:50.064615
# Unit test for method __repr__ of class TestSuites

# Generated at 2022-06-23 13:38:59.719820
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    ts = TestSuites(name = "testsuite")
    ts.suites.append(TestSuite(name = "testsuite1",
                               hostname = "localhost",
                               id = "testsuite1",
                               package = "testsuite1",
                               timestamp = datetime.datetime(2020, 1, 1, 0, 0, 0)))
    ts.suites[0].cases.append(TestCase(name = "testcase1",
                                       assertions = 1,
                                       classname = "testclass1",
                                       status = "status1",
                                       time = decimal.Decimal('1')))

    xml_string = ts.get_xml_element().tostring().decode()


# Generated at 2022-06-23 13:39:02.797646
# Unit test for method get_attributes of class TestSuites
def test_TestSuites_get_attributes():
    assert _attributes(a=1, b="test", c=None) == {'a': '1', 'b': 'test'}


# Generated at 2022-06-23 13:39:10.014359
# Unit test for method __repr__ of class TestCase

# Generated at 2022-06-23 13:39:11.815812
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    obj = TestSuites()
    assert(obj == obj)


# Generated at 2022-06-23 13:39:19.232423
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    FAKE_XML = '''<testsuites>
  <testsuite name="fake" tests="1">
    <testcase name="fake" time="0.0"></testcase>
  </testsuite>
</testsuites>
'''

    testcase = TestCase(name='fake')
    suite = TestSuite(name='fake', cases=(testcase,))
    suites = TestSuites(name='fake', suites=(suite,))

    assert suites.to_pretty_xml() == FAKE_XML

# Generated at 2022-06-23 13:39:21.792764
# Unit test for method __repr__ of class TestError
def test_TestError___repr__():
        instance = TestError()
        assert instance.__repr__() == 'TestError()'

# Generated at 2022-06-23 13:39:31.848410
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    class_ = TestSuites

    # Initialize object _expected_object_ with default values
    name_ = None
    _expected_object_ = class_(name=name_)

    # Initialize object _not_expected_object_ with default values
    name_ = None
    _not_expected_object_ = class_(name=name_)

    # Initialize object _actual_object_ with default values
    name_ = None
    _actual_object_ = class_(name=name_)

    assert _expected_object_ == _actual_object_
    assert not (_expected_object_ != _actual_object_)
    assert not (_expected_object_ == _not_expected_object_)
    assert _expected_object_ != _not_expected_object_



# Generated at 2022-06-23 13:39:42.511198
# Unit test for constructor of class TestSuites
def test_TestSuites():
    # "test_" is prepended for pytest auto-discovery
    class TestTestSuites:
        def test_default(self):
            "Check for default construction of TestSuites"
            suites = TestSuites()
            assert isinstance(suites, TestSuites)

        def test_default_values(self):
            "Check for default values of TestSuites"
            suites = TestSuites()
            assert suites.name is None
            assert suites.suites == []

        def test_non_default(self):
            "Check for non-default construction of TestSuites"
            suites = TestSuites(name="TestSuites_name")
            assert isinstance(suites, TestSuites)
            assert suites.name == "TestSuites_name"

    test_TestSuites = TestTestSuites()
    test_

# Generated at 2022-06-23 13:39:56.092401
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():

    # create test suite with all attributes
    test_suite_all_attributes = TestSuite(name='test', hostname='localhost', id='1', package='com.example', timestamp=datetime.datetime.now(), properties={'property': 'value'})

    # check if all attributes are in return value of method get_attributes
    assert 'name' in test_suite_all_attributes.get_attributes().keys() and 'hostname' in test_suite_all_attributes.get_attributes().keys() and 'id' in test_suite_all_attributes.get_attributes().keys() and 'package' in test_suite_all_attributes.get_attributes().keys() and 'timestamp' in test_suite_all_attributes.get_attributes().keys() and 'disabled' in test

# Generated at 2022-06-23 13:40:00.801741
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    """
    Test method __eq__ of class TestError
    """
    error_1 = TestError("error msg")
    error_2 = TestError("error msg")
    error_3 = TestError("another error msg")
    assert error_1.__eq__(error_2)
    assert not error_1.__eq__(error_3)


# Generated at 2022-06-23 13:40:12.792545
# Unit test for method __eq__ of class TestError
def test_TestError___eq__():
    a = TestError("some_output", "some_message", "some_type")
    b = TestError("some_output", "some_message", "some_type")
    assert a == b
    a = TestError("some_output", None, None)
    b = TestError("some_output", None, None)
    assert a == b
    a = TestError("some_output", "some_message", "some_type")
    b = TestError("some_output", "other_message", "other_type")
    assert a != b
    a = TestError("some_output", "some_message", "some_type")
    b = TestError("some_output", "other_message", None)
    assert a != b
    a = TestError("some_output", "some_message", "some_type")
   

# Generated at 2022-06-23 13:40:17.207827
# Unit test for method __eq__ of class TestFailure
def test_TestFailure___eq__():
    # Setup
    test_result1 = TestFailure()
    test_result2 = TestFailure()

    # Exercise
    result = test_result1 == test_result2

    # Verify
    assert result is True


# Generated at 2022-06-23 13:40:23.844270
# Unit test for method get_xml_element of class TestResult
def test_TestResult_get_xml_element():
    test_result = TestResult(output='Hello World', message='This is a unit test for TestResult', type='TEST_TYPE')
    result = test_result.get_xml_element()
    assert result.text == 'Hello World'
    assert result.attrib['message'] == 'This is a unit test for TestResult'
    assert result.attrib['type'] == 'TEST_TYPE'


# Generated at 2022-06-23 13:40:25.549382
# Unit test for constructor of class TestCase
def test_TestCase():
    test_case = TestCase(name='Test Case 1')


# Generated at 2022-06-23 13:40:35.967052
# Unit test for method __eq__ of class TestSuite
def test_TestSuite___eq__():
    """Unit test for method __eq__ of class TestSuite."""
    # Test x == y.
    test_suite1 = TestSuite(
        name='name1',
    )
    test_suite2 = TestSuite(
        name='name1',
    )
    assert test_suite1 == test_suite2

    test_suite1.cases.append(
        TestCase(
            name='name1',
        )
    )
    test_suite2.cases.append(
        TestCase(
            name='name1',
        )
    )
    assert test_suite1 == test_suite2

    test_suite1.properties['key1'] = 'value1'
    test_suite2.properties['key1'] = 'value1'
    assert test_suite

# Generated at 2022-06-23 13:40:45.430908
# Unit test for method __eq__ of class TestCase
def test_TestCase___eq__():
    test_case1: TestCase = TestCase(
        name='Test.Unit.TestCase2.test_assertEqual',
        assertions=1,
        classname='test_assertEqual',
        status='run',
        time=decimal.Decimal('0.000001'),
        errors=[],
        failures=[],
        skipped=None,
        system_out=None,
        system_err=None
    )


# Generated at 2022-06-23 13:40:51.755264
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    test_suite = TestSuite(name="name", timestamp=datetime.datetime(2019, 1, 1, 0, 0, 0, 0))
    assert test_suite.get_attributes() == {
        "name": "name",
        "timestamp": "2019-01-01T00:00:00",
    }


# Generated at 2022-06-23 13:40:59.662777
# Unit test for method get_attributes of class TestSuite
def test_TestSuite_get_attributes():
    suite_name = "test suite name"
    suite_id = "001"
    suite_hostname = "localhost"
    suite_package = "com.package"
    suite_timestamp = datetime.datetime(2020, 1, 2, hour=3, minute=4, second=5)
    suite_prop_name = "name"
    suite_prop_value = "value"
    suite_properties = {suite_prop_name: suite_prop_value}
    suite_case_name = "test case name"
    suite_case_classname = "com.example.classname"
    suite_case_time = datetime.datetime(2020, 3, 4, hour=5, minute=6, second=7)
    suite_case_error_type = "type"

# Generated at 2022-06-23 13:41:03.616567
# Unit test for method __repr__ of class TestSuite
def test_TestSuite___repr__():
    # Arrange
    obj = TestSuite('test_name')

    # Act
    actual = repr(obj)

    # Assert
    assert actual == 'TestSuite(name="test_name")'



# Generated at 2022-06-23 13:41:08.267850
# Unit test for constructor of class TestFailure
def test_TestFailure():
    #create istance of class
    test_failure = TestResult(
        output = 'output',
        message = 'message',
        type = 'type'
    )
    #assertions
    assert test_failure is not None
    assert test_failure.output is not None
    assert test_failure.message is not None
    assert test_failure.type is not None


# Generated at 2022-06-23 13:41:14.608369
# Unit test for method get_attributes of class TestCase
def test_TestCase_get_attributes():
    tc = TestCase(name="TestCase", assertions=None, classname=None,
                  status=None, time=None, errors=None, failures=None,
                  skipped=None, system_out=None, system_err=None,
                  is_disabled=False)
    actual = tc.get_attributes()
    expect = {'name': 'TestCase'}
    assert actual == expect



# Generated at 2022-06-23 13:41:21.713980
# Unit test for method __repr__ of class TestSuites
def test_TestSuites___repr__():
    try:
        assert (str(TestSuites()) ==
                "TestSuites(name=None, suites=[])"
                )
        assert (str(TestSuites(name="name", suites=[TestSuite(name="name")])) ==
                "TestSuites(name='name', suites=[TestSuite(name='name', hostname=None, id=None, package=None, timestamp=None, properties={}, cases=[], system_out=None, system_err=None)])"
                )
    except:
        return False
    else:
        return True


# Generated at 2022-06-23 13:41:24.271588
# Unit test for method __repr__ of class TestResult
def test_TestResult___repr__():
    obj = TestResult()
    assert len(repr(obj)) > 0


# Generated at 2022-06-23 13:41:33.842708
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    try:
        name = 'test-case'
        assertions = '1'
        classname = 'TestCase'
        status = 'passed'
        time = '0.1234'
        output = 'Test passed'

        expected = (
            'TestCase(name=\'test-case\', assertions=\'1\', classname=\'TestCase\', status=\'passed\', '
            'time=\'0.1234\', output=\'Test passed\')\n'
        )
        actual = TestCase(name, assertions, classname, status, decimal.Decimal(time), output)
        assert expected == repr(actual)
    except Exception:
        raise AssertionError

# Generated at 2022-06-23 13:41:45.070724
# Unit test for method __repr__ of class TestCase
def test_TestCase___repr__():
    assert repr(TestCase('name')) == 'TestCase(name="name", assertions=None, classname=None, status=None, time=None, errors=[], failures=[], skipped=None, system_out=None, system_err=None, is_disabled=False)'

# Generated at 2022-06-23 13:41:46.795552
# Unit test for constructor of class TestCase
def test_TestCase():
    tc = TestCase("skipped")
    assert tc.skipped == "skipped"

# Generated at 2022-06-23 13:41:57.293948
# Unit test for constructor of class TestSuites

# Generated at 2022-06-23 13:42:06.398024
# Unit test for constructor of class TestCase
def test_TestCase():
    assert TestCase.__annotations__['name'] == str
    assert TestCase.__annotations__['assertions'] == t.Optional[int]
    assert TestCase.__annotations__['classname'] == t.Optional[str]
    assert TestCase.__annotations__['status'] == t.Optional[str]
    assert TestCase.__annotations__['time'] == t.Optional[decimal.Decimal]
    assert TestCase.__annotations__['message'] == t.Optional[str]
    

# Generated at 2022-06-23 13:42:15.439516
# Unit test for method get_attributes of class TestSuite

# Generated at 2022-06-23 13:42:22.893553
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    x = TestFailure()
    assert repr(x) == "TestFailure(output=None, message=None, type='failure')"
    x.output = 'x'
    assert repr(x) == "TestFailure(output='x', message=None, type='failure')"
    x.message = 'y'
    assert repr(x) == "TestFailure(output='x', message='y', type='failure')"
    x.type = 'z'
    assert repr(x) == "TestFailure(output='x', message='y', type='z')"


# Generated at 2022-06-23 13:42:30.970888
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    time1 = datetime.datetime(2020, 4, 22, 19, 43, 16)
    time2 = datetime.datetime(2020, 4, 22, 19, 43, 16)
    test_case1 = TestCase(name='foo1', assertions=12, classname='bar1', status='starting1', time=decimal.Decimal(1.1))
    test_case2 = TestCase(name='foo2', assertions=22, classname='bar2', status='starting2', time=decimal.Decimal(2.2))

# Generated at 2022-06-23 13:42:42.246478
# Unit test for method __eq__ of class TestSuites
def test_TestSuites___eq__():
    # test__TestSuites_Name__NotEqual
    testSuites1 = TestSuites(name="TestSuites1")
    testSuites2 = TestSuites(name="TestSuites2")
    assert testSuites1 != testSuites2, 'Expected TestSuites1!=TestSuites2'
    # test__TestSuites_Name__Equal
    testSuites1 = TestSuites(name="TestSuites")
    testSuites2 = TestSuites(name="TestSuites")
    assert testSuites1 == testSuites2, 'Expected TestSuites1==TestSuites2'
    # test__TestSuites_Suites__NotEqual
    testSuites1 = TestSuites(name="TestSuites", suites=[TestSuite("TestSuite1")])
    testSuites2

# Generated at 2022-06-23 13:42:45.797583
# Unit test for method get_xml_element of class TestSuites
def test_TestSuites_get_xml_element():
    suite = TestSuites()
    assert suite.get_xml_element()


# Generated at 2022-06-23 13:42:56.841643
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    xml_file = 'TestSuites.xml'
    # Create a new testsuite
    testsuite = TestSuite(name="testsuite01", hostname="L-PC", id="testsuite01", package="com.example.tests", timestamp=datetime.datetime.now())
    # Create a new testcase
    testcase = TestCase(name="testcase01", assertions=0, classname="TestCases", status="PASSED", time=0.2)
    # Create a new testfailure
    testfailure = TestFailure(output="I'm a failure", message="I'm a failure message", type="BOP Failure")
    # Add the testfailure to the testcase
    testcase.failures.append(testfailure)
    # Add the testcase to the testsuite

# Generated at 2022-06-23 13:43:08.093781
# Unit test for method to_pretty_xml of class TestSuites
def test_TestSuites_to_pretty_xml():
    # Arrange
    test_suites = TestSuites()

    test_suite_1 = TestSuite(
        name='TestSuite1',
        hostname='localhost',
        id='id1',
        package='TestSuite1',
        timestamp=datetime.datetime(2020, 1, 1, 10, 0, 0),
        properties=dict(prop1='value1', prop2='value2'),
        system_out='system out 1',
        system_err='system error 1',
    )

# Generated at 2022-06-23 13:43:14.315745
# Unit test for method __repr__ of class TestFailure
def test_TestFailure___repr__():
    """Unit tests for the method __repr__."""
    assert repr(TestFailure()) == 'TestFailure(output=None, message=None, type=None)'
    assert repr(TestFailure(output='output')) == 'TestFailure(output=\'output\', message=None, type=None)'
    assert repr(TestFailure(output='output', message='message')) == 'TestFailure(output=\'output\', message=\'message\', type=None)'
    assert repr(TestFailure(output='output', message='message', type='type')) == 'TestFailure(output=\'output\', message=\'message\', type=\'type\')'
