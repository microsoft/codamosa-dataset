

# Generated at 2022-06-22 22:53:54.299242
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware import DarwinHardware
    hardware = DarwinHardware(dict())


# Generated at 2022-06-22 22:54:06.497020
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create fake module
    from ansible.module_utils.basic import AnsibleModule
    fake_module = AnsibleModule(
        argument_spec = {},
        supports_check_mode = True
    )

    # Create fake DarwinHardware object
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware(fake_module)

    # Fake module run command
    def fake_run_command(cmd, encoding=None):
        return (0, b'kern.boottime: { sec = 1542926144, usec = 606752 } Fri Nov 30 23:32:24 2018', '')

    hardware.module.run_command = fake_run_command

    uptime_facts = hardware.get_uptime_facts()

# Generated at 2022-06-22 22:54:15.675340
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    def run_command(cmd, encoding=None, errors='surrogate_then_replace'):
        # This command is sent by method get_uptime_facts of class DarwinHardware
        assert cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']
        # kern.boottime returns seconds and microseconds as two 64-bits
        # fields. We use the same value in this unit test.
        return 0, '\x00\x00\x00\x00\x00\x01`\x11\x00\x00', ''

    module.run_command = run_command
    expected_uptime_facts = {'uptime_seconds': 1399}
    actual_uptime_facts = hardware

# Generated at 2022-06-22 22:54:23.948540
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    class MockModule:
        def __init__(self, run_command_result, bin_path_result):
            self.run_command_result = run_command_result
            self.bin_path_result = bin_path_result
        def run_command(self, args, encoding=None):
            return self.run_command_result
        def get_bin_path(self, name):
            return self.bin_path_result

    class MockFacts:
        def __init__(self, hardware_results):
            self.hardware = hardware_results

    # Define inputs to the populate method
    collected_facts = MockFacts({'kernel': 'Darwin'})

    # Create an instance of the DarwinHardware class to test

# Generated at 2022-06-22 22:54:29.558928
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    Runs the method without throwing exceptions
    """
    module = AnsibleModuleMock()

    module.run_command = (lambda x: (0, "", ""))
    module.get_bin_path = (lambda x: "/usr/bin/vm_stat")
    collector = DarwinHardwareCollector(module)
    collector.populate()


# Generated at 2022-06-22 22:54:40.835596
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class TestModule:
        def __init__(self, vmstat_out):
            self.params = dict()
            self.params['gather_subset'] = ['!all', '!min', '!virtual']
            self.run_command_count = 0
            self.run_command_return_value = [0, vmstat_out, '']
            self.run_command_side_effect = None

        def run_command(self, args):
            if self.run_command_side_effect is not None:
                return self.run_command_side_effect(args)

            self.run_command_count += 1
            return self.run_command_return_value


# Generated at 2022-06-22 22:54:44.186597
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector
    assert hardware_collector._platform == 'Darwin'
    assert hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-22 22:54:52.509323
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockModule()
    hw = DarwinHardware(module)

    module.run_command = Mock(
        return_value = (
            0,  # exit code
            'hw.machdep.cpu.brand_string',  # stdout
            '',  # stderr
        )
    )
    hw.sysctl = {}
    hw.get_cpu_facts()

    module.run_command.assert_called_with(['sysctl', 'hw.model'])



# Generated at 2022-06-22 22:55:00.149062
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import sys
    if sys.version_info[:2] == (2, 6):
        # pylint: disable=unused-argument
        def mock_run_command(module, cmd, encoding='utf-8', errors='surrogate_or_strict', check_rc=True):
            """Define a mock for the run_command method.

            :arg module: The module to mock.
            :arg cmd: The command to mock being run.
            :kwarg encoding: The encoding to use when decoding the output.
            :kwarg errors: The method of error handling used when decoding the output.
            :kwarg check_rc: Whether to check the return code for an error.
            :returns: A tuple of (rc, stdout, stderr).
            """

# Generated at 2022-06-22 22:55:01.768083
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hw = DarwinHardware()
    assert hw.platform == 'Darwin'

# Generated at 2022-06-22 22:55:06.466129
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert hasattr(DarwinHardwareCollector, '_platform')
    assert hasattr(DarwinHardwareCollector, '_fact_class')

    darwin_hardware_collector = DarwinHardwareCollector()

    assert darwin_hardware_collector
    assert isinstance(darwin_hardware_collector, HardwareCollector)

# Generated at 2022-06-22 22:55:15.177459
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    import ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.mock_module = patch.object(ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin.AnsibleModule,
                                            'run_command').start()
            self.mock_module.return_value = (0, b'{ sec = 1480636410, usec = 175541 }', '')
            self.test_hw = DarwinHardware

# Generated at 2022-06-22 22:55:15.795394
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-22 22:55:27.615345
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Test dicts for module arguments and expected results of method populate
    test_dict = [
        {
            'module_args': dict(gather_subset='hardware'),
            'expected_results': dict(
                uptime_seconds=334065,
                model='Macmini6,2',
                osrevision=3,
                processor='Intel Core i7-3615QM @ 2.3 GHz',
                processor_vcpus='',
                processor_cores=2,
                osversion='14.0.0',
                memfree_mb=1065,
                memtotal_mb=8192
            )
        },

    ]
    import sys
    sys.modules['ansible.module_utils.facts.hardware.darwin'] = None

# Generated at 2022-06-22 22:55:36.637154
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_returns = dict(rc=0, out=b'hw.model: iMac14,2\n', err=b'')
            self.run_command_calls = 0
            self.get_bin_path_returns = dict(rc=0, out='/usr/sbin/system_profiler', err=b'')
            self.get_bin_path_calls = 0

        def get_bin_path(self, arg, opt_dirs=None):
            self.get_bin_path_calls += 1
            return self.get_bin_path_returns


# Generated at 2022-06-22 22:55:47.082468
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware = DarwinHardware(dict())
    # mock sysctl hw.model
    darwin_hardware.sysctl = dict()
    darwin_hardware.sysctl['hw.model'] = "MacBookPro13,3"
    # mock kern.osversion
    darwin_hardware.sysctl['kern.osversion'] = "19.6.0"
    # mock kern.osrevision
    darwin_hardware.sysctl['kern.osrevision'] = "15G31"

    # expected dictionary
    expected_dict = dict()
    expected_dict['model'] = "MacBookPro13,3"
    expected_dict['osversion'] = "19.6.0"
    expected_dict['osrevision'] = "15G31"

    # assert

# Generated at 2022-06-22 22:55:49.772092
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hwc = DarwinHardwareCollector()
    assert darwin_hwc.__class__.__name__ == 'DarwinHardwareCollector'


# Generated at 2022-06-22 22:55:52.665183
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()
    assert hardware.cpu_facts['processor'] == ''
    assert hardware.cpu_facts['processor_cores'] == ''

# Generated at 2022-06-22 22:55:57.208520
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = FakeAnsibleModule()
    facts = DarwinHardwareCollector(module).collect()
    processor = facts['processor']
    memtotal_mb = facts['memtotal_mb']
    uptime_seconds = facts['uptime_seconds']

    assert processor is not None
    assert memtotal_mb is not None
    assert uptime_seconds is not None



# Generated at 2022-06-22 22:55:59.818547
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Assume that the host is running on Darwin platform
    hardware = DarwinHardware()
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['osrevision'] == "19.5.0"
    assert mac_facts['osversion'] == "15.5.0"


# Generated at 2022-06-22 22:56:07.919834
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    f = DarwinHardware()

# Generated at 2022-06-22 22:56:09.597256
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    ah = DarwinHardware(None)
    assert ah.populate() is not None

# Generated at 2022-06-22 22:56:17.558264
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = type('Module', (object, ), {
        'run_command': lambda self, cmd, encoding=None: (0, "Mach Virtual Memory Statistics: (page size of 4096 bytes)", ''),
    })
    module.run_command = lambda self, cmd, encoding=None: (0, "Pages free: 1234\nPages wired down: 5678\nPages active: 9101112\nPages inactive: 13141516\n", '')
    darwin_hw = DarwinHardware(module)
    assert darwin_hw.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 168669062}

# Generated at 2022-06-22 22:56:20.261950
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    result = DarwinHardwareCollector(module).collect()
    assert 'processor' in result

# Generated at 2022-06-22 22:56:26.333149
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    darwin_hardware = DarwinHardware({})
    darwin_hardware.sysctl = {'hw.memsize': '2147483648'}

    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 2036



# Generated at 2022-06-22 22:56:38.904849
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    We've got a few standard tests to run for the constructor of all platform
    HardwareCollector classes.
    """
    import sys
    import inspect
    import platform

    # Initialize an object of our tested class
    hardware_collector = DarwinHardwareCollector()

    # Check the class inheritance chain
    test_class = inspect.stack()[0][3]
    class_name = '.'.join([__name__, test_class])
    assert issubclass(DarwinHardwareCollector, HardwareCollector), \
        '%s is not a subclass of Facts.Hardware.HardwareCollector' % class_name

    # Make sure the _fact_class is properly set
    assert hardware_collector._fact_class == DarwinHardware, \
        '%s._fact_class is not DarwinHardware' % class_name

    # Make sure the

# Generated at 2022-06-22 22:56:42.486621
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # TypeError is raised if values are not of the expected type.
    get_uptime_facts = DarwinHardware().get_uptime_facts

    # test for valid values.
    assert get_uptime_facts()['uptime_seconds'] >= 0

# Generated at 2022-06-22 22:56:51.082195
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeAnsibleModule()
    # Test under normal condition (hw.memsize in sysctl)
    module.run_command_results = [ (0, '', '') ]
    module.sysctl_results = { 'hw.memsize': '1073741824' }
    hardware = DarwinHardware(module)
    result = hardware.get_memory_facts()
    assert result['memtotal_mb'] == 1024
    assert result['memfree_mb'] == 0

    # Test when hw.memsize not in sysctl
    hardware.sysctl = {}
    hardware.module.run_command_results = [ (0, '', '') ]
    result = hardware.get_memory_facts()
    assert result['memtotal_mb'] == 0
    assert result['memfree_mb'] == 0

    # Test when

# Generated at 2022-06-22 22:57:01.740966
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class TestModule(object):
        def __init__(self, module_utils):
            self.run_command = module_utils.run_command
        fallback = None

    test_module = TestModule(module_utils)

    test_hardware = DarwinHardware(test_module)

    test_memory_facts = {
        'memtotal_mb': 16384,
        'memfree_mb': 8096,
    }


# Generated at 2022-06-22 22:57:05.623159
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert issubclass(DarwinHardwareCollector, HardwareCollector)
    assert DarwinHardwareCollector._platform == 'Darwin'
    assert DarwinHardwareCollector._fact_class == DarwinHardware


# Generated at 2022-06-22 22:57:16.271673
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    system_profile = {'Model Identifier': 'MacBookPro14,3', 'OS Version': '10.13.3 (17D102)', 'OS Build': '17D102'}
    test_module.run_command = MagicMock(return_value=(0, 'hw.model: MacBookPro14,3', ''))
    darwin_hardware = DarwinHardware(module=test_module)
    darwin_hardware.sysctl = {
        'kern.osversion': '',
        'kern.osrevision': '',
    }
    darwin_hardware.get_system_profile = MagicMock(return_value=system_profile)

# Generated at 2022-06-22 22:57:26.902510
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import pytest
    from ansible_collections.community.general.tests.unit.module_utils.plugins.modules import test_get_module_class
    module, module_class = test_get_module_class('DarwinHardware')

    memory_facts = {
        'memtotal_mb': 8192,
        'memfree_mb': 1,
    }

    def run_command(self, cmd, encoding=None):
        output = "page size of 4096 bytes\n"
        output += "Evaluate using: command | awk '/^Mach Virtual Memory Statistics/,/^VM region summary/' | awk '/^Pages/ || /^Mach/'"
        output += "VM Statistics: (page size of 4096 bytes)\n"
        output += "Pages free:                       111774.\n"

# Generated at 2022-06-22 22:57:36.330648
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import sys

    import runpy
    mock_module_path = os.path.join(os.path.dirname(sys.modules['ansible.module_utils.facts.hardware.darwin'].__file__), 'tests', 'unit',
        'module_utils', 'facts', 'hardware', 'modules', 'system_profiler_mock.py')
    if os.path.exists(mock_module_path):
        mock_module = runpy.run_path(mock_module_path)
        sys.modules['ansible.module_utils.facts.hardware.darwin'].module = mock_module['AnsibleModule']()

    hardware = DarwinHardwareCollector._fact_class()
    system_profile = hardware.get_system_profile()

# Generated at 2022-06-22 22:57:42.587246
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()

    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-22 22:57:44.931306
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )
    collector = DarwinHardwareCollector(module)
    assert collector.platform == 'Darwin'


# Generated at 2022-06-22 22:57:48.312430
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector_obj = DarwinHardwareCollector()
    assert hardware_collector_obj._fact_class == DarwinHardware
    assert hardware_collector_obj._platform == 'Darwin'


# Generated at 2022-06-22 22:57:59.658223
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Arrange
    module = FakeAnsibleModule()
    module.ctime = lambda *args: 'Tue Nov  6 13:29:50 2018'
    hardware = DarwinHardware(module)

    module.run_command = lambda *args, **kwargs: (0, "hw.model: Macmini5,1")

    # Act
    result = hardware.get_mac_facts()

    # Assert
    assert result['osversion'] == 'Darwin Kernel Version 18.2.0: Tue Nov  6 13:29:50 PST 2018; root:xnu-4903.231.4~2/RELEASE_X86_64'
    assert result['osrevision'] == '4903.231.4'
    assert result['model'] == 'Macmini5,1'
    assert 'product_name' in result

# Test for

# Generated at 2022-06-22 22:58:01.417647
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hw = DarwinHardware(dict())
    assert darwin_hw.platform == 'Darwin'


# Generated at 2022-06-22 22:58:06.024876
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware_facts = DarwinHardware()
    memory_facts = hardware_facts.get_memory_facts()
    assert isinstance(memory_facts, dict) and 'memtotal_mb' in memory_facts and 'memfree_mb' in memory_facts

# Generated at 2022-06-22 22:58:08.993465
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector._fact_class == DarwinHardware
    assert hardware_collector._platform == 'Darwin'

# Generated at 2022-06-22 22:58:10.860911
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector.get_facts() == {}

# Generated at 2022-06-22 22:58:14.293859
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """Verify that an instance of DarwinHardwareCollector can be created.
    """
    collector = DarwinHardwareCollector(None)
    assert isinstance(collector, DarwinHardwareCollector)

# Generated at 2022-06-22 22:58:19.717925
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()

    assert darwin_hardware_collector is not None
    assert darwin_hardware_collector._platform == 'Darwin'

# Test for DarwinHardware.get_cpu_facts

# Generated at 2022-06-22 22:58:23.955518
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test Intel
    cpu_facts = DarwinHardware({}).get_cpu_facts()
    assert 'processor' in cpu_facts
    assert cpu_facts['processor_cores'] > 0
    assert cpu_facts['processor_vcpus']


# Generated at 2022-06-22 22:58:33.966577
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts import Collector

    # Using mock to fake the class DarwinHardware because it is being
    # instantiated in Collector and all its methods are called by
    # Collector.populate()
    with mock.patch('ansible.module_utils.facts.hardware.base.DarwinHardware',
                    autospec=True) as fake_hw:
        fake_hw.sysctl = {'kern.osversion': 'foo',
                          'kern.osrevision': 'bar',
                          'hw.memsize': '1234',
                          'hw.memsize_free': 'bar'}
        fake_hw.get_mac_facts.return_value = {'foo': 'baz'}

# Generated at 2022-06-22 22:58:36.035627
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    h = DarwinHardwareCollector()
    assert h.platform == 'Darwin'

# Generated at 2022-06-22 22:58:48.602959
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {
        "machdep.cpu.brand_string": "Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz",
        "machdep.cpu.core_count": 2,
    }
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert cpu_facts["processor"] == "Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz",\
        "Unexpected value for key \"processor\" in processor facts"
    assert cpu_facts["processor_cores"] == 2,\
        "Unexpected value for key \"processor_cores\" in processor facts"

# Generated at 2022-06-22 22:59:00.866578
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # This test relies on system facts being available and valid.
    # If the test is failing, it is not a test issue, but a problem in the
    # system facts, or a combination of the two.
    test_module, test_system_facts = get_test_module()
    darwin_hardware = DarwinHardware(test_module)
    output = darwin_hardware.populate(test_system_facts)
    assert 'model' in output
    assert 'osversion' in output
    assert 'osrevision' in output
    assert 'processor_cores' in output
    assert 'processor' in output
    assert 'processor_vcpus' in output
    assert 'memtotal_mb' in output
    assert 'memfree_mb' in output
    assert 'uptime_seconds' in output


# Generated at 2022-06-22 22:59:09.018234
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = FakeModule()
    darwin_hardware = DarwinHardware(module)
    profile = darwin_hardware.get_system_profile()
    expected_keys = set(['Hardware UUID', 'Model Identifier', 'Model Name', 'Processor Name', 'Processor Speed', 'Number of Processors', 'Memory', 'Boot ROM Version', 'Serial Number (system)', 'SMC Version (system)', 'Hardware Overview'])
    if set(profile.keys()) < expected_keys:
        module.fail_json(msg="Output from system_profiler does not have the keys expected")

# Generated at 2022-06-22 22:59:20.434631
# Unit test for method get_mac_facts of class DarwinHardware

# Generated at 2022-06-22 22:59:28.539598
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    fixture_path = os.path.join(fixture_path, 'DarwinHardwareFacts.py')
    command_outputs = load_fixture('DarwinHardwareFacts.py')
    dh = DarwinHardware(module)
    module.run_command = MagicMock(side_effect=command_outputs.get)
    setattr(dh, 'module', module)
    mac_facts = dh.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro14,3'
    assert mac_facts['osversion'] == '17.7.0'
    assert mac_facts['osrevision'] == '15K60'


# Generated at 2022-06-22 22:59:36.164773
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # We expect a dict with at least these keys, but not necessarily these values.
    system_profile = DarwinHardware({}).get_system_profile()
    assert set(system_profile.keys()) == set([
        'Model Name',
        'Model Identifier',
        'Processor Name',
        'Processor Speed',
        'Number of Processors',
        'Memory',
        'Serial Number (system)',
    ])

# Generated at 2022-06-22 22:59:47.577181
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # test for Intel CPU
    hardware_info = DarwinHardware(module=None)
    hardware_info.sysctl = {"machdep.cpu.brand_string": "Intel(R) Core(TM) i5-7360U CPU @ 2.30GHz", "machdep.cpu.core_count": 2}
    cpu_facts = hardware_info.get_cpu_facts()
    assert(cpu_facts['processor'] == "Intel(R) Core(TM) i5-7360U CPU @ 2.30GHz")
    assert(cpu_facts['processor_cores'] == 2)

    # test for PowerPC CPU
    hardware_info = DarwinHardware(module=None)
    hardware_info.sysctl = { "hw.physicalcpu": 2}

# Generated at 2022-06-22 22:59:50.882994
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule({})
    class MockModule:
        run_command = module.run_command

    hardware = DarwinHardware(MockModule)
    hardware.get_system_profile()


# Generated at 2022-06-22 22:59:53.792348
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.fact_class == DarwinHardware
    assert darwin_hardware_collector.platform == 'Darwin'

# Generated at 2022-06-22 23:00:04.868581
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import mock

    class TestDarwinHardware(DarwinHardware):
        def __init__(self):
            self.module = mock.MagicMock()

    hardware = TestDarwinHardware()

    # get_memory_facts returns memtotal_mb and memfree_mb
    # by default, all mem*_mb should be 0
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 0
    assert facts['memfree_mb'] == 0

    # mock run_command returns the following vm_stat output

# Generated at 2022-06-22 23:00:17.098131
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # This is a reference value obtained using `uptime` on macOS 10.12.2
    expected_uptime = 942661

    test_sysctl_path = '/tmp/sysctl.ansible-test'
    test_sysctl_content = 'kern.boottime: { sec: 1497541766, usec: 846283 } Sun May  7 17:49:26 2017\n'

    with open(test_sysctl_path, 'w') as f:
        f.write(test_sysctl_content)

    darwin_hardware = DarwinHardware(dict(module=dict(get_bin_path=lambda _: test_sysctl_path)))
    actual_uptime = darwin_hardware.get_uptime_facts()['uptime_seconds']
    assert actual_uptime == expected_uptime

# Generated at 2022-06-22 23:00:26.914380
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    # Make use of a mock module
    class MockModule(object):
        def get_bin_path(self, param):
            return ''
        def run_command(self, command, encoding=None):
            return 0, 'some.value', []
    module = MockModule()

    # Create the fake object and call the method
    darwinhw = DarwinHardware(module)
    result = darwinhw.get_uptime_facts()

    # Check if the result is as expected
    if 'uptime_seconds' not in result:
        return False
    if not isinstance(result['uptime_seconds'], int):
        return False
    return True

# Generated at 2022-06-22 23:00:31.016372
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_facts_obj = DarwinHardwareCollector()
    assert hardware_facts_obj._fact_class is not None
    assert hardware_facts_obj._platform == 'Darwin'


# Generated at 2022-06-22 23:00:32.984836
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
  hardware_collector = DarwinHardwareCollector()
  assert hardware_collector._platform == 'Darwin'
  assert hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-22 23:00:42.239332
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform

    # Reference date: 2018-12-25 14:38:00
    reference_date = 1545694680000 / 1000.0

    class FakeModule:
        def run_command(self, cmd, encoding=None):
            assert cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']
            assert encoding is None
            return (0, b'1545694680000\n', '')

        def get_bin_path(self, cmd, required=False):
            assert cmd == 'sysctl'
            return '/usr/sbin/sysctl'

    class FakeTime:
        def __init__(self):
            self.time = reference_date

        def time(self):
            return self.time

    mac_os_x_version = platform.mac_ver()[0]

# Generated at 2022-06-22 23:00:53.768491
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    class MockModule:
        def run_command(self, cmd):
            fake_out = ''
            if cmd == ['sysctl', 'hw.memsize']:
                fake_out = 'hw.memsize: 1677721600'

# Generated at 2022-06-22 23:01:05.835278
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # This test is aimed to check the method get_uptime_facts of class DarwinHardware.
    # It is based on the example given in the sysctl man page.
    # The example given in the man page doesn't exactly match the output format
    # of 'sysctl -b kern.boottime'.

    # Mock the 'sysctl' command using the fake_module fixture.
    # For the test, we need raw bytes, not UTF-8. So set encoding to None.
    fake_module = FixtureFakeModule(dict(encoding=None))
    fake_module.run_command = Mock(return_value=(0, fake_boottime_bytes, None))
    fake_module.get_bin_path = Mock(return_value='/usr/sbin/sysctl')

    # Check the output of get_uptime_facts.
    d

# Generated at 2022-06-22 23:01:10.606764
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert isinstance(darwin_hardware_collector, HardwareCollector)
    assert isinstance(darwin_hardware_collector._fact_class, DarwinHardware)
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:01:20.290186
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module_mock = MagicMock()

    # Creating a mock module object
    fake_module = MagicMock()
    fake_module.run_command.return_value = (0, b'\x00\xd8F\xa0\x1b\x00\x00\x00\x00', '')
    fake_module.get_bin_path.return_value = '/usr/bin/sysctl'
    fake_module.params = {}
    dh = DarwinHardware(fake_module)

    # Testing the uptime_facts
    assert dh.get_uptime_facts()['uptime_seconds'] > 0

# Generated at 2022-06-22 23:01:27.460350
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    d = DarwinHardware(dict(), dict(module=None))
    test_output = ''
    test_output += 'Hardware:  '
    test_output += '\n'
    test_output += '    Hardware Overview:  '
    test_output += '\n'
    test_output += '      Model Name:  '
    test_output += 'MacBookPro'
    test_output += '\n'
    test_output += '      Model Identifier:  '
    test_output += 'MacBookPro11,3'
    test_output += '\n'
    test_output += '      Processor Name:  '
    test_output += 'Intel Core i7'
    test_output += '\n'
    test_output += '      Processor Speed:  '
    test_output += '2.5 GHz'
   

# Generated at 2022-06-22 23:01:38.846378
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    import platform
    facts = {}
    facts["ansible_system"] = platform.system()
    facts["ansible_machine"] = platform.machine()
    facts["ansible_distribution"] = platform.system()

    darwin_hardware = DarwinHardware(module=None, facts=facts)
    assert darwin_hardware.sysctl['hw.memsize']
    assert darwin_hardware.sysctl['kern.osversion']
    assert darwin_hardware.sysctl['kern.osrevision']
    assert darwin_hardware.sysctl['hw.ncpu']
    assert darwin_hardware.sysctl['hw.physicalcpu']
    assert darwin_hardware.sysctl['hw.activecpu']



# Generated at 2022-06-22 23:01:49.631435
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    class run_command_mock(object):

        class module_mock(object):
            type_for_run_command = "run_command"
            run_command = None
            get_bin_path = None

            def run_command(command, encoding=None, errors='strict', check_rc=True):
                get_bin_path = "/bin/vm_stat"
                output_of_vm_stat = "1\n2\n3\n4\n5\n6\n7\n8\n9\n10"


# Generated at 2022-06-22 23:01:55.183697
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware = DarwinHardware()

    hardware.sysctl = dict()
    hardware.sysctl['hw.model'] = 'MacBookPro15,1'
    hardware.sysctl['hw.memsize'] = 4294967296
    hardware.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i7-8750H CPU @ 2.20GHz'
    hardware.sysctl['machdep.cpu.core_count'] = 6
    hardware.sysctl['hw.logicalcpu'] = 12
    hardware.sysctl['kern.osversion'] = 'Darwin Kernel Version 18.5.0'
    hardware.sysctl['kern.osrevision'] = 'Darwin Kernel Version 18.5.0'

    result = hardware.populate()


# Generated at 2022-06-22 23:02:07.503557
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """Test get_uptime_facts() on Darwin.

    Use a well-known string as the output and a simulated time to get a value
    that we can compare against.

    """
    import module_utils
    import ansible.module_utils.common.process
    import sys

    # We need to monkeypatch get_bin_path.
    module_utils.common.process.get_bin_path = lambda *args: '/usr/bin/sysctl'

    # We also need to monkeypatch time.time() to return a known value.
    now = time.time()
    time.time = lambda: now

    kern_boottime_struct = struct.pack('@L', int(now) - 100)

# Generated at 2022-06-22 23:02:11.836458
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # DarwinHardware is effectively an abstract class, so we need to create
    # an instance of it
    #
    # We therefore manually create a module which DarwinHardware can then use
    class FakeModule(object):
        def get_bin_path(self, executable, required=False):
            return None

        def run_command(self):
            return 1, '', ''

    hardware = None
    hardware = DarwinHardware(FakeModule())

    # Check that the class contains the correct facts and values
    assert hardware.platform == 'Darwin'

# Generated at 2022-06-22 23:02:21.335061
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware()
    rc, system_profile, err = hardware.module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    if rc != 0:
        return
    sp = hardware.get_system_profile()
    for line in system_profile.splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)
            key, value = key.strip(), ' '.join(value.strip().split())
            assert sp[key] == value, "{0} should be {1}".format(key, value)

# Generated at 2022-06-22 23:02:25.955826
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Create an instance of class DarwinHardware
    module = AnsibleModule({})
    darwin_hardware = DarwinHardware(module)

    # Create a dictionary used as input to the method populate of class DarwinHardware
    collected_facts = {}

    # Call method populate of class DarwinHardware
    darwin_hardware.populate(collected_facts=collected_facts)

# Generated at 2022-06-22 23:02:28.517483
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector._platform == 'Darwin'
    assert DarwinHardwareCollector._fact_class == DarwinHardware


# Generated at 2022-06-22 23:02:34.857632
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.populate()
    # test public methods
    assert hardware.get_memory_facts()
    assert hardware.get_cpu_facts()
    assert hardware.get_mac_facts()
    assert hardware.get_system_profile()
    # test private methods of sysctl
    assert hardware.get_uptime_facts()
    del hardware


# Generated at 2022-06-22 23:02:45.323536
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from collections import namedtuple
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts import timeout

    class FakeModule(object):
        def __init__(self):
            self.params = namedtuple('FakeParams', ['timeout'])
            self.params.timeout = timeout.DEFAULT_TIMEOUT

        def fail_json(self, msg):
            pass

        def run_command(self, command, encoding=None):
            return rc, out, err

        def get_bin_path(self, command):
            return get_bin_path(command)

    os_family = 'Darwin'


# Generated at 2022-06-22 23:02:54.688019
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mod_args = dict()

    mod = CustomModule(argument_spec=dict(), supports_check_mode=False)
    mod.run_command = MagicMock(return_value=(0, SP_HARDWARE_DATA_TYPE, ''))

    sp = DarwinHardware(mod)
    system_profile = sp.get_system_profile()

# Generated at 2022-06-22 23:03:02.969891
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)

    # test case 1: Intel
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz',
                        'machdep.cpu.core_count': 8}
    facts = hardware.get_cpu_facts()
    assert facts['processor'] == 'Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz'
    assert facts['processor_cores'] == 8
    assert facts['processor_vcpus'] == ''

    # test case 2: PowerPC
    hardware.sysctl = {'hw.logicalcpu': 3,
                        'hw.physicalcpu': 1,
                        'hw.ncpu': 4}
    hardware.get_system

# Generated at 2022-06-22 23:03:15.560412
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    h = DarwinHardware()
    h.module = MockModule()
    h.sysctl = MockSysctl()
    h.get_system_profile = lambda: {
        'Machine Model': 'MacPro6,1',
        'Model Name': 'Mac Pro',
        'Processor Name': 'Six-Core Intel Xeon E5',
        'Processor Speed': '3.5 GHz'
    }
    h.get_mac_facts = lambda: {
        'osversion': '15.6.0',
        'osrevision': '17G6030'
    }
    h.get_cpu_facts = lambda: {
        'processor': 'Six-Core Intel Xeon E5',
        'processor_cores': 2,
        'processor_vcpus': 2
    }

# Generated at 2022-06-22 23:03:19.005696
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    mod = AnsibleModule(argument_spec=dict())
    assert issubclass(DarwinHardwareCollector, HardwareCollector)
    assert hasattr(DarwinHardwareCollector, '_platform')
    assert hasattr(DarwinHardwareCollector, '_fact_class')

# Generated at 2022-06-22 23:03:24.303050
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockAnsibleModule()
    hardware = DarwinHardware(module=module)
    facts = hardware.get_mac_facts()
    assert facts['osversion'] == '19.6.0'
    assert facts['osrevision'] == '19H2'


# Generated at 2022-06-22 23:03:34.347887
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    test_module = AnsibleModule(argument_spec={})

    hardware = DarwinHardware(test_module)
    hardware._module = test_module
    hardware._module.run_command = MagicMock(return_value=(0, '', ''))
    hardware._module.get_bin_path = MagicMock(return_value='/usr/sbin/vm_stat')
    hardware.sysctl = get_sysctl(test_module, ['hw', 'machdep', 'kern'])

    hardware_facts = hardware.populate()
    assert hardware_facts['model'] == 'MacBookPro8,2'
    assert hardware_facts['processor'] == 'Intel Core i5'
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['memtotal_mb'] > 0

# Generated at 2022-06-22 23:03:38.040306
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule({'ansible_facts': {'ansible_system': 'Darwin'}},
                           supports_check_mode=False)
    hardware = DarwinHardware(module=module)
    hardware.populate()

    assert hardware.sysctl is not None
    assert type(hardware.sysctl) is dict
    assert hardware.platform == 'Darwin'



# Generated at 2022-06-22 23:03:46.496880
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class MockModule(object):
        def __init__(self):
            self.run_command = mock_run_command
        def exit_json(self, **kwargs):
            pass
        def fail_json(self, **kwargs):
            pass
    class MockHardware(DarwinHardware):
        def __init__(self):
            self.module = MockModule()
    hardware = MockHardware()
    # Command execution fails
    mock_run_command_return_values = [1, 0, 0]
    def mock_run_command(*args, **kwargs):
        return (mock_run_command_return_values.pop(0), '', '')
    assert hardware.get_system_profile() == dict()
    # Command execution succeeds, but wrong data is returned