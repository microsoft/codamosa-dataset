

# Generated at 2022-06-22 22:53:52.032542
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=[0, "", ""])
    module.get_bin_path = MagicMock(return_value="/bin/bash")

# Generated at 2022-06-22 22:53:57.813065
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_instance = DarwinHardware()
    assert hardware_instance.platform == 'Darwin'
    assert hardware_instance.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}
    assert hardware_instance.get_uptime_facts() == {}

# Generated at 2022-06-22 22:54:03.164202
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    mod_args = dict()
    mod_args['module'] = True
    darwin_hwcollector = DarwinHardwareCollector(module=True, facts=dict())
    assert darwin_hwcollector._fact_class is DarwinHardware
    assert darwin_hwcollector._platform is 'Darwin'

# Generated at 2022-06-22 22:54:12.710886
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class ModuleStub(object):
        def __init__(self, args):
            self.args = args

        def run_command(self, command, encoding=None):
            if command[0] == "vm_stat":
                if self.args["vm_stat_output"] is not None:
                    return (0, self.args["vm_stat_output"], "")
                else:
                    return (1, "cmd: vm_stat\nrc: 1\nerr: No such file or directory\n", "")

            if command[0] == "sysctl":
                if self.args["sysctl_output"] is not None:
                    return (0, self.args["sysctl_output"], "")

# Generated at 2022-06-22 22:54:14.416674
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware("module")
    assert hardware.sysctl is None


# Generated at 2022-06-22 22:54:23.261051
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """
    Unit test for method populate of class DarwinHardware.
    """
    module = AnsibleModuleMock()

    hw = DarwinHardware(module=module)
    hw.get_mac_facts = MagicMock(return_value={'a': 1})
    hw.get_cpu_facts = MagicMock(return_value={'b': 2})
    hw.get_memory_facts = MagicMock(return_value={'c': 3})
    hw.get_uptime_facts = MagicMock(return_value={'d': 4})

    hw.populate()

    assert module.exit_json.call_count == 1

# Generated at 2022-06-22 22:54:35.545076
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mock_module = Mock(cache=None)
    mock_module.warn = lambda msg: None

    hardware_module = DarwinHardware(mock_module)

    os_version = 'Mac OS X 10.12.1 (16B2555)'
    os_revision = '16B2555'
    rc, out, err = mock_module.run_command.return_value
    out = os_version

    rc, out, err = mock_module.run_command.return_value
    out = os_revision

    mock_module.run_command.return_value = (rc, out, err)

    sysctl_cmd = hardware_module.module.get_bin_path.return_value
    cmd = [sysctl_cmd, '-n', 'hw.memsize']

    rc, out, err = mock_module

# Generated at 2022-06-22 22:54:43.991416
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import remove_dot_from_keys
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.basic import AnsibleModule

    def make_empty_module():
        module = AnsibleModule(argument_spec={}, supports_check_mode=True)
        module.run_command = lambda *command: (0, b'', b'')
        return module

    # 'kern.boottime': '{ sec = 1515820255, usec = 912881 } Mon Jan 15 17:57:35 2018'
    def make_kern_boottime_module(kern_boottime):
        module = make_empty_module()
        module.run_command

# Generated at 2022-06-22 22:54:54.034172
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert 'Serial Number (system):' in system_profile
    assert 'Processor Name:' in system_profile
    assert 'Processor Speed:' in system_profile
    assert 'L2 Cache (per Core):' in system_profile
    assert 'L3 Cache:' in system_profile
    assert 'Memory:' in system_profile
    assert 'Boot ROM Version:' in system_profile
    assert 'SMC Version (system):' in system_profile
    assert 'OS X' in system_profile

# Generated at 2022-06-22 22:55:02.879162
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    Case 1: When vm_stat doesn't return correctly.
    """
    import platform

    memory_facts = DarwinHardware().get_memory_facts()
    if platform.machine() == "Power Macintosh":
        assert memory_facts == {'memtotal_mb': 256, 'memfree_mb': 0}
    elif platform.machine() == "i386":
        assert memory_facts == {'memtotal_mb': 4096, 'memfree_mb': 0}


# Generated at 2022-06-22 22:55:13.865539
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.six import StringIO

    module = FakeModule()
    hardware = DarwinHardware(module)

    # Test case 1: vm_stat return success with numeric value

# Generated at 2022-06-22 22:55:19.911734
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hw = DarwinHardware()
    sysctl_cmd = darwin_hw.module.get_bin_path('sysctl')

    # Unit test for Darwin uptime_seconds fact
    # This is a unit test for the uptime_seconds fact of class DarwinHardware.
    # Note that this test is only valid at the time of the commit in which this
    # test was added.
    #
    # The test works by calling `sysctl kern.boottime` and parsing its output
    # to get a Python time value for the system's boot time. We then compare it
    # with the current time. This test will require updates as time passes.
    cmd = [sysctl_cmd, 'kern.boottime']
    (rc, out, err) = darwin_hw.module.run_command(cmd, encoding=None)



# Generated at 2022-06-22 22:55:22.002107
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_one = DarwinHardware(dict())
    assert hardware_one.platform == 'Darwin'

# Generated at 2022-06-22 22:55:33.109935
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    dh = DarwinHardware(module)

# Generated at 2022-06-22 22:55:44.999347
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.params = dict()

    test_system_profiler_hardware_data_type = dict()
    test_system_profiler_hardware_data_type['Model Name'] = 'MacBook Pro'
    test_system_profiler_hardware_data_type['Processor Name'] = 'Intel Core i7'
    test_system_profiler_hardware_data_type['Processor Speed'] = '2.2 GHz'

    # Set up the test class and mocks
    test_darwin_hardware = DarwinHardware(test_module)

    test_darwin_hardware.module.get_bin_path = MagicMock(return_value='/usr/sbin/vm_stat')
    test_darwin_hardware.module.run

# Generated at 2022-06-22 22:55:48.802794
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware import DarwinHardware
    obj = DarwinHardware()
    result = obj.get_system_profile()
    assert type(result) is dict
    assert len(result) > 0
    return result

# Generated at 2022-06-22 22:55:59.853906
# Unit test for method get_mac_facts of class DarwinHardware

# Generated at 2022-06-22 22:56:12.518555
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import platform
    fake_module = object()
    fake_module.run_command = lambda *args, **kwargs: (0, '', '')
    fake_module.get_bin_path = lambda *args, **kwargs: '/bin/false'
    fake_module.__dict__ = dict(
        platform=platform.system().lower(),
        sysctl=dict()
    )

    dh = DarwinHardware(fake_module)
    facts = dh.populate()
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'model' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_vcpus' in facts
    assert 'processor_cores' in facts

# Generated at 2022-06-22 22:56:19.923893
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class TestModule(object):
        pass

    module = TestModule()
    module.run_command = lambda cmd: (0, 'machdep.cpu.brand_string: Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz', '')
    hardware = DarwinHardware()
    hardware.module = module

# Generated at 2022-06-22 22:56:29.885441
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    # Create a instance of the DarwinHardware class
    darwin_hardware = DarwinHardware()

    # Create a mock module
    class MockModule:
        def __init__(self):
            self.run_command_calls_count = 0
            self.run_command_calls = []

        def run_command(self, args, encoding=None):

            # vm_stat_command should call run_command once to get the data
            # from the vm_stat command
            self.run_command_calls_count += 1

            # Save the parameters for the first call to run_command
            self.run_command_calls.append({'args': args, 'encoding': encoding})

            # return values for a 1 GB memory system
            rc = 0

# Generated at 2022-06-22 22:56:36.081640
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os

    class TestModule:
        pass

    module = TestModule()
    module.run_command = lambda args: (0, 'Hardware: \n Hardware Overview: \n Model Name: iMac \n Model Identifier: iMac11,1 \n ', '')
    system_profile = DarwinHardware(module).get_system_profile()
    assert system_profile['Model Name'] == 'iMac'
    assert system_profile['Model Identifier'] == 'iMac11,1'

# Generated at 2022-06-22 22:56:46.440084
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    import json
    import sys

    # Load mock data
    with open(sys.path[0] + '/unit/module_utils/facts/hardware/test_DarwinHardware.json') as f:
        mock_data = json.load(f)

    sysctl_mock = mock_data['sysctl']
    hw_system_profile_mock = mock_data['hw_system_profile']

    # Load tested module
    module = ansible.module_utils.facts.hardware.darwin.Hardware()

    # Monkey-patch get_sysctl method
    module.get_sysctl = lambda parameters: sysctl_mock

    # Monkey-patch get_system_profile method
    module.get_system_profile = lambda: hw_system_profile_mock

    # Below are the results that the module should produce
   

# Generated at 2022-06-22 22:56:53.877321
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test case for method get_system_profile of class DarwinHardware
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware(None, None)

    # Test for case: test for method get_system_profile
    # Test for case: does not return empty dict, always returns dict
    ret = hardware.get_system_profile()

    assert ret is not None
    # Test for case: method get_system_profile return dict, contains
    # keys: 'Model Name', 'Model Identifier', 'Processor Name',
    # 'Processor Speed', 'Number of Processors', 'Total Number of Cores',
    # 'L2 Cache (per Core)', 'L3 Cache', 'Memory'
    assert isinstance(ret, dict)
    assert 'Model Name' in ret
   

# Generated at 2022-06-22 22:57:06.362646
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    This method tests the function get_memory_facts of class DarwinHardware.
    """

# Generated at 2022-06-22 22:57:16.961721
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import sys
    if sys.version_info < (2, 7):
        # Test not being run under Python 2.7
        raise AssertionError("This test must be run under Python 2.7 to provide assert_regexp_matches")
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware_fact = DarwinHardware()

    # The output of the function is a dictionary
    system_profile = hardware_fact.get_system_profile()
    assert system_profile != None

    # Each line of the call is split in a key and a value
    # The key is the first part of the line till ": "
    # The value is the rest of the line of the line from ": "
    # The key is trimmed to remove whitespaces on the left and on the right
    # The value is trimmed to remove

# Generated at 2022-06-22 22:57:28.131224
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """ Unit test for method get_memory_facts of class DarwinHardware """
    module = AnsibleModuleFake(
        dict(
            failed=False,
            changed=False,
        )
    )
    hardware = DarwinHardware()
    hardware.module = module

    # Create a fake vm_stat output to test the method
    vm_stat_output = ('VM Statistics:\n'
                      'Pages free:                         8.00.\n'
                      'Pages wired down:                   3.00.\n'
                      'Pages active:                       4.00.\n'
                      'Pages inactive:                     4.00.\n'
                      'Pages occupied by compressor:       7.00.')

    # The number of pages returned by vm_stat should map to the expected value
    # for each type of page.

# Generated at 2022-06-22 22:57:38.194937
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    module.run_command = MagicMock(return_value=(0, 'free: 4993304  \nactive: 5505468  \ninactive: 4725304  \nspeculative: 10204  \nthrottled: 0  \nwired_down: 3049104  \npurgeable: 0  \nfaults: 453750  ', ''))
    hardware.module.run_command = module.run_command
    memory_facts = hardware.get_memory_facts()
    assert memory_facts[u'memtotal_mb'] == (4993304*4)/1024/1024

# Generated at 2022-06-22 22:57:46.319440
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """
    Test get_cpu_facts method of class DarwinHardware
    """
    import platform
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware_obj = DarwinHardware(module)
    hardware_obj.module = module

# Generated at 2022-06-22 22:57:51.260499
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)
    facts = hardware.get_cpu_facts()

    # Test that the keys are in the dictionary
    assert facts['processor_cores'] != ""
    assert facts['processor_vcpus'] != ""
    assert facts['processor'] != ""



# Generated at 2022-06-22 22:57:56.639532
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    os_version = "16.11.0"
    os_revision = "16D32"
    sysctl = get_sysctl({}, ['hw', 'machdep', 'kern'])
    sysctl["kern.osversion"] = os_version
    sysctl["kern.osrevision"] = os_revision
    darwin_hardware = DarwinHardware({"sysctl": sysctl})
    facts = darwin_hardware.populate()
    assert facts["osversion"] == os_version
    assert facts["osrevision"] == os_revision


# Generated at 2022-06-22 22:58:02.973791
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware = DarwinHardware({})
    hardware.sysctl = {
        'hw.model': 'Macmini6,2',
        'kern.osversion': '15.6.0',
        'kern.osrevision': '16G1212'}

    output = hardware.get_mac_facts()
    assert output['model'] == 'Macmini6,2'
    assert output['product_name'] == 'Macmini6,2'
    assert output['osversion'] == '15.6.0'
    assert output['osrevision'] == '16G1212'



# Generated at 2022-06-22 22:58:08.032730
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock({'get_sysctl': {'hw.memsize': 8388608}})
    dhw = DarwinHardware(module)
    assert dhw
    assert dhw.populate() == {'memtotal_mb': 8, 'memfree_mb': 0}

# Generated at 2022-06-22 22:58:16.250357
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    hardware = DarwinHardware(module=module)

    from ansible_collections.ansible.community.tests.unit.plugins.module_utils.facts.collector.system_profiler import SYSTEM_PROFILER_OUTPUT
    hardware.module.run_command = lambda command, **kwargs: (0, SYSTEM_PROFILER_OUTPUT, '')


# Generated at 2022-06-22 22:58:24.728979
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict(data=dict(type='str', required=True)))

    def mock_run_command(module, cmd, check_rc=False, encoding=None):
        if cmd == 'sysctl -n kern.boottime':
            return 0, '1376489568 703308858', ''
        return 0, '', ''

    module.run_command = mock_run_command

    hardware_facts = DarwinHardware(module).populate()
    assert hardware_facts['uptime_seconds'] == 408967

# Generated at 2022-06-22 22:58:32.400176
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    facts = {}
    hardware = DarwinHardware(dict(module=None))
    hardware.populate(facts)
    assert facts['uptime_seconds'] is not None
    assert facts['memtotal_mb'] is not None
    assert facts['memfree_mb'] is not None
    assert facts['processor'] is not None
    assert facts['processor_cores'] is not None
    assert facts['processor_vcpus'] is not None
    assert facts['model'] is not None
    assert facts['osversion'] is not None
    assert facts['osrevision'] is not None

# Generated at 2022-06-22 22:58:40.251200
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    module.run_command = Mock(return_value=(0, '', ''))
    module.run_command = Mock(return_value=(0, 'machdep.cpu.brand_string: Intel(R) Xeon(R) CPU E5-2670 v2 @ 2.50GHz', ''))
    module.run_command = Mock(return_value=(0, 'hw.memsize: 8589934592', ''))

    obj = DarwinHardware()
    result = obj.populate()
    assert result['processor'] == 'Intel(R) Xeon(R) CPU E5-2670 v2 @ 2.50GHz'
    assert result['memtotal_mb'] == 8192


if __name__ == '__main__':
    from collections import namedtuple

# Generated at 2022-06-22 22:58:52.122895
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import mock
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    facts = DarwinHardware({})

    # Test successful path
    with mock.patch('ansible.module_utils.common.process.get_bin_path', return_value='/usr/bin/sysctl'):
        with mock.patch('ansible.module_utils.facts.hardware.darwin.Hardware.run_command', return_value=(0, b'\x00\x00\x00\x00\x01\xD0\xB6\xE6\x00\x00\x00\x00', '')):
            uptime_facts = facts.get_uptime_facts()
            assert uptime_facts == {'uptime_seconds': 88417}

    # Test unsuccessful path

# Generated at 2022-06-22 22:59:02.308789
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-22 22:59:11.476249
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    #Prepare mocked data
    class MockModule:
        def run_command(self, command):
            output = ['page size of 4096 bytes',
                      'Pages wired down:                             23438',
                      'Pages active:                             5367960',
                      'Pages inactive:                            1657851',
                      'Pages free:                                1174936',
                      'Pages purgeable:                                 0']
            return 0, '\n'.join(output), None

    module = MockModule()
    hardware = DarwinHardware(module)
    memory = hardware.get_memory_facts()
    assert memory == {'memtotal_mb': 268435456, 'memfree_mb': 284617}

# Generated at 2022-06-22 22:59:22.715765
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    Test that the get_memory_facts method works correctly by asserting the
    expected values for the instance returned from the method.
    """
    def fake_run_command(command, **kwargs):
        """
        Provides a fake version of the run_command class method to return
        the test content for the plugin to use for analysis.
        """
        return 0, fake_output, b''

    module = AnsibleModuleMock()
    module.run_command = fake_run_command


# Generated at 2022-06-22 22:59:32.846351
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    run_command_run = [
        (0, b'kern.boottime\t{ sec = 1402235471, usec = 537209 } Thu Jul 10 10:44:31 2014\n', ''),
    ]
    module_run_command = [
        (0, b'1420126720\n', ''),
        (0, b'1420126720\n', ''),
        (0, b'1420126720\n', '')
    ]

    darwin_hardware = DarwinHardware()
    darwin_hardware.module = MockModule()
    darwin_hardware.module.run_command = Mock(side_effect=run_command_run)

    uptime_facts = darwin_hardware.get_uptime_facts()

# Generated at 2022-06-22 22:59:40.314005
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    assert hardware.platform == 'Darwin'
    assert hardware.get_memory_facts()['memtotal_mb'] > 0
    assert hardware.get_cpu_facts()['processor']
    assert hardware.get_mac_facts()['osversion']
    assert hardware.get_mac_facts()['osrevision']
    assert not hardware.get_mac_facts()['model']
    assert hardware.get_uptime_facts()['uptime_seconds'] > 0



# Generated at 2022-06-22 22:59:43.971596
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-22 22:59:54.724812
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # initialize a test module
    class TestModule(object):
        def __init__(self):
            self.params = None
            self.run_command_called = 0
            self.command_result = 0
            self.command_output = ""
            self.command_error = ""

        def run_command(self, command, encoding=None):
            self.run_command_called += 1
            return self.command_result, self.command_output, self.command_error

        def get_bin_path(self, name, required=False):
            test_path = './testbin'
            return test_path

    test_module = TestModule()

    # initialize a test DarwinHardware
    darwin_hardware = DarwinHardware(test_module)

    # create a dict for the test result
    expected_result = dict()

# Generated at 2022-06-22 23:00:05.428668
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    system_profiler_output = """
    Hardware:

      Hardware Overview:

        Model Name: Mac Pro
        Model Identifier: MacPro2,1
        Processor Name: Quad-Core Intel Xeon
        Processor Speed: 3.2 GHz
        Number of Processors: 2
        Total Number of Cores: 4
        L2 Cache (per Processor): 8 MB
        Memory: 8 GB
        Bus Speed: 1.33 GHz
        Boot ROM Version: MP21.008C.B07
        SMC Version (system): 1.25f2
        Serial Number (system): G88031203135
        Hardware UUID: 0C36B7B2-F6A8-5DFB-96D4-F1ED4BF11B9A

    """
    hardware = DarwinHardware()
    hardware.module = FakeModule()
    hardware.module.run

# Generated at 2022-06-22 23:00:08.619269
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert isinstance(darwin_hardware_collector, DarwinHardwareCollector)
    assert darwin_hardware_collector.platform == 'Darwin'

# Generated at 2022-06-22 23:00:20.353142
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module_mock = MockAnsibleModule()
    DarwinHardware.module = module_mock
    hardware = DarwinHardware()
    hardware.sysctl = {'hw.memsize': 1073741824}
    memory_facts = hardware.get_memory_facts()
    module_mock.run_command.assert_called_once_with('vm_stat')
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0

from ansible.module_utils.ansible_release import __version__ as ansible_version
if LooseVersion(ansible_version) >= LooseVersion('2.4'):
    from ansible.module_utils.basic import AnsibleModule
else:
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-22 23:00:27.636195
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    m = MockModule()
    hw = DarwinHardware(m)
    hw.sysctl = {'kern.osversion':'15.6.0', 'kern.osrevision':'1222', 'hw.model':'MacPro6,1'}
    facts = hw.get_mac_facts()
    assert facts == {'model': 'MacPro6,1', 'osversion': '15.6.0', 'osrevision': '1222'}


# Generated at 2022-06-22 23:00:39.389376
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        add_file_common_args=True
    )

    if not module._name:
        module._name = 'ansible.module_utils.facts.hardware.darwin'
    facts_collector = collector.get_collector(module, 'hardware')
    facts_collector.populate()
    facts = module.exit_json()
    keys = ['model', 'osversion', 'osrevision', 'memtotal_mb', 'memfree_mb',
            'uptime_seconds', 'processor', 'processor_cores',
            'processor_vcpus']

# Generated at 2022-06-22 23:00:41.890395
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    d = DarwinHardware({}, None)

    assert d.platform == 'Darwin'

# Generated at 2022-06-22 23:00:53.495178
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-22 23:00:55.316566
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """Unit test for method get_system_profile of class DarwinHardware"""
    hardware = DarwinHardware({})
    hardware.get_system_profile()


# Generated at 2022-06-22 23:00:57.011045
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hc = DarwinHardwareCollector()
    assert hc.platform == 'Darwin'

# Generated at 2022-06-22 23:01:08.657588
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    mock_sysctl = dict(
        hw=dict(memsize=33554432, model='MacBookPro8,2'),
        machdep=dict(cpu=dict(brand_string='Intel(R) Core(TM) i5-2540M CPU @ 2.60GHz')),
        kern=dict(osversion='16.6.0', osrevision='191672')
    )

    mm = module_mock(module, dict(
        sysctl=mock_sysctl,
        get_bin_path=MagicMock(return_value='/usr/bin/vm_stat'),
        run_command=MagicMock(return_value=(0, '', '')),
    ))

   

# Generated at 2022-06-22 23:01:21.240989
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.system.base import get_file_content

    module = FakeAnsibleModule()
    obj = DarwinHardware(module)
    module.run_command = MockRun()
    module.run_command.value = (0, get_file_content('./unit/modules/system/fixtures/darwin/vm_stat'), '')
    assert obj.get_memory_facts() == {u'memfree_mb': 1412, u'memtotal_mb': 8192}

    module = FakeAnsibleModule()
    obj = DarwinHardware(module)
    module.run_command = MockRun()

# Generated at 2022-06-22 23:01:33.402286
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-22 23:01:41.145547
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['model'] != ""
    assert hardware_facts['processor_vcpus'] == ""
    assert hardware_facts['memfree_mb'] > hardware_facts['memtotal_mb'] / 2

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    from ansible.module_utils.facts import *
    main()

# Generated at 2022-06-22 23:01:44.172984
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module)

    # returns a dictionary containing CPU facts
    assert hardware.get_cpu_facts()

# Generated at 2022-06-22 23:01:46.166006
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x._fact_class == DarwinHardware
    assert x._platform == 'Darwin'


# Generated at 2022-06-22 23:01:57.627178
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import mock
    import unittest
    import sys

    class MockModule(object):
        params = {}
        def get_bin_path(*args, **kwargs):
            return "/bin/sysctl"

        def run_command(*args, **kwargs):
            return 0, 'kern.boottime: { sec = 1563293558, usec = 247993 }\n', None

    class MockPlatform(object):
        platform = "Darwin"


# Generated at 2022-06-22 23:02:09.891008
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(unittest.TestCase):
        def test_get_uptime_facts_with_seconds(self):
            darwin_hardware = DarwinHardware()
            darwin_hardware.module = lambda: None
            darwin_hardware.module.run_command = lambda cmd, encoding=None: (0, '\x00\x00\xa6\x03\xbe\x1f\x00\x00', '')
            darwin_hardware.module.get_bin_path = lambda binary: '/usr/sbin/sysctl'

            uptime_facts = darwin_hardware.get_uptime_facts()

# Generated at 2022-06-22 23:02:22.633146
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_result = (0, 'Pages free: 1234.\nPages wired down: 5678.\nPages active: 9101112.\nPages inactive: 13141516.\n', '')
        def get_bin_path(self, name):
            return name
        def run_command(self, cmd):
            return self.run_command_result

    mock_module = MockModule()
    dhw = DarwinHardware(mock_module)
    dhw.sysctl = {'hw.memsize': '256000000'} # 256MB
    expected = {
            'memtotal_mb': 256,
            'memfree_mb': 111,
    }
    assert dhw.get_memory_facts

# Generated at 2022-06-22 23:02:24.077840
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()
    assert hardware.platform == 'Darwin'


# Generated at 2022-06-22 23:02:31.888609
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    h = DarwinHardware()

    h.sysctl = {
        'hw.model': 'a model',
        'kern.osversion': 'a version',
        'kern.osrevision': 'a revision',
    }

    (out, err) = h.get_mac_facts()

    assert err == ''
    assert out['model'] == 'a model'
    assert out['osversion'] == 'a version'
    assert out['osrevision'] == 'a revision'


# Generated at 2022-06-22 23:02:43.476002
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    # Test DarwinHardware
    hardware = DarwinHardware()
    hardware.module = None
    hardware.sysctl = {'kern.mach.model': 'MacPro6,1',
                       'kern.mach.version': '17A264c',
                       'kern.maxvnodes': '566666',
                       'kern.osproductversion': '10.13.6',
                       'kern.osrelease': '17G85'}
    hardware.get_mac_facts = lambda: {
        'model': 'MacPro6,1',
        'osversion': '10.13.6',
        'osrevision': '17G85'
    }

# Generated at 2022-06-22 23:02:51.896738
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys

    class MockModule:
        def run_command(self, cmd, encoding=None):
            if cmd == [sys.executable, '-c', 'import time; time.sleep(2)']:
                return 0, '', ''
            else:
                raise AssertionError()

        def get_bin_path(self, cmd):
            return cmd

    test_module = MockModule()

    # We need to call the method twice, so we can compare the second
    # result with the first one, and make sure it is higher.
    first_run = DarwinHardware(test_module).get_uptime_facts()
    second_run = DarwinHardware(test_module).get_uptime_facts()

    if first_run['uptime_seconds'] >= second_run['uptime_seconds']:
        raise AssertionError

# Generated at 2022-06-22 23:02:56.422515
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeAnsibleModule()
    collector = DarwinHardwareCollector(module=module)
    # Test that get_memory_facts method returns a dict with expected keys
    memory_facts = collector.get_memory_facts()
    assert memory_facts.get('memtotal_mb') is not None
    assert memory_facts.get('memfree_mb') is not None


# Generated at 2022-06-22 23:03:03.777296
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.six import StringIO

    # System uptime is 1 week and 3 days
    uptime = 7 * 86400 + 3 * 86400

    # The value is encoded as two 64-bit unsigned integers
    # The two first integers are the seconds of the epoch and the microseconds,
    # we are only interested in the seconds
    boottime = struct.pack('@Q', uptime) + struct.pack('@Q', 0)

    # Pretend the command was successful
    module = MagicMock()
    type(module).run_command = Mock(return_value=(0, boottime, ''))

    hardware = DarwinHardware(module)

    assert hardware.get_uptime_facts() == {'uptime_seconds': uptime}

# Generated at 2022-06-22 23:03:14.394181
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    darwin_hw = DarwinHardware(module)
    darwin_hw.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '15G31'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        model = out.splitlines()[-1].split()[1]
    else:
        model = None
    assert darwin_hw.get_mac_facts() == {'model': model, 'osversion': '15.6.0', 'osrevision': '15G31'}



# Generated at 2022-06-22 23:03:20.659193
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, '', ''))

    hardware_facts_collector = DarwinHardwareCollector(module=module)
    hardware_facts_collector.collect()

    assert hardware_facts_collector._facts['osversion'] == '19.5.0'
    assert hardware_facts_collector._facts['osrevision'] == '17F80'
    assert hardware_facts_collector._facts['memtotal_mb'] == 0

# Generated at 2022-06-22 23:03:30.221828
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '1494358482\n', '')  # Some random value
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = 'system_profiler'

    hardware = DarwinHardware(module=module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts  # Not an empty dict
    assert uptime_facts['uptime_seconds'] == 1494358482

# Generated at 2022-06-22 23:03:39.821317
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    darwin_hw = DarwinHardware(module, sysctl)
    result = darwin_hw.get_cpu_facts()

    assert isinstance(result, dict)
    assert 'processor' in result
    assert isinstance(result['processor'], basestring)
    assert 'processor_cores' in result
    assert isinstance(result['processor_cores'], basestring)
    assert 'processor_vcpus' in result
    assert isinstance(result['processor_vcpus'], basestring)

# Generated at 2022-06-22 23:03:51.641105
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module_mock = MagicMock()
    # Create instance of class DarwinHardware
    dh = DarwinHardware(module_mock)
    cmd_mock = MagicMock()
    # Mock method run_command of class DarwinHardware to return mocked
    # command output
    dh.module.run_command = cmd_mock
    cmd_mock.return_value = (0, vmstat_output, '')
    # Call method to test
    memory_facts = dh.get_memory_facts()
    # Asserts to ensure method ran successfully
    assert(memory_facts['memfree_mb'] == 2604)
    assert(memory_facts['memtotal_mb'] == 16384)
