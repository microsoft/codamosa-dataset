

# Generated at 2022-06-22 22:53:51.706502
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    ansible_module = basic.AnsibleModule(
        argument_spec=dict()
    )
    hardware = DarwinHardware(ansible_module)

    #  mock the system_profiler command
    hardware.module.run_command = MagicMock(return_value=(1, 'Test: Line1\nLine2', ''))
    hardware.get_system_profile() == {}

    hardware.module.run_command = MagicMock(return_value=(1, 'Test: Line1, Line2\n  Line 3', ''))
    hardware.get_system_profile() == {'Test': 'Line1, Line2 Line 3'}


# Generated at 2022-06-22 22:53:56.448248
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    import sys
    sys.path.append('/home/jnguyen/Projects/test_geerlingguy.systeminfo')
    import test_utils
    test_utils.run_unittest(DarwinHardwareCollector)


# Generated at 2022-06-22 22:54:07.705023
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    '''
    Test to see if get_mac_facts function returns expected results for Darwin systems
    '''
    class TestAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, cmd, check_rc=True):
            return 0, 'hw.model: Intel Xeon', ''

    mod = TestAnsibleModule()
    fact_instance = DarwinHardware(module=mod)
    mac_facts = fact_instance.get_mac_facts()
    assert mac_facts['model'] == 'Intel'
    assert mac_facts['osversion'] == med_name[0]
    assert mac_facts['osrevision'] == med_name[1]



# Generated at 2022-06-22 22:54:19.743006
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Unit test for method get_system_profile of class DarwinHardware
    """
    hardware = DarwinHardware({})
    output = """Hardware:

    Hardware Overview:

      Model Name: iMac
      Model Identifier:  iMac14,1
      Processor Name: Intel Core i7
      Processor Speed: 3,2 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 8 MB
      Memory: 16 GB
      Boot ROM Version: IM141.010A.B00
      SMC Version (system): 2.14f4
      Serial Number (system):    C02GBJQZG8WN
      Hardware UUID:    4CE7B9DF-12E0-58D9-804A-D116C878C73D

    """

# Generated at 2022-06-22 22:54:26.025237
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    fact_klass = DarwinHardware

    class ModuleTest(object):
        def __init__(self):
            self.params = {'gather_subset': '!all'}

        def get_bin_path(self, arg):
            return 'sysctl'

        def run_command(self, cmd, encoding):
            return 0, b"kern.boottime: { sec = 1513631368, usec = 740653 } Sat Dec  2 12:09:28 2017\n", None

    test_module = ModuleTest()
    fact_instance = fact_klass(test_module)
    result = fact_instance.get_uptime_facts()

    res_expected = {'uptime_seconds': 581}

    assert result == res_expected


# Generated at 2022-06-22 22:54:28.207454
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
  darwin_hw = DarwinHardware()
  assert darwin_hw.platform == 'Darwin'

# Generated at 2022-06-22 22:54:37.801194
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    mac_facts = DarwinHardware()
    assert isinstance(mac_facts.populate(), dict)
    assert 'processor' in mac_facts.populate()
    assert 'processor_cores' in mac_facts.populate()
    assert 'memtotal_mb' in mac_facts.populate()
    assert 'memfree_mb' in mac_facts.populate()
    assert 'model' in mac_facts.populate()
    assert 'osversion' in mac_facts.populate()
    assert 'osrevision' in mac_facts.populate()
    assert 'uptime_seconds' in mac_facts.populate()



# Generated at 2022-06-22 22:54:51.365610
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    hardware_collector = DarwinHardware(module)
    hardware_collector.get_mac_facts = MagicMock(
        name='get_mac_facts',
        return_value={'osversion': '1.2.3.4.5.6', 'osrevision': '7.8.9.0.1.2', 'model': 'model'}
    )
    hardware_collector.get_cpu_facts = MagicMock(
        name='get_cpu_facts',
        return_value={'processor_cores': '4', 'processor': 'Intel(R) Xeon(R) CPU E5-2676 v3 @ 2.40GHz', 'processor_vcpus': '4'}
    )

# Generated at 2022-06-22 22:54:54.604613
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector.platform == "Darwin"
    assert hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-22 22:55:06.421184
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = type('AnsibleModule', (object,), {"run_command": run_command_mock})()
    hardware = DarwinHardware(module)

    hardware.sysctl['kern.osversion'] = '16.9.0'
    hardware.sysctl['kern.osrevision'] = '16F71'

    mac_facts = hardware.get_mac_facts()

    assert 'model' in mac_facts
    assert mac_facts['model'] == 'MacBookPro12,x'
    assert 'osversion' in mac_facts
    assert mac_facts['osversion'] == '16.9.0'
    assert 'osrevision' in mac_facts
    assert mac_facts['osrevision'] == '16F71'


# Generated at 2022-06-22 22:55:10.362063
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    darwin_hardware = DarwinHardware(module)
    assert darwin_hardware.populate()


# Generated at 2022-06-22 22:55:17.937773
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware import DarwinHardware as UptimeTest
    uut = UptimeTest()

    # Set kern.boottime
    def mock_run_command(self, cmd, encoding=None):
        if cmd == [self.module.get_bin_path('sysctl'), '-b', 'kern.boottime']:
            a = b''
            # On Darwin, the default format is annoying to parse.
            # Use -b to get the raw value and decode it.
            # kern.boottime returns seconds and microseconds as two 64-bits
            # fields, but we are only interested in the first field.
            # time.time() return seconds and microseconds as a float.
            from time import time
            seconds_now = int(time())
            # Fill with zeros the remaining bytes and

# Generated at 2022-06-22 22:55:29.526695
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import shutil
    import tempfile

    # Override the os method in this scope so to get predictable results
    def fake_os_times(self):
        return (0, 12345, 0, 0, 0)

    module = type('FakeModule', (object, ), dict(run_command=lambda self, cmd, encoding=None: (0, '', '')))()

    # Get the current path so to reload the module with our fake module in place
    (fd, test_path) = tempfile.mkstemp(prefix='ansible_test_DarwinHardware_get_uptime_facts')
    orig_path = sys.modules[__name__].__file__
    shutil.copy(orig_path, test_path)

# Generated at 2022-06-22 22:55:37.276526
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time

    dir_unittest_cases = 'lib/ansible/module_utils/facts/hardware/test/unit/'

    class ModuleTest(object):
        def __init__(self):
            self.run_command_args = {}

        def run_command(self, args, encoding=None):
            self.run_command_args['cmd'] = ' '.join(args)
            self.run_command_args['encoding'] = encoding
            with open(dir_unittest_cases + 'test_DarwinHardware_get_uptime_facts.output', 'rb') as f:
                return 0, f.read(), ''

        def get_bin_path(self, executable, required=False):
            return dir_unittest_cases + executable


# Generated at 2022-06-22 22:55:38.126404
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector().get_facts()

# Generated at 2022-06-22 22:55:41.688224
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware=DarwinHardwareCollector()
    assert darwin_hardware.platform == 'Darwin'
    darwin_fact_class=DarwinHardware()
    darwin_hardware.collect()

# Generated at 2022-06-22 22:55:45.932336
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts import unittest_utils
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class LinuxHardwareMock(DarwinHardware):

        def populate(self, *args, **kwargs):
            return {}

    hardware = LinuxHardwareMock(unittest_utils.get_module_mock())
    system_profile = hardware.get_system_profile()
    assert system_profile is not None and len(system_profile) > 0
    assert system_profile['Model Identifier'] == 'MacBookPro11,4'

# Generated at 2022-06-22 22:55:56.840235
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.system.hardware.darwin import DarwinHardware
    instance = DarwinHardware(None)

# Generated at 2022-06-22 22:56:06.415095
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Test case for a Darwin machine (get_memory_facts)
    class TestDarwinHardware:
        def __init__(self, module):
            self.module = module
            self.sysctl = {
                'hw.memsize': 536870912,
                'hw.physicalcpu': 1,
                'hw.ncpu': 1,  # noqa
            }

    class TestDarwinModule:
        def __init__(self):
            self.run_command_args = None
            self.run_command_rc = 0
            self.run_command_out = """
wire: 16
active: 4
inactive: 4
speculative: 4
free: 16
"""

        def run_command(self, command, encoding=None):
            self.run_command_args = command
            return self.run_command

# Generated at 2022-06-22 22:56:09.425792
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # GIVEN

    # WHEN
    darwin_hardware = DarwinHardware()

    # THEN
    assert darwin_hardware is not None

# Generated at 2022-06-22 22:56:17.732264
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    dh = DarwinHardware(module)
    hardware_facts = dh.populate()
    assert hardware_facts['processor'] is not None
    assert hardware_facts['processor_cores'] is not None
    assert hardware_facts['memtotal_mb'] is not None
    assert hardware_facts['memfree_mb'] is not None
    assert hardware_facts['model'] is not None
    assert hardware_facts['osversion'] is not None
    assert hardware_facts['osrevision'] is not None
    assert hardware_facts['uptime_seconds'] is not None


# Generated at 2022-06-22 22:56:21.526203
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    hardware_collector.collect()
    hardware_collector.populate_facts()
    assert hardware_collector.get_facts() is not None

# Generated at 2022-06-22 22:56:30.631505
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    system_profile = DarwinHardware().get_system_profile()

    assert system_profile['Model Identifier'] == 'MacBookAir7,2'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2 GHz'
    assert system_profile['Number of Processors'] == '1'
    assert system_profile['Total Number of Cores'] == '2'
    assert system_profile['L2 Cache (per Core)'] == '256 KB'
    assert system_profile['L3 Cache'] == '4 MB'
    assert system_profile['Memory'] == '8 GB'
    assert system_profile['Boot ROM Version'] == '1037.60.37.0.0 (iBridge: 17.16.1037.60.0.0,0)'
    assert system_profile

# Generated at 2022-06-22 22:56:40.880320
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # example output of system_profiler SPHardwareDataType
    system_profile_output = """
Hardware Overview:

  Model Name: iMac
  Model Identifier: iMac10,1
  Processor Name: Intel Core 2 Duo
  Processor Speed: 3.06 GHz
  Number of Processors: 1
  Total Number of Cores: 2
  L2 Cache: 6 MB
  Memory: 4 GB
  Bus Speed: 1.07 GHz
  Boot ROM Version: IM101.00CC.B00
  SMC Version (system): 1.58f17
  Serial Number (system): W8906E6R5U5
  Hardware UUID: 00000000-0000-1000-8000-0017F13FD6D5

"""
    hardware = DarwinHardware()
    system_profile = hardware.get_system_profile()

# Generated at 2022-06-22 22:56:43.314871
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Constructor
    obj = DarwinHardwareCollector()
    assert obj._fact_class is DarwinHardware
    assert obj._platform == 'Darwin'

# Generated at 2022-06-22 22:56:51.567122
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Test data
    vm_stat_input = """
Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                            16670.
Pages active:                          209280.
Pages inactive:                        117828.
Pages speculative:                     8008.
Pages wired down:                      185916.
"""

    expected_memory_facts = {
        'memtotal_mb': 524288,
        'memfree_mb': 10,
    }

    module = FakeAnsibleModule()
    dh = DarwinHardware(module)
    dh.module.run_command = fake_run_command(0, vm_stat_input, None)
    memory_facts = dh.get_memory_facts()
    assert memory_facts == expected_memory_facts

# Generated at 2022-06-22 22:56:52.298615
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    HardwareCollector()


# Generated at 2022-06-22 22:57:02.203155
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    raw_facts = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz'
    }
    h = DarwinHardware(dict(), raw_facts)
    cpu_facts = h.get_cpu_facts()
    assert len(cpu_facts) == 3, "Invalid number of CPU facts returned"
    assert cpu_facts['processor'] == raw_facts['machdep.cpu.brand_string'], "Mismatched processor fact"
    assert cpu_facts['processor_cores'] == h.sysctl['machdep.cpu.core_count'], "Mismatched processor_cores fact"

# Generated at 2022-06-22 22:57:05.222894
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    data = DarwinHardware()
    assert isinstance(data.platform, str)
    assert isinstance(data.sysctl, dict)

# Generated at 2022-06-22 22:57:07.496755
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_get_system_profile = DarwinHardware(None).get_system_profile()
    assert 'Serial Number (system)' in test_get_system_profile

# Generated at 2022-06-22 22:57:09.609404
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    facts = DarwinHardware(module)
    assert facts.populate()

# Generated at 2022-06-22 22:57:14.493705
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class DarwinHardware
    """
    darwin_obj = DarwinHardware()
    darwin_obj_get_memory_facts = darwin_obj.get_memory_facts()
    assert darwin_obj_get_memory_facts['memtotal_mb'] > 0

# Generated at 2022-06-22 22:57:17.934239
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    for fact in ('model', 'processor', 'processor_cores', 'processor_vcpus', 'memtotal_mb', 'memfree_mb', 'osversion', 'osrevision', 'uptime_seconds'):
        assert fact in hardware.populate()



# Generated at 2022-06-22 22:57:20.296836
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardwareCollector = DarwinHardwareCollector()
    assert hardwareCollector._platform == 'Darwin'

# Generated at 2022-06-22 22:57:31.548471
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Test get_mac_facts method of class DarwinHardware
    """
    from ansible.module_utils.facts.system.darwin import DarwinHardware
    from ansible.module_utils.facts.collector import BaseFactCollector

    class TestDarwinHardware(DarwinHardware):
        def __init__(self, module):
            pass

        def _run_command(self, command):
            return 0, "hw.model: iMac14,2\nhw.machine: x86_64\nkern.osversion: 14.0.0\nkern.osrevision: 14.0.0", ""

        def _load_managers(self):
            return dict()

    obj = TestDarwinHardware(BaseFactCollector())
    res = obj.get_mac_facts()

# Generated at 2022-06-22 22:57:38.852562
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-22 22:57:50.417676
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = Mock(return_value=(0, "hw.model: MacBookAir\n", ""))

    darwin_hardware = DarwinHardware(module)
    module.sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    module.sysctl['machdep.cpu.brand_string'] = 'Intel Core i5-5250U'
    module.sysctl['machdep.cpu.core_count'] = 2
    module.sysctl['kern.osversion'] = '15.6.0'
    module.sysctl['kern.osrevision'] = '16G1712'
    mac_facts = darwin_hardware.get_mac_facts()


# Generated at 2022-06-22 22:57:57.047870
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(dict())
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor_cores'] == '2'
    assert facts['memtotal_mb'] == '4096'
    assert facts['memfree_mb'] > 0
    assert facts['model'] == 'MacBookPro12,1'
    assert facts['osversion'] == '16.0.0'


# Generated at 2022-06-22 22:58:08.259972
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mod = AnsibleModule(argument_spec=dict())
    darwin_hardware = DarwinHardware(mod)

    # Failure
    mod.run_command.return_value = (1, "", "")
    result = darwin_hardware.get_mac_facts()
    assert result == {'osversion': '', 'osrevision': ''}

    # Success
    mod.run_command.return_value = (0, "model: MacBookPro10,1", "")
    darwin_hardware.sysctl['kern.osversion'] = "15.1.0"
    darwin_hardware.sysctl['kern.osrevision'] = "623.1.1"
    result = darwin_hardware.get_mac_facts()

# Generated at 2022-06-22 22:58:21.115174
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test with a system that has Intel CPU
    class DarwinHardwareIsIntel(DarwinHardware):
        sysctl = {
            'hw.memsize': '1',
            'machdep.cpu.brand_string': 'Intel',
            'machdep.cpu.core_count': '4',
        }

    class Module(object):
        def __init__(self):
            self.run_command_results = [
                [0, 'Pages wired down: 788', None],
                [0, 'Pages active: 788', None],
                [0, 'Pages inactive: 788', None],
            ]
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop()

# Generated at 2022-06-22 22:58:31.881919
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    class FakeModule(object):
        def __init__(self, sysctl):
            self.sysctl = sysctl

    # test Intel CPU
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2660 v2 @ 2.20GHz',
        'machdep.cpu.core_count': 2,
    }
    expected_cpu_facts = {
        'processor': sysctl['machdep.cpu.brand_string'],
        'processor_cores': sysctl['machdep.cpu.core_count'],
        'processor_vcpus': '',
    }
    module = FakeModule(sysctl)
    hardware = DarwinHardware()
    hardware.module = module

    cpu_facts = hardware.get_cpu_facts()


# Generated at 2022-06-22 22:58:38.221866
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware_facts = DarwinHardware(None)
    sysctl = get_sysctl(None, ['hw', 'machdep', 'kern'])
    hardware_facts.sysctl = sysctl

    memory_facts = hardware_facts.get_memory_facts()
    assert(memory_facts['memtotal_mb'] == 4096)
    assert(memory_facts['memfree_mb'] == 4096)

# Generated at 2022-06-22 22:58:50.553715
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import os
    import unittest

    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.test_darwin_hardware = DarwinHardware(dict(), dict())

        def test_get_cpu_facts(self):
            if os.popen("sysctl -n machdep.cpu.core_count").read().rstrip() == "1":
                # Only 1 core is available
                cpu_facts = {
                    'processor_cores': '1',
                    'processor': 'Genuine Intel(R) CPU T2400  @ 1.83GHz',
                    'processor_vcpus': '1'}

# Generated at 2022-06-22 22:58:53.191178
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import platform

    mac_facts = DarwinHardware(dict(), platform.system()).get_system_profile()
    assert 'Serial Number (system)' in mac_facts

# Generated at 2022-06-22 22:59:03.145946
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # When sysctl returns a non-zero exit code, return an empty dictionary.
    m = Mock(return_value=(1, '', ''))
    with patch.dict('sys.modules', {'ansible.module_utils.common.process': m}):
        assert DarwinHardware().get_uptime_facts() == {}

    # Test case where kern.boottime does not return a 64-bit field.
    m = Mock(return_value=(0, '', ''))
    with patch.dict('sys.modules', {'ansible.module_utils.common.process': m}):
        assert DarwinHardware().get_uptime_facts() == {}

    # Test case where sysctl returns kern.boottime between 0 and 2^32-1 seconds.

# Generated at 2022-06-22 22:59:11.995929
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    '''
    Test method populate of class DarwinHardware for valid and invalid data
    '''

    # Valid data

# Generated at 2022-06-22 22:59:14.163898
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()
    assert hardware.platform == 'Darwin'
    assert hardware.sysctl == dict()

# Generated at 2022-06-22 22:59:22.227539
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import os
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    module = type('test_object', (object,), {'get_bin_path': os.path.basename})
    obj = DarwinHardware(module)
    obj.module.run_command = lambda x: (0, b'Sec  BootTime\nkern.boottime: { sec = 1578652046.0, usec = 718889 }\n', None)
    assert obj.get_uptime_facts()['uptime_seconds'] == 62042

# Generated at 2022-06-22 22:59:31.489221
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    out = """Hardware:
    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro6,2
      Processor Name: Intel Core i7
      Processor Speed: 2.8 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 8 MB
      Memory: 8 GB
      Boot ROM Version: MBP61.0057.B0C
      SMC Version (system): 1.58f17
      Serial Number (system): C02G79A5DB7H
      Hardware UUID: 00000000-0000-1000-8000-0017F20A5DB7
      Sudden Motion Sensor:
      State:    Enabled
    """

# Generated at 2022-06-22 22:59:36.190596
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import mock
    import tempfile

    module = mock.MagicMock()
    module.run_command.return_value = (0, '1000000000', '')
    module.get_bin_path.return_value = '/usr/sbin/sysctl'

    dh = DarwinHardware(module)

    uptime_facts = dh.get_uptime_facts()
    boottime = uptime_facts['uptime_seconds']

    # Check the result is valid
    assert isinstance(boottime, int)

    # Check the result is as expected
    assert int(time.time()) - boottime == 1000000000



# Generated at 2022-06-22 22:59:39.234521
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    collector = DarwinHardwareCollector()

    # Happy path
    darwin_hardware = DarwinHardware(collector, module=None)
    system_profile = darwin_hardware.get_system_profile()
    assert 'Machine Name:' in system_profile
    assert system_profile['Machine Name:'] != ''

# Generated at 2022-06-22 22:59:51.120983
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    output = {'hw.machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-2675QM CPU @ 2.20GHz', 'hw.logicalcpu': '8', 'hw.memsize': '4294967296', 'hw.cputype': '7', 'hw.physicalcpu': '2', 'hw.cpufrequency': '2176469363', 'hw.ncpu': '4'}
    sysctl = get_sysctl(None, ['hw', 'machdep', 'kern'], output)
    hardware = DarwinHardware(None, sysctl=sysctl)
    assert hardware.get_cpu_facts()['processor'] == 'Intel(R) Core(TM) i7-2675QM CPU @ 2.20GHz'



# Generated at 2022-06-22 22:59:58.504460
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl
    facts = Facts()
    hw = DarwinHardware(module=None)

    sysctl = get_sysctl(hw.module, ['hw', 'machdep', 'kern'])
    sysctl['kern.osversion'] = '10.12.6'
    sysctl['kern.osrevision'] = '16G29'

    hw.sysctl = sysctl

    # Test DarwinHardware.get_mac_facts() with a brand_string

# Generated at 2022-06-22 23:00:07.873800
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    d_hw = DarwinHardware(module=None)
    rc, out, err = d_hw.module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    if rc != 0:
        return dict()
    system_profile = dict()
    for line in out.splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)
            system_profile[key.strip()] = ' '.join(value.strip().split())
    return system_profile

if __name__ == '__main__':
    test_DarwinHardware_get_system_profile()

# Generated at 2022-06-22 23:00:10.705745
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():

    mac_facts = DarwinHardware()
    mac_facts.module = False
    mac_facts.get_system_profile()

# Generated at 2022-06-22 23:00:20.982433
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    testmod = {
        "module": MockModule(),
        "module_utils": {
            "common": {
                "process": {
                    "get_bin_path": MockGetBinPathFunction(),
                    "fetch_file": MockFetchFileFunction(),
                }
            }
        }
    }

    def run_command(cmd, *args, **kwargs):
        return (0, "sysctl hw.model:\nhw.model: MacBookPro8,1\n", None)

    testmod["module"].run_command = run_command

    darwin = DarwinHardware(module=testmod["module"],
                            module_utils=testmod["module_utils"]["common"]["process"])

# Generated at 2022-06-22 23:00:30.582550
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()

# Generated at 2022-06-22 23:00:41.030749
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class FakeModule():
        """
        Fake module used to test get_system_profile function.
        """
        pass

    module = FakeModule()
    module.run_command = lambda cmd: (0, fake_system_profiler, "")

    darwinHardware = DarwinHardware(module)
    system_profile = darwinHardware.get_system_profile()


# Generated at 2022-06-22 23:00:53.139386
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    m = AnsibleModuleMock()
    # Mock factfile has the following output for hw.model:
    # 'hw.model: MacBook5,1'
    # Mock factfile has the following output for kern.osversion:
    # 'kern.osversion: 13.5.0'
    # Mock factfile has the following output for kern.osrevision:
    # 'kern.osrevision: 1'
    # Mock factfile has the following output for machdep.cpu.brand_string:
    # 'machdep.cpu.brand_string: Intel(R) Core(TM) i7-3720QM CPU @ 2.60GHz'
    # Mock factfile has the following output for machdep.cpu.core_count:
    # 'machdep.cpu.core_count: 4'
    # Mock fact

# Generated at 2022-06-22 23:01:05.646714
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a fake module (with a fake run_command method) to test the
    # DarwinHardware class.
    sysctl_cmd = '/usr/sbin/sysctl'
    raw_output = b'\xfe\xff\xff\xff\x00\x00\x00\x00'

    class FakeModule(object):
        @staticmethod
        def get_bin_path(binary):
            assert binary == 'sysctl'
            return sysctl_cmd

        @staticmethod
        def run_command(cmd, encoding=None):
            assert cmd == [sysctl_cmd, '-b', 'kern.boottime']
            assert encoding is None
            return (0, raw_output, None)

    class FakeHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

   

# Generated at 2022-06-22 23:01:18.425296
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    class Hardware:
        def __init__(self):
            self.sysctl = {}
    hardware_obj = Hardware()

    # Test case #1: Intel Processor
    hardware_obj.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-2557M CPU @ 1.70GHz',
                           'machdep.cpu.core_count': '2'}
    cpu_facts = DarwinHardware(module, hardware_obj).get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-2557M CPU @ 1.70GHz'
    assert cpu_facts['processor_cores'] == '2'

    # Test case #2: PowerPC Processor

# Generated at 2022-06-22 23:01:26.431858
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_inputs = ['Pages wired down:                 38272.',
                   'Pages active:                    164907.',
                   'Pages inactive:                    3800.',
                   'Translation faults:           163060783.',
                   'Pages copy-on-write:            1521273.',
                   'Pages zero filled:            132977301.',
                   'Pages reactivated:                10769.',
                   'Pageins:                        1386548.',
                   'Pageouts:                        246477.',
                   'Object cache:                    949446 hits of 6068209 lookups (16% hit rate)']
    test_fact = DarwinHardware()
    memtotal_mb = test_fact.get_memory_facts()['memtotal_mb']
    assert memtotal_mb > 0

# Generated at 2022-06-22 23:01:30.109392
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """Tests for getting facts about processor and operating system"""

    # Test for i386 architecture
    # Test for x86_64 architecture
    # Test for ppc architecture



# Generated at 2022-06-22 23:01:41.456719
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware_class = DarwinHardware()
    test_results = {
        'memtotal_mb': 1024,
        'memfree_mb': 126
    }

    # This is the vm_stat output that was observed from a macOS 10.13 system.
    # This is just a static sample output from one system.
    # The output may be different on different systems, so any tests
    # will be relying somewhat on the output from this sample system.
    vm_stat_command = "/usr/bin/vm_stat"

# Generated at 2022-06-22 23:01:51.128857
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test with Intel
    sysctl = dict()
    sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i7-5775R CPU @ 3.30GHz'
    sysctl['machdep.cpu.core_count'] = 4
    sysctl['machdep.cpu.logical_per_package'] = 8
    sysctl['machdep.cpu.thread_count'] = 8
    hardware = DarwinHardware(dict(module=dict(), sysctl=sysctl))
    res = hardware.get_cpu_facts()
    assert 'Intel(R) Core(TM) i7-5775R CPU @ 3.30GHz' == res['processor']
    assert 8 == res['processor_vcpus']
    assert 4 == res['processor_cores']

    # Test with PowerPC
   

# Generated at 2022-06-22 23:01:53.860730
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_facts = DarwinHardware({})
    assert hardware_facts.platform == 'Darwin'
    assert hardware_facts.populate()['osversion'].startswith('Darwin Kernel')


# Generated at 2022-06-22 23:02:02.308800
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    sysctl_dict = {'hw.memsize': '4294967296'}
    module = FakeModule(sysctl=sysctl_dict)
    hardware_facts = DarwinHardware(module=module)


# Generated at 2022-06-22 23:02:05.121323
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    dh = DarwinHardware({})
    boottime = dh.get_uptime_facts()['uptime_seconds']
    now = time.time()

    # The time must not have drifted too far away, just
    # to validate we are working with the right value.
    assert int(now - boottime) < 3600

# Generated at 2022-06-22 23:02:07.893208
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware = DarwinHardwareCollector()
    assert hardware
    assert hardware.platform == 'Darwin'
    assert hardware._fact_class == DarwinHardware


# Generated at 2022-06-22 23:02:09.461691
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware(dict())
    assert hardware.platform == 'Darwin'

# Generated at 2022-06-22 23:02:13.913369
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, 'hw.model: MacPro4,1\n', ''))
    darwin_hardware = DarwinHardware(module)

    result = darwin_hardware.get_mac_facts()
    assert result == {'model': 'MacPro4,1', 'osversion': '', 'osrevision': ''}



# Generated at 2022-06-22 23:02:17.515820
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware(dict())

    assert hardware.platform == 'Darwin'
    assert hardware.sysctl is None
    assert hardware.module is None


# Generated at 2022-06-22 23:02:27.143829
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    test_module = AnsibleModule(argument_spec={})
    test_hardware = DarwinHardware(module=test_module, collected_facts=dict())
    test_hardware.sysctl = {
        ('kern.osversion'): '16.7.0',
        ('kern.osrevision'): '19H2',
        ('hw.memsize'): '17179869184',
        ('hw.machdep.cpu.brand_string'): 'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz',
        ('machdep.cpu.core_count'): '8',
        ('hw.physicalcpu_max'): '8',
        ('hw.logicalcpu_max'): '8'
    }
    result = test_hardware.get_uptime_facts

# Generated at 2022-06-22 23:02:33.649258
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """Test DarwinHardwareCollector constructor"""
    module = AnsibleModuleMock()
    darwin_hardware_collector = DarwinHardwareCollector(module)
    assert darwin_hardware_collector
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class.platform == 'Darwin'


# Generated at 2022-06-22 23:02:44.887504
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    class FakeModule:
        def __init__(self):
            self.run_command = lambda x: (0, "machdep.cpu.core_count: 8", None)
            self.get_bin_path = lambda x: "vm_stat"
        def fail_json(self, **kwargs):
            pass

    class FakeSysctl:
        def __init__(self):
            self.sysctl = {}
            self.sysctl['hw.memsize'] = 17179869184
            self.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i7-5557U CPU @ 3.10GHz'
            self.sysctl['kern.osversion'] = '15.3.0'

# Generated at 2022-06-22 23:02:47.419204
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    Test DarwinHardwareCollector constructor
    """
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-22 23:02:57.069229
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    command_runner = CommandRunner(module)
    darwin_hardware = DarwinHardware(module, command_runner)
    vm_stat_command_success = CommandResultWrapper(0,
                                                   """Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                              4569.
Pages active:                           27225.
Pages inactive:                         13591.
Pages speculative:                        477.
Pages wired down:                       12619.
Pages purgeable:                          558.
""", "")
    vm_stat_command_failure = CommandResultWrapper(-1, "", "")
    command_runner.add_command_result('vm_stat', vm_stat_command_success)
    memory_facts_success = darwin_hardware.get_memory_

# Generated at 2022-06-22 23:03:04.351204
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    assert dict(
        model='MacBookAir5,2',
        osversion='Darwin Kernel Version 15.2.0: Fri Nov 13 19:56:56 PST 2015; root:xnu-3248.10.71~1/RELEASE_X86_64',
        osrevision='15C50',
        processor='Intel(R) Core(TM) i7-3667U CPU @ 2.00GHz',
        processor_cores='2',
        processor_vcpus='4',
        memtotal_mb=8192,
        memfree_mb=3882,
        uptime_seconds=220178
    ).items() <= hardware.get_facts().items()



# Generated at 2022-06-22 23:03:16.526756
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    facts = DarwinHardwareCollector().collect()

# Generated at 2022-06-22 23:03:19.169967
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector.platform == 'Darwin'
    assert issubclass(hardware_collector.fact_class, Hardware)

# Generated at 2022-06-22 23:03:31.355719
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import sys
    import tempfile

    # Make sure that we have a clean environment
    env = dict()
    env.update(os.environ)
    if 'ANSIBLE_UNIT_TESTING' in env:
        del env['ANSIBLE_UNIT_TESTING']

    # Make sure that the test is atomic
    temp_cwd = tempfile.mkdtemp()

# Generated at 2022-06-22 23:03:37.570749
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    obj = DarwinHardware({'ansible_facts': {'module_hw_facts': {'darwin': {'sysctl': {'kern.osversion': '15.6.0'}}}}})
    assert obj.get_mac_facts() == {'osversion': '15.6.0', 'osrevision': ''}


# Generated at 2022-06-22 23:03:45.882091
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    sysctl_value = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6600U CPU @ 2.60GHz',
        'machdep.cpu.core_count': 2,
    }
    hardware = DarwinHardware({"name": "darwinhardware", "sysctl": sysctl_value})
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_vcpus'] == ''
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-6600U CPU @ 2.60GHz'

