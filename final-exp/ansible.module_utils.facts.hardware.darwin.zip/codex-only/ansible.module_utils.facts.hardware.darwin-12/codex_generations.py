

# Generated at 2022-06-22 22:53:51.764070
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Arrange
    test_processor_cores = '2'
    test_processor_vcpus = '2'
    test_processor = 'Intel(R) Core(TM) i7-4578U CPU @ 3.00GHz'
    test_dict = {
        'machdep.cpu.core_count': test_processor_cores,
        'hw.logicalcpu': test_processor_vcpus,
        'machdep.cpu.brand_string': test_processor,
    }
    this = DarwinHardware(dict())
    this.sysctl = test_dict

    # Act
    actual = this.get_cpu_facts()

    # Assert

# Generated at 2022-06-22 22:54:00.465744
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import os
    import tempfile
    import unittest

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'

        def run_command(self, args, encoding=None):
            class Raw():
                pass

            outobj = Raw()
            outobj.returncode = 0
            outobj.stderr = ''

            # Fake the sysctl output
            tfd, file_path = tempfile.mkstemp()
            os.write(tfd, b'\x00\x00\x00\x00\x00\x00\x00\xd5\x00\x00\x00\x00\x00\x00\x00\x04\x00')


# Generated at 2022-06-22 22:54:07.028572
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    system_profile = DarwinHardware().get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.7 GHz'
    assert system_profile['L2 Cache'] == '256 KB'
    assert system_profile['Memory'] == '16 GB'

# Generated at 2022-06-22 22:54:19.438438
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = type('MockModule', (), {'run_command': run_command})()
    hardware = DarwinHardware(module)

    vm_stat_calls = []

# Generated at 2022-06-22 22:54:30.528835
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-22 22:54:41.538617
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware(None)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Genuine Intel(R) CPU',
                       'machdep.cpu.core_count': '2',
                       'hw.physicalcpu': '2',
                       'hw.logicalcpu': '4'
                      }
    assert hardware.get_cpu_facts() == {'processor': 'Genuine Intel(R) CPU',
                                        'processor_cores': '2',
                                        'processor_vcpus': '4'}

    hardware.sysctl = {'hw.cputype': '7',
                       'hw.cpusubtype': '8',
                       'hw.physicalcpu': '2',
                       'hw.logicalcpu': '4'
                      }

# Generated at 2022-06-22 22:54:45.309367
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwinCollector = DarwinHardwareCollector()
    assert isinstance(darwinCollector, HardwareCollector)
    assert darwinCollector._platform == 'Darwin'


# Generated at 2022-06-22 22:54:56.999711
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # generic command to get output of vm_stat command
    class RunCommand:
        def __init__(self, out, rc=0):
            self.out = out
            self.rc = rc

        def run_command(self, temp):
            return self.rc, self.out, ''

    class AnsibleModule:
        def __init__(self, out, rc=0):
            self.run_command = RunCommand(out, rc)

    # if the ouput of vm_stat is empty or the command failed, default values are set
    hw = DarwinHardware(AnsibleModule("", rc=1))
    assert hw.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}

    hw = DarwinHardware(AnsibleModule(""))
    assert hw.get

# Generated at 2022-06-22 22:55:00.067786
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_mgr = DarwinHardware(dict(), dict())
    assert hardware_mgr.platform == 'Darwin'


# Generated at 2022-06-22 22:55:11.798861
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware({})

    hardware_sysctl_mock = { 'machdep.cpu.core_count': '99', 'machdep.cpu.brand_string': 'foo' }
    hardware.sysctl = hardware_sysctl_mock
    assert hardware.get_cpu_facts() == {'processor': 'foo', 'processor_cores': '99', 'processor_vcpus': ''}

    hardware_sysctl_mock = { 'hw.ncpu': '99', 'hw.physicalcpu': '9' }
    hardware.sysctl = hardware_sysctl_mock
    assert hardware.get_cpu_facts() == {'processor': '', 'processor_cores': '9', 'processor_vcpus': '99'}


# Generated at 2022-06-22 22:55:25.156073
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import ansible.module_utils.facts.hardware.darwin
    # Create mock sysctl command
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []

        def run_command(self, args, encoding=None):
            self.run_command_results.append((args, encoding))
            return (0, b'kern.boottime: 973294508 0\n', None)

        def get_bin_path(self, cmd):
            return '/usr/bin/sysctl'

    module = MockModule()

    # Create instance of DarwinHardware
    dh = ansible.module_utils.facts.hardware.darwin.DarwinHardware(module)

    # Call tested method
    uptime_facts = dh.get_uptime_facts()

    # Check the

# Generated at 2022-06-22 22:55:36.347019
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible_collections.community.general.tests.unit.compat.mock import MagicMock, patch

    module = MagicMock()
    hardware_facts = DarwinHardware(module)

    hardware_facts.sysctl = {'kern.osversion': '19.6.0',
                             'kern.osrevision': '1510',
                             'hw.memsize': 16777216,
                             'hw.model': 'MacBookAir7,2',
                             'machdep.cpu.brand_string': 'Intel Core i7-5650U CPU @ 2.20GHz',
                             'machdep.cpu.core_count': 2,
                             'hw.ncpu': 4}

    vm_stat_mock = MagicMock()

# Generated at 2022-06-22 22:55:42.855026
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mock_module = type('AnsibleModule', (object,), {'run_command': MagicMock(return_value=(0, 'hw.model: MacBookPro5,5\n', ''))})
    module = mock_module()
    hardware = DarwinHardware(module)
    mac_facts = hardware.get_mac_facts()
    assert mac_facts == {'model': 'MacBookPro5,5', 'osversion': '', 'osrevision': ''}


# Generated at 2022-06-22 22:55:52.596517
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Simulate a bytes output that returns epoch.
    epoch = int(time.time())
    out = b''.join([struct.pack('@L', epoch), b'\x00\x00\x00\x00\x00\x00'])

    # Simulate a bytes output that returns too few bytes.
    small_out = b'\x00\x00\x00\x00'

    # Simulate a bytes output that returns zero epoch.
    zero_out = b''.join([struct.pack('@L', 0), b'\x00\x00\x00\x00\x00\x00'])

    # Simulate a bytes output that returns an error.
    error_out = b'Something went wrong\n'

    # We need to patch the module to return the output we are expecting for the test.

# Generated at 2022-06-22 22:55:54.416910
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert isinstance(collector, DarwinHardwareCollector)
    assert isinstance(collector._fact_class, type)

# Generated at 2022-06-22 22:56:04.619866
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {'gather_subset': 'all'}

        def run_command(self, args, check_rc=True, envs=None):
            module = MockModule()
            vm_stat_command = get_bin_path('vm_stat')

# Generated at 2022-06-22 22:56:08.592145
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeModule()
    facts = DarwinHardware(module).get_mac_facts()
    assert facts['model'] is not None
    assert facts['osversion'] is not None
    assert facts['osrevision'] is not None


# Generated at 2022-06-22 22:56:17.000797
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import mock
    module = mock.MagicMock(spec=['get_bin_path', 'run_command'])
    module.run_command.return_value = 0, b'{ sec = 1452851594, usec =  589097 }', ''
    module.get_bin_path.return_value = '/bin/sysctl'

    hardware = DarwinHardware()
    hardware.module = module
    hardware.get_uptime_facts()
    result = hardware.module.run_command.call_args[0][0]
    assert result == ['sysctl', '-b', 'kern.boottime']

# Generated at 2022-06-22 22:56:20.657622
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    f = DarwinHardwareCollector()
    assert isinstance(f, DarwinHardwareCollector)
    assert f._platform == "Darwin"
    assert f._fact_class == DarwinHardware

# Unit tests for DarwinHardware class

# Generated at 2022-06-22 22:56:30.256004
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    result = {
        'Pages active': 2123,
        'Pages inactive': 3543,
        'Pages wired down': 2535,
    }
    fake_module = FakeModule(openssl_cmd='/usr/bin/openssl')
    fake_module.run_command = lambda cmd: ['', '', '']

    darwin_hardware = DarwinHardware(fake_module)
    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['memfree_mb'] == 0

    # For speed this is a string and not a method, so we have to create a new
    # instance of the class.
    darwin_hardware = DarwinHardware(fake_module)

# Generated at 2022-06-22 22:56:39.726608
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a test DarwinHardware class
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    mac = DarwinHardware(dict())
    test_input = '{ sec = 1461899455, usec = 769485 }'
    expected_output = {'uptime_seconds': 1461899455}
    # Define function to be tested
    tested_function = mac.get_uptime_facts
    # Set the value of the kern.boottime sysctl key
    mac.sysctl['kern.boottime'] = test_input
    # Run the method get_uptime_facts
    output = tested_function()
    # Check if output is equal to expected_output
    assert output == expected_output

# Generated at 2022-06-22 22:56:42.527113
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector(dict())
    assert collector.platform == 'Darwin'
    assert collector.fact_class == DarwinHardware
    assert collector.config is not None


# Generated at 2022-06-22 22:56:44.787592
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_collector = DarwinHardwareCollector()
    assert darwin_collector.platform == 'Darwin'
    assert darwin_collector.fact_class._platform == 'Darwin'

# Generated at 2022-06-22 22:56:52.815269
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    Hardware.module = None
    MacFacts = DarwinHardware()
    MacFacts.sysctl = {'kern.osversion': '16.6.0', 'kern.osrevision': '1.0.0'}
    rc, out, err = MacFacts.module.run_command("sysctl hw.model")
    MacFacts.sysctl['hw.model'] = out.splitlines()[-1].split()[1]

    rc, out, err = MacFacts.module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    system_profile = dict()
    for line in out.splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)
            system_profile[key.strip()]

# Generated at 2022-06-22 22:57:02.454112
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    module.sysctl = {}

    hardware = DarwinHardware(module)
    results = hardware.populate()
    assert type(results) is dict

    assert 'model' in results
    assert 'osversion' in results
    assert 'osrevision' in results
    assert 'processor' in results
    assert 'processor_cores' in results
    assert 'processor_vcpus' in results
    assert 'memtotal_mb' in results
    assert 'memfree_mb' in results
    assert 'uptime_seconds' in results

# Generated at 2022-06-22 22:57:06.120275
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Ensure that the constructor is doing nothing substantial and doesn't depend on any external functions
    obj = DarwinHardwareCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinHardware


# Generated at 2022-06-22 22:57:16.407038
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # kern.boottime was 1583567695 on a test macOS
    # machine.
    facts = {'kern.boottime': '\xce6\x00\x00\x00\x9e\xd3*\x00\x00\x00\x00\x00\x00'}
    # On Unix, time.time() returns a float.
    expected_uptime_seconds = int(time.time() - 1583567695)
    # Avoid unit testing the imprecision of time(). Approximate it by
    # asserting that the calculated uptime is no more than 1 second away from
    # the expected uptime.
    assert abs(DarwinHardware(module=None).get_uptime_facts()['uptime_seconds'] - expected_uptime_seconds) <= 1

# Generated at 2022-06-22 22:57:24.999453
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule:
        @staticmethod
        def get_bin_path(name):
            return "/usr/bin/%s" % name

        @staticmethod
        def run_command(cmd, encoding=None):
            if cmd[0] == '/usr/bin/sysctl':
                return 0, "kern.boottime 1000", ""
            else:
                raise RuntimeError("Unexpected command %s" % cmd[0])

    hardware = DarwinHardware()
    hardware.module = MockModule()
    facts = hardware.get_uptime_facts()
    assert facts['uptime_seconds'] == int(time.time() - 1000)

# Generated at 2022-06-22 22:57:26.902474
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darb = DarwinHardware('module', 'collector')
    darb.get_uptime_facts()

# Generated at 2022-06-22 22:57:36.294468
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Instantiate a module_util.CommandResult object
    class module_util_CommandResult:
        def __init__(self, stdout, stderr):
            self.stdout = stdout
            self.stderr = stderr

    # Instantiate a module_utils.module.Module object
    class module_utils_module(object):
        def __init__(self):
            self.params = None
            self.result = None

        @staticmethod
        def get_bin_path(cmd):
            return cmd

        def run_command(self, cmd, encoding=None):
            # Instantiate a module_util.CommandResult object
            class module_util_CommandResult:
                def __init__(self, stdout, stderr):
                    self.stdout = stdout
                    self.stderr = stder

# Generated at 2022-06-22 22:57:45.243570
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """Test that DarwinHardware.get_cpu_facts() parses information correctly"""
    import os.path
    import sys

    # Mock the module and the get_sysctl() function

# Generated at 2022-06-22 22:57:56.997312
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    mock_module = basic.AnsibleModule(
        argument_spec=dict()
    )

    darwin_hardware = DarwinHardware(mock_module)
    output = '''
Hardware:

      Hardware Overview:

        Model Name: MacBook Air
        Model Identifier: MacBookAir3,1
        Processor Name: Intel Core i5
        Processor Speed: 1.8 GHz
        Number of Processors: 1
        Total Number of Cores: 2
        L2 Cache (per Core): 256 KB
        L3 Cache: 3 MB
        Memory: 4 GB
        Boot ROM Version: MBA31.0074.B00
        SMC Version (system): 2.3f36
'''

# Generated at 2022-06-22 22:58:02.972056
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule({})
    hardware = DarwinHardware(module)
    memory_facts_expected = {
        'memtotal_mb': 2048,
        'memfree_mb': 1423
    }
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == memory_facts_expected['memtotal_mb']
    assert memory_facts['memfree_mb'] == memory_facts_expected['memfree_mb']

# Generated at 2022-06-22 22:58:14.251285
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mod = AnsibleModule({
        'system_profiler_command': None,
        'sysctl_command': None,
    })

    hw = DarwinHardware(mod)

    # sysctl hw.model returns an error
    hw.module.run_command = MagicMock(return_value=(1, '', ''))
    mac_facts = hw.get_mac_facts()

    assert mac_facts['model'] == '', 'failed to get model from sysctl'
    assert mac_facts['osversion'] == '', 'failed to get osversion from sysctl'
    assert mac_facts['osrevision'] == '', 'failed to get osrevision from sysctl'

    # sysctl hw.model succeed

# Generated at 2022-06-22 22:58:15.564298
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # DarwinHardware is an abstract class.
    pass

# Generated at 2022-06-22 22:58:25.632395
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    sysctl_cmd = get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    test_time = time.time()
    test_time_micros = int((test_time - int(test_time)) * 1000000)
    test_b = struct.pack('@L', int(test_time)) + struct.pack('@L', test_time_micros)

    hardware = DarwinHardware(None)
    facts = hardware.get_uptime_facts()
    expected = {
        'uptime_seconds': int(time.time() - test_time),
    }
    assert facts == expected



# Generated at 2022-06-22 22:58:31.196914
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mac_facts = DarwinHardware({"module": {"run_command": run_fake_command}})
    mac_facts.sysctl = {'hw.memsize': '4294967296'}

    assert mac_facts.get_memory_facts() == {
        'memtotal_mb': 4096,
        'memfree_mb': 0
    }



# Generated at 2022-06-22 22:58:34.166842
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware = DarwinHardware({'module_setup': True, 'command_warnings': []})
    retval = hardware.get_mac_facts()
    assert isinstance(retval, dict)



# Generated at 2022-06-22 22:58:38.164713
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_fact_collector = DarwinHardwareCollector()
    assert darwin_fact_collector._fact_class == DarwinHardware
    assert darwin_fact_collector._platform == 'Darwin'

# Generated at 2022-06-22 22:58:41.679294
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModuleMock()
    darwin = DarwinHardware(module)
    assert darwin.platform == 'Darwin'


# Generated at 2022-06-22 22:58:52.989890
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class FakeModule(object):
        def __init__(self, result):
            self.run_command_result = result

        def run_command(self, cmd, encoding=None):
            return self.run_command_result

    class FakeTime(object):
        def __init__(self, time):
            self.time = time

        def __call__(self):
            return self.time

    def run_test(result, expected):
        fm = FakeModule(result)
        dh = DarwinHardware(fm)
        dh.get_bin_path = lambda x: '/bin/%s' % x
        dh.time = FakeTime(42)
        assert dh.get_uptime_facts() == expected

    # Successful result, 8-byte binary value.

# Generated at 2022-06-22 22:59:02.967228
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create an instance of test class
    hardware = DarwinHardware()
    hardware.sysctl = {'hw.pagesize': '4096'}
    hardware.module = MockModule()
    hardware.module.run_command.return_value = (0, '"Memory"\nPages free:                3276.\nPages active:              10830.\nPages inactive:            5705.\nPages wired down:          811.\n"VM storage"\nPages free:                3276.\nPages active:              10830.\nPages inactive:            5705.\nPages wired down:          811.\n"VCPU"\nPages free:                3276.\nPages active:              10830.\nPages inactive:            5705.\nPages wired down:          811.', '')
    result = hardware.get_memory

# Generated at 2022-06-22 22:59:08.508818
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()

    cpu_model_string_sysctl_out = """
machdep.cpu.brand_string: Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz
"""
    darwin_hardware.sysctl = get_sysctl(darwin_hardware.module, ['machdep.cpu'])
    darwin_hardware.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz'

    cpu_facts = darwin_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz'
    assert cpu_facts['processor_cores']

# Generated at 2022-06-22 22:59:20.081975
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-22 22:59:23.011630
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert 'processor' in cpu_facts



# Generated at 2022-06-22 22:59:27.681422
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module_args = dict(
        gather_subset='min',
    )

    collected_facts = dict(
        hardware=DarwinHardwareCollector.collect(module_args, {})
    )

    memtotal_mb = collected_facts['hardware'].pop('memtotal_mb')
    memfree_mb = collected_facts['hardware'].pop('memfree_mb')

    return (memtotal_mb, memfree_mb)

# Generated at 2022-06-22 22:59:39.888317
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware()
    out = """Hardware Overview:
  Model Name: MacBook Pro
  Model Identifier: MacBookPro5,5
  Processor Name: Intel Core 2 Duo
  Processor Speed: 2.4 GHz
  Number Of Processors: 1
  Total Number Of Cores: 2
  L2 Cache: 6 MB
  Memory: 4 GB
  Bus Speed: 1.07 GHz
  Boot ROM Version: MBP55.00AC.B03
  SMC Version (system): 1.48f2
  Serial Number (system): W884013X6T
  Hardware UUID: 00000000-0000-1000-8000-001C3CBF2B86
  Sudden Motion Sensor:
    State: Enabled
"""


# Generated at 2022-06-22 22:59:51.923721
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import pytest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    darwin_hardware = DarwinHardware(None)
    # failures have an rc != 0
    # no output have len(out) == 0
    # too short outputs have struct_size > len(out)
    # outputs with wrong format will fail the struct.unpack call

# Generated at 2022-06-22 22:59:53.727600
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hw = DarwinHardwareCollector(None)
    assert hw.get_platform() == 'Darwin'
    assert isinstance(hw._fact_class(None), DarwinHardware)

# Generated at 2022-06-22 22:59:55.784840
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec=dict())
    darwinhw = DarwinHardware(module)

    assert darwinhw.platform == 'Darwin'



# Generated at 2022-06-22 23:00:02.785288
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    fake_module = FakeAnsibleModule()
    fake_module.add_command_output("sysctl hw.model", rc=0, out="hw.model: MacBookPro9,1")
    mac_facts = DarwinHardware(fake_module).get_mac_facts()
    assert mac_facts == {
        'model': 'MacBookPro9,1',
        'osversion': '15.0.0',
        'osrevision': '15A284'
    }



# Generated at 2022-06-22 23:00:15.049857
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = object()
    hardware_obj = DarwinHardware(module)

    # Mock setup

# Generated at 2022-06-22 23:00:22.508488
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class FakeModule(object):
        """Fake module to run commands"""
        def get_bin_path(self, executable):
            return 'sysctl'

        def run_command(self, cmd, encoding=None):
            """Fake run_command method"""
            return (0, b'kern.boottime: { sec = 1547113096, usec = 333851 } Fri Jan 18 20:54:56 2019\n', '')

    # Check that all uptime fields are correctly decoded
    dh = DarwinHardware()
    dh.module = FakeModule()
    dh.sysctl = {}
    uptime_facts = dh.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 1547113096

# Generated at 2022-06-22 23:00:23.841764
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware = DarwinHardwareCollector()
    assert hardware.platform == 'Darwin'
    assert hardware.fact_class is DarwinHardware


# Generated at 2022-06-22 23:00:30.634363
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    platform_info = dict(
        system='Darwin',
        machine='',
        release='',
        version='',
        kernel_version='',
        macosx_productname='',
        macosx_productversion='',
        macosx_productversion_major='',
    )
    darwin_hardware = DarwinHardwareCollector(platform_info)
    assert darwin_hardware.sysctl is None, "sysctl is initialized to None"



# Generated at 2022-06-22 23:00:41.110041
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """Test case to verify that method get_system_profile
    of class DarwinHardware returns the expected dictionary
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware()
    hardware.module = Mock()

# Generated at 2022-06-22 23:00:47.322822
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = type('FakeModule', (object,), {})()

# Generated at 2022-06-22 23:00:56.428286
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a mock module and fake result from system_profiler
    module = MagicMock()
    out = '''
    Hardware:

        Hardware Overview:

          Model Name: MacBook Pro
          Model Identifier: MacBookPro13,3
          Processor Name: Intel Core i5
          Processor Speed: 3 GHz
          Number of Processors: 1
          Total Number of Cores: 2
          L2 Cache (per Core): 256 KB
          L3 Cache: 4 MB
          Memory: 8 GB
          Boot ROM Version: 1037.120.87.0.0 (iBridge: 17.16.16391.0.0,0)
          SMC Version (system): 2.45f0
    '''

    module.run_command = MagicMock(return_value=(0, out, ''))

    # Instantiate class
    darwin_hardware

# Generated at 2022-06-22 23:01:05.361354
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule
    hardware_facts = DarwinHardware(module).populate()
    assert hardware_facts['model']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert hardware_facts['uptime_seconds']


from ansible.module_utils.basic import *  # noqa

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 23:01:18.108757
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    def test(sysctl_mock, expected):
        # Create a mock of run_command() and make get_sysctl() use it
        darwin_hardware = DarwinHardware(dict())
        darwin_hardware.module.run_command = sysctl_mock
        darwin_hardware.get_sysctl = lambda x: sysctl_mock(x)

        ret = darwin_hardware.get_cpu_facts()
        assert ret == expected

    # Test for hardware architecture 'i386'
    sysctl_mock = lambda x: (0, '', '') if x == 'hw.memsize' else (0, '2147483648', '')

# Generated at 2022-06-22 23:01:20.440886
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    facts = {}
    c = DarwinHardware(facts=facts, module=None)
    assert c.platform == 'Darwin'
    assert c.sysctl == {}
    assert c.get_system_profile() == {}


# Generated at 2022-06-22 23:01:32.403525
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Method get_mac_facts of class DarwinHardware should return facts about OS version, OS revision and model.
    """
    import sys
    import os
    import unittest
    import ansible.module_utils.facts.hardware.darwin as darwin

    class ExitModuleException(Exception):
        pass

    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda x: self.fake_run_command(x)

        def run_command(self):
            pass

        def fake_run_command(self, cmd):
            if cmd == ['sysctl', 'hw.model']:
                return 0, 'hw.model: iMac17,1\n', ''
            else:
                return 1, '', 'Error'


# Generated at 2022-06-22 23:01:38.817233
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    args = dict(
        ansible_facts=dict(
            ansible_os_family='Darwin',
            ansible_distribution='macOS',
            ansible_distribution_version='10.13.6',
            ansible_distribution_release='17G7024',
        ),
    )
    module = FakeAnsibleModule(**args)
    darwin_hardware = DarwinHardware(module)
    assert darwin_hardware.get_mac_facts() == dict(
        model='Macmini5,1',
        osversion='Darwin Kernel Version 17.7.0: Thu Jun 21 22:53:14 PDT 2018; root:xnu-4570.71.2~1/RELEASE_X86_64',
        osrevision='17G7024',
    )



# Generated at 2022-06-22 23:01:40.586806
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert d._platform == 'Darwin'

# Generated at 2022-06-22 23:01:50.580692
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeModule()
    darwin = DarwinHardware(module)
    darwin.populate()
    assert darwin.facts['model'] == 'iMac15,1'
    assert darwin.facts['processor'] == 'Intel(R) Core(TM) i5-4570R CPU @ 2.70GHz'
    assert darwin.facts['processor_cores'] == '4'
    assert darwin.facts['processor_vcpus'] == '4'
    assert darwin.facts['memtotal_mb'] == '8192'
    assert darwin.facts['memfree_mb'] == '8192'
    assert darwin.facts['osversion'] == '15.6.0'
    assert darwin.facts['osrevision'] == '18G6020'
    assert dar

# Generated at 2022-06-22 23:01:52.546987
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    assert DarwinHardware(None, dict()).get_mac_facts() == {'osversion': "16.7.0", 'osrevision': "",
                                                            'model': 'MacBookPro12,1'}

# Generated at 2022-06-22 23:02:03.995243
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_native

    if not basic.HAS_STRUCT:
        module = basic.AnsibleModule(argument_spec={})
        module.fail_json(msg="platform: darwin: struct module is not installed")

    test_module = basic.AnsibleModule(argument_spec={})
    test_module.exit_json = lambda arg: arg
    test_module.run_command = lambda arg: (0, b'{a:b}\nkern.boottime: 1688620930 0\n{c:d}\n', None)

    hardware = DarwinHardware(test_module)
    result = hardware.get_uptime_facts()
    assert result == {'uptime_seconds': 1688620930}


# Generated at 2022-06-22 23:02:13.825044
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModules()
    hardware_facts = DarwinHardware(module)
    hardware_facts.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU X5660 @ 2.80GHz',
        'machdep.cpu.core_count': 2
    }

    cpu_facts = hardware_facts.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU X5660 @ 2.80GHz'
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor_vcpus'] == ''

    hardware_facts.sysctl = {
        'hw.physicalcpu': 2
    }

    cpu_facts = hardware_facts.get_cpu_facts()

# Generated at 2022-06-22 23:02:19.491797
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    class DarwinHardwareTestModule(object):
        def __init__(self):
            self.run_command_results = [[0, 'hw.model: MacBookPro8,2', '']]
            self.sysctl = {'kern.osversion': '15.3.0',
                           'kern.osrevision': '15D21'}

        def run_command(self, cmd, encoding=None):
            return self.run_command_results.pop()

    hardware_test_module = DarwinHardwareTestModule()
    darwin_hardware = DarwinHardware(module=hardware_test_module)
    output = darwin_hardware.get_mac_facts()
    assert output['model'] == 'MacBookPro8,2'
    assert output['osversion'] == '15.3.0'

# Generated at 2022-06-22 23:02:21.548299
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    dhwc = DarwinHardwareCollector()
    assert dhwc._platform == 'Darwin'

# Generated at 2022-06-22 23:02:28.846891
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # create a test DarwinHardware object
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    # create the 'sysctl' dictionary we expect to see returned
    sysctl_output = {}
    sysctl_output['hw.model'] = 'MacBookPro12,1'
    sysctl_output['kern.osversion'] = '15.5.0'
    sysctl_output['kern.osrevision'] = '19F101'
    hardware.sysctl = sysctl_output
    hardware.system_profile = {}
    hardware.system_profile['Processor Name'] = 'Intel Core i7'
    hardware.system_profile['Processor Speed'] = '2.8 GHz'
    hardware.system_profile['Number of Processors'] = '1'

# Generated at 2022-06-22 23:02:38.683003
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test with Intel CPU
    raw_sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6600U CPU @ 2.60GHz',
        'machdep.cpu.core_count': '2',
    }
    module = Mock()
    module.get_bin_path = Mock(return_value='/usr/bin/vm_stat')

# Generated at 2022-06-22 23:02:47.728521
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_cpu_facts_data = [
        ({'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-5930K CPU @ 3.50GHz',
          'machdep.cpu.core_count': 6},
         {'processor': 'Intel(R) Core(TM) i7-5930K CPU @ 3.50GHz',
          'processor_cores': 6,
          'processor_vcpus': ''}),
        ({'hw.physicalcpu': 6},
         {'processor': '%s @ %s' % ('PowerPC', 'unknown'),
          'processor_cores': 6,
          'processor_vcpus': ''}),
    ]

    for (sysctl, cpu_facts) in test_cpu_facts_data:
        mock_module = MockAnsibleModule

# Generated at 2022-06-22 23:02:56.996585
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    class ModuleMock:
        '''Mock module to mock a module instance'''
        def __init__(self):
            self.params = dict()
            self.exit_json = dict()
            self.fail_json = dict()

        def run_command(self, cmd, encoding=None):
            if cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']:
                boot_time = struct.pack('@L', int(time.time() - 20))
                return (0, boot_time, '')
            else:
                return (1, '', '')

    hardware_obj = DarwinHardware(ModuleMock())
    hardware_obj.get_uptime_facts()
    assert hardware_obj.facts['uptime_seconds'] == 20

# Generated at 2022-06-22 23:02:58.001381
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware({})
    hardware.populate()

# Generated at 2022-06-22 23:03:02.041327
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    facts = DarwinHardware({}, {}, {})
    expected = {
        'processor': "Intel(R) Core(TM) i7-4510U CPU @ 2.00GHz",
        'processor_cores': 2,
        'processor_vcpus': 4
    }
    actual = facts.get_cpu_facts()
    assert actual == expected


# Generated at 2022-06-22 23:03:11.297059
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hardware = DarwinHardware()
    assert darwin_hardware.populate() == {
        'model': 'MacBookPro9,2',
        'osversion': '16.7.0',
        'osrevision': '15.6.0',
        'uptime_seconds': 4337,
        'processor': 'Intel Core i5 2.5 GHz',
        'processor_cores': 2,
        'memtotal_mb': 8192,
        'memfree_mb': 7111,
    }

# Generated at 2022-06-22 23:03:12.365192
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()

# Generated at 2022-06-22 23:03:21.864268
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a mock run_command function

# Generated at 2022-06-22 23:03:29.004439
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    result = {'osversion': '16.7.0', 'osrevision': '17P3557', 'model': 'MacBookPro11,4'}
    sysctl = get_sysctl(None, ['hw', 'machdep', 'kern'])
    hardware = DarwinHardware(None)
    hardware.sysctl = sysctl
    mac_facts = hardware.get_mac_facts()
    assert mac_facts == result

# Generated at 2022-06-22 23:03:35.782116
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    fact_module = mock.Mock()
    fact_module.run_command.return_value = (0, "kern.boottime: { sec =  1523990838, usec =  655718000 } Thu Apr 19 10:47:18 2018", "")

    darwin_facts = DarwinHardware(fact_module)

    assert darwin_facts.get_uptime_facts() == {'uptime_seconds': 61769}

# Generated at 2022-06-22 23:03:44.922971
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)

    input = {"ansible_facts": {}}
    expected_output = {
        'processor': 'Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz',
        'processor_cores': '4',
        'processor_vcpus': '4',
        'memtotal_mb': 16384,
        'memfree_mb': 8452,
        'model': 'MacBookPro11,2',
        'osversion': '15.4.0',
        'osrevision': '14E46'}

    darwin_hardware = DarwinHardware(module)
    darwin_hardware.populate(input)