

# Generated at 2022-06-22 22:53:51.334622
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mocked_m = type('', (), {})()
    mocked_m.run_command = type('', (), {})()
    mocked_m.run_command.return_value = (0, "    Model Name: MacBook Pro\n    Processor Name: Intel Core i7\n    Processor Speed: 3 GHz", "")
    d = DarwinHardware(mocked_m)
    expected_return = {'Model Name': 'MacBook Pro', 'Processor Name': 'Intel Core i7', 'Processor Speed': '3 GHz'}
    assert d.get_system_profile() == expected_return

# Generated at 2022-06-22 22:53:55.617905
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    cpu_facts = DarwinHardware().get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts

# Generated at 2022-06-22 22:53:56.212774
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-22 22:54:08.321148
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import datetime
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # On Darwin, the default format is annoying to parse.
    # Use -b to get the raw value and decode it.
    sysctl_cmd = '/usr/sbin/sysctl'
    cmd = [sysctl_cmd, '-b', 'kern.boottime']

    # We need to get raw bytes, not UTF-8.
    # rc, out, err = self.module.run_command(cmd, encoding=None)
    rc = 0

# Generated at 2022-06-22 22:54:17.010571
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    def run_command(args):
        return 0, 'MacBookPro5,1\n', ''
    class fake_module(object):
        def __init__(self):
            self.run_command = run_command
    hardware = DarwinHardware(fake_module())
    out = hardware.get_mac_facts()
    assert out['model'] == 'MacBookPro5,1'
    assert out['osversion'] == '16.6.0'
    assert out['osrevision'] == '1'


# Generated at 2022-06-22 22:54:25.134644
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    facts = DarwinHardware(module).get_mac_facts()
    model = facts['model']
    osversion = facts['osversion']
    osrevision = facts['osrevision']
    assert model == 'MacPro5,1' or model == 'MacBookAir5,2' or model == 'MacBookPro11,1' or model == 'iMac14,2'
    assert osversion.startswith('14') or osversion.startswith('13')
    assert osrevision == '0' or osrevision == '1'


# Generated at 2022-06-22 22:54:37.069683
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware


# Generated at 2022-06-22 22:54:44.781688
# Unit test for method populate of class DarwinHardware

# Generated at 2022-06-22 22:54:56.669324
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModuleMock
    hardware = DarwinHardware(module)

    total = 4096
    (wired, active, inactive) = (2048, 1792, 128)
    free = total - (wired + active + inactive)

    # Create a fake vm_stat command output
    vm_stat_output = "%s\n%s\n%s\n%s\n" % \
        ("Pages free: %s" % free, "Pages wired down: %s" % wired, "Pages active: %s" % active, "Pages inactive: %s" % inactive)

    # Mock the module to return this custom output for the vm_stat command
    module.run_command = AnsibleModuleMock.run_command_custom(0, vm_stat_output, '')

    # Run the method to collect memory facts
    memory_facts = hardware

# Generated at 2022-06-22 22:55:08.967056
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-22 22:55:17.444696
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """ Test 'populate' method of DarwinHardware class """
    module = MockModule()
    hw = DarwinHardware(module=module)

    mac_facts = {
        'model': 'MacBookPro5,2',
        'product_name': 'MacBookPro5,2',
        'osversion': '10.12.6',
        'osrevision': '16G29'
    }
    cpu_facts = {
        'processor': 'Intel(R) Core(TM) i7-2635QM CPU @ 2.00GHz',
        'processor_cores': 4,
        'processor_vcpus': '',
    }
    memory_facts = {
        'memtotal_mb': 8192,
        'memfree_mb': 0
    }

# Generated at 2022-06-22 22:55:29.480246
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware()

# Generated at 2022-06-22 22:55:32.709247
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    This method tests the constructor of the DarwinHardwareCollector class
    """
    darwinHardwareObj = DarwinHardwareCollector()
    assert darwinHardwareObj is not None

# Generated at 2022-06-22 22:55:44.687007
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)
    # Test Intel processors
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4250U CPU @ 1.30GHz',
                        'machdep.cpu.core_count': '4'}
    facts = hardware.get_cpu_facts()
    print(facts)
    assert facts['processor'] == 'Intel(R) Core(TM) i5-4250U CPU @ 1.30GHz'
    assert facts['processor_cores'] == '4'
    # Test PowerPC processor (no longer used by Apple, but keeping this for historical reasons)

# Generated at 2022-06-22 22:55:55.249304
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = MockModule()
    hardware = DarwinHardware(module)

    # patch run_command

# Generated at 2022-06-22 22:56:00.040413
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()

    # test fields exist
    assert isinstance(darwin_hardware_collector._fact_class, DarwinHardware)
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-22 22:56:02.420141
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec=dict())
    d = DarwinHardware(module)
    assert d is not None

# Unit test function DarwinHardware.populate()

# Generated at 2022-06-22 22:56:09.324800
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test DarwinHardware.get_system_profile()
    """
    hardware = DarwinHardware()

    # Test if empty string given, no results are returned
    result = hardware.get_system_profile('')
    assert isinstance(result, dict)
    assert len(result) == 0

    # Test if a valid string is given, but without key-value pairs, an empty dictionary is returned
    result = hardware.get_system_profile('This is just a random string, without key-value pairs.')
    assert isinstance(result, dict)
    assert len(result) == 0

    # Test if a valid string is given, and with key-value pairs, a dictionary with those pairs is returned
    result = hardware.get_system_profile('This is just a random string, with key-value pairs.\nSerial Number: ABC123')

# Generated at 2022-06-22 22:56:18.649813
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hw = DarwinHardware(dict(module=None))

    memtotal_mb = int(darwin_hw.sysctl['hw.memsize']) / 1024**2
    memfree_mb = 0
    total_used = 0
    page_size = 4096
    vm_stat_command = get_bin_path('vm_stat')
    rc, out, err = darwin_hw.module.run_command(vm_stat_command)

    # Free = Total - (Wired + active + inactive)
    # Get a generator of tuples from the command output so we can later
    # turn it into a dictionary
    memory_stats = (line.rstrip('.').split(':', 1) for line in out.splitlines())

    # Strip extra left spaces from the value

# Generated at 2022-06-22 22:56:29.290148
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['model'] == 'Macmini5,1'
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == '2'
    assert int(hardware_facts['memtotal_mb']) > -1
    assert int(hardware_facts['memfree_mb']) > -1
    assert hardware_facts['osversion'] == 'Darwin Kernel Version 16.0.0: Fri Sep 23 10:11:45 PDT 2016; root:xnu-3789.1.32~3/RELEASE_X86_64'

# Generated at 2022-06-22 22:56:33.024708
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    system_profile = DarwinHardware.get_system_profile(None)
    assert 'Model Name:' in system_profile
    assert 'Processor Speed:' in system_profile

# Generated at 2022-06-22 22:56:44.394024
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    dh = DarwinHardware(module)
    assert module.run_command == dh.module.run_command

# Generated at 2022-06-22 22:56:52.456777
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = AnsibleRunCommandMock()

    har = DarwinHardware(module)

    result = har.populate()
    assert isinstance(result, dict)
    assert result['uptime_seconds'] == 1142
    assert result['model'] == 'MacBookPro12,1'
    assert result['osversion'] == '15.5.0'
    assert result['processor'] == 'Intel(R) Core(TM) m5-6Y54 CPU @ 1.10GHz'
    assert result['processor_cores'] == '2'
    assert result['processor_vcpus'] == ''
    assert result['memtotal_mb'] == 15722
    assert result['memfree_mb'] == 10057
    assert result['osrevision'] == '16F73'
    assert result

# Generated at 2022-06-22 22:56:56.218851
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector.platform == 'Darwin'
    assert hardware_collector.fact_class == DarwinHardware
    assert hardware_collector.fact_class.platform == 'Darwin'

# Generated at 2022-06-22 22:57:08.215443
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Test results of get_mac_facts function by running it with a mock
    module class.
    """
    # Construct a mock class with a temporary file as its data source.  The
    # temporary file will be removed automatically at the end of this block.
    tmp_file = tempfile.NamedTemporaryFile()
    tmp_file.write('''
hw.model: MacBookPro12,1
kern.osversion: 15.5.0
kern.osrevision: 11G63
'''.encode('utf-8'))
    tmp_file.seek(0)
    MockModule = Mock(dict(params=dict()), tmp_file.name)

    # Call the get_mac_facts function
    mac_facts = DarwinHardware().get_mac_facts(MockModule)

    # Check the results

# Generated at 2022-06-22 22:57:18.420853
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test the get_system_profile method against a mocked-up output
    of system_profiler.
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    mac = DarwinHardware()
    mac.module = mock.MagicMock()
    mac.module.run_command.return_value = (0, SAMPLE_SYSTEM_PROFILER, None)
    system_profile = mac.get_system_profile()

    # check whether the system_profile command and the corresponding
    # output is captured properly.
    mac.module.run_command.assert_called_with(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    # check whether the expected keys are present in the output of system_profiler

# Generated at 2022-06-22 22:57:30.203255
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    # Setup test class
    darwin_hardware = DarwinHardware()

    # Setup test data
    memory_stats = {
        'Pages wired down': 3535,
        'Pages active': 546,
        'Pages inactive': 328,
    }
    page_size = 4096
    vm_stat_output = "Mach Virtual Memory Statistics: (page size of %s bytes)\n%s\n" % (page_size, "\n".join("%s: %s" % (k, v) for k, v in memory_stats.items()))

    # Setup mock module
    darwin_hardware.module = MockModule(run_command=MockCmd(vm_stat_output))

    # Get result
    memory_facts = darwin_hardware.get_memory_facts()

    # Check result
    assert memory_facts

# Generated at 2022-06-22 22:57:38.161342
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """Test for when /usr/sbin/system_profiler does not return valid results"""

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    dh = DarwinHardware({})
    assert {} == dh.get_system_profile()
    rc_0 = 0
    out_0 = "  System Profile: blah blah blah\n"
    err_0 = ""
    assert dh.get_system_profile() == {}
    assert dh.get_system_profile(
        {'rc': rc_0, 'out': out_0, 'err': err_0}) == {}
    out_1 = "  System Profile: blah blah blah\n  " \
            "Serial Number (system): blah blah blah\n"

# Generated at 2022-06-22 22:57:39.167957
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    assert callable(DarwinHardware)

# Generated at 2022-06-22 22:57:49.384673
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Create a mock module
    class MockModule(object):
        def get_bin_path(self, executable):
            return executable
        def run_command(self, cmd, encoding=None):
            return 0, 'succeed', ''

    # Create a mock module
    m = MockModule()

    # Create an instance of DarwinHardware
    darwin = DarwinHardware(m)

    # Try to get processor
    result = darwin.get_cpu_facts()
    assert result['processor'] == 'Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz'
    assert result['processor_cores'] == 4
    assert result['processor_vcpus'] == 4



# Generated at 2022-06-22 22:58:00.219768
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(mock_invalid_attribute)
    def mock_get_sysctl(self, items=None):
        return {
            'hw.memsize': 1234,
            'hw.physicalcpu': 2,
            'kern.boottime': 1516951281,
            'kern.osrevision': '16',
            'kern.osversion': '15.6.0',
            'machdep.cpu.brand_string': 'Intel Core',
            'machdep.cpu.core_count': 4,
            'machdep.cpu.thread_count': 8,
        }

    def mock_get_bin_path(command, required=False):
        if command == 'vm_stat':
            return command

    module.get_bin_path = mock_get_bin_path

# Generated at 2022-06-22 22:58:11.861425
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Dummy class for unit test
    class Dummy:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # Cases for testing method get_cpu_facts of class DarwinHardware
    # Case of input sysctl is None
    dummy_args1 = {'sysctl': None}
    d1 = Dummy(**dummy_args1)
    dhw1 = DarwinHardware(d1)
    assert dhw1.get_cpu_facts() == {}

    # Case of sysctl is not None, machdep.cpu.brand_string is in sysctl

# Generated at 2022-06-22 22:58:19.073059
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    mac = DarwinHardware(dict())
    mac.sysctl = {'kern.boottime': '12345'}
    uptime = mac.get_uptime_facts()
    assert uptime['uptime_seconds'] == int(time.time()) - 12345


# Generated at 2022-06-22 22:58:25.985683
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware(None)

    # Set up the test conditions (mimic the results of the 'vm_stat' command)
    darwin_hardware.sysctl = {'hw.memsize': 3320841728}
    darwin_hardware.module.run_command = dict()
    darwin_hardware.module.run_command['return_code'] = 0

# Generated at 2022-06-22 22:58:29.850563
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Checks to see if get_system_profile returns values of type dict.
    """
    obj = DarwinHardware()
    result = obj.get_system_profile()
    assert isinstance(result, dict)


# Generated at 2022-06-22 22:58:39.681365
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import textwrap
    test_stdout = textwrap.dedent("""
        Hardware:

          Hardware Overview:

            Model Name: MacBook Pro
            Model Identifier: MacBookPro11,2
            Processor Name: Intel Core i7
            Processor Speed: 2 GHz
            Number of Processors: 1
            Total Number of Cores: 4
            L2 Cache (per Core): 256 KB
            L3 Cache: 6 MB
            Memory: 16 GB
            Boot ROM Version: MBP112.0138.B19
            SMC Version (system): 2.19f12
            Serial Number (system): C02RB0C6J5WM
            Hardware UUID: CC0E0F44-ABE9-5B48-B4DD-B29B46BCD0AC
        """)
    m = AnsibleModuleStub()
    m.run

# Generated at 2022-06-22 22:58:51.949556
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})

    hardware = DarwinHardware({'module': module})


# Generated at 2022-06-22 22:59:01.808300
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    expected = {
        'processor': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'processor_cores': 8,
        'processor_vcpus': 8
    }

    dh = DarwinHardware(dict())
    dh.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 8,
        'hw.logicalcpu': 8
    }

    assert dh.get_cpu_facts() == expected, "get_cpu_facts should return the expected value"


# Generated at 2022-06-22 22:59:10.297868
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    params = {'module': mock.MagicMock()}
    params['module'].run_command.side_effect = [
        (0, 'hw.model: MacBookPro6,2', ''),
        (0, '12.4.0', ''),
        (0, '20120505', '')
    ]
    expected = {
        'model': 'MacBookPro6,2',
        'osversion': '12.4.0',
        'osrevision': '20120505'
    }
    hw = DarwinHardware(params)
    assert hw.get_mac_facts() == expected


# Generated at 2022-06-22 22:59:21.619385
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware


# Generated at 2022-06-22 22:59:24.887538
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    #Test instantiation of empty class
    dh = DarwinHardware(module=None)
    assert(dh.platform == 'Darwin')


if __name__ == '__main__':
    test_DarwinHardware()

# Generated at 2022-06-22 22:59:32.911477
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module_name = 'ansible.module_utils.facts.hardware.darwin'
    module = __import__(module_name, fromlist=[''])

    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.run_command = dict()

        def get_bin_path(self, executable):
            return executable

    test_module = TestModule()

    class TestSysctl(object):
        def __init__(self, dict_of_key_value_pair=None):
            self.dict = dict_of_key_value_pair

        def __getitem__(self, key):
            return self.dict[key]


# Generated at 2022-06-22 22:59:43.099414
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-22 22:59:54.610771
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command.return_value = (0, '', '')

    hardware = DarwinHardware(module)

    hardware.get_mac_facts = MagicMock(return_value={'a': 'b'})
    hardware.get_cpu_facts = MagicMock(return_value={'c': 'd'})
    hardware.get_memory_facts = MagicMock(return_value={'e': 'f'})
    hardware.get_uptime_facts = MagicMock(return_value={'g': 'h'})


# Generated at 2022-06-22 22:59:56.424866
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hw = DarwinHardware()
    assert hw.platform == 'Darwin', "get_hwinfo() failed"

# Generated at 2022-06-22 23:00:02.990478
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeAnsibleModule()
    darwin_hardware = DarwinHardware(module)
    # Get the vm_stat from the fixtures
    darwin_hardware.module.run_command = fake_run_command

    # Test the MapReduce
    darwin_hardware.get_memory_facts()
    assert isinstance(darwin_hardware.facts, dict)
    assert darwin_hardware.facts['memfree_mb'] == 770


# Generated at 2022-06-22 23:00:15.259323
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    Method get_uptime_facts returns the system uptime, in seconds, since the last boot.

    The Darwin system command vm_stat is used to obtain this value.
    vm_stat is queried for the number of seconds since boot time:
        vm_stat | grep -w 'Mach Virtual Memory Statistics:'
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.six.moves import mock

    get_bin_path_mock = mock.Mock(return_value='/usr/bin/vm_stat')
    module_run_command_mock = mock.Mock()

# Generated at 2022-06-22 23:00:17.309552
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # Just make sure the module is not raising an error at this stage
    test_module = type('AnsibleModule', (object,), {})
    DarwinHardware(test_module)

# Generated at 2022-06-22 23:00:28.735489
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = FakeModule()
    hw = DarwinHardware(module=test_module)
    system_profile = {
        'Model Name': 'macbookpro1,1',
        'Model Identifier': 'PowerBook6,4',
        'Processor Speed': '2.2 GHz',
        'Processor Name': 'PowerPC G4 (1.1)',
        'Number Of Processors': '1',
        'Memory': '1 GB',
        'Bus Speed': '167 MHz',
        'Boot ROM Version': '4.8.6f2',
        'Serial Number (system)': 'W8xxxxxxxxxxx',
        'Hardware UUID': '11111111-2222-3333-4444-555555555555'
    }

# Generated at 2022-06-22 23:00:40.317812
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import datetime

    # test uptime on Darwin
    module = None
    darwin_hw = DarwinHardware(module)

    boot_time_before = time.time()
    # Modify boot time so it is not too close from current time
    boot_time = int(boot_time_before - 30)

    # Build a string containing the seconds and microseconds fields
    # for sysctl to return
    boot_time_string = struct.pack(b'@L', boot_time)

    # Mock the command for sysctl so it returns the seconds field
    # of the boot time.
    # In this test, sysctl should return a valid boot time, so there
    # is no need to mock return code and standard error.

# Generated at 2022-06-22 23:00:47.005449
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'hw.model: MacBookPro12,1', ''))
    facts = DarwinHardware(module)
    mac_facts = facts.get_mac_facts()
    assert mac_facts
    assert mac_facts['model'] == 'MacBookPro12,1'


# Generated at 2022-06-22 23:00:56.272445
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    def run_command_and_return_output(cmd):
        if cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']:
            return 0, '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', ''
        else:
            return 0, '', ''

    module = type('ModuleMock', (object,), {
        'run_command': run_command_and_return_output,
        'get_bin_path': lambda *args: '/usr/sbin/sysctl',
    })()

    hardware_obj = DarwinHardware(module)
    uptime_dict = hardware_obj.get_

# Generated at 2022-06-22 23:01:07.880743
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import time

    def mock_run_command(module, cmd, **kwargs):
        if cmd == ['sysctl', '-b', 'kern.boottime']:
            return (0, b'\x00\x01\x00\x10@V\x00\x00\x00\x00\x00\x00', None)
        else:
            raise Exception("Unexpected command '%s'" % (cmd))

    module = mock.MagicMock()
    module.run_command.side_effect = mock_run_command

    darwinhardware = DarwinHardware(module)
    expected_uptime_seconds = int(time.time() - (0x1 << 32 | 0x10 << 48))
    uptime_facts

# Generated at 2022-06-22 23:01:10.775701
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # Test 1: create instance of DarwinHardware with empty dict.
    # Expect: No exceptions are thrown.
    test = DarwinHardware(dict())



# Generated at 2022-06-22 23:01:20.420760
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = FakeAnsibleModule()
    sysctl = {
        'kern.boottime': '{ sec = 1388534400, usec = 0 } Wed Jan  1 01:00:00 2014',
    }
    module.run_command.side_effect = [
        (0, b'test_string', ''),
    ]
    hardware = DarwinHardware(module, sysctl)
    real_result = hardware.get_uptime_facts()
    expected_result = {
        'uptime_seconds': 1414194000,
    }
    assert real_result == expected_result


# Generated at 2022-06-22 23:01:32.354930
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(
        argument_spec = dict(),
    )

    mocker = Mocker()
    darwin_hardware = DarwinHardware(module)
    mock_run_command = darwin_hardware.module.run_command = mocker.mock()
    mock_run_command(['/usr/sbin/system_profiler', 'SPHardwareDataType'], check_rc=False)

# Generated at 2022-06-22 23:01:37.861903
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware_obj = DarwinHardware()
    out = hardware_obj.run_command('/bin/echo -e "cpu\t6\ncpu_type\t6\ncpu_subtype\t6\n"')
    assert out == 0
    out = hardware_obj.get_cpu_facts()
    assert out['processor_cores'] == 6


# Generated at 2022-06-22 23:01:41.196330
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = MagicMock()
    hardware_collector = DarwinHardwareCollector(module)
    assert hardware_collector.platform == 'Darwin'
    assert hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-22 23:01:50.972628
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Creating a mock module
    module = type('AnsibleModule', (object,), dict(
        params=dict(),
        run_command=lambda *args, **kwargs: (0, 'hw.model: iMac15,1\n', ''),
    ))()

    # Create an instance of DarwinHardware
    harwdare_instance = DarwinHardware(module)

    # Call method populate
    result = harwdare_instance.populate()

    # Test if method populate returned the right dictionary
    assert result.get('model') == 'iMac15,1'
    assert result.get('processor') == 'iMac15,1'
    assert result.get('memfree_mb') == 0
    assert result.get('memtotal_mb') == 0
    assert result.get('uptime_seconds') == 0

# Generated at 2022-06-22 23:02:01.203916
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    class MockModule:
        def run_command(self, command):
            if command == "sysctl hw.model":
                return 0, "hw.model: iMac (27-inch, Mid 2011)\n", ""
            else:
                return 1, '', ''

    class MockFactCollector:
        main = { 'ansible_facts': {}, 'ansible_facts_d' : {} }

        def __init__(self):
            self.module = MockModule()

    fc = MockFactCollector()
    dh = DarwinHardware(fc)
    mac_facts = dh.get_mac_facts()
    assert mac_facts['model'] == 'iMac (27-inch, Mid 2011)'



# Generated at 2022-06-22 23:02:12.236441
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule({})
    # Prepare mock of sysctl command
    sysctl_cmd = sysctl_mock = Mock(return_value=(0, b'\x04\x00\x00\x00\x84\x94\x03\x00\x00\x00\x00\x00', ''))
    module.get_bin_path = Mock(return_value=sysctl_cmd)
    # Function time.time must return a value below kern.boottime
    time_mock = time_mock = Mock(return_value=1451268700)
    time.time = time_mock
    # Execute get_uptime_facts of DarwinHardware
    hardware = DarwinHardware(module)
    result = hardware.get_uptime_facts()
    # Assertions

# Generated at 2022-06-22 23:02:24.351804
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a test class
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    class TestClass():
        def __init__(self):
            self.module = None

# Generated at 2022-06-22 23:02:35.667256
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils._text import to_bytes
    # We should have the same output on all platforms, because we're testing the same command

# Generated at 2022-06-22 23:02:45.760200
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a dummy module for testing
    from ansible.module_utils.facts import ModuleFactCollector
    test_module = ModuleFactCollector()

    from ansible.module_utils.facts.hardware import DarwinHardware
    darwin_hardware = DarwinHardware(test_module)

    # Create a dummy sysctl which gives the 'kern.boottime'
    test_sysctl = {'kern.boottime': 1550168240}

    # Before we invoke 'get_uptime_facts()', test that it returns an empty
    # dictionary.
    assert darwin_hardware.get_uptime_facts() == {}

    # Now invoke 'get_uptime_facts()'.  This should overwrite the empty
    # dictionary.
    darwin_hardware.sysctl = test_sysctl

# Generated at 2022-06-22 23:02:51.594816
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    # data from sysctl kern.boottime command
    raw_data = struct.pack('@L', 1577106073)
    expected_result = {'uptime_seconds': 446079}
    hw = DarwinHardware(dict(), dict())
    uptime_facts = hw.get_uptime_facts_from_raw_data(raw_data)
    assert expected_result == uptime_facts

# Generated at 2022-06-22 23:03:00.050589
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    fake_module = type(str('FakeModule'), (), dict(run_command=lambda *args, **kwargs: (0, '', '')))

    class FakeSysctl:
        @staticmethod
        def get(key, **kwargs):
            if key == 'hw.memsize':
                return 62254592
            elif key == 'vm.swapusage':
                return 'total = 2048.00M  used = 1091.22M  free = 956.78M  (encrypted)'
            else:
                return False
    fake_module.get_bin_path = lambda *args, **kwargs: '/usr/bin/vm_stat'


# Generated at 2022-06-22 23:03:12.095871
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # This test is supposed to run under a Linux environment.
    # It is not supposed to run on a Darwin sytem
    import platform
    if platform.system() == 'Darwin':
        return
    import pytest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.hardware.darwin import DarwinHardware
    # Ensure we have the exact same output as the one from Darwin.
    darwin_hardware_obj = DarwinHardware()
    darwin_out = int(darwin_hardware_obj.get_uptime_facts()['uptime_seconds'])
    test_out = int(darwin_hardware_obj.get_uptime_facts()['uptime_seconds'])
    assert darwin_out == test_out

# Generated at 2022-06-22 23:03:21.705802
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.hardware.darwin import DarwinHardware

    def sysctl_mock(module, facts):
        kern_boottime = 1592258046
        return {
            'kern.boottime': '{sec} {usec}'.format(sec=kern_boottime, usec=0),
        }

    def time_mock():
        return 1592258046 + 20

    # Call get_uptime_facts to validate the time is correctly computed

# Generated at 2022-06-22 23:03:32.504938
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    test_module = get_test_module()

    # Create an instance of DarwinHardware as this will run the sysctl with self.module
    osx_hardware = DarwinHardware()

    # Assign a test module to the fake class attribute 'module' of DarwinHardware
    osx_hardware.module = test_module

    # Get the facts from the DarwinHardware class
    osx_hardware.get_mac_facts()
    osx_hardware.get_cpu_facts()
    osx_hardware.get_memory_facts()
    osx_hardware.get_uptime_facts()

    # Test method populate of class DarwinHardware
    facts = osx_hardware.populate(collected_facts=None)
    assert facts is not None
    assert facts['processor'] is not None
    assert facts['processor_cores']

# Generated at 2022-06-22 23:03:42.500813
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module_mock = AnsibleModule()
    # test_sysctl is a dictionary with values needed for the following tests
    test_sysctl = {'hw.memsize': '1073741824'}

    def get_sysctl_mock_function(module, keys):
        return test_sysctl

    get_bin_path_mock = Mock()
    vm_stat_command = '/usr/bin/vm_stat'
    get_bin_path_mock.return_value = vm_stat_command
    mock = DarwinHardware(module_mock)
    mock.sysctl = get_sysctl_mock_function

    # Mock the call to get_bin_path