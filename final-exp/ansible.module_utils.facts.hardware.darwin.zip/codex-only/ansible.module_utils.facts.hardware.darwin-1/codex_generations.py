

# Generated at 2022-06-22 22:53:54.958059
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Test case: get_mac_facts method of DarwinHardware class
    """
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, 'hw.model: MacBook Pro\n', ''))
    module.get_bin_path = Mock(return_value=True)
    sysctl = Mock(return_value={'kern.osversion': 'macOS version', 'kern.osrevision': 'macOS revision'})
    hw = DarwinHardware(module)
    hw.sysctl = sysctl
    facts = hw.get_mac_facts()
    assert 'model' in facts
    assert facts['model'] == 'MacBook Pro'
    assert 'product_name' in facts
    assert facts['product_name'] == 'MacBook Pro'
    assert 'osversion'

# Generated at 2022-06-22 22:54:00.370539
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a instance of DarwinHardware
    test_DarwinHardware = DarwinHardware()
    # Create a list with the expected keys
    expected_keys = ['SMC_version', 'HT', 'Boot ROM Version', 'Model Name']
    assert sorted(expected_keys) == sorted(test_DarwinHardware.get_system_profile().keys())

# Generated at 2022-06-22 22:54:11.216658
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule({'ansible_facts': {}})

    def run_command(command, *args, **kwargs):
        return (
            0,
            'hw.model: Intel Core i7',
            '',
        )

    def get_sysctl(sysctl_paths):
        return dict(
            kern=dict(
                osversion='18.7.0',
                osrevision='1671.70.1',
            ),
        )

    module.run_command = run_command
    get_sysctl = get_sysctl
    hardware = DarwinHardware(module)
    result = hardware.get_mac_facts()


# Generated at 2022-06-22 22:54:18.595748
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    module.run_command = MagicMock(return_value=(0, """\
AppleSMBIOS
  SMC Version (system):   2.7f0
""", ""))
    facts = hardware.populate()
    assert facts == {
        'osversion': '19.5.0',
        'model': 'iMacPro1,1',
        'osrevision': '17F77'
    }

# Generated at 2022-06-22 22:54:25.088201
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module_mock = Mock(spec=AnsibleModule)
    module_mock.get_bin_path.return_value = '/usr/bin/sysctl'
    module_mock.run_command.return_value = (0, '', '')

    hardware_collector = DarwinHardwareCollector(module_mock)
    assert hardware_collector.platform == 'Darwin'
    assert hardware_collector.fact_class == DarwinHardware


# Generated at 2022-06-22 22:54:31.601785
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    darwin_hardware = DarwinHardware(module)
    mac_facts = darwin_hardware.get_mac_facts()
    # TODO: How about adding another test for Mac OSX version 11.x and a different OS version?
    assert mac_facts.get('osversion') == '19.6.0'
    assert mac_facts.get('osrevision') == '15G1004'

# Generated at 2022-06-22 22:54:42.100237
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-22 22:54:50.813188
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # An object of class DarwinHardware to run the unit test
    hardware = DarwinHardware()

    # A valid boottime need to be provided.
    boottime = struct.pack('@L', int(time.time() - 10000))
    hardware.module.run_command = lambda *args, **kwargs: (0, boottime, None)

    # Fact 'uptime_seconds' should be greater than 10 seconds
    assert hardware.get_uptime_facts()['uptime_seconds'] > 10


# Generated at 2022-06-22 22:54:58.758234
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    m = AnsibleModuleMock()
    f = DarwinHardware(m)
    assert f.populate() == {'model': 'MacBookPro10,1',
                            'product_name': 'MacBookPro10,1',
                            'osversion': '16.6.0',
                            'osrevision': '',
                            'processor': 'Intel(R) Core(TM) i7-3520M CPU @ 2.90GHz',
                            'processor_cores': '2',
                            'processor_vcpus': '4',
                            'memtotal_mb': 8192,
                            'memfree_mb': 6898,
                            'uptime_seconds': 670670}



# Generated at 2022-06-22 22:55:10.817527
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class ModuleStub(object):
        def __init__(self):
            self.run_command_calls = []

# Generated at 2022-06-22 22:55:24.134894
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import os
    test_module = os.path.dirname(os.path.dirname(os.path.dirname(__file__))) + "/test/unit/module_utils/"
    if not os.path.isfile(test_module + "ansible_module_dummy.py"):
        raise Exception("Ansible module dummy not found")
    if not os.path.isfile(test_module + "ansible_module_dummy.pyc"):
        raise Exception("Ansible module dummy not found")

    # Load test modules
    if 'ansible_module_dummy' not in sys.modules:
        dummy_module = imp.load_source('ansible_module_dummy', test_module + 'ansible_module_dummy.py')
    else:
        dummy_module = imp.load_comp

# Generated at 2022-06-22 22:55:30.140524
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModuleMock()
    darwin_hardware_collector = DarwinHardwareCollector(module=module)
    assert darwin_hardware_collector.module == module
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-22 22:55:37.387357
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule({})

    # Mock sysctl
    class sysctl_mock:
        def __init__(self, module, names):
            self.module = module
            self.names = names

    def sysctl_init(self, module, names):
        return sysctl_mock(module, names)

    sysctl_mock.__init__ = sysctl_init

    # Mock subprocess
    class run_command_mock:
        def __init__(self):
            pass

    def run_command_init(self):
        return run_command_mock()

    run_command_mock.__init__ = run_command_init

    def run_command_run_command(self, args, encoding=None):
        return 0, 'fake_out', 'fake_err'

    run_command

# Generated at 2022-06-22 22:55:43.841573
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class FakeModule:
        def get_bin_path(self, command=None):
            return '/usr/sbin/sysctl'

        def run_command(self, args, encoding=None):
            if args[2] == '-b':
                return 0, b'\x00\x00\x00\x00\xa7\x3f\x0d\x00\x00\x00\x00\x00', ''

    collector = DarwinHardwareCollector()

    # The Unix epoch is 1970-01-01T00:00:00Z.
    # The value returned by the command should be less than this value.
    assert collector._fact_class.get_uptime_facts()['uptime_seconds'] > 0

# Generated at 2022-06-22 22:55:46.865060
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = type('module', (object,), {})()
    module.run_command = correct_run_command
    mac_facts = DarwinHardware(module).get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro6,2'
    assert mac_facts['osversion'] == '14.0.0'
    assert mac_facts['osrevision'] == '14.0.0'



# Generated at 2022-06-22 22:55:48.496908
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    dar = DarwinHardware()
    assert dar is not None


# Generated at 2022-06-22 22:55:57.126942
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    (class method)
    get_system_profile

    Test the get_system_profile method of the DarwinHardware class
    """
    # Import the libraries needed for this test here
    import sys
    import os

    import ansible.module_utils.facts.hardware.darwin
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Setup variables for return values as well as for comparison
    hardware_module_sys_module_path = sys.modules['ansible.module_utils.facts.hardware.darwin'].__file__
    hardware_module_path = ansible.module_utils.facts.hardware.darwin.__file__
    hardware_module_dir = os.path.dirname(hardware_module_path)

# Generated at 2022-06-22 22:55:58.405142
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hardware = DarwinHardware({})
    assert darwin_hardware.platform == 'Darwin'

# Generated at 2022-06-22 22:56:07.247696
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, "", ""))
    hardware = DarwinHardware()
    hardware._module = module
    # Testing with output from different versions of OS X
    # 10.9 Mavericks

# Generated at 2022-06-22 22:56:10.975187
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = MagicMock()
    hw = DarwinHardwareCollector(module=module)
    assert hw.platform == 'Darwin'
    assert hw.fact_class == DarwinHardware


# Generated at 2022-06-22 22:56:12.915008
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()
    assert hardware
    assert hardware.sysctl == {}


# Generated at 2022-06-22 22:56:20.433520
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Returns a dict of parsed values from /usr/sbin/system_profiler

    :return: dict of parsed values from /usr/sbin/system_profiler
    """
    module = AnsibleModule(argument_spec=dict())
    darwin_hw = DarwinHardware()
    data = darwin_hw.get_system_profile()
    module.exit_json(changed=False, ansible_facts=dict(data=data))



# Generated at 2022-06-22 22:56:30.145339
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test the DarwinHardware method get_system_profile by using a
    mocked run_command
    """
    def run_command(self, args, **kwargs):
        out = " Hardware: \n\
            Hardware Overview: \n\
                Model Name: Mac Pro\n\
                Model Identifier: MacPro3,1\n\
                Processor Name: Intel Xeon\n\
                Processor Speed: 2.26 GHz\n\
                Number Of Processors: 2\n\
                Total Number Of Cores: 8\n\
                L2 Cache (per processor): 12 MB\n\
                Memory: 16 GB\n"
        return 0, out, ""  # success

    ah = DarwinHardware()
    ah.module.run_command = run_command

# Generated at 2022-06-22 22:56:35.062538
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mod = AnsibleModuleMock()
    mod.run_command = AnsibleModuleMock.run_command

    # Test getting mac model name via sysctl
    mac_facts = DarwinHardware.get_mac_facts(mod)
    assert 'model' in mac_facts
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts



# Generated at 2022-06-22 22:56:37.852128
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hw = DarwinHardware(dict())

    assert hw.platform == 'Darwin'
    assert isinstance(hw.sysctl, dict)

# Generated at 2022-06-22 22:56:47.069167
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Compute expected values
    expected_cpu_facts = {'processor': 'Intel Core i3 @ 2.50GHz', 'processor_cores': 2, 'processor_vcpus': 2}
    # Create mock of module
    from ansible.module_utils.facts import __ansible_module_commands__ as commands
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    mock_module = type('ansible.module_utils.facts.hardware.darwin.DarwinHardware', (object,), {'run_command': MagicMock()})()
    mock_module.run_command = MagicMock(return_value=(0, 'hw.model: Intel Core i3', ''))

# Generated at 2022-06-22 22:56:48.210396
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
  obj = DarwinHardwareCollector()
  assert obj.collect()

# Generated at 2022-06-22 22:56:55.018972
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Input data for the test
    sysctl_return_values = {
        'machdep.cpu.brand_string': u'Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz',
        'machdep.cpu.core_count': u'4',
    }

    # Define expected results from the test
    expected_results = {
        'processor': u'Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz',
        'processor_cores': u'4',
    }

    # Initialize the tested class
    dh = DarwinHardware()
    dh.module = MockModule()
    dh.sysctl = sysctl_return_values

    # Execute the method under test
    results = dh.get_cpu_facts()

    # We need to ignore '

# Generated at 2022-06-22 22:57:07.449970
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-22 22:57:08.519362
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector


# Generated at 2022-06-22 22:57:18.606516
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Test 1: No vm_stat output
    test_facts = DarwinHardware()
    test_facts.module.run_command = lambda *args, **kwargs: (0, "", "")
    memory_facts = test_facts.get_memory_facts()
    assert memory_facts == {'memtotal_mb': 0, 'memfree_mb': 0}, "Incorrect facts returned: %s" % memory_facts

    # Test 2: Typical vm_stat output
    # (Note: This was captured on a very lightly loaded system, so the total_used is very small.)
    test_facts = DarwinHardware()

# Generated at 2022-06-22 22:57:28.020184
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    h = DarwinHardware()

    assert h.platform == 'Darwin'
    assert h.facts is None

    h.populate()

    assert h.facts is not None
    assert h.facts['processor'] is not None
    assert h.facts['processor_cores'] is not None
    assert h.facts['memtotal_mb'] is not None
    assert h.facts['memfree_mb'] is not None
    assert h.facts['model'] is not None
    assert h.facts['osversion'] is not None
    assert h.facts['osrevision'] is not None
    assert h.facts['uptime_seconds'] is not None

# Generated at 2022-06-22 22:57:29.643209
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    m = DarwinHardware()
    assert m.platform == 'Darwin'

# Generated at 2022-06-22 22:57:39.848604
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Module class import
    module = type('module', (object,), dict())

# Generated at 2022-06-22 22:57:43.613516
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    cpu_facts = DarwinHardwareCollector({})
    result = cpu_facts.get_cpu_facts()
    assert result['processor'].lower().startswith('intel')
    assert result['processor_cores'].isdigit()
    assert result['processor_vcpus'].isdigit()


# Generated at 2022-06-22 22:57:46.587810
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwinHardware = DarwinHardware()

    assert darwinHardware.platform == 'Darwin'

# Generated at 2022-06-22 22:57:58.254373
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import json
    import os
    import sys

    output = True
    sample_fact_file = False


# Generated at 2022-06-22 22:58:09.509680
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-22 22:58:23.012167
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # create a class instance
    dh = DarwinHardware({})
    # read the sysctl contents
    dh.sysctl = {'hw.model': 'MacbookPro9,1',
                 'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-3317U CPU @ 1.70GHz',
                 'machdep.cpu.core_count': '2',
                 'hw.physicalcpu': '2',
                 'hw.ncpu': '2'}
    hardware.facts_cache.update(dh.populate())
    # test the output
    assert hardware.facts_cache['processor'] == dh.sysctl['machdep.cpu.brand_string']


# Generated at 2022-06-22 22:58:28.808968
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Run tests only with darwin platform
    from sys import platform as _platform
    from sys import version_info
    if _platform != 'darwin':
        return

    if version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    import mock

    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.run_command = mock.Mock(return_value=(0, '', ''))
            self.fail_json = mock.Mock(return_value=False)
            self.get_bin_path = mock.Mock(return_value='/path/to/bin')

    class TestDarwinHardware(unittest.TestCase):
        def test_populate(self):
            module

# Generated at 2022-06-22 22:58:37.698470
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, 'hw.model: x86_64\nkern.osversion: 15.5.0\nkern.osrevision: 15.5.0', '')
    module_utils = FakeAnsibleModuleUtils(module)
    darwin_hardware = DarwinHardware(module_utils)
    darwin_hardware.sysctl = {'kern.osversion': '15.5.0', 'kern.osrevision': '15.5.0'}
    results = darwin_hardware.get_mac_facts()
    assert results != dict()
    assert results['model'] == 'x86_64'
    assert results['osversion'] == '15.5.0'

# Generated at 2022-06-22 22:58:50.192061
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """Test DarwinHardware.populate()"""
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "/usr/sbin/system_profiler: Success\n", '')
    module.get_bin_path.side_effect = lambda x: x

# Generated at 2022-06-22 22:59:00.988544
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Init class object
    myclass = DarwinHardware()
    myclass.module = object()
    # Mock method run_command
    myclass.module.run_command = mock_run_command
    # Execute code
    system_profile = myclass.get_system_profile()
    # Assert values

# Generated at 2022-06-22 22:59:11.151765
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware = DarwinHardware()
    hardware.module = MockAnsibleModule()

# Generated at 2022-06-22 22:59:13.241000
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hardware = DarwinHardware()
    assert darwin_hardware


# Generated at 2022-06-22 22:59:23.826400
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import doctest
    module, dummy_config_source = setup_mock_module()

# Generated at 2022-06-22 22:59:28.759637
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-8850H CPU @ 2.60GHz'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor_vcpus'] == '2'

# Generated at 2022-06-22 22:59:40.851696
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test what happens when brand_string is present 
    class MockModule():
        def __init__(self):
            self.params = None
            self.fail_json = None
            self.run_command = None
            
        def dict(self, *args):
            d = dict()
            d.update(args)
            return d

        def fail_json(self, *args):
            raise AssertionError(args)
            
        def run_command(self, args):
            return (0, args, None)

    module = MockModule()
    module.run_command = lambda args: (0, 'Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz\n', '')
    module.get_bin_path = lambda args: '/bin/'+args
    # Test what happens

# Generated at 2022-06-22 22:59:52.802516
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    fake_module = FakeAnsibleModule()
    fake_module._sysctl = {
        'hw.memsize': 15669833728,
        'machdep.cpu.core_count': 4,
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-2620M CPU @ 2.70GHz',
        'hw.physicalcpu': 2,
        'hw.logicalcpu': 4,
        'hw.ncpu': 4,
        'kern.osversion': '15.6.0',
        'kern.osrevision': '20180629161300.0.0.0.1'
    }
    darwin_hardware = DarwinHardware(fake_module)
    darwin_hardware._sysctl = fake_module._sysctl
    cpu

# Generated at 2022-06-22 22:59:59.396556
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Set up module parameters for test:
    module = type('module', (object,), {
        'run_command': lambda *args, **kwargs: (
            0,  # rc
            "hw.model: MacBookPro11,5\n",  # out
            ''  # err
        )
    })()

    # Set up DarwinHardware class parameters for test:
    sysctl = dict()

    # Instantiate DarwinHardware object:
    darwin_hardware = DarwinHardware(module=module, sysctl=sysctl)

    # Verify the facts:
    assert darwin_hardware.get_mac_facts() == dict(
        model='MacBookPro11,5',
        osversion='',
        osrevision='')

# Generated at 2022-06-22 23:00:02.022400
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = '/bin/vm_stat'
    DarwinHardware(module).populate()

# Generated at 2022-06-22 23:00:06.494807
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=[])})
    hw_collector = DarwinHardwareCollector(module)
    hw_facts = hw_collector.collect()
    assert hw_facts is not None


# Generated at 2022-06-22 23:00:17.323493
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    '''
    Run the gather facts test on DarwinHardware get_cpu_facts.
    '''
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5287U CPU @ 2.90GHz',
        'machdep.cpu.core_count': '4'
    }
    darwin_obj = DarwinHardware({'module_setup': True, 'sysctl': sysctl})
    assert 'Intel(R) Core(TM) i5-5287U CPU @ 2.90GHz' == darwin_obj.get_cpu_facts()['processor']
    assert '4' == darwin_obj.get_cpu_facts()['processor_cores']

# Generated at 2022-06-22 23:00:20.501189
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hw = DarwinHardware(dict())
    assert darwin_hw.platform == 'Darwin'


# Generated at 2022-06-22 23:00:30.313977
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    result = DarwinHardware(module).populate()
    assert isinstance(result['osversion'], str)
    assert isinstance(result['osrevision'], str)
    assert isinstance(result['model'], str)
    assert isinstance(result['processor'], str)
    assert isinstance(result['processor_vcpus'], str) or isinstance(result['processor_vcpus'], int)
    assert isinstance(result['processor_cores'], str) or isinstance(result['processor_cores'], int)
    assert isinstance(result['memtotal_mb'], int)
    assert isinstance(result['memfree_mb'], int)

# Generated at 2022-06-22 23:00:40.834738
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeModule('Darwin')
    module.options['gather_subset'] = ['!all', '!min']

    # Intel

# Generated at 2022-06-22 23:00:44.507623
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """
    Unit test for method 'populate' of class 'DarwinHardware'
    """
    class MockModule():
        def __init__(self):
            self.run_command = lambda *args, **kwargs: (0, '', '')
        def get_bin_path(self, *args, **kwargs):
            return '/bin/true'

    obj = DarwinHardware(MockModule)
    collected_facts = {}
    facts = obj.populate(collected_facts)
    assert facts


# Generated at 2022-06-22 23:00:55.074424
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    mock_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Mock the values that sysctl returns
    mock_module.run_command.return_value = (0, 'hw.memsize: 8589934592', '')

# Generated at 2022-06-22 23:01:07.010681
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    def mock_run_command(module, cmd):
        if cmd == ["/usr/sbin/system_profiler", "SPHardwareDataType"]:
            return (0, "Hardware:\nHardware Overview:\nModel Name: MacBook Pro\nModel Identifier: MacBookPro5,5\nProcessor Name: Intel Core 2 Duo\nProcessor Speed: 2.26 GHz\nNumber Of Processors: 1\nTotal Number Of Cores: 2\nL2 Cache: 6 MB\nMemory: 4 GB\nBus Speed: 1.07 GHz\nBoot ROM Version: MBP55.00AC.B03\nSMC Version (system): 1.48f2", "")
        if cmd == ["sysctl", "hw.model"]:
            return (0, "hw.model: iMac11,1\n", "")

# Generated at 2022-06-22 23:01:10.218250
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector_obj = DarwinHardwareCollector()
    assert hardware_collector_obj._fact_class is DarwinHardware
    assert hardware_collector_obj._platform is 'Darwin'

# Generated at 2022-06-22 23:01:21.704580
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.logicalcpu': 2,
        'hw.physicalcpu': 1
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_vcpus'] == 2

    module = MockModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.logicalcpu': 8,
        'hw.physicalcpu': 6
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 6
    assert cpu_facts['processor_vcpus'] == 8


# Generated at 2022-06-22 23:01:34.045188
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class ArgumentSpec:
        def __init__(self):
            self.module_args = '''
            '''
            self.supports_check_mode = True
        def get(self, attr):
            return getattr(self, attr)

    class Module:
        def __init__(self, argument_spec, check_invalid_arguments=True, bypass_checks=False):
            self.argument_spec = argument_spec
        def get_bin_path(self, attr):
            return 'echo'

# Generated at 2022-06-22 23:01:45.690176
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    sys_profiler_cmd = ["/usr/sbin/system_profiler", "SPHardwareDataType"]
    module = MockModule()
    hardware = DarwinHardware(module)

# Generated at 2022-06-22 23:01:57.570909
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import tempfile
    from ansible.module_utils.facts import ModuleData
    from ansible.module_utils.facts.system.darwin import DarwinHardware as TestClass
    from ansible.module_utils._text import to_bytes

    tmp_file = tempfile.TemporaryFile()
    tmp_file.write(to_bytes('hw.model: iMac5,1\n'))
    tmp_file.write(to_bytes('kern.osversion: 15D21\n'))
    tmp_file.write(to_bytes('kern.osrevision: 1\n'))
    tmp_file.seek(0)
    tmp_module = ModuleData(argument_spec=dict())
    tmp_module.run_command.return_value = (0, '', '')
    tmp_module.get_bin_path

# Generated at 2022-06-22 23:02:09.133394
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    result = hardware.populate()
    assert result['processor'] == 'Intel(R) Core(TM)2 Duo CPU     T7250  @ 2.00GHz'
    assert result['processor_cores'] == '2'
    assert result['processor_vcpus'] == '2'
    assert result['memtotal_mb'] == '2048'
    assert result['memfree_mb'] == '1024'
    assert result['model'] == 'MacBookPro4,1'
    assert result['osversion'] == '15.6.0'
    assert result['osrevision'] == '19G2021'
    assert result['uptime_seconds'] > 0


# Generated at 2022-06-22 23:02:10.722843
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    d = DarwinHardware()
    assert d.platform == 'Darwin'
    assert d.sysctl == {}


# Generated at 2022-06-22 23:02:19.757479
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    f = DarwinHardware(module)
    result = f.get_system_profile()
    assert 'Model Name' in result
    assert 'Processor Name' in result
    assert 'Processor Speed' in result
    assert 'Number of Processors' in result
    assert 'Memory' in result
    assert 'Boot ROM Version' in result
    assert 'SMC Version (system)' in result
    assert 'Serial Number (system)' in result
    assert 'Hardware UUID' in result



# Generated at 2022-06-22 23:02:26.878134
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    d = DarwinHardware(module)
    d._get_sysctl = lambda key: {'machdep.cpu.brand_string': 'test CPU'}
    cpu_facts = d.get_cpu_facts()

    assert 'test CPU' == cpu_facts['processor']
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts


# Generated at 2022-06-22 23:02:32.393222
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Unit test for get_system_profile method of class DarwinHardware.
    Method tested through cmdline execution.
    This test requires the Darwin platform.
    """
    dh = DarwinHardware()
    data = dh.get_system_profile()
    assert (data['Serial Number'] != ' ')

# Generated at 2022-06-22 23:02:44.040960
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import json
    import os
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.base import HardwareCollector

    test_lib_path = os.path.join(os.path.dirname(__file__), 'lib')

    # This is a stub of the actual DarwinHardware class
    class TestDarwinHardware(DarwinHardware):
        platform = 'Darwin'

        def __init__(self, module):
            self.module = module
            self.sysctl = json.load(open(os.path.join(test_lib_path, 'sysctl-hw.json')))


# Generated at 2022-06-22 23:02:52.867420
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware as dh

# Generated at 2022-06-22 23:02:55.965104
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware = DarwinHardware()

    # test without collected facts
    hardware.populate()

    # test with collected facts
    hardware.populate({'ansible_product_name': 'MacBookPro'})

# Generated at 2022-06-22 23:02:57.906615
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    mod = AnsibleModule(argument_spec={})
    har = DarwinHardware(mod)
    assert har.platform == 'Darwin'

# Generated at 2022-06-22 23:02:59.946253
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = MockAnsibleModule()
    dh = DarwinHardware(module)
    profiles = dh.get_system_profile()
    assert isinstance(profiles, dict)



# Generated at 2022-06-22 23:03:03.868166
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class FakeModule:
        def run_command(self, cmd):
            return 0, 0, b'kern.boottime: { sec = 1558686443, usec = 0 }\n'

        def get_bin_path(self, cmd):
            return cmd

    hardware = DarwinHardware(module=FakeModule())
    uptime_facts = hardware.get_uptime_facts()

    assert isinstance(uptime_facts['uptime_seconds'], int)

# Generated at 2022-06-22 23:03:16.151720
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = Mock(return_value=(0, '', ''))
    darwin_hardware = DarwinHardware(module)
    facts = darwin_hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM)2 Duo CPU     P8600  @ 2.40GHz'
    assert facts['processor_cores'] == '2'
    assert facts['processor_vcpus'] == '4'
    assert facts['model'] == 'MacBookPro5,3'
    assert facts['memtotal_mb'] == '5002'
    assert facts['memfree_mb'] == '2980'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '17G8030'
    assert facts

# Generated at 2022-06-22 23:03:19.853735
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    m = module_mock(module)
    result = DarwinHardware(m).get_mac_facts()

    assert result['model'] == 'MacBookAir6,2'
    assert result['osversion'] == '14.0.0'
    assert result['osrevision'] == '14A298i'

# Generated at 2022-06-22 23:03:31.840252
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class DummyModule:
        def __init__(self):
            self._hw_facts = {
                'hw.model': 'Power Mac 4,1',
                'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4310U CPU @ 2.00GHz',
                'machdep.cpu.core_count': 4,
                'hw.physicalcpu': 4,
                'hw.logicalcpu': 8,
            }

        def get_bin_path(self, name, required=True, opt_dirs=[]):
            return '/usr/bin/' + name

        def run_command(self, cmd, check_rc=True):
            self.run_command_called = True

# Generated at 2022-06-22 23:03:38.854486
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import unittest

    class StubModule(object):
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/usr/sbin/sysctl'

        @staticmethod
        def run_command(*args, **kwargs):
            return (0, b'kern.boottime: { sec = 1427609950, usec = 800003 }', "")

    fact = DarwinHardware(module=StubModule())
    expected_uptime_facts = {
        'uptime_seconds': int(time.time() - 1427609950),
    }
    uptime_facts = fact.get_uptime_facts()
    assert uptime_facts == expected_uptime_facts

# Generated at 2022-06-22 23:03:43.600160
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hw = DarwinHardware(None)
    expected = {
        'Hardware Overview': '',
        'Serial Number': '',
        'Model': '',
        'Modell': '',
        'Boot ROM Version': '',
        'SMC Version': '',
        'System Version': '',
        'Hardware UUID': '',
    }
    assert hw.get_system_profile() == expected

# Generated at 2022-06-22 23:03:49.636553
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import ansible.module_utils.facts.hardware.darwin as darwin_hw_mod
    import textwrap
    command_output = textwrap.dedent(u'''\
    Hardware:

      Hardware Overview:

          Model Name: Mac Pro
          Model Identifier: MacPro3,1
          Processor Name: Quad-Core Intel Xeon
          Processor Speed: 2.8 GHz
          Number of Processors: 2
          Total Number of Cores: 8
          L2 Cache (per Processor): 12 MB
          Memory: 8 GB
          Bus Speed: 1.6 GHz
          Boot ROM Version: MP31.006C.B05
          SMC Version (system): 1.21f4
          Serial Number (system): G89212DS5KT
          Hardware UUID: 00000000-0000-1000-8000-007459686122

    ''')
   