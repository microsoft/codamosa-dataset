

# Generated at 2022-06-22 22:53:46.706778
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector

# Generated at 2022-06-22 22:53:52.016694
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = DummyModule()
    hardware_facts = DarwinHardware(module)
    sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    hardware_facts.sysctl = sysctl
    mac_facts = hardware_facts.get_mac_facts()
    assert mac_facts['model']
    assert mac_facts['osversion']
    assert mac_facts['osrevision']



# Generated at 2022-06-22 22:54:05.064812
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    mac_facts = {
        'model': 'MacBookPro',
        'osversion': '15.5.0',
        'osrevision': '19F101',
    }
    cpu_facts = {
        'processor': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'processor_cores': 4,
        'processor_vcpus': 8,
    }
    memory_facts = {
        'memtotal_mb': 8192,
        'memfree_mb': 4096,
    }
    uptime_facts = {
        'uptime_seconds': 600,
    }


# Generated at 2022-06-22 22:54:14.685006
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())

    # Init base class
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2630 v4 @ 2.20GHz',
        'machdep.cpu.core_count': 4,
    }
    # Run method
    cpu_facts = darwin_hardware.get_cpu_facts()

    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2630 v4 @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''



# Generated at 2022-06-22 22:54:23.412525
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hardware = DarwinHardware()
    print('Processor: {}'.format(darwin_hardware.processor))
    print('Processor cores: {}'.format(darwin_hardware.processor_cores))
    print('Memory total: {}'.format(darwin_hardware.memtotal_mb))
    print('Memory free: {}'.format(darwin_hardware.memfree_mb))
    print('Model: {}'.format(darwin_hardware.model))
    print('OS Version: {}'.format(darwin_hardware.osversion))
    print('OS Revision: {}'.format(darwin_hardware.osrevision))
    print('Uptime: {}'.format(darwin_hardware.uptime_seconds))


if __name__ == '__main__':
    test_DarwinHardware()

# Generated at 2022-06-22 22:54:28.266078
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import modules.darwin_facts
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class MockModule(object):
        def fail_json(self, *args, **kwargs):
            self.fail = True

        def run_command(self, args, encoding=None):
            if args[0].endswith('vm_stat'):
                if hasattr(self, 'fail'):
                    return 2, None, None
                else:
                    with open('../test/unit/data/darwin_vm_stat') as fh:
                        return 0, fh.read(), None

# Generated at 2022-06-22 22:54:39.781264
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from collections import namedtuple
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    stub_sysctl = {}

    stub_sysctl['machdep.cpu.brand_string'] = 'Intel(R) Xeon(R) CPU E5-2699 v3 @ 2.30GHz'
    stub_sysctl['machdep.cpu.core_count'] = "2"

    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all', '!min'], type='list'),
        }
    )
    hardware = DarwinHardware(module=module)
    hardware.sysctl = stub_sysctl

    cpu_facts = hardware.get_cpu_facts()

    Facts = named

# Generated at 2022-06-22 22:54:52.337544
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    passed = True

    # Test with processor facts
    test_fact = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz',
        'machdep.cpu.core_count': '2'
    }
    expect_fact = {
        'processor': 'Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz',
        'processor_cores': '2',
        'processor_vcpus': ''
    }

    test_class = DarwinHardware(None, test_fact)
    cpu_facts1 = test_class.get_cpu_facts()
    if cpu_facts1 != expect_fact:
        passed = False
        print("Failed - Test with processor facts")

    # Test with PowerPC facts

# Generated at 2022-06-22 22:54:57.341067
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import pytest

    class TestModule:
        def __init__(self, boottime_seconds):
            self.boottime = boottime_seconds
            self.bin_path = {'sysctl': '/sbin/sysctl'}

        def get_bin_path(self, name):
            if name in self.bin_path:
                return self.bin_path[name]
            raise ValueError

        def run_command(self, cmd, encoding=None):
            if cmd == ['/sbin/sysctl', '-b', 'kern.boottime']:
                return 0, struct.pack('@L', self.boottime)
            raise ValueError

    with pytest.raises(ValueError):
        hw_collector = DarwinHardwareCollector(TestModule(0))
        hw_collector

# Generated at 2022-06-22 22:55:03.467749
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # Create a DarwinHardware with 'module'
    darwin_hw = DarwinHardware(module)
    facts = darwin_hw.populate()
    # Check for required 'processor' fact
    assert 'processor' in facts


# Generated at 2022-06-22 22:55:05.518523
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Just ensure that we can create the object.
    hc = DarwinHardwareCollector()
    assert isinstance(hc, HardwareCollector)

# Generated at 2022-06-22 22:55:12.586087
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.hardware import DarwinHardware

    fact_cache = FactCache()
    module_mock = fact_cache.get_module_mock()
    hardware_mock = DarwinHardware(module_mock)

    # test get_mac_facts() method

    # Mock "sysctl hw.model" command to return "hw.model: MacBookPro12,1"
    module_mock.run_command.return_value = (0, "hw.model: MacBookPro12,1", '')

    # Check that "hw.model" is correctly extracted from "sysctl hw.model" command output.

# Generated at 2022-06-22 22:55:17.379792
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mac_facts=DarwinHardware.get_system_profile()
    assert 'Model Name' in mac_facts
    assert 'Model Identifier' in mac_facts
    assert 'Processor Name' in mac_facts
    assert 'Processor Speed' in mac_facts

# Generated at 2022-06-22 22:55:29.436387
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    sysctl_cmd = '/usr/sbin/sysctl'
    cmd = [sysctl_cmd, '-n', 'kern.boottime']
    # run the command
    rc, out, err = get_bin_path('', True).run_command(cmd)
    # get current time
    t = int(time.time())
    # remove the last char (new line)
    out = out[:-1]
    # remove the comma
    out = out.replace(',', '')
    # replace the . with .0
    out = out.replace('.', '.0')
    # split the string in 2
    tboot = int(out.split()[-1])
    uptime_seconds = t - tboot
    # get the hardware uptime
    hardware = DarwinHardware()

# Generated at 2022-06-22 22:55:39.539422
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # To test this method, we need to mock module_utils.common.process.get_bin_path
    import module_utils.common.process
    from unittest.mock import patch

    class FakeModule(object):
        def __init__(self, mock_run_command, mock_get_bin_path):
            self.run_command = mock_run_command
            self.get_bin_path = mock_get_bin_path

    with patch.object(module_utils.common.process, 'get_bin_path') as get_bin_path_mock:
        get_bin_path_mock.return_value = 'vm_stat'
        module = FakeModule(mock_run_command={}, mock_get_bin_path={})
        # On Darwin, the default format is annoying to parse.
        #

# Generated at 2022-06-22 22:55:44.999624
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl
    class MockModule:
        def run_command(self):
            return 0, "", ""
    module_obj = MockModule()
    hardware_obj = DarwinHardware(module=module_obj)
    assert hardware_obj.populate == {}

# Generated at 2022-06-22 22:55:55.143412
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hardware = DarwinHardware(module)

    expected_facts = {
        'processor': 'Intel(R) Core(TM) i7-6820HK CPU @ 2.70GHz',
        'processor_cores': 8,
        'processor_vcpus': '',
        'model': 'MacBookPro13,3',
        'osversion': '16.5.0',
        'osrevision': '',
        'uptime_seconds': 39456,
        'memtotal_mb': 16384,
        'memfree_mb': 4025
    }

    returned_facts = hardware.populate()
    assert expected_facts == returned_facts



# Generated at 2022-06-22 22:56:04.782892
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockModule({})
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = {
        'kern.osversion': '15.6.0',
        'kern.osrevision': '19G2021'
    }
    cmd_out = """hw.model: MacBookAir6,2"""
    module.run_command = Mock(return_value=(0, cmd_out, ''))
    facts = darwin_hardware.get_mac_facts()
    assert facts['model'] == 'MacBookAir6,2'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'


# Generated at 2022-06-22 22:56:07.304552
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module=module)

    assert hardware.platform == 'Darwin'

# Generated at 2022-06-22 22:56:17.596308
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # On Darwin, the default format is annoying to parse
    # Use -b to get the raw value and decode it
    sysctl_cmd = get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'kern.boottime']

    # We need to get raw bytes, not UTF-8.
    rc, out, err = module.run_command(cmd, encoding=None)

    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if rc != 0 or len(out) < struct_size:
        return


# Generated at 2022-06-22 22:56:26.907870
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    facts_dict = {
        'processor': 'Intel(R) Core(TM) i7-8559U CPU @ 2.70GHz',
        'processor_cores': 8,
        'processor_vcpus': 8,
        'memtotal_mb': 16384,
        'memfree_mb': 16384,
        'model': 'MacBookPro15,1',
        'osversion': '19G2021',
        'osrevision': '2',
        'uptime_seconds': 484345,
    }
    hw_collector = DarwinHardwareCollector()
    assert hw_collector.collect(None) == facts_dict

# Generated at 2022-06-22 22:56:33.372221
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():

    # Create a collector object and pass it a module_executor mock
    darwin_hw_collector = DarwinHardwareCollector(None)

    # Assert that the correct fact class was set
    assert darwin_hw_collector._fact_class == DarwinHardware
    # Assert that the correct platform was set
    assert darwin_hw_collector._platform == 'Darwin'

# Generated at 2022-06-22 22:56:44.477350
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_facts = {
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2620 v3 @ 2.40GHz',
        'machdep.cpu.core_count': '12',
        'hw.memsize': '67108864000',
        'hw.ncpu': '2',
        'kern.osversion': '14.6.0',
        'kern.osrevision': '14.6.0',
    }

    dhw = DarwinHardware(module=None, sysctl=hardware_facts)
    memory_facts = dhw.get_memory_facts()
    cpu_facts = dhw.get_cpu_facts()
    mac_facts = dhw.get_mac_facts()
    uptime_facts = dhw.get_upt

# Generated at 2022-06-22 22:56:50.723344
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts import FactManager

    module = MockModule()
    fact_manager = FactManager(module=module)
    facts = DarwinHardware(fact_manager)

    facts.populate()

    for key in (
        'uptime_seconds',
        'memfree_mb',
        'memtotal_mb',
        'processor_cores',
        'processor',
        'osversion',
        'osrevision',
        'model',
        'processor_vcpus',
    ):
        assert key in facts.data, 'Failed to populate key: {}'.format(key)


# Generated at 2022-06-22 22:56:56.361884
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import sys
    if sys.version_info[:2] <= (2, 6):
        import unittest2 as unittest
    else:
        import unittest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_memory_facts

    class FakeModule:
        def __init__(self, out, rc=0):
            self.out = out
            self.rc = rc

        def run_command(self, arg):
            out = self.out
            rc = self.rc
            return rc, out, ""

        def get_bin_path(self, arg):
            return "vm_stat"


# Generated at 2022-06-22 22:57:05.974423
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Test possibility that system_profiler is not available on the system
    m = MockModule()
    m.run_command.return_value = (1, "", "")
    d = DarwinHardware(m)
    assert d.get_system_profile() == {}

    # Test the correct data is returned
    m = MockModule()
    m.run_command.return_value = (0, "Machinename: my-mac-name\n", "")
    d = DarwinHardware(m)
    assert d.get_system_profile() == {
        'Machinename': 'my-mac-name',
    }

# Generated at 2022-06-22 22:57:16.624138
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import os
    import json
    import sys

    old_env = os.environ.copy()
    d = DarwinHardware()
    os.environ = {"PATH": "/usr/sbin:/usr/bin"}

    # Test the case when the command returns zero
    _rc, out, _err = d.module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])

    os.environ = old_env

    # Test the case when the command returns non-zero
    if sys.version_info.major >= 3:
        # Python 3 moved the class to a subpackage
        from unittest.mock import Mock
    else:
        from mock import Mock

    d.module.run_command = Mock

# Generated at 2022-06-22 22:57:19.766605
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hardware = DarwinHardware(None)

    for key in darwin_hardware.sysctl.keys():
        assert key in ['hw.memsize', 'kern.osversion', 'kern.osrevision']


# Generated at 2022-06-22 22:57:31.232303
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from StringIO import StringIO
    from ansible.module_utils.facts import ModuleData
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    # GIVEN
    data = {
        'ANSIBLE_CACHE_PLUGIN': 'memory',
        'ANSIBLE_CACHE_PLUGIN_CONNECTION': '',
        'ANSIBLE_CACHE_PLUGIN_PREFIX': 'ansible_check_',
        'ANSIBLE_STDOUT_CALLBACK': 'unixy',
        'ANSIBLE_FORCE_COLOR': False,
    }

# Generated at 2022-06-22 22:57:33.852378
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert d._platform == 'Darwin'
    assert isinstance(d._fact_class, DarwinHardware)
    assert d._fact_class.platform == 'Darwin'

# Generated at 2022-06-22 22:57:43.467178
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Get the time since booting in seconds, using a raw call to sysctl
    sysctl_cmd = '/usr/sbin/sysctl'
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    rc, out, err = module.run_command(cmd, encoding=None)
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if rc != 0 or len(out) < struct_size:
        return {}

    (time_since_boot, ) = struct.unpack(struct_format, out[:struct_size])

    # Instantiate Hardware class
    hardware = DarwinHardware()

    # Call get_uptime_facts of class DarwinHardware
    uptime_facts = hardware.get_uptime_facts()

    # Check if the upt

# Generated at 2022-06-22 22:57:46.066474
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert issubclass(DarwinHardwareCollector, HardwareCollector)


# Generated at 2022-06-22 22:57:57.807430
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-22 22:58:04.820819
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform
    import datetime
    import time

    # We have 4 cases when we run the unit test on Darwin:
    #
    # 1. We run the test on Linux (i.e. 'Darwin' not in platform.system()) but the test
    #    is executed from file tests/unit/module_utils/facts/hardware/darwin.py
    # 2. We run the test on Darwin but the test is executed from
    #    test/units/module_utils/facts/hardware/darwin.py
    # 3. We run the test on Darwin and the test is executed from
    #    test/units/module_utils/facts/hardware/darwin.py
    # 4. We run the test on Darwin and the test is executed from
    #    test/units/module_utils/facts/hardware/darwin.py

# Generated at 2022-06-22 22:58:14.931775
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import sys

    module = type('AnsibleModule', (object,), dict(
        check_mode=False,
        run_command=lambda *args, **kwargs: (0, '/usr/sbin/system_profiler SPHardwareDataType\nProcessor Speed: 2.9 GHz\nProcessor Name: Intel Core i7\nProcessor Interconnect Speed: 4.8 GT/s\n', ''),
    ))()

    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()

    if sys.version_info[0] < 3:
        assert system_profile == {
            'Processor Interconnect Speed': u'4.8 GT/s',
            'Processor Speed': u'2.9 GHz',
            'Processor Name': u'Intel Core i7',
        }

# Generated at 2022-06-22 22:58:19.880724
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module=module)
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['osversion'] == '14.3.0'


# Generated at 2022-06-22 22:58:25.677364
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MagicMock()
    mac_hardware = DarwinHardware(module)
    mac_hardware.sysctl = {'kern.osversion': 'xxx', 'kern.osrevision': 'xxx'}
    rc = 0
    out = 'hw.model: MacBookPro14,1\n'
    err = ''
    module.run_command.return_value = (rc, out, err)
    mac_facts = mac_hardware.get_mac_facts()
    assert mac_facts == {'model': 'MacBookPro14,1', 'osversion': 'xxx', 'osrevision': 'xxx'}


# Generated at 2022-06-22 22:58:35.805954
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    fake_module = MagicMock()

# Generated at 2022-06-22 22:58:46.059307
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a fake module
    module = FakeModule()

    # Give control over the sysctl command to the fake module
    module.sysctl_fake_out = b"{ kern.boottime = { sec = 1477791038, usec = 794192 } }\n"
    DarwinHardware.get_uptime_facts =  DarwinHardware_get_uptime_facts_fake
    hardware = DarwinHardware(module)
    hardware.get_uptime_facts()
    assert hardware._uptime_seconds == int(time.time() - 1477791038 - 0.794192)

# Fake the DarwinHardware.get_uptime_facts method

# Generated at 2022-06-22 22:58:49.509397
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Test input-output for seconds
    uptime_seconds = [0, 1, 2, 3, 1e6, 1e7, 1e8]

    for sec in uptime_seconds:
        raw_uptime = bytes(struct.pack('@Q', sec))
        hw = DarwinHardware(module=None, sysctl={})
        assert(hw.get_uptime_facts() == {'uptime_seconds': int(sec)})

# Generated at 2022-06-22 22:58:52.324820
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware(dict())
    assert hardware.platform == 'Darwin'


# Generated at 2022-06-22 22:59:02.463796
# Unit test for method get_mac_facts of class DarwinHardware

# Generated at 2022-06-22 22:59:11.764327
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mac_facts = {
        'model': 'MacBookPro11,5',
        'osversion': '16.7.0',
        'osrevision': '1',
    }
    module = MockModule()
    mock_sysctl = {
        'hw.model': 'hw.model: MacBookPro11,5',
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1',
    }
    module.run_command.return_value = (0, '', '')
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = mock_sysctl
    facts = darwin_hardware.get_mac_facts()
    for key, value in mac_facts.items():
        assert key in facts
        assert facts

# Generated at 2022-06-22 22:59:20.508886
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    '''
    Unit test for method populate of class DarwinHardware
    '''
    import platform
    import os

    # Mock class that allows to mock the run_command method
    class MockModule:
        def __init__(self):
            self.run_command = MockModule.run_command

        # Mock method that allows to return a fake system profile with
        # PowerPC informations

# Generated at 2022-06-22 22:59:30.525111
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Get an instance of DarwinHardware
    mac_facts = DarwinHardware(module)

    # Run the populate method
    mac_facts.populate()

    # Get the total number of facts generated
    mac_facts_length = len(mac_facts.facts)

    # Get the number of expected facts
    expected_mac_facts_length = 9

    # Test to make sure the number of facts match
    assert mac_facts_length == expected_mac_facts_length

    # Now let's test to make sure a few of the facts match expected values
    assert mac_facts.facts['osversion'] == '17.5.0'
    assert mac_facts.facts['osrevision'] == '15F34'
    assert mac_

# Generated at 2022-06-22 22:59:36.436456
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = fake_module()
    hardware = DarwinHardware(module)


# Generated at 2022-06-22 22:59:45.171519
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # testing a fixed value and the parsed response of sysctl -b kern.boottime.
    checks = ((1487230590, {'uptime_seconds': 1055}),
              (b"\x6c\xd6\x75\xa3", {'uptime_seconds': 47743}))
    h = DarwinHardware()
    for c in checks:
        sysctl_cmd = h.module.get_bin_path('sysctl')
        h.module.run_command = lambda x, encoding=None: (0, c[0], '')
        assert c[1] == h.get_uptime_facts()

# Generated at 2022-06-22 22:59:52.309122
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    d = DarwinHardware()

    # Test for PowerPC
    d.sysctl = {'hw.physicalcpu': 1, 'hw.logicalcpu': 2}
    d.get_system_profile = lambda: {'Processor Name': 'PowerPC 970 (2.2)', 'Processor Speed': '2.0GHz'}
    cpu_facts = d.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC 970 (2.2) @ 2.0GHz'
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_vcpus'] == 2

    # Test for Intel
    d.sysctl = {'machdep.cpu.core_count': 2, 'machdep.cpu.thread_count': 4}
    d.get_system_profile = lambda: {}

# Generated at 2022-06-22 22:59:59.531515
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class DarwinHardware
    """
    fact = DarwinHardware()
    fact.sysctl = dict(pagesize=4096)

# Generated at 2022-06-22 23:00:02.874574
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    local_facts = {}
    osxHardwareCollector = DarwinHardware(module=local_facts)
    osxHardwareCollector.populate()

if __name__ == '__main__':
    test_DarwinHardwareCollector()

# Generated at 2022-06-22 23:00:04.710737
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hardware = DarwinHardware(dict())
    assert darwin_hardware.platform == 'Darwin'

# Generated at 2022-06-22 23:00:16.918042
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    raw_json_output = """{
    "hw": {
        "memsize": 16777216
    },
    "machdep": {
        "cpu": {
            "core_count": 2,
            "brand_string": "Intel(R) Core(TM) i5-5287U CPU @ 2.90GHz"
        }
    },
    "kern": {
        "osversion": "15.6.0",
        "osrevision": "17G6030",
        "boottime": "17335183.571216"
    }
}
"""
    fake_module = dict()


# Generated at 2022-06-22 23:00:28.285008
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware(None)

    # Test when vm_stat is not present
    def get_bin_path_without_vm_stat(x):
        if x == 'vm_stat':
            raise ValueError
        return x
    darwin_hardware.get_bin_path = get_bin_path_without_vm_stat

    assert darwin_hardware.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}

    # Test when vm_stat is present, but the output contains not only numbers
    def get_bin_path_with_vm_stat(x):
        if x == 'vm_stat':
            return 'vm_stat'
        return x


# Generated at 2022-06-22 23:00:30.688445
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    dhc = DarwinHardwareCollector("")
    assert dhc._platform == 'Darwin'

# Generated at 2022-06-22 23:00:41.109849
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware()

    # Assert that the class is inherited from the base Hardware class.
    assert isinstance(hardware, Hardware)
    # Assert the platform is Darwin.
    assert hardware.platform == "Darwin"

    # Assert the subclass populate method is called.
    get_mac_facts = hardware.get_mac_facts()
    assert "osversion" in get_mac_facts
    assert "osrevision" in get_mac_facts

    # Assert the CPU facts are not empty
    cpu_facts = hardware.get_cpu_facts()
    assert "processor_cores" in cpu_facts
    assert "processor" in cpu_facts
    assert "processor_vcpus" in cpu_facts

    # Assert the memory facts

# Generated at 2022-06-22 23:00:48.157589
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    class FakeModule:
        def __init__(self):
            self.run_command = run_command

        def get_bin_path(self, command):
            return '/usr/sbin/system_profiler'

    def run_command(command, encoding='utf-8'):
        return 0, '', ''

    module = FakeModule()
    hardware_obj = DarwinHardware(module)

    hardware_obj.populate()



# Generated at 2022-06-22 23:00:52.683346
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware = DarwinHardware(module)

    # test populate, model should match output from running sysctl hw.model in the terminal
    assert hardware.populate()['model'] == 'MacBookPro7,1'

# Generated at 2022-06-22 23:01:05.072477
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = MockModule()
    hardware = DarwinHardware(module)

# Generated at 2022-06-22 23:01:17.225225
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
     module = 'ansible.module_utils.facts.hardware.darwin'
     mac_facts = {
        'osversion': '16.7.0',
        'model': 'Macmini8,1',
        'osrevision': '19H2',
     }
     out_sysctl_hw_model = b'hw.model: Macmini8,1\n'
     out_sysctl_kern_osversion = b'kern.osversion: 16.7.0\n'
     out_sysctl_kern_osrevision = b'kern.osrevision: 19H2\n'


# Generated at 2022-06-22 23:01:25.482915
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware_facts = dict()

    get_cpu_facts_output_ppc = """
hw.physicalcpu: 2
hw.logicalcpu: 2
"""

    get_cpu_facts_output_intel = """
machdep.cpu.brand_string: Intel(R) Core(TM)2 Duo CPU     T7700  @ 2.40GHz
machdep.cpu.core_count: 2
"""

    get_cpu_facts_output_with_vcpus = """
hw.physicalcpu: 2
hw.logicalcpu: 4
hw.ncpu: 4
"""

    module = MagicMock()
    test_DarwinHardware = DarwinHardware(module)

    # PPC
    module.run_command.return_value = (0, get_cpu_facts_output_ppc, '')
    hardware_facts = test

# Generated at 2022-06-22 23:01:37.760973
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModuleStub()
    # Pretend that vm_stat commands outputs the following lines.
    # Page size of 4096 bytes
    #
    # Mach Virtual Memory Statistics: (page size of 4096 bytes)
    # Free:                               7013216.
    # Active:                             12122752.
    # Inactive:                          102032064.
    # Speculative:                        2967040.
    # Throttled:                              0.
    # Wired down:                          952320.
    # File-backed:                        1155072.
    # Anonymous:                          6866432.
    # Compressions:                          722.
    # Decompressions:                        684.
    # Compressor Size:                  19856384.
    # Uncompressed Pages in Compressor:   776749.
   

# Generated at 2022-06-22 23:01:48.881377
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()
    hardware = DarwinHardware(module)
    # test hw.model
    hardware.sysctl = {
        'hw.model': 'iMac15,1'
    }
    hardware.populate()
    assert hardware.facts['model'] == hardware.facts['product_name'] == 'iMac15,1'
    # test hw.model not exist
    hardware.sysctl = {}
    hardware.populate()
    assert hardware.facts['model'] == hardware.facts['product_name'] == ''
    # test kern.osversion
    hardware.sysctl = {
        'kern.osversion': '16.7.0'
    }
    hardware.populate()
    assert hardware.facts['osversion'] == '16.7.0'
    # test kern.osversion not exist


# Generated at 2022-06-22 23:01:54.818004
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware = DarwinHardware()
    sysctl = {
        'hw.memsize': '4294836224',
        'hw.model': 'MacBookPro7,1',
        'kern.osrevision': '11.0.0',
        'kern.osversion': '15.0.0',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM)2 Duo CPU     P8600  @ 2.40GHz',
        'machdep.cpu.core_count': '2',
        'machdep.cpu.thread_count': '2',
    }

# Generated at 2022-06-22 23:02:07.404941
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from datetime import datetime, timedelta
    from time import time

    class TestModule:
        def run_command(command, encoding=None):
            # The third entry in the array is kern.boottime in seconds since the epoch
            cmd = ['sysctl', '-b', 'kern.boottime']
            if command == cmd:
                boot_time = int(time() - timedelta(days=8).total_seconds())
                raw_seconds = (boot_time + 1).to_bytes(struct.calcsize('@L'), 'little')
                microseconds = (99).to_bytes(struct.calcsize('@Q'), 'little')
                output = raw_seconds + microseconds
                return (0, output, '')
            else:
                return (1, '', '')


# Generated at 2022-06-22 23:02:13.637476
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import shutil
    import tempfile

    test_string = 'Hardware:\n' \
                  '    Hardware Overview:\n' \
                  '      Model Name: test name\n' \
                  '      Model Identifier: test identifier\n' \
                  '      Processor Speed: test speed\n' \
                  '      Number of Processors: test number\n' \
                  '      Total Number of Cores: test cores\n' \
                  '      L2 Cache (per Core): test cache\n' \
                  '      L3 Cache (per Processor): test cache\n' \
                  '      Memory: test memory\n' \
                  '      Processor Interconnect Speed: test speed\n' \
                  '      Boot ROM Version: test version\n' \
                  '      SMC Version (system): test version\n' \
                 

# Generated at 2022-06-22 23:02:25.431079
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import datetime

    class MockRunCommand(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def __call__(self, command, encoding=None):
            return (self.rc, self.out, self.err)

    # Values taken from macOS 10.12 Sierra.
    # The mock sysctl output is completely bogus, the values are taken from
    # the documentation:
    # https://developer.apple.com/library/content/documentation/Darwin/Conceptual/FSEvents_ProgGuide/KernelQueues/KernelQueues.html#//apple_ref/doc/uid/TP40005289-CH10-SW1

# Generated at 2022-06-22 23:02:36.567851
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule():
        def __init__(self):
            self.run_command_counter = 0

        def run_command(self, cmd, encoding=None):
            self.run_command_counter += 1

            if self.run_command_counter == 1:
                return 0, b'1\n', ''
            elif self.run_command_counter == 2:
                return 0, b'\x00\x00\x00\x00\x00\x00\x00\x00', ''

            raise Exception('Unexpected call to "cmd"')

        def get_bin_path(self, executable, required=False):
            return executable

    test_uptime = DarwinHardware(MockModule())
    uptime = test_uptime.get_uptime_facts()

# Generated at 2022-06-22 23:02:46.378622
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Create a fake module, required for invocation of class DarwinHardware
    class FakeModule:
        def __init__(self):
            self.run_command = None
            self.get_bin_path = None

    # Create a fake mgmt_exe, required for invocation of class DarwinHardware
    class FakeManager:
        def __init__(self):
            self.module = FakeModule()

    # Create a mock run_command function.  This is used to simulate
    # the return values of the run_command function.

# Generated at 2022-06-22 23:02:56.138736
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # The expected sysctl output here is made of two 64-bits integers that
    # represent seconds and microseconds since the system boot.
    # The mock_module object here is required by the sysctl() function that
    # get_uptime_facts() uses internally.
    mock_module = object()
    sysctl_output = struct.pack('QQ', (1405853361, 981125000))
    sysctl_output_packed = sysctl_output + b'abc'

    dh = DarwinHardware(mock_module)
    dh.sysctl = dict()
    dh.sysctl['kern.boottime'] = sysctl_output_packed.decode('utf-8')

    dh.populate()

    assert dh.facts['uptime_seconds'] == 1405853644

# Generated at 2022-06-22 23:03:04.054242
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import tempfile
    from ansible.module_utils.six import StringIO

    class FakeModule():
        def __init__(self):
            self.run_command_args = None
            self.run_command_rc = 0
            self.run_command_err = ""
            self.run_command_stdout = ""

        def run_command(self, args):
            self.run_command_args = args

            return (self.run_command_rc, self.run_command_stdout, self.run_command_err)

    def setup_fake_module():
        fake_module = FakeModule()

        old_stdout = sys.stdout
        sys.stdout = StringIO()
        fake_module.run_command_stdout = ""
        fake_module.run_command_rc = 0
        fake_

# Generated at 2022-06-22 23:03:16.299228
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import mock
    if not mock:
        return
    mc_tempfile = mock.mock_open(read_data='tempfile')
    mc_tempfile.return_value.name = '/tmp/foo'
    mc_open = mock.MagicMock(return_value=mc_tempfile)

    with mock.patch('ansible.module_utils.facts.hardware.darwin.open', mc_open, create=True):
        dh = DarwinHardware()

# Generated at 2022-06-22 23:03:23.783230
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = None
    module_name = 'DarwinHardware'
    module_path = None
    class_name = 'DarwinHardware'
    class_ = getattr(__import__(module_name, globals(), locals(), [class_name]), class_name)
    method_name = 'get_cpu_facts'
    method = getattr(class_, method_name)

    # Call the method
    cpu_facts = {}
    method(module, cpu_facts)
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '4'



# Generated at 2022-06-22 23:03:33.947018
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_host_facts = {
        'ansible_architecture': 'x86_64',
        'ansible_distribution': 'MacOSX',
        'ansible_distribution_version': '10.12',
        'ansible_kernel': 'Darwin',
        'ansible_machine': 'x86_64'
    }

    expected_cpu_facts = {
        'processor': 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz',
        'processor_cores': 4,
        'processor_vcpus': ''
    }

    hardware_fact_retriever = DarwinHardware(dict(), test_host_facts)
    cpu_facts = hardware_fact_retriever.get_cpu_facts()
    assert cpu_facts == expected_cpu_facts

# Generated at 2022-06-22 23:03:38.165123
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    darwin_hw = DarwinHardware(module)
    uptime_facts = darwin_hw.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] >= 0


# Generated at 2022-06-22 23:03:46.613166
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import pytest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
