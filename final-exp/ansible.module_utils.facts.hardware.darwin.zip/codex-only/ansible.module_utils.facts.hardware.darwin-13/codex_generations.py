

# Generated at 2022-06-22 22:53:54.341151
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
  """
  Return the fact 'processor' based on the value of kern.osversion or hw.model and 'processor_cores' based on hw.ncpu.
  """
  module_mock = mock.MagicMock()
  module_mock.get_bin_path.return_value = '/usr/sbin/system_profiler'
  module_mock.run_command.return_value = (0, "SPHardwareDataType\nModel Name: MacBook Pro\nProcessor Name: Intel Core i7\nProcessor Speed: 2.8 GHz\nNumber of Processors: 1\nTotal Number of Cores: 8\nL2 Cache (per Core): 256 KB\n", None)

  # test method get_cpu_facts()

# Generated at 2022-06-22 22:54:01.921361
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Unit test for method get_system_profile of class DarwinHardware
    """
    facts = {'module': None}
    hardware = DarwinHardware(facts)
    hardware.module = MockModule()

# Generated at 2022-06-22 22:54:06.956619
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module_mock = AnsibleModuleMock(params=dict())
    module_mock.run_command = MagicMock(return_value=(0, "hw.model: MacBookPro12,1", ""))
    module_mock.run_command = MagicMock(return_value=(0, "kern.osversion: 15G1108", ""))
    module_mock.run_command = MagicMock(return_value=(0, "kern.osrevision: 14E46", ""))
    system_profile_mock = MagicMock(return_value=dict())
    hardware = DarwinHardware(module_mock, system_profile_mock)
    assert hardware.get_mac_facts() == dict(model='MacBookPro12,1', osversion='15G1108', osrevision='14E46')



# Generated at 2022-06-22 22:54:11.516984
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    """
    Test darwin hardware constructor.

    :return:
    """
    darwin_hardware_obj = DarwinHardware(dict())
    assert darwin_hardware_obj.platform == 'Darwin'

# Generated at 2022-06-22 22:54:21.671810
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-22 22:54:28.939676
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_module = type('', (), {'run_command': run_command_for_get_mac_facts})

    darwin_hardware = DarwinHardware(test_module)
    mac_facts = darwin_hardware.get_mac_facts()

    assert mac_facts['model'] == 'MacBookPro7,1'
    assert mac_facts['osversion'] == '19.6.0'
    assert mac_facts['osrevision'] == '15G1421'



# Generated at 2022-06-22 22:54:38.567836
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, "test_cmd_output", ""))

        def get_bin_path(self, executable):
            return get_bin_path(executable)

    module = MockModule()
    hardware = DarwinHardware(module)

    darwin_cpu_facts = hardware.get_cpu_facts()

    assert darwin_cpu_facts['processor']
    assert darwin_cpu_facts['processor_vcpus']
    assert darwin_cpu_facts['processor_cores']


# Generated at 2022-06-22 22:54:41.758503
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector._platform == 'Darwin'
    assert hardware_collector._fact_class == DarwinHardware


# Generated at 2022-06-22 22:54:52.132034
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = DarwinHardwareCollector(module)
    hardware_facts_instance = hardware_collector.collect()
    hardware_facts = hardware_facts_instance.populate()

    assert hardware_facts['processor']
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['model']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert hardware_facts['uptime_seconds'] > 0

# Generated at 2022-06-22 22:54:56.856178
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_instance = DummyModule()
    test_instance.run_command = fake_run_command
    hw = DarwinHardware(test_instance)
    facts = hw.get_mac_facts()
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts


# Generated at 2022-06-22 22:54:59.467272
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    dH = DarwinHardware({},  None)
    assert dH.platform == 'Darwin'

# Generated at 2022-06-22 22:55:04.888262
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    facts = DarwinHardware()
    assert facts.processor is not None
    assert facts.processor_cores is not None
    assert facts.memtotal_mb is not None
    assert facts.memfree_mb is not None
    assert facts.model is not None
    assert facts.osversion is not None
    assert facts.osrevision is not None
    assert facts.uptime_seconds is not None

# Generated at 2022-06-22 22:55:11.784955
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "hw.model: MacBookPro10,1\nhw.memsize: 8589934592", "")
    module.get_bin_path.return_value = '/usr/sbin/system_profiler'
    module.run_command.return_value = (0, "Processor Name: Intel Core i7\nProcessor Speed: 2.9 GHz\n", "")

    hardware_facts_class_instance = DarwinHardware(module)
    hardware_facts_class_instance.sysctl = dict(hw={}, machdep={})
    hardware_facts_class_instance.sysctl['hw']['memsize'] = 8589934592

# Generated at 2022-06-22 22:55:18.470198
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    cpu_facts = darwin_hardware.get_cpu_facts()

    # Assert the expected keys are present in the result
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts

# Generated at 2022-06-22 22:55:27.367670
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwinHardware = DarwinHardware()

    # Return empty dictionary if vm_stat is not installed
    darwinHardware.module = _MockModule(run_command_response=(1, '', ''))
    assert darwinHardware.get_memory_facts() == {}

    # Return with empty result if vm_stat returned with non-zero exit code
    darwinHardware.module = _MockModule(run_command_response=(1, '', ''))
    assert darwinHardware.get_memory_facts() == {}

    # Return with empty result if vm_stat retu

# Generated at 2022-06-22 22:55:30.944739
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardwareCollector = DarwinHardwareCollector()
    assert hardwareCollector.platform == 'Darwin'
    assert hardwareCollector.fact_class == DarwinHardware

# Generated at 2022-06-22 22:55:37.648873
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import sys

    import ansible.module_utils.facts.hardware.darwin
    sys.modules['ansible.module_utils.facts.hardware.darwin'] = ansible.module_utils.facts.hardware.darwin

    current_dir = os.path.abspath(os.path.dirname(__file__))

# Generated at 2022-06-22 22:55:47.529135
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = mock.MagicMock()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '10', 'kern.osrevision': '2'}
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['osversion'] == '10'
    assert mac_facts['osrevision'] == '2'

    hardware.sysctl = {}
    hardware.module.run_command.return_value = (0, "hw.model: MacBookPro11,4\n", "")
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == "MacBookPro11,4"
    assert mac_facts['product_name'] == "MacBookPro11,4"


# Generated at 2022-06-22 22:55:55.565554
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware = DarwinHardware()
    hardware.module.fail_json = True
    hardware.module.run_command = lambda cmd: (0, 'hw.model: MacPro4,1', None)
    hardware.module.run_command = lambda cmd: (0, 'kern.osversion: 14.1.0\nkern.osrevision: 14.1.0', None)
    hardware.get_mac_facts()
    assert hardware.facts['model'] == "MacPro4,1"
    assert hardware.facts['osversion'] == "14.1.0"
    assert hardware.facts['osrevision'] == "14.1.0"



# Generated at 2022-06-22 22:56:05.748635
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_module = type('TestModule', (object,), {})
    # Test for Intel
    setattr(test_module, 'run_command', lambda x: (0, 'machdep.cpu.brand_string: Intel(R) Core(TM) i7-4960HQ CPU @ 2.60GHz', ''))
    test_module.get_bin_path = lambda x: "test"
    hw_intel = DarwinHardware(test_module)

    test_module.run_command = lambda x: (0, 'hw.physicalcpu: 4', '')
    hw_intel.sysctl = get_sysctl(test_module, ['hw', 'machdep', 'kern'])
    test_cpu_facts_intel = hw_intel.get_cpu_facts()

# Generated at 2022-06-22 22:56:11.626949
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand()
    darwin_hardware = DarwinHardware(module)
    res = darwin_hardware.get_mac_facts()
    assert(res == {'model': 'Test-Model', 'osversion': 'Test-OSversion', 'osrevision': 'Test-OSrevision'})



# Generated at 2022-06-22 22:56:19.599753
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
  memory_facts = {
    'memtotal_mb': '100',
    'memfree_mb': '50',
  }

  # Rc=0
  mod = AnsibleModule({ "sysctl": "vm_stat" })
  d = DarwinHardware(mod)
  memory_facts_rc_0 = d.get_memory_facts()
  assert memory_facts_rc_0['memtotal_mb'] == memory_facts['memtotal_mb']
  assert memory_facts_rc_0['memfree_mb'] == memory_facts['memfree_mb']
  mock_run_command.assert_called_with(['/usr/bin/vm_stat'])

  # Rc=0 and no memtotal_mb
  mod = AnsibleModule({ "sysctl": "vm_stat" })

# Generated at 2022-06-22 22:56:29.761985
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # set up mocks
    class MockModule():
        pass
    cpu_facts = {
        'processor': 'Intel(R) Core(TM) i5-5250U CPU @ 1.60GHz',
        'processor_cores': '2'
    }

    # get cpu facts
    m = MockModule()
    h = DarwinHardware(m)
    h.sysctl = get_sysctl(m, ['hw', 'machdep', 'kern'])
    h.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i5-5250U CPU @ 1.60GHz'
    h.sysctl['machdep.cpu.core_count'] = '2'
    assert h.get_cpu_facts() == cpu_facts
    # test if both processor_cores and

# Generated at 2022-06-22 22:56:40.394012
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Create mock objects
    module.run_command = MagicMock(return_value=(0, '', ''))
    sysctl = {}
    sysctl['kern.osversion'] = '16.6.0'
    sysctl['kern.osrevision'] = '16G2059'
    sysctl['hw.model'] = 'MacPro6,1'
    sysctl['hw.memsize'] = 0
    sysctl['hw.ncpu'] = 0
    sysctl['hw.physicalcpu'] = 4
    sysctl['hw.logicalcpu'] = 4

# Generated at 2022-06-22 22:56:42.444518
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    harware = DarwinHardware(module)
    harware.populate()

# Generated at 2022-06-22 22:56:51.047616
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    '''Tests that the DarwinHardware class populates all known facts'''
    module = AnsibleModuleMock()

    module.run_command.return_value = (0, '/usr/sbin/system_profiler: Successfully found the "system_profiler" command on the system.', '')
    module.get_bin_path.return_value = '/usr/sbin/system_profiler'
    module._config = dict(run_command_checks=True)
    module._ansible_version = dict(full="2.5.1")

    sysctl_func_mock = MagicMock(return_value={'hw': {'machdep': {'cpu': {'brand_string': 'Intel(R) Xeon(R) CPU E5-2667 v4 @ 3.20GHz'}}}})
    get_sys

# Generated at 2022-06-22 22:56:52.246580
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    info = DarwinHardwareCollector()
    assert info._platform == 'Darwin'
    assert info._fact_class == DarwinHardware

# Generated at 2022-06-22 22:57:01.490606
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import sys
    import os
    import test_utils

    test_utils.save_platform_info()
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    facts_to_test = ('model', 'product_name', 'osversion', 'osrevision')
    hardware_to_test = DarwinHardware()
    hardware_to_test.populate()
    for fact in facts_to_test:
        assert fact in hardware_to_test.get_facts(), "Fact %s not populated!" % fact
    test_utils.restore_platform_info()



# Generated at 2022-06-22 22:57:13.266391
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Test scenario:
    # The method will be able to decode kern.boottime if the output format is correct
    # The method will throw exception if the format is not correct
    # The method will return an empty dict, if the output is empty
    module = None
    mock_cmd = MagicMock(return_value = (0, '', ''))
    with patch.dict(DarwinHardware._module.__dict__, {'run_command': mock_cmd}):
        dh = DarwinHardware(module)
        # 1) Correct output format, raw bytes, not utf-8

# Generated at 2022-06-22 22:57:21.199461
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    collected_facts = hardware.populate()
    assert collected_facts['model'] == 'MacBook5,1'
    assert collected_facts['osrevision'] == '15'
    assert collected_facts['osversion'] == '12.5.11'
    assert collected_facts['processor'] == 'Intel(R) Core(TM)2 Duo P8600 @ 2.40GHz'
    assert collected_facts['processor_cores'] == '2'
    assert collected_facts['processor_vcpus'] == '4'
    assert collected_facts['memtotal_mb'] == 4023
    assert collected_facts['memfree_mb'] == 1168
    assert collected_facts['uptime_seconds'] > 0


# Generated at 2022-06-22 22:57:32.216513
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # create a mock module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # create mocks of output from a profile command

# Generated at 2022-06-22 22:57:41.935817
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from collections import namedtuple
    from datetime import datetime, timedelta
    from ansible.module_utils.facts.hardware.darwin import test_up_start_time, test_down_start_time

    up_start_time = datetime.fromisoformat(test_up_start_time)
    down_start_time = datetime.fromisoformat(test_down_start_time)
    if up_start_time < down_start_time:
        up_start_time, down_start_time = down_start_time, up_start_time

    sysctl = {'kern.boottime': up_start_time.strftime("%s.%f").encode("utf-8")}
    fake_sysctl = namedtuple("Sysctl", sysctl.keys())(*sysctl.values())

# Generated at 2022-06-22 22:57:46.373639
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    m.run_command = MagicMock(
        return_value = (0, 'hw.model: MacBookPro12,1', '')
    )
    mac_facts = DarwinHardware(m).get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro12,1'



# Generated at 2022-06-22 22:57:52.392663
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwinhw = DarwinHardware()
    darwinhw.module = type('TestAnsibleModule', (object,), {'run_command': test_run_command})
    memory_facts = darwinhw.get_memory_facts()

    assert memory_facts['memfree_mb'] == 47
    assert memory_facts['memtotal_mb'] == 4095


# Generated at 2022-06-22 22:58:02.057473
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import sys
    import pytest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl

    # Create instance of DarwinHardware class
    hardware_inst = DarwinHardware()

    # Simulate module instantiation
    hardware_inst.module = pytest.Mock()
    hardware_inst.module.run_command.return_value = (0, '0x010664', '')
    hardware_inst.sysctl = get_sysctl(hardware_inst.module, ['hw', 'machdep', 'kern'])
    # Intel
    hardware_inst.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz'
    hardware_

# Generated at 2022-06-22 22:58:13.813366
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware(dict())

    # Test for handling of values that can be converted to integers so we can
    # do math on it.
    mock_result = 'Pages wired down: 4765\nPages active: 25480\nPages inactive: 4196\nPages free: 12332059\n'
    output = hardware._mem_parse(mock_result.splitlines())
    assert output['memfree_mb'] == 10186

    # Test for handling of values that can't be converted to integers.
    mock_result = 'Pages wired down: 4265\nPages active: 25480\n' \
                  'Pages inactive: 4196\nPages free: 12332059\n' \
                  'Pages speculative: Not Supported\n'
    output = hardware._mem_parse(mock_result.splitlines())

# Generated at 2022-06-22 22:58:25.859500
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    module = MagicMock()
    dhw = DarwinHardware(module)
    dhw.sysctl = {'hw.memsize': 1234567}
    module.run_command.return_value = (0, """\
Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                               73942.
Pages active:                             25509.
Pages inactive:                           16221.
Pages wired down:                         18203.
Pages purgeable:                              0.
""", "")

    memory_facts = dhw.get_memory_facts()
    module.run_command.assert_called_once_with(['/usr/bin/vm_stat'])

# Generated at 2022-06-22 22:58:35.967309
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mac_facts = dict(model='MacBookAir5,2', osversion='15.6.0', osrevision='17G65',
                     processor='Intel Core i7-3667U CPU @ 2.00GHz', processor_cores=4, processor_vcpus=4,
                     memtotal_mb=4045, memfree_mb=384, uptime_seconds=156980)

    hw = DarwinHardware(dict())
    hw.sysctl = dict(hw=dict(memsize='4294967296', model='MacBookAir5,2'),
                     machdep=dict(cpu=dict(brand_string='Intel Core i7-3667U CPU @ 2.00GHz', core_count=4)),
                     kern=dict(osversion='15.6.0', osrevision='17G65'))

    h

# Generated at 2022-06-22 22:58:42.706696
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    darwin_hardware = DarwinHardware(module)
    assert darwin_hardware.get_uptime_facts() == {'uptime_seconds': 242}
    module.exit_json(changed=False, ansible_facts=dict(hardware=darwin_hardware.populate()))



# Generated at 2022-06-22 22:58:54.211917
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.system.freebsd import FreeBSDFacts
    from ansible.module_utils.facts.system.darwin import DarwinFacts
    darwin_facts = DarwinFacts(dict())
    freebsd_facts = FreeBSDFacts(dict(), darwin_facts)
    darwin_hw = DarwinHardware(freebsd_facts)
    # test powerpc
    darwin_hw.sysctl = {
        'hw.physicalcpu': 2,
        'hw.memsize': 1252249600
    }

# Generated at 2022-06-22 22:59:01.161684
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    m = ModuleArgsMock()
    hw = DarwinHardware(m)
    hw.get_mac_facts()
    assert m.run_command.call_count == 1
    args, kwargs = m.run_command.call_args
    assert args[0] == ["sysctl", "hw.model"]
    m.run_command.reset_mock()
    assert hw.sysctl == {'kern.osversion': '16.7.0', 'kern.osrevision': '16R57'}


# Generated at 2022-06-22 22:59:07.604527
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import timeit
    import platform
    import mac_facts
    import sys

    # Can't test without root perms
    if sys.platform != 'darwin' or not platform.mac_ver()[0]:
        return

    module = sys.modules[__name__]
    class MockModule:
        def __init__(self):
            self.run_command = module.run_command

    fact_module = mac_facts.DarwinHardware()
    fact_module.module = MockModule()
    mock_time = time.time()
    m = MockModule()
    @staticmethod
    def run_command(command, encoding=None):
        command_args = command[2:]
        if command_args:
            command_arg = command_args[0]

# Generated at 2022-06-22 22:59:19.469877
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Create a module for testing
    module = AnsibleModule(argument_spec=dict())

    # Create a dummy instance of DarwinHardware
    hw = DarwinHardware(module)

    # We need to fake the sysctl command
    hw.sysctl = {
        'kern.boottime': '1450390561',
        'hw.memsize': '4194304',
        'hw.ncpu': '2',
        'kern.osversion': '15.5.0',
        'kern.osrevision': '1412',
        'hw.physicalcpu': '1',
        'hw.logicalcpu': '2'
    }

    data = hw.populate()


# Generated at 2022-06-22 22:59:28.212984
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    class AnsibleModuleFake(object):
        def __init__(self):
            self._command_results = {}

        def run_command(self, command):
            return self._command_results.get(tuple(command))

    class TestDarwinHardware(unittest.TestCase):

        def setUp(self):
            self.module = AnsibleModuleFake()
            self.module._command_results[('sysctl', 'hw.model')] = (0, 'hw.model: MacBookPro7,1', '')

# Generated at 2022-06-22 22:59:29.869148
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware_facts = DarwinHardware(module=module).populate()

    assert hardware_facts['memtotal_mb'] == 1

# Generated at 2022-06-22 22:59:35.464966
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-22 22:59:46.705061
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.collector.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-22 22:59:52.846649
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockModule()
    hardware = DarwinHardware(module)

    module.run_command.return_value = (0, 'hw.model: Xserve', '')

    assert hardware.get_mac_facts() == {
        'model': 'Xserve',
        'osversion': '19.6.0',
        'osrevision': '1510',
        'product_name': 'Xserve',
    }



# Generated at 2022-06-22 22:59:55.795810
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class == DarwinHardware

# Generated at 2022-06-22 23:00:04.408081
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockModule()
    hardware = DarwinHardware(module)

    hardware.module.run_command.return_value = (0, "hw.model: MacPro6,1", "")
    facts = hardware.get_mac_facts()
    assert facts['model'] == "MacPro6,1"
    facts = hardware.get_mac_facts()
    assert facts['osversion'] == hardware.sysctl['kern.osversion']
    facts = hardware.get_mac_facts()
    assert facts['osrevision'] == hardware.sysctl['kern.osrevision']
    module.fail_json.assert_not_called()



# Generated at 2022-06-22 23:00:07.227387
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()

    assert hardware_collector._platform == 'Darwin'
    assert hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-22 23:00:08.958100
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector is not None

# Generated at 2022-06-22 23:00:20.487697
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    darwin_hardware = DarwinHardware()
    # Test pages wired down
    memory_stats = {'Pages wired down': 100}
    darwin_hardware.get_memory_facts(memory_stats, None)
    assert darwin_hardware.memfree_mb < 0

    # Test nano size pages wired down
    memory_stats = {'Pages wired down': 1000000000000000000000}
    darwin_hardware.get_memory_facts(memory_stats, None)
    assert darwin_hardware.memfree_mb < 0

    # Test pages wired down, pages active and pages inactive

# Generated at 2022-06-22 23:00:30.283898
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # Unfortunately it is not possible to mock sysctl on the module object
    # without making Ansible fail to load the module.
    # So we need to inject our own sysctl command.
    out = struct.pack('@L', 0)
    module.run_command = lambda cmd, encoding=None: (0, out, '')
    darwin_hardware = DarwinHardware(module)
    assert darwin_hardware.get_uptime_facts() == {
        'uptime_seconds': int(time.time()),
    }

# The following class is used only for unit testing.

# Generated at 2022-06-22 23:00:31.980636
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()
    assert hardware.platform == 'Darwin'

# Generated at 2022-06-22 23:00:36.131217
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = get_test_module()
    darwin_hw = DarwinHardware(module)
    mac_facts = darwin_hw.get_mac_facts()

    assert mac_facts['model'] == 'MacBookPro11,3'
    assert mac_facts['osversion'] == '15.5.0'
    assert mac_facts['osrevision'] == '17F77'


# Generated at 2022-06-22 23:00:41.899703
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    '''
    unit test for DarwinHardwareCollector to test constructor
    '''
    # Create empty module
    module = MockAnsibleModule()
    # Create a hardware collector
    hardware_collector = DarwinHardwareCollector(module)
    # Assert that fact_class is DarwinHardware
    assert hardware_collector.fact_class == DarwinHardware
    # Assert that platform_name is Darwin
    assert hardware_collector.platform_name == 'Darwin'

# Unit test to test DarwinHardware class

# Generated at 2022-06-22 23:00:53.534145
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    contents = """
    Hardware Overview:

    Model Name: MacBook Pro
    Model Identifier: MacBookPro11,1
    Processor Name: Intel Core i5
    Processor Speed: 2.6 GHz
    Number of Processors: 1
    Total Number of Cores: 2
    L2 Cache (per Core): 256 KB
    L3 Cache: 3 MB
    Memory: 8 GB
    Boot ROM Version: MBP111.0138.B00
    SMC Version (system): 2.18f15
    """

    module_mock = Mock()
    module_mock.run_command.return_value = (0, contents, "")
    system_profile = DarwinHardware().get_system_profile(module_mock)

# Generated at 2022-06-22 23:01:00.326294
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import io
    import sys
    import textwrap
    # Avoid writing to stdout in the test.
    stdout = sys.stdout
    sys.stdout = io.StringIO()

# Generated at 2022-06-22 23:01:05.022979
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware()
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Identifier'] == 'MacBookPro7,1'
    assert system_profile['Processor Name'] == 'Intel Core 2 Duo'


# Generated at 2022-06-22 23:01:17.173710
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    obj = DarwinHardware(module)
    obj.sysctl = {'kern.ostype': 'Darwin', 'kern.osrelease': '15.6.0', 'kern.osrevision': '15.6.0', 'kern.osversion': 'Darwin Kernel Version 15.6.0: Tue Mar  7 16:33:36 PST 2017; root:xnu-3248.60.10~1/RELEASE_X86_64', 'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5645  @ 2.40GHz', 'machdep.cpu.core_count': 12}
    mac_facts = obj.get_mac_facts()

# Generated at 2022-06-22 23:01:25.295392
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes

    if PY3:
        system_profile = DarwinHardware._system_profile_py3
    else:
        system_profile = DarwinHardware._system_profile_py2
    system_profile_parsed = DarwinHardware(dict())._parse_system_profile(system_profile)

    assert system_profile_parsed['Serial Number (system)'] == 'C02Q97MGHVH7'
    assert system_profile_parsed['Model Identifier'] == 'MacBookPro13,1'
    assert system_profile_parsed['Model Name'] == 'MacBook Pro'
    assert system_profile_pars

# Generated at 2022-06-22 23:01:37.515367
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import shlex
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    class FakeModule:
        def run_command(self, command):
            assert isinstance(command, list)
            expected_command = '/usr/sbin/system_profiler SPHardwareDataType'
            assert shlex.split(expected_command) == command


# Generated at 2022-06-22 23:01:40.898716
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    mac_facts = DarwinHardware().get_mac_facts()
    assert mac_facts['osversion']
    assert mac_facts['osrevision']
    assert mac_facts['model']



# Generated at 2022-06-22 23:01:50.809041
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Test with valid output of sysctl
    test_module = AnsibleModule(argument_spec=dict())
    setattr(test_module, 'run_command', run_command_mock)
    hardware = DarwinHardware(module=test_module)

    hardware_facts = hardware.populate()
    expected_hardware_facts = {
        'memtotal_mb': 0,
        'model': 'MacBookPro5,5',
        'osrevision': '1465.0.0',
        'osversion': '10K549',
        'processor': 'Intel(R) Core(TM)2 Duo CPU     P8600  @ 2.40GHz',
        'processor_cores': 1,
        'product_name': 'MacBookPro5,5',
        'uptime_seconds': 0
    }

    assert hardware_

# Generated at 2022-06-22 23:01:59.827822
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import platform
    import tempfile

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_function

    def sysctl_load(path, kernel_name=None, missing_ok=False, split=False):
        # sysctl_load(kernel_name) -> value

        if path is None:
            raise ValueError("No path specified.")

        if kernel_name is None:
            kernel_name = path.replace('.', '/')

        # sysctl outputs to stderr, so combine it with stdout
        p = subprocess.Popen([sysctl_cmd, kernel_name],
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

        stdout, _ = p.communicate()
        ret

# Generated at 2022-06-22 23:02:11.221968
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value='/usr/bin/vm_stat')
    module.run_command = MagicMock(return_value=(0, 'Mach Virtual Memory Statistics: (page size of 4096 bytes)\nPages free:                               1477.\nPages active:                             2038.\nPages inactive:                           2948.\nPages wired down:                         2522.\nPages purgeable:                             0.\nPages speculative:                         818.\nPages throttled:                             0.\nPages wired down:                         2522.', ''))

    memory_facts = DarwinHardware(module).get_memory_facts()


# Generated at 2022-06-22 23:02:23.660705
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    d = DarwinHardware(module)

    # Mock get_sysctl, otherwise we will not be able to run the unit tests
    d.get_sysctl = lambda x: dict()
    d.get_sysctl.__name__ = 'get_sysctl'
    d.get_system_profile = lambda: dict()

    # Mock the return value of get_bin_path, which is not relevant here
    d.module.get_bin_path = lambda x: x

    assert d.get_cpu_facts() == dict(processor='', processor_cores='', processor_vcpus='')
    assert d.get_cpu_facts()['processor_vcpus'] == d.sysctl.get('hw.logicalcpu') or d.sysctl.get('hw.ncpu') or ''



# Generated at 2022-06-22 23:02:34.730217
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import sys
    sys.modules['ansible'] = type('DummyAnsibleModule', (object,), {'run_command': DummyAnsibleModule_run_command_returning_fake_profiler_output})
    sys.modules['ansible.module_utils'] = module_utils = type('DummyModuleUtils', (object,), {})
    module_utils.common = type('DummyCommon', (object,), {'get_platform': lambda: 'Darwin'})

# Generated at 2022-06-22 23:02:45.226606
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hw = DarwinHardware(dict())
    hw.sysctl = {
        'hw.memsize': 1073725440,
    }

    # Test normal conditions
    hw.module.run_command = lambda x: (0, """
Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                             19071.
Pages active:                          483435.
Pages inactive:                         92238.
Pages speculative:                       7652.
Pages throttled:                           0.
Pages wired down:                      943538.
Pages purgeable:                         6795.
""", '')
    assert hw.get_memory_facts() == {
        'memtotal_mb': 1024,
        'memfree_mb': 1,
    }

    # Test vm_stat syntax error

# Generated at 2022-06-22 23:02:55.325542
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class obj(object):
        module = None
    class obj2(object):
        run_command = None
    class obj3(object):
        def __init__(self):
            self.rc = 0
            self.out = "Processor Name: Intel(R) Core(TM) i5 CPU         M 560  @ 2.67GHz\nProcessor Speed: 2.67 GHz\nNumber of Processors: 1\nTotal Number of Cores: 2\nL2 Cache (per Core): 256 KB\nL3 Cache: 3 MB\nMemory: 4 GB"
            self.err = ""
    obj4 = DarwinHardware(module=obj())

# Generated at 2022-06-22 23:03:02.669156
# Unit test for method get_uptime_facts of class DarwinHardware

# Generated at 2022-06-22 23:03:15.257641
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    test_module = type(sys)('ansible_module_%s' % __name__)
    test_module.verbose = False
    test_module.run_command = lambda *args, **kwargs: (0, '', '')
    test_module.get_bin_path = get_bin_path
    hardware = DarwinHardware(test_module)

    hardware.sysctl = {
        'hw': {},
        'machdep': {},
        'kern': {
            'kern.osversion': '15.6.0',
            'kern.osrevision': '1',
        },
    }


# Generated at 2022-06-22 23:03:16.612055
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hc = DarwinHardware()
    # TODO: Add unit tests


# Generated at 2022-06-22 23:03:21.493431
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mock_module = MockOSModule()
    obj = DarwinHardware(mock_module)
    result = obj.get_system_profile()
    assert result == {'Model Identifier': 'MacBookPro8,2', 'Processor Name': 'Intel Core i7', 'Processor Speed': '2.4 GHz'}

# Generated at 2022-06-22 23:03:30.477722
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    h = DarwinHardware(None)
    # The following generates an example of the data that are returned on
    # Darwin system
    data = h.get_system_profile()
    assert 'Model Name' in data

    # The following generates an example of the data that are returned on
    # Darwin system
    data = h.get_mac_facts()
    assert 'model' in data
    assert 'product_name' in data
    assert 'osversion' in data
    assert 'osrevision' in data

    assert 'Model Name' in data['model']
    assert 'Model Name' in data['product_name']



# Generated at 2022-06-22 23:03:36.407371
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    from ansible_collections.notstdlib.moveitallout.tests.unit.module_utils.facts.collectors.hardware.darwin import DarwinHardwareCollector
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector._fact_class == DarwinHardware
    assert darwin_hw_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:03:45.280699
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    facts = dict()
    module = MagicMock()
    sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4500U CPU @ 1.80GHz',
              'machdep.cpu.core_count': '2',
              }
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.side_effect = lambda x: x
    obj = DarwinHardware(module)
    obj.sysctl = sysctl
    result = obj.get_cpu_facts(facts)
    assert result['processor'] == 'Intel(R) Core(TM) i7-4500U CPU @ 1.80GHz'
    assert str(result['processor_cores']) == '2'
