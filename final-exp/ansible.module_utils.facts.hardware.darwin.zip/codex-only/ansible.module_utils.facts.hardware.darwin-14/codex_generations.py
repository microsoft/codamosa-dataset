

# Generated at 2022-06-22 22:53:51.980172
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    fixture_data = {
        "processor": "Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz",
        "processor_cores": 2,
        "processor_vcpus": 4,
        "memtotal_mb": 8192,
        "memfree_mb": 6152,
        "model": "MacBookAir7,2",
        "osversion": "15.6.0",
        "osrevision": "19G73",
        "uptime_seconds": 27682,
    }
    hardware = DarwinHardwareCollector(None, fixture_data, None)
    assert hardware.get_all() == fixture_data

# Generated at 2022-06-22 22:54:05.012526
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Store the old env variable
    old_env = os.environ.copy()
    os.environ['ANSIBLE_SYSTEM_PROFILER_COMMAND'] = '/usr/sbin/system_profiler'
    os.environ['ANSIBLE_SYSTEM_PROFILER_FAIL'] = '1'

    # Run the function with a failure
    d = DarwinHardware()
    system_profile = d.get_system_profile()
    assert system_profile == {'Processor Name': ' ', 'Processor Speed': ' '}

    # Run the function correctly
    os.environ['ANSIBLE_SYSTEM_PROFILER_FAIL'] = '0'
    d = DarwinHardware()
    system_profile = d.get_system_profile()

# Generated at 2022-06-22 22:54:12.773826
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl

    m = DarwinHardware()
    m.module = MockAnsibleModule()
    m.sysctl = get_sysctl(m.module, ['hw', 'machdep', 'kern'])

    results = m.get_mac_facts()

    # model
    assert results['model'] == ('MacBookPro11,3')

    # osversion
    assert results['osversion'] == ('19.3.0')

    # osrevision
    assert results['osrevision'] == ('17D2047')


# Generated at 2022-06-22 22:54:14.823227
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hw = DarwinHardware()
    assert darwin_hw.sysctl is None


# Generated at 2022-06-22 22:54:23.501481
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():  # pylint: disable=R0915
    module = None # pylint: disable=C0103

    def run_command(command, encoding=None):
        """
        Test mocked run_command function. Allows to modify command return values

        :param command: command tuple
        :param encoding: (not used)
        :return: tuple (command return code, command outout, command errout)
        """
        if command[0] == get_bin_path('sysctl'):  # Mocked sysctl command
            if command[1] == 'hw.model':
                return (0, 'hw.model: MacBookPro4,1\n', None)
            if command[1] == 'hw.memsize':
                return (0, '8589934592\n', None)

# Generated at 2022-06-22 22:54:35.597916
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class MyModule(object):
        def __init__(self, module):
            self.module = module

        def run_command(self, cmd):
            # First call to run_command will mock the command
            # "sysctl machdep.cpu.brand_string" and return
            # the cpu brand string and a return code of 0.
            # Second call to run_command will mock the command
            # "/usr/sbin/system_profiler SPHardwareDataType"
            # and return the output for the mocked command.
            if 'machdep.cpu.brand_string' in cmd:
                return 0, "machdep.cpu.brand_string: Intel(R) Core(TM) i7-6820HQ CPU @ 2.70GHz", ''
            if '/usr/sbin/system_profiler' in cmd:
                return 0

# Generated at 2022-06-22 22:54:44.019924
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware()
    cpu_facts = {}
    cpu_facts['processor'] = "Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz"
    cpu_facts['processor_cores'] = 8
    cpu_facts['processor_vcpus'] = 4
    hardware.module = MockModule()
    hardware.module.run_command = Mock(return_value=(0, "hw.machdep.cpu.brand_string: Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz\n" +
                                                    "hw.physicalcpu: 8\n" +
                                                    "hw.logicalcpu: 4", ""))
    cpu_facts_result = hardware.get_cpu_facts()

    assert cpu_facts_result == cpu_facts



# Generated at 2022-06-22 22:54:56.153894
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule(object):
        def get_bin_path(self, command):
            return command

        def run_command(self, cmd, encoding=None):
            import subprocess
            output = subprocess.check_output(cmd, encoding=encoding)
            return 0, output, ''

    import time
    import struct
    # Test a fake uptime_seconds value that can be easily predicted
    test_kern_boottime = int(time.time() - 12345)
    test_command_output = struct.pack('@L', test_kern_boottime)
    module = TestModule()
    darw_hardware = DarwinHardware(module)

    test_output = darw_hardware.get_uptime_facts()
    assert test_output == {'uptime_seconds': 12345}

# Generated at 2022-06-22 22:55:07.332826
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    command_rc_map = {
        'sysctl hw.model': (0, 'hw.model: x86_64', ''),
        '/usr/sbin/system_profiler SPHardwareDataType': (0, 'Processor Name: Intel Core i7', ''),
    }

    module = get_module_mock(command_rc_map=command_rc_map)

    hardware = DarwinHardware(module=module)
    mac_facts = hardware.get_mac_facts()

    assert mac_facts == {
        'model': 'Intel Core i7',
        'product_name': 'Intel Core i7',
        'osversion': '/bin/false',
        'osrevision': '/bin/false',
    }



# Generated at 2022-06-22 22:55:16.999493
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # No value
    fake_module = FakeModule(kern_boottime=None)
    hardware = DarwinHardware(fake_module)
    assert {} == hardware.get_uptime_facts()

    # Empty string
    fake_module = FakeModule(kern_boottime=' ')
    hardware = DarwinHardware(fake_module)
    assert {} == hardware.get_uptime_facts()

    # Empty string
    fake_module = FakeModule(kern_boottime=' ')
    hardware = DarwinHardware(fake_module)
    assert {} == hardware.get_uptime_facts()

    # Non-integer value
    fake_module = FakeModule(kern_boottime='ABC')
    hardware = DarwinHardware(fake_module)
    assert {} == hardware.get_uptime_facts()

    # time.time() returns a float

# Generated at 2022-06-22 22:55:28.404877
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(
        argument_spec=dict()
    )

# Generated at 2022-06-22 22:55:37.013314
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = get_module_mock()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.vendor': 'GenuineIntel', 'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'machdep.cpu.core_count': 4, 'machdep.cpu.thread_count': 8, 'hw.physicalcpu': 4, 'hw.logicalcpu': 8, 'hw.activecpu': 8, 'hw.ncpu': 1}
    facts = hardware.get_cpu_facts()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts

# Generated at 2022-06-22 22:55:47.427864
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mock_module = Mock()
    mock_module.run_command.return_value = (0, dedent("""Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                              1683857.
Pages active:                             767007.
Pages inactive:                           598610.
Pages speculative:                        599127.
Pages wired down:                          44116.
Pages purgeable:                          274939.
"Translation faults":                54420977.
Pages copy-on-write:                    3911087.
Pages zero filled:                    54314443.
Pages reactivated:                      1107188.
Pageins:                                  677179.
Pageouts:                                    769.
Object cache: 47 hits of 23946 lookups (0% hit rate)"""), '')


# Generated at 2022-06-22 22:55:51.480313
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert type(memory_facts['memtotal_mb']) is int
    assert type(memory_facts['memfree_mb']) is int


# Generated at 2022-06-22 22:55:54.526477
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hw = DarwinHardwareCollector()
    assert isinstance(hw, HardwareCollector)
    assert hw._fact_class == DarwinHardware
    assert hw._platform == 'Darwin'

# Unit tests for constructor of class DarwinHardware

# Generated at 2022-06-22 22:56:04.743020
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    result = darwin_hardware.get_system_profile()
    assert 'Hardware UUID' in result
    assert 'Hardware Overview' in result
    assert 'Boot ROM Version' in result
    assert 'Model Name' in result
    assert 'SMC Version (system)' in result
    assert 'Model ID' in result
    assert 'Processor Name' in result
    assert 'Processor Speed' in result
    assert 'Number of Processors' in result
    assert 'Total Number of Cores' in result
    assert 'L2 Cache' in result
    assert 'Memory' in result
    assert 'Native PCI-express' in result
    assert 'Thunderbolt' in result
    assert 'USB' in result
    assert 'Memory Slots' in result
    assert 'Storage' in result

# Generated at 2022-06-22 22:56:15.926113
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    output = """    Model Name: Mac Pro
    Model Identifier: MacPro2,1
    Processor Name: Quad-Core Intel Xeon
    Processor Speed: 2.66 GHz
    Number Of Processors: 2
    Total Number Of Cores: 8
    Memory: 24 GB
    Processor Interconnect Speed: 4.8 GT/s
    L3 Cache (per processor): 12 MB
    Memory: 24 GB
    Boot ROM Version: MP21.006C.B05
    SMC Version (system): 1.7f10
    Serial Number (system): WXXXXXXXXXXX
    Hardware UUID: E6XXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
"""
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six.moves import StringIO

# Generated at 2022-06-22 22:56:19.944392
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModuleMock()
    hw = DarwinHardware(module)
    assert isinstance(hw, DarwinHardware)
    assert hw.module == module


# Generated at 2022-06-22 22:56:29.657093
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    #  Define faked input
    module_return_values = (0, "hw.model: MacBookPro12,1\n", "")
    module_mock = MagicMock()
    module_mock.run_command = MagicMock(return_value=module_return_values)
    #  Call method
    Darwin_Hardware = DarwinHardware(module_mock)
    mac_facts = Darwin_Hardware.get_mac_facts()
    #  Check output
    mac_facts_expected = {'model': 'MacBookPro12,1', 'osversion': '',
                          'osrevision': ''}
    assert mac_facts == mac_facts_expected
    assert module_mock.run_command.call_args[0][0] == "sysctl hw.model"

# Generated at 2022-06-22 22:56:40.321480
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    if not module.check_mode:
        module.fail_json(msg='ansible-test does not support OSX')
    hardware = DarwinHardware(module)
    hardware.sysctl = dict(
        hw_memsize=str(4096*4096),
        machdep_cpu_core_count=str(4),
    )
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 4096
    # The module is meant to be tested with the OSX data from ci/lib/common.py
    # rather than being an actual test on the physical device
    assert memory_facts['memfree_mb'] == 3443



# Generated at 2022-06-22 22:56:48.915851
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    # We need to mock modules, since module class tries to run commands.
    # The method actually tested is populate, no need to test the remaining
    # methods.
    class MockedModule(object):
        def run_command(self, args):
            return 0, '', ''
        def get_bin_path(self, command):
            return '/usr/bin/%s' % command

    # Create a DarwinHardware object
    obj = DarwinHardware()

    # Populate it with facts
    obj.populate(MockedModule())

    # Check that it's not empty
    assert(obj.facts)

    # Check some of the populated facts
    assert('processor' in obj.facts)
    assert('processor_cores' in obj.facts)
    assert('memtotal_mb' in obj.facts)

# Generated at 2022-06-22 22:56:52.998097
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils.fake_module import FakeModule

    fake_module = FakeModule()
    fake_module.run_command = lambda command: [0, "", ""]
    collector = DarwinHardware(fake_module)
    result = collector.get_system_profile()
    assert result == dict()

# Generated at 2022-06-22 22:56:54.857765
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = FakeModule()
    hardware = DarwinHardware(module)
    assert hardware.platform == 'Darwin'


# Generated at 2022-06-22 22:57:07.365468
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    fake_sysctl_dict = {
        'hw.model': 'hw.model: iMacPro1,1',
        'kern.osversion': 'kern.osversion: 17.6.0',
        'kern.osrevision': 'kern.osrevision: 15000',
    }
    fake_DarwinHardware = type(
        '',
        (DarwinHardware,),
        {
            'get_system_profile.return_value': {
                'Processor Name': 'Processor Name',
                'Processor Speed': 'Processor Speed',
            },
            'module': module,
            'sysctl': fake_sysctl_dict,
        }
    )

    assert fake_

# Generated at 2022-06-22 22:57:10.651724
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    darwin = DarwinHardware(module)
    assert(darwin.platform == 'Darwin')
    assert(darwin.sysctl == {})

# Generated at 2022-06-22 22:57:15.865580
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    import platform
    import pytest

    # Test mocking of constructor
    collector = DarwinHardwareCollector()
    assert collector._fact_class == DarwinHardware
    assert collector._platform == 'Darwin'

    # Test mocking of get_platform
    # get_platform will always return "Darwin" because of the mocking of
    # the platform module.
    assert collector.get_platform() == 'Darwin'

# Generated at 2022-06-22 22:57:22.306467
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.sysctl = dict()

        def run_command(self, command):
            if command == "sysctl hw.model":
                return (0, "hw.model: MacBookPro11,3\n", "")

# Generated at 2022-06-22 22:57:23.371989
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector._platform == 'Darwin'

# Generated at 2022-06-22 22:57:26.345586
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """Test if object can be created with the right class."""
    collector = DarwinHardwareCollector()
    assert collector.__class__.__name__ == 'DarwinHardwareCollector'

# Generated at 2022-06-22 22:57:33.772678
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """Just test the memory facts are correctly populated"""
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    fact_mock = {
        'os': {
            'name': 'Darwin',
            'version': '16.5.0'
        },
        'kernel': 'Darwin'
    }
    hardware_obj = DarwinHardware(fact_mock)
    result = hardware_obj.get_memory_facts()
    assert result['memtotal_mb'] > 0
    assert result['memfree_mb'] > 0



# Generated at 2022-06-22 22:57:34.342368
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector

# Generated at 2022-06-22 22:57:43.934993
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.namespace import Namespace
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.hardware import DarwinHardware

    # Set up a test object
    module = Namespace()
    facts = Facts(module)
    hardware = DarwinHardware(module, facts)
    hardware.sysctl = {'kern.osversion': '16.0.0', 'kern.osrevision': '16A323'}

    rc = 0
    out = u'''hw.model: MacBookPro11,3
'''

    hardware.module.run_command = lambda cmd: (rc, out, '')
    hardware.get_system_profile = lambda: {}

    # Test a known model
    hardware.populate()

# Generated at 2022-06-22 22:57:50.679850
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    fake_ansible_module = object()
    hardware = DarwinHardware(fake_ansible_module)
    mac_facts = hardware.get_mac_facts()
    version_info = mac_facts['osversion'].split('.')
    assert mac_facts['osrevision'] == version_info[-1]
    assert mac_facts['model'] == 'MacBookPro'

# Generated at 2022-06-22 22:58:01.056208
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Create a class to be tested
    hw = DarwinHardware(dict())

    # Set attribute sysctl with expected value
    hw.sysctl = {'kern.osversion': '16.1.0', 'kern.osrevision': '16A323'}

    # Set attribute module
    cmd = "/usr/sbin/system_profiler SPHardwareDataType"
    hw.module = MagicMock()
    hw.module.run_command.return_value = (0, "name: iMac\n", "")

    # Apply tests
    result = hw.get_mac_facts()
    assert result['model'] == "iMac"
    assert result['osversion'] == hw.sysctl['kern.osversion']

# Generated at 2022-06-22 22:58:12.934246
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.memsize': '8589934592',
        'hw.physicalcpu': '4',
        'kern.osversion': '14.0.0',
        'kern.osrevision': '15.0.0',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz',
        'machdep.cpu.core_count': '8'
    }

# Generated at 2022-06-22 22:58:25.460876
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    out = dict()

    # First, override hw facts so we are not affected by actual machine
    out['hw'] = dict()
    out['hw']['model'] = 'iMac14,2'
    out['hw']['ncpu'] = '3'
    out['hw']['memsize'] = '42939136256'
    out['hw']['core_count'] = '2'

    # Second, override kern facts so we are not affected by actual machine
    out['kern'] = dict()
    out['kern']['osversion'] = '1.3.3'
    out['kern']['osrevision'] = '14.3.1'

    dh = DarwinHardware(out)
    assert dh.cpu['model'] == '2'

# Generated at 2022-06-22 22:58:28.803067
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import test_module
    stats = DarwinHardware(module=test_module).get_uptime_facts()
    assert stats['uptime_seconds'] > 0

# Generated at 2022-06-22 22:58:36.957198
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    sysctl_func = lambda x: {'hw.model': 'MacPro6,1', 'kern.osversion': '15.7.0', 'kern.osrevision': '15P2117'}
    module = FakeModule(get_bin_path=lambda: None, run_command=lambda x: (0, "", ""), get_sysctl=sysctl_func)

    mac_facts = DarwinHardware(module, 'Darwin').get_mac_facts()
    assert mac_facts == {'model': 'MacPro6,1', 'osversion': '15.7.0', 'osrevision': '15P2117', 'product_name': 'MacPro6,1'}



# Generated at 2022-06-22 22:58:39.026805
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x.platform == 'Darwin'

# Generated at 2022-06-22 22:58:47.773862
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a class
    hardware = DarwinHardware()
    # Create a system profile
    system_profile = {
        'Processor Name': 'Intel Core i7',
        'Processor Speed': '2.8 GHz',
    }
    # Create a variable to store the returned value
    ret = {}
    # Set the variable system_profile to the return of the method get_system_profile
    system_profile = hardware.get_system_profile()
    # Assert if the method get_system_profile returns the same that we introduced
    assert system_profile == ret

# Generated at 2022-06-22 22:58:59.420905
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from distribute_setup import use_setuptools
    use_setuptools()
    from setuptools import setup, find_packages
    setup(name='ansible-hardware-facts',
          version='0.1',
          description='Ansible hardware related facts',
          author='Ibrahim Assed',
          packages=find_packages(),
          )
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import mock
    import json
    import os
    import sys
    import shutil
    facts = {}
    failed_facts = {}
    skipped_facts = {}
    sys.path.append('/home/ibrahim/ansible/module_utils')
    module = mock.MagicMock()
    module.run_command = mock.MagicMock()

# Generated at 2022-06-22 22:59:06.785793
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command.side_effect = [
        (0, 'machdep.cpu.brand_string: Intel(R) Core(TM) i5-6600 CPU @ 3.30GHz', ''),
        (0, 'machdep.cpu.core_count: 4', ''),
        (0, 'hw.physicalcpu: 4', ''),
        (0, 'hw.logicalcpu: 8', ''),
    ]
    module.get_bin_path.return_value = '/usr/bin/vm_stat'

    hardware = DarwinHardware(module)

# Generated at 2022-06-22 22:59:18.398870
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    h = DarwinHardware()
    out_good = "\nHardware:\n\n    Hardware Overview:\n\n              Model Name: Mac Pro\n       Model Identifier: MacPro1,1\n                 Processor Name: Quad-Core Intel Xeon\n            Processor Speed: 3.2 GHz\n                 Number of Processors: 1\n                         Total Number of Cores: 4\n                      L2 Cache (per Core): 512 KB\n                       L3 Cache: 8 MB\n                Memory: 16 GB\n    Boot ROM Version: MP11.005C.B05\n           SMC Version (system): 1.7f10\n           Serial Number (system): G893101J3K1\n                   Hardware UUID: 00000000-0000-1000-8000-0017F15C67FF\n\n       "
    h.module = Mock()

# Generated at 2022-06-22 22:59:28.638741
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils.fixtures.mac_facts import mac_facts
    from ansible.module_utils.facts import ansible_collections

    mac = DarwinHardware()

    mac.sysctl = {
        'kern.osversion': '16.6.0',
        'kern.osrevision': '15G1108'
    }

    mac.module = ansible_collections.ansible.community.tests.unit.module_utils.facts.ansible_collections.ansible.community.plugins.module_utils.network.base.AnsibleModule(
        argument_spec=dict())

    result = mac.get_mac_facts()

    assert result == mac_facts



# Generated at 2022-06-22 22:59:33.559042
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hwfact_collector = DarwinHardwareCollector()
    assert darwin_hwfact_collector._fact_class == DarwinHardware
    assert darwin_hwfact_collector._platform == 'Darwin'

# Generated at 2022-06-22 22:59:44.900680
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Mock the module and the module class, as they are used to read the value of sysctl
    module = type('AnsibleModule', (object,), {})()
    darwin_hardware = DarwinHardware(module)
    # Set the value of sysctl for hw.memsize so that we can simulate that
    # we are on a system with 32GB RAM.
    darwin_hardware.sysctl['hw.memsize'] = 3.2e9

    # Test the success case where vm_stat is present.

# Generated at 2022-06-22 22:59:46.928834
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware('module')
    assert hardware.platform == 'Darwin'



# Generated at 2022-06-22 22:59:53.186133
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Dummy class that simulates Module method run_command
    class DummyModule:
        def run_command(self, command, encoding=None):
            return (0, struct.pack('@L', int(time.time() - 2404220)), None)

    class DummyDarwinHardware:
        def __init__(self):
            self.module = DummyModule()

    dhw = DummyDarwinHardware()
    d = dhw.get_uptime_facts()
    assert isinstance(d['uptime_seconds'], int)
    assert d['uptime_seconds'] == 2404220

# Generated at 2022-06-22 22:59:57.404831
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = type('MockModule', (object,), dict(run_command=lambda x: (0, '', ''), params={}))
    hardware = DarwinHardware(module)
    assert hardware.platform == 'Darwin'
    assert hardware.sysctl is not None

# Generated at 2022-06-22 22:59:59.383152
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # For now just make sure it doesn't crash
    darwin_hw = DarwinHardware
    darwin_hw()

# Generated at 2022-06-22 23:00:00.790880
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # No OSX/Darwin system around to write tests on
    pass

# Generated at 2022-06-22 23:00:11.246851
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mock_module = type('ansible_module')()
    mock_module.run_command = Mock(return_value=(0, '', ''))
    mock_module.get_bin_path = Mock(return_value='')
    hardware = DarwinHardware(mock_module)
    hardware.sysctl = {
        'kern.osversion': '17.7.0',
        'kern.osrevision': '151672',
        'kern.boottime': '1339154864',
        'hw.memsize': '8589934592',
        'hw.model': 'MacBookPro11,2',
        'hw.physicalcpu': '2',
        'hw.logicalcpu': '8'
    }
    hardware.get_system_profile = Mock(return_value=dict())
   

# Generated at 2022-06-22 23:00:15.536814
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hw = DarwinHardware(dict())
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw.platform == 'Darwin'
    assert darwin_hw_collector.platform == 'Darwin'

# Generated at 2022-06-22 23:00:25.837595
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Test creation of DarwinHardware object
    # The creation of the object will call get_sysctl() which will raise a SystemExit exception
    # if the command does not exist
    try:
        darwin_hw = DarwinHardware(dict())
    except SystemExit:
        pass
    except Exception as e:
        raise

    # Test memory facts
    memory_facts = darwin_hw.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert memory_facts['memtotal_mb'] != 0
    assert memory_facts['memfree_mb'] != 0

# Generated at 2022-06-22 23:00:37.299982
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Run get_mac_facts() and verify the result.
    """
    os_version = '16.7.0'
    os_revision = '1671.256.16.43.1'
    model = 'MacBookPro9,2'
    module = Mock()
    module.run_command = Mock(return_value=(0, 'hw.model: {}\n'.format(model), ''))
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': os_version,
                       'kern.osrevision': os_revision}
    assert hardware.get_mac_facts() == {'model': model,
                                        'osversion': os_version,
                                        'osrevision': os_revision}



# Generated at 2022-06-22 23:00:40.873938
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """ Constructor for DarwinHardwareCollector()
    This test construct a DarwinHardwareCollector class.
    """

    obj = DarwinHardwareCollector()

    assert obj.platform == 'Darwin', 'Wrong platform'
    assert obj._fact_class == DarwinHardware, 'Wrong fact class'

# Generated at 2022-06-22 23:00:47.024714
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import tempfile

    try:
        import vcr
    except ImportError:
        pytest.skip('vcrpy is not installed, skipping test')

    (fd, _) = tempfile.mkstemp()
    os.close(fd)
    sys.modules['ansible.module_utils.basic'] = None
    sys.modules['ansible.module_utils.facts.hardware.base'] = None
    sys.modules['ansible.module_utils.facts.sysctl'] = None

    with vcr.use_cassette(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fixtures', 'DarwinHardware.yaml')):
        from ansible.module_utils.facts.hardware.darwin import DarwinHardware

# Generated at 2022-06-22 23:00:54.895548
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware()
    # mock the vmstat output
    hardware.module._bytes_output = b"Mach Virtual Memory Statistics: (page size of 4096 bytes)\n" \
    b"Pages free:                          113.\n" \
    b"Pages active:                         87.\n" \
    b"Pages inactive:                       64.\n" \
    b"Pages wired down:                    177.\n" \
    b"Pages purgeable:                      14.\n" \
    b"\"Translation faults\":            282250.\n" \
    b"Pages copy-on-write:               677847.\n" \
    b"Pages zero filled:                7030305.\n" \
    b"Pages reactivated:                   498.\n" \
    b"Pageins:                            8975.\n"

# Generated at 2022-06-22 23:01:01.097852
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    module = MagicMock()

# Generated at 2022-06-22 23:01:13.005281
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.compat.tests import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class StubModule():

        class FakeRunCommand():

            def __init__(self, fake_out):
                self.fake_out = fake_out

            def __call__(self, cmd, encoding=None):
                return (0, self.fake_out, '')

        def __init__(self, time_now, time_start):
            self.run_command = StubModule.FakeRunCommand(struct.pack('@L', time_start))
            self.time = int(time_now)

        def get_bin_path(self, module):
            # This is a required method, so we return a stub
            return str()


# Generated at 2022-06-22 23:01:23.259889
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = None
    sysctl_mock = {'kern.osversion': '15.6.0', 'kern.osrevision': '17G65'}
    darwin_hardware = DarwinHardware(module=module)
    darwin_hardware.sysctl = sysctl_mock
    darwin_hardware.module.run_command = mock_run_command
    result = darwin_hardware.get_mac_facts()
    assert result['osversion'] == sysctl_mock['kern.osversion']
    assert result['osrevision'] == sysctl_mock['kern.osrevision']
    assert result['model'] == 'MacBookPro11,4'


# Generated at 2022-06-22 23:01:33.097584
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class args():
        module = None
        run_command = staticmethod(_return_uptime_cmd_output)

    def _return_uptime_cmd_output(cmd, encoding=None):
        return (0, '{ "Epoch" = 1469063530; "Sec" = 1469063530; "Usec" = 222075; }', '')

    hardware = DarwinHardware(args)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 1570

# Generated at 2022-06-22 23:01:42.029586
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    hardware = DarwinHardware({}, module)
    actual = hardware.populate()
    assert actual['uptime_seconds'] == 0
    assert actual['osrevision'] == ''
    assert actual['osversion'] == ''
    assert actual['processor_cores'] == ''
    assert actual['model'] == ''
    assert actual['product_name'] == ''
    assert actual['memfree_mb'] == 0
    assert actual['memtotal_mb'] == 0
    assert actual['processor_vcpus'] == ''
    assert actual['processor'] == ''



# Generated at 2022-06-22 23:01:47.873072
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    def test_run_command(cmd, encoding=None):
        return 0, 'abcdefabcdef', ''

    module = MagicMock(run_command=test_run_command)
    darwin_hardware = DarwinHardware(module)
    fact = {
        'uptime_seconds': darwin_hardware.get_uptime_facts()['uptime_seconds']
    }
    assert fact['uptime_seconds'] > 0

# Generated at 2022-06-22 23:01:54.577857
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hw = DarwinHardware(dict())
    hw.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'}
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert cpu_facts.get('processor_vcpus') == ''


# Generated at 2022-06-22 23:02:02.784766
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    def mock_run_command(cmd, encoding=None):
        assert cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']
        return (
            0,
            '\x00\x00\x00\x00\x01\x22\x48\x8b\x00\x00\x00\x00',
            ''
        )

    class MockedModule(object):
        def get_bin_path(self, name):
            return '/usr/sbin/sysctl'

    module = MockedModule()
    module.run_command = mock_run_command
    hardware = DarwinHardware()
    hardware.module = module
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 793

# Generated at 2022-06-22 23:02:13.125477
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import mock

    darwin_module = mock.MagicMock()
    darwin_module.run_command.return_value = (0, "Hardware:\n", "")

    darwin_hardware = DarwinHardware(darwin_module)
    system_profile = darwin_hardware.get_system_profile()

    assert system_profile == dict()

    darwin_module.run_command.return_value = (0, "Hardware:\n  Hardware Overview:\n", "")
    system_profile = darwin_hardware.get_system_profile()

    assert system_profile == dict()

    darwin_module.run_command.return_value = (0, "Hardware:\n  Hardware Overview:\n    Model Name: MacBook Pro\n", "")

# Generated at 2022-06-22 23:02:16.604375
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:02:26.397096
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModuleMock()
    module.run_command = AnsibleModuleMock.run_command
    module.get_bin_path = AnsibleModuleMock.get_bin_path
    module.run_command.return_value = (0, 'test command output', '')
    module.get_bin_path.return_value = '/bin/sysctl'
    facts = DarwinHardwareCollector(module).collect()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'uptime_seconds' in facts



# Generated at 2022-06-22 23:02:37.250250
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-22 23:02:41.942504
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware_facts = DarwinHardware().populate()

    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['model']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert hardware_facts['uptime_seconds']

# Generated at 2022-06-22 23:02:51.773499
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Test using a fixture, but at some point it would be good to use real
    # (preferably mocked) output from "sysctl hw.model"
    fake_module = type('Fake Module', (object,), dict())
    fake_module.run_command = lambda *args, **kwargs: (0, 'hw.model: MacBookPro6,2', '')
    fake_module.get_bin_path = lambda *args, **kwargs: 'sysctl'
    result = DarwinHardware(fake_module).get_mac_facts()
    expected = dict(
        model = 'MacBookPro6,2',
        product_name = 'MacBookPro6,2',
        osversion = None,
        osrevision = None
    )
    assert result == expected


# Generated at 2022-06-22 23:02:55.282167
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = type('FakeAnsibleModule', (object,), dict(run_command=run_command))()
    hardware = DarwinHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] >= 0

# Generated at 2022-06-22 23:02:59.501860
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    d = DarwinHardware()
    expected_keys = ['model', 'product_name', 'osversion', 'osrevision']
    system_profile = d.get_system_profile()
    for key in expected_keys:
        assert key in system_profile.keys()


# Generated at 2022-06-22 23:03:01.312760
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    darwin = DarwinHardware(module)
    assert isinstance(darwin.facts, dict)

# Generated at 2022-06-22 23:03:13.806841
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """ Unit test to check get_memory_facts of class DarwinHardware """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwinHardware = DarwinHardware()

    # Negative test to check if the darwinHardware.module is defined
    try:
        darwinHardware.module
    except AttributeError as attr_err:
        assert attr_err
    else:
        raise

    # Positive test to check if the vm_stat command is returned
    # by the get_bin_path method
    try:
        from ansible.module_utils.common.process import get_bin_path
        vm_stat_command = get_bin_path('vm_stat')
        assert vm_stat_command
    except ValueError as val_err:
        assert val_err
    else:
        raise

# Generated at 2022-06-22 23:03:18.711619
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = FakeAnsibleModule()
    hw = DarwinHardware(module)
    hw.get_system_profile()
    assert module.run_command.called == True
    assert module.run_command.call_args_list[0][0][0] == ['/usr/sbin/system_profiler', 'SPHardwareDataType']


# Generated at 2022-06-22 23:03:31.000958
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mod_obj = MockModule()
    test_obj = DarwinHardware(mod_obj)
    sample_output = """
Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro11,4
      Processor Name: Intel Core i5
      Processor Speed: 2.5 GHz
      Number of Processors: 1
      Total Number of Cores: 2
      L2 Cache (per Core): 256 KB
      L3 Cache: 3 MB
      Memory: 8 GB
      Boot ROM Version: MBP114.0172.B23
      SMC Version (system): 2.19f12
      Serial Number (system): C02QQ2BQG3QH
      Hardware UUID: FFFFABFF-FFFF-FFFF-FFFF-FFFFA7FFFFFF
"""

# Generated at 2022-06-22 23:03:34.835234
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin = DarwinHardware(dict())
    assert darwin.platform == 'Darwin'
    assert darwin.sysctl is None
    assert darwin.get_system_profile() == dict()



# Generated at 2022-06-22 23:03:40.500854
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    """
    Constructor test for class DarwinHardware

    Arguments
    ---------
    No arguments

    Returns
    -------
    None

    Raises
    ------
    No exceptions
    """
    # test with no params
    darwin_hw = DarwinHardware()
    assert dict == type(darwin_hw.sysctl)
    assert 0 == len(darwin_hw.sysctl)
    assert 'Darwin' == darwin_hw.platform

# Generated at 2022-06-22 23:03:48.014850
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    sample_output = '''
     Hardware:

       Hardware Overview:

         Model Name: MacBook Pro
         Model Identifier: MacBookPro11,3
         Processor Name: Intel Core i7
         Processor Speed: 2.3 GHz
         Number of Processors: 1
         Total Number of Cores: 4
         L2 Cache (per Core): 256 KB
         L3 Cache: 6 MB
         Memory: 16 GB
         Boot ROM Version: MBP112.0138.B23
         SMC Version (system): 2.19f12
         Serial Number (system): C02P7N1DG8QG
         Hardware UUID: 948E5693-D100-5AB3-BDC3-7E3F3BE038F5
      '''