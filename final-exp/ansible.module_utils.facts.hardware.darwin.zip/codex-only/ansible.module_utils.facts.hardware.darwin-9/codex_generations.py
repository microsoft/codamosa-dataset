

# Generated at 2022-06-22 22:53:52.471250
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    mac_hw = DarwinHardware(dict())

    import time
    import ctypes
    from ctypes import c_ulonglong

    # Mock kern.boottime sysctl value
    mac_hw.sysctl = {'kern.boottime': b'%d, %d' % (
        ctypes.c_ulonglong(int(time.time()) - 42).value,  # seconds (in a 64-bits unsigned integer)
        ctypes.c_ulonglong(int(time.time() * 1000)).value,  # microseconds (in a 64-bits unsigned integer)
    )}

    assert mac_hw.get_uptime_facts() == {'uptime_seconds': 42}

# Generated at 2022-06-22 22:54:05.165869
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    fixtures = {
        "sysctl": {
            "hw.model": 0,
            "kern.osversion": "17.4.0",
            "kern.osrevision": "15E65"
        }
    }

    def impl_run_command(cmd, encoding=None):
        if cmd[0] == "/usr/sbin/system_profiler":
            return (0, "", "")
        else:
            return (0, fixtures["sysctl"][cmd[1]], "")

    expected = {
        "osversion": "17.4.0",
        "osrevision": "15E65"
    }

    d = DarwinHardware()
    d.module.run_command = impl_run_command
    actual = d.get_mac_facts()

    assert actual == expected



# Generated at 2022-06-22 22:54:14.806998
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
  '''
  Test that the populate method of the DarwinHardware class
  '''
  import os
  import json
  import subprocess
  import tempfile
  from ansible.module_utils.common.process import get_bin_path
  from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector

  if not os.path.exists('/usr/sbin/system_profiler'):
    exit(0)

  temp_dir=tempfile.mkdtemp()
  temp_file=temp_dir+'/temp_facts'
  with open(temp_file, 'w') as fd:
    fd.write(json.dumps(dict()))

# Generated at 2022-06-22 22:54:15.556061
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-22 22:54:23.902804
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import ansible.module_utils.facts.hardware.darwin
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class MockModule:
        def run_command(self, command, encoding=None):
            return 0, b'\x0a\x00\x00\x00\x00\x00\x00\x00', ''

        def get_bin_path(self, exe, opts=None, required=False):
            return '/sbin/sysctl'

    class MockTime:
        @staticmethod
        def time():
            return 1000.0

    darwin = DarwinHardware(MockModule())
    darwin.run_command = MockModule.run_command
    darwin.get_bin_path = MockModule.get_bin_path
    dar

# Generated at 2022-06-22 22:54:29.914256
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = {
        }
    )
    dH = DarwinHardware(module)
    assert dH.get_cpu_facts() == {
        'processor': 'Intel(R) Xeon(R) CPU E5-2667 v3 @ 3.20GHz',
        'processor_cores': 8,
        'processor_vcpus': 8,
    }


# Generated at 2022-06-22 22:54:33.009609
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector._platform == 'Darwin'
    assert hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-22 22:54:39.941882
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware(None)
    system_profile = hardware.get_system_profile()
    assert 'Hardware Overview' in system_profile
    assert 'Model Name' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile
    assert 'Number of Processors' in system_profile
    assert 'Memory' in system_profile

# Generated at 2022-06-22 22:54:48.095315
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)

    module.run_command = MagicMock(return_value=(0, 'hw.model: iMac14,1\n', None))
    mac_facts = hardware.get_mac_facts()
    assert mac_facts == {
        "model": "iMac14,1",
        "product_name": "iMac14,1",
        "osversion": "",
        "osrevision": "",
    }



# Generated at 2022-06-22 22:54:51.872584
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # pylint: disable=unused-variable
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector is not None

# Generated at 2022-06-22 22:54:59.924530
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Values are taken from "vm_stat 1" command. The optional wired memory is
    # not used in the calculation.
    memory_stats = {
        'Pages free': 313,
        'Pages active': 73,
        'Pages inactive': 154,
        'Pages speculative': 363,
    }
    th = DarwinHardware()
    th.sysctl = {'hw.memsize': '17179869184'}  # 16GB
    th.get_memory_facts = lambda: {}
    th.get_memory_facts.__name__ = 'get_memory_facts'
    th.get_memory_facts.__dict__['vm_stat'] = lambda: ('', memory_stats, 0)
    memory_facts = th.get_memory_facts()
    memtotal_mb = 16384

# Generated at 2022-06-22 22:55:06.574638
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    har = DarwinHardware(module)

    # Inject data into the class
    har.sysctl = {'kern.osversion': '16.1.0', 'kern.osrevision': '15160', 'hw.memsize': '4294967296', 'hw.physicalcpu': '4', 'hw.ncpu': '4', 'hw.model': 'MacBookPro10,1'}
    har.cpu_facts = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-3740QM CPU @ 2.70GHz', 'machdep.cpu.core_count': '4'}

    # Run the populate method
    facts = har.populate()
    assert 'model' in facts

# Generated at 2022-06-22 22:55:16.538393
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    sysctl = {
        to_bytes('machdep.cpu.brand_string'): to_bytes('Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'),
        to_bytes('machdep.cpu.core_count'): to_bytes('2'),
    }

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = lambda args, encoding=None: (0, '', '')
    module.get_bin_path = lambda name: name

    facts = DarwinHardware(module)
    facts.sysctl = sysctl
    cpu_facts = facts.get_cpu_facts()


# Generated at 2022-06-22 22:55:28.243249
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl

    sysctl_mock = dict(
        hw_model="hw.model: iMac16,1",
        kern_osversion="kern.osversion: 15.2.0",
        kern_osrevision="kern.osrevision: 16C67"
    )
    sysctl_mock = dict((k.split(':')[0], v.split(':')[1].strip()) for k, v in sysctl_mock.items())

# Generated at 2022-06-22 22:55:31.099843
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware({})
    hardware.get_system_profile()

# Generated at 2022-06-22 22:55:40.779913
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module_mock = mock.Mock()
    module_mock.run_command = mock.Mock(return_value=(0, 'hw.model: MacBookPro10,1', ''))
    hardware = DarwinHardware(module_mock)
    hardware.sysctl = {'kern.osversion': 'x.y.z', 'kern.osrevision': '1'}
    assert hardware.get_mac_facts() == {'model': 'MacBookPro10,1', 'osversion': 'x.y.z', 'osrevision': '1', 'product_name': 'MacBookPro10,1'}
    assert module_mock.run_command.call_count == 1
    module_mock.run_command.assert_called_with('sysctl hw.model')



# Generated at 2022-06-22 22:55:50.915461
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """Check that get_uptime_facts returns the correct value for a given boot time.
    """
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch


# Generated at 2022-06-22 22:55:53.974142
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == "Darwin"

# Generated at 2022-06-22 22:56:04.061419
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Unit test for method get_memory_facts of class DarwinHardware
    from ansible.module_utils.basic import AnsibleModule
    def run_command(args, **kwargs):
        # Since it's Unix, test for free output to be processed
        if args[0] == '/usr/bin/free':
            return 0, '''             total       used       free     shared    buffers     cached
Mem:       1024040     927652      96380          0      54320     363736
-/+ buffers/cache:     509596     514444
Swap:       237559     117542     120008''', ''

    module = AnsibleModule(argument_spec=dict())
    module.run_command = run_command

    hardware_facts_class = DarwinHardware(module)
    memory_facts = hardware_facts_

# Generated at 2022-06-22 22:56:15.717165
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = get_fake_module()

    # Test with a Intel based Mac
    set_module_args(dict(
        gather_subset='all',
        gather_timeout=30,
        filter=dict(name='ansible_processor')
    ))
    # Create a intel based mac object
    mac_intel = DarwinHardware(module=module)
    facts = mac_intel.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-8750H CPU @ 2.20GHz'
    assert facts['processor_cores'] == 2

    # Test with a PowerPC based Mac
    set_module_args(dict(
        gather_subset='all',
        gather_timeout=30,
        filter=dict(name='ansible_processor')
    ))
    # Create a PowerPC based mac object

# Generated at 2022-06-22 22:56:25.812581
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware()
    hardware.module = None
    hardware.sysctl = dict()
    hardware.sysctl['hw.logicalcpu'] = 2
    hardware.sysctl['hw.physicalcpu'] = 2
    hardware.sysctl['machdep.cpu.brand_string'] = 'Intel'
    hardware.sysctl['machdep.cpu.core_count'] = 2
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor_vcpus'] == 2
    assert cpu_facts['processor'] == 'Intel'


# Generated at 2022-06-22 22:56:29.902656
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw = DarwinHardwareCollector()
    assert darwin_hw.platform == 'Darwin'

# Generated at 2022-06-22 22:56:40.464559
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class Module:
        def __init__(self, fail_json_msg, params):
            self.params = params
            self.fail_json_msg = fail_json_msg

        def fail_json(self, msg):
            self.fail_json_msg = msg

    class TestHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    class TestSysctl():
        def __init__(self, module):
            self.sysctl = {'kern.osversion': '1', 'kern.osrevision': '2', 'hw.memsize': '3', 'hw.physicalcpu': '4', 'hw.model': 'Dummy Model'}

    #mock dictionary of sysctl values

# Generated at 2022-06-22 22:56:49.068050
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware()

    # Test if get_memory_facts returns expected values for valid vm_stat output.
    rc = 0

# Generated at 2022-06-22 22:56:55.514542
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    config = dict()
    config['module_name'] = 'command'
    config['module_args'] = dict()
    config['module_args']['_raw_params'] = "/usr/sbin/system_profiler"

    class TestModule():
        def __init__(self, config):
            self.config = config


# Generated at 2022-06-22 22:57:07.786169
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = None
    facter = DarwinHardware(module)
    collected_facts = {'kernel': 'Darwin'}


# Generated at 2022-06-22 22:57:18.079198
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    darwin_hw_instance = DarwinHardware(module)

    module.run_command = run_command_mock
    module.run_command.side_effect = run_command_side_effect

    darwin_hw_instance.get_mac_facts = get_mac_facts_mock
    darwin_hw_instance.get_mac_facts.return_value = {
        'osversion': '16.7.0',
        'osrevision': '15R2048',
        'model': 'MacPro5,1'
    }

    darwin_hw_instance.get_system_profile = get_system_profile_mock

# Generated at 2022-06-22 22:57:29.947832
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class Options(object):
        def __init__(self, module):
            self.module = module
            self.no_log = False
            self.gather_timeout = 10
            self.verbosity = 0
            self.all_logs = False
            self.multiplex_vars = False

    class Module(object):
        def __init__(self):
            self.options = Options(self)
            self.no_log_values = set(())

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return "/usr/bin/%s" % executable


# Generated at 2022-06-22 22:57:37.795511
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = mock.Mock()
    facts = DarwinHardware(module)
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6600U CPU @ 2.60GHz',
        'machdep.cpu.core_count': 4
    }
    facts.sysctl = sysctl

    result = facts.get_cpu_facts()

    assert result == {
        'processor': 'Intel(R) Core(TM) i7-6600U CPU @ 2.60GHz',
        'processor_cores': 4
    }



# Generated at 2022-06-22 22:57:44.601843
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = MockModule()
    sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    module.run_command.return_value = (0, str(sysctl['kern.boottime']), '')
    now = time.time()
    expected = {
        'uptime_seconds': int(now - float(sysctl['kern.boottime'])),
    }
    hardware = DarwinHardware(module)
    hardware.sysctl = sysctl
    result = hardware.get_uptime_facts()
    assert result == expected


# Generated at 2022-06-22 22:57:52.705515
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = mock.MagicMock(return_value=(0, 'hw.model: MacBookPro8,1', ''))
    test_DarwinHardware = DarwinHardware()
    test_DarwinHardware.module = test_module
    result = test_DarwinHardware.get_mac_facts()
    assert result == {'model': 'MacBookPro8,1', 'osversion': '', 'osrevision': ''}



# Generated at 2022-06-22 22:58:02.287595
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    test_sysctl = {'kern.boottime': '{ sec = 1234567890, usec = 0 }', 'kern.osversion': '16.3.0', 'kern.osrevision': '16D32', 'hw.memsize': '16777216', 'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-3615QM CPU @ 2.30GHz', 'machdep.cpu.core_count': '4'}
    test_module = 'ansible.module_utils.facts.hardware.darwin'
    test_class = DarwinHardware
    test_platform = 'Darwin'

    darwin_collector = DarwinHardwareCollector(test_module, test_sysctl, test_class, test_platform)


# Generated at 2022-06-22 22:58:09.871318
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():  # pylint: disable=too-many-locals
    module = FakeAnsibleModule()
    darwin_hardware = DarwinHardware(module=module)
    err_msg = "The default constructor of DarwinHardware should be instance of Hardware"
    assert isinstance(darwin_hardware, Hardware), err_msg
    err_msg = "The default constructor of DarwinHardware should have set the platform"
    assert darwin_hardware.platform == 'Darwin', err_msg



# Generated at 2022-06-22 22:58:15.386733
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts



# Generated at 2022-06-22 22:58:27.347382
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """
    DarwinHardware - populate()
    """
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    result = hardware.populate()
    assert 'processor' in result
    assert result['processor'] == 'Intel(R) Core(TM) i5-4670S CPU @ 3.10GHz'
    assert 'processor_cores' in result
    assert result['processor_cores'] == '4'
    assert 'processor_vcpus' in result
    assert 'memtotal_mb' in result
    assert result['memtotal_mb'] == 16384
    assert 'memfree_mb' in result
    assert result['memfree_mb'] == 0
    assert 'model' in result
    assert result['model'] == 'Macmini7,1'
    assert 'osversion' in result

# Generated at 2022-06-22 22:58:36.852478
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-22 22:58:46.955174
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = type('', (object,), {'run_command': lambda self, a, b, c=None: (0, 'hw.model: MacBookPro16,3', '')})()
    module.run_command = lambda x, check_rc=True, encoding=None, data=None: (0, "a", "")
    darwin_hardware = DarwinHardware(module)
    mac_facts = darwin_hardware.get_mac_facts()
    if mac_facts['model'] != "MacBookPro16,3":
        raise Exception("The model must be MacBookPro16,3")

# Generated at 2022-06-22 22:58:58.605072
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    hw = DarwinHardware(module)
    hw.sysctl = {
        'kern.osversion': '10.9.5',
        'kern.osrelease': '13F34',
        'hw.memsize': 4294967296,
        'hw.ncpu': 4,
        'hw.physicalcpu': 2,
        'hw.logicalcpu': 4,
    }
    hw.get_system_profile = lambda: {
        'Processor Name': 'Intel Core i5',
        'Processor Speed': '2.5 GHz',
    }

# Generated at 2022-06-22 22:59:09.180552
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Mocking module to be able to run this test outside of a playbook.
    class Module:
        def __init__(self):
            self.fail_json = True

        def run_command(self, cmd, encoding=None):
            # The bytes are the same as the output of sysctl.
            return (0, b'\x00\x00\x00\x00\x00\x00\x00\x00', '')


    class MockTime:
        def time(self):
            # 10 seconds after the kern.boottime.
            return 10

    import time
    old_time_time = time.time
    time.time = MockTime().time

    h = DarwinHardware(Module())
    uptime_facts = h.get_uptime_facts()

    assert uptime_facts['uptime_seconds']

# Generated at 2022-06-22 22:59:11.213665
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()

    assert hardware.sysctl is not None
    assert hardware.sysctl['hw.memsize'] is not None

# Generated at 2022-06-22 22:59:13.781721
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    Unit test for get_uptime_facts method of class DarwinHardware
    """

    # create a test object
    hardware = DarwinHardware()

    # create a test dict
    uptime_list = hardware.get_uptime_facts()
    assert (uptime_list['uptime_seconds'] > 0)

# Generated at 2022-06-22 22:59:24.248587
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module_mock = MockModule()
    set_module_args(dict())

    # instantiate MockOs detection class
    darwin_hw = DarwinHardware(module_mock)

    # create fake sysctl to be used
    class MockSysctl(object):
        _sysctl = {
            'hw.memsize': '4',
            'hw.physmem': '4',
            'hw.ncpu': '2',
            'hw.model': 'i386',
            'hw.machine_arch': 'i386',
            'kern.version': 'Darwin Kernel Version 14.3.0: Mon Mar 23 11:59:05 PDT 2015; root:xnu-2782.20.48~5/RELEASE_X86_64',
        }

# Generated at 2022-06-22 22:59:25.384237
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Test if DarwinHardwareCollector can be constructed
    DarwinHardwareCollector()

# Generated at 2022-06-22 22:59:33.190388
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock

    class MockedModule:
        def run_command(self, command):
            mocked_run = Mock()
            mocked_run.configure_mock(**{
                'return_value.__getitem__.side_effect': [100, "/n", None],
                'return_value.__getitem__.return_value': "hw.model: MacBookPro12,1"
            })
            return mocked_run

    module = MockedModule()
    hardware = DarwinHardware(module=module)
    hardware.sysctl = {'kern.osversion': '10.13.4', 'kern.osrevision': '17E199'}
    # test
    assert hardware.get_mac_facts()

# Generated at 2022-06-22 22:59:37.990757
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert 'uptime_seconds' in hardware_facts



# Generated at 2022-06-22 22:59:40.018855
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(dict())
    darwinHardware = DarwinHardware(module)
    assert darwinHardware.platform == 'Darwin'

# Generated at 2022-06-22 22:59:52.063456
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    params = {
        'module': {},
        'ansible_facts': {},
    }

# Generated at 2022-06-22 23:00:02.224944
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['all'])})
    obj_hw = DarwinHardware(module)
    assert obj_hw.sysctl['kern.hostname'] == 'Darwin Kernel Version 17.4.0'
    assert obj_hw.get_mac_facts()['model'] == 'MacBookPro11'
    assert obj_hw.get_mac_facts()['osversion'] == '15E65'
    assert obj_hw.get_mac_facts()['osrevision'] == '15E65'
    assert obj_hw.get_cpu_facts()['processor'] == 'Intel(R) Core(TM) i5-5287U CPU @ 2.90GHz'
    assert obj_hw.get_cpu_facts()['processor_cores'] == '1'


# Generated at 2022-06-22 23:00:04.910198
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    Test constructor of class DarwinHardwareCollector
    """

    obj = DarwinHardwareCollector()
    assert obj.platform == 'Darwin'
    assert obj._fact_class == DarwinHardware

# Generated at 2022-06-22 23:00:07.577135
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    darwin_hardware_collector.collect()

# Generated at 2022-06-22 23:00:10.759442
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = DarwinHardware(module)
    hardware_obj.get_memory_facts()

# Generated at 2022-06-22 23:00:21.012608
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # test data
    # two types of return values to test
    # 0.00226008413293886,19113344.000000
    # 0.00226008413293886,19113344
    test_data = [
        [0, b'0.00226008413293886,19113344.000000\n', b''],
        [0, b'0.00226008413293886,19113344\n', b''],
    ]
    for td in test_data:
        # create fake module with the test data
        module = FakeAnsibleModule(td)
        # create object of class DarwinHardware
        darwinHardware = DarwinHardware()
        # set the fake module to the object
        darwinHardware.module = module
        # get uptime facts
       

# Generated at 2022-06-22 23:00:30.609264
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from mock import patch
    from ansible.module_utils.facts.hardware import darwin_hardware

    darwin_hardware.get_bin_path = lambda x: '/usr/sbin/system_profiler'
    system_profile_facts = {'Model Identifier': 'MacBookPro11,4',
                            'Serial Number (system)': 'C02Q4P3QF8VW',
                            'Processor Name': 'Intel Core i7',
                            'Processor Speed': '2.5 GHz',
                            'Number of Processors': '1',
                            'Total Number of Cores': '4'}


# Generated at 2022-06-22 23:00:41.072262
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a mock module to use in testing
    module = type('module', (object,), dict())

    # Create a mock run_command method

# Generated at 2022-06-22 23:00:49.841772
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    This function tests that the get_memory_facts() function returns
    expected values for the memory facts on Darwin systems
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    dh = DarwinHardware()
    memory_facts = dh.get_memory_facts()

    test_dict = {
        'memtotal_mb': memory_facts['memtotal_mb'],
        'memfree_mb': memory_facts['memfree_mb'],
    }

    assert test_dict == memory_facts

# Generated at 2022-06-22 23:00:52.401216
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    hardware = DarwinHardware(module)
    hardware.populate()

# Generated at 2022-06-22 23:00:59.773628
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    mac_hardware = DarwinHardware(module)
    mac_hardware.module = module

    # Mock the sysctl dictionary
    mac_hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-3230M CPU'}
    mac_hardware.sysctl['machdep.cpu.core_count'] = '2'
    test_cpu_facts = mac_hardware.get_cpu_facts()
    assert test_cpu_facts['processor_cores'] == '2'
    assert test_cpu_facts['processor'] == 'Intel(R) Core(TM) i5-3230M CPU'

    # Mock the sysctl dictionary

# Generated at 2022-06-22 23:01:10.437768
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )

    hw = Hardware(module)
    facts = hw.populate()

    assert facts['uptime_seconds'] != 0
    assert facts['model'] != ""
    assert facts['osversion'] != ""
    assert facts['osrevision'] != ""
    assert facts['processor'] != ""
    assert facts['processor_cores'] != ""
    assert facts['processor_vcpus'] != ""
    assert facts['memtotal_mb'] != 0
    assert facts['memfree_mb'] != 0

from ansible.module_utils.basic import *
if __name__ == '__main__':
    test_DarwinHardware_populate()

# Generated at 2022-06-22 23:01:16.911586
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    Hardware._module = None
    darwinHardware = DarwinHardware()
    res = darwinHardware.populate()
    assert res["uptime_seconds"] >= 0
    assert res["memfree_mb"] >= 0
    assert res["processor_cores"] >= 0
    assert res["memtotal_mb"] >= 0
    assert res["osrevision"] >= 0

# Generated at 2022-06-22 23:01:19.297815
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector is not None

# Generated at 2022-06-22 23:01:20.246789
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector._platform == 'Darwin'

# Generated at 2022-06-22 23:01:21.492818
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware(dict())
    hardware.get_system_profile()

# Generated at 2022-06-22 23:01:22.364810
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector() is not None

# Generated at 2022-06-22 23:01:24.443804
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    Test if DarwinHardwareCollector will be an instance of DarwinHardwareCollector.
    """
    assert isinstance(DarwinHardwareCollector(), DarwinHardwareCollector)

# Generated at 2022-06-22 23:01:36.643311
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # TODO: Remove this once we have a unit test system for this.
    # Create a fake module for the DarwinHardware class.
    class Mod:

        class RunCmd:
            def __init__(self, rc, out):
                self.rc = rc
                self.out = out
            def __call__(self, cmd):
                return self.rc, self.out, ""


# Generated at 2022-06-22 23:01:40.937671
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.system.darwin_hardware import DarwinHardware

    # Number of seconds between Jan 1, 1970, and Jan 1, 2001.
    REFERENCE_VALUE = 978307200

    # kern.boottime content for the reference value.
    REFERENCE_KERN_BOOTTIME = b"\x01\x00\x00\x00\x7c\x58\xb5\x1b"

    # Mocked module
    module = Mock(name='module',
                  run_command=Mock(return_value=(0, REFERENCE_KERN_BOOTTIME, None)))

    # Test instantiation
    darwin_hardware = DarwinHardware(module)

    # Test get_uptime_facts
    result = darwin_hardware.get_uptime_facts()


# Generated at 2022-06-22 23:01:42.994344
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    mac = DarwinHardware({})
    assert mac.platform == 'Darwin'

# Generated at 2022-06-22 23:01:45.682770
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    h = DarwinHardware()
    assert h.platform == 'Darwin', 'platform is set to %s instead of %s' % (h.platform, 'Darwin')

# Generated at 2022-06-22 23:01:57.570283
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    # Test case 1 - sysctl hw.model returns value
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'hw.model: MacBookPro6,2', ''))
    darwin_hw_get_mac_facts = DarwinHardware(module)
    facts = darwin_hw_get_mac_facts.get_mac_facts()
    assert facts['model'] == 'MacBookPro6,2'

    # Test case 2 - sysctl hw.model does not return value
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(1, '', 'ERROR'))
    darwin_hw_get_mac_facts = DarwinHardware(module)
    facts = darwin_hw_get

# Generated at 2022-06-22 23:02:02.859635
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_fact_collector = DarwinHardwareCollector()

    assert darwin_fact_collector._fact_class == DarwinHardware
    assert darwin_fact_collector._platform == 'Darwin'
    assert not hasattr(darwin_fact_collector, '_collect_platform')


# Generated at 2022-06-22 23:02:13.158042
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    ansible_module = AnsibleModule(
        argument_spec=dict()
    )
    ansible_module._checks = dict(argspec=dict(), nocheck=[])
    hardware = DarwinHardware(ansible_module)

    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz',
        'machdep.cpu.core_count': '4',
        'hw.memsize': '1055353344',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
        'kern.osversion': '15.6.0',
        'kern.osrevision': '15F34',
    }
    # get_bin_path return None if command is not

# Generated at 2022-06-22 23:02:24.489803
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware(dict(module=None))
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2620 0 @ 2.00GHz',
        'machdep.cpu.core_count': 2,
        'hw.logicalcpu': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    if cpu_facts['processor'] != 'Intel(R) Xeon(R) CPU E5-2620 0 @ 2.00GHz':
        assert False
    if cpu_facts['processor_cores'] != 2:
        assert False
    if cpu_facts['processor_vcpus'] != 4:
        assert False


# Generated at 2022-06-22 23:02:35.820074
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    m = type('MockModule', (object,), {'run_command': get_system_profile})
    h = DarwinHardware(m)

# Generated at 2022-06-22 23:02:45.840688
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # TODO: make a real unit test
    # Currently the unit test is using the real sysctl binary, and just
    # check the results of what was parsed. It is not testing the
    # specific value but only the result format.
    sysctl_cmd = get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    rc, out, err = module.run_command(cmd, encoding=None)
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    (kern_boottime, ) = struct.unpack(struct_format, out[:struct_size])

    uptime_seconds = int(time.time() - kern_boottime)

    assert uptime_seconds > 0


# Generated at 2022-06-22 23:02:55.970079
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    from ansible.module_utils.facts.hardware.darwin import _DarwinHardwareCollector as DarwinHardwareCollector
    from ansible.module_utils.six import PY2

    # Collected data

# Generated at 2022-06-22 23:03:03.893386
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class FakeModule(object):
        def run_command(self, *args, **kwargs):
            # We assume this method will be only called with the following command
            if args[0][0] == '/usr/sbin/system_profiler':
                return (0, '''
                Hardware Overview:

                  Model Name: MacBook Pro
                  Processor Name: Intel Core i7
                  Processor Speed: 2.9 GHz
                  Number of Processors: 1
                  Total Number of Cores: 2
                  L2 Cache (per Core): 256 KB
                  L3 Cache: 6 MB
                  Memory: 8 GB
                ''', '')

# Generated at 2022-06-22 23:03:16.149958
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Test values as returned by sysctl.
    test_values = [
        # boottime as hex, expected uptime_seconds
        # Values got from a Mac running OS X 10.11.
        ('0x5e82e03', 1249),
        # From a Ubuntu VM running on OS X 10.11.
        ('0x5edacca', 2311),
    ]

    darwin_hardware_instance = DarwinHardware(None, None)

    for (boottime, expected_uptime_seconds) in test_values:
        # Call the tested method with a fake sysctl output.
        facts = darwin_hardware_instance.get_uptime_facts(boottime=boottime)

        # Assert that the method returns the expected uptime_seconds.
        assert facts['uptime_seconds'] == expected_uptime_seconds

# Generated at 2022-06-22 23:03:17.665271
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hc = DarwinHardwareCollector()
    assert darwin_hc is not None

# Generated at 2022-06-22 23:03:24.727005
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import AnsibleFactCollector


# Generated at 2022-06-22 23:03:34.564309
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModuleMock({})
    darwin_hardware = DarwinHardware(module)

# Generated at 2022-06-22 23:03:36.166510
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert d._platform == 'Darwin'
    assert d._fact_class == DarwinHardware
    assert d.collector == d._collect_platform_facts

# Generated at 2022-06-22 23:03:40.361443
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    results = hardware.populate()
    assert results['model']
    assert results['processor']
    assert results['processor_cores']
    assert results['processor_vcpus']
    assert results['memtotal_mb']
    assert results['memfree_mb']
    assert results['osrevision']
    assert results['osversion']
    assert results['uptime_seconds']

# Generated at 2022-06-22 23:03:53.588346
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Test empty output
    mac_hw = DarwinHardware(module)
    mac_hw.sysctl = dict()
    mac_facts = mac_hw.get_mac_facts()
    assert mac_facts == dict()

    # Test output of sysctl hw.model
    mac_hw.sysctl = {'hw.model': 'MacBookPro9,1'}
    mac_facts = mac_hw.get_mac_facts()
    assert mac_facts == {'model': 'MacBookPro9,1', 'product_name': 'MacBookPro9,1'}

    # Test output of sysctl kern.osversion and kern.osrevision