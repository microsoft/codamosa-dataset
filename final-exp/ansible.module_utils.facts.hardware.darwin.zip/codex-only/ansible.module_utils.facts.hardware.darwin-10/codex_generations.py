

# Generated at 2022-06-22 22:53:54.340558
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    # required for testing, an object of class ModuleStub called module
    module = ModuleStub()

    # required for testing, an object of class DarwinHardware called hardware
    hardware = DarwinHardware(module)

    # The actual output of the command: vm_stat

# Generated at 2022-06-22 22:54:01.929980
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_module = MagicMock()
    test_module_result = MagicMock(return_value=0)
    test_module.run_command = MagicMock(return_value=(test_module_result, '4096\n4096\n4096', ''))
    test_module.modules = []

    darwin_hw = DarwinHardware(module=test_module)

    memory_facts = darwin_hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1
    assert memory_facts['memfree_mb'] == 1

    test_module_result = MagicMock(return_value=1)
    test_module.run_command = MagicMock(return_value=(test_module_result, '', ''))
    memory_facts = darwin_hw.get_memory_

# Generated at 2022-06-22 22:54:05.978829
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.common.listmachines import list_all_machines
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.six.moves import StringIO

    class MockModule(object):

        def __init__(self):
            self.params = {}
            self.run_command_invoked = False
            self.run_command_stdout = ""

        def fail_json(self, **kwargs):
            pass

        def get_bin_path(self, arg, **kwargs):
            return "/usr/sbin/vm_stat"

        def run_command(self, args, **kwargs):
            self.run_command_invoked = True
            stdout = self.run_command_stdout

# Generated at 2022-06-22 22:54:15.490164
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    # Make class instance
    mac_facts = DarwinHardware()

    # Create dict with vm statistics
    vm_stats = {
        'Pages wired down': 69956,
        'Pages active': 99637,
        'Pages inactive': 58004,
        'Pages free': 0,
    }

    # Convert dict to lines
    vm_stats_as_lines = []
    for key in vm_stats:
        vm_stats_as_lines.append(key + ': ' + str(vm_stats[key]) + '.')

    # Create final output
    out = "\n".join(vm_stats_as_lines)

    # Mock instance method module.run_command
    mac_facts.module.run_command = lambda cmd: (0, out)

    # Execute method
    mem_facts = mac_facts.get

# Generated at 2022-06-22 22:54:19.524625
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hw = DarwinHardware(None)
    assert darwin_hw.sysctl is None
    assert darwin_hw._platform == 'Darwin'
    assert darwin_hw.platform == 'Darwin'
    assert darwin_hw.facts is None


# Generated at 2022-06-22 22:54:21.521559
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware({})
    assert hardware.platform == 'Darwin'


# Generated at 2022-06-22 22:54:28.367867
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.run_command = MagicMock(return_value=(0, "hw.model: MacBookPro12,1", ""))
    hardware = DarwinHardware(module)
    facts = hardware.get_mac_facts()
    assert facts['model'] == 'MacBookPro12,1'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == ''


# Generated at 2022-06-22 22:54:39.170329
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    def get_system_profile_mock(self):
        return {
            'Machine Model': 'MacBookPro6,1',
            'Processor Name': 'Intel Core2 Duo',
            'Processor Speed': '2.66 GHz',
        }

    module = AnsibleModuleMock()
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.get_system_profile = get_system_profile_mock
    facts = darwin_hardware.get_mac_facts()
    assert facts['model'] == 'MacBookPro6,1'
    assert facts['osversion'] == '19.2.0'
    assert facts['osrevision'] == '17C88'

# Generated at 2022-06-22 22:54:51.820989
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import shutil
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a fake vm_stat command
    vm_stat_command = os.path.join(tmpdir, 'vm_stat_command')

# Generated at 2022-06-22 22:54:59.924508
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils.timezone import get_cur_timezone_offset

    # We need to mock the current time and timezone using the epoch
    # timezone (0 timezone) of 1970-01-01T00:00:00.
    # We also have to adjust the current timezone to 0 (UTC), otherwise
    # the test would fail as the timezone would change
    # the value of the number of seconds returned by time.time().
    import time
    import os
    old_tz = os.environ.get('TZ')
    os.environ['TZ'] = "ETC/UTC"
    time.tzset()

    # The epoch timestamp used for our tests.
    epoch_timestamp = 0

   

# Generated at 2022-06-22 22:55:05.713858
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = type('Module', (object,), {'run_command': run_command_mock})
    hardware_facts = DarwinHardware(module=module)
    cpu_facts = hardware_facts.get_cpu_facts()
    # processor_vcpus should normally be greater than or equal to processor_cores
    assert cpu_facts['processor_cores'] <= cpu_facts['processor_vcpus']


# Generated at 2022-06-22 22:55:13.570230
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    module = Mock(
            debug=Mock(return_value=None),
            get_bin_path=Mock(return_value='/sbin/sysctl'),
            run_command=Mock(return_value=(0, struct.pack('@L', 1496100594), '')),
        )

    hardware = DarwinHardware(module)

    expected_uptime = {
            'uptime_seconds': int(time.time() - 1496100594),
        }

    assert hardware.get_uptime_facts() == expected_uptime

# Generated at 2022-06-22 22:55:21.045704
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    this_module = type(sys)('__main__')
    this_module.run_command = lambda x: (0, '1234', None)
    this_module.get_bin_path = lambda x: '/usr/sbin/sysctl'

    hardware_facts = DarwinHardware(this_module)
    assert hardware_facts.get_uptime_facts() == {'uptime_seconds': 1234}

# Generated at 2022-06-22 22:55:32.472820
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-22 22:55:42.215975
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module=module)
    hardware.sysctl = {'kern.osversion': 'darwin_version', 'kern.osrevision': 'darwin_revision'}
    hardware.sysctl['hw.model'] = 'hw_model'
    module.run_command = AnsibleModuleMock.run_command

    assert hardware.get_mac_facts() == {
        'osversion': 'darwin_version',
        'osrevision': 'darwin_revision',
        'model': 'hw_model',
    }


# Generated at 2022-06-22 22:55:52.127739
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    sample_module = AnsibleModule(argument_spec={})
    facts = module.get_bin_path('facts')
    command_output = module.run_command(facts)[1]
    darwin_hardware = DarwinHardware(module)
    assert darwin_hardware
    darwin_hardware_populated_facts = darwin_hardware.populate()
    if 'processor' in command_output:
        assert darwin_hardware_populated_facts['processor'] == sample_module.run_command(module.get_bin_path('system_profiler'), 'SPHardwareDataType | grep \'Processor Name\'')[1].split(':')[1].strip()
    if 'processor_cores' in command_output:
        assert darwin

# Generated at 2022-06-22 22:56:01.146604
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Since the sysctl and vm_stat command are not available in a unit testing
    # environment, we are just testing whether the returned dictionary has the
    # keys we expect, but without any values.
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    mac_facts = DarwinHardware()
    mac_facts.module = FactsCollector()
    mac_facts.module.run_command = lambda x: (0, '', '')
    memory_facts = mac_facts.get_memory_facts()

    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts

# Generated at 2022-06-22 22:56:14.004366
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import tempfile
    content_template="""{}:\t{}
"""
    content = content_template.format('Serial Number', 'XXX')
    content += content_template.format('Hardware UUID', 'YYY')
    content += content_template.format('SMC Version (system)', '1.1f4')
    content += content_template.format('System Version', 'OS X 10.11.1 (15B42)')
    content += content_template.format('System Memory', '8 GB')
    content += content_template.format('Processor Name', 'Intel Core i7')
    content += content_template.format('Processor Speed', '2.5 GHz')
    content += content_template.format('Boot ROM Version', 'MBP102.88Z.0138.B17.1501021708')

# Generated at 2022-06-22 22:56:26.332956
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.system.darwin import DarwinHardware
    import os

    darwin_hardware = DarwinHardware()
    darwin_hardware.module = MockAnsibleModule()
    if os.path.exists('/usr/sbin/system_profiler'):
        darwin_hardware.sysctl = {
            'kern.osversion': '10.12.0',
            'kern.osrevision': '16A323',
        }
        mac_facts = darwin_hardware.get_mac_facts()
        assert mac_facts == {
            'model': 'MacBookPro13,2',
            'osversion': '10.12.0',
            'osrevision': '16A323',
        }
    else:
        mac_facts = d

# Generated at 2022-06-22 22:56:38.905292
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class FakeModule:
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = {}

        def run_command(self, args, encoding=None):
            self.run_command_count += 1
            self.run_command_args[self.run_command_count] = args
            if self.run_command_count == 1:
                return (0, b'/dev/disk0s2   396365008 190982784  205380224  48%    /', None)

# Generated at 2022-06-22 22:56:45.853735
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=[0, 'foo 42@5.6', ''])
    hardware = DarwinHardware(module)
    hardware.sysctl = dict(machdep_cpu_brand_string='foo 42@5.6')
    assert hardware.get_cpu_facts() == dict(
        processor='foo 42@5.6',
        processor_cores=42,
        processor_vcpus=42,
    )



# Generated at 2022-06-22 22:56:51.047021
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mod = type('Module', (object,), {'run_command': lambda *args, **kwargs: (0, 'Pages wired down:   61324\n', '')})()
    darwin = DarwinHardware(mod)
    darwin.sysctl = {'hw.memsize': '17179869184'}
    facts = darwin.get_memory_facts()
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 16368

# Generated at 2022-06-22 22:57:01.632738
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module_mock = MockModule()
    mac_facts_mock = {
        'machdep.cpu.brand_string': "Intel Core i9-9880H 8-Core Processor",
        'hw.memsize': 20971520, 'hw.ncpu': 24,
        'kern.osversion': "19.4.0", 'kern.osrevision': 'Darwin Kernel Version 19.4.0'
    }
    class_mock = DarwinHardware(module_mock)
    class_mock.sysctl = mac_facts_mock
    rc, out, err = module_mock.run_command("sysctl hw.model")

# Generated at 2022-06-22 22:57:13.370585
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True)

    # minimal collected facts
    facts = dict()

    hw = DarwinHardware(module)
    facts.update(hw.populate())

    assert facts['model'] == 'MacBookPro'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '18G1012'
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 4
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 33
    assert facts['uptime_seconds'] > 0

# Generated at 2022-06-22 22:57:21.252627
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    fact_subclass = DarwinHardware()
    # Test first available
    fact_subclass.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '19G2021'}
    rc, out, err = fact_subclass.module.run_command("sysctl hw.model")
    fact_subclass.get_mac_facts()
    assert fact_subclass.facts['model'] == 'Macmini8,1', 'model should be Macmini8,1'
    assert fact_subclass.facts['osversion'] == '15.6.0', 'osversion should be 15.6.0'
    assert fact_subclass.facts['osrevision'] == '19G2021', 'osrevision should be 19G2021'


# Generated at 2022-06-22 22:57:24.130462
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    result = DarwinHardware.get_system_profile(object())
    assert 'Chipset Model' in result
    assert result['Chipset Model'] == 'X79'


# Generated at 2022-06-22 22:57:28.227853
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hostname = "dummy-host"
    loader = 'dummy'
    runner = 'dummy'
    module = 'dummy'

    darwin_collector = DarwinHardwareCollector(runner, hostname, loader, module)
    assert darwin_collector.platform == 'Darwin'
    assert isinstance(darwin_collector.collect(), dict)


# Generated at 2022-06-22 22:57:33.170734
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert hasattr(darwin_hw_collector, '_fact_class')
    assert hasattr(darwin_hw_collector, '_platform')
    assert darwin_hw_collector._fact_class == 'DarwinHardware'
    assert darwin_hw_collector._platform == 'Darwin'

# Generated at 2022-06-22 22:57:36.152387
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = MagicMock()
    hardware = DarwinHardware(module)
    hardware.get_memory_facts()
    module.run_command.assert_called_with(['vm_stat'])



# Generated at 2022-06-22 22:57:45.152269
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import sys
    import imp

    # Mock module
    sys.modules['ansible.module_utils.facts.hardware.darwin'] = imp.new_module('ansible.module_utils.facts.hardware.darwin')
    sys.modules['ansible.module_utils.facts.hardware.darwin'].get_bin_path = lambda *args: '/usr/sbin/system_profiler' if args[0] == 'system_profiler' else None
    sys.modules['ansible.module_utils.facts.hardware.darwin'].get_filesystem_encoding = lambda: 'UTF-8'
    sys.modules['ansible.module_utils.facts.hardware.darwin'].to_bytes = lambda x: x.encode('UTF-8')


# Generated at 2022-06-22 22:57:56.947779
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    test_file_path = os.path.join(os.path.dirname(__file__), 'system_profiler_SPHardwareDataType.txt')
    with open(test_file_path) as f:
        system_profiler_SPHardwareDataType = f.read()
        hardware = DarwinHardware(dict(module=dict()), dict())
        hardware.module.run_command = lambda command: (0, system_profiler_SPHardwareDataType, '')

# Generated at 2022-06-22 22:57:58.690955
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin = DarwinHardwareCollector()
    assert darwin.platform == 'Darwin'

# Generated at 2022-06-22 22:58:09.827305
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    def run_command_inner(args, **kwargs):
        return 0, 'brand_string: Intel(R) Core(TM) i7-2020QM CPU @ 2.00GHz\n' \
                  'L3 cache: 8MB\n' \
                  'logical cpu: 8\n' \
                  'physical cpu: 4\n' \
                  'core count: 4\n', ''

    # Test Intel CPU
    cpu_facts = DarwinHardware(dict(run_command=run_command_inner)).get_cpu_facts()
    assert cpu_facts == {'processor': 'Intel(R) Core(TM) i7-2020QM CPU @ 2.00GHz',
                         'processor_cores': '4',
                         'processor_vcpus': '8'}

    # Test PowerPC CPU

# Generated at 2022-06-22 22:58:11.115023
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    mac_facts = DarwinHardware()

# Generated at 2022-06-22 22:58:24.171854
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    # Create an instance of class DarwinHardware
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    # Create a "fake" dictionary for the sysctl function
    sysctl_dict = {'kern.osversion': '17.3.0',
                   'kern.osrevision': '1510.3.12'}

    # Return the "fake" dictionary when the function is called
    def sysctl(module, args):
        return sysctl_dict

    # Override the original function with our "fake" one
    hardware._sysctl = sysctl

    # Define the expected result for the test
    expected_result = {'model': 'MacBookPro9,1',
                       'osversion': '17.3.0',
                       'osrevision': '1510.3.12'}



# Generated at 2022-06-22 22:58:34.176711
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-22 22:58:41.947394
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from units.compat import mock
    module = mock.MagicMock()
    darwin = DarwinHardware(module)
    darwin.sysctl = {'hw.memsize': '1073741824'}
    darwin.module.run_command.return_value = (0, "", "")
    assert darwin.get_memory_facts()['memtotal_mb'] == 1024

# Generated at 2022-06-22 22:58:48.823598
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hostvars = {
        'ansible_facts': {
            'ansible_libvirt_version': '1.3.1',
        },
    }
    mac_facts = DarwinHardware(None, hostvars).get_mac_facts()
    assert isinstance(mac_facts, dict)
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts

# Generated at 2022-06-22 22:59:00.447350
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.get_bin_path = Mock(return_value='/usr/sbin/vm_stat')
    module.run_command = Mock(return_value=(0, "", ""))

    hardware = DarwinHardware(module)
    facts = hardware.populate()

    assert facts['model'] == 'MacBookPro14,1'
    assert facts['osversion'] == '19.2.0'
    assert facts['osrevision'] == '20C69'
    assert facts['processor'] == 'Intel(R) Core(TM) i5-7360U CPU @ 2.30GHz'
    assert facts['processor_vcpus'] == ''
    assert facts['processor_cores'] == 2
    assert facts['memtotal_mb'] > 0

# Generated at 2022-06-22 22:59:10.961031
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import os
    import tempfile


# Generated at 2022-06-22 22:59:22.272650
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts import Collector

    # Test with a mocked version of the sysctl command
    mocked_module = Collector()
    mocked_module.run_command = lambda x: (0, 'hw.model: x86_64', '')
    darwin_facts = DarwinHardware(mocked_module)

    # Test with a mocked version of the sysctl command and an invalid output
    mocked_module = Collector()
    mocked_module.run_command = lambda x: (0, 'hw.model:', '')
    mocked_darwin_facts = DarwinHardware(mocked_module)

    # Test with a mocked version of the sysctl command and a wrong return code
    mocked_module = Collector()
    mocked_module.run_command = lambda x: (1, '', '')
    mocked_darwin_facts = Darwin

# Generated at 2022-06-22 22:59:31.523381
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.collector import TestModule
    m = TestModule()
    h = DarwinHardware(m)
    h.sysctl = {
        'kern.osversion': '15.6.0', 'kern.osrev': '17',
        'hw.memsize': 2147483648, 'hw.memsize': '2147483648',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4960HQ CPU @ 2.60GHz',
        'machdep.cpu.core_count': 4
    }
    h.get_mac_facts = lambda: {}
    h.get_uptime_facts = lambda: {}

# Generated at 2022-06-22 22:59:41.824738
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    macfacts_file = 'sample-output/mac_facts.txt'
    module = FakeAnsibleModule(
        macfacts_file=macfacts_file,
    )
    hardware = DarwinHardware(module)
    hardware.populate()

# Generated at 2022-06-22 22:59:47.948693
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware(dict())
    assert hardware.get_dhcp_lease_time('en0') == -1
    assert hardware.get_dhcp_lease_time('en1') == -1
    assert hardware.get_interfaces() == {}
    assert hardware.get_route_to_address('10.0.0.1') == {}

# Generated at 2022-06-22 22:59:56.819668
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    darwin_hardware = DarwinHardware(module)


# Generated at 2022-06-22 23:00:07.354407
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import mock
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = (0, """hw.ncpu: 4
hw.activecpu: 4
hw.physicalcpu: 2
hw.physicalcpu_max: 2
hw.logicalcpu: 4
hw.logicalcpu_max: 4
hw.cputype: 7
hw.cpusubtype: 8
hw.cpufamily: 1485
hw.model: MacBookPro12,1
hw.machine: x86_64
hw.memsize: 17179869184""", '')

    hardware_instance = DarwinHardware(module_mock)

# Generated at 2022-06-22 23:00:19.173106
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # pylint: disable=protected-access
    mac_fact = DarwinHardware(None)
    # create a fake system_profiler with some values

# Generated at 2022-06-22 23:00:29.434538
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Test code.
    sample_out = b'{ sec = 1562295388, usec = 880409 }\n'
    mock_module = MockModule()
    hardware_info = DarwinHardware(mock_module)
    # Call the method.
    uptime_facts = hardware_info.get_uptime_facts()

    mock_module.run_command.assert_called_with(['/usr/sbin/sysctl', '-b', 'kern.boottime'], encoding=None)

    # Check results.
    assert uptime_facts == {'uptime_seconds': 1562295388}

    # Simulate a failure, i.e., sysctl returns 2 bytes only.
    mock_module.run_command.return_value = (0, sample_out[:2], "")

# Generated at 2022-06-22 23:00:34.502513
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = type('module', (object, ), {'run_command': lambda *args: "", 'get_bin_path': lambda *args: ""})
    hardware_instance = DarwinHardware(module)
    module.run_command = lambda *args: (0, "hw.memsize: 4294967296\n", "")
    module.get_bin_path = lambda *args: "/usr/sbin/vm_stat"
    # Run the method for testing
    result = hardware_instance.populate()
    assert result['memtotal_mb'] == 4
    assert result['memfree_mb'] == 4


# Generated at 2022-06-22 23:00:40.447591
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert "processor" in facts
    assert "processor_cores" in facts
    assert "memtotal_mb" in facts
    assert "memfree_mb" in facts
    assert "model" in facts
    assert "osversion" in facts
    assert "osrevision" in facts
    assert "uptime_seconds" in facts

# Generated at 2022-06-22 23:00:43.269423
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwinHw = DarwinHardware(None)
    assert darwinHw.platform == "Darwin"

# Generated at 2022-06-22 23:00:54.360489
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-22 23:01:06.309596
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import platform
    import unittest
    import ansible.module_utils

    class TestModule():
        def __init__(self, sysctl_dict, encoding):
            self.sysctl = sysctl_dict
            self.encoding = encoding

        def get_bin_path(self, name, preferred=False):
            if name == 'sysctl':
                return '/usr/sbin/sysctl'

        def run_command(self, cmd, encoding=None):
            return 0, struct.pack('@L', 64), ''

    class DummyModuleUtils(ansible.module_utils.basic.AnsibleModule):
        def __init__(self):
            self.run_command_environ_update = dict()
            self.run_command_supports_check_rc = False


# Generated at 2022-06-22 23:01:19.106725
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    fact_module = AnsibleModuleMock()
    fact_module.run_command = MagicMock(return_value=(0, '', ''))
    fact_module.run_command.return_value = (0, "machdep.cpu.brand_string:  Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz\n", "")
    darwin_hardware = DarwinHardware(fact_module)
    darwin_hardware.sysctl = {}
    darwin_hardware.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    darwin_hardware.sysctl['machdep.cpu.core_count'] = '4'


# Generated at 2022-06-22 23:01:29.876255
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts(): 
    import ctypes
    import sys
    import os

    class kernel_ctl_t(ctypes.Structure):
        _fields_ = [('ctl_id', ctypes.c_uint32),
                    ('ctl_name', ctypes.c_char * 31),
                    ('ctl_val', ctypes.c_int),
                    ('ctl_type', ctypes.c_int)]

    def sysctlbyname(name):
        ctl = kernel_ctl_t()
        ctl.ctl_name = name
        libc = ctypes.CDLL(None)
        size = ctypes.c_size_t(ctypes.sizeof(ctl))
        res = libc.sysctlbyname(name, ctypes.byref(ctl), ctypes.byref(size), None, 0)

# Generated at 2022-06-22 23:01:30.953198
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hardware = DarwinHardware(dict())
    assert darwin_hardware
    assert darwin_hardware.populate()

# Generated at 2022-06-22 23:01:42.731134
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import platform
    import datetime
    import time
    # Generate fake data
    os_version = 'Mac OS X 10.12.6 (16G29)'
    os_revision = 'Darwin Kernel Version 16.7.0'
    procesor = 'Intel Core i7'
    product_name = 'MacBookPro'
    processor_cores = '2'
    processor_vcpus = '4'
    memtotal_mb = 8192
    memfree_mb = 8192

    # Call the module
    test_class = DarwinHardware(None)

    # Use module method to populate the fake data.

# Generated at 2022-06-22 23:01:45.458454
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    my_obj = DarwinHardware(module)
    assert 'model' in my_obj.populate()


# Generated at 2022-06-22 23:01:57.312337
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    # Mock module and class
    m = type("AnsibleModule", (), dict(
        run_command=lambda self, cmd: (1, "", ""),
        get_bin_path=lambda self, cmd: cmd
    ))()
    h = DarwinHardware("", m)

    # Case 1: sysctl returns an invalid value
    if h.get_uptime_facts() != {}:
        raise Exception("Test 1 failed")

    # Case 2: sysctl returns a valid value
    m = type("AnsibleModule", (), dict(
        run_command=lambda self, cmd, encoding: (0, b'', ""),
        get_bin_path=lambda self, cmd: cmd
    ))()
    h = DarwinHardware("", m)

# Generated at 2022-06-22 23:02:09.582069
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware_obj_intel = DarwinHardware(dict(module=None))
    hardware_obj_powerpc = DarwinHardware(dict(module=None))
    hardware_obj_intel.sysctl = {
        'machdep.cpu.brand_string': 'Intel Xeon E3-1200 v3',
        'machdep.cpu.core_count': 4,
    }
    hardware_obj_powerpc.sysctl = {
        'hw.physicalcpu': 4,
    }
    hardware_obj_powerpc.get_system_profile = lambda: {
        'Processor Name': 'PowerPC 970 (2.2 GHz)',
        'Processor Speed': '2.2 GHz',
    }

# Generated at 2022-06-22 23:02:11.317708
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    h = DarwinHardware({})
    assert h.processor == 'Darwin'

# Generated at 2022-06-22 23:02:16.614695
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    result = DarwinHardwareCollector().collect(module, [])
    assert result['memory_mb']['real']['total'] > 0

# Generated at 2022-06-22 23:02:22.471947
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={},supports_check_mode=True)

    try:
        darwin_hardware = DarwinHardware(module=module)
        mem_facts = darwin_hardware.get_memory_facts()
    except Exception as e:
        module.fail_json(msg="Failed to get memory facts because '%s'" % str(e))

# Generated at 2022-06-22 23:02:33.649771
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.utils import mock_module_params

    # The current time is the reference from which to compute how long a system
    # has been running.
    import time
    now = time.time()

    # The kern.boottime value, in seconds and microseconds
    kern_boottime = now - 100

    # The output of sysctl
    sysctl_output = struct.pack('@L', kern_boottime)

    # The expected uptime_seconds value
    uptime_seconds = 100

    # Mock the module with a dummy method that returns sysctl_output
    module = mock_module_params()

# Generated at 2022-06-22 23:02:42.518518
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)
    module.run_command = FakeRunCommand(
        rc=0,
        out="""
      Mach Virtual Memory Statistics: (page size of 4096 bytes, cache hits 0%)
        free:                              65124.
        active:                            11434.
        inactive:                          10490.
        speculative:                        3542.
        throttled:                             0.
        wired down:                         8144.
        purgeable:                             0.
        file-backed:                        1997.
        empty:                             55333.
        used by compressor:                14178.
        occupied by compressor:             9347.
      """.lstrip()
    )
    facts = hardware.get_memory_facts()
    assert facts['memfree_mb'] == 61

# Generated at 2022-06-22 23:02:50.361968
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys

    # By default on Darwin, sys.getdefaultencoding() is 'utf-8', which fails
    # when decoding bytes from the "sysctl -b" command.
    # This is a problem for Python 2.6 because it does not set PYTHONIOENCODING.
    # Set it here to fix this issue.
    if sys.version_info[:2] == (2, 6):
        sys.setdefaultencoding('iso-8859-1')

    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    facts = hardware.get_uptime_facts()
    assert facts['uptime_seconds'] > 0

# Ansible module to run this module

# Generated at 2022-06-22 23:02:59.069511
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # test data
    osversion = '15.6.0'
    memtotal_in_bytes = 4294967296
    memtotal_in_kb = memtotal_in_bytes // 1024
    memtotal_in_mb = memtotal_in_kb // 1024
    # per page size
    memfree_in_kb = 1955072  # free = total - (active + inactive)
    memfree_in_mb = memfree_in_kb // 1024
    # per page size
    wired_down = 2555904
    active = 1052672
    inactive = 61440

    # create module object
    module = MockModule()
    # create object and mocks
    darwin_hardware = DarwinHardware(module)

    vm_stat_mock = MockVMStat()

# Generated at 2022-06-22 23:03:10.467119
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class FakeAnsibleModule(object):
        FAKE_SYSCTL_INTEL = dict()
        FAKE_SYSCTL_INTEL['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i7-3520M CPU @ 2.90GHz'
        FAKE_SYSCTL_INTEL['machdep.cpu.core_count'] = '2'
        FAKE_SYSCTL_INTEL['hw.logicalcpu'] = '4'

        FAKE_SYSCTL_PPC = dict()
        FAKE_SYSCTL_PPC['hw.physicalcpu'] = '2'
        FAKE_SYSCTL_PPC['hw.logicalcpu'] = '4'

        def __init__(self, **kargs):
            self.params

# Generated at 2022-06-22 23:03:18.723912
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = type('AnsModule', (object,), {'run_command': lambda self, cmd: (0, vm_stat_mock_output, None)})
    darwin_facts = DarwinHardware(module)
    memory_facts = darwin_facts.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 1748

# Mock output of command vm_stat

# Generated at 2022-06-22 23:03:29.237900
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    d = DarwinHardware()
    assert d.grains['os'] == 'Darwin'
    assert d.facts == dict(processor='', processor_cores='', processor_vcpus='', model='',
            memtotal_mb='', memfree_mb='', osversion='', osrevision='', uptime_seconds='')
    assert d.sysctl == {}
    assert d.get_system_profile() == {}
    assert d.get_mac_facts() == {}
    assert d.get_cpu_facts() == {}
    assert d.get_memory_facts() == {}
    assert d.get_uptime_facts() == {}

# Generated at 2022-06-22 23:03:39.213576
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    darwin_hardware = DarwinHardware(module)
    rc, out, err = module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    if rc != 0:
        return dict()
    system_profile = dict()
    for line in out.splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)
            system_profile[key.strip()] = ' '.join(value.strip().split())
    assert darwin_hardware.get_mac_facts() == system_profile


# Generated at 2022-06-22 23:03:40.546168
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj = DarwinHardwareCollector()
    assert obj.platform == 'Darwin'

# Generated at 2022-06-22 23:03:49.948739
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bin_paths = {
        'vm_stat': '/usr/bin/vm_stat',
    }

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    module = AnsibleModuleMock(bin_path=bin_paths)
    hinfo = DarwinHardware(module)
    rc, out, err = module.run_command(["/usr/bin/vm_stat"])
    assert hinfo.get_memory_facts()['memfree_mb'] == 755
