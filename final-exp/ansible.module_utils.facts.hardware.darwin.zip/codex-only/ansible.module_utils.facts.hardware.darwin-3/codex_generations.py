

# Generated at 2022-06-22 22:53:51.880476
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = DummyModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4750HQ CPU @ 2.00GHz'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == hardware.sysctl['machdep.cpu.brand_string']
    assert cpu_facts['processor_cores'] == 4

    module = DummyModule()
    hardware = DarwinHardware(module)
    system_profile = {'Processor Name': 'PowerPC G5', 'Processor Speed': '2.5 GHz'}
    hardware.get_system_profile = lambda: system_profile
    hardware.sysctl = {'hw.physicalcpu': 2}
    cpu_facts = hardware.get_

# Generated at 2022-06-22 22:54:04.908891
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    m1 = MockDarwinHardware({"system_profiler": [
        0,
        '',
        ''
    ]})
    assert m1.get_system_profile() == dict()


# Generated at 2022-06-22 22:54:14.471936
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Ansible get_system_profile method for DarwinHardware class can correctly parse system_profiler output
    and returns a dictionary with parsed data.
    """

# Generated at 2022-06-22 22:54:23.304847
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.mac import DarwinHardware
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict()
    )

    hardware_instance = DarwinHardware(module=module)
    hardware_instance.sysctl = {'hw.memsize': to_bytes('161061273600')}
    hardware_instance.distribution = DarwinDistribution(module=module)
    module.run_command = lambda cmd, encoding=None: (0, b"Mach Virtual Memory Statistics: (page size of 4096 bytes)\n", b'')


# Generated at 2022-06-22 22:54:32.773129
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=[0, 'test_return', ''])
    hw = DarwinHardware(module)
    assert hw.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}

    # When vm_stat is not installed
    module.run_command = MagicMock(return_value=['vm_stat not found', '', ''])
    hw = DarwinHardware(module)
    assert hw.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}


# Generated at 2022-06-22 22:54:34.384094
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    h = DarwinHardware(dict())
    assert h.platform == 'Darwin'

# Generated at 2022-06-22 22:54:43.600882
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mock_module = MockModule()

    # Mock the following methods from the mock_module

# Generated at 2022-06-22 22:54:55.833125
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """
    Tests Hardware.populate() method on Darwin
    """
    # setup a test module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # setup fake data
    module.run_command = lambda cmd: (0, '', '')
    module.run_command.__name__ = 'run_command'
    # normal run
    hardware = DarwinHardware(module)
    assert hardware.populate() == {'model': 'UUID', 'osversion': 'UUID', 'osrevision': 'UUID', 'memtotal_mb': 0, 'memfree_mb': 0, 'processor': 'UUID', 'processor_vcpus': '', 'processor_cores': 'UUID', 'uptime_seconds': 0}

    # Here are some real facts on

# Generated at 2022-06-22 22:54:59.009487
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector._platform == 'Darwin'
    assert DarwinHardwareCollector._fact_class == DarwinHardware

# Generated at 2022-06-22 22:55:05.713410
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector()

if __name__ == '__main__':
    import sys
    import unittest
    import doctest

    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite(sys.modules[__name__]))

    rc = unittest.TextTestRunner(verbosity=2).run(suite)
    if not rc.wasSuccessful():
        sys.exit(1)

# Generated at 2022-06-22 22:55:15.978947
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # The (invalid) value we are expecting to be parsed
    expected_seconds = 1234

    # Generate the test data: a dummy buffer containing the time in seconds
    # and in microseconds.
    test_data = struct.pack('@L', expected_seconds)

    # Generate a dummy module
    class dummy(object):
        class run_command(object):
            @staticmethod
            def __call__(cmd, encoding = None):
                return (0, test_data, '')
    module = dummy()

    # Instantiate the module and call get_uptime_facts()
    darwinhw = DarwinHardware()
    darwinhw.module = module
    results = darwinhw.get_uptime_facts()

    # Assert that the returned value is correct
    assert 'uptime_seconds' in results


# Generated at 2022-06-22 22:55:27.906196
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {
                        'hw.physicalcpu': 4,
                        'hw.logicalcpu': 8,
                        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4250U CPU'
                    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts == {
        'processor': 'Intel(R) Core(TM) i5-4250U CPU',
        'processor_cores': 4,
        'processor_vcpus': 8,
    }

# Generated at 2022-06-22 22:55:36.749656
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = Mock(return_value=(0, "", ""))
    module.PER_HOST_OVERRIDE_VARS = dict()
    module.params = dict()
    DarwinHardware.module = module
    DarwinHardware.platform = "Darwin"
    DarwinHardware.sysctl = Mock()
    DarwinHardware.get_mac_facts = Mock()
    DarwinHardware.get_cpu_facts = Mock()
    DarwinHardware.get_memory_facts = Mock()
    DarwinHardware.get_uptime_facts = Mock()
    obj = DarwinHardware()

# Generated at 2022-06-22 22:55:41.221891
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform
    import pytest

    mac = DarwinHardware()
    facts = mac.get_uptime_facts()

    assert type(facts) == dict
    assert facts['uptime_seconds'] > 0

# Run tests on host machine if not imported
if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-22 22:55:51.264207
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.base import Hardware
    module = type('EmptyModule', (object, ), {
        'get_bin_path': lambda *args, **kwargs: None,
        'run_command': lambda *args, **kwargs: (0, '', ''),
    })

    hardware_facts = DarwinHardware(module).populate()

    assert hardware_facts.get('model') is not None
    assert hardware_facts.get('product_name') is not None
    assert hardware_facts.get('osversion') is not None
    assert hardware_facts.get('osrevision') is not None
    assert hardware_facts.get('processor') is not None

# Generated at 2022-06-22 22:56:01.679557
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import ansible.module_utils.facts.system.darwin
    for cpu_type in ('Intel', 'PowerPC'):
        module = MagicMock()
        sysctl = {
            'machdep.cpu.brand_string': 'Intel CPU',
            'machdep.cpu.core_count': '1',
            'hw.physicalcpu': '2'
        }
        darwin_hardware = ansible.module_utils.facts.system.darwin.DarwinHardware(module)
        darwin_hardware.sysctl = sysctl
        system_profile = {
            'Processor Name': 'PowerPC CPU',
            'Processor Speed': '1000'
        }
        darwin_hardware.get_system_profile = MagicMock(return_value=system_profile)

# Generated at 2022-06-22 22:56:07.689927
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule():
        def run_command(self, cmd, encoding=None):
            if cmd[2] == 'kern.boottime':
                return (0, '1', '')
            elif cmd[2] == 'kern.boottime':
                return (0, '1', '')

        def get_bin_path(self, name):
            return 'sysctl'

    module = MockModule()
    fact_class = DarwinHardware(module)
    result = fact_class.get_uptime_facts()
    assert result['uptime_seconds'] == int(time.time() - 1)

# Generated at 2022-06-22 22:56:09.825176
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()
    for key in hardware.get_facts().keys():
        assert hardware.get_fact(key)

# Generated at 2022-06-22 22:56:18.906297
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_args = []
            # Map of command outputs for various mac versions

# Generated at 2022-06-22 22:56:29.400618
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # test case 1
    module = AnsibleModule(
        argument_spec=dict(),
    )
    hardware_facts = DarwinHardware(module)
    hardware_facts.get_system_profile = MagicMock(return_value=dict(
        ModelName='Macmini5,1',
        ProcessorName='Intel Core i7',
        ProcessorSpeed='2.8 GHz',
        NumberOfCores=4,
        Memory=8,
    ))
    hardware_facts.get_cpu_facts = MagicMock(return_value=dict(
        processor='Intel(R) Core(TM) i7-3615QM CPU @ 2.30GHz',
        processor_cores='4',
        processor_vcpus='4',
    ))

# Generated at 2022-06-22 22:56:38.063579
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    os.environ['PATH'] = '/usr/bin:/bin'
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-3720QM CPU @ 2.60GHz',
        'machdep.cpu.core_count': '4',
    }
    mac_facts = DarwinHardware(module, sysctl)
    assert mac_facts.get_cpu_facts() == {'processor': 'Intel(R) Core(TM) i7-3720QM CPU @ 2.60GHz', 'processor_cores': '4'}


# Generated at 2022-06-22 22:56:44.743435
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule:
        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, encoding):
            return (0, struct.pack('@L', 1388012746), None)

    harwdare = DarwinHardware(TestModule())

    assert harwdare.get_uptime_facts() == {
        'uptime_seconds': 1477878921 - 1388012746,
    }

# Generated at 2022-06-22 22:56:52.493282
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    import ansible.module_utils.facts.hardware.darwin
    import ansible.module_utils.facts.hardware.base

    mocker, module_mock = get_module_mock(params={})

    darwin_hw = ansible.module_utils.facts.hardware.darwin.DarwinHardware()


# Generated at 2022-06-22 22:57:04.474410
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes
    THIRTY_ONE_YEARS = 31 * 365 * 24 * 60 * 60

    def run_command_mock(cmd, encoding=None):
        # Mock that the sysctl module is available
        if 'sysctl' in cmd[0]:
            return 0, to_bytes('{0}'.format(THIRTY_ONE_YEARS)), ''
        # Mock that the vm_stat command is not available
        else:
            return 1, '', ''
    # Monkey patch
    DarwinHardware.module.run_command = run_command_mock

    # Test
    m = DarwinHardware(DarwinHardware.module)
    data = m.get_uptime_facts()

# Generated at 2022-06-22 22:57:06.213788
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    result = DarwinHardwareCollector()
    assert result.platform == 'Darwin'

# Generated at 2022-06-22 22:57:16.835414
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl

    module = AnsibleModule(argument_spec=dict())
    sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.run_command.assert_called_once_with(
            "/usr/sbin/system_profiler SPMemoryDataType")
    hardware = DarwinHardware(module)

    for fact in ["processor", "processor_cores", "memtotal_mb",
            "memfree_mb", "model", "osversion", "osrevision",
            "uptime_seconds"]:
        assert hardware.populate

# Generated at 2022-06-22 22:57:27.969627
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeModule(platform='Darwin')
    hw = DarwinHardware(module)
    hw.sysctl = {'hw.memsize': '1073741824'}  # 1GB
    hw.get_bin_path = lambda _: True
    current_free_memory = None

    def run_command(_):
        """
        This function is called by hw.get_memory_facts. Return a list
        with the output of the command we need to test. The test will
        check the result by comparing the value of free_memory with the
        expected value.
        """
        global current_free_memory
        if current_free_memory is None:
            return (0, 'Pages free:    144', '')

# Generated at 2022-06-22 22:57:30.699593
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """ Create object DarwinHardwareCollector and check if object is created
    """
    darwin_hw = DarwinHardwareCollector()
    assert darwin_hw.__class__.__name__ == 'DarwinHardwareCollector'

# Generated at 2022-06-22 22:57:34.620379
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Inject test attributes
    facts = DarwinHardware()
    facts.sysctl = {'hw.memsize': 0x10000000}

    # Run the test
    mem_facts = facts.get_memory_facts()

    # Test assertions
    assert 'memtotal_mb' in mem_facts
    assert mem_facts['memtotal_mb'] == 256

# Generated at 2022-06-22 22:57:44.155910
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware()


# Generated at 2022-06-22 22:57:46.426226
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert isinstance(collector, DarwinHardwareCollector)

# Generated at 2022-06-22 22:57:51.611897
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = DarwinHardware().module
    result = DarwinHardware().get_mac_facts(module)

    # Testing that the type of values of the dictionary are strings
    assert isinstance(result['osversion'], str)
    assert isinstance(result['osrevision'], str)
    assert isinstance(result['model'], str)

# Generated at 2022-06-22 22:58:01.557316
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    results = hardware.populate()
    assert 'uptime_seconds' in results
    assert results['uptime_seconds'] == 15
    assert 'memfree_mb' in results
    assert results['memfree_mb'] == 4095
    assert 'memtotal_mb' in results
    assert results['memtotal_mb'] == 8191
    assert 'processor_vcpus' in results
    assert results['processor_vcpus'] == '2'
    assert 'processor_cores' in results
    assert results['processor_cores'] == '2'
    assert 'processor' in results
    assert results['processor'] == 'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz'
    assert 'osrevision' in results


# Generated at 2022-06-22 22:58:06.695539
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    Constructor of class DarwinHardwareCollector
    """
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.__class__.__name__ == "DarwinHardwareCollector"



# Generated at 2022-06-22 22:58:15.768798
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class MockModule(object):
        def run_command(self, cmd):
            out = ['  Hardware:', '',
                   '    Hardware Overview:', '',
                   '      Model Name: Mac Pro', '',
                   '      Model Identifier: MacPro4,1', '',
                   '      Processor Name: Intel Xeon', '',
                   '      Processor Speed: 2.4 GHz', '',
                   '      Number of Processors: 2', '',
                   '      Total Number of Cores: 8', '',
                   '      L2 Cache (per Core): 256 KB', '',
                   '      L3 Cache: 8 MB', '',
                   '      Memory: 24 GB', '']
            return (0, '\n'.join(out), '')

    mac = DarwinHardware(module=MockModule())
    assert mac.get_system_profile

# Generated at 2022-06-22 22:58:18.789988
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    system_profile = DarwinHardware(module=None).get_system_profile()
    assert ('Hardware Overview' in system_profile)

# Generated at 2022-06-22 22:58:29.585896
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    '''Unit test for constructor of class DarwinHardware'''

    sysctl_mock_dict = {'machdep.cpu.core_count': '4', 'kern.osversion': '15.6.0', 'hw.memsize': '1073741824', 'hw.physicalcpu': '4', 'hw.ncpu': '4', 'kern.osrevision': '1456.20.1'}
    sysctl_mock_obj = get_sysctl_mock_obj(sysctl_mock_dict)
    my_obj = DarwinHardware(sysctl_mock_obj)
    my_obj.populate()
    assert my_obj.facts['processor'] == 'machdep.cpu.brand_string'
    assert my_obj.facts['processor_cores'] == 4
    assert my_obj

# Generated at 2022-06-22 22:58:31.519363
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    h = DarwinHardware()
    memory_facts = h.get_memory_facts()
    assert memory_facts is not None

# Generated at 2022-06-22 22:58:38.503165
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.hardware.darwin import DarwinHardware
    hw = DarwinHardware()
    hw.sysctl = {}
    cpu_facts = hw.get_cpu_facts()
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts
    assert 'processor' in cpu_facts


# Generated at 2022-06-22 22:58:49.879846
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module=module)

    facts = hardware.populate()
    assert facts['model'] == 'MacBookPro'
    assert facts['processor'] == 'Intel(R) Core(TM) i5-5350U CPU @ 1.80GHz'
    assert facts['processor_vcpus'] == '8'
    assert facts['processor_cores'] == '2'
    assert facts['memtotal_mb'] == 8389
    assert facts['memfree_mb'] == 5386
    assert facts['osversion'] == '17.5.0'
    assert facts['osrevision'] == '15F34'
    assert facts['uptime_seconds'] > 0



# Generated at 2022-06-22 22:59:00.945152
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware_facts = DarwinHardware(dict())
    hardware_facts.sysctl = {
        'hw.memsize': "4294967296"
    }

    vm_stat_command = get_bin_path('vm_stat')
    if vm_stat_command is None:
        return
    rc, out, err = run_command(vm_stat_command)
    if rc == 0:
        # Free = Total - (Wired + active + inactive)
        # Get a generator of tuples from the command output so we can later
        # turn it into a dictionary
        memory_stats = (line.rstrip('.').split(':', 1) for line in out.splitlines())

        # Strip extra left spaces from the value
        memory_stats = dict((k, v.lstrip()) for k, v in memory_stats)

       

# Generated at 2022-06-22 22:59:11.120393
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = {}
            self.run_command_calls = []
        def run_command(self, args, encoding=None):
            self.run_command_calls.append(args)
            return self.run_command_results[args]
    class MockFacts(object):
        __dict__ = {}
    module = MockModule()
    module.run_command_results = {('sysctl', 'hw.model'):(0, 'hw.model: Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz', '')}

# Generated at 2022-06-22 22:59:22.406488
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_fixtures

    darwinHardware = DarwinHardware()
    darwinHardware.sysctl = {
        'kern.osversion': '10.13.6',
        'kern.osrevision': '17G65',
    }
    darwinHardware.module = object()

    facts_dict = darwinHardware.get_mac_facts()
    assert facts_dict['model'] == 'MacPro5,1'
    assert facts_dict['osversion'] == '10.13.6'
    assert facts_dict['osrevision'] == '17G65'


# Generated at 2022-06-22 22:59:29.890004
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class ModuleStub:
        def run_command(self, args):
            return 0, "hw.model: Power Macintosh", ''

    hardware = DarwinHardware(ModuleStub())
    hardware.sysctl['kern.osversion'] = '1.0.0'
    hardware.sysctl['kern.osrevision'] = '1'

    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'Power'
    assert mac_facts['osversion'] == '1.0.0'
    assert mac_facts['osrevision'] == '1'



# Generated at 2022-06-22 22:59:35.541180
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Arrange
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = Mock(return_value=(0, '8', ''))

# Generated at 2022-06-22 22:59:38.035966
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert "Model Name:" in system_profile

# Generated at 2022-06-22 22:59:44.565566
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.platform import Platform
    from ansible.module_utils.facts.system.lsb import LSB
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBox
    from ansible.module_utils.facts.virtual.kvm import KVM
    from ansible.module_utils.facts.virtual.xen import Xen
    from ansible.module_utils.facts.virtual.parallels import Parallels
    from ansible.module_utils.facts.virtual.vmware import VMWare
    from ansible.module_utils.facts.virtual.hyperv import HyperV


# Generated at 2022-06-22 22:59:47.522603
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_collector = DarwinHardwareCollector()
    assert darwin_collector.platform == 'Darwin'
    assert darwin_collector._fact_class == DarwinHardware

# Generated at 2022-06-22 22:59:57.067920
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Create a sysctl mock object
    class sysctl_mock(object):
        def __init__(self):
            self.sysctl = {
                'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz',
                'machdep.cpu.core_count': '4',
                'hw.physicalcpu': '4',
                'hw.logicalcpu': '8',
            }
        def __getitem__(self, name):
            return self.sysctl[name]
    sysctl = sysctl_mock()

    # Create a module mock object
    class run_command_module_mock(object):
        def __init__(self):
            self.run_command_results = ["hw.model: Power Macintosh", 0, 0]

# Generated at 2022-06-22 22:59:59.023340
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_collector = DarwinHardwareCollector()
    assert darwin_collector.platform == 'Darwin'

# Generated at 2022-06-22 23:00:03.248111
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    hardware = DarwinHardware()
    hardware.sysctl = {'kern.boottime': 1479034592.34966}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1479034592)

# Generated at 2022-06-22 23:00:15.535255
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    def sysctl_mock(cmd, encoding=None):
        if cmd == [sysctl_cmd, "-b", "kern.boottime"]:
            return 0, struct.pack("@L", boottime), ""
        else:
            raise RuntimeError("Called with %s" % cmd)

    # Get an instance of our test class with a mocked module
    h = DarwinHardware({})
    h.module = MagicMock()
    h.module.get_bin_path = Mock(side_effect=get_bin_path)
    h.module.run_command = Mock(side_effect=sysctl_mock)

    # Assume we were booted at the same time as the epoch
    boottime = 0
    h.populate()
    assert h.uptime_seconds == 0

    # Assume we were booted a few seconds

# Generated at 2022-06-22 23:00:24.977042
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockModule()
    module.run_command = Mock(return_value=[0, 'hw.model: MacBookPro1,1', ''])
    sysctl = {'kern.osversion': '1', 'kern.osrevision': '2'}
    hw = DarwinHardware(module, sysctl)
    facts = hw.get_mac_facts()
    assert facts['model'] == 'MacBookPro1,1'
    assert facts['product_name'] == 'MacBookPro1,1'
    assert facts['osversion'] == '1'
    assert facts['osrevision'] == '2'



# Generated at 2022-06-22 23:00:36.932495
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

# Generated at 2022-06-22 23:00:38.025635
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector.name == 'hardware'

# Generated at 2022-06-22 23:00:44.953987
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Get a module_utils command object
    module = AnsibleModule(argument_spec=dict())

    # Create an object
    facts_obj = DarwinHardware(module=module)

    # Create a sysctl stub
    class SysctlStub(dict):
        def get(self, key, default=None):
            if key == 'machdep.cpu.brand_string':
                return 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
            if key == 'machdep.cpu.core_count':
                return 4
            return default

    # Reroute the sysctl command
    module.run_command = Mock(return_value=(0, '', ''))
    facts_obj.get_sysctl_output = Mock(return_value=SysctlStub())

    # Call the method

# Generated at 2022-06-22 23:00:52.755628
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, "hw.memsize: 8589934592", ""))

# Generated at 2022-06-22 23:01:05.227122
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class Module(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_results = []
            self.run_command_result_ind = 0

            self.sysctl = {}

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=True):
            self.run_command_calls.append(args)
            return self.run_command_results[self.run_command_result_ind]

        def set_command_result(self, result_list):
            self.run_command_results.append(result_list)

    module = Module()
    module.set_command_result((0, "hw.model: iMac13,1\n", ""))
   

# Generated at 2022-06-22 23:01:17.963725
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware import Hardware
    import mock
    import struct

    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)

    # In the test environment time.time() will return
    # a value different from kern.boottime. But we don't care
    # because the goal of the test is to check that the
    # method call and output decoding works.
    kern_boottime = int(time.time()) - 60
    up_seconds = int(time.time()) - kern_boottime

    # Format the output correctly


# Generated at 2022-06-22 23:01:26.172698
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = type('AnsibleModule', (object,), {'run_command': run_command_mock})
    hardware = DarwinHardware(module=module)
    system_profile_mock = {
        'Model Identifier': 'MacBookPro10,2',
        'Boot ROM Version': 'MBP102.00EE.B00',
        'SMC Version (system)': '2.2f44',
        'Serial Number (system)': 'C02J18YSDV7S',
        'Hardware UUID': '3F8F3C4F-4F4D-59A1-8D4E-5CDA6DCB2B49'
    }


# Generated at 2022-06-22 23:01:29.934622
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    harness = DarwinHardware(module)

    assert harness.platform == "Darwin"
    assert not harness.sysctl



# Generated at 2022-06-22 23:01:41.351812
# Unit test for method populate of class DarwinHardware

# Generated at 2022-06-22 23:01:47.992028
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    """ test constructor of class DarwinHardware """
    mod = 'ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin.DarwinHardware'
    module = AnsibleModule(argument_spec={})
    dh = DarwinHardware(module)
    assert dh.__class__.__name__ == 'DarwinHardware'
    assert dh.__class__.__module__ == mod
    assert dh.platform == 'Darwin'


# Generated at 2022-06-22 23:01:58.060845
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import time

    m = Mock()
    m.module_utils.common.process.get_bin_path.return_value = None
    m.ansible_facts = {}
    m.run_command.return_value = (0, '', '')
    m.get_bin_path.return_value = None
    m.get_file_content.return_value = None
    time.time.return_value = 1234567890


# Generated at 2022-06-22 23:02:00.039023
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    dh = DarwinHardware({'module': None})
    assert dh.platform == 'Darwin'

# Generated at 2022-06-22 23:02:05.555334
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware = DarwinHardware(dict())
    result = hardware.get_mac_facts()
    assert result.__class__ is dict
    assert len(result) in [2, 3]
    assert 'model' in result
    assert 'osversion' in result
    assert 'osrevision' in result


# Generated at 2022-06-22 23:02:14.334838
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule:
        def get_bin_path(self, command):
            return "fake " + command
        def run_command(self, cmd, encoding=None):
            return 0, b'syctld: unknown oid \'kern.boottime\'', b''

    module = MockModule()
    harware = DarwinHardware()
    harware.module = module
    facts = harware.get_uptime_facts()
    assert not facts

    # Test with incorrect data
    module.run_command = lambda cmd, encoding=None: (0, b'foobar', b'')
    facts = harware.get_uptime_facts()
    assert not facts

    # Test with empty data
    module.run_command = lambda cmd, encoding=None: (0, b'', b'')
    facts = harware.get_

# Generated at 2022-06-22 23:02:19.538391
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    hardware = DarwinHardware()

    sysctl_cmd = hardware.module.get_bin_path('sysctl')

    class MockOsMock(object):
        def __init__(self):
            self.environ = dict()
            self.default_encoding = 'utf-8'

    class MockCmdMock(object):
        def __init__(self, enc="utf-8"):
            self.encoding = enc
            self.stdin = None
            self.stdout = None
            self.stderr = None
            self.close_fds = False
            self.shell = False
            self.cwd = None
            self.timeout = None
            self.module = None
            self.binary = sysctl_cmd
            self.args = []
            self.run()


# Generated at 2022-06-22 23:02:28.088035
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts import ansible_facts

   # Set up context mock
    class Context:
        def __init__(self):
            self.module = ModuleStub()

    class ModuleStub:
        def __init__(self):
            self.run_command_results = []

        def run_command(self, command):
            if command[0] == "/usr/sbin/system_profiler":
                self.run_command_results.append((0, "Serial Number (system): C01C8ST3ZBP5\nHardware UUID: 3767D8C3-3D11-5EEC-B8D7-8ECB2F58F207\nSMC Version (system): 2.28f7\n", ""))
                return self.run_command_results.pop()
           

# Generated at 2022-06-22 23:02:33.996002
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = DarwinHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    assert hardware
    assert hardware.model == 'MacPro5,1'
    assert hardware.processor == 'Intel(R) Core(TM) i7-3770K CPU @ 3.50GHz'

# Generated at 2022-06-22 23:02:44.929644
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl

# Generated at 2022-06-22 23:02:54.326544
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import mock
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    process = mock.MagicMock()
    process.run_command = mock.MagicMock(
        return_value=(0, 'kern.boottime = (1583075763, 71438)\n', '')
    )
    module = mock.MagicMock()
    module.run_command = process.run_command
    darwin = DarwinHardware(module)

    uptime_facts = darwin.get_uptime_facts()
    assert(uptime_facts['uptime_seconds'] == 1583075763)
    process.run_command.assert_called_once_with(
        ['/usr/sbin/sysctl', '-b', 'kern.boottime'],
        encoding=None
    )

# Generated at 2022-06-22 23:03:02.707259
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = Mock()

# Generated at 2022-06-22 23:03:15.308318
# Unit test for method populate of class DarwinHardware

# Generated at 2022-06-22 23:03:23.450961
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    mac_facts = {'osversion': '15.6.0', 'osrevision': '19G73'}
    hardware_facts = {
        'processor': 'Intel(R) Core(TM) i5-6600K CPU @ 3.50GHz',
        'processor_cores': 4,
        'processor_vcpus': None
    }
    hardware_facts.update(mac_facts)
    darwin_hardware = DarwinHardware(dict(), dict())

# Generated at 2022-06-22 23:03:31.839334
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = MagicMock()
    module.run_command.return_value = (0, '\x7f\x00\x00\x00\x00\x00\x00\x00', None)
    hardware = DarwinHardware(module)
    hardware.module = module

    uptime_facts = hardware.get_uptime_facts()

    module.run_command.assert_called_with(['/sbin/sysctl', '-b', 'kern.boottime'], encoding=None)
    assert uptime_facts == {'uptime_seconds': 175472166}

# Generated at 2022-06-22 23:03:41.950571
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'hw.model: Intel\nhw.model: Intel\nhw.physicalcpu: 4\nhw.logicalcpu: 4\nhw.memsize: 16384\nkern.osversion: 15.0.0\nkern.osrevision: 15.0.0', '')
    darwin_hardware = DarwinHardware(module)
    expected = dict([('osversion', '15.0.0'), ('osrevision', '15.0.0'), ('processor', 'Intel'), ('model', 'Intel'), ('processor_cores', 4), ('processor_vcpus', '4'), ('memtotal_mb', 16383), ('memfree_mb', 16383), ('uptime_seconds', None)])
    result = d

# Generated at 2022-06-22 23:03:51.106705
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    module = None
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Iris(TM) Graphics 6100'}
    processor = hardware.get_cpu_facts()
    assert processor == {'processor': 'Intel(R) Iris(TM) Graphics 6100', 'processor_cores': '', 'processor_vcpus': ''}