

# Generated at 2022-06-22 22:53:46.413693
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x.get_platform() == 'Darwin'

# Generated at 2022-06-22 22:53:56.622740
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware_obj = DarwinHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl.get('hw.model', 'unknown') == 'MacBookPro10,1'
    assert hardware_obj.sysctl.get('machdep.cpu.brand_string', 'unknown') == 'Intel(R) Core(TM) i7-3740QM CPU @ 2.70GHz'
    assert hardware_obj.sysctl.get('machdep.cpu.core_count', 0) == 4
    assert hardware_obj.sysctl.get('hw.memsize', 0) == 8589934592
    assert hardware_obj.sysctl.get('hw.physicalcpu', 0) == 2
    assert hardware_obj.sysctl.get

# Generated at 2022-06-22 22:54:07.082663
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    cmd_output = b'kern.boottime: { sec = 1564853164, usec = 759042 }\n'

    def mock_run_command(cmd, encoding):
        assert cmd == [sysctl_cmd, '-b', 'kern.boottime']
        assert encoding is None
        return (0, cmd_output, b'')

    sysctl_cmd = '/usr/sbin/sysctl'
    expected_output = {
        'uptime_seconds': 1564853164
    }

    hardware = DarwinHardware()
    hardware.run_command = mock_run_command

    assert hardware.get_uptime_facts() == expected_output

# Generated at 2022-06-22 22:54:18.731357
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    '''Test on method get_mac_facts'''
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    hw = DarwinHardware(module)

    # Test on x86_64 Intel
    hw.sysctl = {
        'kern.osversion': '16.4.0',
        'kern.osrevision': '16E195',
        'hw.model': 'MacBookPro13,3',
    }

    expected = {
        'osversion': '16.4.0',
        'osrevision': '16E195',
        'model': 'MacBookPro13,3',
    }
    assert hw.get_mac_facts() == expected


# Generated at 2022-06-22 22:54:23.897602
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware = DarwinHardware(module=module)
    hardware.populate()
    # This is a basic test just to make sure we got data without
    # raising an Exception. Let's not test for exact values because
    # we have no way to know in advance and it would be brittle.
    assert hardware.facts

# Generated at 2022-06-22 22:54:30.329535
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = None
    hw = DarwinHardware(module=module)
    # You should set a real MAC address in your test.
    hw.sysctl = dict(hw=dict(model="MacBook5,2"))
    expected = {"model": "MacBook5,2", "osversion": "14.4.0", "osrevision": "15E65"}
    assert hw.get_mac_facts() == expected


# Generated at 2022-06-22 22:54:39.481986
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '16G29'}
    rc, out, err = module.run_command(["sysctl", "hw.model"])

    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,5'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '16G29'


# Generated at 2022-06-22 22:54:50.867272
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    '''
    Test DarwinHardware.get_mac_facts() using a mock module.
    '''
    from mock import Mock
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import sysctl_dict

    module = Mock()
    module.run_command.return_value = (0, 'hw.memsize: 2147483648', '')
    module.params = dict()

    hardware = DarwinHardware(module, sysctl_dict)
    facts = hardware.get_mac_facts()

    assert facts['osversion'] is not None
    assert facts['osrevision'] is not None


# Generated at 2022-06-22 22:54:54.645569
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    assert hardware.get_memory_facts() == {'memfree_mb': 0, 'memtotal_mb': 0}
    assert hardware.get_cpu_facts() == {'processor_cores': 0, 'processor': '', 'processor_vcpus': 0}
    assert hardware.get_uptime_facts() == {'uptime_seconds': 0}
    assert hardware.get_mac_facts() == {'model': '', 'osversion': '', 'osrevision': ''}

# Generated at 2022-06-22 22:55:07.332207
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, 'hw.model: MacBookPro11,3', '')
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    result = hardware.get_mac_facts()
    assert result == {'osversion': '16.7.0', 'osrevision': '15.6.0', 'model': 'MacBookPro11,3'}


# Entirely taken from Ansbile test_module_utils_facts_system.py


# Generated at 2022-06-22 22:55:17.000653
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())

    # Test Intel Mac
    mock_sysctl = {
        'hw.memsize': '1073741824',
        'hw.physicalcpu': '4',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz',
        'machdep.cpu.core_count': '4'
    }
    DarwinHardware.sysctl = mock_sysctl
    cpu_facts = DarwinHardware(module).get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz'
    assert cpu_facts['processor_cores'] == '4'

# Generated at 2022-06-22 22:55:28.405412
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class TestModule(object):
        def __init__(self, sysctl):
            self.sysctl = sysctl

        def run_command(self, command):
            pass

    class TestSysctl(object):
        def __init__(self, data):
            self.data = data

        def __getitem__(self, item):
            return self.data[item]

    # test with Intel CPU

# Generated at 2022-06-22 22:55:37.013474
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = get_module_mock()

    # test Intel (macOS 10.12+)
    hardware_obj = DarwinHardware(module)
    hardware_obj.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i7-6920HQ CPU @ 2.90GHz'
    hardware_obj.sysctl['machdep.cpu.core_count'] = 4
    system_profile = {'Processor Name': 'PowerPC G5', 'Processor Speed': '9 GHz'}
    hardware_obj.get_system_profile = lambda: system_profile

    cpu_facts = hardware_obj.get_cpu_facts()

# Generated at 2022-06-22 22:55:44.036253
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    # Mock output of vm_stat command, which is parsed in get_memory_facts
    module.run_command = Mock(return_value=(0, """
Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                       16358.
Pages active:                     269599.
Pages inactive:                   984136.
Pages speculative:                106800.
Pages throttled:                  0.
Pages wired down:                 244444.
""", ""))

    # Expected results
    memtotal_mb = 4 * 1024 * 1024 * 1024 // 1024 // 1024
    memfree_mb = (16358 + 106800) * 4096 // 1024 // 1024

    hardware_facts = hardware.get_memory_facts()

# Generated at 2022-06-22 22:55:55.107463
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = dict(
        hw_model='MacBookAir',
        hw_memsize='100',
        hw_physicalcpu='1',
        hw_logicalcpu='40',
        machdep_cpu_brand_string='Intel',
        machdep_cpu_core_count='2',
        kern_osversion='10.1.1',
        kern_osrevision='1',
        kern_boottime='10',
    )
    cmd_result = dict(
        rc=0,
        out='Pages free:                              10.\n',
        err='',
    )
    module.run_command.return_value = cmd_result
    result = hardware.populate()

# Generated at 2022-06-22 22:56:02.716560
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_module = type('', (), {})()
    test_module.run_command = lambda x: (0, '', '')
    test_module.get_bin_path = lambda x: ''

    darwin_facts = DarwinHardware(test_module)
    darwin_facts.sysctl = { 'machdep.cpu.brand_string': 'Intel Xeon' }
    darwin_facts.get_cpu_facts() == { 'processor': 'Intel Xeon', 'processor_cores': '0', 'processor_vcpus': '' }

# Generated at 2022-06-22 22:56:09.477612
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class FakeModule:
        def __init__(self, run_command_output):
            self.run_command_output = run_command_output


# Generated at 2022-06-22 22:56:18.741858
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from io import BytesIO
    from ansible.module_utils.six import PY2

    # Prepare structures to mock sysctl call
    # (This is what a sysctl call for kern.boottime returns on Darwin)
    # A mock RunCommand class, with input and output mocked
    class RunCommandMock(object):
        def __init__(self):
            # kern.boottime returns seconds and microseconds as two 64-bits
            # fields.
            struct_format = '@L'
            struct_size = struct.calcsize(struct_format)
            the_time = time.time()
            the_btime = int(the_time)
            the_bytes = struct.pack(struct_format, the_btime)
            self.out = BytesIO(the_bytes)


# Generated at 2022-06-22 22:56:29.328240
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-22 22:56:33.806472
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec=dict())
    hardware_collector = DarwinHardwareCollector(module=module)
    hardware = DarwinHardware(module)
    result = hardware.get_system_profile()

    module.exit_json(changed=False, ansible_facts=dict(result=result))



# Generated at 2022-06-22 22:56:44.699475
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class ModuleMock(object):
        def __init__(self, return_value):
            self.return_value = return_value

        def run_command(self, args):
            return (0, '', '')

    # Test that missing sysctl value is not fatal
    module_mock = ModuleMock(None)
    mac_facts = DarwinHardware(module_mock).get_mac_facts()
    assert mac_facts.get('model') is None
    assert mac_facts.get('osversion') is None
    assert mac_facts.get('osrevision') is None

    # Test non-empty values
    module_mock.return_value = {
        'kern.osversion': '16.4.0',
        'kern.osrevision': '15R566',
    }
    mac_

# Generated at 2022-06-22 22:56:52.162066
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # First, create a object instance of DarwinHardware
    test_module = AnsibleModule(argument_spec={})
    test_hardware = DarwinHardware(module=test_module)

    # Dictionary of expected return values
    expected_cpu_fact_result = {
        'processor': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz',
        'processor_cores': 2,
        'processor_vcpus': 4
    }

    # Call the get_cpu_facts() method of class DarwinHardware
    actual_cpu_fact_result = test_hardware.get_cpu_facts()

    # Compare the actual result with the expected result
    assert actual_cpu_fact_result == expected_cpu_fact_result


# Generated at 2022-06-22 22:56:57.822969
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    test_obj = DarwinHardware()

    # Create a class to mock the run_command() method of the DarwinHardware class.
    # This mock method will return a tuple with (0, out, err), where 'out' is the
    # output and 'err' is the errput of the mocked command, in this case it will be
    # the output of the real 'vm_stat' command.
    class MockRunCommand:
        def __init__(self, fake_commands):
            self.real_commands = {}
            self.real_commands['vm_stat'] = get_bin_path('vm_stat')
            self.fake_commands = fake_commands


# Generated at 2022-06-22 22:57:09.908037
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = fake_module()
    dhw = DarwinHardware(module)
    dhw.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz',
        'machdep.cpu.core_count': 2,
        'hw.model': 'MacBookPro11,1',
        'hw.memsize': 17179869184,
        'hw.ncpu': 2,
        'kern.osversion': '14.3.0',
        'kern.osrevision': '15.3.0',
    }

# Generated at 2022-06-22 22:57:19.346311
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-22 22:57:26.850551
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    hardware_collector = DarwinHardwareCollector(module=module)
    facts = hardware_collector.collect()['ansible_facts']

    assert facts['processor']
    assert facts['processor_cores']
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['model']
    assert facts['osversion']
    assert facts['osrevision']
    assert facts['uptime_seconds']



# Generated at 2022-06-22 22:57:29.444761
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector._fact_class is DarwinHardware

# Generated at 2022-06-22 22:57:37.713489
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """
    Test the method get_cpu_facts of class DarwinHardware
    """
    sysctl_response = {
        'hw.model': "Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz",
        'hw.ncpu': "8",
        'hw.physicalcpu': "4",
        'machdep.cpu.core_count': "4"
        }

    cpu_facts_expected_result = {
        'processor': "Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz",
        'processor_cores': "4",
        'processor_vcpus': "8"
        }

    module = FakeAnsibleModule()
    module.run_command.return_value = (0, "", "")
    module.params = {}

   

# Generated at 2022-06-22 22:57:45.057851
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = type('AnsibleModule', (object,), dict(run_command=lambda x: (0, 'Pages free: 1690.\nPages wired down: 6420.\nPages active: 9828.\nPages inactive: 6261.\nPages speculative: 498.\nPages wired down: 6420.\n', '')))
    fake_sysctl = type('SysCtl', (object,), dict(machdep_cpu_core_count='8', hw_memsize='42'))
    hw = DarwinHardware(fake_sysctl, module)
    assert hw.get_memory_facts() == { 'memtotal_mb': 42, 'memfree_mb': 10 }

# Generated at 2022-06-22 22:57:54.765101
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = get_module_mock({})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.model': 'MacBookAir6,2',
        'kern.osversion': '15.6.0',
        'kern.osrevision': '16G1036',
    }
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookAir6,2'
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '16G1036'


# Generated at 2022-06-22 22:58:01.435887
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
  facts = {
      '_ansible_system': 'Darwin',
      'hw': {
          'memsize': '2097152',
          'physicalcpu': '1',
          'memsize': '1572864'
      },
      'kern': {
          'osversion': '15.4.0',
          'osrevision': '15E65',
      }
  }

  # Create the object
  dh = DarwinHardware(module=None, facts=facts)
  assert dh.facts['osversion'] == '15.4.0'

# Generated at 2022-06-22 22:58:13.288281
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict(filter=dict(default='*', aliases=['name', 'pattern', 'search'])))

    # For testing, mock the sysctl method to return canned values
    darwinhw = DarwinHardware(module)
    old_sysctl_method = darwinhw.sysctl
    darwinhw.sysctl = lambda: dict()
    darwinhw.sysctl['kern.osversion'] = '15.4.0'
    darwinhw.sysctl['kern.osrevision'] = '16E195'
    darwinhw.get_mac_facts()

    module.exit_json(ansible_facts={'hardware': darwinhw.get_facts()})

    # Restore the sysctl method
    darwinhw.sysctl = old_sysctl

# Generated at 2022-06-22 22:58:19.558989
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    uptime_facts = DarwinHardware().get_uptime_facts()
    uptime_seconds = int(time.time() - uptime_facts['uptime_seconds'])

    assert(uptime_seconds > 0)

# Generated at 2022-06-22 22:58:28.169077
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # import module_utils.facts.hardware.darwin
    # raw_struct = b'\x000\x00\x00\x00\x00\x00\x00\x00'
    # unpack_format = '@L'
    # struct_size = struct.calcsize(unpack_format)
    # (kern_boottime, ) = struct.unpack(unpack_format, raw_struct[:struct_size])
    # print(kern_boottime)
    # current_time = time.time()
    # print(current_time)
    # print(current_time - kern_boottime)
    pass

# Generated at 2022-06-22 22:58:34.428169
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_HardwareCollector = DarwinHardwareCollector()
    assert darwin_HardwareCollector._fact_class == DarwinHardware
    darwin_HardwareCollector._fact_class = "Changed"
    assert darwin_HardwareCollector._fact_class != DarwinHardware
    assert darwin_HardwareCollector._platform == "Darwin"
    darwin_HardwareCollector._platform = "Changed"
    assert darwin_HardwareCollector._platform != "Darwin"


# Generated at 2022-06-22 22:58:47.567316
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule(object):
        def __init__(self, out, time=None):
            self.out = out
            self.time = time
            self.run_command_results = []

        def get_bin_path(self, name, *args, **kwargs):
            return ':/usr/bin/%s' % name

        def run_command(self, cmd, encoding=None):
            if cmd[-1] == 'time':
                return 0, time.strftime('%H:%M:%S', time.localtime(self.time)), ''
            elif cmd[-1] == 'uptime':
                return 0, self.out, ''
            self.run_command_results.append((cmd, encoding))
            return 0, '', ''


# Generated at 2022-06-22 22:58:59.306225
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def run_command(self, cmd, check_rc=True, encoding=None, data=None, binary_data=False):
            if cmd == [sysctl_cmd, '-b', 'kern.boottime']:
                struct_format = '@L'
                struct_size = struct.calcsize(struct_format)
                # kern.boottime returns seconds and microseconds as two 64-bits
                # fields, but we are only interested in the first field.
                out = b'\x00\x00\x00\x00' + b'\x00\x00\x00\x00'


# Generated at 2022-06-22 22:59:05.555840
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test = DarwinHardware(dict())
    test.sysctl = {'hw.model': 'MacPro5,1', 'hw.ncpu': '8', 'hw.logicalcpu': '16'}
    #  This is what the result should look like
    facts = {'processor': 'Intel(R) Xeon(R) CPU           E5520  @ 2.27GHz', 'processor_cores': '8', 'processor_vcpus': '16'}
    cpu_facts = test.get_cpu_facts()
    for fact in facts.keys():
        assert cpu_facts[fact] == facts[fact]



# Generated at 2022-06-22 22:59:14.723508
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    m = module.params
    dh = DarwinHardware(module)
    facts = dh.populate()
    assert (facts['processor_cores'] >= 1) or (facts['processor_cores'] == 'unknown')
    assert (facts['memtotal_mb'] >= 1) or (facts['memtotal_mb'] == 'unknown')
    assert (facts['memfree_mb'] >= 1) or (facts['memfree_mb'] == 'unknown')
    assert facts['osversion'] != ''
    assert facts['osrevision'] != ''

# Generated at 2022-06-22 22:59:17.062660
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hw = DarwinHardware({'module': None})
    assert darwin_hw.platform == 'Darwin'
    assert darwin_hw.sysctl == {}

# Generated at 2022-06-22 22:59:26.661451
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
  darwinHardware = DarwinHardware()
  system_profile = darwinHardware.get_system_profile()
  assert 'Hardware Overview' in system_profile
  assert 'Model Name' in system_profile
  assert system_profile['Model Name'] == 'MacBook Pro'
  assert system_profile['Model Identifier'] == 'MacBookPro14,3'
  assert system_profile['Number of Processors'] == '1'
  assert system_profile['Processor Name'] == 'Intel Core i7'
  assert system_profile['Processor Speed'] == '2.9 GHz'
  assert system_profile['Memory'] == '16 GB'
  assert system_profile['MAC Address'] == 'e0:ac:cb:91:39:e2'

# Generated at 2022-06-22 22:59:33.849255
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import os
    import sys
    import unittest
    import mock

    test_module = os.path.join(os.path.dirname(__file__), 'module_utils', 'basic.py')
    sys.modules['ansible.module_utils.basic'] = __import__('ansible.module_utils.basic', globals(), locals(), ['basic'], -1)
    sys.modules['ansible.module_utils.basic'].AnsibleModule = mock.Mock()
    sys.modules['ansible.module_utils.basic'].get_platform = mock.Mock()
    sys.modules['ansible.module_utils.basic'].platform.system = mock.Mock(return_value='Darwin')

# Generated at 2022-06-22 22:59:45.228923
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.compat.test import mock
    from ansible.module_utils.six import iteritems

    dm = mock.Mock()
    dm.run_command.side_effect = [
        (0,  # rc
         "hw.model: x86_64",  # out
         ""),  # err
        (0,  # rc
         "machdep.cpu.brand_string: Genuine Intel(R) CPU            @ 2.40GHz",  # out
         ""),  # err
        (0,  # rc
         "machdep.cpu.core_count: 4",  # out
         ""),  # err
    ]

    dm.get_bin_path.return_value = 'system_profiler'

# Generated at 2022-06-22 22:59:55.372530
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    '''
    Test get_cpu_facts of class DarwinHardware.
    Test with sysctl.out containing data for both PowerPC and Intel CPUs.
    Test fixture is a list of lines of data which contains both
    PowerPC and Intel CPU data.
    '''
    # Set up a module for testing purposes
    module = {}
    module['run_command'] = run_command_mock
    module['get_bin_path'] = get_bin_path_mock
    module['get_platform'] = get_platform_mock
    module['get_distribution'] = get_distribution_mock

    # Set up arguments for testing purposes
    args = {}
    args['module'] = module

    # Call the method under test
    test_obj = DarwinHardware(**args)
    cpu_facts = test_obj.get_cpu_facts

# Generated at 2022-06-22 22:59:59.180063
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = MockModule()
    darwinhw = DarwinHardware(module)
    mac_model = darwinhw.get_system_profile()['Model Name']
    assert mac_model == "MacBookPro"


# Generated at 2022-06-22 23:00:09.828772
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-22 23:00:20.735047
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class test_module:
        def run_command(self, cmd, encoding=None):
            if cmd == ['/usr/sbin/system_profiler', 'SPHardwareDataType']:
                return 0, "Machine Name: Macmini\nProcessor Name: i7\nProcessor Speed: 3.2\n", ""
            if cmd == ["/usr/bin/sysctl", "-n", "kern.osversion"]:
                return 0, "Darwin version 15.0.0\n", ""
            if cmd == ["/usr/bin/sysctl", "-n", "kern.osrevision"]:
                return 0, "Darwin version 15.0.0\n", ""

# Generated at 2022-06-22 23:00:26.956351
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class MockHelper:
        def __init__(self, command_status=0, command_output=2):
            self.command_status = command_status
            self.command_output = command_output

        def run_command(self, command):
            return self.command_status, self.command_output, ''


# Generated at 2022-06-22 23:00:38.813492
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = type(sys)('test_get_system_profile')

# Generated at 2022-06-22 23:00:39.501000
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    assert DarwinHardware


# Generated at 2022-06-22 23:00:52.474152
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import pytest

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    test_cases = [
        {
            'kern_boottime': 1234,
            'expected_uptime': int(time.time()) - 1234,
        },
        {
            'kern_boottime': 0,
            'expected_uptime': int(time.time()) - 0,
        },
    ]

    sys.modules['ansible'] = MockAnsibleModule()
    hardware = DarwinHardware()
    hardware.module.run_command = MockRunCommand()
    hardware.module.get_bin_path = MockGetBinPath()
    hardware.module.run_command.return_value = (0, '', '')


# Generated at 2022-06-22 23:00:59.774328
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-22 23:01:11.802256
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.errors import AnsibleError
    mock_module = MockModule()
    mock_module.run_command.side_effect = [
        (0, 'Mach Virtual Memory Statistics: (page size of 4096 bytes)\nPages free:                        151477.\nPages active:                      322.\nPages inactive:                    298.\nPages wired down:                  899.\nPages purgeable:                   0.\n', '')
    ]

    try:
        darwin_hardware = DarwinHardware(mock_module)
    except AnsibleError:
        # Calling this function under OSs other than Darwin will result in
        # an AnsibleError exception.
        pass

    memory_facts = darwin_hardware.get_memory_facts()

# Generated at 2022-06-22 23:01:23.179476
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import io
    import sys
    from ansible.module_utils.facts import dict_to_facts
    from ansible.module_utils.six import PY2

    hardware_facts = dict()
    hardware_facts['uptime_seconds'] = int(time.time())

    if PY2:
        out = io.BytesIO(b'test:\n\ttest1\ntest2:\ntest3')
    else:
        out = io.StringIO('test:\n\ttest1\ntest2:\ntest3')

    class MockModule(object):
        def __init__(self):
            self.run_command_results = [(0, out.getvalue(), '')]
            self.run_command_calls = []

        def run_command(self, cmd, encoding=None):
            self.run_command

# Generated at 2022-06-22 23:01:27.595091
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    darwin_hardware = DarwinHardware(module)
    result = darwin_hardware.get_memory_facts()
    assert result['memtotal_mb'] > 0



# Generated at 2022-06-22 23:01:37.709819
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeModule({
        'hw.model': 'MacBookPro10,1',
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 8,
        'hw.ncpu': 2,
        'kern.osversion': '16.0.0',
        'kern.osrevision': '0.0.0',
    })
    darwin = DarwinHardware(module)
    cpu_facts = darwin.get_cpu_facts()
    assert cpu_facts == {
        'processor': 'Intel Core i7 @ 2.8 GHz',
        'processor_cores': 4,
        'processor_vcpus': 8,
    }

# Generated at 2022-06-22 23:01:46.570090
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict())
    sysctl_cmd = module.get_bin_path('sysctl')
    module.run_command = Mock(return_value=(0, struct.pack('@L', 42), None))
    hardware = DarwinHardware(module)

    result = hardware.get_uptime_facts()

    module.run_command.assert_called_once_with([sysctl_cmd, '-b', 'kern.boottime'], encoding=None)
    assert result == {
        'uptime_seconds': int(time.time() - 42),
    }

# Generated at 2022-06-22 23:01:49.302690
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    print(DarwinHardware().get_system_profile())


# Generated at 2022-06-22 23:01:57.484612
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockAnsibleModule(
        dict(
            run_command=dict(
                side_effect=[
                    (0, "hw.model: x86_64\n", ""),
                    (0, "kern.osversion: 14.0.0\n", ""),
                    (0, "kern.osrevision: 14.0.0\n", "")
                ]
            )
        )
    )
    darwin_hw = DarwinHardware(module)
    assert darwin_hw.get_mac_facts() == dict(osversion="14.0.0", osrevision="14.0.0", model="x86_64")


# Generated at 2022-06-22 23:01:59.484090
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    obj = DarwinHardware()
    assert obj.get_system_profile()

# Generated at 2022-06-22 23:02:05.654882
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_model = DarwinHardware().sysctl['hw.model']
    test_core_count = DarwinHardware().sysctl['machdep.cpu.core_count']
    test_logicalcpu = DarwinHardware().sysctl['hw.logicalcpu']
    test_ncpu = DarwinHardware().sysctl['hw.ncpu']

    test_facts = {}
    test_facts['processor'] = '%s @ %s' % (test_model, 'test_processor_speed')
    test_facts['processor_cores'] = test_core_count
    test_facts['processor_vcpus'] = '' if test_logicalcpu == None else test_logicalcpu
    if test_ncpu != None:
        test_facts['processor_vcpus'] = test_ncpu

    assert DarwinHardware().get_cpu_facts() == test

# Generated at 2022-06-22 23:02:09.299282
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
  obj = DarwinHardware()

  # method get_uptime_facts should return the correct uptime seconds
  test_data = {
    'uptime_sec': '6553760'
  }
  result = obj.get_uptime_facts()

  assert test_data['uptime_sec'].encode('utf-8') == result['uptime_seconds']

# Generated at 2022-06-22 23:02:21.759318
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class MockMod:
        def __init__(self):
            self.run_command = mock_run_command
        def run_command(self):
            return None
    class MockModule:
        def __init__(self):
            self.params = dict()
            self.run_command = mock_run_command
            self.get_bin_path = mock_get_bin_path
        def fail_json(self, *args, **kwargs):
            return None
        def get_bin_path(self, *args, **kwargs):
            return None
        def run_command(self, *args, **kwargs):
            return None


# Generated at 2022-06-22 23:02:28.949118
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils.sysctl import get_sysctl
    class FakeModule():
        def __init__(self):
            self.run_command = lambda x: ([0,"hw.model: i386\nmachdep.cpu.brand_string: Intel(R) Core(TM) i5-4300U CPU @ 1.90GHz\nhw.physicalcpu: 2\nmachdep.cpu.core_count: 2\nhw.logicalcpu: 4\nhw.ncpu: 4"],"","")
    fake_module = FakeModule()
    sysctl_values = get_sysctl(fake_module, ['hw', 'machdep', 'kern'])

# Generated at 2022-06-22 23:02:32.850459
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    facts = {'ansible_system': 'Darwin'}
    hardware_collector = DarwinHardwareCollector(facts)
    assert hardware_collector._fact_class == DarwinHardware
    assert hardware_collector._platform == 'Darwin'

# Generated at 2022-06-22 23:02:42.039695
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts import cached
    import pytest
    
    # Defines a mock for sysctl.get (hw.machdep.cpu.brand_string)
    @property
    def mock_sysctl(self):
        return "mock_brand_string"
    DarwinHardware.sysctl = mock_sysctl
    
    assert DarwinHardware().get_cpu_facts() == {"processor": "mock_brand_string", "processor_cores": "mock_brand_string"}

# Generated at 2022-06-22 23:02:46.301217
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModuleMock()

    darwin_hardware = DarwinHardware(module=module)
    cpu_facts = darwin_hardware.get_cpu_facts()

    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts

# Generated at 2022-06-22 23:02:55.412630
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    def run_command(cmd, encoding=None):
        if cmd[2] == 'kern.boottime':
            return 0, b'\xfa\xec\x9b\xba\x00\x00\x00\x00\x00\x00\x00\x00', ''
        return (1, '', '')
    get_bin_path = lambda cmd: cmd
    module = type('', (), {
        'run_command': run_command,
        'get_bin_path': get_bin_path,
    })()
    hardware = DarwinHardware(module)
    uptime_facts = hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-22 23:03:03.475162
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils._text import to_bytes, to_text


# Generated at 2022-06-22 23:03:13.496392
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    if ((sys.version_info[0] == 2 and sys.version_info[1] < 7)
            or (sys.version_info[0] == 3 and sys.version_info[1] < 1)):
        hardware.module.run_command = lambda *args, **kwargs: (0, "", "")
    hardware.populate()
    facts = hardware.get_facts()
    assert 'memtotal_mb' in facts
    assert 'processor_cores' in facts
    assert 'osversion' in facts



# Generated at 2022-06-22 23:03:17.012553
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert hasattr(x, '_platform')
    assert hasattr(x, '_fact_class')
    assert x._platform == 'Darwin'
    assert x._fact_class == DarwinHardware

# Generated at 2022-06-22 23:03:24.335455
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from subprocess import CalledProcessError
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import pytest

    def run_command(self, cmd, encoing=None):
        return 0, command_out, ''

    def get_bin_path(self, cmd):
        return '/usr/bin/vm_stat'


# Generated at 2022-06-22 23:03:27.062103
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModuleHelper(argument_spec={}, supports_check_mode=True)
    hardware = DarwinHardware(module=module)
    test_results = {'model': 'MacPro1,1', 'osversion': '17.0.0', 'osrevision': '15A278'}
    results = hardware.get_mac_facts()
    for key, value in test_results.items():
        assert results[key] == value


# Generated at 2022-06-22 23:03:31.198146
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    myfact = DarwinHardware(dict(module=None))
    myfact._get_system_profile = lambda: {'Model Identifier': 'MacBookPro7,1'}
    fact = myfact.get_mac_facts()

    assert fact['model'] == 'MacBookPro7,1'


# Generated at 2022-06-22 23:03:41.432020
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    cpu_facts_dict = {'model': 'iMac14,2', 'osversion': '15.6.0', 'osrevision': '15.6.0', 'processor': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz', 'processor_cores': '4', 'processor_vcpus': '8'}

# Generated at 2022-06-22 23:03:50.375715
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class MockModule(object):
        pass

    module = MockModule()
    module.run_command = lambda x: (0, "hw.model: MacBookPro12,1", None)
    module.get_bin_path = lambda x: "sysctl"

    darwin_hardware = DarwinHardware(module)
    mac_facts = darwin_hardware.get_mac_facts()

    assert mac_facts['model'] == 'MacBookPro12,1'
