

# Generated at 2022-06-24 21:48:29.818974
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    float_1 = -784.0
    darwin_hardware_1 = DarwinHardware(float_1)
    darwin_hardware_1.populate()
    # Check whether the method call on line 147 of DarwinHardware.py
    # was called with the proper arguments
    assert_1 = darwin_hardware_1.args == (None,)
    assert assert_1


# Generated at 2022-06-24 21:48:32.901065
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    float_0 = -1114.0
    darwin_hardware_0 = DarwinHardware(float_0)

    darwin_hardware_0.get_mac_facts()
    darwin_hardware_0.get_cpu_facts()
    darwin_hardware_0.get_memory_facts()
    darwin_hardware_0.get_uptime_facts()
    darwin_hardware_0.populate()


# Generated at 2022-06-24 21:48:35.420727
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    float_0 = -5.5
    darwin_hardware_0 = DarwinHardware(float_0)
    map_0 = darwin_hardware_0.populate()



# Generated at 2022-06-24 21:48:38.788054
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    float_0 = -1.7e+308
    darwin_hardware_collector_0 = DarwinHardwareCollector(float_0)
    darwin_hardware_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_DarwinHardwareCollector()

# Generated at 2022-06-24 21:48:41.546630
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware(None)
    collected_facts_0 = {}

    try:
        darwin_hardware_0.populate(collected_facts_0)
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-24 21:48:51.863573
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-24 21:48:59.590942
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import try_except_return_false
    import get_bin_path
    try_except_return_false_0 = try_except_return_false.TryExceptReturnFalse()
    get_bin_path_0 = get_bin_path.GetBinPath()
    try_except_return_false_0.try_except_return_false()
    get_bin_path_0.get_bin_path()
    # Construct a mock object of module_utils.common.process.get_bin_path.
    module_utils.common.process.get_bin_path.get_bin_path = get_bin_path_0.get_bin_path

    darwin_hardware_0 = DarwinHardware(float_0)
    darwin_hardware_0.get_system_profile()
    return

# Unit test

# Generated at 2022-06-24 21:49:09.084759
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    float_0 = -326.0
    darwin_hardware_0 = DarwinHardware(float_0)
    module_0 = darwin_hardware_0.module
    module_0.module_utils.module_runner = "test"
    module_0.run_command = mock_run_command
    darwin_hardware_0.sysctl = {'kern.osversion': '10.8.0'}
    darwin_hardware_0.get_mac_facts = mock_get_mac_facts
    darwin_hardware_0.get_cpu_facts = mock_get_cpu_facts
    darwin_hardware_0.get_memory_facts = mock_get_memory_facts
    darwin_hardware_0.get_uptime_facts = mock_get_

# Generated at 2022-06-24 21:49:13.427139
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    float_0 = -1114.0
    darwin_hardware_0 = DarwinHardware(float_0)
    sysctl_cmd = darwin_hardware_0.module.get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    rc, out, err = darwin_hardware_0.module.run_command(cmd, encoding=None)
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if rc != 0 or len(out) < struct_size:
        return {}

    (kern_boottime, ) = struct.unpack(struct_format, out[:struct_size])


# Generated at 2022-06-24 21:49:17.618839
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    min_float_0 = -1114.0
    darwin_hardware_0 = DarwinHardware(min_float_0)

    assert darwin_hardware_0.get_system_profile() == {}


# Generated at 2022-06-24 21:49:29.941440
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert(True)


# Generated at 2022-06-24 21:49:31.020974
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    param_0 = DarwinHardware()
    param_0.populate()


# Generated at 2022-06-24 21:49:32.103217
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    var_0 = DarwinHardware()
    var_0.get_uptime_facts()

# Generated at 2022-06-24 21:49:35.749339
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # In case this test is executed within a virtualenv
    darwin_hardware = DarwinHardware()
    darwin_hardware.module = importlib.import_module('ansible.modules.system.hardware')
    out = darwin_hardware.get_mac_facts()
    assert out['osversion'] == '15.6.0'
    assert out['osrevision'] == '3'


# Generated at 2022-06-24 21:49:46.869395
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_param_0 = None
    var_0 = DarwinHardware(test_param_0)
    var_0.sysctl = {u'machdep.cpu.brand_string': u'Intel Core i7-4870HQ CPU \u00b7 2.50 GHz', u'hw.logicalcpu': u'8'}
    var_1 = var_0.get_cpu_facts()
    assert var_1.keys() == set(['processor_vcpus', 'processor', 'processor_cores'])
    assert var_1['processor_vcpus'] == u'8'
    assert var_1['processor'] == u'Intel Core i7-4870HQ CPU \u00b7 2.50 GHz'
    assert var_1['processor_cores'] == u'2'

# Generated at 2022-06-24 21:49:48.405166
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj_0 = DarwinHardwareCollector()
    assert obj_0.platform == 'Darwin'


# Generated at 2022-06-24 21:49:58.348502
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    var = DarwinHardware()
    var_res = {'uptime_seconds': var.get_uptime_facts(), 'memtotal_mb': var.get_memory_facts(), 'model': var.get_mac_facts(), 'osrevision': var.get_mac_facts(), 'osversion': var.get_mac_facts(), 'processor_vcpus': var.get_cpu_facts(), 'processor_cores': var.get_cpu_facts(), 'processor': var.get_cpu_facts()}
    var_out = DarwinHardware.populate()

    assert var_res == var_out


# Generated at 2022-06-24 21:50:07.213401
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-24 21:50:09.825945
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    var_0 = DarwinHardware()
    var_0.module = module_0
    var_0.sysctl = {}
    var_0.module.run_command = test_case_0
    var_0.get_mac_facts()

test_DarwinHardware_get_mac_facts()

# Generated at 2022-06-24 21:50:10.696879
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    test_case_0()

# Generated at 2022-06-24 21:50:25.721482
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:50:31.437425
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_2 = b'\x02'
    darwin_hardware_3 = DarwinHardware(bytes_2)
    darwin_hardware_3.populate()
    assert darwin_hardware_3.get_mac_facts() == {'osversion': '16.6.0', 'osrevision': '1916.6.0'}


# Generated at 2022-06-24 21:50:34.825648
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_uptime_facts()
    assert var_0 == {}


# Generated at 2022-06-24 21:50:42.687467
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bytes_0 = b'\x01\x02\x03'
    # bytes -> str implicitly
    str_0 = str(bytes_0)
    # str -> dict implicitly
    dict_0 = dict({str_0:str_0})
    # dict -> bool implicitly
    bool_0 = bool(dict_0)
    darwin_hardware_0 = DarwinHardware(dict_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:50:51.027740
# Unit test for method get_mac_facts of class DarwinHardware

# Generated at 2022-06-24 21:51:00.272871
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    rc = 0

# Generated at 2022-06-24 21:51:03.972217
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b'\xff'
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_0.sysctl = {'hw.memsize': '65536'}
    var_0 = darwin_hardware_0.get_memory_facts()
    assert var_0 == {'memfree_mb': 0, 'memtotal_mb': 64}


# Generated at 2022-06-24 21:51:08.282051
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_1 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:51:14.841666
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_mac_facts()
    print("type of var_0: ", type(var_0))
    print("value of var_0: ", var_0)


# Generated at 2022-06-24 21:51:17.902946
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_memory_facts()



# Generated at 2022-06-24 21:51:39.586365
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    data_0 = 'WFZhRQ=='
    bytes_0 = base64.b64decode(data_0)
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_system_profile()
    print(var_0)


# Generated at 2022-06-24 21:51:44.013751
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Initialization
    bytes_0 = b'\xff'
    bool_0 = True
    # Execution
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_2 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:51:47.551911
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 21:51:50.319048
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    try:
        darwin_hardware_0 = DarwinHardware()
        darwin_hardware_0.populate()
    except Exception as e:
        var_0 = type(e)



# Generated at 2022-06-24 21:51:54.262669
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:52:01.154271
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x13\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_system_profile()

# Generated at 2022-06-24 21:52:05.094399
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_system_profile()

# Generated at 2022-06-24 21:52:13.705151
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_0 = b'\xff'
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_mac_facts()
    assert isinstance(var_0, dict)
    assert 'model' in var_0
    assert 'osversion' in var_0
    assert 'osrevision' in var_0
    assert 'uptime_seconds' not in var_0
    assert 'processor' not in var_0
    assert 'processor_vcpus' not in var_0
    assert 'processor_cores' not in var_0
    assert 'memtotal_mb' not in var_0
    assert 'memfree_mb' not in var_0


# Generated at 2022-06-24 21:52:16.772674
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_0.populate()
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:52:19.186978
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    bytes_0 = b'\xff'
    darwin_hardware_collector_0 = DarwinHardwareCollector(bytes_0)


# Generated at 2022-06-24 21:53:06.345019
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    result = darwin_hardware_0.get_mac_facts()
    assert result == {}


# Generated at 2022-06-24 21:53:09.143792
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:53:11.779563
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:53:14.730778
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bytes_0 = b'\x1b'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:53:25.014728
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():

    # Parameters
    darwin_hardware_0 = DarwinHardware(b'\xff')
    darwin_hardware_1 = DarwinHardware(b'\xff')
    darwin_hardware_0.get_mac_facts = darwin_hardware_1.get_mac_facts
    darwin_hardware_0.get_cpu_facts = darwin_hardware_1.get_cpu_facts
    darwin_hardware_0.get_memory_facts = darwin_hardware_1.get_memory_facts
    darwin_hardware_0.get_uptime_facts = darwin_hardware_1.get_uptime_facts
    darwin_hardware_0.populate = darwin_hardware_1.populate
    darwin_hard

# Generated at 2022-06-24 21:53:27.593253
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:53:31.050811
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    kwargs_0 = {
        'byteorder': 'big',
    }
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_collector_0 = DarwinHardwareCollector(bytes_0, **kwargs_0)


# Generated at 2022-06-24 21:53:35.704325
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector(DarwinHardware, True)
    assert darwin_hardware_collector_0._fact_class is DarwinHardware, 'Unexpected value for attribute _fact_class'
    assert darwin_hardware_collector_0._platform == 'Darwin', 'Unexpected value for attribute _platform'

# Generated at 2022-06-24 21:53:38.418088
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_collector_0 = DarwinHardwareCollector(bytes_0)


# Generated at 2022-06-24 21:53:42.001053
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_0.populate()
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:55:38.534237
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    assert (darwin_hardware_0.get_uptime_facts() == {})


# Generated at 2022-06-24 21:55:40.005437
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:55:42.197663
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector(platform, module)


# Generated at 2022-06-24 21:55:44.164796
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():

    darwin_hardware_collector_0 = DarwinHardwareCollector()

    assert darwin_hardware_collector_0 is not None

# Generated at 2022-06-24 21:55:48.704241
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Input params
    bytes_0 = b'\xff'

    # Constructor of class DarwinHardware
    darwin_hardware_0 = DarwinHardware(bytes_0)

    # Call method get_cpu_facts of class DarwinHardware
    var_1 = darwin_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 21:55:51.727999
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # darwin_hardware_0 is a instance of class DarwinHardware
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:55:54.034454
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    bytes_0 = b'\xff'
    darwin_hardware_collector_0 = DarwinHardwareCollector(bytes_0)
    var_0 = darwin_hardware_collector_0.generate_facts()

# Generated at 2022-06-24 21:55:54.954898
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware = DarwinHardwareCollector()


# Generated at 2022-06-24 21:55:55.912339
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Nothing to test in constructor
    pass


# Generated at 2022-06-24 21:55:58.205452
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_0 = b'\xff'
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_mac_facts()
