

# Generated at 2022-06-24 21:48:23.576971
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    out = b'Pages wired down:         126426\nPages active:           36123437\nPages inactive:         31732836\n'
    # Before calling get_memory_facts we need to setup a couple of things
    darwin_hardware_0.sysctl = {'hw.memsize': '64773579776'}
    darwin_hardware_0.module.run_command = lambda cmd, encoding: (0, out, None)
    memory_facts = darwin_hardware_0.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 61631
    assert memory_facts['memfree_mb'] == 9984


# Generated at 2022-06-24 21:48:26.897754
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    assert darwin_hardware_0.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}


# Generated at 2022-06-24 21:48:33.754855
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_obj = DarwinHardware()
    darwin_hardware_obj.module = module_mock()
    darwin_hardware_obj.sysctl = {
        'hw.memsize': 1048576
    }
    memory_facts = darwin_hardware_obj.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1
    assert memory_facts['memfree_mb'] == 0



# Generated at 2022-06-24 21:48:40.521255
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module.run_command = lambda command: (0, "4096\n", "")
    darwin_hardware_0.sysctl = {'hw.memsize': '1234'}
    results = darwin_hardware_0.get_memory_facts()

    assert results['memtotal_mb'] == 1
    assert results['memfree_mb'] == 0

# Generated at 2022-06-24 21:48:46.928716
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    for key in [
        '_fact_class',
        '_platform',
        '_provider',
        '_fact_subsets',
        '_subset_map',
    ]:
        assert key in darwin_hardware_collector.__dict__


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:48:50.186399
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():

    darwin_hardware_collector = DarwinHardwareCollector()

    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'


# Generated at 2022-06-24 21:48:51.706494
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_memory_facts()

# Generated at 2022-06-24 21:48:57.794280
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware({'module': ''})
    # Calling get_mac_facts method of DarwinHardware class
    # This will not return any value, but we need to withdraw any exception here
    # If exception occurs, we will mark this function as failed
    output = darwin_hardware_0.get_mac_facts()
    return True


# Generated at 2022-06-24 21:49:01.136306
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    assert darwin_hardware_0.get_system_profile() == {}


# Generated at 2022-06-24 21:49:09.188238
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )


# Generated at 2022-06-24 21:49:34.446918
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    darwin_hardware_0 = DarwinHardware()

    darwin_hardware_0.module = MagicMock()
    darwin_hardware_0.sysctl = {}
    darwin_hardware_0.get_mac_facts = MagicMock(return_value={})
    darwin_hardware_0.get_memory_facts = MagicMock(return_value={})
    darwin_hardware_0.get_uptime_facts = MagicMock(return_value={})

    # Test with hw.model as sysctl
    darwin_hardware_0.sysctl = {'hw.model': 'MacBookPro'}
    cpu_facts = darwin_hardware_0.get_cpu_facts()
    assert cpu_facts['processor'] == 'MacBookPro'


# Generated at 2022-06-24 21:49:44.413455
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz',
        'machdep.cpu.core_count': 8,
    }

    cpu_facts = {
        'processor': 'Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz',
        'processor_cores': 8,
        'processor_vcpus': '',
    }

    assert cpu_facts == darwin_hardware.get_cpu_facts()


# Generated at 2022-06-24 21:49:47.415105
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector({})
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware


# Generated at 2022-06-24 21:49:48.883689
# Unit test for method get_uptime_facts of class DarwinHardware

# Generated at 2022-06-24 21:49:50.149031
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware_0 = DarwinHardware()
    hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:49:57.035911
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    try:
        from mock import patch
    except ImportError:
        from unittest.mock import patch

    with patch.object(DarwinHardware, "get_system_profile", return_value=dict()) as mock_func:
        darwin_hardware_0 = DarwinHardware()
        darwin_hardware_0.get_memory_facts()
    assert mock_func.called


# Generated at 2022-06-24 21:50:09.541931
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    test_DarwinHardware = DarwinHardware()
    test_DarwinHardware.module = mock.Mock()
    sysctl_cmd = test_DarwinHardware.module.get_bin_path.return_value
    raw_bytes = struct.pack('@L', int(time.time() - 12345))
    test_DarwinHardware.module.run_command.return_value = [
        0, raw_bytes, None,
    ]

    assert test_DarwinHardware.get_uptime_facts() == {
        'uptime_seconds': 12345,
    }
    test_DarwinHardware.module.get_bin_path.assert_called_once_with(sysctl_cmd)

# Generated at 2022-06-24 21:50:11.496293
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_hardware = DarwinHardware()
    assert test_hardware.get_system_profile() == dict()


# Generated at 2022-06-24 21:50:23.060973
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert darwin_hardware_collector_0._platform == 'Darwin'
    assert darwin_hardware_collector_0._fact_class.platform == 'Darwin'
    assert darwin_hardware_collector_0._fact_class.sysctl is None
    assert darwin_hardware_collector_0._fact_class.get_mac_facts() == {'osversion': '', 'osrevision': '', 'model': ''}
    assert darwin_hardware_collector_0._fact_class.get_cpu_facts() == {'processor': '', 'processor_cores': '', 'processor_vcpus': ''}
    assert darwin_hardware_collector_0._fact_class

# Generated at 2022-06-24 21:50:29.144077
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_instance = DarwinHardware()
    darwin_hardware_instance.module = Mock()
    darwin_hardware_instance.module.run_command.return_value = (0, 'Processor Name: Intel Core i7\nProcessor Speed: 2.5 GHz\n', None)
    response = darwin_hardware_instance.get_system_profile()
    assert(response['Processor Name'] == 'Intel Core i7')
    assert(response['Processor Speed'] == '2.5 GHz')


# Generated at 2022-06-24 21:51:12.726202
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_obj_0 = DarwinHardware(module=None)
    darwin_hardware_obj_0.sysctl = {'hw.memsize': '512000', 'hw.pagesize': '4096'}
    darwin_hardware_obj_0.module = None
    darwin_hardware_obj_0.module.run_command = lambda x: (0, '', '')
    memory_facts = darwin_hardware_obj_0.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 500


# Generated at 2022-06-24 21:51:15.100579
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    result = darwin_hardware.get_cpu_facts()

    assert result is not None


# Generated at 2022-06-24 21:51:22.603474
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Initialise the class
    darwin_hardware_class_0 = DarwinHardware(None)
    # We want to check the value that gets returned for memfree_mb
    # As the memory may change between runs we will check that at least
    # the total amount is less than the amount of memory in the system
    rc, out, err = darwin_hardware_class_0.module.run_command("sysctl hw.memsize")
    if rc == 0:
        total_memory = int(out.splitlines()[-1].split()[1]) // 1024 // 1024
    memory_facts = darwin_hardware_class_0.get_memory_facts()
    assert memory_facts['memtotal_mb'] < total_memory


# Generated at 2022-06-24 21:51:26.400708
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    test_case_0()


if __name__ == '__main__':
    test_DarwinHardwareCollector()

# Generated at 2022-06-24 21:51:33.855766
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware_0 = DarwinHardware()
    hardware_0.module = MagicMock()
    hardware_0.sysctl = get_sysctl(hardware_0.module, ['hw', 'machdep', 'kern'])
    rc, out, err = hardware_0.module.run_command("sysctl hw.model")
    if rc == 0:
        mac_facts['model'] = mac_facts['product_name'] = out.splitlines()[-1].split()[1]
    mac_facts['osversion'] = hardware_0.sysctl['kern.osversion']
    mac_facts['osrevision'] = hardware_0.sysctl['kern.osrevision']

# Generated at 2022-06-24 21:51:46.012803
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()

# Generated at 2022-06-24 21:51:51.485423
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    DarwinHardware_0 = DarwinHardware({})
    DarwinHardware_0.module.run_command = MagicMock(return_value=(0,
            'A: 78756\nB: 23456\nC: 123\nD: 5678\nE: 3456\nF: 235', ''))
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert 'memtotal_mb' in DarwinHardware_0.get_memory_facts()


# Generated at 2022-06-24 21:52:02.537419
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    this_module = AnsibleModule(argument_spec={})
    this_module.run_command = Mock()

# Generated at 2022-06-24 21:52:08.474848
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware()
    kern_boottime = darwin_hardware_0.get_uptime_facts()
    assert darwin_hardware_0.get_uptime_facts() is not None

# Generated at 2022-06-24 21:52:13.589000
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_obj = DarwinHardware()
    darwin_hardware_obj.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '', 'hw.model': 'MacBookPro13'}
    model, osversion, osrevision = darwin_hardware_obj.get_mac_facts()
    assert model == 'MacBookPro13'
    assert osversion == '16.7.0'
    assert osrevision == ''



# Generated at 2022-06-24 21:53:01.215864
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_module = type('', (object,), dict(params=dict(gather_subset='all')))()
    test_module.run_command = run_command_mock
    test_module.get_bin_path = get_bin_path_mock
    test_instance = DarwinHardware(test_module)
    test_instance.module = test_module
    test_instance.sysctl = {'kern.osversion': 'test_kern.osversion', 'kern.osrevision': 'test_kern.osrevision'}
    return_value = test_instance.get_mac_facts()

# Generated at 2022-06-24 21:53:02.556625
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()


# Generated at 2022-06-24 21:53:11.231890
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class MockModule():
        def __init__(self):
            pass


# Generated at 2022-06-24 21:53:16.376183
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = ansible_module_0
    darwin_hardware_0.sysctl = dict()
    darwin_hardware_0.sysctl['hw.memsize'] = '2147483648'
    result = darwin_hardware_0.get_memory_facts()
    assert result['memtotal_mb'] == 2048
    assert result['memfree_mb'] == 0


# Generated at 2022-06-24 21:53:16.972530
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    pass

# Generated at 2022-06-24 21:53:27.431043
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a new instance of the DarwinHardware class
    darwin_hardware = DarwinHardware()
    # Create a sample return value for method get_system_profile of class DarwinHardware
    system_profile = {'Model Identifier': 'MacPro6,1', 'Processor Name': 'Quad-Core Intel Xeon E5', 'Processor Speed': '3.5 GHz'}
    # Set module.run_command() to return the sample return value above
    darwin_hardware.module.run_command.return_value = (0, 'SPHardwareDataType: (null)', '')
    # Execute method get_system_profile() of DarwinHardware class
    darwin_hardware.get_system_profile()
    # Verify that method run_command() was called with the correct arguments
    darwin_hardware.module.run_

# Generated at 2022-06-24 21:53:34.317519
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwinHardware = DarwinHardware()


    # These tests use values from sysctl.  See the unit tests for that
    # module for more details.
    darwinHardware.sysctl = { 'hw.memsize': 209715200,
                              'hw.physicalcpu': 2,
                              'hw.logicalcpu': 4 }

    # First test - vm_stat command gives good output.
    darwinHardware.module = MockModule()


# Generated at 2022-06-24 21:53:40.884471
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {'hw.model': 'foo', 'kern.osversion': 'bar', 'kern.osrevision': 'baz'}
    darwin_hardware_0.module.run_command = MagicMock()
    darwin_hardware_0.module.run_command.return_value = (0, 'foo', None)

    darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:53:42.570950
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    obj = DarwinHardware()
    # get_mac_facts is not tested yet.


# Generated at 2022-06-24 21:53:52.423084
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Create an instance of DarwinHardware
    darwin_hardware_0 = DarwinHardware()

    # Run method get_mac_facts on instance of DarwinHardware
    darwin_hardware_get_mac_facts_0 = darwin_hardware_0.get_mac_facts()
    # Run method get_mac_facts on instance of DarwinHardware
    darwin_hardware_get_mac_facts_1 = darwin_hardware_0.get_mac_facts()

    # Raise an exception if any of the following conditions are met:
    # 1) The return value is a dictionary containing a 'model' key
    if not isinstance(darwin_hardware_get_mac_facts_0, dict) or not 'model' in darwin_hardware_get_mac_facts_0:
        raise AssertionError

# Generated at 2022-06-24 21:54:53.504547
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)

    # Call method populate of class DarwinHardware
    test_case_0()
    test_case_1()

# Generated at 2022-06-24 21:54:56.369890
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.populate()


# Generated at 2022-06-24 21:54:58.888894
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:55:00.562356
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    tuple_0 = None
    darwin_hardware_collector_0 = DarwinHardwareCollector(tuple_0)


# Generated at 2022-06-24 21:55:03.348946
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    tuple_0 = None
    darwin_hardware_collector_0 = DarwinHardwareCollector(tuple_0)
    assert isinstance(darwin_hardware_collector_0, DarwinHardwareCollector) == True
    assert darwin_hardware_collector_0._platform == 'Darwin'

# Generated at 2022-06-24 21:55:11.769505
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Stub data for get_sysctl
    get_sysctl_parm_1 = {
        'kern.osrevision': '12747',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM)2 Duo CPU     P9600  @ 2.53GHz',
        'machdep.cpu.core_count': 2,
        'hw.memsize': 4194304,
        'kern.osversion': '15.5.0',
    }
    darwin_hardware_0 = DarwinHardware(None)
    darwin_hardware_0.sysctl = get_sysctl_parm_1
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:55:13.764937
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:55:16.101504
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:55:17.971954
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:55:21.369120
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:57:27.978618
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:57:37.535065
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Create a class with a method mock to test
    class MacFactsTest:
        def __init__(self):
            self.module = MagicMock()

        def get_mac_facts(self):
            # Create a side effect to simulate the command output
            self.run_command = MagicMock(return_value=(0, "hw.model: MacBookAir5,2", ""))
            # Execute the method to test
            return self.get_mac_facts_origin()

        def get_mac_facts_origin(self):
            out = ""
            rc, out, err = self.module.run_command("sysctl hw.model")

# Generated at 2022-06-24 21:57:39.582969
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:57:42.232461
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardwareCollector(tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_DarwinHardwareCollector()

# Generated at 2022-06-24 21:57:50.845030
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    tuple_1 = None
    darwin_hardware_1 = DarwinHardware(tuple_1)

# Generated at 2022-06-24 21:57:54.170392
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.populate()
    var_1 = darwin_hardware_0.populate()


# Generated at 2022-06-24 21:57:58.174874
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_cpu_facts()
    assert var_0 == {'processor_cores': '4', 'processor': 'Intel(R) Core(TM) i5-5675R CPU @ 3.10GHz', 'processor_vcpus': '8'}


# Generated at 2022-06-24 21:58:04.942270
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible_collections.ansible.community.tests.unit.compat import mock
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils import basic
    from ansible_collections.ansible.community.plugins.module_utils.facts import hardware

    class TestAnsibleModule():
        def __init__(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            return (0, 'good', '')

    tuple_0 = None
    darwin_hardware_0 = DarwinHardware(tuple_0)
