

# Generated at 2022-06-24 21:48:22.441415
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = -1397
    darwin_hardware_0 = DarwinHardware(int_0)
    assert darwin_hardware_0.get_system_profile() == dict()


# Generated at 2022-06-24 21:48:26.305029
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    int_0 = -1397
    darwin_hardware_0 = DarwinHardware(int_0)

    # Call method
    result = darwin_hardware_0.populate()

    assert result == None


# Generated at 2022-06-24 21:48:34.236519
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    int_0 = -1596
    darwin_hardware_0 = DarwinHardware(int_0)
    darwin_hardware_0.module = unittest.mock.MagicMock()
    darwin_hardware_0.module.run_command.return_value = (-1056, 'dqsjbxyxknhrwms', 'hxlmhgikqu')
    method_return_value_1 = darwin_hardware_0.populate()
    assert method_return_value_1 is None


# Generated at 2022-06-24 21:48:38.105831
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Arrange
    int_0 = -1397
    darwin_hardware_0 = DarwinHardware(int_0)
    # Act
    darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:48:44.246810
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    int_0 = -1397
    darwin_hardware_0 = DarwinHardware(int_0)

    darwin_hardware_0.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '170102', 'hw.model': 'MacPro5,1'}
    darwin_hardware_0.module = mock.MagicMock()
    darwin_hardware_0.module.run_command.return_value = (0, 'hw.model: MacPro5,1', '')
    darwin_hardware_0.get_system_profile = mock.MagicMock()

# Generated at 2022-06-24 21:48:47.796749
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    print("Testing DarwinHardwareCollector constructor")
    # Setup test class object
    darwin_hardware_0 = DarwinHardwareCollector()
    assert(darwin_hardware_0 != None)


# Generated at 2022-06-24 21:48:50.993558
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    int_0 = -1408
    darwin_hardware_collector_0 = DarwinHardwareCollector(int_0)
    darwin_hardware_collector_0.get_all()


# Generated at 2022-06-24 21:48:58.291771
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    int_0 = 887
    darwin_hardware_0 = DarwinHardware(int_0)
    darwin_hardware_0.module = ansible_module_0
    darwin_hardware_0.sysctl = {}
    int_0 = 1357
    darwin_hardware_0.sysctl['hw.memsize'] = int_0
    darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:49:00.755766
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = -1397
    darwin_hardware_0 = DarwinHardware(int_0)


# Generated at 2022-06-24 21:49:09.167724
# Unit test for method get_uptime_facts of class DarwinHardware

# Generated at 2022-06-24 21:49:21.655454
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert isinstance(d, DarwinHardwareCollector)

# Generated at 2022-06-24 21:49:29.785168
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = AnsibleModule(argument_spec={})
    darwin_hardware_0.sysctl = {'hw.machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-5557U CPU @ 3.10GHz'}
    darwin_hardware_0.sysctl['hw.physicalcpu'] = 2

    assert darwin_hardware_0.get_cpu_facts() == {'processor_cores': 2, 'processor': 'Intel(R) Core(TM) i7-5557U CPU @ 3.10GHz', 'processor_vcpus': ''}


# Generated at 2022-06-24 21:49:33.234787
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    print("Testcase 1: " + str(darwin_hardware_collector_0.__class__.__name__))
    print("Testcase 1: " + str(darwin_hardware_collector_0.__doc__))



# Generated at 2022-06-24 21:49:36.742471
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = dict()
    darwin_hardware_0.sysctl['hw.memsize'] = 1073741824
    expected_result = {'memtotal_mb': 1024, 'memfree_mb': 0}
    actual_result = darwin_hardware_0.get_memory_facts()
    assert expected_result == actual_result


# Generated at 2022-06-24 21:49:40.657674
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    fact_module = darwin_hardware_collector_0._fact_class(test_module)
    fact_module.get_memory_facts()


# Generated at 2022-06-24 21:49:50.054189
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mock_module_0 = type('', (), {'run_command': mock_run_command_0})
    mock_run_command_0.return_value = (0, 'HW_MODEL_NAME: Macmini7,1\nHW_NCPU: 2\nHW_MEMSIZE: 17179869184\nHW_AVAILCPU: 2\n', '')
    mock_module_1 = type('', (), {'run_command': mock_run_command_1})
    mock_run_command_1.return_value = (0, '4', '')
    mock_module_2 = type('', (), {'run_command': mock_run_command_2})
    mock_run_command_2.return_value = (0, '56', '')

# Generated at 2022-06-24 21:49:52.249884
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_obj_0 = DarwinHardware()
    assert darwin_hardware_obj_0.get_cpu_facts() == {'processor': '', 'processor_cores': '', 'processor_vcpus': ''}


# Generated at 2022-06-24 21:49:54.097843
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware(module=None)
    # When not mocked, will raise NotImplementedError anyway
    return_value_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:50:02.847133
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    rc, out, err = darwin_hardware_0.module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    if rc != 0:
        return dict()
    system_profile = dict()
    for line in out.splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)
            system_profile[key.strip()] = ' '.join(value.strip().split())
    return system_profile

# Generated at 2022-06-24 21:50:05.656739
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_get_memory_facts_0 = DarwinHardware()
    test_get_memory_facts_0.populate()
    assert test_get_memory_facts_0._DarwinHardware__sysctl == {'hw.cachelinesize': 0, 'hw.ncpu': 0, 'hw.byteorder': 0, 'hw.logicalcpu': 0, 'hw.memsize': 0, 'hw.physicalcpu': 0}

# Generated at 2022-06-24 21:50:23.266942
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    d1 = DarwinHardware()
    d1.sysctl = {'kern.osversion':'15.5.0', 'kern.osrevision':'19F101'}
    mac_facts = d1.get_mac_facts()
    assert mac_facts['osversion'] == '15.5.0'
    assert mac_facts['osrevision'] == '19F101'


# Generated at 2022-06-24 21:50:25.580730
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:50:35.787072
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # First, test with the system_profiler command returning an error
    darwin_hardware_0 = DarwinHardware(module=dict())

    darwin_hardware_0.module.run_command = MagicMock(return_value=(1, 'a', 'b'))
    assert darwin_hardware_0.get_system_profile() == dict()

    # Then, test with the command returning a success

# Generated at 2022-06-24 21:50:38.236037
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector.__class__ == DarwinHardwareCollector

# Generated at 2022-06-24 21:50:43.247409
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    obj1 = darwin_hardware_collector_0.get_facts()
    assert obj1['processor'] == 'Intel(R) Core(TM)2 Duo CPU     T7700  @ 2.40GHz'
    assert obj1['processor_vcpus'] == 4
    assert obj1['memory_mb'] == 1023


# Generated at 2022-06-24 21:50:44.518823
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    a = DarwinHardware()
    ret = a.get_uptime_facts()

# Generated at 2022-06-24 21:50:47.668255
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0_obj = DarwinHardware()
    collected_facts = 'collected_facts'
    ansible_facts_0 = darwin_hardware_0_obj.populate(collected_facts)


# Generated at 2022-06-24 21:50:50.062745
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 21:51:00.211528
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    print('##TEST: test_DarwinHardware_get_uptime_facts()')
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    # Test if the DarwinHardware class is able to parse a basic output of sysctl
    cpu = DarwinHardware()
    # Test a valid output of sysctl
    cpu.sysctl = {
    'kern.boottime': '{ sec = 1535642793, usec = 649280 } '
                     'Tue Aug 28 13:19:53 2018'
    }
    assert cpu.get_uptime_facts() == {
        'uptime_seconds': 0
    }

    # Test an output of sysctl containing the wrong type of time format

# Generated at 2022-06-24 21:51:04.491198
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModule(argument_spec = dict(
        gather_subset = dict(default=['!all'], type='list')
    ))
    darwin_hardware_collector_1 = DarwinHardwareCollector(module=module)
    assert darwin_hardware_collector_1.platform == 'Darwin', "Object creation using module failed"
    assert darwin_hardware_collector_1.fact_class == DarwinHardware, "Object creation using module failed"



# Generated at 2022-06-24 21:51:30.320933
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    sysctl_output_0 = {"hw":{"memsize":512,"model":"MacBookPro7,1","physicalcpu":2,"cputype":18,"cpufamily":23,"cpusubtype":18}}
    system_profile_output = {"Processor Name":"Intel Core 2 Duo","Processor Speed":"2.66 GHz","Number Of Processors":1,"Total Number Of Cores":2,"L2 Cache (per processor):":"3 MB","Memory":"4 GB"}
    darwin_hardware_0.sysctl = sysctl_output_0
    # The `mock` library is available in Python 3.3+
    # darwin_hardware_0.get_system_profile = MagicMock(return_value=system_profile_output)

# Generated at 2022-06-24 21:51:42.057907
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create an instance of class DarwinHardware
    test_instance_0 = DarwinHardware()
    # Use the instance of class DarwinHardware to get the memory facts of MacOs.
    memory_facts_result = test_instance_0.get_memory_facts()
    # The result should contain key 'memtotal_mb' and the value should be an integer.
    assert ('memtotal_mb' in memory_facts_result) and isinstance(memory_facts_result['memtotal_mb'], int)
    # The result should contain key 'memfree_mb' and the value should be an integer.
    assert ('memfree_mb' in memory_facts_result) and isinstance(memory_facts_result['memfree_mb'], int)

# Generated at 2022-06-24 21:51:45.767031
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:51:53.051462
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware('module')
    darwin_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-24 21:51:59.974835
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware()
    hardware.sysctl = {'machdep.cpu.brand_string' : ['Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz']}
    hardware.get_cpu_facts() == {'processor': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz',
                                 'processor_cores': '',
                                 'processor_vcpus': ''}


# Generated at 2022-06-24 21:52:11.818759
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Test for Mac Mini Early 2009, 10.12.2
    sysctl_command = 'sysctl -n hw.model && sysctl -n kern.osversion && sysctl -n kern.osrevision'
    sysctl = dict(model=["Macmini2,1"], osversion=["15C50"], osrevision=["1712011002"])
    darwin_hardware_0 = DarwinHardware(module=None, sysctl=sysctl)
    assert darwin_hardware_0.get_mac_facts() == dict(model="Macmini2,1", osversion="15C50", osrevision="1712011002")

    # Test for Mac Mini Early 2009, 10.10.2

# Generated at 2022-06-24 21:52:15.415522
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hw = DarwinHardware({})
    ret = hw.get_cpu_facts()

    assert 'processor_cores' in ret
    assert 'processor' in ret
    assert 'processor_vcpus' in ret



# Generated at 2022-06-24 21:52:26.266212
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'machdep.cpu.brand_string':'Intel(R) Core(TM) i3-2367M CPU @ 1.40GHz','machdep.cpu.core_count':1}
    darwin_hardware_get_cpu_facts = darwin_hardware.get_cpu_facts()
    assert darwin_hardware_get_cpu_facts['processor'] == 'Intel(R) Core(TM) i3-2367M CPU @ 1.40GHz'
    assert darwin_hardware_get_cpu_facts['processor_cores'] == 1
    assert darwin_hardware_get_cpu_facts['processor_vcpus'] == ''



# Generated at 2022-06-24 21:52:29.474135
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class Test:
        pass
    test = Test()
    darwin_hardware_0 = DarwinHardware(test)

    # DarwinHardware._sysctl is set to None
    # method get_cpu_facts should return a dict
    assert isinstance(darwin_hardware_0.get_cpu_facts(), dict)


# Generated at 2022-06-24 21:52:32.968182
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_obj_0 = DarwinHardware()
    # darwin_hardware_obj_0.populate()



# Generated at 2022-06-24 21:53:33.305530
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    system_profile_output = """Hardware Overview:

    Model Name: MacBook Pro
    Model Identifier: MacBookPro11,4
    Processor Name: Intel Core i7
    Processor Speed: 2.4 GHz
    Number of Processors: 1
    Total Number of Cores: 2
    L2 Cache (per Core): 256 KB
    L3 Cache: 4 MB
    Memory: 8 GB
    Boot ROM Version: MBP114.0172.B00
    SMC Version (system): 2.29f12
    Serial Number (system): C02RM2TQFK42
    Hardware UUID: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX

"""

# Generated at 2022-06-24 21:53:34.927876
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_1 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:53:43.939620
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hostname = "foo.example.com"

    darwin_hardware = DarwinHardware(None, dict(), hostname)

    darwin_hardware.sysctl = {
        'kern.osversion': '12.0.0',
        'kern.osrevision': '1'
    }

    rc = 0
    out = b"hw.model: MacPro6,1\n"
    err = ""

    darwin_hardware.module.run_command = lambda x: (rc, out, err)

    mac_facts = darwin_hardware.get_mac_facts()


# Generated at 2022-06-24 21:53:49.828346
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    '''
    Test implementation of get_memory_facts of class DarwinHardware
    '''
    # Create an instance of class DarwinHardware
    darwin_hardware_obj_0 = DarwinHardware()
    # Call method get_memory_facts of darwin_hardware_obj_0
    memory_facts = darwin_hardware_obj_0.get_memory_facts()

# Generated at 2022-06-24 21:54:00.510170
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware()
    # Note that mocking the sysctl module is not trivial; the method in fact
    # returns a class of type 'collections.defaultdict', which is not
    # directly mockable.
    darwin_hardware_0.sysctl = {u'kern.osrevision': 14955049, u'kern.osversion': u'15.5.0', u'hw.memsize': 17179869184, u'kern.boottime': {u'sec': 1554666269, u'usec': 297315}}
    darwin_hardware_0.module = Mock()
    darwin_hardware_0.module.run_command.return_value = (0, 'com.apple.vm.vm_stat:', '')
    dar

# Generated at 2022-06-24 21:54:08.306330
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    out = '''
System Profile:

  Hardware Overview:

    Model Name: MacBook Pro
    Model Identifier: MacBookPro9,1
    Processor Name: Intel Core i7
    Processor Speed: 2.7 GHz
    Number of Processors: 1
    Total Number of Cores: 2
    L2 Cache (per Core): 256 KB
    L3 Cache: 4 MB
    Memory: 4 GB
    Boot ROM Version: MBP91.00D3.B08
    SMC Version (system): 2.3f36
    Serial Number (system): C02H50KFKTDH
    Hardware UUID: ********-****-****-****-************

  Model Information:

    Model Identifier: MacBookPro9,1
    Part Number: MD101xx/A
    Model Name: MacBook Pro
    EMC Number: 2556
'''
    out

# Generated at 2022-06-24 21:54:17.000343
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware('ansible_module')

    with open('test_DarwinHardware_get_system_profile.stdout') as f:
        data = f.read()
        darwin_hardware_0._collector = type('', (), {'get_system_profile': lambda: data})


# Generated at 2022-06-24 21:54:19.385348
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class is DarwinHardware
    assert darwin_hardware_collector._platform is 'Darwin'



# Generated at 2022-06-24 21:54:20.891002
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    hardware = DarwinHardware()
    assert hardware.get_uptime_facts()['uptime_seconds'] > 0

# Generated at 2022-06-24 21:54:27.795748
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    dummy_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    dummy_module.get_bin_path = Mock(return_value="/usr/bin/vm_stat")
    dummy_module.run_command = Mock(return_value=(0, """
Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                                1929.
Pages active:                              387791.
Pages inactive:                            6016.
Pages speculative:                         160.
Pages throttled:                           0.
Pages wired down:                          194797.
""", None))
    darwin_hardware_0 = DarwinHardware(dummy_module)

# Generated at 2022-06-24 21:55:40.077215
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_obj = DarwinHardwareCollector()
    assert(isinstance(darwin_hardware_collector_obj, DarwinHardwareCollector))

if __name__ == "__main__":
    test_case_0()
    test_DarwinHardwareCollector()

# Generated at 2022-06-24 21:55:47.112737
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.hardware.base import HardwareCollector

    hardware_collector_0 = HardwareCollector()
    darwin_hardware_0 = DarwinHardware()

    hardware_collector_0.populate()
    darwin_hardware_0.populate()
    cache.FactsCache().populate()

    darwin_hardware_0.get_memory_facts()

# Generated at 2022-06-24 21:55:50.244497
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    Test case for initialization of class DarwinHardwareCollector
    """
    try:
        test_case_0()
    except Exception as e:
        assert False , "Error occurred in initialization of class DarwinHardwareCollector"
    else:
        assert True


# Generated at 2022-06-24 21:55:50.768921
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    pass

# Generated at 2022-06-24 21:56:00.601231
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    '''
    Unit test for method get_cpu_facts of class DarwinHardware
    '''
    darwin_hardware_0 = DarwinHardware()

    # Testing this method with a PowerPC Processor
    darwin_hardware_0.sysctl = {
        'machdep.cpu.core_count': None,
        'hw.physicalcpu': 2,
        'kern.osversion': '14.5.0',
        'kern.osrevision': '15E65',
        'hw.memsize': 1073741824
    }

    system_profile = {'Processor Name': 'G4', 'Processor Speed': '800 MHz'}
    darwin_hardware_0.get_system_profile = lambda: system_profile

    assert darwin_hardware_0.get_cpu_facts

# Generated at 2022-06-24 21:56:03.980003
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    # mock_module = MagicMock()
    # darwin_hardware.module = mock_module
    with patch.object(darwin_hardware, 'module') as mock_module:
        mock_module.run_command.return_value = 0
        assert darwin_hardware.get_system_profile() == 0

# Generated at 2022-06-24 21:56:07.892726
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Test case with good parameters
    darwin_hardware_get_memory_facts_0 = DarwinHardware()
    print(darwin_hardware_get_memory_facts_0.get_memory_facts())


# Generated at 2022-06-24 21:56:16.547387
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    '''
    Unit test for method get_uptime_facts of class DarwinHardware
    '''
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = AnsibleModule(argument_spec=dict())
    darwin_hardware_0.module.run_command = MagicMock(return_value=(0,
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', ''))
    assert darwin_hardware_0.get_uptime_facts() == {'uptime_seconds': 0}


# Generated at 2022-06-24 21:56:18.655636
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    instance = DarwinHardware()
    assert isinstance(instance, DarwinHardware) == True
    assert instance._platform == 'Darwin'
    assert instance.platform == 'Darwin'


# Generated at 2022-06-24 21:56:27.776496
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mac_facts_result = {
        'model': 'MacBookPro11,4', 'osversion': '15.6.0', 'osrevision': '19G73'
    }

    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '19G73'}
    rc, out, err = darwin_hardware_0.module.run_command("sysctl hw.model")
    if rc == 0:
        mac_facts_result['model'] = mac_facts_result['product_name'] = out.splitlines()[-1].split()[1]
    assert darwin_hardware_0.get_mac_facts() == mac_facts_result

# Generated at 2022-06-24 21:57:43.845185
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_0 = b'P\xe3\xc8\xbevlQ\xe9a\xec\x9a@\x16=h\xa8'
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:57:48.982367
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_0 = b'P\xe3\xc8\xbevlQ\xe9a\xec\x9a@\x16=h\xa8'
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.populate()
    var_1 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:57:53.520603
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_1 = b'`\xa3\x14\xaf\x881\xb3\x8f\xae\x9c\xac\x1d#\x85\x1d\x89\x93\x8c\x9f'
    darwin_hardware_1 = DarwinHardware(bytes_1)
    var_1 = darwin_hardware_1.get_mac_facts()


# Generated at 2022-06-24 21:57:56.727440
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bytes_0 = b'P\xe3\xc8\xbevlQ\xe9a\xec\x9a@\x16=h\xa8'
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:58:00.224851
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    expected = {'uptime_seconds': 1234}
    darwin_hardware.sysctl = {'kern.boottime': '1234'}
    result = darwin_hardware.get_uptime_facts()
    assert result == expected

# end of class DarwinHardware

# Generated at 2022-06-24 21:58:05.130017
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    #
    # case 0
    # Test with:
    #            valid sysctl output
    #
    bytes_0 = b'P\xe3\xc8\xbevlQ\xe9a\xec\x9a@\x16=h\xa8'
    darwin_hardware_collector_0 = DarwinHardwareCollector(bytes_0)