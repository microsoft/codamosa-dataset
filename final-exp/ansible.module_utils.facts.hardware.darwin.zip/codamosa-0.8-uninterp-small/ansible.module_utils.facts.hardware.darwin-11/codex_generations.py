

# Generated at 2022-06-24 21:48:32.559291
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_1 = darwin_hardware_collector_1.collect()

    if darwin_hardware_1 is None:
        print("Current Operating System is not supported by", darwin_hardware_collector_1.__class__.__name__)
        return

    darwin_hardware_1.populate()

    cpu_facts = darwin_hardware_1.get_cpu_facts()

    print("Test case 0:")
    print(cpu_facts)


# Generated at 2022-06-24 21:48:34.873082
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwinHardware = DarwinHardware()
    assert darwinHardware.get_system_profile() == dict()


# Generated at 2022-06-24 21:48:35.867476
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    result = DarwinHardwareCollector()


# Generated at 2022-06-24 21:48:43.149455
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    expected_cpu_facts_0 = {
        'processor': 'Intel(R) Core(TM) i7-7567U CPU @ 3.50GHz',
        'processor_cores': '2',
        'processor_vcpus': '4',
    }
    cpu_facts_0 = darwin_hardware_0.get_cpu_facts()
    assert cpu_facts_0 == expected_cpu_facts_0, cpu_facts_0


# Generated at 2022-06-24 21:48:53.100045
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()

    darwin_hardware_0.sysctl = {"hw.memsize": "8589934592"}

    darwin_hardware_0.get_bin_path = get_bin_path


# Generated at 2022-06-24 21:48:56.273777
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert isinstance(system_profile, dict)


# Generated at 2022-06-24 21:49:00.759977
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    darwin_hardware_class_0 = DarwinHardware

    darwin_hardware_class_0.populate()



# Generated at 2022-06-24 21:49:05.540345
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    fact_list = [{'memfree_mb': 0, 'memtotal_mb': 16384}, {'memfree_mb': 16384, 'memtotal_mb': 16384}]
    for mem_fact in fact_list:
        darwin_hardware_0 = DarwinHardware()

# Generated at 2022-06-24 21:49:08.835609
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    DarwinHardware_get_mac_facts_0 = DarwinHardware(module=None)
    DarwinHardware_get_mac_facts_1 = DarwinHardware(module=None)

    # Place your implementation of assertion statements for test case 0
    assert DarwinHardware_get_mac_facts_1.get_mac_facts() == DarwinHardware_get_mac_facts_0.get_mac_facts()


# Generated at 2022-06-24 21:49:18.235169
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    ret = darwin_hardware_0.get_system_profile()

# Generated at 2022-06-24 21:49:31.093677
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    assert isinstance(darwin_hardware.get_uptime_facts(), dict)

# Generated at 2022-06-24 21:49:37.550623
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    darwin_hardware = DarwinHardware()
    command = darwin_hardware.module.get_bin_path('vm_stat')
    expected_result = {'memtotal_mb': 16384, 'memfree_mb': 4095}

    rc, out, err = darwin_hardware.module.run_command([command])

    def get_memory_facts():
        memory_facts = {
            'memtotal_mb': int(darwin_hardware.sysctl['hw.memsize']) // 1024 // 1024,
            'memfree_mb': 0,
        }

        total_used = 0
        page_size = 4096

        rc, out, err = darwin_hardware.module.run_command([command])

        if rc != 0:
            return memory_facts


# Generated at 2022-06-24 21:49:41.119766
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    collected_facts = {}
    darwin_hardware_0 = DarwinHardware(module=None)
    darwin_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 21:49:50.373161
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    '''
    DarwinHardware - class to collect Darwin-specific hardware facts.
    test host: macOS Catalina 10.15.5
      system uptime: 2020-07-04 10:03:59 +0800
    '''
    def mock_run_command(self, cmd, encoding=None):
        '''
        Intercept and mock function module.run_command
        '''
        if cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']:
            return 0, b'\x00\x00\x00\x00\x00\x00\xe3\xd3\x0c\x0d\x00\x00\x0c\x0d\x00\x00', None

# Generated at 2022-06-24 21:49:54.121328
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    uptime_facts = darwin_hardware.get_uptime_facts()
    assert isinstance(uptime_facts, dict)
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-24 21:49:56.947332
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_1 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:50:09.505687
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import os
    import shutil
    import tempfile
    import datetime
    import math

    def helper(boot_time):
        sample_cmd = ['kern.boottime: {0}.000000 sec'.format(boot_time)]
        sample_data = '\n'.join(sample_cmd)

        command = "sysctl -b kern.boottime"
        command_line = [command, '-b', 'kern.boottime']

        cwd = tempfile.mkdtemp()
        boot_time_file = os.path.join(cwd, 'boot_time')
        with open(boot_time_file, 'w') as data:
            data.write(sample_data)

        with open(os.path.join(cwd, 'sysctl'), 'w') as sysctl_file:
            sysctl

# Generated at 2022-06-24 21:50:19.445456
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # if config is None:
    #     config = {}

    # Initialize the class object
    hardware_object = DarwinHardware()
    hardware_object.module = AnsibleModule(argument_spec=dict())

    darwin_get_mac_facts_result = hardware_object.get_mac_facts()


# Generated at 2022-06-24 21:50:23.010458
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware(module=None)
    darwin_hardware_0.populate()


# Generated at 2022-06-24 21:50:28.904301
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {}
    darwin_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    darwin_hardware_0.get_system_profile()
    darwin_hardware_0.module.run_command.assert_any_call(["/usr/sbin/system_profiler", "SPHardwareDataType"])


# Generated at 2022-06-24 21:50:40.511450
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # No assertion
    test_case_0()


# Generated at 2022-06-24 21:50:43.639782
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'j-1A'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:50:47.185607
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_memory_facts()
    assert var_0 is None


# Generated at 2022-06-24 21:50:51.934414
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    # Setup
    test_obj_0 = DarwinHardware("A")

    # Invocation
    result = test_obj_0.populate()

    # Verification
    assert result == None


# Generated at 2022-06-24 21:50:55.287908
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    str_0 = 'zea'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:51:00.084906
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    unit_test_0()
    unit_test_1()
    unit_test_2()
    unit_test_3()
    unit_test_4()
    unit_test_5()
    unit_test_6()
    unit_test_7()
    unit_test_8()
    unit_test_9()
    unit_test_10()    
if __name__ == '__main__':
    test_case_0()
    test_DarwinHardwareCollector()

# Generated at 2022-06-24 21:51:02.184437
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    str_0 = 'mAxz'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 21:51:04.608607
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:51:08.384589
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.populate()


# Generated at 2022-06-24 21:51:12.201009
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    platform_0 = 'darwin'
    darwin_hardware_collector_0 = DarwinHardwareCollector(platform_0)


# Generated at 2022-06-24 21:51:44.106127
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.module.run_command = MagicMock(return_value=(0, 'hw.model: x86_64', ''))
    darwin_hardware_0.module.run_command = MagicMock(return_value=(0, 'hw.model: x86_64', ''))
    darwin_hardware_0.module.run_command = MagicMock(return_value=(0, '19.4.0', ''))
    darwin_hardware_0.module.run_command = MagicMock(return_value=(0, '15.4.0', ''))
    var_0 = darwin_hardware_0.get_mac_facts

# Generated at 2022-06-24 21:51:45.843853
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_memory_facts()



# Generated at 2022-06-24 21:51:55.385889
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Remove test data
    if os.path.exists('temp_file1'):
        os.remove('temp_file1')
    if os.path.exists('temp_file2'):
        os.remove('temp_file2')

    test_asset_dir = os.path.join(os.path.dirname(__file__), 'test_assets')
    test_module = type('module', (object,), {'run_command': run_command})()

    # Test calls with no error
    darwin_hardware_0 = DarwinHardware('module')
    darwin_hardware_0.module = test_module
    result_0 = darwin_hardware_0.populate()

    # Test calls with error
    darwin_hardware_1 = DarwinHardware('module')
    d

# Generated at 2022-06-24 21:52:01.505355
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Test to validate that the method get_memory_facts of class DarwinHardware works as expected.
    str_0 = 'n3!U'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_memory_facts()
    assert var_0 == {'memtotal_mb': 0, 'memfree_mb': 0}

# Generated at 2022-06-24 21:52:05.502018
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Arrange
    darwin_hardware_0 = DarwinHardware(None)
    var_0 = darwin_hardware_0.get_uptime_facts()
    assert var_0 == {}


# Generated at 2022-06-24 21:52:11.375455
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)

    darwin_hardware_0.sysctl = dict(
    )

    # Call method get_cpu_facts
    var_0 = darwin_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 21:52:13.559563
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:52:17.481656
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:52:22.427669
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    str_0 = 'k-j("'
    darwin_hardware_collector_0 = DarwinHardwareCollector(str_0)
    var_0 = isinstance(darwin_hardware_collector_0, DarwinHardwareCollector)

# vim: filetype=python tabstop=4 expandtab

# Generated at 2022-06-24 21:52:25.873515
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:53:17.220595
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    str_0 = 'c'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.sysctl = dict()
    darwin_hardware_0.sysctl['hw.memsize'] = 'E'
    var_0 = darwin_hardware_0.get_memory_facts()
    assert var_0['memtotal_mb'] == 1423


# Generated at 2022-06-24 21:53:24.866583
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    str_0 = '8rT'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.populate()

# Generated at 2022-06-24 21:53:25.712355
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    pass


# Generated at 2022-06-24 21:53:29.554537
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    dict_0 = darwin_hardware_0.get_memory_facts()
    assert isinstance(dict_0, dict) == True
    assert dict_0['memfree_mb'] == 0
    assert dict_0['memtotal_mb'] == 0


# Generated at 2022-06-24 21:53:31.818689
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    str_0 = 'kHf'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.populate()


# Generated at 2022-06-24 21:53:36.005091
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'I'
    darwin_hardware_0 = DarwinHardware(str_0)
    assert darwin_hardware_0.get_mac_facts() == {'osversion': '15G31', 'osrevision': '15G31', 'model': 'MacBookPro11,2'}


# Generated at 2022-06-24 21:53:39.252803
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    str_0 = 'I'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:53:45.165435
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # print('populate')
    str_1 = 'v-kF'
    darwin_hardware_1 = DarwinHardware(str_1)
    var_1 = darwin_hardware_1.populate()
    str_2 = 'v-kF'
    darwin_hardware_2 = DarwinHardware(str_2)
    var_2 = darwin_hardware_2.populate()
    str_3 = 'v-kF'
    darwin_hardware_3 = DarwinHardware(str_3)
    var_3 = darwin_hardware_3.populate()


# Generated at 2022-06-24 21:53:48.756461
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    str_0 = 'o3q'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:53:58.598702
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'V-kF'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.sysctl = {'kern.osversion': 'V-kF', 'kern.osrevision': 'V-kF'}
    var_0 = darwin_hardware_0.get_mac_facts()
    assert var_0 == {'osversion': 'V-kF', 'model': 'V-kF', 'osrevision': 'V-kF', 'product_name': 'V-kF'}



# Generated at 2022-06-24 21:56:01.153710
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    str_0 = 'XcU]b6'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_system_profile()
    dict_1 = dict(var_0)
    for key_0, value_0 in dict_1:
        var_1 = key_0

# Generated at 2022-06-24 21:56:06.253641
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    str_0 = 'v-kF'
    darwin_hardware_0 = DarwinHardware(str_0)

    str_1 = 'sysctl'
    str_2 = '-b'
    str_3 = 'kern.boottime'
    darwin_hardware_0.module.get_bin_path = lambda x: str_1
    darwin_hardware_0.module.run_command = lambda x, encoding=None: (0, '1536582379 0\n', '')

    var_0 = darwin_hardware_0.get_uptime_facts()

    assert var_0['uptime_seconds'] == 1536582379

# Generated at 2022-06-24 21:56:10.524613
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    inst_0 = DarwinHardwareCollector()
    assert inst_0._fact_class == DarwinHardware
    assert inst_0._platform == 'Darwin'


# Generated at 2022-06-24 21:56:14.668869
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    str_0 = '!P'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.populate()
    str_1 = '+{'
    var_0 = darwin_hardware_0._get_memory_facts(str_1)


# Generated at 2022-06-24 21:56:16.218045
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # If the class constructor raises, no test is needed.
    DarwinHardwareCollector()


# Generated at 2022-06-24 21:56:18.182174
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Create instance of class DarwinHardwareCollector with default arguments
    darwin_hardware_collector_0 = DarwinHardwareCollector()

# Generated at 2022-06-24 21:56:20.645438
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:56:23.730183
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    str_0 = 'v-kF'

    # Call the method
    res = DarwinHardware.get_uptime_facts(str_0)

    # Check the result
    assert res is None


# Generated at 2022-06-24 21:56:26.110543
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = '}'
    darwin_hardware_0 = DarwinHardware(str_0)
    assert darwin_hardware_0.get_mac_facts() == {}


# Generated at 2022-06-24 21:56:28.439834
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    str_0 = 's[s)s'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.get_uptime_facts()
