

# Generated at 2022-06-24 21:48:26.510984
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():

    assert darwin_hardware_collector_0.collect() is None
    darwin_hardware_collector_0.exit()


# Generated at 2022-06-24 21:48:36.017323
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-3687U CPU @ 2.10GHz', 'machdep.cpu.core_count': '2', 'machdep.cpu.thread_count': '4'}
    expected_result = {'processor': 'Intel(R) Core(TM) i7-3687U CPU @ 2.10GHz', 'processor_vcpus': '4', 'processor_cores': '2'}
    actual_result = darwin_hardware_0.get_cpu_facts()
    assert actual_result == expected_result


# Generated at 2022-06-24 21:48:37.952674
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    tmp_darwin_hardware_0 = DarwinHardware()
    res = tmp_darwin_hardware_0.get_uptime_facts()
    assert(res is None)

# Generated at 2022-06-24 21:48:38.761343
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    pass

# Generated at 2022-06-24 21:48:45.698007
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    DarwinHardware_instance = DarwinHardware()
    ret = DarwinHardware_instance.get_mac_facts()
    # Assertion error if returned value does not equal expected value
    assert ret == {
        'model': 'Darwin',
        'osversion': 'Darwin Kernel Version 15.6.0: Mon Aug 29 20:21:34 PDT 2016; root:xnu-3248.60.10~1/RELEASE_X86_64',
        'osrevision': '15.6.0'
    }


# Generated at 2022-06-24 21:48:53.100494
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():

    class Module:

        def run_command(self, cmd, encoding=None):
            return 0, '', ''

    module = Module()
    darwin_hardware = DarwinHardware(module)
    assert darwin_hardware.get_system_profile() == {}

    class Module:

        def run_command(self, cmd, encoding=None):
            return 0, '      Key: Test\n      Value: Test2', ''

    module = Module()
    darwin_hardware = DarwinHardware(module)
    assert darwin_hardware.get_system_profile() == {'Key': 'Test'}



# Generated at 2022-06-24 21:48:55.130737
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware()
    # get system profile
    hardware.get_system_profile()

# Generated at 2022-06-24 21:48:58.843120
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Initialization
    darwin_hardware_0 = DarwinHardware()

    # Execution
    darwin_hardware_0.populate(None)

    # Verification
    assert darwin_hardware_0.sysctl == {}

    # Cleanup - None necessary


# Generated at 2022-06-24 21:49:01.369271
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.populate()

# Generated at 2022-06-24 21:49:06.164357
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware = DarwinHardware()
    rc, out, err = darwin_hardware.module.run_command(['sysctl', '-n', 'hw.memsize'])
    assert rc == 0
    assert 'memsize' in darwin_hardware.sysctl
    darwin_hardware.sysctl['hw.memsize'] = int(out)
    memtotal_mb = int(out) // 1024 // 1024
    rc, out, err = darwin_hardware.module.run_command("sysctl hw.model")
    assert rc == 0
    assert 'hw.model' in darwin_hardware.sysctl
    collected_facts = dict()
    collected_facts.update(darwin_hardware.sysctl)

# Generated at 2022-06-24 21:49:19.606491
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_1 = DarwinHardware(darwin_hardware_collector_1)
    var_1 = darwin_hardware_1.populate(None)

# Generated at 2022-06-24 21:49:23.405023
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:49:24.323598
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    assert True


# Generated at 2022-06-24 21:49:25.912051
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()

# Generated at 2022-06-24 21:49:28.001634
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    var_0 = darwin_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 21:49:31.172488
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_1 = DarwinHardware(darwin_hardware_collector_1)
    var_1 = darwin_hardware_1.get_memory_facts()


# Generated at 2022-06-24 21:49:33.466178
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_1 = DarwinHardware()
    var_1 = darwin_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 21:49:36.288756
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:49:44.030028
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    # Call method get_memory_facts of class DarwinHardware with argument darwin_hardware_collector_0
    var_0 = darwin_hardware_0.get_memory_facts()
    assert var_0 == {'memtotal_mb': 8192, 'memfree_mb': 0}

# Generated at 2022-06-24 21:49:45.270045
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:50:06.127355
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware(DarwinHardwareCollector())
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:50:08.551707
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    # Unit test for get_mac_facts function of class DarwinHardware
    var_0 = test_case_0()

if __name__ == '__main__':
    test_DarwinHardwareCollector()

# Generated at 2022-06-24 21:50:12.717719
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_1 = DarwinHardware(darwin_hardware_collector_1)
    var_1 = darwin_hardware_1.get_mac_facts()


# Generated at 2022-06-24 21:50:22.026187
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)

    var_0 = darwin_hardware_0.get_system_profile()
    var_1 = darwin_hardware_0.get_system_profile()
    var_2 = darwin_hardware_0.get_system_profile()
    var_3 = darwin_hardware_0.get_system_profile()
    var_4 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:50:26.514480
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:50:31.764221
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_memory_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 21:50:33.167700
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert darwin_hardware_collector_0._platform == 'Darwin'


# Generated at 2022-06-24 21:50:37.846710
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:50:42.075425
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    assert darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:50:44.813015
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    var_3 = DarwinHardwareCollector()
    var_3.seed_cache()
    var_3.collect()
    var_3.collect()
    var_3.seed_cache()



# Generated at 2022-06-24 21:51:24.370643
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.populate()

# Generated at 2022-06-24 21:51:28.992268
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    darwin_hardware_0.populate()


# Generated at 2022-06-24 21:51:32.547106
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_1 = DarwinHardware(darwin_hardware_collector_1)
    var_1 = darwin_hardware_1.populate()


# Generated at 2022-06-24 21:51:35.962844
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_collector = DarwinHardwareCollector()
    darwin_hardware = DarwinHardware(darwin_hardware_collector)
    var = darwin_hardware.get_system_profile()


# Generated at 2022-06-24 21:51:37.571109
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:51:43.876514
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    try:
        var_0 = darwin_hardware_0.get_system_profile()
    except Exception:
        var_0 = None
    assert var_0 is not None


# Generated at 2022-06-24 21:51:46.756602
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:51:51.918646
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    # Test with default args
    var_0 = darwin_hardware_0.get_uptime_facts()
    assert var_0 is not None
    # Test with arg: key
    var_1 = darwin_hardware_0.get_uptime_facts(key='key')
    assert var_1 is not None


# Generated at 2022-06-24 21:51:56.044102
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:52:00.952970
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.populate()
    print(var_0)

# Unit tests for method 

# Generated at 2022-06-24 21:53:23.705397
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:53:24.966672
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    pass

# Generated at 2022-06-24 21:53:32.697343
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # These are examples of system facts gathered from the fact module
    # These may prove useful during unit testing
    collected_facts = {
        'ansible_kernel': 'Darwin',
        'ansible_architecture': 'x86_64',
        'ansible_distribution': 'MacOSX',
        'ansible_pkg_mgr': 'homebrew',
        'ansible_distribution_release': '10.6.0',
        'ansible_system': 'Darwin',
        'ansible_distribution_version': '10.6.0',
    }

    facts_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        add_file_common_args=True,
    )

# Generated at 2022-06-24 21:53:42.129611
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """Test method get_mac_facts in class DarwinHardware"""

    # Some expected values
    var_0 = {
        u'osrevision': u'15.5.0',
        u'model': u'MacBookPro12,1',
        u'osversion': u'Darwin Kernel Version 15.5.0: Mon Apr 18 22:53:36 PDT 2016; root:xnu-3248.50.21~8/RELEASE_X86_64'
    }

    # Get the value of sysctl['kern']

# Generated at 2022-06-24 21:53:44.613365
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_1 = DarwinHardware(darwin_hardware_collector_1)
    var_1 = darwin_hardware_1.get_memory_facts()


# Generated at 2022-06-24 21:53:49.205715
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_1 = DarwinHardware(darwin_hardware_collector_1)
    var_1 = darwin_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 21:53:55.607754
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    print('Calling method populate of class DarwinHardware')
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.populate()
    print(var_0)


# Generated at 2022-06-24 21:53:59.087152
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:54:01.705905
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:54:02.961450
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    memory_facts_0 = DarwinHardware().get_memory_facts()


# Generated at 2022-06-24 21:57:54.135482
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mac_facts = {
        'model': 'MacBookPro14,3',
        'osversion': '17.7.0',
        'osrevision': '15F34'
    }
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    assert mac_facts == darwin_hardware_0.get_mac_facts()



# Generated at 2022-06-24 21:57:56.792666
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_1 = DarwinHardware(darwin_hardware_collector_1)
    var_1 = darwin_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 21:57:57.878467
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()


# Generated at 2022-06-24 21:58:00.973029
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_1 = DarwinHardware(darwin_hardware_collector_1, module=AnsibleModule())
    var_1 = darwin_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 21:58:04.397912
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_0)
    var_0 = darwin_hardware_0.get_mac_facts()

if __name__ == '__main__':
    test_case_0()
    test_DarwinHardware_get_system_profile()

# Generated at 2022-06-24 21:58:08.656638
# Unit test for method get_memory_facts of class DarwinHardware