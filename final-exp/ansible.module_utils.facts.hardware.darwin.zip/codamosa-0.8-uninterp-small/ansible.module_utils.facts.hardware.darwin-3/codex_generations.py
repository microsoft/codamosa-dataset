

# Generated at 2022-06-24 21:48:28.097868
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    float_0 = 8266.25174
    darwin_hardware_0 = DarwinHardware(float_0)
    # Test the return value, because the method is void
    assert darwin_hardware_0.get_uptime_facts() is None


# Generated at 2022-06-24 21:48:34.991220
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    float_0 = 5323.384
    darwin_hardware_0 = DarwinHardware(float_0)
    darwin_hardware_0.populate()

    # Test with a new process
    test_case_0()

if __name__ == '__main__':
    # Run unit tests
    test_DarwinHardware_get_uptime_facts()

# Generated at 2022-06-24 21:48:42.014104
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    float_0 = 5323.384
    darwin_hardware_0 = DarwinHardware(float_0)

    rc_0 = 0
    splitlines_0 = []

    out_0 = ''.join(splitlines_0)
    rc_1 = 0
    err_0 = ''.join([])

    rc_mock_0 = mock.Mock(return_value=rc_0)
    run_command_mock_0 = mock.Mock(return_value=(rc_1, out_0, err_0))
    setattr(darwin_hardware_0, 'run_command', run_command_mock_0)

    sysctl_0 = {'hw.model':'MacBookPro15,1'}

# Generated at 2022-06-24 21:48:52.223179
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Construct object
    float_0 = 3986.506
    darwin_hardware_0 = DarwinHardware(float_0)
    darwin_hardware_0.sysctl = {
        'kern.osrevision': '1570',
        'kern.osversion': '15.6.0',
        'hw.logicalcpu': '4',
        'hw.physicalcpu': '2',
        'hw.memsize': '16777216',
        'machdep.cpu.core_count': '2',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6600U CPU @ 2.60GHz',
    }

    # Assertions

# Generated at 2022-06-24 21:48:56.531009
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector(5323.384)
    assert darwin_hardware_collector_0._platform == 'Darwin'
    assert darwin_hardware_collector_0._fact_class == DarwinHardware

# Testing the fact that the class DarwinHardware will return the name of its platform correctly

# Generated at 2022-06-24 21:49:06.771631
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = dict()
    # darwin_hardware_0.sysctl['kern.osversion'] # Implicitly tested by get_mac_facts
    # darwin_hardware_0.sysctl['kern.osrevision'] # Implicitly tested by get_mac_facts
    # darwin_hardware_0.sysctl['machdep.cpu.brand_string'] # Implicitly tested by get_cpu_facts
    # darwin_hardware_0.sysctl['machdep.cpu.core_count'] # Implicitly tested by get_cpu_facts
    # darwin_hardware_0.sysctl['hw.physicalcpu'] # Implicitly tested by get_cpu_facts
   

# Generated at 2022-06-24 21:49:13.984487
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    float_0 = 5323.384
    darwin_hardware_collector_0 = DarwinHardwareCollector(float_0)

    darwin_hardware_0 = DarwinHardware('/usr/bin/python2.7', mock_obj=True)
    result_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:49:24.375471
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = -1696
    darwin_hardware_0 = DarwinHardware(int_0)

    # Run the method with a good parameter
    get_sysctl_0 = get_sysctl(darwin_hardware_0.module, ['hw', 'machdep', 'kern'])
    rc, out, err = darwin_hardware_0.module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    system_profile = dict()
    for line in out.splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)
            system_profile[key.strip()] = ' '.join(value.strip().split())

    # Compare the result

# Generated at 2022-06-24 21:49:29.901830
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Assigning kern.boottime to a literal for test purposes.
    kern_boottime = 1550243701
    # Test is expected to pass if the actual and expected uptime_seconds values match.
    darwin_hardware_0 = DarwinHardware(0)
    darwin_hardware_0.get_uptime_facts(kern_boottime)

test_DarwinHardware_get_uptime_facts()


# Generated at 2022-06-24 21:49:33.335166
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    float_0 = 5323.384
    float_1 = float_0
    darwin_hardware_0 = DarwinHardware(float_1)
    darwin_hardware_0.module.run_command = run_command_mock
    darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:49:50.469404
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    setattr(get_sysctl, 'cache', {'kern.boottime': '1508237954.907907000'})
    current_time = int(time.time())
    expected_uptime = current_time - 1508237954
    darwin_hardware_2 = DarwinHardware()
    value = darwin_hardware_2.get_uptime_facts()
    assert value == {'uptime_seconds': expected_uptime}, "get_uptime_facts method returned an unexpected result"

if __name__ == '__main__':
    test_case_0()
    test_DarwinHardware_get_uptime_facts()

# Generated at 2022-06-24 21:50:01.104252
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz', 'machdep.cpu.core_count': 4}
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert isinstance(cpu_facts, dict)
    assert cpu_facts == {'processor': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz', 'processor_cores': 4, 'processor_vcpus': ''}


# Generated at 2022-06-24 21:50:04.827066
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.get_cpu_facts()


# Generated at 2022-06-24 21:50:06.121809
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    obj = DarwinHardware()
    obj.get_uptime_facts()

# Generated at 2022-06-24 21:50:07.788534
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()

# Generated at 2022-06-24 21:50:09.881840
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware = DarwinHardware()
    mac_facts = darwin_hardware.get_mac_facts()
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts


# Generated at 2022-06-24 21:50:11.818768
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    darwin_hardware.get_system_profile()


# Generated at 2022-06-24 21:50:13.129158
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()

# Generated at 2022-06-24 21:50:18.815663
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'machdep.cpu.brand_string': 'QEMU Virtual CPU version 2.3.0'}
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'QEMU Virtual CPU version 2.3.0'


# Generated at 2022-06-24 21:50:28.338224
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    rc, out, err = darwin_hardware_0.module.run_command("sysctl hw.model")
    if rc == 0:
        mac_facts = {}
        mac_facts['model'] = mac_facts['product_name'] = out.splitlines()[-1].split()[1]
        mac_facts['osversion'] = darwin_hardware_0.sysctl['kern.osversion']
        mac_facts['osrevision'] = darwin_hardware_0.sysctl['kern.osrevision']
        return True
    else:
        return False


# Generated at 2022-06-24 21:50:58.201167
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware(module=None)
    darwin_hardware_0._module = MockModule()
    darwin_hardware_0._module.run_command = Mock()
    darwin_hardware_0._module.run_command.return_value = (0, 'Pages free:                                18162.', '')

    assert darwin_hardware_0.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}



# Generated at 2022-06-24 21:51:02.008867
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    cpu_facts = darwin_hardware_0.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-3667U CPU @ 2.00GHz'
    assert cpu_facts['processor_vcpus'] == '2'
    assert cpu_facts['processor_cores'] == '2'


# Generated at 2022-06-24 21:51:02.998341
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()

# Generated at 2022-06-24 21:51:07.329627
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware = DarwinHardware()
    mac_facts = darwin_hardware.get_mac_facts()
    assert mac_facts["model"] == "MacBookAir6,2"
    assert mac_facts["osversion"] == "15.4.0"
    assert mac_facts["osrevision"] == "15F34"


# Generated at 2022-06-24 21:51:11.423205
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    cpu_facts = darwin_hardware.get_cpu_facts()


# Generated at 2022-06-24 21:51:16.231866
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'hw.memsize': '4', 'hw.physicalcpu': '5'}
    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts == {'memfree_mb': 0, 'memtotal_mb': 0}

# Generated at 2022-06-24 21:51:18.849259
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    uptime_facts = darwin_hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 0


# Generated at 2022-06-24 21:51:22.681776
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    os_uptime_seconds = time.time() - int(time.time())
    darwin_hardware = DarwinHardware()
    result = darwin_hardware.get_uptime_facts()
    assert result['uptime_seconds'] == os_uptime_seconds


# Generated at 2022-06-24 21:51:32.765697
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # create a mock module object
    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, 'hw.model: Power Macintosh', ''))

    mock_module = MockModule()

    # instantiate the module object
    darwin_hardware_0 = DarwinHardware(module=mock_module)

    # set the sysctl facts
    darwin_hardware_0.sysctl = {'kern.osversion': '1.2.3', 'kern.osrevision': '4.5.6'}

    # test the mac facts
    mac_facts = darwin_hardware_0.get_mac_facts()
    assert mac_facts['model'] == 'Power'
    assert mac_facts['product_name'] == 'Power'
   

# Generated at 2022-06-24 21:51:45.394555
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {
        'hw.memsize': '10000000000',
        'hw.model': 'x86_64',
        'hw.physicalcpu': '2',
        'kern.osrevision': '623.7.10',
        'kern.osversion': '15.7.0',
        'kern.version': 'Darwin Kernel Version 15.7.0: Thu Jun 23 18:25:34 PDT 2016; root:xnu-3248.70.11~1/RELEASE_X86_64'
        }

# Generated at 2022-06-24 21:52:29.155142
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    obj = darwin_hardware.get_uptime_facts()
    assert type(obj) == dict

# Generated at 2022-06-24 21:52:38.109387
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {
        'hw.model': 'MacBookPro10,2',
        'kern.osversion': '15.6.0',
        'kern.osrevision': '1670.70.1',
    }

    expected = {
        'model': 'MacBookPro10,2',
        'product_name': 'MacBookPro10,2',
        'osversion': '15.6.0',
        'osrevision': '1670.70.1',
    }

    actual = darwin_hardware_0.get_mac_facts()

    assert actual == expected


# Generated at 2022-06-24 21:52:47.919830
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    darwin_hardware_1 = DarwinHardware()
    # Test with good input
    rc, out, err = darwin_hardware_1.module.run_command(["/usr/bin/vm_stat"])
    if rc != 0:
        return dict()
    memory_stats = dict()
    for line in out.splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)
            memory_stats[key.strip()] = ' '.join(value.strip().split())
    page_size = 4096
    total_used = 0
    if memory_stats.get("Pages wired down"):
        total_used += int(memory_stats["Pages wired down"]) * page_size

# Generated at 2022-06-24 21:52:51.553032
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    assert darwin_hardware.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1574082644)}


# Generated at 2022-06-24 21:52:52.533573
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()

# Generated at 2022-06-24 21:52:56.090921
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    assert darwin_hardware_0.get_memory_facts().get('memtotal_mb') is not None
    assert darwin_hardware_0.get_memory_facts().get('memfree_mb') is not None


# Generated at 2022-06-24 21:52:58.283854
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_1 = DarwinHardware()
    uptime_facts = darwin_hardware_1.get_uptime_facts()



# Generated at 2022-06-24 21:52:59.439754
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()

# Generated at 2022-06-24 21:53:03.009770
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    result = darwin_hardware_0.get_uptime_facts()
    expected_result = {'uptime_seconds': result['uptime_seconds']}
    assert result == expected_result

# Generated at 2022-06-24 21:53:11.489588
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hw = DarwinHardware()
    sysctl_cmd = darwin_hw.module.get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'kern.boottime']

    # We need to get raw bytes, not UTF-8.
    rc, out, err = darwin_hw.module.run_command(cmd, encoding=None)

    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if rc != 0 or len(out) < struct_size:
        return {}


# Generated at 2022-06-24 21:55:11.937046
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import os
    import tempfile
    dummy_boottime_file = tempfile.mkstemp(text=True)[1]
    with open(dummy_boottime_file, mode='w') as dummy_boottime:
        dummy_boottime.write('kern.boottime: { sec = 1588947549, usec = 477658 } Thu Apr  9 21:25:49 2020\n')
    os.environ['PATH'] += ':%s' % os.path.dirname(os.path.realpath(__file__))
    darwin_hardware_1 = DarwinHardware()
    darwin_hardware_1.sysctl = get_sysctl(darwin_hardware_1.module, ['hw', 'machdep', 'kern'])
    darwin_hardware_1.get

# Generated at 2022-06-24 21:55:13.510283
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    assert darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:55:15.233716
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.get_cpu_facts()


# Generated at 2022-06-24 21:55:23.189590
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    #Arrange
    class MockModule(object):
        def __init__(self):
            self.run_command = Mock_run_command()
    class Mock_run_command(object):
        def __init__(self):
            self.counter = 0
        def __call__(self, *args, **kwargs):
            if(self.counter == 0):
                self.counter += 1
                return (0, "hw.model: Intel(R) Core(TM) i5-5250U CPU @ 1.60GHz", "")
            else:
                return (0, "machdep.cpu.brand_string: Intel(R) Core(TM) i5-5250U CPU @ 1.60GHz\nmachdep.cpu.core_count: 2", "")


# Generated at 2022-06-24 21:55:28.559430
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # It is not clear how we can reliably simulate an error from sysctl hw.model.
    # For now, test just the happy path.
    darwin_hardware = DarwinHardware()
    mac_facts = darwin_hardware.get_mac_facts()
    assert mac_facts["osversion"] == "19.6.0"
    assert mac_facts["osrevision"] == "1119062"
    assert mac_facts["model"] == "iMac11,2"
    assert mac_facts["product_name"] == "iMac11,2"


# Generated at 2022-06-24 21:55:34.619475
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test of Mac OS X machine with Intel CPU
    mac_os_x_machine = dict(sysctl={'hw.memsize': 5739687936, 'hw.physicalcpu': 1, 'hw.logicalcpu': 2, 'machdep.cpu.core_count': 2})
    mac_os_x_machine['sysctl']['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i5-5287U CPU @ 2.90GHz'
    mac_os_x_machine_0 = DarwinHardware(module=None, collected_facts=mac_os_x_machine)
    result_0 = mac_os_x_machine_0.get_cpu_facts()

# Generated at 2022-06-24 21:55:45.186856
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_1 = DarwinHardware()
    darwin_hardware_1._module.get_bin_path = lambda x: 'test/fixtures/bin/sysctl'
    darwin_hardware_1._module.run_command = lambda x, encoding=None: (0, b'123456789\x00\x00\x00\x00\x00\x00\x00\x00', '')
    darwin_hardware_1._module.time.time = lambda: 1234567890

    darwin_hardware_2 = DarwinHardware()
    darwin_hardware_2._module.get_bin_path = lambda x: 'test/fixtures/bin/sysctl'

# Generated at 2022-06-24 21:55:47.821403
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_get_cpu_facts = DarwinHardware()
    cpu_facts = darwin_hardware_get_cpu_facts.get_cpu_facts()
    assert cpu_facts


# Generated at 2022-06-24 21:55:49.687484
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # darwin_hardware = DarwinHardware()
    # assert darwin_hardware.get_uptime_facts() == {}
    pass

# Generated at 2022-06-24 21:55:56.421563
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz',
        'machdep.cpu.core_count': 2,
        'hw.model': 'MacBookPro12,1',
        'hw.physmem': 4123123,
        'kern.osversion': '17.4.0',
        'kern.osrevision': '15E65'
    }
    expected = {
        'osversion': '17.4.0',
        'osrevision': '15E65',
        'model': 'MacBookPro12,1'
    }
    assert darwin_hardware.get_mac_facts() == expected

# Generated at 2022-06-24 21:58:05.305651
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bytes_0 = b'\xa7'
    list_0 = [bytes_0]
    darwin_hardware_0 = DarwinHardware(list_0, bytes_0)
    var_0 = darwin_hardware_0.get_cpu_facts()
    assert var_0 == None


# Generated at 2022-06-24 21:58:06.389845
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    print('Running unit test for method get_cpu_facts of class DarwinHardware')

    # Test case #0
    test_case_0()

# Generated at 2022-06-24 21:58:09.571004
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bytes_0 = b'\n'
    list_0 = [bytes_0]
    darwin_hardware_0 = DarwinHardware(list_0, bytes_0)
    var_0 = darwin_hardware_0.get_cpu_facts()
