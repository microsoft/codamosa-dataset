

# Generated at 2022-06-24 21:48:33.553861
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import platform
    import socket
    import struct
    import sys
    import time

    os_name = platform.system()
    arch = platform.machine()
    system = platform.system()
    release = platform.release()
    mac_version = platform.mac_ver()

    kern_boottime = int(time.time()) - 531
    raw_kern_boottime = struct.pack('@L', kern_boottime)


# Generated at 2022-06-24 21:48:40.934029
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    sp_hw_data_type = """Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro14,2
      Processor Name: Intel Core i5
      Processor Speed: 2.5 GHz
      Number of Processors: 1
      Total Number of Cores: 2
      L2 Cache (per Core): 256 KB
      L3 Cache: 4 MB
      Hyper-Threading Technology: Enabled
      Memory: 16 GB
      Boot ROM Version: MBP142.0167.B07
      SMC Version (system): 2.46f1
      Serial Number (system): YMXXXXXXXXXX
      Hardware UUID: XXXX-XXXX-XXXX-XXXX
      """

# Generated at 2022-06-24 21:48:49.320703
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '1510', 'hw.model': 'Macmini7,1'}
    mac_facts = darwin_hardware_0.get_mac_facts()
    assert mac_facts == {'osversion': '16.7.0', 'osrevision': '1510', 'model': 'Macmini7,1', 'product_name': 'Macmini7,1'}


# Generated at 2022-06-24 21:48:55.374272
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    # Object initialization
    darwin_hardware_0 = DarwinHardware()

    # Test attributes of object darwin_hardware_0
    assert darwin_hardware_0.platform == 'Darwin'

    # Test method get_memory_facts() of object darwin_hardware_0
    darwin_hardware_0.get_memory_facts()



# Generated at 2022-06-24 21:49:06.070910
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Set up mock fact instance
    mock_facts = {"sysctl": {"kern.osversion": "15.6.0", "machdep.cpu.brand_string": "Intel(R) Core(TM) i7-3520M CPU @ 2.90GHz", "kern.osrevision": "15.6.0", "machdep.cpu.core_count": 4, "hw.physicalcpu": 2}}
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, "", "")
    mock_module_instance = DarwinHardware(mock_module)
    mock_module_instance.populate_sysctl_facts = MagicMock(return_value=mock_facts)

# Generated at 2022-06-24 21:49:13.600881
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert darwin_hardware_collector_0._fact_class == DarwinHardware, "The class must be 'DarwinHardware'"
    assert darwin_hardware_collector_0._platform == 'Darwin', "The platform must be 'Darwin'"

# Generated at 2022-06-24 21:49:17.395274
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()
    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0


# Generated at 2022-06-24 21:49:19.776924
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
  # Test a basic empty case
  test_system_profile_0 = DarwinHardware().get_system_profile()
  assert test_system_profile_0 == dict()

# Generated at 2022-06-24 21:49:24.445062
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert darwin_hardware_collector_0.platform == 'Darwin'
    assert isinstance(darwin_hardware_collector_0._fact_class, DarwinHardware)
    assert darwin_hardware_collector_0._platform == 'Darwin'


# Generated at 2022-06-24 21:49:33.202077
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test get_system_profile method of class DarwinHardware
    """
    darwin_hardware_0 = DarwinHardware()
    results = darwin_hardware_0.get_system_profile()
    assert u'Number of Processors' in results
    assert u'Processor Speed' in results
    assert u'Memory' in results
    assert u'Processor Name' in results
    assert u'Boot ROM Version' in results
    assert u'System Version' in results
    assert u'Serial Number (system)' in results
    assert u'Hardware UUID' in results
    assert u'SMC Version (system)' in results
    assert u'L2 Cache (per Core)' in results
    assert u'L3 Cache' in results
    assert u'Model Name' in results
    assert u'Time since boot' in results



# Generated at 2022-06-24 21:49:53.667920
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:49:58.002660
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware()
    collected_facts = {}
    darwin_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 21:50:04.038119
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardwareCollector()._fact_class()
    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-24 21:50:07.874132
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware(dict(), dict())
    darwin_hardware_uptime_facts = darwin_hardware.get_uptime_facts()
    assert 'uptime_seconds' in darwin_hardware_uptime_facts


# Generated at 2022-06-24 21:50:12.089838
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    assert darwin_hardware_0.get_mac_facts() == {'osversion': '15.6.0', 'model': 'MacBookPro', 'osrevision': '19G73'}


# Generated at 2022-06-24 21:50:17.320598
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert darwin_hardware_collector_0._fact_class == DarwinHardware
    assert darwin_hardware_collector_0._fact_subclasses == set()
    assert darwin_hardware_collector_0._platform == 'Darwin'
    assert darwin_hardware_collector_0._cached_sysctl is None


# Generated at 2022-06-24 21:50:23.161727
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'hw.memsize': '1073741824'}
    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-24 21:50:32.410447
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module.run_command = MagicMock(return_value=(0, 'hw.model: Apple iMac 14,2', ''))
    darwin_hardware_0.sysctl = {'kern.osversion': '14.0.0', 'kern.osrevision': '15C50'}
    assert darwin_hardware_0.get_mac_facts() == {'model': 'Apple iMac 14,2', 'osversion': '14.0.0', 'osrevision': '15C50'}


# Generated at 2022-06-24 21:50:40.645920
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware(module=None)
    darwin_hardware_0.populate()
    darwin_hardware_0.sysctl = {'machdep.cpu.core_count': '4', 'hw.memsize': '17179869184', 'hw.physicalcpu': '2', 'hw.logicalcpu': '4', 'kern.osversion': '16.7.0', 'kern.osrevision': '0'}
    darwin_hardware_0.populate()

# Generated at 2022-06-24 21:50:49.509023
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware({'module': mock.MagicMock()}, {})
    assert darwin_hardware_0.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}

    darwin_hardware_1 = DarwinHardware({'module': mock.MagicMock()}, {})
    darwin_hardware_1.module.run_command = mock.MagicMock(return_value=(0, '', ''))
    darwin_hardware_1.get_system_profile = mock.MagicMock(return_value={'Processor Name': '', 'Processor Speed': ''})
    assert darwin_hardware_1.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}

   

# Generated at 2022-06-24 21:51:19.435701
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = type('', (), {'run_command':
                                             lambda c, **m: (0,
                                                             "SPHardwareDataType:\n"
                                                             "  Version:                1\n"
                                                             "  Hardware:\n"
                                                             "    Hardware Overview:\n"
                                                             "      Model Name:          Mac Pro\n Processor Name:          Quad-"
                                                             "Core Intel Xeon\n Processor Speed:         2.66 GHz\n "
                                                             "                        "
                                                             "...", '')})

# Generated at 2022-06-24 21:51:24.221076
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    dh = DarwinHardware()
    uptime_facts = dh.get_uptime_facts()

    # Since there is no way to control the system's uptime, we can
    # only make very weak assertions.
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-24 21:51:25.784689
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():

    hardware = DarwinHardware()

    hardware.module.run_command = lambda args: (0, 'foo: bar\nbaz: quux', None)

    assert hardware.get_system_profile() == dict(foo='bar', baz='quux')


# Generated at 2022-06-24 21:51:29.019900
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = dict()
    darwin_hardware_0.sysctl['hw.memsize'] = '17179869184'
    result = darwin_hardware_0.get_memory_facts()
    assert {'memtotal_mb': 16384, 'memfree_mb': 0} == result


# Generated at 2022-06-24 21:51:30.530744
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware()
    assert hardware.get_system_profile() == dict()


# Generated at 2022-06-24 21:51:32.347095
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert('DarwinHardwareCollector' and 'Darwin' and 'DarwinHardware')



# Generated at 2022-06-24 21:51:38.225043
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    facts = {
        'uptime_seconds': 0,
    }

    darwin_hardware_0 = DarwinHardware({}, facts)
    uptime_facts = darwin_hardware_0.get_uptime_facts()

    assert uptime_facts == {'uptime_seconds': 0}


# Generated at 2022-06-24 21:51:42.181150
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardwareCollector().collect()[0]

    assert darwin_hardware.get_uptime_facts()['uptime_seconds'] > 0

# Generated at 2022-06-24 21:51:51.827037
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    sysctl_0 = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5200U CPU @ 2.20GHz', 'machdep.cpu.core_count': 4}
    sysctl_1 = {'hw.physicalcpu': 8, 'hw.logicalcpu': 4}
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = sysctl_0
    cpu_facts_0 = darwin_hardware_0.get_cpu_facts()
    assert cpu_facts_0['processor_cores'] == 4
    assert cpu_facts_0['processor_vcpus'] == '4'
    darwin_hardware_1 = DarwinHardware()
    darwin_hardware_1.sysctl = sysctl_

# Generated at 2022-06-24 21:52:02.991266
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_1 = DarwinHardware()
    darwin_hardware_2 = DarwinHardware()
    darwin_hardware_1.sysctl = { 'machdep.cpu.brand_string': 'Intel' }
    darwin_hardware_2.sysctl = {
        'machdep.cpu.core_count': 2,
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 8
    }
    cpu_facts_1 = darwin_hardware_1.get_cpu_facts()
    cpu_facts_2 = darwin_hardware_2.get_cpu_facts()
    assert(cpu_facts_1['processor'] == 'Intel')
    assert(cpu_facts_2['processor_cores'] == 2)

# Generated at 2022-06-24 21:52:27.858369
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_1 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:52:33.614098
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    set_1 = set()
    darwin_hardware_1 = DarwinHardware(set_1)
    var_1 = darwin_hardware_1.get_memory_facts()
    assert var_1


# Generated at 2022-06-24 21:52:36.160631
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:52:36.973708
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    test_case_0()


# Generated at 2022-06-24 21:52:46.317860
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)

    rc_0, out_0, err_0 = darwin_hardware_0.module.run_command("sysctl machdep.cpu.brand_string")
    if rc_0 == 0:
        darwin_hardware_0.sysctl['machdep.cpu.brand_string'] = out_0.splitlines()[-1].split()[1]
        darwin_hardware_0.sysctl['machdep.cpu.core_count'] = out_0.splitlines()[-1].split()[1]
    else:
        system_profile_0 = darwin_hardware_0.get_system_profile()

# Generated at 2022-06-24 21:52:49.849768
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:52:52.864881
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:52:55.079588
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_0 = darwin_hardware_0.get_system_profile()
    assert var_0 is not None


# Generated at 2022-06-24 21:52:56.915556
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    assert darwin_hardware.get_system_profile() is None


# Generated at 2022-06-24 21:52:59.968454
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    set_1 = set()
    darwin_hardware_0.sysctl = set_1
    var_1 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:53:56.100757
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_0 = darwin_hardware_0.get_system_profile()

    assert isinstance(var_0, dict) == True


# Generated at 2022-06-24 21:53:58.539430
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    set_0 = set()
    darwin_hardware_collector_0 = DarwinHardwareCollector(set_0)


# Generated at 2022-06-24 21:54:02.222417
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    set_1 = set()
    darwin_hardware_1 = DarwinHardware(set_1)
    
    # Call method
    rc_0 = darwin_hardware_1.get_memory_facts()
    
    # Test assertions
    assert (rc_0 == {'memtotal_mb': 8192, 'memfree_mb': 0}), "Test of method \"get_memory_facts\" failed"
    
    

# Generated at 2022-06-24 21:54:10.853766
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    darwin_hardware_0.sysctl = {'kern.osversion': '', 'kern.osrevision': '', 'hw.memsize': '', 'hw.physicalcpu': '', 'hw.ncpu': ''}
    darwin_hardware_0.sysctl = {'machdep.cpu.core_count': '', 'machdep.cpu.brand_string': '', 'hw.memsize': '', 'hw.physicalcpu': '', 'hw.logicalcpu': '', 'hw.ncpu': ''}

# Generated at 2022-06-24 21:54:13.126319
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:54:17.045537
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_0 = darwin_hardware_0.get_system_profile()
    # The call coverage for this function is 66.67%


# Generated at 2022-06-24 21:54:20.816285
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_0 = darwin_hardware_0.get_mac_facts()
    assert isinstance(var_0, dict)
    assert 'osversion' in var_0
    assert 'osrevision' in var_0


# Generated at 2022-06-24 21:54:25.207137
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)

# Generated at 2022-06-24 21:54:34.725489
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    darwin_hardware_0.module.run_command = MagicMock(return_value=(
        0,
        'kern.boottime: { sec = 1435852892, usec = 456875 } Sat Jun 27 18:08:12 2015',
        '',
    ))
    var_0 = darwin_hardware_0.get_uptime_facts()
    assert 'uptime_seconds' in var_0

if __name__ == '__main__':
    from ansible.module_utils.facts.hardware.darwin import *
    darwin_hardware = DarwinHardware({})
    result = darwin_hardware.populate()
    print(result)

# Generated at 2022-06-24 21:54:40.635129
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    darwin_hardware_0.sysctl = dict()
    darwin_hardware_0.sysctl['hw.physicalcpu'] = '1'
    darwin_hardware_0.get_cpu_facts()
    darwin_hardware_0.sysctl['machdep.cpu.brand_string'] = 'test_value'
    darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:56:51.167124
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    set_1 = set()
    darwin_hardware_1 = DarwinHardware(set_1)
    # TODO: implement test for get_mac_facts of class DarwinHardware
    pass


# Generated at 2022-06-24 21:56:55.843207
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    darwin_hardware_0.sysctl = dict()
    var_0 = darwin_hardware_0.get_system_profile()
    assert set(var_0.keys()) == set()
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 21:56:57.958784
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    assert darwin_hardware_0.get_system_profile() == {}


# Generated at 2022-06-24 21:57:04.293329
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    darwin_hardware_0.sysctl = dict()
    var_0 = darwin_hardware_0.get_cpu_facts()
    assert var_0['processor_cores'] == '2'
    assert var_0['processor_vcpus'] == ''
    assert var_0['processor'] == 'Intel(R) Core(TM) i5-5400U CPU @ 2.70GHz'


# Generated at 2022-06-24 21:57:08.223994
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    assert darwin_hardware_0.get_system_profile() == dict()


# Generated at 2022-06-24 21:57:11.465812
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:57:14.135956
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    set_1 = set()
    darwin_hardware_1 = DarwinHardware(set_1)
    var_1 = darwin_hardware_1.get_cpu_facts()
    assert var_1 != None


# Generated at 2022-06-24 21:57:16.797942
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    dict_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:57:18.924518
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:57:21.537971
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import math
    set_0 = set()
    darwin_hardware_0 = DarwinHardware(set_0)
    uptime_facts = darwin_hardware_0.get_uptime_facts()
    assert isinstance(uptime_facts['uptime_seconds'], int)