

# Generated at 2022-06-24 21:48:34.638509
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test case 0
    # Test fixture 0
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {
        'hw.logicalcpu': '2',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6920HQ CPU @ 2.90GHz',
        'machdep.cpu.core_count': '4',
    }

    # Test fixture 1
    darwin_hardware_1 = DarwinHardware()

# Generated at 2022-06-24 21:48:37.592114
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    print('test_DarwinHardwareCollector()')
    test_case_0()
    print('end of test_DarwinHardwareCollector()')


# Generated at 2022-06-24 21:48:42.167854
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Instantiate a DarwinHardware object
    darwin_hardware_object = DarwinHardware(module)

    # Call method get_cpu_facts of the darwin_hardware_object
    darwin_hardware_get_cpu_facts_output = darwin_hardware_object.get_cpu_facts()


# Generated at 2022-06-24 21:48:45.259065
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware(None)
    assert darwin_hardware_0.get_system_profile() == dict()


# Generated at 2022-06-24 21:48:55.260513
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import re
    import sys

    darwin_hardware = DarwinHardware()
    # case 0: test get_memory_facts
    # Input:
    #   cmd = "vm_stat"
    #   rc  = 0
    #   out = ""
    #   err = ""
    # Expected Result: Success
    cmd = "vm_stat"
    rc  = 0
    out = ""
    err = ""
    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts == {'memtotal_mb': 0, 'memfree_mb': 0}
    # case 1: test get_memory_facts
    # Input:
    #   cmd = "vm_stat"
    #   rc  = 0
    #   out = """
    #   Mach Virtual Memory Statistics: (page

# Generated at 2022-06-24 21:49:00.570019
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {
        'hw.memsize': '3879731200'
    }

    assert(darwin_hardware_0.get_memory_facts() == {
        'memtotal_mb': 3740,
        'memfree_mb': 3740
    })


# Generated at 2022-06-24 21:49:08.952230
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware(darwin_hardware_collector_1)
    assert darwin_hardware_0.populate() == {
        'osversion': '19.0.0',
        'osrevision': '15506',
        'memtotal_mb': 16384,
        'memfree_mb': 0,
        'uptime_seconds': 1493933793,
        'processor_cores': '4',
        'model': 'MacBookPro11,3',
        'product_name': 'MacBookPro11,3',
        'processor': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
        'processor_vcpus': '8',

    }


# Generated at 2022-06-24 21:49:12.734911
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert isinstance(system_profile, dict)


# Generated at 2022-06-24 21:49:17.031631
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware()
    # TODO: Add test for DarwinHardware.get_memory_facts()


# Generated at 2022-06-24 21:49:19.119935
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    res = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:49:33.954254
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:49:34.589843
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    test = DarwinHardwareCollector()


# Generated at 2022-06-24 21:49:38.166234
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_1 = DarwinHardware()
    result = darwin_hardware_1.get_mac_facts()
    assert isinstance(result, dict), "Method 'get_mac_facts' of class 'DarwinHardware' should return 'dict' instance."


# Generated at 2022-06-24 21:49:48.739894
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '20160708163400.0.0.0.1.0'}
    rc = 0
    out = 'hw.model: MacBookPro10,2\n'
    err = ''
    darwin_hardware.module.run_command = lambda x: (rc, out, err)
    assert darwin_hardware.get_mac_facts() == {'osversion': '16.7.0', 'osrevision': '20160708163400.0.0.0.1.0', 'model': 'MacBookPro10,2'}

    rc = 0
    out = ''

# Generated at 2022-06-24 21:49:53.454206
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    cpu_facts = darwin_hardware_0.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts


# Generated at 2022-06-24 21:49:54.983855
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()

# Generated at 2022-06-24 21:49:59.539032
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Hardcoded test case
    darwin_hardware_0 = DarwinHardware()

# Generated at 2022-06-24 21:50:03.985352
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware()

    # method called without sysctl populated
    hardware.sysctl = None
    hardware.get_cpu_facts()


# Generated at 2022-06-24 21:50:07.498816
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    collector = DarwinHardwareCollector()
    result = collector.get_cpu_facts()
    assert result['processor_cores'] > 0
    assert result['processor_vcpus'] > 0
    assert len(result['processor']) > 0


# Generated at 2022-06-24 21:50:09.409432
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    try:
        DarwinHardware_get_system_profile_ret = darwin_hardware_0.get_system_profile()
    except OSError:
        pass


# Generated at 2022-06-24 21:50:33.709794
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()

    result_dict0 = darwin_hardware.get_system_profile()
    result_dict1 = darwin_hardware.get_system_profile()

    assert result_dict0 == result_dict1


# Generated at 2022-06-24 21:50:41.554083
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    # The following line is not in upstream, but it is needed for the test to pass.
    darwin_hardware_0.module = AnsibleModule()
    # This test case should return a dictionary.
    expected = {
        'uptime_seconds': 0,
    }
    # This method should return a dictionary.
    actual = darwin_hardware_0.get_uptime_facts()
    assert actual != None
    # The contents of the dictionary returned by get_uptime_facts should be
    # checked here. As this method is called and tested by setUpClass we can't
    # use the assertEqual method here.
    print("test_DarwinHardware_get_uptime_facts:", actual)
    # The following line is not in upstream, but it is

# Generated at 2022-06-24 21:50:44.645669
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # darwin_hardware_1 is an object of class DarwinHardware
    darwin_hardware_1 = DarwinHardware()
    # Run method populate of class DarwinHardware
    darwin_hardware_1.populate()

# Generated at 2022-06-24 21:50:51.952220
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_get_cpu_facts_0 = DarwinHardware()
    try:
        darwin_hardware_get_cpu_facts_0.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Xeon(R) CPU E5-2697 v3 @ 2.60GHz'
        darwin_hardware_get_cpu_facts_0.sysctl['machdep.cpu.core_count'] = '32'
        darwin_hardware_get_cpu_facts_0.sysctl['hw.logicalcpu'] = '64'
        darwin_hardware_get_cpu_facts_0.get_cpu_facts()
    except NameError:
        pass


# Generated at 2022-06-24 21:50:55.654616
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()
    rc = darwin_hardware.get_cpu_facts()
    assert 'processor' in rc
    assert 'processor_cores' in rc
    assert 'processor_vcpus' in rc

# Generated at 2022-06-24 21:51:00.211685
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    darwin_hardware = DarwinHardware()
    darwin_hardware.module = AnsibleModuleMock()

    darwin_hardware.sysctl = {'hw.memsize': '16777216'}

    expected_output = {
        'memtotal_mb': 16,
        'memfree_mb': 0,
    }

    assert darwin_hardware.get_memory_facts() == expected_output



# Generated at 2022-06-24 21:51:03.556574
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'hw.memsize': 1073741824, 'hw.pagesize': 4096}
    darwin_hardware.module = ''
    darwin_hardware.get_bin_path = ''
    darwin_hardware.get_memory_facts()

# Generated at 2022-06-24 21:51:13.763896
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()
    # 4GB RAM
    darwin_hardware.sysctl = {'hw.memsize': '4294967296'}
    rc, out, err = darwin_hardware.module.run_command(['/usr/bin/vm_stat'], data='Mach Virtual Memory Statistics: (page size of 4096 bytes) Pages free:                              9693.\nPages active:                           65838.\n')
    facts = darwin_hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 4096
    assert facts['memfree_mb'] == 9695



# Generated at 2022-06-24 21:51:17.522162
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    uptime = DarwinHardware()
    uptime_facts = uptime.get_uptime_facts()
    assert isinstance(uptime_facts, dict)
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-24 21:51:28.649120
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    # Setting up the test cases
    darwin_memory_facts_0 = {'memtotal_mb': 2753, 'memfree_mb': 1837}

    # Testing the 1st test case
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'hw.memsize': '140733593600'}
    darwin_hardware.module = FakeModule()

# Generated at 2022-06-24 21:52:12.328519
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware() 
    darwin_hardware_0.populate()

# Generated at 2022-06-24 21:52:16.610448
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    out = darwin_hardware._get_system_profile()

    assert type(out) is dict
    for key in ['Memory', 'Processor Name', 'Processor Speed']:
        assert key in out


# Generated at 2022-06-24 21:52:19.862449
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()

    assert darwin_hardware.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}


# Generated at 2022-06-24 21:52:29.020081
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    t_DarwinHardware = DarwinHardware()
    t_DarwinHardware.module = ansible_fake_module
    t_DarwinHardware.module.run_command = fake_run_command
    t_DarwinHardware.sysctl = {
        'hw.model' : 'MacPro4,1',
        'kern.osversion' : '19.6.0',
        'kern.osrevision' : '15G1108',
    }

    expected = {
        'model' : 'MacPro4,1',
        'osversion' : '19.6.0',
        'osrevision' : '15G1108',
    }
    actual = t_DarwinHardware.get_mac_facts()
    assert actual == expected


# Generated at 2022-06-24 21:52:32.681646
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()


if __name__ == '__main__':
    test_case_0()
    test_DarwinHardwareCollector()

# Generated at 2022-06-24 21:52:35.155469
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.populate()
    darwin_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 21:52:37.493996
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    assert darwin_hardware.get_uptime_facts()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:52:43.170720
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'hw.memsize': '92274688',
                              'hw.pagesize': '4096'}
    # sysctl hw.memsize returns bytes
    # divide by 1024 to get kb
    # divide by 1024 again to get mb
    assert darwin_hardware.get_memory_facts() == {'memtotal_mb': 88, 'memfree_mb': 0}


# Generated at 2022-06-24 21:52:48.166618
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {'hw.memsize': '123', 'kern.osversion': '4.0', 'kern.osrevision': '5.0'}
    darwin_hardware_0.get_mac_facts()



# Generated at 2022-06-24 21:52:55.825785
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_1 = DarwinHardware()
    darwin_hardware_1.module.run_command.return_value = (0, b'{ kern.boottime: { sec = 1456616342, usec = 669536 } }', b'')
    assert darwin_hardware_1.get_uptime_facts() == { 'uptime_seconds': 1456616342 }
    assert darwin_hardware_1.module.run_command.call_args[0][0] == ['sysctl', '-b', 'kern.boottime']


# Generated at 2022-06-24 21:54:43.784179
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware()

# Generated at 2022-06-24 21:54:44.503795
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()


# Generated at 2022-06-24 21:54:48.106056
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    rc = darwin_hardware_0.get_system_profile()
    assert rc


# Generated at 2022-06-24 21:54:51.688240
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware = DarwinHardware()
    output = darwin_hardware.get_mac_facts()
    assert output['model'] == 'MacBookAir7,2'
    assert output['osversion'] == '16.7.0'
    assert output['osrevision'] == '201607091927'


# Generated at 2022-06-24 21:54:54.694015
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    fact_class = darwin_hardware_collector.fact_class
    platform = darwin_hardware_collector.platform

# Generated at 2022-06-24 21:55:02.605504
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware = DarwinHardware()

    rc, out, err = darwin_hardware.module.run_command("sysctl hw.model")
    darwin_hardware.sysctl['kern.osversion'] = '11.4.2'
    darwin_hardware.sysctl['kern.osrevision'] = '15E65'
    darwin_hardware.module.run_command = Mock(return_value=(0, out, None))
    darwin_hardware.module.run_command = Mock(return_value=(0, None, None))

    platform = darwin_hardware.get_mac_facts()
    assert platform['model'] == 'MacBook4,1'
    assert platform['osversion'] == '11.4.2'

# Generated at 2022-06-24 21:55:08.942593
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    cpu_facts = darwin_hardware_0.get_cpu_facts()
    cpu_facts_keys = cpu_facts.keys()
    cpu_facts_keys.sort()
    assert cpu_facts_keys == ['processor', 'processor_cores', 'processor_vcpus']


# Generated at 2022-06-24 21:55:10.665360
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    cpu_facts = darwin_hardware_0.get_cpu_facts()
    print(cpu_facts)


# Generated at 2022-06-24 21:55:17.304112
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
     # In this test we changed the value of sysctl to simulate the call of 
     # the get_sysctl method. The get_sysctl method takes the output of a call of
     # the sysctl command. But in our case we want to focus only on the get_cpu_facts
     # method: that's why we mocked the call of get_sysctl.

    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz',
        'machdep.cpu.core_count': '8'
    }
    cpu_facts_Intel = darwin_hardware.get_cpu_facts()

# Generated at 2022-06-24 21:55:18.165469
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    assert DarwinHardware().get_uptime_facts() is not None
