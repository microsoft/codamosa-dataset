

# Generated at 2022-06-24 21:48:21.415556
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:48:23.565808
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 21:48:27.814577
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    assert('uptime_seconds' in darwin_hardware.get_uptime_facts())
    assert(darwin_hardware.get_uptime_facts()['uptime_seconds'] > 0)

# Generated at 2022-06-24 21:48:31.249337
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    hardware = DarwinHardware()
    uptime_facts = hardware.get_uptime_facts()
    # "uptime_seconds" is the only field we care about
    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-24 21:48:36.123594
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware(module=None, collected_facts={})
    darwin_hardware._facts = {}
    darwin_hardware._facts['sysctl'] = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz', 'hw.ncpu': '4', 'hw.physicalcpu': '2'}
    darwin_hardware._facts['system_profile'] = None
    expected = {'processor': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz', 'processor_cores': '2', 'processor_vcpus': '4'}
    results = darwin_hardware.get_cpu_facts()
    assert_equals(expected, results)

# Unit

# Generated at 2022-06-24 21:48:39.360618
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware()
    hardware.get_memory_facts()
    hardware.get_memory_facts()
    hardware.get_memory_facts()
    hardware.get_memory_facts()


# Generated at 2022-06-24 21:48:42.229649
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware()
    collected_facts_0 = dict()
    darwin_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 21:48:45.753649
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert darwin_hardware_collector_0._fact_class.platform=='Darwin'
    assert darwin_hardware_collector_0._platform=='Darwin'

# Generated at 2022-06-24 21:48:49.583201
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    assert darwin_hardware_collector_1._fact_class is DarwinHardware
    assert darwin_hardware_collector_1._platform is 'Darwin'


# Generated at 2022-06-24 21:48:51.111061
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class_inst = DarwinHardware()
    r = class_inst.get_system_profile()


# Generated at 2022-06-24 21:49:03.081587
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    return


# Generated at 2022-06-24 21:49:08.079134
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_mac_facts()
    assert var_0 == {'osrevision': '15000422', 'osversion': '16.7.0', 'model': 'MacBookPro11,2'}


# Generated at 2022-06-24 21:49:12.328857
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    int_0 = 9
    str_0 = '*fq<3dx'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.populate()
    var_1 = darwin_hardware_0.get_cpu_facts()
    assert var_1 == None
    var_2 = str(var_1.get('processor_cores'))
    assert var_2 == 'b\'@F{w'


# Generated at 2022-06-24 21:49:22.559003
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.module = Mock()
    mock_module_0 = darwin_hardware_0.module
    mock_module_0.run_command.return_value = (int_0, str_0, str_0)
    mock_module_0.get_bin_path.return_value = str_0
    # TODO: Test fails due to wrong test data
    assert darwin_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 21:49:27.615896
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Initialize the object
    str_0 = 'mv=C'
    darwin_hardware_0 = DarwinHardware(str_0)
    # Get the result
    result = darwin_hardware_0.get_uptime_facts()
    # Test
    assert result.get('uptime_seconds') == None
    # Test
    assert result == {}


# Generated at 2022-06-24 21:49:28.863266
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Test with missing arguments.

    # Test with extra arguments.
    pass

# Generated at 2022-06-24 21:49:30.574292
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():

    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert isinstance(darwin_hardware_collector_0, DarwinHardwareCollector) # check if created instance is of instance of DarwinHardwareCollector


# Generated at 2022-06-24 21:49:36.324884
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    str_0 = 'R;=`'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.platform = '\x15'
    darwin_hardware_0.sysctl = dict()
    darwin_hardware_0.sysctl['machdep.cpu.brand_string'] = '<u?$'
    darwin_hardware_0.sysctl['machdep.cpu.core_count'] = 6
    var_0 = darwin_hardware_0.get_cpu_facts()
    assert(var_0 == {'processor_cores': 6, 'processor': '<u?$'})


# Generated at 2022-06-24 21:49:41.066547
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    kwargs = dict()
    kwargs['memtotal_mb'] = 1
    kwargs['memfree_mb'] = 2
    darwin_hardware_0 = DarwinHardware(**kwargs)
    darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:49:44.662437
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:50:11.238356
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    # call method
    var_1 = darwin_hardware_0.get_mac_facts()
    # if statement
    if int_0 < 522:
        int_1 = -522
    else:
        int_1 = 522
    # for statement
    for i in range(int_1):
        int_2 = 522
        int_3 = 522
        int_3 = int_2 * int_3
        int_2 = -522
        int_3 = int_3 / int_2
    # for statement
    for i in range(int_1):
        int_4 = 522
        int_4 = int_4 * int

# Generated at 2022-06-24 21:50:15.193015
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:50:18.624078
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 21:50:23.316036
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    int_0 = 208
    str_0 = '{(^T'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:50:26.954292
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    str_0 = 'iRn'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_system_profile(0)



# Generated at 2022-06-24 21:50:30.314690
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.populate()


# Generated at 2022-06-24 21:50:33.834776
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:50:41.608663
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.sysctl = mock.Mock(spec_set=dict)
    darwin_hardware_0.sysctl.items = mock.MagicMock(return_value=set([]))
    darwin_hardware_0.module.run_command = mock.MagicMock(return_value=(0, '10', ''))

    # Call method
    cpu_facts = darwin_hardware_0.get_cpu_facts()
    assert cpu_facts['processor'] == 'Core i7'
    assert cpu_facts['processor_cores'] == 10
    assert cpu_facts['processor_vcpus'] == ''


#

# Generated at 2022-06-24 21:50:45.063594
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    # get_uptime_facts is a static method.
    # Add an extra argument, module, to its signature.
    darwin_hardware_1 = DarwinHardware('')
    var_1 = darwin_hardware_1.get_uptime_facts()



# Generated at 2022-06-24 21:50:46.160776
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    pass


# Generated at 2022-06-24 21:51:33.459990
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    int_0 = 67
    str_0 = 'o*CKC'
    str_1 = 'o<QQ_J'
    str_2 = '|}L0'
    str_3 = 'QwB`'
    str_4 = 'yNJB'
    str_5 = 'B>zN'
    str_6 = 'B>zN'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.module = MagicMock(name='module')
    darwin_hardware_0.get_system_profile = MagicMock(return_value={str_1: int_0, str_2: str_3})
    dict_0 = darwin_hardware_0.get_memory_facts()
    int_1 = dict

# Generated at 2022-06-24 21:51:45.555540
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a new instance of 'DarwinHardware'
    obj = DarwinHardware()
    # Create a new instance of 'MockModule'
    class_dict = {'get_bin_path': test_DarwinHardware_get_uptime_facts.get_bin_path, 'run_command': test_DarwinHardware_get_uptime_facts.run_command}
    mock_module = MockModule()
    mock_module.set_class('DarwinHardware', class_dict)
    obj.module = mock_module

    # Call method
    out = obj.get_uptime_facts()

    # Check for correct return type
    assert isinstance(out, dict)
    # Check for correct return value
    assert out == {u'uptime_seconds': 2}


# Generated at 2022-06-24 21:51:47.226899
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'jb'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:51:50.716765
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    vm_stat_command_0 = '/sbin/vm_stat'
    _, _, err = darwin_hardware_0.module.run_command(vm_stat_command_0)
    assert (var_0 == '1077')


# Generated at 2022-06-24 21:51:59.347902
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = 169
    str_0 = 'Ej.-m'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.module = Mock()
    with patch('ansible.module_utils.facts.hardware.darwin.DarwinHardware.get_system_profile', new_callable=Mock) as mocked_DarwinHardware_get_system_profile:
        darwin_hardware_0.get_system_profile()
        mocked_DarwinHardware_get_system_profile.assert_called_with()


# Generated at 2022-06-24 21:52:02.246317
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware(str_0)
    assert not darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:52:07.664607
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    int_0 = 1
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = cursor(int_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:52:12.404539
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    str_1 = 'hw.memsize'
    dict_0 = {'hw.memsize': 1024}
    darwin_hardware_0.get_memory_facts(dict_0, str_1)


# Generated at 2022-06-24 21:52:16.324752
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.populate()


# Generated at 2022-06-24 21:52:27.133360
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = 522
    str_0 = 'guA=0-'
    # darwin_hardware_0 => U0+{'tYaA9X-': 0.0, 'T(dLsA-': 1.0, 'd': 0.0, 'Y{': 58.0, '8': 9.0, 'm=': 76.0, 'z)': 0.0, '6': 90.0, 'dD': 56.0, 'J5': 58.0, ':': 9.0, '@': 'bS^', 'A': 0.0, '+': 'k4', '_': 130.0, '8B': 37.0, '#': 53.0, 'p': 38.0, '-k': '!', 'q': 9.0, '*': 'f',

# Generated at 2022-06-24 21:54:11.950403
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    int_0 = 735
    str_0 = 'g~(Fz'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:54:14.914858
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    str_0 = 'dJ'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:54:15.577119
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    pass


# Generated at 2022-06-24 21:54:17.943514
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_1 = DarwinHardware(str_0)
    var_0 = darwin_hardware_1.get_memory_facts()


# Generated at 2022-06-24 21:54:21.005086
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:54:24.330165
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    tmp_str_0 = 'hx'
    darwin_hardware_0 = DarwinHardware(tmp_str_0)
    tmp_dict_0 = darwin_hardware_0.get_system_profile()
    print(tmp_dict_0)


# Generated at 2022-06-24 21:54:27.812732
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    int_0 = 264
    str_0 = 'Yb3q}6U1'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:54:31.230773
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    str_0 = 'X'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:54:34.320136
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = 522
    str_0 = 'guA=0-'
    darwin_hardware_0 = DarwinHardware(str_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:54:37.407177
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    int_2 = 3
    darwin_hardware_collector_0 = DarwinHardwareCollector(int_2)

    assert darwin_hardware_collector_0.platform == 'Darwin'
    assert darwin_hardware_collector_0._fact_class == DarwinHardware
