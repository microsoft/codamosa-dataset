

# Generated at 2022-06-24 21:48:23.690555
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:48:27.046074
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    assert darwin_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 21:48:31.070546
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    dict_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:48:39.112784
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()
    hardware = DarwinHardware(module)
    module.get_bin_path.return_value = 'system_profiler'

# Generated at 2022-06-24 21:48:41.314186
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Run test of method get_mac_facts of class DarwinHardware
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)

    out = darwin_hardware_0.get_mac_facts()

    assert out is not None


# Generated at 2022-06-24 21:48:51.668272
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    sysctl = {
        'kern.boottime': 1548107574,
        'hw.memsize': 1073741824,
        'hw.ncpu': 4,
        'hw.physicalcpu': 2,
        'kern.osversion': '16.0.0',
        'kern.osrevision': '341100010'
    }
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, json.dumps(sysctl), None)
    mock_module.get_bin_path.return_value = '/usr/sbin/vm_stat'
    darwin_hardware_collector_0 = DarwinHardwareCollector(mock_module)
    darwin_hardware_collector_0.collect()
    darwin_hard

# Generated at 2022-06-24 21:48:54.515391
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    print("In method get_memory_facts")

    tuple_0 = ()


# Generated at 2022-06-24 21:49:02.204852
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    # Get function by name
    function_name = 'get_uptime_facts'
    code_object = getattr(DarwinHardware, function_name)

    # Construct class
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)

    # Call function
    argument_count = 0
    argument_list = []
    argument_tuple = ()

    return_value = code_object(darwin_hardware_0, *argument_tuple)
    assert return_value == {}


# Generated at 2022-06-24 21:49:07.342605
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    dict_0 = {}
    dict_0.update(("foo", "bar"))
    dict_0.update(("baz", "biz"))
    dict_1 = {}
    dict_0.update(("boo", "far"))
    dict_0.update(("buz", "biz"))
    dict_2 = {}
    dict_0.update(("foo", "baz"))
    dict_0.update(("boo", "far"))
    dict_0.update(("baz", "biz"))
    dict_0.update(("buz", "biz"))
    dict_0.update(("foo", "bar"))
    dict_3 = {}

# Generated at 2022-06-24 21:49:12.444584
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:49:34.417238
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware()
    # Set to None to make it always run.
    if 0:
        darwin_hardware_0.module = None
    if 0:
        darwin_hardware_0.sysctl = None
    assert darwin_hardware_0.populate() is not None


# Generated at 2022-06-24 21:49:36.865862
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_collector_1 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:49:47.800387
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # unit test for DarwinHardware.get_memory_facts()
    # no memory is used and no memory is free
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {
        "hw.memsize": "4294967296",
        "hw.pagesize": "4096",
    }
    mem_facts = darwin_hardware_0.get_memory_facts()
    assert mem_facts == {'memfree_mb': 4096, 'memtotal_mb': 4096}

    # some memory is used and free
    darwin_hardware_1 = DarwinHardware()
    darwin_hardware_1.sysctl = {
        "hw.memsize": "4294967296",
        "hw.pagesize": "4096",
    }


# Generated at 2022-06-24 21:49:54.719578
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0._module.run_command = lambda x: (0, 'Machine Name: foo\nCPU Type: bar\nCPU Speed: 2.2 GHz\nMemory: 2.1\n', 1)
    assert darwin_hardware_0.get_system_profile() == {'CPU Speed': '2.2 GHz', 'Machine Name': 'foo', 'CPU Type': 'bar', 'Memory': '2.1'}


# Generated at 2022-06-24 21:49:59.636742
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware({'module': FakeAnsibleModule()})
    assert darwin_hardware.get_system_profile()


# Generated at 2022-06-24 21:50:01.498323
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    assert darwin_hardware.get_uptime_facts()


# Generated at 2022-06-24 21:50:11.718616
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0_obj = DarwinHardware()

# Generated at 2022-06-24 21:50:12.629894
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    DarwinHardware().populate()


# Generated at 2022-06-24 21:50:24.450899
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform in ['Darwin']
    assert darwin_hardware_collector.hardware_collector_class_list == [DarwinHardwareCollector]
    assert darwin_hardware_collector.fact_class.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class.get_cpu_facts() == {'processor': 'Intel(R) Core(TM) i7-6600U CPU @ 2.60GHz', 'processor_cores': 4, 'processor_vcpus': 8}

# Generated at 2022-06-24 21:50:28.245330
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(
        argument_spec = dict(
            filter = dict(default='', required=False),
        ),
        supports_check_mode=True
    )

    darwin_hardware_0 = DarwinHardware(module)
    darwin_hardware_0.populate()


# Generated at 2022-06-24 21:50:55.214055
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_instance_0 = DarwinHardware()
    darwin_hardware_instance_0.sysctl = dict()
    darwin_hardware_instance_0.module = None

    assert 'processor' in darwin_hardware_instance_0.get_cpu_facts()


# Generated at 2022-06-24 21:51:02.326874
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()

# Generated at 2022-06-24 21:51:03.032252
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    DarwinHardware().get_mac_facts()

# Generated at 2022-06-24 21:51:04.655928
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mac_facts = DarwinHardware()
    mac_facts.get_system_profile()


# Generated at 2022-06-24 21:51:07.288452
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()

    assert darwin_hardware_collector.__class__.__name__ == 'DarwinHardwareCollector'


# Generated at 2022-06-24 21:51:17.437457
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware_facts = DarwinHardware()
    hardware_facts.module = AnsibleModule
    hardware_facts.populate()
    assert hardware_facts.processor == "Intel(R) Core(TM) i5-5287U CPU @ 2.90GHz"
    assert hardware_facts.processor_cores == 4
    assert hardware_facts.processor_vcpus == 4
    assert hardware_facts.memtotal_mb == 8192
    assert hardware_facts.memfree_mb == 2495
    assert hardware_facts.model == "MacBookPro11,5"
    assert hardware_facts.osversion == "19C57"
    assert hardware_facts.osrevision == "0"


# Generated at 2022-06-24 21:51:19.168992
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    test_DarwinHardware = DarwinHardware(module)
    test_DarwinHardware.get_uptime_facts()


# Generated at 2022-06-24 21:51:21.237659
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.populate()


# Generated at 2022-06-24 21:51:27.943149
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Initialization
    dh = DarwinHardware()

    # Testing
    dh.module.run_command = lambda x: (0, 'Serial Number (system): C07L807N4N4H', '')
    system_profile = dh.get_system_profile()
    assert system_profile['Serial Number (system)'] == 'C07L807N4N4H'


# Generated at 2022-06-24 21:51:38.545612
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware_0 = DarwinHardware()
    hardware_0.module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    hardware_0.module.run_command = mocked_run_command
    hardware_0.module.run_command.return_value = (0, "hw.model: x86_64\nhw.model: x86_64", "")

    darwin_hardware_collector_0 = DarwinHardwareCollector()

    ret_val_0 = hardware_0.get_mac_facts()

    if 0 == ret_val_0:
        print("test get_mac_facts of class DarwinHardware failed")
        exit(1)
    if 1 == ret_val_0:
        print("test get_mac_facts of class DarwinHardware passed")

# Generated at 2022-06-24 21:52:26.300708
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    cpu_facts = {
        'processor_cores': '2',
        'processor': 'Intel(R) Core(TM) i3-4150 CPU @ 3.50GHz',
        'processor_vcpus': '4',
    }
    darwin_hardware = DarwinHardware()

    assert cpu_facts == darwin_hardware.get_cpu_facts()


# Generated at 2022-06-24 21:52:27.080904
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware_0 = DarwinHardware()

    hardware_0.get_system_profile()


# Generated at 2022-06-24 21:52:34.850433
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_class = DarwinHardware()
    # get sample size of calculation
    data_size = len(test_class.sysctl['hw.memsize'])
    # block to test, call the function with a non-dict, non-module and non-module-running argument
    test_class.get_memory_facts()
    # test if the data size is equal
    assert len(test_class.sysctl['hw.memsize']) == data_size

# Generated at 2022-06-24 21:52:43.386700
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware = DarwinHardware()

    # test when kernel version is less than 10.7
    darwin_hardware.sysctl = {
        'kern.osversion': '10.6.8',
        'hw.memsize': '16605089792',
        'hw.physicalcpu': '1',
        'hw.ncpu': '1',
        'kern.osrevision': '15',
    }
    darwin_hardware.get_system_profile = lambda: {'Processor Name': 'Intel Core i7', 'Processor Speed': '2.6 GHz'}

    hardware_facts = darwin_hardware.populate()
    assert hardware_facts['processor'] == 'Intel Core i7 @ 2.6 GHz'

# Generated at 2022-06-24 21:52:45.959807
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:52:50.500722
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()

    test_state_dict_0 = dict()

    test_key_values_0 = darwin_hardware.get_system_profile()

    assert test_state_dict_0 == test_key_values_0


# Generated at 2022-06-24 21:52:52.947101
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = darwin_hardware_collector_0.collect()


# Generated at 2022-06-24 21:52:57.152187
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    result = darwin_hardware_0.get_mac_facts()
    assert result == {'osversion': '19.3.0', 'osrevision': 'Darwin Kernel Version 19.3.0: Thu Jan  9 20:58:23 PST 2020; root:xnu-6153.81.5~1/RELEASE_X86_64', 'model': 'MacBookPro15,1'}


# Generated at 2022-06-24 21:53:06.532382
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

# Generated at 2022-06-24 21:53:11.121485
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """
    Test case for method get_cpu_facts of class DarwinHardware
    """
    darwin_hardware_0 = DarwinHardware()

    assert darwin_hardware_0.get_cpu_facts() == {
        'processor': 'Intel(R) Xeon(R) CPU E5-2683 v4 @ 2.10GHz',
        'processor_cores': 2,
        'processor_vcpus': 4
    }



# Generated at 2022-06-24 21:54:08.275629
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.populate()
    var_1 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:54:11.808206
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_memory_facts()
    assert var_0.get('memfree_mb') == 0
    assert var_0.get('memtotal_mb') == 127036


# Generated at 2022-06-24 21:54:15.453065
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    rc, out, err = run_command(["sysctl hw.model"])
    if rc == 0:
        mac_facts['model'] = mac_facts['product_name'] = out.splitlines()[-1].split()[1]


# Generated at 2022-06-24 21:54:17.797255
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:54:19.309859
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    tuple_0 = ()
    darwin_hardware_collector_0 = DarwinHardwareCollector(tuple_0)

# Generated at 2022-06-24 21:54:21.969813
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_system_profile()
    assert var_0


# Generated at 2022-06-24 21:54:24.664791
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:54:34.249460
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    darwin_hardware_0.sysctl = {}
    darwin_hardware_0.sysctl['hw.model'] = 'TEST_STRING_VALUE'
    darwin_hardware_0.sysctl['kern.osversion'] = 'TEST_STRING_VALUE'
    darwin_hardware_0.sysctl['kern.osrevision'] = 'TEST_STRING_VALUE'
    darwin_hardware_0.sysctl['hw.memsize'] = 'TEST_STRING_VALUE'
    darwin_hardware_0.sysctl['hw.physicalcpu'] = 'TEST_STRING_VALUE'

# Generated at 2022-06-24 21:54:36.567339
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:54:38.586528
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:56:59.687177
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    assert 'processor' in darwin_hardware_0.get_cpu_facts() and \
        'processor_vcpus' in darwin_hardware_0.get_cpu_facts() and \
        'processor_cores' in darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:57:01.731904
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:57:04.373966
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    tuple_1 = (3, None)
    darwin_hardware_1 = DarwinHardware(tuple_1)
    darwin_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 21:57:05.953811
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    tuple_0 = ()
    darwin_hardware_collector_0 = DarwinHardwareCollector(tuple_0)

# Generated at 2022-06-24 21:57:10.222507
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.populate()

# Generated at 2022-06-24 21:57:13.178903
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    darwin_hardware_0.sysctl = {}
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:57:20.745416
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    var_0 = darwin_hardware_0.populate()
    sysctl = get_sysctl(darwin_hardware_0.module, ['hw', 'machdep', 'kern'])
    assert sysctl['kern.hostname'] == 'matrix', 'Incorrect value returned'
    assert sysctl['hw.memsize'] == 17179869184, 'Incorrect value returned'
    assert sysctl['hw.activecpu'] == 4, 'Incorrect value returned'
    assert sysctl['kern.boottime'] == '{ sec = 1557362500, usec = 634185 }', 'Incorrect value returned'

# Generated at 2022-06-24 21:57:26.319574
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Test case with empty tuple
    tuple_0 = ()
    darwin_hardware_collector_0 = DarwinHardwareCollector(tuple_0)
    # Test case with empty tuple
    tuple_1 = ()
    darwin_hardware_collector_1 = DarwinHardwareCollector(tuple_1)


# Generated at 2022-06-24 21:57:29.087015
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    darwin_hardware_0.get_mac_facts()
    var_0 = darwin_hardware_0.populate()


# Generated at 2022-06-24 21:57:34.435979
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(tuple_0)
    # Get the facts
    darwin_hardware_0.populate()
    var_0 = darwin_hardware_0.get_cpu_facts()
    # AssertionError: AssertionError: "processor_cores" should not be empty.
    print(var_0)
