

# Generated at 2022-06-24 21:48:21.840018
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Initializing object for class DarwinHardware
    darwin_hardware_0 = DarwinHardware()
    # Calling method get_memory_facts of class DarwinHardware
    result = darwin_hardware_0.get_memory_facts()
    assert result == {'memfree_mb': 0, 'memtotal_mb': 0}


# Generated at 2022-06-24 21:48:31.753110
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    module_1 = AnsibleModule(argument_spec=dict())
    module_1.run_command = MagicMock(return_value=(0, 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz', ''))
    darwin_hardware_1 = darwin_hardware_collector_1._get_facts(module_1)
    assert darwin_hardware_1.get_cpu_facts() == {'processor': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'}


# Generated at 2022-06-24 21:48:33.714119
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.populate()



# Generated at 2022-06-24 21:48:44.845501
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Create a new instance of DarwinHardware
    darwin_hardware = DarwinHardware()

    # Set the member variable sysctl of darwin_hardware to a constant that is
    # a dictionary of fictitious results of get_sysctl. The dictionary is an
    # Intel Mac with 4 cores.
    darwin_hardware.sysctl = {
        "machdep.cpu.brand_string":"Intel(R) Core(TM) i5-3470 CPU @ 3.20GHz",
        "machdep.cpu.core_count":4
    }

    # Call the get_cpu_facts method of darwin_hardware
    cpu_facts = darwin_hardware.get_cpu_facts()

    # Assert that the contents of the returned dictionary are equal to
    # the expected values.

# Generated at 2022-06-24 21:48:47.305354
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    system_profile_0 = darwin_hardware_0.get_system_profile()

# Generated at 2022-06-24 21:48:56.729640
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Create instance of class DarwinHardware
    darwin_hardware_0 = DarwinHardware()

    # Populate 'collected_facts' with the current knowledge
    # We the know that the ansible_facts key will be present in the resulting
    # 'ansible_facts'
    collected_facts = {'ansible_facts': {}}
    darwin_hardware_0.populate(collected_facts=collected_facts)

    # Test that the 'ansible_facts' key is present
    assert 'ansible_facts' in collected_facts


# Generated at 2022-06-24 21:49:03.171918
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    cpu_facts = darwin_hardware_0.get_cpu_facts()
    assert cpu_facts['processor'].startswith('Intel')
    assert cpu_facts['processor_cores'].startswith('4')


# Generated at 2022-06-24 21:49:09.885708
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    sysctl_cmd = darwin_hardware_0.module.get_bin_path('sysctl')
    get_uptime_facts_cmd = [sysctl_cmd, '-b', 'kern.boottime']
    rc, out, err = darwin_hardware_0.module.run_command(get_uptime_facts_cmd, encoding=None)

    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if rc != 0 or len(out) < struct_size:
        return {}


# Generated at 2022-06-24 21:49:15.684904
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # This is what /usr/sbin/system_profiler returns on OS X 10.9.5
    fake_output = """
Hardware:

Hardware Overview:

  Model Name: Mac Pro
  Model Identifier: MacPro1,1
  Processor Name: Dual-Core Intel Xeon
  Processor Speed: 2.66 GHz
  Number of Processors: 2
  Total Number of Cores: 2
  L2 Cache (per Processor): 4 MB
  Memory: 1 GB
  Bus Speed: 1.33 GHz
  Boot ROM Version: MP11.005C.B08
  SMC Version (system): 1.7f10
  Serial Number (system): G881238P4QH
  Hardware UUID: 00000000-0000-1000-8000-0016CBA2B5E3

"""

    hardware_instance = DarwinHardware()
    hardware

# Generated at 2022-06-24 21:49:25.419819
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Stub the required methods in class DarwinHardware
    get_sysctl_mock = MagicMock(name='get_sysctl')

# Generated at 2022-06-24 21:49:39.096483
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()



# Generated at 2022-06-24 21:49:42.253633
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware(module=None, sysctl=None)
    darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:49:50.934809
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    # Test with 'machdep.cpu.brand_string' in sysctl
    darwin_hardware_0.sysctl = {
        'hw.model': 'Intel',
        'hw.physicalcpu': '2',
        'hw.logicalcpu': '4',
        'hw.coresperpackage': '1',
        'hw.physicalcpu_max': '4',
        'hw.packages': '2',
        'hw.memsize': '4294967296',
        'hw.ncpu': '4',
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2670 v3 @ 2.30GHz'
    }
    darwin_hardware_0.module.run_command = Magic

# Generated at 2022-06-24 21:50:02.847123
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import os
    import sys
    import unittest
    import ansible.modules.extras.hardware.darwin as darwin
    class StubModule:
        def __init__(self, *args, **kwargs):
            pass
        def get_bin_path(self, cmd, *args, **kwargs):
            return os.path.join(os.environ["PWD"], "bin_path")
        def run_command(self, cmd, *args, **kwargs):
            return 0, "System time 00:20:59.00", ""
    expected_uptime_facts = {'uptime_seconds': 1259}
    darwin_hardware_0 = darwin.DarwinHardware(StubModule())
    result_uptime_facts = darwin_hardware_0.get_uptime

# Generated at 2022-06-24 21:50:08.959392
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = MagicMock()
    darwin_hardware_0.module.run_command.return_value = (0, 'sysctl hw.model', '')
    darwin_hardware_0.sysctl = dict()
    darwin_hardware_0.get_system_profile = MagicMock()
    darwin_hardware_0.get_system_profile.return_value = dict()
    result = darwin_hardware_0.get_cpu_facts()
    assert result == dict()


# Generated at 2022-06-24 21:50:11.478351
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hw = DarwinHardware()
    hw.sysctl = {
        'hw.memsize': '10051559936'
    }
    result = hw.get_memory_facts()
    assert result == {
        'memtotal_mb': 9540,
        'memfree_mb': 0
    }



# Generated at 2022-06-24 21:50:17.468155
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_mac_facts()
    darwin_hardware_0.populate()
    darwin_hardware_0.populate()
    darwin_hardware_0.populate()
    darwin_hardware_0.populate()
    darwin_hardware_0.populate()


# Generated at 2022-06-24 21:50:24.124405
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    darwin_hardware_0 = DarwinHardware(module)

    #Vérifier que le résultat de la méthode get_memory_facts() est un dictionary
    assert isinstance(darwin_hardware_0.get_memory_facts(), dict)


# Generated at 2022-06-24 21:50:31.746166
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # In this test, method get_memory_facts is called with these input arguments:
    # input_memory_facts = {}
    # Expected output
    # memory_facts = {'memtotal_mb': 246306, 'memfree_mb': 202698}

    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {
        'hw.logicalcpu': 4,
        'hw.physicalcpu': 4,
        'hw.memsize': 256622464,
        'hw.pagesize': 4096,
        'hw.usermem': 244034688,
        'hw.ncpu': 4,
        'hw.activecpu': 4,
    }

    memory_facts = darwin_hardware.get_memory_facts()

# Generated at 2022-06-24 21:50:40.197082
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = AnsibleModule(
        argument_spec = dict()
    )
    darwin_hardware_0.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1.0',
        'hw.memsize': 4294967296,
        'hw.model': 'MacBookPro11,1',
        'machdep.cpu.core_count': 2,
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz',
        'hw.logicalcpu': 4,
        'hw.ncpu': 4,
    }

    darwin_hardware_

# Generated at 2022-06-24 21:51:03.103251
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:51:04.769604
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:51:14.401885
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    rc, out, err = darwin_hardware_0.module.run_command("sysctl machdep.cpu.brand_string || echo PowerPC")
    if rc == 0:
        system_profile_0 = darwin_hardware_0.get_system_profile()
        if system_profile_0['Processor Name'] == 'PowerPC':
            cpu_facts_0 = darwin_hardware_0.get_cpu_facts()
            if cpu_facts_0['processor_cores'] == '2':
                assert False
            elif cpu_facts_0['processor_cores'] == '1':
                assert True
    else:
        if out.splitlines()[-1].split()[1] == 'PowerPC':
            cpu_facts_

# Generated at 2022-06-24 21:51:15.664346
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector._platform == 'Darwin'


# Generated at 2022-06-24 21:51:18.644430
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    _hardware_0 = DarwinHardwareCollector().populate()
    _hardware_1 = DarwinHardware().populate()
    assert isinstance(_hardware_1, dict)
    assert _hardware_1 == _hardware_0


# Generated at 2022-06-24 21:51:29.870090
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware = DarwinHardware()

# Generated at 2022-06-24 21:51:39.971482
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Mocking the module and class
    module = MagicMock()
    darwin_hardware = DarwinHardware(module)

    system_profile = MagicMock(return_value = {'Processor Name': 'Intel Core i7 @ 2.80GHz', 'Processor Speed': '2.8 GHz'})
    darwin_hardware.get_system_profile = system_profile

    expected = {'processor': 'Intel Core i7 @ 2.80GHz', 'processor_cores': '2.8 GHz'}
    actual = darwin_hardware.get_cpu_facts()

    assert expected == actual


# Generated at 2022-06-24 21:51:45.370091
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_case = DarwinHardware()
    test_case.module.run_command = MagicMock(return_value=(0, test_case.get_system_profile(), ''))
    result = test_case.get_cpu_facts()
    assert result['processor'] == 'Intel Core i5 @ 1.50 GHz'
    assert result['processor_cores'] == '2'


# Generated at 2022-06-24 21:51:46.663754
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Test for constructor of class DarwinHardwareCollector
    darwin_hardware_collector_0 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:51:51.343176
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert 'Hardware UUID' in system_profile
    assert 'Hardware Overview' in system_profile
    assert 'Model Name' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile
    assert 'Number of Processors' in system_profile
    assert 'Memory' in system_profile

# Generated at 2022-06-24 21:52:16.189516
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert darwin_hardware_collector_0._fact_class == DarwinHardware
    assert darwin_hardware_collector_0._platform == 'Darwin'

# Function to test DarwinHardware.populate()

# Generated at 2022-06-24 21:52:24.391869
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Invalid input.
    # Pass the sysctl output that is not in expected format.
    str_1 = 'hw.memsize=40'
    list_1 = ['sysctl hw.model']
    tuple_1 = (list_1, str_1)
    darwin_hardware_collector_0 = DarwinHardwareCollector(tuple_1)
    # Do not return error if the output is not in expected format.

if __name__ == '__main__':
    test_case_0()
    test_DarwinHardwareCollector()

# Generated at 2022-06-24 21:52:28.406536
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    str_0 = 'f*@H5=m8%.Y'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:52:30.077833
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()


# Generated at 2022-06-24 21:52:37.932693
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    bool_0 = True
    str_0 = '|0wcb '
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    darwin_hardware_0.get_cpu_facts()
    darwin_hardware_0.get_mac_facts()
    darwin_hardware_0.get_memory_facts()
    darwin_hardware_0.get_uptime_facts()
    var_0 = darwin_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 21:52:41.507717
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bool_0 = True
    str_0 = 'Wc][0'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:52:52.447452
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Define a dictionary to simulate the cache
    str_0 = 'hv BtW`'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)

    # Populate the cache
    darwin_hardware_0.get_cpu_facts()

    # Define a dictionary to simulate the module argument spec
    sysctl_0 = {'hw.physicalcpu': 2, 'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-2720QM CPU @ 2.20GHz', 'hw.ncpu': 2, 'hw.logicalcpu': 2}

    # Populate the facts
    darwin_hardware_0.populate(sysctl=sysctl_0)

    # Check the facts
    processor_0 = d

# Generated at 2022-06-24 21:52:56.349122
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bool_0 = True
    str_0 = '&6KrZ3q9e'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.get_cpu_facts()
    pass


# Generated at 2022-06-24 21:52:59.630048
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bool_0 = True
    str_0 = 't3;'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:53:03.198099
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    bool_0 = True
    str_0 = ':l_|'
    tuple_0 = ()
    darwin_hardware_collector_0 = DarwinHardwareCollector(str_0, tuple_0)


# Generated at 2022-06-24 21:53:59.266372
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Test cases that should return a dictionary of information from system_profile.
    # Gather a dictionary of data from system_profile
    bool_0 = True
    str_0 = '|0wcb '
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:54:02.022822
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bool_0 = True
    str_0 = '|0wcb '
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:54:10.709143
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Input params
    # Output params
    cpu_facts = {
        'processor': 'Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz',
        'processor_cores': 8,
        'processor_vcpus': 8
    }

    # Normal run
    darwin_hardware_0 = DarwinHardware()

# Generated at 2022-06-24 21:54:14.519468
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bool_0 = True
    str_0 = '|(. 5'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 21:54:23.360096
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bool_0 = True
    str_0 = '1~y'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    str_1 = '/usr/sbin/system_profiler '
    tuple_1 = darwin_hardware_0.get_system_profile()
    str_2 = str_1
    str_3 = '5'
    str_4 = ' '
    str_5 = "9Xv'8"
    str_6 = str_1
    str_7 = str_2
    str_8 = str_3
    str_9 = str_4
    str_10 = str_5
    str_11 = ':'
    str_12 = str_6
    str_13 = str_7
    str_14

# Generated at 2022-06-24 21:54:26.022810
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    sysctl = {'hw.memsize': '268435456'}
    darwin_hardware_0 = DarwinHardware(sysctl)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:54:35.574572
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = '#;Xn<'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.get_mac_facts()
    str_1 = ';A'
    tuple_1 = ()
    darwin_hardware_1 = DarwinHardware(str_1, tuple_1)
    var_1 = darwin_hardware_1.get_mac_facts()
    str_2 = 'C*{8`<'
    tuple_2 = ()
    darwin_hardware_2 = DarwinHardware(str_2, tuple_2)
    var_2 = darwin_hardware_2.get_mac_facts()


# Generated at 2022-06-24 21:54:36.570383
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector_0 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:54:40.253761
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = 'e&1!b'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    tuple_0 = ()
    darwin_hardware_0.get_mac_facts(tuple_0)


# Generated at 2022-06-24 21:54:42.562620
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    str_0 = '  P'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 21:56:36.581620
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bool_0 = True
    str_0 = '|0wcb '
    tuple_0 = ()
    darwin_hardware_1 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 21:56:38.410503
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    fact_class_0 = DarwinHardware
    platform_0 = '-y2'
    darwin_hardware_collector_0 = DarwinHardwareCollector(fact_class_0, platform_0)

# Generated at 2022-06-24 21:56:43.179024
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bool_0 = True
    str_0 = 'F;7zvY\\'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    # test get_cpu_facts
    assert darwin_hardware_0.get_cpu_facts() == {'processor': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz', 'processor_cores': '4', 'processor_vcpus': '4'}


# Generated at 2022-06-24 21:56:44.287006
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    str_1 = 'Darwin'
    darwin_hardware_collector = DarwinHardwareCollector(str_1)
    test_case_0()

# Generated at 2022-06-24 21:56:48.581263
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bool_0 = True
    str_0 = '|0wcb '
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:56:57.259221
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    bool_0 = True
    str_0 = ':p:l1_s'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.populate()
    darwin_hardware_1 = DarwinHardware('', tuple_0)
    darwin_hardware_1.populate()
    darwin_hardware_2 = DarwinHardware('', tuple_0)
    darwin_hardware_2.populate()
    darwin_hardware_3 = DarwinHardware('', tuple_0)
    darwin_hardware_3.populate()
    darwin_hardware_4 = DarwinHardware('', tuple_0)
    darwin_hardware_4.populate

# Generated at 2022-06-24 21:57:07.873786
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    with mock.patch('ansible.module_utils.facts.hardware.darwin.DarwinHardware._run_command', return_value=(0, '10485760\n', None)):
        with mock.patch('ansible.module_utils.facts.hardware.darwin.DarwinHardware.get_system_profile', return_value={}):
            darwin_hardware_0 = DarwinHardware(None, None)
            (code, out, err) = darwin_hardware_0._run_command()
            assert darwin_hardware_0._run_command() == (0, '10485760\n', None)
            assert darwin_hardware_0.get_system_profile() == {}

# Generated at 2022-06-24 21:57:12.151555
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bool_0 = True
    str_0 = '|0wcb '
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:57:19.898596
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    key_0 = '!!;(+j&9h/O`L2/DB#|'
    excpt_0 = KeyError('QI1xW8`v`X-?ZpP=I"j')
    excpt_0.__context__ = None
    excpt_0.__cause__ = None
    bool_0 = True
    str_0 = '(c>U0Y4U6H3q_,mv)X0K'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    darwin_hardware_0.module.run_command = MethodType(lambda self, arg_0: (0, arg_0[1], arg_0[2]), darwin_hardware_0.module)

# Generated at 2022-06-24 21:57:26.218193
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bool_0 = True
    str_0 = ' |a'
    tuple_0 = ()
    darwin_hardware_0 = DarwinHardware(str_0, tuple_0)
    result = darwin_hardware_0.get_memory_facts()
    assert result == {'memtotal_mb': 0, 'memfree_mb': 0}
