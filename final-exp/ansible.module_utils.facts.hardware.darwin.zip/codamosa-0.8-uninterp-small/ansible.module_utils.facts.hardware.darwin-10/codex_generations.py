

# Generated at 2022-06-24 21:48:22.961882
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    str_0 = '- dependency %s is already installed, skipping.'
    darwin_hardware_0 = DarwinHardware(str_0)
    rc_0 = darwin_hardware_0.get_system_profile()



# Generated at 2022-06-24 21:48:32.739390
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    str_0 = '- dependency %s is already installed, skipping.'
    darwin_hardware_0 = DarwinHardware(str_0)
    str_0 = '/var/run/sysconfig/network-scripts/ifcfg-lo'
    darwin_hardware_0.module = get_module(ansible_positionals=str_0)
    str_1 = 'myhost.mydomain.com'
    darwin_hardware_0.module.params = {'hostname': str_1}
    darwin_hardware_0.populate()
    assert darwin_hardware_0.memory.size == 524288


# Generated at 2022-06-24 21:48:38.106355
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # The test case values
    str_1 = '- dependency %s is already installed, skipping.'
    darwin_hardware_0 = DarwinHardware(str_1)

    # Invoke the method
    result_0 = darwin_hardware_0.get_mac_facts()

    # Verify the results
    assert result_0 is not None


# Generated at 2022-06-24 21:48:39.051146
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj_0 = DarwinHardwareCollector()


# Generated at 2022-06-24 21:48:40.927011
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert darwin_hardware_collector_0._fact_class == DarwinHardware
    assert darwin_hardware_collector_0._platform == 'Darwin'


# Generated at 2022-06-24 21:48:43.147744
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:48:46.282385
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware(str_0)

    # Get system profile
    darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:48:55.907436
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
      str_0 = '- dependency %s is already installed, skipping.'
      dict_0 = dict()
      dict_0['1'] = 4711
      dict_0['2'] = 22
      dict_0['3'] = 33
      dict_0['4'] = 44
      dict_0['5'] = 55
      dict_0['6'] = 66
      dict_0['7'] = 77
      dict_0['8'] = 88
      dict_0['9'] = 99
      dict_0['10'] = 1010

      darwin_hardware_1 = DarwinHardware(str_0, dict_0)
      dict_1 = darwin_hardware_1.get_uptime_facts()
      dict_2 = dict()
      dict_2['uptime_seconds'] = 130

# Generated at 2022-06-24 21:48:58.118983
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    str_0 = '- dependency %s is already installed, skipping.'
    darwin_hardware_0 = DarwinHardware(str_0)
    darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:49:02.036945
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_1 = DarwinHardware()
    system_profile_0 = darwin_hardware_1.get_system_profile()

    assert system_profile_0 is not None


# Generated at 2022-06-24 21:49:17.172251
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    assert 'product_name' in darwin_hardware_0.get_system_profile()
    assert 'system_profile' in darwin_hardware_0.get_system_profile()
    assert 'Processor Name' in darwin_hardware_0.get_system_profile()
    assert 'Processor Speed' in darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:49:19.240005
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    try:
        darwin_hardware_collector_0 = DarwinHardwareCollector()
    except Exception as exception:
        assert False


# Generated at 2022-06-24 21:49:21.877638
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():

    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector is not None

# Generated at 2022-06-24 21:49:22.722194
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    pass


# Generated at 2022-06-24 21:49:23.893292
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert type(DarwinHardwareCollector()) is DarwinHardwareCollector


# Generated at 2022-06-24 21:49:27.318043
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert test_case_0()[0] == (
        'DarwinHardwareCollector',
        {
            '_fact_class': DarwinHardware,
            '_platform': 'Darwin'
        }
    )


# Generated at 2022-06-24 21:49:29.238960
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    print('Testing method get_cpu_facts of class DarwinHardware')
    DarwinHardware.get_cpu_facts()
    

# Generated at 2022-06-24 21:49:32.830508
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert isinstance(darwin_hardware_collector_0, HardwareCollector)
    assert darwin_hardware_collector_0._platform is 'Darwin'
    assert darwin_hardware_collector_0._fact_class is DarwinHardware

# Generated at 2022-06-24 21:49:36.005640
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'hw.memsize': '17179869184'}
    assert darwin_hardware.get_memory_facts() == {'memtotal_mb': 16384, 'memfree_mb': 0}


# Generated at 2022-06-24 21:49:38.086156
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:49:51.137125
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:49:54.984930
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = -1298
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_system_profile()
    print(var_0)


# Generated at 2022-06-24 21:49:56.893867
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = 508
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_uptime_facts()
    assert var_0 == {}, var_0


# Generated at 2022-06-24 21:50:00.907870
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = -4197
    darwin_hardware_0 = DarwinHardware(int_0)
    darwin_hardware_0.sysctl = dict()
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:50:08.385409
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    darwin_hardware_0.get_mac_facts()
    darwin_hardware_0.get_cpu_facts()
    darwin_hardware_0.get_memory_facts()
    darwin_hardware_0.get_uptime_facts()
    # Should not raise an exception

# Generated at 2022-06-24 21:50:11.996693
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = -5813
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 21:50:15.235494
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.populate(collected_facts=None)


# Generated at 2022-06-24 21:50:18.600107
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():

    int_0 = -113
    darwin_hardware_0 = DarwinHardware(int_0)
    # Give the system_profiler command an executable path
    darwin_hardware_0.module.run_command = lambda cmd, encoding=None: (0, 'Processor Speed: 2.7 GHz', '')
    # Test if the system_profiler command was called
    darwin_hardware_0.get_system_profile()

test_DarwinHardware_get_system_profile()


# Generated at 2022-06-24 21:50:22.612361
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = 7867
    darwin_hardware_0 = DarwinHardware(int_0)
    darwin_hardware_0._DarwinHardware__get_system_profile()


# Generated at 2022-06-24 21:50:26.238511
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin_hardware_0 = DarwinHardware()

    # Test without specified argument
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:50:48.751993
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    int_1 = -2379
    darwin_hardware_1 = DarwinHardware(int_1)
    darwin_hardware_1.get_memory_facts()

# Generated at 2022-06-24 21:50:54.521388
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_mac_facts()


if __name__ == "__main__":
    test_case_0()
    test_DarwinHardware_populate()

# Generated at 2022-06-24 21:50:56.879763
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = 9
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:51:02.795077
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {'hw.model': 'Macmini5,1',
                                'kern.osversion': '15D21',
                                'kern.osrevision': '13A584'}
    var_0 = darwin_hardware_0.get_system_profile()
    assert var_0 == {'Machine Model': 'Macmini5,1',
                     'Number of Processors': '2',
                     'Processor Name': 'Intel Core i7',
                     'Processor Speed': '2.3 GHz',
                     'Total Number of Cores': '4'}


# Generated at 2022-06-24 21:51:05.962450
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    collected_facts_0 = int_0
    darwin_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 21:51:09.739805
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    int_0 = -1906
    darwin_hardware_collector_0 = DarwinHardwareCollector(int_0)
    assert darwin_hardware_collector_0.platform == 'Darwin'


# Generated at 2022-06-24 21:51:19.611426
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    memory_facts = {
        'memtotal_mb': int(self.sysctl['hw.memsize']) // 1024 // 1024,
        'memfree_mb': 0,
    }

    total_used = 0
    page_size = 4096
    try:
        vm_stat_command = get_bin_path('vm_stat')
    except ValueError:
        return memory_facts

    rc, out, err = self.module.run_command(vm_stat_command)
    if rc == 0:
        # Free = Total - (Wired + active + inactive)
        # Get a generator of tuples from the command output so we can later
        # turn it into a dictionary
        memory_stats = (line.rstrip('.').split(':', 1) for line in out.splitlines())

        # Strip extra left spaces from

# Generated at 2022-06-24 21:51:30.757545
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    global hw_collector
    hw_collector = DarwinHardwareCollector()

# Generated at 2022-06-24 21:51:33.652658
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = -118
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:51:37.699432
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = -44
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:52:23.657067
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    system_profile_0 = {}
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    darwin_hardware_0.module = ansible_module_0
    test_case_0(darwin_hardware_0)
    assert darwin_hardware_0.get_system_profile() == system_profile_0


# Generated at 2022-06-24 21:52:27.591462
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:52:28.313619
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector()

# Generated at 2022-06-24 21:52:37.150496
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    int_1 = -4774
    darwin_hardware_collector_0 = DarwinHardwareCollector(int_1)
    assert isinstance(darwin_hardware_collector_0, DarwinHardwareCollector) == True , "constructor of class DarwinHardwareCollector has failed"
    assert darwin_hardware_collector_0._platform == 'Darwin', "attribute _platform of class DarwinHardwareCollector has failed"
    assert darwin_hardware_collector_0._fact_class == DarwinHardware, "attribute _fact_class of class DarwinHardwareCollector has failed"


# Generated at 2022-06-24 21:52:40.307780
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    int_0 = -1906
    darwin_hardware_collector_0 = DarwinHardwareCollector(int_0)
    var_0 = darwin_hardware_collector_0.__dict__
    var_0 = darwin_hardware_collector_0.get_all()


# Generated at 2022-06-24 21:52:43.332482
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:52:46.744716
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:52:51.228049
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    int_0 = -2021
    darwin_hardware_0 = DarwinHardware(int_0)
    int_1 = -1372
    var_1 = darwin_hardware_0.get_memory_facts(int_1)


# Generated at 2022-06-24 21:52:53.859498
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = -142
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:52:56.721492
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    int_0 = -6901
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_mac_facts()
    assert (var_0 == {})


# Generated at 2022-06-24 21:54:41.578781
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    darwin_hardware_0.populate()
    var_0 = darwin_hardware_0.get_mac_facts()
    assert len(var_0) == 3
    int_1 = -1845
    darwin_hardware_1 = DarwinHardware(int_1)
    var_1 = darwin_hardware_1.get_mac_facts()
    assert len(var_1) == 3
    int_2 = -1772
    darwin_hardware_2 = DarwinHardware(int_2)
    darwin_hardware_2.populate()
    var_2 = darwin_hardware_2.get_mac_facts()

# Generated at 2022-06-24 21:54:42.992861
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    var_0 = darwin_hardware_collector_0.platform


# Generated at 2022-06-24 21:54:45.294317
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    int_0 = -1690
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:54:53.706429
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    # hw.memsize: 6147604480
    # hw.physicalcpu: 1
    # hw.logicalcpu: 1
    # hw.ncpu: 1
    darwin_hardware_0.sysctl = dict()
    # should raise RuntimeError: The Darwin module requires vm_stat to be installed
    with pytest.raises(RuntimeError):
        darwin_hardware_0.get_memory_facts()
    int_1 = 6147604480
    var_0 = darwin_hardware_0.sysctl['hw.memsize']
    assert var_0 == int_1
    int_2 = 1
    var_1 = darwin_hardware

# Generated at 2022-06-24 21:55:02.055298
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    int_0 = 1905
    darwin_hardware_0 = DarwinHardware(int_0)
    # test case for mac_facts:
    # Model Identifier: MacBookPro1,1
    # Processor Name: Intel Core Solo
    # Processor Speed: 1.83 GHz
    mac_facts = darwin_hardware_0.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro1'
    assert mac_facts['osversion'] == '13.4.0'
    assert mac_facts['osrevision'] == 'Darwin Kernel Version 13.4.0: Tue Jan 27 22:35:58 PST 2015; root:xnu-2422.115.3~1/RELEASE_X86_64'

    # test case for mac_facts:
    # Model Identifier: iMac5,1


# Generated at 2022-06-24 21:55:05.190943
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:55:08.914418
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    int_1 = -1631
    darwin_hardware_1 = DarwinHardware(int_1)
    var_2 = darwin_hardware_1.get_system_profile()


# Generated at 2022-06-24 21:55:10.638651
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:55:17.279950
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Test if constructor raises exception on invalid input
    assert_raises(TypeError, DarwinHardwareCollector, None)
    assert_raises(TypeError, DarwinHardwareCollector, 1)
    assert_raises(TypeError, DarwinHardwareCollector, float(1))
    assert_raises(TypeError, DarwinHardwareCollector, True)
    assert_raises(TypeError, DarwinHardwareCollector, "string")
    assert_raises(TypeError, DarwinHardwareCollector, {"key": 1})
    assert_raises(TypeError, DarwinHardwareCollector, [1, 2, 3])
    assert_raises(TypeError, DarwinHardwareCollector, (1, 2, 3))
    assert_raises(TypeError, DarwinHardwareCollector, set(1, 2, 3))

# Generated at 2022-06-24 21:55:20.180428
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    int_0 = -1906
    darwin_hardware_0 = DarwinHardware(int_0)
    darwin_hardware_0.get_memory_facts()
