

# Generated at 2022-06-24 21:48:35.063136
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    darwin_hardware_collector_0_sysctl = get_sysctl(darwin_hardware_collector_1.module, ['hw', 'machdep', 'kern'])
    assert darwin_hardware_collector_0_sysctl['hw.memsize'] == 9223372036854775807
    assert darwin_hardware_collector_0_sysctl['hw.model'] == 'MacBookPro10,2'
    darwin_hardware_collector_1_mac_facts = darwin_hardware_collector_1.get_mac_facts()
    assert darwin_hardware_collector_1_mac_facts['model'] == 'MacBookPro10,2'
   

# Generated at 2022-06-24 21:48:42.041716
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    system_profile_0 = dict()
    system_profile_0['Processor Speed'] = '1.6 GHz'
    system_profile_0['Processor Name'] = 'Intel Core i5'
    hw_machdep_cpu_brand_string_0 = 'Intel(R) Core(TM) i5-5250U CPU @ 1.60GHz'
    hw_physicalcpu_0 = '4'
    hw_logicalcpu_0 = '4'
    sysctl_0 = dict()
    sysctl_0['machdep.cpu.brand_string'] = hw_machdep_cpu_brand_string_0
    sysctl_0['hw.physicalcpu'] = hw_physicalcpu_0
    sysctl_0['hw.logicalcpu'] = hw_logicalcpu_0
    d

# Generated at 2022-06-24 21:48:47.700848
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_instantiate_0 = DarwinHardware()
    # Asserting the equality of darwin_hardware_instantiate_0.get_memory_facts()['memtotal_mb'] and "10240"
    assert darwin_hardware_instantiate_0.get_memory_facts()['memtotal_mb'] == "10240"


# Generated at 2022-06-24 21:48:58.979959
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware(module=AnsibleModule(argument_spec={}))
    system_profile_0 = darwin_hardware_0.get_system_profile()
    assert type(system_profile_0) == dict
    assert system_profile_0.get('System UUID') == ''
    assert system_profile_0.get('Hardware UUID') == ''
    assert system_profile_0.get('Serial Number (system)') == ''
    assert system_profile_0.get('Number of Processors') == ''
    assert system_profile_0.get('Total Number of Cores') == ''
    assert system_profile_0.get('L2 Cache (per Core)') == ''
    assert system_profile_0.get('L3 Cache') == ''

# Generated at 2022-06-24 21:49:05.007699
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {
        'hw.memsize': '4299916288',
        'hw.logicalcpu': '8',
    }
    assert darwin_hardware_0.get_memory_facts() == {
        'memtotal_mb': 4096,
        'memfree_mb': 0,
        }

# Generated at 2022-06-24 21:49:07.573836
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware({})
    darwin_hardware_0.populate()
    assert isinstance(darwin_hardware_0, DarwinHardware)


# Generated at 2022-06-24 21:49:09.504771
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware({}, {}, {})
    assert darwin_hardware_0.get_uptime_facts() == {}

# Generated at 2022-06-24 21:49:18.444919
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create an instance of class DarwinHardware
    darwin_hardware_0 = DarwinHardware()
    # Set a value for the attribute kern.boottime
    darwin_hardware_0.sysctl['kern.boottime'] = '1394335006 0'

    # Create an instance of module_utils.common.process.Process
    process_1 = Process(binary='/usr/sbin/system_profiler', args=['SPHardwareDataType'])

    # Create an instance of module_utils.common.process.Process
    process_2 = Process(binary='vm_stat', args=[])

    # Create an instance of module_utils.common.process.Process

# Generated at 2022-06-24 21:49:19.446689
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Not implemented yet
    pass


# Generated at 2022-06-24 21:49:24.155747
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    hardware_obj_1 = DarwinHardware(darwin_hardware_collector_1)
    test_case_1 = hardware_obj_1.get_system_profile()
    print("DarwinHardware.get_system_profile() = %s" % test_case_1)


# Generated at 2022-06-24 21:49:46.752832
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    system_profile = {
        'Processor Name': 'Intel',
        'Processor Speed': '2.0GHz'
    }
    self = {
        'sysctl': {
            'kern.osversion': '10.12.5',
            'kern.osrevision': '16F73'
        },
        'module': {
            'run_command': lambda x: ('', '', '')
        }
    }
    expected_mac_facts = {
        'osversion': '10.12.5',
        'osrevision': '16F73',
        'model': '',
        'product_name': ''
    }
    mac_facts = DarwinHardware.get_mac_facts(self)
    print(mac_facts)
    print(expected_mac_facts)
    assert mac_facts

# Generated at 2022-06-24 21:49:50.131498
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    assert darwin_hardware_collector_0.platform == 'Darwin'
    assert darwin_hardware_collector_0.fact_class == DarwinHardware


# Generated at 2022-06-24 21:49:53.125493
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector_0 = DarwinHardwareCollector()

if __name__ == '__main__':
    test_case_0()
    test_DarwinHardwareCollector()

# Generated at 2022-06-24 21:49:59.736815
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_memory_facts()
    assert var_0 == {'memtotal_mb': 0, 'memfree_mb': 0}


# Generated at 2022-06-24 21:50:11.413185
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Setup the test
    mock_module_0 = Mock(ansible.module_utils.basic.AnsibleModule)

    rc, out, err = 0, b'hw.model: Power Macintosh\n', b''

    mock_module_0.run_command.return_value = (rc, out, err)
    darwin_hardware_0 = DarwinHardware(mock_module_0)
    # Execute the test
    actual_return_0 = darwin_hardware_0.get_mac_facts()
    expected_return_0 = {
        'model': 'Power Macintosh',
        'osrevision': '1915.10.17',
        'osversion': '16.0.0'
    }
    assert actual_return_0 == expected_return_0


# Generated at 2022-06-24 21:50:12.358020
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    pass


# Generated at 2022-06-24 21:50:15.945096
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_memory_facts()
    assert var_0 == {}



# Generated at 2022-06-24 21:50:17.266857
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Test0: Initialization with None
    assert isinstance(DarwinHardwareCollector(None), DarwinHardwareCollector)


# Generated at 2022-06-24 21:50:21.441545
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # mock the module_utils.common.process.get_bin_path function
    # get_bin_path function returns the absolute path of the binary command run
    get_bin_path_method_name = 'module_utils.common.process.get_bin_path'
    get_bin_path_method_mock = MagicMock(return_value='/usr/sbin/system_profiler')
    with patch(get_bin_path_method_name, get_bin_path_method_mock):
        # mock the run_command function
        # run_command function returns the return code of the executed cmd
        # along with stdout and stderr
        run_command_method_name = 'ansible.module_utils.basic.AnsibleModule.run_command'
        run_command_method_mock = MagicMock

# Generated at 2022-06-24 21:50:29.434195
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mock_module = MagicMock(return_value=False)
    mock_run_command = MagicMock(return_value=(0, b'1666.0M', b''))
    with patch.dict('sys.modules', {'ansible.module_utils.common.process': mock_module}):
        with patch.object(mock_module, 'run_command', mock_run_command):
            bytes_0 = b''
            darwin_hardware_0 = DarwinHardware(bytes_0)
            var_0 = darwin_hardware_0.get_memory_facts()

            mock_run_command.assert_called_once()



# Generated at 2022-06-24 21:50:53.924592
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:50:58.021782
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    bytes_1 = b''
    darwin_hardware_1 = DarwinHardware(bytes_1)
    var_1 = darwin_hardware_1.populate()
    bytes_2 = b''
    darwin_hardware_2 = DarwinHardware(bytes_2)
    var_2 = darwin_hardware_2.populate()
    assert var_1 ==  var_2
    assert type(var_1) == {'type': 'dict', 'value': None}


# Generated at 2022-06-24 21:51:00.346792
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:51:02.153042
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:51:04.568756
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 21:51:08.351366
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:51:19.322281
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # This is a little function that takes an input string, and returns the output
    # written to stdout when the input is fed to this module. This is needed to
    # compare test strings when we want to match against the actual output.
    # The output we want to match is the JSON-dumped version of the actual output
    def get_bytes_output(input_string):
        bytes_output = b''
        try:
            import StringIO
        except ImportError:
            import io as StringIO
        with StringIO.BytesIO() as output:
            try:
                import __builtin__
            except ImportError:
                import builtins as __builtin__
            used_builtin = __builtin__.__dict__.get('bytes', __builtin__.__dict__.get('str'))

# Generated at 2022-06-24 21:51:29.624797
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)

    with mock.patch.dict('os.environ', {'PATH': '/bin'}):
        with mock.patch.object(darwin_hardware_0, 'run_command') as mocked_run_command_0:
            mocked_run_command_0.return_value = (0, '', '')

            darwin_hardware_0.get_system_profile()
            expected = [mock.call(['/bin/system_profiler', 'SPHardwareDataType'])]
            assert mocked_run_command_0.call_args_list == expected



# Generated at 2022-06-24 21:51:32.470451
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_1 = darwin_hardware_0.populate()


# Generated at 2022-06-24 21:51:34.656782
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    bytes_0 = b''
    darwin_hardware_collector_0 = DarwinHardwareCollector(bytes_0)


# Generated at 2022-06-24 21:52:16.508308
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    cmd = ['/usr/sbin/system_profiler', 'SPHardwareDataType']
    rc, out, err = check_output(cmd)


# Generated at 2022-06-24 21:52:18.938901
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector.get_fact_class() == DarwinHardware
    assert collector.get_platform() == 'Darwin'

# Generated at 2022-06-24 21:52:28.732209
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    bytes_1 = b'\x00\x00\x00\x00'
    struct_1 = struct.pack(b'@L', 1526573500)
    if (bytes_1 != struct_1):
        var_0 = True
        print(var_0)
    else:
        var_0 = False
    bytes_2 = b'\x00\x00\x00\x00'
    struct_2 = struct.pack(b'@L', 1526573500)
    if (bytes_2 != struct_2):
        var_1 = True
        print(var_1)
    else:
        var_1 = False

# Generated at 2022-06-24 21:52:33.368767
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:52:41.639019
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_uptime_facts()
    assert 0 == len(var_0)
    bytes_1 = b''
    darwin_hardware_1 = DarwinHardware(bytes_1)
    var_1 = darwin_hardware_1.get_uptime_facts()
    assert 0 == len(var_1)
    bytes_2 = b'\x00\x00\x00\x00'
    darwin_hardware_2 = DarwinHardware(bytes_2)
    var_2 = darwin_hardware_2.get_uptime_facts()
    assert 0 == len(var_2)

# Generated at 2022-06-24 21:52:46.022723
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_1 = darwin_hardware_0.get_uptime_facts()
    assert isinstance(var_1, dict)
    assert var_1.get('uptime_seconds') == 0


# Generated at 2022-06-24 21:52:49.957391
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_uptime_facts()
    assert var_0 == {}


# Generated at 2022-06-24 21:52:52.907287
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:52:54.119863
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    bytes_0 = b''
    darwin_hardware_collector_0 = DarwinHardwareCollector(bytes_0)

# Generated at 2022-06-24 21:52:56.648564
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.populate()


# Generated at 2022-06-24 21:54:43.121281
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # initial data
    darwin_hardware_1 = DarwinHardware(b'')
    test_data_0 = {'kern.osrevision': b'15.3.0', 'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2673 v3 @ 2.40GHz', 'hw.logicalcpu': 6, 'hw.memsize': 2966422528, 'kern.osversion': b'Darwin Kernel Version 15.3.0: Thu Dec 10 18:40:58 PST 2015; root:xnu-3248.30.4~1/RELEASE_X86_64'}
    darwin_hardware_1.sysctl = test_data_0
    # call the tested function
    var_0 = darwin_hardware_1.get_cpu_

# Generated at 2022-06-24 21:54:51.121392
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bytes_2 = b''
    darwin_hardware_1 = DarwinHardware(bytes_2)
    var_1 = darwin_hardware_1.get_cpu_facts()
    var_1 = darwin_hardware_1.get_cpu_facts()
    var_1 = darwin_hardware_1.get_cpu_facts()
    var_1 = darwin_hardware_1.get_cpu_facts()
    var_1 = darwin_hardware_1.get_cpu_facts()
    var_1 = darwin_hardware_1.get_cpu_facts()
    var_1 = darwin_hardware_1.get_cpu_facts()
    var_1 = darwin_hardware_1.get_cpu_facts()

# Generated at 2022-06-24 21:54:54.217675
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_uptime_facts()
    assert var_0 == {}

# Generated at 2022-06-24 21:54:56.740343
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    darwin_hardware_0.populate()


# Generated at 2022-06-24 21:54:59.462965
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:55:00.692933
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardwareCollector(bytes_0)

# Generated at 2022-06-24 21:55:04.737306
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_system_profile()


# Generated at 2022-06-24 21:55:08.126968
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    assert 'uptime_seconds' in darwin_hardware.get_uptime_facts()


# Generated at 2022-06-24 21:55:10.131317
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    collected_facts_0 = None
    darwin_hardware_0.populate(collected_facts_0)



# Generated at 2022-06-24 21:55:11.768362
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    bytes_0 = b''
    darwin_hardware_0 = DarwinHardware(bytes_0)
    var_0 = darwin_hardware_0.get_uptime_facts()
