

# Generated at 2022-06-24 21:48:34.952136
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware({})
    darwin_hardware_0.module = MagicMock()
    darwin_hardware_0.module.get_bin_path.return_value = '/usr/bin/vm_stat'

# Generated at 2022-06-24 21:48:37.028747
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    hardware_fact_0 = darwin_hardware_collector_0.collect(None)

# Generated at 2022-06-24 21:48:47.797333
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockOS:
        def __init__(self):
            self.rc = 0
            self.out = b'{ sec = 1510334005, usec = 837929 }'
            self.err = None

        def run_command(self, cmd, encoding=None):
            return (self.rc, self.out, self.err)

    class MockModule:
        def __init__(self):
            self.os = MockOS()

        def get_bin_path(self, path):
            return '/usr/sbin/sysctl'

    mock = MockModule()

    darwin_hardware = DarwinHardware(module=mock)
    uptime_facts = darwin_hardware.get_uptime_facts()
    assert (uptime_facts['uptime_seconds'] > 0)


# Generated at 2022-06-24 21:48:51.270535
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    test_class = DarwinHardware()
    uptimedata = test_class.get_uptime_facts()
    # Expecting a dict with uptime floating point values
    assert isinstance(uptimedata, dict)
    assert uptimedata['uptime_seconds'] > 0.0

# Generated at 2022-06-24 21:49:03.168720
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    # Setup
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.module = AnsibleModuleMock()

    rc, out, err = darwin_hardware_0.module.run_command(["sysctl", "hw.model"])
    darwin_hardware_0.sysctl = get_sysctl(darwin_hardware_0.module, ['hw', 'machdep', 'kern'])

    # Act
    result = darwin_hardware_0.get_mac_facts()

    # Assert
    assert result['model'] == out.splitlines()[-1].split()[1]
    assert result['osversion'] == darwin_hardware_0.sysctl['kern.osversion']
    assert result['osrevision'] == d

# Generated at 2022-06-24 21:49:05.480610
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_DarwinHardware = DarwinHardware(dict())
    test_DarwinHardware.get_system_profile()

# Generated at 2022-06-24 21:49:07.464752
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    failures = []
    # No errors expected
    test_case_0()
    if failures:
        print("Failed: " + ", ".join(failures))
    else:
        print("OK")

# Generated at 2022-06-24 21:49:18.135141
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    # Test with Intel processor
    darwin_hardware_0.sysctl = {'machdep.cpu.brand_string': 'brand_string_1', 'machdep.cpu.core_count': 'core_count_2'}
    darwin_hardware_0.get_system_profile = lambda: {}
    result = darwin_hardware_0.get_cpu_facts()
    assert result == {'processor': 'brand_string_1', 'processor_vcpus': '', 'processor_cores': 'core_count_2'}

    # Test with PowerPC processor

# Generated at 2022-06-24 21:49:21.341921
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware(dict(), dict())
    darwin_hardware_0.sysctl = dict()
    darwin_hardware_0.sysctl['hw.memsize'] = 2594056192
    assert darwin_hardware_0.get_memory_facts() == {'memfree_mb': 0, 'memtotal_mb': 2485}


# Generated at 2022-06-24 21:49:22.572520
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    assert len(darwin_hardware.get_uptime_facts()) > 0


# Generated at 2022-06-24 21:49:44.746125
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.get_uptime_facts()


# Generated at 2022-06-24 21:49:48.134685
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.install_mock(
        sysctl_output='kern.boottime: { sec = 1535261510, usec = 0 }'
    )
    darwin_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 21:49:51.389392
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    darwin_hardware_0 = DarwinHardware(module=None, collected_facts=None)
    out = darwin_hardware_0.get_uptime_facts()

test_DarwinHardware_get_uptime_facts()
test_case_0()


# Generated at 2022-06-24 21:50:01.537542
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()

    darwin_hardware_0.sysctl = {
        'hw.memsize': '2147483648',
    }
    result = darwin_hardware_0.get_memory_facts()
    assert result == {'memtotal_mb': 2048, 'memfree_mb': 0}

    darwin_hardware_0.sysctl = {}
    result = darwin_hardware_0.get_memory_facts()
    assert result == {'memtotal_mb': 0, 'memfree_mb': 0}



# Generated at 2022-06-24 21:50:05.676543
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    res = darwin_hardware.get_system_profile()
    print("test_DarwinHardware_get_system_profile", res)


# Generated at 2022-06-24 21:50:08.384711
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardware()
    
    darwin_hardware_0.get_system_profile()
    


# Generated at 2022-06-24 21:50:11.997147
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware(module = None)
    assert darwin_hardware_0
    darwin_hardware_0.populate()


# Generated at 2022-06-24 21:50:23.619059
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    '''
    Test case for method get_system_profile.
    '''
    memsize = 4
    processor = 'Intel(R) Core(TM) i5-4360U CPU @ 1.80GHz'

# Generated at 2022-06-24 21:50:26.836746
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware_facts = DarwinHardware(module).get_uptime_facts()

    assert hardware_facts['uptime_seconds'] > 0


# Generated at 2022-06-24 21:50:32.938832
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware_obj = DarwinHardware()
    hardware_obj.sysctl = {'hw.physicalcpu': '2', 'machdep.cpu.core_count': '2', 'kern.osversion': '', 'kern.osrevision': ''}
    facts = hardware_obj.get_cpu_facts()
    assert facts == {'processor_vcpus': '2', 'processor_cores': '2', 'processor': ''}


# Generated at 2022-06-24 21:50:56.822920
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    # Mock return value for method sysctl of class Hardware
    sysctl_mock = {'kern.boottime': 1522912786.0}

    # Mock class Hardware
    class Hardware:
        def __init__(self):
            self.sysctl = sysctl_mock

    darwin_hardware = DarwinHardware(Hardware())

    # Call method get_uptime_facts of class DarwinHardware
    darwin_hardware.get_uptime_facts()

# Generated at 2022-06-24 21:51:03.292756
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_obj = DarwinHardware()
    darwin_hardware_collector_obj = DarwinHardwareCollector()
    darwin_hardware_obj.module = darwin_hardware_collector_obj.module
    darwin_hardware_obj.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i3-3120M CPU @ 2.50GHz', 'machdep.cpu.core_count': '4', 'hw.memsize': '17179869184', 'hw.physicalcpu': '2', 'hw.ncpu': '2', 'kern.osversion': '16.7.0', 'kern.osrevision': '0'}

# Generated at 2022-06-24 21:51:10.157104
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware()
    results = {}
    results['ansible_facts'] = dict(
        processor='Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz',
        processor_cores=4,
        processor_vcpus=4,
    )
    assert darwin_hardware_0.get_cpu_facts() == results['ansible_facts']

# Generated at 2022-06-24 21:51:11.946199
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector()._platform == 'Darwin'


# Generated at 2022-06-24 21:51:14.944233
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware = DarwinHardware(module=None)
    facts = hardware.get_mac_facts()
    facts.get('model')
    facts.get('osversion')
    facts.get('osrevision')


# Generated at 2022-06-24 21:51:22.715396
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_0 = DarwinHardware()

# Generated at 2022-06-24 21:51:27.336172
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()
    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts.get('memtotal_mb') > 0


# Generated at 2022-06-24 21:51:34.242973
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    sysctl = {'hw.memsize': 8589934592, 'hw.physicalcpu': 8, 'hw.logicalcpu': 8, 'kern.osversion': '18.7.0', 'kern.osrevision': '1518', 'hw.model': 'MacPro6,1'}
    module_mock = Mock()

# Generated at 2022-06-24 21:51:36.040912
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class_0 = DarwinHardware()
    get_system_profile_return_value = class_0.get_system_profile()

# Generated at 2022-06-24 21:51:46.768173
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
  hardware = DarwinHardware()
  hardware.sysctl = {
    'machdep.cpu.brand_string': 'Fake CPU string'
  }
  hardware.get_system_profile = lambda: {}
  assert hardware.get_cpu_facts() == {
    'processor': 'Fake CPU string',
    'processor_cores': ''
  }

  hardware.sysctl = {}
  hardware.get_system_profile = lambda: {
    'Processor Name': 'Fake CPU name',
    'Processor Speed': 'Fake CPU speed'
  }
  assert hardware.get_cpu_facts() == {
    'processor': 'Fake CPU name @ Fake CPU speed',
    'processor_cores': ''
  }


# Generated at 2022-06-24 21:52:08.108446
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    DarwinHardware = DarwinHardware()
    DarwinHardware.get_uptime_facts()


# Generated at 2022-06-24 21:52:12.007480
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()
    result = darwin_hardware.get_uptime_facts()
    for k in result.keys():
        print("{} : {}".format(k, result[k]))
    print(type(result))

if __name__ == '__main__':
    test_DarwinHardware_get_uptime_facts()

# Generated at 2022-06-24 21:52:16.983045
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    _fact_class = type('DarwinHardware', (object,), dict())
    _platform = type('str', (object,), dict())
    # Constructing an instance of class DarwinHardwareCollector
    darwin_hardware_collector_0 = DarwinHardwareCollector(fact_class=_fact_class, platform=_platform)


# Generated at 2022-06-24 21:52:21.267776
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_1 = DarwinHardwareCollector()
    assert darwin_hardware_collector_1._platform == 'Darwin'
    assert darwin_hardware_collector_1._fact_class == DarwinHardware


# Generated at 2022-06-24 21:52:25.981336
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # create instance of class DarwinHardware
    darwin_hardware_0 = DarwinHardware()
    # return value of get_system_profile
    return_value_get_system_profile = darwin_hardware_0.get_system_profile()
    assert isinstance(return_value_get_system_profile, dict) is True


# Generated at 2022-06-24 21:52:28.669677
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware_0 = DarwinHardwareCollector().collect()[0]
    system_profile_0 = darwin_hardware_0.get_system_profile()
    assert type(system_profile_0) == dict


# Generated at 2022-06-24 21:52:34.378225
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware_0 = DarwinHardware()
    darwin_hardware_0.sysctl = {'kern.boottime': '524536.5'}
    assert darwin_hardware_0.get_uptime_facts() == {'uptime_seconds': '175847'}

# Generated at 2022-06-24 21:52:39.736202
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Built-in time module has been broken on macOS 10.15.7 and 10.15.8:
    # https://github.com/python/cpython/issues/24435
    # https://bugs.python.org/issue38998

    # macOS 10.15.7 has been released on Dec 14, 2020.
    # macOS 10.15.8 has been released on Feb 8, 2021.
    darwin_hardware_0 = DarwinHardware({'module_setup': True}, {'ansible_system': 'Darwin', 'ansible_distribution_version': '10.15.7'})
    result = darwin_hardware_0.get_uptime_facts()
    assert result == {}

# Generated at 2022-06-24 21:52:50.700228
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {
        'hw.memsize': 24576,
        'kern.osversion': '',
        'kern.osrevision': '',
        'hw.model': '',
        'hw.physicalcpu': 2,
        'hw.logicalcpu': 4,
        'hw.ncpu': 4,
    }

# Generated at 2022-06-24 21:52:54.417085
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create an empty mocks
    sysctl = {}

    # Create a new instance of DarwinHardware
    darwin_hardware = DarwinHardware({}, sysctl=sysctl)

    # Test get_uptime_facts
    assert darwin_hardware.get_uptime_facts() == {}


# Generated at 2022-06-24 21:53:46.201181
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():

    mock_module = MagicMock()

# Generated at 2022-06-24 21:53:54.816066
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    DarwinHardwareInstance0 = DarwinHardware()
    DarwinHardwareInstance0.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz', 'machdep.cpu.core_count': '4'}
    DarwinHardwareInstance0.get_system_profile = test_case_0
    assert DarwinHardwareInstance0.get_cpu_facts() == {'processor': 'Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz', 'processor_cores': '4', 'processor_vcpus': ''}

# Generated at 2022-06-24 21:53:55.231469
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    pass

# Generated at 2022-06-24 21:54:00.758506
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    darwin_hardware_instance = DarwinHardware()
    darwin_hardware_instance.module = Mock()
    darwin_hardware_instance.sysctl = {'hw.memsize': '-1'}

    darwin_hardware_instance.module.run_command.return_value = (0, '', '')
    assert darwin_hardware_instance.get_memory_facts() == {'memfree_mb': 0, 'memtotal_mb': 0}



# Generated at 2022-06-24 21:54:04.488761
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_collector_0 = DarwinHardwareCollector()
    hardware_0 = darwin_hardware_collector_0.collect()
    assert hardware_0.get('processor') == 'Intel(R) Core(TM) i7-2675QM CPU @ 2.20GHz'


# Generated at 2022-06-24 21:54:07.173035
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    mac_facts = DarwinHardware().get_cpu_facts()
    assert 'processor_cores' in mac_facts
    assert 'processor_vcpus' in mac_facts
    assert 'processor' in mac_facts


# Generated at 2022-06-24 21:54:13.288456
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware_0 = DarwinHardware(module='test')
    darwin_hardware_0.sysctl = {'hw.memsize': '5210451968', 'kern.osversion': '15.6.0', 'kern.osrevision': '15G1004',
                                'machdep.cpu.core_count': '3', 'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz'}
    darwin_hardware_0.get_system_profile = lambda : {'Processor Name': 'Intel Core 2 Duo', 'Processor Speed': '2 GHz'}

# Generated at 2022-06-24 21:54:22.114664
# Unit test for method populate of class DarwinHardware

# Generated at 2022-06-24 21:54:24.532027
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware_0 = DarwinHardware(module=None)
    darwin_hardware_0.populate(collected_facts=None)


# Generated at 2022-06-24 21:54:34.145061
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    module_args = dict(
        gather_subset='all'
    )

    # initialise the object
    darwin_hardware = DarwinHardware(module_args)

    # populate darwin_hardware.sysctl with data
    test_data = dict()
    test_data['hw'] = dict()
    test_data['hw']['memsize'] = 1610612736
    test_data['hw']['model'] = 'Macmini6,2'
    test_data['machdep'] = dict()
    test_data['machdep']['cpu'] = dict()
    test_data['machdep']['cpu']['brand_string'] = 'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz'

# Generated at 2022-06-24 21:55:42.363780
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    pass


# Generated at 2022-06-24 21:55:45.954271
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bool_0)
    try:
        darwin_hardware_0.get_cpu_facts()
    except NameError:
        print("NameError in 0")


# Generated at 2022-06-24 21:55:48.811291
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bool_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:55:51.028570
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bool_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:56:00.669011
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bool_0)
    var_0 = darwin_hardware_0.get_system_profile()

# Generated at 2022-06-24 21:56:02.811904
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bool_0)
    assert darwin_hardware_0.get_mac_facts() == dict()


# Generated at 2022-06-24 21:56:05.719174
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    fact_class = DarwinHardware
    platform = DarwinHardwareCollector._platform
    darwin_hardware_collector_0 = DarwinHardwareCollector(fact_class, platform)

test_case_0()

# Generated at 2022-06-24 21:56:10.649504
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    bool_0 = True
    darwin_hardware_0 = DarwinHardware(bool_0)
    var_0 = darwin_hardware_0.get_mac_facts()


# Generated at 2022-06-24 21:56:12.829381
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    assert callable(getattr(DarwinHardware, "get_system_profile", None))


# Generated at 2022-06-24 21:56:17.038485
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    bool_0 = False
    darwin_hardware_0 = DarwinHardware(bool_0)
    var_0 = darwin_hardware_0.get_system_profile()
    print(var_0)

