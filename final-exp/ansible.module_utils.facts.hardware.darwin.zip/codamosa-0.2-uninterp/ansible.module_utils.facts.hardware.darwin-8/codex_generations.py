

# Generated at 2022-06-16 23:51:07.691763
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-16 23:51:17.481235
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 8
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == 8


# Generated at 2022-06-16 23:51:25.033413
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import pytest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

        def get_bin_path(self, name):
            return '/usr/bin/%s' % name

    # Create a mock module
    module = MockModule()

    # Create a fake sysctl output
    kern_boottime = int(time.time())
    struct_format = '@L'
    struct_size = struct.calcs

# Generated at 2022-06-16 23:51:29.395702
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:51:38.183743
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1510',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro12,1'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '1510'



# Generated at 2022-06-16 23:51:45.865740
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import pytest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Test data
    test_data = [
        # Test case 1:
        #   - sysctl returns a valid value
        #   - expected result: uptime_seconds
        {
            'sysctl_out': b'{ sec = 1528672959, usec = 0 }\n',
            'expected_result': {
                'uptime_seconds': 1528672959,
            },
        },
        # Test case 2:
        #   - sysctl returns an invalid value
        #   - expected result: empty dictionary
        {
            'sysctl_out': b'{ sec = 1528672959, usec = 0 }\n',
            'expected_result': {},
        },
    ]

   

# Generated at 2022-06-16 23:51:54.890408
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(DarwinHardware):
        def __init__(self):
            self.module = None

    dh = TestDarwinHardware()
    uptime_facts = dh.get_uptime_facts()
    uptime_seconds = uptime_facts.get('uptime_seconds')
    assert uptime_seconds is not None
    assert uptime_seconds >= 0
    assert uptime_seconds <= int(time.time())


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-16 23:52:00.640589
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['model']
    assert hardware.facts['osversion']
    assert hardware.facts['osrevision']
    assert hardware.facts['uptime_seconds']


# Generated at 2022-06-16 23:52:12.632960
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz',
        'machdep.cpu.core_count': '2',
        'hw.physicalcpu': '2',
        'hw.logicalcpu': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor_vcpus'] == '4'


# Generated at 2022-06-16 23:52:19.733143
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    # Test with a valid vm_stat output

# Generated at 2022-06-16 23:52:35.447255
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-16 23:52:43.226935
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module


# Generated at 2022-06-16 23:52:48.924181
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '16777216'}
    hardware.get_memory_facts()
    assert hardware.facts['memtotal_mb'] == 16
    assert hardware.facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:52:56.711917
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class MockModule(object):
        def run_command(self, command):
            return 0, '''
Hardware:

    Hardware Overview:

      Model Name: Mac Pro
      Model Identifier: MacPro3,1
      Processor Name: Quad-Core Intel Xeon
      Processor Speed: 2.8 GHz
      Number of Processors: 2
      Total Number of Cores: 8
      L2 Cache (per Processor): 12 MB
      Memory: 8 GB
      Bus Speed: 1.6 GHz
      Boot ROM Version: MP31.006C.B05
      SMC Version (system): 1.25f2
      Serial Number (system): G881603V2PY
      Hardware UUID: 00000000-0000-1000-8000-0017F2C3D8A3

''', ''
    hardware = DarwinHardware(MockModule())
    system_

# Generated at 2022-06-16 23:53:01.501815
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-16 23:53:11.596243
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '15.6.0',
        'kern.osrevision': '15G1004',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    else:
        hardware.sysctl['hw.model'] = ''
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']

# Generated at 2022-06-16 23:53:15.836032
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-16 23:53:18.897396
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:53:29.425301
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils.six import StringIO

    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: '/usr/bin/vm_stat',
    })()

    # Create a mock sysctl
    sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    sysctl['hw.memsize'] = '4294967296'

    #

# Generated at 2022-06-16 23:53:38.861078
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:53:56.463608
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts.utils import mock_command

    # Mock the module
    module = mock_module()

    # Mock the command
    mock_command(module, 'sysctl', '-b kern.boottime', b'\x00\x00\x00\x00\x00\x00\x00\x00')

    # Create the object
    darwin_hw = DarwinHardware(module)

    # Get the uptime facts
    uptime_facts = darwin_hw.get_uptime_facts()

    # Check the result
    assert uptime_facts == {'uptime_seconds': 0}

# Generated at 2022-06-16 23:54:06.877210
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.5 GHz'
    assert system_profile['Memory'] == '16 GB'
    assert system_profile['Serial Number (system)'] == 'C02LHACTFVH6'
    assert system_profile['Hardware UUID'] == 'E8F9C9D4-3E1A-5F4A-9E2A-F7B9A9B8E8F9'


# Generated at 2022-06-16 23:54:12.037667
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:54:13.956857
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class == DarwinHardware


# Generated at 2022-06-16 23:54:22.792474
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:54:33.965000
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''

    hardware.sysctl = {
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts

# Generated at 2022-06-16 23:54:42.131971
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import tempfile
    import unittest

    class TestDarwinHardware(DarwinHardware):
        def __init__(self, *args, **kwargs):
            self.module = unittest.mock.MagicMock()
            self.module.run_command.return_value = (0, '', '')
            self.module.get_bin_path.return_value = '/usr/sbin/system_profiler'

    class TestDarwinHardwareModule(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(os.rmdir, self.tmpdir)


# Generated at 2022-06-16 23:54:55.141024
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:55:04.871691
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.module = FakeModule()
            self.module.run_command = run_command
            self.module.get_bin_path = get_bin_path
            self.hw = DarwinHardware(self.module)

        def test_get_uptime_facts(self):
            # We need to mock the time.time() function to return a fixed value
            # so that we can test the uptime calculation.
            time_time_mock = lambda: 1500000000

# Generated at 2022-06-16 23:55:17.444199
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock module class
    class MockDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    # Create a mock module class
    class MockDarwinHardwareCollector(DarwinHardwareCollector):
        def __init__(self, module):
            self.module = module

    # Create a mock module class
    class MockAnsibleModule:
        def __init__(self, argument_spec, supports_check_mode):
            self.argument_spec = argument_spec
            self.supports_check_mode = supports_check_mode
            self.params = dict()


# Generated at 2022-06-16 23:55:49.734184
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_output as test_output
    test_module.run_command = lambda *args, **kwargs: (0, test_output, '')
    darwin_hardware = DarwinHardware(test_module)
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Model Identifier'] == 'MacBookPro11,3'
    assert system_profile['Processor Name'] == 'Intel Core i7'

# Generated at 2022-06-16 23:56:01.126288
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '17G65'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,3'
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '17G65'


# Generated at 2022-06-16 23:56:05.800384
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:56:13.692874
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'machdep.cpu.core_count': 4}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''

    hardware.sysctl = {'hw.physicalcpu': 4}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC'
    assert cpu

# Generated at 2022-06-16 23:56:21.013990
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:56:30.494577
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 8,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == 8


# Generated at 2022-06-16 23:56:43.659669
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import time
    import datetime
    import pytz

    # Get the current time
    now = time.time()

    # Get the current time in UTC
    utc_now = datetime.datetime.now(pytz.utc)

    # Get the current time in UTC in seconds
    utc_now_seconds = int(utc_now.strftime('%s'))

    # Get the current time in UTC in microseconds
    utc_now_microseconds = int(utc_now.strftime('%f'))

    # Get the current time in UTC in microseconds
    utc_now_microseconds = int(utc_now.strftime('%f'))

    # Create a DarwinHardware object
    darwin_hard

# Generated at 2022-06-16 23:56:56.985460
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3

    class MockModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = []
            self.run_command_kwargs = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def run_command(self, args, **kwargs):
            self.run_command_

# Generated at 2022-06-16 23:57:00.390717
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class == DarwinHardware

# Generated at 2022-06-16 23:57:11.429256
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    else:
        hardware.sysctl['hw.model'] = 'MacBookPro'
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro'
    assert mac_facts['osversion'] == '15.6.0'

# Generated at 2022-06-16 23:58:04.240581
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class == DarwinHardware

# Generated at 2022-06-16 23:58:11.817962
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    hardware = DarwinHardware(module)
    facts = hardware.populate()

    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-16 23:58:21.669456
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class ModuleStub:
        def run_command(self, command):
            return 0, """
Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro11,3
      Processor Name: Intel Core i7
      Processor Speed: 2.5 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 6 MB
      Memory: 16 GB
      Boot ROM Version: MBP112.0138.B16
      SMC Version (system): 2.19f12
      Serial Number (system): C02PQ0W5G8QH
      Hardware UUID: 00000000-0000-1000-8000-0026BB765291

""", ""
    module = ModuleStub()
    hardware = DarwinHardware(module)
    system

# Generated at 2022-06-16 23:58:26.347889
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector._platform == 'Darwin'
    assert hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:58:32.236475
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-16 23:58:35.758239
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:58:43.002187
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module

    # Test with empty output
    test_module.run_command = lambda *args, **kwargs: (0, '', '')
    assert DarwinHardware().get_system_profile() == dict()

    # Test with valid output

# Generated at 2022-06-16 23:58:53.095321
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '15G31'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,4'
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '15G31'



# Generated at 2022-06-16 23:58:59.516400
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import pytest
    import os
    import tempfile
    import time
    import struct

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Create a temporary file to store the output of sysctl
    (fd, sysctl_output_file) = tempfile.mkstemp()
    os.close(fd)

    # Get the current time in seconds
    current_time = int(time.time())

    # Create a string containing the output of sysctl
    # The output of sysctl is a struct containing the boot time in seconds
    # and microseconds.
    sysctl_output = struct.pack('@L', current_time)

    # Write the output of sysctl to the temporary file

# Generated at 2022-06-16 23:59:09.374238
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                       'machdep.cpu.core_count': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''

    hardware.sysctl = {'hw.physicalcpu': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == '4 @ '

# Generated at 2022-06-17 00:00:49.973190
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''
