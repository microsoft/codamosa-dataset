

# Generated at 2022-06-16 23:51:16.175791
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:51:24.957091
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)
            self.test_file = os.path.join(self.test_dir, 'system_profiler.txt')

# Generated at 2022-06-16 23:51:32.305151
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.model': 'MacBookPro12,1',
        'kern.osversion': '15.6.0',
        'kern.osrevision': '19G2021',
    }
    mac_facts = hardware.get_mac_facts()
    assert mac_facts == {
        'model': 'MacBookPro12,1',
        'osversion': '15.6.0',
        'osrevision': '19G2021',
    }


# Generated at 2022-06-16 23:51:34.994114
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:51:38.216029
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector._platform == 'Darwin'
    assert darwin_hw_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:51:48.898914
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_mount_points
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-16 23:51:59.537697
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '1510'}
    rc, out, err = module.run_command(["sysctl", "hw.model"])
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,4'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '1510'



# Generated at 2022-06-16 23:52:12.588427
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import pytest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Test with a valid output

# Generated at 2022-06-16 23:52:16.495351
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-16 23:52:24.771805
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock class
    class MockDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    # Create a mock sysctl
    class MockSysctl(dict):
        def __init__(self, module):
            self.module = module
            self['kern.boottime'] = '{ sec = 1512552825, usec = 0 } Sun Dec 10 15:27:05 2017'

    # Create a mock module.run_command
    class MockRunCommand(object):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-16 23:52:38.899339
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts


# Generated at 2022-06-16 23:52:49.591745
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0, 'machdep.cpu.brand_string: Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz', ''))
    module.run_command = MagicMock(return_value=(0, 'machdep.cpu.core_count: 4', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/system_profiler')
    module.run_command = MagicMock(return_value=(0, 'Processor Name: Intel Core i5', ''))

# Generated at 2022-06-16 23:52:57.073916
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['model'] == 'MacBookPro11,3'
    assert hardware.facts['osversion'] == '19.0.0'
    assert hardware.facts['osrevision'] == '15.0.0'
    assert hardware.facts['uptime_seconds'] > 0
    assert hardware.facts['memtotal_mb'] > 0
    assert hardware.facts['memfree_mb'] > 0
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware.facts['processor_cores'] == '4'
    assert hardware.facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:53:06.111637
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:53:14.954702
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.mock import patch

    # Mock the open builtin
    mock_open = patch.object(builtins, 'open', create=True)
    mock_open.start()
    mock_file = mock_open.return_value

    # Mock the get_file_content function
    mock_get_file_content = patch.object(get_file_content, 'get_file_content')
    mock_get_file_content.start()

    # Mock the run_command function
   

# Generated at 2022-06-16 23:53:25.121052
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1510',
    }
    hardware.module.run_command = MagicMock(return_value=(0, 'hw.model: MacBookPro11,3', ''))
    mac_facts = hardware.get_mac_facts()
    assert mac_facts == {
        'model': 'MacBookPro11,3',
        'product_name': 'MacBookPro11,3',
        'osversion': '16.7.0',
        'osrevision': '1510',
    }


# Generated at 2022-06-16 23:53:35.501462
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a fake module
    module = type('AnsibleModule', (object,), {'run_command': run_command_mock})
    module.run_command = run_command_mock
    # Create a fake class
    class_ = type('DarwinHardware', (object,), {'module': module})
    # Create an instance of the fake class
    obj = class_()
    # Call the method
    system_profile = obj.get_system_profile()
    # Check the result

# Generated at 2022-06-16 23:53:42.703243
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'


# Generated at 2022-06-16 23:53:47.574637
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0



# Generated at 2022-06-16 23:53:50.146132
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:54:18.342451
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = MockModule()

    # Create a mock command
    cmd = MockCommand()

    # Create a mock sysctl command
    sysctl_cmd = MockCommand()

    # Create a mock struct
    struct_mock = MockStruct()

    # Create a mock time
    time_mock = MockTime()

    # Create a mock DarwinHardware object
    darwin_hardware = DarwinHardware(module)

    # Set the mock command
    darwin_hardware.module.get_bin_path = Mock(return_value=cmd)

    # Set the mock sysctl command
    darwin_hardware.module.get_bin_path = Mock(return_value=sysctl_cmd)

    # Set the mock struct
    darwin_hardware.struct = struct_mock

    # Set the

# Generated at 2022-06-16 23:54:29.641494
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    # Test with Intel CPU
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6600U CPU @ 2.60GHz',
        'machdep.cpu.core_count': 2,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-6600U CPU @ 2.60GHz'
    assert cpu_facts['processor_cores'] == 2

    # Test with PowerPC CPU
    hardware.sysctl = {
        'hw.physicalcpu': 2,
    }

# Generated at 2022-06-16 23:54:39.357248
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz',
        'machdep.cpu.core_count': 4,
        'hw.physicalcpu': 2,
        'hw.logicalcpu': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == 4


# Generated at 2022-06-16 23:54:51.350001
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 8098
    assert hardware.facts['model'] == 'MacBookPro11,1'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:55:02.424800
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import Hardware
    from ansible.module_utils.facts.hardware.darwin import HardwareCollector
    from ansible.module_utils.facts.hardware.darwin import DarwinHardwareCollector
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_memory_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts

# Generated at 2022-06-16 23:55:05.481415
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts


# Generated at 2022-06-16 23:55:17.513427
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,3'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '15.6.0'


# Generated at 2022-06-16 23:55:26.298990
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:55:33.478966
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock_sysctl
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock_time
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock_struct
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock_struct_unpack

# Generated at 2022-06-16 23:55:42.445320
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.model': 'MacBookPro10,1',
        'kern.osversion': '15.6.0',
        'kern.osrevision': '19G2021',
    }
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro10,1'
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '19G2021'


# Generated at 2022-06-16 23:56:42.040078
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:56:49.450992
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 4
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 0
    assert hardware.facts['model'] == 'MacBookPro11,5'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] == 0

# Generated at 2022-06-16 23:56:54.623141
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'

# Generated at 2022-06-16 23:57:01.040049
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = DarwinHardware(module)
    facts = hardware.populate()

    assert facts['processor']
    assert facts['processor_cores']
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['model']
    assert facts['osversion']
    assert facts['osrevision']
    assert facts['uptime_seconds']

# Generated at 2022-06-16 23:57:12.025937
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import datetime
    import time
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            return 0, struct.pack('@L', int(time.time())), ''

        def get_bin_path(self, name):
            return name

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.module = MockModule()
            self.hardware = DarwinHardware(self.module)

        def test_get_uptime_facts(self):
            self.assertTrue(self.hardware.get_uptime_facts())

# Generated at 2022-06-16 23:57:18.360414
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['model']
    assert facts['osversion']
    assert facts['osrevision']
    assert facts['uptime_seconds']

# Generated at 2022-06-16 23:57:25.287038
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = type('test_module', (object,), {'run_command': lambda self, args: (0, '', '')})

# Generated at 2022-06-16 23:57:36.524084
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.3 GHz'
    assert system_profile['Memory'] == '16 GB'
    assert system_profile['Serial Number (system)'] == 'C02QH0JQG8WM'
    assert system_profile['Hardware UUID'] == 'E9C6D9C6-D3E8-5F1C-B1C3-F8D8B8C7E9D3'

# Generated at 2022-06-16 23:57:45.425563
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:57:50.006266
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['model'] == 'MacBookPro11,3'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == '4'
    assert hardware_facts['processor_vcpus'] == '8'
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 8078
    assert hardware_facts['uptime_seconds'] == 81709


# Generated at 2022-06-16 23:59:41.849421
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:59:51.984441
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_out as test_out
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_err as test_err
    test_module.run_command = lambda *args, **kwargs: (0, test_out, test_err)
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/system_profiler'

# Generated at 2022-06-16 23:59:57.717264
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-17 00:00:06.430295
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    hardware.module.run_command = MagicMock(return_value=(0, 'hw.model: MacBookPro11,1', ''))
    facts = hardware.get_mac_facts()
    assert facts['model'] == 'MacBookPro11,1'
    assert facts['osversion'] == '16.7.0'
    assert facts['osrevision'] == '15.6.0'


# Generated at 2022-06-17 00:00:12.241252
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-17 00:00:22.695304
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz',
        'machdep.cpu.core_count': '4',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-17 00:00:29.781796
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '17G65'
    assert mac_facts['model'] == 'MacBookPro14,3'


# Generated at 2022-06-17 00:00:40.210266
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '15G31'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-17 00:00:44.913179
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-17 00:00:48.623119
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0
