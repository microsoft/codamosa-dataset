

# Generated at 2022-06-16 23:51:18.326184
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '15G31'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,3'
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '15G31'



# Generated at 2022-06-16 23:51:21.238954
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class == DarwinHardware

# Generated at 2022-06-16 23:51:29.488373
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:51:37.393278
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 8
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 8096
    assert facts['model'] == 'MacBookPro11,3'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:51:45.314194
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module


# Generated at 2022-06-16 23:51:56.549219
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), dict(
        run_command=lambda self, cmd, encoding=None: (0, b'kern.boottime: { sec = 1489788367, usec = 0 } Thu Mar  9 21:06:07 2017', ''),
        get_bin_path=lambda self, name: '/usr/sbin/sysctl',
    ))()

    # Create a mock class
    class MockDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    # Create an instance of the mock class
    darwin_hardware = MockDarwinHardware(module)

    # Get the uptime facts
    uptime_facts = darwin_hardware.get_uptime_facts()

    # Assert

# Generated at 2022-06-16 23:51:59.108383
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-16 23:52:03.361897
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:52:05.365090
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:52:16.235956
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 8
    assert facts['memtotal_mb'] == 8192
    assert facts['memfree_mb'] == 496
    assert facts['model'] == 'MacBookPro11,1'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['uptime_seconds'] == 8


# Generated at 2022-06-16 23:52:33.668698
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(DarwinHardware):
        def __init__(self):
            self.module = None

    class TestModule(object):
        def __init__(self):
            self.run_command_results = []

        def run_command(self, cmd, encoding=None):
            return self.run_command_results.pop(0)

        def get_bin_path(self, name, opt_dirs=[]):
            return name

    class TestTime(object):
        def __init__(self):
            self.time_results = []

        def time(self):
            return self.time_results.pop(0)


# Generated at 2022-06-16 23:52:36.296244
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:52:40.140445
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:52:50.948915
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 8
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 5
    assert hardware_facts['model'] == 'MacBookPro11,3'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['uptime_seconds'] == 6


# Generated at 2022-06-16 23:53:01.390852
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                        'machdep.cpu.core_count': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:53:11.174769
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = DarwinHardware(module).populate()
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 4
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['memfree_mb'] == 5
    assert hardware_facts['model'] == 'MacBookPro11,1'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['uptime_seconds'] == 8


# Generated at 2022-06-16 23:53:22.087138
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, encoding=None: (0, b'kern.boottime: { sec = 1476172629, usec = 0 }\n', None),
        'get_bin_path': lambda self, name: '/usr/sbin/sysctl'
    })()

    # Create a mock class
    class MockDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    # Create an instance of the mock class
    darwin_hardware = MockDarwinHardware(module)

    # Call the method
    uptime_facts = darwin_hardware.get_uptime_facts()

    # Assert that the method returns the expected value
   

# Generated at 2022-06-16 23:53:32.986749
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = MockModule()

    # Create a mock sysctl command
    sysctl_cmd = 'sysctl'
    module.get_bin_path.return_value = sysctl_cmd

    # Create a mock output for the sysctl command

# Generated at 2022-06-16 23:53:40.530867
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '15G31'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:53:49.278385
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 8
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 8094
    assert facts['model'] == 'MacBookPro11,3'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['uptime_seconds'] == 805


# Generated at 2022-06-16 23:54:10.965828
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:54:15.315777
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['model']
    assert facts['osversion']
    assert facts['osrevision']
    assert facts['uptime_seconds']

# Generated at 2022-06-16 23:54:21.191053
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)

    # Test with Intel CPU
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4'
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'

    # Test with PowerPC CPU
    hardware.sysctl = {
        'hw.physicalcpu': '2'
    }

# Generated at 2022-06-16 23:54:30.357005
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:54:35.159835
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= memory_facts['memfree_mb']

# Generated at 2022-06-16 23:54:42.797293
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz',
        'machdep.cpu.core_count': '4',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:54:48.174432
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-16 23:54:59.301003
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:55:07.261440
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 4
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['memfree_mb'] == 4981
    assert hardware_facts['model'] == 'MacBookPro12,1'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['uptime_seconds'] == 804


# Generated at 2022-06-16 23:55:18.866209
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                       'machdep.cpu.core_count': '4',
                       'hw.physicalcpu': '4',
                       'hw.logicalcpu': '8'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:56:14.317957
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Test with vm_stat output
    module = FakeModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = dict()
    hardware.sysctl['hw.memsize'] = '1073741824'

# Generated at 2022-06-16 23:56:26.870340
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Test case 1: vm_stat command returns valid output
    module = FakeModule()

# Generated at 2022-06-16 23:56:29.366788
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:56:31.543077
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:56:40.502846
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'uptime_seconds' in facts

# Generated at 2022-06-16 23:56:41.662076
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:56:49.491183
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:56:53.461382
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:57:04.941121
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import time
    import unittest

    class TestDarwinHardware(DarwinHardware):
        def __init__(self):
            self.module = None
            self.sysctl = None

    class TestHardware(Hardware):
        def __init__(self):
            self.module = None
            self.sysctl = None

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/sbin/sysctl'


# Generated at 2022-06-16 23:57:13.990430
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import unittest
    import mock

    class TestDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    class TestModule(object):
        def __init__(self):
            self.run_command = mock.Mock()

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

    class TestDarwinHardwareCollector(DarwinHardwareCollector):
        def __init__(self, module):
            self.module = module

    class TestDarwinHardwareCollectorCase(unittest.TestCase):
        def setUp(self):
            self.module = TestModule()

# Generated at 2022-06-16 23:59:09.454476
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_mac_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_cpu_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_memory_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_populate

# Generated at 2022-06-16 23:59:14.591584
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['model']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert hardware_facts['uptime_seconds']

# Generated at 2022-06-16 23:59:19.142518
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:59:23.705858
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['memfree_mb'] <= memory_facts['memtotal_mb']

# Generated at 2022-06-16 23:59:29.022780
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-16 23:59:37.420108
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import run_command
    from ansible.module_utils.facts.hardware.darwin import struct
    from ansible.module_utils.facts.hardware.darwin import time

    class TestModule(object):
        def get_bin_path(self, name):
            return '/usr/bin/vm_stat'


# Generated at 2022-06-16 23:59:47.914218
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 8
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 8072
    assert hardware_facts['model'] == 'MacBookPro11,4'
    assert hardware_facts['osversion'] == '15.0.0'
    assert hardware_facts['osrevision'] == '15A284'
    assert hardware_facts['uptime_seconds'] == 1234


# Generated at 2022-06-16 23:59:56.798330
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import mock_module

    # Create a mock module
    module = mock_module()

    # Create a mock module.run_command
    def mock_run_command(cmd, encoding=None):
        if cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']:
            return 0, b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', ''
        else:
            return 1, '', ''
    module.run_command = mock_run_command

    # Create a mock module.get_bin_path

# Generated at 2022-06-17 00:00:00.760767
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-17 00:00:11.483761
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 4
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 8192
    assert hardware.facts['model'] == 'Macmini6,2'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] == 5
