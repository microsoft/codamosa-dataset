

# Generated at 2022-06-16 23:51:20.434844
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock module class
    class MockModule(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, executable):
            return '/usr/sbin/sysctl'

        def run_command(self, cmd, encoding=None):
            return (0, 'kern.boottime: { sec = 1523361152, usec = 0 }', '')

    module.AnsibleModule = MockModule
    module.AnsibleModule.__init__ = lambda self, argument_spec: None

    # Create a mock sysctl class

# Generated at 2022-06-16 23:51:28.923126
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 4
    assert facts['memtotal_mb'] == 8192
    assert facts['memfree_mb'] == 7078
    assert facts['model'] == 'MacBookAir7,2'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['uptime_seconds'] == 888

# Generated at 2022-06-16 23:51:34.994586
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import time

    # Create a DarwinHardware object
    darwin_hardware = DarwinHardware()

    # Get the current time
    current_time = time.time()

    # Get the uptime_seconds
    uptime_seconds = darwin_hardware.get_uptime_facts()['uptime_seconds']

    # Check that the uptime_seconds is not greater than the current time
    assert uptime_seconds <= current_time

# Generated at 2022-06-16 23:51:38.215794
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:51:45.655860
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 4
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 4981
    assert hardware.facts['model'] == 'MacBookPro11,1'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:51:56.858101
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Test with a valid output
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', ''))
    hardware = DarwinHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {'uptime_seconds': 0}

    # Test with an invalid output
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, b'', ''))
    hardware = DarwinHardware(module)
    uptime_facts = hardware.get_uptime

# Generated at 2022-06-16 23:52:02.820188
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['model']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert hardware_facts['uptime_seconds']

# Generated at 2022-06-16 23:52:14.805934
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import MockModule
    from ansible.module_utils.facts.utils import MockCommand
    from ansible.module_utils.facts.utils import MockFile
    from ansible.module_utils.facts.utils import MockOS
    from ansible.module_utils.facts.utils import MockTime

    # Mock the module
    module = MockModule()

    # Mock the command
    sysctl_cmd = '/usr/sbin/sysctl'
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    module.run_command.return_value = (0, b'\x00\x00\x00\x00\x00\x00\x00\x00', '')

# Generated at 2022-06-16 23:52:17.547578
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:52:20.907887
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_vcpus']

# Generated at 2022-06-16 23:52:40.418925
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''

    hardware.sysctl = {
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts

# Generated at 2022-06-16 23:52:44.481704
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.memsize': '4294967296',
    }
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:52:54.953693
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_output as test_output

    test_module.run_command = lambda *args, **kwargs: (0, test_output, '')
    hardware = DarwinHardware(test_module)
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.3 GHz'

# Generated at 2022-06-16 23:53:07.198323
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = MockModule()

    # Create a mock module.run_command
    module.run_command = Mock(return_value=(0, b'\x00\x00\x00\x00\x00\x00\x00\x00', ''))

    # Create a DarwinHardware object
    darwin_hardware = DarwinHardware(module)

    # Call the get_uptime_facts method
    uptime_facts = darwin_hardware.get_uptime_facts()

    # Assert that the uptime_facts is a dictionary
    assert isinstance(uptime_facts, dict)

    # Assert that the uptime_facts contains the key 'uptime_seconds'
    assert 'uptime_seconds' in uptime_facts

    # Assert that the uptime_facts['uptime

# Generated at 2022-06-16 23:53:15.586327
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Test data
    test_data = """Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro11,1
      Processor Name: Intel Core i7
      Processor Speed: 2.2 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 6 MB
      Memory: 16 GB
      Boot ROM Version: MBP111.0138.B16
      SMC Version (system): 2.18f15
      Serial Number (system): C02PQ0QUGVH5
      Hardware UUID: E811E1A7-2D41-5E44-9207-9BAD7ED49CE1

    """

    # Create a DarwinHardware object
    darwin_hardware = DarwinHardware()

   

# Generated at 2022-06-16 23:53:26.564753
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-16 23:53:30.229915
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(DarwinHardware):
        def __init__(self):
            self.sysctl = {'kern.boottime': int(time.time()) - 10}

    dh = TestDarwinHardware()
    uptime_facts = dh.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 10

# Generated at 2022-06-16 23:53:38.614889
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 4
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 9091
    assert facts['model'] == 'MacBookPro11,1'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['uptime_seconds'] == 578

# Generated at 2022-06-16 23:53:47.096613
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz',
                       'machdep.cpu.core_count': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:53:50.358959
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_vcpus']

# Generated at 2022-06-16 23:54:17.151542
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, command: (0, 'Pages wired down:  595\nPages active:     595\nPages inactive:   595\n', ''),
    })()

    # Create a mock module
    hardware = DarwinHardware(module)

    # Get memory facts
    memory_facts = hardware.get_memory_facts()

    # Assert that the memory facts are correct
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:54:28.948157
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1510',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']

# Unit

# Generated at 2022-06-16 23:54:31.807390
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:54:38.132493
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-16 23:54:41.029307
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:54:54.062203
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.darwin_hardware = DarwinHardware()

        def test_get_uptime_facts(self):
            self.darwin_hardware.module = sys.modules[__name__]
            uptime_facts = self.darwin_hardware.get_uptime_facts()
            self.assertTrue('uptime_seconds' in uptime_facts)
            self.assertTrue(isinstance(uptime_facts['uptime_seconds'], int))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestDarwinHardware)

# Generated at 2022-06-16 23:54:56.476842
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:54:59.941399
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector._platform == 'Darwin'
    assert darwin_hw_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:55:07.591243
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_output as test_output

    # Create a fake module
    module = test_module.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Create a fake DarwinHardware object
    darwin_hardware = DarwinHardware(module)

    # Create a fake system_profiler output
    system_profiler_output = test_output.SYSTEM_PROFILER_OUTPUT

    # Create a fake run_command method

# Generated at 2022-06-16 23:55:19.605716
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_out as test_out
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_err as test_err
    test_module.run_command = lambda *args, **kwargs: (0, test_out, test_err)
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/system_profiler'
    hardware = DarwinHardware(test_module)

# Generated at 2022-06-16 23:55:50.466418
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0, 'hw.model: MacBookPro11,1', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/system_profiler')
    module.run_command = MagicMock(return_value=(0, '', ''))
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.5.0', 'kern.osrevision': '15.5.0'}
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,1'

# Generated at 2022-06-16 23:56:00.183263
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import get_file_content
    import time
    import pytest

    # Get the current time
    now = time.time()

    # Create a fake sysctl command that returns the current time
    sysctl_cmd = "echo 'kern.boottime: {0} 0'".format(int(now))

    # Create a fake DarwinHardware object
    hardware = DarwinHardware(None, sysctl_cmd)

    # Get the uptime facts
    uptime_facts = hardware.get_uptime_facts()

    # Assert that the uptime is correct
    assert uptime_facts['uptime_seconds'] == int(now)

# Generated at 2022-06-16 23:56:10.860595
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:56:23.243589
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = type('test_module', (object,), {'run_command': lambda self, *args, **kwargs: (0, '', '')})

# Generated at 2022-06-16 23:56:28.904255
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert 'Model Name' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile
    assert 'Memory' in system_profile
    assert 'Serial Number (system)' in system_profile
    assert 'Hardware UUID' in system_profile


# Generated at 2022-06-16 23:56:41.727544
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 8
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 8071
    assert hardware_facts['model'] == 'MacBookPro11,3'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts

# Generated at 2022-06-16 23:56:49.510347
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock module
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Create a mock module
    module.get_bin_path = MagicMock(return_value='/usr/sbin/sysctl')

    # Create a mock module
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Create a mock module
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Create a mock module
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Create a mock module

# Generated at 2022-06-16 23:56:59.357154
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import tempfile
    import shutil
    import time
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module
    module_path = os.path.join(tmpdir, 'test_darwin_hardware.py')

# Generated at 2022-06-16 23:57:03.720869
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-16 23:57:12.339566
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '17G65'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        mac_facts = hardware.get_mac_facts()
        assert mac_facts['model'] == out.splitlines()[-1].split()[1]
        assert mac_facts['osversion'] == '15.6.0'
        assert mac_facts['osrevision'] == '17G65'


# Generated at 2022-06-16 23:57:46.127310
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_memory_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import test_get_bin_path
    from ansible.module_utils.facts.hardware.darwin import test_get_sysctl

# Generated at 2022-06-16 23:57:55.037760
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = MockModule()

    # Create a mock module.run_command
    def mock_run_command(cmd, encoding=None):
        if cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']:
            return 0, b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', ''
        else:
            return 1, '', ''

    module.run_command = mock_run_command

    # Create a mock module.get_bin_path
    def mock_get_bin_path(name):
        return '/usr/sbin/sysctl'

    module.get_bin_path = mock_get

# Generated at 2022-06-16 23:57:59.891533
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-16 23:58:06.606918
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert 'Model Name' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile
    assert 'Memory' in system_profile
    assert 'Serial Number' in system_profile
    assert 'Hardware UUID' in system_profile


# Generated at 2022-06-16 23:58:18.151753
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_out as test_out
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_err as test_err

    # Create a mock module
    module = test_module.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a mock command
    command = test_module.Command(module)

    # Create a mock run_command

# Generated at 2022-06-16 23:58:24.331277
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    test_module.run_command = lambda *args, **kwargs: (0, '', '')
    test_module.run_command.__name__ = 'run_command'
    test_module.run_command.__module__ = 'ansible.module_utils.facts.hardware.darwin'
    test_module.run_command.__wrapped__ = test_module.run_command
    test_module.run_command.__self__ = test_module
    test_module.run_command.__doc__ = 'Mock run_command'
    test_module.run_command.__dict__

# Generated at 2022-06-16 23:58:35.308120
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})

# Generated at 2022-06-16 23:58:40.890000
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['model']
    assert hardware.facts['osversion']
    assert hardware.facts['osrevision']
    assert hardware.facts['uptime_seconds']


# Generated at 2022-06-16 23:58:51.123968
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform
    import sys

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_results = []
            self.run_command_exceptions = []

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            if self.run_command_exceptions:
                raise self.run_command_exceptions.pop(0)
            return self.run_command_results.pop(0)

        def get_bin_path(self, name):
            return '/usr/bin/' + name

    # Create a mock time module
    class MockTime(object):
        def __init__(self):
            self.time_calls = []


# Generated at 2022-06-16 23:58:54.167508
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:59:28.871032
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:59:35.959456
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz',
                        'machdep.cpu.core_count': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:59:37.916416
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:59:47.980702
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module_utils
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module_utils_common
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module_utils_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module_utils_facts_

# Generated at 2022-06-16 23:59:56.608445
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    facts = hardware.get_mac_facts()
    assert facts['model'] == 'MacBookPro10,1'
    assert facts['osversion'] == '16.7.0'
    assert facts['osrevision'] == '15.6.0'


# Generated at 2022-06-17 00:00:03.951526
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['model']
    assert hardware.facts['osversion']
    assert hardware.facts['osrevision']
    assert hardware.facts['uptime_seconds']


# Generated at 2022-06-17 00:00:12.927930
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 10984
    assert hardware.facts['model'] == 'MacBookPro11,1'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:00:23.003062
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1510',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']

# Unit

# Generated at 2022-06-17 00:00:34.328382
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-17 00:00:41.567936
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def get_bin_path(self, name):
            return '/usr/sbin/' + name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls += 1