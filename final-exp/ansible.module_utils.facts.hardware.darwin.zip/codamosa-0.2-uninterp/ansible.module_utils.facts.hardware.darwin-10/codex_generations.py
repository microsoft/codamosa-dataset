

# Generated at 2022-06-16 23:51:07.218211
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:51:17.572808
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:51:21.771155
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:51:25.521301
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-16 23:51:28.403368
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:51:33.823985
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'uptime_seconds' in facts

# Generated at 2022-06-16 23:51:43.153139
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_out as test_out
    test_module.run_command = lambda *args, **kwargs: (0, test_out, '')
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/system_profiler'
    test_module.params = {}
    test_module.params['gather_subset'] = ['!all', '!min']
    test_module.params['gather_timeout'] = 10
    test_module.params

# Generated at 2022-06-16 23:51:48.686897
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0



# Generated at 2022-06-16 23:51:54.208507
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:52:03.673586
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 4
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 6096
    assert hardware.facts['model'] == 'MacBookPro11,1'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] == 807


# Generated at 2022-06-16 23:52:18.213726
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert 'Model Name' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile
    assert 'Memory' in system_profile
    assert 'Serial Number' in system_profile
    assert 'Hardware UUID' in system_profile


# Generated at 2022-06-16 23:52:20.864620
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class == DarwinHardware

# Generated at 2022-06-16 23:52:31.051419
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:52:34.190240
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-16 23:52:41.759224
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1510',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,3'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '1510'


# Generated at 2022-06-16 23:52:52.136088
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl

    # Test for Intel
    sysctl = get_sysctl(None, ['hw', 'machdep', 'kern'])
    sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i7-3615QM CPU @ 2.30GHz'
    sysctl['machdep.cpu.core_count'] = 4
    sysctl['hw.logicalcpu'] = 8
    sysctl['hw.ncpu'] = 8
    sysctl['hw.physicalcpu'] = 4

    darwin_hardware = DarwinHardware(None)
    darwin_hardware.sysctl = sysctl
    cpu_facts = darwin

# Generated at 2022-06-16 23:53:04.105624
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {'run_command': run_command})

    # Create a mock module
    hardware = DarwinHardware(module)

    # Create a mock sysctl command
    sysctl_cmd = '/usr/sbin/sysctl'

    # Create a mock output for the sysctl command
    sysctl_out = b'kern.boottime: { sec = 1512557926, usec = 0 }\n'

    # Create a mock time
    time_time = 1512557926

    # Create a mock time module
    time_module = type('time', (object,), {'time': time_time})

    # Create a mock struct module
    struct_module = type('struct', (object,), {'unpack': unpack})

    # Create a

# Generated at 2022-06-16 23:53:08.838115
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:53:19.552427
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 4
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 7094
    assert hardware_facts['model'] == 'MacBookPro11,1'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['uptime_seconds'] == 467


# Generated at 2022-06-16 23:53:30.127228
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)

    # Test with Intel CPU
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''

    # Test with PowerPC CPU

# Generated at 2022-06-16 23:53:49.905101
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test for Intel
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    module = FakeModule(sysctl=sysctl)
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'

    # Test for PowerPC
    sysctl = {
        'hw.physicalcpu': '2',
    }
    module = FakeModule(sysctl=sysctl)
    hardware = DarwinHardware(module)


# Generated at 2022-06-16 23:53:51.429443
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:53:59.764915
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    hardware.module.run_command = Mock(return_value=(0, 'hw.model: MacBookPro11,4', ''))
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,4'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '15.6.0'


# Generated at 2022-06-16 23:54:10.381195
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_args = []
            self.run_command_kwargs = []

        def get_bin_path(self, name):
            return name

        def run_command(self, args, encoding=None):
            self.run_command_calls += 1
            self.run_command_args.append(args)
            self.run_command_kwargs.append(encoding)

            # Return a fake boottime
            boottime = int(time.time()) - 42
            return (0, struct.pack('@L', boottime), '')

    module = FakeModule

# Generated at 2022-06-16 23:54:17.045874
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                        'machdep.cpu.core_count': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:54:21.800117
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-16 23:54:31.806895
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert facts['processor_cores'] == '4'
    assert facts['processor_vcpus'] == '4'
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 8098
    assert facts['model'] == 'MacBookPro11,4'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G73'
    assert facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:54:41.033445
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0

    hardware.sysctl = {'hw.memsize': '1073741824'}
    hardware.module.run_command = MagicMock(return_value=(0, 'Pages wired down:   516\nPages active:      516\nPages inactive:    516\n', ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 512



# Generated at 2022-06-16 23:54:54.061903
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import tempfile
    import shutil
    import time
    import struct
    import subprocess
    import unittest

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []
            self.run_command_encodings = []

        def get_bin_path(self, name):
            return '/usr/bin/' + name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            self.run_command_encodings.append(encoding)
            rc = self.run_

# Generated at 2022-06-16 23:55:04.019325
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:55:23.687457
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = self.fake_run_command
            self.get_bin_path = self.fake_get_bin_path


# Generated at 2022-06-16 23:55:31.701923
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import get_system_profile
    from ansible.module_utils.facts.hardware.darwin import get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import populate
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_memory_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts

# Generated at 2022-06-16 23:55:42.128139
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock class
    class MockDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module
            self.sysctl = {
                'hw.memsize': '4294967296',
            }

        def get_system_profile(self):
            return dict()

    # Create a mock class
    class MockDarwinHardware2(DarwinHardware):
        def __init__(self, module):
            self.module = module
            self.sysctl = {
                'hw.memsize': '4294967296',
            }

        def get_system_profile(self):
            return dict()


# Generated at 2022-06-16 23:55:45.007721
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:55:51.595881
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import populate
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_memory_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_populate

# Generated at 2022-06-16 23:55:55.967432
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_vcpus']


# Generated at 2022-06-16 23:56:07.209396
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import time
    import struct

    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get raw bytes, not UTF-8.
    # We need to get

# Generated at 2022-06-16 23:56:12.184336
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_vcpus'] > 0
    assert hardware_facts['model']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert hardware_facts['processor']

# Generated at 2022-06-16 23:56:24.326016
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins

    # Mock the module
    module = type('AnsibleModule', (object,), {'run_command': lambda *args, **kwargs: (0, '', '')})()

    # Mock the run_command method

# Generated at 2022-06-16 23:56:28.904631
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:57:00.563405
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['model'] == 'MacBookPro'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-8559U CPU @ 2.70GHz'
    assert hardware_facts['processor_cores'] == '4'
    assert hardware_facts['processor_vcpus'] == '8'
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 5
    assert hardware_facts['uptime_seconds'] > 0


# Generated at 2022-06-16 23:57:11.646899
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, command, encoding=None):
            self.run_command_calls.append(command)

# Generated at 2022-06-16 23:57:21.881919
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import time

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_args = []
            self.run_command_kwargs = []

        def get_bin_path(self, name):
            return '/usr/bin/' + name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls += 1
            self.run_command_args.append(cmd)
            self.run_command_kwargs.append(encoding)

            # Return a fake boottime
            boottime = int(time.time()) - 100
            return 0, struct.pack('@L', boottime), ''



# Generated at 2022-06-16 23:57:27.418176
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.memsize': '1073741824',
    }
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:57:36.210261
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python script
    script_file = os.path.join(tmpdir, 'script.py')

# Generated at 2022-06-16 23:57:47.477982
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '15G31'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:57:53.174028
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['model'] == 'MacBookPro11,4'
    assert hardware_facts['osversion'] == '16.7.0'
    assert hardware_facts['osrevision'] == '15.7.0'
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 8
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 8073
    assert hardware_facts['uptime_seconds'] > 0


# Unit test

# Generated at 2022-06-16 23:58:02.640201
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:58:13.518358
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    test_module.run_command = lambda *args, **kwargs: (0, '', '')
    test_module.run_command.__name__ = 'run_command'
    test_module.run_command.__module__ = 'ansible.module_utils.common.process'
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/system_profiler'
    test_module.get_bin_path.__name__ = 'get_bin_path'

# Generated at 2022-06-16 23:58:18.026882
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'

# Generated at 2022-06-16 23:59:27.018169
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module

# Generated at 2022-06-16 23:59:38.073389
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_output as test_output

    test_module.run_command = lambda *args, **kwargs: (0, test_output, '')
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/system_profiler'

    hardware = DarwinHardware(test_module)
    system_profile = hardware.get_system_profile()


# Generated at 2022-06-16 23:59:43.328098
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def run_command(self, args, encoding=None):
            self.run_command_count += 1
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    class MockSysctl(object):
        def __init__(self):
            self.sysctl = dict()

        def __getitem__(self, key):
            return self.sysctl[key]

        def __contains__(self, key):
            return key in self.sysctl

    module = MockModule()
    sysctl = MockSysctl

# Generated at 2022-06-16 23:59:53.130467
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # The following is the output of the command sysctl -b kern.boottime
    # on a Mac OS X 10.11.6.

# Generated at 2022-06-17 00:00:03.175593
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                       'machdep.cpu.core_count': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-17 00:00:13.121179
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-17 00:00:18.012288
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-17 00:00:27.785418
# Unit test for method get_uptime_facts of class DarwinHardware

# Generated at 2022-06-17 00:00:39.546458
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module

    # Create a test module
    test_module.ANSIBLE_MODULE_ARGS = {}
    test_module.ANSIBLE_MODULE_KWARGS = {}
    test_module.module = test_module

    # Create a test DarwinHardware object
    darwin_hardware = DarwinHardware(test_module)

    # Create a test system profile

# Generated at 2022-06-17 00:00:49.283382
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['model'] == 'MacBookPro11,3'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['uptime_seconds'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 8