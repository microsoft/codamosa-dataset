

# Generated at 2022-06-16 23:51:18.548260
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i5'
    assert system_profile['Processor Speed'] == '2.3 GHz'
    assert system_profile['Number of Processors'] == '1'
    assert system_profile['Total Number of Cores'] == '2'
    assert system_profile['L2 Cache (per Core)'] == '256 KB'
    assert system_profile['L3 Cache'] == '3 MB'
    assert system_profile['Memory'] == '8 GB'

# Generated at 2022-06-16 23:51:28.489085
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock class
    class MockDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    # Create a mock sysctl command
    class MockSysctlCommand(object):
        def __init__(self, module):
            self.module = module

        def __call__(self, *args, **kwargs):
            # Return a fake sysctl command
            return ['/usr/sbin/sysctl', '-b', 'kern.boottime']

    # Create a mock run_command method
    class MockRunCommand(object):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-16 23:51:37.466955
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    test_data = """Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro11,4
      Processor Name: Intel Core i7
      Processor Speed: 2.2 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 6 MB
      Memory: 16 GB
      Boot ROM Version: MBP114.0172.B00
      SMC Version (system): 2.19f12
      Serial Number (system): C02QG0JUDTFD
      Hardware UUID: 00000000-0000-1000-8000-0026BB765291

"""

# Generated at 2022-06-16 23:51:40.999572
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    mac_facts = hardware.get_mac_facts()
    assert 'model' in mac_facts
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts


# Generated at 2022-06-16 23:51:51.420450
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 8096
    assert hardware.facts['model'] == 'MacBookPro11,3'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] == 10

# Generated at 2022-06-16 23:52:01.787157
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_output as test_output

    test_module.run_command = lambda *args, **kwargs: (0, test_output, '')
    darwin_hardware = DarwinHardware(test_module)
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Model Identifier'] == 'MacBookPro11,4'

# Generated at 2022-06-16 23:52:05.063885
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:52:16.739905
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts
    import time

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_args = []
            self.run_command_kwargs = []
            self.run_command_results = []

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls += 1
            self.run_command_args.append(cmd)
            self.run_command_kwargs.append(encoding)
            return self

# Generated at 2022-06-16 23:52:24.448606
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 8
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 8500
    assert facts['model'] == 'MacBookPro11,5'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['uptime_seconds'] > 0


# Generated at 2022-06-16 23:52:33.916821
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import struct

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python module
    module_path = os.path.join(tmpdir, 'test_ansible_module.py')
    with open(module_path, 'w') as f:
        f.write("""
from ansible.module_utils.facts.hardware.darwin import DarwinHardware

module = AnsibleModule(argument_spec={})

dh = DarwinHardware(module)
facts = dh.get_uptime_facts()

module.exit_json(changed=False, ansible_facts=facts)
""")

    # Run the temporary python module

# Generated at 2022-06-16 23:52:54.421541
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:53:06.626405
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:53:15.246499
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:53:26.473209
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts as test_func

    # Test case 1:
    #   - kern.boottime = 1557984707
    #   - time.time() = 1557984767
    #   - expected uptime_seconds = 60
    test_case = 1
    test_obj = DarwinHardware()
    test_obj.sysctl = {'kern.boottime': '1557984707 0'}
    test_obj.module = MockModule()

# Generated at 2022-06-16 23:53:29.942936
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '4'


# Generated at 2022-06-16 23:53:33.504667
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:53:40.830377
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_output as test_output

    test_module.run_command = lambda *args, **kwargs: (0, test_output, '')
    hardware = DarwinHardware(test_module)
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Identifier'] == 'MacBookPro11,3'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.5 GHz'
    assert system

# Generated at 2022-06-16 23:53:50.145929
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_output as test_output

    test_module.run_command = lambda *args, **kwargs: (0, test_output, '')
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/system_profiler'

    dh = DarwinHardware(test_module)
    system_profile = dh.get_system_profile()

    assert system_profile['Model Identifier'] == 'MacBookPro11,3'

# Generated at 2022-06-16 23:53:56.716172
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import run_command
    from ansible.module_utils.facts.hardware.darwin import get_system_profile
    from ansible.module_utils.facts.hardware.darwin import get_mac_facts
    from ansible.module_utils.facts.hardware.darwin import get_cpu_facts
    from ansible.module_utils.facts.hardware.darwin import get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import populate
   

# Generated at 2022-06-16 23:54:07.951202
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.3 GHz'
    assert system_profile['Memory'] == '16 GB'
    assert system_profile['Serial Number (system)'] == 'C02QHACGFVH6'
    assert system_profile['Hardware UUID'] == 'D0A8D0D8-C9E5-5B4D-8A5B-F5B5C5F5C5C5'
    assert system_profile['SMC Version (system)'] == '2.28f7'


# Generated at 2022-06-16 23:54:39.554999
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''

    hardware.sysctl = {
        'hw.physicalcpu': 2,
        'hw.logicalcpu': 4,
    }
    cpu_facts = hardware.get_

# Generated at 2022-06-16 23:54:52.069177
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Model Identifier'] == 'MacBookPro11,4'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.5 GHz'
    assert system_profile['Number of Processors'] == '1'
    assert system_profile['Total Number of Cores'] == '4'
    assert system_profile['L2 Cache (per Core)'] == '256 KB'
    assert system_profile['L3 Cache'] == '6 MB'
    assert system_profile['Memory'] == '16 GB'

# Generated at 2022-06-16 23:54:55.559819
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:55:05.168419
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module

# Generated at 2022-06-16 23:55:09.190535
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:55:20.773561
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts
    import time

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

        def get_bin_path(self, arg):
            return '/usr/sbin/sysctl'

    # Create a mock module
    module = MockModule()

    # Create a mock time

# Generated at 2022-06-16 23:55:22.980615
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0


# Generated at 2022-06-16 23:55:25.560891
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:55:32.951356
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:55:36.495504
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:56:42.342699
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform
    import sys
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_results = []

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

        def get_bin_path(self, name):
            return '/usr/bin/' + name

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.module = MockModule()

# Generated at 2022-06-16 23:56:49.823095
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock_run_command
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock_run_command_rc
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock_run_command_out
   

# Generated at 2022-06-16 23:57:01.433389
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware(None)
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.8 GHz'
    assert system_profile['Memory'] == '16 GB'
    assert system_profile['Serial Number (system)'] == 'C02QV8U6DTFD'
    assert system_profile['Hardware UUID'] == 'D9D9F9D4-D7D2-5C4C-B8B2-E5E7F2E3E4E5'

# Generated at 2022-06-16 23:57:12.340571
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_system_profile
    from ansible.module_utils.facts.hardware.darwin import get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import get_mac_facts
    from ansible.module_utils.facts.hardware.darwin import get_cpu_facts
    from ansible.module_utils.facts.hardware.darwin import DarwinHardwareCollector
    from ansible.module_utils.facts.hardware.base import HardwareCollector

# Generated at 2022-06-16 23:57:22.249170
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform
    import time
    import unittest

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.dh = DarwinHardware()
            self.dh.module = MockModule()

        def test_get_uptime_facts(self):
            # Test with a valid output
            self.dh.module.run_command.return_value = (0, b'\x00\x00\x00\x00\x00\x00\x00\x00', None)
            uptime_facts = self.dh.get_uptime_facts()
            self.assertEqual(uptime_facts, {'uptime_seconds': int(time.time())})

            # Test with an invalid output

# Generated at 2022-06-16 23:57:33.864865
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import time

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            return 0, struct.pack('@L', int(time.time())), ''

    module = FakeModule()

    # Create a fake hardware object
    hardware = DarwinHardware(module)

    # Call the method
    facts = hardware.get_uptime_facts()

    # Check the result
    assert 'uptime_seconds' in facts
    assert facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:57:36.584868
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class == DarwinHardware

# Generated at 2022-06-16 23:57:40.891847
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:57:51.458575
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '17G65'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:58:02.639878
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import time
    import struct

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary script
    script_path = os.path.join(tmpdir, 'script.sh')
    script_content = '''#!/bin/sh
echo 'kern.boottime: { "sec": %d, "usec": 0 }'
''' % int(time.time())
    with open(script_path, 'w') as f:
        f.write(script_content)
    os.chmod(script_path, 0o755)

    # Create a temporary module

# Generated at 2022-06-16 23:59:57.794294
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-17 00:00:09.522613
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '15G31'}
    rc, out, err = module.run_command(["sysctl", "hw.model"])
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '15G31'
    assert mac_facts['model'] == hardware.sysctl['hw.model']


# Generated at 2022-06-17 00:00:15.502617
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
                       'machdep.cpu.core_count': '4',
                       'hw.physicalcpu': '4',
                       'hw.logicalcpu': '8'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-17 00:00:23.890801
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DarwinDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import OpenBSDDistribution
    from ansible.module_utils.facts.system.distribution import System
    from ansible.module_utils.facts.system.distribution import SystemBSD
    from ansible.module_utils.facts.system.distribution import SystemLinux
    from ansible.module_utils.facts.system.distribution import SystemPOSIX

# Generated at 2022-06-17 00:00:26.161898
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-17 00:00:37.081491
# Unit test for method get_uptime_facts of class DarwinHardware

# Generated at 2022-06-17 00:00:42.015862
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-17 00:00:44.229901
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-17 00:00:48.319601
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_vcpus']


# Generated at 2022-06-17 00:00:52.784855
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] is not None
    assert hardware.facts['processor_cores'] is not None
    assert hardware.facts['memtotal_mb'] is not None
    assert hardware.facts['memfree_mb'] is not None
    assert hardware.facts['model'] is not None
    assert hardware.facts['osversion'] is not None
    assert hardware.facts['osrevision'] is not None
    assert hardware.facts['uptime_seconds'] is not None