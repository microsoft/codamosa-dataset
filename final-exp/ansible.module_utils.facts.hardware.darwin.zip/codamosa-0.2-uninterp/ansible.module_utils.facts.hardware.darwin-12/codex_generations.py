

# Generated at 2022-06-16 23:51:17.883001
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['model']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert hardware_facts['uptime_seconds']


# Generated at 2022-06-16 23:51:25.276886
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda x, encoding=None: (0, StringIO(x[1]), '')

    module = FakeModule()
    darwin_hardware = DarwinHardware(module)

    # Test with a valid output

# Generated at 2022-06-16 23:51:34.737471
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '15G31'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:51:43.943093
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_out as test_out
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_err as test_err
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_rc as test_rc
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_out_2 as test_out_2

# Generated at 2022-06-16 23:51:55.095676
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a mock module
    module = MockModule()

    # Create a mock command

# Generated at 2022-06-16 23:52:05.266027
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 4
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 6096
    assert hardware_facts['model'] == 'MacBookPro11,3'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:52:16.924487
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_mac_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_cpu_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_memory_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_populate

# Generated at 2022-06-16 23:52:25.082742
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    # Create a fake module and a fake stdout

# Generated at 2022-06-16 23:52:29.641372
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts


# Generated at 2022-06-16 23:52:36.506448
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_out as test_out
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_err as test_err
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_rc as test_rc
    test_module.run_command = lambda *args, **kwargs: (test_rc, test_out, test_err)

# Generated at 2022-06-16 23:52:54.638525
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                        'machdep.cpu.core_count': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:53:06.887813
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test the get_system_profile method of class DarwinHardware
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module

    # Create a test instance of DarwinHardware
    test_instance = DarwinHardware(test_module)

    # Create a test system profile

# Generated at 2022-06-16 23:53:14.317320
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:53:21.725425
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['model']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert hardware_facts['uptime_seconds']


# Generated at 2022-06-16 23:53:32.325411
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a mock module
    module = MockModule()

    # Create a mock class for the DarwinHardware class
    class MockDarwinHardware:
        def __init__(self, module):
            self.module = module
            self.sysctl = {'hw.memsize': '4294967296'}

    # Create a mock class for the DarwinHardwareCollector class
    class MockDarwinHardwareCollector:
        def __init__(self, module):
            self.module = module
            self.facts = {'memtotal_mb': 0, 'memfree_mb': 0}

    # Create a mock class for the DarwinHardware class
    class MockDarwinHardware:
        def __init__(self, module):
            self.module = module
            self.sysctl = {'hw.memsize': '4294967296'}



# Generated at 2022-06-16 23:53:40.292825
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts as test_get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock as test_get_uptime_facts_mock
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock_2 as test_get_uptime_facts_mock_2
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_mock_3 as test_get_uptime_facts_mock

# Generated at 2022-06-16 23:53:48.565284
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts == {
        'processor': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'processor_cores': 4,
        'processor_vcpus': '',
    }


# Generated at 2022-06-16 23:53:55.787342
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-16 23:54:03.844061
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(DarwinHardware):
        def __init__(self):
            self.module = None

    dh = TestDarwinHardware()
    uptime_facts = dh.get_uptime_facts()
    uptime_seconds = uptime_facts['uptime_seconds']
    assert uptime_seconds > 0
    assert uptime_seconds < time.time()


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-16 23:54:14.278487
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    module.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                     'machdep.cpu.core_count': '4'}
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''



# Generated at 2022-06-16 23:54:42.443377
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import get_cpu_facts
    from ansible.module_utils.facts.hardware.darwin import get_mac_facts
    from ansible.module_utils.facts.hardware.darwin import get_system_profile
    from ansible.module_utils.facts.hardware.darwin import populate
    from ansible.module_utils.facts.hardware.darwin import DarwinHardwareCollector


# Generated at 2022-06-16 23:54:47.287070
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:54:58.902108
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import os
    import tempfile

    # Test with a file that does not exist
    darwin_hardware = DarwinHardware(None)
    assert darwin_hardware.get_system_profile() == dict()

    # Test with a file that exists
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        f.write('Hardware:\n')
        f.write('    Hardware Overview:\n')
        f.write('      Model Name: MacBook Pro\n')
        f.write('      Model Identifier: MacBookPro11,4\n')
        f.write('      Processor Name: Intel Core i7\n')
        f.write('      Processor Speed: 2.2 GHz\n')
        f.write

# Generated at 2022-06-16 23:55:02.633582
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_vcpus']


# Generated at 2022-06-16 23:55:14.189617
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_results = []

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

        def get_bin_path(self, name):
            return '/usr/bin/' + name

    class TestDarwinHardware(unittest.TestCase):
        def test_get_uptime_facts(self):
            module = MockModule()

# Generated at 2022-06-16 23:55:17.060720
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:55:20.215135
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:55:28.757455
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_ansible_module
    test_module.run_command = test_ansible_module.run_command
    test_module.get_bin_path = test_ansible_module.get_bin_path
    test_module.get_sysctl = test_ansible_module.get_sysctl
    test_module.get_system_profile = test_ansible_module.get_system_profile
    test_module.get_mac_facts = test_ansible_module.get_

# Generated at 2022-06-16 23:55:34.755264
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 8078
    assert hardware.facts['model'] == 'MacBookPro11,1'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:55:45.443173
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 4
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 16384
    assert hardware_facts['model'] == 'MacBookPro11,4'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G73'
    assert hardware_facts['uptime_seconds'] == 528


# Generated at 2022-06-16 23:56:44.644266
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import get_system_profile
    from ansible.module_utils.facts.hardware.darwin import get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import populate
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_memory_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts

# Generated at 2022-06-16 23:56:55.676333
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert 'Model Name' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile
    assert 'Number of Processors' in system_profile
    assert 'Memory' in system_profile
    assert 'Boot ROM Version' in system_profile
    assert 'SMC Version' in system_profile
    assert 'Serial Number' in system_profile
    assert 'Hardware UUID' in system_profile

# Generated at 2022-06-16 23:57:06.909426
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,4'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '15.6.0'


# Generated at 2022-06-16 23:57:14.765994
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 8097
    assert hardware.facts['model'] == 'MacBookPro11,1'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:57:17.785907
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:57:24.923484
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module

# Generated at 2022-06-16 23:57:36.275988
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class FakeModule:
        def run_command(self, cmd):
            return 0, """
Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro8,1
      Processor Name: Intel Core i7
      Processor Speed: 2.2 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 6 MB
      Memory: 8 GB
      Boot ROM Version: MBP81.0047.B27
      SMC Version (system): 1.69f2
      Serial Number (system): C02G913YDVH7
      Hardware UUID: 00000000-0000-1000-8000-0017F2C8D531
      Sudden Motion Sensor:
      State: Enabled

""", ""

    darwin_hard

# Generated at 2022-06-16 23:57:45.399919
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.module.run_command = MagicMock(return_value=(0, 'hw.model: MacBookPro13,1', ''))
    hardware.sysctl = {'kern.osversion': '19.6.0', 'kern.osrevision': '19G2021'}
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro13,1'
    assert mac_facts['osversion'] == '19.6.0'
    assert mac_facts['osrevision'] == '19G2021'


# Generated at 2022-06-16 23:57:53.842753
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module

# Generated at 2022-06-16 23:58:00.613448
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:59:55.023354
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = DarwinHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['uptime_seconds'] > 0
    assert hardware_obj.facts['memtotal_mb'] > 0
    assert hardware_obj.facts['memfree_mb'] > 0
    assert hardware_obj.facts['processor'] != ''
    assert hardware_obj.facts['processor_cores'] > 0
    assert hardware_obj.facts['processor_vcpus'] > 0
    assert hardware_obj.facts['model'] != ''
    assert hardware_obj.facts['osversion'] != ''
    assert hardware_obj.facts['osrevision'] != ''


# Generated at 2022-06-17 00:00:04.703723
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['model'] == 'MacBookPro11,3'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert facts['processor_cores'] == '4'
    assert facts['processor_vcpus'] == '8'
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 8192
    assert facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:00:13.788076
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import time

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary python file
    test_file = os.path.join(tmpdir, 'test_DarwinHardware_get_uptime_facts.py')

# Generated at 2022-06-17 00:00:21.959989
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-17 00:00:28.294911
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-17 00:00:39.580527
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    import os

    # Create a fake module
    fake_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, args, check_rc=True: (0, '', ''),
        'get_bin_path': lambda self, arg, opt_dirs=[] : os.path.join('/usr/sbin', arg),
    })()

    # Create a fake hardware object
    fake_hardware = DarwinHardware(fake_module)

    # Create a fake system profile

# Generated at 2022-06-17 00:00:42.599797
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-17 00:00:50.711993
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test with Intel CPU
    sysctl_mock = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 8,
    }
    module_mock = Mock()
    module_mock.run_command.return_value = (0, '', '')
    hardware = DarwinHardware(module_mock)
    hardware.sysctl = sysctl_mock
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor_vcpus'] == ''



# Generated at 2022-06-17 00:00:58.889832
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 8
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 5863
    assert hardware_facts['model'] == 'MacBookPro11,3'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts