

# Generated at 2022-06-16 23:51:15.822104
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import tempfile
    import shutil
    import time
    import stat
    import subprocess
    import unittest

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.sysctl_cmd = os.path.join(self.test_dir, 'sysctl')
            self.sysctl_output = os.path.join(self.test_dir, 'sysctl_output')

            # Create a fake sysctl command
            with open(self.sysctl_cmd, 'w') as f:
                f.write('#!/bin/sh\n')
                f.write('cat %s\n' % self.sysctl_output)

# Generated at 2022-06-16 23:51:24.054930
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 4
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 7447
    assert hardware.facts['model'] == 'MacBookPro11,1'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] > 0


# Generated at 2022-06-16 23:51:32.166551
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''



# Generated at 2022-06-16 23:51:39.596979
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '15.6.0', 'kern.osrevision': '19G2021'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro15,1'
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '19G2021'


# Generated at 2022-06-16 23:51:50.933316
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 4
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 9072
    assert hardware_facts['model'] == 'MacBookPro11,5'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['uptime_seconds'] == 575

# Generated at 2022-06-16 23:52:01.176558
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 8984
    assert hardware.facts['model'] == 'MacBookPro11,1'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:52:04.703482
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:52:15.573138
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.8 GHz'
    assert system_profile['Memory'] == '16 GB'
    assert system_profile['Serial Number (system)'] == 'C02QG0JTDVH7'
    assert system_profile['Hardware UUID'] == 'D8D8D8D8-D8D8-D8D8-D8D8-D8D8D8D8D8D8'


# Generated at 2022-06-16 23:52:19.897080
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    hardware.get_memory_facts()
    assert hardware.facts['memtotal_mb'] == 4096
    assert hardware.facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:52:30.165640
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'hw.model: Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', ''),
                (0, 'machdep.cpu.brand_string: Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', ''),
                (0, 'machdep.cpu.core_count: 4', ''),
                (0, 'hw.physicalcpu: 4', ''),
                (0, 'hw.logicalcpu: 8', ''),
            ]
            self.run_command_calls = []

        def run_command(self, args, encoding=None):
            self.run_command_calls.append(args)
            return self

# Generated at 2022-06-16 23:52:48.423807
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert 'model' in mac_facts
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts


# Generated at 2022-06-16 23:52:57.079889
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.dh = DarwinHardware()

        def test_get_uptime_facts(self):
            uptime_facts = self.dh.get_uptime_facts()
            self.assertTrue('uptime_seconds' in uptime_facts)
            self.assertTrue(isinstance(uptime_facts['uptime_seconds'], int))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestDarwinHardware)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-16 23:53:08.566451
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a mock of class DarwinHardware
    darwin_hardware = DarwinHardware(module)

    # Create a mock of method get_mac_facts
    def get_mac_facts():
        return {
            'model': 'MacBookPro',
            'osversion': '16.7.0',
            'osrevision': '15G1004'
        }
    darwin_hardware.get_mac_facts = get_mac_facts

    # Create a mock of method get_cpu_facts

# Generated at 2022-06-16 23:53:15.466665
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''



# Generated at 2022-06-16 23:53:18.576993
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:53:21.862564
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector._platform == 'Darwin'
    assert darwin_hw_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:53:24.550619
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'uptime_seconds' in facts

# Generated at 2022-06-16 23:53:35.081251
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_output as test_output
    test_module.run_command = lambda *args, **kwargs: (0, test_output, '')
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/system_profiler'
    test_module.get_sysctl = lambda *args, **kwargs: dict()
    test_module.get_file_content = lambda *args, **kwargs: ''

# Generated at 2022-06-16 23:53:41.609260
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)

    # Test with vm_stat output

# Generated at 2022-06-16 23:53:50.888534
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 4
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 8
    assert hardware.facts['model'] == 'MacBookPro11,3'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] == 8


# Generated at 2022-06-16 23:54:16.803081
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    dh = DarwinHardware(None)
    system_profile = dh.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.5 GHz'
    assert system_profile['Memory'] == '16 GB'
    assert system_profile['Serial Number (system)'] == 'C02LH0HDFVH3'
    assert system_profile['Hardware UUID'] == 'D8D7B8E7-8E6C-5C4D-B9C9-9D5B0F3F3C3C'

# Generated at 2022-06-16 23:54:21.494526
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-16 23:54:25.307561
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector._fact_class == DarwinHardware
    assert darwin_hw_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:54:35.429379
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    # Get the content of the file kern.boottime
    kern_boottime_file = get_file_content('tests/unit/module_utils/facts/hardware/darwin/kern.boottime')

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_values = [
                (0, kern_boottime_file, ''),
            ]


# Generated at 2022-06-16 23:54:37.228646
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector = DarwinHardwareCollector(module=module)
    assert collector.platform == 'Darwin'
    assert collector.fact_class == DarwinHardware


# Generated at 2022-06-16 23:54:41.748476
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'uptime_seconds' in facts

# Generated at 2022-06-16 23:54:54.857235
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.memsize': '4294967296',
    }
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0

    hardware.sysctl = {
        'hw.memsize': '4294967296',
    }
    hardware.module.run_command = lambda x: (0, 'Pages wired down:   5\nPages active:     10\nPages inactive:   15\n', '')
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 40

# Generated at 2022-06-16 23:54:58.495674
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:55:06.781223
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''

    hardware.sysctl = {
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts

# Generated at 2022-06-16 23:55:19.368805
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Model Identifier'] == 'MacBookPro11,4'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.5 GHz'
    assert system_profile['Number of Processors'] == '1'
    assert system_profile['Total Number of Cores'] == '4'
    assert system_profile['L2 Cache (per Core)'] == '256 KB'
    assert system_profile['L3 Cache'] == '6 MB'
    assert system_profile['Memory'] == '16 GB'

# Generated at 2022-06-16 23:56:07.114904
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'uptime_seconds' in facts

# Generated at 2022-06-16 23:56:13.118494
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        mac_facts = hardware.get_mac_facts()
        assert mac_facts['model'] == out.splitlines()[-1].split()[1]
        assert mac_facts['osversion'] == '16.7.0'
        assert mac_facts['osrevision'] == '15.6.0'


# Generated at 2022-06-16 23:56:25.555592
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 8,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == 8


# Generated at 2022-06-16 23:56:33.073836
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)

    # Test with a valid vm_stat output

# Generated at 2022-06-16 23:56:37.907422
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:56:48.028566
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a mock module
    module = MockModule()

    # Create a mock module class
    class MockDarwinHardware:
        def __init__(self, module):
            self.module = module
            self.sysctl = {'hw.memsize': '4294967296'}

    # Create a mock module instance
    darwin_hardware = MockDarwinHardware(module)

    # Create a mock vm_stat command
    class MockVmStatCommand:
        def __init__(self, module):
            self.module = module
            self.rc = 0

# Generated at 2022-06-16 23:56:59.612492
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 4
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 9092
    assert facts['model'] == 'MacBookPro11,3'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['uptime_seconds'] == 1807


# Generated at 2022-06-16 23:57:07.285208
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware_facts = DarwinHardware(module).populate()

    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['model']
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']
    assert hardware_facts['uptime_seconds']

# Generated at 2022-06-16 23:57:15.169086
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    import os

    # Test with a valid output

# Generated at 2022-06-16 23:57:21.215377
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = MockModule()
    # Create a mock module.run_command
    module.run_command = Mock(return_value=(0, b'\x00\x00\x00\x00\x00\x00\x00\x00', ''))
    # Create a DarwinHardware object
    hardware = DarwinHardware(module)
    # Test get_uptime_facts
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 0


# Generated at 2022-06-16 23:58:53.137454
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:58:57.640802
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.model': 'MacBookPro11,3',
        'kern.osversion': '15.6.0',
        'kern.osrevision': '17G65',
    }
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,3'
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '17G65'


# Generated at 2022-06-16 23:59:07.460158
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/sysctl')
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.boottime': '1513141415'}
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1513141415)

# Generated at 2022-06-16 23:59:18.830140
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_out as test_out
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile_err as test_err

    test_module.run_command = lambda *args, **kwargs: (0, test_out, test_err)
    darwin_hardware = DarwinHardware(test_module)
    system_profile = darwin_hardware.get_system_profile()

# Generated at 2022-06-16 23:59:21.399762
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector._fact_class == DarwinHardware
    assert darwin_hw_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:59:27.833582
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:59:38.665241
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module_alias

    # Test that the method get_system_profile returns a dictionary
    # with the expected keys and values
    system_profile = DarwinHardware(test_module).get_system_profile()
    assert system_profile['Hardware Overview'] == 'Hardware Overview'
    assert system_profile['Hardware UUID'] == '00000000-0000-1000-8000-0026BB765291'
    assert system_profile['Model Name'] == 'MacBookPro'
    assert system_profile['Model Identifier']

# Generated at 2022-06-16 23:59:48.014065
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.basic import AnsibleModule
    import os

    # Create a fake module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a fake module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a fake module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a fake module

# Generated at 2022-06-16 23:59:55.621941
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                        'machdep.cpu.core_count': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:59:58.386166
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware