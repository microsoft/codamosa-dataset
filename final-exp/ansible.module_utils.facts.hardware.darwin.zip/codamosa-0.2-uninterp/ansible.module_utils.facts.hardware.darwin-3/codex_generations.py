

# Generated at 2022-06-16 23:51:12.345231
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1510',
    }
    hardware.module.run_command = MagicMock(return_value=(0, 'hw.model: MacBookPro11,3', ''))
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,3'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '1510'


# Generated at 2022-06-16 23:51:21.847688
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_system_profile as test_module_utils

    # Create a test module
    test_module.ANSIBLE_MODULE_ARGS = dict()
    test_module.module = test_module_utils.AnsibleModule(
        argument_spec=test_module.ANSIBLE_MODULE_ARGS,
        supports_check_mode=test_module.ANSIBLE_MODULE_ARGS.get('supports_check_mode', False)
    )

    # Create a test DarwinHardware object
    test_darwin

# Generated at 2022-06-16 23:51:31.646115
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_mount_status_info
    from ansible.module_utils.facts.utils import get_mount_size_info
    from ansible.module_utils.facts.utils import get_mount_size_info

# Generated at 2022-06-16 23:51:39.523045
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']


# Generated at 2022-06-16 23:51:50.825228
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a fake module
    module = type('', (), dict(run_command=lambda *args, **kwargs: (0, '', '')))()

    # Create a fake DarwinHardware object
    hardware = DarwinHardware(module)

    # Create a fake sysctl command
    sysctl_cmd = '/usr/sbin/sysctl'
    hardware.module.get_bin_path = lambda *args, **kwargs: sysctl_cmd

    # Create a fake time
    time_now = 1500000000
    time_boot = time_now - 1000000
    time_boot_bytes = struct.pack('@L', time_boot)

    # Create a fake run_command

# Generated at 2022-06-16 23:52:01.386990
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '15.6.0',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == hardware.sysctl['hw.model']
    assert mac_facts['osversion'] == hardware.sysctl['kern.osversion']
    assert mac_facts['osrevision'] == hardware.sysctl['kern.osrevision']

# Generated at 2022-06-16 23:52:07.004835
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert 'Model Name' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile
    assert 'Memory' in system_profile


# Generated at 2022-06-16 23:52:10.770096
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:52:20.614703
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 8
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 10894
    assert hardware_facts['model'] == 'MacBookPro11,1'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['uptime_seconds'] > 0


# Generated at 2022-06-16 23:52:23.874807
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:52:40.452657
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import get_sysctl
    from ansible.module_utils.facts.hardware.darwin import get_system_profile
    from ansible.module_utils.facts.hardware.darwin import get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import get_mac_facts
    from ansible.module_utils.facts.hardware.darwin import get_cpu_facts
    from ansible.module_utils.facts.hardware.darwin import get_memory_facts
    from ansible.module_utils.facts.hardware.darwin import get

# Generated at 2022-06-16 23:52:44.188649
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '1073741824'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:52:50.497285
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-16 23:52:56.583070
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, check_rc=True: (0, '', ''),
    })

    # Create a mock class
    class MockDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    # Create an instance of the mock class
    darwin_hardware = MockDarwinHardware(module)

    # Call the method
    system_profile = darwin_hardware.get_system_profile()

    # Assert the result
    assert system_profile == dict()

# Generated at 2022-06-16 23:53:08.288477
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    else:
        hardware.sysctl['hw.model'] = 'MacBookPro'
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro'
    assert mac_facts['osversion'] == '16.7.0'

# Generated at 2022-06-16 23:53:18.532870
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['processor_vcpus'] == 4
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['memfree_mb'] == 6056
    assert hardware_facts['model'] == 'MacBookPro11,3'
    assert hardware_facts['osversion'] == '15.6.0'
    assert hardware_facts['osrevision'] == '19G2021'
    assert hardware_facts['uptime_seconds'] == 459


# Generated at 2022-06-16 23:53:29.099563
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 8,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == 8


# Generated at 2022-06-16 23:53:37.405258
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1510',
    }
    hardware.module.run_command = MagicMock(return_value=(0, 'hw.model: MacBookPro11,3', ''))
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,3'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '1510'


# Generated at 2022-06-16 23:53:45.425882
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(DarwinHardware):
        def __init__(self):
            self.module = None

    darwin_hardware = TestDarwinHardware()
    uptime_facts = darwin_hardware.get_uptime_facts()
    uptime_seconds = uptime_facts['uptime_seconds']
    assert uptime_seconds > 0
    assert uptime_seconds < time.time()


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-16 23:53:50.093449
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '4'
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'

# Generated at 2022-06-16 23:54:16.540956
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['model'] == 'MacBookPro11,3'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'
    assert facts['uptime_seconds'] == 5
    assert facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 8
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 16384

# Generated at 2022-06-16 23:54:28.294808
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, encoding=None: (0, '', ''),
        'get_bin_path': lambda self, name: '/usr/bin/%s' % name,
    })()

    # Create a mock time
    time = type('time', (object,), {
        'time': lambda: 1400000000,
    })()

    # Create a mock struct
    struct = type('struct', (object,), {
        'calcsize': lambda self, fmt: 8,
        'unpack': lambda self, fmt, data: (1400000000, ),
    })()

    # Create a mock DarwinHardware class
    class DarwinHardware(object):
        module = module
        time = time
        struct = struct

    #

# Generated at 2022-06-16 23:54:38.005976
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Intel
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
    }
    expected_cpu_facts = {
        'processor': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'processor_cores': 4,
        'processor_vcpus': '',
    }
    cpu_facts = DarwinHardware(dict(sysctl=sysctl)).get_cpu_facts()
    assert cpu_facts == expected_cpu_facts

    # PowerPC
    sysctl = {
        'hw.physicalcpu': 2,
    }

# Generated at 2022-06-16 23:54:50.230857
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.memsize': '1048576',
        'hw.pagesize': '4096',
    }
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024
    assert memory_facts['memfree_mb'] == 0

    hardware.sysctl = {
        'hw.memsize': '1048576',
        'hw.pagesize': '4096',
    }
    hardware.module.run_command = MagicMock(return_value=(0, 'Pages wired down:   0\nPages active:      0\nPages inactive:    0\nPages free:        0\nPages purgeable:   0\n', ''))


# Generated at 2022-06-16 23:55:01.091552
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 9096
    assert hardware.facts['model'] == 'MacBookPro11,1'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['uptime_seconds'] == 511

# Generated at 2022-06-16 23:55:08.125353
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import tempfile
    import unittest

    # Create a temporary file to store the output of sysctl
    (fd, sysctl_output_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to store the output of date
    (fd, date_output_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to store the output of python
    (fd, python_output_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to store the output of the test
    (fd, test_output_file) = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to store the output of the test

# Generated at 2022-06-16 23:55:19.977290
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock module class
    class MockModule(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, name):
            return '/usr/sbin/sysctl'

        def run_command(self, cmd, encoding=None):
            return (0, b'kern.boottime: { sec = 1498571777, usec = 0 }\n', '')

    # Create a mock AnsibleModule
    class MockAnsibleModule(object):
        def __init__(self, argument_spec):
            self.params = {}

        def fail_json(self, **kwargs):
            pass

    # Create a mock AnsibleModule

# Generated at 2022-06-16 23:55:28.528218
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec=dict())

    # Create a mock class
    class MockDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module
            self.sysctl = {'hw.memsize': '4294967296'}

        def get_system_profile(self):
            return dict()

    # Create a mock class
    class MockDarwinHardware2(DarwinHardware):
        def __init__(self, module):
            self.module = module
            self.sysctl = {'hw.memsize': '4294967296'}

        def get_system_profile(self):
            return dict()

        def get_bin_path(self, executable):
            return '/usr/bin/vm_stat'


# Generated at 2022-06-16 23:55:34.090845
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
                       'machdep.cpu.core_count': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-16 23:55:44.931516
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.utils.fake_module import FakeModule

    module = FakeModule()

# Generated at 2022-06-16 23:56:34.489084
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_return_value = (0, '', '')

        def run_command(self, cmd, encoding=None):
            return self.run_command_return_value

        def get_bin_path(self, cmd):
            return cmd

    class TestDarwinHardware(unittest.TestCase):
        def test_get_uptime_facts_success(self):
            module = MockModule()
            module.run_command_return_value = (0, struct.pack('@L', int(time.time() - 3600)), '')
            hardware = DarwinHardware(module)
            uptime_facts = hardware.get_uptime_facts()

# Generated at 2022-06-16 23:56:42.775314
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'uptime_seconds' in facts

# Generated at 2022-06-16 23:56:47.527701
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert 'Model Name' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile
    assert 'Memory' in system_profile
    assert 'Serial Number' in system_profile
    assert 'Hardware UUID' in system_profile


# Generated at 2022-06-16 23:57:00.134581
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import tempfile
    import unittest

    class TestDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, command):
            self.run_command_calls.append(command)
            return 0, "", ""

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.module = TestModule()
            self.hardware = TestDarwinHardware(self.module)

        def test_get_system_profile(self):
            system_profile = self.hardware.get_system_profile()
            self.assertEqual(system_profile, {})

           

# Generated at 2022-06-16 23:57:11.189187
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-16 23:57:17.617975
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '17179869184'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-16 23:57:20.174816
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:57:22.254788
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:57:34.182548
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.facts['model'] == 'MacBookPro'
    assert hardware.facts['osversion'] == '15.6.0'
    assert hardware.facts['osrevision'] == '19G2021'
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-8559U CPU @ 2.70GHz'
    assert hardware.facts['processor_cores'] == '4'
    assert hardware.facts['processor_vcpus'] == '8'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['memfree_mb'] == 16384
    assert hardware.facts['uptime_seconds'] > 0

# Generated at 2022-06-16 23:57:44.191792
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
                       'machdep.cpu.core_count': '4',
                       'hw.physicalcpu': '4',
                       'hw.logicalcpu': '8'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '8'


# Generated at 2022-06-16 23:59:32.301284
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_data
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_data_expected
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_data_expected_2
    from ansible.module_utils.facts.hardware.darwin import test_DarwinHardware_get_uptime_facts_data_expected_3

# Generated at 2022-06-16 23:59:36.970657
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class == DarwinHardware
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-16 23:59:41.575617
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-16 23:59:51.726836
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import tempfile
    import unittest

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.test_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-17 00:00:04.246376
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a fake module
    module = type('', (), {'run_command': run_command})
    module.get_bin_path = get_bin_path

    # Create a fake module.run_command
    def run_command(cmd, encoding=None):
        # Return a fake sysctl output
        return 0, b'kern.boottime: { sec = 1578995853, usec = 809826 } Thu Jan 23 11:17:33 2020', ''

    # Create a fake get_bin_path
    def get_bin_path(name):
        return name

    # Create a fake time
    time = type('', (), {'time': lambda: 1578995853})

    # Create a fake struct

# Generated at 2022-06-17 00:00:09.337299
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '4294967296'}
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-17 00:00:15.419782
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': 4,
        'hw.physicalcpu': 2,
        'hw.logicalcpu': 8,
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_vcpus'] == 8


# Generated at 2022-06-17 00:00:23.826949
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz',
        'machdep.cpu.core_count': '4',
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''

    hardware.sysctl = {
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
    }
    cpu_facts

# Generated at 2022-06-17 00:00:34.371948
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import unittest
    import mock
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.module = mock.Mock()
            self.module.run_command.return_value = (0, '', '')
            self.module.get_bin_path.return_value = '/usr/sbin/sysctl'

        def test_get_uptime_facts(self):
            darwin_hardware = DarwinHardware(self.module)
            darwin_hardware.get_uptime_facts()
            self.module.run_command.assert_called_with(['/usr/sbin/sysctl', '-b', 'kern.boottime'], encoding=None)

   

# Generated at 2022-06-17 00:00:41.474924
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'kern.osversion': '15.6.0',
        'kern.osrevision': '15G31',
    }
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro11,4'
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '15G31'
