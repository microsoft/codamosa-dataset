

# Generated at 2022-06-20 17:07:34.732892
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    hw = DarwinHardware()
    cpu_facts = hw.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts

    memory_facts = hw.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts

    mac_facts = hw.get_mac_facts()
    assert 'model' in mac_facts
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts

    uptime_facts = hw.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-20 17:07:47.957720
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware('module', use_cache=False)
    darwin_hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel i7',
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert 'Intel i7' == cpu_facts['processor']
    assert 4 == cpu_facts['processor_cores']
    assert not 'processor_vcpus' in cpu_facts

    darwin_hardware.sysctl = {
        'hw.physicalcpu': 8,
        'machdep.cpu.core_count': 4,
    }
    cpu_facts = d

# Generated at 2022-06-20 17:07:57.748607
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    darwin_obj = DarwinHardware(module)

    # get_memory_facts

# Generated at 2022-06-20 17:08:10.028528
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, binary, *args, **kwargs):
            return binary

        def run_command(self, command, *args, **kwargs):
            self.run_command_calls.append(command)
            return self.run_command_results.pop(0)

    # sysctl is not able to get the kern.boottime on the CI environment
    # so we simulate an answer from sysctl to test DarwinHardware
    # get_uptime_facts method.
    fake_module = FakeModule()
    fake_out = b'12884901888\n'

# Generated at 2022-06-20 17:08:17.615005
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    module.run_command =  lambda cmd: (0, "hw.model: MacBookPro11,1\nhw.memsize: 17179869184\nkern.osversion: 15D21\nkern.osrevision: 11.0.0\nmachdep.cpu.brand_string: Intel(R) Core(TM) i7-4960HQ CPU @ 2.60GHz\nmachdep.cpu.core_count: 4\nmachdep.cpu.thread_count: 8\nhw.physicalcpu: 4\nhw.logicalcpu: 8\n", None)
    fact = DarwinHardware(module)
    fact_dictionary = fact.populate()

# Generated at 2022-06-20 17:08:29.382709
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module_mock = type('module', (object,), dict(run_command=lambda *a, **kw: (0, 'Model Name:  MacBookPro\nProcessor Name:  Intel Core i5\nProcessor Speed:  2.3 GHz\n', '')))
    hardware = DarwinHardware(module_mock)
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBookPro'
    assert system_profile['Processor Name'] == 'Intel Core i5'
    assert system_profile['Processor Speed'] == '2.3 GHz'

# Generated at 2022-06-20 17:08:36.567360
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    class MockDarwinHardware(DarwinHardware):
        def __init__(self):
            pass

        def get_mac_facts(self):
            mac_facts = {'osversion': '16.4.0', 'product_name': 'iMac13,2', 'osrevision': '15E65'}
            return mac_facts

        def get_cpu_facts(self):
            cpu_facts = {'processor': 'Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz', 'processor_cores': '2'}
            return cpu_facts

        def get_memory_facts(self):
            memory_facts = {'memtotal_mb': 8192, 'memfree_mb': 3568}
            return memory_facts

        def get_uptime_facts(self):
            uptime_

# Generated at 2022-06-20 17:08:43.488848
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils.common.process import get_bin_path
    import subprocess
    import struct
    import time
    class TestDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module
            self.sysctl = get_sysctl(self.module, ['hw', 'machdep', 'kern'])
            return
    dh = TestDarwinHardware(subprocess)
    rc, out, err = subprocess.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    system_profile = {}

# Generated at 2022-06-20 17:08:53.327991
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hw = DarwinHardware(None)       # create an instance of DarwinHardware
    assert darwin_hw.sysctl                # return the sysctl data structure
    assert darwin_hw.get_system_profile()  # return the system profile
    assert darwin_hw.get_mac_facts()       # return the mac facts
    assert darwin_hw.get_cpu_facts()       # return the cpu facts
    assert darwin_hw.get_memory_facts()    # return the memory facts
    assert darwin_hw.get_uptime_facts()    # return the uptime facts


# Generated at 2022-06-20 17:08:55.802295
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    module.exit_json(ansible_facts={'collect_subset': ['hardware']})


# Generated at 2022-06-20 17:09:16.348868
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})

    stats = {
        # value: {expected, time at test, time at start}
        "kern.boottime": {
            "expected": 1498989898,
            "current": 1499289898,
            "start": 1498989898,
        },
    }

    def _run_command(self, cmd, encoding):
        key = cmd[-1]
        struct_format = '@L'
        return (0, struct.pack(struct_format, int(stats[key]["start"])), None)

    def _get_bin_path(self, tool):
        return "/usr/sbin/{tool}".format(tool=tool)


# Generated at 2022-06-20 17:09:22.176494
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw = DarwinHardwareCollector()
    assert darwin_hw._platform == 'Darwin'
    assert darwin_hw._fact_class == DarwinHardware

# Generated at 2022-06-20 17:09:34.647190
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module)
    module.run_command.return_value = (0, 'hw.memsize: 6000000', '')

    facts = hardware.populate()
    assert facts['memtotal_mb'] == 6000000 / 1024 / 1024
    assert facts['memfree_mb'] == 0
    assert facts['osversion'] == ''
    assert facts['osrevision'] == ''
    assert facts['model'] == ''
    assert facts['processor'] == ''
    assert facts['processor_cores'] == ''
    assert facts['processor_vcpus'] == ''
    assert facts['uptime_seconds'] == 0

# Generated at 2022-06-20 17:09:47.786114
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class FakeModule:
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, cmd):
            class FakeRC:
                def __init__(self, **kwargs):
                    self.params = kwargs

# Generated at 2022-06-20 17:09:54.198133
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    osx_facts = DarwinHardware()
    assert isinstance(osx_facts.processor, str)
    assert osx_facts.uptime_seconds > 0
    assert osx_facts.memtotal_mb > 0

# Generated at 2022-06-20 17:10:02.288041
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    hardware_facts = DarwinHardware(module).populate()
    assert hardware_facts['uptime_seconds'] == (module.run_command.mock_calls[0][1][2])['kern.boottime']
    assert hardware_facts['memfree_mb'] == 1855
    assert hardware_facts['memtotal_mb'] == 4278
    assert hardware_facts['processor_vcpus'] == 4
    assert hardware_facts['processor_cores'] == 2
    assert hardware_facts['processor'] == 'Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz'
    assert hardware_facts['osrevision'] == '16'
    assert hardware_facts['osversion'] == '19.0.0'

# Generated at 2022-06-20 17:10:10.758701
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """
    Test for DarwinHardware get_cpu_facts
    """

    # First test, with non-Intel CPU
    sysctl = {
        'hw.cputype': '12',
        'hw.cpusubtype': '11',
        'hw.physicalcpu': '4',
    }
    mocked_sp = {
        'Processor Name': 'PowerPC G5',
        'Processor Speed': '2.0 GHz',
    }
    darwin_hw = DarwinHardware('module')
    darwin_hw.get_system_profile = mocked_sp
    darwin_hw.sysctl = sysctl
    cpu_facts = darwin_hw.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC G5 @ 2.0 GHz'

# Generated at 2022-06-20 17:10:16.038301
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwinhw = DarwinHardwareCollector()
    if darwinhw is not None:
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_DarwinHardwareCollector()

# Generated at 2022-06-20 17:10:20.541140
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    fact_class = DarwinHardware(module)

    attrs_to_assert = ['sysctl']
    for attr in attrs_to_assert:
        assert hasattr(fact_class, attr)


# Generated at 2022-06-20 17:10:24.462803
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware(dict(module=None))
    hardware.get_system_profile()

# Generated at 2022-06-20 17:10:44.820642
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-20 17:10:51.904111
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    memory_facts = DarwinHardware(module).get_memory_facts()
    assert isinstance(memory_facts, dict)
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts


# Generated at 2022-06-20 17:10:59.231075
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec=dict())
    darwin_hardware = DarwinHardware(module)
    system_profile = darwin_hardware.get_system_profile()

    assert "Machine Model:" in system_profile
    assert "Processor Speed:" in system_profile


# Generated at 2022-06-20 17:11:01.254619
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj = DarwinHardwareCollector()
    assert obj.platform == 'Darwin'
    assert isinstance(obj.collect(), dict)

# Generated at 2022-06-20 17:11:11.011120
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class Test(object):
        class Module(object):
            def run_command(self, command):
                class Result(object):
                    stdout=""
                    stderr=""
                    rc=0
                    def splitlines(self):
                        return self.stdout.splitlines()
                res = Result()

# Generated at 2022-06-20 17:11:17.619554
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = MockAnsibleModule()
    test_module.run_command_args = ['system_profiler', 'SPHardwareDataType']
    test_module.run_command_rcs = [0]
    test_module.run_command_outs = ["Hardware:\n Machine Model: iMac13,1\n"]
    test_hardware = DarwinHardware(module=test_module)
    assert test_hardware.get_system_profile() == {'Hardware': 'Machine Model: iMac13,1'}

# Generated at 2022-06-20 17:11:30.816018
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Set up mock module object and populate it with standard keys
    mock_module = Mock(return_value=None)
    mock_module.params = dict()

# Generated at 2022-06-20 17:11:37.633512
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware(dict())
    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] == 0 or memory_facts['memfree_mb'] < memory_facts['memtotal_mb']

# Generated at 2022-06-20 17:11:53.036048
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import unittest
    # Get the path to the module
    module_path = os.path.abspath(os.path.dirname(sys.argv[0]))
    module_path = os.path.join(module_path, os.pardir, os.pardir, 'lib')

    sys.path.append(module_path)
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class FakeModule(object):
        def __init__(self, bin_path=None):
            self.run_command_result = 0
            self.run_command_output = '/usr/bin:/bin:/usr/sbin:/sbin:/usr/local/bin:/usr/local/sbin'
            self.run_command_environ = os.environ

# Generated at 2022-06-20 17:11:54.844657
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    from ansible.module_utils.facts.collector.darwin import DarwinHardwareCollector
    assert DarwinHardwareCollector._platform == 'Darwin'

# Generated at 2022-06-20 17:12:42.239091
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = type('Module', (object,), {'get_bin_path': lambda x: ''})
    hardware = DarwinHardware(module)

    # None of factory function's return values are used,
    # just making sure the mocked calls return something.
    def mocked_run_command(cmd):
        return 0, '', ''
    hardware.module.run_command = mocked_run_command

    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-20 17:12:53.079387
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = MockModule()

# Generated at 2022-06-20 17:12:56.738747
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """ This function is used to test constructor of class DarwinHardwareCollector."""

    hw_facts = DarwinHardwareCollector()
    assert hw_facts.platform == 'Darwin'

# Generated at 2022-06-20 17:13:04.707545
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class TestableDarwinHardware(DarwinHardware):
        def __init__(self, *args, **kwargs):
            self.module = type('', (), {})()

            # Mock the module.run_command
            def mock_run_command(module, command):
                return (0, 'hw.model: x86_64', '')

            self.module.run_command = mock_run_command

            self.sysctl = type('', (), {})()
            self.sysctl['kern.osversion'] = '15.6.0'
            self.sysctl['kern.osrevision'] = '1910.7.12'
            self.sysctl['hw.memsize'] = 4294967296
            self.sysctl['hw.logicalcpu'] = 2

# Generated at 2022-06-20 17:13:15.299785
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    darwin_hardware = DarwinHardware(module)

    rc, out, err = module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    if rc != 0:
        module.exit_json(changed=False, ansible_facts={})
    system_profile = dict()
    for line in out.splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)
            system_profile[key.strip()] = ' '.join(value.strip().split())

    module.run_command = Mock(return_value=(0, 'hw.model: Intel(R) Core(TM) i7-3720QM CPU @ 2.60GHz', ''))
    module.get

# Generated at 2022-06-20 17:13:27.086505
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule:
        class MockRunCommand:
            class MockExecutable:
                def __init__(self, found = False):
                    self.found = found
                def __call__(self, command, **kwargs):
                    if command == "sysctl -b kern.boottime":
                        if self.found:
                            return 0, b"1469190301\n", ""
                        else:
                            return 1, "", "not found"
                def __str__(self):
                    return "/usr/bin/sysctl"
            executable = MockExecutable()
            def __call__(self, command, **kwargs):
                return self.executable(command, **kwargs)

# Generated at 2022-06-20 17:13:28.802060
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj = DarwinHardwareCollector()
    assert obj._fact_class == DarwinHardware
    assert obj._platform == 'Darwin'

# Generated at 2022-06-20 17:13:37.422651
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    darwin_hardware_class_instance = DarwinHardware(module)

    # Intel
    darwin_hardware_class_instance.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-5930K CPU @ 3.50GHz', 'machdep.cpu.core_count': 6}
    assert darwin_hardware_class_instance.get_cpu_facts() == {'processor': 'Intel(R) Core(TM) i7-5930K CPU @ 3.50GHz', 'processor_cores': 6, 'processor_vcpus': ''}

    # PowerPC

# Generated at 2022-06-20 17:13:48.944734
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = DarwinHardware(module=module)

# Generated at 2022-06-20 17:14:02.280447
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # mock the module
    module_args = dict()
    module = AnsibleModule(argument_spec=module_args)
    module.run_command = mock_run_command
    # instantiate a class instance
    dh = DarwinHardware(module=module)
    result = dh.get_system_profile()

# Generated at 2022-06-20 17:15:22.450728
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module)
    assert hardware.platform == 'Darwin'

    assert hardware.sysctl == {'kern.osversion': '16.7.0', 'kern.osrevision': '16R57', 'hw.memsize': 4294967296, 'hw.physicalcpu': 2, 'hw.logicalcpu': 4, 'hw.ncpu': 4, 'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4578U CPU @ 3.00GHz', 'machdep.cpu.core_count': 2}



# Generated at 2022-06-20 17:15:27.922390
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    def get_uptime_facts_test_bin(module):
        def fake_command(command, encoding=None):
            class A:
                def __init__(self, out, rc):
                    self.stdout = out
                    self.rc = rc
            return A(out='0x11bfb3ad0', rc=0)
        module.run_command = fake_command
        hardware = DarwinHardware(module)
        uptime_facts = hardware.get_uptime_facts()
        return uptime_facts

    # Test
    facts = get_uptime_facts_test_bin(None)
    assert facts['uptime_seconds'] != 0
    assert int(facts['uptime_seconds']/3600) > 0

# Generated at 2022-06-20 17:15:30.108817
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    d = DarwinHardware()
    assert d.populate() is not None


# Generated at 2022-06-20 17:15:32.258426
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = Hardware()
    hardware.get_cpu_facts()

# Generated at 2022-06-20 17:15:44.665912
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.params['gather_subset'] = 'min'
            self.params['filter'] = ''
            self.run_command_results = [0, '', '']
            self.run_command_exception = None
            self.run_command_calls = []

# Generated at 2022-06-20 17:15:54.750043
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    def get_sysctl_mock(module, sysctl_paths):
        return {
            'kwarg2': 'value2',
            'kern.osversion': '12.5',
            'kern.osrevision': '12.5',
            'hw.model': 'MacPro5,1',
        }

    test_module = type('module', (object,), dict(run_command=lambda self, cmd: (0, 'hw.model: MacPro5,1', '')))

    hardware_instance = DarwinHardware()
    hardware_instance.sysctl = get_sysctl_mock  # Override sysctl for unit test
    hardware_instance.module = test_module

    mac_facts = hardware_instance.get_mac_facts()
    assert mac_facts['model'] == 'MacPro5,1'


# Generated at 2022-06-20 17:16:05.581634
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Unit test method get_mac_facts of class DarwinHardware testing the following:
        - osversion and osrevision

    """
    module = AnsibleModuleMock()

    darwin_hardware = DarwinHardware(module=module)
    darwin_hardware.sysctl = {'kern.osversion': "16.7.0", 'kern.osrevision': "1515.1.30001351.3.0"}
    mac_facts = darwin_hardware.get_mac_facts()
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '1515.1.30001351.3.0'



# Generated at 2022-06-20 17:16:08.674303
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert d != None
    assert isinstance(d, DarwinHardwareCollector)

# Generated at 2022-06-20 17:16:18.305790
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Intel
    sysctl = {
        'machdep.cpu.brand_string': "Intel(R) Xeon(R) CPU D-1540 @ 2.00GHz"
    }
    darwin_hardware = DarwinHardware(sysctl)
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU D-1540 @ 2.00GHz'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor_vcpus'] == ''

    # PowerPC
    sysctl = {
        'hw.physicalcpu': '2'
    }

# Generated at 2022-06-20 17:16:22.332820
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = MockModule()
    darwin_hardware = DarwinHardware('fake_module', module)
    assert darwin_hardware.get_system_profile() == {}

