

# Generated at 2022-06-20 17:07:27.434403
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware({})
    assert hardware.platform == 'Darwin'

# Generated at 2022-06-20 17:07:36.160569
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware_obj = DarwinHardware(None)
    hardware_obj.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Xeon(R) CPU E5-2680 0 @ 2.70GHz'
    hardware_obj.sysctl['machdep.cpu.core_count'] = '2'
    hardware_obj.sysctl['hw.logicalcpu'] = '4'
    hardware_obj.get_cpu_facts()
    expected_result = {'processor': 'Intel(R) Xeon(R) CPU E5-2680 0 @ 2.70GHz',
                       'processor_cores': '2',
                       'processor_vcpus': '4'}
    assert hardware_obj.cpu == expected_result


# Generated at 2022-06-20 17:07:37.048857
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    for cls in Hardware, DarwinHardware:
        obj = cls()
        assert obj


# Generated at 2022-06-20 17:07:39.598169
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    instantiated_object = DarwinHardware()
    assert(instantiated_object is not None)
    assert(type(instantiated_object) is DarwinHardware)

# Generated at 2022-06-20 17:07:43.225811
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Create a dummy module object
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a dummy class object
    darwinhw_obj = DarwinHardware(module)

    # Test the class method
    darwinhw_obj.populate()

# Generated at 2022-06-20 17:07:50.318431
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    '''
    Test the get_memory_facts method of the DarwinHardware class.
    :return:
    '''
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0



# Generated at 2022-06-20 17:07:51.688045
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    h = DarwinHardware(dict())
    assert h.platform == 'Darwin'

# Generated at 2022-06-20 17:08:01.103966
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = type('TestModule', (object,), {})
    module.run_command = lambda x, **kwargs: (0, 'out', 'err')
    # normal intel case
    get_sysctl = type('get_sysctl', (object,), {'return_value': {'machdep.cpu.brand_string': 'Intel processor', 'machdep.cpu.core_count': 2}})
    module.get_bin_path = lambda x: True
    hardware_obj = DarwinHardware(module=module, get_sysctl=get_sysctl)
    facts = hardware_obj.populate()
    assert facts['processor'] == 'Intel processor'
    assert facts['processor_cores'] == 2
    # normal powerpc case

# Generated at 2022-06-20 17:08:09.292377
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # pylint: disable=no-self-use
    os_release = {
        'name': 'Darwin',
        'version_id': '10.14.2',
    }
    hardware = DarwinHardware({'ansible_facts': {'os_release': os_release}})
    assert hardware.os_release == os_release
    assert hardware.sysctl == get_sysctl({'ansible_facts': {'os_release': os_release}}, ['hw', 'machdep', 'kern'])


# Generated at 2022-06-20 17:08:16.742670
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    # Test 1: kern.boottime is a valid value
    darwin_hardware = DarwinHardware(dict())
    darwin_hardware.sysctl = {
        'kern.boottime': 'Thu Jan  1 01:00:00 1970'
    }
    expected = {
        'uptime_seconds': 0,
    }
    assert darwin_hardware.get_uptime_facts() == expected

    # Test 2: kern.boottime is None
    darwin_hardware = DarwinHardware(dict())
    darwin_hardware.sysctl = {
        'kern.boottime': None
    }
    expected = {}
    assert darwin_hardware.get_uptime_facts() == expected

# Generated at 2022-06-20 17:08:37.122929
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw = DarwinHardwareCollector()
    assert darwin_hw._platform == 'Darwin'
    assert darwin_hw._fact_class == DarwinHardware

# Generated at 2022-06-20 17:08:39.763880
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hostname = "localhost"
    cachedir = "/"

    d_hw = DarwinHardware(hostname, cachedir)
    assert d_hw.hostname == hostname
    assert d_hw.cachedir == cachedir


# Generated at 2022-06-20 17:08:50.444259
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a DarwinHardware instance
    module_mock = Mock()
    module_mock.run_command.return_value = (0, '1: 2\n2: 3\n3: 4', '')
    hardware = DarwinHardware(module_mock)

    # Call the memory facts method
    memory_facts = hardware.get_memory_facts()

    # Validate the content of the dictionary
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-20 17:08:54.994468
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = None
    hardware = DarwinHardware(module)
    assert hardware.sysctl == {}
    assert hardware.platform == "Darwin"
    assert isinstance(hardware.get_memory_facts(), dict)
    assert isinstance(hardware.get_cpu_facts(), dict)
    assert isinstance(hardware.get_mac_facts(), dict)
    assert isinstance(hardware.get_uptime_facts(), dict)
    assert isinstance(hardware.get_system_profile(), dict)
    assert hardware.populate() == {}



# Generated at 2022-06-20 17:08:56.449766
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    dh = DarwinHardware({}, {})

# Generated at 2022-06-20 17:09:06.322716
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from systemd import journal
    import os.path
    import sys

    __test__ = {}

    # Construct a fake module "m"
    class fakeModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg, **kwargs):
            self.error = msg
            self.error_kwargs = kwargs
            sys.exit(1)

        def run_command(self, args, encoding=None):
            if 'system_profiler' in args[0]:
                return self.run_command_system_profiler(args, encoding)
            else:
                raise NotImplementedError()


# Generated at 2022-06-20 17:09:16.529705
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """
    Run hardware on a Darwin system and check the output
    """
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    darwin_facts = hardware.populate()

    sysctl_cmd = get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'hw.memsize']
    rc, out, err = module.run_command(cmd, encoding=None)
    memtotal_mb = int(to_bytes(out.rstrip())) // 1024 // 1024


# Generated at 2022-06-20 17:09:23.309541
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_facts = DarwinHardware()
    assert hardware_facts.collect()['processor'] == 'Intel(R) Core(TM) i5-7360U CPU @ 2.30GHz'
    assert hardware_facts.collect()['processor_cores'] == 4

# Generated at 2022-06-20 17:09:31.601569
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    fake_rc, fake_out, fake_err = 0, '', ''
    facts = DarwinHardware(module).get_mac_facts()
    assert facts == {'model': 'iMac14,3', 'osversion': '15.5.0', 'osrevision': '15.5.0'}


# Generated at 2022-06-20 17:09:40.523258
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import sys
    import mock
    mock_module = mock.Mock()
    mock_module.run_command.return_value = 0, "machdep.cpu.brand_string: Intel(R) Core(TM) i7-8850H CPU @ 2.60GHz", ""
    sys.modules['ansible.module_utils.common.process'] = mock.Mock()
    sys.modules['ansible.module_utils.facts.hardware.base'] = mock.Mock()
    hardware = DarwinHardware()
    hardware.module = mock_module

# Generated at 2022-06-20 17:10:07.849019
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """Test_DarwinHardware_get_system_profile.

    Test the get_system_profile function of the DarwinHardware class.
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

# Generated at 2022-06-20 17:10:21.851056
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = DummyModule()

    DarwinHardware.module = module
    DarwinHardware.module.run_command.return_value = (0, 'hw.model: Power Macintosh\n', '')
    DarwinHardware.sysctl = sysctl
    darwin_hw = DarwinHardware()

    mac_facts = darwin_hw.get_mac_facts()

    expected_mac_facts = {
        'model': 'Power Macintosh',
        'osversion': 'Darwin Kernel Version 16.7.0: Thu Jun 21 16:25:48 PDT 2018; root:xnu-3789.73.8~1/RELEASE_X86_64',
        'osrevision': '184.2.7'
    }

    assert mac_facts == expected_mac_facts



# Generated at 2022-06-20 17:10:25.564576
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.get_system_profile()

# Generated at 2022-06-20 17:10:34.488802
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware()


# Generated at 2022-06-20 17:10:41.150097
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModule(argument_spec=dict())
    hardware_collector = DarwinHardwareCollector(module=module)

    assert hardware_collector.platform == 'Darwin'
    assert hardware_collector.fact_class == DarwinHardware
    assert hardware_collector.fact_class.platform == 'Darwin'

# Generated at 2022-06-20 17:10:54.700511
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    class MyDarwinHardware(DarwinHardware):

        def __init__(self, module):
            self.module = module

        def get_system_profile(self):
            return dict()

    class MyModule(object):

        def __init__(self):
            self.args = dict(
                gather_subset="!all,!any"
            )

        def run_command(self, args):
            if args == ["/usr/sbin/system_profiler", "SPHardwareDataType"]:
                return 0, "", ""
            if "sysctl hw.model" in args:
                return 0, "hw.model: PowerPC G5", ""

# Generated at 2022-06-20 17:11:06.016908
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = type('AnsibleModule', (object,), dict(
        run_command=lambda *args, **kwargs: (0, 'machdep.cpu.brand_string: Intel(R) Core(TM) i5-6267U CPU @ 2.90GHz\n', ''),
        get_bin_path=lambda *args, **kwargs: '/usr/sbin/sysctl',
        ))()
    darwin_hardware = DarwinHardware(module)
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert 'processor' == cpu_facts['processor']
    assert 'processor_cores' == cpu_facts['processor_cores']
    assert 'processor_vcpus' == cpu_facts['processor_vcpus']

# Generated at 2022-06-20 17:11:17.203671
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_module = AnsibleModule(module.argument_spec)
    test_module.sysctl_exists = True
    test_module.run_command_exists = True

    test_DarwinHardware = DarwinHardware(module=test_module,)
    test_DarwinHardware.sysctl = {}

    expected_processor_facts = {
        'processor': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
        'processor_cores': 4,
        'processor_vcpus': 8
    }
    expected_ppc_facts = {
        'processor': 'PowerPC G5 @ 2.5 GHz',
        'processor_cores': 2,
        'processor_vcpus': ''
    }

    # Test Intel CPU facts

# Generated at 2022-06-20 17:11:29.455333
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()
    facts = DarwinHardware(module).populate()

    # Key checks
    keys = [
        'model',
        'osversion',
        'osrevision',
        'uptime_seconds',
        'processor',
        'processor_cores',
        'processor_vcpus',
        'memtotal_mb',
        'memfree_mb'
    ]
    for key in keys:
        assert key in facts

    # Total memory in megabytes
    assert int(facts['memtotal_mb']) > 0

    # OS version starts with digit
    assert facts['osversion'][0].isdigit()

    # OS revision starts with digit
    assert facts['osrevision'][0].isdigit()


# Generated at 2022-06-20 17:11:39.044075
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """
    Test get_cpu_facts() returns correct CPU facts on Darwin platform
    """
    mac = DarwinHardware()

    mac.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz',
        'machdep.cpu.core_count': '4',
    }

    cpu_facts = mac.get_cpu_facts()

    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'
    assert cpu_facts['processor_cores'] == '4'


# Generated at 2022-06-20 17:12:01.972318
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    result = DarwinHardware().get_uptime_facts()
    assert result['uptime_seconds'] > 0

# Generated at 2022-06-20 17:12:12.336050
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    class MockModule(object):
        def __init__(self):
            self.run_command = lambda *args, **kwargs: (0, "", "")
            self.get_bin_path = lambda name: "/usr/sbin/vm_stat"

    module = MockModule()

    hardware_facts = DarwinHardware(module).populate()
    assert 'model' in hardware_facts
    assert 'osversion' in hardware_facts
    assert 'osrevision' in hardware_facts
    assert 'processor' in hardware_facts
    assert 'processor_cores' in hardware_facts
    assert 'processor_vcpus' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'memfree_mb' in hardware_facts
    assert 'uptime_seconds' in hardware_facts


# Generated at 2022-06-20 17:12:24.520048
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class Module:
        def __init__(self, run_command_result):
            self.run_command_result = run_command_result
            self.get_bin_path_result = '/usr/sbin/sysctl'

        def get_bin_path(self, *args, **kwargs):
            return self.get_bin_path_result

        def run_command(self, *args, **kwargs):
            return self.run_command_result

    expected_uptime_facts = {
        'uptime_seconds': int(time.time() - 1588537752)
    }

    # test for unit uptime_seconds

# Generated at 2022-06-20 17:12:33.783512
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.compat import unittest
    from ansible_collections.ansible.community.tests.unit.module_utils.compat.mock import patch, MagicMock

    # Create the fake constants that we'll use to mock the sysctl -b kern.boottime
    # return value.
    seconds = 446656312
    microseconds = 794327

    # Create the buffer with the second and microsecond fields, in little
    # endian byte order.
    out_mock = struct.pack('@LL', seconds, microseconds)

    # Mocking the time.time() function to use seconds.
    time_mock = MagicMock(return_value=seconds)

    # Mocking the run_command() method of the class instance that gets
   

# Generated at 2022-06-20 17:12:45.282167
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils._text import to_bytes
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {
        'hw.memsize': to_bytes('1073741824', 'utf-8'),
        'hw.ncpu': to_bytes('4', 'utf-8'),
        'machdep.cpu.brand_string': to_bytes('Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz', 'utf-8'),
        'machdep.cpu.core_count': to_bytes('2', 'utf-8'),
        'kern.osversion': to_bytes('16.7.0', 'utf-8'),
        'kern.osrevision': to_bytes('1918272', 'utf-8')
    }


# Generated at 2022-06-20 17:12:56.746912
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    adh = DarwinHardware({}, {})
    sysctl = get_sysctl({}, ['hw', 'machdep', 'kern'])
    if 'machdep.cpu.brand_string' in sysctl:
        assert adh.platform == 'Darwin'
        assert adh.get_cpu_facts()['processor'] == sysctl['machdep.cpu.brand_string']
        assert adh.get_cpu_facts()['processor_cores'] == int(sysctl['machdep.cpu.core_count'])
    else:
        system_profile = adh.get_system_profile()
        assert system_profile['Processor Name'] in adh.get_cpu_facts()['processor']
        assert system_profile['Processor Speed'] in adh.get_cpu_facts()['processor']
        assert int

# Generated at 2022-06-20 17:13:02.994203
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class Module():
        def run_command(self, cmd):
            out = "hw.model: Macmini6,2\n"
            return 0, out, ""

    module = Module()
    hardware = DarwinHardware(module)

    rc, out, err = module.run_command("sysctl hw.model")
    assert rc == 0
    assert out.startswith("hw.model: ")

    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'Macmini6,2'

# Generated at 2022-06-20 17:13:07.026485
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)

    assert hardware.platform == 'Darwin'

# Generated at 2022-06-20 17:13:13.499101
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    module.run_command = mock.Mock(return_value=(0, 'hw.model: MacBookPro14,1\n', ''))
    darwinhw = DarwinHardware(module)
    mac_facts = darwinhw.get_mac_facts()
    assert mac_facts == {'model': 'MacBookPro14,1', 'product_name': 'MacBookPro14,1'}


# Generated at 2022-06-20 17:13:25.364692
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = mock.MagicMock()
    hardware=DarwinHardware(module)

    # Set up the sysctl
    module.run_command.return_value = (0, "hw.memsize: 8589934592\nhw.physicalcpu: 4\nhw.logicalcpu: 8\nmachdep.cpu.core_count: 4\nmachdep.cpu.brand_string: Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz\nkern.osversion: 14.5.0\nkern.osrevision: 15F34", 0)
    module.get_bin_path.return_value = "/usr/bin/system_profiler"

    # Set up the system_profiler

# Generated at 2022-06-20 17:14:14.203809
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    ''' Check behavior of get_system_profile of class DarwinHardware
    '''
    module = AnsibleModule(
        argument_spec = dict(),
    )

    # Check if the correct command is being called
    module.run_command = MagicMock(return_value=(0,' ',' '))

    hardware_instance = DarwinHardware(module)
    hardware_instance.get_system_profile()
    module.run_command.assert_called_with(["/usr/sbin/system_profiler", "SPHardwareDataType"])

    # Check if empty dictionary is being returned when command returns non zero
    module.run_command = MagicMock(return_value=(1,' ',' '))

    hardware_instance = DarwinHardware(module)
    result = hardware_instance.get_system_profile()
    assert isinstance(result, dict)

# Generated at 2022-06-20 17:14:28.183517
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class MockedModule(object):
        def __init__(self):
            self.run_command_in_check_mode = False
            self.run_command_in_debug_mode = False
            self.run_command_supports_check_mode = False
            self.run_command_supports_debug = False
            self.module = None
            self.check_mode = False
            self.debug = False
            self.log = None
            self.changed = False
            self.warns = []
            self.deprecations = []
            self.exception = False
            self.exit_args = {}

    mocked_module = MockedModule()

# Generated at 2022-06-20 17:14:30.249581
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    dh = DarwinHardware()
    assert dh.get_mac_facts() == dict()


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-20 17:14:38.591289
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class MockModule(object):
        def run_command(self, command):
            return 0, "machdep.cpu.brand_string: Intel(R) Xeon(R) CPU E5-2670 v2 @ 2.50GHz\nmachdep.cpu.core_count: 12\n", None

        def get_bin_path(self, command):
            pass

    class Context(object):
        def __init__(self, ret_val):
            self.ret_val = ret_val

        def __enter__(self):
            return self.ret_val

        def __exit__(self, *args):
            return False


# Generated at 2022-06-20 17:14:50.988060
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware()
    system_profile = {
        'Pages wired down': 0,
        'Pages active': 252,
        'Pages inactive': 0,
        'Translation faults': 539930,
        'Copy-on-write faults': 73220,
        'Zero fill pages zeroed': 2457,
        'Zero fill pages reactive': 0,
        'Pages examined by the page daemon': 77,
        'Pages purged': 0,
        'File-backed pages': 0,
        'Anonymous pages': 0,
        'Pages stored in compressor': 0,
        'Decompressions': 0,
        'Compressions': 0,
        'Pageins': 0,
        'Pageouts': 0,
        'Swapins': 0,
        'Swapouts': 0,
    }


# Generated at 2022-06-20 17:14:53.557373
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector.platform == 'Darwin'
    assert collector._fact_class == DarwinHardware

# Generated at 2022-06-20 17:15:03.442799
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    # create an instance
    hw = DarwinHardware(module)
    hw.module.run_command = lambda *args, **kwargs: (0, '', '')
    hw.sysctl = dict()
    rc = 0

    # test a CPU with 2 cores
    out = 'hw.logicalcpu: 2\nhw.physicalcpu: 1\n'
    hw.module.run_command = lambda *args, **kwargs: (rc, out, '')
    result = hw.get_cpu_facts()
    assert result['processor_vcpus'] == 2

# Generated at 2022-06-20 17:15:08.193163
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware = DarwinHardwareCollector()
    assert hardware.__class__.__name__ == 'DarwinHardwareCollector'
    assert hardware.platform == 'Darwin'
    assert hardware.fact_class == DarwinHardware

# This is needed for the unit test to execute properly.
if __name__ == "__main__":
    test_DarwinHardwareCollector()

# Generated at 2022-06-20 17:15:19.976754
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    """
    Test creation of DarwinHardware object
    """
    hardware_facts = DarwinHardware()
    assert hardware_facts.platform == "Darwin"
    assert hardware_facts.sysctl == {}
    assert hardware_facts.model == ''
    assert hardware_facts.processor == ''
    assert hardware_facts.processor_vcpus == ''
    assert hardware_facts.processor_cores == ''
    assert hardware_facts.memtotal_mb == 0
    assert hardware_facts.memfree_mb == 0
    assert hardware_facts.osversion == ''
    assert hardware_facts.osrevision == ''
    assert hardware_facts.uptime_seconds == 0

# Generated at 2022-06-20 17:15:27.690225
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    '''
    Tests for DarwinHardware class
    '''

    hardware_facts = DarwinHardware()
    assert hardware_facts.facts['processor'] == 'Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz'
    assert hardware_facts.facts['processor_cores'] == 2

# Generated at 2022-06-20 17:17:08.297024
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """
    DarwinHardware.populate() returns a dictionary containing all possible
    facts for this platform.
    """
    darwin_hw = DarwinHardware({})
    darwin_hw_facts = darwin_hw.populate()
    assert 'processor' in darwin_hw_facts
    assert 'processor_cores' in darwin_hw_facts
    assert 'memtotal_mb' in darwin_hw_facts
    assert 'memfree_mb' in darwin_hw_facts
    assert 'model' in darwin_hw_facts
    assert 'osversion' in darwin_hw_facts
    assert 'osrevision' in darwin_hw_facts

# Generated at 2022-06-20 17:17:19.120705
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Test case for instance method get_mac_facts of class DarwinHardware
    """
    import os
    from ansible_collections.apple.osx.plugins.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible_collections.apple.osx.plugins.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3


    class TestAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            self.params = dict(gather_subset=['!all'], gather_timeout=5)
            super(TestAnsibleModule, self).__init__(*args, **kwargs)
