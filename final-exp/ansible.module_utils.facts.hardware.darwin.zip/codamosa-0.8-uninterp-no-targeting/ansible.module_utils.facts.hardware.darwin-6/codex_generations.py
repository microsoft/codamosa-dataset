

# Generated at 2022-06-20 17:07:32.543012
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = None

    darwin_hw_collector_ins = DarwinHardwareCollector(module)
    assert darwin_hw_collector_ins.get_all() == {}

    darwin_hw_collector_ins._module = module
    assert darwin_hw_collector_ins.get_all() == {}

    darwin_hw_collector_ins._module = None
    assert darwin_hw_collector_ins.get_all() == {}

# Generated at 2022-06-20 17:07:42.626426
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware import DarwinHardware
    from ansible.module_utils.facts.hardware.darwin import utils
    import datetime
    import mock

    # fake the time we booted so we can rely on the uptime
    fake_kern_boottime = -datetime.datetime.now().total_seconds()

    with mock.patch.object(DarwinHardware, 'get_uptime_facts'):
        with mock.patch.object(utils, 'get_sysctl') as mock_get_sysctl:
            mock_get_sysctl.return_value = {'kern.boottime': fake_kern_boottime}
            hwinfo = DarwinHardware()
            uptime_facts = hwinfo.get_uptime_facts()

# Generated at 2022-06-20 17:07:54.536697
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import platform
    import os

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    class MockModule:
        def __init__(self):
            self.params = {}
            self.result = {}
            self.fail_json = lambda **kw: self.fail(**kw)
            self.exit_json = lambda **kw: self.exit(**kw)
            self.exit = self.fail = self.success = self.run_command = lambda *a, **k: None

        def get_bin_path(self, *_):
            return '/usr/bin/env'

    class MockPopen:
        def __init__(self, *_, **kw):
            buf = StringIO()
            buf.write(kern_boottime)
            buf

# Generated at 2022-06-20 17:08:08.476873
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-20 17:08:17.112452
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-20 17:08:31.169196
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """This is a test method for DarwinHardwareCollector class"""
    module = ''
    facts = DarwinHardwareCollector(module).collect()
    assert facts['uptime_seconds'] == ''
    assert facts['processor_vcpus'] == ''
    assert facts['product_name'] == ''
    assert facts['osversion'] == '17.7.0'
    assert facts['osrevision'] == '15000000'
    assert facts['model'] == 'iMac12,1'
    assert facts['processor'] == 'Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz'
    assert facts['processor_cores'] == '4'
    assert facts['memtotal_mb'] == '4096'
    assert facts['memfree_mb'] == '0'

# Generated at 2022-06-20 17:08:41.493278
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible_collections.ansible.os_family.tests.unit.utils.config import Config
    config = Config()
    config.runner_config.module_configs_paths = []
    config.runner_config.module_configs_paths.append('../../../../../lib/ansible/module_utils/facts/hardware/')
    config.runner_config.module_configs_paths.append('../../../../../lib/ansible/module_utils/facts/sysctl/')
    my_darwin = DarwinHardware(config, config)
    my_darwin.sysctl['hw.memsize'] = '1048576000'
    out = my_darwin.get_memory_facts()
    assert out['memtotal_mb'] == 1000

# Generated at 2022-06-20 17:08:53.785853
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = type('', (), {})
    module.run_command = lambda x: (0, 'Serial Number (system): C07HC0ZHG5W8\nHardware UUID: C07HC0ZHG5W8\nModel Name: MacBook Pro\nModel Identifier: MacBookPro8,2\nProcessor Name: Intel Core i7\nProcessor Speed: 2.2 GHz\nNumber of Processors: 1\nTotal Number of Cores: 4\nL2 Cache (per Core): 256 KB\nL3 Cache: 6 MB\nMemory: 8 GB\nBoot ROM Version: MBP81.0047.B27\nSMC Version (system): 1.69f2\n', str())

    test_class = DarwinHardware()
    test_class.module = module
    result = test_class.get_system_profile

# Generated at 2022-06-20 17:08:57.608191
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    system_profile = DarwinHardware().get_system_profile()
    assert system_profile != None
    assert len(system_profile) > 0

# Generated at 2022-06-20 17:09:04.933662
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    # Create a mock module
    module = type('', (), {})()
    # Mock module.run_command function to return a fixed output - boottime in seconds
    module.run_command = lambda cmd, encoding=None: [0, time.time() - 3000, '']
    # Create a DarwinHardware object and run the get_uptime_facts method
    darwin_hardware = DarwinHardware(module)
    uptime_facts = darwin_hardware.get_uptime_facts()

    # Assert that the result equals 3000 seconds
    assert uptime_facts['uptime_seconds'] == 3000

# Generated at 2022-06-20 17:09:21.778732
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_module = DarwinHardware(module)
    hardware_module.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
        'machdep.cpu.core_count': 8,
        'machdep.cpu.thread_count': 8,
    }
    assert hardware_module.get_cpu_facts() == {
        'processor': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
        'processor_cores': 8,
        'processor_vcpus': 8,
    }



# Generated at 2022-06-20 17:09:35.570030
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    processor_facts = {
        'names': ['Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz', 'Genuine Intel(R) CPU T2300 @ 1.66GHz'],
        'cores': ['4', '2'],
    }
    for processor, cores in zip(processor_facts['names'], processor_facts['cores']):
        module = MockModule()
        module.run_command.return_value = (0, processor, '')
        sysctl_facts = {'machdep.cpu.brand_string': '%s' % processor, 'machdep.cpu.core_count': cores}
        hardware = DarwinHardware(module, {'sysctl': sysctl_facts})
        cpu_facts = hardware.get_cpu_facts()

# Generated at 2022-06-20 17:09:48.220200
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    d = DarwinHardware()
    d.sysctl = {'hw.memsize': '1073741824'}
    m = d.get_memory_facts()
    assert m['memtotal_mb'] == 1024
    assert m['memfree_mb'] == 0

    d.sysctl = {'hw.memsize': '1073741824'}
    d.get_system_profile = lambda: {}
    d.get_bin_path = lambda: '/bin/vm_stat'

# Generated at 2022-06-20 17:10:00.680313
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockModule()

    # Test DarwinHardware.get_cpu_facts on Mac OS X
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = {'machdep.cpu.core_count': 4, 'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz'}
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz'
    assert cpu_facts['processor_cores'] == 4

    # Test DarwinHardware.get_cpu_facts on Mac OS X but with PowerPC CPU
    darwin_hardware = DarwinHardware(module)
    d

# Generated at 2022-06-20 17:10:06.481487
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware_collector = DarwinHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]

    # Check that model is not empty
    assert hardware.model != ''

    # Check that osversion is not empty
    assert hardware.osversion != ''

    # Check that osrevision is not empty
    assert hardware.osrevision != ''


# Generated at 2022-06-20 17:10:12.812096
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import sys
    import os
    import random
    import tempfile
    import shutil
    import textwrap

    # Create a fake osversion file
    osversion_file_content = textwrap.dedent("""\
    ProductName:    Mac OS X
    ProductVersion: 10.11.1
    BuildVersion:   15B42
    """)
    osversion_tmpdir = tempfile.mkdtemp()
    osversion_file = os.path.join(osversion_tmpdir, 'osversion')
    with open(osversion_file, 'w') as f:
        f.write(osversion_file_content)

    # Create a fake osrevision file
    osrevision_file_content = textwrap.dedent("""\
    15B42
    """)
    osrevision_tmpdir = tempfile

# Generated at 2022-06-20 17:10:13.660634
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware(dict())
    hardware.get_system_profile()

# Generated at 2022-06-20 17:10:22.264984
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    import sys
    import json

    if sys.version_info.major == 2:
        import mock
        from ansible.module_utils.facts.hardware.darwin import DarwinHardware

        mac_facts = DarwinHardware({}, {})
        mac_facts.module = mock.MagicMock()
        mac_facts.module.get_bin_path.return_value = '/usr/sbin/system_profiler'

        facts = mac_facts.populate()
        print(json.dumps(facts, indent=2))
        assert facts is not None

        pass

# Generated at 2022-06-20 17:10:33.390103
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    macos = DarwinHardware()
    macos.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz', 'machdep.cpu.core_count': 8}
    cpu_facts = macos.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-6700K CPU @ 4.00GHz', cpu_facts['processor']
    assert cpu_facts['processor_cores'] == 8, cpu_facts['processor_cores']
    macos.sysctl = {'hw.physicalcpu': 4}
    cpu_facts = macos.get_cpu_facts()
    assert cpu_facts['processor'] == 'PowerPC @ Unknown', cpu_facts['processor']
    assert cpu_facts

# Generated at 2022-06-20 17:10:45.448286
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Test for method get_cpu_facts with Intel CPU
    setattr(module, 'sysctl', {"machdep.cpu.brand_string": "Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz", "hw.logicalcpu": "4", "hw.physicalcpu": "2"})
    darwin_hardware = DarwinHardware(module)
    expected_cpu_facts = {
        "processor": "Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz",
        "processor_cores": "2",
        "processor_vcpus": "4"
    }
    assert darwin

# Generated at 2022-06-20 17:11:16.330015
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_module = FakeModule(dict())

# Generated at 2022-06-20 17:11:30.304468
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    s ='''
    kern.boottime: { sec = 1606412436, usec = 0 } Thu Nov 19 00:00:36 2020
    hw.memsize: 67108864
    machdep.cpu.brand_string: Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz
    machdep.cpu.core_count: 2
    kern.osrevision: 199506
    kern.osversion: 19.6.0
    '''
    import io
    import mock
    import sys
    import textwrap

    module = mock.MagicMock()
    module.run_command.side_effect = [
        (0, sys.platform, ''),
        (0, textwrap.dedent(s).strip(), '')
    ]
    hardware = DarwinHardware(module)

# Generated at 2022-06-20 17:11:34.060811
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwinhw = DarwinHardware(dict())
    assert darwinhw.collect()['processor_cores'] == '1'

# Unit tests for populate method of class DarwinHardware

# Generated at 2022-06-20 17:11:42.810026
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
    )
    out = """Hardware:

    Hardware Overview:

      Model Name: Mac Pro
      Model Identifier: MacPro3,1
      Processor Name: Quad-Core Intel Xeon
      Processor Speed: 2.8 GHz
      Number of Processors: 2
      Total Number of Cores: 4
      L2 Cache (per Processor): 12 MB
      Memory: 8 GB
      Bus Speed: 1.6 GHz
      Boot ROM Version: MP31.006C.B05
      Serial Number (system): G881451PDV7
      Hardware UUID: 12345678-1234-1234-1234-123456789ABC

"""
    inp = {'run_command': lambda x: (0, out, '')}


# Generated at 2022-06-20 17:11:50.957532
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    x = DarwinHardware()
    x.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz'}
    expected_result = {
        'processor': 'Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz',
        'processor_vcpus': None,
        'processor_cores': 4,
    }
    assert expected_result == x.get_cpu_facts()


# Generated at 2022-06-20 17:11:52.917647
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # If a constructor fails, it will raise an exception
    DarwinHardwareCollector()

# Generated at 2022-06-20 17:12:02.152701
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import unittest.mock as mock
    import os
    import sys

    module = mock.MagicMock()
    module.run_command.return_value = (0, '', '')

    hardware_object = DarwinHardware(module)
    hardware_object.sysctl = {}

    # Test if we obtain the cpu facts when the processor is an Intel processor
    hardware_object.sysctl = {'machdep.cpu.brand_string': 'Intel', 'machdep.cpu.core_count': '4'}
    cpu_facts = hardware_object.get_cpu_facts()
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor'] == 'Intel'
    assert cpu_facts['processor_vcpus'] == ''

    # Test if we obtain the cpu facts when the processor is a

# Generated at 2022-06-20 17:12:12.534213
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware_get_memory_facts = DarwinHardware()

    class MockModule:
        def __init__(self, out, rc):
            self.rc = rc
            self.out = out

        def run_command(self, vm_stat_command):
            return (self.rc, self.out, '')

    out = ""
    rc = 0
    module = MockModule(out, rc)
    darwin_hardware_get_memory_facts.module = module
    out = "Pages free: 4998.\nPages wired down: 4999.\nPages active: 5000.\nPages inactive: 5001.\n"
    rc = 0
    module = MockModule(out, rc)
    darwin_hardware_get_memory_facts.module = module
    darwin_hardware_

# Generated at 2022-06-20 17:12:23.097321
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mock_module = type('', (object,), dict(run_command=lambda x: (0, '', '')))()
    hardware = DarwinHardware(mock_module)
    hardware.sysctl = dict(hw_memsize='4294967296')
    
    assert hardware.get_memory_facts() == {'memtotal_mb': 4096, 'memfree_mb': 0}
    mock_module.run_command = lambda x: (0, 'Pages wired down: 512\nPages active: 1024\nPages inactive: 2048', '')
    assert hardware.get_memory_facts() == {'memtotal_mb': 4096, 'memfree_mb': 4000}

# Generated at 2022-06-20 17:12:34.145089
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    iface = DarwinHardware(module)
    result = iface.populate()

    assert 'product_name' in result
    assert 'osversion' in result
    assert 'osrevision' in result
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_vcpus' in result
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'uptime_seconds' in result

    assert 'processor_threads_per_core' not in result
    assert 'processor_socket_count' not in result

# Generated at 2022-06-20 17:13:19.660870
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    facts = DarwinHardware({})
    assert facts._platform == 'Darwin'

# Generated at 2022-06-20 17:13:29.270751
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class Args(object):

        def __init__(self):
            self.module = AnsibleModuleFake()

    class AnsibleModuleFake(object):

        def __init__(self):
            self.params = dict()

        def get_bin_path(self, param, opt_dirs=None, required=False):
            return param

        def run_command(self, cmd, encoding=None):
            return (0, cmd[2].upper().encode(), '')

    class DarwinHardwareTest(DarwinHardware):
        def __init__(self):
            super(DarwinHardwareTest, self).__init__(Args())

    msg = ('AnsibleModuleFake', 'DarwinHardwareTest', 'DarwinHardware')

# Generated at 2022-06-20 17:13:33.482428
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware = DarwinHardwareCollector()
    assert darwin_hardware._platform == 'Darwin'
    assert darwin_hardware._fact_class == DarwinHardware
    assert type(darwin_hardware._fact_class()) == DarwinHardware

# Generated at 2022-06-20 17:13:47.441126
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import darwin_hw_sysctl

    class FakeModule:
        def __init__(self, systcl_output):
            self.sysctl = darwin_hw_sysctl(systcl_output)
            self.run_command_calls = 0
            self.run_command_args = None

        def run_command(self, args, encoding=None):
            self.run_command_calls += 1
            self.run_command_args = args

            # Return a dummy response.
            return 123, 'dummy_out', 'dummy_err'

    class FakeTime:
        def __init__(self, time_value):
            self.time = time_value

        def time(self):
            return self.time


# Generated at 2022-06-20 17:13:59.943289
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import sys
    import tempfile

    # Test an Intel Mac
    sysctl_file = tempfile.NamedTemporaryFile()
    sysctl_file.write('hw.model: x86_64\n')
    sysctl_file.write('hw.ncpu: 8\n')
    sysctl_file.write('hw.physicalcpu: 4\n')
    sysctl_file.write('hw.logicalcpu: 8\n')
    sysctl_file.write('machdep.cpu.brand_string: Intel\n')
    sysctl_file.flush()
    facts = DarwinHardware(module=sys, sysctl=sysctl_file.name).get_cpu_facts()
    assert facts['processor'] == 'Intel'
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus']

# Generated at 2022-06-20 17:14:03.217186
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector.hardware.darwin import DarwinHardware

    hardware = DarwinHardware(basic.AnsibleModule(argument_spec=dict()))

    system_profile = hardware.get_system_profile()
    assert system_profile['Model Identifier'] == 'MacBookPro11,4'

# Generated at 2022-06-20 17:14:06.702078
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert isinstance(d, HardwareCollector)

# Generated at 2022-06-20 17:14:16.668392
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class ModuleStub():
        def run_command(self, *args):
            return 0, "hw.model: iMac13,2", ""

    darwin_hw = DarwinHardware(ModuleStub())
    darwin_hw.sysctl = { 'kern.osversion': '1.2.3', 'kern.osrevision': '4.5.6' }

    facts = darwin_hw.get_mac_facts()
    assert('model' in facts)
    assert(facts['model'] == 'iMac13,2')
    assert('product_name' in facts)
    assert(facts['product_name'] == 'iMac13,2')
    assert('osversion' in facts)
    assert(facts['osversion'] == '1.2.3')

# Generated at 2022-06-20 17:14:28.810548
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mac_facts = {}
    mac_facts['model'] = 'Intel Mac Mini'
    mac_facts['osversion'] = '18.7.0'
    mac_facts['osrevision'] = '15.7.0'
    mac_facts['processor'] = 'Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz'
    mac_facts['processor_cores'] = 1
    mac_facts['processor_vcpus'] = 1
    mac_facts['memtotal_mb'] = 4096
    mac_facts['memfree_mb'] = 1024

    mac_stats = {'Pages wired down': 20,
                 'Pages active': 16,
                 'Pages inactive': 8,
                 'VM object cache': 0,
                 'Pages free': 100}
    hardware = DarwinHardware()
    hardware.mac_

# Generated at 2022-06-20 17:14:33.547323
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    '''Unit test for method get_cpu_facts of class DarwinHardware'''
    mac_facts = DarwinHardware()
    cpu_facts = mac_facts.get_cpu_facts()
    assert cpu_facts['processor_cores'] != 0


# Generated at 2022-06-20 17:16:04.570860
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    facts = DarwinHardware().populate()
    system_profile = facts.get('system_profile', None)
    assert system_profile is not None
    assert system_profile.get('Boot ROM Version') is not None
    assert system_profile.get('Memory') is not None
    assert system_profile.get('Model Name') is not None
    assert system_profile.get('Model Identifier') is not None
    assert system_profile.get('Processor Name') is not None
    assert system_profile.get('Processor Speed') is not None
    assert system_profile.get('Serial Number (system)') is not None
    assert facts.get('memtotal_mb') is not None
    assert facts.get('processor') is not None

# Generated at 2022-06-20 17:16:17.188355
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    os.environ['PATH'] = "/usr/sbin:/usr/bin:/sbin:/bin"

# Generated at 2022-06-20 17:16:28.301450
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_object = DarwinHardware(None)

    test_object.sysctl = {
        'hw.memsize': '1073741824',
        'hw.activecpu': '1',
        'hw.ncpu': '2'
    }

    test_object.sysctl = {
        'hw.memsize': '1073741824',
        'hw.activecpu': '1',
        'hw.ncpu': '2'
    }

    # This is the output of the command:
    # $ vm_stat | sed 's/[^0-9]//g'
    #
    # We do not wan't to read output from these commands in every test,
    # so we create a fake output as a string

# Generated at 2022-06-20 17:16:38.932777
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl
    from ansible.module_utils.six.moves import builtins

    module = builtins.__dict__['__builtins__']['False']
    module.run_command = lambda *args, **kwargs: (0, 'test\n', '')
    module.get_bin_path = lambda *args, **kwargs: '/usr/bin/test'

    # Simulate sysctl not found
    module.run_command = lambda *args, **kwargs: (1, '', '')
    fc = FactCollector(module=module)
    fact_class = fc.get_fact_

# Generated at 2022-06-20 17:16:45.480384
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl

    module = FakeAnsibleModule()
    module.run_command.return_value = (0, to_bytes("sysctl: unknown oid 'hw.model'\nhw.model: MacBookPro3,1"),
                                       to_bytes(' '))
    sysctl = get_sysctl(module, ['hw', 'kern'])
    hardware = DarwinHardware(module)
    hardware.sysctl = sysctl

# Generated at 2022-06-20 17:16:47.483880
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwinObj = DarwinHardware(dict())
    assert darwinObj.platform == 'Darwin'
    assert darwinObj.sysctl is None


# Generated at 2022-06-20 17:16:59.823778
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = type('module', (), dict(run_command=None))

# Generated at 2022-06-20 17:17:08.330220
# Unit test for method get_uptime_facts of class DarwinHardware