

# Generated at 2022-06-20 17:07:36.426377
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = FakeModule()
    # sysctl_cmd is not really used, we only need to set it so that
    # get_bin_path works.
    module.sysctl_cmd = '/usr/bin/sysctl'
    cmd = ['/usr/bin/sysctl', '-b', 'kern.boottime']
    boottime_raw = (1566892427, 206871)
    module.run_command.return_value = (0, struct.pack('@L', boottime_raw[0]), '')
    hardware = DarwinHardware(module)
    hardware.get_uptime_facts()
    module.run_command.assert_called_with(cmd, encoding=None)


# Generated at 2022-06-20 17:07:43.734845
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = Mock()
    module.run_command.return_value = (0, 'hw.model: MacBookPro5,5', '')
    obj = DarwinHardware(module)
    rc, out, err = obj.get_mac_facts()
    assert rc == 0
    assert out['model'] == 'MacBookPro5,5'



# Generated at 2022-06-20 17:07:54.769177
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_module.get_bin_path = MagicMock(return_value='sysctl')
    dummy_boot_time = int(round(time.time() - 100))
    get_sysctl_mock = MagicMock(return_value={'kern.boottime': dummy_boot_time})
    test_DarwHw = DarwinHardware(test_module, get_sysctl_mock, {})
    uptime_facts = test_DarwHw.get_uptime_facts()
    assert isinstance(uptime_facts, dict)
    assert uptime_facts['uptime_seconds'] == 100, "Uptime should be 100 seconds"



# Generated at 2022-06-20 17:07:58.017154
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module)
    assert hardware.platform == 'Darwin'
    assert hardware.sysctl == {}
    hardware.populate()
    assert hardware.sysctl != {}


# Generated at 2022-06-20 17:08:10.132957
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()
    hardware = DarwinHardware(module)

    # Make sysctl method return what we want
    module.run_command = Mock(return_value=(0, sysctl_output, ""))
    # Make get_system_profile method return what we want
    hardware.get_system_profile = Mock(return_value=system_profile_output)

    facts = hardware.populate()

# Generated at 2022-06-20 17:08:14.499783
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = DarwinHardware(module)
    facts = hardware_obj.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['processor']
    assert facts['model']
    assert facts['osversion']
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0

# Generated at 2022-06-20 17:08:23.107433
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.params = kwargs
            self.exit_json = lambda **kwargs: None

        def run_command(self, *args, **kwargs):
            # We expect a call like sysctl -b kern.boottime
            assert args[0] == ['sysctl', '-b', 'kern.boottime']

            # We mock a string as returned by sysctl, but we split
            # it into 2 lines to simulate the readlines() call
            # happening later on.
            return (0, self.kwargs['sysctl_out'], '')

        def get_bin_path(self, command):
            return command


# Generated at 2022-06-20 17:08:33.870433
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    Test for method "get_uptime_facts" of class "DarwinHardware"
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils._text import to_text
    from time import time
    import struct

    # Create a mock module for the unit test
    mock_module = type('AnsibleModule', (), {'run_command': DarwinHardware.run_command})

    # Create an instance of DarwinHardware with the mock module
    test_instance = DarwinHardware(mock_module)

    # Create a command that returns the value of sysctl kern.boottime
    cmd = ['/sbin/sysctl', '-b', 'kern.boottime']

    # Get the value of the system uptime in seconds
    seconds = int(time())

   

# Generated at 2022-06-20 17:08:42.320959
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-2450M CPU @ 2.50GHz',
        'machdep.cpu.core_count': '4',
        'hw.logicalcpu': '4',
        'hw.ncpu': '4'
    }
    cpu_facts = {
        'processor': 'Intel(R) Core(TM) i5-2450M CPU @ 2.50GHz',
        'processor_vcpus': '4',
        'processor_cores': '4'
    }
    assert hardware.get_cpu_facts() == cpu_facts

    # test on PPC

# Generated at 2022-06-20 17:08:54.149034
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

# Generated at 2022-06-20 17:09:11.542857
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Preparing for testing
    import sys
    import os
    import json
    import tempfile
    from ansible.module_utils._text import to_bytes

    result_dict = {"failed": False,
                   "changed": False,
                   "failed_when_result": False,
                   "invocation": {"module_args": "", "module_name": ""},
                   "_ansible_version": "",
                   "stderr": "",
                   "stdout": "",
                   "stdout_lines": [],
                   "_ansible_no_log": False,
                   "stderr_lines": [],
                   "rc": 0,
                   "stdout_json": None,
                   "warnings": []}

# Generated at 2022-06-20 17:09:24.850596
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.six import BytesIO

    class FakeModule(object):
        def run_command(self, argv):
            stdout = BytesIO()

# Generated at 2022-06-20 17:09:28.892975
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector._fact_class is DarwinHardware
    assert hardware_collector._platform is 'Darwin'

# Generated at 2022-06-20 17:09:36.553455
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule (object):
        def __init__(self, *args, **kwargs):
            pass

        @staticmethod
        def get_bin_path(*args, **kwargs):
            return 'sysctl'

        @staticmethod
        def run_command(*args, **kwargs):
            return 0, struct.pack('@L', int(time.time())), ''

    module = MockModule()
    darwin_hardware = DarwinHardware(module)
    uptime_facts = darwin_hardware.get_uptime_facts()
    assert uptime_facts.get('uptime_seconds')

# Generated at 2022-06-20 17:09:42.993836
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    dh = DarwinHardware()
    system_profile = dh.get_system_profile()
    assert 'Serial Number' in system_profile
    assert 'Model Name' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile

# Generated at 2022-06-20 17:09:47.969966
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """
    This is a test method, called by nose.
    """
    # Tests are executed in current directory.
    # So module_utils should be in current directory.
    # Add current directory to module path in order to import
    # module_utils.common.process module
    import os
    import sys
    sys.path.insert(0, os.getcwd())

    import argparse
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.base import HardwareCollector

    # If we run tests with default values,
    # facter will try to connect to a mac system.
    # We have to avoid this.
    parser = argparse.ArgumentParser()

# Generated at 2022-06-20 17:09:53.695583
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hw = DarwinHardware(module)
    facts = hw.populate()

    assert isinstance(facts, dict)
    assert 'uptime_seconds' in facts

# Generated at 2022-06-20 17:10:00.938252
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MagicMock()
    hardware = DarwinHardware(module=module)

    rc = 0
    out = '''\
hw.model: MacBookAir6,2
'''
    err = ''
    module.run_command.return_value = (rc, out, err)

    expected = {
        'osversion': "10.9",
        'model': "MacBookAir6,2",
        'osrevision': "13F34",
        'product_name': "MacBookAir6,2"
    }
    actual = hardware.get_mac_facts()
    assert expected == actual


# Generated at 2022-06-20 17:10:04.303143
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    platform_facts = DarwinHardwareCollector()
    assert platform_facts._platform =='Darwin'
    assert platform_facts._fact_class == DarwinHardware

# Generated at 2022-06-20 17:10:13.146405
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    darwin_hardware = DarwinHardware()
    darwin_hardware.populate()

    assert darwin_hardware.memtotal_mb != ''
    assert darwin_hardware.memtotal_mb != '0'
    assert darwin_hardware.memfree_mb != ''
    assert darwin_hardware.memfree_mb != '0'
    assert darwin_hardware.processor != ''
    assert darwin_hardware.model != ''
    assert darwin_hardware.osversion != ''
    assert darwin_hardware.osrevision != ''
    assert darwin_hardware.uptime_seconds != ''
    assert darwin_hardware.uptime_seconds != '0'
    assert darwin_hardware

# Generated at 2022-06-20 17:10:41.006952
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    """
    Constructor test for class DarwinHardware
    """
    module = AnsibleModule(argument_spec={})
    sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    hardware_obj = DarwinHardware(module, sysctl)
    assert hardware_obj.sysctl == sysctl

# Generated at 2022-06-20 17:10:54.630842
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_facts = DarwinHardware()
    expected_facts = dict(
        osversion='18.7.0',
        osrevision='17G6029',
        model='MacBookPro15,1',
        processor='Intel(R) Core(TM) i7-8559U CPU @ 2.70GHz',
        processor_cores='4',
        processor_vcpus='4',
        memtotal_mb='16384',
        memfree_mb='16144',
        uptime_seconds='11647',
    )

    # create new object with different __opts__
    hardware_facts = DarwinHardware({'gather_subset': ['all']})
    # run populate()
    hardware_facts.populate()
    # compare
    assert hardware_facts.facts == expected_facts
    # make sure its really a dictionary


# Generated at 2022-06-20 17:11:06.226892
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class module:
        def get_bin_path(self, executable):
            return '/usr/bin/sysctl'

        def run_command(self, command, encoding=None):
            if encoding:
                raise AssertionError('encoding should be None')

            # This KERN_BOOTTIME_TIME is the output of sysctl -b -w kern.boottime

# Generated at 2022-06-20 17:11:17.277043
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    This test verifies that DarwinHardware.get_system_profile() returns
    expected results.
    """

    # First, we create an instance of class DarwinHardware.
    hardware_facts = DarwinHardware(dict())

    # Next, we test the get_system_profile() method. To do that, we need to
    # mock the run_command() method.
    # We do this by replacing the method with a lambda that returns a tuple
    # containing the return code (0 means success), stdout, and stderr.
    # For the sake of simplicity, we use a constant stdout and stderr.
    # The stdout we use is a typical output of the system_profiler command.
    out = 'Hardware:\n' \
          '\n' \
          '    Hardware Overview:\n' \
          '\n' \
         

# Generated at 2022-06-20 17:11:26.934078
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = AnsibleModule(
        argument_spec={},
    )
    test_module.params['gather_subset'] = '!all'
    test_module.params['gather_timeout'] = 5

    # Use a dummy module to get all facts using the '!all' filter
    test_module.run_command = lambda x: (0, "", "")

    hardware = DarwinHardware(test_module)
    hardware.get_system_profile()

# Generated at 2022-06-20 17:11:39.608582
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hw = DarwinHardware()
    # Mock darwin_hw.module.run_command

# Generated at 2022-06-20 17:11:45.738046
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    facts = DarwinHardware(module).get_cpu_facts()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts

# Generated at 2022-06-20 17:11:54.231219
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class MockModule:
        def run_command(*args, **kwargs):
            return 0, "1.0GHz", ""
    module = MockModule()
    darwin_hw = DarwinHardware(module)
    # On Intel macs the sysctl machdep.cpu.brand_string is used.
    assert darwin_hw._get_cpu_facts() == {
        'processor_cores': '2',
        'processor_vcpus': '4',
        'processor': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
    }

    # On PowerPC macs the sysctl machdep.cpu.brand_string does not exist.

# Generated at 2022-06-20 17:12:01.980761
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-20 17:12:12.244138
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module)

    assert hardware.platform == 'Darwin'
    assert hardware.sysctl == {}
    assert hardware.get_system_profile() == {}
    assert hardware.get_mac_facts() == {'osversion': '', 'osrevision': '', 'model': ''}
    assert hardware.get_cpu_facts() == {'processor': '', 'processor_cores': '', 'processor_vcpus': ''}
    assert hardware.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}
    assert hardware.get_uptime_facts() == {'uptime_seconds': ''}
    assert hardware.populate() == {}



# Generated at 2022-06-20 17:12:54.146797
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    m = DarwinHardware()
    assert m.platform == 'Darwin'

# Generated at 2022-06-20 17:13:00.868850
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts import ansible_facts


# Generated at 2022-06-20 17:13:10.578744
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = DarwinHardware(module)
    module.run_command = MagicMock(return_value=(0, "hw.model: MacBookPro7,1", ""))
    module.params = module.load_params(params=dict(gather_subset="all"))
    hardware_obj.get_mac_facts()
    module.run_command.assert_called_with(['sysctl', 'hw.model'])


# Generated at 2022-06-20 17:13:22.377409
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware_instance = DarwinHardware()
    expected_result = {
        'Machine Model': 'iMac14,2',
        'Boot ROM Version': 'IM142.0118.B00',
        'SMC Version (system)': '2.17f1',
        'Serial Number (system)': 'C02N7BJSDVVT',
        'Hardware UUID': '26b09aee-f6fc-51e4-8a34-2d2f18f78b66'
    }
    actual_result = hardware_instance.get_system_profile()
    assert(expected_result == actual_result)

# Generated at 2022-06-20 17:13:35.673843
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    SystemProfile = {
        'Serial Number (system)': 'C02XXXXXXX',
        'Hardware UUID': 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX',
        'Version': '1.0',
        'Secure Virtual Memory': 'Enabled',
        'Model': 'MacBookPro5,5',
        'System Version': 'OS X 10.9.3 (13D65)',
        'Hardware': 'MacBookPro5,5',
        'Memory': '8 GB',
        'Processor Name': 'Intel Core 2 Duo',
        'Processor Speed': '2.4 GHz',
    }
    test_darwinhw = DarwinHardware()

# Generated at 2022-06-20 17:13:47.936749
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)

    hardware.sysctl = {
        'machdep.cpu.brand_string': 'machdep.cpu.brand_string',
        'machdep.cpu.core_count': 'machdep.cpu.core_count',
        'hw.logicalcpu': 'hw.logicalcpu',
        'hw.ncpu': 'hw.ncpu',
    }

    actual_cpu_facts = hardware.get_cpu_facts()

    expected_cpu_facts = {
        'processor': 'machdep.cpu.brand_string',
        'processor_cores': 'machdep.cpu.core_count',
        'processor_vcpus': 'hw.logicalcpu'
    }


# Generated at 2022-06-20 17:14:00.890803
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mac_facts = {
        'osversion': '14.1.0',
        'osrevision': '14B25',
        'model': 'MacBookPro',
        'product_name': 'MacBookPro'
    }
    cpu_facts = {
        'processor': 'Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz',
        'processor_cores': '4',
        'processor_vcpus': '4'
    }
    memory_facts = {
        'memtotal_mb': 16384,
        'memfree_mb': 2536,
    }
    uptime_facts = {
        'uptime_seconds': 166695,
    }
    mac_hw = DarwinHardware()
    mac_hw.sysctl = {}

# Generated at 2022-06-20 17:14:09.774793
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Set up parameters for mock_module
    data = {'ansible_facts': {'hardware': {'processor': "Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz",
                                           'processor_cores': 4,
                                           'processor_vcpus': 4,
                                           'memfree_mb': 1837,
                                           'memtotal_mb': 8192,
                                           'model': "MacBookPro11,4",
                                           'osversion': "14C1510",
                                           'osrevision': "16B2357",
                                           'uptime_seconds': 3670,
                                           'ansible_system': "Darwin"}}}

    # Set up mock_module
    mock_module = Mock()
    mock_module.run_command

# Generated at 2022-06-20 17:14:16.055470
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    now = int(time.time())

    # Test 0
    # This time is impossible, but it allows to check that the boot time is
    # smaller than the current time.
    boot_time = now - 100 * 365 * 24 * 60 * 60
    data = struct.pack('@L', boot_time)

    d = DarwinHardware({})
    assert d.get_uptime_facts() == {}

    results = d.get_uptime_facts(out=data)
    assert results['uptime_seconds'] == now - boot_time

# Generated at 2022-06-20 17:14:28.569062
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class TestModule(object):
        def __init__(self, out, rc):
            self.rc = rc
            self.out = out
        def run_command(self, command, encoding=None):
            return self.rc, self.out, ''

    h = DarwinHardware()
    h.module = TestModule('Pages wired down: 40960\nPages active: 2264616\n'
                         'Pages inactive: 21648\n', 0)
    stats = h.get_memory_facts()
    assert stats['memtotal_mb'] == 8192
    assert stats['memfree_mb'] == 4079

    # test error
    h.module = TestModule('error', 1)
    stats = h.get_memory_facts()
    assert stats['memtotal_mb'] == 8192
    # we set memtotal_mb to 0

# Generated at 2022-06-20 17:16:04.952187
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = DummyModule(params={})
    dh = DarwinHardware(module)
    # test for Intel
    dh.sysctl = {'machdep.cpu.brand_string': 'Intel'}
    assert dh.get_cpu_facts() == {'processor': 'Intel', 'processor_cores': None}
    # test for PowerPC
    dh.sysctl = {'hw.logicalcpu': 2, 'hw.ncpu': 2, 'hw.physicalcpu': 2}
    dh.get_system_profile = lambda: {'Processor Name': 'PowerPC', 'Processor Speed': '2.0 GHz'}
    assert dh.get_cpu_facts() == {'processor': 'PowerPC @ 2.0 GHz', 'processor_cores': 2}

# Generated at 2022-06-20 17:16:16.689710
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Set up a dummy AnsibleModule
    module = type('', (), {
        'run_command': lambda self, cmd: (
            0,
            'kern.boottime: { sec = 1363874184, usec = 128892 } Sat Mar 16 10:03:04 2013',
            None,
        ),
        'get_bin_path': lambda self, cmd: cmd,
    })()
    # Create an instance of DarwinHardware
    fact_instance = DarwinHardware(module)
    # Get uptime facts
    uptime_facts = fact_instance.get_uptime_facts()
    # Check that uptime is correct
    assert uptime_facts['uptime_seconds'] == int(time.time()) - 1363874184

# Generated at 2022-06-20 17:16:26.853795
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    darwin_h = DarwinHardware(module)
    # default tests
    darwin_h.populate()
    assert 'uptime_seconds' in darwin_h.facts
    assert 'processor' in darwin_h.facts
    assert 'model' in darwin_h.facts
    assert 'processor_cores' in darwin_h.facts
    assert 'processor_vcpus' in darwin_h.facts
    assert 'memtotal_mb' in darwin_h.facts
    assert 'memfree_mb' in darwin_h.facts


# Generated at 2022-06-20 17:16:38.425255
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    from ansible.utils.display import Display
    from ansible.module_utils.facts.hardware.darwin import DarwinHardwareCollector

    display = Display()
    facts = DarwinHardwareCollector(None, display).collect()
    assert isinstance(facts, dict)
    assert isinstance(facts.get('uptime_seconds'), int)
    assert isinstance(facts.get('memtotal_mb'), int)
    assert isinstance(facts.get('memfree_mb'), int)
    assert isinstance(facts.get('model'), str)
    assert isinstance(facts.get('processor'), str)
    assert isinstance(facts.get('processor_cores'), int)
    assert isinstance(facts.get('osversion'), str)
    assert isinstance(facts.get('osrevision'), str)

# Generated at 2022-06-20 17:16:49.629297
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MagicMock()
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.get_system_profile = MagicMock(return_value = { 'Processor Name': 'FooName', 'Processor Speed': 'FooSpeed' })
    darwin_hardware.sysctl = { 'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-3470 CPU @ 3.20GHz', 'hw.physicalcpu': 4, 'hw.ncpu': 8, 'hw.logicalcpu': 8 }
    expected = { 'processor': 'Intel(R) Core(TM) i7-3470 CPU @ 3.20GHz', 'processor_cores': 4, 'processor_vcpus': 8 }
    result = darwin_hardware.get_cpu_facts()

# Generated at 2022-06-20 17:16:55.941365
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class test_case:
        def run_command(self, command):
            global vm_stat_data
            if command == ['/usr/bin/vm_stat', '-c', '2']:
                rc = 0
                out = vm_stat_data
                err = ''
            else:
                rc = -1
                out = ''
                err = 'The command was not found'
            return rc, out, err

        def get_bin_path(self, command):
            return command

    global vm_stat_data

    # On Darwin, the default format is annoying to parse.
    # Use -c to get the raw value and decode it.

# Generated at 2022-06-20 17:17:00.869141
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector_object = DarwinHardwareCollector()
    assert darwin_hardware_collector_object.platform == 'Darwin'
    assert darwin_hardware_collector_object._fact_class == DarwinHardware


# Generated at 2022-06-20 17:17:07.820640
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    # This is the output of sysctl hw.model on a real Mac
    fake_stdout = 'hw.model: MacBookPro13,3'
    module.run_command = MagicMock(return_value=(0, fake_stdout, None))
    mac_facts = DarwinHardware(module).get_mac_facts()

    # Check the correct values are returned
    assert mac_facts['model'] == 'MacBookPro13,3'
    assert mac_facts['osversion'] == '19.5.0'
    assert mac_facts['osrevision'] == '15E65'



# Generated at 2022-06-20 17:17:18.768923
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    module = type('a', (), {})
    darwin_hardware = DarwinHardware(module)