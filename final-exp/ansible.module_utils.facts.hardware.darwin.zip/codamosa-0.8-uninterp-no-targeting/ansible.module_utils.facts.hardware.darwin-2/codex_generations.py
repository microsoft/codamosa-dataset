

# Generated at 2022-06-20 17:07:36.124231
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(no_errors=True)
    sysctl = {
        'kern.osversion': '15.6.0',
        'kern.osrevision': '15.6.0',
        'hw.memsize': '17179869184',
        'hw.physicalcpu': '2',
        'hw.model': 'MacBookAir5,2',
    }
    module.run_command.sysctl = sysctl

    facts = DarwinHardware(module).populate()
    assert 'model' in facts
    assert facts['model'] == 'MacBookAir5,2'
    assert 'osrevision' in facts
    assert 'osversion' in facts

    # Test for Intel processor

# Generated at 2022-06-20 17:07:38.720874
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    darwin_hardware = DarwinHardware(module=module)
    mac_facts = darwin_hardware.get_mac_facts()
    assert mac_facts is not None, "Failed to fill mac facts"
    assert mac_facts['osversion'] is not None, "Failed to fill osversion"
    assert mac_facts['osrevision'] is not None, "Failed to fill osrevision"

# Generated at 2022-06-20 17:07:43.176252
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hw = DarwinHardware({'module_setup': True})
    assert isinstance(darwin_hw, DarwinHardware)
    assert darwin_hw.platform == 'Darwin'


# Generated at 2022-06-20 17:07:50.356860
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible_collections.ansible.os_hardware.tests.unit import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible_collections.ansible.os_hardware.tests.unit.compat.mock import patch, MagicMock


# Generated at 2022-06-20 17:07:55.609335
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = FakeModule()
    hardware = DarwinHardware(module=module)

    # Fake return value to sysctl.
    hardware.sysctl = dict(kern_boottime=1574368220)

    uptime_facts = hardware.get_uptime_facts()

    # Check that we are returning a dict.
    assert type(uptime_facts) == dict

    # Check that the dict contains the expected key.
    assert 'uptime_seconds' in uptime_facts

    # We have no real way to test that the result is correct,
    # just make sure it's an integer.
    assert type(uptime_facts['uptime_seconds']) == int



# Generated at 2022-06-20 17:08:09.177842
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-20 17:08:11.466118
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    This function will take no input and will return an instance
    of class DarwinHardwareCollector.
    """
    d_h_c = DarwinHardwareCollector()
    assert isinstance(d_h_c, DarwinHardwareCollector)

# Generated at 2022-06-20 17:08:19.325507
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = FakeModule()
    darwin_hardware = DarwinHardware(module)
    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but get_uptime_facts only keeps seconds as a 32-bit
    # int.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    current_time = int(time.time())
    # Overflow happens on 32-bit platforms, so take a value that
    # overflows on both 32-bit and 64-bit platforms.
    current_time_overflow = current_time + sys.maxint
    for time in [current_time, current_time_overflow]:
        darwin_hardware.sysctl = {'kern.boottime': time}
        uptime_facts = dar

# Generated at 2022-06-20 17:08:29.644630
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    facts = {'ansible_system': 'Darwin'}

    # Try on a Darwin system
    module = AnsibleModule(argument_spec=dict())
    module.facts = facts
    darwin = DarwinHardware(module=module)
    result = darwin.populate()

    assert isinstance(result, dict)
    assert 'model' in result

    # Try on a non-Darwin system
    module.facts = {}
    result = darwin.populate()

    assert result == {}

# Generated at 2022-06-20 17:08:35.271670
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    fake_sysctl = {
        'kern.osversion': '16.1.0',
        'kern.osrevision': '15P2137',
    }

    hw = DarwinHardware(module)
    hw.sysctl = fake_sysctl
    mac_facts = hw.get_mac_facts()

    assert mac_facts['model'] == 'MacBookPro'
    assert mac_facts['osversion'] == '16.1.0'
    assert mac_facts['osrevision'] == '15P2137'



# Generated at 2022-06-20 17:08:54.766515
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware = DarwinHardware(dict())
    hardware.module.run_command = lambda x: (0, "", "")

# Generated at 2022-06-20 17:09:05.294213
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    Test the method get_uptime_facts of class DarwinHardware.
    """
    import sys
    import os
    import mock

    module = mock.MagicMock()
    module.get_bin_path.side_effect = lambda i: getattr(sys, '_MEIPASS', os.getcwd()) + os.path.sep + i

    now = int(time.time())

    # Test the case that the command sysctl returns an error.
    module.run_command.return_value = (1, '', 'Up')
    dh = DarwinHardware()
    dh.module = module
    assert dh.get_uptime_facts() == {}

    # Test the case that the command sysctl returns a valid output.
    struct_format = '@L'

# Generated at 2022-06-20 17:09:16.059866
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test DarwinHardware.get_system_profile
    """
    # pylint: disable=protected-access
    output = """
    Hardware:

      Hardware Overview:

        Model Name: MacBook Pro
        Model Identifier: MacBookPro5,5
        Processor Name: Intel Core 2 Duo
        Processor Speed: 2.4 GHz
        Number of Processors: 1
        Total Number of Cores: 2
        L2 Cache: 3 MB
        Memory: 4 GB
        Bus Speed: 1.07 GHz
        Boot ROM Version: MBP55.00AC.B03
        SMC Version (system): 1.46f2
        Serial Number (system): W89207HSY6Q
        Hardware UUID: 00000000-0000-1000-8000-0016CBF12EAA

    """
    hardware = DarwinHardware()
    hardware.module = Ansible

# Generated at 2022-06-20 17:09:17.884413
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hardware = DarwinHardware(dict())
    assert darwin_hardware.platform == 'Darwin'


# Generated at 2022-06-20 17:09:24.850414
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Setup a fake module object
    fake_module = FakeModule()

    # Define function that returns value from sysctl, depending on the
    # dictionary key.
    def sysctl_function(sysctl_keys):
        if sysctl_keys[0] == 'machdep.cpu.brand_string':
            return "2.6 GHz Intel Core i7"
        else:
            return 4

    # Patch the sysctl_function
    fake_module.sysctl = sysctl_function

    # Setup an instance of DarwinHardware class to test method
    # get_cpu_facts
    darwin_hardware = DarwinHardware(fake_module)

    # Testing get_cpu_facts function
    cpu_facts = darwin_hardware.get_cpu_facts()

    # Testing if all the values are correct

# Generated at 2022-06-20 17:09:28.781571
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hostname = 'localhost'
    module = FakeAnsibleModule(check_invalid_arguments=False)
    th = DarwinHardware(module)
    th.get_sysctl(['hw', 'machdep'])
    th.get_mac_facts()
    th.get_cpu_facts()
    th.get_memory_facts()
    th.get_uptime_facts()

# Generated at 2022-06-20 17:09:34.686517
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_module = FakeModule()
    test_Hardware = DarwinHardware(test_module)
    test_Hardware.sysctl = {'hw.memsize': '4294967296'}
    out = test_Hardware.get_memory_facts()
    assert out['memtotal_mb'] == 4096
    assert out['memfree_mb'] == 0


# Generated at 2022-06-20 17:09:47.786787
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd, encoding=None):
            return self.params.get(cmd[0], [0, '', ''])

        def get_bin_path(self, arg):
            return arg

    class MockVmStat(object):
        def __init__(self):
            self.cmd = ''
            self.rc = 0
            self.out = ''
            self.err = ''

        def __call__(self, module, cmd):
            self.cmd = cmd

            if cmd == ['hw.logicalcpu'] and self.rc != 0:
                module.fail_json(msg=self.err)

            return self.out


# Generated at 2022-06-20 17:09:52.866248
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = type('Test', (object,), {})()
    obj = DarwinHardware(module)
    assert isinstance(obj.get_system_profile(), dict)

# Generated at 2022-06-20 17:09:59.384643
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = None

    # Create a DarwinHardware object (with a mocked 'module')
    hardware = DarwinHardware(module)

    # Execute get_system_profile() and test the result
    result = hardware.get_system_profile()
    assert(result['Serial Number (system)'] == 'C02H4TXDF5J4')
    assert(result['Processor Name'] == 'Intel Core i7')
    assert(result['Processor Speed'] == '2.8 GHz')

# Generated at 2022-06-20 17:10:25.219414
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.facts import collector


# Generated at 2022-06-20 17:10:34.364826
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware
    darwin_hardware._sysctl = {'hw.memsize': 16 * 1024 * 1024 * 1024}
    vm_stat_output = """
Pages free:                             1313774.
Pages active:                           65936.
Pages inactive:                         352820.
Pages wired down:                       161392.
Pages zero filled:                      203112.
Pages reactivated:                      10620.
Pages purged:                           10512.
Translation faults:                     34454761.
Pages copy-on-write:                    72830.
Pages zero fill on demand:              4261823.
Pages reactivated on demand:             3126.
Pageins:                               85720.
Pageouts:                                  0.
Object cache: 38 hits of 7542 lookups (0% hit rate)
"""


# Generated at 2022-06-20 17:10:43.339676
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    hardware = DarwinHardware(module=module)
    hardware.sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])

    mac_facts = hardware.get_mac_facts()
    assert mac_facts['osversion'] == '19.0.0'
    assert mac_facts['osrevision'] == '15386000'
    assert mac_facts['model'] == 'MacBookPro7,1'


# Generated at 2022-06-20 17:10:50.964770
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_facts = DarwinHardware(module)

    cpu_facts = hardware_facts.get_cpu_facts()

    assert cpu_facts['processor'] == ''
    assert cpu_facts['processor_cores'] == ''
    assert cpu_facts['processor_vcpus'] == ''



# Generated at 2022-06-20 17:10:55.637563
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hardware = DarwinHardware(module=module)
    facts = hardware.populate()

    assert 'model' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-20 17:11:04.908322
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    facts = {'ansible_kernel': 'Darwin'}
    module = AnsibleModule(facts=facts)

    hardware = DarwinHardware(module)
    expected_cpu_facts = hardware.get_cpu_facts()

    assert 'processor' in expected_cpu_facts
    assert 'processor_cores' in expected_cpu_facts
    assert 'processor_vcpus' in expected_cpu_facts
    assert expected_cpu_facts['processor_cores'] > 0
    assert expected_cpu_facts['processor_cores'] <= expected_cpu_facts['processor_vcpus']


# Generated at 2022-06-20 17:11:16.907937
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()

    fake_sysctl_values = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-6440HQ CPU',
        'hw.memsize': '4294967296',
        'machdep.cpu.core_count': '8',
    }

    # Create a DarwinHardware object and mock the output of get_sysctl to
    # return the hardcoded values above
    darwin_hw = DarwinHardware(module)
    darwin_hw.sysctl = get_sysctl(darwin_hw.module, ['hw', 'machdep', 'kern'])
    darwin_hw.sysctl = lambda x: fake_sysctl_values.get(x, None)

    # Unit test populate of class DarwinHardware

# Generated at 2022-06-20 17:11:28.199968
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # We don't have a module object, so create a fake one
    class FakeModule:
        @staticmethod
        def run_command(args):
            return 0, 'hw.model: iMac11,3\n', ''

    FakeModule.run_command.__doc__ = '''Run shell command'''

    d = DarwinHardware(None, FakeModule())
    assert {
        'model': 'iMac11,3',
        'osversion': '19.3.0',
        'osrevision': '19D76',
    } == d.get_mac_facts()


# Generated at 2022-06-20 17:11:39.778612
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    Test function get_uptime_facts of class DarwinHardware
    """

    def mock_run_command(module, cmd, encoding=None):
        """
        Mock function run_command of class DarwinHardware
        """
        if cmd[-1] == 'kern.boottime':
            # Return a valid time
            return 0, '1536288752.63459', None

        return 0, '', None

    def mock_get_bin_path(module, executable):
        """
        Mock function get_bin_path of class DarwinHardware
        """
        if executable == 'sysctl':
            return '/usr/sbin/sysctl'
        else:
            return None

    darwin_hardware = DarwinHardware()
    darwin_hardware.module.run_command = mock_run_command
    darwin

# Generated at 2022-06-20 17:11:44.831963
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = type('MockModule', (object,), {})()
    mac_facts = DarwinHardware(module).populate()

    assert 'osversion' in mac_facts
    assert 'model' in mac_facts

# Generated at 2022-06-20 17:12:25.759567
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector._fact_class == DarwinHardware
    assert darwin_hw_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:12:32.085106
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = DarwinHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    for fact in ['processor', 'processor_cores', 'memtotal_mb', 'memfree_mb', 'uptime_seconds']:
        assert hardware.get(fact) is not None

# Generated at 2022-06-20 17:12:44.634615
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_obj = DarwinHardware(dict())
    test_obj.sysctl = { "kern.osversion": "16.5.0",
                        "kern.osrevision": "15605",
                        "machdep.cpu.brand_string": "Intel(R) Core(TM) i5-7267U CPU @ 3.10GHz",
                        "machdep.cpu.core_count": 2}
    produced_cpu_facts = test_obj.get_cpu_facts()
    expected_cpu_facts = {'processor': 'Intel(R) Core(TM) i5-7267U CPU @ 3.10GHz',
                          'processor_cores': 2,
                          'processor_vcpus': ''}
    assert produced_cpu_facts == expected_cpu_facts


# Generated at 2022-06-20 17:12:56.206993
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockModule()
    obj = DarwinHardware(module)
    stats = dict()
    obj.sysctl = stats

    # Testing Intel
    stats['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i3-3227U CPU'
    stats['machdep.cpu.core_count'] = '4'

    cpu_facts = obj.get_cpu_facts()

    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i3-3227U CPU'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''

    # Testing PowerPC
    del stats['machdep.cpu.brand_string']
    stats['machdep.cpu.core_count'] = '2'

# Generated at 2022-06-20 17:13:04.527296
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    global module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Run the get_system_profile method of the class DarwinHardware
    actual_result = DarwinHardware().get_system_profile()

    # Create the expected result using the system_profiler output
    # gathered during the development of this module.

# Generated at 2022-06-20 17:13:13.858441
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    # sysctl hw.model returns an error
    module.run_command.return_value = (-1, None, None)
    darwin_hardware = DarwinHardware(module=module, sysctl={'kern.osversion': '18.7.0'})
    assert darwin_hardware.get_mac_facts() == {'osversion': '18.7.0', 'osrevision': '', 'model': ''}
    # sysctl hw.model is successful
    module.run_command.return_value = (0, 'hw.model: x86_64', '')
    assert darwin_hardware.get_mac_facts() == {'osversion': '18.7.0', 'osrevision': '', 'model': 'x86_64'}

# Generated at 2022-06-20 17:13:25.524883
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    test_system_profile = """Hardware:

      Hardware Overview:

        Model Name: MacBook Pro
        Model Identifier: MacBookPro5,5
        Processor Name: Intel Core 2 Duo
        Processor Speed: 2.53 GHz
        Number Of Processors: 1
        Total Number Of Cores: 2
        L2 Cache: 6 MB
        Memory: 4 GB
        Bus Speed: 1.07 GHz
        Boot ROM Version: MBP55.00AC.B03
        SMC Version (system): 1.48f7
        Serial Number (system): W88401K1FPM
        Hardware UUID: 00000000-0000-1000-8000-0017F2ED8C2F

"""


# Generated at 2022-06-20 17:13:33.669939
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # do not execute if not on Darwin
    import platform
    if platform.system() != 'Darwin':
        return

    # execute method get_system_profile of class DarwinHardware
    import sys
    sys.path.append('/usr/local/Cellar/ansible/devel/lib/python3.6/site-packages')
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    dh = DarwinHardware()
    assert dh.get_system_profile()


# Generated at 2022-06-20 17:13:39.018208
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import sys
    facts = DarwinHardware().get_memory_facts()
    if facts['memtotal_mb'] <= 0:
        sys.exit(1)

# Generated at 2022-06-20 17:13:50.338276
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a fake module and its argument_spec,
    # do not use the real module in unit testing
    module = AnsibleModule(argument_spec={})

    class MockSysctl:
        def __init__(self, kern_boottime):
            self.kern_boottime = kern_boottime

        def __getitem__(self, key):
            return self.kern_boottime

    class MockModule:
        # Mock get_bin_path to return the command unchanged
        def get_bin_path(self, command):
            return command

        def run_command(self, cmd, encoding=None):
            if cmd[0] == 'sysctl' and cmd[1] == '-b' and cmd[2] == 'kern.boottime':
                time_now = time.time()

# Generated at 2022-06-20 17:15:10.764392
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():

    class TestModule(object):
        def __init__(self):
            self.run_command = lambda: (0, None, None)
    hardware = DarwinHardware(TestModule())
    assert hardware.platform == 'Darwin'
    assert hardware.collect()
    assert hardware.facts['osversion'] == '16.7.0'
    assert hardware.facts['uptime_seconds'] == 0
    assert hardware.facts['memtotal_mb'] == 0
    assert hardware.facts['memfree_mb'] == 0
    assert hardware.facts['processor'] == 'unknown'
    assert hardware.facts['processor_cores'] == 'unknown'
    assert hardware.facts['processor_vcpus'] == 'unknown'
    assert hardware.facts['model'] == 'unknown'

# Generated at 2022-06-20 17:15:22.609952
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import ansible.module_utils.facts.hardware.darwin as darwin
    import sys
    if sys.version_info.major >= 3:
        from unittest.mock import Mock
    else:
        from mock import Mock

    # Create a mock AnsibleModule
    mock_module = Mock()

    # We don't actually need to call it, so mock it to not do anything.
    mock_module.get_bin_path = Mock(return_value='mock_path')

    mock_module.run_command = Mock(return_value=(0, b'kern.boottime\t { sec = 123456, usec = 789012345 }', ''))

    mock_hardware = darwin.DarwinHardware(mock_module)

    uptime_facts = mock_hardware.get_uptime

# Generated at 2022-06-20 17:15:27.397492
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import json
    import os
    import sys
    import tempfile
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.modules["ansible.module_utils.common.command"] = __import__("ansible.module_utils.common.process", fromlist=["command"])
    from ansible.module_utils.facts import ModuleTest
    module_test = ModuleTest()
    module_test.path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    module_test.size = 0
    module_test.data = ''
    module_test.rc = 0
    module_test.lines = []
    module_test.err = ''
    module_test.std

# Generated at 2022-06-20 17:15:35.455576
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-20 17:15:42.012678
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    mac_facts = DarwinHardware(module).get_mac_facts()

    assert mac_facts['model'] == 'iMac14,3'
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '192115'



# Generated at 2022-06-20 17:15:53.358218
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import pytest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import SysctlFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    dh = DarwinHardware()
    class MockModule:
        def __init__(self):
            self.params = dict(gather_subset='all')
        def run_command(cmd):
            return (0,'')
    dh.module = MockModule()
    fact_collector = SysctlFactCollector(dh.module)
    distribution_fact_collector = DistributionFactCollector(dh.module)
    facts_dict = dict()
    fact_collector.populate()
    distribution_fact_collector.populate()
    facts_

# Generated at 2022-06-20 17:16:05.457527
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class TestDarwinHardware(DarwinHardware):
        def run_command(cmd, *args, **kwargs):
            expected = ["vm_stat"]
            assert cmd == expected
            return 0, OUTPUT, ''
    expected = {
        'memfree_mb': 159,
        'memtotal_mb': 16384,
    }

# Generated at 2022-06-20 17:16:11.970825
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    test_class = DarwinHardware()
    mac_facts = test_class.get_mac_facts()
    print("mac_facts = %s" % mac_facts)


# Generated at 2022-06-20 17:16:15.136344
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hw = DarwinHardware(module)
    assert hw.platform == 'Darwin'
    assert hw.sysctl is None


# Generated at 2022-06-20 17:16:27.741315
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import ansible.module_utils.facts.hardware.darwin as darwin

    # Test 'sysctl' command returns a zero return code
    old_sysctl = darwin.sysctl_cmd.run_command
    def new_sysctl(self, args, check_rc=True, close_fds=True, executable=None, run_as_root=True, encoding=None):
        # Avoid running the command
        return 0, 'hw.model: MacBookPro13,1', ''
    darwin.sysctl_cmd.run_command = new_sysctl

    mac_facts = darwin.DarwinHardware().get_mac_facts()

    assert mac_facts['model'] == 'MacBookPro13,1'
    assert mac_facts.get('osversion') is None