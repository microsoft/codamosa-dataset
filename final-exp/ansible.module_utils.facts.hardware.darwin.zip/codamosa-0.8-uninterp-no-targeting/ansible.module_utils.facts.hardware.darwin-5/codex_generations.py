

# Generated at 2022-06-20 17:07:36.318373
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hw = DarwinHardware(None)
    hw.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-8259U CPU @ 2.30GHz',
                 'machdep.cpu.core_count': '4',
                 'hw.ncpu': '4'}
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-8259U CPU @ 2.30GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '4'


# Generated at 2022-06-20 17:07:48.131535
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    '''
    unit test function for the DarwinHardware class method get_system_profile()
    '''
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import sys

    saved_stdout = sys.stdout
    saved_stderr = sys.stderr


# Generated at 2022-06-20 17:07:57.539634
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Creating a MacOS Hardware Object
    p = DarwinHardware()

    # Mock the function sysctl
    p.sysctl = dict()
    p.sysctl['kern.osversion'] = '10.9'
    p.sysctl['kern.osrevision'] = '13A603'
    p.sysctl['hw.model'] = 'MacBookPro3,1'

    # Simulating the mocked value
    output = p.get_mac_facts()

    # Verifying the result
    assert output['osversion'] == '10.9'
    assert output['osrevision'] == '13A603'
    assert output['model'] == 'MacBookPro3,1'



# Generated at 2022-06-20 17:08:05.246797
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            # Convert the fake time.time() return value to bytes
            self.time_now = int(1500076800)
            self.time_now_bytes = struct.pack('@L', self.time_now)

            # Fake time.time() for the test
            def time():
                return self.time_now
            self.run_original = time.time
            time.time = time
            self.run_command_args = []

        def run_command(self, args, encoding=None):
            self.run_command_args.append(args)
            # Fake the sysctl command for the test
            if args[0].endswith("sysctl"):
                return (0, self.time_now_bytes, "")
            else:
                return

# Generated at 2022-06-20 17:08:08.495521
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    result = hardware.populate()
    assert 'processor_cores' in result
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'osversion' in result
    assert 'osrevision' in result
    assert 'uptime_seconds' in result

# Generated at 2022-06-20 17:08:13.646028
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    darwin_hw = DarwinHardware(module=module)
    mac_facts = darwin_hw.get_mac_facts()

    # check if the result is correct
    keys = ['osversion', 'osrevision', 'model']
    for key in keys:
        assert key in mac_facts.keys()


# Generated at 2022-06-20 17:08:21.832404
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-20 17:08:24.211223
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert d is not None

# Generated at 2022-06-20 17:08:28.084220
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    my_hardware = DarwinHardware()
    assert my_hardware is not None

if __name__ == '__main__':
    test_DarwinHardware()

# Generated at 2022-06-20 17:08:35.527956
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    """Test parsing of system_profiler output"""
    darwin_hw = DarwinHardware({})
    system_profile = darwin_hw.get_system_profile()
    assert system_profile['Serial Number (system)'] == 'C02L3AYLDVH3'
    assert system_profile['Model Name'] == 'MacBook Pro'

# Generated at 2022-06-20 17:08:48.673498
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector._fact_class is DarwinHardware


# Generated at 2022-06-20 17:08:54.148260
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    result = dict(
        changed = False,
        ansible_facts = dict(
            ansible_hardware = None,
        ),
    )
    darwin_hw_fact = DarwinHardware(module)
    result['ansible_facts']['ansible_hardware'] = darwin_hw_fact.populate()
    module.exit_json(**result)



# Generated at 2022-06-20 17:09:05.074380
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():

    import pytest


# Generated at 2022-06-20 17:09:10.036632
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.hardware.base import HardwareCollector

    print("Testing DarwinHardware_get_memory_facts")

    collector = HardwareCollector()
    hardware = DarwinHardware(module=None)

    memory_facts = hardware.get_memory_facts()

    print()
    print("memory_facts:\n", memory_facts)
    print()



# Generated at 2022-06-20 17:09:15.142270
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    hardware.module.run_command = mock.Mock(return_value=(0, "hw.model: MacBookAir5,2", ""))
    facts = hardware.get_mac_facts()
    assert facts['model'] == "MacBookAir5,2"
    assert "osversion" in facts
    assert "osrevision" in facts


# Generated at 2022-06-20 17:09:24.442293
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()

# Generated at 2022-06-20 17:09:36.351225
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import mock
    import sys

    sys.modules['ansible'] = mock.MagicMock()
    sys.modules['ansible.module_utils'] = mock.MagicMock()
    sys.modules['ansible.module_utils.common'] = mock.MagicMock()
    sys.modules['ansible.module_utils.facts'] = mock.MagicMock()
    sys.modules['ansible.module_utils.facts.hardware'] = mock.MagicMock()

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    m = DarwinHardware(mock.MagicMock())

    raw_kern_boottime = "1444528807"

    cmd = ['/usr/sbin/sysctl', '-b', 'kern.boottime']

# Generated at 2022-06-20 17:09:48.621711
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class FakeModule(object):
        def run_command(self, cmd):
            assert cmd == ['/usr/sbin/system_profiler', 'SPHardwareDataType']

# Generated at 2022-06-20 17:10:00.876114
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Test 1
    # kern.boottime value = 1209964479
    module = type('', (object,), {
        'get_bin_path': lambda self, path: path,
        'run_command': lambda self, cmd, encoding=None: (0, '\x47\xf3\x2c\x77', '')
    })()
    test_hardware = DarwinHardware(module)
    result = test_hardware.get_uptime_facts()
    assert result['uptime_seconds'] == time.time() - 1209964479

    # Test 2
    # kern.boottime value = 0

# Generated at 2022-06-20 17:10:08.868158
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        "kern.osversion": "15.6.0",
        "kern.osrevision": "15.6.0",
    }
    mac_facts = hardware.get_mac_facts()
    assert mac_facts == {
        'osversion': "15.6.0",
        'osrevision': "15.6.0",
    }

# Generated at 2022-06-20 17:10:32.356804
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class DarwinHardware(Hardware):
        platform = 'Darwin'
        def populate(self, collected_facts=None):
            hardware_facts = {}
            self.sysctl = get_sysctl(self.module, ['hw', 'machdep', 'kern'])
            cpu_facts = self.get_cpu_facts()
            hardware_facts.update(cpu_facts)
            return hardware_facts

    dh = DarwinHardware({})
    cpu_facts = dh.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert cpu_facts['processor_cores'] >= 1
    assert cpu_facts['processor_vcpus'] >= 1

# Generated at 2022-06-20 17:10:43.793411
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # set up object and insert fake values into sysctl
    mac = DarwinHardware(None)
    mac.sysctl = {
        'kern.osversion': '14.3.0',
        'kern.osrevision': '15',
    }

    # Set up fake command output
    rc = 0
    out = "hw.model: MacBookPro13,1"
    err = ""

    # call command, then call method
    mac.module.run_command = lambda *args, **kwargs: (rc, out, err)
    mac_facts = mac.get_mac_facts()

    assert mac_facts['model'] == 'MacBookPro13,1'



# Generated at 2022-06-20 17:10:54.965929
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible_collections.ansible.community.plugins.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode = True
    )

    test_darwin_hardware_facts = DarwinHardware(module=module)
    cpu_facts = test_darwin_hardware_facts.get_cpu_facts()
    if cpu_facts['processor_cores'] == 1:
        print("DarwinHardware get_cpu_facts test passed!")
    else:
        raise Exception("DarwinHardware get_cpu_facts test failed!")


if __name__ == '__main__':
    test_DarwinHardware_get_cpu_facts()

# Generated at 2022-06-20 17:11:06.280316
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Define module and class
    class ModuleArgs(object):
        def __init__(self):
            self.args = ''

# Generated at 2022-06-20 17:11:17.299085
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    '''
    Test DarwinHardware.get_system_profile by mocking the run_command method.
    When the sysctl command returns with a successful rc, load the test output
    as the mocked run_command output.
    '''

    # Common arguments to the run_command method
    command = ['/usr/sbin/system_profiler', 'SPHardwareDataType']
    module = dict()
    check_rc = False
    tmpdir = None
    environ_update = dict()
    data = ''

    # Contents of the 'system_profile' dictionary on a machine

# Generated at 2022-06-20 17:11:24.360061
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class TestModule():
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            return "/usr/bin/vm_stat"

# Generated at 2022-06-20 17:11:29.499444
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-20 17:11:40.732639
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-20 17:11:48.169367
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()
    hardware = DarwinHardware(module=module)
    hardware.populate()
    assert hardware.facts['model'] == 'Macmini6,2'
    assert hardware.facts['processor_cores'] == '2'
    assert hardware.facts['processor_vcpus'] == hardware.facts['processor_cores']



# Generated at 2022-06-20 17:11:51.848407
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    assert isinstance(hardware.get_cpu_facts(), dict)

# Generated at 2022-06-20 17:12:37.358080
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform
    import collections
    import ansible.module_utils.facts.hardware.darwin

    def read_file_mock(self, filename):
        return collections.OrderedDict((
            ('sysctl', '/usr/sbin/sysctl'),
            ('uptime', '12:11  up 8 days, 11:25, 2 users, load averages: 1.04 1.03 1.04'),
            ('date', 'Sat Apr  9 12:11:48 PDT 2016')
        ))[filename.split()[-1]]

    monkeypatch = ansible.module_utils.facts.hardware.darwin.__dict__['__monkeypatch_module']
    monkeypatch.setattr(ansible.module_utils.facts.hardware.darwin.HardwareDarwin, 'read_file', read_file_mock)

   

# Generated at 2022-06-20 17:12:40.896088
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    obj = DarwinHardware(dict())
    output = obj.get_system_profile()
    assert type(output) == dict
    assert 'Serial Number' in output

# Generated at 2022-06-20 17:12:47.508655
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwinhardware = DarwinHardware()
    osversion_value = "13.3.0"
    osrevision_value = "0"
    model_value = "MacBookPro11,5"
    processor_value = "2.2 GHz Intel Core i7"
    processor_cores_value = 8
    processor_vcpus_value = 8
    memtotal_mb_value = 16384
    memfree_mb_value = 0
    uptime_seconds_value = 60


# Generated at 2022-06-20 17:12:50.078645
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_fact = DarwinHardware(dict())
    assert hardware_fact is not None


# Generated at 2022-06-20 17:12:56.672501
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwinhardware = DarwinHardware({'module_name': 'ansible.module_utils.facts.hardware.darwin'})
    assert darwinhardware.get_memory_facts() == {'memtotal_mb': 0, 'memfree_mb': 0}
    assert darwinhardware.get_cpu_facts() == {'processor': '', 'processor_cores': '', 'processor_vcpus': ''}
    assert darwinhardware.get_mac_facts() == {'osversion': '', 'osrevision': '', 'model': ''}
    assert darwinhardware.get_uptime_facts() == {}
    assert darwinhardware.platform == 'Darwin'


# Generated at 2022-06-20 17:13:04.691624
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-20 17:13:13.903766
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import os
    kernel_version_major = int(os.uname()[2].split('.')[0])
    osversion = '15.3.0'
    osrevision = '15.3.0'
    processor = 'Intel(R) Core(TM) i7-3770K CPU @ 3.50GHz'
    processor_cores = 8
    model = 'Macmini6,2'
    memtotal_mb = 8192
    uptime_seconds = 300

    mock_run_command = ['sysctl hw.model', 'sysctl hw.memsize', '/usr/sbin/vm_stat', '/usr/sbin/system_profiler SPHardwareDataType']

# Generated at 2022-06-20 17:13:25.588361
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class ModuleStub(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = list()

        def run_command(self, args):
            self.run_command_count += 1
            self.run_command_args.append(args)
            return 0, "", ""

    class DarwinHardwareStub(DarwinHardware):
        def __init__(self):
            pass

    test_module = ModuleStub()
    test_hardware = DarwinHardwareStub()

    # Test that when everything works, the proper data is populated
    test_hardware.module = test_module
    test_hardware.get_system_profile()
    assert test_module.run_command_count == 1

# Generated at 2022-06-20 17:13:29.066922
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    h = DarwinHardwareCollector()
    assert isinstance(h, DarwinHardwareCollector)
    assert isinstance(h._fact_class, DarwinHardware)
    assert h._platform == 'Darwin'

# Generated at 2022-06-20 17:13:34.615517
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = { 'gather_subset': ['all'] }
    module.run_command = MagicMock(return_value=(0, "hw.model: MacBookPro", ""))
    hardwareFacts = DarwinHardware(module)
    facts_out = hardwareFacts.populate()
    assert facts_out['model'] == 'MacBookPro'

# Generated at 2022-06-20 17:14:56.547155
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    darwin = DarwinHardware()
    mac_facts = darwin.get_mac_facts()
    assert mac_facts['model'] == 'Mac-42FD25EABCABB274'
    assert mac_facts['osversion'] == '15.3.0'
    assert mac_facts['osrevision'] == '10.11.6'



# Generated at 2022-06-20 17:15:04.804695
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import tempfile
    import shutil

    class TestModule:
        def __init__(self, *args, **kwargs):
            self.run_command_args = args
            self.run_command_kwargs = kwargs

        def run_command(self, *args, **kwargs):
            self.run_command_args = args
            self.run_command_kwargs = kwargs
            return 0, '', ''

    class TempVMStatFile():
        def __init__(self, tempdir, vm_stat_output):
            self.filepath = tempdir + '/vm_stat'
            self.content = vm_stat_output

        def __enter__(self):
            with open(self.filepath, 'w') as f:
                f.write(self.content)

            return self.filepath

# Generated at 2022-06-20 17:15:08.333390
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    """
    This function is used to test constructor of
    class DarwinHardware.
    """
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    harware_obj = DarwinHardware(module)
    assert harware_obj.platform == 'Darwin'

# Generated at 2022-06-20 17:15:20.338343
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = MockModule()
    module.run_command = mock_run_command
    hw = DarwinHardware(module)
    assert hw._uptime_facts == {'uptime_seconds': 0}

    sysctl_cmd = 'sysctl'
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    (rc, out, err) = module.run_command(cmd, encoding=None)
    (kern_boottime, ) = struct.unpack('@L', out[:4])
    assert hw._uptime_facts == {'uptime_seconds': int(time.time() - kern_boottime)}


# Generated at 2022-06-20 17:15:33.360156
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import tempfile
    import unittest

    temp_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-20 17:15:38.421312
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    assert type(hardware.sysctl) == dict
    assert hardware.platform == "Darwin"


# Generated at 2022-06-20 17:15:51.734874
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-20 17:16:04.952648
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    my_obj = BaseFactCollector(AnsibleModule(
    ))
    my_obj.collect()
    facts = my_obj.fetch().to_dict()

    m = DarwinHardware(AnsibleModule(
    ))

    m.module = AnsibleModule(
    )

# Generated at 2022-06-20 17:16:17.187669
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule():
        def __init__(self, bin_path):
            self.bin_path = bin_path
        def get_bin_path(self, app, required=False, opt_dirs=[]):
            if app == 'sysctl':
                return self.bin_path
    class TestFactsModule():
        def __init__(self, bin_path):
            self.bin_path = bin_path
            self.sysctl = get_sysctl(self, ['hw', 'machdep', 'kern'])
        def run_command(self, cmd, encoding=None):
            out = b''
            err = b''

# Generated at 2022-06-20 17:16:28.301521
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible_collections.community.general.plugins.module_utils.facts.hardware.darwin import DarwinHardware

    # Intel CPU
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-7267U CPU @ 3.10GHz',
        'machdep.cpu.core_count': 2
    }
    cpu_facts = DarwinHardware.get_cpu_facts({'sysctl': sysctl})
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-7267U CPU @ 3.10GHz'
    assert cpu_facts['processor_cores'] == 2
    assert not cpu_facts['processor_vcpus']
    
    # PowerPC CPU