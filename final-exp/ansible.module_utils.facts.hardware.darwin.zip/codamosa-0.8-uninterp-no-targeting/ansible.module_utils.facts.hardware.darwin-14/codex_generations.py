

# Generated at 2022-06-20 17:07:39.435833
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    import sys
    if sys.version_info[0] == 2:
        import mock
    else:
        from unittest import mock
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    module = mock.MagicMock()

# Generated at 2022-06-20 17:07:45.148857
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mem_facts = DarwinHardware.get_memory_facts({},
                                                {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz',
                                                 'hw.memsize': 8589934592,
                                                 'machdep.cpu.core_count': 4,
                                                 'hw.logicalcpu': 8,
                                                 'hw.physicalcpu': 4})
    assert mem_facts['memtotal_mb'] == 8192
    assert mem_facts['memfree_mb'] == 0

# Generated at 2022-06-20 17:07:57.243510
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import unittest.mock
    import ansible.module_utils.facts.hardware.darwin
    import ansible.module_utils.basic
    import ansible.module_utils.facts.hardware.darwin_fixture_data as fixture
    darwin_hw = ansible.module_utils.facts.hardware.darwin.DarwinHardware()
    darwin_hw._module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    darwin_hw._module.run_command = unittest.mock.Mock(side_effect=[
        (0, fixture.SYSTEM_PROFILE_SP_HARDWARE_DATA_TYPE, '')])
    result = darwin_hw.get_system_profile()
    assert 'Processor Name'

# Generated at 2022-06-20 17:08:09.772990
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import sys

    if sys.version_info[0] < 3:
        import __builtin__ as builtins  # pylint: disable=import-error
        builtin_str = '__builtin__.str'
        unicode = builtins.unicode
    else:
        import builtins
        builtin_str = 'builtins.str'
        unicode = builtins.str  # pylint: disable=invalid-name

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware


# Generated at 2022-06-20 17:08:13.024728
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())

    hardware = DarwinHardware(module)

    hardware.run()

    # FIXME: make a real test
    print(hardware.get_mac_facts().keys())



# Generated at 2022-06-20 17:08:16.701809
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """ Test class initialization """

    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector
    assert isinstance(darwin_hw_collector, HardwareCollector)

# Generated at 2022-06-20 17:08:30.548153
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """Test DarwinHardware.get_mac_facts"""
    # Set up a class instance and a module object
    hardware = DarwinHardware(None)
    module = type('', (), {})()
    module.run_command = lambda *args: (0, 'hw.model: MacBookPro11,1\nhw.memsize: 1865510912', '')
    module.get_bin_path = lambda *args: '/usr/sbin/vm_stat'
    hardware.module = module
    # Test method behaviour
    assert hardware.get_mac_facts() == {
        'model': 'MacBookPro11,1',
        'osversion': '14.6.0',
        'osrevision': '19.6.0',
    }


# Generated at 2022-06-20 17:08:39.227258
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Prepare the mock module object
    module_mock = type('module_mock', (), {})()
    type.__setattr__(module_mock, 'run_command', test_run_command)

    # Get the result
    dh = DarwinHardware(module=module_mock)
    result = dh.get_uptime_facts()

    # Check the result
    assert result['uptime_seconds'] == 123


# Generated at 2022-06-20 17:08:53.035573
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module=module)


# Generated at 2022-06-20 17:09:04.715902
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mock_module = MockAnsibleModule(
        dict(
            platform='Darwin',
            os_family='Darwin',
            ansible_machine='x86_64',
        )
    )
    hardware = DarwinHardware(mock_module)
    result = hardware.populate()
    assert "Darwin" == result['platform']
    assert "Darwin" == result['os_family']
    assert "x86_64" == result['architecture']
    assert "model" in result
    assert "osversion" in result
    assert "osrevision" in result
    assert "uptime_seconds" in result
    assert "processor" in result
    assert "processor_cores" in result
    assert "processor_vcpus" in result
    assert "memtotal_mb" in result

# Generated at 2022-06-20 17:09:22.775512
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes

    # We define a mock class for the DarwinHardware class

# Generated at 2022-06-20 17:09:25.734767
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj = DarwinHardwareCollector()
    assert isinstance(obj, DarwinHardwareCollector)

# Generated at 2022-06-20 17:09:35.315408
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    sysctl_out = {'kern.osversion': '1.0', 'kern.osrevision': '2'}
    m = HardwareCollector._create_module(platform='Darwin')
    m.run_command = lambda cmd: (0, 'hw.model: Apple Mac  1 2', '')
    hd = DarwinHardwareCollector(module=m)
    hd.sysctl = sysctl_out
    facts = hd.get_mac_facts()
    assert facts == {'model': 'Apple Mac', 'osversion': '1.0', 'osrevision': '2'}



# Generated at 2022-06-20 17:09:48.068252
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    mock_module = OptiMock()
    mock_module.run_command.expect().and_return(
        (0, 'hw.model: x86_64\nhw.memsize: 17179869184\nhw.ncpu: 4\nkern.osversion: 15.6.0\nkern.osrevision: 17G65', '')
    )

    mac = DarwinHardware(mock_module)
    result = mac.populate()

    assert result.get('model') == 'x86_64'
    assert result.get('osversion') == '15.6.0'
    assert result.get('osrevision') == '17G65'
    assert result.get('memtotal_mb') == 16383
    assert result.get('memfree_mb') > 0

# Generated at 2022-06-20 17:10:00.608548
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Test with vm_stat output
    class ModuleMock(object):
        class RunCommandResult(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

        def run_command(self, argument):
            global sysctl_out
            rc = 0
            if argument[0] == '/usr/bin/sysctl':
                out = sysctl_out
            elif argument[0] == 'vm_stat':
                out = vm_stat_out
                return self.RunCommandResult(0, out, '')
            else:
                return self.RunCommandResult(256, '', 'error')
            return self.RunCommandResult(rc, out, '')

        def get_bin_path(self, argument):
            return argument

# Generated at 2022-06-20 17:10:11.614925
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    m = DarwinHardware({})
    # Mock raw data

# Generated at 2022-06-20 17:10:23.304513
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    facts = DarwinHardware()

    # Test with a simple vm_stat output

# Generated at 2022-06-20 17:10:27.449314
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    instance = DarwinHardwareCollector()
    assert isinstance(instance, DarwinHardwareCollector)
    assert instance._platform == 'Darwin'
    assert instance._fact_class == DarwinHardware

# Generated at 2022-06-20 17:10:35.119421
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 17:10:36.320495
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec=dict())
    result = DarwinHardware(module).populate()

    assert isinstance(result, dict)

# Generated at 2022-06-20 17:10:57.782487
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.modules import facts

    module = facts
    module.run_command = MagicMock(return_value=(0, "Hardware:\nHardware Overview:\n  Model Name: MacBook Air\n  Model Identifier: MacBookAir6,2\n  Processor Name: Intel Core i5\n  Processor Speed: 1.3 GHz\n  Number of Processors: 1\n  Total Number of Cores: 2", ""))
    hardware = DarwinHardware()
    system_profile = hardware.get_system_profile()

# Generated at 2022-06-20 17:11:04.870934
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock('dummy', 'dummyargs')
    darwin_hw_ins = DarwinHardware(module)
    darwin_hw_ins.sysctl = {
        'hw.model': 'dummy',
        'kern.osversion': 'dummy',
        'kern.osrevision': 'dummy',
        'hw.memsize': 'dummy',
        'hw.ncpu': 'dummy'
    }
    assert(darwin_hw_ins.populate())

# Generated at 2022-06-20 17:11:16.907615
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeAnsibleModule()

# Generated at 2022-06-20 17:11:30.602610
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """
    Tests the functionality of the method get_cpu_facts for the class DarwinHardware
    """
    # Test for Darwin on Intel
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, '', ''))
    darwin_hw = DarwinHardware(module)

    darwin_hw.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz',
        'machdep.cpu.core_count': '1',
    }
    cpu_facts = darwin_hw.get_cpu_facts()

    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz'

# Generated at 2022-06-20 17:11:37.934228
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    harwd = DarwinHardware(module)
    facts = harwd.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'uptime_seconds' in facts

# Generated at 2022-06-20 17:11:51.709806
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """
    This unit test attempts to exercise code paths in `DarwinHardware`
    """
    # Example sysctl output

# Generated at 2022-06-20 17:12:01.686504
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # create a test module
    test_module = AnsibleModule(
        argument_spec = dict()
    )

    # create a test_DarwinHardware object
    test_obj = DarwinHardware(test_module)

    # set test facts and mock methods
    test_obj.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4250U CPU @ 1.30GHz', 'machdep.cpu.core_count': 2}
    test_obj.get_system_profile = Mock()

    # call the method under test
    result = test_obj.get_cpu_facts()

    # assert that expected cpu facts were returned
    assert result['processor'] == 'Intel(R) Core(TM) i5-4250U CPU @ 1.30GHz'

# Generated at 2022-06-20 17:12:08.439083
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockModule()
    hardware = DarwinHardware(module)
    hardware.module.run_command.return_value = (0, 'hw.model: MacBookPro13,1', '')
    results = hardware.get_mac_facts()

    assert results['model'] == 'MacBookPro13,1'


# Generated at 2022-06-20 17:12:16.776161
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class FakeModule:
        def __init__(self):
            self.check_mode = False
            self.module_args = []
        def run_command(self, args, encoding=None):
            if args[0] == "/usr/sbin/system_profiler":
                return 0, "", ""
            rv = [ None, None, None ]
            if args[1] == 'hw.model':
                rv = [ 0, 'hw.model: Power Macintosh\n', "" ]
            if args[1] == 'machdep.cpu.brand_string':
                rv = [ 0, 'machdep.cpu.brand_string: Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz\n', "" ]
            if args[1] == 'hw.physicalcpu':
                r

# Generated at 2022-06-20 17:12:18.844963
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x is not None

# Generated at 2022-06-20 17:12:44.900396
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_module.run_command = MagicMock(return_value=(0, 'test', ''))
    hardware = DarwinHardware()
    hardware.module = test_module
    hardware.get_memory_facts()
    test_module.run_command.assert_called_once_with(['/usr/bin/vm_stat'])

# Generated at 2022-06-20 17:12:46.381226
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert isinstance(d, HardwareCollector)

# Generated at 2022-06-20 17:12:58.725718
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    test_class = DarwinHardware()
    attrs = {'_module': None}
    for key, value in attrs.items():
        setattr(test_class, key, value)

    # Replace sysctl with a Mock
    test_class.sysctl = {
        'hw.memsize': '1073741824',
        'hw.model': 'Macmini3,1',
        'hw.physicalcpu': '1',
        'hw.ncpu': '1',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM)3 Duo CPU 2.26GHz',
        'machdep.cpu.core_count': '2',
        'kern.osrevision': '151667',
        'kern.osversion': 'Darwin Kernel Version 15.0.0'
    }

# Generated at 2022-06-20 17:13:03.466666
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self, result={}, rc=0):
            self._result = result
            self._rc = rc

        def get_bin_path(self, binary):
            return binary

        def run_command(self, command, encoding=None):
            return (self._rc, self._result, None)

    test_result = b'{ sec = 1502905185, usec = 222381 }'
    test_rc = 0
    test_obj = DarwinHardware(MockModule(test_result, test_rc))
    res = test_obj.get_uptime_facts()

    exp_res = {
        'uptime_seconds': int(time.time() - 1502905185),
    }
    assert res == exp_res

# Generated at 2022-06-20 17:13:06.341538
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware(dict())
    assert hardware.facts['osversion']

# Generated at 2022-06-20 17:13:08.313605
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert d.platform == 'Darwin'

# Generated at 2022-06-20 17:13:16.593095
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """ Test function get_cpu_facts of class DarwinHardware """
    sysctl_mock = {
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2620 v2 @ 2.10GHz',
        'machdep.cpu.core_count': 4,
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 4
    }
    module = type('', (), {'run_command': lambda self, x: (0, '', '')})()
    mac = DarwinHardware(module, sysctl=sysctl_mock)
    assert mac.get_cpu_facts() == {'processor': 'Intel(R) Xeon(R) CPU E5-2620 v2 @ 2.10GHz', 'processor_cores': 4, 'processor_vcpus': 4}

# Generated at 2022-06-20 17:13:21.100899
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # The constructor will throw an exception if the class cannot be used.
    darwin_hw = DarwinHardware()
    assert isinstance(darwin_hw, DarwinHardware)


# Generated at 2022-06-20 17:13:28.842526
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mac_facts = DarwinHardware(dict()).populate()
    assert 'memtotal_mb' in mac_facts
    assert 'memfree_mb' in mac_facts
    assert 'processor' in mac_facts
    assert 'processor_cores' in mac_facts
    assert 'model' in mac_facts

# Generated at 2022-06-20 17:13:32.073179
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # Test constructor
    darwin_hw = DarwinHardware(dict())
    assert darwin_hw.platform == 'Darwin'



# Generated at 2022-06-20 17:14:21.878970
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-20 17:14:26.644008
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware = DarwinHardware(module)

    module.exit_json(msg=hardware)


from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-20 17:14:37.798666
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import pytest

    module = pytest.Mock()
    module.run_command.return_value = (0, "", "")

    darwin_hardware = DarwinHardware(module)

    # Replace module.run_command with a lambda function to return
    # the desidered vm_stat output
    def vm_stat_output():
        return (0, """Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                               59832.
Pages active:                            938183.
Pages inactive:                          684784.
Pages speculative:                        39893.
Pages wired down:                       4693658.
Pages purgeable:                          37693.
""", "")
    module.run_command.side_effect = vm_stat_output

    mem_facts = darwin_hardware.get_memory_facts

# Generated at 2022-06-20 17:14:45.088903
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class MockModule(object):
        def run_command(self, args, encoding=None):
            return 0, 'test: ok', ''
    mac = DarwinHardware(MockModule())
    out = mac.get_system_profile()

    assert out['test'] == 'ok'



# Generated at 2022-06-20 17:14:48.822247
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Unit test for method get_mac_facts of class DarwinHardware
    """
    m = MockModule()
    darwin_hardware = DarwinHardware(m)
    assert darwin_hardware.get_mac_facts() == {}

# Generated at 2022-06-20 17:14:56.264946
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    out = DarwinHardware.get_mac_facts(test_get_mac_facts_object)
    assert out['osversion'] == '15.6.0'
    assert out['osrevision'] == '15G31'
    assert out['model'] == 'MacBookPro11,1'
    assert out['product_name'] == 'MacBookPro11,1'



# Generated at 2022-06-20 17:15:04.683993
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    import tempfile

    class MockModule(object):
        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()

        def run_command(self, cmd, encoding=None):
            if cmd == ['vm_stat']:
                with open('/'.join([self.tmpdir, 'vm_stat_out'])) as vm_stat_out:
                    return (0, vm_stat_out.read(), '')

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.module = MockModule()
            self.hardware = DarwinHardware()

       

# Generated at 2022-06-20 17:15:11.659175
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule({})

    hw = DarwinHardware(module)

    mac_facts = hw.get_mac_facts()
    assert(mac_facts['osversion'] != '')
    assert('osrevision' in mac_facts)

    cpu_facts = hw.get_cpu_facts()
    assert(cpu_facts['processor'] != '')
    assert(cpu_facts['processor_cores'] != '')
    assert('processor_vcpus' in cpu_facts)

    mem_facts = hw.get_memory_facts()
    assert(mem_facts['memtotal_mb'] != '')
    assert(mem_facts['memfree_mb'] != '')
    assert(mem_facts['memtotal_mb'] > mem_facts['memfree_mb'])

    uptime_facts = hw

# Generated at 2022-06-20 17:15:21.541849
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = object()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': '8589934592'}
    hardware.vm_stat = {'Pages wired down': '18', 'Pages active': '30', 'Pages inactive': '28'}

    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 8192
    assert memory_facts['memfree_mb'] == 8192 - 18 * 4 * 1024 / 1024 / 1024 - 30 * 4 * 1024 / 1024 / 1024 - 28 * 4 * 1024 / 1024 / 1024

# Generated at 2022-06-20 17:15:33.613236
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    facts = dict(dict())
    module = dict(dict())
    # Test for a value of machdep.cpu.brand_string
    facts['kernel'] = 'Darwin'
    module['run_command'] = lambda x: (0, 'machdep.cpu.brand_string: Intel(R) Core(TM) i5-6360U CPU @ 2.00GHz', '')
    processor_cores_facts = dict()
    facts['processor_cores'] = processor_cores_facts
    processor_facts = dict()
    facts['processor'] = processor_facts
    processor_vcpus_facts = dict()
    facts['processor_vcpus'] = processor_vcpus_facts

    hardware = DarwinHardware(module)
    hardw