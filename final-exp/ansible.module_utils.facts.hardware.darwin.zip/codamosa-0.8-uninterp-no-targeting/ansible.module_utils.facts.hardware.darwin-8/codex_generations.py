

# Generated at 2022-06-20 17:07:28.948379
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModuleMock()
    facts = DarwinHardware(module=module)
    assert isinstance(facts, DarwinHardware)


# Generated at 2022-06-20 17:07:38.298113
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.basic import AnsibleModule, load_platform_subclass
    from ansible.module_utils.facts import default_collectors

    def test_module():
        module = AnsibleModule(
            argument_spec=dict()
        )
        result = {}

        # Get facts.
        if not module.check_mode:
            result['ansible_facts'] = dict()
            result['ansible_facts']['hardware'] = load_platform_subclass(DarwinHardware, module)()

        # Set exit message and return
        module.exit_json(**result)

    # Example of kern.boottime output:
    # Fri Oct  5 15:03:31 2018
    # This corresponds to value: 1538803811

# Generated at 2022-06-20 17:07:42.187821
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    h = DarwinHardware(dict())
    assert h.get_system_profile() == {}



# Generated at 2022-06-20 17:07:53.663496
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    hardware = DarwinHardware(module=module)
    result = hardware.populate()
    assert hardware.platform == 'Darwin'
    assert 'model' in result
    assert result['osversion']
    assert result['osrevision']
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_vcpus' in result
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'uptime_seconds' in result

# Test module
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 17:07:57.378070
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    collected_facts = dict()
    hardware_instance = DarwinHardware(succeed_json={"ansible_facts": collected_facts}, module=None)
    system_profile = hardware_instance.get_system_profile()
    assert 'Serial Number (system)' in system_profile

# Generated at 2022-06-20 17:08:01.219704
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # create a AdwinHardware
    darwin_hw = DarwinHardware({})
    # check if the platform is Darwin
    assert darwin_hw.platform == 'Darwin'

# Generated at 2022-06-20 17:08:11.437844
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module)
    hardware.populate()

    assert hardware.facts['uptime_seconds'] == 151087
    assert hardware.facts['memtotal_mb'] == 7900
    assert hardware.facts['memfree_mb'] == 5981
    assert hardware.facts['model'] == 'MacBookPro11,4'
    assert hardware.facts['osversion'] == '17.4.0'
    assert hardware.facts['osrevision'] == '15E65'
    assert hardware.facts['processor'] == 'Intel(R) Core(TM) i7-4770HQ CPU ' + \
                                          '@ 2.20GHz'
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_vcpus'] == 8

# Generated at 2022-06-20 17:08:19.303616
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    args = dict(
        module_name='test',
        module_args='test',
        module_kwargs=dict(collect_default=False, gather_subset=[])
    )
    module = AnsibleModule(**args)
    b = DarwinHardware()
    b.module = module
    result = b.get_system_profile()
    assert result['Serial Number'] == 'C0JH19G1DV9Y'
    assert result['Boot ROM Version'] == '166.0.0'
    assert result['SMC Version (system)'] == '2.19f12'
    for key in [
        'Hardware UUID',
        'Number of Processors',
        'Processor Name',
        'Processor Speed',
        'Memory',
        'Startup Disk',
    ]:
        assert key in result



# Generated at 2022-06-20 17:08:32.693781
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import datetime
    import pytz
    import time

    now = datetime.datetime.now(pytz.timezone('UTC'))

    def mock_run_command(cmd, encoding=None):
        # We are only interested in the seconds part, so the fractional part
        # does not matter.
        boot_time = int(time.mktime(now.timetuple()))

        # Bytes, not strings.
        return (0, struct.pack('@L', boot_time), '')

    module = type('AnsibleModule', (object,), dict(run_command=mock_run_command))
    hardware = DarwinHardware(module=module)
    uptime_facts = hardware.get_uptime_facts()


# Generated at 2022-06-20 17:08:42.208138
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock
    mock_module = MagicMock()

    class TestDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    with patch.object(get_sysctl, 'get_sysctl') as mock_func:
        mock_func.return_value = dict()
        # Test when brand_string is present
        mock_module.run_command = MagicMock(side_effect=[(0, 'brand_string', None), (0, '__apple_copyright__', None)])
        dh = TestDarwinHardware(mock_module)
        dh.sysctl

# Generated at 2022-06-20 17:09:09.222861
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModule(argument_spec={})
    hc = DarwinHardwareCollector(module)

    assert hc.platform == 'Darwin'
    assert hc.fact_class == DarwinHardware

# Unit tests for class DarwinHardware

# Generated at 2022-06-20 17:09:11.959364
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hw = DarwinHardware({})
    # TODO: Add tests for _get_sysctl()


# Generated at 2022-06-20 17:09:15.621964
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    m = DarwinHardware()
    assert m.get_uptime_facts() == {'uptime_seconds': 1458348529}

# Generated at 2022-06-20 17:09:19.197809
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x.platform == 'Darwin'
    assert x.fact_class == DarwinHardware


# Generated at 2022-06-20 17:09:25.663072
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Execute method with 4 parameter and get result
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    hw_facts = DarwinHardware(module).populate()

    # Check the result
    # All value will be positif since it is the result of an integer division
    assert hw_facts['memtotal_mb'] > 0
    assert hw_facts['memfree_mb'] > 0


# Generated at 2022-06-20 17:09:36.059602
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    '''
    Test the DarwinHardware class method get_uptime_facts with a mock
    sysctl command as input.
    '''
    # Call the method with a mocked sysctl command
    # The mocked command output matches the output of
    # sysctl kern.boottime -b on a macOS 10.13.6 (High Sierra)
    # machine, with a system that has been booted on 2020-01-24
    # at 13:31:42
    darwin_hardware = DarwinHardware(None)
    boottime = darwin_hardware.get_uptime_facts()

    # Check that we get the correct uptime in seconds
    assert boottime['uptime_seconds'] == 1579871754

# Generated at 2022-06-20 17:09:48.482778
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import unittest

    class FakeModule(object):
        def __init__(self, cmd, value):
            self.cmd = cmd
            self.value = value

        def get_bin_path(self, cmd):
            return self.cmd

        def run_command(self, cmd, encoding=None, *args, **kwargs):
            if self.cmd == 'wrong':
                return 1, '', ''

            struct_format = '@L'
            struct_size = struct.calcsize(struct_format)

            (kern_boottime,) = struct.unpack(struct_format, self.value[:struct_size])

            real_cmd = [self.cmd, '-b', 'kern.boottime']


# Generated at 2022-06-20 17:10:00.812316
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    module = AnsibleModule(argument_spec={})
    h = DarwinHardware(module)

    # First test with a fake sysctl.hw.physicalcpu
    h.sysctl = fake_sysctl = {}
    fake_sysctl['machdep.cpu.brand_string'] = "Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz"
    fake_sysctl['hw.physicalcpu'] = 2
    fake_sysctl['machdep.cpu.core_count'] = 4
    fake_sysctl['hw.logicalcpu'] = 8
    fake_sysctl['hw.ncpu'] = 8


# Generated at 2022-06-20 17:10:11.645326
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    module = MagicMock(name='module')

    class ModuleSubclass:
        def __init__(self):
            self.module = module

    darwinHardware = DarwinHardware(ModuleSubclass())

    # Test case 1: vm_stat returns error
    module.run_command.return_value = 255, 'error', ''

    memory_facts = darwinHardware.get_memory_facts()

    module.run_command.assert_called_once_with("vm_stat")
    assert memory_facts == {
        "memtotal_mb": 0,
        "memfree_mb": 0
    }

    # Test case 2: vm_stat running successfully
    module.reset_mock()


# Generated at 2022-06-20 17:10:13.511767
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._fact_class.platform == 'Darwin'
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:10:36.438367
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    assert DarwinHardware().get_cpu_facts() == dict(processor='Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz', processor_vcpus='4', processor_cores='4')


# Generated at 2022-06-20 17:10:46.282281
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    '''
        Unit test to test method populate of class DarwinHardware
    '''

    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list'),
        ),
        supports_check_mode=True,
    )

    # Create instance of DarwinHardware
    result = DarwinHardware(module=module)
    # Execute method populate
    result.populate()
    # Check output
    result_dict = result.get_facts()
    assert 'model' in result_dict
    assert 'product_name' in result_dict
    assert 'osrevision' in result_dict
    assert 'processor' in result_dict
    assert 'processor_cores' in result_dict
    assert 'processor_vcpus' in result_dict

# Generated at 2022-06-20 17:10:47.129588
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector()._platform == 'Darwin'
    assert DarwinHardwareCollector()._fact_class == DarwinHardware

# Generated at 2022-06-20 17:10:57.684983
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # mock the response of command vm_stat
    # the command is equivalent to `vm_stat | grep -vE "Pages|free"`
    # on macOS Mojave (10.14.6)
    out = """
Pages wired down:            4429784
Pages active:                2252223
Pages inactive:              1321429
Pages speculative:            719226
File-backed pages:           1955517
Anonymous pages:             1201278
Compressions:                   636
Decompressions:                 848
Compressor Size:                 4
"""
    module = AnsibleModuleMock({'vm_stat': ('cmd', out, '', 0)})
    h = DarwinHardware(module)
    assert h.get_memory_facts() == {'memtotal_mb': 16384, 'memfree_mb': 5287}

# Generated at 2022-06-20 17:11:07.493549
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    darwin_hardware = DarwinHardware({})
    darwin_hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '17113',
        'hw.model': 'MacBookPro14,1',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-7820HQ CPU @ 2.90GHz',
        'machdep.cpu.core_count': '4',
        'hw.memsize': '17179869184',
        'hw.logicalcpu': '8',
        'hw.physicalcpu': '4'
    }
    hardware_facts = darwin_hardware.populate()

    assert hardware_facts['uptime_seconds'] == 0
    assert hardware_facts

# Generated at 2022-06-20 17:11:17.806901
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.collector import FactsCollector

    start_time = int(time.time())
    test_hardware = DarwinHardware()

    def test_sysctl_factory(module, _):
        return {'kern.boottime': start_time}

    test_hardware.get_sysctl = test_sysctl_factory
    test_hardware.get_bin_path = lambda _: None

    facts_collector = FactsCollector(None, {}, None)
    test_hardware.populate(facts_collector)
    uptime = int(facts_collector.get_facts()['ansible_uptime_seconds'])

# Generated at 2022-06-20 17:11:30.853145
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = mock.Mock(run_command=_command, get_bin_path=_bin_path)
    hw = DarwinHardware(module)
    facts = hw.populate()
    assert int(facts['uptime_seconds']) > 0
    assert facts['processor'] == b'Intel(R) Core(TM) i7-4510U CPU @ 2.00GHz'
    assert facts['processor_cores'] == '2'
    assert int(facts['memtotal_mb']) > 0
    assert int(facts['memfree_mb']) > 0
    assert facts['model'] == b'MacBookPro11,3'
    assert facts['osversion'] == b'16.6.0'
    assert facts['osrevision'] == b'16G29'
    assert facts['uptime_seconds'] > 0



# Generated at 2022-06-20 17:11:41.591439
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MagicMock()
    facts = (
        {
            'hw.machdep.cpu.brand_string': 'Intel Core i7-6600U CPU @ 2.60GHz',
            'hw.machdep.cpu.core_count': 4
        },
        {
            'hw.model': 'Intel Xeon',
            'hw.physicalcpu': 8,
            'hw.logicalcpu': 16,
        },
        {
            'hw.model': 'Power Macintosh',
            'hw.physicalcpu': 1,
            'hw.logicalcpu': 1,
        },
    )


# Generated at 2022-06-20 17:11:43.186827
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()
    assert hardware

# Generated at 2022-06-20 17:11:53.613639
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # test on macos, first use Intel
    def test_sysctl(key):
        if key == 'machdep.cpu.core_count':
            return '12'
        elif key == 'machdep.cpu.brand_string':
            return 'Intel(R) Core(TM) i7-7820HQ CPU @ 2.90GHz'
        else:
            return ''

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware(None)
    darwin_hardware.sysctl = test_sysctl
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-7820HQ CPU @ 2.90GHz'
    assert cpu_facts

# Generated at 2022-06-20 17:12:37.644003
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    h = DarwinHardwareCollector()
    assert h.platform == 'Darwin'

# Generated at 2022-06-20 17:12:46.607326
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    hw = DarwinHardware(dict())

    # The "uptime" command on Darwin is a Perl script that formats the output.
    # We don't care about the formatting, so we'll use a different command.
    # We need to tell the module to load "sysctl".
    hw.module = FakeModule(dict(ansible_sysctl=dict()))
    hw.module.run_command = FakeCommand(
        return_value=(0, 'kern.boottime: { sec = 1523990527, usec = 634941 }\n', '')
    )

    uptime_facts = hw.get_uptime_facts()
    expected_uptime_facts = dict(
        uptime_seconds=20,
    )
    assert uptime_facts == expected_uptime_facts


# A fake AnsibleModule

# Generated at 2022-06-20 17:12:47.914301
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hw = DarwinHardware({})
    assert hw.platform == 'Darwin'
    assert hw.facts == {}

# Generated at 2022-06-20 17:13:01.060894
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """
    Run tests on method get_cpu_facts of class DarwinHardware
    """

    import json
    import os
    import tempfile

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    fact_names = [
        'processor',
        'processor_cores',
        'processor_vcpus'
        ]
    fact_values = [
        'Intel(R) Core(TM) i7-3615QM CPU @ 2.30GHz',
        4,
        4
        ]
    mocker = Mocker()
    module = AnsibleModule(argument_spec=dict())
    dh = DarwinHardware(module)
    dh.module = Mocker()
    dh.module.run_command = mocker.mock()
    dh.module.run_command("sysctl -a")


# Generated at 2022-06-20 17:13:11.172110
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule()
    hardware = DarwinHardware(module)
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['osversion'] == "16.7.0"
    assert mac_facts['osrevision'] == "Darwin Kernel Version 16.7.0: Thu Jun 15 17:36:27 PDT 2017; root:xnu-3789.70.16~2/RELEASE_X86_64"

# Generated at 2022-06-20 17:13:17.879919
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    mac_facts = DarwinHardware({})
    cpu_facts = mac_facts.get_cpu_facts()
    assert cpu_facts['processor_cores'] > 0

# Generated at 2022-06-20 17:13:28.565348
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()

# Generated at 2022-06-20 17:13:30.730919
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 17:13:34.345774
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test = DarwinHardware()
    system_profile = test.get_system_profile()
    mac_facts = test.get_mac_facts()
    assert mac_facts['model'] == system_profile['Model Name']
    assert mac_facts['osversion'] == '19.6.0'
    assert mac_facts['osrevision'] == 'Darwin Kernel Version 19.6.0: Mon Aug 31 22:13:44 PDT 2020; root:xnu-6153.141.1~1/RELEASE_X86_64'


# Generated at 2022-06-20 17:13:47.630156
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    class MyDarwinHardware(DarwinHardware):
        def __init__(self, module):
            super(MyDarwinHardware, self).__init__(module)
            self.sysctl = {u'kern.osrevision': u'', u'kern.osversion': u'16.6.0', u'hw.model': u'MacBookPro13,3'}
        def get_system_profile(self):
            return dict()
    hardware_obj = MyDarwinHardware(None)
    mac_facts = hardware_obj.get_mac_facts()
    assert mac_facts['osversion'] == '16.6.0'
    assert mac_facts['osrevision'] == ''

# Generated at 2022-06-20 17:15:22.913826
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import sys
    import os
    import json

    # This combines the AnsibleModule and DarwinHardware classes
    # so we can test the class methods in isolation, without needing a mock
    test_module = type('AnsibleModule', (object,), dict(
        run_command=DarwinHardwareCollector.run_command,
        get_bin_path=DarwinHardwareCollector.get_bin_path,
        fail_json=DarwinHardwareCollector.fail_json,
        exit_json=DarwinHardwareCollector.exit_json,
        AnsibleModule=type('AnsibleModule', (object,), dict(
            params=dict(),
            check_mode=False,
            no_log=False,
        )),
    ))()

    # Populate the test AnsibleModule instance with specific data

# Generated at 2022-06-20 17:15:33.919126
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import sys
    import platform

    sys.modules['ansible'] = mock.Mock()
    sys.modules['ansible.module_utils'] = mock.Mock()
    sys.modules['ansible.module_utils.facts'] = mock.Mock()
    sys.modules['ansible.module_utils.facts.system'] = mock.Mock()
    sys.modules['ansible.module_utils.facts.system.platform'] = 'Darwin'
    sys.modules['ansible.module_utils.facts.hardware'] = mock.Mock()

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware(mock.Mock())


# Generated at 2022-06-20 17:15:45.084047
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MagicMock()
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '', '')
    sysctl = {'kern.osversion': '1', 'kern.osrevision': '2'}
    get_sysctl = MagicMock()
    get_sysctl.return_value = sysctl
    module.get_bin_path = MagicMock(side_effect=lambda x: x)
    module.boolean = lambda x: x

    hardware = DarwinHardware(module)
    hardware.sysctl = sysctl

    module.run_command.return_value = (0, 'hw.model: MacBookPro', '')
    mac_facts = hardware.get_mac_facts()

# Generated at 2022-06-20 17:15:49.632071
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware(dict())
    darwin_hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) M-5Y71 CPU @ 1.20GHz',
        'machdep.cpu.core_count': '2'
    }
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) M-5Y71 CPU @ 1.20GHz'
    assert cpu_facts['processor_cores'] == '2'
    del darwin_hardware


# Generated at 2022-06-20 17:15:53.245631
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = type('DummyModule', (), {'run_command': mocked_run_command})
    darwin_hardware = DarwinHardware(module)
    expected_facts = {
        'memtotal_mb': 1044768,
        'memfree_mb': 996176
    }
    assert darwin_hardware.get_memory_facts() == expected_facts



# Generated at 2022-06-20 17:16:01.128106
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    module = mock.MagicMock()
    hardware = DarwinHardware(module)
    hardware.get_system_profile = mock.MagicMock()
    hardware.get_system_profile.return_value = dict()
    assert isinstance(hardware.get_system_profile(), dict)


# Generated at 2022-06-20 17:16:07.942325
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    test_host = 'localhost'
    test_runner = None
    test_module = None

    test_darwin_hardware = DarwinHardware(test_runner, test_module, test_host)

    test_kern_boottime = 1515496197
    test_time_now = 1515496200

    test_kern_boottime_struct_format = '@L'
    test_kern_boottime_struct_size = struct.calcsize(test_kern_boottime_struct_format)

    test_kern_boottime_bytes = struct.pack(test_kern_boottime_struct_format, test_kern_boottime)
    test_time_now_bytes = struct.pack(test_kern_boottime_struct_format, test_time_now)


# Generated at 2022-06-20 17:16:18.129099
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = MessageStoreMock()
    darwinHardware = DarwinHardware(module)
    system_profile = darwinHardware.get_system_profile()

    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Model Identifier'] == 'MacBookPro10,1'
    assert system_profile['Processor Name'] == 'Intel Core i7'
    assert system_profile['Processor Speed'] == '2.6 GHz'
    assert system_profile['Number of Processors'] == '1'
    assert system_profile['Total Number of Cores'] == '4'
    assert system_profile['L2 Cache (per Core)'] == '256 KB'
    assert system_profile['L3 Cache'] == '6 MB'
    assert system_profile['Memory'] == '16 GB'



# Generated at 2022-06-20 17:16:26.888180
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    Unit test for method get_uptime_facts of class DarwinHardware.
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    l_class = DarwinHardware()

    # In real conditions, we cannot know what Apple will use for kern.boottime
    # in the future so we will only test that the returned value is an integer.
    l_int = l_class.get_uptime_facts()['uptime_seconds']
    assert isinstance(l_int, int), "Error in class DarwinHardware, method get_uptime_facts"

# Generated at 2022-06-20 17:16:36.432984
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_facts = {
        'hw': {
            'memsize': '1048576',  # 1 GB
        },
        'machdep': {},
        'kern': {},
    }
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module)
    hardware.sysctl = test_facts
    hardware.get_memory_facts()
    assert hardware.memory_facts['memtotal_mb'] == 1024
    assert hardware.memory_facts['memfree_mb'] == 1024

