

# Generated at 2022-06-20 17:07:33.556258
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    mac = DarwinHardware(module=module)
    mac.sysctl = {
        'hw.memsize': 1048576,
    }
    mac.get_memory_facts()
    assert mac.facts['memtotal_mb'] == 1024
    assert mac.facts['memfree_mb'] == 0


# Generated at 2022-06-20 17:07:43.047159
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))
            self.get_bin_path = Mock(return_value=None)

    # Test sysctl hw.model
    mac_facts = {
        'model': 'MacBookPro8',
        'product_name': 'MacBookPro8',
        'osversion': '14.1.0',
        'osrevision': '1266',
    }
    cpu_facts = {
        'processor': 'Intel(R) Core(TM) i7-3720QM CPU @ 2.60GHz',
        'processor_cores': 4,
        'processor_vcpus': 8,
    }

# Generated at 2022-06-20 17:07:54.537018
# Unit test for method populate of class DarwinHardware

# Generated at 2022-06-20 17:08:01.908678
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModuleMock()
    module.run_command = lambda x: (0, 'hw.model: MacBookPro\nhw.model: MacBookPro\nhw.model: MacBookPro8,2\nhw.model: MacBookPro\nhw.model: MacBookPro8,2\nhw.model: MacBookPro\nhw.model: MacBookPro\n',"")
    module.get_bin_path = lambda x: '/usr/sbin/system_profiler'

    dh = DarwinHardware(module)
    assert dh.get_mac_facts() == {'osversion': '15.6.0', 'osrevision': '15G31', 'model': 'MacBookPro8,2'}


# Generated at 2022-06-20 17:08:07.956337
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock(params=dict())

    hardware = DarwinHardware()
    hardware.module = module
    hardware.populate()

    # assert statements to verify the results
    assert(hardware.facts['osversion'] == '14.3.0')
    assert(hardware.facts['osrevision'] == '15D21')
    assert(hardware.facts['model'] == 'MacBookPro6,2')
    assert(int(hardware.facts['uptime_seconds']) > 0)
    assert(int(hardware.facts['memtotal_mb']) > 0)
    assert(int(hardware.facts['memfree_mb']) > 0)
    assert(hardware.facts['processor'] == 'Intel(R) Core(TM) i7-2720QM CPU @ 2.20GHz')
   

# Generated at 2022-06-20 17:08:14.252119
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class ModuleMock(object):
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, name, opts=None):
            return '/usr/sbin/vm_stat'


# Generated at 2022-06-20 17:08:16.403466
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    darwin_hardware = DarwinHardware(None)
    assert darwin_hardware.platform == 'Darwin'

# Generated at 2022-06-20 17:08:22.849793
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class MockModule:
        def __init__(self, sysctl):
            self.sysctl_data = sysctl

        def run_command(self, command, encoding=None): pass
        def get_bin_path(self, executable): pass

        def run_command(self, command):
            rc = 0
            out = ''
            err = ''
            if command[0] == 'sysctl':
                if command[1] == 'hw.model':
                    rc = 0
                    out = 'hw.model: Power Macintosh\n'
                if command[1] == 'machdep.cpu.brand_string':
                    rc = 0
                    out = 'machdep.cpu.brand_string: Intel Core i7\n'
            return rc, out, err

        def sysctl(self, sysctl_args):
            return self

# Generated at 2022-06-20 17:08:33.753370
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestDarwinHardwareModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_values = dict()
            self.run_command_values['rc'] = 0
            self.run_command_values['err'] = ''
            self.run_command_values['out'] = ''

        def get_bin_path(self, name, required=False):
            return name

        def run_command(self, args, encoding=None):
            self.run_command_calls += 1
            return (
                self.run_command_values['rc'],
                self.run_command_values['out'],
                self.run_command_values['err'],
            )


# Generated at 2022-06-20 17:08:36.871433
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    """
    Test DarwinHardware Class
    """
    facts_module = DarwinHardware(None)
    assert facts_module.platform == 'Darwin'


# Generated at 2022-06-20 17:08:54.548925
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a FakeModule object
    module = FakeModule()

    # Create an instance of DarwinHardware
    darwin_hardware = DarwinHardware(module)

    # Get a dictionary of system_profile
    system_profile = darwin_hardware.get_system_profile()

    # Assert the system_profile is not empty
    assert system_profile, 'get_system_profile failed'

    # Assert the system_profile has some of the keys
    assert 'Hardware Overview' in system_profile
    assert 'Memory' in system_profile
    assert 'Model Identifier' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile



# Generated at 2022-06-20 17:08:55.107661
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()


# Generated at 2022-06-20 17:08:59.141497
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # Base case
    module = AnsibleModule(dict())
    dhw = DarwinHardware(module)

    assert dhw is not None
    assert dhw.module == module

# Generated at 2022-06-20 17:09:01.771450
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware_inst = DarwinHardware()
    system_profile = hardware_inst.get_system_profile()
    assert(system_profile.get('Hardware UUID') is not None)

# Generated at 2022-06-20 17:09:05.293876
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    dcol = DarwinHardwareCollector()
    assert isinstance(dcol._fact_class, DarwinHardware)

# Generated at 2022-06-20 17:09:16.093795
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    h = DarwinHardware()

    h.module.run_command.return_value = (0, 'hw.model: MacBookPro6,2\nhw.memsize: 17179869184', '')
    h.module.get_bin_path.return_value = '/bin/vm_stat'
    h.module.run_command.return_value = (0, 'Pages free:                 473.\nPages wired down:    717019.\nPages active:     21661815.\nPages inactive:    3427583.\nPages speculative:   428806.\nPages throttled:         0.\nPages purgeable:        64.\n"Translation faults:       0.\nPages copy-on-write:   20578.', '')

# Generated at 2022-06-20 17:09:24.849985
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware = DarwinHardware()
    hardware.sysctl = {}
    hardware.sysctl['hw.memsize'] = '4294967296'
    hardware.sysctl['hw.physicalcpu'] = '4'
    hardware.sysctl['hw.model'] = 'MacProx,x86_64'
    hardware.sysctl['kern.osversion'] = '15A284'
    hardware.sysctl['kern.osrevision'] = '14B25'

    hardware.module.run_command = lambda x, encoding=None: (0, "", "")
    hardware.get_system_profile = lambda: {}

    facts = hardware.populate()

    assert facts['memtotal_mb'] == 4096
    assert facts['memfree_mb'] == 0
    assert facts['processor_cores'] == '4'
    assert facts

# Generated at 2022-06-20 17:09:28.878296
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import json
    import os

    module = ModuleFactCollector()

    darwin = DarwinHardware()
    darwin.sysctl = json.loads(os.environ['MOCK_SYSCONFIG'])
    darwin.module = module
    result = darwin.get_system_profile()
    assert result['Memory'] == '16 GB'
    assert result['Processor Name'] == 'Intel Core i7'
    assert result['Processor Speed'] == '2.5 GHz'
    assert result['Serial Number (system)'] == 'F83HTMG7DNFR'

# Generated at 2022-06-20 17:09:37.618384
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    class TestModule():
        def __init__(self):
            self.sysctl = {
                'hw.model': 'MacPro4,1',
                'kern.osversion': 'Version is 15.4',
                'kern.osrevision': 'Revision is 20',
            }
        def run_command(self, command):
            if command[0] == 'sysctl':
                return (0, 'hw.model: Mac Pro (8-core)\n', '')
            elif command[0] == '/usr/sbin/system_profiler':
                return (0, 'Hardware:', '')
            else:
                return (1, 'No command', 'Error')

    module = TestModule()
    darwin_facts = DarwinHardware(module)
    mac_facts = darwin_facts.get_

# Generated at 2022-06-20 17:09:47.663254
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # This test requires the module_utils directory to be in the
    # PYTHONPATH.
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    hardware = DarwinHardware(module)

    hardware.sysctl = {
        'kern.osversion': '16.7.0',
        'kern.osrevision': '1510.30.2',
    }

    facts = hardware.get_mac_facts()

    assert facts['osversion'] == '16.7.0'
    assert facts['osrevision'] == '1510.30.2'


# Generated at 2022-06-20 17:10:07.478011
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector._platform == "Darwin"
    assert DarwinHardwareCollector._fact_class == DarwinHardware

# Generated at 2022-06-20 17:10:16.549469
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Retrieve the cpu facts
    hw = DarwinHardware()
    cpu_facts = hw.get_cpu_facts()

    # The following assertions can only be done if the method call above succeed
    if cpu_facts:
        assert cpu_facts['processor']
        assert cpu_facts['processor_cores']
        assert cpu_facts['processor_vcpus']



# Generated at 2022-06-20 17:10:23.005514
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import mock
    module = mock.MagicMock()
    module.run_command = mock.MagicMock()
    module.run_command.return_value = (0, "hw.model: MacBookPro10,1\n", "")
    hardware = DarwinHardware(module)
    expected = {"model": "MacBookPro10,1", "osversion": "", "osrevision": ""}
    assert hardware.get_mac_facts() == expected


# Generated at 2022-06-20 17:10:33.646717
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Create a dummy module, which uses a dummy class
    class FakeModule(object):
        def __init__(self, dict_):
            self.params = dict_
            for key, value in dict_.iteritems():
                setattr(self, key, value)

        def fail_json(self, msg):
            self.msg = msg

        def run_command(self, cmd, encoding=None):
            # Assume the command is sysctl hw.model
            return 0, self.model, ''

    class DummyClass(object):
        def __init__(self, dict_):
            for key, value in dict_.iteritems():
                setattr(self, key, value)

    # Start testing

# Generated at 2022-06-20 17:10:35.336453
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hw = DarwinHardware(module)
    assert hw.platform == 'Darwin'

# Generated at 2022-06-20 17:10:45.943222
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import sys
    import pytest

    from ansible_collections.ansible.community.tests.unit.module_utils.facts.hardware import darwin_hardware

    # simple test for model
    dm = darwin_hardware.DarwinHardware()
    dm.module = sys.modules[__name__]
    dm.sysctl = { 'hw.model': 'a' }
    output = dm.get_mac_facts()
    assert output == {
        'model': 'a',
        'osversion': '',
        'osrevision': '',
    }

    # simple test for osversion and osrevision
    dm = darwin_hardware.DarwinHardware()
    dm.module = sys.modules[__name__]

# Generated at 2022-06-20 17:10:57.177622
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # mock class module with current time = 1590854105
    class Module:
        def __init__(self):
            self._run_command_rc = 0
            self._run_command_out = struct.pack('@L', 0, 1590854105)
            self._run_command_err = ''
            self.run_command_called = 0
        # mock run_command method of class module
        def run_command(self, cmd, encoding=None):
            self.run_command_called += 1
            return (self._run_command_rc, self._run_command_out, self._run_command_err)

    module = Module()

    # mock class DarwinHardware

# Generated at 2022-06-20 17:11:06.822168
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import os
    import tempfile
    import platform

    # Setup test results
    rc = 0
    err = []
    out = """hw.model: MacPro1,1
kern.osversion: 19.6.0
kern.osrevision: VMware71"""

    # Create a temporary file and write the test results to it
    fd, tmpfile = tempfile.mkstemp()
    os.write(fd, out.encode('utf-8'))
    os.close(fd)

    # Create a temporary module
    import ansible.module_utils.facts.system.dmesg as dmesg_module

    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.system.dmesg import DmesgModule

# Generated at 2022-06-20 17:11:15.712136
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware({})
    assert hardware.collect() == {
        'processor': 'Intel(R) Core(TM) i7-4750HQ CPU @ 2.00GHz',
        'processor_cores': 4,
        'processor_vcpus': 4,
        'memtotal_mb': 16384,
        'memfree_mb': 5613,
        'model': 'MacBookPro11,5',
        'osversion': '17.3.0',
        'osrevision': '15E65',
        'uptime_seconds': 78327,
    }

# Generated at 2022-06-20 17:11:24.847157
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mac_facts = DarwinHardware()
    mac_facts.sysctl = {'hw.memsize': 20971520}
    memory_facts = mac_facts.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 20
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-20 17:12:09.272301
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    modul = AnsibleModule(
        argument_spec = dict()
    )
    hal = DarwinHardware(modul)
    facts = hal.populate()
    assert isinstance(facts, dict)
    assert facts['uptime_seconds'] > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] <= facts['memtotal_mb']


# Generated at 2022-06-20 17:12:12.655185
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    # Load the class
    DarwinHardware()
    

# Generated at 2022-06-20 17:12:14.212021
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector.platform == 'Darwin'
    assert collector.fact_class == DarwinHardware

# Generated at 2022-06-20 17:12:25.489375
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    class MockModule(object):
        def run_command(self, args, encoding=None):
            class MockRC(object):
                def __init__(self, rc):
                    self.rc = rc
            
            if args == ["/usr/sbin/system_profiler", "SPHardwareDataType"]:
                rc = 0

# Generated at 2022-06-20 17:12:33.095597
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    '''
    test_DarwinHardware_get_mac_facts
    '''
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    mac_facts = DarwinHardware(module).get_mac_facts()
    module.run_command.assert_called_with('sysctl hw.model')
    assert mac_facts['osversion'].startswith('Darwin Kernel Version')
    assert mac_facts['osrevision'].startswith('16')


# Generated at 2022-06-20 17:12:45.062777
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    mac_facts = dict(
        model='MacBookAir7,2',
        product_name='MacBookAir7,2',
        osversion='19.6.0',
        osrevision='15G1611',
    )

    cpu_facts = dict(
        processor='Intel(R) Core(TM) i5-4250U CPU @ 1.30GHz',
        processor_cores=2,
        processor_vcpus=4,
    )

    memory_facts = dict(
        memtotal_mb=8192,
        memfree_mb=8192,
    )

    uptime_facts = dict(
        uptime_seconds=12,
    )

    expected_facts = dict()
    expected_facts.update(mac_facts)
   

# Generated at 2022-06-20 17:12:55.135813
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    class TestObj:
        def __init__(self, module):
            self.module = module

        def run_command(self, command):
            return 0, "", ""


# Generated at 2022-06-20 17:13:01.516788
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Use mock to simulate run_command.
    # This is probably really heavy, but mainly to avoid using a real test
    # system.
    import mock

    # Test case 1: vm_stat returns 0 and the following command output
    # PageSize: 4096
    # Pages free: 3896
    # Pages active: 6172
    # Pages inactive: 5921
    # Pages speculative: 210
    # Pages wired down: 49185

    # The expected result is {'memtotal_mb': 1073676, 'memfree_mb': 966}
    mock_run_command = mock.Mock()

# Generated at 2022-06-20 17:13:12.112666
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """Unit test of method DarwinHardware.get_mac_facts

    """
    _test_module = None  # Fake module
    _test_module.run_command = test_module_run_command

    hardware_object = DarwinHardware(_test_module)
    result = hardware_object.get_mac_facts()

    # test expected values
    assert 'osversion' in result
    assert 'osrevision' in result
    assert 'model' in result
    assert result['model'] == 'Macmini1,1'
    assert result['osversion'] == '15.4.0'
    assert result['osrevision'] == '15.4.0'


# Generated at 2022-06-20 17:13:24.325265
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import ansible.module_utils.facts.hardware.darwin as darwin

    class Module(object):

        def get_bin_path(self, name):
            return 'sysctl'

        def run_command(self, cmd, encoding=None):
            res = b''
            if cmd[-1] == '-b kern.boottime':
                res = b'{ sec = 10000, usec = 0 }\n'
            return 0, res, ''

    hardware = darwin.DarwinHardware()
    hardware.module = Module()
    hardware.populate()
    assert hardware.osrevision != ''
    assert hardware.osversion != ''
    assert hardware.uptime_seconds != ''

# Generated at 2022-06-20 17:14:36.579526
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware = DarwinHardware()
    facts = hardware.get_mac_facts()
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts


# Generated at 2022-06-20 17:14:50.238836
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # set up a test object
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.module import AnsibleModule

# Generated at 2022-06-20 17:15:01.455017
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    module.run_command = lambda *args, **kwargs: (0, "hw.memsize: 8589934592\nhw.physicalcpu: 4\nhw.logicalcpu: 4\nmachdep.cpu.brand_string: Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz\nmachdep.cpu.core_count: 2\nkern.osversion: 15.6\nkern.osrevision: 11G63\n", "")
    facts = DarwinHardware(module)
    facts.populate()
    assert facts.processor_cores == '4'
    assert facts.processor_vcpus == '4'

# Generated at 2022-06-20 17:15:10.354611
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule:
        def __init__(self):
            self.run_command = local_run_command
        def get_bin_path(self, path):
            return path
    class TestCollector(DarwinHardware):
        def __init__(self):
            self.module = TestModule()
    data = '{ kern = { boottime = ( sec = 1512667584, usec = 474245 ); }; }'
    def local_run_command(cmd, encoding=None):
        return [0, data, '']
    # We call the real code, not a fake
    collector = TestCollector()
    uptime_seconds = collector.get_uptime_facts()['uptime_seconds']
    assert uptime_seconds == int(time.time() - 1512667584)

# Generated at 2022-06-20 17:15:22.448228
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module_args = dict(
        gather_subset='all',
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    darwin_hardware = DarwinHardware(module)

    # The following tests are mostly for coverage.  There's no way to
    # return realistic output without actually running the command.
    # So we just fake the output here.

    # Test good output.
    module.run_command = Mock(return_value=(0, '', ''))
    memory_facts = darwin_hardware.get_memory_facts()
    assert memory_facts == {'memtotal_mb': 0, 'memfree_mb': 0}

    # Test error output.

# Generated at 2022-06-20 17:15:28.306298
# Unit test for method get_mac_facts of class DarwinHardware

# Generated at 2022-06-20 17:15:35.655609
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # We cannot use the unit test class because it uses the DarwinHardwareCollector
    # class which needs the module_utils module to be loaded with the module
    # and some system facts populated. We don't want to test facts, only this
    # method.
    import ansible.module_utils
    from ansible.module_utils.facts.collector import BaseFactCollector

    class FakeModule(ansible.module_utils.basic.AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(FakeModule, self).__init__(*args, **kwargs)

            self.fake_command_results = {
                '/usr/sbin/system_profiler SPHardwareDataType': (0, test_system_profile_return, '')
            }
            self.run_command_results = {}


# Generated at 2022-06-20 17:15:42.395759
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    fake_module = type('', (), {
        'run_command.return_value': (0, '0x000466bb 0x00000001', ''),
    })()
    facts = DarwinHardware(fake_module)
    uptime_facts = facts.get_uptime_facts()
    assert int(time.time() - 1148658580) == uptime_facts['uptime_seconds']

# Generated at 2022-06-20 17:15:53.461029
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = MockModule()
    sysctl_cmd = get_bin_path('sysctl', required=True)
    cmd = [sysctl_cmd, '-b', 'kern.boottime']

    # Return raw bytes, not UTF-8.
    rc, out, err = module.run_command(cmd, encoding=None)
    assert rc == 0
    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    assert len(out) >= struct_size
    (kern_boottime, ) = struct.unpack(struct_format, out[:struct_size])

    # Expected uptime based on kern.boottime value
   

# Generated at 2022-06-20 17:15:55.437940
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    h = DarwinHardware()
    assert h.get_facts()
