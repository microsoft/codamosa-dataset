

# Generated at 2022-06-20 17:07:36.886180
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import os
    from ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.common.process import get_bin_path
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.test_module_facts import MockModule

    try:
        get_bin_path('vm_stat')
    except ValueError:
        # vm_stat may not exist on all Darwin systems
        return

    sysctl_cmd = 'sysctl'

    # Create a fake module object that passes a fake ansible call
    module = MockModule()

    # Create an instance of DarwinHardware class
    dh = DarwinHardware(module)

    # Fake sysctl module

# Generated at 2022-06-20 17:07:40.723048
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_data = """
Hardware Overview:
  Model Name: MacBook Pro
  Model Identifier: MacBookPro12,1
  Processor Name: Intel Core i7
  Processor Speed: 3.1 GHz
  Number of Processors: 1
  Total Number of Cores: 4
  L2 Cache (per Core): 256 KB
  L3 Cache: 6 MB
  Memory: 16 GB
  Boot ROM Version: 194.0.0.0.0
  SMC Version (system): 2.27f2
"""

# Generated at 2022-06-20 17:07:47.232226
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = mock.Mock()
    darwin_hardware = DarwinHardware(module)

    command_output = """
        Mach Virtual Memory Statistics: (page size of 4096 bytes)
        Pages free:                         8385.
        Pages active:                       2855.
        Pages inactive:                     3383.
        Pages wired down:                   5933.
        "Translation faults":               164539.
        Pages copy-on-write:                6309.
        Pages zero filled:                  279.
        Pages reactivated:                  5.
        Pageins:                            43.
        Pageouts:                           0.
        Object cache: 100 hits of 1005 lookups (10% hit rate)
        """

    darwin_hardware.module.run_command.return_value = (0, command_output, '')

    memory_facts = darwin_

# Generated at 2022-06-20 17:07:57.559249
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # We create a class with the interface required by the hardware collector
    # (see the module_utils/hardware/__init__.py file)
    module = type('MockModule', (object, ), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: '/bin/false',
        'debug': lambda *args, **kwargs: None,
    })()

# Generated at 2022-06-20 17:08:03.959377
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    mac_obj = DarwinHardware()
    mac_obj.sysctl = {'machdep.cpu.brand_string': 'intel cpu1'}
    result = mac_obj.get_cpu_facts()
    assert result['processor'] == 'intel cpu1'


# Generated at 2022-06-20 17:08:12.332202
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    class module:
        class run_command:

            def __init__(self, name):
                self.name = name
                self.rc = 0
                self.err = None
                self.output = struct.pack('@L', 1377478008)

            def __call__(self, *args, **kwargs):
                assert kwargs['encoding'] is None
                assert self.name == 'sysctl -b kern.boottime'
                assert self.rc == 0
                assert self.err is None
                assert self.output is not None
                return self.rc, self.output, self.err

    # Run test
    dh = DarwinHardware(module())
    facts = dh.get_uptime_facts()
    # Expected
    assert facts == { 'uptime_seconds': 145 }

# Generated at 2022-06-20 17:08:21.446156
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    hardware = DarwinHardware()
    hardware.module = MagicMock()
    # Check the correct return on a correct parameter
    hardware.module.run_command.return_value = 0, '4', None
    hardware.module.get_bin_path.return_value = '/usr/bin/sysctl'
    assert hardware.get_uptime_facts() == {'uptime_seconds': 4}
    hardware.module.run_command.assert_called_once_with(['/usr/bin/sysctl', '-b', 'kern.boottime'], encoding=None)
    hardware.module.get_bin_path.assert_called_once_with('sysctl')
    # Check the return with a wrong parameter
    hardware.module.reset_mock()
    hardware.module.run_command.return_value = 1, None, None

# Generated at 2022-06-20 17:08:33.363184
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    m = DarwinHardware()
    # Match output of `system_profiler SPHardwareDataType`
    input = 'Pages free:                   44951.\nPages active:                  28861.\nPages inactive:                20755.\nPages wired down:              23152.\nPages purgeable:                4693.\n"Translation faults":       118459417.\nPages copy-on-write:         51542521.\nPages zero filled:          361324492.\nPages reactivated:             65106.\nPageins:                     3580772.\nPageouts:                       5547.\nObject cache: sid 0 objects 14139 and slots 14141.\n'
    m.module.run_command = lambda command, encoding=None, data=None: (0, input, '')

# Generated at 2022-06-20 17:08:42.291802
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    '''Unit test for method get_memory_facts of class DarwinHardware'''
    darwin_hardware = DarwinHardware()

# Generated at 2022-06-20 17:08:54.132371
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mock_module = MagicMock()
    mock_cmd = MagicMock(return_value=(0, 'hw.memsize: 2147483648\nkern.osversion: 15.5.0\nkern.osrevision: 15.5.0\nmachdep.cpu.brand_string: Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz\nmachdep.cpu.core_count: 4\nhw.logicalcpu: 8\nhw.logicalcpu_max: 8\nhw.physicalcpu: 4\nhw.physicalcpu_max: 4\nhw.memsize: 17179869184', ''))
    mock_module.run_command = mock_cmd

    hardware = DarwinHardware(mock_module)

# Generated at 2022-06-20 17:09:08.616728
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module, order_attrs=True)
    facts = hardware.populate()
    assert "model" in facts

# Generated at 2022-06-20 17:09:17.320078
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    import datetime
    import sys

    if sys.version_info.major >= 3:
        long = int

    # Get the current time in seconds.
    # This will be used to compare with the
    # value that is returned by get_uptime_facts().
    now = datetime.datetime.utcnow()
    now_seconds = int(now.strftime('%s'))

    # We need this monkeypatch to avoid the following error
    # in module_utils/facts/hardware/darwin.py:360:
    #     get_bin_path('sysctl')
    # module_utils.common.process.ValueError: Cannot find 'sysctl'
    original_get_

# Generated at 2022-06-20 17:09:24.789281
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    d = DarwinHardware(None)

    d.sysctl = {
        'kern.osversion': '16.0.0',
        'kern.osrevision': 'somestring',
        'hw.model': 'MacBookPro13,2',
    }

    # We are not interested in the two methods called by populate
    d.get_cpu_facts = lambda: None
    d.get_memory_facts = lambda: None

    facts = d.populate()
    assert len(facts) == 3
    assert facts['osversion'] == '16.0.0'
    assert facts['osrevision'] == 'somestring'
    assert facts['model'] == 'MacBookPro13,2'

# Generated at 2022-06-20 17:09:29.128046
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mac_hw_info = DarwinHardware()
    mac_hw_info.module = FakeAnsibleModule()
    mac_hw_info.module.run_command = fake_run_command
    mac_hw_info.sysctl = dict()
    mac_hw_info.sysctl['kern.osversion'] = '16.7.0'
    mac_hw_info.sysctl['kern.osrevision'] = '151671'

    mac_facts = mac_hw_info.get_mac_facts()
    assert mac_facts['osversion'] == '16.7.0'
    assert mac_facts['osrevision'] == '151671'

    mac_facts = mac_hw_info.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro'
    assert mac_facts

# Generated at 2022-06-20 17:09:38.641501
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = DummyModule()
    hardware = DarwinHardware(module)

    hardware.sysctl = {
        "kern.osversion": "16.7.0",
        "kern.osrevision": "17G65",
    }

    rc, out, err = module.run_command.return_value
    module.run_command.return_value = 0, "hw.model: MacBookPro9,2", ""
    rc, out, err = module.run_command.return_value
    module.run_command.return_value = 0, "", ""

    expected = {
        "osversion": "16.7.0",
        "osrevision": "17G65",
        "model": "MacBookPro9,2",
        "product_name": "MacBookPro9,2",
    }

    actual

# Generated at 2022-06-20 17:09:49.353278
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import os
    import tempfile


# Generated at 2022-06-20 17:09:55.654241
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware_get_uptime_facts
    uptime_facts = DarwinHardware_get_uptime_facts()

    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-20 17:09:59.863571
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector(None)
    assert type(collector) is DarwinHardwareCollector


# Generated at 2022-06-20 17:10:11.399857
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = get_test_module()
    hardware = DarwinHardware(module)
    hardware.get_mac_facts = lambda: {'osversion': '17.7.0', 'osrevision': '1510'}
    hardware.get_cpu_facts = lambda: {'processor': 'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz',
                                      'processor_cores': 8, 'processor_vcpus': 8}
    hardware.get_memory_facts = lambda: {'memtotal_mb': 8192, 'memfree_mb': 5131}
    hardware.get_uptime_facts = lambda: {'uptime_seconds': 47150}
    facts = hardware.populate()

    assert facts['osversion'] == '17.7.0'
    assert facts['osrevision']

# Generated at 2022-06-20 17:10:20.006380
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    with patch('ansible.module_utils.facts.hardware.darwin.DarwinHardware.get_system_profile') as mocked_get_system_profile:
        mocked_get_system_profile.return_value = 'some_value'
        darwin_hardware = DarwinHardware(None)
        assert darwin_hardware.get_system_profile() == 'some_value'

# Generated at 2022-06-20 17:10:41.012288
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    darwin_hardware = DarwinHardware(module)
    hardware_facts = darwin_hardware.populate()

    assert hardware_facts['uptime_seconds']


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-20 17:10:44.486063
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardwareCollector = DarwinHardwareCollector()
    assert hardwareCollector._fact_class is DarwinHardware
    assert hardwareCollector._platform == 'Darwin'

# Generated at 2022-06-20 17:10:51.035764
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(dict())
    harware_facts = DarwinHardwareCollector(module).collect()
    assert 'processor' in harware_facts
    assert 'processor_cores' in harware_facts
    assert 'processor_vcpus' in harware_facts


# Generated at 2022-06-20 17:10:52.843516
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert isinstance(DarwinHardwareCollector(None), DarwinHardwareCollector)


# Generated at 2022-06-20 17:10:54.115251
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-20 17:11:06.054477
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from datetime import datetime

    # Use a class to fake the module
    class DummyModule(object):

        def __init__(self):
            self.run_command_values = []

        def run_command(self, cmd, encoding=None):
            assert cmd == [DarwinHardware.get_bin_path('sysctl'), '-b', 'kern.boottime']
            assert encoding is None

            if not self.run_command_values:
                return (255, '', '')

            value, output = self.run_command_values.pop(0)
            return value, output, ''

        def get_bin_path(self, binary):
            return binary

    # Create a fake module object
    fake_module = DummyModule()

    # Create a fake uptime value

# Generated at 2022-06-20 17:11:14.903980
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, '1361538132', None)
    module_mock.get_bin_path.return_value = '/usr/sbin/sysctl'

    test_class = DarwinHardware(module_mock)
    expected_result = {'uptime_seconds': 1361538134}
    result = test_class.get_uptime_facts()

    assert result == expected_result


# Generated at 2022-06-20 17:11:29.030291
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    mock_module = type('MockModule', (object,), {
        'run_command': lambda *a, **kw: (0, 'some output', ''),
        'get_bin_path': lambda *a, **kw: '/bin/some_binary',
    })

    # Test Intel hardware
    hardware = DarwinHardware(mock_module)
    hardware.sysctl = {
        'kern.osversion': '15.5.0',
        'kern.osrevision': '15.5.0',
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 8,
        'machdep.cpu.brand_string': "Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz",
        'machdep.cpu.core_count': 4,
    }
   

# Generated at 2022-06-20 17:11:40.111101
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.process import get_bin_path

    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            rc = 0
            out = StringIO("hw.model: x86_64\n")
            err = StringIO("")
            return (rc, out.read(), err.read())

        def get_bin_path(self, arg):
            return get_bin_path(arg)

    # Initialize test object
    test_object = DarwinHardware()
    test_object.module

# Generated at 2022-06-20 17:11:52.556317
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import datetime

    class MockModule(object):
        class MockRunCommand(object):
            def __init__(self, rc=0, out=b'', err=b''):
                self.rc = rc
                self.out = out
                self.err = err

            def __call__(self, cmd, encoding=None):
                return (self.rc, self.out, self.err)

        def __init__(self):
            self.run_command = self.MockRunCommand()

        def get_bin_path(self, name):
            return '', name

    class MockTime(object):
        def __init__(self, now=1489761176.0657522):
            self.now = now

        def time(self):
            return self.now

    # The sysctl command works and sp

# Generated at 2022-06-20 17:12:24.887514
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    test_module.run_command = MagicMock(return_value=(0, "Hardware:\n    Hardware Overview:\n      Model Name: iMac\n      Model Identifier: iMac11,1\n      Processor Name: Intel Core i3\n      Processor Speed: 3.06 GHz\n      Number Of Processors: 1\n      Total Number Of Cores: 2\n      L2 Cache: 256 KB\n      Memory: 4 GB\n      Bus Speed: 1.07 GHz\n    Boot ROM Version: IM112.0057.B00\n    SMC Version (system): 1.57f17\n  System Version: OS X 10.11.6 (15G31)\n", ""))

# Generated at 2022-06-20 17:12:35.018514
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Mock class to allow creation of class with arguments
    class MockModule:
        def __init__(self, sysctl=dict()):
            self.sysctl = sysctl

        def run_command(self, cmd):
            return (0, "", "")

        def get_bin_path(self, _):
            return ""

    # Intel Mac
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R)',
        'machdep.cpu.core_count': 2,
    }

    # Mock class to allow creation of class with arguments
    class MockModule_Intel(MockModule):
        def __init__(self, sysctl=dict()):
            super(MockModule_Intel, self).__init__(sysctl)


# Generated at 2022-06-20 17:12:38.902026
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware()

    hardware.module.run_command = lambda _: (0, "hw.model: Macmini6,2", "")

    mac_facts = hardware.get_mac_facts()

    assert mac_facts == dict(
        model="Macmini6,2",
        osversion="15.4.0",
        osrevision="17E199",
    )



# Generated at 2022-06-20 17:12:46.961055
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)

    time_utc_epoch = time.mktime(time.gmtime())
    epoch_time = int(time_utc_epoch)

    # Using a fake value for kern.boottime
    buffer_struct = struct.pack('@L', epoch_time)
    hardware.get_uptime_facts.return_value = True, buffer_struct, None
    assert hardware.get_uptime_facts() == {
        'uptime_seconds': int(time.time() - epoch_time),
    }

    # Using a fake value for kern.boottime that is bigger than 2^32, which is
    # a limit on PPC.
    buffer_struct = struct.pack('@L', epoch_time)

# Generated at 2022-06-20 17:12:59.703569
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module=test_module)

    # happy path
    rc, out, err = test_module.run_command('sysctl hw.model')
    out = ''.join(out)
    test_module.run_command.return_value = (0, out, '')
    test_module.run_command = Mock(return_value=(0, ''.join(out), ''))
    test_module.run_command.return_value = (0, 'MacBookPro14,3', '')
    test_module.run_command.return_value = (0, '15.6.0', '')
    test_module.run_command.return_value = (0, '15.6.0', '')
    result = hardware.get_

# Generated at 2022-06-20 17:13:12.348810
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mock_module = Mock(name='ansible.module_utils.common.process.get_bin_path')
    mock_get_bin_path = Mock(name='ansible.module_utils.facts.hardware.darwin.get_bin_path')
    with patch.object(DarwinHardware, 'sysctl', new_callable=PropertyMock(return_value={'kern.osrelease': '15.3.0'})):
        host = DarwinHardware(module=mock_module)

# Generated at 2022-06-20 17:13:25.242390
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Returns the uptime in seconds
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    darwinhw = DarwinHardware(module)

    cmd = ['sysctl', '-b', 'kern.boottime']
    rc, out, err = module.run_command(cmd, encoding=None)

    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if rc != 0 or len(out) < struct_size:
        return None

    (kern_boottime, ) = struct.unpack(struct_format, out[:struct_size])

# Generated at 2022-06-20 17:13:28.974762
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x._platform == 'Darwin'
    assert x._fact_class.__name__ == 'DarwinHardware'


# Generated at 2022-06-20 17:13:37.469209
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    out = """Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro11,1
      Processor Name: Intel Core i7
      Processor Speed: 2.2 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 6 MB
      Memory: 16 GB
      Boot ROM Version: MBP111.0138.B17
      SMC Version (system): 2.18f15
"""
    hardware = DarwinHardware()
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro', "System profile failed to return Model Name"
    assert system_profile['Model Identifier'] == 'MacBookPro11,1', "System profile failed to return Model Identifier"
    assert system

# Generated at 2022-06-20 17:13:44.121283
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    command_module = AnsibleModule(argument_spec=dict())
    hw = DarwinHardware()
    hw.module = command_module
    hw.sysctl = dict()
    hw.sysctl['hw.memsize'] = '1041234567'

    # get_memory_facts should return a dictionary where:
    #  - memtotal_mb is 1041234567 // 1024 // 1024
    #  - memfree_mb is 0
    assert hw.get_memory_facts() == {
        'memtotal_mb': 1009,
        'memfree_mb': 0,
    }

# Generated at 2022-06-20 17:14:36.254103
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import time

    darwinHardware = DarwinHardware()

    # Time that elapsed since the last boot
    elapsedSeconds = 10

    # Seconds and microseconds of the boot, as a tuple of two 64 bits int
    boottime = (int(time.time()) - elapsedSeconds, 0)

    # Packed structure that contains the boottime
    packed = struct.pack('@L', boottime[0])

    uptime_facts = darwinHardware.get_uptime_facts()

    assert uptime_facts == { 'uptime_seconds': elapsedSeconds }

# Generated at 2022-06-20 17:14:50.114786
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    Collects memory facts from the system.
    """
    # Create a Fake AnsibleModule object
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()

    # Fake the input args
    module.params = {}
    module.params['custom'] = []

    # Fake the method run_command
    module.run_command = MagicMock(return_value=None)

# Generated at 2022-06-20 17:14:55.741454
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    facts = dict(DarwinHardware().get_memory_facts())
    assert 'memtotal_mb' in facts
    assert facts['memtotal_mb'] > 0
    assert 'memfree_mb' in facts
    assert facts['memfree_mb'] >= 0

# Generated at 2022-06-20 17:15:08.333344
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeModule()

    # Test the Intel case
    module.run_command.return_value = (0, 'hw.machdep.cpu.brand_string: Intel(R) Core(TM) i5-4570S CPU @ 2.90GHz', None)
    module.run_command.side_effect = None
    module.run_command.return_value = (0, 'hw.physicalcpu: 1', None)
    module.run_command.return_value = (0, 'hw.logicalcpu: 2', None)
    module.run_command.return_value = (0, 'hw.ncpu: 2', None)
    processor = DarwinHardware(module)

# Generated at 2022-06-20 17:15:21.509389
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import mock
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    module = mock.MagicMock()

    darwin = DarwinHardware(module)

    # Mock the output of the command "sysctl -b kern.boottime"
    # This output is always in raw bytes, not UTF-8.
    module.run_command.return_value = 0, struct.pack('@L', 0), ''
    assert darwin.get_uptime_facts() == {'uptime_seconds': 0}

    module.run_command.return_value = 0, struct.pack('@L', 1), ''
    assert darwin.get_uptime_facts() == {'uptime_seconds': 1}

    module.run_command.return_value = 0, struct.pack('@L', 42),

# Generated at 2022-06-20 17:15:27.393862
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware = DarwinHardware(module)
    # TODO: Add tests
    # facts = hardware.populate()
    # assert facts == {
    # }

# Generated at 2022-06-20 17:15:35.455639
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    test_cases = [
        {
            'sysctl': {
                'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4460 CPU @ 3.20GHz',
                'machdep.cpu.core_count': 2
            },
            'expected': {
                'processor': 'Intel(R) Core(TM) i5-4460 CPU @ 3.20GHz',
                'processor_cores': 2
            }
        },
        {
            'sysctl': {
                'hw.physicalcpu': 2,
            },
            'expected': {
                'processor': 'Processor Name @ Processor Speed',
                'processor_cores': 2
            }
        }
    ]


# Generated at 2022-06-20 17:15:45.601638
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))
            self.params = {'gather_subset': 'all'}

    class MockOS(object):
        def __init__(self):
            self.name = 'Darwin'

    module = MockModule()
    set_module_args(dict(
        gather_subset=['all'],
    ))
    os = MockOS()
    hardware = DarwinHardware(module)
    hardware.distribution = os

    # Get the cpu facts
    cpu_facts = hardware.get_cpu_facts()

    # Check no error
    assert 'error' not in cpu_facts

    # Check processor

# Generated at 2022-06-20 17:15:50.295557
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock()
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    cpu_facts_test = darwin_hardware.get_cpu_facts()
    for actual_fact, expected_value in [
        ('processor', 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'),
        ('processor_cores', '4'),
        ('processor_vcpus', '4')
    ]:
        assert cpu_facts_test[actual_fact] == expected_value

# Generated at 2022-06-20 17:15:59.077987
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    test_object=DarwinHardware(None)
    result=test_object.get_system_profile()
    keys=["Hardware Overview", "Model Identifier", "Processor Name", "Processor Speed", "Memory", "System Version", "Serial Number (system)"]
    assert all(key in result for key in keys)
