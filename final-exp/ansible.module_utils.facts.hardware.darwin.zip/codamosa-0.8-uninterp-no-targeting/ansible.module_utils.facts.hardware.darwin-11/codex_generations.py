

# Generated at 2022-06-20 17:07:27.264864
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert d._fact_class == DarwinHardware
    assert d._platform == 'Darwin'

# Generated at 2022-06-20 17:07:36.463240
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware = DarwinHardware()
    hardware.get_system_profile = lambda: {'Model Name': 'MacBook Pro',
                                           'Processor Name': 'Intel Core i7', 'Processor Speed': '2.2 GHz'}
    hardware.sysctl = {
        'machdep.cpu.brand_string': '',
        'kern.osversion': '15.7.0',
        'kern.osrevision': '15.2.0',
        'hw.memsize': '42949672960',
        'hw.model': 'MacBookPro11,2',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8'
    }

# Generated at 2022-06-20 17:07:48.171865
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = type('AnsibleModule', (object,), {"run_command": lambda *args, **kwargs: (0, "hw.model: iMac15,1\n", "")})
    harware = DarwinHardware(module=module)
    system_profile = {'Machine Model': 'iMac'}
    system_profile_py3_unicode_string = {'Machine Model': 'iMac\u2019s'}
    harware.get_system_profile = lambda: system_profile
    facts = {'model': 'iMac', 'osversion': '', 'osrevision': ''}
    assert harware.get_mac_facts() == facts
    harware.get_system_profile = lambda: system_profile_py3_unicode_string

# Generated at 2022-06-20 17:07:50.488514
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    hardware.populate()

    assert hardware.facts == dict()

# Generated at 2022-06-20 17:07:58.907764
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mem_facts = {
        'memtotal_mb': int(16 * 1024 * 1024 * 1024 // 1024 // 1024),
        'memfree_mb': 0,
    }

# Generated at 2022-06-20 17:08:04.216263
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    system_profile = DarwinHardware(module=test_module).get_system_profile()
    assert len(system_profile) > 0


# Generated at 2022-06-20 17:08:05.075086
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-20 17:08:13.734432
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts import FactCollector
    from io import StringIO
    import sys
    import pytest
    class MockModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, bin_name, required=False):
            return bin_name
        def run_command(self, command, encoding=None):
            if command[1] == '-b':
                out = "\x00\x00\x00\x00\x00\x00\x00\x00"
            else:
                out = '0'
            return 0, out, ''
    class MockLegacyUtils(object):
        def __init__(self):
            self.params = {}

# Generated at 2022-06-20 17:08:19.232273
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin

    module = MockModule()
    hardware = ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin.DarwinHardware(module)

    # Use a well-known date (1/1/1901) and add some seconds to it
    BOOTTIME_SECONDS = int(time.mktime(time.strptime('1901 01 01', '%Y %m %d')))
    BOOTTIME_SECONDS += 345678

    # First, test an error condition
    hardware.module.run_command = Mock(return_value=[1, '', ''])
    assert hardware.get_uptime_facts() == {}


# Generated at 2022-06-20 17:08:32.657200
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    class MockModule(object):
        def __init__(self, vm_stat_command=None, command_result=None):
            self.vm_stat_command = vm_stat_command
            self.command_result = command_result

        def get_bin_path(self, command, opt_dirs=[]):
            return self.vm_stat_command

        def run_command(self, command, encoding=None):
            # Return empty string.
            return self.command_result

    # Test the case where vm_stat is not found.
    module = MockModule(None)
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert hardware.module.get_bin_path.call_count == 1
    assert memory_facts.get('memtotal_mb') is not None
   

# Generated at 2022-06-20 17:08:54.522019
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # This test is specific to Mac OS X 10.9.5
    darwin_hardware_get_cpu_facts_object = DarwinHardware({'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz'})
    processor = darwin_hardware_get_cpu_facts_object.get_cpu_facts()['processor']
    assert processor == 'Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz'
    core_count = darwin_hardware_get_cpu_facts_object.get_cpu_facts()['processor_cores']
    assert core_count == 2

# Generated at 2022-06-20 17:09:05.232362
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-20 17:09:07.597282
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware(None)
    assert hardware.platform == 'Darwin'

# Generated at 2022-06-20 17:09:16.992457
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    command_output = """
Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro8,1
      Processor Name: Intel Core i7
      Processor Speed: 2.2 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 8 MB
      Memory: 8 GB
      Boot ROM Version: MBP81.0047.B27
      SMC Version (system): 1.69f2
      Serial Number (system): C02L37YDDFH4
      Hardware UUID: D14B7B21-A150-5E4A-8C0F-41BD2EB6E9BC
"""
    hardware = DarwinHardware()
    system_profile = hardware.get_system_profile()


# Generated at 2022-06-20 17:09:28.133021
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """This test method aims to cover the DarwinHardware._get_uptime_facts method.
    It uses the following pytest fixtures:
    - mac_command_fixture: provides a macOS machine to run the tests on (the test method runs on macos)
    - mac_command_get_bin_path: defines the path to the system binaries needed by the test method
    It uses the following pytest markers:
    - mac_command_check: marks the test as excluded on non-macos targets
    """

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from .fixtures.mac_command_fixture import mac_command_fixture
    from .fixtures.mac_command_get_bin_path import mac_command_get_bin_path

    # This fixture is used to get the path of the 'sysctl'

# Generated at 2022-06-20 17:09:37.462862
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """ Unit test for get_system_profile method of class DarwinHardware """
    import os
    import sys
    import filecmp
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils._text import to_bytes

    test_file = os.path.join(os.path.dirname(__file__), 'system_profiler.txt')
    test_data = DarwinHardware.get_system_profile()
    test_result = dict()

    for line in open(test_file, 'r').read().splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)

# Generated at 2022-06-20 17:09:44.172911
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time

    class FakeModule:
        def run_command(self, command, encoding=None):
            # Each field has 8 bytes, so boottime is at 20 bytes.
            # Return seconds since epoch.
            return 0, struct.pack('@Q', time.time()), ''
        def get_bin_path(self, name):
            return 'sysctl'

    module = FakeModule()

    darwin_hardware = DarwinHardware(module=module)
    uptime_facts = darwin_hardware.get_uptime_facts()
    fact_uptime_seconds = uptime_facts['uptime_seconds']
    command_uptime_seconds = time.time() - int(time.time())
    assert fact_uptime_seconds == int(command_uptime_seconds)

# Generated at 2022-06-20 17:09:47.474826
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    result = DarwinHardwareCollector().collect()
    assert "processor" in result


# Generated at 2022-06-20 17:09:56.803196
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    facts = {}
    hardware = DarwinHardware(module, facts)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-4590 CPU @ 3.30GHz'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == '4'


# Generated at 2022-06-20 17:10:06.348867
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel x86 CPU'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts == {'processor': 'Intel x86 CPU', 'processor_cores': '', 'processor_vcpus': ''}


# Generated at 2022-06-20 17:10:29.641479
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    d = DarwinHardware(dict())
    assert d.platform == 'Darwin'
    # Test the empty path doesn't raise an exception
    assert repr(d)
    assert isinstance(d.get_memory_facts(), dict)
    assert isinstance(d.get_cpu_facts(), dict)
    assert isinstance(d.get_mac_facts(), dict)
    assert isinstance(d.get_uptime_facts(), dict)

# Generated at 2022-06-20 17:10:35.064747
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    dwh = DarwinHardware(module)
    module.exit_json(changed=False, ansible_facts=dict(ansible_hardware=dict()))

# Generated at 2022-06-20 17:10:45.853172
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeModule()  # noqa
    darwin_hardware = DarwinHardware(module=module)
    darwin_hardware.sysctl['kern.osversion'] = '15.6.0'
    darwin_hardware.sysctl['kern.osrevision'] = '15G22010'
    rc, out, err = darwin_hardware.module.run_command("sysctl hw.model")
    if rc != 0:
        assert darwin_hardware.get_mac_facts() == {}
    else:
        assert darwin_hardware.get_mac_facts() == {'model': out.rstrip().split()[-1],
                                                   'osversion': '15.6.0',
                                                   'osrevision': '15G22010'}


# Generated at 2022-06-20 17:10:54.673967
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():

    module = AnsibleModule(argument_spec=dict())
    hardware_obj = DarwinHardware(module)
    hardware_obj.populate()
    facts = module.exit_json()["ansible_facts"]

    for fact in [ "processor", "processor_cores", "model", "osversion", "osrevision", "uptime_seconds",
                  "memtotal_mb", "memfree_mb" ]:
        assert fact in facts


# Generated at 2022-06-20 17:11:06.254402
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = type('AnsibleModule', (object,), {'run_command': fake_run_command})
    module = type('AnsibleModule', (object,), {'run_command': fake_run_command})
    darwin_hardware = DarwinHardware(module)

    # sysctl returns 0
    module.run_command = fake_run_command(0, 'hw.model: iMac13,2')
    mac_facts = darwin_hardware.get_mac_facts()
    assert mac_facts['model'] == 'iMac13,2'

    # sysctl returns 1
    module.run_command = fake_run_command(1, '')
    mac_facts = darwin_hardware.get_mac_facts()
    assert mac_facts['model'] == ''



# Generated at 2022-06-20 17:11:10.536902
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Test if a class object gets created for the class
    obj = DarwinHardwareCollector()
    # Test if the _fact_class class attribute is DarwinHardware
    assert obj._fact_class == DarwinHardware
    # Test if the _platform class attribute is Darwin
    assert obj._platform == 'Darwin'


# Generated at 2022-06-20 17:11:18.265951
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = DummyModule()

    # Test for the vm_stat command
    vm_stat_command = get_bin_path('vm_stat')

    # Mock the default output of the vmstat command

# Generated at 2022-06-20 17:11:30.940288
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    class TestObj(object):
        def __init__(self):
            self.module = self

        def run_command(self):
            pass

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, args):
            out = 'machdep.cpu.brand_string: Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz\n'
            out += 'machdep.cpu.core_count: 2\n'

            return(0, out, "")

    test_obj = TestObj()
    test_obj.module = MockModule()


# Generated at 2022-06-20 17:11:38.603981
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    """Test creation of DarwinHardware class, which is instantiated by the
    fact collection process."""
    # Initialize class
    darwin_obj = DarwinHardware(dict())
    # Assert if it is the correct class
    assert isinstance(darwin_obj, DarwinHardware)
    # Assert platform is set correctly
    assert darwin_obj.platform == 'Darwin'
    # Assert that it is a subclass of class Hardware
    assert issubclass(DarwinHardware, Hardware)

# Generated at 2022-06-20 17:11:40.703381
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    host_info = DarwinHardware()
    assert host_info.platform == 'Darwin'

# Generated at 2022-06-20 17:12:22.829561
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mock_module = MockModule()
    mock_module.run_command.return_value = 0, """Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                             2652512.
Pages active:                            138025.
Pages inactive:                          186026.
Pages speculative:                           0.
Pages wired down:                        200051.
Pages purgeable:                               0.
""", ""
    darwin_hardware_obj = DarwinHardware(mock_module)
    memory_facts = darwin_hardware_obj.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 262144
    assert memory_facts['memfree_mb'] == 258819



# Generated at 2022-06-20 17:12:29.706541
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    darwin_hardware = DarwinHardware(module)
    assert darwin_hardware.module == module
    assert darwin_hardware.sysctl is None



# Generated at 2022-06-20 17:12:33.976924
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # mock output of command 'sysctl hw.model'
    DarwinHardware.module = Mock(run_command=Mock(return_value=(0, 'hw.model: MacBookPro6,2', '')))

    # call the method being tested
    facts = DarwinHardware().get_mac_facts()

    # verify returned hardware facts
    assert facts['model'] == 'MacBookPro6,2'



# Generated at 2022-06-20 17:12:45.343215
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Test data
    test_data = dict(
        model = "MacBookPro11,1",
        osversion = "15.6.0",
        osrevision = "17G65",
        processor = "Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz",
        processor_cores = "8",
        processor_vcpus = "8",
        memtotal_mb = "16384",
        memfree_mb = "4386",
        uptime_seconds = "48299",
        product_name = "MacBookPro11,1"
    )

    # Initialize the instance
    darwin_hardware = DarwinHardware(dict(module=dict(run_command=run_command)))
    # Run the populate instance
    result = darwin_hardware.populate()



# Generated at 2022-06-20 17:12:56.875836
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MagicMock()
    module.run_command.return_value = (0, 'hw.model: Macmini2,1\n', '')
    module.get_bin_path.return_value = '/usr/sbin/system_profiler'
    system_profile = {
        'Model Identifier': 'Macmini2,1',
        'Software': 'macOS High Sierra 10.13.6 (17G65)',
        'Serial Number (system)': 'C04960AAU54',
        'Hardware UUID': '59ED0D6C-1F33-5E2D-ABCF-7F2D5D890E6F'
    }

# Generated at 2022-06-20 17:13:04.753921
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    collected_facts = {
        'ansible_memtotal_mb': None
    }

    vm_stat_out = b"""Mach Virtual Memory Statistics: (page size of 4096 bytes)
    Pages free:                               498467.
    Pages active:                              47079.
    Pages inactive:                            12322.
    Pages speculative:                            0.
    Pages wired down:                          12300.
    "Translation faults":                   5100907.
    Pages copy-on-write:                      515159.
    Pages zero filled:                       9861022.
    Pages reactivated:                          896.
    Pageins:                                    756.
    Pageouts:                                    0.
    Object cache: 128 hits of 159481 lookups (0% hit rate)
"""

    m = DarwinHardware(dict(module=None))

# Generated at 2022-06-20 17:13:09.188469
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module=module) # pylint: disable=no-member
    data = hardware.get_uptime_facts()

    assert ('uptime_seconds' in data)

# Generated at 2022-06-20 17:13:15.695075
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule(object):
        def run_command(self, command, encoding=None):
            if command[-2:] == ["-b", "kern.boottime"]:
                return (
                    0,
                    struct.pack("@L", 1524820799),
                    ""
                )
            else:
                return (1, "", "")

        def get_bin_path(self, path):
            return "sysctl"

    darwinHardware = DarwinHardware(MockModule())
    assert darwinHardware.get_uptime_facts()['uptime_seconds'] == 3

# Generated at 2022-06-20 17:13:24.981673
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    now = int(time.time())

    # First test: can we get the uptime from the system?
    # If the system does not work properly, we should not
    # fail the test.
    try:
        uptime_facts = DarwinHardware(dict()).get_uptime_facts()
        uptime_seconds = uptime_facts['uptime_seconds']
    except:
        uptime_seconds = -1
    assert uptime_seconds >= 0

    # Second test: do we return a valid value?
    # The uptime may differ from the real one, but it should
    # be at least 5 seconds.
    assert now - 5 <= uptime_seconds

# Generated at 2022-06-20 17:13:36.022970
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Preparing mock class
    class MockModule:
        def __init__(self):
            self.run_command = Mock(return_value=(0, '', ''))

        def get_bin_path(self, executable):
            return '/usr/bin/vm_stat'

    mock_module = MockModule()
    # Preparing result
    result = {'memtotal_mb': 2413, 'memfree_mb': 1637}
    # Preparing mock results and testing

# Generated at 2022-06-20 17:14:59.080747
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    module.run_command = mock_run_command
    hardware = DarwinHardware(module)
    mac_facts = hardware.get_mac_facts()
    assert mac_facts['model'] == 'MacBookPro'
    assert mac_facts['osversion'] == '15.6.0'
    assert mac_facts['osrevision'] == '19G201'


# Generated at 2022-06-20 17:15:09.926309
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware(dict())
    darwin_hardware.sysctl = {'hw.physicalcpu': '4', 'hw.logicalcpu': '4', 'hw.ncpu': '4',
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E31240 @ 3.30GHz',
        'machdep.cpu.core_count': '4'}
    cpu_facts = darwin_hardware.get_cpu_facts()

    assert('processor_cores' in cpu_facts)
    assert(cpu_facts['processor_cores'] == 4)
    assert('processor' in cpu_facts)
    assert(cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E31240 @ 3.30GHz')

# Generated at 2022-06-20 17:15:22.279199
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, "hw.model: Apple iMac\n", "")
    module.get_bin_path.return_value = "sysctl"
    module.params = dict()
    module.params["gather_subset"] = ["!all", "!min"]

    dh = DarwinHardware(module)
    dh.sysctl = dict()
    dh.sysctl["kern.osversion"] = "16.6.0"
    dh.sysctl["kern.osrevision"] = "77.0.0"

    mac_facts = dh.get_mac_facts()

    module.run_command.assert_called_once_with(["sysctl", "hw.model"])

# Generated at 2022-06-20 17:15:33.891403
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = Mock(**{'run_command.return_value': (0, '', '')})
    facts = {
        'sysctl': {
            'kern.osrevision': '15D21',
            'kern.osversion': '15.5.0',
            'hw.memsize': '1610612736',
            'hw.physicalcpu': '4',
            'hw.logicalcpu': '8',
            'hw.ncpu': '8',
            'hw.memsize': '1610612736',
            'machdep.cpu.brand_string': 'Intel',
            'machdep.cpu.core_count': '2',
            },
    }
    darwin_hardware = DarwinHardware(module, facts)


# Generated at 2022-06-20 17:15:35.644263
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware(dict())

# Generated at 2022-06-20 17:15:45.655868
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import pytest
    module = pytest.Mock()
    module.run_command.return_value = (0, output_vm_stat, '')
    module.get_bin_path.return_value = '/usr/bin/vm_stat'
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts == {'memtotal_mb': 8192, 'memfree_mb': 8123}



# Generated at 2022-06-20 17:15:47.428113
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware()
    assert hardware.sysctl == get_sysctl(hardware.module, ['hw', 'machdep', 'kern'])
    assert hardware.platform == 'Darwin'


# Generated at 2022-06-20 17:15:52.323835
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_module = FakeAnsibleModule()
    test_module.run_command = fake_run_command

    test_hardware = DarwinHardware(test_module)
    memory_facts = test_hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-20 17:15:57.025967
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = DarwinHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl['kern.osversion']

# Generated at 2022-06-20 17:16:00.835008
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # create FreeBSDHardware object
    hardware_object = DarwinHardware()
    # call the populate function
    hardware_object.populate()
    
