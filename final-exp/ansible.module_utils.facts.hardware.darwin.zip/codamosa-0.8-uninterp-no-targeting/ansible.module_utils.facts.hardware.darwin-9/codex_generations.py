

# Generated at 2022-06-20 17:07:34.648246
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware(dict())
    hardware.sysctl = {'hw.model': 'MacPro2,1'}
    facts = hardware.get_mac_facts()
    assert facts['osversion'] == '19.6.0'
    assert facts['osrevision'] == 'Darwin Kernel Version 19.6.0: Wed Oct 14 17:44:47 PDT 2020; root:xnu-6153.141.1~1/RELEASE_X86_64'
    assert facts['model'] == 'MacPro2,1'

# Generated at 2022-06-20 17:07:39.001413
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    sut = DarwinHardware(dict())
    assert len(sut.get_system_profile()) > 0

# Generated at 2022-06-20 17:07:48.831670
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = FakeModule()

# Generated at 2022-06-20 17:07:58.986368
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)

    system_profile = {'Memory': '16 GB',
                      'Processor Name': 'Intel Core i5',
                      'Processor Speed': '3.3 GHz',
                      'Serial Number (system)': 'C02STJY8FGWC',
                      'Hardware UUID': '11111111-2222-3333-4444-555555555555'}
    memory_stats = {'Pages wired down': 111,
                    'Pages active': 222,
                    'Pages inactive': 333}


# Generated at 2022-06-20 17:08:10.580525
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = type('', (), {
        'run_command': lambda self, args, **kw: (0, '', ''),
        'get_bin_path': lambda self, name, **kw: '/usr/sbin/vm_stat',
    })()

    module.run_command.__dict__.update({
        'side_effect': lambda *args, **kw: (0, '', ''),
    })

    hardware = DarwinHardware(module)
    hardware.populate()
    assert hardware.platform == 'Darwin'

# Generated at 2022-06-20 17:08:18.736853
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2699 v4 @ 2.20GHz',
                              'machdep.cpu.core_count': '1'}
    assert darwin_hardware.get_cpu_facts() == {'processor': 'Intel(R) Xeon(R) CPU E5-2699 v4 @ 2.20GHz',
                                               'processor_cores': '1',
                                               'processor_vcpus': ''}
    darwin_hardware.sysctl = {'hw.physicalcpu': '1', 'hw.logicalcpu': '2'}
    assert d

# Generated at 2022-06-20 17:08:32.465356
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    # test with below data
    # hw.model: MacBookPro11,1
    # hw.memsize: 17179869184
    # hw.physicalcpu: 2
    # hw.logicalcpu: 4
    # hw.ncpu: 4
    # hw.byteorder: 1234
    # hw.machine: x86_64
    # hw.memsize: 17179869184
    # machdep.cpu.brand_string: Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz
    # machdep.cpu.core_count: 2
    # machdep.cpu.thread_count: 4
    # kern.osversion: 15.3.0


# Generated at 2022-06-20 17:08:39.501148
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.system.darwin import DarwinHardware

    facts = dict()
    darwin_hardware = DarwinHardware(module=None, collected_facts=facts)

    if not hasattr(darwin_hardware, 'get_mac_facts'):
        module.fail_json(msg='get_mac_facts method does not exist')

    return darwin_hardware.get_mac_facts()


# Generated at 2022-06-20 17:08:44.626934
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector(None)
    assert darwin_hw_collector._fact_class == DarwinHardware
    assert darwin_hw_collector._platform == 'Darwin'

# Generated at 2022-06-20 17:08:54.520811
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create an object of class DarwinHardware
    darwinhardware = DarwinHardware(None)
    
    # Get the system profile
    system_profile = darwinhardware.get_system_profile()
    
    # Assert that the values returned are not empty
    assert system_profile
    
    # Assert that the keys are a part of the system_profile
    assert 'Serial Number (system):' and 'Processor Name:' and 'Processor Speed:' in system_profile
    
    # Assert that values corresponding to the keys in system_profile are not empty
    assert system_profile['Serial Number (system):'] and system_profile['Processor Name:'] and system_profile['Processor Speed:']

# Generated at 2022-06-20 17:09:15.908819
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl

    module = Mock()
    module.run_command.return_value = (0, 'Machine Name: x86_64', '')

    darwin = DarwinHardware(module)

    mac_facts = darwin.get_mac_facts()
    assert mac_facts == dict(
        model='x86_64',
        osversion=get_sysctl(module, ['kern', 'osversion']),
        osrevision=get_sysctl(module, ['kern', 'osrevision']),
    )

    cpu_facts = darwin.get_cpu_facts()

# Generated at 2022-06-20 17:09:18.927413
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardwarecollector = DarwinHardwareCollector()
    assert hardwarecollector._platform == 'Darwin'

# Generated at 2022-06-20 17:09:25.327912
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import re
    import os
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl


# Generated at 2022-06-20 17:09:26.232758
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    pass

# Generated at 2022-06-20 17:09:28.425650
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert isinstance(x, HardwareCollector) == True

# Generated at 2022-06-20 17:09:37.348763
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModuleMock({})
    facts = DarwinHardware()
    facts.module = module
    facts.sysctl = {'kern.osversion': '16', 'kern.osrevision': '0'}
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        mac_facts = facts.get_mac_facts()
        assert mac_facts['osversion'] == '16'
        assert mac_facts['osrevision'] == '0'
        assert mac_facts['model'] == out.splitlines()[-1].split()[1]
        assert mac_facts['product_name'] == out.splitlines()[-1].split()[1]
    else:
        assert False



# Generated at 2022-06-20 17:09:48.962644
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mem_total_mb = 16071
    mem_free_mb = 1117
    inactive_memory = 268435456

    bytes_to_mb = 1024 * 1024

# Generated at 2022-06-20 17:10:00.967869
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware(dict(module=None))

# Generated at 2022-06-20 17:10:09.812915
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    output = """
Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro6,1
      Processor Name: Intel Core i7
      Processor Speed: 2.66 GHz
      Number of Processors: 1
      Total Number of Cores: 2
      L2 Cache (per Core): 256 KB
      L3 Cache: 4 MB
      Memory: 8 GB
      Boot ROM Version: MBP61.0057.B0F
      SMC Version (system): 1.58f17
      Serial Number (system): W89391#$3%!
      Hardware UUID: 55555000-7777-8888-9999-AAAAAAAABBBB
"""

    d = DarwinHardware()
    system_profile = d.get_system_profile()

    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile

# Generated at 2022-06-20 17:10:22.536736
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mac_facts_example = """
Hardware:

    Hardware Overview:

      Model Name: Mac mini
      Model Identifier: Macmini6,1
      Processor Name: Intel Core i5
      Processor Speed: 2.5 GHz
      Number of Processors: 1
      Total Number of Cores: 2
      L2 Cache (per Core): 256 KB
      L3 Cache: 3 MB
      Memory: 4 GB
      Boot ROM Version: MM61.0106.B03
      SMC Version (system): 2.11f12
      Serial Number (system): C07JJ0TDDVH5
      Hardware UUID: C528B431-E423-52D0-B212-FF8D227B1AD2
      Sudden Motion Sensor:
      State: Enabled
"""
    module_mock = type('', (), {})()
    hardware_m

# Generated at 2022-06-20 17:10:45.319346
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    collected_facts = {}
    darwin_module = ansible.module_utils.facts.fact_collector.get_module_util('Darwin')
    darwin_module.get_bin_path = lambda x: '/usr/sbin/system_profiler'
    darwin_module.run_command = lambda x: (0, 'Processor Name: Intel Core 2 Duo\nProcessor Speed: 3.00 GHz', '')

    darwin_module.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2680 v3 @ 2.50GHz',
        'machdep.cpu.core_count': 2,
    }
    darwin_hardware = DarwinHardware(darwin_module)

# Generated at 2022-06-20 17:10:50.707840
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(
        argument_spec=dict()
    )
    darwin_hardware = DarwinHardware(module)

    assert 'processor' in darwin_hardware.populate()

# Generated at 2022-06-20 17:10:52.312739
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector.__class__ == DarwinHardwareCollector

# Generated at 2022-06-20 17:11:00.312293
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    import sys
    if sys.version_info[0] == 2:
        test = type('', (), {})()
        test.run_command = run_command
    else:
        test = type('', (), {})
        test.run_command = run_comman
    hardware = DarwinHardware(test)
    hardware.populate()


# Generated at 2022-06-20 17:11:07.781241
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    result_fail = {}
    result_success = {'uptime_seconds': 1524852911}

    # Copy/paste of class DarwinHardware with added method get_uptime_facts_raw_output
    class DarwinHardware_tmp():
        module = None
        sysctl = None

        def __init__(self, module_tmp):
            self.module = module_tmp

        def get_uptime_facts(self):
            return self.get_uptime_facts_raw_output(None)

        def get_uptime_facts_raw_output(self, output_tmp):
            # On Darwin, the default format is annoying to parse.
            # Use -b to get the raw value and decode it.
            sysctl_cmd = self.module.get_bin_path('sysctl')

# Generated at 2022-06-20 17:11:15.531925
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class MyDarwinHardware(DarwinHardware):
        def __init__(self, sysctl):
            self.sysctl = sysctl
    myDarwinHardware = MyDarwinHardware({'kern.osversion': '13.4', 'kern.osrevision': '17E199'})
    mac_facts = myDarwinHardware.get_mac_facts()
    assert mac_facts['osversion'] == '13.4'
    assert mac_facts['osrevision'] == '17E199'



# Generated at 2022-06-20 17:11:29.417408
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test DarwinHardware.get_system_profile()
    """
    # Test missing command
    dm = DarwinHardware(module=None)
    dm.module = MockModule(run_command_return_values=[(1, '', 'IOError')])
    assert {} == dm.get_system_profile()

    # Test missing output
    dm = DarwinHardware(module=None)
    dm.module = MockModule(run_command_return_values=[(0, '', '')])
    assert {} == dm.get_system_profile()

    # Test success
    dm = DarwinHardware(module=None)

# Generated at 2022-06-20 17:11:32.591946
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj = DarwinHardwareCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinHardware


# Generated at 2022-06-20 17:11:40.942121
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    mac_facts = {
        'model': 'Model',
        'osversion': '10.12.6',
        'osrevision': '16G1212',
    }

    expected_description = 'product_name: Model'
    expected_description += '\nosrevision: 16G1212'
    expected_description += '\nosversion: 10.12.6'

    class TestModule(object):
        def __init__(self):
            self.run_command_results = [0, 'Model', '']

        def run_command(self, args):
            return self.run_command_results

    dh = DarwinHardware(TestModule())

    sysctl = {
        'kern.osversion': '10.12.6',
        'kern.osrevision': '16G1212',
    }

   

# Generated at 2022-06-20 17:11:52.651042
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Test for case 1: get current memtotal_mb and memfree_mb of linux machine
    module_args = dict(
        gather_subset=['!all', '!min'],
        filter=['*'],
    )
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        module_args=module_args,
    )
    result = DarwinHardware(module).populate()
    if isinstance(result['ansible_facts']['ansible_memtotal_mb'], int) and \
            isinstance(result['ansible_facts']['ansible_memfree_mb'], int):
        pass
    else:
        raise Exception('get_memory_facts() fails on linux machine')

# Generated at 2022-06-20 17:12:19.980552
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware_obj = DarwinHardware()
    hardware_obj.sysctl = {'kern.osversion': '16.1.0'}

    rc, out, err = hardware_obj.module.run_command("sysctl hw.model")
    rc, out, err = hardware_obj.module.run_command("sysctl hw.model")
    if rc == 0:
        hardware_obj.sysctl['hw.model'] = ' '.join(out.splitlines()[-1].split()[1:])

    rc, out, err = hardware_obj.module.run_command("sysctl kern.osrevision")

# Generated at 2022-06-20 17:12:33.133015
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModuleMock()
    darwin_hw = DarwinHardware(module)
    mock_ansible_module_run_command = module.run_command
    mock_module_run_command = darwin_hw.module.run_command


# Generated at 2022-06-20 17:12:43.980193
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-7567U CPU @ 3.50GHz', 'machdep.cpu.core_count': '2', 'hw.logicalcpu': '4'}
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-7567U CPU @ 3.50GHz'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor_vcpus'] == '4'


# Generated at 2022-06-20 17:12:47.896197
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hardware_facts = DarwinHardware(module).populate()
    assert 'processor' in hardware_facts
    assert 'memtotal_mb' in hardware_facts


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-20 17:13:00.208460
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    cmd_outputs = ['hw.model: iMac14,2\n',
                   'OS X 10.15.1 (19B88)\n',
                   '15.1.0\n']
    module = FakeModule(cmd_outputs)
    d_h = DarwinHardware(module)
    d_h.sysctl = {'kern.osrevision': '15.1.0'}
    results = d_h.get_mac_facts()
    expected_results = {'osrevision': '15.1.0', 'osversion': 'OS X 10.15.1 (19B88)',
                        'model': 'iMac14,2'}
    assert expected_results == results


# Generated at 2022-06-20 17:13:06.114591
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware = DarwinHardware(None)
    mac_facts = hardware.get_mac_facts()
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts
    assert 'model' in mac_facts



# Generated at 2022-06-20 17:13:08.725640
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_facts = DarwinHardware(dict())
    assert hardware_facts.platform == 'Darwin'

# Generated at 2022-06-20 17:13:12.081806
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import doctest
    results = doctest.testmod(DarwinHardware)
    if results.failed != 0:
        module.fail_json(msg='test_DarwinHardware_get_system_profile failed')


# Generated at 2022-06-20 17:13:24.286357
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(
        (0, 'hw.model: x86_64\n', ''),
        (0, '12.5.5\n', ''),
        (0, '15G31\n', ''),
    )
    module.get_bin_path = FakeGetBinPath()

    obj = DarwinHardware(module)
    facts = obj.populate()
    assert facts['model'] == 'x86_64'
    assert facts['osversion'] == '12.5.5'
    assert facts['osrevision'] == '15G31'
    assert facts['memtotal_mb'] == 0


# Generated at 2022-06-20 17:13:34.262012
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.model': 'macmini7,1',
        'kern.osversion': '15.6.0',
        'kern.osrevision': '15G1421',
    }
    facts = hardware.get_mac_facts()
    assert facts == {
        'model': 'macmini7,1',
        'product_name': 'macmini7,1',
        'osversion': '15.6.0',
        'osrevision': '15G1421',
    }



# Generated at 2022-06-20 17:14:16.799619
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    assert DarwinHardware(dict())

# Generated at 2022-06-20 17:14:27.815892
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    d = DarwinHardware(dict(module=None, sysctl=None), 'Darwin')
    
    # test case 1: check return value when sysctl return 0
    d.sysctl = {'kern.boottime': '1000'}
    result = d.get_uptime_facts()
    assert result['uptime_seconds'] == int(time.time() - 1000), 'unexpected uptime_seconds value'

    # test case 2: check return value when sysctl return -1
    d.sysctl = {'kern.boottime': '-1'}
    result = d.get_uptime_facts()
    assert result == {} , 'unexpected returned value'

# Generated at 2022-06-20 17:14:38.228988
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    module = type('module', (object,), dict())
    module.run_command = lambda cmd: (0, 'out', '')
    module.get_bin_path = lambda cmd: cmd

    # sysctl outputs two 64-bits values.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    now = int(time.time())
    kern_boottime = str(now - 7651)
    packed_data = struct.pack(struct_format,
                              int(kern_boottime))
    out = packed_data + ('\x00' * (struct_size - len(packed_data)))

    module.run_command = lambda cmd, encoding=None: (0, out, '')

    d = DarwinHardware(module)

    assert d.get_uptime

# Generated at 2022-06-20 17:14:43.699213
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    ''' test constructor of class DarwinHardwareCollector
    '''
    obj = DarwinHardwareCollector()
    assert obj.platform == 'Darwin'
    assert obj.fact_class == DarwinHardware


# Generated at 2022-06-20 17:14:49.368040
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    t = DarwinHardware()
    rc, out, err = t.module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    assert rc == 0
    assert out
    assert err == ""
    # One line from system_profiler output is:
    # "Model Name: MacBook Pro"
    assert "MacBook Pro" in out

# Generated at 2022-06-20 17:15:01.110289
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_object = DarwinHardware()

    # Test get_cpu_facts
    class MockedSysctl(dict):
        def __init__(self, *args, **kwargs):
            super(MockedSysctl, self).__init__(*args, **kwargs)
            self.__dict__ = self

    mocked_sysctl = MockedSysctl()
    mocked_sysctl.machdep = MockedSysctl()
    mocked_sysctl.machdep.cpu = MockedSysctl()
    mocked_sysctl.machdep.cpu.brand_string = 'Intel(R) Xeon(R) CPU E5-2676 v3 @ 2.40GHz'
    mocked_sysctl.machdep.cpu.core_count = '4'
    mocked_sysctl.hw = MockedSysctl()
    mocked_sysctl

# Generated at 2022-06-20 17:15:08.894932
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware = DarwinHardware()
    hardware.sysctl = {'kern.osversion': '0', 'kern.osrevision': '1'}
    rc, out, err = hardware.module.run_command("sysctl hw.model")
    hardware.sysctl['hw.model'] = out.splitlines()[-1].split()[1]
    assert hardware.get_mac_facts() == {'osversion': '0', 'osrevision': '1', 'model': hardware.sysctl['hw.model']}


# Generated at 2022-06-20 17:15:21.793399
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()
    hardware = DarwinHardware(module=module)
    module.run_command.return_value = (0, 'hw.model: MacBookPro13,1\nhw.memsize: 17179869184\nmachdep.cpu.feature_bits: 0x000000003EBD3BFF\nmachdep.cpu.core_count: 4\nmachdep.cpu.core_count: 4\nkern.osversion: 17.7.0\nkern.osrevision: 15102800\nkern.boottime: { sec = 1533353929, usec = 851680 }\n', [])
    module.get_bin_path.return_value = 'vm_stat'

# Generated at 2022-06-20 17:15:33.739719
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule(object):
        class RunCommandError(Exception):
            def __init__(self, rc, out, err):
                self._rc = rc
                self._out = out
                self._err = err

        def __init__(self, rc, out, err):
            self._rc = rc
            self._out = out
            self._err = err

        def get_bin_path(self, binary, opt_dirs=None, required=False):
            return binary

        def run_command(self, cmd, encoding=None):
            return self._rc, self._out, self._err


# Generated at 2022-06-20 17:15:45.020749
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockAnsibleModule()
    module.run_command.return_value = (0, ' i386', '')
    hardware = DarwinHardware(module=module)
    module.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Core(TM)2 Duo CPU     T7700  @ 2.40GHz'
    module.sysctl['machdep.cpu.core_count'] = 2

    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM)2 Duo CPU     T7700  @ 2.40GHz'
    assert cpu_facts['processor_cores'] == 2

    module.run_command.return_value = (0, 'PowerPC G5', '')
    hardware = DarwinHardware(module=module)
    module