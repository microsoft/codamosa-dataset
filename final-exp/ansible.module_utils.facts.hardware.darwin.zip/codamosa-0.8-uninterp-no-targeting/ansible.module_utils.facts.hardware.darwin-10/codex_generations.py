

# Generated at 2022-06-20 17:07:35.109672
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-20 17:07:47.957690
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-20 17:07:53.921958
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    mac_facts = DarwinHardware(dict()).get_cpu_facts()
    assert isinstance(mac_facts['processor_cores'], int)
    assert isinstance(mac_facts['processor_vcpus'], str)
    assert mac_facts['processor_vcpus'] == '' or isinstance(int(mac_facts['processor_vcpus']), int)
    assert mac_facts['processor'] != ''

# Generated at 2022-06-20 17:08:02.422425
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    target = DarwinHardware(module)
    memory = target.get_memory_facts()
    cpu = target.get_cpu_facts()
    mac = target.get_mac_facts()
    sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    total_used = 0
    page_size = 4096

    rc, out, err = module.run_command("vm_stat")
    if rc == 0:
        memory_stats = (line.rstrip('.').split(':', 1) for line in out.splitlines())

        # Strip extra left spaces from the value
        memory_stats = dict((k, v.lstrip()) for k, v in memory_stats)


# Generated at 2022-06-20 17:08:11.872473
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.process import get_bin_path
    import ansible.module_utils.facts.hardware.darwin

    module = AnsibleModule(argument_spec=dict())
    try:
        vm_stat_command = get_bin_path('vm_stat')
    except ValueError:
        return

# Generated at 2022-06-20 17:08:15.189401
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    mockapi = MockLinuxHardwareModuleAPI()
    mockapi.sysctl = {'kern.boottime': '1513828827'}

    darwin = DarwinHardware(mockapi)
    uptime_facts = darwin.get_uptime_facts()

    assert 'uptime_seconds' in uptime_facts.keys()
    assert uptime_facts['uptime_seconds'] == 1513828827

# Generated at 2022-06-20 17:08:20.968539
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import tempfile
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    hardware = DarwinHardware(module)
    # return value is timestamp of the boot
    boot_time = hardware.get_uptime_facts()['uptime_seconds']
    actual_time = int(time.time())
    if (actual_time - boot_time) < 0 or (actual_time - boot_time) > 300:
        raise Exception('Boot time %s is not close enough to actual time %s' % (boot_time, actual_time))

# Generated at 2022-06-20 17:08:33.243967
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, Mock

    mock_module = Mock()

# Generated at 2022-06-20 17:08:39.049504
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Arrange
    mac_facts = dict()
    module = AnsibleModuleStub()

    # Act
    hardware = DarwinHardware(module)
    mac_facts = hardware.get_mac_facts()

    # Assert
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts
    assert 'model' in mac_facts


# Generated at 2022-06-20 17:08:41.840285
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware_inst = DarwinHardware(dict())

    assert hardware_inst is not None

# Generated at 2022-06-20 17:09:03.390628
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import json
    json_data = '''{
        "Serial Number (system)": "Test-SN",
        "Model Name": "MacBook Pro",
        "Processor Name": "Intel Core 2 Duo",
        "Processor Speed": "2.4 GHz",
        "Number of Processors": "1",
        "Total Number of Cores": "2",
        "L2 Cache (per Core)": "3 MB",
        "L3 Cache": "6 MB",
        "Memory": "4 GB",
        "Boot ROM Version": "Test-ROM-Version",
        "SMC Version (system)": "Test-SMC-Version"
    }'''
    dh = DarwinHardware()
    dh.module.run_command = lambda args: (0, json.dumps(json.loads(json_data)), '')

# Generated at 2022-06-20 17:09:13.013649
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule()
    h = DarwinHardware(module)
    module.run_command.return_value = 0, 'hw.model: MacBookPro5,5', None
    rc, out, err = module.run_command("sysctl hw.model")
    assert rc == 0
    assert out == 'hw.model: MacBookPro5,5'
    assert err is None
    h.get_mac_facts()
    module.run_command.assert_called_with("sysctl hw.model")
    del h


# Generated at 2022-06-20 17:09:16.967008
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    This test case checks the correct behavior of the method get_memory_facts of the class DarwinHardware.
    """
    import sys
    if sys.version_info[0] == 3:
        # Python3 is picky about asserting the types of variables
        # pylint: disable=unidiomatic-typecheck
        assert type(DarwinHardware.get_memory_facts(DarwinHardware())) == dict

# Generated at 2022-06-20 17:09:23.309582
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    hardware = DarwinHardware('module')
    assert 'darwin' in hardware.distribution
    assert 'model' in hardware.distribution
    assert 'system' in hardware.distribution
    assert 'release' in hardware.distribution
    assert 'version' in hardware.distribution



# Generated at 2022-06-20 17:09:36.059024
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-20 17:09:48.486536
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class ModuleStub(object):
        def __init__(self):
            self.results = []
        def run_command(self, cmd):
            self.results.append({
                'cmd': cmd,
                'out': 'hw.model: Intel(R) Xeon(R) CPU E3-1275 V3 @ 3.50GHz',
                'rc': 0,
                'err': '',
            })
        def get_bin_path(self, name):
            return name
    class DarwinHardwareStub(DarwinHardware):
        def __init__(self, module):
            self.module = module
            self.sysctl = {
                'kern.osversion': '15.6.0',
                'kern.osrevision': '19G2021',
            }
    stub_module = ModuleStub()

# Generated at 2022-06-20 17:10:00.812208
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.facts import ModuleStub

    # Create a stub for the ansible module
    module = ModuleStub()

    # Create the string representation of vm_stat command output

# Generated at 2022-06-20 17:10:08.506886
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class WindowsHardware
    """

    module = AnsibleModule(argument_spec={})

    m = module.params
    X = DarwinHardware(module)
    d = X.get_memory_facts()

    assert d["memtotal_mb"] > 0
    assert d["memfree_mb"] > 0
    assert d["memtotal_mb"] >= d["memfree_mb"]

# Generated at 2022-06-20 17:10:15.063235
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = MagicMock()
    hardware = DarwinHardware(module)
    hardware.get_system_profile()
    module.run_command.assert_called_once_with(['/usr/sbin/system_profiler', 'SPHardwareDataType'])


# Generated at 2022-06-20 17:10:20.400534
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    hardware_facts = DarwinHardware(module).populate()

    # Check some basics
    assert hardware_facts['system'] == 'Darwin'

    # Check that the facts are integer values
    #
    # Note that we don't check 'processor_cores', as it is not mandatory
    # that a hardware platform has this fact available.
    int_facts = ['uptime_seconds']
    if 'processor_vcpus' in hardware_facts:
        int_facts.append('processor_vcpus')
    for fact in int_facts:
         assert isinstance(hardware_facts[fact], int)

    # Check that we have the memory facts
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] >= 0

    # Check that we have the

# Generated at 2022-06-20 17:10:46.714158
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import os
    import sys
    import unittest

    # Mock up ansible module
    class AnsibleModule(object):
        def __init__(self):
            self.params = dict()
        def run_command(self, cmd, encoding=None):
            return 0, os.urandom(8), ''
        def get_bin_path(self, cmd):
            return cmd
        def fail_json(self, **kwargs):
            raise AssertionError(str(kwargs))
        def log(self, message):
            sys.stderr.write(str(message))
        def debug(self, message):
            sys.stderr.write(str(message))

    # Create mock object
    am = AnsibleModule()

    # Test the uptime facts
    af = DarwinHardware(am)

# Generated at 2022-06-20 17:10:50.477292
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    assert 'Darwin' == hardware.platform

# Generated at 2022-06-20 17:10:52.516178
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    my_test_hw_obj=DarwinHardware()
    assert my_test_hw_obj.platform == 'Darwin'

# Generated at 2022-06-20 17:11:01.110137
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule({})
    darwin = DarwinHardware(module)
    darwin.sysctl = {'hw.memsize': '2147483648'}
    darwin.get_memory_facts()

    assert darwin.memory['memtotal_mb'] == 2048
    assert darwin.memory['memfree_mb'] == 0

# Generated at 2022-06-20 17:11:10.966306
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    class TestModule(object):
        def __init__(self, distro=None, platform=None):
            self.run_command = mock.Mock()
            self.params = {'gather_subset': ('!all', '!min')}

            self.facts = {'distribution': distro}
            self.collector = Collector(module=self)
            self.collector.collect_platform_facts()

            self.distro_collector = DistributionFactCollector(module=self)
            self.distro_

# Generated at 2022-06-20 17:11:19.685533
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module_mock = type('module', (), {'run_command': lambda self, command: (0, '', '')})
    darwin_cpu_facts = DarwinHardware(module_mock)
    darwin_cpu_facts.sysctl = {
        'kern.osversion': '16.6.0',
        'kern.osrevision': '1510',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-5960X CPU @ 3.00GHz',
        'machdep.cpu.core_count': '8',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
        'hw.ncpu': '4',
    }

    cpu_facts = darwin_cpu_facts.get_cpu_facts

# Generated at 2022-06-20 17:11:25.463274
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    h = DarwinHardware({"module": None})
    # The test will fail if this doesn't find the binary.
    assert '/usr/sbin/system_profiler' == h.get_system_profile().get("system_profiler", '')

# Generated at 2022-06-20 17:11:39.032927
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    class MockModule(object):
        module_utils = {
            'common': {
                'process': {
                    'get_bin_path': get_bin_path,
                }
            },
            'facts': {
                'sysctl': get_sysctl,
            }
        }

        def run_command(self, cmd):
            if cmd[0] == '/usr/sbin/system_profiler':
                return 0, "".join(["System Version: macOS 10.14.1 (18B75)\n",
                                   "    Kernel Version: Darwin 18.2.0\n",
                                   "    System Model Name: MacBookPro11,5\n"]), ''

# Generated at 2022-06-20 17:11:48.216201
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule:
        def get_bin_path(self, cmd, **kwargs):
            return ''
        def run_command(self, cmd, encoding=None):
            return 0, struct.pack('@L', 1234), 'stderr'

    module = MockModule()
    obj = DarwinHardware(module=module)
    obj.populate_facts()
    assert obj.facts['uptime_seconds'] == int(time.time()) - 1234

# Generated at 2022-06-20 17:11:54.989432
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import mock
    import datetime

    module = mock.Mock()
    module.get_bin_path.return_value = '/usr/bin/sysctl'
    module.run_command.return_value = (0, """
    kern.boottime = { sec = 1424805198, usec = 0 }
    """, '')

    harware = DarwinHardware(module)
    result = harware.get_uptime_facts()

    # mock the current time()
    datetimeobj = datetime.datetime(2015, 2, 18, 23, 1, 39)
    with mock.patch.object(datetime, 'datetime',
                           mock.Mock(wraps=datetime.datetime)) as mock_datetime:
        mock_datetime.utcnow.return_value = datetimeobj

# Generated at 2022-06-20 17:12:17.739174
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    fact = DarwinHardwareCollector(dict())
    assert fact.platform == 'Darwin'
    assert fact.get_platform() == 'Darwin'
    assert fact.get_fact_class() == DarwinHardware

# Generated at 2022-06-20 17:12:27.290468
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # see 'sysctl -a hw' for list of possible results
    m = basic.AnsibleModule(argument_spec=dict())
    m.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i3-2100 CPU @ 3.10GHz'}
    m.run_command.return_value = (0, to_bytes('hw.memsize: 4294967296'), None)
    h = DarwinHardware(m)
    # cpu_facts is a dictionary
    cpu_facts = h.get_cpu_facts()
    # check cpu_facts is expected

# Generated at 2022-06-20 17:12:35.831267
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # pylint: disable=no-member
    import mock
    import module_utils.facts.hardware.darwin as darwin_utils

    # Mock the results of get_bin_path and run_command
    class Results():
        def __init__(self, rc=None, out=None, err=None):
            self.rc = rc or 0
            self.out = out
            self.err = err

        def __iter__(self):
            yield self.rc
            yield self.out
            yield self.err
    mock_bin_path = mock.Mock(return_value='/usr/sbin/sysctl')
    mock_run_command = mock.Mock(return_value=Results(out=b'kern.boottime = 12345\n'))

    # Replace the 'module' and 'get

# Generated at 2022-06-20 17:12:45.912699
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils._text import to_bytes
    import contextlib


# Generated at 2022-06-20 17:12:51.055245
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = FakeAnsibleModule()
    fake_output = b'\0\0\0\0\0U\x08\0\0'
    module.run_command.return_value = (0, fake_output, b'')

    hardware = DarwinHardware(module, FakeDistribution(), '', {})
    assert hardware.get_uptime_facts() == {'uptime_seconds': 510}



# Generated at 2022-06-20 17:13:02.508642
# Unit test for method get_uptime_facts of class DarwinHardware

# Generated at 2022-06-20 17:13:12.048636
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Arrange
    sysctl_mock = Mock()
    sysctl_mock.return_value = 1234567890, b'\x00\x00\x00\x00\x00\x00\x00\x00'

    with patch.object(DarwinHardware, 'get_sysctl', sysctl_mock):
        module_mock = Mock()
        instance = DarwinHardware(module_mock)

        # Act
        actual = instance.get_uptime_facts()

        # Assert
        assert actual == {'uptime_seconds': 1234.56789}

# Generated at 2022-06-20 17:13:25.126248
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = {'kern.osversion': '16.7.0'}

    hardware.sysctl={
        'machdep.cpu.core_count': '2',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz',
        'hw.logicalcpu': '4',
        'hw.cpufrequency': '2800000000',
        'hw.physicalcpu': '1'
    }
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz'
    assert cpu_facts['processor_cores']

# Generated at 2022-06-20 17:13:36.077867
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils._text import to_bytes
    import sys

    class FakeModule:
        """Fake module for testing."""
        def __init__(self):
            self.params = {}
            self.run_command_result = {
                'rc': 0,
                'out': b'',
                'err': b'',
            }

        def run_command(self, cmd):
            # Replace : with . in the key when returning a sysctl value so
            # we can do a simple match on the key.
            out = b''
            for key, value in sysctl.items():
                out += to_bytes("%s: %s\n" % (key.replace(':', '.'), value), encoding='utf-8')
            self.run_command_result['out'] = out

# Generated at 2022-06-20 17:13:39.018865
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    dh = DarwinHardware()
    results = dh.get_system_profile()
    assert isinstance(results, dict)
    assert results['Model Identifier'] == 'x86_64'
    assert results['Boot ROM Version'] == '1037.120.108'
    assert results['Serial Number (system)'] == 'C02PP8SLG8WC'

# Generated at 2022-06-20 17:14:28.346782
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import mock

    hw = DarwinHardware()
    with mock.patch.object(hw, 'get_memory_facts') as mock_get_memory_facts, \
            mock.patch.object(hw, 'get_mac_facts') as mock_get_mac_facts, \
            mock.patch.object(hw, 'get_cpu_facts') as mock_get_cpu_facts, \
            mock.patch.object(hw, 'get_uptime_facts') as mock_get_uptime_facts:
        mock_get_memory_facts.return_value = {}
        mock_get_mac_facts.return_value = {}
        mock_get_cpu_facts.return_value = {}
        mock_get_uptime_facts.return_value = {}
        hw.populate({})
        assert mock_get_memory

# Generated at 2022-06-20 17:14:37.988662
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mac_facts = {'osrevision': '19103', 'model': 'MacBookPro11,4', 'osversion': '15.4.0'}
    tmp_module = FakeModule({'hw.model': 'MacBookPro11,4', 'kern.osversion': '15.4.0', 'kern.osrevision': '19103'})
    Darwin_hw = DarwinHardware(tmp_module)
    assert Darwin_hw.get_mac_facts() == mac_facts
    tmp_module = FakeModule({})
    Darwin_hw = DarwinHardware(tmp_module)
    assert Darwin_hw.get_mac_facts() == {'osversion': '', 'osrevision': '', 'model': ''}



# Generated at 2022-06-20 17:14:50.798844
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = DummyAnsibleModule()
    hardware = DarwinHardware(module)


# Generated at 2022-06-20 17:14:54.174733
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = type('', (object,), dict(fail_json=lambda x: None))()
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['memfree_mb'] == 14336

# Generated at 2022-06-20 17:14:56.844916
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    a = DarwinHardwareCollector()
    assert isinstance(a.collect(), dict)


# Generated at 2022-06-20 17:15:04.918213
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, encoding=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    def test(expected_result, run_command_result_code, run_command_result_stdout):
        module = TestModule()

        module.run_command_results = [
            (run_command_result_code, run_command_result_stdout, "")
        ]

        hardware = DarwinHardware(module=module)
        result = hardware.get_system_profile()

        assert result == expected_result

    test({}, 0, "")

# Generated at 2022-06-20 17:15:10.063368
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware = DarwinHardware(dict())
    facts = hardware.populate()
    assert facts['model'] == 'MacBook2,1'
    assert facts['processor_cores'] == '4'
    assert facts['processor'] == 'Intel(R) Core(TM)2 Duo CPU     L7500  @ 1.60GHz'
    assert facts['memtotal_mb'] == 2048
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '15600000'

# Generated at 2022-06-20 17:15:22.098797
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import sys
    import pytest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    argv = ['']
    argv[0] = pytest.python
    sys.argv = argv
    test = DarwinHardware("testmodule")
    test.sysctl = {'hw.memsize': 268435456}
    test.get_memory_facts()
    test.module.run_command = lambda *_: (0, 'Pages wired down:  1662396\nPages active:     3898352\nPages inactive:   2357008\n', '')
    memory_stats = test.get_memory_facts()
    assert memory_stats['memtotal_mb'] == 256
    assert memory_stats['memfree_mb'] == 87

# Generated at 2022-06-20 17:15:33.872046
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time

    import pytest

    class Args(object):
        def __init__(self, bin_path_to_mock=None, return_value_to_mock=None):
            self.bin_path_to_mock = bin_path_to_mock
            self.return_value_to_mock = return_value_to_mock

    class MockResponse(object):
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err


# Generated at 2022-06-20 17:15:45.085166
# Unit test for constructor of class DarwinHardware
def test_DarwinHardware():
    har = DarwinHardware({'module_setup': True}, None)
    # Assert that the dictionary returned from populate() is the same as the
    # dictionary defined below.
    mac_facts = {'model': 'MacBookPro11,4', 'osversion': '15.2.0', 'osrevision': '20160310'}
    cpu_facts = {'processor': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
                 'processor_cores': '4', 'processor_vcpus': '8'}
    memory_facts = {'memtotal_mb': 16384, 'memfree_mb': 8217}
    uptime_facts = {'uptime_seconds': 143910}
    
    facts = {'ansible_facts': {'hardware': mac_facts}}
