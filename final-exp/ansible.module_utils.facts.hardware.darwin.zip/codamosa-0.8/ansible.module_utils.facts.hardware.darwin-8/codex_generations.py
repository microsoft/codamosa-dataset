

# Generated at 2022-06-11 02:22:27.083567
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class Module:
        def __init__(self):
            self.run_command = run_command

    out = '''
Pages free:                             10040.
Pages wired down:                       14600.
Pages active:                           25278.
Pages inactive:                         10033.
Pages speculative:                      57539.
Pages throttled:                             0.
Pages filebacked:                            0.
Pages purgeable:                          1277.
'''
    hardware = DarwinHardware()
    hardware.module = Module()
    hardware.sysctl = dict()
    hardware.sysctl['hw.memsize'] = '8589934592'
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 8192
    assert memory_facts['memfree_mb'] == 973


# Generated at 2022-06-11 02:22:37.200494
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MagicMock()

    class DarwinHw(DarwinHardware):
        def __init__(self, module):
            self.sysctl = {'kern.osversion': '16.5.0',
                           'hw.memsize': '16777216',
                           'kern.osrevision': '151665',
                           'machdep.cpu.core_count': '8',
                           'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz'}

    test_hw = DarwinHw(module)

    cpu_facts = test_hw.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz'
   

# Generated at 2022-06-11 02:22:49.051020
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModuleFake()
    hardware = DarwinHardware(module)

    sysctl = {
        'hw.model': 'iMac14,2',
        'hw.physicalcpu': 4,
        'kern.osversion': '15.6.0',
        'kern.osrevision': '22',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4570R CPU @ 2.70GHz',
        'machdep.cpu.core_count': 4,
    }
    hardware.get_sysctl = Mock(return_value=sysctl)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == sysctl['machdep.cpu.brand_string']
    assert cpu_facts['processor_cores'] == sysctl

# Generated at 2022-06-11 02:22:54.153237
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.command import Cmd
    from ansible.module_utils.common.process import module_args_argument_spec


# Generated at 2022-06-11 02:23:03.434455
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import pytest

# Generated at 2022-06-11 02:23:06.517147
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == "Darwin"
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-11 02:23:12.238509
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    # Test for mac_facts after successful execution
    mac_facts = {
        'osversion': '19.4.0',
        'osrevision': '15E65',
        'model': 'MacBookPro15,1',
    }
    assert DarwinHardware().get_mac_facts() == mac_facts



# Generated at 2022-06-11 02:23:20.249224
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    Unit test for the get_memory_facts method of class DarwinHardware
    """
    import sys
    import os
    import unittest


# Generated at 2022-06-11 02:23:30.259253
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeModule()
    # Test for Intel
    module.run_command.return_value = 0, "hw.model: Intel(R) Core(TM) i5-5350U CPU @ 1.80GHz", ''

    fact = DarwinHardware(module)
    assert fact.get_cpu_facts() == {'processor': 'Intel(R) Core(TM) i5-5350U CPU @ 1.80GHz',
                                    'processor_cores': '2',
                                    'processor_vcpus': '2'}

    # Test PowerPC
    module.run_command.return_value = 0, "hw.model: PowerMac1,1", ''
    system_profile = {'Processor Name': 'PowerPC G5', 'Processor Speed': '2.5 GHz'}

# Generated at 2022-06-11 02:23:39.725682
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # ModuleFixture requires packages provided by Python's standard library,
    # thus we can use it without any requirement on Ansible.
    from ansible.module_utils.basic import ModuleFixture
    m = ModuleFixture(argument_spec={})

    # Create a stub for the method run_command that simulates the output of
    # the sysctl command.
    m.run_command.side_effect = [
        (0, b'Tue Jan  5 08:53:41 2016', None),  # command output
    ]
    hardware = DarwinHardware(m)
    facts = hardware.get_uptime_facts()
    assert facts['uptime_seconds'] == 1452022221 - 1451991221

# Generated at 2022-06-11 02:24:00.274147
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'
    assert facts['processor_cores'] == '1'
    assert facts['processor_vcpus'] == '2'
    assert facts['memtotal_mb'] == '8192'
    assert facts['memfree_mb'] == '4091'
    assert facts['model'] == 'MacBookAir7,2'
    assert facts['osversion'] == '19E287'
    assert facts['osrevision'] == '19E266'
    assert facts['uptime_seconds'] == '1026'


# Generated at 2022-06-11 02:24:10.282619
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class Options:
        def __init__(self):
            self.module = None

    class FakeModule:
        def __init__(self, options):
            self.options = options


# Generated at 2022-06-11 02:24:20.703978
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = namedtuple("Module", ["run_command"])
    sysctl = {'hw.physicalcpu': 4, 'hw.logicalcpu': 4, 'hw.ncpu': 4}
    sysctl_command = module.run_command = namedtuple("RunCommandResult", ["stdout", "stderr", "rc"])
    sysctl_command.stdout = "\n".join(["%s: %s" % (key, value) for key, value in sysctl.items()])
    sysctl_command.stderr = ""
    sysctl_command.rc = 0


# Generated at 2022-06-11 02:24:24.711591
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class TestModule(object):
        @staticmethod
        def run_command(cmd, **kwargs):
            return 0, "hw.model: MacBookPro12,1\n", ""

    hardware_facts = DarwinHardware(TestModule()).populate()
    assert hardware_facts['model'] == "MacBookPro12,1"
    assert hardware_facts['osversion']
    assert hardware_facts['osrevision']


# Generated at 2022-06-11 02:24:33.424924
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import random
    import unittest.mock as mock

    sysctl_cmd = '/bin/sysctl'
    # Set up a mock DarwinHardware object
    module = mock.Mock()
    module.run_command = mock.Mock()
    module.get_bin_path = mock.Mock(return_value=sysctl_cmd)

    dh = DarwinHardware(module)

    # Generate a random time as the value of kern_boottime
    kern_boottime = random.random()

    # sysctl_cmd -b kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)

# Generated at 2022-06-11 02:24:38.868042
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class FakeModule(object):
        def run_command(self, cmd):
            return 0, '''
Hardware Overview:
Model Name: MacBook
Model Identifier: MacBook1,1
Processor Name: Intel Core Duo
Processor Speed: 2 GHz
Number Of Processors: 1
Total Number Of Cores: 2
L2 Cache: 4 MB
Memory: 1 GB

''', ''

    class FakeSysctl(object):
        def __init__(self):
            self.sysctl = dict()

        def get_sysctl(self, names):
            return self.sysctl

    class FakeDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    mac_hw = FakeDarwinHardware(FakeModule())
    mac_sysctl = FakeSysctl()
    mac_hw.get_

# Generated at 2022-06-11 02:24:48.451322
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware


# Generated at 2022-06-11 02:24:53.429673
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    power_hardware = DarwinHardware(dict())
    power_hardware.module.fail_json = lambda *args, **kw: None
    power_hardware.module.run_command = lambda x, encoding=None: (0, '0\n', '')
    assert isinstance(power_hardware.get_uptime_facts(), dict)

# Generated at 2022-06-11 02:25:03.001039
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Create a new instance of the DarwinHardwareCollector class
    darwin_hardware = DarwinHardwareCollector()

    # Create a mock AnsibleModule object
    mock_module = MagicMock()

    # Create a mock AnsibleModule object
    mock_module = MagicMock()

    # Create a mock Facts object
    mock_facts = Facts()

    # Set the facts member variable of the mock_facts object to an empty
    # dictionary.
    mock_facts.facts = {}

    # Set the _ansible_version member variable of a mock AnsibleModule object
    # to 2.3.0.0
    mock_module.ansible_version = '2.3.0.0'

    # Run the populate() method of the DarwinHardwareCollector class.  This
    # method should call the populate() method of the DarwinHardware class. 

# Generated at 2022-06-11 02:25:13.607737
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class MockModule():
        def __init__(self):
            self.run_command_results = []

        def run_command(self, command):
            return self.run_command_results.pop(0)

    module = MockModule()

    # Create a mock vm_stat command that returns the following output:
    # $ vm_stat
    # Mach Virtual Memory Statistics: (page size of 4096 bytes)
    # Pages free:                             99561.
    # Pages active:                          146612.
    # Pages inactive:                          6801.
    # Pages speculative:                        632.
    # Pages copied-on-write:                 452078.
    # Pages zero filled:                     131858.
    # Pages reactivated:                      15984.
    # Pages purged:                              10.
    # File-backed pages:

# Generated at 2022-06-11 02:25:39.217992
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert isinstance(d._fact_class(dict()), DarwinHardware)
    assert d._platform == 'Darwin'

# Generated at 2022-06-11 02:25:46.587659
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # We can't test this on other platforms because it requires sysctl
    import pytest

    if not pytest.helpers.is_darwin():
        pytest.skip('Test only available on Darwin')

    # To keep it simple, we'll use the fact module to get the system boottime
    # and compare this to the time in the uptime_facts
    from ansible.module_utils.facts.system.base import DarwinSystem
    from ansible.module_utils.facts import system
    from ansible.module_utils.basic import AnsibleModule

    system_fact = system.System(AnsibleModule(None), None).populate()
    boottime_fact = DarwinHardware(AnsibleModule(None), None).get_uptime_facts()['uptime_seconds']

    # sysctl -b kern.boottime returns seconds and micro

# Generated at 2022-06-11 02:25:55.557168
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MagicMock()
    hw = DarwinHardware(module)
    hw.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz',
        'machdep.cpu.core_count': 2
    }
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor_vcpus'] == ''
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz'



# Generated at 2022-06-11 02:26:05.735408
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils._text import to_native
    import re
    import sys

    # Mock AnsibleModule class
    class MockAnsibleModule:
        def __init__(self):
            sys.modules['ansible.module_utils.common.process'] = MockProcess()
            self.module = sys.modules['ansible.module_utils.common.process']
            self.fail_json = lambda: sys.exit(1)  # pylint: disable=unnecessary-lambda

        def run_command(self, cmd):
            return 0, '', ''

    # Mock Process class
    class MockProcess:
        def get_bin_path(self, name, required=False):
            return 'vm_stat'

    # Mock the return value of subprocess.check_output
    sys.modules['subprocess'].check

# Generated at 2022-06-11 02:26:15.137454
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    def f(*x):
        pass

    # Python3: Use mock.patch.object(), Python2: Use mock.patch()
    try:
        import unittest.mock as mock
        m = mock.mock_module.Mock(run_command=f)
        with mock.patch.object(DarwinHardware, 'module', m):
            d = DarwinHardware()
            assert d.get_uptime_facts() == {}
    except ImportError:
        from mock import Mock, patch
        m = Mock(run_command=f)
        with patch.object(DarwinHardware, 'module', m):
            d = DarwinHardware()
            assert d.get_uptime_facts() == {}

# Generated at 2022-06-11 02:26:27.861819
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import ansible.module_utils.facts.hardware.darwin as darwin
    module = Mock()
    module.run_command = Mock()
    module.get_bin_path = Mock()
    # Test get_mac_facts
    module.run_command.side_effect = [
        (0, 'hw.model: MacBookPro12,1', ''),
        (0, '15F34', ''),
        (0, '15.3.0', ''),
    ]
    dhw = darwin.DarwinHardware(module)()
    assert dhw['model'] == 'MacBookPro12,1'
    assert dhw['osversion'] == '15F34'
    assert dhw['osrevision'] == '15.3.0'
    # Test get_cpu_facts
    module.run_command

# Generated at 2022-06-11 02:26:30.878447
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw = DarwinHardwareCollector()
    assert darwin_hw._fact_class == DarwinHardware
    assert darwin_hw._platform == 'Darwin'

# Generated at 2022-06-11 02:26:39.671003
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    module.run_command = MagicMock(return_value=(0, "", ""))
    har = DarwinHardware(module)

    result = har.populate()
    assert 'osrevision' in result
    assert 'osversion' in result
    assert 'processor_cores' in result
    assert 'processor_vcpus' in result
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'model' in result
    assert result['uptime_seconds'] > 0

# Generated at 2022-06-11 02:26:50.226654
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Test on Darwin.
    import platform
    import unittest
    import tempfile

    # Initialize mock data.
    mock_command_intput = b'\x00\x00\x00\x00\x00\n\xcf\xaa\x00\x00\x00\x00'
    mock_time_intput = 1547378035

    def _open_mock_file(*args, **kwargs):
        """
        Mock open() to return a mock file-like object with the content of the
        mock input.
        """
        return tempfile.TemporaryFile(mode='w+b', *args, **kwargs)


# Generated at 2022-06-11 02:26:57.294340
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    mac_facts = hardware.get_mac_facts()

    assert(mac_facts['osversion'].startswith('Darwin Kernel Version '))
    assert(mac_facts['osrevision'] != '')
    assert(mac_facts['model'] in ['iMac', 'iMacPro', 'MacBookPro', 'MacPro', 'Macmini', 'MacBookAir', 'MacBook'])


# Generated at 2022-06-11 02:27:45.508336
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_module = 'test_module'

# Generated at 2022-06-11 02:27:53.923921
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    This method tests DarwinHardware.get_mac_facts()
    """

    # Create an instance of class DarwinHardware
    d = DarwinHardware()

    # Set the module to 'mocked'
    d.module = type('', (), {})()
    d.module.run_command = lambda x, y: (0, "hw.model: MacPro4,1\nhw.memsize: 167772150", "")

    # get_mac_facts() should return facts
    assert d.get_mac_facts() == {'model': 'MacPro4,1', 'osversion': '', 'osrevision': ''}


# Generated at 2022-06-11 02:27:55.962601
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # No check, we only want to decode a raw 64-bits value.
    DarwinHardware._get_uptime_facts(None)

# Generated at 2022-06-11 02:28:06.684063
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """Test stub for utlizing mock objects
    in testing of module_utils/facts/hardware/darwin.py
    """
    import datetime
    import mock
    import tempfile

    module = mock.Mock()
    module.run_command.return_value = (0, 'user  70563        0.0  0.0  2556096    776   0.0  0:00.01 ttys001    0:00.03 /usr/libexec/login -pf daemondo', '')
    module.get_bin_path.return_value = '/bin/ls'
    # Set up an instance of DarwinHardware to test
    darwin_hardware = DarwinHardware(module)

    # Set the return values from get_sysctl to mock data

# Generated at 2022-06-11 02:28:13.810508
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    DarwinHardware_get_mac_facts()
    """
    a = DarwinHardware()

    a.sysctl = {}
    a.sysctl['kern.osversion'] = '15.6.0'
    a.sysctl['kern.osrevision'] = '20200605'

    a.get_system_profile = lambda: {'Processor Name': 'Intel Core i5', 'Processor Speed': '3.3 GHz'}
    a.module.run_command = lambda command: (0, 'hw.model: MacBookPro11,3\n', '')

    result = a.get_mac_facts()
    assert result['model'] == 'MacBookPro11,3'
    assert result['product_name'] == 'MacBookPro11,3'

# Generated at 2022-06-11 02:28:25.269726
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec={}
    )

    mocked_sysctl = {
        'hw.model': 'MacPro5,1',
        'hw.memsize': '536543232',
        'hw.ncpu': '8',
        'hw.physicalcpu': '4',
        'kern.osrevision': '150000',
        'kern.osversion': '19D76',
        'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU W3550  @ 3.07GHz',
        'machdep.cpu.core_count': '4'
    }

    def mock_sysctl(module, keys):
        return dict((k, mocked_sysctl[k]) for k in keys)


# Generated at 2022-06-11 02:28:32.400938
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Arrange
    module = AnsibleModule(argument_spec={})
    mac = DarwinHardware(module)

    # Act
    mac_facts = mac.get_mac_facts()

    # Assert
    osversion = mac.sysctl['kern.osversion']
    osrevision = mac.sysctl['kern.osrevision']
    assert mac_facts['osversion'] == osversion
    assert mac_facts['osrevision'] == osrevision



# Generated at 2022-06-11 02:28:40.903961
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import ansible.module_utils.facts.hardware.darwin as darwin

    # Unit test cannot rely on external files, so we mock sysctl function in
    # this module.
    darwin.get_sysctl = lambda module, sysctls: {
        'hw.memsize': 1048576000,
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 4
    }

    module = MockModule()

    darwin_hardware = darwin.DarwinHardware(module)

    total_used = 0
    page_size = 4096


# Generated at 2022-06-11 02:28:45.863599
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mac_facts = DarwinHardware().get_mac_facts()
    assert isinstance(mac_facts, dict)
    assert mac_facts['osversion']
    assert mac_facts['osrevision']
    assert mac_facts['model'] or mac_facts['product_name']



# Generated at 2022-06-11 02:28:58.554158
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import pytest
    from ansible.module_utils.common.process import get_bin_path

    sysctl_cmd = get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'kern.boottime']

    # We need to get raw bytes, not UTF-8.
    rc, out, err = pytest.module.run_command(cmd, encoding=None)

     # kern.boottime returns seconds and microseconds as two 64-bits
     # fields, but we are only interested in the first field.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if rc != 0 or len(out) < struct_size:
        return {}


# Generated at 2022-06-11 02:30:32.595812
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

# Generated at 2022-06-11 02:30:44.621386
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    darwin_hw = DarwinHardware()
    rc, out, err = module.run_command("sysctl hw.model")
    if rc == 0:
        model = out.splitlines()[-1].split()[1]
    else:
        model = "Failed to get model"
    rc, out, err = module.run_command("sysctl hw.memsize")
    if rc == 0:
        memsize = out.splitlines()[-1].split()[1]
    else:
        memsize = "Failed to get total memory"
    rc, out, err = module.run_command("sysctl hw.physicalcpu")

# Generated at 2022-06-11 02:30:51.079084
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a test DarwinHardware object
    cal = DarwinHardware()
    # Create the expected output result
    result = {
        'memtotal_mb': 16384,
        'memfree_mb': 0,
    }
    # set the command output for vm_stat as the input for the unit test
    cal.module.run_command = command_output('Filesystems', 8192, 8192)
    assert cal.get_memory_facts() == result


# Generated at 2022-06-11 02:30:58.257019
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    def test_get_bin_path(binary):
        return binary

    class ModuleMock:

        def __init__(self):
            self.params = {}

        def get_bin_path(self, binary):
            return test_get_bin_path(binary)

        def run_command(self, cmd, encoding=None):
            if encoding == None:
              return 0, test_boottime, None
            else:
              return 0, test_boottime.decode('utf-8'), None

    module = ModuleMock()
    h = DarwinHardware(module=module)
    uptime_facts = h.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 79580

# Generated at 2022-06-11 02:31:01.242890
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = FakeAnsibleModule()
    hw = DarwinHardwareCollector(module=module)

    assert hw.platform is not None
    assert hw.platform == 'Darwin'



# Generated at 2022-06-11 02:31:07.964148
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:31:19.308511
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """
    When the plugin sends a command to retrieve the processor value, if the command
    returns a non-zero value, the plugin returns empty strings for the processor and
    processor_cores facts.
    """
    module = MagicMock()
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz',
                              'machdep.cpu.core_count': 8}
    cpu_facts = darwin_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz'
    assert cpu_facts['processor_cores'] == 8
   

# Generated at 2022-06-11 02:31:26.598517
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    test_cases = [
        # test good output
        {
            'input': b'kern.boottime: { sec = 1589563718, usec = 925713 }\n',
            'output': {
                'uptime_seconds': 1589578718,
            },
        },

        # test no output
        {
            'input': b'',
            'output': {},
        },

        # test wrong output type
        {
            'input': b'kern.boottime: { sec = ?, usec = ? }\n',
            'output': {},
        },

        # test truncated output
        {
            'input': b'kern.boottime: { sec = ',
            'output': {},
        },
    ]

    # patches are monkey-patching the output of run_

# Generated at 2022-06-11 02:31:32.373771
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    hardware_obj = DarwinHardware(module)
    hardware_obj.populate()
    assert isinstance(hardware_obj.facts, dict)
    assert hardware_obj.facts['memtotal_mb'] > 0
    assert hardware_obj.facts['uptime_seconds'] > 0
    assert hardware_obj.facts['osversion'] != ''
    assert hardware_obj.facts['model'] != ''

# Generated at 2022-06-11 02:31:41.610722
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.utils import python as pyutils
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Unit test reader:
    #   - https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/hardware/linux.py
    #   - https://github.com/ansible/ansible/blob/devel/test/units/module_utils/facts/test_linux.py
    class FakeModule:

        def __init__(self):
            self.exit_json = None
            self.fail_json = None

        def get_bin_path(self, name):
            return self
