

# Generated at 2022-06-11 02:22:34.826934
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Initialize the class.
    module_args = dict(
        gather_subset='all'
    )
    module = AnsibleModule(argument_spec=module_args)
    # Set required attributes.
    module.run_command = mock.Mock(return_value=(0, '', ''))
    module.run_command.side_effect = [
        (0, 'Pages wired down: 272844', ''),
        (0, 'Pages active: 314856', ''),
        (0, 'Pages inactive: 148342', ''),
        (0, 'Pages free: 173204', '')
    ]
    module.get_bin_path = mock.Mock(return_value='/usr/bin/vm_stat')
    dh = DarwinHardware(module)
    # Call the method.
    facts = dh.get

# Generated at 2022-06-11 02:22:46.767496
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Model Name'] == 'MacBook Pro'
    assert system_profile['Serial Number'] == 'C02MM5Q2G5QX'
    assert system_profile['Processor Name'] == 'Intel Core i5'
    assert system_profile['Processor Speed'] == '2 GHz'
    assert system_profile['Number of Processors'] == '1'
    assert system_profile['Memory'] == '16 GB'
    assert system_profile['Boot ROM Version'] == 'MBP152.0172.B00'
    assert system_profile['SMC Version (system)'] == '2.26f7'
    assert system_profile['Serial ATA'] == 'APPLE SSD SM0256G'

# Generated at 2022-06-11 02:22:54.710399
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware({}, dict())
    command = [
            "system_profiler",
            "SPHardwareDataType"
            ]
    result = darwin_hardware.get_system_profile()['Serial Number (system)']
    # Command output example
    # "Serial Number (system): C02GVL10DV7V"
    assert result == 'C02GVL10DV7V'
    return result

# Generated at 2022-06-11 02:22:58.907891
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
  module = AnsibleModule(argument_spec=dict())
  hardware = DarwinHardware(module)
  hardware_facts_a = hardware.populate()
  hardware_facts_b = hardware.populate()
  assert hardware_facts_a == hardware_facts_b



# Generated at 2022-06-11 02:23:09.106435
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # This is a method of the class DarwinHardware
    # That we are going to test.
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Create a mock module.
    module_mock = Mock(spec=AnsibleModule)
    module_mock.params = {}

    # Patch methods of mock.
    module_mock.run_command.return_value = (0, 'hw.model: x86_64', '')
    module_mock.get_bin_path.return_value = '/usr/sbin/vm_stat'

    # Create a mock ansible module.
    ansible_module_mock = AnsibleModule(
        argument_spec = dict()
    )

    # We need to make the mock return our own mock.

# Generated at 2022-06-11 02:23:12.809636
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    delta = {'changed': False, 'failed': False}
    macfacts = DarwinHardware(delta)
    macfacts = macfacts.populate()
    assert isinstance(macfacts['osversion'], str)
    assert isinstance(macfacts['model'], str)

# Generated at 2022-06-11 02:23:15.660376
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class == DarwinHardware

# Generated at 2022-06-11 02:23:26.802325
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:23:38.241164
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # We use Linux for testing as Darwin does not have a mock version
    # of sysctl in the distro
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from mock import Mock, patch
    from pytest import raises
    darwin_h = DarwinHardware(module=Mock())

    # We mock the sysctl command and the fact that it exists
    with patch('ansible.module_utils.facts.hardware.darwin.get_bin_path') as get_bin_path:
        with patch('ansible.module_utils.facts.hardware.darwin.DarwinHardware.run_command') as run_command:
            # We make the command succeed
            run_command.return_value = (0, '', '')

            # When returning the path to the command, we check that the exact command

# Generated at 2022-06-11 02:23:49.636076
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Setup
    module_mock = AnsibleModuleMock()
    time_mock = time
    time_mock.time = MagicMock(return_value=1578564665.0)
    sysctl_cmd_mock = "sysctl -b kern.boottime"
    rc_mock = 0
    out_mock = "\x11\x00\x00\x00\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    err_mock = ""
    module_mock.run_command = MagicMock(return_value=(rc_mock, out_mock, err_mock))
    time.sleep = MagicMock()

    # Execute

# Generated at 2022-06-11 02:24:09.277568
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Test for method get_mac_facts of class DarwinHardware.
    Unit tests for method get_mac_facts of class DarwinHardware and
    the corresponding system calls.

    :id: bea1a7c1-c5f9-5d5c-8f7f-cccddb61daed

    :steps:
        1) Call DarwinHardware.get_mac_facts() method
        2) Check the value of attributes model, osversion and osrevision
        3) Check the return code and output of the corresponding system call

    :expectedresults:
        1) The values of attributes model, osversion and osrevision should be
        returned correctly.
        2) The return code and output of the corresponding system call should
        be valid.
    """
    f = DarwinHardware()
    # get_mac_facts() calls 'sysctl

# Generated at 2022-06-11 02:24:20.134597
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule({})

# Generated at 2022-06-11 02:24:22.691259
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    uptime_facts = DarwinHardware(dict()).get_uptime_facts()
    assert uptime_facts.get('uptime_seconds') is not None

# Generated at 2022-06-11 02:24:32.216268
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    module = fakes.FakeModule()
    # Test case 1

# Generated at 2022-06-11 02:24:43.696146
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_module = type('module', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
    })
    test_module.get_bin_path = lambda *args, **kwargs: '/usr/bin/vm_stat'
    test_class = type('DarwinHardware', (DarwinHardware,), {
        'module': test_module,
    })
    test_obj = test_class()
    test_obj.sysctl = {
        'hw.memsize': 1048576000,
    }
    memory_facts = test_obj.get_memory_facts()

    # If "vm_stat" is not found or returns no output, there are no memory facts
    assert memory_facts == {}


# Generated at 2022-06-11 02:24:44.982402
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector._platform == 'Darwin'

# Generated at 2022-06-11 02:24:53.765629
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware = DarwinHardware(dict())
    hardware.module.run_command = lambda *args, **kwargs: (0, '', '')
    hardware.module.get_bin_path = lambda *args, **kwargs: "vm_stat"
    hardware.module.run_command = lambda *args, **kwargs: (0, 'Pages active: 26413\nPages wired down: 81846456\nPages free: 14936\nPages inactive: 37311\nPages speculative: 2311', '')
    hardware.sysctl = dict()
    hardware.sysctl['kern.osversion'] = '15.2.0'
    hardware.sysctl['kern.osrevision'] = '15.2.0'
    hardware.sysctl['hw.model'] = 'MacPro3,1'

# Generated at 2022-06-11 02:25:03.194686
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Arrange
    import json
    import tempfile
    import textwrap
    import unittest

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware


# Generated at 2022-06-11 02:25:12.712354
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    """
    Test get_mac_facts()
    """
    sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    module = FakeModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    hw = DarwinHardware(module)
    hw.sysctl = sysctl
    facts = hw.get_mac_facts()
    assert facts['model'] is None
    assert facts['osversion'] == '16.7.0'
    assert facts['osrevision'] == '15.6.0'


# Generated at 2022-06-11 02:25:18.062789
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    dhw = DarwinHardware(None)
    dhw.module = None
    sys_prof = dhw.get_system_profile()
    assert isinstance(sys_prof, dict)
    assert isinstance(sys_prof['Serial Number (system)'], str)
    assert isinstance(sys_prof['System Version'], str)


# Generated at 2022-06-11 02:25:40.263356
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """ Tests for method get_memory_facts of class DarwinHardware """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils.test import MockModule
    from ansible.module_utils.facts.utils.test import MockCommand
    import os
    import sys

    # Store input parameters as a dictionary
    sysctl_input = {'hw.memsize': '4294967296', '/usr/bin/vm_stat': ''}

    # Store expected output of the command

# Generated at 2022-06-11 02:25:46.938162
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = MockModule()
    module.run_command.return_value = (0, "\n"
                                       "Pages free:                     1404.\n"
                                       "Pages active:                   2943.\n"
                                       "Pages inactive:                  726.\n"
                                       "Pages speculative:               636.\n"
                                       "Pages throttled:                  10.\n"
                                       "Pages wired down:               3893.\n", "")
    hardware = DarwinHardware(module=module, sysctl={'hw.memsize': 4294967296})
    facts = hardware.get_memory_facts()
    assert facts == {'memtotal_mb': 4096, 'memfree_mb': 2850}


# Generated at 2022-06-11 02:25:51.649535
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'model' in cpu_facts
    assert 'osversion' in cpu_facts
    assert 'osrevision' in cpu_facts



# Generated at 2022-06-11 02:26:03.057425
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import sys
    import mock
    import uuid
    test_uuid = '{0}_{1}'.format(uuid.uuid4().hex, uuid.uuid4().hex)
    test_uuid = test_uuid.replace('-', '_')

    test_memory_facts = {
        'memtotal_mb': 0,
        'memfree_mb': 0,
    }

    class FakeAnsibleModule(object):
        def __init__(self):
            self.run_command_expect_return_code = 0

# Generated at 2022-06-11 02:26:06.072581
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware()
    hardware.module = type("Module", (), {"run_command": mock_run_command})
    hardware.sysctl = {}  # mock_get_sysctl

    hardware.get_system_profile()



# Generated at 2022-06-11 02:26:16.041442
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # fake module so we can test!
    class FakeModule:
        def __init__(self, content):
            self.content = content
            self.run_command_count = 0
        # fake run_command so we can control the output
        def run_command(self, args, encoding=None):
            self.run_command_count += 1
            if args[0] == 'vm_stat':
                return 0, self.content, None
            else:
                return 1, None, None


# Generated at 2022-06-11 02:26:28.745126
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    darwin_hardware = DarwinHardware(module=None)


# Generated at 2022-06-11 02:26:39.835682
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Test 1: sysctl returns 1000s, method returns {'uptime_seconds': 1000}
    module = MockModuleWithSysctl()
    module.run_command.return_value = (0, b'\x10\x00\x00\x00\x00\x00\x00\x00', '')

    fact_class = DarwinHardware(module)
    uptime_facts = fact_class.get_uptime_facts()

    assert uptime_facts == {'uptime_seconds': 1000}

    # Test 2: sysctl returns 32bit value, method returns {'uptime_seconds': 1}
    module = MockModuleWithSysctl()
    module.run_command.return_value = (0, b'\x01\x00\x00\x00', '')

    fact_class = DarwinHardware(module)

# Generated at 2022-06-11 02:26:47.675030
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils._text import to_bytes
    darwin_hardware = DarwinHardware(dict(), dict())
    rc, out, err = darwin_hardware.module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    if rc != 0:
        return dict()
    output_bytes = to_bytes(out)
    system_profile = darwin_hardware.get_system_profile()

    assert len(system_profile['Serial Number (system)']) == 11

# Generated at 2022-06-11 02:26:58.212698
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware()
    hardware.module = get_module_mock()

# Generated at 2022-06-11 02:27:29.686387
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule():
        def __init__(self):
            self.run_command_result_values = [((0, '', ''), (0, b'\x00\x00\x00\x00\x00\x00\x00\x00', ''))]
            self.run_command_calls = 0

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, encoding=None):
            rc, out, err = self.run_command_result_values[self.run_command_calls]
            self.run_command_calls += 1
            return rc, out, err

    hardware = DarwinHardware(TestModule())
    uptime_facts = hardware.get_uptime_facts()


# Generated at 2022-06-11 02:27:35.926428
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware()
    cpu_facts = hardware.get_cpu_facts()

    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts

    assert isinstance(cpu_facts['processor'], str)
    assert isinstance(cpu_facts['processor_cores'], str)
    assert isinstance(cpu_facts['processor_vcpus'], str)


# Generated at 2022-06-11 02:27:44.304639
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict())
    sysctl_cmd = module.get_bin_path('sysctl')

    # Generate a mocked output of the sysctl command, with the time
    # fields set to 0 so we can the result easily.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    fields = struct.pack(struct_format, 0)
    mocked_out = fields + b'0' * (len(fields) - 1)

    def mock_run_command(cmd, encoding=None):
        # The command should pass the -b option to get the raw value.
        assert sorted(cmd) == sorted([sysctl_cmd, '-b', 'kern.boottime'])

        # The command should ask for a raw byte string output.

# Generated at 2022-06-11 02:27:54.428072
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModuleMock()
    hardware = DarwinHardware(module)

    module.run_command.side_effect = [
        (0, "Hardware:\nHardware Overview:\nModel Name: iMac\nModel Identifier: iMac12,1\nProcessor Name: Intel Core i7\nProcessor Speed: 3.4 GHz\nNumber of Processors: 1\nTotal Number of Cores: 4\nL2 Cache (per Core): 256 KB\nL3 Cache: 8 MB\nMemory: 16 GB", ""),
        (1, "", "")
    ]

    system_profile_1 = hardware.get_system_profile()
    system_profile_2 = hardware.get_system_profile()

    assert(system_profile_1['Model Name'] == 'iMac')

# Generated at 2022-06-11 02:28:02.853278
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class ModuleStub(object):
        def run_command(*args, **kwargs):
            return 0, 'hw.model: MacBookAir4,2', ''

    class DarwinHardwareStub(DarwinHardware):
        sysctl = dict()

        def __init__(self, module):
            self.module = ModuleStub()

    m = ModuleStub()
    dh = DarwinHardwareStub(m)

    mac_facts = dh.get_mac_facts()

    assert mac_facts['model'] == 'MacBookAir4,2'
    assert mac_facts['osversion'] == ''
    assert mac_facts['osrevision'] == ''



# Generated at 2022-06-11 02:28:09.258303
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Initialize the module with a mocked module.run_command
    module.run_command = MagicMock(return_value=(0, 'hw.model: iMac14,2', ''))
    hardware = DarwinHardware(module)

    mac_facts = hardware.get_mac_facts()

    assert mac_facts['model'] == 'iMac14,2'

# Generated at 2022-06-11 02:28:22.054731
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils._text import to_bytes
    import json
    import os

    # Intel
    testdata_dir = os.path.join(os.path.dirname(__file__), '../../unit/module_utils/facts/hardware/fixtures')
    test_sysctl_file = os.path.join(testdata_dir, 'sysctl_get_cpu_facts_intel.json')
    sysctl_get_cpu_facts_intel = json.load(open(test_sysctl_file))

    module = AnsibleModuleMock()
    module.run_command.return_value = (0, to_bytes(json.dumps(sysctl_get_cpu_facts_intel), errors='surrogate_then_replace'), None)

    objDarwinHardware = DarwinHardware(module)

    cpu

# Generated at 2022-06-11 02:28:32.977454
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform
    import tempfile
    import os
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Get the current time in seconds and create a test file with that time.
    now = time.time()
    test_file = tempfile.NamedTemporaryFile()
    os.write(test_file.file.fileno(), struct.pack('@L', int(now)))

    # Create an instance of DarwinHardware class
    dh = DarwinHardware(dict(module=dict(run_command=lambda x: (0, os.read(test_file.file.fileno(), 8), ''))))
    # Assert that the uptime is the expected
    assert dh.get_uptime_facts() == {'uptime_seconds': int(time.time() - now)}

# Generated at 2022-06-11 02:28:36.394671
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """This is a test of the constructor for class DarwinHardwareCollector.
    """
    mac_hw_collector = DarwinHardwareCollector()

    assert mac_hw_collector._fact_class == DarwinHardware
    assert mac_hw_collector._platform == 'Darwin'

# Generated at 2022-06-11 02:28:44.985369
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware_obj = DarwinHardware()
    system_profile_dict = hardware_obj.get_system_profile()

# Generated at 2022-06-11 02:29:37.433441
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    fixture = """
Hardware Overview:

      Model Name: iMac
      Model Identifier: iMac10,1
      Processor Name: Intel Core 2 Duo
      Processor Speed: 3.06 GHz
      Number of Processors: 1
      Total Number of Cores: 2
      L2 Cache: 6 MB
      Memory: 4 GB
      Bus Speed: 1.07 GHz
      Boot ROM Version: IM101.00CC.B00
      SMC Version (system): 1.58f16
      Serial Number (system): W890915GGZF
      Hardware UUID: 00000000-0000-1000-8000-0015E0D104BE

"""

# Generated at 2022-06-11 02:29:41.084906
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_class = DarwinHardware(dict())
    test_profile = test_class.get_system_profile()
    assert len(test_profile) > 0
    assert 'Model Name' in test_profile
    assert 'CPU Speed' in test_profile
    assert 'Number of Processors' in test_profile
    assert 'Memory' in test_profile

# Generated at 2022-06-11 02:29:48.872991
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = type('module', (object,), {'run_command': run_command})
    hardware = DarwinHardware(module=module)
    facts = hardware.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-3720QM CPU @ 2.60GHz'
    assert facts['processor_cores'] == '4'
    assert facts['processor_vcpus'] == '4'
    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 16384
    assert facts['model'] == 'MacBookPro9,1'
    assert facts['osversion'] == '14.4.0'
    assert facts['osrevision'] == '15E65'


# Generated at 2022-06-11 02:29:54.974523
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible_collections.community.general.plugins.module_utils.facts.hardware.darwin import DarwinHardware

    # Mocking time.time()
    time_seconds = 1568968160
    time_nanoseconds = 125000000
    DarwinHardware.time_seconds = lambda: time_seconds
    DarwinHardware.time_nanoseconds = lambda: time_nanoseconds

    # Returns a tuple: (seconds, nanoseconds)
    DarwinHardware.get_uptime_seconds_nanoseconds = lambda self: (1578078000, 470000000)

    # Mocking method run_command of the module instance
    DarwinHardware.module = lambda: None

# Generated at 2022-06-11 02:30:04.720669
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware_module_input_params = {
        "module_utils": "ansible.module_utils.facts.hardware.base",
    }
    hardware_obj = DarwinHardware(module_input_params=hardware_module_input_params)
    hardware_obj.populate()

# Generated at 2022-06-11 02:30:12.155303
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    in_lines = (
        "kern.boottime: { sec = 1505840033, usec = 0 }",  # Wed Aug 16 10:20:33 2017
        "kern.boottime: { sec = 1499969860, usec = 0 }",  # Sat Jul  1 11:24:20 2017
    )

    hardware = DarwinHardware(None)
    hardware.sysctl = get_sysctl(None, ['kern'])
    hardware.module.run_command.return_value = (
        0, in_lines[0], None)
    uptime_seconds = hardware.get_uptime_facts()['uptime_seconds']
    expect_seconds = int(time.time()) - 1505840033

    # Small tolerance.
    assert abs(uptime_seconds - expect_seconds) < 60

    hardware.module

# Generated at 2022-06-11 02:30:14.242657
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    Test the constructor of class DarwinHardwareCollector
    """
    darwinHardwareCollector = DarwinHardwareCollector()
    assert darwinHardwareCollector.platform == 'Darwin'

# Generated at 2022-06-11 02:30:21.557599
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = type('module', (object,), {})

    class ModuleResult:
        rc = 0
        err = None

        def __init__(self, out):
            self.out = out

    module.run_command = lambda x: ModuleResult(out=x[0])

    test = DarwinHardware(module)
    assert test.get_system_profile() == {'test': 'test'}

    module.run_command = lambda x: ModuleResult(out=x[0] + '\n')
    assert test.get_system_profile() == {'test': 'test'}

    module.run_command = lambda x: ModuleResult(out=x[0] + '\n\n')
    assert test.get_system_profile() == {'test': 'test'}


# Generated at 2022-06-11 02:30:30.217154
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    global_module = None
    global_class_name_params = {
        'sysctl': {
            'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2697 v2 @ 2.70GHz',
            'machdep.cpu.core_count': '8',
            'hw.physicalcpu': '4',
            'hw.logicalcpu': '8',
            'hw.ncpu': '8',
        },
        'run_command': lambda x, encoding=None: (0, '', '')
    }
    # Case 1: Run on Intel processor
    local_class = DarwinHardware(global_module, global_class_name_params)
    cpu_facts = local_class.get_cpu_facts()

# Generated at 2022-06-11 02:30:42.857667
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    m = DarwinHardware()
    setattr(m, 'sysctl', {'hw.memsize': '67108864'})
    memory_facts = m.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 64

    # test the code path where vm_stat module is not installed
    setattr(m, 'sysctl', {'hw.memsize': '67108864', 'hw.pagesize': '4096'})
    setattr(m, 'module', object())
    setattr(m.module, 'run_command', lambda command: (1, 'test', 'test'))
    memory_facts = m.get_memory_facts()
    assert memory_facts['memfree_mb'] == 0

