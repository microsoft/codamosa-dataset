

# Generated at 2022-06-11 02:22:26.298134
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwinhardware = DarwinHardwareCollector()
    assert darwinhardware._platform == 'Darwin'

# Generated at 2022-06-11 02:22:28.513894
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    from ansible.module_utils.six import PY3
    if not PY3:
        assert DarwinHardwareCollector(None)._platform == 'Darwin'

# Generated at 2022-06-11 02:22:38.443767
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule()
    sysctl = {}
    sysctl['hw.memsize'] = '1073741824'
    sysctl['hw.pagesize'] = '4096'
    sysctl['vm.swapusage'] = 'total = 1024.00M  used = 0.00M  free = 1024.00M  (encrypted)'
    module.run_command = MagicMock(return_value=(0, 'Pages wired down:         60717.\nPages active:            64336.\nPages inactive:          62264.\nPages free:              45975.\nPages speculative:         571.\nPages throttled:              0.\nPages filebacked:             0.\nPages purged:                0.\n', ''))
    mac_hardware = DarwinHardware(module)
    mac_hardware

# Generated at 2022-06-11 02:22:49.386921
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Create a dummy module.  It will be used to access some module methods
    module = type('DummyModule', (object, ), dict(run_command=lambda *args, **kwargs: (0, '', ''),
                                                  get_bin_path=lambda *args, **kwargs: '/bin/vm_stat'))

    hardware = DarwinHardware(module)

    # Create a mock sysctl output
    # With brand_string

# Generated at 2022-06-11 02:23:00.923208
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import platform
    import re

    if platform.system() != 'Darwin':
        pytest.skip("not darwin system")

    import sys
    import socket
    sys.modules['socket'] = socket
    socket.gethostname.return_value = "localhost.localdomain"

    sysctl = {'machdep.cpu.core_count': '5'}
    sysctl_module = sysctl
    sysctl_module['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i5-6500 CPU @ 3.20GHz'

    # Run get_cpu_facts with mock sysctl
    hardware = DarwinHardware()
    hardware.sysctl = sysctl_module

    # Check that processor is properly set

# Generated at 2022-06-11 02:23:10.725929
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:23:13.028879
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware = DarwinHardwareCollector()
    assert darwin_hardware.platform == 'Darwin'

# Generated at 2022-06-11 02:23:13.692105
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-11 02:23:17.594368
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # pylint: disable=protected-access
    # disable invalid-name because this method is called by the unit test framework
    # pylint: disable=invalid-name
    result = DarwinHardware._get_uptime_facts()
    assert 'uptime_seconds' in result
    assert isinstance(result['uptime_seconds'], int)

# Generated at 2022-06-11 02:23:28.430726
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    # Generate output of command vm_stat with certain thresholds set on each
    # memory state so we can easily calculate the total used memory
    def generate_vm_stat_output(wired, active, inactive):
        output = ""
        output += "Mach Virtual Memory Statistics: (page size of 4096 bytes)\n\n"
        output += "Pages free:                           83564.\n"
        output += "Pages active:                         %d.\n" % active
        output += "Pages inactive:                       %d.\n" % inactive
        output += "Pages speculative:                    4312.\n"
        output += "Pages throttled:                      0.\n"
        output += "Pages wired down:                     %d.\n" % wired
        output += "Pages purgeable:                      0.\n"

# Generated at 2022-06-11 02:23:38.866774
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert d.platform == 'Darwin'

# Generated at 2022-06-11 02:23:50.312119
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import ansible.module_utils.facts.sysctl as sysctl

    module = sysctl.MyModule()
    darwin_hardware = DarwinHardware(module)

    # We test with different vm_stat outputs to test that the method
    # deals correctly with negative free memory and different usages of
    # the 'Pages' keyword.

# Generated at 2022-06-11 02:24:02.322469
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """Unit test for method get_memory_facts of class DarwinHardware"""
    # define input parameters
    hw_memsize = 1048576000
    sysctl = {'hw.memsize': hw_memsize}
    mem_stats = {'Pages wired down': 1048576, 'Pages active': 1048576, 'Pages inactive': 1048576}
    mem_stats_str = "\n".join("%s: %s" % (k, v) for k, v in mem_stats.items())

    # create instance of DARWINHardware
    dh = DarwinHardware({})

    # mock methods
    def mock_run_command(cmd):
        assert cmd == ['/usr/sbin/vm_stat']
        return (0, mem_stats_str, "")

    dh.module.run_command = mock_run

# Generated at 2022-06-11 02:24:13.421816
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts_instance = DarwinHardware(module)


# Generated at 2022-06-11 02:24:21.090718
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Set up a mocked module and its parameters
    module = MockAnsibleModule({
        'sysctl': {
            'hw.model': 'hw.model: MacBookPro12,1',
            'kern.osversion': '15.3.0',
            'kern.osrevision': '15.3.0',
        },
    })

    d = DarwinHardware(module=module)
    facts = d.get_mac_facts()

    assert facts['model'] == 'MacBookPro12,1'
    assert facts['osversion'] == '15.3.0'
    assert facts['osrevision'] == '15.3.0'


# Generated at 2022-06-11 02:24:31.094558
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    testdata_1 = {
        'machdep.cpu.brand_string': 'Intel Core 2 Duo CPU P7350 @ 2.00GHz',
        'machdep.cpu.core_count': '2',
    }

    testdata_2 = {
        'hw.physicalcpu': '2',
    }

    expected_output_1 = {
        'processor': 'Intel Core 2 Duo CPU P7350 @ 2.00GHz',
        'processor_cores': '2',
        'processor_vcpus': '',
    }

    expected_output_2 = {
        'processor': 'Intel Core 2 Duo CPU P7350 @ 2.00GHz',
        'processor_cores': '2',
        'processor_vcpus': '2',
    }

    testobj = DarwinHardware()

    testobj.sys

# Generated at 2022-06-11 02:24:43.171591
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create a stub module
    module = AnsibleModuleAPI(argument_spec={})

    # Replace module.run_command by a mock function

# Generated at 2022-06-11 02:24:52.828470
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    mac = DarwinHardware(dict(module=dict(run_command=None)))

# Generated at 2022-06-11 02:25:02.791701
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:25:11.546181
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mock_module = type('MockModule', (object,), {
        'run_command': lambda x: (0, "Hardware:\nMachine Name: x\nModel Name: x\n", ''),
    })
    hardware = DarwinHardware(mock_module, 'x86_64', 'Darwin')

    system_profile = hardware.get_system_profile()
    assert system_profile == {'Hardware': '', 'Model Name': 'x', 'Machine Name': 'x'}

NoMacs = DarwinHardwareCollector
__all__ = ('DarwinHardware', 'DarwinHardwareCollector')

# Generated at 2022-06-11 02:25:40.150313
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    Intel = {"machdep.cpu.brand_string": "Intel(R) Core(TM) i5-8259U CPU @ 2.30GHz",
             "machdep.cpu.core_count": "2",
             "hw.logicalcpu": "2",
             "hw.ncpu": "2",
             }

    PowerPC = {"hw.physicalcpu": "1",
               "hw.logicalcpu": "1",
               "hw.ncpu": "1",
               }

    Intel_result = {"processor": "Intel(R) Core(TM) i5-8259U CPU @ 2.30GHz",
                    "processor_cores": "2",
                    "processor_vcpus": "2",
                    }


# Generated at 2022-06-11 02:25:46.617345
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = Mock()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/vm_stat')

    hardware = DarwinHardware(module)
    facts = hardware.populate()

    assert facts['uptime_seconds'] == 0
    assert facts['processor_cores'] == '2'
    assert facts['memtotal_mb'] == 1024
    assert facts['memfree_mb'] == 0
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '14G1036'
    assert facts['model'] == 'MacBookPro10,2'

# Generated at 2022-06-11 02:25:58.291186
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    darwin_hardware_instance = DarwinHardware(module)
    darwin_hardware_instance.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15.6.0'}
    rc, out, err = module.run_command("sysctl hw.model")

    if rc == 0:
        if out.splitlines()[-1].split()[1] == "Macmini7,1":
            mac_facts = darwin_hardware_instance.get_mac_facts()
            module.exit_json(ansible_facts = dict(
                hardware = mac_facts
            ))

# Generated at 2022-06-11 02:26:05.503739
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mac_hardware = DarwinHardware()
    test_profile = mac_hardware.get_system_profile()
    truth_value = {'Serial Number (system)': 'C02CFFBHGK1J',
                   'Processor Speed': '2.5 GHz',
                   'Number of Processors': '1',
                   'Processor Name': 'Intel Core i5',
                   'Boot ROM Version': 'MBP101.00EE.B1B',
                   'SMC Version (system)': '2.5f0'}
    assert test_profile == truth_value, "get_system_profile test failed"

# Generated at 2022-06-11 02:26:14.953141
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    # Module imports
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Module variable
    dh = DarwinHardware()

    # Module method
    result = dh.get_memory_facts()

    # Test result
    assert isinstance(result, dict)
    assert 'memtotal_mb' in result.keys()
    assert result['memtotal_mb'] > 0
    assert 'memfree_mb' in result.keys()
    assert result['memfree_mb'] > 0
    memory_used_mb = result['memtotal_mb'] - result['memfree_mb']
    assert memory_used_mb > 0


# Generated at 2022-06-11 02:26:27.651914
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_string = """Hardware Overview:

  Model Name: MacBook Pro
  Model Identifier: MacBookPro11,4
  Processor Name: Intel Core i7
  Processor Speed: 2.2 GHz
  Number of Processors: 1
  Total Number of Cores: 4
  L2 Cache (per Core): 256 KB
  L3 Cache: 6 MB
  Memory: 16 GB
  Boot ROM Version: MBP114.0172.B06
  SMC Version (system): 2.26f2
  Serial Number (system): C02SR71RG3Q3
  Hardware UUID: D4B316A4-E4E4-5FDE-9CA4-23E1A79A2046

"""
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    test_object = DarwinHardware(None)


# Generated at 2022-06-11 02:26:37.136180
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Arrange
    module = Mock()
    module.run_command.return_value = 0, 'hw.model: MacBookPro12,1', None
    facts_object = DarwinHardware(module)

    # Act
    result = facts_object.get_mac_facts()

    # Assert
    module.run_command.assert_called_once_with(['sysctl', 'hw.model'])
    assert result == {
        'model': 'MacBookPro12,1',
        'product_name': 'MacBookPro12,1',
        'osversion': '',
        'osrevision': '',
    }


# Generated at 2022-06-11 02:26:46.938169
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Create a mock module that just sets a 'changed' value
    # and provides a few functions.
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, 'success', ''))

# Generated at 2022-06-11 02:26:53.618752
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = type('', (object,), dict(run_command=lambda x, y=None, z=False, e=None: (0, 'Pages active: 148     \nPages wired down: 44     \nPages inactive: 44     \n.', None)))
    hardware = DarwinHardware(module=module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0

# Generated at 2022-06-11 02:27:03.170935
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=(0, "2.4 GHz Intel Core i5", ""))
    hardware = DarwinHardware(module)

    hardware.sysctl = dict()
    hardware.sysctl['machdep.cpu.brand_string'] = "2.4 GHz Intel Core i5"
    hardware.sysctl['machdep.cpu.core_count'] = "4"

    result = hardware.get_cpu_facts()
    assert result['processor_cores'] == '4'
    assert result['processor_vcpus'] == ''
    assert result['processor'] == '2.4 GHz Intel Core i5'



# Generated at 2022-06-11 02:27:49.221795
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    mac_module = MockMacModule()
    mac_hardware = DarwinHardware(module=mac_module)
    assert mac_hardware.get_cpu_facts()['processor'] == 'Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz'
    assert mac_hardware.get_cpu_facts()['processor_cores'] == '2'
    assert mac_hardware.get_cpu_facts()['processor_vcpus'] == '4'



# Generated at 2022-06-11 02:27:58.804092
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Setup
    module = FakeAnsibleModule()
    test_class = DarwinHardware(module)

# Generated at 2022-06-11 02:28:00.519265
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # This class is tested indirectly through sys_info.py
    pass

# Generated at 2022-06-11 02:28:10.345515
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    uname = {
        'release': '14.0.0',
        'product_name': 'MacBookPro10,2',
        'osversion': 'Darwin Kernel Version 14.0.0: Fri Sep 19 00:26:44 PDT 2014; root:xnu-2782.1.97~2/RELEASE_X86_64',
        'osrevision': '14.0.0',
        'machine': 'x86_64',
        'processor': 'i386',
        'model': 'MacBookPro10,2',
        'processor_cores': 4,
        'memtotal_mb': 8192,
        'memfree_mb': 778,
        'uptime_seconds': 262331,
    }

    DarwinHardware().get()

    assert DarwinHardware().get_mac_facts() == uname


# Generated at 2022-06-11 02:28:22.852770
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:28:30.408926
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Create a fake module
    module = type('AnsibleModule', (), {})()

    # Fake run_command
    module.run_command = lambda *args, **kwargs: (0, 'hw.model: MacBookPro10,1', '')

    # Create the object
    obj = DarwinHardware()

    # Add the module to the object
    obj.module = module

    # Try to fetc the memory facts.
    facts = obj.get_mac_facts()

    # Check facts
    assert 'model' in facts

# Generated at 2022-06-11 02:28:39.577103
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible_collections.os_majors.os_version.tests.unit.compat.mock import Mock, MagicMock, patch

    DarwinHardware.get_system_profile = MagicMock()
    module = MagicMock()
    out = """Hardware Overview:

      Model Name: MacBookPro5,5
      Processor Name: Intel Core 2 Duo
      Processor Speed: 2.53 GHz
      Number of Processors: 1
      Total Number of Cores: 2
      L2 Cache: 6 MB
      Memory: 8 GB"""
    rc = 0
    err = ""
    module.run_command = MagicMock(return_value=(rc, out, err))
    hardware = DarwinHardware(module)

    hardware.get_system_profile()


# Generated at 2022-06-11 02:28:47.345247
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    global module_args

    # Class initialization and default values
    module_args = dict(
        gather_subset='all',
        filter='*',
    )
    module = MockModule(**module_args)
    hw = DarwinHardware(module)

    # This is not a complete test of all DarwinHardware methods
    # Additional testing should be done for each method
    assert type(hw.populate()) is dict, "populate did not return a dict"

# Generated at 2022-06-11 02:28:59.406994
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import datetime
    import freezegun
    import mock

    # The mocked command returns a boottime of 2 seconds
    mock_run_command = mock.Mock(return_value=(0, b'\x02\x00\x00\x00\x00\x00\x00\x00', ''))

    # We will use a specific datetime and then freeze it, to avoid any
    # dependency on the real time.
    timestamp = datetime.datetime(2016, 1, 1)
    freezer = freezegun.freeze_time(timestamp)
    with freezer:
        from ansible.module_utils.facts.hardware.darwin import DarwinHardware
        facts = DarwinHardware({}).get_uptime_facts()

        # The fact should be a dictionary with 2 keys.
        assert len(facts) == 1

# Generated at 2022-06-11 02:29:01.602266
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockModule()
    darwin_hardware = DarwinHardware(module=module)
    darwin_hardware.get_cpu_facts()


# Generated at 2022-06-11 02:30:33.091339
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    # Testing an Intel Mac
    module.run_command = MagicMock(side_effect=[[0, 'machdep.cpu.brand_string: Genuine Intel(R) CPU 0000 @ 2.00GHz', ''], [0, 'hw.memsize: 536870912', ''], [0, 'hw.physicalcpu: 2', ''], [0, 'hw.logicalcpu: 4', ''], [0, 'kern.osversion: 15.0.0', ''], [0, 'kern.osrevision: 15G31', ''], [0, 'kern.boottime: { sec = 1423140180, usec = 405314 }', '']])
    mac_obj = DarwinHardware(module)
    mac_facts = mac_obj.populate()


# Generated at 2022-06-11 02:30:38.695224
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    collected_facts = hardware.populate()
    assert collected_facts['processor'] == ''
    assert collected_facts['model'] == ''
    assert collected_facts['osversion'] == ''
    assert collected_facts['osrevision'] == ''

# Generated at 2022-06-11 02:30:49.864589
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = MockModule()
    harwdare = DarwinHardware(module)

# Generated at 2022-06-11 02:30:58.230301
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import module_utils.facts.hardware.darwin as DUT

    module_ = mock.MagicMock(name='module')

    instance = DUT.DarwinHardware(module_, DUT.get_sysctl(module_, ['hw', 'machdep', 'kern']))

    module_.get_bin_path.return_value = 'sysctl'
    module_.run_command.return_value = (0, b'\x01\x00\x00\x00\x00\x00\x00\x00', 'err')
    res = instance.get_uptime_facts()
    assert res == {'uptime_seconds': 1}


# Generated at 2022-06-11 02:30:59.661263
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert isinstance(DarwinHardwareCollector(), DarwinHardwareCollector)


# Generated at 2022-06-11 02:31:07.263677
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = Mock()
    # This is the output of '/usr/sbin/system_profiler SPHardwareDataType'

# Generated at 2022-06-11 02:31:18.985138
# Unit test for method get_uptime_facts of class DarwinHardware

# Generated at 2022-06-11 02:31:21.954856
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    my_darwin_hardware = DarwinHardware()

    system_profile = my_darwin_hardware.get_system_profile()
    if system_profile != dict():
        assert True
    else:
        assert False

# Generated at 2022-06-11 02:31:24.682527
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwinHardwareCollector = DarwinHardwareCollector()
    assert isinstance(darwinHardwareCollector, HardwareCollector)
    assert darwinHardwareCollector._platform == 'Darwin'

# Generated at 2022-06-11 02:31:33.911095
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()
    module.run_command.return_value = (0, "", "")
    module.get_bin_path.return_value = "/bin/vm_stat"
    darwin_hardware = DarwinHardware(module)
    collected_facts = dict()
    facts = darwin_hardware.populate(collected_facts)
    assert facts['processor'] == "Intel(R) Core(TM) i7-2675QM CPU @ 2.20GHz"
    assert facts['processor_cores'] == 4
    assert facts['processor_vcpus'] == 4
    assert facts['memtotal_mb'] == 8192
    assert facts['memfree_mb'] == 1
    assert facts['model'] == "MacBookPro8,3"