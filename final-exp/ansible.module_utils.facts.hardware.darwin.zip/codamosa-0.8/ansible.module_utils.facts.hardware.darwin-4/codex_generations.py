

# Generated at 2022-06-11 02:22:33.306736
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = FakeModule({})
    hardware_obj = DarwinHardware(module)
    # mock out /usr/sbin/system_profiler

# Generated at 2022-06-11 02:22:46.114621
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts import decoded_dict_from_bytes
    # Create a temporary file for the module to read from.
    # Test a valid input.

# Generated at 2022-06-11 02:22:55.319603
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-11 02:23:00.838776
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardwareCollector._get_fact_class()()
    hardware.module = MockModule()
    system_profile = hardware.get_system_profile()
    assert(system_profile['Model Identifier'] == 'MacBookPro10,1')
    assert(system_profile['Processor Name'] == 'Intel Core i7')
    assert(system_profile['Processor Speed'] == '2.3 GHz')


# Generated at 2022-06-11 02:23:04.085261
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mac_facts = DarwinHardware(None)

    # Returned value should be a dict().
    assert isinstance(mac_facts.get_system_profile(), dict)


# Generated at 2022-06-11 02:23:12.084121
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class DarwinHardwareMock:
        def __init__(self):
            pass

        def run_command(self, cmd):
            if cmd[0] == "/usr/sbin/system_profiler" and cmd[1] == "SPHardwareDataType":
                rc = 0
                err = ""

# Generated at 2022-06-11 02:23:15.998095
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    darwin_hardware = DarwinHardware()
    namespace = darwin_hardware.populate(collected_facts={})

    module.exit_json.assert_called_with(ansible_facts={'ansible_hardware': namespace})


# Generated at 2022-06-11 02:23:27.251374
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible_collections.community.macos.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.community.macos.tests.unit.modules.utils import AnsibleFailJson
    from ansible_collections.community.macos.tests.unit.modules.utils import ModuleTestCase
    from ansible_collections.community.macos.tests.unit.modules.utils import set_module_args

    class AnsibleModuleMock(object):
        """ This is a mock module class to test the DarwinHardware class. """

        def __init__(self, params):
            self.params = params


# Generated at 2022-06-11 02:23:38.811892
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.collector import BaseFactCollector

    class MockModule(object):
        def __init__(self):
            self.params = {
                'gather_timeout': 5,
            }

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return 'vm_stat'

        def run_command(self, cmd, encoding=None):
            return 0, '', ''

    class MockCollector(BaseFactCollector):
        def __init__(self, module):
            self.module = module

        def gather_device_facts(self, device):
            return dict()

    dh = DarwinHardware()
    dm = MockModule()
    dc = MockCollector(dm)
    dh

# Generated at 2022-06-11 02:23:47.422713
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware("")
    hardware.sysctl = {'hw.logicalcpu': '4',
                       'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-7267U CPU @ 3.10GHz'}
    result = hardware.get_cpu_facts()
    assert result['processor'] == 'Intel(R) Core(TM) i5-7267U CPU @ 3.10GHz'
    assert result['processor_cores'] == '4'
    assert result['processor_vcpus'] == '4'


# Generated at 2022-06-11 02:24:02.177443
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeModule()
    facts = DarwinHardware(module).get_cpu_facts()
    assert facts['processor'] == 'Intel(R) Core(TM) m3-6Y30 CPU @ 0.90GHz'
    assert facts['processor_cores'] == '2'
    assert facts['processor_vcpus'] == '2'



# Generated at 2022-06-11 02:24:11.747624
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    failed_mac_facts = {'model': '', 'osversion': '', 'osrevision': ''}
    module = FakeAnsibleModule()
    darwin_hardware = DarwinHardware(module)
    results = darwin_hardware.get_mac_facts()

    # We cannot check the values here because they will be different on every machine
    # But we can verify that keys are present and that they are not empty
    assert 'model' in results
    assert results['model'] != ''
    assert 'osversion' in results
    assert results['osversion'] != ''
    assert 'osrevision' in results
    assert results['osrevision'] != ''


# Generated at 2022-06-11 02:24:15.756356
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    darwin_hardware = DarwinHardware(module=module)
    module.run_command().return_value = 0, '', ''
    darwin_hardware.populate()
    assert darwin_hardware.platform == 'Darwin'

# Generated at 2022-06-11 02:24:23.999494
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """Unit test function of get_memory_facts"""
    module = AnsibleModule(argument_spec=dict())
    test_obj = DarwinHardware(module)

    # Success case
    vm_stat_command = get_bin_path('vm_stat')
    module.run_command = MagicMock(return_value=(0, 'Mock output'))
    sysctl_command = module.get_bin_path('sysctl')
    module.run_command = MagicMock(return_value=(0, 'hw.memsize: 0x400000000'))
    memory_facts = test_obj.get_memory_facts()
    assert memory_facts == dict(memtotal_mb=1024, memfree_mb=0)

    # Fail case

# Generated at 2022-06-11 02:24:32.997599
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-11 02:24:35.329902
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModule()
    assert DarwinHardwareCollector(module).platform == 'Darwin'


# Generated at 2022-06-11 02:24:41.855371
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = type('MockModule', (object,), {})
    module.run_command = lambda cmd, encoding=None: (0, '\x01\x00' + '\x00' * 14, '')
    mac_hardware = type('MockMacHardware', (DarwinHardware,), {'module': module})

    assert mac_hardware().get_uptime_facts() == {'uptime_seconds': 1}

# Generated at 2022-06-11 02:24:51.854814
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test output of method get_system_profile
    """
    import tempfile
    import shutil

    INPUT_FILE = """
Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro14,1
      Processor Name: Intel Core i5
      Processor Speed: 2 GHz
      Number of Processors: 1
      Total Number of Cores: 2
      L2 Cache (per Core): 256 KB
      L3 Cache: 4 MB
      Memory: 8 GB
      Boot ROM Version: MP61.0116.B17
      SMC Version (system): 2.38f7
      Serial Number (system): C02T3H3AFA8Y
      Hardware UUID: B2A958D8-DF46-58DD-A64E-FFF14D871A76
"""
    EXP

# Generated at 2022-06-11 02:25:02.083968
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:25:13.272797
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Mac Mini (Late 2012), OSX 10.9
    module = Mock()
    module.run_command.return_value = (0, 'hw.model: Macmini6,2\n', '')
    module.get_bin_path.return_value = '/usr/sbin/system_profiler'
    module.run_command.side_effect = [(0, 'kern.osversion: 14.0.0\n', ''),
                                      (0, 'kern.osrevision: 14.0.0\n', '')]

    hardware = DarwinHardware(module)
    assert hardware.get_mac_facts() == {'model': 'Macmini6,2',
                                        'osversion': '14.0.0',
                                        'osrevision': '14.0.0'}

# Generated at 2022-06-11 02:25:38.444756
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Initialize a local module
    module = AnsibleModule(argument_spec=dict())
    module.run_command = Mock(return_value=(0, 'mock_output'))

    # Initialize an instance of class DarwinHardware
    darwin_hardware = DarwinHardware(module)

    # Define the expected output and verify the method returns the same
    expected = dict(processor='Intel(R) Xeon(R) CPU E5-2667 0 @ 3.00GHz',
                    processor_cores='4')
    result = darwin_hardware.get_cpu_facts()
    assert isinstance(result, dict)
    assert result == expected

# Generated at 2022-06-11 02:25:44.962098
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware(dict())
    dh = DarwinHardwareCollector()

    # Create mock for sysctl
    class MockedDarwinHardwareCollector(DarwinHardwareCollector):
        def __init__(self, *args, **kwargs):
            pass

        def get_sysctl(self, sysctl_names):
            sysctls = {
                "hw.logicalcpu": None,
                "hw.physicalcpu": None,
                "hw.model": None,
                "hw.ncpu": None,
                "machdep.cpu.brand_string": None,
                "machdep.cpu.core_count": None
            }
            return dict((k, v) for k, v in sysctls.items() if k in sysctl_names)

    # Use the mocked method instead of the real one

# Generated at 2022-06-11 02:25:55.700165
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    class ModuleMock:
        def __init__(self, run_command_result):
            self.run_command_result = run_command_result

        def run_command(self, command, encoding=None):
            return self.run_command_result

    # Test Intel
    module = ModuleMock(run_command_result=(0, "machdep.cpu.brand_string: Intel(R) Core(TM) i7-5775R CPU @ 3.30GHz", ""))
    test_case = DarwinHardware(module)
    cpu_facts = test_case.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-5775R CPU @ 3.30GHz'
    assert cpu_facts['processor_cores'] == '4'

# Generated at 2022-06-11 02:26:01.801282
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    # Get facts
    facts = DarwinHardware().get_mac_facts()

    # Assertions
    assert isinstance(facts, dict), "get_mac_facts() must return a dict"
    assert isinstance(facts['model'], str)
    assert isinstance(facts['osversion'], str)
    assert isinstance(facts['osrevision'], str)


# Generated at 2022-06-11 02:26:12.228999
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    This test case is to ensure that the hardware facts
    are extracted properly from Darwin operating system
    """

    def get_sample_output():

        # Sample output from command 'vm_stat'
        sample_output = """
Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                              172795.
Pages active:                            182684.
Pages inactive:                          269786.
Pages speculative:                        43921.
Pages wired down:                        111209.
Pages purgeable:                           3266.
""".strip()
        # split the string on lines
        sample_output = sample_output.splitlines()
        # Decode the byte string to unicode
        sample_output = [str(line) for line in sample_output]
        return sample_output


# Generated at 2022-06-11 02:26:25.947261
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test get_system_profile with a mock module,
    to ensure the method returns a dict as expected.
    """
    # Create a mock module
    test_module = AnsibleModule(argument_spec={})

    # Instantiate a DarwinHardware object
    hardware = DarwinHardware(module=test_module)

    mock_system_profile = """
Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro5,5
      Processor Name: Intel Core 2 Duo
      Processor Speed: 3.06 GHz
      Number of Processors: 1
      Total Number of Cores: 2
      L2 Cache: 3 MB
      Memory: 8 GB
      Bus Speed: 1.07 GHz
      Boot ROM Version: MBP55.00AC.B03
      SMC Version (system): 1.47f2
    """



# Generated at 2022-06-11 02:26:37.617410
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # The value returned by the memory_stats generator is a dictionary with keys corresponding to the
    # title of each column returned by vm_stat on the CLI.  The data itself are values in each column.
    # The following test simulates the memory_stats dictionary returned by the memory_stats generator
    # and then asserts the values returned by the get_memory_facts method.
    memory_stats = {
        'Pages wired down': '1000',
        'Pages active': '2000',
        'Pages inactive': '3000'
    }

    # Set the total memory to 9000MB so we can test the calculation of used memory.
    # The used memory calculation is the sum of the "Pages wired down", "Pages active",
    # and "Pages inactive" column values.
    hardware = DarwinHardware()

# Generated at 2022-06-11 02:26:47.520671
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Create a mock AnsibleModule object
    module = AnsibleModule()

    # Mock run_command
    rc = 0
    out = "hw.model: iMac10,1\n"
    err = ''
    module.run_command = Mock(return_value=(rc, out, err))

    # Create a DarwinHardware object
    darwin_obj = DarwinHardware(module)

    # Set attributes of DarwinHardware object
    darwin_obj.sysctl = {'kern.osversion': '17.5.0',
                         'kern.osrevision': '15F34'}

    # Get mac facts
    darwin_obj.get_mac_facts()
    assert darwin_obj.facts['model'] == 'iMac10,1'

# Generated at 2022-06-11 02:26:50.365144
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert DarwinHardwareCollector._platform == 'Darwin'
    assert DarwinHardwareCollector._fact_class == DarwinHardware
    collector = DarwinHardwareCollector()
    assert collector._platform == 'Darwin'
    assert collector._fact_class == DarwinHardware

# Generated at 2022-06-11 02:27:00.911223
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import os
    import tempfile
    darwin_hardware = DarwinHardware(None)

# Generated at 2022-06-11 02:27:42.446191
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj = DarwinHardwareCollector()
    assert isinstance(obj._fact_class, DarwinHardware)
    assert obj._fact_class.platform == 'Darwin'
    assert obj._platform == 'Darwin'

# Generated at 2022-06-11 02:27:52.580446
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    Test the get_uptime_facts method.
    """
    now = time.time()
    last_boottime = now - 314159  # 314159 seconds is 10 hours and 26 minutes

    def sysctl_stub(module, keys, check_rc=True):
        if 'kern.boottime' in keys:
            return {'kern.boottime': struct.pack('@L', int(last_boottime))}
        else:
            return {}

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(name='fake')
    module.run_command = lambda cmd: (0, '', '')

    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = sysctl_stub

    uptime_facts = darwin

# Generated at 2022-06-11 02:28:02.403071
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'machdep.cpu.brand_string' : 'Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz',
        'machdep.cpu.core_count' : '2'
    }
    hardware.module.run_command = lambda x: (0, '', '')

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_vcpus'] == '', cpu_facts
    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz'
    assert cpu_facts['processor_cores'] == '2'

# Generated at 2022-06-11 02:28:11.686302
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-11 02:28:15.356155
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = MagicMock()
    hardware = DarwinHardware(module)
    hardware.get_uptime_facts()

    assert module.get_bin_path.called
    assert module.run_command.called

# Generated at 2022-06-11 02:28:26.709935
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    Test the method get_memory_facts() of class DarwinHardware
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    memtotal = 1024 * 1024 * 1234
    # Memory stats with one value in every field
    memory_stats = {
        'Page size of 4096 bytes' : 4096,
        'Pages wired down' : 1,
        'Pages active' : 1,
        'Pages inactive' : 1,
        'Other' : 'string',
        'Pages free' : 1,
    }
    expected_memfree = memtotal / 1024 / 1024 - (memory_stats['Pages wired down'] +
                                                 memory_stats['Pages active'] +
                                                 memory_stats['Pages inactive']) * memory_stats['Page size of 4096 bytes'] / 1024 / 1024

    # Create a mock

# Generated at 2022-06-11 02:28:37.126077
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    import ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin

    facts_module = ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin.Hardware()
    facts_collector = FactsCollector(module=facts_module)
    facts_collector.collect()
    facts = facts_collector.get_facts()
    mac_facts = facts[DarwinHardware.platform]

    assert isinstance(mac_facts['osversion'], str)
    assert isinstance(mac_facts['osrevision'], str)
    assert isinstance(mac_facts['model'], str)
    assert mac_facts['model'] != ""


# Generated at 2022-06-11 02:28:45.557088
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class RunCommand:
        def __init__(self, returncode, out, err):
            self.returncode = returncode
            self.out = out
            self.err = err
        def run_command(self, cmd, encoding=None):
            return (self.returncode, self.out, self.err)


# Generated at 2022-06-11 02:28:48.048384
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwinHardwareCollector = DarwinHardwareCollector()
    assert darwinHardwareCollector.fact_class == DarwinHardware

# Generated at 2022-06-11 02:28:59.985530
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    test_module = FakeModule()
    test_class = DarwinHardware(module=test_module)

# Generated at 2022-06-11 02:30:39.973407
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-11 02:30:44.815237
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Note: This test is meant to be run manually.
    #       It will run forever unless you send an EOF to the test process
    #       when you are satisfied with the results.
    h = DarwinHardware()
    while True:
        facts = h.get_system_profile()
        print(facts)



# Generated at 2022-06-11 02:30:55.016723
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FactsParamsMock({
        'sysctl': {
            'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5675R CPU @ 3.10GHz',
            'hw.physicalcpu': '2',
            'hw.logicalcpu': '8',
            'hw.memsize': '8589934592',
            'kern.osversion': '16.7.0',
            'kern.osrevision': 'Darwin Kernel Version 16.7.0: Thu Jun 15 17:36:27 PDT 2017; root:xnu-3789.70.16~2/RELEASE_X86_64',
        },
    })
    hardware = DarwinHardware(module)
    cpu_facts = hardware.get_cpu_facts()


# Generated at 2022-06-11 02:31:04.591127
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    fact_module = DarwinHardware(module=None)

    # On Darwin, the default format is annoying to parse.
    # Use -b to get the raw value and decode it.
    sysctl_cmd = 'sysctl'
    cmd = [sysctl_cmd, '-b', 'kern.boottime']

    # We need to get raw bytes, not UTF-8.
    m = None
    rc, out, err = fact_module.module.run_command(cmd, encoding=None)

    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)

# Generated at 2022-06-11 02:31:16.138384
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """
    test get_memory_facts method of DarwinHardware class
    """

    # Unit test for DarwinHardware.get_memory_facts using /bin/sysctl
    sysctl_cmd = "/bin/sysctl"

# Generated at 2022-06-11 02:31:26.088750
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:31:34.668076
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware import DarwinHardware
    from ansible.module_utils.facts.sysctl import get_sysctl

    # Test Intel CPU
    module = MockModule()
    sysctl = dict()
    sysctl['machdep.cpu.brand_string'] = 'Intel(R) Xeon(R) CPU @ 2.30GHz'
    sysctl['machdep.cpu.core_count'] = '1'
    get_sysctl = lambda a1, a2: sysctl
    d_hardware = DarwinHardware(module)
    cpu_facts = d_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU @ 2.30GHz'
    assert cpu_facts['processor_cores'] == '1'

    # Test PowerPC

# Generated at 2022-06-11 02:31:36.769257
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Instantiation
    darwin_collector = DarwinHardwareCollector()
    assert darwin_collector

# Generated at 2022-06-11 02:31:43.429937
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mock_module = Mock()
    mock_module.run_command.return_value = 0, '''
Hardware:

    Hardware Overview:

      Model Name: Mac Pro
      Model Identifier: MacPro3,1
      Processor Name: Quad-Core Intel Xeon
      Processor Speed: 2.8 GHz
      Number of Processors: 1
      Total Number of Cores: 8
      L2 Cache (per Processor): 12 MB
      Memory: 16 GB
      Bus Speed: 1.6 GHz
      Boot ROM Version: MP31.006C.B05
      SMC Version (system): 1.25f4
      Serial Number (system): G8932052JGX
      Hardware UUID: 00000000-0000-1000-8000-000C298D6F3B

      Sudden Motion Sensor:
        State: Enabled
    ''', None
    darwin_

# Generated at 2022-06-11 02:31:45.671018
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_collector = DarwinHardwareCollector()
    assert darwin_collector._fact_class == DarwinHardware
    assert darwin_collector._platform == 'Darwin'