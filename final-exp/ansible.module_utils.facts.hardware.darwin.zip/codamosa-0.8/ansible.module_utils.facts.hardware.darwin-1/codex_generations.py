

# Generated at 2022-06-11 02:22:33.553498
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = type('', (), {})()
    module.run_commands = [
        type('', (), {'rc': 0, 'stdout': 'machdep.cpu.brand_string: Intel(R) Core(TM) i3-4150 CPU @ 3.50GHz', 'stderr': ''}),
        type('', (), {'rc': 0, 'stdout': 'hw.physicalcpu: 4', 'stderr': ''}),
        type('', (), {'rc': 0, 'stdout': 'hw.logicalcpu: 4', 'stderr': ''}),
        type('', (), {'rc': 0, 'stdout': 'hw.ncpu: 2', 'stderr': ''})
    ]
    module.run_command = lambda x: module.run_commands.pop(0)
    d

# Generated at 2022-06-11 02:22:46.307591
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test that DarwinHardware object returns a dict with expected keys and values
    when calling get_system_profile method.
    """
    class FakeModule(object):
        def __init__(self):
            self.run_command_args = []
            self.run_command_rcs = {
                tuple(): 0,
            }

# Generated at 2022-06-11 02:22:59.205316
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    fake_module = type('AnsibleModule', (object,), {'run_command': lambda self, x: ('', '    Serial Number (system): C02SNGS6FVH6\nHardware UUID: BDBF4B4B-8F86-59D3-AF71-1B2CA0E01BBA\n', ''), 'get_bin_path': lambda self, x: x, 'warn': lambda self, x: None})()
    obj = DarwinHardware(fake_module)
    expected = {'Serial Number (system)': 'C02SNGS6FVH6', 'Hardware UUID': 'BDBF4B4B-8F86-59D3-AF71-1B2CA0E01BBA'}
    assert obj.get_system_profile() == expected

# Generated at 2022-06-11 02:23:09.350227
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule:
        def run_command(self, cmd, encoding=None):
            # This is a little dangerous and brittle: it is based on the
            # `struct_format` and `struct_size` above.
            #
            # The first field of `kern.boottime` is the time since 1970-01-01 UTC.
            # Here, we return a value representing the time 17 years ago. If a
            # change of this date would affect the test, then this will break.
            #
            # For now, we can assume that 17 years from now, the unit test will be
            # fixed.
            out = struct.pack('@L', 17 * 365 * 24 * 60 * 60)
            return 0, out, ''

        def get_bin_path(self, cmd):
            return cmd

    module = MockModule()

    d

# Generated at 2022-06-11 02:23:15.968187
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule(object):
        @staticmethod
        def run_command(*args, **kwargs):
            return (0, b'kern.boottime: { sec = 1485707644, usec = 652418 }\n', '')
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/usr/sbin/sysctl'

    obj = DarwinHardware()
    obj.module = MockModule()

    assert obj.get_uptime_facts() == { 'uptime_seconds': int(time.time()) - 1485707644 }

# Generated at 2022-06-11 02:23:27.203634
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """This is a dummy test. Replace it with real tests."""
    assert DarwinHardwareCollector
    assert DarwinHardwareCollector.collect()
    assert DarwinHardwareCollector.collect().populate().platform == 'Darwin'
    assert DarwinHardwareCollector.collect().populate().model == 'iMacPro1,1'
    assert DarwinHardwareCollector.collect().populate().osversion == '16.11.0'
    assert DarwinHardwareCollector.collect().populate().osrevision == '19A583'
    assert DarwinHardwareCollector.collect().populate().processor == 'Intel(R) Xeon(R) W-2140B CPU @ 3.20GHz'
    assert DarwinHardwareCollector.collect().populate().processor_cores == '10'
    assert DarwinHardwareCollector.collect().populate().processor_vcpus == '20'


# Generated at 2022-06-11 02:23:38.713870
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    def get_module():
        module = Mock(name='module', spec_set=['run_command'])
        module.run_command.return_value = (
            0,
            """
            Mach Virtual Memory Statistics: (page size of 4096 bytes)
            Pages free:                             119267.
            Pages active:                            42890.
            Pages inactive:                          26466.
            Pages speculative:                         842.
            Pages throttled:                             0.
            Pages wired down:                          4668.
            """,
            None,
        )
        return module


# Generated at 2022-06-11 02:23:40.905825
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    test_hw = DarwinHardwareCollector()
    assert test_hw.platform == 'Darwin'

# Generated at 2022-06-11 02:23:51.524705
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)
    hardware.sysctl = dict()
    hardware.sysctl['kern.osversion'] = '15.x'
    hardware.sysctl['kern.osrevision'] = '42'
    rc, out, err = module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    if rc != 0:
        return dict()
    system_profile = dict()
    for line in out.splitlines():
        if ': ' in line:
            (key, value) = line.split(': ', 1)
            system_profile[key.strip()] = ' '.join(value.strip().split())

    results = dict()
    results['model'] = system_profile['Model Name']
    results['product_name']

# Generated at 2022-06-11 02:23:52.875959
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwinHardwareCollector = DarwinHardwareCollector()
    assert darwinHardwareCollector._platform == 'Darwin'

# Generated at 2022-06-11 02:24:13.423819
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, executable):
            return 'sysctl'

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    dh = DarwinHardware()
    dh.module = TestModule()


# Generated at 2022-06-11 02:24:22.923716
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-11 02:24:32.304045
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import time
    import unittest

    class TestModule(object):
        def __init__(self):
            class TestCommand(object):
                def __init__(self, returncode, stdout, stderr):
                    self.returncode = returncode
                    self.stdout = stdout
                    self.stderr = stderr

            self.run_command = lambda cmd, encoding: TestCommand(0, b'kern.boottime: {secs=1492458966, microsecs=320907}', b'')

        def get_bin_path(self, name):
            return name

    class TestDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module
            self.sysctl = dict()


# Generated at 2022-06-11 02:24:34.594284
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector.sysctl == None
    

# Generated at 2022-06-11 02:24:36.636174
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector.__class__.__name__ == 'DarwinHardwareCollector'

# Generated at 2022-06-11 02:24:45.326016
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class ModuleMock(object):
        def get_bin_path(self, path):
            return path

        def run_command(self, cmd, encoding=None):
            if cmd == ['sysctl', '-b', 'kern.boottime']:
                return 0, '\x00\x00\x00\x00\x00\x00\x00\x00', ''
            if cmd == ['uptime', '-l']:
                return 0, '', ''

    module = ModuleMock()
    dh = DarwinHardware(module)
    facts = dh.get_uptime_facts()
    assert facts['uptime_seconds'] == 0

# Generated at 2022-06-11 02:24:54.018148
# Unit test for method get_cpu_facts of class DarwinHardware

# Generated at 2022-06-11 02:25:03.359187
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # To get good performance, we want to avoid repeated regex searches
    def mock_get_bin_path(name):
        if name == 'vm_stat':
            return 'foo'
        raise ValueError()


# Generated at 2022-06-11 02:25:08.915132
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    facts = DarwinHardware()
    system_profile = facts.get_system_profile()
    assert system_profile['Machine Model'] == 'MacBook Pro'
    assert system_profile['Processor Name'] == 'Intel Core i5'
    assert system_profile['Processor Speed'] == '2.7 GHz'

# Generated at 2022-06-11 02:25:11.548171
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModule(argument_spec={})
    assert DarwinHardwareCollector(module, "Darwin").collect() is not None

# Generated at 2022-06-11 02:25:36.140266
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = type('', (), {'run_command': run_command})()
    hardware = DarwinHardware(module)
    facts = hardware.get_mac_facts()
    assert facts['model'] == 'MacBookPro6,2'
    assert facts['osversion'] == '16.7.0'
    assert facts['osrevision'] == '15R2014'



# Generated at 2022-06-11 02:25:43.072818
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():

    class MockModule(object):
        @staticmethod
        def run_command(command):
            return (0, '', '')

        @staticmethod
        def get_bin_path(*_, **__):
            return '/usr/sbin/vm_stat'

    facts = DarwinHardware(MockModule()).populate()

    assert facts['model'] == 'MacBookPro3,1'
    assert facts['processor'] is not None
    assert facts['processor_vcpus'] is not None
    assert facts['processor_cores'] is not None
    assert facts['memfree_mb'] >= 0
    assert facts['memtotal_mb'] >= 0
    assert facts['osversion'] is not None
    assert facts['osrevision'] is not None
    assert facts['uptime_seconds'] >= 0

# Generated at 2022-06-11 02:25:52.987948
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    module.run_command = MagicMock(return_value=(0, "hw.model: MacBookPro10,2\n", ""))
    module.params = {}

    hard_obj = DarwinHardware(module)
    hard_obj.sysctl = {
        'kern.osversion': '13.4.0',
        'kern.osrevision': 'Darwin Kernel Version 13.4.0: Wed Mar 18 16:20:14 PDT 2015; root:xnu-2422.115.4~1/RELEASE_X86_64'
    }

    result = hard_obj.get_mac_facts()
    assert result['model'] == 'MacBookPro10,2'
    assert result['osversion']

# Generated at 2022-06-11 02:26:04.197125
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    # create instance of the class we want to test
    darwin_hardware_facts = DarwinHardware()

    # mock the needed system calls
    darwin_hardware_facts.sysctl = {
        'hw.logicalcpu': '4',
        'hw.physicalcpu': '2',
        'machdep.cpu.core_count': '4',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5350U CPU @ 1.80GHz',
    }

    # run the method with whatever parameters you want to test
    cpu_facts = darwin_hardware_facts.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-5350U CPU @ 1.80GHz'

# Generated at 2022-06-11 02:26:08.644406
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    mac_facts = DarwinHardware().get_mac_facts()
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts
    assert 'model' in mac_facts

# Generated at 2022-06-11 02:26:16.958203
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec = dict())
    hardware = DarwinHardware(module)
    hardware.sysctl = {'hw.memsize': str(42)}
    hardware.get_bin_path = lambda _: '/usr/bin/vm_stat'

# Generated at 2022-06-11 02:26:21.567960
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock({})
    darwin_hw = DarwinHardware(module)
    facts_result = darwin_hw.populate()

    assert 'osrevision' in facts_result
    assert 'osversion' in facts_result


# Generated at 2022-06-11 02:26:34.016346
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    DarwinHardware_instance = DarwinHardware()
    # Test with result of 'sysctl hw.model' command
    DarwinHardware_instance.sysctl = dict()
    DarwinHardware_instance.sysctl['kern.osversion'] = '16.4.0'
    DarwinHardware_instance.sysctl['kern.osrevision'] = '20E261'
    mac_facts = DarwinHardware_instance._get_mac_facts()
    assert mac_facts['osversion'] == '16.4.0'
    assert mac_facts['osrevision'] == '20E261'

    # Test with empty result of 'sysctl hw.model' command
    DarwinHardware_instance.sysctl = dict()
    DarwinHardware_instance.sysctl['kern.osversion'] = '16.4.0'

# Generated at 2022-06-11 02:26:37.472750
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert issubclass(DarwinHardwareCollector, HardwareCollector)
    assert DarwinHardwareCollector._platform == 'Darwin'
    assert DarwinHardwareCollector._fact_class == DarwinHardware


# Generated at 2022-06-11 02:26:47.356728
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import get_module_args, get_sys_platform

    # Mock the module
    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Mock the module command
    class MockRunCommand():
        def __init__(self):
            self.rc = 0
            self.out = struct.pack('@L', time.time())
            self.err = ''
            self.encoding = 'utf-8'
    module.run_command = MockRunCommand().run_command

    # Define the facts object
    facts = DarwinHardware()
    # The get_uptime_facts method returns a dictionary

# Generated at 2022-06-11 02:27:40.590056
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )

    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None):
        class ProcessResult():
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err

# Generated at 2022-06-11 02:27:44.381018
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    memory_facts = DarwinHardware._get_memory_facts()
    assert isinstance(memory_facts, dict)
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert isinstance(memory_facts['memtotal_mb'], int)
    assert isinstance(memory_facts['memfree_mb'], int)


# Generated at 2022-06-11 02:27:54.523361
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils._text import to_bytes

    fake_system_profiler = """
Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro7,1
      Processor Name: Intel Core 2 Duo
      Processor Speed: 2.4 GHz
      Number of Processors: 1
      Total Number of Cores: 2
      L2 Cache: 3 MB
      Memory: 4 GB
      Bus Speed: 1.07 GHz
      Boot ROM Version: MBP71.0039.B0E
      SMC Version (system): 1.57f16
      Serial Number (system): W88401231TY
      Hardware UUID: 00000000-0000-1000-8000-0016CB926E34
    """

    hardware = DarwinHardware()
    hardware.module = MockModule()

# Generated at 2022-06-11 02:27:57.727082
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwinHardwareCollector = DarwinHardwareCollector()
    assert isinstance(darwinHardwareCollector, HardwareCollector)
    assert darwinHardwareCollector.platform == 'Darwin'
    assert darwinHardwareCollector._fact_class == DarwinHardware

# Generated at 2022-06-11 02:28:00.619476
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    hardware = DarwinHardware(dict())
    system_profile = hardware.get_system_profile()
    assert system_profile['Model Name'].startswith("MacBook Pro")


# Generated at 2022-06-11 02:28:08.889135
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class ModuleMock(object):
        def __init__(self, *args, **kwargs):
            pass

        def run_command(self, cmd, encoding=None):
            return (0, b'\xa2\x12\x15\x00\x00\x00\x00\x00', b'fake error')

    class DarwinHardwareMock(DarwinHardware):
        def __init__(self, *args, **kwargs):
            self.module = ModuleMock()

    uptime_facts = DarwinHardwareMock().get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 33545

# Generated at 2022-06-11 02:28:21.782778
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Create instance of DarwinHardware class
    test_class = DarwinHardware({})

    # Create dictionary of sample return values from command `vm_stat`
    sample_return_values = dict()
    sample_return_values['Pages wired down'] = '1723347'
    sample_return_values['Pages active'] = '1748046'
    sample_return_values['Pages inactive'] = '132582'
    sample_return_values['Pages free'] = '267025'

    # Monkey patch method `run_command`
    test_class.run_command = lambda command: (0, str(sample_return_values), None)

    # Create dictionary of sample sysctl values for `hw.memsize` and `hw.physicalcpu`
    sample_

# Generated at 2022-06-11 02:28:33.076295
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import sys
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware


# Generated at 2022-06-11 02:28:39.752020
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, "hw.model: iMac18,1", ""))
            self.get_bin_path = Mock(return_value="/usr/sbin/system_profiler")
    mock_module = MockModule()

    facts = DarwinHardware(mock_module).populate()

    assert facts['product_name'] == 'iMac18,1'
    assert facts['osversion'] == '19.6.0'
    assert facts['osrevision'] == '19G73'


# Generated at 2022-06-11 02:28:52.645911
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """ Test memtotal_mb and memfree_mb using example vm_stat output """

    import textwrap


# Generated at 2022-06-11 02:30:30.392716
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # Create a DarwinHardware object to test
    os = DarwinHardware(None)

    # A minimum example of output for the command "sysctl -b kern.boottime"
    # On Darwin, the default format is annoying to parse.
    # Use -b to get the raw value and decode it.
    # We need to get raw bytes, not UTF-8.
    darwin_boottime = b'{\n   sec = 0x5ebdf741;\n   usec = 0x2b38;\n}'

    # We expect the value of the dictionary returned by get_uptime_facts to be
    # the result of the difference between time.time() and the kern.boottime
    # value encoded in the raw output of "sysctl -b

# Generated at 2022-06-11 02:30:40.081337
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    module_name = 'ansible.module_utils.facts.hardware.darwin'
    module = __import__(module_name)
    facts_obj = module.DarwinHardware()
    assert facts_obj.populate()['model'] == 'MacBookPro3,1'
    # wrong sysctl key
    assert module.get_sysctl(facts_obj.module, ['machdep.cpu.brand_string']) == ''

# Generated at 2022-06-11 02:30:44.069906
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    facts = DarwinHardware()
    facts_output = {'processor': '', 'processor_cores': '', 'processor_vcpus': ''}
    assert(facts.get_cpu_facts() == facts_output)


# Generated at 2022-06-11 02:30:48.141035
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mock_module = MagicMock()
    mock_module.run_command.return_value = 0, "fake_out", "fake_err"
    mock_module.run_command.side_effect = [
        (0, "fake_out", "fake_err"),
        (0, "fake_out", "fake_err"),
        (0, "fake_out", "fake_err"),
        (0, "fake_out", "fake_err"),
        (0, "fake_out", "fake_err"),
    ]
    hardware = DarwinHardware()
    hardware.module = mock_module
    hardware.get_system_profile()
    mock_module.run_command.assert_has_calls(
        [call(['/usr/sbin/system_profiler', 'SPHardwareDataType'])]
    )

# Generated at 2022-06-11 02:30:57.259555
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class DarwinHardware(Hardware):
        def get_uptime_facts(self):
            return self._get_uptime_facts()

    class StubModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'

        def run_command(self, arg, **kwargs):
            if arg[0] != '/usr/bin/sysctl':
                raise Exception('Invalid call to run_command')
            self.run_command_calls.append(arg)
            return (0, 'kern.boottime = 1478545254')

    dh = DarwinHardware(module=StubModule())
    uptime_facts = dh.get_uptime_facts()

# Generated at 2022-06-11 02:30:57.854625
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-11 02:31:06.353884
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = mock.MagicMock()
    hardware = DarwinHardware(module=module)
    module.run_command.return_value = (1, '', '')
    result = hardware.get_system_profile()
    assert result == dict()

    module.run_command.return_value = (0, 'foo', '')
    result = hardware.get_system_profile()
    assert result == dict()

    module.run_command.return_value = (0, 'Processor Name: Intel Core\nProcessor Speed: 2.30 GHz\n', '')
    result = hardware.get_system_profile()
    assert result == {'Processor Name': 'Intel Core', 'Processor Speed': '2.30 GHz'}

    # Testing with a trailing dot

# Generated at 2022-06-11 02:31:16.622471
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    collected_facts = {
        'ansible_local': {
            'sysctl': {
                'hw.memsize': '1234567890',
                'hw.physicalcpu': '2',
                'kern.boottime': '1.2.3.4',
                'kern.osrevision': '1234567890',
                'kern.osversion': '1.2.3.4'
            }
        }
    }
    h = DarwinHardware()
    h.module = MockModule()
    h.module.run_command.return_value = (0, 'Intel', None)

    h.populate(collected_facts=collected_facts)


# Generated at 2022-06-11 02:31:26.499321
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={'module_setup': {'no_log': True}}, supports_check_mode=False)
    mac_facts = DarwinHardware(module=module)

    # The actual value we get from the system is not easily reproduced
    # We'll use this hack instead to avoid re-compiling the kernel
    # each time the unit test is run.
    mac_facts.sysctl = dict()
    mac_facts.sysctl['kern.boottime'] = b'\x01\x3f\x58\x68\x84\x86\x0a\x02\x00\x00\x00\x00\x00\x00\x00\x00'

    uptime_facts = mac_facts.get_uptime_facts()


# Generated at 2022-06-11 02:31:33.547881
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    system_profile = DarwinHardware.get_system_profile(None)
    assert 'Hardware Overview' in system_profile
    assert 'Hardware UUID' in system_profile
    assert 'Model Name' in system_profile
    assert 'System Version' in system_profile
    assert 'Processor Name' in system_profile
    assert 'Processor Speed' in system_profile
    assert 'Boot ROM Version' in system_profile
    assert 'Serial Number' in system_profile
    assert 'SMC Version' in system_profile
    assert 'Memory' in system_profile
    assert 'System Report' in system_profile
