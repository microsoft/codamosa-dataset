

# Generated at 2022-06-11 02:22:31.742661
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-11 02:22:39.944742
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    test_ansible_facts = ansible_facts()
    test_module = type('AnsibleModule', (object,), dict(params={},
                                                        fail_json=lambda x: exit(1),
                                                        check_mode=False,
                                                        get_bin_path=get_bin_path))
    test_sysctl = type('Sysctl', (object,), dict(boottime=b'\x01\x02'))

    test_hardware = DarwinHardware(test_module, test_sysctl)

    test_uptime_facts = test_hardware.get_uptime_facts()

   

# Generated at 2022-06-11 02:22:50.096164
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module_mock = MockModule()
    fact_class_mock = DarwinHardware(module_mock)
    fact_class_mock.sysctl['hw.memsize'] = "16777216"

# Generated at 2022-06-11 02:23:01.450343
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    test_obj = DarwinHardware(module)
    test_obj._cpu_facts_from_proc_cpuinfo = None
    test_obj._sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-8259U CPU @ 2.30GHz'}
    test_obj._sysctl['hw.logicalcpu'] = 4
    test_obj._sysctl['hw.physicalcpu'] = 2
    test_obj._sysctl['hw.ncpu'] = 8
    test_obj._sysctl['machdep.cpu.core_count'] = 2
    cpu_facts = test_obj.get_cpu_facts()

# Generated at 2022-06-11 02:23:06.006454
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = MockModule()
    hardware = DarwinHardware(module)
    hardware.get_uptime_facts = MagicMock(return_value={"uptime_seconds": 172800})
    assert hardware.get_uptime_facts()["uptime_seconds"] == 172800

# Generated at 2022-06-11 02:23:15.405466
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware = {
        "model" : "MacBookPro8,2",
        "processor" : "Intel Core i7",
        "processor_cores" : 4,
        "processor_vcpus" : 4,
        "memtotal_mb" : 4096,
        "memfree_mb" : 2048,
        "osversion" : "14.5.0",
        "osrevision" : "11",
        "uptime_seconds" : 178329,
    }
    darwin_hw = DarwinHardwareCollector(None)
    facts = darwin_hw.collect(hardware)
    for k, v in facts.items():
        assert v == hardware[k]

# Generated at 2022-06-11 02:23:17.601858
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x.platform == "Darwin"
    assert isinstance(x._fact_class, DarwinHardware)

# Generated at 2022-06-11 02:23:28.430951
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule:
        def __init__(self):
            self.run_command_args = None

        def get_bin_path(self, _):
            return '/bin/sysctl'

        def run_command(self, args, encoding=None):
            self.run_command_args = args
            return 0, struct.pack('@L', 100), ''

    class MockTime:
        # We fake that time.time() returned 101 (which is 1 second after
        # kern.boottime)
        def __init__(self):
            self.current_time = 101

        def time(self):
            return self.current_time

    class MockStruct:
        def calcsize(self, format):
            return 8

        def unpack(self, format, string):
            return (100, )

    darwin

# Generated at 2022-06-11 02:23:38.573103
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    hardware = DarwinHardware(None)
    hardware.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2660 0 @ 2.20GHz'}
    hardware.sysctl['machdep.cpu.core_count'] = '4'
    cpu_info = hardware.get_cpu_facts()
    assert cpu_info == {'processor': 'Intel(R) Xeon(R) CPU E5-2660 0 @ 2.20GHz', 'processor_cores': '4', 'processor_vcpus': ''}



# Generated at 2022-06-11 02:23:49.985300
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mock_module = Mock()
    mock_module.run_command = Mock()

# Generated at 2022-06-11 02:24:09.980835
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import unittest

    class MockRunCommand(object):
        def __init__(self):
            self.kern_boottime = 1498999812
            self.boottime_struct = struct.pack('@L', self.kern_boottime)
            self.boottime_with_extra_data = self.boottime_struct + b'extra_data'
            self.boottime_invalid_len = b'extra_data'

        def __call__(self, cmd, encoding=None):
            sysctlname = cmd[-1]
            if 'kern.boottime' == sysctlname:
                return 0, self.boottime_with_extra_data, None


# Generated at 2022-06-11 02:24:12.216571
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Test an empty class
    DarwinHardwareCollector()

# vim: et ts=4 sw=4

# Generated at 2022-06-11 02:24:12.820986
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-11 02:24:16.757007
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec={},
    )

    darwin_hardware = DarwinHardware(module)
    darwin_hardware.populate()
    assert darwin_hardware.sysctl['hw.model'] == 'MacBookAir5,2'

# Generated at 2022-06-11 02:24:24.684194
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware = DarwinHardware(dict())
    hardware.sysctl = {'kern.osversion': '1.2.3.4',
                       'kern.osrevision': '87.6'}
    rc1 = 0
    out1 = "hw.model: MacBookPro12,1\n"
    err1 = ""
    hardware.module.run_command = lambda x: (rc1, out1, err1)
    hardware.get_mac_facts()
    assert hardware.facts['model'] == 'MacBookPro12,1'
    assert hardware.facts['product_name'] == 'MacBookPro12,1'
    assert hardware.facts['osversion'] == '1.2.3.4'
    assert hardware.facts['osrevision'] == '87.6'



# Generated at 2022-06-11 02:24:35.977352
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:24:46.498237
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts import hardware

    hardware.collector = hardware.get_collector('DarwinHardwareCollector')
    hardware.collector._module = FakeModule()
    hardware.collector._module.run_command = FakeRunCommand()
    hw = hardware.collector.collect()

    assert hw['processor'] == 'i386'
    assert hw['processor_cores'] == '4'
    assert hw['memtotal_mb'] == '256'
    assert hw['memfree_mb'] == '64'
    assert hw['model'] == 'MacBookPro'
    assert hw['osversion'] == '12.0.0'
    assert hw['osrevision'] == 'Darwin Kernel Version 12.0.0'

# Generated at 2022-06-11 02:24:52.792868
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.get_bin_path = fake_get_bin_path
    module.run_command = fake_run_command

    hardware_object = DarwinHardware(module)
    cpu_facts = hardware_object.get_cpu_facts()

    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2660 v2 @ 2.20GHz'
    assert cpu_facts['processor_cores'] == 12
    assert cpu_facts['processor_vcpus'] == 24



# Generated at 2022-06-11 02:25:02.762886
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test the value of get_system_profile of class DarwinHardware
    """
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.system import System
    from ansible.module_utils.facts.utils import get_file_lines

    # Prepare the input for the method get_system_profile
    command_output = get_file_lines('./test/unit/module_utils/facts/hardware/resources/DarwinSystemProfile.txt')[:-1]

    # Unit test
    system_profile = DarwinHardware.get_system_profile(System(), command_output)

    # Verify that the result matches the expected dictionary

# Generated at 2022-06-11 02:25:07.978196
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware(None)

    import os
    os.environ['ansible_system_vendor'] = 'apple'
    hardware.module = type('', (), {})()

    def run_command_mock(command):
        output = '\n'
        output += 'Mach Virtual Memory Statistics: (page size of 4096 bytes)\n'
        output += 'Pages free:                             1390.\n'
        output += 'Pages active:                          20732.\n'
        output += 'Pages inactive:                        18591.\n'
        output += 'Pages speculative:                       586.\n'
        output += 'Pages wired down:                       4114.\n'
        output += 'Pages purgeable:                          38.\n'
        output += '"Translation faults":                 274622.\n'

# Generated at 2022-06-11 02:25:30.132358
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils.test_utils import import_test_module

    test_module = import_test_module('ansible.module_utils.facts.hardware.darwin')

    test_facts = {
        # test data taken from https://en.wikipedia.org/wiki/MacBook_Air
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-2677M CPU @ 1.80GHz',
        'machdep.cpu.core_count': '2',
        'hw.physicalcpu': '2',
        'hw.logicalcpu': '4'
    }


# Generated at 2022-06-11 02:25:31.738420
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector._platform == 'Darwin'
    assert collector._fact_class == DarwinHardware

# Generated at 2022-06-11 02:25:40.369178
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule:
        def get_bin_path(self, name, required=False):
            return '/usr/sbin/sysctl'

        def run_command(self, cmd, encoding=None):
            return 0, b'{ kern.boottime: { sec: %d, usec: 0 } }' % (time.time() - 144,), ''

    # The test runs on a host with 100 days of uptime, but it does not matter
    # much because we are only testing the parsing of the raw kern.boottime
    # value.
    test_module = TestModule()
    darwin_hw = DarwinHardware(module=test_module)
    uptime_facts = darwin_hw.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 12960000

# Generated at 2022-06-11 02:25:45.316341
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    modmock = MockModule()
    modmock.run_command = Mock(return_value=(0, "hw.model: MacBookPro7,1\n", ""))
    darwin_hardware = DarwinHardware(modmock)
    facts = darwin_hardware.get_mac_facts()
    assert facts == {'model': 'MacBookPro7,1',
                     'osversion': '19.3.0',
                     'osrevision': '19D76'}


# Generated at 2022-06-11 02:25:48.889614
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    obj = DarwinHardware()
    facts = obj.get_memory_facts()
    assert facts['memtotal_mb'] >= 0
    assert facts['memfree_mb'] >= 0
    assert facts['memtotal_mb'] >= facts['memfree_mb']

# Generated at 2022-06-11 02:26:00.598230
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    fixture = {
        'kern.osversion': '12.5.0',
        'kern.osrevision': '15F34',
        'sysctl_path': 'sysctl',
        'hw.model': 'MacBookPro12,1'
    }
    hardware_test_obj = DarwinHardware(None)
    hardware_test_obj.sysctl = fixture
    mac_facts = hardware_test_obj.get_mac_facts()
    assert 'osversion' in mac_facts and mac_facts['osversion'] == '12.5.0'
    assert 'osrevision' in mac_facts and mac_facts['osrevision'] == '15F34'
    assert 'model' in mac_facts and mac_facts['model'] == 'MacBookPro12,1'
    assert 'product_name' in mac_

# Generated at 2022-06-11 02:26:06.070607
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    platform = DarwinHardware()

    # We can't use time.time() because it's a floating point number
    # and we need to compare the result of uptime_seconds as an integer.
    now = int(time.mktime(time.localtime()))
    facts = platform.populate()
    assert facts['uptime_seconds'] <= now
    assert facts['uptime_seconds'] > now - 120

    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] < facts['memtotal_mb']

# Generated at 2022-06-11 02:26:16.041847
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    dh = DarwinHardware()
    dh.module = module
    dh.sysctl = {
        'hw.memsize': '16441671680',
        'kern.osversion': '16.0.0',
        'hw.physicalcpu': '2',
        'hw.logicalcpu': '4',
        'kern.osrevision': '16.0.0.0.0',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-3615QM CPU @ 2.30GHz',
        'machdep.cpu.core_count': '4'
    }


# Generated at 2022-06-11 02:26:28.744239
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import json

    # Intel
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-7267U CPU @ 3.10GHz',
        'machdep.cpu.core_count': 2,
        'machdep.cpu.thread_count': 4,
    }
    h = DarwinHardware({'run_command': lambda *_: [0, json.dumps(sysctl), '']}, mock=True)
    assert h.get_cpu_facts() == {
        'processor': 'Intel(R) Core(TM) i5-7267U CPU @ 3.10GHz',
        'processor_cores': 2,
        'processor_vcpus': 4,
    }

    # PowerPC

# Generated at 2022-06-11 02:26:39.836259
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # pylint: disable=too-few-public-methods
    class MockModule:
        """
        Mock of AnsibleModule
        """
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return '/usr/sbin/sysctl'

        def run_command(self, command, encoding=None, errors='strict', binary=False):
            if command == ['/usr/sbin/sysctl', '-b', 'kern.boottime']:
                return 0, struct.pack('@L', 1510828856), ''
            return 127, '', ''

    module = MockModule({})
    hardware = DarwinHardware

# Generated at 2022-06-11 02:27:07.071867
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule({})
    hardware = DarwinHardware(module)
    timedelta = datetime.timedelta(seconds=hardware.get_uptime_facts()["uptime_seconds"])
    module.exit_json(up=timedelta.days * 24 * 3600 + timedelta.seconds)


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    hardware = DarwinHardware(module)
    timedelta = datetime.timedelta(seconds=hardware.get_uptime_facts()["uptime_seconds"])
    module.exit_json(up=timedelta.days * 24 * 3600 + timedelta.seconds)

# Generated at 2022-06-11 02:27:18.584473
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    input_vmstat_output = """\
Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                               4737.
Pages active:                            14837.
Pages inactive:                          27413.
Pages speculative:                        1652.
Pages wired down:                        23170.
Pages purgeable:                            89.
"Translation faults":                    68829.
Pages copy-on-write:                     91789.
Pages zero filled:                     3389707.
Pages reactivated:                         684.
Pageins:                                 61480.
Pageouts:                                  336.
Object cache: 42525 hits of 211645 lookups (20% hit rate)
"""
    memory_stat = {
        'Pages wired down': 23170,
        'Pages active': 14837,
        'Pages inactive': 27413,
    }
    dar

# Generated at 2022-06-11 02:27:29.766734
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = get_module_mock()
    darwin = DarwinHardware(module)


# Generated at 2022-06-11 02:27:40.511204
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.facts import collector


# Generated at 2022-06-11 02:27:47.378214
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = type('MockModule', (object,), dict(run_command=MockRunCommand, get_bin_path=lambda path: path))()
    h = DarwinHardware(module)
    h.sysctl = {'hw.model': 'MacPro5,1',
                'hw.physicalcpu': '4',
                'hw.logicalcpu': '4',
                'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'}
    result = h.get_cpu_facts()
    assert result['processor'] == 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'
    assert result['processor_cores'] == '4'
    assert result['processor_vcpus'] == '4'
    # Test the P

# Generated at 2022-06-11 02:27:55.161786
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz', '')
    module.get_bin_path.side_effect = lambda x: x
    module.params = {'gather_subset': ['all']}
    dx = DarwinHardware(module)
    facts = dx.get_cpu_facts()
    assert facts == {'processor': 'Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz', 'processor_cores': '2', 'processor_vcpus': ''}, facts

# Generated at 2022-06-11 02:28:05.560027
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import unittest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class DarwinHardwareTestCase(unittest.TestCase):
        def setUp(self):
            from ansible.module_utils.facts import ModuleFactCollector
            from ansible.module_utils.facts.hardware.darwin import DarwinHardware

            class module(object):
                def get_bin_path(self, executable):
                    return '/usr/bin/vm_stat'


# Generated at 2022-06-11 02:28:13.358233
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.hardware.darwin import Hardware
    module = type('module', (object,), {'run_command': test_run_command, 'params': {'gather_subset': 'all'}})
    obj = Hardware(module)
    obj.populate()
    assert obj.sysctl == {
        'hw': {},
        'machdep': {},
        'kern': {
            'osrevision': '15G31',
            'osversion': '15.6.0',
        },
    }

# Generated at 2022-06-11 02:28:24.910893
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    truth = {'memfree_mb': 2124,
             'memtotal_mb': 8126}

    test = DarwinHardware(None)

    # mock up the system info
    test.sysctl = {
        'hw.memsize': '8589934592',
        'hw.physicalcpu': '4',
        'hw.logicalcpu': '8',
        'hw.memsize': '8589934592'}

    # mock up the vm_stat output and command rc

# Generated at 2022-06-11 02:28:26.047693
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj = DarwinHardwareCollector()

# Generated at 2022-06-11 02:29:08.102313
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock({})
    hardware = DarwinHardware(module)
    hardware.populate()
    assert hasattr(hardware, "sysctl")
    assert hasattr(hardware, "model")
    assert hasattr(hardware, "osversion")
    assert hasattr(hardware, "osrevision")


# Generated at 2022-06-11 02:29:10.207331
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hw = DarwinHardware()
    assert isinstance(darwin_hw.get_system_profile(), dict)

# Generated at 2022-06-11 02:29:16.097871
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    hardware_facts = DarwinHardware().populate()

    assert 'model' in hardware_facts
    assert 'osversion' in hardware_facts
    assert 'osrevision' in hardware_facts
    assert 'processor' in hardware_facts
    assert 'processor_cores' in hardware_facts
    assert 'processor_vcpus' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'memfree_mb' in hardware_facts



# Generated at 2022-06-11 02:29:18.670469
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    '''
    Test for creating an instance of class DarwinHardwareCollector
    '''
    dhc = DarwinHardwareCollector()

    assert dhc._platform == 'Darwin'

# Generated at 2022-06-11 02:29:28.264735
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    # Create a module object
    module = basic.AnsibleModule(argument_spec=dict())
    options = module.params
    # Create a DarwinHardware object and set the proper sysctl structure
    hw = DarwinHardware(module, options)
    # Set a sysctl like the one returned by get_sysctl()
    hw.sysctl = {
        'hw.memsize': '4294967296'
    }
    # Set a vm_stat command that returns the expected output

# Generated at 2022-06-11 02:29:33.159389
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    # get_system_profile is not mocked here, to test real functionality in the system
    hardware = DarwinHardware(None)
    assert isinstance(hardware.get_system_profile(), dict)


# Generated at 2022-06-11 02:29:38.570350
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hostname = '127.0.0.1'
    remote_user = 'root'
    module_factory = None
    ansible_connection = 'local'
    collector = DarwinHardwareCollector(module_factory, ansible_connection, hostname, remote_user)
    assert collector._platform == 'Darwin'
    assert collector._fact_class == DarwinHardware


# Generated at 2022-06-11 02:29:44.671745
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mac_facts = DarwinHardware().get_system_profile()

# Generated at 2022-06-11 02:29:52.479178
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # import only for unit test
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector, VirtualMachineError
    from ansible.module_utils.facts.network.base import Network

    # mock ansible module
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.vboxmanage import VBoxManage
    from ansible.module_utils.facts.virtual.sysctl import Sysctl

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    fact_classes = {
        'virtual': Virtual,
        'network': Network,
    }
    fact_collectors = {
        'virtual': VirtualCollector,
        'network': Network,
    }


# Generated at 2022-06-11 02:30:01.061652
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)

    rc, out, err = module.run_command("dmesg | grep 'Darwin Kernel Version'")
    if rc != 0:
        raise Exception('Unable to determine macOS version. Is this a macOS host?')
    osversion = out.split()[3]
    osrevision = out.split()[4]

    model = 'MacBookPro11,4'
    sysctl = {
        'kern.osversion': osversion,
        'kern.osrevision': osrevision,
    }

    # Mock sysctl module
    def mock_get_sysctl(module, key=None):
        if key:
            return sysctl[key]
        return sysctl


# Generated at 2022-06-11 02:31:46.429070
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert 'DarwinHardwareCollector' == d.__class__.__name__
    assert d._fact_class == DarwinHardware


# Generated at 2022-06-11 02:31:49.068758
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    '''
    Unit test for constructor of class DarwinHardwareCollector
    '''
    # Test idempotence
    DarwinHardwareCollector()
    DarwinHardwareCollector()

# Generated at 2022-06-11 02:31:51.174671
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x
    assert x._fact_class.platform == 'Darwin'

# Generated at 2022-06-11 02:31:58.425150
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.facts.collector import TestCollector
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(default=[], required=False)),
        supports_check_mode=True)

    set_module_args({})

    tc = TestCollector(
        module=module,
        class_path="ansible.module_utils.facts.hardware.darwin.DarwinHardware")
    result = tc.populate()
    assert 'processor' in result
    assert 'model' in result
    assert 'osversion' in result



# Generated at 2022-06-11 02:32:09.394890
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts import get_module_facts

    def mock_module():
        mock_module = MagicMock()

        class MockModule(object):
            def __init__(self):
                self.run_command = mock_module

            def get_bin_path(self, name):
                return name

        return MockModule()

    # Intel - mock hw.model, machdep.cpu.brand_string and machdep.cpu.core_count
    module = mock_module()