

# Generated at 2022-06-11 02:22:30.749703
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """This method is used by the unit test framework to
    validate the results of get_cpu_facts
    """
    (rc, out, err) = (0, "hw.model: x86_64\n", "")
    module = FakeAnsibleModule(rc, out, err)
    hw = DarwinHardware(module)
    hw.get_sysctl = lambda: {'machdep.cpu.brand_string': 'Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz'}
    result = hw.get_cpu_facts()
    assert (result['processor'] == 'Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz')
    assert (result['processor_cores'] == 1)

# Generated at 2022-06-11 02:22:36.254657
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a new instance of DarwinHardware
    hardware = DarwinHardware({})
    # Call the get_system_profile method
    system_profile = hardware.get_system_profile()

    # Assert that the method return type is a dictionary
    assert(isinstance(system_profile, dict))
    # Assert that the dictionary contains some keys
    assert('Model Name' in system_profile)
    assert('Processor Name' in system_profile)


# Generated at 2022-06-11 02:22:48.210272
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    system = DarwinHardware()
    import datetime
    from dateutil.parser import parse
    # we calculate the "correct" boottime in the same way we do it in
    # DarwinHardware.get_uptime_facts()
    now = datetime.datetime.utcnow()
    kern_boottime = int(now.timestamp())
    with_utc_timezone = parse(now.isoformat())
    boottime = with_utc_timezone
    # now we can calculate the uptime
    uptime_seconds = int((now - boottime).total_seconds())
    # this is the same calulation done in DarwinHardware.get_uptime_facts()
    assert system.get_uptime_facts()['uptime_seconds'] == upt

# Generated at 2022-06-11 02:23:00.263328
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = MagicMock(return_value=(0, "/usr/bin/vm_stat\n", ""))
    sysctl = {
        'hw.memsize': '8589934592',
        'hw.physicalcpu': '4',
        'kern.osrevision': '15',
        'kern.osversion': '15.0.0',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz',
        'machdep.cpu.core_count': '2',
        'hw.logicalcpu': '4',
    }
    hardware = DarwinHardware(module, sysctl)

# Generated at 2022-06-11 02:23:10.208380
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import stat
    import tempfile


# Generated at 2022-06-11 02:23:19.118194
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # We need to decode bytes to get the first field.
    import os
    import sys

    class ModuleDummy:
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/usr/sbin/sysctl'

        @staticmethod
        def run_command(*args, **kwargs):
            # We need to decode bytes to get the first field.
            encoding = kwargs.get('encoding')
            if encoding is None:
                encoding = sys.stdin.encoding
            return (0, os.urandom(16), '')

    class HardwareDummy(Hardware):
        def __init__(self, module_dummy):
            self.module = module_dummy

    # Check that the first field is an integer

# Generated at 2022-06-11 02:23:29.633117
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """Unit test for method get_system_profile of class DarwinHardware"""
    import ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin
    import tempfile
    system_profile = {
        'Processor Name': 'i7',
        'Processor Speed': '2.2GHz'
    }
    test_fh = tempfile.NamedTemporaryFile()

# Generated at 2022-06-11 02:23:40.723531
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeModule()
    hardware = DarwinHardware(module)

    # Test with a valid output

# Generated at 2022-06-11 02:23:51.418957
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create an instance of DarwinHardware
    darwin_hardware = DarwinHardware()

    # Create a fake class to fake the module
    class FakeModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '/usr/sbin/' + name

        def run_command(self, command, encoding=None):
            raw_string = struct.pack('@L', 1462741381)
            bytes = raw_string[:4]
            return 0, bytes, None

    # Set the fake module to the fake class
    darwin_hardware.module = FakeModule

    # Try to execute the get_uptime_facts method
    uptime_facts = darwin_hardware.get_uptime_facts

# Generated at 2022-06-11 02:24:00.216628
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'uptime_seconds' in facts
    assert 'product_name' in facts

# Generated at 2022-06-11 02:24:19.602942
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils import basic
    darwin_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    dh = DarwinHardware(darwin_module)

    rc, out, err = darwin_module.run_command(["/usr/sbin/system_profiler", "SPHardwareDataType"])
    if rc != 0:
        raise Exception('Could not get system_profiler information on this platform')

    if ': ' in out:
        (key, value) = out.split(': ', 1)
        if key.strip() == 'Model Identifier':
            assert dh.get_mac_facts()['model'] == value.strip()

# Generated at 2022-06-11 02:24:24.070150
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    dhwc = DarwinHardwareCollector()

    assert dhwc.platform == 'Darwin'
    assert dhwc._fact_class.platform == 'Darwin'
    assert dhwc.collect() == dict()
    assert dhwc._fact_class().populate(dict()) == dict()

# Generated at 2022-06-11 02:24:33.057596
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = Gallimaufry()
    module.run_command = MagicMock(return_value=(0, 'hw.model: Intel(R) Core(TM) i5-4870HQ', ''))
    module.run_command.side_effect = [(0, '/usr/sbin/system_profiler', ''), (0, '', '')]
    hardware_facts_obj = DarwinHardware(module)
    assert hardware_facts_obj.get_cpu_facts()['processor'] == 'Intel(R) Core(TM) i5-4870HQ'
    assert hardware_facts_obj.get_cpu_facts()['processor_cores'] == '4'
    module.run_command.side_effect = [(0, '', ''), (0, '/usr/sbin/system_profiler', '')]
    hardware_facts_obj

# Generated at 2022-06-11 02:24:36.766600
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModuleMock()
    darwin_hw = DarwinHardwareCollector(module)
    assert darwin_hw.sysctl == module.run_command.call_args[0][0]

# Generated at 2022-06-11 02:24:45.414136
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # DarwinHardwareCollector is a subclass of HardwareCollector
    d = DarwinHardwareCollector(None)

    # DarwinHardwareCollector is an instance of DarwinHardwareCollector
    assert isinstance(d, DarwinHardwareCollector)

    # DarwinHardwareCollector is an instance of HardwareCollector
    assert isinstance(d, HardwareCollector)

    # DarwinHardwareCollector is an instance of object
    assert isinstance(d, object)

    # DarwinHardwareCollector._fact_class is DarwinHardware
    assert d._fact_class == DarwinHardware

    # DarwinHardwareCollector._platform is Darwin
    assert d._platform == 'Darwin'



# Generated at 2022-06-11 02:24:48.183516
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'
    assert darwin_hardware_collector._fact_class == DarwinHardware

# Generated at 2022-06-11 02:24:55.563567
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create a fake module for testing
    class FakeModule:
        class FakeRunCommand:
            def __init__(self, out=''):
                self._out = out
            def __call__(self, *args, **kwargs):
                return (0, self._out, '')

        def __init__(self, out=''):
            self.run_command = self.FakeRunCommand(out)

    # Create a fake module

# Generated at 2022-06-11 02:25:02.942121
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_module = type('module', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'Model: MacBookPro15,4, BootROM MBP153.0172.B00, 4 processors, Intel Core i9, 2.30 GHz, 16 GB, SMC 2.45f0\n', ''),
    })

    hardware = DarwinHardware(test_module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == 'Intel Core i9'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_vcpus'] == ''

# Generated at 2022-06-11 02:25:13.109211
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=tuple((0, 'machdep.cpu.brand_string: AMD Ryzen 9 3900X 12-Core Processor\n', '')))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/system_profiler')

    darwin_hw = DarwinHardware(module=module)
    cpu_facts = darwin_hw.get_cpu_facts()

    assert cpu_facts['processor'] == 'AMD Ryzen 9 3900X 12-Core Processor'
    assert cpu_facts['processor_cores'] == '12'
    assert cpu_facts['processor_vcpus'] == ''


# Generated at 2022-06-11 02:25:17.025120
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mod = AnsibleModule(argument_spec={})
    hardware_facts = DarwinHardware(mod)
    memory_facts = hardware_facts.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0



# Generated at 2022-06-11 02:25:42.982683
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    if sys.version_info < (2,7):
        raise "This test only runs with Python version >= 2.7"

    import unittest

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    import ansible.module_utils.common.process as process
    from ansible.module_utils._text import to_bytes

    class TestDarwinHardware(unittest.TestCase):
        def setUp(self):
            self.dh = DarwinHardware(dict())

            import io
            import struct
            self.pack_struct = struct.Struct('@L').pack
            self.mock_process = io.BytesIO()

        def test_uptime(self):
            import time

            test_time = int(time.time()) + 1
            # Write a bytes string with the test

# Generated at 2022-06-11 02:25:51.972917
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Mock the module and context
    module = MagicMock()
    context = MagicMock()
    test = DarwinHardware(module=module, context=context)

    # Mock the parameters
    test.sysctl = {
        'hw.memsize': 4194304000
    }

    # Mock the system call
    context.run_command.return_value = (0, 'PageSize: 4096\nPages wired down: 0\nPages active: 1,843\nPages inactive: 1,492', '')

    memory_facts = test.get_memory_facts()

    # Check the results
    assert memory_facts['memtotal_mb'] == 1024 * 1024 * 4
    assert memory_facts['memfree_mb'] == 2 * 1024


# Generated at 2022-06-11 02:26:02.625118
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    facts = hardware.populate()
    assert isinstance(facts['osversion'], str)
    assert isinstance(facts['osrevision'], str)
    assert isinstance(facts['uptime_seconds'], int)
    assert isinstance(facts['model'], str)
    assert isinstance(facts['memtotal_mb'], int)
    assert isinstance(facts['memfree_mb'], int)
    assert isinstance(facts['processor'], str)
    assert isinstance(facts['processor_cores'], int)
    assert isinstance(facts['processor_vcpus'], int) or facts['processor_vcpus'] == ''

# Generated at 2022-06-11 02:26:13.159755
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Test on a system with Intel processor
    module_mock = type('module_mock', (object,), {
        'run_command': lambda self, args: (0, 'machdep.cpu.brand_string: Intel(R) Core(TM) i7-6920HQ CPU @ 2.90GHz', ''),
        'get_bin_path': lambda _, executable: '/sbin/sysctl',
    })()

    result = DarwinHardware(module_mock).get_cpu_facts()
    assert result['processor'] == 'Intel(R) Core(TM) i7-6920HQ CPU @ 2.90GHz'
    assert result['processor_cores'] == 4

    # Test on a system with PowerPC processor
    class FakeProcess(object):
        def __init__(self, rc, **kwargs):
            self

# Generated at 2022-06-11 02:26:26.003219
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # This unittest runs only with Python 2.6
    if sys.version_info[:2] != (2, 6):
        return


# Generated at 2022-06-11 02:26:28.478833
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector.__class__.__name__ == "DarwinHardwareCollector"


# Generated at 2022-06-11 02:26:39.628330
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # This is necessary to import the module in the test module
    import sys
    sys.modules['ansible'] = __import__('ansible')
    sys.modules['ansible.module_utils'] = __import__('ansible.module_utils')
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    # This is the output of command "vm_stat"

# Generated at 2022-06-11 02:26:41.881401
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Arrange
    darwin_hardware = DarwinHardware(dict())

    # Act
    darwin_hardware.get_memory_facts()

    # Assert

# Generated at 2022-06-11 02:26:47.023157
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """This is a unit test for the DarwinHardwareCollector class."""
    import pytest

    # Test creating an instance of DarwinHardwareCollector
    collector = DarwinHardwareCollector()
    assert collector
    assert collector.platform == 'Darwin'
    assert collector._fact_class == DarwinHardware
    assert collector._platform == 'Darwin'

# Generated at 2022-06-11 02:26:56.226588
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockAnsibleModule({})
    hardware = DarwinHardware(module)

    hardware.sysctl = {
        'hw.model': 'MacBook10,1',
        'kern.osversion': '17.5.0',
        'kern.osrevision': '16384'
    }

    expected = {
        'model': 'MacBook10,1',
        'product_name': 'MacBook10,1',
        'osversion': '17.5.0',
        'osrevision': '16384',
    }

    actual = hardware.get_mac_facts()

    assert expected == actual


# Generated at 2022-06-11 02:27:43.130199
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    m = AnsibleModule()
    d = DarwinHardware(m)
    # This is an example of output of commands run by populate.
    # Replace /dev/null with actual files.

# Generated at 2022-06-11 02:27:49.028402
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts import FactCollector
    import sys
    module = sys.modules.get('ansible.module_utils.facts')
    fc = DarwinHardwareCollector(module)
    facts = fc.collect(None, None)
    assert facts['model'] == 'MacBookPro7,1'
    assert facts['osversion'] == '15.6.0'
    assert facts['osrevision'] == '19G2021'

# Generated at 2022-06-11 02:27:52.009180
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware()
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_cores'] > 0


# Generated at 2022-06-11 02:27:54.292818
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    result = DarwinHardwareCollector()
    assert result.__dict__ == {'_fact_class': DarwinHardware, '_platform': 'Darwin'}


# Generated at 2022-06-11 02:28:04.222317
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = type('module',(object,),{'run_command':lambda x: (0, '', '')})
    h = DarwinHardware({})
    h.module = module
    def getitem(sysctl, item):
        if item == 'machdep.cpu.brand_string':
            return 'Intel (R) Core(TM) i5-6267U CPU @ 2.90GHz'
        elif item == 'machdep.cpu.core_count':
            return '2'
        else:
            raise KeyError('Invalid systemctl key {}'.format(item))
    h.sysctl.__getitem__ = getitem
    cpu = h.get_cpu_facts()
    assert cpu['processor'] == 'Intel (R) Core(TM) i5-6267U CPU @ 2.90GHz'

# Generated at 2022-06-11 02:28:12.854310
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import json
    import os
    import tempfile


# Generated at 2022-06-11 02:28:19.023706
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware_obj = DarwinHardware(module)
    hardware_obj.populate()
    assert hardware_obj.sysctl.get('machdep.cpu.brand_string') is not None or \
           hardware_obj.sysctl.get('hw.physicalcpu') is not None


# Generated at 2022-06-11 02:28:30.355864
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    sysctl_get_map = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-4250U CPU @ 1.30GHz',
        'machdep.cpu.core_count': '4',
    }

    sysctl_get_map_PowerPC = {
        'hw.physicalcpu': '8',
        'hw.logicalcpu': '8',
    }

    hw = DarwinHardware()
    hw.module = MockModule()
    hw.sysctl = sysctl_get_map
    cpu_facts_intel = hw.get_cpu_facts()

    hw.sysctl = sysctl_get_map_PowerPC
    cpu_facts_ppc = hw.get_cpu_facts()


# Generated at 2022-06-11 02:28:39.539317
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    #fake hardware information
    hardware_facts={
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-8550U',
        'machdep.cpu.core_count': 4,
        'machdep.cpu.l2cachesize': 4096,
        'machdep.cpu.logical_per_package': 4,
        'hw.physicalcpu': 2,
        'hw.logicalcpu': 8
    }

    #fake module instance
    class Module(object):
        def __init__(self):
            pass

        def run_command(self, cmd):
            return 0, '', ''
    module = Module()
    module.facts = {}
    module.sysctl = hardware_facts

    hardware = DarwinHardware(module)

    cpu_facts = hardware.get_

# Generated at 2022-06-11 02:28:52.251980
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Create DarwinHardware
    d = DarwinHardware(dict())
    # Set the sysctl attribute of the DarwinHardware to be None
    d.sysctl = None
    # Invoke the method
    mac_facts = d.get_mac_facts()
    # Assert that the method returns a dictionary with only one key
    assert len(mac_facts) == 1
    keys = list(mac_facts.keys())
    # Assert that the only key is 'model'
    assert keys == ['model']
    # Assert that the model value is empty string
    assert mac_facts['model'] == ''
    # Create the sysctl dict object
    sysctl = dict()
    # Create the kern dict object
    kern = dict()
    # Create the osversion dict object
    kern['osversion'] = '1.2.3'
   

# Generated at 2022-06-11 02:30:16.690967
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware(None)
    system_profile = darwin_hardware.get_system_profile()
    assert 'Serial Number (system)' in system_profile
    assert 'Model Name' in system_profile

# Generated at 2022-06-11 02:30:22.752970
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:30:31.048797
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils.pycompat24 import mock

    module = mock.MagicMock()
    module.run_command.return_value = (0, "hw.model: iMac13,2", "")

    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = {'kern.osversion': '1.0',
                              'kern.osrevision': '2'}

    mac_facts = darwin_hardware.get_mac_facts()

    assert mac_facts['model'] == 'iMac13,2'
    assert mac_facts['osversion'] == '1.0'
    assert mac_facts['osrevision'] == '2'

# Generated at 2022-06-11 02:30:43.048693
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    class FakeModule():
        def run_command(self,cmd):
            output = "Hardware:\n"
            output += "    Hardware Overview:\n"
            output += "      Model Name: MacBook Air\n"
            output += "      Processor Name: Intel Core i5\n"
            output += "      Processor Speed: 1.7 GHz\n"
            output += "      Number of Processors: 1\n"
            output += "      Total Number of Cores: 2\n"
            output += "      L2 Cache (per Core): 256 KB\n"
            output += "      L3 Cache: 3 MB\n"
            output += "      Memory: 4 GB\n"
            return 0,output,""

# Generated at 2022-06-11 02:30:47.187139
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector(None)
    assert darwin_hardware_collector.platform == 'Darwin'
    assert darwin_hardware_collector.fact_class == DarwinHardware


# Generated at 2022-06-11 02:30:48.602973
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hw = DarwinHardwareCollector()
    assert isinstance(hw, HardwareCollector)

# Generated at 2022-06-11 02:30:57.493575
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts import hardware
    import sys, os

    # Setup
    hardware.HARDWARE_INSTANCE = None
    hardware.HardwareCollector._fact_classes = dict()
    hardware.HardwareCollector._fact_classes['Darwin'] = DarwinHardwareCollector
    hardware.HardwareCollector._platform = 'Darwin'

    hw = DarwinHardware()
    hw.module = sys.modules[__name__]

    # Mocks
    def run_command(cmd, encoding=None):
        if cmd[len(cmd) - 1] == 'kern.boottime':
            return 0, get_macos_boottime(), ''
        else:
            return -1, '', ''
    hw.module.run_command = run_command


# Generated at 2022-06-11 02:31:00.020986
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    Test DarwinHardwareCollector class constructor.
    """
    hardware_collector = DarwinHardwareCollector()

    assert hardware_collector.platform == 'Darwin'

# Generated at 2022-06-11 02:31:02.446923
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = MagicMock()
    hardware = DarwinHardwareCollector(module=module)
    assert hardware.platform.startswith('Darwin')

# Generated at 2022-06-11 02:31:14.240823
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # When vm_stat fails, return an empty dict
    module = MagicMock()
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.get_system_profile = MagicMock(return_value=dict())
    darwin_hardware.sysctl = dict()
    module.run_command.return_value = 1, "", ""
    assert darwin_hardware.get_memory_facts() == dict()

    # When vm_stat succeeds, return memory facts
    module = MagicMock()
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.get_system_profile = MagicMock(return_value=dict())
    darwin_hardware.sysctl = dict(hw_memsize="1073741824")
    module.run_