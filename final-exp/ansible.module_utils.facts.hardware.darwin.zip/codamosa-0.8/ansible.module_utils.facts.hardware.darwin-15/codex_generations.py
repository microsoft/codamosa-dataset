

# Generated at 2022-06-11 02:22:25.924201
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Test that Apple's Darwin platform is supported by DarwinHardwareCollector.
    collector = DarwinHardwareCollector()
    assert collector.platforms == ['Darwin']

# Generated at 2022-06-11 02:22:36.096025
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    output = """Hardware Overview:

  Model Name: MacBook Pro
  Model Identifier: MacBookPro1,1
  Processor Name: Intel Core Duo
  Processor Speed: 2 GHz
  Number Of Processors: 1
  Total Number Of Cores: 2
  L2 Cache: 2 MB
  Memory: 2 GB
  Bus Speed: 667 MHz
  Boot ROM Version: MB11.0055.B07
  SMC Version (system): 1.6f10
  Serial Number (system): W871273A3MW
  Hardware UUID: 00000000-0000-1000-8000-00176DBE8B65"""

    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

# Generated at 2022-06-11 02:22:45.908318
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(
        argument_spec=dict(
            output_format=dict(default='raw', choices=['raw', 'json'])
        )
    )

    darwin_hw = DarwinHardware(module)
    system_profile = {}
    system_profile = darwin_hw.get_system_profile()

    if module.params['output_format'] == 'json':
        module.exit_json(changed=False, ansible_facts=dict(system_profile=system_profile))
    else:
        module.exit_json(changed=False, ansible_facts=system_profile)



# Generated at 2022-06-11 02:22:59.108488
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    import ansible.module_utils.facts.hardware.darwin
    from ansible.module_utils.six import StringIO


# Generated at 2022-06-11 02:23:09.350331
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    import os
    os.environ['ANSIBLE_MODULE_UTILS'] = os.path.join(os.path.dirname(__file__), '../../utils')
    for prefix, _ in os.environ.items():
        if prefix.startswith('ANSIBLE_MODULE_'):
            del os.environ[prefix]

    from ansible.module_utils.facts import hardware
    import ansible.module_utils.facts.hardware.darwin as darwin
    import tempfile
    import shutil

    import textwrap

    # Setting up properties

    # Set current directory to temp directory
    tempdir = tempfile.mkdtemp()
    currentdir = os.getcwd()
    os.chdir(tempdir)

    hardware.Hardware._SYSTEM_PROFILER_CACHE_LOC

# Generated at 2022-06-11 02:23:17.783543
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import ansible.module_utils.facts.hardware.darwin as darwin_hw_facts
    import datetime
    import mock
    import pytz
    import struct
    import time

    def make_mock_big_endian_int(i):
        return struct.pack('@L', i)

    now = datetime.datetime.now(pytz.utc)
    now_timestamp = time.mktime(now.timetuple())

    assert now_timestamp > 0

    def mock_run_command(args, encoding):
        assert encoding is None
        assert args == ['sysctl', '-b', 'kern.boottime']
        return (
            0,
            make_mock_big_endian_int(now_timestamp - 15),
            '',
        )


# Generated at 2022-06-11 02:23:24.772738
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    output = '{ sec = 1489508726, usec = 711043 }\n'
    class module:
        def run_command(self, cmd, encoding=None):
            return (0, output, '')
        class params:
            pass
    hardware = DarwinHardware(module)
    hardware.module = module
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {'uptime_seconds': 1489508726}

# Generated at 2022-06-11 02:23:32.328789
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    src = dict(hw=dict(
        memsize=1073741824,
        physicalcpu=2,
    ), machdep=dict(
        cpu=dict(core_count=1, brand_string='Intel(R) Core(TM) i5-2500S CPU @ 2.70GHz'),
    ), kern=dict(
        osversion='15.6.0',
        osrevision='1910.60.3',
    ))

# Generated at 2022-06-11 02:23:33.043864
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-11 02:23:37.416305
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    fc = DarwinHardwareCollector()
    attrs = ['_platform', '_fact_class']
    assert all([hasattr(fc, a) for a in attrs])
    assert fc._platform == 'Darwin'
    assert fc._fact_class == DarwinHardware

# Generated at 2022-06-11 02:23:54.629149
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

# Generated at 2022-06-11 02:24:04.736135
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)

# Generated at 2022-06-11 02:24:14.415730
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Unit test requires the following mock objects.
    module = MagicMock()
    module.run_command = MagicMock(
        return_value=(0, 'hw.memsize: 1048576\nhw.model: Power Macintosh\nhw.logicalcpu: 1\nhw.physicalcpu: 1\nkern.osversion: 19.2.0\nkern.osrevision: 11.2.0\nmachdep.cpu.core_count: 1\nmachdep.cpu.brand_string: Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/vm_stat')

# Generated at 2022-06-11 02:24:23.260094
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import sys
    import argparse
    import json

    ##########################################################################
    # Create the mock module
    ##########################################################################
    mock_module = type('MockModule', (object,), {
        'run_command': staticmethod(lambda x, encoding=None: (0, x[1], '')),
        'get_bin_path': staticmethod(lambda dummy: '/usr/bin/vm_stat')
    })()
    mock_module.params = {}

    ##########################################################################
    # Create a DarwinHardware object
    ##########################################################################
    dh = DarwinHardware(mock_module)
    dh.sysctl = {
        'hw.memsize': '4294967296',
    }

    ##########################################################################
    # Create a parser to parse and interpret the test's command line arguments
    #

# Generated at 2022-06-11 02:24:31.399334
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_module = MagicMock()
    test_module.run_command = MagicMock(return_value=(0, 'hw.model: iMac', ''))
    test_dh = DarwinHardware(test_module)
    test_dh.sysctl = {}
    test_dh.sysctl['kern.osversion'] = '15.0.0'
    test_dh.sysctl['kern.osrevision'] = '18G1012'
    result = test_dh.get_mac_facts()
    assert result == {'model': 'iMac', 'osversion': '15.0.0', 'osrevision': '18G1012'}



# Generated at 2022-06-11 02:24:43.222449
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:24:52.829078
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import sys
    import os
    import unittest2 as unittest
    from ansible.module_utils._text import to_bytes

    if sys.version_info[:2] < (2, 7):
        unittest = unittest2

    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = list()

        def run_command(self, args, encoding=None):
            self.run_command_calls.append(args)
            if args == ['/usr/sbin/sysctl', '-b', 'kern.boottime']:
                s = struct.pack('@L', 0)
                return (0, to_bytes(s), '')
            else:
                raise ValueError('Unexpected call %s' % (args, ))


# Generated at 2022-06-11 02:24:59.293963
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():

    class HelloMockModule:
        def run_command(self, cmd):
            return (1, "error")

    darwin_hardware = DarwinHardware(HelloMockModule())
    system_profile = darwin_hardware.get_system_profile()

    # bogus output should return dict()
    assert system_profile == dict()

if __name__ == "__main__":
    test_DarwinHardware_get_system_profile()

# Generated at 2022-06-11 02:25:08.118831
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    m = {'run_command.return_value': (0, """
{
    "kern.boottime": {
        "tv_sec": 1507255854,
        "tv_usec": 0
    }
}
""", "")}
    m_time = {'time.time.return_value': 1508415517}

    h = DarwinHardware(m, m_time)
    assert h.get_uptime_facts() == {'uptime_seconds': 11707163}

# Generated at 2022-06-11 02:25:08.826361
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-11 02:25:36.881442
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    obj = DarwinHardware({})
    memory_facts = obj.get_memory_facts()
    assert isinstance(memory_facts, dict)
    # memfree_mb
    assert 'memfree_mb' in memory_facts
    assert memory_facts['memfree_mb'] >= 0
    # memtotal_mb
    assert 'memtotal_mb' in memory_facts
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] <= memory_facts['memtotal_mb']

# Generated at 2022-06-11 02:25:38.986687
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts.get('uptime_seconds')

# Generated at 2022-06-11 02:25:45.113468
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module_mock = Mock()
    module_mock.run_command.return_value = [0, "hw.model: Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz", '']
    sysctl = {
        'kern.osversion': '14.5.0',
        'kern.osrevision': '15F34',
    }
    hardware = DarwinHardware(module_mock, sysctl)
    mac_facts = hardware.get_mac_facts()
    assert mac_facts == {
        'model': 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz',
        'osversion': '14.5.0',
        'osrevision': '15F34',
    }



# Generated at 2022-06-11 02:25:55.888434
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():

    module = type('AnsibleModule', (object,), dict(
        run_command=lambda *_: (0, '', ''),
        get_bin_path=lambda *_: '/usr/sbin/system_profiler'
    ))()
    hardware = DarwinHardware(module=module)

    class SysctlMock(object):
        def __init__(self, *sysctls):
            self.sysctls = dict(sysctls)
        def __getitem__(self, name):
            return self.sysctls[name]

    assert hardware.get_cpu_facts() == {
        'processor': 'Intel Core i7',
        'processor_cores': 2,
        'processor_vcpus': ''
    }


# Generated at 2022-06-11 02:26:05.925101
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin import DarwinHardware

    h = DarwinHardware()

    # Test with all lines valid
    with patch.object(h.module, 'run_command') as run_command_mock:
        with patch.object(run_command_mock, 'return_value') as return_value_mock:
            return_value_mock.rc = 0
            return_value_mock.out = 'name1: value1\nname2: value2\n'
            assert h.get_system_profile() == {'name1': 'value1', 'name2': 'value2'}

    # Test with one bad line
   

# Generated at 2022-06-11 02:26:16.013870
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils import basic
    # Create a fakes module
    module = basic.AnsibleModule(argument_spec=dict())

    # Create a fake DarwinHardware
    dh = DarwinHardware(module=module)

    # Get data for Mac mini

# Generated at 2022-06-11 02:26:25.052496
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hardware = DarwinHardware()

    # Set up a fake module
    darwin_hardware.module = type('FakeModule', (), {})()
    darwin_hardware.module.run_command = lambda command, encoding=None: (0, b'Wed Dec 21 13:13:24 2016', '')

    uptime_facts = darwin_hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-11 02:26:36.837435
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict()
    )
    darwin_hardware = DarwinHardware(module)

    # Check for Intel CPU
    darwin_hardware.sysctl = {'machdep.cpu.brand_string': 'Genuine Intel(R) CPU @ 2.20GHz', 'machdep.cpu.core_count': '1'}
    assert darwin_hardware.get_cpu_facts() == {'processor': 'Genuine Intel(R) CPU @ 2.20GHz', 'processor_cores': '1', 'processor_vcpus': ''}

    # Check for PowerPC CPU - System Profiler found

# Generated at 2022-06-11 02:26:46.539847
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Init the class with dummy memory
    mac_facts = {
        'memtotal_mb': 16000,
        'memfree_mb': 0,
    }
    class FakeModule:
        run_command = lambda self, command: (0, "", "")
    class FakeDarwinHardware(DarwinHardware):
        def __init__(self):
            self.module = FakeModule()
    darwin_hardware = FakeDarwinHardware()
    darwin_hardware.get_memory_facts = DarwinHardware.get_memory_facts.__func__
    # Run the function
    darwin_hardware.get_memory_facts()
    # Assert the results
    assert darwin_hardware.memtotal_mb == mac_facts['memtotal_mb']
    assert darwin_hardware.memfree_

# Generated at 2022-06-11 02:26:57.241945
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Arrange
    Darwin = DarwinHardware()
    Darwin.sysctl = {'hw.memsize': 360710144}
    Darwin.module = _MockModule()
    Darwin.module.run_command.return_value = (0, "\"Pages wired down\": 1985934\n\"Pages active\": 5296403\n\"Pages inactive\": 5485324", "")

    # Act
    result = Darwin.get_memory_facts()

    # Assert
    assert result['memtotal_mb'] == int(360710144 / 1024 / 1024)
    assert result['memfree_mb'] == int((360710144 - ((1985934 + 5296403 + 5485324) * 4096)) / 1024 / 1024)


# Generated at 2022-06-11 02:27:52.093959
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    datadir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'data')
    unit_test_datadir = os.path.join(datadir, 'unit/ansible_collections/ansible/community/plugins/module_utils/facts/hardware')
    test_data = open(os.path.join(unit_test_datadir, 'DarwinHardware_get_memory_facts_data')).read()
    command_output = test_data.splitlines()
    test_obj = DarwinHardware()
    test_obj.module = AnsibleModule(argument_spec=dict())
    test_obj.module.run_command = MagicMock(return_value=(0, command_output, None))

# Generated at 2022-06-11 02:28:01.911515
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import platform
    import sys
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, "", "")
    sys.modules['ansible'] = MockModule()

    class MockPlatform(object):
        def __init__(self, is_intel, is_ppc):
            self.machine = 'x86_64' if is_intel else 'ppc'
            self.processor = 'Intel' if is_intel else 'PowerPC'
            self.system = 'Darwin'

    class MockSysctl(object):
        def __init__(self, is_intel, is_ppc):
            self.values = dict()

# Generated at 2022-06-11 02:28:07.673201
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    result = DarwinHardware(module).populate()
    assert result['processor']
    assert result['processor_cores']
    assert result['memtotal_mb']
    assert result['memfree_mb']
    assert result['model']
    assert result['osversion']
    assert result['osrevision']
    assert result['uptime_seconds']

# Generated at 2022-06-11 02:28:09.573419
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    find_file = get_bin_path('vm_stat')
    return DarwinHardwareCollector(None, find_file)


# Generated at 2022-06-11 02:28:16.888006
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    '''Creates a fake module class and tests the get_mac_facts method'''
    module = FakeModule()

    module.run_command.return_value = (0, 'hw.model: Macmini3,1', None)

    obj = DarwinHardware(module)

    assert obj.get_mac_facts() == {'osversion': '', 'model': 'Macmini3,1', 'osrevision': ''}



# Generated at 2022-06-11 02:28:28.732180
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    sample_data = [
        "machdep.cpu.brand_string: Intel(R) Core(TM) i7-4870HQ CPU @ 2.50GHz",
        "machdep.cpu.core_count: 4"
    ]

    class ModuleMock:
        run_command = lambda self, cmd, encoding=None: (0, '\n'.join(sample_data), None)
        get_bin_path = lambda self, name: "bin_path_for_" + name

    module_mock = ModuleMock()

    hardware = DarwinHardware(module_mock)

    cpu_facts = hardware.get_cpu_facts()


# Generated at 2022-06-11 02:28:38.338992
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    facts_instance = DarwinHardware()
    sysctl_cmd = facts_instance.module.get_bin_path('sysctl')

    # The sysctl command returns an integer of seconds
    uptime_cmd = (sysctl_cmd, '-b', 'kern.boottime')
    updated_time = time.time()

# Generated at 2022-06-11 02:28:40.056728
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware_collector = DarwinHardwareCollector()
    assert darwin_hardware_collector._platform == 'Darwin'

# Generated at 2022-06-11 02:28:53.004372
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mac_hw = DarwinHardware()
    system_profile = mac_hw.get_system_profile()
    assert system_profile["Model Name"] == "MacBook Pro"
    assert system_profile["Model Identifier"] == "MacBookPro9,2"
    assert system_profile["Processor Name"] == "Intel Core i7"
    assert system_profile["Processor Speed"] == "2.9 GHz"
    assert system_profile["Number of Processors"] == "1"
    assert system_profile["Total Number of Cores"] == "4"
    assert system_profile["L2 Cache (per Core)"] == "256 KB"
    assert system_profile["L3 Cache"] == "6 MB"
    assert system_profile["Memory"] == "16 GB"

# Generated at 2022-06-11 02:28:58.894178
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class FakeModule:
        def run_command(self, command):
            return 0, 'hw.model: iMac14,1\n'.encode('utf-8'), ''

    hardware_facts = DarwinHardware(module=FakeModule()).get_mac_facts()
    assert hardware_facts['model'] == 'iMac14,1'


# Generated at 2022-06-11 02:30:40.235110
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockOSModule()
    hw = DarwinHardware(module)
    sysctl = hw.sysctl
    sysctl['machdep.cpu.brand_string'] = 'Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz'
    sysctl['machdep.cpu.core_count'] = 8
    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz'
    assert cpu_facts['processor_cores'] == 8
    assert not cpu_facts['processor_vcpus']
    sysctl['machdep.cpu.brand_string'] = None

# Generated at 2022-06-11 02:30:51.269224
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command = mock.Mock()
    module.get_bin_path = mock.Mock()
    module.get_bin_path.side_effect = lambda name: './bin/' + name

    cmd = './bin/sysctl -b kern.boottime'
    out = ''.join([chr(n) for n in [
        0x1a, 0x28, 0x18, 0x3d, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    ]])
    rc = 0
    module.run_command.return_value = (rc, out, '')

    mac_hard

# Generated at 2022-06-11 02:30:58.993763
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({}, {}, check_invalid_arguments=False)

# Generated at 2022-06-11 02:31:06.960669
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    system_profile = """
Hardware:

    Hardware Overview:

      Model Name: MacBook Pro
      Model Identifier: MacBookPro8,2
      Processor Name: Intel Core i7
      Processor Speed: 2.5 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 6 MB
      Memory: 8 GB
      Boot ROM Version: MBP81.0047.B27
      SMC Version (system): 1.69f2
    """
    mac_hw = DarwinHardware(None)

    result = mac_hw.get_system_profile()

# Generated at 2022-06-11 02:31:12.496512
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    # Create object
    mac_facts_object = DarwinHardware()
    mac_facts = mac_facts_object.get_mac_facts('/tmp')
    assert mac_facts['osversion'] == '19.6.0'
    assert mac_facts['osrevision'] == '18G1012'


# Generated at 2022-06-11 02:31:16.324334
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    d = DarwinHardware(module=module)
    facts = d.populate()
    assert isinstance(facts, dict)

# Unit test class

# Generated at 2022-06-11 02:31:26.240207
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)

# Generated at 2022-06-11 02:31:32.860765
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # An object of class DarwinHardware
    module = type('module', (object, ), {'run_command': run_command})
    hardware = DarwinHardware(module)

    # A successful run of the command, output
    rc = 0
    out = "Mon Jan 15 12:20:10 2018".encode('utf-8')

    # Call the function
    result = hardware.get_uptime_facts()

    assert rc == 0
    assert result['uptime_seconds'] == 1516077210

# Mock for the ansible module

# Generated at 2022-06-11 02:31:41.638119
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # In this test, we mock the 'sysctl' module to simulate a response
    # from the mock of the 'sysctl' command.

    class MockModule(object):
        @staticmethod
        def run_command(cmd, encoding=None):
            assert cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']

            if encoding is None:
                return 0, b'\x00\x01\x02\x03\x04\x05\x06\x07\x00\x01\x02\x03', ''
            else:
                return 0, u'\x00\x01\x02\x03\x04\x05\x06\x07\x00\x01\x02\x03', ''


# Generated at 2022-06-11 02:31:48.422965
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class TestModule(object):
        def get_bin_path(self, executable, required=True, opt_dirs=None):
            return "/usr/bin/vm_stat"

        def run_command(self, command, encoding=None):
            return 0, "Pages free:             5188.\nPages active:           9211.\nPages inactive:         3007.\nPages wired down:       6258.\n ", ""

    m = TestModule()
    d = DarwinHardware(m)

    # test normal case
    ans = d.get_memory_facts()
    assert ans['memfree_mb'] == 479
    assert ans['memtotal_mb'] > 0

    # test vm_stat output is not found
    m.run_command = (lambda command, encoding: (-1, "", ""))
    ans = d