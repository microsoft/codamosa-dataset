

# Generated at 2022-06-11 02:22:33.599872
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """Test that get_system_profile function makes the proper command."""

    cmd = '/usr/sbin/system_profiler SPHardwareDataType'

    def mock_run_command(self, command, **kwargs):
        assert command == cmd.split()
        return "", "", 0

    import ansible.module_utils.facts.hardware.darwin
    import types
    ansible.module_utils.facts.hardware.darwin.Hardware.run_command = types.MethodType(mock_run_command, ansible.module_utils.facts.hardware.darwin.Hardware)

    h = ansible.module_utils.facts.hardware.darwin.Hardware()
    h.get_system_profile()

# Generated at 2022-06-11 02:22:45.080640
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    mock_module = Mock()
    mock_module.run_command.return_value = (0, """
Errata: none.

9.8.0:
ProductName:	MacBookPro11,1
ProductVersion:	9.8.0
BuildVersion:	13D65
    """, "")

    dh = DarwinHardware(mock_module)
    facts = dh.get_mac_facts()
    assert facts['model'] == 'MacBookPro11,1'
    assert facts['osversion'] == '9.8.0'
    assert facts['osrevision'] == '13D65'



# Generated at 2022-06-11 02:22:52.382016
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = None
    # Build test data set
    darwin_sysctl = {
        'machdep.cpu.brand_string': 'Testing CPU',
        'machdep.cpu.core_count': '4'
    }
    darwin_system_profile = {
        'Processor Name': 'Testing CPU',
        'Processor Speed': '2.5 GHz',
    }

    # Create instance of DarwinHardware
    dh = DarwinHardware(module)
    # Set mock return value for sysctl
    dh.sysctl = darwin_sysctl
    # Set mock return value for get_system_profile
    dh._DarwinHardware__get_system_profile = lambda: darwin_system_profile
    # Test with Intel processor
    cpu_facts = dh.get_cpu_facts()

# Generated at 2022-06-11 02:23:02.704024
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = MockModule()
    module.get_bin_path = Mock(return_value="/usr/bin/vm_stat")

    # Prepare values for the test
    fake_sysctl = {
        'hw.memsize': 825753600,
    }

# Generated at 2022-06-11 02:23:09.401003
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    module = AnsibleModule(dict(),
                           supports_check_mode=False)
    set_module_args(dict(gather_subset=['!all', '!min']))
    hardware = DarwinHardware(module)
    hardware.populate()
    facts = hardware.get_facts()
    assert 'model' in facts
    assert 'osversion' in facts
    assert 'osrevision' in facts


# Generated at 2022-06-11 02:23:17.849700
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    sysctl_mock = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4650U CPU @ 1.70GHz',
        'machdep.cpu.core_count': 1,
        'hw.physicalcpu': 1,
        'hw.logicalcpu': 2,
    }

    with patch.dict(hardware.sysctl, sysctl_mock):
        # Test for Intel CPU
        cpu_facts = hardware.get_cpu_facts()
        assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4650U CPU @ 1.70GHz'
        assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-11 02:23:28.638254
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = MagicMock()
    hardware = DarwinHardware(module)

    # Test if memory facts are successfully created

# Generated at 2022-06-11 02:23:33.750466
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    fake_module = type('AnsibleModule', (object,),
                       {'run_command': lambda self, module: ('0', '', '')})
    hardware = DarwinHardwareCollector(fake_module)

    assert isinstance(hardware.get_system_profile(), dict)


# Generated at 2022-06-11 02:23:40.140515
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware(None)
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'Intel',
        'machdep.cpu.core_count': '2',
        'hw.physicalcpu': '1',
    }
    assert hardware.get_cpu_facts() == {
        'processor': 'Intel',
        'processor_cores': '2',
        'processor_vcpus': '1',
    }



# Generated at 2022-06-11 02:23:51.092443
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from .test_hardware_base import TestHardwareBase
    from ansible.module_utils import facts
    from ansible.module_utils.facts.collector.darwin import DarwinHardwareCollector
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    my_obj = DarwinHardware()
    class_name = my_obj.__class__.__name__
    method_name = 'get_cpu_facts'
    result = TestHardwareBase.run_unit(class_name,method_name,module_name='ansible.module_utils.facts.hardware.darwin', facts_collector=DarwinHardwareCollector)
    expected = {"processor": "m1.large", "processor_cores": 2, "processor_vcpus": 2}
    assert expected == result


# Generated at 2022-06-11 02:24:10.832707
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    facts_obj = DarwinHardware()
    facts_obj.module = module
    facts_obj.sysctl = dict()

    facts_obj.get_mac_facts()
    assert 'osversion' in facts_obj.facts
    assert 'model' in facts_obj.facts



# Generated at 2022-06-11 02:24:21.027154
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class TestDarwinHardware_get_mac_facts1(DarwinHardware):
        def __init__(self, module):
            self.sysctl = {'kern.osversion': '1.2.3', 'kern.osrevision': '4.5.6'}
    hw = TestDarwinHardware_get_mac_facts1(None)
    hw.get_mac_facts() == {'osversion': '1.2.3', 'osrevision': '4.5.6'}

    class TestDarwinHardware_get_mac_facts2(DarwinHardware):
        def __init__(self, module):
            self.sysctl = {'machdep.cpu.brand_string': 'Intel Core i7'}
    hw = TestDarwinHardware_get_mac_facts2(None)


# Generated at 2022-06-11 02:24:31.056539
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    """Tests populate method of DarwinHardware class"""

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    hardware_expect = {
        'model': 'iMacPro1,1',
        'osversion': '17.7.0',
        'osrevision': '15H1421',
        'processor': '3.2 GHz Intel Xeon W',
        'processor_cores': '36',
        'processor_vcpus': '',
        'memtotal_mb': 268435456,
        'memfree_mb': 0,
        'uptime_seconds': 0,
    }

    hardware = DarwinHardware(None)
    hardware_out = hardware.populate()

    assert isinstance(hardware_out, dict)
    assert hardware_out == hardware_expect

# Generated at 2022-06-11 02:24:36.129404
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    d_hw = DarwinHardware()
    cpu_facts = d_hw.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_vcpus' in cpu_facts

# Generated at 2022-06-11 02:24:46.618326
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_module = AnsibleModule(
        argument_spec=dict()
    )
    darwin_hardware = DarwinHardware(test_module)
    darwin_hardware.sysctl['machdep.cpu.brand_string'] = 'Intel(R) Xeon(R) CPU E5-2680 v3 2.50GHz'
    darwin_hardware.sysctl['machdep.cpu.core_count'] = '16'
    darwin_hardware.sysctl['hw.physicalcpu'] = '2'
    darwin_hardware.sysctl['hw.logicalcpu'] = ''
    darwin_hardware.sysctl['hw.ncpu'] = '2'
    cpu_facts = darwin_hardware.get_cpu_facts()

# Generated at 2022-06-11 02:24:49.580880
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockModule()
    hardware = DarwinHardware(module)
    hardware.get_mac_facts()
    module.run_command.assert_called_with("sysctl hw.model")


# Generated at 2022-06-11 02:24:53.387541
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """
    Ensure DarwinHardwareCollector instantiates properly when passed the proper
    values, and fails otherwise.
    """
    assert DarwinHardwareCollector._platform == 'Darwin'
    assert DarwinHardwareCollector._fact_class == DarwinHardware

# Unit tests for some methods of class DarwinHardware

# Generated at 2022-06-11 02:25:02.971519
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.mock_command(rc=0, out='Pages wired down: 40960')
    module.mock_command(rc=0, out='Pages active: 50960')
    module.mock_command(rc=0, out='Pages inactive: 60960')
    module.mock_command(rc=0, out='Pages free: 70960')
    hardware = DarwinHardware(module)
    hardware.get_memory_facts()
    # memfree_mb = memtotal_mb - (wired + active + inactive) / (1024 * 1024)
    assert hardware.ansible_facts['memory']['memtotal_mb'] == 1047552
    assert hardware.ansible_facts['memory']['memfree_mb'] == 104752


# Generated at 2022-06-11 02:25:12.841431
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    m = AnsibleModuleMock(params={})
    m.run_command = MagicMock(return_value=(0, 'hw.model: MacBookPro', ''))
    if sys.version_info[0] >= 3:
        m.to_bytes = lambda x: x.encode('utf-8')
    class DarwinHardware(DarwinHardware):
        module = m
    facts = DarwinHardware()
    assert_equal(facts.get_mac_facts(), {'model': 'MacBookPro', 'osversion': '15.5.0', 'osrevision': '15.5.0'})
    m.run_command.assert_called_once_with('sysctl hw.model')


# Generated at 2022-06-11 02:25:24.351298
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mod = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    try:
        import psutil
        psutil  # to avoid pyflakes warning
    except ImportError:
        raise SkipTest("psutil is not installed")

    if not get_bin_path('vm_stat'):
        raise SkipTest("vm_stat is not installed")

    if not get_bin_path('sysctl'):
        raise SkipTest("sysctl is not installed")

    if not get_bin_path('system_profiler'):
        raise SkipTest("system_profiler is not installed")

    hardware_facts = DarwinHardware(module=mod).populate()
    assert len(hardware_facts) > 0

# Generated at 2022-06-11 02:25:55.699377
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    m = DarwinHardware(None)

# Generated at 2022-06-11 02:26:05.817097
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """Unit test for method get_memory_facts of class DarwinHardware"""
    class Args(object):
        pass
    class Module(object):
        def __init__(self):
            self.args = Args()
            self.run_command_results = dict()
        def run_command(self, args, namespace=None):
            if args[0] == "/usr/bin/vm_stat":
                return (self.run_command_results["vm_stat"]["rc"],
                        self.run_command_results["vm_stat"]["out"],
                        self.run_command_results["vm_stat"]["err"])
            if args[0] == "/usr/sbin/system_profiler":
                return self.run_command_results["system_profiler"]
            return (0, "", "")



# Generated at 2022-06-11 02:26:15.985418
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Create a mock class for module.run_command
    class R:
        def __init__(self):
            self.rc = 0
            self.out = 0
            self.err = 0

        def run_command(self, cmd):
            self.cmd = cmd
            if "sysctl hw.model" in cmd:
                self.out = "hw.model: Intel(R) Core(TM) i5-5200U CPU @ 2.20GHz"
                return self.rc, self.out, self.err

# Generated at 2022-06-11 02:26:28.692676
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import mock
    from datetime import datetime

    class MockedModule:
        def get_bin_path(self, tool):
            return tool

        def run_command(self, cmd, encoding=None):
            if cmd[1] == '-b':
                epoch_time = int((datetime.utcnow() - datetime(1970,1,1)).total_seconds())
                return 0, struct.pack('L', epoch_time), ''
            else:
                return 0, '', ''

    module = MockedModule()
    hardware = DarwinHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    # For uptime_seconds to be correct, we need to ensure that the unit test
    # takes less than 1 second to run, hence this test is done at the end.

# Generated at 2022-06-11 02:26:39.458416
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module_mock = Mock()
    hardware_facts = DarwinHardware(module_mock)

    # Test with a simple output
    expected = {
        'Machine Model': 'MacBook Pro',
        'Memory': '16 GB',
        'Processor Name': 'Intel Core i7',
        'Processor Speed': '3.1 GHz'
    }
    module_mock.run_command.return_value = (0, "Machine Model: %s\nMemory: %s\nProcessor Name: %s\nProcessor Speed: %s" % (
        expected['Machine Model'],
        expected['Memory'],
        expected['Processor Name'],
        expected['Processor Speed']), '')
    assert hardware_facts.get_system_profile() == expected


# Generated at 2022-06-11 02:26:45.116173
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    hardware_obj = DarwinHardware(module)
    facts = hardware_obj.populate()
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['model']
    assert facts['osversion']
    assert facts['osrevision']
    assert facts['uptime_seconds']

# Generated at 2022-06-11 02:26:55.781241
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Create empty values for the calcuations.
    total_used = 0

    # Test vm_stat command output.

# Generated at 2022-06-11 02:27:03.049490
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    m = MockDarwinHardware()

# Generated at 2022-06-11 02:27:09.535827
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:27:21.137043
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    mac_facts = {
        'model': 'Macmini6,1',
        'osversion': '16.7.0',
        'osrevision': '16G1212'
    }
    cpu_facts = {
        'processor': 'Intel(R) Core(TM) i5-4250U CPU @ 1.30GHz',
        'processor_cores': 2,
        'processor_vcpus': 4
    }
    memory_facts = {
        'memtotal_mb': 8192,
        'memfree_mb': 2048
    }
    uptime_facts = {
        'uptime_seconds': 3720
    }

    dh = DarwinHardware()
    facts = dh.populate(collected_facts={})


# Generated at 2022-06-11 02:27:49.948146
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})

    # Inject module and module_utils so we can reach the sysctl command
    darwin_hardware = DarwinHardware(module=module, module_utils=module._module_utils)
    uptime_facts = darwin_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-11 02:27:59.808226
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    up_time = 56789
    kern_boottime = int(time.time() - up_time)

    hw = DarwinHardware()

    # Define methods get_bin_path, run_command and sysctl
    def get_bin_path(program):
        return '/usr/sbin/' + program
    hw.get_bin_path = get_bin_path

    def run_command(commands, encoding=None):
        sysctl_cmd = 'sysctl'
        if commands[0] != sysctl_cmd:
            raise ValueError('Unsupported command %s' % commands[0])
        sub_cmd = commands[2]
        if sub_cmd == 'kern.boottime':
            return (0, struct.pack('@L', kern_boottime), '')

# Generated at 2022-06-11 02:28:09.805768
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # In this test, we use a mocked call to sysctl, so that it returns
    # the value of kern.boottime. Since we don't have a running OS X
    # system, we must fake the value of the boottime. We just use the
    # current time in seconds.

    # Import test_utils so that we can mock the module.run_command method
    # and replace it with a mock function.
    import ansible.module_utils.facts.hardware.darwin.test_utils
    import ansible.module_utils.facts.hardware.darwin

    current_time = int(time.time())
    # The kern.boottime field is a struct timeval, so we return the
    # current time in seconds (as a 64-bit unsigned int, in network byte order)
    # and zero microseconds.
    k

# Generated at 2022-06-11 02:28:14.952962
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = AnsibleModuleMock()
    darwin_hw = DarwinHardwareCollector(module)
    assert isinstance(darwin_hw, DarwinHardwareCollector)
    assert isinstance(darwin_hw._fact_class, DarwinHardware)


# Generated at 2022-06-11 02:28:22.943728
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()
    hardware = DarwinHardware(module=module)

    # Call populate but disable collection of facts
    hardware.populate({'gather_subset': [], 'gather_timeout': 0})

    # Get the facts and ensure they are empty
    hardware_facts = hardware.get_facts()
    assert hardware_facts == {}

    # Gather all facts
    hardware.populate()

    # Get the facts and ensure they are not empty
    hardware_facts = hardware.get_facts()
    assert hardware_facts != {}



# Generated at 2022-06-11 02:28:34.120753
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    import sys
    import inspect
    current_modname = __name__
    current_path = inspect.getfile(inspect.currentframe())
    current_dir = os.path.dirname(current_path)
    sys.path.insert(0, current_dir)

    import module_utils.facts.hardware.darwin
    profiler = module_utils.facts.hardware.darwin.DarwinHardware()

    # Mock the results of the tested method

# Generated at 2022-06-11 02:28:43.886447
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector.darwin import DarwinHardware as testClass

    module = AnsibleModule()

    # Test without sysctl binary
    module.run_command = Mock(return_value=(1, None, None))
    test = testClass(module)
    assert test.get_uptime_facts() == {}

    # Test with invalid output of sysctl
    module.run_command = Mock(return_value=(0, '123456789', None))
    test = testClass(module)
    assert test.get_uptime_facts() == {}

    # Test with valid output of sysctl
    # See test_get_sysctl for the meaning of the mock

# Generated at 2022-06-11 02:28:53.627216
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    sysctl_mock = dict(
        {'machdep.cpu.brand_string': 'Some CPU',
         'machdep.cpu.core_count': 12,
         'hw.physicalcpu': 2,
         'hw.logicalcpu': 2
        }
    )
    facts = DarwinHardware(dict(module=dict(get_bin_path=lambda *args: None), sysctl=sysctl_mock)).populate()
    assert facts['processor'] == 'Some CPU'
    assert facts['processor_cores'] == 12
    assert facts['processor_vcpus'] == 2



# Generated at 2022-06-11 02:29:03.681774
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware(None)

    vm_stat_command = """Mach Virtual Memory Statistics: (page size of 4096 bytes)
Pages free:                               5167.
Pages active:                          2492672.
Pages inactive:                       10236064.
Pages speculative:                      149157.
Pages throttled:                             0.
Pages wired down:                      4914936.
Pages purgeable:                         15260.
"Translation faults":              33019354619.
Pages copy-on-write:                 52427589.
Pages zero filled:                 1290233929.
Pages reactivated:                     269791.
Pageins:                             44974348.
Pageouts:                                1805.
Object cache: 36 hits of 82348 lookups (0% hit rate)
"""

# Generated at 2022-06-11 02:29:14.117766
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    This test is for issue #28446 where module hangs if uptime is not
    available. The bug was due to struct.calcsize failing on an encoded
    string.
    """
    from ansible.module_utils.facts import hardware as hw

    class TestModule(object):
        def __init__(self, result):
            self.result = result

        def run_command(self, cmd, encoding=None):
            return self.result

    # This is the value of kern.boottime as provided by sysctl
    boottime = {'kern.boottime': '{ sec = 1512853381, usec = 0 } '}

    # encode it as bytes
    encoded_boottime = '{ sec = 1512853381, usec = 0 } '.encode()

    # Return code 0 and the encoded value

# Generated at 2022-06-11 02:30:05.334392
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hw = DarwinHardwareCollector(None)
    assert hw.platform == 'Darwin'

# Generated at 2022-06-11 02:30:06.711177
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector() is not None

# Generated at 2022-06-11 02:30:15.734390
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = MagicMock()
    mod_utils = MagicMock()
    sysctl = {
        'hw.memsize': '16471818240'
    }

# Generated at 2022-06-11 02:30:25.844312
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import os.path
    import sys
    import unittest

    # test case to use
    class DarwinHardware_test(DarwinHardware):
        def setUp(self, filepath, test_uptime):
            self.sysctl = {
                'kern.boottime': str(test_uptime)
            }

        def test_get_uptime_facts(self):
            # Get the uptime facts
            uptime_facts = self.get_uptime_facts()

            # Assert that the uptime is correct
            self.assertEqual(uptime_facts['uptime_seconds'], self.expected_uptime)

    # test directory
    test_dir = os.path.dirname(os.path.realpath(__file__))

    # specify test cases

# Generated at 2022-06-11 02:30:29.370940
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    d = DarwinHardware(module)

    expected_mac_facts = {'model': 'MacBookPro7,1','osversion': '15.6.0','osrevision': '15G22010'}

    assert d.get_mac_facts() == expected_mac_facts



# Generated at 2022-06-11 02:30:42.002088
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-11 02:30:52.997316
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleFakeModule()
    hardware = DarwinHardware()
    hardware.module = module
    module.run_command.return_value = (0, "hw.model: iMac17,1\n", "")
    expected = {
        'osversion': '19.6.0',
        'osrevision': '17G65',
        'model': 'iMac17,1'
    }
    result = hardware.get_mac_facts()
    assert result == expected, "Unexpected result"

    module.run_command.return_value = (1, "", "")
    expected = {
        'osversion': '19.6.0',
        'osrevision': '17G65'
    }
    result = hardware.get_mac_facts()
    assert result == expected, "Unexpected result"




# Generated at 2022-06-11 02:31:01.523366
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = MockModule()

    # Populate data

# Generated at 2022-06-11 02:31:08.081363
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class ModuleStub:
        class module_utils:
            class common:
                class process:
                    class get_bin_path():
                        return_value = '/usr/sbin/system_profiler'
                class run_command():
                    def run_command(self, arg):
                        system_profile = dict()
                        system_profile['Processor Name'] = "Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz"
                        system_profile['Processor Speed'] = "2.30 GHz"
                        return 0, system_profile, None
    class HardwareStub(DarwinHardware):
        module = ModuleStub()
        sysctl = dict()

        def __init__(self):
            self.sysctl['hw.logicalcpu'] = 4
            self.sysctl['hw.physicalcpu'] = 4

# Generated at 2022-06-11 02:31:09.042299
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mac_facts = DarwinHardware().get_mac_facts()
    assert isinstance(mac_facts, dict)

