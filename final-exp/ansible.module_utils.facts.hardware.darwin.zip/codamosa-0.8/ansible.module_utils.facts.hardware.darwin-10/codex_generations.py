

# Generated at 2022-06-11 02:22:34.472770
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import os
    import sys
    import time

    # Some fake values
    mock_sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-3520M CPU @ 2.90GHz',
        'machdep.cpu.core_count': 4,
    }

# Generated at 2022-06-11 02:22:41.029873
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = MagicMock()
    contents = struct.pack('@L', 100)
    module.run_command.return_value = 0, contents, None
    darwin_hardware = DarwinHardware({}, module)
    uptime_facts = darwin_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time()) - 100

# Generated at 2022-06-11 02:22:50.771411
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Create a test module
    module = AnsibleModule(
        argument_spec = dict()
    )

    # Create a test file
    testfile = tempfile.NamedTemporaryFile()

    # Create an empty file
    open(testfile.name, 'w').close()

    # Create a test file name
    testfilename = os.path.basename(testfile.name)

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a test file in the temporary directory
    testdirfile = os.path.join(tmpdir, testfilename)

    # Copy the test file to the temporary directory
    shutil.copy(testfile.name, testdirfile)

    # Create a test DarwinHardware object
    test_dh = DarwinHardware(module)

    # Create a test dictionary with empty 'sysctl

# Generated at 2022-06-11 02:23:01.894190
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():

    sysctl_out_with_model = [
        'hw.model: iMac12,2',
    ]

    sysctl_out_no_model = [
        'hw.model: Unknown',
    ]

    sysctl_out_osversion = [
        'kern.osversion: 15.6.0',
    ]

    sysctl_out_osrevision = [
        'kern.osrevision: 14G57',
    ]

    # Construct a mock module class
    class ModuleMock():
        def __init__(self, params):
            self.params = params

# Generated at 2022-06-11 02:23:07.134803
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    facts = DarwinHardware().get_cpu_facts()
    assert isinstance(facts, dict)
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_vcpus' in facts
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['processor_vcpus']

# Generated at 2022-06-11 02:23:16.734657
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module=module)
    command_results = {'rc':0, 'out': 'hw.model: Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'err':''}
    hardware.module.run_command.return_value = command_results
    hardware.sysctl = {
        'kern.boottime.tv_sec': '1489765476',
        'kern.boottime.tv_usec': '0',
        'kern.osversion': '15G31',
        'kern.osrevision': '15G31',
        }

    mac_facts = hardware.get_mac_facts()


# Generated at 2022-06-11 02:23:25.453551
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    darwin_hardware = DarwinHardware()
    darwin_hardware.sysctl = {'hw.memsize': '1048576'}
    darwin_hardware.module = mock.MagicMock()
    darwin_hardware.module.run_command.return_value = 0, "Pages free:                   14074.\nPages active:                  8284.\nPages inactive:                 819.\nPages wired down:              3126.\n", ""
    assert darwin_hardware.get_memory_facts() == {'memtotal_mb': 1, 'memfree_mb': 1}

# Generated at 2022-06-11 02:23:31.612163
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockAnsibleModule()
    module.run_command.return_value = (0, "hw.model: MacBookPro14,3", '')
    mac_facts = DarwinHardware().get_mac_facts(module)
    assert mac_facts['model'] == "MacBookPro14,3"
    assert mac_facts['product_name'] == "MacBookPro14,3"


# Generated at 2022-06-11 02:23:35.179310
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Monkey patching the module class.
    import ansible.module_utils.facts.hardware.darwin
    module = ansible.module_utils.facts.hardware.darwin.AnsibleModule(
        argument_spec={},
        bypass_checks=True,
    )
    module.run_command = run_command
    m = DarwinHardware(module)

    assert m.get_uptime_facts() == {'uptime_seconds': 1440}

# Mock for the run_command method of an AnsibleModule object.
# It returns 1440 seconds from now.

# Generated at 2022-06-11 02:23:45.272421
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class ModuleMock(object):
        def __init__(self):
            self.run_command_line_list = []
            self.run_command_patches = {}

        def run_command(self, args, encoding=None):
            rc = 0
            stdout = ''
            stderr = ''

            got_command_line = " ".join(args)
            if got_command_line not in self.run_command_line_list:
                self.run_command_line_list.append(got_command_line)

            if got_command_line in self.run_command_patches:
                patch = self.run_command_patches.get(got_command_line)
                if isinstance(patch, Exception):
                    raise patch
                else:
                    rc, stdout, stderr = patch


# Generated at 2022-06-11 02:23:56.943703
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    test_profile = DarwinHardware(dict(), dict())
    test_profile.get_system_profile()



# Generated at 2022-06-11 02:24:06.045260
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule(object):
        def __init__(self):
            self.params = dict()

        def run_command(self, cmd, **kwargs):
            self.cmd = cmd
            # Return a fake result.
            return (0, struct.pack('@L', kern_bootime), '')

        def get_bin_path(self, cmd):
            return '/usr/sbin/' + cmd

    darwin_hardware = DarwinHardware(None)

    # Set the fake boot time.
    kern_bootime = int(time.time()) - 100000

    # Assign the fake module to the class.
    darwin_hardware.module = TestModule()

    # Run the method.
    uptime_facts = darwin_hardware.get_uptime_facts()

    # Check the

# Generated at 2022-06-11 02:24:18.020040
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware(dict())

    system_profile = '''
    Hardware:

      Hardware Overview:

        Model Name: MacBook Pro
        Model Identifier: MacBookPro2,2
        Processor Name: Intel Core 2 Duo
        Processor Speed: 2 GHz
        Number of Processors: 1
        Total Number of Cores: 2
        L2 Cache: 4 MB
        Memory: 2 GB
        Bus Speed: 667 MHz
    '''

    result = darwin_hardware.get_system_profile(system_profile)

    assert result == {
        'Processor Name': 'Intel Core 2 Duo',
        'Processor Speed': '2 GHz',
        'Total Number of Cores': '2',
        'Memory': '2 GB'
    }

# Generated at 2022-06-11 02:24:19.695049
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    d = DarwinHardwareCollector()
    assert d is not None

# Generated at 2022-06-11 02:24:29.978494
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    dummy_module = object()
    memory_facts = {
        'memtotal_mb': 0,
        'memfree_mb': 0,
    }
    mock_run_command = object()
    mock_get_bin_path = object()
    mock_module = MagicMock()
    mock_module.get_bin_path = mock_get_bin_path
    mock_module.run_command = mock_run_command

    darwin_hardware = DarwinHardware(dummy_module)
    darwin_hardware.module = mock_module

    # 1st case: vm_stat command not found
    mock_get_bin_path.side_effect = ValueError

    # Call under test
    result = darwin_hardware.get_memory_facts()
    assert_equals(result, memory_facts)

# Generated at 2022-06-11 02:24:41.099020
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict

    module = FakeAnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.get_bin_path = lambda *a, **kw: get_bin_path(*a, **kw)
    module.run_command = lambda *a, **kw: FakeCommandResult()
    module.mock_command('darwin', '/bin/date', 'No matching processes belonging to you were found')

    facts = DarwinHardware(module).get_uptime_facts()
    assert facts == {'uptime_seconds': 12345}



# Generated at 2022-06-11 02:24:49.675025
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    Tests that get_uptime_facts works correctly.
    """
    import tempfile
    import shutil
    import sys
    import os

    # Create a temporary directory to place the fake sysctl executable
    tmpdir = tempfile.mkdtemp()

    # Create a fake sysctl executable with a name ending in sysctl (as real sysctl would)
    sysctl_fake = os.path.join(tmpdir, 'sysctl')
    with open(sysctl_fake, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo "Seconds since January 1, 1970 = $(date +%s)"\n')

    # Make the executable executable
    os.chmod(sysctl_fake, 0o755)

    # Add the directory containing the fake sysctl executable to the PATH environment

# Generated at 2022-06-11 02:25:00.184423
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    dummy_module = dict()


# Generated at 2022-06-11 02:25:12.305241
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    test_object = DarwinHardware(module)

    # Test with output from vm_stat without the vm_stat command
    test_object.module.run_command = Mock(return_value=(0, 'Mach Virtual Memory Statistics: (page size of 4096 bytes)', ''))
    result = test_object.get_memory_facts()
    assert_equals(result, {'memtotal_mb': 0, 'memfree_mb': 0})

    # Test with output from vm_stat with the vm_stat command

# Generated at 2022-06-11 02:25:18.063295
# Unit test for method get_memory_facts of class DarwinHardware

# Generated at 2022-06-11 02:25:45.089392
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """ Unit test for method: DarwinHardware.get_system_profile """
    module_mock = AnsibleModuleMock()

# Generated at 2022-06-11 02:25:55.831915
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class FakeModule(object):
        run_command = lambda self, t, encoding=None: setattr(self, 'last', t); return 0, '/bin/vm_stat', ''

        def get_bin_path(self, t):
            if len(self.last) > 1 and self.last[1] == t:
                return 'vm_stat'
            
            raise ValueError(t)

    facts = {
        'hw.model': 'Power Macintosh',
        'hw.physicalcpu': 1,
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5250U CPU @ 1.60GHz',
        'machdep.cpu.core_count': 2,
    }
    module = FakeModule()

    hardware = DarwinHardware(module, facts)
    cpu_facts = hardware

# Generated at 2022-06-11 02:26:01.153616
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = None
    darwin_hardware = DarwinHardware(module)
    system_profile = darwin_hardware.get_system_profile()
    assert 'model' in system_profile
    assert 'osversion' in system_profile
    assert 'osrevision' in system_profile


# Generated at 2022-06-11 02:26:03.778495
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    result = DarwinHardware().populate()
    assert result['uptime_seconds'] > 0
    assert result['memtotal_mb'] > 0
    assert result['memfree_mb'] > 0
    assert result['model'] is not None



# Generated at 2022-06-11 02:26:13.752008
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    dh = DarwinHardware({})
    # make it look like we have run vm_stat successfully
    dh.module.run_command = lambda x: (0, 'Pages free: 1232.\nPages wired down: 1.\nPages active: 2.\nPages inactive: 3.', '')
    assert dh.get_memory_facts() == {'memfree_mb': 476, 'memtotal_mb': 1234}
    dh.module.run_command = lambda x: (1, '', '')
    assert dh.get_memory_facts() == {'memtotal_mb': 1234, 'memfree_mb': 0}



# Generated at 2022-06-11 02:26:26.293262
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Create a subclass to test parent class
    class TestDarwinHardware(DarwinHardware):
        platform = 'Darwin'

    def get_sysctl(module, path):
        sysctl_dict = {
            "hw.memsize": "16777216",
            "hw.model": "Power Macintosh",
            "kern.osversion": "10.11.6",
            "kern.osrelease": "15G1504",
            "kern.osrevision": "15G1421",
            # PowerPC
            "hw.physicalcpu": "2",
            "hw.ncpu": "2",
            # Intel
            "machdep.cpu.core_count": "2"
        }

        return {k: sysctl_dict[k] for k in sysctl_dict if k in path}

   

# Generated at 2022-06-11 02:26:27.981100
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    result = Hardware().get_memory_facts()
    assert result['memtotal_mb'] == 0

# Generated at 2022-06-11 02:26:39.287548
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import platform
    import subprocess
    import sys
    import unittest

    mock_command = unittest.mock.Mock(return_value=(0, "", ""))

    class MockModule(object):
        user_bin_path = '/usr/bin/'

        def __init__(self):
            self.run_command = mock_command

    class MockRunCommand(object):
        def __init__(self, return_value):
            self.return_value = return_value

        def __call__(self, *args, **kwargs):
            return self.return_value

    mock_sysctl = {
        'hw.pagesize': '4096',
        'hw.memsize': '3',
    }


# Generated at 2022-06-11 02:26:49.845299
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class DarwinHardware"""

    # Test the default case with an Intel device
    sysctl_mock = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz',
        'machdep.cpu.core_count': 8,
    }
    system_profile = dict()
    hardware = DarwinHardware(dict(module=dict(run_command=lambda x: (0, '', '')), sysctl=sysctl_mock))
    cpu_facts = hardware.get_cpu_facts()
    assert len(cpu_facts) == 3
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz'

# Generated at 2022-06-11 02:26:52.187611
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    uptime_facts = DarwinHardware.get_uptime_facts()
    uptime_seconds = uptime_facts.get('uptime_seconds')
    assert uptime_seconds

# Generated at 2022-06-11 02:27:35.900508
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    '''Test DarwinHardwareCollector class'''
    obj = DarwinHardwareCollector()

    expected = 'DarwinHardware'
    fact_class = obj.fact_class()
    assert fact_class == expected

    expected = 'Darwin'
    platform = obj.platform()
    assert platform == expected

# Generated at 2022-06-11 02:27:44.305113
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import pytest
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    time_now = int(time.time())
    time_now_plus_five = time_now + 5
    time_now_plus_5_5 = time_now + 5.5
    time_now_plus_ten = time_now + 10

    # No value
    uptime_facts = DarwinHardware().get_uptime_facts()
    assert uptime_facts == {}

    # One valid value
    uptime_facts = DarwinHardware().get_uptime_facts([time_now])
    assert uptime_facts['uptime_seconds'] == 5

    # One out of range small value
    uptime_facts = DarwinHardware().get_uptime_facts([0])
    assert uptime_facts == {}

    # One

# Generated at 2022-06-11 02:27:50.683275
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    mac_facts = {'model': 'MacBookPro9,1', 'osversion': '15.6.0', 'osrevision': '15G22010', 'product_name': 'MacBookPro9,1'}
    if DarwinHardware().get_system_profile() == mac_facts:
        print("on DarwinHardware: get_system_profile: passes unit test")
    else:
        print("on DarwinHardware: get_system_profile: fails unit test")



# Generated at 2022-06-11 02:28:00.664606
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform
    import re

    if platform.system() != 'Darwin':
        raise Exception('test_DarwinHardware_get_uptime_facts must be run on Darwin')

    sysctl_cmd = get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    rc, out, err = module.run_command(cmd, encoding=None)

    p = re.compile('{ sec = (\d+), usec = (\d+) }')
    match = p.match(out)
    if match is not None:
        sec = int(match.group(1))
        usec = int(match.group(2))
        boottime = sec + usec * 1e-6

        d = DarwinHardware()
        uptime_facts = d.get

# Generated at 2022-06-11 02:28:10.448938
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Get an instance of DarwinHardware for testing
    darwin_hw = DarwinHardware(dict(module=None))

    # Patch darwin_hw.run_command to return a hardcoded output
    # for testing

# Generated at 2022-06-11 02:28:22.991381
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # See comment above for explanation of the format of this string.
    # This string is 64-bits seconds + 64-bits microseconds.
    kern_boottime_raw = (
        b'\x00\x00\x00\x00\x00\x00\x00\x01' +
        b'\x00\x00\x00\x00\x00\x00\x00\x00'
    )

    class MockModule(object):

        def __init__(self, sysctl_result, time_time_result):
            self.sysctl_result = sysctl_result
            self.time_time_result = time_time_result

        def get_bin_path(self, _):
            return '/sbin/sysctl'


# Generated at 2022-06-11 02:28:33.389763
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    def mock_run_command(module, command, encoding=None):
        out = struct.pack('@L', int(1416432713))
        return (0, out, '')

    def mock_get_bin_path(module, name):
        return "/usr/sbin/%s" % (name)

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch.object(DarwinHardware, 'run_command', mock_run_command):
        with patch.object(DarwinHardware, 'get_bin_path', mock_get_bin_path):
            dh = DarwinHardware()
            assert dh.get_uptime_facts() == {'uptime_seconds': 2}

# Generated at 2022-06-11 02:28:41.217875
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    set_module_args(dict(
        gather_subset='!all',
        gather_timeout=10,
    ))
    my_obj = DarwinHardware(module)
    my_obj.sysctl = dict(osversion="14.0.0", osrevision="1495.1.1")
    rc, out, err = my_obj.module.run_command("sysctl hw.model")
    result = my_obj.get_mac_facts()

    assert result['osversion'] == "14.0.0"
    assert result['osrevision'] == "1495.1.1"
    assert 'model' in result

# Generated at 2022-06-11 02:28:44.077208
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    collector = DarwinHardwareCollector()
    assert collector.platform == 'Darwin'
    assert collector.fact_class == DarwinHardware


# Generated at 2022-06-11 02:28:57.382508
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.facts import ModuleParameters

    # Create a mock module
    module = MagicMock(name='module', module_args=dict(), params=ModuleParameters(), check_mode=False, no_log=False)

# Generated at 2022-06-11 02:30:19.979404
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.processor import Processor
    module = Processor()
    module.run_command = MagicMock(side_effect=unpack_run_command)
    hardware = DarwinHardware(module=module)
    facts = hardware.get_uptime_facts()
    assert facts['uptime_seconds'] == 1416831848

# Generated at 2022-06-11 02:30:29.161266
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Testing DarwinHardware().get_cpu_facts()
    # Creating a fake module object and a fake_sysctl so that the facts
    # can be tested
    # Parameterizing the fake_sysctl in accordance with the case being tested
    fake_sysctl = {'hw.model': 'Core i7', 'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6700 CPU @ 3.40GHz'}
    fake_module = FakeAnsibleModule(**{'params': {'sysctl': fake_sysctl}})

    # Case 1:
    # Testing for a fake_sysctl with parameters machdep.cpu.brand_string and
    # hw.model
    # Expected result:
    # processor and processor_cores facts will be gathered from the sysctl
    # dictionary
    expected_

# Generated at 2022-06-11 02:30:35.750270
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    platform = 'Darwin'
    darwin_hardware_collector = DarwinHardwareCollector(platform)
    assert darwin_hardware_collector._fact_class.platform == 'Darwin'
    assert darwin_hardware_collector._platform == 'Darwin'


# Generated at 2022-06-11 02:30:37.400868
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hc = DarwinHardwareCollector()
    assert type(hc) == DarwinHardwareCollector

# Generated at 2022-06-11 02:30:48.554018
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-11 02:30:52.661191
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    system_profile = DarwinHardware().get_system_profile()
    assert system_profile == {
        'Number of Cores': '4',
        'Processor Name': 'Intel Core i5',
        'Processor Speed': '2.7 GHz',
        'Total Number of Cores': '4',
    }

# Generated at 2022-06-11 02:30:55.259407
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    darwin_hardware = DarwinHardware()
    darwin_hardware.module = AnsibleModule(argument_spec=dict())
    sys_profile = darwin_hardware.get_system_profile()
    assert sys_profile
    for field in ['SMC']:
        assert field in sys_profile

# Generated at 2022-06-11 02:30:59.124365
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    hardware_facts = DarwinHardware()
    mac_facts = hardware_facts.get_mac_facts()

    assert mac_facts['osversion'] is not None
    assert mac_facts['osrevision'] is not None
    assert mac_facts['model'] is not None

# Generated at 2022-06-11 02:31:07.010424
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # set up a dummy module, with a dummy command - this simulates a process running the module.
    # you could also run this module in an actual process, e.g. with a runner, ansible, ansible-playbook, or ad-hoc
    # command.
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # populate the HardwareCollector class with module
    hardware_collector = DarwinHardwareCollector(module)

    # populate the DarwinHardware class with self.module
    hardware = DarwinHardware(module)

    # run populate()
    hardware.populate()

    # verify hardware facts
    assert hardware.facts['osversion'] == '15.6.0'

# Generated at 2022-06-11 02:31:18.430294
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MockModule()
    hardware = DarwinHardware(module)
    # mock the sysctl function
    hardware.sysctl = {
        'machdep.cpu.brand_string': 'mocked Intel',
        'machdep.cpu.core_count': 'mocked 8',
        'hw.physicalcpu': 'mocked 2',
        'hw.logicalcpu': 'mocked 4',
        'hw.ncpu': 'mocked 6'
    }
    cpu_facts = hardware.get_cpu_facts()

    cpu_facts_expected = {
        'processor': 'mocked Intel',
        'processor_cores': 'mocked 8',
        'processor_vcpus': 'mocked 4'
    }
    assert cpu_facts == cpu_facts_expected
