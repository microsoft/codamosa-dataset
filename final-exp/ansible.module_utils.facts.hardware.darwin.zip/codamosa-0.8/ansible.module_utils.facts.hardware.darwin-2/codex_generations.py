

# Generated at 2022-06-11 02:22:33.502838
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    class FakeModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_value = (0, b'\x00\x00\x00\xC0\x9C\xD2\xB0\xB7', None)

        def run_command(self, *args, **kwargs):
            self.run_command_called = True
            return self.run_command_value

    # Basic test, validate that the returned value is correct when sysctl returns
    # the correct value.
    module = FakeModule()
    hardware = DarwinHardware(module)
    expected_uptime_seconds = int(time.time() - 1500000000)
    assert hardware.get_uptime

# Generated at 2022-06-11 02:22:36.361058
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    module = FakeAnsibleModule()
    dhc = DarwinHardwareCollector(module)
    assert dhc._platform == 'Darwin'


# Generated at 2022-06-11 02:22:48.250729
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts import timeout

    # Set up a DarwinHardware object and set some test data.
    dwh = DarwinHardware(None, timeout=timeout, sysctl={
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-6267U CPU @ 2.90GHz',
        'machdep.cpu.core_count': 2
    })

    cpu_facts = dwh.get_cpu_facts()

    # The values we get back are the same as the ones we set.

# Generated at 2022-06-11 02:22:59.205376
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    When called with a sysctl command that return 0 and a valid output,
    the get_uptime_facts method should return a dictionary containing the
    uptime in seconds.

    The result is rounded to the nearest second because uptime can be
    computed from two different sources.
    """
    module = MockAnsibleModule()
    module.run_command.return_value = (0, "\x4c\x5c\x5a\x5a\x5b\x90\x00\x00", "")

    facts = DarwinHardware(module)
    output = facts.get_uptime_facts()

    assert output == {
        'uptime_seconds': 34048,
    }


# Generated at 2022-06-11 02:23:09.350118
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    """Unit-test get_memory_facts"""
    import mock

    class MockModule:
        def __init__(self, **kwargs):
            self.params = kwargs


# Generated at 2022-06-11 02:23:17.791928
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    # Sample output of /usr/sbin/system_profiler

# Generated at 2022-06-11 02:23:28.598179
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test the system_profiler parsing method.
    """
    data = """Hardware:

    Hardware Overview:

      Model Name: Mac mini
      Model Identifier: Macmini6,2
      Processor Name: Intel Core i7
      Processor Speed: 2.6 GHz
      Number of Processors: 1
      Total Number of Cores: 4
      L2 Cache (per Core): 256 KB
      L3 Cache: 6 MB
      Memory: 16 GB
      Boot ROM Version: MM61.0106.B00
      SMC Version (system): 2.12f44
      Serial Number (system): C02KJ15PFFV5
      Hardware UUID: 98E4882E-9D82-59A0-B7FD-23F697D77A69

    """
    d = DarwinHardware(dict(module=dict()))
   

# Generated at 2022-06-11 02:23:39.977055
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import unittest
    import copy
    class MockVmStatModule():
        def run_command(self, command):
            if command == ['vm_stat']:
                return 0, "Pages free:  393032.\nPages active:  400764.\nPages inactive:  398138.\nPages wired down:  610515.\n", ""
            raise Exception("Unexpected command '%s'" % command)

        def get_bin_path(self, cmd):
            if cmd == 'vm_stat':
                return 'vm_stat'

        def fail_json(self, failed, failed_msg):
            raise Exception(failed_msg)

    class MockSysctlModule():
        def __init__(self):
            self.sysctl = dict()

# Generated at 2022-06-11 02:23:50.941946
# Unit test for method get_uptime_facts of class DarwinHardware

# Generated at 2022-06-11 02:23:59.807470
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    mh = DarwinHardware(module)

    mac_facts = mh.get_mac_facts()
    assert isinstance(mac_facts['model'], str), 'model should be a string'
    assert isinstance(mac_facts['osversion'], str), 'osversion should be a string'
    assert isinstance(mac_facts['osrevision'], str), 'osrevision should be a string'



# Generated at 2022-06-11 02:24:14.050624
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class FakeModule:
        def run_command(self, c):
            return 0, 'hw.model: iMac9,1', ''

    results = DarwinHardware(FakeModule()).get_mac_facts()
    assert results['model'] == 'iMac9,1'


# Generated at 2022-06-11 02:24:18.318302
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert('memtotal_mb' in memory_facts)
    assert('memfree_mb' in memory_facts)

# Generated at 2022-06-11 02:24:28.378881
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Given a mac with a boot time of 10 seconds
    boottime_seconds = 10
    boottime_value = struct.pack('@L', boottime_seconds)

    # And a mocked module
    class module(object):
        def get_bin_path(self, binary_name):
            return binary_name

        def run_command(self, cmd, encoding=None):
            return (0, boottime_value, '')

    # And a DarwinHardware instance
    hardware = DarwinHardware(module())

    # When I get the uptime facts
    uptime_facts = hardware.get_uptime_facts()

    # Then they should be the uptime of the system
    assert uptime_facts['uptime_seconds'] == int(time.time() - boottime_seconds)

# Generated at 2022-06-11 02:24:34.696081
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    hardware = DarwinHardware({'module': None})
    hardware.sysctl = {
        'hw.memsize': '2048',
        'hw.pagesize': '4096',
    }
    hardware._run_command = lambda x: (0, '', '')

    memory_stats = {
        'Pages wired down': '1024',
        'Pages active': '512',
        'Pages inactive': '256',
    }
    hardware._system_profile = lambda x: memory_stats

    mem_facts = hardware.get_memory_facts()
    assert mem_facts['memtotal_mb'] == 2
    assert mem_facts['memfree_mb'] == 0

# Generated at 2022-06-11 02:24:37.084899
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils import basic  # noqa

    module = basic.AnsibleModule(argument_spec={})
    hw = DarwinHardware(module)
    system_profile = hw.get_system_profile()
    assert system_profile['Machine Name'] == 'Ansible Test'

# Generated at 2022-06-11 02:24:42.214476
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    test_darwin = DarwinHardware()
    test_darwin.module = None

    facts = test_darwin.get_mac_facts()
    assert facts.get("model")
    assert facts.get("osversion")
    assert facts.get("osrevision")

# Generated at 2022-06-11 02:24:52.250530
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Simulate an uptime of 3 minutes and 4 seconds
    uptime_time = 4 + 60 * 3
    # The machine was started at this datetime
    start_time = datetime.now() - timedelta(seconds=uptime_time)
    # The corresponding boottime is this value
    boottime = int(time.mktime(start_time.timetuple()))
    # Create a fake DarwinHardware class instance
    test_instance = DarwinHardware()
    # Store the raw boottime value and the boottime in seconds
    test_instance.sysctl = {
        'kern.boottime': '\x00\x00\x00\x00\x00\x00\x00\x00',
        'kern.boottime.seconds': boottime,
    }
    # Check that the get_uptime_facts method returns

# Generated at 2022-06-11 02:25:02.265520
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # initialize the module
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['all']
    module.exit_json = exit_json

    # initialize the class
    hardware_obj = DarwinHardware(module)

    hardware_obj.sysctl = dict(
        hw=dict(
            memsize=4294967296,
        ),
        machdep=dict(
            cpu=dict(
                core_count=1,
                brand_string='Intel(R) Core(TM) i5-8259U CPU @ 2.30GHz'
            )
        ),
        kern=dict(
            osversion='15.6.0',
            osrevision=0,
        )
    )


# Generated at 2022-06-11 02:25:02.999586
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-11 02:25:04.430730
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Create an instance of DarwinHardware
    obj = DarwinHardware(module=None)

    # Call get_system_profile()
    obj.get_system_profile()

# Generated at 2022-06-11 02:25:34.105513
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())

    m_get_bin_path = MagicMock()
    m_module = MagicMock(run_command=MagicMock(return_value=(0, '', '')), get_bin_path=m_get_bin_path, params=dict())

    # test 'processor_cores' and 'processor_vcpus' (Intel platform, MacOS)
    m_get_bin_path.reset_mock()
    m_module.run_command.reset_mock()
    m_module.params = dict(gather_subset=['!all', '!min'])

# Generated at 2022-06-11 02:25:35.166662
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x.platform == 'Darwin'
    assert x._fact_class == DarwinHardware

# Generated at 2022-06-11 02:25:43.356697
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class TestModule:
        def run_command(self, command):
            return (0, """Hardware:

Hardware Overview:

Model Name: MacBook Air
Model Identifier: MacBookAir5,2
Processor Name: Intel Core i7
Processor Speed: 1.8 GHz
Number of Processors: 1
Total Number of Cores: 2
L2 Cache (per Core): 256 KB
L3 Cache: 4 MB
Memory: 8 GB
Boot ROM Version: MBA51.00EF.B01
SMC Version (system): 2.13f15
Serial Number (system): C02KH4DZFFW4
Hardware UUID: 97AD7F69-D5B2-5A3A-B5F5-5E5A5A5B5C5D

""", "")

# Generated at 2022-06-11 02:25:53.370840
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    import sys
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    def _exec_command(cmd, check_rc=True, cwd=None):
        if 'sysctl hw.machdep.cpu.brand_string' in cmd:
            return 0, 'hw.machdep.cpu.brand_string: Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz\n', ''
        elif 'sysctl hw.machdep.cpu.core_count' in cmd:
            return 0, 'hw.machdep.cpu.core_count: 4\n', ''

# Generated at 2022-06-11 02:26:04.459886
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class TestModule(object):
        def __init__(self, returncode, out):
            self.run_command_results = list()
            self.run_command_calls = list()
            self.run_command_results.append((returncode, out, None))

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            out = self.run_command_results.pop(0)
            return out

    test_module = TestModule(0, b'\x00\x00\x00\x00\x00\x00\x00\x00')
    dh = DarwinHardware(test_module)
    facts = dh

# Generated at 2022-06-11 02:26:07.231149
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    darwin = DarwinHardware(module)
    ret = darwin.populate()
    assert type(ret) == dict

# Generated at 2022-06-11 02:26:16.589119
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # input facts
    sysctl_fact = {}
    sysctl_fact['machdep.cpu.brand_string'] = 'Intel'
    sysctl_fact['machdep.cpu.core_count'] = '10'
    sysctl_fact['hw.physicalcpu'] = '4'
    sysctl_fact['hw.logicalcpu'] = '4'
    sysctl_fact['hw.ncpu'] = '4'

    # system_profile for PowerPC
    system_profile = {}
    system_profile['Processor Name'] = 'PowerPC'
    system_profile['Processor Speed'] = '1024'

    # result
    cpu_facts = {}

    # expected output facts
    cpu_facts['processor'] = 'Intel'
    cpu_facts['processor_cores'] = '10'

# Generated at 2022-06-11 02:26:29.258613
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import sys

    if sys.version_info.major == 2:
        from mock import patch, MagicMock
    else:
        from unittest.mock import patch, MagicMock

    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.facts import Facts

    # test variable for DarwinHardware.get_memory_facts()
    vm_stat_command = '/usr/bin/vm_stat'
    vm_stat_command_fail = '/usr/bin/vm_stat_fail'

    # test variable for run_command()
    rc = 0
    err = ''

    # test variables for Facts.gather()
    ansible_facts = dict()

    # test function for module mock

# Generated at 2022-06-11 02:26:40.158204
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils._text import to_bytes

    mac_facts = DarwinHardware()
    mac_facts.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz',
        'machdep.cpu.core_count': 4,
        'hw.physicalcpu': 4,
        'hw.logicalcpu': 8,
    }
    cpu_facts = mac_facts.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz'
    assert cpu_facts['processor_cores'] == 4

# Generated at 2022-06-11 02:26:45.965382
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.six import StringIO
    module_mock = Mock()
    module_mock.run_command.return_value = (0, StringIO('Memory: 16 GB\n'), '')
    darwin_hardware = DarwinHardware(module_mock)
    system_profile = darwin_hardware.get_system_profile()
    assert system_profile['Memory'] == '16 GB'

# Generated at 2022-06-11 02:27:30.490851
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "hw.model: MacBookAir6,2\n", "")

    hardware = DarwinHardware(module)
    facts = hardware.get_mac_facts()
    assert 'osversion' in facts
    assert 'osrevision' in facts
    assert 'model' in facts


# Generated at 2022-06-11 02:27:38.364517
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # Populate a dictionary representing the output of sysctl
    # This dictionary will be passed as the argument `sysctl` to the method
    sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz',
        'machdep.cpu.core_count': '2',
        'hw.physicalcpu': '1',
    }

    # Instantiate an object of class DarwinHardware
    mac_hardware = DarwinHardware(dict(), dict(), dict(), sysctl)

    # Invoke the method that we are testing
    cpu_facts = mac_hardware.get_cpu_facts()

    # Verify the results

# Generated at 2022-06-11 02:27:42.929265
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hardware_collector = collector.get_collector(module, 'hardware')
    hardware_collector.collect()
    hardware_obj = hardware_collector.get_facts()
    return hardware_obj.get_system_profile()

# Generated at 2022-06-11 02:27:43.767553
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()


# Generated at 2022-06-11 02:27:53.840099
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # for explanation of this syntax, see:
    #   http://stackoverflow.com/questions/1132941/least-astonishment-in-python-the-mutable-default-argument

    class Mock(object):
        pass

    module = Mock()

# Generated at 2022-06-11 02:27:54.245534
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-11 02:28:03.053636
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    mac_facts = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM)2 Duo CPU     T9300  @ 2.50GHz',
        'machdep.cpu.core_count': '2'
    }
    module = FakeModule(args={}, facts={'ansible_facts': {}})
    h = DarwinHardware(module)
    h.sysctl = mac_facts
    cpu_facts = h.get_cpu_facts()
    assert(cpu_facts['processor'] == 'Intel(R) Core(TM)2 Duo CPU     T9300  @ 2.50GHz')
    assert(cpu_facts['processor_cores'] == '2')



# Generated at 2022-06-11 02:28:08.761349
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware

    obj = DarwinHardware({})
    obj.module.run_command = lambda cmd: (0, struct.pack('@L', 1568769063), None)
    data = obj.get_uptime_facts()

    # Check if method returns the correct uptime.
    assert data['uptime_seconds'] == 1568769063

# Generated at 2022-06-11 02:28:21.227117
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    text = '''
            Pageins: 3975
            Pageouts: 0
            Translated Faults: 67
            Zero fill pages: 4167
            File-backed pages: 4
            Copy-on-write faults: 1483
            Copy-on-write optimized faults: 1
            Kernel alloc once: 10164
            Kernel alloc permanent: 1248
            Kernel alloc permanent physical: 524
            '''
    module = type('', (), {})
    module.run_command = lambda cmd: (0, text, '')
    module.get_bin_path = lambda cmd: '/usr/bin/vm_stat'
    hardware = DarwinHardware(module, None)
    facts = hardware.get_memory_facts()
    assert facts == {'memfree_mb': 622, 'memtotal_mb': 8192}

# Generated at 2022-06-11 02:28:27.599880
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    """
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    class FakeModule(object):
        def __init__(self, text):
            self.run_command_return_value = 0, text, ''

        def run_command(self, args):
            return self.run_command_return_value


# Generated at 2022-06-11 02:29:52.586447
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    with open('tests/unit/facts/fixtures/hardware/mac_hardware.txt') as sysctl_file:
        sysctl_file_facts = sysctl_file.read()

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True
    )
    # test default
    dynamic_module = DarwinHardware(module=module)
    default_populate_result = dynamic_module.populate(dict())
    assert len(default_populate_result) == 5
    assert default_populate_result['processor'] == 'Intel(R) Core(TM) i3-2105 CPU @ 3.10GHz'
    assert default_populate_result['processor_cores']

# Generated at 2022-06-11 02:30:01.090998
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    class Module(object):
        def __init__(self):
            self.supports_check_mode = False
            self.run_command_results = [(0, """
Hardware Overview:

  Hardware Overview:

    Model Name: MacBook Air
    Model Identifier: MacBookAir5,1
    Processor Name: Intel Core i7
    Processor Speed: 1.7 GHz
    Number of Processors: 1
    Total Number of Cores: 2
    L2 Cache (per Core): 256 KB
    L3 Cache: 4 MB
    Memory: 8 GB
    Boot ROM Version: MBA51.00EF.B03
    SMC Version (system): 2.9f7
    Serial Number (system): C02KQ4J4DVH4
    Hardware UUID: 0000000-000-000-000000
    """, "")]


# Generated at 2022-06-11 02:30:05.175854
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    if not find_executable('system_profiler'):
        pytest.skip('Skipping due to missing system_profiler executable')
    darwinhw = DarwinHardware()
    assert 'Serial Number' in darwinhw.get_system_profile()


# Generated at 2022-06-11 02:30:12.475482
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    import time
    clock = time.time()
    class MockedModule:
        def __init__(self, time=clock):
            self.run_command_rc = 0
            self.run_command_output = struct.pack('@L', int(time))
        def run_command(self, cmd, encoding=None):
            return (self.run_command_rc, self.run_command_output, '')
        def get_bin_path(self, cmd):
            return cmd

    m = MockedModule(clock)
    dh = DarwinHardware(m)
    uptime_facts = dh.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 0
    clock34 = clock + 34

# Generated at 2022-06-11 02:30:13.994158
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector

# Generated at 2022-06-11 02:30:16.724775
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    # Test instantiation of class DarwinHardwareCollector
    obj = DarwinHardwareCollector()

    # Test instance of class DarwinHardwareCollector
    assert isinstance(obj, DarwinHardwareCollector)


# Generated at 2022-06-11 02:30:18.532335
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = FakeAnsibleModule()
    darwin_facts = DarwinHardware(module)
    darwin_facts.get_mac_facts()

# Generated at 2022-06-11 02:30:28.409935
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils import basic
    import os

    # Define the contents of a file

# Generated at 2022-06-11 02:30:39.258836
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hw = DarwinHardware()
    hw.sysctl = {
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i7-6Y75 CPU @ 1.20GHz',
        'machdep.cpu.core_count': 4,
    }
    hw.module = AnsibleModule(argument_spec={'filter': {'required': False, 'type': 'list'}})
    facts = hw.populate()
    assert facts['processor'] == 'Intel(R) Core(TM) i7-6Y75 CPU @ 1.20GHz'
    assert facts['processor_cores'] == 4



# Generated at 2022-06-11 02:30:50.373865
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    obj = DarwinHardware()
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes