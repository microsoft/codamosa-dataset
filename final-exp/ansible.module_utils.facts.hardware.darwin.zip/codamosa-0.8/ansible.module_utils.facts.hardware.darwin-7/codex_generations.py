

# Generated at 2022-06-11 02:22:36.495881
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    class TestObj:
        def __init__(self):
            self.sysctl = {}

        def run_command(self, cmd, encoding=None):
            if cmd[0] == '/usr/sbin/sysctl':
                if cmd[1] == 'hw.model':
                    return 0, 'hw.model: PowerMac7,2\n', None
                if cmd[1] in ['hw.physicalcpu', 'hw.logicalcpu']:
                    return 0, '%s: 4\n' % cmd[1], None
                if cmd[1] == 'hw.memsize':
                    return 0, 'hw.memsize: 200000000\n', None
            elif cmd[0] == '/usr/sbin/system_profiler':
                if cmd[1] == 'SPHardwareDataType':
                    return 0,

# Generated at 2022-06-11 02:22:47.034010
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    # create a module mock
    class ModuleMock(object):
        def run_command(self, cmd, encoding=None):
            return 0, struct.pack('@L', 123456789), ''

        def get_bin_path(self, name):
            return 'sysctl'

    # create an instance of DarwinHardware
    dh = DarwinHardware(ModuleMock())

    # set expected values
    expected = {
        'uptime_seconds': int(time.time() - 123456789),
    }

    # run the code to test
    actual = dh.get_uptime_facts()

    # compare expected and actual results
    assert actual == expected

# Generated at 2022-06-11 02:22:59.538047
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    '''
    This method is not tested by default as it depends on sysctl output
    that varies with the platform and the state of the system.
    Unit test has been written to test the method

    The method is tested on MacOSX 10.12.6

    Command run: sysctl -b kern.boottime

    Command output:
    (boot time)
    1502116645.000000000
    '''

    class MockModule(object):
        def __init__(self):
            self.run_command_args = ()

        def run_command(self, args):
            self.run_command_args = args
            output = b'\x1d\xa5\x8b\x92\x00\x00\x00\x00\x00\x00\x00\x00'
            rc = 0
           

# Generated at 2022-06-11 02:23:09.656820
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    """
    Tests DarwinHardware.get_uptime_facts
    """
    raw_val = b'1371177527 2\x00\x00\x00\x00\x00\x00'
    expected_result = {
        'uptime_seconds': int(time.time() - 1371177527),
    }

    class Module(object):
        def __init__(self, raw_output):
            self.raw_output = raw_output

        def run_command(self, cmd, encoding=None):
            return 0, self.raw_output, None

    class Hardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    test_obj = Hardware(Module(raw_val))
    result = test_obj.get_uptime_facts()

# Generated at 2022-06-11 02:23:13.316517
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    from ansible.module_utils.facts.system.hardware import HardwareInfo
    assert issubclass(DarwinHardwareCollector, HardwareInfo)
    assert DarwinHardwareCollector._fact_class == DarwinHardware
    assert DarwinHardwareCollector._platform == 'Darwin'


# Generated at 2022-06-11 02:23:20.800208
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)

    with patch.object(module, 'run_command', return_value=(0, '', '')):
        with patch.object(DarwinHardware, 'get_system_profile', return_value=dict()):
            with patch.object(DarwinHardware, 'sysctl', return_value=dict(
                    hw_memsize='4294967296',
            )):
                memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['memfree_mb'] == 0


# Generated at 2022-06-11 02:23:30.419854
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, "hw.model: MacBookPro12,1\nsysctl: unknown oid 'hw.model1'", ""))
    test_module.get_bin_path = MagicMock(return_value='/usr/sbin/sysctl')

    test_obj = DarwinHardware(test_module)
    test_obj.sysctl = {'kern.osversion': '16.7.0', 'kern.osrevision': '15R58'}
    test_obj_facts = test_obj.get_mac_facts()
    assert test_obj_facts['model'] == 'MacBookPro12,1'

# Generated at 2022-06-11 02:23:40.998831
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Test with a mocked vm_stat output.
    module = MockAnsibleModule()
    with patch.object(DarwinHardware, 'get_system_profile', return_value={}):
        hardware = DarwinHardware(module)

# Generated at 2022-06-11 02:23:49.724172
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes

    m = MagicMock(spec_set=['run_command', 'get_bin_path'])
    m.get_bin_path.return_value = '/usr/sbin/sysctl'
    m.run_command.return_value = (0, to_bytes(b'kern.boottime: { sec = 5, usec = 704293 }\n'), '')

    hw = DarwinHardware(m)
    uptime_facts = hw.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 5

# Generated at 2022-06-11 02:23:55.009071
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = DarwinHardware(module)
    mac_facts = hardware_obj.get_mac_facts()
    assert 'model' in mac_facts
    assert 'osversion' in mac_facts
    assert 'osrevision' in mac_facts


# Generated at 2022-06-11 02:24:12.694884
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    hardware = DarwinHardware()
    hardware.sysctl = {'test': {'test': 'test'}}

    # populate method is called before get_cpu_facts to set sysctl
    hardware.populate()
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-5350U CPU @ 1.80GHz'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor_vcpus'] == '2'


# Generated at 2022-06-11 02:24:22.182290
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class FakeModule(object):
        def __init__(self, module_utils):
            self.module_utils = module_utils

        def get_bin_path(self, path, required=False):
            return '/usr/bin/vm_stat'


# Generated at 2022-06-11 02:24:30.455303
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModuleMock()

    # With 4GB of memory, we should have 3.5GB of ram free.
    # However, we have to round the value and finally get 3GB of free ram.
    total_memory = 356515840
    module.run_command.return_value = (0,
                                       "Mach Virtual Memory Statistics: (page size of 4096 bytes)\n" +
                                       "Pages free:                            7051768.\n" +
                                       "Pages active:                          2155168.\n" +
                                       "Pages inactive:                        1469772.\n" +
                                       "Pages wired down:                         4876.\n",
                                       "")
    module.get_bin_path.return_value = "/usr/bin/vm_stat"

# Generated at 2022-06-11 02:24:35.504854
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    harware = DarwinHardware(module)
    result = harware.get_mac_facts()

    assert result is not None


# Generated at 2022-06-11 02:24:46.171943
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class FakeModule():
        def __init__(self):
            def run_command(self, command, encoding=None):
                if command[0] == 'sysctl':
                    return (0, "hw.memsize: 2147483648", "")

# Generated at 2022-06-11 02:24:48.624190
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    darwin_hw = DarwinHardware({})
    uptime_facts = darwin_hw.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-11 02:24:56.438554
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MockModule()
    hardware = DarwinHardware(module)
    sysctl = dict(kern=dict(osversion='version', osrevision='revision'), hw=dict(model='model'))
    hardware.sysctl = sysctl
    mac_facts = hardware.get_mac_facts()

    assert mac_facts['osversion'] == sysctl['kern']['osversion']
    assert mac_facts['osrevision'] == sysctl['kern']['osrevision']
    assert mac_facts['model'] == sysctl['hw']['model']


# Generated at 2022-06-11 02:25:04.428957
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Test the DarwinHardware.get_system_profile method
    """

    def mock_run_command(module, cmd, encoding=None):
        """
        Run command function
        """
        if cmd == ["/usr/sbin/system_profiler", "SPHardwareDataType"]:
            with open('test/unit/module_utils/facts/system_profiler.txt', 'r') as system_profiler_file:
                return (0, system_profiler_file.read(), '')

        raise Exception('Unsupported command')

    def mock_get_bin_path(module, name):
        """
        Get path of a binary
        """
        return name


# Generated at 2022-06-11 02:25:14.200175
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import subprocess
    import tempfile

    # Test case 1: no wired, active, or inactive page values
    test_case = """
    Mach Virtual Memory Statistics: (page size of 4096 bytes)
    Pages free:                                   1477.
    Pages inactive:                                  0.
    Pages active:                                    0.
    Pages wired down:                                0.
    """.strip()

    # Test case 2: wired, active, and inactive page values
    test_case2 = """
    Mach Virtual Memory Statistics: (page size of 4096 bytes)
    Pages free:                                   1477.
    Pages inactive:                                  0.
    Pages active:                                    0.
    Pages wired down:                                0.
    """.strip()


# Generated at 2022-06-11 02:25:21.549828
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = MagicMock()
    path = {'rc': 0, 'out': '', 'err': '', 'stdout': '', 'stderr': ''}
    module.run_command.return_value = path['rc'], path['out'], path['err']

    obj = DarwinHardware(module)
    obj.get_mac_facts()

    module.run_command.assert_called_with("sysctl hw.model")

# Generated at 2022-06-11 02:25:49.895294
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import pytest
    module = pytest.Mock()
    module.run_command.return_value = (0, struct.pack('@Q', 1506373950), '')
    hardware = DarwinHardware(module)
    expected_dict = {
        'uptime_seconds': int(time.time() - 1506373950),
    }
    assert hardware.get_uptime_facts() == expected_dict

# Generated at 2022-06-11 02:26:01.607717
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec=dict())
    hardware = DarwinHardware(module=module)

# Generated at 2022-06-11 02:26:04.984039
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    hardware_facts = DarwinHardware().populate()

    module.exit_json(
        ansible_facts=dict(
            hardware=hardware_facts,
        ),
    )


# Generated at 2022-06-11 02:26:13.586635
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = dict(
        kern_osversion="14.0.0",
        kern_osrevision="14C109",
        hw_model="MacBookPro11,2",
    )
    expected_facts = dict(
        model="MacBookPro11,2",
        product_name="MacBookPro11,2",
        osversion="14.0.0",
        osrevision="14C109",
    )
    assert hardware.get_mac_facts() == expected_facts

# Generated at 2022-06-11 02:26:18.791274
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, unit_test_vm_stat_output, '')
    hardware = DarwinHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memfree_mb'] == 964


# Generated at 2022-06-11 02:26:31.376138
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import pytest
    module = pytest.Mock()

# Generated at 2022-06-11 02:26:34.354059
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware = DarwinHardwareCollector()
    assert darwin_hardware._fact_class is not None
    assert darwin_hardware._platform == 'Darwin'

# Generated at 2022-06-11 02:26:38.841332
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = get_fixture_data('darwin_vmstat.txt')
    hardware = DarwinHardware()
    hardware.module = module

    facts = hardware.get_memory_facts()

    assert facts['memtotal_mb'] == 16384
    assert facts['memfree_mb'] == 1929



# Generated at 2022-06-11 02:26:49.561060
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = DarwinHardware(module)

    # Test for Intel
    sysctl_mock = FakeSysctl()
    sysctl_mock.values['machdep.cpu.brand_string'] = 'Intel(R) Core(TM) i5-6267U CPU @ 2.90GHz'
    sysctl_mock.values['machdep.cpu.core_count'] = 2
    hardware.sysctl = sysctl_mock
    assert hardware.get_cpu_facts() == {
        'processor': 'Intel(R) Core(TM) i5-6267U CPU @ 2.90GHz',
        'processor_cores': 2,
        'processor_vcpus': '',
    }

    # Test for PowerPC
    sysctl_mock = FakeSysctl()
    sys

# Generated at 2022-06-11 02:26:50.531554
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    facts_collector = DarwinHardwareCollector()

# Generated at 2022-06-11 02:27:45.510909
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible_collections.ansible.community.plugins.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.utils import mock_module
    module = mock_module()
    hw_facts = DarwinHardware(module)

    time_values = [0, 10, 60, 3600]
    expected_values = [
        {'uptime_seconds': 0},
        {'uptime_seconds': 10},
        {'uptime_seconds': 60},
        {'uptime_seconds': 3600},
    ]
    for index, time_value in enumerate(time_values):
        now = time.time()
        time_tuple = (time_value, 0)

# Generated at 2022-06-11 02:27:48.731485
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    facts = {}
    DarwinHardwareCollector(facts, None)
    assert facts['processor_cores'] == 1
    assert facts['memtotal_mb'] == 1

# Generated at 2022-06-11 02:27:54.518097
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a DarwinHardware object, call get_uptime_facts()
    # and check the result
    from ansible.module_utils.facts.module import get_module_info

    mo = get_module_info(dict(), dict())
    d = DarwinHardware(mo)
    assert d.get_uptime_facts() == {
        'uptime_seconds': int(time.time() - float(mo.run_command(['date', '+%s'])[1]))
    }

# Generated at 2022-06-11 02:28:04.444101
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Hard-coded value of kern.boottime used in tests
    kern_boottime = 1544800000
    uptime_fact = {
        'uptime_seconds' : int(time.time() - kern_boottime)
    }
    # Create a mock module object
    mock_module = MockModule()
    # Mock the method for getting bin path
    mock_module.get_bin_path = mock_bin_path

    # Create the object of class DarwinHardware
    harware = DarwinHardware(mock_module)

    # Run the get_uptime_facts method with hardcoded value
    out = harware.get_uptime_facts_test(kern_boottime)

    # assert equal of the output & uptime_fact
    assert out == uptime_fact


# Generated at 2022-06-11 02:28:13.001813
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():

    # input
    sysctl_cmd = '/usr/sbin/sysctl'
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    boot_time = 1504945952

    # result
    expected_result = {
        'uptime_seconds': int(time.time() - boot_time),
    }

    # invoke tested method
    #
    # the tested method get_uptime_facts needs to run project_get_bin_path
    # for finding 'sysctl' command.
    # Its result is cached by 'ansible.module_utils.facts.sysctl.get_bin_path_cache'.
    # So, let's flush the cache before test.
    sysctl_module = __import__('ansible.module_utils.facts.sysctl')
    sysctl_module.get_

# Generated at 2022-06-11 02:28:24.457427
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    test_fixture = dict(
        dict(
            module_name="system_profiler",
            module_path="/usr/sbin/system_profiler",
            module_args="SPHardwareDataType",
            module_flags=dict(changed=False, rc=0, stdout="", stderr=""),
            chdir=None
        )
    )

# Generated at 2022-06-11 02:28:29.907440
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    module = MagicMock(run_command=lambda cmd: (0, struct.pack('@L', int(time.time() - 3600)), None))
    hw = DarwinHardware(module)
    uptime_facts = hw.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 3600

# Generated at 2022-06-11 02:28:33.023018
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hw_collector = DarwinHardwareCollector()
    assert darwin_hw_collector._platform == DarwinHardwareCollector._platform
    assert darwin_hw_collector._fact_class is not None

# Generated at 2022-06-11 02:28:41.049050
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    mac_facts = DarwinHardware(module).populate()
    assert isinstance(mac_facts, dict)
    assert isinstance(mac_facts['processor'], str)
    assert isinstance(mac_facts['processor_cores'], str)
    assert isinstance(mac_facts['memfree_mb'], int)
    assert isinstance(mac_facts['memtotal_mb'], int)
    assert isinstance(mac_facts['model'], str)
    assert isinstance(mac_facts['osrevision'], str)
    assert isinstance(mac_facts['osversion'], str)
    assert isinstance(mac_facts['uptime_seconds'], int)

# Generated at 2022-06-11 02:28:54.223129
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes

    # Create a minimal module
    class FakeModule(object):
        def __init__(self):
            self.fail_json = Display().error
            self.get_bin_path = lambda command: 'sysctl'

        def run_command(self, cmd, check_rc=True, encoding=None):
            if cmd[0] == 'sysctl':
                # We need to see raw bytes, not UTF-8.
                boottime = struct.pack('@L', 0)
                return 0, boottime, b''
            raise AnsibleError('unexpected command %s' % cmd)


# Generated at 2022-06-11 02:30:45.011616
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    from ansible.module_utils.six import b

    module = DummyModule()
    module.run_command.return_value = (0, b(''), '')

    hardware = DarwinHardware(module)
    hardware.sysctl = {
        'hw.model': 'iMac14,2',
        'hw.memsize': 134217728,
        'hw.physicalcpu': 4,
        'kern.osversion': '15.2.0',
        'kern.osrevision': '15.2.0',
    }
    hardware.get_system_profile = lambda: {
        'Processor Name': 'Intel Core i5',
        'Processor Speed': '2.7 GHz',
    }


# Generated at 2022-06-11 02:30:55.173906
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    memory_facts = {
        'memtotal_mb': 0,
        'memfree_mb': 0,
    }

    module = mock.Mock()
    module.run_command.return_value = (0, to_bytes(''), to_bytes(''))

    with patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.hardware.darwin.get_bin_path', return_value=None):
        mock_

# Generated at 2022-06-11 02:30:58.219974
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    """Test constructor of class DarwinHardwareCollector"""
    module = AnsibleModuleMock(platform='Darwin')
    # This should never fail
    assert DarwinHardwareCollector(module)



# Generated at 2022-06-11 02:31:06.563602
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class DummyModule:
        def __init__(self):
            self.run_command = self.mock_run_command


# Generated at 2022-06-11 02:31:18.298863
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'hw.model: MacBookPro1,1\nmachdep.cpu.brand_string: "Intel(R) Core(TM)2 Duo CPU     P8600  @ 2.40GHz"\nmachdep.cpu.core_count: 2\nmachdep.cpu.thread_count: 4\n', None)
    darwin_hardware = DarwinHardware(module)
    darwin_hardware.sysctl = {
        'hw.model': 'MacBookPro1,1',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM)2 Duo CPU     P8600  @ 2.40GHz',
        'machdep.cpu.core_count': '2',
    }
    mac_facts

# Generated at 2022-06-11 02:31:25.128289
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    fact_data = dict()
    fact_data['sysctl'] = dict()
    fact_data['sysctl']['kern.osversion'] = '12'
    fact_data['sysctl']['kern.osrevision'] = '19'
    fact_data['module'] = dict()
    fact_data['module']['run_command'] = dict()
    fact_data['module']['run_command'] = mock_run_command

    hardware = DarwinHardware(fact_data)
    hardware_facts = hardware.populate()

# Generated at 2022-06-11 02:31:34.273684
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import sys
    import io

    # Create a fake module for mocking the module.run_command call

# Generated at 2022-06-11 02:31:37.849158
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    try:
        assert isinstance(DarwinHardwareCollector(), HardwareCollector)
        print ('Test passed : The object is an instance of HardwareCollector')
    except AssertionError:
        print ('Test failed : The object is not an instance of HardwareCollector')

# Generated at 2022-06-11 02:31:39.784856
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_hardware = DarwinHardwareCollector()
    assert darwin_hardware._fact_class == DarwinHardware
    assert darwin_hardware._platform == "Darwin"

# Generated at 2022-06-11 02:31:47.665331
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self):
            self.run_command = basic.run_command
            self.params = {}
            self.exit_json = exit_json

        def fail_json(self, *args, **kwargs):
            self.exit_json(*args, **kwargs)

    def exit_json(*args, **kwargs):
        pass

    module = FakeModule()
    result = {}
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
