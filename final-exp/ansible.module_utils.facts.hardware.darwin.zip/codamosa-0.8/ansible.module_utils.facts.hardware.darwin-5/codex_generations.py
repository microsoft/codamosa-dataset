

# Generated at 2022-06-11 02:22:27.850217
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    # Given
    module_mock = mock.MagicMock()
    module_mock.run_command.return_value = (0, '\n'.join(['A: B', 'C: D E F G H I J']), '')
    hw_mock = DarwinHardware(module_mock)

    # When
    system_profile = hw_mock.get_system_profile()

    # Then
    assert system_profile == {
        'A': 'B',
        'C': 'D E F G H I J'
    }

# Generated at 2022-06-11 02:22:37.861968
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    import platform
    import sys
    import unittest

    import ansible.module_utils.facts.hardware.darwin as darwin


# Generated at 2022-06-11 02:22:49.090987
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class ModuleStub():
        @staticmethod
        def run_command(cmd, encoding=None):
            return 0, "", ""
    class HardwareStub(DarwinHardware):
        module = ModuleStub()

    test_dict = {'hw.model': 'MacBookPro13,3', 'kern.osversion': '15.6.0', 'kern.osrevision': '18G5033'}
    h = HardwareStub()
    h.sysctl = test_dict
    facts = h.get_mac_facts()
    assert 'model' in facts and facts['model'] == 'MacBookPro13,3'
    assert 'osversion' in facts and facts['osversion'] == '15.6.0'
    assert 'osrevision' in facts and facts['osrevision'] == '18G5033'

# Generated at 2022-06-11 02:22:51.549587
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    module = get_fake_module()
    ch = DarwinHardware(module=module)
    facts = ch.get_mac_facts()
    assert facts['osversion'] == '19.2.0'
    assert facts['osrevision'] == '1550.14.1'

# Generated at 2022-06-11 02:23:01.752966
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    darwin_hardware = DarwinHardware()

    # Intel
    darwin_hardware.sysctl = {
        'hw.memsize': 4294967296,
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i9-9880H CPU @ 2.30GHz',
        'machdep.cpu.core_count': 8
    }
    cpu_facts = darwin_hardware.get_cpu_facts()

    assert 'Intel(R) Core(TM) i9-9880H CPU @ 2.30GHz' == cpu_facts['processor']
    assert '8' == cpu_facts['processor_cores']
    assert '8' == cpu_facts['processor_vcpus']

# Generated at 2022-06-11 02:23:11.237833
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    '''
    Test method get_memory_facts of class DarwinHardware
    '''
    print("Testing get_memory_facts of DarwinHardware")
    DH = DarwinHardware()
    facts = DH.get_memory_facts()
    memtotal_mb = facts.get("memtotal_mb", 0)
    memfree_mb = facts.get("memfree_mb", 0)
    assert memtotal_mb > 0
    assert memfree_mb >= 0
    assert memtotal_mb >= memfree_mb
    print("memtotal_mb = %d, memfree_mb = %d" % (memtotal_mb, memfree_mb))
    print("get_memory_facts OK")
    return True


# Generated at 2022-06-11 02:23:19.620972
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    # Mock module
    module = Mock()

    # Mock memory facts
    memory_facts = {'memtotal_mb': 8192, 'memfree_mb': 0}

    # Mock vm_stat command output

# Generated at 2022-06-11 02:23:29.917782
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    '''
    Test for returning hardware facts for Darwin OS.
    '''
    def run_command(self, cmd):
        '''
        Return hardcoded output for the command.
        '''
        if cmd == ['sysctl', 'hw.model']:
            return (0, 'hw.model: MacBookPro11,1', None)

# Generated at 2022-06-11 02:23:40.822277
# Unit test for method get_system_profile of class DarwinHardware

# Generated at 2022-06-11 02:23:51.490846
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    import os
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    mod = ansible_collector.get_module()

    # test darwin hardware were collected correctly
    darwin_facts = DarwinHardware(mod).populate()
    assert darwin_facts['osrevision'] == '15'
    assert darwin_facts['osversion'] == '16.7.0'
    assert darwin_facts['processor'] == 'Intel(R) Core(TM) i7-3770 CPU @ 3.40GHz'
    assert darwin_facts['processor_cores'] == 8
    assert darwin_facts['processor_vcpus'] == 8

# Generated at 2022-06-11 02:24:04.646729
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
  darwin_hardware = DarwinHardware()
  memory_facts = darwin_hardware.get_memory_facts()
  assert isinstance(memory_facts, dict)
  assert memory_facts['memtotal_mb'] > 0
  assert memory_facts['memfree_mb'] >= 0

# Generated at 2022-06-11 02:24:14.416384
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class FakeModule:
        def __init__(self, **kwargs):
            for k,v in kwargs.items():
                setattr(self, k, v)
        def run_command(self, cmd, encoding=None):
            if cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']:
                return self.rc, self.out, self.err
            else:
                raise AssertionError("Must be called with /usr/sbin/sysctl -b kern.boottime only")

    fake_time = time.time()

    # Use an odd number of seconds, to avoid rounding errors when calculating
    # uptime_seconds with integer division.
    kern_boottime_seconds = 42
    kern_boottime_microseconds = 999999999

# Generated at 2022-06-11 02:24:15.996785
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    hardware_collector = DarwinHardwareCollector()
    assert hardware_collector is not None

# Generated at 2022-06-11 02:24:16.577422
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    DarwinHardwareCollector()

# Generated at 2022-06-11 02:24:19.838973
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_facts = DarwinHardwareCollector(None).collect()
    assert len(darwin_facts) == len(darwin_facts['ansible_facts'])

# Generated at 2022-06-11 02:24:24.312779
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    mem_facts = DarwinHardware(None).get_memory_facts()
    assert mem_facts['memtotal_mb'] > 64
    assert mem_facts['memfree_mb'] > 0
    assert mem_facts['memtotal_mb'] > mem_facts['memfree_mb']


# Generated at 2022-06-11 02:24:31.621517
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = MagicMock()
    module.run_command.return_value = 0, "4", ""
    darwin_hw = DarwinHardware(module)
    darwin_hw.sysctl = {'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz'}
    cpu_facts = darwin_hw.get_cpu_facts()
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor'] == 'Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz'

# Generated at 2022-06-11 02:24:43.431529
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """This method is used to test the get_system_profile method of DarwinHardware class
    """
    # import module snippets
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    # Create object of darwin hardware
    darwin_hardware = DarwinHardware()
    # Create the function object
    get_sys_profile = darwin_hardware.get_system_profile
    # This key is used to match the string 'Processor Name' in the return string of get_system_profile method
    key = "Processor Name"
    # This key is used to check the return type of get_system_profile method
    value = 'Intel Core i7'
    # Call the get_system_profile method
    system_profile_dict = get_sys_profile()

# Generated at 2022-06-11 02:24:46.070250
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    darwin_collector = DarwinHardwareCollector()
    assert darwin_collector._fact_class == DarwinHardware
    assert darwin_collector._platform == 'Darwin'

# Generated at 2022-06-11 02:24:54.385828
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_module = AnsibleModule(argument_spec={})
    data = {"kern.osversion": "16.7.0", "kern.osrevision": "15750" }
    test_module.run_command = Mock(return_value=(0, "hw.model: Intel(R) Core(TM) i7-3970X CPU @ 3.50GHz" , None ))
    test_Darwin_obj = DarwinHardware(test_module)
    test_Darwin_obj.sysctl = data

# Generated at 2022-06-11 02:25:14.951344
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    x = DarwinHardwareCollector()
    assert x._platform == 'Darwin'
    assert x._fact_class == DarwinHardware

# Generated at 2022-06-11 02:25:23.917362
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    # Unit test - the object containing the actual methods.
    hardware_facts = DarwinHardware(module=module)

    # Unit test - the actual data.
    memory_facts_expected = {'memfree_mb': 3, 'memtotal_mb': 4}
    # Now run the method with the unit test data.
    memory_facts_actual = hardware_facts.get_memory_facts()

    # Compare the actual data with the expected data.
    assert memory_facts_actual == memory_facts_expected

# Generated at 2022-06-11 02:25:33.893687
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    import ansible.module_utils.facts.hardware.darwin as darwin_hw
    darwin_hw.struct = struct
    darwin_hw.time = time
    obj = darwin_hw.DarwinHardware()
    obj.module = type(
        'Module', (object,), {
            'run_command': lambda cmd: (0, 'Pages wired down: 78743\nPages active: 72675\nPages inactive: 71877', ''),
            'get_bin_path': lambda cmd: '/bin/vmstat'
        }
    )()
    obj.sysctl = {}
    obj.sysctl['hw.memsize'] = 1024 ** 3 # 1GB
    obj.page_size = 4096

# Generated at 2022-06-11 02:25:42.288342
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-11 02:25:43.392644
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    assert issubclass(DarwinHardwareCollector, HardwareCollector)


# Generated at 2022-06-11 02:25:53.418260
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    from ansible.module_utils.facts import ModuleDataConsumer
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.darwin import DarwinHardwareCollector

    class TestModuleDataConsumer(ModuleDataConsumer):
        def __init__(self, module_name='ansible.module_utils.facts.hardware.darwin'):
            self.module_name = module_name
            self.params = dict()

        def get_bin_path(self, arg, required=False):
            return '/usr/sbin/system_profiler'


# Generated at 2022-06-11 02:26:00.483921
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = DarwinHardware(module)
    hardware.sysctl = get_sysctl(module, ['hw', 'machdep', 'kern'])
    hardware.sysctl['hw.memsize'] = 402653184
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 384
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-11 02:26:10.441099
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Create a mock module for unit testing
    import ansible.module_utils.facts.hardware.darwin as darwin_facts

    module_instance = darwin_facts.AnsibleModule()

    # Mock the run_command method in order to get back a static response
    def run_command_mock(self, module_ref, cmd, encoding=None):
        return 0, b"time: { sec = 1544882465, usec = 911925 }  boottime = 2017-12-22\n", ""

    # Replace the default run_command method with the mock
    module_instance.run_command = run_command_mock.__get__(module_instance, module_instance.__class__)

    # Create an instance of DarwinHardware

# Generated at 2022-06-11 02:26:15.247728
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    module = AnsibleModule(argument_spec={})
    facts = DarwinHardware(module=module, collected_facts={}).get_system_profile()
    keys = ['Model Identifier', 'Model Name', 'Hardware UUID',
            'Processor Name', 'Processor Speed', 'Serial Number (system)']
    for key in keys:
        assert key in facts, "%s not found in facts" % key


# Generated at 2022-06-11 02:26:27.091010
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    # Manually generate the raw uptime value.
    # This is normally generated by:
    #   sysctl -b kern.boottime

    # Uptime in seconds is a signed 32-bit integer.
    uptime_seconds_bytes = struct.pack('@L', 36)
    uptime_microseconds_bytes = struct.pack('@Q', 0)
    out = uptime_seconds_bytes + uptime_microseconds_bytes

    # This is the value that would be returned by:
    #   sysctl -b kern.boottime

    mac_facts = DarwinHardware()
    uptime_facts = mac_facts.get_uptime_facts()
    assert uptime_facts == {
        'uptime_seconds': 36,
    }

# Generated at 2022-06-11 02:27:07.931425
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    test_module = type('test_module', (object,), {
        'run_command': lambda self, args: (0, 'hw.model: MacBookPro8,1\n', '')
    })()

    hardware = DarwinHardware(test_module)
    facts = hardware.get_mac_facts()
    assert facts['model'] == 'MacBookPro8,1'
    assert 'osversion' in facts
    assert 'osrevision' in facts



# Generated at 2022-06-11 02:27:19.551339
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    """
    Method get_system_profile of class DarwinHardware should be able to parse
    output from the system_profiler command.
    """
    darwin_hardware = DarwinHardware(dict(module=dict()))
    darwin_hardware.get_system_profile.__globals__.update(dict(get_bin_path=lambda x: "/usr/sbin/system_profiler"))

# Generated at 2022-06-11 02:27:29.451628
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    module = AnsibleModule
    instance_of_darwin_hardware = DarwinHardware(module)
    instance_of_darwin_hardware.sysctl = dict()
    instance_of_darwin_hardware.sysctl['hw.memsize'] = 2097152
    memory_facts = dict()
    try:
        vm_stat_command = get_bin_path('vm_stat')
    except ValueError:
        memory_facts = dict()
    else:
        rc, out, err = instance_of_darwin_hardware.module.run_command(vm_stat_command)

# Generated at 2022-06-11 02:27:37.936507
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    # Basic scenario with a mocked module
    module = MagicMock()

    # Populate the mocked object with values
    module.run_command.return_value = (0, "hw.model: iMac (27-inch, Late 2009)\n", '')
    module.get_bin_path.return_value = '/usr/bin/vm_stat'

# Generated at 2022-06-11 02:27:45.508651
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    result_dict = {}
    result_dict["Hardware Overview"] = "Hardware Overview"
    result_dict["  Model Name:	MacBook Pro"] = "Model Name"
    result_dict["  Model Identifier:	MacBookPro11,3"] = "Model Identifier"
    result_dict["  Processor Name:	Intel Core i5"] = "Processor Name"
    result_dict["  Processor Speed:	2.6 GHz"] = "Processor Speed"
    result_dict["  Number of Processors:	1"] = "Number of Processors"
    result_dict["  Total Number of Cores:	2"] = "Total Number of Cores"
    result_dict["  L2 Cache (per Core):	256 KB"] = "L2 Cache (per Core)"

# Generated at 2022-06-11 02:27:48.682397
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    dhc = DarwinHardwareCollector()
    assert dhc.platform == 'Darwin'
    assert isinstance(dhc, HardwareCollector)


# Generated at 2022-06-11 02:27:58.263498
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = "/usr/sbin/system_profiler"
    module.run_command.return_value = (0, 'hw.model: x86_64', '')
    da = DarwinHardware(module)
    module.run_command.return_value = (0, 'hw.physicalcpu: 4', '')
    module.get_bin_path.return_value = "/usr/bin/vm_stat"

# Generated at 2022-06-11 02:28:08.804095
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    # The method is called with module_utils.facts.hardware.base.Hardware
    # class
    class ModuleMock(object):
        class run_command(object):
            def __init__(self, command, encoding=None, errors='surrogate_then_replace'):
                self.command = command
                self.encoding = encoding
                self.errors = errors

            def __call__(self):
                command_array = self.command.split()
                if command_array[0] == "/usr/sbin/system_profiler" and command_array[1] == "SPHardwareDataType":
                    rc = 0
                    out = "    Processor Speed: 3.2 GHz\n"
                    err = ""
                else:
                    rc = 1
                    out = ""
                    err = "Command not found"
                return rc,

# Generated at 2022-06-11 02:28:21.695738
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    class TestAnsibleModule:
        def __init__(self):
            self.params = {}
            self.fail_json = ModuleFailJson
            self.run_command = RunCommand

    class TestDarwinHardware(DarwinHardware):
        def __init__(self, module):
            self.module = module

    class TestRunCommand:
        def __init__(self):
            self.run_command_call_count = 0
            self.run_command_return_values = []

        def set_run_command_return_values(self, return_values):
            self.run_command_return_values = return_values

        def reset_run_command_call_count(self):
            self.run_command_call_count = 0


# Generated at 2022-06-11 02:28:32.978641
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    memtotal_mb = 4 * 1024 * 1024 * 1024 / 1024 / 1024
    memfree_mb = 4 * 1024 * 1024 * 1024 / 1024 / 1024 - 2048 * 1024 * 1024 / 1024 / 1024

    module = FakeModule()

# Generated at 2022-06-11 02:29:52.524096
# Unit test for method populate of class DarwinHardware
def test_DarwinHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '3.2GHz Intel Core i7', ''))
    facts = module.params
    hardware_facts = DarwinHardware(module).populate()

    assert 'processor' in hardware_facts
    assert hardware_facts['processor'] == '3.2GHz Intel Core i7'



# Generated at 2022-06-11 02:30:01.092623
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    class ModuleStub:
        class FailJsonException(Exception):
            pass

        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'hw.model: Intel(R) Core(TM) i3-3240 CPU @ 3.40GHz'
            self.run_command_err = ''

        def fail_json(self, *args, **kwargs):
            raise self.FailJsonException()

        def run_command(self, cmd):
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    class SysctlStub:
        def __init__(self, module_stub):
            self.module_stub = module_stub

# Generated at 2022-06-11 02:30:09.449023
# Unit test for method get_memory_facts of class DarwinHardware
def test_DarwinHardware_get_memory_facts():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.compat.six import BytesIO
    from ansible.module_utils.facts.hardware.darwin import DarwinHardware
    class FakeModule(object):
        def run_command(self, command, encoding=None):
            if PY3:
                return 0, BytesIO(b'1\n2\n3\n'), None
            else:
                return 0, BytesIO('1\n2\n3\n'), None
    memory_facts = DarwinHardware(FakeModule()).get_memory_facts()
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['memfree_mb'] == 0

# Generated at 2022-06-11 02:30:17.884833
# Unit test for method get_mac_facts of class DarwinHardware
def test_DarwinHardware_get_mac_facts():
    mac_facts = {'osversion': b'15.6.0', 'osrevision': b'15K55', 'model': b'MacBookPro12,1'}
    fixture = {'kern.osversion': b'15.6.0', 'kern.osrevision': b'15K55', 'hw.model': b'MacBookPro12,1'}
    module = fake_module()
    obj = DarwinHardware(module)
    obj.module.run_command.return_value = (0, 'hw.model: MacBookPro12,1', '')
    obj.sysctl = fixture
    obj.get_mac_facts()
    assert obj.facts == mac_facts



# Generated at 2022-06-11 02:30:23.358967
# Unit test for method get_uptime_facts of class DarwinHardware
def test_DarwinHardware_get_uptime_facts():
    class MockModule(object):
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/usr/sbin/sysctl'

        @staticmethod
        def run_command(*args, **kwargs):
            return [0, b'\x00\x00\x00\x00\x00\x00\x00\x00', '']

    facts = DarwinHardware(MockModule())
    uptime_facts = facts.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] >= 0

    class MockModule2(object):
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/usr/sbin/sysctl'


# Generated at 2022-06-11 02:30:25.469584
# Unit test for constructor of class DarwinHardwareCollector
def test_DarwinHardwareCollector():
    obj = DarwinHardwareCollector()
    assert obj.platform == 'Darwin'


# Generated at 2022-06-11 02:30:32.654886
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    obj = DarwinHardware(module)
    # Intel
    obj.sysctl = {
        'machdep.cpu.brand_string': 'Intel',
        'machdep.cpu.core_count': 16,
        'hw.logicalcpu': 16,
        'hw.ncpu': 8
    }
    cpu_facts = obj.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel'
    assert cpu_facts['processor_cores'] == 16
    assert cpu_facts['processor_vcpus'] == 16
    # PowerPC
    obj.sysctl = {
        'hw.physicalcpu': 16,
        'hw.logicalcpu': 8,
        'hw.ncpu': 8
    }
    obj.get_system_profile = fake_get

# Generated at 2022-06-11 02:30:44.668889
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    sample_sysctl_data = {
        'hw.memsize': '4294967296',
        'hw.physicalcpu': '2',
        'hw.logicalcpu': '4',
        'machdep.cpu.brand_string': 'Intel(R) Core(TM) i5-5267U CPU @ 2.90GHz'
    }
    new_os = DarwinHardware()
    new_os.module = FakeAnsibleModule(dkms_kernel_module=None)
    new_os.sysctl = sample_sysctl_data
    expected_result = {
        'processor': 'Intel(R) Core(TM) i5-5267U CPU @ 2.90GHz',
        'processor_cores': '2',
        'processor_vcpus': '4'
    }
    result = new_os

# Generated at 2022-06-11 02:30:53.793196
# Unit test for method get_cpu_facts of class DarwinHardware
def test_DarwinHardware_get_cpu_facts():
    test_input = {
        "hw.model": "MacBookAir4,2",
        "machdep.cpu.brand_string": "Intel(R) Core(TM) i5-2557M CPU @ 1.70GHz",
        "machdep.cpu.core_count": 2
    }
    expected_output = {
        "processor": "Intel(R) Core(TM) i5-2557M CPU @ 1.70GHz",
        "processor_cores": 2,
        "processor_vcpus": ""
    }
    obj = DarwinHardware()
    obj.sysctl = test_input
    assert(obj.get_cpu_facts() == expected_output)



# Generated at 2022-06-11 02:31:00.021217
# Unit test for method get_system_profile of class DarwinHardware
def test_DarwinHardware_get_system_profile():
    ansible_module_args = dict(
        gather_subset="!all",
        filter="*",
    )
    host_vars = dict()
    host_vars['ansible_module_args'] = ansible_module_args
    # Create a fake ansible module for get_system_profile
    module = FakeModule(ansible_module_args, host_vars)
    hardware = DarwinHardware(module)
    system_profile = hardware.get_system_profile()
    assert system_profile
    assert 'Serial Number (system)' in system_profile

