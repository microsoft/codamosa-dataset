

# Generated at 2022-06-20 19:42:50.325816
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json
    import os
    import shutil
    import tempfile

    tempdir = tempfile.mkdtemp()
    test_data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'unittes_data')
    cachedir = os.path.join(tempdir, 'ansible_facts')
    python_executable = sys.executable
    if not os.path.exists(python_executable):
        python_executable = None

# Generated at 2022-06-20 19:42:57.933180
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector.collect()['python']['version']['major'] == sys.version_info[0]
    if sys.version_info[0] < 3:
        assert collector.collect()['python']['version']['releaselevel'] == sys.version_info[3]
    else:
        assert collector.collect()['python']['version']['releaselevel'] == sys.version_info[3].upper()

# Generated at 2022-06-20 19:43:00.202885
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'

# Generated at 2022-06-20 19:43:09.102347
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert set(python_facts.keys()) == {'python'}
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['version'] == {
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4],
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
    }
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-20 19:43:15.279163
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    # Assert 'python' key is present in the facts dict
    assert 'python' in facts.keys()
    # Assert keys under 'version' subkey of 'python' key
    assert 'version' in facts['python'].keys()
    assert 'major' in facts['python']['version'].keys()
    assert 'minor' in facts['python']['version'].keys()
    assert 'micro' in facts['python']['version'].keys()
    assert 'releaselevel' in facts['python']['version'].keys()
    assert 'serial' in facts['python']['version'].keys()
    assert isinstance(facts['python']['version']['major'], int)

# Generated at 2022-06-20 19:43:19.512315
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()

    ansible_facts = {}
    result = collector.collect(None, ansible_facts)
    assert result['python']['version']['major'] >= 2

# Generated at 2022-06-20 19:43:28.562989
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # We patch os.uname to return a known distribution
    python_facts = {
        'python': {
            'executable': '/usr/bin/python',
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'major': 2,
                'micro': 6,
                'minor': 6,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [
                2,
                6,
                6,
                'final',
                0
            ]
        }
    }

    try:
        collector = PythonFactCollector()
        assert collector.collect() == python_facts
    except:
        raise AssertionError("Failed to retrieve correct Python facts")

# Generated at 2022-06-20 19:43:31.019893
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == "python"
    assert pfc._fact_ids == set()


# Generated at 2022-06-20 19:43:36.377862
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-20 19:43:45.951447
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    collect = globals()['PythonFactCollector'].collect()
    assert 'python' in collect
    assert 'version' in collect['python']
    assert 'major' in collect['python']['version']
    assert 'minor' in collect['python']['version']
    assert 'micro' in collect['python']['version']
    assert 'releaselevel' in collect['python']['version']
    assert 'serial' in collect['python']['version']
    assert 'version_info' in collect['python']
    assert 'executable' in collect['python']
    assert 'has_sslcontext' in collect['python']

# Generated at 2022-06-20 19:43:59.868488
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test_class = PythonFactCollector()
    assert test_class.name == 'python', 'Test Failed - Incorrect value for test_class.name, got: %s, expected: %s' % (test_class.name, 'python')
    assert set(['version', 'version_info', 'executable', 'has_sslcontext']) == set(test_class.collect()['python'].keys()), 'Test Failed - Incorrect value for test_class.collect()[\'python\'].keys(), got: %s, expected: %s' % (set(test_class.collect()['python'].keys()), set(['version', 'version_info', 'executable', 'has_sslcontext']))


# Generated at 2022-06-20 19:44:02.550496
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert isinstance(pfc._fact_ids, set)
    assert pfc.collect()['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:44:11.716120
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)
    assert isinstance(python_facts['python']['version_info'], list)

# Generated at 2022-06-20 19:44:17.873162
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert result.get('python') is not None
    assert result['python'].get('version') is not None
    assert result['python'].get('version_info') is not None
    assert result['python'].get('executable') is not None
    assert result['python'].get('type') is not None

# Generated at 2022-06-20 19:44:21.305994
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector({})
    result = fact_collector.collect()

    assert result['python']['version']['major'] == 2
    assert result['python']['version_info'][0] == 2

# Generated at 2022-06-20 19:44:30.785408
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    results = collector.collect(None, None)
    assert results['python']['executable'] == collector.get_file_content('/proc/self/exe')
    assert results['python']['version']['major'] == sys.version_info[0]
    assert results['python']['version']['minor'] == sys.version_info[1]
    assert results['python']['version']['micro'] == sys.version_info[2]
    assert results['python']['version']['releaselevel'] == sys.version_info[3]
    assert results['python']['version']['serial'] == sys.version_info[4]
    assert results['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:44:33.464169
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None

# Generated at 2022-06-20 19:44:36.202636
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()

    # Assertions
    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-20 19:44:43.022654
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test the collect method of PythonFactCollector class
    """
    python_collector = PythonFactCollector()
    result = python_collector.collect()
    assert type(result) == dict
    assert 'python' in result
    assert type(result['python']) == dict
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-20 19:44:53.495054
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create PythonFactCollector object
    pfc = PythonFactCollector()

    # Test python facts
    python_facts = pfc.collect()
    assert type(python_facts) == dict
    assert 'python' in python_facts
    assert type(python_facts['python']) == dict
    assert 'version' in python_facts['python']
    assert type(python_facts['python']['version']) == dict
    assert 'major' in python_facts['python']['version']
    assert type(python_facts['python']['version']['major']) == int
    assert 'minor' in python_facts['python']['version']
    assert type(python_facts['python']['version']['minor']) == int
    assert 'micro' in python_facts['python']['version']


# Generated at 2022-06-20 19:45:09.417665
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    # Test without python version information and without executable
    if hasattr(sys.version_info, '__delitem__'):
        del sys.version_info[0]
        del sys.version_info[1]
        del sys.version_info[2]
        del sys.version_info[3]
        del sys.version_info[4]

    del sys.executable

    assert python_fact_collector.collect() == {'python': {'version_info': [], 'has_sslcontext': True}}

    sys.version_info = (2, 7, 9, 'final', 0)
    sys.executable = '/tests/bin/python'


# Generated at 2022-06-20 19:45:12.764739
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector

# Generated at 2022-06-20 19:45:14.014733
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'

# Generated at 2022-06-20 19:45:24.433552
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    # Confirm that the expected keys are in the results
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:45:26.112855
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector is not None



# Generated at 2022-06-20 19:45:30.593481
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Assert that PythonFactCollector.collect() creates a dict with the expected
    keys
    """

    collector = PythonFactCollector()
    result = collector.collect()

    assert 'python' in result
    assert 'type' in result['python']
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']


# Generated at 2022-06-20 19:45:35.038449
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Execute the method collect
    python_facts = PythonFactCollector().collect()

    # Assertion
    assert type(python_facts) == dict

# Execute the test
if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-20 19:45:37.252212
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'


# Generated at 2022-06-20 19:45:39.241354
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    test = PythonFactCollector()
    assert test.name == 'python'
    assert test._fact_ids == set()

# Generated at 2022-06-20 19:45:49.372730
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    python_facts = fact_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:46:05.401550
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc is not None

# Generated at 2022-06-20 19:46:06.613163
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector(None)
    assert "python" in p.collect()

# Generated at 2022-06-20 19:46:08.955176
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_dict = dict()
    p = PythonFactCollector(facts_dict)
    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-20 19:46:10.111724
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'

# Generated at 2022-06-20 19:46:12.259841
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test collect method of class PythonFactCollector
    """
    fact_collector = PythonFactCollector()
    python_facts = fact_collector.collect()
    assert 'python' in collecte

# Generated at 2022-06-20 19:46:18.399271
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert ('version' in facts['python']) and ('version_info' in facts['python']) and ('executable' in facts['python']) and ('type' in facts['python']) and ('has_sslcontext' in facts['python'])

# Generated at 2022-06-20 19:46:21.240786
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert 'python' in python_collector._fact_ids


# Generated at 2022-06-20 19:46:30.219300
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ test_PythonFactCollector_collect """
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import callback_facts
    collector = Collector({'fact_cache': callback_facts}, {}, {}, None)
    collector.collect(None)
    assert collector.fact_cache['python']
    assert collector.fact_cache['python']['version']
    assert collector.fact_cache['python']['version_info']
    assert collector.fact_cache['python']['executable']
    assert collector.fact_cache['python']['has_sslcontext']
    assert collector.fact_cache['python']['type']

# Generated at 2022-06-20 19:46:31.815744
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()


# Generated at 2022-06-20 19:46:42.689022
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert facts['python']['type'] in ('CPython', 'PyPy')
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
   

# Generated at 2022-06-20 19:47:15.524373
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector(None)
    assert pfc.name == 'python'

# Generated at 2022-06-20 19:47:21.401487
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert 'python' in facts
    assert facts['python']['version']['major'] == '2'
    assert facts['python']['executable'] == 'python'
    assert facts['python']['has_sslcontext'] == False

# Generated at 2022-06-20 19:47:32.157687
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    python_facts = fc.collect()
    assert 'python' in python_facts, "Failed to collect python facts"
    assert 'version' in python_facts['python'], "Failed to collect python version facts"
    assert 'major' in python_facts['python']['version'], "Failed to collect python version major facts"
    assert python_facts['python']['version']['major'] == sys.version_info[0], "Failed to collect python version major facts"
    assert 'minor' in python_facts['python']['version'], "Failed to collect python version minor facts"
    assert python_facts['python']['version']['minor'] == sys.version_info[1], "Failed to collect python version minor facts"

# Generated at 2022-06-20 19:47:33.206756
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-20 19:47:37.189867
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert isinstance(PythonFactCollector._fact_ids, set)
    assert len(PythonFactCollector._fact_ids) == 0


# Generated at 2022-06-20 19:47:40.634417
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    python_facts = facts.get('python', {})

    assert 'version' in python_facts
    assert 'version_info' in python_facts
    assert 'type' in python_facts
    assert 'executable' in python_facts
    assert 'has_sslcontext' in python_facts

# Generated at 2022-06-20 19:47:42.760084
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    assert obj.collect()



# Generated at 2022-06-20 19:47:51.257018
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import get_collector_instance

    # Intialize the FactCollector object
    factCollector = get_collector_instance('python')

    # Testing the method collect for invalid parameters
    python_facts = factCollector.collect(collected_facts=None)
    assert 'python' in python_facts
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys

# Generated at 2022-06-20 19:47:54.231511
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fc = PythonFactCollector()

    assert python_fc.name == 'python'
    assert python_fc._fact_ids == set()

# Generated at 2022-06-20 19:47:55.450541
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'

# Generated at 2022-06-20 19:49:10.546149
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-20 19:49:17.814582
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector({}, None)

    python_facts = collector.collect(collected_facts={})
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert isinstance(python_facts['python'], dict)

    python = python_facts['python']
    assert 'version' in python
    assert isinstance(python['version'], dict)

    version = python['version']
    assert 'major' in version
    assert isinstance(version['major'], int)
    assert 'minor' in version
    assert isinstance(version['minor'], int)
    assert 'micro' in version
    assert isinstance(version['micro'], int)
    assert 'releaselevel' in version
    assert isinstance(version['releaselevel'], str)
    assert 'serial' in version

# Generated at 2022-06-20 19:49:20.320189
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert 'python' == python_fact_collector.name

# Generated at 2022-06-20 19:49:27.626152
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    #Create an instance of PythonFactCollector
    pythonFactCollector = PythonFactCollector()

    # Test with empty collected_facts
    collected_facts = dict()
    python_facts = pythonFactCollector.collect(collected_facts=collected_facts)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-20 19:49:38.577601
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    # Generic checks
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:49:47.199894
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = AnsibleModuleMock()
    fact_collector = PythonFactCollector(module)
    base_facts = dict()
    facts_dict = fact_collector.collect(base_facts)
    expected_dict = dict(
        python=dict(
            version=dict(
                major=sys.version_info[0],
                minor=sys.version_info[1],
                micro=sys.version_info[2],
                releaselevel=sys.version_info[3],
                serial=sys.version_info[4],
            ),
            version_info=list(sys.version_info),
            executable=sys.executable,
            has_sslcontext=HAS_SSLCONTEXT,
            type=sys.implementation.name
        )
    )
    assert facts_dict == expected_dict

# Generated at 2022-06-20 19:49:54.786287
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    result = python_fact_collector.collect()

    assert result.get('python')

    python_version_info = result.get('python').get('version_info')
    python_version_info_expected = [sys.version_info.major, sys.version_info.minor, sys.version_info.micro, sys.version_info.releaselevel, sys.version_info.serial]

    assert python_version_info_expected == python_version_info

# Generated at 2022-06-20 19:50:06.132785
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    py_fc = PythonFactCollector()

    assert (isinstance(py_fc, PythonFactCollector))
    assert (isinstance(py_fc, BaseFactCollector))
    assert (isinstance(py_fc, object))

    try:
        import ssl
        assert(py_fc.collect()['python']['has_sslcontext'] == True)
    except ImportError:
        assert(py_fc.collect()['python']['has_sslcontext'] == False)

    py_fc._fact_ids = set()
    assert(py_fc.collect()['python']['version']['major'] == sys.version_info[0])


# Generated at 2022-06-20 19:50:10.887740
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfac = PythonFactCollector()
    assert pyfac.name == 'python'
    assert pyfac._fact_ids == set()

# Generated at 2022-06-20 19:50:12.456993
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'


# Generated at 2022-06-20 19:52:37.186888
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:52:44.175103
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    ansible_facts = fact_collector.collect()
    python_facts = ansible_facts['ansible_python']

    assert python_facts['version_info'] == list(sys.version_info)
    assert python_facts['executable'] == sys.executable

    if sys.version_info[0] == 2:
        assert python_facts['type'] == 'cpython'
    else:
        assert python_facts['type'] == 'CPython'