

# Generated at 2022-06-20 19:42:57.031633
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts["python"], dict)
    assert isinstance(python_facts["python"]["version_info"], list)
    assert isinstance(python_facts["python"]["version"], dict)
    assert isinstance(python_facts["python"]["type"], str)
    assert isinstance(python_facts["python"]["executable"], str)
    assert isinstance(python_facts["python"]["has_sslcontext"], bool)

# Generated at 2022-06-20 19:43:08.197950
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    _collector = PythonFactCollector()
    collected_facts = _collector.collect()
    assert 'python' in collected_facts.keys()
    assert 'version' in collected_facts['python'].keys()
    assert 'version_info' in collected_facts['python'].keys()
    assert 'executable' in collected_facts['python'].keys()
    assert 'type' in collected_facts['python'].keys()
    assert 'has_sslcontext' in collected_facts['python'].keys()
    assert collected_facts['python']['type'] is not None
    assert collected_facts['python']['version']['serial'] >= 0
    assert collected_facts['python']['version']['micro'] >= 0
    assert collected_facts['python']['version']['minor'] >= 0
    assert collected

# Generated at 2022-06-20 19:43:12.213541
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    sys.version_info = (2, 7, 3, 'final', 0)
    sys.version = '2.7.3 (default, Aug  1 2012, 05:14:39) \n[GCC 4.6.3]'
    sys.executable = '/usr/bin/python'
    sys.modules['ssl'] = None

    obj = PythonFactCollector()
    obj.collect()

# Generated at 2022-06-20 19:43:23.723293
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()

    result = obj.collect()
    assert result
    assert isinstance(result, dict)
    assert 'python' in result
    assert 'version' in result['python']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'type' in result['python']
    assert 'has_sslcontext' in result['python']

    # test that the module is happy with the test result
    assert isinstance(result['python']['version'], dict)
    assert isinstance(result['python']['version']['major'], int)
    assert isinstance(result['python']['version']['minor'], int)
    assert isinstance(result['python']['version']['micro'], int)

# Generated at 2022-06-20 19:43:26.225258
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

    assert 'python' in pfc._fact_ids

# Generated at 2022-06-20 19:43:31.039544
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Unit
    python_facts = PythonFactCollector().collect()

    # Verify
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

    # Unit
    python_facts = PythonFactCollector().collect(collected_facts={'python': 'Dummy'})

    # Verify
    assert 'python' in python_facts
    assert python_facts['python'] == 'Dummy'

# Generated at 2022-06-20 19:43:33.317140
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'

# Generated at 2022-06-20 19:43:35.869951
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-20 19:43:37.084734
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-20 19:43:49.775451
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert facts
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SS

# Generated at 2022-06-20 19:44:04.700733
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()

    result = pf.collect()
    assert 'python' in result
    assert 'version' in result['python']
    assert 'major' in result['python']['version']
    assert result['python']['version']['major'] == sys.version_info[0]
    assert 'minor' in result['python']['version']
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert 'micro' in result['python']['version']
    assert result['python']['version']['micro'] == sys.version_info[2]
    if sys.version_info[3] == 'alpha' and sys.version_info[4] == 0:
        releaselevel = 'final'
        serial = ''

# Generated at 2022-06-20 19:44:05.615882
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_collector = PythonFactCollector(None)

# Generated at 2022-06-20 19:44:13.069143
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    try:
        python_facts['python']['type'] = sys.implementation.name
    except AttributeError:
        python_facts['python']['type'] = None

    pfc = PythonFactCollector()
    assert pfc.collect() == python_

# Generated at 2022-06-20 19:44:22.904344
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    # Assert that fact_collector is the instance of PythonFactCollector
    assert isinstance(fact_collector, PythonFactCollector)
    # Assert that name of fact_collector is python
    assert fact_collector.name == 'python'
    # Assert that _fact_ids of fact_collector is empty set
    assert isinstance(fact_collector._fact_ids, set)
    assert fact_collector._fact_ids == set()
    # Assert that _fact_names of fact_collector is empty set
    assert isinstance(fact_collector._fact_names, set)
    assert fact_collector._fact_names == set()

# Generated at 2022-06-20 19:44:32.177204
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # We can't use the builtin assertRaises here because it doesn't work
    # on Python 2.6.  We need python 2.6 support until at least
    # Debian Wheezy and RHEL 6 are EOL.
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    assertRaises = getattr(builtins, "raises")

    class TestPythonFactCollector(PythonFactCollector):
        def __init__(self, module=None, collected_facts=None):
            self.myfacts = {}

    tfpc = TestPythonFactCollector()

    if tfpc.get_fact("has_sslcontext"):
        assertRaises(AttributeError, tfpc.collect)
    else:
        tfpc.collect()
        assert tfpc.get_fact("version")

# Generated at 2022-06-20 19:44:33.191592
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test if we create an instance
    PythonFactCollector()

# Generated at 2022-06-20 19:44:37.113887
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert isinstance(python_fact_collector._fact_ids, set)
    assert python_fact_collector._fact_ids == set()
    assert python_fact_co

# Generated at 2022-06-20 19:44:45.645003
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert facts is not None
    assert facts['python']['version']['major'] == 3
    assert facts['python']['version']['minor'] == 6
    assert facts['python']['version']['micro'] == 5
    assert facts['python']['version']['releaselevel'] == 'final'
    assert facts['python']['version']['serial'] == 0
    assert facts['python']['version']['type'] == 'CPython'

# Generated at 2022-06-20 19:44:46.730482
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test not available
    pass

# Generated at 2022-06-20 19:44:54.531269
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import mock
    import json

    python_collector = PythonFactCollector()
    tmp_dict = python_collector.collect()
    assert type(tmp_dict['python']) is dict
    assert len(tmp_dict['python']) > 0
    assert type(tmp_dict['python']['type']) is str or tmp_dict['python']['type'] is None
    assert type(tmp_dict['python']['executable']) is str
    assert type(tmp_dict['python']['version']) is dict
    assert type(tmp_dict['python']['version_info']) is list
    assert type(tmp_dict['python']['has_sslcontext']) is bool

# Generated at 2022-06-20 19:44:59.287243
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x
    assert x.name == 'python'

# Generated at 2022-06-20 19:45:01.220357
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Verifies that the class attributes have been initialized
    # correctly.

    assert PythonFactCollector.name == 'python'
    assert set(PythonFactCollector._fact_ids) == set()

# Generated at 2022-06-20 19:45:02.567773
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact = PythonFactCollector()
    assert type(python_fact) is PythonFactCollector
    assert python_fact.name == 'python'

# Generated at 2022-06-20 19:45:04.539829
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    result = f.collect()
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:45:08.030500
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert type(python_fact_collector.name) == str
    assert type(python_fact_collector._fact_ids) == set
    assert python_fact_collector.name == 'python'


# Generated at 2022-06-20 19:45:19.512504
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name  == 'python', 'Test PythonFactCollector - name failed'
    assert len(collector._fact_ids) == 0, 'Test PythonFactCollector - _fact_ids failed'

# Generated at 2022-06-20 19:45:21.398584
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids is not None

# Generated at 2022-06-20 19:45:30.736359
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    # The result should be a dictionary
    assert isinstance(result, dict)
    # There should be a 'python' key in the dictionary
    assert result.has_key('python')
    # The value of key 'python' should be a dictionary
    assert isinstance(result['python'], dict)
    # 'has_sslcontext' should be a key in the dictionary
    assert 'has_sslcontext' in result['python']
    # 'version_info' should be a key in the dictionary
    assert 'version_info' in result['python']
    # 'executable' should be a key in the dictionary
    assert 'executable' in result['python']
    # 'version' should be a key in the dictionary

# Generated at 2022-06-20 19:45:32.102439
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-20 19:45:35.354533
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert isinstance(python_facts.name, str)
    assert isinstance(python_facts._fact_ids, set)

# Generated at 2022-06-20 19:45:48.824316
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Test method collect of class PythonFactCollector
    '''
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-20 19:45:49.898245
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert hasattr(PythonFactCollector(), '_fact_ids')

# Generated at 2022-06-20 19:45:52.586415
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc.collect()['python']['type'] == 'CPython'

# Generated at 2022-06-20 19:46:00.440482
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import collector_registry, \
        PythonFactCollector
    from copy import deepcopy
    from unittest import TestCase, TestLoader, TextTestRunner

    class TestPythonFactCollector(TestCase):
        def test_collect(self):
            collected_facts = dict()
            p = PythonFactCollector()
            facts = p.collect(collected_facts=collected_facts)

            # Assert that 'python' is in facts dictionary
            self.assertTrue('python' in facts)

            # Assert that 'version' is in python dictionary
            self.assertTrue('version' in facts['python'])

            # Assert that 'version_info' is in python dictionary
            self.assertTrue('version_info' in facts['python'])

            # Assert that 'type'

# Generated at 2022-06-20 19:46:02.235127
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_fact_collector.collect()

# Generated at 2022-06-20 19:46:06.771533
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert isinstance(collector, BaseFactCollector)
    assert collector.name == 'python'
    assert isinstance(collector._fact_ids, set) and len(collector._fact_ids) == 0


# Generated at 2022-06-20 19:46:12.322035
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result_dict = sys.modules[__name__].PythonFactCollector().collect()
    assert type(result_dict) is dict
    assert 'python' in result_dict
    assert type(result_dict['python']) is dict
    assert type(result_dict['python']['version']) is dict
    assert type(result_dict['python']['version_info']) is list
    assert type(result_dict['python']['executable']) is str
    assert type(result_dict['python']['has_sslcontext']) is bool

# Generated at 2022-06-20 19:46:14.996666
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:46:16.877021
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector


# Generated at 2022-06-20 19:46:19.262381
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collector import PythonFactCollector
    p = PythonFactCollector()

# Generated at 2022-06-20 19:46:40.129737
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    python_fact_collector_obj = get_collector_instance('python')
    assert type(python_fact_collector_obj) == PythonFactCollector
    assert python_fact_collector_obj.name == 'python'
    assert type(python_fact_collector_obj.collect()) == dict
    assert 'python' in python_fact_collector_obj.collect()

# Generated at 2022-06-20 19:46:46.163732
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    expected_attributes = {'name': 'python', '_fact_ids': set()}
    returned_attributes = {}
    for attribute in expected_attributes:
        returned_attributes[attribute] = getattr(PythonFactCollector(), attribute)
    assert expected_attributes == returned_attributes, "Expected returned attributes '%s', got '%s'" % (expected_attributes, returned_attributes)


# Generated at 2022-06-20 19:46:55.086594
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import json

    python_facts = PythonFactCollector().collect()

    assert python_facts['python']['version'] == {'major': sys.version_info[0],
                                                 'minor': sys.version_info[1],
                                                 'micro': sys.version_info[2],
                                                 'releaselevel': sys.version_info[3],
                                                 'serial': sys.version_info[4]}

    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

    # subversion was removed for Python 3
    # https://docs.python.org/3.0/whatsnew/3.0.html#miscellaneous

# Generated at 2022-06-20 19:46:59.166612
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert len(python_fact_collector._fact_ids) == 0


# Generated at 2022-06-20 19:47:01.557285
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:47:03.383822
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert hasattr(p, 'collect')

# Generated at 2022-06-20 19:47:07.789542
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    collected_facts = {}
    collected_facts['python'] = pfc.collect()
    print(collected_facts)

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-20 19:47:16.829750
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collectors import PythonFactCollector
    from ansible.module_utils.facts.collectors.python.python_version import PythonVersionFactCollector
    from ansible.module_utils.facts.collectors.python.python_implementation import PythonImplementationFactCollector

    fact_collector = Facts()
    python_collector = PythonFactCollector()
    python_collector.__class__.__name__ = 'MockedPythonFactCollector'

    python_collector.set_fact_collector(fact_collector)

    # Mock the PythonVersionFactCollector
    python_collector._fact_collector.collectors['python_version'] = PythonVersionFactCollector()

# Generated at 2022-06-20 19:47:19.265291
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'


# Generated at 2022-06-20 19:47:20.901556
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-20 19:48:02.567857
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-20 19:48:05.779799
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc is not None

# Generated at 2022-06-20 19:48:10.027837
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    def check_equal(expected, actual):
        assert expected == actual

    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None
    check_equal('python', python_fact_collector.name)
    check_equal(set(), python_fact_collector._fact_ids)

# Generated at 2022-06-20 19:48:20.536723
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert hasattr(p, 'collect')
    assert p.collect()['python']['version']['major'] == sys.version_info[0]
    assert p.collect()['python']['version']['minor'] == sys.version_info[1]
    assert p.collect()['python']['version']['micro'] == sys.version_info[2]
    assert p.collect()['python']['version']['releaselevel'] == sys.version_info[3]
    assert p.collect()['python']['version']['serial'] == sys.version_info[4]

if __name__ == '__main__':
    test_PythonFactCollector()

# Generated at 2022-06-20 19:48:21.581483
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-20 19:48:26.060217
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_pfc = PythonFactCollector()

    assert test_pfc._fact_ids == set()
    assert test_pfc.name == 'python'

    test_pfc.collect()



# Generated at 2022-06-20 19:48:27.808784
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None

# Generated at 2022-06-20 19:48:29.338988
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'


# Generated at 2022-06-20 19:48:30.806011
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_col = PythonFactCollector()
    assert py_fact_col.name == 'python'

# Generated at 2022-06-20 19:48:33.065202
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()



# Generated at 2022-06-20 19:49:37.377753
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-20 19:49:41.882836
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == "python"
    assert 'distribution' not in x._fact_ids
    assert 'lsb' not in x._fact_ids
    assert 'redhat' not in x._fact_ids
    assert 'debian' not in x._fact_ids

# Generated at 2022-06-20 19:49:46.308192
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert result == {'python': {'type': 'CPython', 'has_sslcontext': True, 'version': {'micro': 2, 'major': 2, 'releaselevel': 'final', 'minor': 7, 'serial': 0}, 'executable': '/opt/ansible/bin/python', 'version_info': [2, 7, 2, 'final', 0]}}



# Generated at 2022-06-20 19:49:53.861163
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    pf.collect()
    assert 'python' in pf.collect().keys()
    assert 'version' in pf.collect()['python'].keys()
    assert 'version_info' in pf.collect()['python'].keys()
    assert 'executable' in pf.collect()['python'].keys()
    assert 'has_sslcontext' in pf.collect()['python'].keys()
    assert 'type' in pf.collect()['python'].keys()



# Generated at 2022-06-20 19:50:00.810202
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    facts = fc.collect()
    assert isinstance(facts['python'], dict)
    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert facts['python']['type'] in ['CPython', 'IronPython', 'Jython', 'PyPy']

# Generated at 2022-06-20 19:50:08.081065
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize Parameters for method collect
    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-20 19:50:17.135895
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ Tests the return value of collect method of class PythonFactCollector
    """
    if sys.version_info < (3, 0):
        package = '__builtin__'
    else:
        package = 'builtins'
    python_fact = {'python': {'has_sslcontext': True, 'version': {'serial': 0, 'releaselevel': 'final', 'major': 2, 'minor': 7, 'micro': 13}, 'type': 'CPython', 'version_info': [2, 7, 13, 'final', 0]}, package: {}}
    collector_mock = PythonFactCollector()
    python_fact_collected = collector_mock.collect()
    assert python_fact_collected == python_fact

# Generated at 2022-06-20 19:50:19.945550
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert c.collect()['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:50:21.627507
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-20 19:50:31.209525
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    # Collect!
    python_facts = pfc.collect()
    # Check for some of the expected keys
    assert 'python' in python_facts
    assert 'executable' in python_facts['python']
    # Check for expected keys
    assert 'version_info' in python_facts['python']['version']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']