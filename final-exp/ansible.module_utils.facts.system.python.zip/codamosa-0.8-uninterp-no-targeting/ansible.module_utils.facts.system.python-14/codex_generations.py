

# Generated at 2022-06-20 19:42:54.416830
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    try:
        # We can't test if attributes on the instance of the class, because of
        # the way the facts are generated, with a new empty instance of the
        # collector every time they are generated.
        PythonFactCollector()
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-20 19:43:01.431299
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Initialize the PythonFactCollector class
    pfc = PythonFactCollector()

    # Collect python facts
    facts = pfc.collect(module=None, collected_facts=None)

    assert isinstance(facts, dict), "Expected: <class 'dict'>, Got: %s" % type(facts)
    assert 'python' in facts, "Cannot find python dictionary in facts"
    assert 'executable' in facts['python'], "Cannot find executable key in facts['python']"
    assert 'has_sslcontext' in facts['python'], "Cannot find has_sslcontext key in facts['python']"
    assert 'version' in facts['python'], "Cannot find version dictionary in facts['python']"

# Generated at 2022-06-20 19:43:10.861038
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert python_facts['ansible_python']['version']['major'] == sys.version_info[0]
    assert python_facts['ansible_python']['version']['minor'] == sys.version_info[1]
    assert python_facts['ansible_python']['version']['micro'] == sys.version_info[2]
    assert python_facts['ansible_python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['ansible_python']['version']['serial'] == sys.version_info[4]
    assert python_facts['ansible_python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:43:13.613242
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'

# Generated at 2022-06-20 19:43:15.340461
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-20 19:43:19.208804
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector_instance = PythonFactCollector(None, None)

    assert isinstance(python_fact_collector_instance, PythonFactCollector)

# Generated at 2022-06-20 19:43:24.797838
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """ Test the constructor of PythonFactCollector """
    # Set up a test, using PythonFactCollector
    python_facts = PythonFactCollector()

    # Assert the facts_type of PythonFactCollector is 'python'
    assert python_facts.name == 'python'

    # Assert the fact ids are correct
    assert python_facts._fact_ids == set()



# Generated at 2022-06-20 19:43:31.028472
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python

# Generated at 2022-06-20 19:43:37.045034
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    gfc = PythonFactCollector(None)
    facts = gfc.collect()
    assert type(facts) is dict
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']


# Generated at 2022-06-20 19:43:41.910417
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()

    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:43:47.696260
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    f = p.collect()
    assert 'python' in f

# Generated at 2022-06-20 19:43:51.554959
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # If we have SSLContext support, assert for True.
    if HAS_SSLCONTEXT:
        assert PythonFactCollector().collect()['python']['has_sslcontext'] is True
    else:
        assert PythonFactCollector().collect()['python']['has_sslcontext'] is False

# Generated at 2022-06-20 19:44:02.044159
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create PythonFactCollector instance
    python_fact_collector = PythonFactCollector()
    # Call collect method
    collected_facts = python_fact_collector.collect()
    # Check result
    assert 'python' in collected_facts
    assert isinstance(collected_facts['python'], dict)
    assert 'version' in collected_facts['python']
    assert isinstance(collected_facts['python']['version'], dict)
    assert 'major' in collected_facts['python']['version']
    assert isinstance(collected_facts['python']['version']['major'], int)
    assert 'minor' in collected_facts['python']['version']
    assert isinstance(collected_facts['python']['version']['minor'], int)
    assert 'micro' in collected

# Generated at 2022-06-20 19:44:04.347461
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-20 19:44:05.694123
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    gfc = PythonFactCollector()
    gfc.collect()

# Generated at 2022-06-20 19:44:07.544739
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert(obj.name == 'python')
    assert(obj._fact_ids == set())


# Generated at 2022-06-20 19:44:08.758605
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-20 19:44:19.391475
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCollector
    module = "test"
    collected_facts = {}
    python_fact = PythonFactCollector()
    fact_collector = FactCollector
    result = python_fact.collect(module, collected_facts)
    assert result == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 12, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 12, 'final', 0], 'has_sslcontext': True, 'executable': '/usr/bin/python'}}, "Python facts returned are not as expected"


# Generated at 2022-06-20 19:44:20.606254
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 19:44:22.043073
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc is not None

# Generated at 2022-06-20 19:44:40.948535
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import ssl
    ssl_context = ssl.create_default_context()
    tmp_rc = type(sys)(sys.version)
    tmp_rc.implementation = type(ssl_context)(ssl.SSLContext)
    tmp_rc.implementation.name = 'CPython'
    tmp_rc.version_info = type(sys.version_info)(sys.version_info)
    tmp_rc.version_info.__reduce__ = lambda self: (self.__class__, tuple(self))
    tmp_rc.version = type(sys.version)(sys.version)
    tmp_rc.version_info.__str__ = lambda self: sys.version
    tmp_rc.version.__str__ = lambda self: sys.version

# Generated at 2022-06-20 19:44:42.534835
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:44:53.097464
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    sys_version_info = sys.version_info

    py_collector = PythonFactCollector()
    py_data = {
        'python': {
            'version': {
                'major': sys_version_info[0],
                'minor': sys_version_info[1],
                'micro': sys_version_info[2],
                'releaselevel': sys_version_info[3],
                'serial': sys_version_info[4]
            },
            'version_info': list(sys_version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-20 19:44:56.349588
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'
    assert py_collector._fact_ids == set()


# Generated at 2022-06-20 19:44:58.361850
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Arrange
    python_collector = PythonFactCollector()

    # Assert
    assert python_collector
    assert python_collector.name == 'python'


# Generated at 2022-06-20 19:45:02.550921
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    facts = obj.collect()

    assert 'python' in facts.keys()
    assert 'type' in facts['python'].keys()
    assert 'version' in facts['python'].keys()
    assert 'version_info' in facts['python'].keys()
    assert 'executable' in facts['python'].keys()
    assert 'has_sslcontext' in facts['python'].keys()

# Generated at 2022-06-20 19:45:05.379701
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Test creating an instance of PythonFactCollector
    python_fact_collector = PythonFactCollector()

    # Assert that an instance of PythonFactCollector is created
    assert isinstance(python_fact_collector, PythonFactCollector)

    # Assert that the instance can collect facts
    assert hasattr(python_fact_collector, 'collect')

# Generated at 2022-06-20 19:45:06.769431
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:45:18.202268
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'CPython',
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': [3, 4, 0, 'final', 0]
        }
    }

    try:
        pfc = PythonFactCollector()
        collected_facts = pfc.collect()
        if not python_facts == collected_facts:
            assert False
    except Exception:
        assert False

# Generated at 2022-06-20 19:45:25.457595
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # initialize test object and create expected result
    result = {'python':{'type': 'CPython', 'executable': '/usr/bin/python2.7', 'has_sslcontext': True, 'version': {'micro': 0, 'releaselevel': 'final', 'major': 2, 'minor': 7, 'serial': 0}, 'version_info': [2, 7, 0, 'final', 0]}}

    # test PythonFactCollector.collect()
    python = PythonFactCollector()
    assert python.collect() == result

# Generated at 2022-06-20 19:45:47.952209
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    pc = PythonFactCollector()
    facts = pc.collect()
    v = facts['python']['version']
    assert v['major']
    assert v['minor']
    assert v['micro']
    assert v['releaselevel']
    assert v['serial']
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:45:50.177059
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythoncollector = PythonFactCollector()
    assert pythoncollector

# Generated at 2022-06-20 19:45:59.150472
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    py_facts = c.collect()
    assert py_facts['python']['version']['major'] == sys.version_info[0]
    assert py_facts['python']['version']['minor'] == sys.version_info[1]
    assert py_facts['python']['version']['micro'] == sys.version_info[2]
    assert py_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_facts['python']['version']['serial'] == sys.version_info[4]
    assert py_facts['python']['version_info'] == list(sys.version_info)
    assert py_facts['python']['executable'] == sys.executable
    assert py_facts

# Generated at 2022-06-20 19:46:00.965096
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-20 19:46:07.366708
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert 'python' in python_facts
    assert isinstance(python_facts['python'], dict)
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:46:17.721016
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a mocker that replaces a function from the standard library
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    mocker = collector.MockCall()
    BaseFactCollector.__bases__ = (mocker,)

    # A fact collector that uses the mocked function
    import sys
    class PythonFactCollector(collector.PythonFactCollector):
        def collect(self, module, collected_facts):
            return {'python': {'executable': sys.executable}}

    # Create a mock environment
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import get_collector_instance
    import sys
    mocker = collector.MockCall()
    collector.get_collector_

# Generated at 2022-06-20 19:46:18.497322
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert True is True

# Generated at 2022-06-20 19:46:29.517626
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    # Make sure we have all the dictionary elements we expect.
    assert len(python_facts) == 1
    assert 'python' in python_facts
    assert len(python_facts['python']) == 5
    assert 'version' in python_facts['python']
    assert len(python_facts['python']['version']) == 5
    assert 'version_info' in python_facts['python']
    assert isinstance(python_facts['python']['version_info'], list)
    assert 'type' in python_facts['python']
    assert python_facts['python']['type'] is not None
    assert 'executable' in python_facts['python']
    assert python_facts['python']['executable'] is not None
    assert 'has_sslcontext' in python

# Generated at 2022-06-20 19:46:38.461033
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import mock

    def _mock_tuple_type():
      return tuple

    python_fact_collector = PythonFactCollector()
    with mock.patch('sys.version_info', _mock_tuple_type()):
        facts = python_fact_collector.collect()
        assert 'python' in facts
        assert 'version' in facts['python']
        assert 'version_info' in facts['python']
        assert 'executable' in facts['python']
        assert 'has_sslcontext' in facts['python']
        assert 'type' in facts['python']

# vim: set et ts=4 sw=4

# Generated at 2022-06-20 19:46:40.066271
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-20 19:46:56.790808
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert 'python' in c.collect()

# Generated at 2022-06-20 19:47:01.519249
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector
    pfc = PythonFactCollector()
    assert isinstance(pfc, BaseFactCollector)
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-20 19:47:03.343542
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()

# Generated at 2022-06-20 19:47:15.140267
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Needs to have self parameter
    try:
        collector = PythonFactCollector()
    except TypeError:
        assert 0, 'PythonFactCollector needs self parameter'

    # Needs to have module parameter
    try:
        collector.collect()
    except TypeError:
        assert 0, 'PythonFactCollector needs module parameter'

    # Needs to have collected_facts parameter
    try:
        collector.collect(module='test')
    except TypeError:
        assert 0, 'PythonFactCollector needs collected_facts parameter'

    # Test python_facts dictionary using empty collected_facts
    try:
        py_facts = collector.collect(module='test', collected_facts=dict())
    except Exception:
        assert 0, 'Failed to create python_facts dictionary'

    # Test python_facts dictionary

# Generated at 2022-06-20 19:47:21.323589
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert isinstance(py_fact_collector, PythonFactCollector)
    assert isinstance(py_fact_collector, BaseFactCollector)
    assert py_fact_collector.name == 'python'
    assert isinstance(py_fact_collector._fact_ids, set)

# Generated at 2022-06-20 19:47:32.020399
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    # Check version info
    version_info = list(sys.version_info)

    assert python_facts['python']['version']['major'] == version_info[0]
    assert python_facts['python']['version']['minor'] == version_info[1]
    assert python_facts['python']['version']['micro'] == version_info[2]
    assert python_facts['python']['version']['releaselevel'] == version_info[3]
    assert python_facts['python']['version']['serial'] == version_info[4]

    # Check executable
    assert python_facts['python']['executable'] == sys.executable

    # Check SSL Context

# Generated at 2022-06-20 19:47:33.100257
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:47:39.526165
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    if py_fact_collector is not None:
        assert py_fact_collector.name == 'python'
        assert len(py_fact_collector._fact_ids) == 0
        assert hasattr(py_fact_collector, 'collect')


# Generated at 2022-06-20 19:47:50.162953
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()

    result = py_fc.collect()

    assert result['python']['version']['major'] == sys.version_info.major
    assert result['python']['version']['minor'] == sys.version_info.minor
    assert result['python']['version']['micro'] == sys.version_info.micro
    assert result['python']['version']['releaselevel'] == sys.version_info.releaselevel
    assert result['python']['version']['serial'] == sys.version_info.serial
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:47:56.738946
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = python_fact_collector.collect()
    assert isinstance(collected_facts, dict)
    assert isinstance(collected_facts['python'], dict)
    assert isinstance(collected_facts['python']['version'], dict)
    assert python_fact_collector.name in collected_facts
    assert collected_facts[python_fact_collector.name] == collected_facts['python']

# Generated at 2022-06-20 19:48:35.627367
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py = PythonFactCollector()
    py_facts = py.collect()
    assert py_facts['python']['version_info'][:3] == list(sys.version_info)[:3]
    assert py_facts['python']['executable'] == sys.executable
    assert py_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    try:
        py_facts = py_facts['python']['type'] == sys.subversion[0]
    except AttributeError:
        try:
            py_facts = py_facts['python']['type'] == sys.implementation.name
        except AttributeError:
            assert py_facts['python']['type'] is None

# Generated at 2022-06-20 19:48:45.236541
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Construct an instance of the PythonFactCollector class with a stub
    # module_utils/facts/collector.py.BaseFactCollector.
    fact_collector = PythonFactCollector(
        module_utils='module_utils',
        facts={},
        collected_facts={}
    )

    # Check result of collect method of PythonFactCollector class when
    # system has SSLContext support.
    MODULE.warn.call_count == 0
    result = fact_collector.collect()
    assert result['python']['has_sslcontext'] is True
    assert MODULE.warn.call_count == 0

    # Check result of collect method of PythonFactCollector class when
    # system has no SSLContext support.
    fact_collector._unsupported_sslv23_method = True
    MODULE.warn.call_count == 0


# Generated at 2022-06-20 19:48:53.443677
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Initialize PythonFactCollector instance.
    fact_collector = PythonFactCollector()

    # Call method collect of PythonFactCollector instance.
    facts = fact_collector.collect()

    # Verify facts dictionary.
    assert isinstance(facts, dict)
    assert 'python' in facts.keys()
    assert facts['python'].has_key('version')
    assert facts['python'].has_key('version_info')
    assert facts['python'].has_key('executable')
    assert facts['python'].has_key('has_sslcontext')
    assert facts['python'].has_key('type')
    key_list = ['major', 'minor', 'micro', 'releaselevel', 'serial']
    assert facts['python']['version'].has_key('major')

# Generated at 2022-06-20 19:48:55.832779
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert set(obj._fact_ids) == set(['python'])

# Generated at 2022-06-20 19:49:07.434887
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Mock sys
    python_version_info = (3, 5, 6, 'final', 0)
    python_executable = '/usr/bin/python3.5'
    python_subversion = ['CPython', '3.5.6']
    sys_mock = {'version_info': python_version_info, 'executable': python_executable, 'subversion': python_subversion}
    sys.version_info = python_version_info
    sys.executable = python_executable
    sys.subversion = python_subversion

    # Create an instance of PythonFactCollector
    pfc = PythonFactCollector()

    # Test the collect method with mocked out sys
    python_facts = pfc.collect(collected_facts=None)
    python_version = python_facts['python']['version']
   

# Generated at 2022-06-20 19:49:08.684602
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'

# Generated at 2022-06-20 19:49:14.902212
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    os_facts = PythonFactCollector().collect()
    assert type(os_facts) == dict
    assert os_facts['python']['version']['major'] == sys.version_info[0]
    if sys.version_info[0] == 2:
        assert os_facts['python']['type'] == sys.subversion[0]
    else:
        assert os_facts['python']['type'] == sys.implementation.name

# Generated at 2022-06-20 19:49:19.019783
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector()
    assert isinstance(pythonFactCollector, BaseFactCollector)
    assert pythonFactCollector.name == 'python'


# Generated at 2022-06-20 19:49:20.875742
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert isinstance(python_collector, PythonFactCollector)

# Generated at 2022-06-20 19:49:29.923594
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    assert isinstance(py_collector, BaseFactCollector)
    py_fact = py_collector.collect()
    assert py_fact['python']['version']['major'] == sys.version_info[0]
    assert py_fact['python']['version']['minor'] == sys.version_info[1]
    assert py_fact['python']['version']['micro'] == sys.version_info[2]
    assert py_fact['python']['version']['releaselevel'] == sys.version_info[3]
    assert py_fact['python']['version']['serial'] == sys.version_info[4]
    assert py_fact['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:50:39.141842
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pc = PythonFactCollector()
    assert pc.name == 'python'
    assert pc._fact_ids == set()



# Generated at 2022-06-20 19:50:41.269235
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()
    assert collector._module == None
    assert collector._collected_facts == None


# Generated at 2022-06-20 19:50:50.895588
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    import ansible.module_utils.facts.collector

    # Get an instance of PythonFactCollector
    py_collector = PythonFactCollector(ansible_module=None)

    # Call method
    python_facts = py_collector.collect()

    import sys, collections
    def all_key_values_found(sub_dict):
        for key, value in sub_dict.iteritems():
            if key == 'has_sslcontext':
                if not value == HAS_SSLCONTEXT:
                    return False
            elif isinstance(value, collections.Mapping):
                if not all_key_values_found(value):
                    return False
            elif key == 'version_info':
                if not value == list(sys.version_info):
                    return False

# Generated at 2022-06-20 19:51:00.362650
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = collector.collect()
    assert isinstance(collected_facts, dict)
    assert 'python' in collected_facts.keys()
    assert 'version' in collected_facts['python'].keys()
    assert isinstance(collected_facts['python']['version'], dict)
    assert 'major' in collected_facts['python']['version'].keys()
    assert isinstance(collected_facts['python']['version']['major'], int)
    assert 'minor' in collected_facts['python']['version'].keys()
    assert isinstance(collected_facts['python']['version']['minor'], int)
    assert 'micro' in collected_facts['python']['version'].keys()

# Generated at 2022-06-20 19:51:06.738684
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import json

    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    python_facts_collector = PythonFactCollector()

    collector = Collector()
    collector.add_collector(python_facts_collector)

    facts = collector.collect(module=None)

    test_facts = json.loads(json.dumps(facts, sort_keys=True, indent=4))

# Generated at 2022-06-20 19:51:09.339015
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Unit test for constructor of class PythonFactCollector'''

    p = PythonFactCollector()

    assert p.name == 'python'
    assert p._fact_ids == set()


# Generated at 2022-06-20 19:51:12.326025
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert type(obj.__class__.__name__) is str
    assert obj.__class__.__name__ == 'PythonFactCollector'


# Generated at 2022-06-20 19:51:13.850902
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert 'python' in pfc._fact_ids

# Generated at 2022-06-20 19:51:19.130808
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert isinstance(facts['python']['version'], dict)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)
    assert isinstance(facts['python']['has_sslcontext'], bool)
    assert isinstance(facts['python']['type'], (str, type(None)))

# Generated at 2022-06-20 19:51:21.642628
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyf = PythonFactCollector()
    assert pyf.name == 'python'
    assert pyf._fact_ids == set()