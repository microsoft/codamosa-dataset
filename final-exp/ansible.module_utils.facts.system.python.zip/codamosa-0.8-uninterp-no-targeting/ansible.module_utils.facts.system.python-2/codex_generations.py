

# Generated at 2022-06-20 19:42:48.982357
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect() is not None

# Generated at 2022-06-20 19:42:57.377742
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test collect method of PythonFactCollector
    p = PythonFactCollector()
    facts = p.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    try:
        facts['python']['type']
    except Exception:
        # We should get here because there is no type
        assert facts['python']['type'] is None

# Generated at 2022-06-20 19:42:59.355812
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-20 19:43:09.323441
# Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-20 19:43:10.448321
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']

# Generated at 2022-06-20 19:43:15.987482
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {}

    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python

# Generated at 2022-06-20 19:43:19.549817
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'
    assert py_collector._fact_ids == set()

# Generated at 2022-06-20 19:43:25.090420
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # This returns what is in sys.version_info
    my_python_facts = PythonFactCollector().collect()

    assert my_python_facts['python']['version']['major'] >= 2
    assert my_python_facts['python']['version']['releaselevel'] in ['final', 'dev', 'alpha', 'beta', 'candidate']


# Generated at 2022-06-20 19:43:30.841078
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # GIVEN: A PythonFactCollector object
    fact_collector = PythonFactCollector()

    # WHEN: Call fact_collector collect method
    collected_facts = fact_collector.collect()

    # THEN: FactCollector.collect should return dictionary containing facts
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert isinstance(collected_facts['python']['version'], dict)
    assert 'version_info' in collected_facts['python']
    assert isinstance(collected_facts['python']['version_info'], list)
    assert 'executable' in collected_facts['python']
    assert isinstance(collected_facts['python']['executable'], basestring)

# Generated at 2022-06-20 19:43:33.077434
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    assert isinstance(obj.collect(), dict)
    obj = None

# Generated at 2022-06-20 19:43:43.604249
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    # Create object of class PythonFactCollector
    fact_collector = PythonFactCollector()

    # Check if object of class PythonFactCollector is correctly created
    assert fact_collector.name == 'python'
    assert isinstance(fact_collector._fact_ids, set)
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:43:46.956872
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:43:49.465018
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()

    assert pyfc.name == 'python'
    assert pyfc._fact_ids == set()


# Generated at 2022-06-20 19:43:55.838801
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_facts = python_fact_collector.collect()
    # Sliced to 'N' elements from the version_info list
    version_info_list = collected_facts['python']['version_info'][:5]
    assert version_info_list == list(sys.version_info)

# Generated at 2022-06-20 19:44:01.280644
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    fact_dict = fc.collect()

    assert fact_dict == dict(python=dict(
        version=dict(
            major=3,
            minor=6,
            micro=8,
            releaselevel='final',
            serial=0),
        version_info=[3, 6, 8, 'final', 0],
        executable='/usr/bin/python3',
        has_sslcontext=True,
        type='CPython'))

# Generated at 2022-06-20 19:44:04.173349
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:44:05.901825
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = {}
    fact = PythonFactCollector(module)
    assert isinstance(fact, BaseFactCollector)

# Generated at 2022-06-20 19:44:07.428898
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-20 19:44:09.661468
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py = PythonFactCollector()
    assert py.name == 'python'
    assert py.collectors == set()
    assert py._fact_ids == set()

# Generated at 2022-06-20 19:44:14.158940
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.modules.utils.fixtures.collector import FACT_SUBSET

    collector = PythonFactCollector()
    result = collector.collect()
    assert result == FACT_SUBSET
    assert type(result) == dict

# Generated at 2022-06-20 19:44:30.589740
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector instance
    pfc = PythonFactCollector()

    # Create a simple object mapping to the test_facts.json file
    test_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': None
        }
    }

    # Collect facts from the PythonFactCollector instance and store them in the test_facts dict


# Generated at 2022-06-20 19:44:36.337436
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_collected = []
    python_info_keys = ['version', 'version_info', 'executable']
    collector = PythonFactCollector(None, facts_collected)
    assert type(collector.collect()['python']) == dict
    assert type(collector.collect()['python']['version']) == dict
    assert collector.collect()['python']['version'].keys() == ['major', 'minor', 'micro', 'releaselevel', 'serial']
    assert collector.collect()['python']['version_info'].count == 6
    assert collector.collect()['python']['executable'].endswith("python")
    for key in python_info_keys:
        assert key in collector.collect()['python'].keys()

# Generated at 2022-06-20 19:44:47.586579
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    def get_all_facts_in_a_dict(collected_facts=None):
        python_facts = PythonFactCollector().collect(module=None,collected_facts=collected_facts)
        collected_facts = collected_facts or {}
        collected_facts.update(python_facts)
        return collected_facts

    result = get_all_facts_in_a_dict()
    assert 'python' in result
    assert 'version' in result['python']
    assert isinstance(result['python']['version'], dict)
    assert 'major' in result['python']['version']
    assert isinstance(result['python']['version']['major'], int)
   

# Generated at 2022-06-20 19:44:55.995960
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    # Test that the correct keys are returned
    facts = fact_collector.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

    # Test that sys.subversion is prepended to sys.version if present
    # This is the case with python-2.7.x
    sys.subversion = ['subversion']
    facts = fact_collector.collect()
    assert 'subversion' in facts['python']['version']['full']
    sys.subversion = None

    # Test that sys.implementation.name is prepended to sys.version
    # if present.  This

# Generated at 2022-06-20 19:45:03.302660
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version_info'], list)
    assert 'executable' in facts['python']
    assert isinstance(facts['python']['executable'], str)
    assert 'has_sslcontext' in facts['python']
    return True


# Generated at 2022-06-20 19:45:13.592352
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    
    try:
        assert python_facts['python']['type'] == sys.subversion[0]
    except AttributeError:
        try:
            assert python_facts['python']['type'] == sys.implementation.name
        except AttributeError:
            assert python_facts['python']['type'] == None

# Generated at 2022-06-20 19:45:15.149016
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert 'python' in x._fact_ids

# Generated at 2022-06-20 19:45:17.250657
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_collector = PythonFactCollector()
    assert facts_collec

# Generated at 2022-06-20 19:45:27.480417
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    # sys.version_info is a tuple and cannot be mocked in the same manner
    # as other attributes.
    # Instead, this tests the existence of the version info keys.
    version_info = sys.version_info
    expected_version_info = {
        'major': version_info[0],
        'minor': version_info[1],
        'micro': version_info[2],
        'releaselevel': version_info[3],
        'serial': version_info[4]
    }

    # The remainder of the attributes are strings, so we can use
    # assertEqual(mock, expected)
    pfc._module = MockModule()
    pfc._module.run_command = Mock(return_value=('ansible test', 0))


# Generated at 2022-06-20 19:45:40.242335
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        sys.version_info = (1, 0, 0, 'final', 0)
        collector = PythonFactCollector(None)
        facts = collector.collect()
        assert facts['python']['version']['major'] == 1
        assert facts['python']['version']['minor'] == 0
        assert facts['python']['version']['micro'] == 0
        assert facts['python']['version']['releaselevel'] == 'final'
        assert facts['python']['version']['serial'] == 0
        assert facts['python']['version_info'] == [1, 0, 0, 'final', 0]
        assert facts['python']['executable'] == sys.executable
        assert facts['python']['has_sslcontext'] == False
    finally:
        sys.version

# Generated at 2022-06-20 19:46:01.086007
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert isinstance(facts['python']['version']['major'], int)
    assert isinstance(facts['python']['version']['minor'], int)
    assert isinstance(facts['python']['version']['micro'], int)
    assert isinstance(facts['python']['version']['releaselevel'], str)
    assert isinstance(facts['python']['version']['serial'], int)
    assert isinstance(facts['python']['version_info'], list)
    assert isinstance(facts['python']['executable'], str)
    assert isinstance(facts['python']['has_sslcontext'], bool)
    assert isinstance(facts['python']['type'], str)

# Generated at 2022-06-20 19:46:04.669254
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result = collector.collect()
    assert result['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-20 19:46:06.286005
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == "python"
    assert pfc.priority == 12

# Generated at 2022-06-20 19:46:08.057328
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert set(PythonFactCollector._fact_ids) == set(['python'])

# Generated at 2022-06-20 19:46:13.598627
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()

    # Some basic testing to ensure we have keys and values
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert 'type' in facts['python']
    assert 'executable' in facts['python']
    assert 'version_info' in facts['python']

# Generated at 2022-06-20 19:46:16.875738
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result = collector.collect()
    assert result['python']['version']['major'] == 3

# Generated at 2022-06-20 19:46:19.257265
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-20 19:46:23.069255
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Unit test for method collect of class PythonFactCollector
    '''
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert isinstance(facts, dict)
    assert facts['python']['executable'] is not None

# Generated at 2022-06-20 19:46:32.076856
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Return a dictionary containing facts about the python interpreter in use.'''

    pfc = PythonFactCollector()

    # Create a dictionary containing expected facts
    # This can be compared with the dictionary returned by pfc.collect()
    expected = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

    # Add type to expected if it is available

# Generated at 2022-06-20 19:46:42.902173
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    test_collector = PythonFactCollector()
    facts_dict = test_collector.collect()

    if sys.version_info[0] == 2:
        py2_key = 'executable'
        py2_val = '/usr/bin/python'

        py3_key = 'has_sslcontext'
        py3_val = False
    else:
        py2_key = 'has_sslcontext'
        py2_val = False

        py3_key = 'executable'
        py3_val = '/usr/bin/python3'

    assert facts_dict['python']['version']['major'] == sys.version_info[0]


# Generated at 2022-06-20 19:47:18.128599
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert python_facts['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-20 19:47:21.210842
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pcc = PythonFactCollector()
    assert pcc.name == 'python'
    assert pcc._fact_ids == set()

# Generated at 2022-06-20 19:47:23.127882
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create instance of PythonFactCollector
    pfc = PythonFactCollector()

    # Check method collect returns a dictionary
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-20 19:47:27.290300
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Check constructor of class PythonFactCollector'''

    p_f_c = PythonFactCollector()

    assert p_f_c is not None
    assert p_f_c._fact_ids == set()
    assert p_f_c.name == 'python'


# Generated at 2022-06-20 19:47:28.242548
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc.name == 'python'

# Generated at 2022-06-20 19:47:39.309553
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version_info'] == [2, 7, 12, 'final', 0]
    assert python_facts['python']['version']['major'] == 2
    assert python_facts['python']['version']['minor'] == 7
    assert python_facts['python']['version']['micro'] == 12
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert python_facts['python']['version']['serial'] == 0
    assert python_facts['python']['type'] == 'CPython'
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:47:48.157400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    assert pfc.collect() == {'python': {'executable': '/usr/bin/python',
                                        'has_sslcontext': True,
                                        'type': None,
                                        'version': {'major': 2,
                                                    'micro': 5,
                                                    'minor': 5,
                                                    'releaselevel': 'final',
                                                    'serial': 0},
                                        'version_info': [2,
                                                         5,
                                                         5,
                                                         'final',
                                                         0]}}

# Generated at 2022-06-20 19:47:49.172622
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector.collect()
    assert type(PythonFactCollector.collect()) is dict

# Generated at 2022-06-20 19:47:53.286216
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert 'python' in facts, 'Key "python" is missing in facts'
    assert 'version' in facts['python'], 'Key "version" is missing in facts["python"]'
    assert 'version_info' in facts['python'], 'Key "version_info" is missing in facts["python"]'
    assert 'executable' in facts['python'], 'Key "executable" is missing in facts["python"]'

# Generated at 2022-06-20 19:47:55.689909
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    assert 'python' in fc.collect(module=None, collected_facts=None).keys()

# Generated at 2022-06-20 19:49:01.314189
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    This test case is used to test the constructor of class PythonFactCollector
    """
    py_obj = PythonFactCollector()
    assert py_obj.name == 'python'
    assert py_obj._fact_ids == set()


# Generated at 2022-06-20 19:49:03.526531
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc.name == 'python'
    assert 'python' in fc._fact_ids

# Generated at 2022-06-20 19:49:07.637034
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test setup
    python_fact_collector = PythonFactCollector()

    # Test successful outcome of constructor
    assert python_fact_collector.name == 'python'
    assert isinstance(python_fact_collector.name, str)
    assert isinstance(python_fact_collector._fact_ids, set)

# Generated at 2022-06-20 19:49:13.129729
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector"""
    # Create an instance of class PythonFactCollector
    python_fact_collector = PythonFactCollector()
    # Call the method collect on the instance
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts

# Generated at 2022-06-20 19:49:19.843979
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    python_collector = PythonFactCollector()

    # Test public attributes of class PythonFactCollector
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()


# Generated at 2022-06-20 19:49:22.956396
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
   pfc = PythonFactCollector()
   assert pfc.name == 'python'
   assert type(pfc._fact_ids) == set
   assert pfc.collect()['python']['type'] == sys.implementation.name

# Generated at 2022-06-20 19:49:24.305953
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 19:49:25.091332
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    p._collect()

# Generated at 2022-06-20 19:49:34.264434
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect"""
    python_result = {}
    python_result['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-20 19:49:36.949930
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    class FakeModuleUtils(object):
        def __init__(self):
            self.module = None
    import sys
    module_utils = FakeModuleUtils()
    pfc = PythonFactCollector(module_utils, 'foo', {})
    assert(type(pfc.collect()) is dict)

# Generated at 2022-06-20 19:51:52.472198
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect()

# Generated at 2022-06-20 19:51:56.094771
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert set(fact_collector._collected_facts.keys()) == set(['python']), 'FactCollector did not collect facts as expected'

# Generated at 2022-06-20 19:52:06.455673
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']

    # Obtain python major and minor version
    major = sys.version_info[0]
    minor = sys.version_info[1]
    assert facts['python']['version']['major'] == major
    assert facts['python']['version']['minor'] == minor
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_

# Generated at 2022-06-20 19:52:07.957864
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc.collect()
    assert isinstance(pfc.get_facts(), dict)

# Generated at 2022-06-20 19:52:17.846732
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import copy

    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_classes
    from ansible.module_utils.facts.collector import get_collectors

    from ansible.module_utils.facts import timeout

    import sys

    # Create a temporary directory to use as the target of
    # ansible.module_utils.facts.timeout.FACT_CACHE_TIMEOUT_PATH.
    import tempfile
    temp_dir = tempfile.mkdtemp()

    # Change the value of FACT_C

# Generated at 2022-06-20 19:52:23.147449
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_fac

# Generated at 2022-06-20 19:52:33.758189
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from collections import namedtuple
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.collectors import python
    from ansible.module_utils.facts.collectors.python import PythonFactCollector
    PythonFactCollector.collect = lambda x: namedtuple('Python', ['version', 'version_info', 'executable', 'type', 'has_sslcontext'])(2.7, '2.7', '/usr/bin/python', 'CPython', 'True' )
    collector = PythonFactCollector()
    assert 'python' == collector.name
    assert isinstance(collector, Collector)
    assert isinstance(collector, python.PythonFactCollector)

# Generated at 2022-06-20 19:52:36.374275
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-20 19:52:38.380604
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    result = PythonFactCollector(None)
    assert result.name == 'python', "Name of PythonFactCollector should be 'python'."

# Generated at 2022-06-20 19:52:45.883504
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact = PythonFactCollector()
    facts = fact.collect()
    assert(facts['python']['has_sslcontext'] == True)
    assert(facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    })
    assert(facts['python']['version_info'] == list(sys.version_info))