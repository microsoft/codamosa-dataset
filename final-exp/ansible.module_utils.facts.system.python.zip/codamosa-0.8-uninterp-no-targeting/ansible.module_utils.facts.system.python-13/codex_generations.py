

# Generated at 2022-06-20 19:42:47.365640
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    cf = PythonFactCollector()
    assert cf._fact_ids == set()

# Unit tests for methods of class PythonFactCollector

# Generated at 2022-06-20 19:42:50.477249
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts_dict = fact_collector.collect()
    assert 'python' in facts_dict
    assert 'version' in facts_dict['python']
    assert 'version_info' in facts_dict['python']
    assert 'executable' in facts_dict['python']
    assert 'has_sslcontext' in facts_dict['python']

# Generated at 2022-06-20 19:43:00.015694
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.python import PythonFactCollector
    import sys
    # Initialize collector 'Python'
    test_collector = PythonFactCollector()
    # Test method collect from PythonFactCollector
    # Response from the PythonFactCollector.collect should be the same with the var 'expected'
    # But it not the same, check in your method collect of PythonFactCollector what is the problem

# Generated at 2022-06-20 19:43:09.617194
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import pytest
    from ansible.module_utils.facts import Facts

    test_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-20 19:43:13.683191
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = pc.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version_info'], list)
    assert 'executable' in facts['python']
    assert isinstance(facts['python']['executable'], basestring)
    assert 'has_sslcontext' in facts['python']
    assert isinstance(facts['python']['has_sslcontext'], bool)
    assert 'type' in facts['python']

# Generated at 2022-06-20 19:43:15.784561
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()
    assert pyfc.name == 'python'
    assert len(pyfc._fact_ids) == 0

# Generated at 2022-06-20 19:43:19.973325
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_data = {}
    facts = PythonFactCollector(fact_data)
    assert facts.name == 'python'
    assert set(facts.fetch_facts().keys()) == {'python'}

# Generated at 2022-06-20 19:43:23.170500
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == 'python'

# Generated at 2022-06-20 19:43:27.149340
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    def MockModule(ansible_module_args=None, ansible_facts=None):
        if ansible_facts:
            return True
        return False

    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect(MockModule())

# Generated at 2022-06-20 19:43:38.489455
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Unit test for method collect of class PythonFactCollector'''
    python_collector = PythonFactCollector()
    
    # Unit test of method return
    assert isinstance(python_collector.collect()['python'], dict)
    assert isinstance(python_collector.collect()['python']['executable'], str)
    assert isinstance(python_collector.collect()['python']['version'], dict)
    assert isinstance(python_collector.collect()['python']['version']['major'], int)
    assert isinstance(python_collector.collect()['python']['version']['minor'], int)
    assert isinstance(python_collector.collect()['python']['version']['micro'], int)

# Generated at 2022-06-20 19:43:52.090236
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector

    python_fact_collector = PythonFactCollector()


# Generated at 2022-06-20 19:44:02.550609
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # load facts
    collector = PythonFactCollector()
    result = collector.collect()

    # test version property is separated correctly
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)

    # test executable path
    assert result['python']['executable'] == sys.executable

   

# Generated at 2022-06-20 19:44:06.689121
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector.collect()['python']['version']['major'] == 3

#  Unit test for method collect of class PythonFactCollector

# Generated at 2022-06-20 19:44:09.111277
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    _pfc = PythonFactCollector()
    assert _pfc.collect()['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:44:20.685248
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Instanciate a PythonFactCollector object
    python_fact_collector_obj = PythonFactCollector()

    # Test if the result of method collect of PythonFactCollector object is a dict
    python_facts = python_fact_collector_obj.collect()
    if not isinstance(python_facts, dict):
        raise AssertionError('Invalid return type for method collect of class PythonFactCollector. It should return a dict')

    # Test if the returned dict contains the expected members
    for member in [ 'version', 'version_info', 'executable', 'has_sslcontext', 'type' ]:
        if member not in python_facts['python']:
            raise AssertionError('Member {} not in return of method collect of class PythonFactCollector'.format(member))

    # Test if the returned dict contains the expected members
   

# Generated at 2022-06-20 19:44:25.986602
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    facts = PythonFactCollector().collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert type(facts['python']['has_sslcontext']) is bool
    assert 'type' in facts['python']

# Generated at 2022-06-20 19:44:33.735676
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test empty parametters
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    python_fact = python_facts['python']
    assert 'version' in python_fact
    python_version = python_fact['version']
    assert 'major' in python_version
    assert 'minor' in python_version
    assert 'micro' in python_version
    assert 'releaselevel' in python_version
    assert 'serial' in python_version
    assert 'version_info' in python_fact
    assert 'executable' in python_fact
    assert 'has_sslcontext' in python_fact


# Generated at 2022-06-20 19:44:36.105633
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'

# Generated at 2022-06-20 19:44:47.386644
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    facts = py_fact_collector.collect()

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable


# Generated at 2022-06-20 19:44:55.856580
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector(None)

    assert isinstance(python_fact_collector.collect(), dict), \
        "Returned variable is not of type dict"

    # Test that the python variable contains a key 'version'.
    assert 'version' in python_fact_collector.collect()['python'], \
        "dict returned by python_fact_collector.collect() does not contain key 'version'"

    # Test that the python variable contains a key 'version_info'.
    assert 'version_info' in python_fact_collector.collect()['python'], \
        "dict returned by python_fact_collector.collect() does not contain key 'version_info'"

    # Test that the python variable contains a key 'executable'.

# Generated at 2022-06-20 19:45:13.259789
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    from ansible.module_utils.facts.collectors.python import PythonFactCollector

    fact_collector_obj = PythonFactCollector()

    # python.version is always added to collected_facts
    collected_facts = {'python': {'version': '2.7'}}

    # python.has_sslcontext is only returned when actual ssl support
    # was detected
    if HAS_SSLCONTEXT:
        assert(fact_collector_obj.collect(None, collected_facts)['python']['has_sslcontext'] is True)
    else:
        assert('has_sslcontext' not in fact_collector_obj.collect(None, collected_facts)['python'])


# Generated at 2022-06-20 19:45:24.348412
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = dict()
    collector = PythonFactCollector()
    facts = collector.collect(collected_facts=collected_facts)

    assert 'python' in facts
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:45:26.025909
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'


# Generated at 2022-06-20 19:45:27.208687
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector()
    assert pythonFactCollector

# Generated at 2022-06-20 19:45:31.945669
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:45:42.709996
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.modules.utility.execution.results import AnsibleFailJson
    from ansible_collections.ansible.community.tests.unit.modules.utility.compat import mock_module

    if sys.version_info[0] == 2:
        with patch('ansible_collections.ansible.community.plugins.module_utils.facts.collector.subprocess.Popen', side_effect = OSError()):
            with pytest.raises(AnsibleFailJson):
                module = mock_module()
                collect_result = PythonFactCollector(module=module, collected_facts=collector.Collector()).collect()

# Generated at 2022-06-20 19:45:53.183316
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector instance
    pfc = PythonFactCollector()

    # Compare the expected and actual results for method collect
    expected_result = {
        'python': {
            'has_sslcontext': HAS_SSLCONTEXT,
            'executable': sys.executable,
            'version': {
                'serial': sys.version_info[4],
                'releaselevel': sys.version_info[3],
                'micro': sys.version_info[2],
                'minor': sys.version_info[1],
                'major': sys.version_info[0]
            },
            'version_info': list(sys.version_info),
            'type': 'CPython'
        }
    }

    actual_result = pfc.collect()


# Generated at 2022-06-20 19:45:54.812229
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert fact_collector

# Generated at 2022-06-20 19:46:05.263548
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], basestring)
    assert isinstance(python_facts['python']['has_sslcontext'], (bool, type(None)))
    assert isinstance(python_facts['python']['type'], (basestring, type(None)))

# Generated at 2022-06-20 19:46:05.836098
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-20 19:46:22.942791
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-20 19:46:27.303473
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    try:
        assert python_facts['python']['type'] == sys.subversion[0]
    except AttributeError:
        try:
            assert python_facts['python']['type'] == sys.implementation.name
        except AttributeError:
            assert python

# Generated at 2022-06-20 19:46:29.927885
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:46:35.377590
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Dict of collected facts
    collected_facts = {}

    # Create PythonFactCollector object
    fc = PythonFactCollector()

    # Run method collect of class PythonFactCollector
    fc.collect(collected_facts=collected_facts)

    # Check that python_facts are in collected_facts
    assert 'python' in collected_facts


# Generated at 2022-06-20 19:46:38.236000
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    try:
        x = PythonFactCollector()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-20 19:46:40.422054
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector.fact_names == set(['python'])

# Generated at 2022-06-20 19:46:42.465325
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-20 19:46:45.595187
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()



# Generated at 2022-06-20 19:46:47.265264
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-20 19:46:49.407174
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert 'python' == pfc.name
    assert isinstance(pfc._fact_ids, set)
    assert pfc.collect()['python']['has_sslcontext']

# Generated at 2022-06-20 19:47:21.689507
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.collect()

# Generated at 2022-06-20 19:47:32.118431
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert not HAS_SSLCONTEXT

    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

    # These fields will vary depending on the Python version and install
    facts = c.collect()
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'type' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']

# Generated at 2022-06-20 19:47:33.170710
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
  o = PythonFactCollector()
  assert o.name == 'python'

# Generated at 2022-06-20 19:47:37.764819
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['micro'] == sys.version_info[2]

# Generated at 2022-06-20 19:47:39.278038
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_col_obj = PythonFactCollector()
    assert py_col_obj.name == 'python'

# Generated at 2022-06-20 19:47:43.340637
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    Verify that an instance of the class PythonFactCollector can be initialized
    """

    obj = PythonFactCollector()

    assert obj is not None

# Generated at 2022-06-20 19:47:47.613873
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    python_facts = fact_collector.collect()

    python_fact_keys = ('version', 'version_info', 'executable', 'has_sslcontext', 'type')
    for python_fact_key in python_fact_keys:
        assert python_fact_key in python_facts['python']

# Generated at 2022-06-20 19:47:48.703981
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(
        PythonFactCollector(),
        PythonFactCollector
    )

# Generated at 2022-06-20 19:47:53.144066
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version_info'], list)
    assert 'executable' in facts['python']
    assert isinstance(facts['python']['executable'], str)

# Generated at 2022-06-20 19:47:59.652884
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test method collect of class PythonFactCollector
    # collect method returns python facts
    # No assert statment is used, since assert in python 2.6 is not a statement
    # Returning None from the test method implies success
    # where as any other value implies test failure
    results = {}
    collector = PythonFactCollector(module=None, collected_facts=results.copy())
    collector.collect()

# Generated at 2022-06-20 19:49:07.721763
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector(None)

    assert pfc
    assert isinstance(pfc, PythonFactCollector)
    assert pfc.name == 'python'

# Generated at 2022-06-20 19:49:10.809178
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == "python"
    assert obj._fact_ids == set(['python'])

# Generated at 2022-06-20 19:49:12.973322
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'

# Generated at 2022-06-20 19:49:16.977743
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    # Assert that variable name equal to 'python'
    assert p.name == 'python'

# Generated at 2022-06-20 19:49:17.953003
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    assert PythonFactCollector.collect()

# Generated at 2022-06-20 19:49:21.278306
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()


# Generated at 2022-06-20 19:49:21.913812
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-20 19:49:27.053211
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import Collector

    collector = Collector()
    result = collector._collect_facts(['python'])
    assert(result)

    assert(result['python']['version'])
    assert(result['python']['version_info'])
    assert(result['python']['executable'])
    assert(result['python']['has_sslcontext'])

# Generated at 2022-06-20 19:49:28.092047
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert 'python' == fc.name

# Generated at 2022-06-20 19:49:31.126541
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    assert isinstance(fc.collect(), dict)

# Generated at 2022-06-20 19:50:40.931824
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test instantiation of PythonFactCollector class"""
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None

# Generated at 2022-06-20 19:50:43.043140
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'
    assert not PythonFactCollector()._fact_ids

# Generated at 2022-06-20 19:50:45.385458
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()

    assert 'python' in facts

# Generated at 2022-06-20 19:50:51.164154
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    # We must be running on Python 2.6, 2.7, 3.3, 3.4, 3.5, 3.6, 3.7 or higher to test PythonFactCollector
    if sys.version_info[0] > 2 or (sys.version_info[0] == 2 and sys.version_info[1] >= 6):
        fact_collector = PythonFactCollector()
        fact_collector.collect()


if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-20 19:50:53.149304
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector({}, None)
    assert p.name == 'python'

# Generated at 2022-06-20 19:50:56.182234
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert len(collector._fact_ids) == 0


# Generated at 2022-06-20 19:51:04.057212
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facter = PythonFactCollector()
    result = facter.collect()

    assert 'python' in result
    assert isinstance(result['python'], dict)
    assert len(result['python']) > 0

    assert 'version' in result['python']
    assert isinstance(result['python']['version'], dict)
    assert len(result['python']['version']) > 0

    for key in ('major', 'minor', 'micro', 'releaselevel', 'serial'):
        assert key in result['python']['version']

    assert 'version_info' in result['python']
    assert isinstance(result['python']['version_info'], list)
    assert len(result['python']['version_info']) > 0

# Generated at 2022-06-20 19:51:04.505236
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-20 19:51:07.524725
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
        pyfc = PythonFactCollector()
        # check if isinstance return true when passed with PythonFactCollector class
        assert isinstance(pyfc, PythonFactCollector)
        # check if _fact_ids is a set
        assert isinstance(pyfc._fact_ids, set)
        # check if _fact_ids is not set
        assert not pyfc._fact_ids
        # check if name is python
        assert pyfc.name == 'python'


# Generated at 2022-06-20 19:51:09.993941
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()