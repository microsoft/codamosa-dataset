

# Generated at 2022-06-20 19:42:46.918002
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fc = PythonFactCollector()
    assert fc.name == 'python'
    assert fc._fact_ids == set()


# Generated at 2022-06-20 19:42:48.245431
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-20 19:42:54.458425
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Tests for the constructor of the class PythonFactCollector"""

    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert isinstance(py_fact_collector._fact_ids, set)
    assert py_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:42:59.344109
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.collect() == dict(python=dict(version=dict(major=sys.version_info[0], minor=sys.version_info[1], micro=sys.version_info[2], releaselevel=sys.version_info[3], serial=sys.version_info[4]), version_info=list(sys.version_info), executable=sys.executable, has_sslcontext=HAS_SSLCONTEXT, type=sys.subversion[0]))

# Generated at 2022-06-20 19:43:01.362672
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    pass

# Generated at 2022-06-20 19:43:04.424415
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    my_python_facts = PythonFactCollector().collect()
    assert 'python' in my_python_facts
    assert 'version' in my_python_facts['python']
    assert 'has_sslcontext' in my_python_facts['python']

# Generated at 2022-06-20 19:43:05.866267
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'

# Generated at 2022-06-20 19:43:07.969175
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    fact_collector._collect()


# Generated at 2022-06-20 19:43:14.615826
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None)
    result = collector.collect(None, None)
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == sys.version_info
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLC

# Generated at 2022-06-20 19:43:19.249502
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    result = python_facts.collect()

    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:43:30.601774
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    This is a unit test for method collect() of class PythonFactCollector
    '''
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['version']['major'] == 3
    assert result['python']['version']['minor'] == 6
    assert result['python']['version']['micro'] == 4
    assert result['python']['version']['releaselevel'] == 'final'
    assert result['python']['version']['serial'] == 0
    assert result['python']['version_info'] == [3, 6, 4, 'final', 0]
    assert result['python']['executable'] == sys.executable
    assert result['python']['has_sslcontext'] == True

# Generated at 2022-06-20 19:43:32.915470
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None

# Generated at 2022-06-20 19:43:35.053994
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_temp = PythonFactCollector()
    assert python_temp.name == 'python'

# Generated at 2022-06-20 19:43:41.887188
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create the class and run the collect method
    py = PythonFactCollector()
    result = py.collect()

    # Check if the result is a dictionary
    assert isinstance(result, dict)

    # Check if the result has the correct keys
    assert 'python' in result.keys()

    # Check if all the correct facts are in the result
    assert 'type' in result['python'].keys()
    assert 'version' in result['python'].keys()
    assert 'version_info' in result['python'].keys()
    assert 'executable' in result['python'].keys()
    assert 'has_sslcontext' in result['python'].keys()

    # Check if version is a dictionary with the correct keys
    assert isinstance(result['python']['version'], dict)

# Generated at 2022-06-20 19:43:51.867477
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test the return value of  PythonFactCollector.collect function
    """
    python_collector = PythonFactCollector()
    result = python_collector.collect()

    assert isinstance(result, dict)
    version = result['python']['version']
    assert isinstance(version, dict)
    assert isinstance(version['major'], int)
    assert isinstance(version['minor'], int)
    assert isinstance(version['micro'], int)
    assert isinstance(version['releaselevel'], str)
    assert isinstance(version['serial'], int)
    version_info = result['python']['version_info']
    assert isinstance(version_info, list)
    assert len(version_info) == 5
    assert isinstance(version_info[0], int)

# Generated at 2022-06-20 19:43:57.012267
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    c = PythonFactCollector()
    assert isinstance(c, PythonFactCollector)
    assert isinstance(c, BaseFactCollector)
    assert c.name == 'python'


# Generated at 2022-06-20 19:44:04.533637
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_collector = PythonFactCollector()
    assert test_collector.collect() == {
        'python': {
            'version': {
                'major': 3,
                'minor': 6,
                'micro': 6,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [
                3,
                6,
                6,
                'final',
                0
            ],
            'executable': '/usr/bin/python3.6m',
            'type': 'CPython',
            'has_sslcontext': True
        }
    }

# Generated at 2022-06-20 19:44:11.807203
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    expected_facts = {'python': {'version': {'major': sys.version_info[0],
                                             'minor': sys.version_info[1],
                                             'micro': sys.version_info[2],
                                             'releaselevel': sys.version_info[3],
                                             'serial': sys.version_info[4]},
                                 'version_info': list(sys.version_info),
                                 'executable': sys.executable,
                                 'has_sslcontext': HAS_SSLCONTEXT}}

    fact_collector = PythonFactCollector()
    actual_facts = fact_collector.collect()

    assert expected_facts == actual_facts

# Generated at 2022-06-20 19:44:18.021713
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = {}
    collector.collect(collected_facts=collected_facts)
    assert 'python' in collected_facts
    assert 'type' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'version' in collected_facts['python']
    assert 'has_sslcontext' in collected_facts['python']

# Generated at 2022-06-20 19:44:23.236233
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():

    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert isinstance(python_facts._fact_ids, set)
    # Check that python_facts._fact_ids is empty
    assert len(python_facts._fact_ids) == 0
    # Check that python_facts.collect() is of type dict
    assert isinstance(python_facts.collect(), dict)

# Generated at 2022-06-20 19:44:33.906252
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()


# Generated at 2022-06-20 19:44:45.785627
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import platform

    test_c = PythonFactCollector()
    test_dc = {}
    test_dc = test_c.collect(collect_default=True, collected_facts=test_dc)

    # below are a set of known facts that should be in the list
    # this first one can be used to indicate if the list has changed
    # these are the current known values on a Mac OS X 10.12.6 system
    if sys.version_info[0] >= 3:
        assert len(test_dc['python']['version_info']) == 5
    else:
        assert len(test_dc['python']['version_info']) == 5
    assert test_dc['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-20 19:44:47.265089
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector != None

# Generated at 2022-06-20 19:44:50.454364
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    pfacts = python_fact_collector.collect()
    assert len(pfacts) == 1
    assert 'python' in pfacts


# Generated at 2022-06-20 19:44:53.251629
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == 3



# Generated at 2022-06-20 19:44:57.079018
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

    c = PythonFactCollector()
    assert c._fact_ids == set()
    c.collect()

# Generated at 2022-06-20 19:45:00.266866
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.__name__ == 'PythonFactCollector'
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()
    assert PythonFactCollector.depends == tuple()

    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-20 19:45:01.997560
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert isinstance(c, PythonFactCollector)


# Generated at 2022-06-20 19:45:03.124872
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'

# Generated at 2022-06-20 19:45:04.187033
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector is not None

# Generated at 2022-06-20 19:45:21.440001
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_obj = PythonFactCollector()
    assert python_obj.name == 'python'
    assert python_obj.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-20 19:45:23.304720
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Instantiate the object
    obj = PythonFactCollector()

    # Should have class name in the list of fact ids
    assert 'python' in obj._fact_ids

# Generated at 2022-06-20 19:45:27.441929
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Return a dictionary of key/value pairs facts collected on the local
    system under the 'python' key.
    """
    facts = PythonFactCollector().collect()
    print(facts)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_PythonFactCollector_collect()

# Generated at 2022-06-20 19:45:31.942397
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()

    assert python_facts.name == 'python'
    assert python_facts._fact_ids == set()


# Generated at 2022-06-20 19:45:39.686002
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    result = { 'python': {'version': {'micro': 6, 'releaselevel': 'final', 'serial': 0, 'major': 3, 'minor': 6}, 'version_info': [3, 6, 6, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython'} }
    assert python_facts == result, "The output of the collect method of class PythonFactCollector is wrong"


# Generated at 2022-06-20 19:45:41.440482
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert isinstance(python_collector._fact_ids, set)

# Generated at 2022-06-20 19:45:49.155311
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test collect method of PythonFactCollector class
    """
    python_fact = PythonFactCollector()
    assert isinstance(python_fact.collect(), dict)
    assert 'python' in python_fact.collect()
    assert 'version' in python_fact.collect()['python']
    assert 'version_info' in python_fact.collect()['python']
    assert 'executable' in python_fact.collect()['python']
    assert 'has_sslcontext' in python_fact.collect()['python']
    assert 'type' in python_fact.collect()['python']

# Generated at 2022-06-20 19:45:50.101187
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    PythonFactCollector().collect()

# Generated at 2022-06-20 19:45:53.184588
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:45:55.024491
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == 'python'
    assert isinstance(py_fact_collector._fact_ids, set)

# Generated at 2022-06-20 19:46:29.723423
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py = PythonFactCollector()
    facts = py.collect(module=None, collected_facts=None)
    assert facts['python']
    assert facts['python']['version']
    assert facts['python']['version_info']
    assert facts['python']['type']
    assert facts['python']['executable']
    assert facts['python']['has_sslcontext']



# Generated at 2022-06-20 19:46:40.537109
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        # Check if we have SSLContext support
        from ssl import create_default_context, SSLContext
        has_context = True
    except ImportError:
        has_context = False

    expected_facts = {'python': {'version': {'major': sys.version_info[0],
                                             'minor': sys.version_info[1],
                                             'micro': sys.version_info[2],
                                             'releaselevel': sys.version_info[3],
                                             'serial': sys.version_info[4]},
                                 'version_info': list(sys.version_info),
                                 'executable': sys.executable,
                                 'type': sys.subversion[0],
                                 'has_sslcontext': has_context}}

# Generated at 2022-06-20 19:46:42.942921
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()

# Generated at 2022-06-20 19:46:45.010972
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test with a class
    x = PythonFactCollector()
    assert x



# Generated at 2022-06-20 19:46:48.474364
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    facts_collector = get_collector_instance('python')
    facts = facts_collector.collect()
    assert facts['python']['version']['major'] == 3
    assert facts['python']['version']['minor'] >= 5

# Generated at 2022-06-20 19:46:51.061694
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    try:
        obj.collect()
    except:
        assert False, "An exception occurred while trying to collect facts"

# Generated at 2022-06-20 19:46:59.300570
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    facts = obj.collect()['python']
    assert facts['version']['major'] is not None
    assert facts['version']['minor'] is not None
    assert facts['version']['micro'] is not None
    assert facts['version']['releaselevel'] is not None
    assert facts['version']['serial'] is not None
    assert facts['version_info'] is not None
    assert facts['executable'] is not None
    assert facts['has_sslcontext'] is not None
    assert facts['type'] is not None

# Generated at 2022-06-20 19:47:02.527676
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:47:04.821341
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'


# Generated at 2022-06-20 19:47:07.999714
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc.priority == 10
    assert pfc.depends == ()

# Generated at 2022-06-20 19:48:19.840799
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()

    assert python_collector.name == 'python'
    collected_facts = {}
    python_collector.collect(collected_facts=collected_facts)
    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]
    assert collected_facts['python']['version_info'] == list

# Generated at 2022-06-20 19:48:30.379231
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()

    test_python_facts = python_fact_collector.collect()
    expected_python_facts = {
        "python": {
            "version": {
                "major": sys.version_info[0],
                "minor": sys.version_info[1],
                "micro": sys.version_info[2],
                "releaselevel": sys.version_info[3],
                "serial": sys.version_info[4]

            },
            "version_info": list(sys.version_info),
            "executable": sys.executable,
            "has_sslcontext": HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-20 19:48:32.039213
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()



# Generated at 2022-06-20 19:48:34.787947
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test constructor of class SosCollector
    test_collector = PythonFactCollector()
    assert test_collector.name == 'python'
    assert test_collector._fact_ids == set()

# Generated at 2022-06-20 19:48:37.782157
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert isinstance(facts, dict)

# Generated at 2022-06-20 19:48:47.624628
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.subversion[0]
        }
    }

# Generated at 2022-06-20 19:48:50.075533
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert len(python_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 19:49:01.584676
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['ansible_local']['python']['version_info'][0] == sys.version_info[0]
    assert python_facts['ansible_local']['python']['version_info'][1] == sys.version_info[1]
    assert python_facts['ansible_local']['python']['version_info'][2] == sys.version_info[2]
    assert python_facts['ansible_local']['python']['version_info'][3] == sys.version_info[3]
    assert python_facts['ansible_local']['python']['version_info'][4] == sys.version_info[4]



# Generated at 2022-06-20 19:49:03.786737
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    processor = PythonFactCollector()
    assert processor.name == 'python'
    assert processor._fact_ids == set()


# Generated at 2022-06-20 19:49:05.795007
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pc = PythonFactCollector()
    assert pc.name == 'python'
    assert pc._fact_ids == set()

# Generated at 2022-06-20 19:51:20.977518
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    my_collector = PythonFactCollector()
    assert my_collector.name == 'python'

# Generated at 2022-06-20 19:51:23.560488
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert 'python' == fact_collector.name
    assert [] == fact_collector._fact_ids



# Generated at 2022-06-20 19:51:29.913520
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_data = fact_collector.collect()
    assert fact_data
    assert fact_data.get('python')
    assert fact_data['python'].get('version')
    assert fact_data['python'].get('version_info')
    assert fact_data['python'].get('executable')
    assert fact_data['python'].get('has_sslcontext')

# Generated at 2022-06-20 19:51:32.876256
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert bool(obj._fact_ids) is True

# Generated at 2022-06-20 19:51:34.870489
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts_dict = collector.collect()
    assert facts_dict['python']['type'] == 'CPython'

# Generated at 2022-06-20 19:51:44.695450
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert facts['python']['executable'] == sys.executable
    assert 'has_sslcontext' in facts['python']
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert 'type' in facts['python']
    assert facts['python']['type'] != None
    assert 'version' in facts['python']['version']
    assert 'version_info' in facts['python']['version']
    assert 'major' in facts['python']['version']

# Generated at 2022-06-20 19:51:50.199017
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import threading
    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }


# Generated at 2022-06-20 19:52:01.830131
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()

    # Testing urllib2 is not installed
    sys.modules['urllib2'] = None
    sys.modules['ssl'] = None
    facts = pc.collect()
    assert facts['python']['has_sslcontext'] == False
    del sys.modules['urllib2']
    del sys.modules['ssl']

    # Testing urllib2 is installed and ssl is not installed
    sys.modules['urllib2'] = True
    sys.modules['ssl'] = None
    facts = pc.collect()
    assert facts['python']['has_sslcontext'] == False
    del sys.modules['urllib2']
    del sys.modules['ssl']

    # Testing both urllib2 and ssl are imported
    sys.modules['urllib2'] = True


# Generated at 2022-06-20 19:52:03.369511
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:52:08.618674
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ Unit test for method collect of class PythonFactCollector"""

    mock_module = 'module'

    # Create a new instance of the PythonFactCollector
    pfc = PythonFactCollector()

    # Check if the collect method returns the expected result
    # In this case the method is expected to return a dictionary containing the
    # Python version
    try:
        pfc.collect(module=mock_module)
    except:
        # The collect method should not raise any exception
        assert False, 'Unexpected exception raised'

    # If everything went as expected, pass the test
    assert True