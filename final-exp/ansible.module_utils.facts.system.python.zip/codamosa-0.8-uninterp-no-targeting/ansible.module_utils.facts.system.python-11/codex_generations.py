

# Generated at 2022-06-20 19:42:58.902136
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test the method collect of the class PythonFactCollector
    """
    # Initialise the class PythonFactCollector
    pfc = PythonFactCollector(None, None, None)
    assert isinstance(pfc, PythonFactCollector)

    # Test the method collect of the class PythonFactCollector
    python_facts = pfc.collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], str)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-20 19:43:08.990610
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    import sys
    import pkg_resources
    # Create mock input facts
    collected_facts = {}
    # Create python fact collector
    fact_collector = PythonFactCollector(collected_facts, {})
    # Collect facts
    fact_collector.collect()
    # Get the collected facts
    python_facts = fact_collector.get_facts()

    # Test the version string
    version_string = '{0}.{1}.{2}'.format(sys.version_info[0], sys.version_info[1], sys.version_info[2])
    # On mac the version_string will be like "3.6.0 (v3.6.0:41df79263a11, Dec 22 2016, 17:23:13) "
    # and not "3.6.0 (default, Dec 22 2016, 17

# Generated at 2022-06-20 19:43:11.026302
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc is not None
    assert pfc.name == 'python'
    assert pfc.collect() is not None

# Generated at 2022-06-20 19:43:16.139452
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    result = pfc.collect()

    assert "python" in result
    assert "version" in result["python"]
    assert "version_info" in result["python"]
    assert "executable" in result["python"]
    assert "has_sslcontext" in result["python"]

# Generated at 2022-06-20 19:43:25.012544
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_data = fact_collector.collect()

    assert fact_data == {'python': {'version': {'major': 2, 'micro': 7, 'releaselevel': 'final', 'minor': 7, 'serial': 0},
                                    'version_info': [2, 7, 7, 'final', 0],
                                    'executable': '/usr/bin/python',
                                    'has_sslcontext': True,
                                    'type': 'CPython'}}


# Generated at 2022-06-20 19:43:28.446240
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    results = pfc.collect()

    assert 'python' in results
    python_facts = results['python']
    assert 'version' in python_facts
    assert 'version_info' in python_facts
    assert 'executable' in python_facts
    assert 'has_sslcontext' in python_facts

# Generated at 2022-06-20 19:43:30.311374
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == "python"

# Generated at 2022-06-20 19:43:32.913803
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
  pfc = PythonFactCollector()
  assert pfc.name == 'python'
  assert 'python' in pfc._fact_ids

# Generated at 2022-06-20 19:43:35.069008
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    d = PythonFactCollector()
    assert d.collect() == d

# Generated at 2022-06-20 19:43:35.846149
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Check output for each supported python version
    assert PythonFactCollector().collect()

# Generated at 2022-06-20 19:43:42.081886
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''Test constructor.'''
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-20 19:43:44.661746
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()  # should return None if there are no facts
    assert fact_collector._collected_facts

# Generated at 2022-06-20 19:43:45.569388
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert(PythonFactCollector().name == 'python')

# Generated at 2022-06-20 19:43:50.370637
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python', \
            "PythonFactCollector.name should be 'python', is {}".format(PythonFactCollector.name)
    assert PythonFactCollector._fact_ids == set(), \
            "PythonFactCollector._fact_ids should be set(), is {}".format(PythonFactCollector._fact_ids)

# Generated at 2022-06-20 19:43:51.858913
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-20 19:43:55.838620
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f.name == 'python'
    assert f._fact_ids == set()
    assert f.collect().keys() == ['python']

# Generated at 2022-06-20 19:44:05.557632
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    fact_collector = get_collector_instance()

    python_facts = fact_collector.get_facts()['python']
    assert python_facts['version']['major'] == sys.version_info[0]
    assert python_facts['version']['minor'] == sys.version_info[1]
    assert python_facts['version']['micro'] == sys.version_info[2]
    assert python_facts['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['version']['serial'] == sys.version_info[4]
    assert python_facts['version_info'] == list(sys.version_info)
    assert python_facts['executable'] == sys.executable

# Generated at 2022-06-20 19:44:06.747410
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:44:08.286008
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()

# Generated at 2022-06-20 19:44:10.681472
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:44:19.766437
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:44:29.493699
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test for method collect of class PythonFactCollector."""

    import sys

    # Create a simple python version_info like that returned by sys.version_info
    version_info = (2, 7, 5, 'final', 0)

    # Create an instance of PythonFactCollector
    fact = PythonFactCollector()

    # Assign values to the attributes of sys
    sys.version_info = version_info
    sys.version = '2.7.5 (default, May  3 2017, 07:55:04) \n[GCC 4.8.5 20150623 (Red Hat 4.8.5-11)]'
    sys.executable = '/usr/bin/python2.7'

    # Call the method collect of PythonFactCollector
    facts = fact.collect()

    # Check if returned facts match the expected value
   

# Generated at 2022-06-20 19:44:41.032398
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instantiate object
    pfc = PythonFactCollector()

    # Assert the parameter module is defined as a function
    assert callable(pfc.module)

    # Call function collect
    result = pfc.collect()

    # Assert the result is defined
    assert result

    # Assert the result has the required keys
    assert 'python' in result.keys()

    # Assert the key 'executable' has the value defined
    assert result['python']['executable']

    # Assert the key 'version' has the value defined
    assert result['python']['version']

    # Assert the key 'version_info' has the value defined
    assert result['python']['version_info']

    # Assert the key 'type' has the value defined
    assert result['python']['type']

    # Ass

# Generated at 2022-06-20 19:44:53.252599
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    FACT_DATA = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-20 19:45:00.960483
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.collect() == {
        'ansible_python': {
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }

# Generated at 2022-06-20 19:45:02.583075
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set(['python'])

# Generated at 2022-06-20 19:45:09.638584
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert f.collect() == {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }

# Generated at 2022-06-20 19:45:21.274452
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    collected_facts = {}
    collected_facts['python'] =  {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

# Generated at 2022-06-20 19:45:30.709519
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Mocking sys.version_info with a tuple
    # Mocking sys.executable with a string
    # Mocking sys.implementation.name with a string
    # Mocking sys.subversion with a list
    # Testing with an empty module
    python_facts = PythonFactCollector().collect(collected_facts={})
    assert 'python' in python_facts and 'version' in python_facts['python'] and 'version_info' in python_facts['python'] and 'has_sslcontext' in python_facts['python'] and 'executable' in python_facts['python'] and 'type' in python_facts['python']
    assert 6==len(python_facts['python']['version_info'])
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-20 19:45:39.642511
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector(None, None)
    fact_collector.collect()

    # We should have at least the following facts in the fact_collector results
    assert fact_collector.get_facts().has_key('python')
    assert fact_collector.get_facts()['python'].has_key('version')
    assert fact_collector.get_facts()['python'].has_key('version_info')
    assert fact_collector.get_facts()['python'].has_key('executable')
    assert fact_collector.get_facts()['python'].has_key('has_sslcontext')

# Generated at 2022-06-20 19:45:50.839982
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-20 19:45:52.543882
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x != None


# Generated at 2022-06-20 19:45:59.314230
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector('a')
    assert obj.name == 'a'
    assert obj.collect() == {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'version_info': [3, 7, 3, 'final', 0], 'executable': '/home/dummy/sources/ansible/hacking/env-setup', 'has_sslcontext': True, 'type': 'cpython'}}

# Generated at 2022-06-20 19:46:09.746439
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    import math

    # On some platforms, math.inf is not defined, we could use float('inf')
    # instead but that wouldn't work on Python 2.6. So let's dynamically use
    # whatever works:
    infinity = getattr(math, 'inf', float('inf'))

    # Test on both Python 2 and 3, since they behave slightly differently
    if sys.version_info.major > 2:
        # Python 3 shows micro version and releaselevel
        version_info = (3, 7, 6, 'final', 0)
        version_string = "%d.%d.%d" % version_info[:3]
    else:
        # Python 2 only shows major and minor version, no releaselevel
        version_info = (2, 7, 15)
        version_string = "%d.%d.%d"

# Generated at 2022-06-20 19:46:10.867787
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert(PythonFactCollector().name == 'python')


# Generated at 2022-06-20 19:46:21.407132
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # In general, we can't import module_utils.facts.collector because it has
    # a dependency on ansible.module_utils.basic which is not importable in
    # the standalone python environment. However, the python-specific file does
    # not have this dependency, so we can import it for unit testing.
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:46:23.068174
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf = PythonFactCollector()
    pf.collect()


# Generated at 2022-06-20 19:46:32.075803
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

    # Since 2.7.11 and 3.4.4 (https://docs.python.org/3.6/whatsnew/changelog.html#python-3-6-0-final)
    # the releaselevel changed from 'final' to 'final0'
    # so we test for both values
    assert facts['python']['version']['releaselevel'] in ['final', 'final0']
    assert facts['python']['version']['serial'] == sys.version_info[4]

    # Test on Python 2.6.x (no subversion nor implementation.

# Generated at 2022-06-20 19:46:42.900191
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    x = f.collect()
    assert x == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-20 19:46:44.100923
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()

# Generated at 2022-06-20 19:47:14.040906
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pyfc = PythonFactCollector()
    result = pyfc.collect()

    assert type(result) == dict
    assert 'python' in result
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:47:19.047346
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_module = PythonFactCollector()
    assert fact_module.name == 'python'
    assert fact_module._fact_ids == set()
    assert fact_module.collect()['python']['type'] in ('CPython', 'IronPython', 'Jython', 'PyPy')

# Generated at 2022-06-20 19:47:29.705465
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']
    assert 'has_sslcontext' in facts['python']

    assert isinstance(facts['python']['version']['major'], int)

# Generated at 2022-06-20 19:47:39.962840
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    collected_result = python_fact_collector.collect()

    assert isinstance(collected_result, dict)
    assert "python" in collected_result
    assert isinstance(collected_result["python"], dict)

    for key in ("version", "version_info", "executable", "type", "has_sslcontext"):
        assert key in collected_result["python"]

    assert isinstance(collected_result["python"]["version"], dict)
    assert isinstance(collected_result["python"]["version_info"], list)
    assert isinstance(collected_result["python"]["executable"], str)

# Generated at 2022-06-20 19:47:42.418008
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.collect()

# Generated at 2022-06-20 19:47:44.241720
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # call constructor without parameters
    assert PythonFactCollector().name == 'python'

# Generated at 2022-06-20 19:47:45.679129
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact = PythonFactCollector()
    assert fact.name == 'python'

# Generated at 2022-06-20 19:47:53.816693
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    res = pfc.collect()

    assert res['python']['version']['major'] == sys.version_info[0]
    assert res['python']['version']['minor'] == sys.version_info[1]
    assert res['python']['version']['micro'] == sys.version_info[2]
    assert res['python']['version']['releaselevel'] == sys.version_info[3]
    assert res['python']['version']['serial'] == sys.version_info[4]
    assert res['python']['version_info'] == list(sys.version_info)
    assert res['python']['executable'] == sys.executable
    assert res['python']['has_sslcontext'] == HAS_SSLCON

# Generated at 2022-06-20 19:47:55.373766
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Verify that constructor does not throw exceptions"""

    pfc = PythonFactCollector()

# Generated at 2022-06-20 19:48:04.235672
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_bytes

    python_fact = "executable: " + sys.executable + "\n"
    python_fact += "has_sslcontext: True\n"
    python_fact += "type: " + sys.implementation.name + "\n"
    python_fact += "version:\n"
    python_fact += "    major: " + str(sys.version_info.major) + "\n"
    python_fact += "    minor: " + str(sys.version_info.minor) + "\n"
    python_fact += "    micro: " + str(sys.version_info.micro) + "\n"
    python

# Generated at 2022-06-20 19:48:50.707486
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a new instance of PythonFactCollector
    pfc = PythonFactCollector()

    # run method collect of class PythonFactCollector
    result = pfc.collect()

    # test
    assert isinstance(result, dict)

# Generated at 2022-06-20 19:48:54.682932
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']

# Generated at 2022-06-20 19:48:58.896462
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:49:00.798122
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'

# Generated at 2022-06-20 19:49:04.568588
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version_info'] == [3, 5, 1, 'final', 0]
    assert python_facts['python']['version']['serial'] == 0

# Test the property name of class PythonFactCollector

# Generated at 2022-06-20 19:49:07.713998
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc.name == 'python'
    assert py_fc._fact_ids == set()

# Unit tests for methods of class PythonFactCollector

# Generated at 2022-06-20 19:49:10.808036
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert 'python' == c.name
    facts = c.collect()
    assert 'version' in facts['python']

# Generated at 2022-06-20 19:49:12.093757
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector


# Generated at 2022-06-20 19:49:14.636693
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:49:24.269124
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_inst = PythonFactCollector()
    assert python_inst.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': None
        }
    }

# Generated at 2022-06-20 19:50:39.638720
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.collect()['python'] is not None
    assert fact_collector.collect()['python']['has_sslcontext'] is not None

# Generated at 2022-06-20 19:50:40.931903
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'



# Generated at 2022-06-20 19:50:49.511185
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector.collect(None) == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': 'CPython'
        }
    }

# Generated at 2022-06-20 19:50:57.188135
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import collector

    # Inject a fake class for the import
    BaseFactCollector_real = collector.BaseFactCollector

    collector.BaseFactCollector = object

    # Run the method under test
    pythonfc = PythonFactCollector()
    pythonfc.collect()
    facts = pythonfc.get_facts()

    # Make sure we got the expected result
    if type(facts) != dict or 'python' not in facts:
        raise AssertionError("Could not find expected structure in facts")

    # Clean up
    collector.BaseFactCollector = BaseFactCollector_real

# Generated at 2022-06-20 19:51:05.051545
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert 'python' in facts, "Missing python facts"
    assert 'version' in facts['python'], "Missing python version facts"
    assert 'major' in facts['python']['version'], "Missing python major version facts"
    assert 'minor' in facts['python']['version'], "Missing python minor version facts"
    assert 'micro' in facts['python']['version'], "Missing python micro version facts"
    assert 'releaselevel' in facts['python']['version'], "Missing python releaselevel facts"
    assert 'serial' in facts['python']['version'], "Missing python serial version facts"
    assert 'version_info' in facts['python'], "Missing python version_info facts"

# Generated at 2022-06-20 19:51:10.485168
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    import os

    collector = PythonFactCollector()

    assert collector.collector[0] == 'python'
    assert collector.collector[1] == os.path.abspath(os.path.join(os.path.dirname(__file__), '../library/python.py'))
    assert collector.name == 'python'

# Generated at 2022-06-20 19:51:14.328189
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {'python': {'has_sslcontext': HAS_SSLCONTEXT, 'executable': sys.executable, 'type': 'CPython', 'version': {'micro': 2, 'minor': 7, 'serial': 0, 'releaselevel': 'final', 'major': 2}, 'version_info': [2, 7, 2, 'final', 0]}}


# Generated at 2022-06-20 19:51:18.730445
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-20 19:51:21.495716
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyCollector = PythonFactCollector()
    collected_facts = {}
    pyCollector.collect(collected_facts)
    assert isinstance(collected_facts, dict)

# Generated at 2022-06-20 19:51:22.967896
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'
    assert PythonFactCollector()._fact_ids is not None
    assert 'python' in PythonFactCollector()._fact_ids