

# Generated at 2022-06-20 19:42:50.116953
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # constructor
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

    # collect
    pfc.collect()

# Generated at 2022-06-20 19:42:57.933716
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    container = object()
    facts = {}
    collector = PythonFactCollector(container)

    actual = collector.collect(collected_facts=facts)
    assert actual == {'python': {'executable': sys.executable, 'has_sslcontext': True, 'type': 'CPython', 'version': {'major': 3, 'micro': 6, 'minor': 1, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 1, 6, 'final', 0]}}


# Generated at 2022-06-20 19:43:00.893505
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:43:03.263283
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    ph = PythonFactCollector()
    assert ph is not None
    assert ph.name == 'python'
    assert ph._fact_ids == set()


# Generated at 2022-06-20 19:43:06.116520
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Get the class
    collector = PythonFactCollector()
    # Run the collect test
    collector.collect()
    # Verify the returned python
    assert collector.collect()['python']


# Generated at 2022-06-20 19:43:07.885486
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:43:08.726387
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-20 19:43:10.180193
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name is 'python'
        

# Generated at 2022-06-20 19:43:11.217776
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.collect() is not None

# Generated at 2022-06-20 19:43:14.921397
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.collect() == {'python': {'has_sslcontext': True,
                                        'executable': sys.executable,
                                        'type': sys.implementation.name,
                                        'version': {'major': 3,
                                                    'micro': 6,
                                                    'minor': 5,
                                                    'releaselevel': 'final',
                                                    'serial': 0},
                                        'version_info': [3, 5, 6, 'final', 0]}}

# Generated at 2022-06-20 19:43:21.138223
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test creation of PythonFactCollector instance"""

    x = PythonFactCollector()
    assert x
    assert x.name == 'python'
    assert hasattr(x, 'collect')

    assert x._fact_ids == set()

    assert x.collect()

# Generated at 2022-06-20 19:43:29.869981
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    from ansible.module_utils.facts.collector import PythonFactCollector

    pfc = PythonFactCollector()
    facts_dict = pfc.collect()

    assert facts_dict['python']['version']['major'] == sys.version_info[0]
    assert facts_dict['python']['version']['minor'] == sys.version_info[1]
    assert facts_dict['python']['version']['micro'] == sys.version_info[2]
    assert facts_dict['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts_dict['python']['version']['serial'] == sys.version_info[4]
    assert facts_dict['python']['version_info'] == list(sys.version_info)
    assert facts

# Generated at 2022-06-20 19:43:35.536439
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python', 'PythonFactCollector.name returned %s instead of python' % pfc.name
    assert pfc._fact_ids == set(), 'PythonFactCollector._fact_ids returned %s instead of set()' % pfc._fact_ids


# Generated at 2022-06-20 19:43:37.376544
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert c.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:43:42.567259
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()
    assert pfc.collect() == pfc.collect(None, None)

# Generated at 2022-06-20 19:43:43.986490
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    with pytest.raises(TypeError):
        x = PythonFactCollector()

# Generated at 2022-06-20 19:43:45.306467
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PyCollector = PythonFactCollector()
    assert PyCollector.name == 'python'

# Generated at 2022-06-20 19:43:54.857741
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    actual = pfc.collect()
    expected = dict(python=dict(version=dict(
            major=sys.version_info[0],
            minor=sys.version_info[1],
            micro=sys.version_info[2],
            releaselevel=sys.version_info[3],
            serial=sys.version_info[4]),
                version_info=list(sys.version_info),
                executable=sys.executable,
                has_sslcontext=HAS_SSLCONTEXT))
    try:
        expected['python']['type'] = sys.implementation.name
    except AttributeError:
        expected['python']['type'] = sys.subversion[0]
    assert actual == expected

# Generated at 2022-06-20 19:43:57.442913
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collect = PythonFactCollector()
    results = py_collect.collect(collected_facts={})
    assert results['python']
    assert results['python']['version']
    assert results['python']['has_sslcontext']

# Generated at 2022-06-20 19:44:05.057613
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    facts_obj = PythonFactCollector()
    python_facts = facts_obj.collect()

    assert python_facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert python_facts['python']['version_info']
    assert python_facts['python']['executable']
    assert python_facts['python']['type']

# Generated at 2022-06-20 19:44:10.473518
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    import sys
    from ansible.module_utils.facts.collector import BaseFactCollector

# Generated at 2022-06-20 19:44:22.338933
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_module = sys.modules['__main__'].__class__.__module__
    py_version = sys.version_info[0:5]
    execut = sys.executable
    has_ssl = HAS_SSLCONTEXT
    py_type = hasattr(sys, "subversion") and sys.subversion[0] or hasattr(sys, 'implementation') and sys.implementation.name or None

    python_facts = {}

# Generated at 2022-06-20 19:44:23.235369
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:44:25.936469
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfactcollector = PythonFactCollector()
    assert pythonfactcollector.name == 'python'
    assert pythonfactcollector._fact_ids == set()


# Generated at 2022-06-20 19:44:34.158714
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Validates that the collect() method of the PythonFactCollector produces a dictionary with
    the requisite key.
    :return:
    """
    import unittest
    import sys

    class ImportedModule(object):
        def __init__(self, name, **kwargs):
            self.__name__ = name
            self.__dict__.update(kwargs)

    class C:
        """
        Simple test class for sys.implementation attribute
        """
        pass

    class TestPythonFactCollector(unittest.TestCase):
        def test_collect(self):
            """
            This test validates that the method collect() produces the expected results when executed.
            :return:
            """
            # Setup a sys module with minimal details

# Generated at 2022-06-20 19:44:45.829226
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collectors
    collectors.collectors['python'] = PythonFactCollector()

    # Test with no params
    python_facts = PythonFactCollector.collect(None, None)

    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert isinstance(python_facts['python'], dict)

    # Ensure the major version is an int (should raise an exception if not)
    int(python_facts['python']['version']['major'])
    # Ensure the minor version is an int (should raise an exception if not)
    int(python_facts['python']['version']['minor'])
    # Ensure the micro version is an int (should raise an exception if not)

# Generated at 2022-06-20 19:44:54.790524
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()
    assert result == {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': [
                sys.version_info[0],
                sys.version_info[1],
                sys.version_info[2],
                sys.version_info[3],
                sys.version_info[4]
            ]
        }
    }

# Generated at 2022-06-20 19:45:02.028260
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == "python"
    assert python_fact_collector._fact_ids == set()

    # FactCollector.collect method returns a dictionary of facts from
    # a given source.
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

    assert python_fact_collector._check_ignore('python', collected_facts=None)

# Generated at 2022-06-20 19:45:03.880204
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'


# Generated at 2022-06-20 19:45:06.070328
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version_info'][0] == 3

# Generated at 2022-06-20 19:45:15.964574
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert 'python' == PythonFactCollector.name
    assert set() == PythonFactCollector._fact_ids


# Generated at 2022-06-20 19:45:19.982416
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']

# Generated at 2022-06-20 19:45:23.199546
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts import Collector
    c = Collector("python", [PythonFactCollector])
    assert c is not None


# Generated at 2022-06-20 19:45:31.075944
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create fact collector
    fact_collector = PythonFactCollector()

    # Collect facts
    facts = fact_collector.collect()

    # Verify instance
    assert type(fact_collector) is PythonFactCollector

    # Verify data type
    assert type(facts) is dict

    # Verify the number of facts
    assert len(facts) == 1

    # Verify the presence of fact 'ansible_python'
    assert 'python' in facts

    # Verify the type of the fact 'ansible_python'
    assert type(facts['python']) is dict

    # Verify the type of the fact 'ansible_python.version_info'
    assert type(facts['python']['version_info']) is list

    # Verify the type of the fact 'ansible_python.version_info'

# Generated at 2022-06-20 19:45:39.552954
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    result_dict = collector.collect()
    print("%s" % result_dict)
    assert 'python' in result_dict
    assert 'version' in result_dict['python']
    assert 'version_info' in result_dict['python']
    assert 'executable' in result_dict['python']
    assert 'type' in result_dict['python']
    assert 'has_sslcontext' in result_dict['python']


# Run unit test when this is executed directly
if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-20 19:45:49.625170
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_version = sys.version_info
    python_minor = python_version[0] == 2 and python_version[1] < 7
    module = None
    collected_facts = None
    pfc = PythonFactCollector()
    x = pfc.collect(module, collected_facts)
    assert len(x['python']['version_info']) == 5
    assert x['python']['version']['major'] == python_version[0]
    assert x['python']['version']['minor'] == python_version[1]
    assert x['python']['version']['micro'] == python_version[2]
    assert x['python']['version']['releaselevel'] == python_version[3]

# Generated at 2022-06-20 19:45:58.732157
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    (facts_dict, additional_warnings) = obj.collect()
    assert facts_dict.get('python') is not None
    assert facts_dict['python']['type'] is not None
    assert facts_dict['python']['version_info'] is not None
    assert facts_dict['python']['version']['major'] == sys.version_info[0]
    assert facts_dict['python']['version']['minor'] == sys.version_info[1]
    assert facts_dict['python']['version']['micro'] == sys.version_info[2]
    assert facts_dict['python']['version']['releaselevel'] == sys.version_info[3]

# Generated at 2022-06-20 19:46:06.678251
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
        Unit test for method PythonFactCollector.collect
    """
    python_fact_collector = PythonFactCollector()
    collected_facts = {}
    python_facts = python_fact_collector.collect(collected_facts=collected_facts)
    assert 'python' in python_facts
    python_fact = python_facts['python']
    assert 'version' in python_fact
    assert 'version_info' in python_fact
    assert 'executable' in python_fact
    assert 'type' in python_fact

# Generated at 2022-06-20 19:46:08.061339
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-20 19:46:09.816547
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-20 19:46:28.881618
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    values = {
        'name': 'python',
        '_fact_ids': set()
    }

    pfc = PythonFactCollector()
    for key in values:
        assert getattr(pfc, key) == values[key]


# Generated at 2022-06-20 19:46:32.104208
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # If a subclass does not set _fact_class_name or _fact_ids, a TypeError should be raised
    try:
        o = PythonFactCollector()
        raise Exception
    except TypeError:
        pass

# Generated at 2022-06-20 19:46:34.285874
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test empty ansible_facts
    ansible_facts = {}

    # Test actual ansible_facts
    raw_facts = dict(PythonFactCollector().collect(collected_facts=ansible_facts))
    assert 'python' in raw_facts

# Generated at 2022-06-20 19:46:45.092819
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Test with the collect method of the PythonFactCollector.
    """
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_as_dict

    python_fact_collector = get_collector_instance('python')

    collected_facts = {}
    collected_facts = python_fact_collector.collect(collected_facts=collected_facts)

# Generated at 2022-06-20 19:46:47.648521
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert type(pfc) is PythonFactCollector
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Test the collector method of class PythonFactCollector

# Generated at 2022-06-20 19:46:57.752535
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    x = PythonFactCollector()
    result = x.collect()
    assert(result['python']['version']['major'] == platform.python_version_tuple()[0])
    assert(result['python']['version']['minor'] == platform.python_version_tuple()[1])
    assert(result['python']['version']['micro'] == platform.python_version_tuple()[2])
    assert(result['python']['version']['releaselevel'] == platform.python_version_tuple()[3])
    assert(result['python']['version']['serial'] == platform.python_version_tuple()[4])
    assert(result['python']['version_info'] == list(platform.python_version_tuple()))

# Generated at 2022-06-20 19:47:04.333503
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    python_facts = collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-20 19:47:13.509433
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()
    assert x.collect() == {'python': {'version': {'major': 3, 'minor': 6, 'micro': 4, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 6, 4, 'final', 0], 'executable': '/home/travis/virtualenv/python3.6.4/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-20 19:47:15.701814
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:47:20.706703
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()
    assert isinstance(pfc.collect(), dict)


# Generated at 2022-06-20 19:47:54.666135
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:48:01.196003
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Create instance of PythonFactCollector and check basic attributes
    python_instance = PythonFactCollector()
    assert isinstance(python_instance, BaseFactCollector)
    assert hasattr(python_instance, 'name') and python_instance.name == 'python'
    assert hasattr(python_instance, '_fact_ids') and python_instance._fact_ids == set()

    # test collect() method
    assert isinstance(python_instance.collect(), dict)

# Generated at 2022-06-20 19:48:08.705585
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()

    assert 'python' in result
    python_info_result = result['python']
    assert 'version' in python_info_result
    assert 'version_info' in python_info_result
    assert 'executable' in python_info_result
    assert 'has_sslcontext' in python_info_result
    assert 'type' in python_info_result

# Generated at 2022-06-20 19:48:09.702967
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-20 19:48:20.547986
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    facts = pfc.collect()

    assert 'python' in facts
    assert type(facts['python']['version_info']) == list
    assert type(facts['python']['version']) == dict
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]

# Generated at 2022-06-20 19:48:23.229107
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonFactCollector = PythonFactCollector()
    assert pythonFactCollector.name == 'python'
    assert pythonFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:48:28.051400
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python', "Wrong name of PythonFactCollector"
    assert python_fact_collector._fact_ids == set(), "Wrong value of _fact_ids of PythonFactCollector"

# Generated at 2022-06-20 19:48:28.936801
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact = PythonFactCollector()
    assert fact.name == 'python'

# Generated at 2022-06-20 19:48:37.370609
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    #This test is optional as it needs a full installation of Python 2.7,
    #3.3 and pypy to be installed in the system.
    #Initialize a new instance of PythonFactCollector class
    python_fact_collector = PythonFactCollector()
    #Call the collect method with module and collected_facts parameters
    python_facts = python_fact_collector.collect()
    #Assert if method collect returns a dict
    assert isinstance(python_facts, dict)
    #Assert if method collect returns dict with key python
    assert python_facts.has_key('python')
    #Assert if method collect returns dict with key major, minor, micro and releaselevel
    assert python_facts['python']['version'].has_key('major')

# Generated at 2022-06-20 19:48:39.124481
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    gc = PythonFactCollector()

    assert gc.name == 'python'
    assert gc._fact_ids == set()


# Generated at 2022-06-20 19:49:53.066780
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    facts = python_fact.collect()
    assert 'python' in facts
    assert 'version' not in facts
    assert 'version_info' not in facts
    assert 'executable' not in facts
    assert 'has_sslcontext' not in facts
    assert 'type' not in facts

    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-20 19:49:55.868143
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = type('DummyModule', (object,), {'exit_json': lambda self, **kwargs: None})()
    obj = PythonFactCollector(module)
    assert obj.name == 'python'
    assert issubclass(PythonFactCollector, BaseFactCollector)

# Generated at 2022-06-20 19:50:01.198228
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_facts = PythonFactCollector()
    collected_facts = {}

    py_facts.collect(collected_facts)

    expected_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'micro': sys.version_info[2],
                'minor': sys.version_info[1],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-20 19:50:03.109636
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)

# Generated at 2022-06-20 19:50:08.478662
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collected_facts = {}
    collector = PythonFactCollector()
    result = collector.collect(collected_facts=collected_facts)
    assert 'python' in result
    assert 'version' in result['python']
    assert 'major' in result['python']['version']
    assert 'minor' in result['python']['version']
    assert 'micro' in result['python']['version']
    assert 'releaselevel' in result['python']['version']
    assert 'serial' in result['python']['version']
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'type' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-20 19:50:17.897336
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert(python_fact_collector.collect()['python']['version_info'][0] == sys.version_info[0])
    assert(python_fact_collector.collect()['python']['version_info'] == list(sys.version_info))
    assert(python_fact_collector.collect()['python']['executable'] == sys.executable)
    assert(python_fact_collector.collect()['python']['has_sslcontext'] == HAS_SSLCONTEXT)

# Generated at 2022-06-20 19:50:21.529876
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector is not None
    assert python_fact_collector._fact_ids == set()
    assert python_fact_collector.name == "python"

# Generated at 2022-06-20 19:50:22.322605
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc

# Generated at 2022-06-20 19:50:33.082788
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()

    assert result is not None
    assert result['python'] is not None
    assert result['python']['version'] is not None
    assert result['python']['version']['major'] is not None
    assert result['python']['version']['minor'] is not None
    assert result['python']['version']['micro'] is not None
    assert result['python']['version']['releaselevel'] is not None
    assert result['python']['version']['serial'] is not None
    assert result['python']['version_info'] is not None
    assert result['python']['has_sslcontext'] is not None
    assert result['python']['type'] is not None

# Generated at 2022-06-20 19:50:42.283356
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test the collect method of the PythonFactCollector
    """
    from os.path import dirname, abspath, join
    import sys
    import tempfile
    import re

    # Change to the test directory
    test_dir = dirname(abspath(__file__))
    old_dir = abspath(tempfile.mkdtemp())
    sys.path.append(test_dir)
    sys.path.append(test_dir + '/../../../')
    sys.path.append(test_dir + '/../utils/')

    # Mock the imports
    import ansible.module_utils.facts.collector

    # Get the python facts
    facts = PythonFactCollector().collect()
    assert facts['python']['executable'] == sys.executable