

# Generated at 2022-06-20 19:42:57.529690
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    ret = python_collector.collect()
    assert isinstance(ret, dict)
    assert ret['python']['version']['major'] == sys.version_info[0]
    assert ret['python']['version']['minor'] == sys.version_info[1]
    assert ret['python']['version']['micro'] == sys.version_info[2]
    assert ret['python']['version']['releaselevel'] == sys.version_info[3]
    assert ret['python']['version']['serial'] == sys.version_info[4]
    assert ret['python']['version_info'] == list(sys.version_info)
    assert ret['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:43:00.507453
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'
    assert pf._fact_ids == set()

# Generated at 2022-06-20 19:43:06.240189
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python', "PythonFactCollector.name == 'python'"
    assert fact_collector._fact_ids == set(), "PythonFactCollector._fact_ids is set()"
    assert fact_collector._platform == "Any", "PythonFactCollector._platform == 'Any'"
    assert fact_collector._collection_warnings == [], "PythonFactCollector._collection_warnings is []"

# Generated at 2022-06-20 19:43:08.915068
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert isinstance(pfc, PythonFactCollector)
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-20 19:43:11.005035
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test constructor can instantiate PythonFactCollector class."""
    pfc = PythonFactCollector()
    assert isinstance(pfc, PythonFactCollector)


# Generated at 2022-06-20 19:43:15.829568
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    facts, dummy_warnings = p.collect()
    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']

# Generated at 2022-06-20 19:43:18.618069
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-20 19:43:24.926401
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    pyfc.collect()
    assert sorted(pyfc.collect().keys()) == [u'python']
    assert sorted(pyfc.collect().get(u'python').keys()) == [u'executable', u'has_sslcontext', u'type', u'version', u'version_info']
    assert type(pyfc.collect().get(u'python').get(u'version_info')) == list

# Generated at 2022-06-20 19:43:26.821742
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector('any_module', 'any_collected_facts')
    assert fact_collector is not None

# Generated at 2022-06-20 19:43:29.740346
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()

# Unit test case for method collect of class PythonFactCollector

# Generated at 2022-06-20 19:43:41.003289
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Get an instance of the PythonFactCollector class
    fact_collector_instance = PythonFactCollector()
    # Get the return from the method collect
    python_facts = fact_collector_instance.collect()

    # Assert python_facts is not empty
    assert python_facts is not None

    # Assert version facts are provided and are integers
    assert python_facts['python']['version']['major'] is not None
    assert python_facts['python']['version']['minor'] is not None
    assert python_facts['python']['version']['micro'] is not None
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)

# Generated at 2022-06-20 19:43:44.894212
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert isinstance(python_fact_collector._fact_ids, set)
    assert len(python_fact_collector._fact_ids) == 0


# Generated at 2022-06-20 19:43:53.829272
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactsCollectionError

    def mock_loadfile(self):
        return

    mcollector = PythonFactCollector
    mcollector._load_file = mock_loadfile
    mfacts_dict = mcollector.collect()


# Generated at 2022-06-20 19:43:57.186076
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # TODO: Mock or make module_utils.facts.collector.BaseFactCollector.collect()
    pass

# Generated at 2022-06-20 19:44:07.726885
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import ansible.module_utils.facts.collector

    # Patch ssl.create_default_context to simulate the presence of SSLContext
    def create_default_context():
        return 1

    # Patch ssl.SSLContext
    class SSLContext:
        pass

    with ansible.module_utils.facts.collector.patch_ssl():
        sys.modules['ansible.module_utils.facts.collector'] = ansible.module_utils.facts.collector
        reload(ansible.module_utils.facts.collector)
        p = PythonFactCollector()
        python_facts = p.collect()

    assert python_facts['python']['has_sslcontext']

    # Patch ssl.create_default_context to simulate the absence of SSLContext
    def create_default_context():
        raise Import

# Generated at 2022-06-20 19:44:13.971406
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    facts = python_collector.collect()
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version_info'], list)
    assert 'executable' in facts

# Generated at 2022-06-20 19:44:16.524547
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    _obj = PythonFactCollector()
    assert _obj.name == 'python'


# Generated at 2022-06-20 19:44:18.854812
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert 'python' == c.name
    assert c.name in c._fact_ids

# Generated at 2022-06-20 19:44:21.051461
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:44:23.620108
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    # we should get the python version
    assert python_facts['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:44:29.119970
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert (python_fact_collector.name == 'python')

# Generated at 2022-06-20 19:44:30.944170
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact = PythonFactCollector()
    assert py_fact.collect()["python"]["executable"].lower().endswith("python")

# Generated at 2022-06-20 19:44:33.639366
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyfc = PythonFactCollector()
    results = pyfc.collect()
    assert results['python']['executable']

# Generated at 2022-06-20 19:44:37.896735
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    mod = sys.modules[__name__]
    collector = PythonFactCollector(mod)

    # Check if the constructor set the correct name
    assert collector.name == 'python'

    # Check if the correct fact IDs are set
    assert collector._fact_ids == set(['python'])

# Generated at 2022-06-20 19:44:47.015046
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    expected_dict = {'python': {'version': {'serial': 0, 'releaselevel': 'alpha', 'major': 2, 'minor': 7, 'micro': 13},
                                'has_sslcontext': True,
                                'version_info': [2, 7, 13, 'alpha', 0],
                                'executable': '/usr/local/bin/python',
                                'type': 'CPython'}}

    assert p.collect() == expected_dict

if __name__ == '__main__':
    test_PythonFactCollector_collect()

# Generated at 2022-06-20 19:44:55.588161
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create an instance
    pyfc = PythonFactCollector()

    # Invoke method
    result = pyfc.collect()

    # Verify expected results
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
   

# Generated at 2022-06-20 19:44:57.488630
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect()['python']['version']['major'] == sys.version_info[0]

# Generated at 2022-06-20 19:45:04.394495
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create a PythonFactCollector object
    python_fact_collector = PythonFactCollector()

    # Make a call to its collect method and check the result
    assert python_fact_collector.collect() == {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT,
        'type': sys.implementation.name
    }}

# Generated at 2022-06-20 19:45:15.271369
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''Test method collect of class PythonFactCollector'''
    pfc = PythonFactCollector()
    pfact_output = pfc.collect()
    assert pfact_output['python']['version']['major'] == sys.version_info[0]
    assert pfact_output['python']['version']['minor'] == sys.version_info[1]
    assert pfact_output['python']['version']['micro'] == sys.version_info[2]
    assert pfact_output['python']['version']['releaselevel'] == sys.version_info[3]
    assert pfact_output['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-20 19:45:18.584694
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector.collect() != {}


# Generated at 2022-06-20 19:45:32.558082
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    result = {
        'python': {
            'executable': '/usr/bin/python2.7',
            'has_sslcontext': True,
            'type': 'CPython',
            'version': {
                'major': 2,
                'minor': 7,
                'micro': 9,
                'releaselevel': 'final',
                'serial': 0
            },
            'version_info': [2, 7, 9, 'final', 0]
        }
    }

    obj = get_collector_instance(BaseFactCollector, 'python')

    assert result == obj.collect()

# Generated at 2022-06-20 19:45:38.187241
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    # Check that python_facts contains all the required data
    python_facts = python_collector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']

# Generated at 2022-06-20 19:45:43.461404
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python = PythonFactCollector()
    result = python.collect()
    assert 'python' in result
    assert 'type' in result['python']
    assert 'version' in result['python']
    assert 'version_info' in result['python']['version']
    assert 'executable' in result['python']
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-20 19:45:46.196782
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Constructor of PythonFactCollector should not throw any exception
    python_collector = PythonFactCollector()
    assert python_collector is not None

# Generated at 2022-06-20 19:45:50.879124
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Initialize a python fact collector object
    pythonFactCollector = PythonFactCollector()

    # Collect facts
    python_facts = pythonFactCollector.collect()

    # Assert that the fact collection succeeded
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:45:54.356200
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    m = PythonFactCollector()
    f = m.collect()

    assert 'python' in f
    assert 'version' in f['python']
    assert 'version_info' in f['python']

# Generated at 2022-06-20 19:45:56.196231
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'


# Generated at 2022-06-20 19:46:00.127256
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Unit test for PythonFactCollector
    """
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:46:05.959092
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector.collect()
    if (sys.version_info[0]) > 3:
        assert python_facts['python']['version']['major'] == 3
    else:
        assert python_facts['python']['version']['major'] == 2

    assert python_facts['python']['type'] == 'CPython'


# Generated at 2022-06-20 19:46:08.344737
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert python_facts._fact_ids == set()



# Generated at 2022-06-20 19:46:27.605523
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc.name == 'python'
    assert hasattr(py_fc, '_fact_ids') == True


# Generated at 2022-06-20 19:46:39.040342
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible_collections.ansible.community.tests.unit.compat import mock
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.plugins.module_utils import basic

    mock_module = mock.MagicMock()
    mock_module.params = {}

    my_obj = PythonFactCollector()
    my_obj.collect(mock_module)

    assert 'python' in basic.AnsibleModule._fact_cache

    with patch.dict(sys.modules, {'ansible_collections.ansible.community.plugins.module_utils': basic}):
        my_obj.collect(mock_module)

    assert len(basic.AnsibleModule._fact_cache) == 1

# Generated at 2022-06-20 19:46:41.497896
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts


test_collector = PythonFactCollector()

# Generated at 2022-06-20 19:46:50.038213
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import inspect
    import sys
    import pytest

    # create an object and invoke collect to get the facts
    col = PythonFactCollector()
    facts = PythonFactCollector().collect()

    # check the facts structure, do not check all the values as this may
    # natively test the OS or python version.
    assert len(facts.keys()) == 1
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]

# Generated at 2022-06-20 19:47:00.960234
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()
    assert 'python' in facts.keys()
    assert 'version' in facts['python'].keys()
    assert 'has_sslcontext' in facts['python'].keys()
    assert 'version_info' in facts['python'].keys()
    assert 'executable' in facts['python'].keys()
    assert 'type' in facts['python'].keys()

    if sys.version_info[0] <= 2:
        assert sys.version_info[0] == facts['python']['version']['major']
        assert sys.version_info[1] == facts['python']['version']['minor']
        assert sys.version_info[2] == facts['python']['version']['micro']

# Generated at 2022-06-20 19:47:07.740725
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version_info'][0] == sys.version_info[0]
    assert python_facts['python']['version_info'][1] == sys.version_info[1]
    assert python_facts['python']['version_info'][2] == sys.version_info[2]
    assert python_facts['python']['version_info'][3] == sys.version_info[3]
    assert python_facts['python']['version_info'][4] == sys.version_info[4]
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:47:16.088298
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    f = fc.collect()

    expected = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': None,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }

    assert f == expected

# Generated at 2022-06-20 19:47:19.714952
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:47:30.382527
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_obj = PythonFactCollector()
    asserted_result = {
        'python': {
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': None,
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info)
        }
    }
    result = test_obj.collect()

    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        # Python 2.6
        assert result

# Generated at 2022-06-20 19:47:40.183762
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = 'test'
    python_facts = PythonFactCollector().collect(module)
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:48:17.494259
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """test_PythonFactCollector: Test the constructor of PythonFactCollector """
    _fact_collector = PythonFactCollector()
    assert _fact_collector.name == 'python'



# Generated at 2022-06-20 19:48:19.800000
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-20 19:48:22.709897
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_collector = PythonFactCollector(None)
    assert facts_collector.name == 'python'
    assert facts_collector.priority == 10
    assert facts_collector._fact_ids == set()


# Generated at 2022-06-20 19:48:25.896027
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'


# Generated at 2022-06-20 19:48:33.650272
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert 'python' in result
    assert isinstance(result['python'], dict)
    assert result['python']

    assert 'version' in result['python']
    assert isinstance(result['python']['version'], dict)
    assert result['python']['version']

    assert 'version_info' in result['python']
    assert isinstance(result['python']['version_info'], list)
    assert result['python']['version_info']

    assert 'executable' in result['python']
    assert isinstance(result['python']['executable'], str)
    assert result['python']['executable']

    # skip has_sslcontext because it varies by python version
    # assert 'has_sslcontext

# Generated at 2022-06-20 19:48:36.157106
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector_class = PythonFactCollector()

    assert fact_collector_class.name == 'python'
    assert fact_collector_class._fact_ids == set()

# Generated at 2022-06-20 19:48:38.634238
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert(facts['python']['version']['releaselevel'] in ('alpha', 'beta', 'candidate', 'final'))

# Generated at 2022-06-20 19:48:50.671029
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    import pytest

    try:
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        # HAS_SSLCONTEXT will be True
        assert HAS_SSLCONTEXT
    except ImportError:
        # HAS_SSLCONTEXT will be False
        assert not HAS_SSLCONTEXT

    try:
        python_type = sys.subversion[0]
    except AttributeError:
        try:
            python_type = sys.implementation.name
        except AttributeError:
            python_type = None

    python_facts = FactCollector(None, None).collect(None, 'python')['ansible_facts']


# Generated at 2022-06-20 19:48:54.499536
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert isinstance(pfc._fact_ids, set)
    assert len(pfc._fact_ids) == 0


# Generated at 2022-06-20 19:48:59.740257
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert isinstance(pfc, PythonFactCollector)

if __name__ == '__main__':
    import pytest
    pytest.main(['-vs', __file__])

# Generated at 2022-06-20 19:50:17.701695
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    # This is what the python fact module should return
    expected_python_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'type': sys.subversion[0] if hasattr(sys, 'subversion') else None,
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }
    # This is the method the python fact module calls
    actual_python

# Generated at 2022-06-20 19:50:29.053554
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact = PythonFactCollector()
    actual_facts = python_fact.collect()

    expected_facts = {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }


# Generated at 2022-06-20 19:50:29.783582
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-20 19:50:36.717955
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    '''
    This test is for constructor of the class PythonFactCollector
    '''
    python_fact_obj = PythonFactCollector()
    try:
        assert python_fact_obj.name == 'python'
        assert len(python_fact_obj._fact_ids) == 0
    except Exception as err:
        print('TEST: python_fact_obj.name != \'python\'')
        raise err


# Generated at 2022-06-20 19:50:40.600333
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector.collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:50:42.762887
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-20 19:50:51.810376
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f.name == 'python'
    assert f._fact_ids == set()
    member = f.collect()
    assert member['python']
    assert member['python']['version']
    assert member['python']['version']['major'] == sys.version_info[0]
    assert member['python']['version']['minor'] == sys.version_info[1]
    assert member['python']['version']['micro'] == sys.version_info[2]
    assert member['python']['version']['releaselevel'] == sys.version_info[3]
    assert member['python']['version']['serial'] == sys.version_info[4]
    assert member['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:50:53.693805
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fact_collector = PythonFactCollector()
    assert py_fact_collector.name == "python"
    assert py_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:50:57.311039
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    try:
        python = PythonFactCollector(None, None)
    except Exception as e:
        pytest.fail(e)

# Generated at 2022-06-20 19:51:02.621311
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test dictionary returned by get_vars method
    found_facts = PythonFactCollector().collect()
    assert ('python' in found_facts)
    assert ('version' in found_facts['python'])
    assert ('version_info' in found_facts['python'])
    assert ('executable' in found_facts['python'])
    assert ('has_sslcontext' in found_facts['python'])
    assert ('type' in found_facts['python'])
