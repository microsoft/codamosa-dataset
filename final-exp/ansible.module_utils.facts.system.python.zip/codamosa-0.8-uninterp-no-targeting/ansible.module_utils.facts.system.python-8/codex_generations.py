

# Generated at 2022-06-20 19:42:44.350584
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector

# Generated at 2022-06-20 19:42:45.825932
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfact = PythonFactCollector()
    assert pfact is not None

# Generated at 2022-06-20 19:42:46.551792
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'

# Generated at 2022-06-20 19:42:47.853449
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """Test that the class constructor and methods do not raise exceptions."""
    PythonFactCollector()

# Generated at 2022-06-20 19:42:55.036064
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_collector = PythonFactCollector()
    py_facts = py_collector.collect()
    assert 'python' in py_facts
    assert 'version' in py_facts['python']
    assert 'version_info' in py_facts['python']
    assert 'executable' in py_facts['python']
    assert 'type' in py_facts['python']
    assert 'has_sslcontext' in py_facts['python']

# Generated at 2022-06-20 19:42:56.298267
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    f = PythonFactCollector()
    assert f.name == 'python'

# Generated at 2022-06-20 19:43:00.753340
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc.collect()['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:43:07.736295
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import collector
    from six.moves import reload_module
    facts = collector.get_facts_from_collectors(['python'])
    reload_module(sys)
    assert facts['python']['type'] == sys.implementation.name
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:43:09.172652
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector.collect(), dict)

# Generated at 2022-06-20 19:43:10.326925
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collect = PythonFactCollector()
    assert isinstance(collect.collect(), dict)

# Generated at 2022-06-20 19:43:23.724670
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()
    assert hasattr(python_facts, 'keys')
    assert 'python' in python_facts.keys()
    assert hasattr(python_facts['python'], 'keys')
    assert 'version' in python_facts['python'].keys()
    assert hasattr(python_facts['python']['version'], 'keys')
    assert 'major' in python_facts['python']['version'].keys()
    assert 'minor' in python_facts['python']['version'].keys()
    assert 'micro' in python_facts['python']['version'].keys()
    assert 'releaselevel' in python_facts['python']['version'].keys()
    assert 'serial' in python_facts['python']['version'].keys

# Generated at 2022-06-20 19:43:29.044400
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts, dict)
    assert 'python' in python_facts
    assert isinstance(python_facts['python'], dict)
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:43:31.662974
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()
    assert isinstance(PythonFactCollector._fact_ids, set)


# Generated at 2022-06-20 19:43:37.006917
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create an instance of the PythonFactCollector class
    python_collector = PythonFactCollector()

    # Call the method under test with arguments
    result = python_collector.collect()

    # Check the result
    assert(result is not None)
    assert(isinstance(result, dict))

# Generated at 2022-06-20 19:43:41.856278
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert type(obj.collect()) == dict
    assert obj.collect().get('python')

# Generated at 2022-06-20 19:43:51.830394
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test that PythonFactCollector.collect returns correct data
    python_fact_collector = PythonFactCollector()
    collected_facts = python_fact_collector.collect()

    assert collected_facts is not None
    assert "python" in collected_facts
    assert "version" in collected_facts["python"]
    assert "major" in collected_facts["python"]["version"]
    assert "minor" in collected_facts["python"]["version"]
    assert "micro" in collected_facts["python"]["version"]
    assert "releaselevel" in collected_facts["python"]["version"]
    assert "serial" in collected_facts["python"]["version"]
    assert "version_info" in collected_facts["python"]
    assert "executable" in collected_facts["python"]
    assert "has_sslcontext"

# Generated at 2022-06-20 19:44:02.303060
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fc = PythonFactCollector()
    facts = py_fc.collect()
    # expected_facts is the combined set of facts from the two possible
    # implementations of the dict.items() method

# Generated at 2022-06-20 19:44:09.461577
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert isinstance(result, dict)
    assert 'python' in result.keys()
    assert 'version' in result['python'].keys()
    assert 'version_info' in result['python'].keys()
    assert isinstance(result['python']['version_info'], list)
    assert 'executable' in result['python'].keys()
    assert 'type' in result['python'].keys()
    assert 'has_sslcontext' in result['python'].keys()

# Generated at 2022-06-20 19:44:12.414938
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-20 19:44:15.456513
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Verify that the constructor sets the _fact_ids attribute.
    fact_collector = PythonFactCollector()
    fact_ids = fact_collector._fact_ids
    assert 'python' in fact_ids

# Generated at 2022-06-20 19:44:26.155080
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # We start by instantiating PythonFactCollector
    pfc = PythonFactCollector()

    # Then we assert correct fact_id
    assert pfc.name == 'python'

    # assert that we have not yet collected facts
    assert not pfc.collected_facts

    # When we invoke collect, we get back a dict
    res = pfc.collect()

    # Make sure the dict contains the right keys
    assert 'python' in res
    assert 'version' in res['python']
    assert 'executable' in res['python']
    assert 'has_sslcontext' in res['python']

    # And that the values are what we expect
    assert isinstance(res['python']['version'], dict)
    assert isinstance(res['python']['version']['major'], int)

# Generated at 2022-06-20 19:44:28.059177
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfact_collector = PythonFactCollector()
    assert pythonfact_collector is not None

# Generated at 2022-06-20 19:44:32.686373
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert pfc is not None
    facts = pfc.collect()
    assert facts is not None
    assert facts['python'] is not None
    assert facts['python']['version'] is not None
    assert facts['python']['version']['major'] != None
    assert facts['python']['version_info'] is not None
    assert facts['python']['executable'] is not None

# Generated at 2022-06-20 19:44:44.924779
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Collect facts
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    # Assert facts
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'major' in facts['python']['version']
    assert isinstance(facts['python']['version']['major'], int)
    assert 'minor' in facts['python']['version']
    assert isinstance(facts['python']['version']['minor'], int)
    assert 'micro' in facts['python']['version']
    assert isinstance(facts['python']['version']['micro'], int)
    assert 'releaselevel'

# Generated at 2022-06-20 19:44:47.425920
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:44:55.138000
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, PythonFactCollector)
    assert python_fact_collector.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-20 19:44:58.010242
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import ansible.module_utils.facts.collector

    test_collector = ansible.module_utils.facts.collector.PythonFactCollector()
    test_collector.collect()

    assert test_collector._collector_data

# Generated at 2022-06-20 19:45:04.052078
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Remove legacy FACT_CACHE
    sys.modules.pop('ansible_facts', None)

    collector = PythonFactCollector()
    facts = collector.collect()

    facts.pop('python/executable')
    facts.pop('python/has_sslcontext')

    assert facts == {'python': {'type': 'CPython', 'version_info': [2, 7, 9, 'final', 0], 'version': {'releaselevel': 'final', 'minor': 7, 'micro': 9, 'major': 2, 'serial': 0}}}

# Generated at 2022-06-20 19:45:14.177284
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    gfc = PythonFactCollector()
    facts = gfc.collect()
    assert 'python' in facts, "'python' not present in returnded facts"
    assert 'version' in facts['python'], "'python.version' not present in returnded facts"
    assert 'version_info' in facts['python'], "'python.version_info' not present in returnded facts"
    assert 'executable' in facts['python'], "'python.executable' not present in returnded facts"
    assert 'has_sslcontext' in facts['python'], "'python.has_sslcontext' not present in returnded facts"
    assert 'type' in facts['python'], "'python.type' not present in returnded facts"

# Generated at 2022-06-20 19:45:25.375298
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    fact_list = python_fact_collector.collect()

    assert fact_list['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert fact_list['python']['version_info'] == list(sys.version_info)
    assert fact_list['python']['executable'] == sys.executable
    assert fact_list['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-20 19:45:43.333318
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fc = PythonFactCollector()
    python_facts = python_fc.collect()
    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert python_facts['python']['version_info'][3] in ('alpha', 'beta', 'candidate', 'final')
    assert isinstance(python_facts['python']['executable'], str)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:45:46.439069
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instantiate object
    python_fact_collector = PythonFactCollector()

    # Assert function call
    assert python_fact_collector.collect() != {}

# Generated at 2022-06-20 19:45:50.556204
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector({})
    data = python_collector.collect()
    assert isinstance(data, dict)
    assert 'python' in data
    assert 'version' in data['python']
    assert 'version_info' in data['python']
    assert isinstance(data['python']['version'], dict)
    assert isinstance(data['python']['version_info'], list)

# Generated at 2022-06-20 19:45:59.437315
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Unit test for method collect of class PythonFactCollector
    '''
    # Create a mock class for class BaseFactCollector
    class MockBaseFactCollector:
        pass

    # Create a mock class for module sys
    class MockSys:
        version_info = (2, 7, 8, 'beta', 1)
        executable = '/usr/bin/python'
        subversion = ('CPython', '', '')

    # Create a mock class for module ssl
    class MockSsl:
        def create_default_context(self):
            return 'ssl_context'

    # Save original sys class
    orig_sys_class = sys.__class__

    # Save original ssl class
    orig_ssl_class = ssl.__class__

    # Mock sys class
    sys.__class__ = MockSys



# Generated at 2022-06-20 19:46:09.823446
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc._module = None
    pfc._collected_facts = None
    python_facts = pfc.collect()
    assert "python" in python_facts
    assert "version" in python_facts["python"]
    assert isinstance(python_facts["python"]["version"], dict)
    assert "major" in python_facts["python"]["version"]
    assert "minor" in python_facts["python"]["version"]
    assert "micro" in python_facts["python"]["version"]
    assert "releaselevel" in python_facts["python"]["version"]
    assert "serial" in python_facts["python"]["version"]
    assert "version_info" in python_facts["python"]

# Generated at 2022-06-20 19:46:11.605349
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initialize class
    pc = PythonFactCollector()

    # Collect method should return a list
    assert(isinstance(pc.collect(), dict))

# Generated at 2022-06-20 19:46:23.422837
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = None
    collected_facts = None
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'

    # Test that the collector is able to collect a minimum amount of
    # facts when it is called
    python_facts = python_collector.collect(module=module,
        collected_facts=collected_facts)
    assert 'python' in python_facts

    # Test that the collector is able to collect a specific fact if
    # requested.
    python_facts = python_collector.collect(module=module,
        collected_facts=collected_facts)
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'executable' in python_facts['python']

# Generated at 2022-06-20 19:46:29.388264
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    x = PythonFactCollector()
    assert x.collect() == {'python': {'version': {'major': 3, 'minor': 5, 'micro': 2, 'releaselevel': 'final', 'serial': 0}, 'version_info': [3, 5, 2, 'final', 0], 'executable': '/usr/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-20 19:46:32.443018
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_val = PythonFactCollector()
    assert python_val.name == 'python'
    assert python_val._fact_ids == set()


# Generated at 2022-06-20 19:46:34.855933
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pf_collector = PythonFactCollector()
    pf_collection = pf_collector.collect()
    assert 'python' in pf_collection

# Generated at 2022-06-20 19:46:52.090095
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'


# Generated at 2022-06-20 19:46:58.193411
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact = PythonFactCollector()
    assert fact.collect() == {'python': {'version': {'major': 2, 'minor': 7, 'micro': 5, 'releaselevel': 'final', 'serial': 0}, 'version_info': [2, 7, 5, 'final', 0], 'executable': '/usr/local/bin/python', 'has_sslcontext': True, 'type': 'CPython'}}

# Generated at 2022-06-20 19:47:06.357501
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test with python 2
    if sys.version_info[0] == 2:
        assert PythonFactCollector().collect() == {'python': {'executable': '/usr/bin/python',
                                                              'has_sslcontext': False,
                                                              'version': {'major': 2,
                                                                          'micro': 7,
                                                                          'minor': 9,
                                                                          'releaselevel': 'final',
                                                                          'serial': 0},
                                                              'version_info': [2, 7, 9, 'final', 0],
                                                              'type': 'CPython'}}
    # Test with python 3

# Generated at 2022-06-20 19:47:08.137849
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    assert isinstance(pfc.collect(), dict)


# Generated at 2022-06-20 19:47:10.652394
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc.collect()

# Generated at 2022-06-20 19:47:13.512722
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector.fact_class_name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:47:18.213905
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
  python_collector = PythonFactCollector()
  assert isinstance(python_collector,BaseFactCollector)
  assert python_collector.name == 'python'
  assert python_collector._fact_ids == set()


# Generated at 2022-06-20 19:47:29.333044
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create a PythonFactCollector instance
    python_fact_collector = PythonFactCollector()

    # Retrieve facts
    collected_facts = python_fact_collector.collect()

    # Assert that the value of the key 'two' in the collected facts
    # equals to the expected value

# Generated at 2022-06-20 19:47:39.712034
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Check that the a value of python->version->serial is returned.
    py_version_info = sys.version_info
    py_executable = sys.executable
    pfc = PythonFactCollector()
    py_facts = pfc.collect()
    assert py_version_info[4] == py_facts['python']['version']['serial']
    assert py_version_info[0] == py_facts['python']['version']['major']
    assert py_version_info[1] == py_facts['python']['version']['minor']
    assert py_version_info[2] == py_facts['python']['version']['micro']
    assert py_version_info[3] == py_facts['python']['version']['releaselevel']
    assert py_exec

# Generated at 2022-06-20 19:47:43.942242
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Initialize PythonFactCollector object
    pfc = PythonFactCollector(None)

    # Check if name attribute is properly set
    assert pfc.name == 'python'

# Generated at 2022-06-20 19:48:23.013680
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    # Verify that at least some of the attributes are correct
    # It is not possible to test every attribute
    assert fact_collector.collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_collector.collected_facts['python']['executable'] == sys.executable
    assert fact_collector.collected_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:48:26.385481
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'
    assert PythonFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:48:30.413562
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    cls = PythonFactCollector()
    result=cls.collect()
    assert result['python'] is not None


if __name__ == '__main__':
    # Unit test for class PythonFactCollector
    cls = PythonFactCollector()
    result=cls.collect()
    assert result['python'] is not None

# Generated at 2022-06-20 19:48:34.119432
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()

    # Check to see if at least these keys are present
    assert 'python' in result and \
        'version' in result['python'] and \
        'type' in result['python'] and \
        'version_info' in result['python'] and \
        'executable' in result['python'] and \
        'has_sslcontext' in result['python']

# Generated at 2022-06-20 19:48:35.436062
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-20 19:48:37.782160
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector(None)

    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set()

# Generated at 2022-06-20 19:48:45.436599
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert PythonFactCollector().collect() == {'python':
            {'executable': '/usr/bin/python2.7',
            'version': {'micro': 4,
                        'minor': 7,
                        'releaselevel': 'final',
                        'major': 2,
                        'serial': 0},
            'type': 'CPython',
            'version_info': [2, 7, 4, 'final', 0],
            'has_sslcontext': True}
    }

# Generated at 2022-06-20 19:48:48.776487
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python', \
       'Test failed because __init__ is not working properly'


# Generated at 2022-06-20 19:48:52.149055
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set()


# Generated at 2022-06-20 19:49:03.786583
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    fact_ids = python_fact_collector.collect()
    assert fact_ids is not None
    assert len(fact_ids) > 0
    assert fact_ids['python']['version']['major'] == sys.version_info[0]
    assert fact_ids['python']['version']['minor'] == sys.version_info[1]
    assert fact_ids['python']['version']['micro'] == sys.version_info[2]
    assert fact_ids['python']['version']['releaselevel'] == sys.version_info[3]
    assert fact_ids['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-20 19:50:19.192281
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'major' in python_facts['python']['version']
    assert 'minor' in python_facts['python']['version']
    assert 'micro' in python_facts['python']['version']
    assert 'releaselevel' in python_facts['python']['version']
    assert 'serial' in python_facts['python']['version']
    assert 'type' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:50:24.677609
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector()
    facts = python_facts.collect()

    assert 'python' in facts
    assert len(facts['python']) == 5
    assert 'version' in facts['python']
    assert len(facts['python']['version']) == 5
    assert facts['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:50:34.076771
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    #
    # Test collect method of class PythonFactCollector
    #
    collector = PythonFactCollector()

    # Test a 'standard' python installation
    python_facts = collector.collect()
    assert 'python' in python_facts # return a dictionary with correct key 'python'
    assert 'version' in python_facts['python'] # 'version' sub-dictionary is present
    assert 'version_info' in python_facts['python'] # 'version_info' sub-list is present
    assert 'executable' in python_facts['python'] # 'executable' sub-value is present

    # Test a python installation in virtualenv
    python_facts = collector.collect()
    assert 'type' in python_facts['python'] # 'type' sub-value is present

    # Test a Jython installation
    python_facts = collector.collect()

# Generated at 2022-06-20 19:50:40.460465
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()

    py_facts = py_fact_collector.collect()
    assert 'python' in py_facts
    assert 'version' in py_facts['python']
    assert 'version_info' in py_facts['python']
    assert 'executable' in py_facts['python']
    assert 'type' in py_facts['python']
    assert 'has_sslcontext' in py_facts['python']

# Generated at 2022-06-20 19:50:45.505002
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert 'python' in result
    assert 'version_info' in result['python']
    assert type(result['python']['version_info']) == list
    assert len(result['python']['version_info']) == 5
    assert type(result['python']['version_info'][0]) == int
    assert type(result['python']['version_info'][1]) == int
    assert type(result['python']['version_info'][2]) == int
    assert type(result['python']['version_info'][3]) == str
    assert type(result['python']['version_info'][4]) == int

    assert 'version' in result['python']

# Generated at 2022-06-20 19:50:47.470379
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), BaseFactCollector)

# Generated at 2022-06-20 19:50:49.325548
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    module = object
    returned_fact_type = PythonFactCollector(module).name
    assert returned_fact_type == 'python'

# Generated at 2022-06-20 19:50:51.338118
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts import Collector

    fc = Collector.get_fact_collector(Collector.CACHE_TYPE_FULL)
    assert isinstance(fc, PythonFactCollector)

# Generated at 2022-06-20 19:50:52.258968
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'

# Generated at 2022-06-20 19:50:58.211069
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  python_fact_collector = PythonFactCollector()
  python_facts = python_fact_collector.collect()
  assert python_facts
  assert python_facts['python']
  assert python_facts['python']['version']
  assert python_facts['python']['version_info']
  assert python_facts['python']['executable']
  assert python_facts['python']['has_sslcontext']