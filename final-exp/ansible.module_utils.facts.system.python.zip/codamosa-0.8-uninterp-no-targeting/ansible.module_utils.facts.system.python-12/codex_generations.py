

# Generated at 2022-06-20 19:42:58.438222
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    python_facts = collector.collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts

# Generated at 2022-06-20 19:43:00.202853
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector is not None


# Generated at 2022-06-20 19:43:03.906561
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    my_facts = pfc.collect()
    expected_keys = [u'python']
    assert sorted(my_facts.keys()) == sorted(expected_keys)
    assert my_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:43:06.157476
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    Constructor test: Checks if all attributes are of the right kind
    """
    p = PythonFactCollector()
    assert p.name is not None

# Generated at 2022-06-20 19:43:08.575672
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    module = sys.modules[__name__]
    py_coll = PythonFactCollector(module=module)
    py_coll.collect()

# Generated at 2022-06-20 19:43:11.469028
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # NOTE: This is not currently a full-fledged test, but more of a placeholder
    #       to make sure the method returns at all (otherwise the function will be
    #       unreachable and therefore cannot be tested at all.)

    c = PythonFactCollector()
    c.collect()

# Generated at 2022-06-20 19:43:16.407747
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert sys.version_info.__class__.__name__ == 'sys.version_info'
    assert isinstance(collector.collect(), dict) and collector.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'type': 'CPython',
            'has_sslcontext': HAS_SSLCONTEXT
        }
    }

# Generated at 2022-06-20 19:43:27.767713
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    This is a unit test of the method collect of the class PythonFactCollector
    There is only one method to be test so I am omitting the setUpClass and the tearDownClass
    '''

    # pylint: disable=too-many-locals
    '''
    The setUp method of the class
    '''
    collector = PythonFactCollector()
    # The data structure returned by the method collect

# Generated at 2022-06-20 19:43:38.136127
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

    # Verify the collect function returns a dict with at least 'python' key
    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts, dict)
    assert python_facts.get('python') is not None
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']

# Generated at 2022-06-20 19:43:42.129379
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set(['python'])

# Generated at 2022-06-20 19:43:52.383001
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    collected_facts = pfc.collect()
    assert isinstance(collected_facts, dict)
    assert collected_facts['python'] is not None
    assert collected_facts['python']['version'] is not None
    assert collected_facts['python']['version_info'] is not None
    assert collected_facts['python']['executable'] is not None
    assert collected_facts['python']['type'] is not None
    assert collected_facts['python']['has_sslcontext'] is not None

# Generated at 2022-06-20 19:43:58.016406
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert str(PythonFactCollector) == "<class 'ansible.module_utils.facts.system.python.PythonFactCollector'>"
    py_collector = PythonFactCollector()
    assert py_collector.name == 'python'
    assert py_collector._fact_ids == set()


# Generated at 2022-06-20 19:44:05.529456
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert result == {"python":
                        {
                            "version": {
                                "major": 2, "minor": 7, "micro": 15,
                                "releaselevel": "final", "serial": 0
                            },
                            "version_info": [2, 7, 15, "final", 0],
                            "executable": "/usr/bin/python2.7",
                            "has_sslcontext": False,
                       }
                    }

# Generated at 2022-06-20 19:44:08.059235
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    x._fact_ids.add('a')
    assert len(x._fact_ids) == 1


# Generated at 2022-06-20 19:44:11.868842
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pythonfactcollector = PythonFactCollector()
    fact = pythonfactcollector.collect()
    assert fact['python']['type'] == "CPython"
    if sys.version_info[0] == 2:
        assert fact['python']['has_sslcontext'] == False
    else:
        assert fact['python']['has_sslcontext'] == True

# Generated at 2022-06-20 19:44:22.713681
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.collector.python import PythonFactCollector

    def __test_module(name, **kwargs):
        return ModuleFacts(name, **kwargs)

    # construct object for testing, for case where sslcontext is present
    pyfc1 = PythonFactCollector()

    # construct object for testing, for case where sslcontext is not present
    pyfc2 = PythonFactCollector()

    testmodule = __test_module("testmodule",
                               _python_module_facts_module=pyfc1,
                               _python_module_facts_module_sslcontext=pyfc2)

    # test the module method

# Generated at 2022-06-20 19:44:25.072353
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python = PythonFactCollector()
    assert python.name == 'python'

# Generated at 2022-06-20 19:44:33.619082
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector()
    collected_facts = python_collector.collect()
    assert collected_facts['python']['executable'] == sys.executable
    assert collected_facts['python']['version']['major'] == sys.version_info[0]
    assert collected_facts['python']['version']['minor'] == sys.version_info[1]
    assert collected_facts['python']['version']['micro'] == sys.version_info[2]
    assert collected_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert collected_facts['python']['version']['serial'] == sys.version_info[4]
    assert collected_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-20 19:44:45.506844
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    pf = pc.collect()
    assert 'python' in pf
    assert 'version' in pf['python']
    assert 'type' in pf['python']
    assert 'version_info' in pf['python']
    assert 'executable' in pf['python']
    assert 'has_sslcontext' in pf['python']
    assert pf['python']['type'] in ['CPython', 'PyPy']
    # Check a few properties of the "version" dict
    assert 'major' in pf['python']['version']
    assert 'minor' in pf['python']['version']
    assert 'micro' in pf['python']['version']
    assert 'releaselevel' in pf['python']['version']

# Generated at 2022-06-20 19:44:47.626587
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()


# Generated at 2022-06-20 19:45:02.140985
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pf_dict = pfc.collect()
    # Check that some keys are present in python_dict.
    # Unlikely that all would be removed in the future.
    assert 'version' in pf_dict['python']
    assert 'major' in pf_dict['python']['version']
    assert 'micro' in pf_dict['python']['version']
    assert 'version_info' in pf_dict['python']
    assert 'executable' in pf_dict['python']
    assert 'has_sslcontext' in pf_dict['python']
    assert 'type' in pf_dict['python']

# Generated at 2022-06-20 19:45:03.361154
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'

# Generated at 2022-06-20 19:45:04.391379
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()

# Generated at 2022-06-20 19:45:13.889341
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector({}, [])
    output = p.collect()
    assert 'python' in output
    assert 'version' in output['python']
    assert 'major' in output['python']['version']
    assert 'minor' in output['python']['version']
    assert 'micro' in output['python']['version']
    assert 'releaselevel' in output['python']['version']
    assert 'serial' in output['python']['version']
    assert 'version_info' in output['python']
    assert 'executable' in output['python']
    assert 'type' in output['python']
    assert 'has_sslcontext' in output['python']

# Generated at 2022-06-20 19:45:25.062508
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = { 'python': {
                'version': {
                    'major': sys.version_info[0],
                    'minor': sys.version_info[1],
                    'micro': sys.version_info[2],
                    'releaselevel': sys.version_info[3],
                    'serial': sys.version_info[4]
                },
                'version_info': list(sys.version_info),
                'executable': sys.executable,
                'has_sslcontext': HAS_SSLCONTEXT
            }
    }


# Generated at 2022-06-20 19:45:31.994311
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector(None)
    assert python_collector['python']['type'] == sys.implementation.name
    assert python_collector['python']['version']['major'] == sys.version_info[0]
    assert python_collector['python']['version']['minor'] == sys.version_info[1]
    assert python_collector['python']['version']['micro'] == sys.version_info[2]
    assert python_collector['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_collector['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-20 19:45:35.591459
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()
    assert obj.collect()['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:45:37.801426
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fac_col = PythonFactCollector()
    py_fac_col.collect()
    assert py_fac_col.name == 'python'

# Generated at 2022-06-20 19:45:40.156949
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    temp = PythonFactCollector()
    output = temp.collect()
    assert output is not None
    assert 'python' in output

# Generated at 2022-06-20 19:45:45.380022
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'type' in python_facts['python']
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'version_info' in python_facts['python']

# Generated at 2022-06-20 19:46:08.547324
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()

    fact_collector._module = MockModule
    fact_collector._collected_facts = dict()
    # As the module and collected_facts parameters aren't used in collect method, the test case pass None values
    facts = fact_collector.collect(None, None)

    assert 'python' in facts
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']


# Generated at 2022-06-20 19:46:15.004664
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Setup
    python_facts = {'python': {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }}

    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python_facts

# Generated at 2022-06-20 19:46:18.612474
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    python_facts = pfc.collect()

    assert python_facts['python']['version_info'][0] == sys.version_info[0]
    assert python_facts['python']['version_info'][1] == sys.version_info[1]
    assert python_facts['python']['version_info'][2] == sys.version_info[2]
    assert python_facts['python']['version_info'][3] == sys.version_info[3]
    assert python_facts['python']['version_info'][4] == sys.version_info[4]
    assert python_facts['python']['executable'] == sys.executable
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:46:19.842470
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector()


# Generated at 2022-06-20 19:46:28.024659
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """unit test for method collect of class PythonFactCollector"""

    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts
    assert isinstance(python_facts['python']['version'], dict)
    assert 'version_info' in python_facts['python']
    assert isinstance(python_facts['python']['version_info'], list)
    assert 'executable' in python_facts['python']
    assert 'has_sslcontext' in python_facts['python']
    assert 'type' in python_facts['python']

# Generated at 2022-06-20 19:46:32.333232
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    assert len(fact_collector.collect()) == 1
    assert isinstance(fact_collector._fact_ids, set)
    assert fact_collector.collect().get('python')

# Generated at 2022-06-20 19:46:43.100356
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance

    fixture_module = None
    fixture_collected_facts = None

    # Unit test for case when PythonFactCollector is not supported

# Generated at 2022-06-20 19:46:43.866184
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyf = PythonFactCollector()
    pyf.collect()

# Generated at 2022-06-20 19:46:52.051165
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # test ssl context.
    context = {'python': {'has_sslcontext': HAS_SSLCONTEXT}}
    python_fact_collector = PythonFactCollector(None)

    # test python.version
    version_info = sys.version_info
    version = {'major': version_info[0],
               'minor': version_info[1],
               'micro': version_info[2],
               'releaselevel': version_info[3],
               'serial': version_info[4]}
    python = {'version': version,
              'version_info': list(version_info),
              'executable': sys.executable,
              'has_sslcontext': HAS_SSLCONTEXT}

# Generated at 2022-06-20 19:46:53.571392
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'

# Generated at 2022-06-20 19:47:35.613222
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys

    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts['python']['version'] == {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    if sys.version_info >= (2, 7):
        assert facts['python']['has_sslcontext'] is True

# Generated at 2022-06-20 19:47:37.148530
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    my_obj = PythonFactCollector()
    assert type(my_obj) == PythonFactCollector


# Generated at 2022-06-20 19:47:42.993139
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Test collector with python facts
    python_facts = PythonFactCollector().collect()
    assert 'python' in python_facts

    # Test python fact
    python_fact = python_facts['python']
    assert 'version' in python_fact
    assert 'version_info' in python_fact
    assert 'executable' in python_fact
    assert 'has_sslcontext' in python_fact
    assert 'type' in python_fact

    # Test version of python fact
    version = python_fact['version']
    assert 'major' in version
    assert 'minor' in version
    assert 'micro' in version
    assert 'releaselevel' in version
    assert 'serial' in version

    # Test python executable
    assert python_fact['executable'] == sys.executable

    # Test has_sslcontext
    assert python_fact

# Generated at 2022-06-20 19:47:45.163248
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:47:48.533300
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    result = obj.collect()
    assert 'version_info' in result['python']
    assert 'executable' in result['python']
    assert 'version' in result['python']
    assert 'has_sslcontext' in result['python']
    assert 'type' in result['python']

# Generated at 2022-06-20 19:47:50.200228
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()


# Generated at 2022-06-20 19:47:52.908938
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()
    assert x.collect()

# Generated at 2022-06-20 19:47:55.932378
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:48:00.307678
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:48:00.979064
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-20 19:49:13.130710
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_facts = {
        'python': {
            'executable': '/usr/bin/python3.3',
            'version': {
                'releaselevel': 'final',
                'micro': 3,
                'serial': 0,
                'major': 3,
                'minor': 3
            },
            'has_sslcontext': HAS_SSLCONTEXT,
            'version_info': [
                3,
                3,
                3,
                'final',
                0
            ],
            'type': 'CPython'
        }
    }
    py_facts_collector = PythonFactCollector()
    assert py_facts == py_facts_collector.collect()

# Generated at 2022-06-20 19:49:25.166355
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-20 19:49:27.913664
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector.name == 'python'
    assert python_collector._fact_ids == set(['python_version'])

# Generated at 2022-06-20 19:49:32.766747
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_obj = PythonFactCollector()
    assert python_obj.name == 'python'
    assert isinstance(python_obj._fact_ids, set)


# Generated at 2022-06-20 19:49:38.705182
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts = pc.collect()

    python_facts = {'python': {'version': {'major': sys.version_info[0], 'minor': sys.version_info[1], 'micro': sys.version_info[2], 'releaselevel': sys.version_info[3], 'serial': sys.version_info[4]}, 'has_sslcontext': HAS_SSLCONTEXT, 'type': 'cpython', 'version_info': list(sys.version_info), 'executable': sys.executable}}

    assert facts == python_facts


# Generated at 2022-06-20 19:49:47.318394
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    try:
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        HAS_SSLCONTEXT = True
    except ImportError:
        HAS_SSLCONTEXT = False

    python_facts = PythonFactCollector()
    facts = python_facts.collect()
    # Check if version_info is a list
    assert isinstance(facts['python']['version_info'], list)
    # Check if version is a dict
    assert isinstance(facts['python']['version'], dict)
    # Check if version_info and version have the same length
    assert len(facts['python']['version_info']) == len(facts['python']['version'])
    # Check if executable is valid
    assert facts['python']['executable'] == sys.exec

# Generated at 2022-06-20 19:49:53.169827
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    result = p.collect()
    assert type(result['python']['version']) == dict
    assert type(result['python']['version_info']) == list
    assert type(result['python']['executable']) == str
    assert type(result['python']['has_sslcontext']) == bool
    assert type(result['python']['type']) == str

# Generated at 2022-06-20 19:49:59.446325
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert isinstance(PythonFactCollector().collect(), dict)
    assert isinstance(PythonFactCollector().collect()['python']['version']['major'], int)
    assert isinstance(PythonFactCollector().collect()['python']['version']['minor'], int)
    assert isinstance(PythonFactCollector().collect()['python']['version']['micro'], int)
    assert isinstance(PythonFactCollector().collect()['python']['version']['releaselevel'], str)
    assert isinstance(PythonFactCollector().collect()['python']['version']['serial'], int)
    assert isinstance(PythonFactCollector().collect()['python']['version_info'], list)

# Generated at 2022-06-20 19:50:05.672591
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector(None)
    collected_facts = { 'ansible_python': { 'type': 'CPython', 'version': '2.7.14', 'version_info': [2, 7, 14, 'final', 0], 'has_sslcontext': False, 'executable': '/usr/bin/python' } }
    assert collected_facts == python_fact_collector.collect()

# Generated at 2022-06-20 19:50:16.070255
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Check the content of the Python fact
    assert PythonFactCollector().collect() == {
            'python': {
                'version': {
                    'major': sys.version_info[0],
                    'minor': sys.version_info[1],
                    'micro': sys.version_info[2],
                    'releaselevel': sys.version_info[3],
                    'serial': sys.version_info[4]
                },
                'version_info': list(sys.version_info),
                'executable': sys.executable,
                'has_sslcontext': HAS_SSLCONTEXT,
                'type': 'CPython'
            }
    }

# Generated at 2022-06-20 19:52:47.363850
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    col = PythonFactCollector()
    facts = col.collect()
    assert type(facts) is dict
    assert facts['python']
    assert facts['python']['version']
    assert type(facts['python']['version']['major']) is int
    assert facts['python']['version']['minor']
    assert facts['python']['version']['micro']
    assert facts['python']['version']['releaselevel']
    assert facts['python']['version']['serial']
    assert type(facts['python']['version_info']) is list
    assert type(facts['python']['version_info'][0]) is int
    assert len(facts['python']['version_info']) == 5
    assert facts['python']['executable']