

# Generated at 2022-06-20 19:42:49.411192
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:42:52.177225
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    a = PythonFactCollector()
    assert a

# Generated at 2022-06-20 19:42:54.642610
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert (python_facts['python']['version']['minor'] > 2)

# Generated at 2022-06-20 19:43:01.579129
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()

    python_facts = pfc.collect()

    assert isinstance(python_facts, dict)
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)

# Generated at 2022-06-20 19:43:02.943672
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()

    assert collector is not None

# Generated at 2022-06-20 19:43:08.651938
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    collected_facts = fact_collector.collect()
    assert 'python' in collected_facts
    assert 'version' in collected_facts['python']
    assert 'version_info' in collected_facts['python']
    assert 'executable' in collected_facts['python']
    assert 'has_sslcontext' in collected_facts['python']
    assert 'type' in collected_facts['python']

# Generated at 2022-06-20 19:43:12.801178
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    result = p.collect()
    # 'version', 'version_info' and 'executable' are required keys
    assert set(['version', 'version_info', 'executable']) == set(result['python'].keys())
    # 'type' is not a required key
    assert set(['version', 'version_info', 'executable']) <= set(result['python'].keys())



# Generated at 2022-06-20 19:43:13.982351
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc is not None


# Generated at 2022-06-20 19:43:21.557459
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    result = pfc.collect()
    assert result['python']['version_info'][0] == 3
    assert 'version' in result['python'].keys()
    assert 'version_info' in result['python'].keys()
    assert result['python']['version']['major'] == 3
    assert 'executable' in result['python'].keys()
    assert type(result['python']['executable']) is str
    assert 'type' in result['python'].keys()

# Generated at 2022-06-20 19:43:27.798724
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert isinstance(pfc._fact_ids, set)
    assert pfc.file_name == 'python'

    # Test with_file_name parameter
    pfc = PythonFactCollector(with_file_name=False)
    assert pfc.file_name is None

    # Test is_supported method
    assert pfc.is_supported() == True

# Generated at 2022-06-20 19:43:40.455455
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import types
    # Create an empty module
    module = types.ModuleType('ansible_test_module')
    module.params = {'gather_subset': 'all'}

    # make the test fail if we are not gathering all facts
    assert module.params['gather_subset'] == 'all', "gather_subset is not set to 'all'"

    fact_collector = PythonFactCollector(module=module)

    # Test that method collect works when it is called without parameters
    result = fact_collector.collect()
    assert isinstance(result, dict), "unexpected return type of method collect"

    # Test that method collect works when providing an empty dictionary
    result = fact_collector.collect(collected_facts=dict())
    assert isinstance(result, dict), "unexpected return type of method collect"


# Generated at 2022-06-20 19:43:46.609447
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method collect of class PythonFactCollector."""
    # Test with no arguments
    test_python_fact_collector = PythonFactCollector()
    test_python_fact_collector_collected_facts = test_python_fact_collector.collect()
    assert 'python' in test_python_fact_collector_collected_facts
    assert 'version' in test_python_fact_collector_collected_facts['python']
    assert 'major' in test_python_fact_collector_collected_facts['python']['version']
    assert 'minor' in test_python_fact_collector_collected_facts['python']['version']
    assert 'micro' in test_python_fact_collector_collected_facts['python']['version']
    assert 'releaselevel' in test_python

# Generated at 2022-06-20 19:43:49.150043
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfact = PythonFactCollector()

    assert pythonfact.name == 'python'
    assert pythonfact.collect()  # do not fail


# Generated at 2022-06-20 19:43:59.825974
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = {'python': {
        'executable': '/usr/bin/python',
        'has_sslcontext': False,
        'type': 'CPython',
        'version': {
            'major': 2,
            'micro': 5,
            'minor': 5,
            'releaselevel': 'final',
            'serial': 0},
        'version_info': [2,
                         5,
                         5,
                         'final',
                         0]
    }
    }

    pfc = PythonFactCollector()
    # make sure we get a dictionary back
    assert isinstance(pfc.collect(), dict)
    # make sure we get the right dictionary
    assert pfc.collect() == python_facts

# Generated at 2022-06-20 19:44:01.001831
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc is not None


# Generated at 2022-06-20 19:44:02.651466
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert not PythonFactCollector()._skip_collect
    assert PythonFactCollector.name == 'python'

# Generated at 2022-06-20 19:44:05.196838
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert hasattr(obj, 'collect')

# Generated at 2022-06-20 19:44:12.821725
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collectors import which
    try:
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        has_sslcontext = True
    except ImportError:
        has_sslcontext = False

    python_facts = FactCollector(module="fake_module", collected_facts={}).collect(collectors=["python"])['python']
    assert python_facts['executable'] == which('python')
    assert python_facts['type'] != ''
    assert python_facts['version_info'][0] == sys.version_info[0]
    assert python_facts['version_info'][1] == sys.version_info[1]

# Generated at 2022-06-20 19:44:16.476156
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == {}
    assert obj._fact_ids.__class__.__name__ == 'set'


# Generated at 2022-06-20 19:44:19.900063
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()

    assert(c.name == 'python')
    assert(isinstance(c._fact_ids, set))
    assert(len(c._fact_ids) == 0)

# Generated at 2022-06-20 19:44:31.990333
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert 'python' in python_facts
    assert 'version' in python_facts['python']
    assert 'version_info' in python_facts['python']

    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['version'], dict)

# Generated at 2022-06-20 19:44:41.919344
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    res = collector.collect()
    assert res['python']['version']['major'] == sys.version_info[0]
    assert res['python']['version']['minor'] == sys.version_info[1]
    assert res['python']['version']['micro'] == sys.version_info[2]
    assert res['python']['type'] == sys.implementation.name
    assert res['python']['executable'] == sys.executable
    assert res['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert res['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:44:42.796267
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-20 19:44:45.206988
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    result = PythonFactCollector()
    assert result is not None

# Generated at 2022-06-20 19:44:54.330218
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_class
    from ansible.module_utils.facts.collector import list_collection_classes

    # Instantiation of collector classes
    c_collector = Collector()
    c_pfc = PythonFactCollector()
    c_get_collector_instance = get_collector_instance()
    c_get_collector_class = get_collector_class('python')
    c_list_collection_classes = list_collection_classes()

    # Verify Collector is a class
    assert isinstance(Collector, type)

    # Verify get_collector_instance is a PythonFactCollector instance

# Generated at 2022-06-20 19:45:02.741810
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import sys
    import test.support as test_support
    fact_collector = PythonFactCollector()
    fact_collector.collect()
    expected_facts_python_version = {
        'major': sys.version_info[0],
        'minor': sys.version_info[1],
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4]
    }
    expected_facts_python_version_info = list(sys.version_info)
    expected_facts_python_type = ''

# Generated at 2022-06-20 19:45:07.911185
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Testing empty module input
    assert PythonFactCollector().collect(module='', collected_facts='') == {'python': {'has_sslcontext': True, 'version_info': [2, 7, 12, 'final', 0], 'version': {'major': 2, 'minor': 7, 'releaselevel': 'final', 'micro': 12, 'serial': 0}, 'executable': '/usr/bin/python', 'type': 'CPython'}}

# Generated at 2022-06-20 19:45:12.094883
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()
    assert callable(pfc.collect)


# Generated at 2022-06-20 19:45:13.930013
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert python_facts['python']['type'] == 'CPython'

# Generated at 2022-06-20 19:45:18.698406
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    facts = c.collect()
    assert 'python' in facts
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT
    assert 'type' in facts['python']
    assert 'version' in facts['python']

# Generated at 2022-06-20 19:45:31.944265
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_col = PythonFactCollector()
    assert py_col.name == 'python'
    assert py_col._fact_ids == set()


# Generated at 2022-06-20 19:45:33.226553
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'

# Generated at 2022-06-20 19:45:44.352607
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Initializing a PythonFactCollector object
    py_col_obj = PythonFactCollector()

    returned_facts = py_col_obj.collect()

    assert returned_facts['python']['version']['major'] == sys.version_info[0]
    assert returned_facts['python']['version']['minor'] == sys.version_info[1]
    assert returned_facts['python']['version']['micro'] == sys.version_info[2]
    assert returned_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert returned_facts['python']['version']['serial'] == sys.version_info[4]
    assert returned_facts['python']['version_info'] == list(sys.version_info)
    assert returned_facts

# Generated at 2022-06-20 19:45:52.330601
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    sys_version_info = sys.version_info
    sys_version_info_as_list = list(sys_version_info)
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert python_facts['python']['version']['major'] == sys_version_info[0]
    assert python_facts['python']['version']['minor'] == sys_version_info[1]
    assert python_facts['python']['version']['micro'] == sys_version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys_version_info[3]
    assert python_facts['python']['version']['serial'] == sys_version_info[4]
    assert python_facts

# Generated at 2022-06-20 19:46:00.285935
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import platform
    import subprocess

    # Get the Python version information
    major = sys.version_info[0]
    minor = sys.version_info[1]
    micro = sys.version_info[2]
    releaselevel = sys.version_info[3]
    serial = sys.version_info[4]

    # Get the Python executable
    executable = sys.executable

    # Get the Python type
    try:
        python_type = sys.subversion[0]
    except AttributeError:
        try:
            python_type = sys.implementation.name
        except AttributeError:
            python_type = None

    # Declare a blank dict to hold the Python facts
    python_facts = {}

    # Build the Python fact dict

# Generated at 2022-06-20 19:46:05.397941
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Instantiate the object
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert isinstance(pfc._fact_ids, set)
    assert len(pfc._fact_ids) == 0

    # It should have a collect method
    assert callable(pfc.collect)

# Generated at 2022-06-20 19:46:07.323255
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    mf = PythonFactCollector()

    # Just check that this doesn't throw an exception.
    mf.collect(collected_facts=dict())

# Generated at 2022-06-20 19:46:08.239605
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'

# Generated at 2022-06-20 19:46:10.340835
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    my_obj =  PythonFactCollector()
    assert my_obj.name == 'python'
    assert my_obj._fact_ids == set()


# Generated at 2022-06-20 19:46:15.655792
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fc = PythonFactCollector()
    result = fc.collect()

    # Assert correct structure of the returned facts
    assert isinstance(result, dict)
    assert 'python' in result.keys()
    assert isinstance(result['python'], dict)
    assert set(result['python'].keys()) == set(('version', 'version_info', 'executable', 'has_sslcontext'))

    # Assert a specific set of expected keys for the 'version' dict
    # This is not a full test, which would need to test the underlying implementation of
    # each of these facts
    assert set(result['python']['version'].keys()) == set(('major', 'minor', 'micro', 'releaselevel', 'serial'))

# Generated at 2022-06-20 19:46:34.248705
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()

# Generated at 2022-06-20 19:46:43.839599
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_collector = PythonFactCollector(None, {}, {})
    assert python_collector.collect() == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'type': sys.implementation.name,
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT
        },
    }

# Generated at 2022-06-20 19:46:44.924494
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'

# Generated at 2022-06-20 19:46:46.978036
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_fc = PythonFactCollector()
    assert py_fc.name == 'python'
    assert py_fc._fact_ids == set()


# Generated at 2022-06-20 19:46:48.024214
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert isinstance(PythonFactCollector(), PythonFactCollector)


# Generated at 2022-06-20 19:46:51.433429
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector(None, None, None)
    facts = collector.collect(None)
    assert isinstance(facts, dict)
    assert 'python' in facts
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert 'version_info' in facts['python']
    assert 'executable' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-20 19:46:54.404208
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """ PythonFactCollector class is instantiated
    """
    python_fact_collector = PythonFactCollector()
    assert isinstance(python_fact_collector, PythonFactCollector)


# Generated at 2022-06-20 19:47:03.656939
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    class ModuleMock(object):
        def __init__(self):
            self.params = {'gather_subset': ['!all', 'min']}
            self.fail_json = 10

    module_mock = ModuleMock()
    python_facts = PythonFactCollector(module_mock)
    assert python_facts.name == 'python'
    assert python_facts.module == module_mock
    assert python_facts._gather_subset == ['!all', 'min']
    assert python_facts._gather_network == False
    assert python_facts.FACTS_CACHE == '/opt/ansible/cache/ansible_facts.cache'  # noqa


# Generated at 2022-06-20 19:47:15.258057
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Get a PythonFactCollector
    python = PythonFactCollector()

    # Collect facts
    facts = python.collect()

    assert isinstance(facts, dict)
    assert isinstance(facts['python'], dict)
    assert 'version' in facts['python']
    assert isinstance(facts['python']['version'], dict)
    assert 'major' in facts['python']['version']
    assert 'minor' in facts['python']['version']
    assert 'micro' in facts['python']['version']
    assert 'releaselevel' in facts['python']['version']
    assert 'serial' in facts['python']['version']
    assert 'version_info' in facts['python']
    assert isinstance(facts['python']['version'], list)

# Generated at 2022-06-20 19:47:23.226315
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Create object
    python_fact_collector = PythonFactCollector()

    # Tests
    python_facts = python_fact_collector.collect()
    assert 'python' in python_facts.keys()
    assert 'version' in python_facts['python'].keys()
    assert 'version_info' in python_facts['python'].keys()
    assert 'executable' in python_facts['python'].keys()
    assert 'has_sslcontext' in python_facts['python'].keys()

# Generated at 2022-06-20 19:48:04.682466
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    result = python_fact_collector.collect()
    assert result['python']['version'] == {'major': sys.version_info[0],
                                           'minor': sys.version_info[1],
                                           'micro': sys.version_info[2],
                                           'releaselevel': sys.version_info[3],
                                           'serial': sys.version_info[4]}
    assert result['python']['version_info'] == list(sys.version_info)
    assert result['python']['executable'] == sys.executable
    assert result['python']['type'] is not None
    assert result['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:48:06.458964
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collecter = PythonFactCollector()
    assert collecter.name == 'python'

# Generated at 2022-06-20 19:48:06.982154
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    PythonFactCollector()

# Generated at 2022-06-20 19:48:08.705012
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:48:20.069559
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    """
    Unit test class constructor without any arguments
    """
    # Create an instance of class PythonFactCollector
    python_fact_collector = PythonFactCollector()
    # Check if the attribute name is set correctly
    assert python_fact_collector.name == 'python'
    # Check if the attribute _fact_ids is empty
    if len(python_fact_collector._fact_ids) == 0:
        assert True
    else:
        assert False

    # Unit test with arguments
    # Create an instance of class PythonFactCollector
    python_fact_collector1 = PythonFactCollector(name='ansible', fact_ids=['a', 'b'])
    # Check if the attribute name is set correctly
    assert python_fact_collector1.name == 'ansible'
    # Check if the attribute _fact_ids

# Generated at 2022-06-20 19:48:21.335252
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts is not None

# Generated at 2022-06-20 19:48:29.301575
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    expected_result = {
        "python": {
            "version": {
                "micro": 0,
                "releaselevel": "final",
                "serial": 0,
                "major": 2,
                "minor": 7
            },
            "executable": "/usr/bin/python",
            "has_sslcontext": True,
            "version_info": [
                2,
                7,
                0,
                "final",
                0
            ]
        }
    }
    assert(PythonFactCollector().collect() == expected_result)

# Generated at 2022-06-20 19:48:36.964582
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert type(python_facts) == dict
    assert "python" in python_facts
    assert type(python_facts['python']) == dict
    assert "type" in python_facts['python']
    assert type(python_facts['python']['type']) == str
    assert "version" in python_facts['python']
    assert type(python_facts['python']['version']) == dict
    assert "version_info" in python_facts['python']
    assert type(python_facts['python']['version_info']) == list
    assert len(python_facts['python']['version_info']) == 5
    assert "executable" in python_facts['python']
    assert type(python_facts['python']['executable']) == str
   

# Generated at 2022-06-20 19:48:37.490835
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pass

# Generated at 2022-06-20 19:48:39.213436
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'
    assert obj._fact_ids == set()
    

# Generated at 2022-06-20 19:49:56.820649
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    collected_facts = collector.collect()
    assert collected_facts == {
        'python': {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': list(sys.version_info),
            'executable': sys.executable,
            'has_sslcontext': HAS_SSLCONTEXT,
            'type': sys.implementation.name
        }
    }

# Generated at 2022-06-20 19:49:59.017723
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pf = PythonFactCollector()
    assert pf.name == 'python'

# Generated at 2022-06-20 19:50:05.911485
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    Meaning of return value:
      - If None is returned all tests have been successful.
      - If a string starting with 'ERROR:' is returned all later tests are skipped and
        the test represented by the returned string has failed.
    """

    py_fc = PythonFactCollector()
    python_facts = py_fc.collect()
    assert python_facts != {}

    return None

if __name__ == '__main__':
    print(test_PythonFactCollector_collect())

# Generated at 2022-06-20 19:50:09.990005
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)

# Generated at 2022-06-20 19:50:12.091316
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()
    assert c.collect()

# Generated at 2022-06-20 19:50:14.988205
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    # check if only one id is defined
    assert len(collector._fact_ids) == 1
    assert collector._fact_ids.pop() == 'python'

# Generated at 2022-06-20 19:50:20.335804
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()
    assert isinstance(python_facts['python'], dict)
    assert isinstance(python_facts['python']['version'], dict)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], str)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)
    assert python_facts['python']['has_sslcontext'] == HAS_SSLCONTEXT

# Generated at 2022-06-20 19:50:30.798430
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_version = {
        'micro': sys.version_info[2],
        'releaselevel': sys.version_info[3],
        'serial': sys.version_info[4],
        'major': sys.version_info[0],
        'minor': sys.version_info[1]
    }
    collector = PythonFactCollector()
    assert collector is not None
    assert collector.name == 'python'
    assert 'python' in collector._fact_ids
    assert collector.collect()['python']['version'] == python_version
    assert collector.collect()['python']['version_info'] == list(sys.version_info)
    assert collector.collect()['python']['executable'] == sys.executable
    python_type = sys.implementation.name

# Generated at 2022-06-20 19:50:35.548968
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert fact_collector.name == 'python'
    assert 'executable' in fact_collector.collect().keys()
    assert 'version' in fact_collector.collect().keys()
    assert 'version_info' in fact_collector.collect().keys()

# Generated at 2022-06-20 19:50:38.002023
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'
    assert PythonFactCollector()._fact_ids == set(['python'])