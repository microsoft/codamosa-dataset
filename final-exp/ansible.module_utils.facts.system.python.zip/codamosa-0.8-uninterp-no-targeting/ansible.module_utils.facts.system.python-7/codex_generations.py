

# Generated at 2022-06-20 19:42:47.294575
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Patching class name
    PythonFactCollector.name = "test"

    pfc = PythonFactCollector()
    # Checking if collect method return not empty dictionary
    assert isinstance(pfc.collect(), dict)

# Generated at 2022-06-20 19:42:52.490123
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.os
    import ansible.module_utils.facts.system.platform
    import ansible.module_utils.facts.system.pkg_mgr
    import ansible.module_utils.facts.system.timezone

    ansible.module_utils.facts.collector.BaseFactCollector.validate_OPTS = lambda self: None

    fact_module = ansible.module_utils.facts.system.distribution.Distribution()
    collected_facts = ansible.module_utils.facts.system.distribution.Distribution.collect(fact_module, collected_facts=None)

# Generated at 2022-06-20 19:43:00.325987
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Unit test function for testing method collect of class PythonFactCollector."""

    # Check if we have SSLContext support
    try:
        from ssl import create_default_context, SSLContext
        del create_default_context
        del SSLContext
        HAS_SSLCONTEXT = True
    except ImportError:
        HAS_SSLCONTEXT = False

    # Create a PythonFactCollector object
    python_fact_collector = PythonFactCollector()

    # Call method collect
    collected_facts = python_fact_collector.collect()

    # Check if the facts are what we expect them to be

# Generated at 2022-06-20 19:43:03.418225
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    result = fact_collector.collect()
    assert result.get('python')
    assert result.get('python').get('version')
    assert result.get('python').get('version_info')

# Generated at 2022-06-20 19:43:05.581038
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-20 19:43:13.536467
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Create a new instance of our class
    collector = PythonFactCollector(module)

    # We mock the facts collector to return an empty list
    # This way, our mock of the class works the same way as it should
    # when it runs in the code
    mocker = Collector.collect
    Collector.collect = lambda self: []
    python_facts = collector.collect()

# Generated at 2022-06-20 19:43:15.127582
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    tester = PythonFactCollector()
    # test attribute name
    assert tester.name == 'python'

# Generated at 2022-06-20 19:43:16.403401
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    assert len(PythonFactCollector().collect().keys()) == 1

# Generated at 2022-06-20 19:43:19.207015
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert obj.name == 'python'

# Generated at 2022-06-20 19:43:28.629480
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_facts = PythonFactCollector()
    facts = py_facts.collect()

    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable

    # Python 2.7

# Generated at 2022-06-20 19:43:34.072531
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Test PythonFactCollector constructor
    o = PythonFactCollector()
    assert o.name == 'python'
    assert o._fact_ids == set()


# Generated at 2022-06-20 19:43:39.214540
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    fact_collector._read_fact_cache = lambda: dict()
    facts = fact_collector.collect()
    print(facts)
    assert facts['python']['version']['major'] == 3
    assert facts['python']['version']['minor'] == 7
    assert facts['python']['has_sslcontext'] == True
    assert facts['python']['type'] == 'CPython'


# Generated at 2022-06-20 19:43:44.661929
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    ansible_facts = collector.collect()
    # Check if some of the expected keys exist
    assert 'executable' in ansible_facts['python']
    assert 'releaselevel' in ansible_facts['python']['version']
    assert 'micro' in ansible_facts['python']['version']

# Generated at 2022-06-20 19:43:52.128471
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_python_fully_qualified_class_name = 'ansible.module_utils.facts.collectors.python.PythonFactCollector'

    # test PythonFactCollector class name
    assert PythonFactCollector.__name__ == 'PythonFactCollector', 'PythonFactCollector class has wrong name'
    assert PythonFactCollector.__qualname__ == test_python_fully_qualified_class_name, 'PythonFactCollector class has wrong fully qualified class name'

    # test if PythonFactCollector.collect method exists
    assert hasattr(PythonFactCollector, 'collect'), 'PythonFactCollector class does not have collect method'

# Generated at 2022-06-20 19:44:02.585197
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector(None).collect()

    assert type(python_facts) == dict

    # Test if values and keys have the correct type
    assert type(python_facts['python']) == dict
    assert type(python_facts['python']['type']) == str or python_facts['python']['type'] == None
    assert type(python_facts['python']['version']) == dict
    assert type(python_facts['python']['version']['major']) == int
    assert type(python_facts['python']['version']['minor']) == int
    assert type(python_facts['python']['version']['micro']) == int
    assert type(python_facts['python']['version']['releaselevel']) == str

# Generated at 2022-06-20 19:44:04.634706
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    ptc = PythonFactCollector(None)
    assert ptc is not None

# Generated at 2022-06-20 19:44:05.902164
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py_coll = PythonFactCollector()
    assert py_coll is not None

# Generated at 2022-06-20 19:44:08.800846
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set(), 'Facts ids should be empty'


# Generated at 2022-06-20 19:44:09.931292
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    py_fact_collector = PythonFactCollector()
    assert 'python' in py_fact_collector.collect()

# Generated at 2022-06-20 19:44:13.460710
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()

    # Test variables
    assert fact_collector.name == 'python'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:44:18.950950
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x is not None

# Generated at 2022-06-20 19:44:25.982246
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method collect of class PythonFactCollector"""
    pfc = PythonFactCollector()
    pf = pfc.collect()

    if pf['python']['type'] == 'CPython':
        assert pf['python']['version_info'] == [2, 7, 15, 'final', 0]
    elif pf['python']['type'] == 'PyPy':
        assert pf['python']['version_info'] == [2, 7, 13, 'final', 0]
    else:
        assert False, "Unknown Python interpreter"

# Generated at 2022-06-20 19:44:27.479568
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-20 19:44:31.449794
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """
    This method tests the collect method of class PythonFactCollector on various OSes
    """

    pf = PythonFactCollector()
    collected_facts = pf.collect()
    python_facts = collected_facts['python']

    assert python_facts['type'] is not None
    assert python_facts['version']['major'] == sys.version_info[0]
    assert python_facts['version']['minor'] == sys.version_info[1]
    assert python_facts['version']['micro'] == sys.version_info[2]
    assert python_facts['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-20 19:44:43.151240
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)
    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], str)
    assert isinstance(python_facts['python']['has_sslcontext'], bool)

# Generated at 2022-06-20 19:44:45.505897
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pfc = PythonFactCollector()
    pfc.collect()

# Generated at 2022-06-20 19:44:46.972296
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'

# Generated at 2022-06-20 19:44:48.158197
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'

# Generated at 2022-06-20 19:44:56.367695
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    facts_collector = PythonFactCollector()
    assert facts_collector.name == 'python'
    assert facts_collector._fact_ids == set()
    assert facts_collector.collect()['python']['version']['major'] == sys.version_info[0]
    assert facts_collector.collect()['python']['version']['minor'] == sys.version_info[1]
    assert facts_collector.collect()['python']['version']['micro'] == sys.version_info[2]
    assert facts_collector.collect()['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts_collector.collect()['python']['version']['serial'] == sys.version_info[4]
    assert facts_collector.collect

# Generated at 2022-06-20 19:45:03.704104
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = {}
    python_facts['python'] = {
        'version': {
            'major': sys.version_info[0],
            'minor': sys.version_info[1],
            'micro': sys.version_info[2],
            'releaselevel': sys.version_info[3],
            'serial': sys.version_info[4]
        },
        'version_info': list(sys.version_info),
        'executable': sys.executable,
        'has_sslcontext': HAS_SSLCONTEXT
    }

    try:
        python_facts['python']['type'] = sys.subversion[0]
    except AttributeError:
        try:
            python_facts['python']['type'] = sys.implementation.name
        except AttributeError:
            python

# Generated at 2022-06-20 19:45:23.305343
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['version']['major'] == sys.version_info[0]
    assert python_facts['python']['version']['minor'] == sys.version_info[1]
    assert python_facts['python']['version']['micro'] == sys.version_info[2]
    assert python_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert python_facts['python']['version']['serial'] == sys.version_info[4]
    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable

# Generated at 2022-06-20 19:45:25.858281
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:45:27.051146
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    assert collector.collect()['python']

# Generated at 2022-06-20 19:45:40.157060
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()

    assert isinstance(python_facts['python']['version']['major'], int)
    assert isinstance(python_facts['python']['version']['minor'], int)
    assert isinstance(python_facts['python']['version']['micro'], int)
    assert isinstance(python_facts['python']['version']['releaselevel'], str)
    assert isinstance(python_facts['python']['version']['serial'], int)

    assert isinstance(python_facts['python']['version_info'], list)
    assert isinstance(python_facts['python']['executable'], str)
    assert isinstance(python_facts['python']['type'], str)

# Generated at 2022-06-20 19:45:47.012701
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
  pfc = PythonFactCollector(None)

  # This test is only valid for python 2.7 or above.
  assert hasattr(sys, 'implementation')

  collected_facts = pfc.collect()

  # Test python facts
  assert collected_facts['python']
  assert collected_facts['python']['executable']
  assert collected_facts['python']['has_sslcontext']
  assert collected_facts['python']['version']

# Generated at 2022-06-20 19:45:50.203369
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test PythonFactCollector.collect()"""
    # Create a new instance of the PythonFactCollector
    python_fc = PythonFactCollector()

    # Run the collect method (returns dict)
    data = python_fc.collect()

    # Verify that the return data is a dict
    assert isinstance(data, dict)

# Generated at 2022-06-20 19:45:59.196078
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Instantiate a PythonFactCollector object
    python_collector = PythonFactCollector()

    # Create a dict with a key named as the name of the collector
    # and a value set to None
    collected_facts = {python_collector.name: None}

    # Execute method collect
    python_collector.collect(collected_facts=collected_facts)

    # Assert the returned value is not None
    assert collected_facts[python_collector.name] is not None

    # Assert the returned value is a dict
    assert isinstance(collected_facts[python_collector.name], dict)

    # Assert it contains the keys expected
    assert 'python' in collected_facts[python_collector.name]
    assert 'version' in collected_facts[python_collector.name]['python']
   

# Generated at 2022-06-20 19:46:06.533814
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    from ansible.module_utils.facts.collectors import collect_subset_of_facts
    pfc = PythonFactCollector()
    raw_facts = collect_subset_of_facts(pfc)['python']
    assert isinstance(raw_facts, dict)
    assert 'version' in raw_facts
    assert 'version_info' in raw_facts
    assert 'executable' in raw_facts
    assert 'has_sslcontext' in raw_facts
    assert 'type' in raw_facts



# Generated at 2022-06-20 19:46:08.871950
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    fact_collector = PythonFactCollector()
    assert (fact_collector.name == 'python')
    assert (fact_collector._fact_ids == set())


# Generated at 2022-06-20 19:46:10.341400
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:46:21.376972
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)
    assert obj.name == 'python'
    assert issubclass(PythonFactCollector, BaseFactCollector)

# Generated at 2022-06-20 19:46:23.028252
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pythonfact = PythonFactCollector()
    assert pythonfact.name == 'python'

# Generated at 2022-06-20 19:46:25.748647
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:46:27.359504
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p.name == 'python'
    assert p._fact_ids == set([])

# Generated at 2022-06-20 19:46:34.375733
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """ Test the private _collect method of the PythonFactCollector class
    """
    python_facts = PythonFactCollector()
    ret = python_facts.collect(collected_facts=dict())
    assert ret['python']['version']['major'] == sys.version_info[0]
    assert ret['python']['version']['minor'] == sys.version_info[1]
    assert ret['python']['version']['micro'] == sys.version_info[2]
    assert ret['python']['version']['releaselevel'] == sys.version_info[3]
    assert ret['python']['version']['serial'] == sys.version_info[4]
    assert ret['python']['version_info'] == list(sys.version_info)

# Generated at 2022-06-20 19:46:36.086169
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'


# Generated at 2022-06-20 19:46:43.756367
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    result = {'Facts':{'python':{'has_sslcontext':False,
    'version':{'major':2, 'minor':7, 'micro':15, 'releaselevel':'final', 'serial':0},
    'version_info': [2, 7, 15, 'final', 0], 'executable':'/usr/bin/python',
    'type':'CPython'}}}
    obj = PythonFactCollector()
    assert obj._fact_ids == set()
    assert obj.name == 'python'
    assert obj.collect() == result

# Generated at 2022-06-20 19:46:44.522149
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pass

# Generated at 2022-06-20 19:46:51.514219
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    def mock_collect(self, module=None, collected_facts=None):
        return {
            "ansible_python": {
                "executable": "/usr/bin/python3",
                "has_sslcontext": True,
                "type": "CPython",
                "version": {
                    "major": 3,
                    "micro": 6,
                    "minor": 8,
                    "releaselevel": "final",
                    "serial": 0
                },
                "version_info": [
                    3,
                    8,
                    6,
                    "final",
                    0
                ]
            }
        }

    test_PythonFactCollector = PythonFactCollector()
    test_PythonFactCollector.collect = mock_collect
    result = test_PythonFactCollector.collect()

# Generated at 2022-06-20 19:46:54.088283
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_facts = PythonFactCollector()
    assert python_facts.name == 'python'
    assert python_facts._fact_ids == set()


# Generated at 2022-06-20 19:47:13.508874
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pyFactCollector = PythonFactCollector()
    collected_facts = {
        'ansible_python': {
            'version': {
                'major': '2.7',
                'micro': '8',
                'minor': '6',
                'releaselevel': 'final',
                'serial': '0'
            },
            'version_info': [
                '2.7',
                '8',
                '6',
                'final',
                '0'
            ],
            'executable': '/usr/bin/python',
            'has_sslcontext': True,
            'type': 'CPython'
        }
    }

    assert pyFactCollector.collect() == collected_facts

# Generated at 2022-06-20 19:47:15.020221
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert c._fact_ids == set()


# Generated at 2022-06-20 19:47:26.076135
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    '''
    Test the collect method of the PythonFactCollector against a known result
    '''

    # Import the module to be tested
    from ansible.module_utils.facts.collectors.python.python import PythonFactCollector

    # Create an instance of the module to be tested with a fake module
    module = object()
    python_fact_collector = PythonFactCollector(module)

    # Execute the collect method against a known result
    result = python_fact_collector.collect()

    # Set the known result

# Generated at 2022-06-20 19:47:29.057185
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    c = PythonFactCollector()
    assert c.name == 'python'
    assert isinstance(c._fact_ids, set)

# Generated at 2022-06-20 19:47:33.275396
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    python_facts = python_fact_collector.collect()

    assert python_facts['python']['version_info'] == list(sys.version_info)
    assert python_facts['python']['executable'] == sys.executable



# Generated at 2022-06-20 19:47:36.641887
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()


# Generated at 2022-06-20 19:47:42.744603
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    collector = PythonFactCollector()
    facts = collector.collect()
    assert facts['python']['version']['major'] == sys.version_info[0]
    assert facts['python']['version']['minor'] == sys.version_info[1]
    assert facts['python']['version']['micro'] == sys.version_info[2]
    assert facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert facts['python']['version']['serial'] == sys.version_info[4]
    assert facts['python']['version_info'] == list(sys.version_info)
    assert facts['python']['executable'] == sys.executable
    assert facts['python']['has_sslcontext'] == HAS_SSLCONTEXT


# Generated at 2022-06-20 19:47:51.226501
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_fact_collector = PythonFactCollector()
    facts = python_fact_collector.collect()

    try:
        version_info = facts['python']['version_info']
    except KeyError:
        raise AssertionError('python fact not found')

    if type(version_info) is not list:
        raise AssertionError('python.version_info is not a list')

    if len(version_info) != 5:
        raise AssertionError('python.version_info does not match length of sys.version_info')

    for idx,val in enumerate(version_info):
        if type(val) is not int:
            raise AssertionError('python.version_info[{}] is not an integer'.format(idx))

# Generated at 2022-06-20 19:48:00.141479
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    pc = PythonFactCollector()
    facts_dict = pc.collect()
    # Check that version is set
    assert 'version' in facts_dict['python']
    # Check that version_info is set
    assert 'version_info' in facts_dict['python']
    # Check that has_sslcontext is set
    assert 'has_sslcontext' in facts_dict['python']
    # Check that executable is set
    assert 'executable' in facts_dict['python']
    # Check that type is set
    assert 'type' in facts_dict['python']

# Generated at 2022-06-20 19:48:01.930872
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    my_obj = PythonFactCollector()
    print("Unit test for PythonFactCollector.py")

# Generated at 2022-06-20 19:48:24.787310
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():

    # Create empty input parameters
    collected_facts = {}

    # Create an instance of PythonFactCollector class
    fact_collector = PythonFactCollector()

    # Call collect method of PythonFactCollector class
    result = fact_collector.collect(collected_facts=collected_facts)

    # Assert the result
    assert result['python']['version']['major'] == sys.version_info[0]
    assert result['python']['version']['minor'] == sys.version_info[1]
    assert result['python']['version']['micro'] == sys.version_info[2]
    assert result['python']['version']['releaselevel'] == sys.version_info[3]
    assert result['python']['version']['serial'] == sys.version_info[4]

# Generated at 2022-06-20 19:48:25.936406
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert(PythonFactCollector.name == 'python')

# Generated at 2022-06-20 19:48:28.368245
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_fact_collector = PythonFactCollector()
    assert python_fact_collector.name == 'python'
    assert python_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:48:32.670963
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    # Use the module to play nicely with other unit tests
    python_facts_collector = PythonFactCollector()
    facts = python_facts_collector.collect()
    assert 'version_info' in facts['python']
    assert len(facts['python']['version_info']) == 5
    assert 'executable' in facts['python']
    assert 'has_sslcontext' in facts['python']
    assert 'type' in facts['python']

# Generated at 2022-06-20 19:48:34.351027
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    obj = PythonFactCollector()
    assert isinstance(obj, PythonFactCollector)
    assert obj.collect()

# Generated at 2022-06-20 19:48:36.200394
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    py = PythonFactCollector('collect')
    assert py
    assert py.name == 'python'

# Generated at 2022-06-20 19:48:42.885665
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    if sys.version_info[0] >= 3:
        py_ver = {
            'version': {
                'major': sys.version_info[0],
                'minor': sys.version_info[1],
                'micro': sys.version_info[2],
                'releaselevel': sys.version_info[3],
                'serial': sys.version_info[4]
            },
            'version_info': [3, 6, 3, 'final', 0],
            'executable': sys.executable,
            'has_sslcontext': True
        }

# Generated at 2022-06-20 19:48:51.602814
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert python_facts['python']['type'] == 'CPython'
    assert python_facts['python']['version']['major'] == 2
    assert python_facts['python']['version']['minor'] == 7
    assert python_facts['python']['version']['micro'] == 5
    assert python_facts['python']['version']['releaselevel'] == 'final'
    assert python_facts['python']['version']['serial'] == 0
    assert python_facts['python']['version_info'] == [2, 7, 5, 'final', 0]

# Generated at 2022-06-20 19:48:53.187773
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector is not None


# Generated at 2022-06-20 19:48:54.499213
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'

# Generated at 2022-06-20 19:49:31.190776
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    p = PythonFactCollector()
    assert p is not None

# Generated at 2022-06-20 19:49:33.480798
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    x = PythonFactCollector()
    assert x.name == 'python'
    assert 'python' in x._fact_ids


# Generated at 2022-06-20 19:49:43.611081
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    """Test method collect of class PythonFactCollector."""
    # TODO: Save and restore sys.version
    # TODO: Save and restore sys.subversion
    # TODO: Save and restore sys.version_info
    # TODO: Save and restore sys.executable
    # TODO: Save and restore ssl.create_default_context
    # TODO: Save and restore ssl.SSLContext
    # TODO:  Save and restore ssl.HAS_SSLCONTEXT
    python_facts = PythonFactCollector()
    facts = python_facts.collect()
    assert 'python' in facts, \
        "Returned facts are missing 'python'"
    assert 'version' in facts['python'], \
        "Returned facts['python'] are missing 'version'"

# Generated at 2022-06-20 19:49:47.281766
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    assert PythonFactCollector().name == 'python'
    assert PythonFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:49:53.802073
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    f = PythonFactCollector()
    assert isinstance(f.collect()['python']['version'],dict)
    assert isinstance(f.collect()['python']['version_info'],list)
    assert isinstance(f.collect()['python']['executable'],str)
    assert isinstance(f.collect()['python']['type'],str)
    assert isinstance(f.collect()['python']['has_sslcontext'],bool)

# Generated at 2022-06-20 19:49:59.812191
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    test_obj = PythonFactCollector()

    returned_facts = test_obj.collect()
    assert returned_facts['python']['version']['major'] == sys.version_info[0]
    assert returned_facts['python']['version']['minor'] == sys.version_info[1]
    assert returned_facts['python']['version']['micro'] == sys.version_info[2]
    assert returned_facts['python']['version']['releaselevel'] == sys.version_info[3]
    assert returned_facts['python']['version']['serial'] == sys.version_info[4]
    assert returned_facts['python']['version_info'] == sys.version_info
    assert returned_facts['python']['executable'] == sys.executable
    assert returned_

# Generated at 2022-06-20 19:50:07.054267
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    fact_collector = PythonFactCollector()
    facts = fact_collector.collect()

    python_facts = {
        'executable': '/usr/bin/python3',
        'has_sslcontext': True,
        'type': 'CPython',
        'version': {
            'major': 3,
            'minor': 5,
            'micro': 2,
            'releaselevel': 'final',
            'serial': 0
        },
        'version_info': [
            3,
            5,
            2,
            'final',
            0
        ]
    }

    assert facts == {'python': python_facts}

# Generated at 2022-06-20 19:50:17.633608
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    obj = PythonFactCollector()
    module = {}
    collected_facts = {}
    result = obj.collect(module, collected_facts)
    assert result is not None
    assert result is not False
    assert result is not ''
    assert isinstance(result, dict)
    assert 'python' in result
    assert result['python'] is not None
    assert result['python'] is not False
    assert result['python'] is not ''
    assert isinstance(result['python'], dict)
    assert 'version' in result['python']
    assert result['python']['version'] is not None
    assert result['python']['version'] is not False
    assert result['python']['version'] is not ''
    assert isinstance(result['python']['version'], dict)

# Generated at 2022-06-20 19:50:20.689979
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert type(pfc._fact_ids) is set


# Generated at 2022-06-20 19:50:23.115258
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert collector._fact_ids is not None

# Generated at 2022-06-20 19:51:39.544974
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    # Instanciate the class
    x = PythonFactCollector()

    # Check the name is 'python'
    assert x.name == 'python'

    # Check it is using a set()
    assert isinstance(x._fact_ids, set)

    # Check a public attribute type
    assert x.name == 'python'

# Generated at 2022-06-20 19:51:40.991334
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    c = PythonFactCollector()
    assert isinstance(c.collect(module=None, collected_facts=None), dict)

# Generated at 2022-06-20 19:51:45.826791
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    p = PythonFactCollector()
    fact = p.collect()
    assert fact == dict(python=dict(version=dict(major=2, minor=7,
                                                 micro=12, releaselevel='final',
                                                 serial=0),
                                    version_info=[2, 7, 12, 'final', 0],
                                    executable='/usr/bin/python',
                                    has_sslcontext=True,
                                    type='CPython'))

# Generated at 2022-06-20 19:51:51.851469
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    from ansible.module_utils.facts.collector import Collector
    assert issubclass(PythonFactCollector, Collector)

# Unit test to ensure the presence of a method named 'collect' in class PythonFactCollector

# Generated at 2022-06-20 19:51:54.477033
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pfc = PythonFactCollector()
    assert pfc.name == 'python'
    assert pfc._fact_ids == set()

# Generated at 2022-06-20 19:51:56.775090
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    collector = PythonFactCollector()
    assert collector.name == 'python'
    assert PythonFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:52:00.276648
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    python_collector = PythonFactCollector()
    assert python_collector._fact_ids == set()
    assert python_collector.name == 'python'

# Generated at 2022-06-20 19:52:02.309787
# Unit test for constructor of class PythonFactCollector
def test_PythonFactCollector():
    pycol = PythonFactCollector()
    assert pycol.name == 'python'
    assert len(pycol._fact_ids) == 0


# Generated at 2022-06-20 19:52:08.214000
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    result = PythonFactCollector().collect()

    # Tests that python dict was created.
    assert 'python' in result
    # Tests that version dict was created.
    assert 'version' in result['python']
    # Tests that version_info list was created.
    assert 'version_info' in result['python']
    # Tests that type was created.
    assert 'type' in result['python']
    # Tests that executable was created.
    assert 'executable' in result['python']
    # Tests that has_sslcontext was created.
    assert 'has_sslcontext' in result['python']

# Generated at 2022-06-20 19:52:17.622349
# Unit test for method collect of class PythonFactCollector
def test_PythonFactCollector_collect():
    python_facts = PythonFactCollector().collect()
    assert type(python_facts) is dict, 'Invalid type returned!'
    assert python_facts, 'Empty facts dictionary returned!'
    assert python_facts['python'], 'Empty python dictionary returned!'
    assert python_facts['python']['version'], 'Empty python version dictionary returned!'
    assert python_facts['python']['version_info'], 'Empty python version info dictionary returned!'

if __name__ == '__main__':
    print('=== Running tests for module_utils.facts.python.py ===')
    print('--- Running test_PythonFactCollector_collect()... ---')
    test_PythonFactCollector_collect()
    print('--- Running test_PythonFactCollector_collect()... PASSED ---')